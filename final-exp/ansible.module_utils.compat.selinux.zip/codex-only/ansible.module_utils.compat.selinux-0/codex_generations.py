

# Generated at 2022-06-22 22:22:36.931980
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    path = "/tmp"

    # Make sure we can get the context of /tmp, if the function returns a context ('sys_u:sys_r:sys_t:s0').
    # If we get an error or the return value is NULL, then the function failed.
    out = lgetfilecon_raw(path)
    try:
        assert out[0] == 0
        assert out[1] == 'sys_u:sys_r:sys_t:s0'
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-22 22:22:39.990529
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:22:47.704140
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        import unittest.mock as mock
        from unittest.mock import call, DEFAULT
    except ImportError:
        import mock
        from mock import call, DEFAULT

    # If a lot of testing like this is needed, consider integrating into ansible-test

    _mock_char_p = type(mock.DEFAULT)
    _mock_int = type(mock.DEFAULT.value)

    # FIXME: stub this out
    return '', 0


# Generated at 2022-06-22 22:22:48.596151
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    selinux_getenforcemode()



# Generated at 2022-06-22 22:22:52.514473
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw
    """
    from ansible.module_utils.selinux import lgetfilecon_raw
    assert lgetfilecon_raw(__file__) == [0, 'system_u:object_r:default_t:s0']



# Generated at 2022-06-22 22:22:56.324489
# Unit test for function matchpathcon
def test_matchpathcon():
    a = matchpathcon("/system/bin/foo", 0)
    print("{0} (0x{1:x})".format(a[0], a[0]))
    print("{0}".format(a[1]))



# Generated at 2022-06-22 22:22:58.833775
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw(b'/proc/version')
    print(rc)
    print(result)
    assert(rc == 0 and result is not None)


# Generated at 2022-06-22 22:23:04.561996
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw

    p = '/etc/shadow'
    rc, con = lgetfilecon_raw(to_bytes(p))
    assert rc != -1
    assert len(con) > 0

# Generated at 2022-06-22 22:23:06.489477
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, ret = selinux_getpolicytype()
    assert rc == 0
    assert ret.startswith('targeted')

# Generated at 2022-06-22 22:23:10.512437
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert type(enforcemode) is int
    assert enforcemode in [0, 1, 2]
    assert type(rc) is int
    assert rc in [0, 1, -1]



# Generated at 2022-06-22 22:23:13.865201
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0, "Error rc={0}".format(rc)
    assert policy == "targeted", "Error policy={0}".format(policy)
    print("test_selinux_getpolicytype: PASSED")

# Generated at 2022-06-22 22:23:19.728247
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not is_selinux_enabled():
        return
    try:
        policytype = selinux_getpolicytype()
        assert policytype[0] == 0
        assert type(policytype[1]) is str
    except Exception as err:
        print(err)
        raise err


# Generated at 2022-06-22 22:23:26.185981
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    testdir = tempfile.mkdtemp()
    path = os.path.join(testdir, 'test_file')
    with open(path, 'w') as fd:
        fd.write('test data')

    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert len(con) > 0

    os.unlink(path)
    os.rmdir(testdir)

# Generated at 2022-06-22 22:23:37.765500
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        pytest.skip("The SELinux is disabled")

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes

    assert lgetfilecon_raw("/") == [0, "system_u:object_r:root_t:s0"]

    argu = {
        "path": "/",
        "check_mode": False,
    }

    module = AnsibleModule(
        argument_spec=basic.AnsibleModule.argument_spec,
        supports_check_mode=True,
        add_file_common_args=True,
    )
    module.params.update(argu)


# Generated at 2022-06-22 22:23:39.913476
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw('/')
    assert ret[0] == 0 and ret[1] != ''



# Generated at 2022-06-22 22:23:42.214737
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == "targeted"



# Generated at 2022-06-22 22:23:46.539243
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Get enforcemode value
    mode = selinux_getenforcemode()[1]
    # If enforcemode is one of the following, return True
    if mode == 0 or mode == 1 or mode == 2:
        return True
    else:
        return False



# Generated at 2022-06-22 22:23:49.381244
# Unit test for function matchpathcon
def test_matchpathcon():
    mpc = matchpathcon('/etc/passwd', 0)
    assert mpc[0] == 0
    assert mpc[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:23:55.232385
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test selinux_getpolicytype()
    """

    rc, policy_type = selinux_getpolicytype()
    if rc != 0:
        print("\n** Error getting selinux policy type: {0}".format(rc))
    else:
        print("\n** SELinux Policy Type: {0}".format(policy_type))



# Generated at 2022-06-22 22:24:05.159253
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # When a file doesn't exist
    rc, con = lgetfilecon_raw('/tmp/doesntexist')
    # Then the return code should be -1
    assert rc == -1
    # And no context should be returned
    assert con is None

    # When a file exists
    rc, con = lgetfilecon_raw('/tmp')
    # Then the return code should be 0
    assert rc == 0
    # And a context should be returned
    assert con is not None

    # When a file doesn't exist
    rc, con = lgetfilecon_raw('/doesntexist')
    # Then the return code should be -1
    assert rc == -1
    # And no context should be returned
    assert con is None

# Generated at 2022-06-22 22:24:07.349665
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc is 0
    assert con.startswith('selinuxfs')

# Generated at 2022-06-22 22:24:10.697995
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[0] == 0:
        assert True
    else:
        assert False



# Generated at 2022-06-22 22:24:14.845203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = 0
    rv = ""
    rc, rv = lgetfilecon_raw('/var/log/audit/audit.log')
    assert rc == 0
    assert rv == 'system_u:object_r:auditd_log_t:s0'



# Generated at 2022-06-22 22:24:19.725900
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        print("rc is {}".format(rc))
    else:
        print("rc is {0} and enforcemode is {1}".format(rc, enforcemode))



# Generated at 2022-06-22 22:24:21.419711
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-22 22:24:24.388117
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert len(ret) == 2
    assert isinstance(ret[0], int)
    assert isinstance(ret[1], int)


# Generated at 2022-06-22 22:24:27.114730
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected = 0
    actual, _ = selinux_getpolicytype()
    assert actual == expected, "expected {}, got {}".format(expected, actual)

# Generated at 2022-06-22 22:24:30.055317
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type == b"mcs" or policy_type == b"targeted"


# Generated at 2022-06-22 22:24:33.877372
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.getcwd()
    rc, con = lgetfilecon_raw(path)
    assert rc == 0


__all__ = [
    'selinux_getenforcemode',
    'selinux_getpolicytype',
    'lgetfilecon_raw',
    'matchpathcon',
]

# Generated at 2022-06-22 22:24:45.217348
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Is security.selinux enabled?
    if _selinux_lib.is_selinux_enabled():
        # Is security.selinux_mls_enabled enabled?
        if _selinux_lib.is_selinux_mls_enabled():
            # Does the current test file exist?
            if os.path.isfile(__file__):
                # Get the security file context from __file__ and return the
                # SELinux code result, in a list
                outcon_raw, rc_conraw = lgetfilecon_raw(__file__)

                # Can we match the file context, based on the file location on disk?
                outpathcon, rc_pathcon = matchpathcon(__file__, os.stat(__file__).st_mode)

                # If both functions succeed, does the

# Generated at 2022-06-22 22:24:49.123187
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, val) = lgetfilecon_raw("/etc/")
    assert rc == 0
    if __debug__:
        print("rc = %d, val = %s" % (rc, val))

# Generated at 2022-06-22 22:24:56.407053
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import subprocess
    cmd = ['getenforce']
    process = subprocess.Popen(cmd,
                               stdout=subprocess.PIPE)
    while True:
        output = process.stdout.readline()
        if output == '' and process.poll() is not None:
            break
        if output:
            rc, policy = selinux_getpolicytype()
            if rc == -1:
                policy = 'unknown'
            assert policy in ['targeted', 'mls', 'unknown']
            break

# Generated at 2022-06-22 22:24:58.518867
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test that selinux_getpolicytype returns the correct value.
    """
    assert selinux_getpolicytype()[1] == 'nam'

# Generated at 2022-06-22 22:25:01.470579
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if (rc < 0):
        raise OSError('Error in selinux_getenforcemode()')

    if (enforcemode < 0):
        raise OSError('Error in selinux_getenforcemode()')



# Generated at 2022-06-22 22:25:10.164202
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw by passing in a valid and invalid file path"""
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    rc, con = lgetfilecon_raw('/tmp/does_not_exist')
    assert rc != 0
    assert con == 'Invalid argument'
    rc, con = lgetfilecon_raw('/etc/')
    assert rc != 0
    assert con == 'Invalid argument'

if __name__ == "__main__":
    # This runs test functions in the current module
    # FIXME: if the module is loaded as a library, this code would be executed
    from ansible_collections.test.test_utils.plugins.selinux.test_ctypes import \
        test_is_selinux_enabled, \
        test

# Generated at 2022-06-22 22:25:11.528852
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert len(selinux_getenforcemode()) == 2


# Generated at 2022-06-22 22:25:12.872741
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:25:16.295714
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/"
    (rc, con) = matchpathcon(path, 0)
    assert rc == 0
    assert 'system_u:object_r:root_t:s0' in con

# Generated at 2022-06-22 22:25:19.068336
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/etc/hosts") == [0, 'system_u:object_r:etc_t:s0']
    rc, con = lgetfilecon_raw(b'nonexistent')
    assert rc == -1
    assert get_errno() == 2
    assert con == ''



# Generated at 2022-06-22 22:25:22.336368
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    print('rc: {0}'.format(rc))
    print('enforcemode: {0}'.format(enforcemode))
    assert rc == 0


# Generated at 2022-06-22 22:25:27.660872
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'lgetfilecon_test_file'
    try:
        open(path, 'wb').close()
        rc, con = lgetfilecon_raw(path)
        assert rc >= 0
        assert con
    finally:
        os.remove(path)

# Generated at 2022-06-22 22:25:31.104841
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''
    Test selinux_getpolicytype
    '''
    got_policy = selinux_getpolicytype()[1]
    if got_policy == "targeted":
        print("OK: got targeted for policy type")
    else:
        raise Exception("ERROR: policy type is %s, not targeted" % got_policy)


# Generated at 2022-06-22 22:25:34.984271
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test selinux_getenforcemode"""
    assert selinux_getenforcemode()[1] != -1, 'SELinux is not enabled'


# Generated at 2022-06-22 22:25:39.388614
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype_list = selinux_getpolicytype()
    rc = policytype_list[0]
    policytype = policytype_list[1]
    assert rc == 0
    assert policytype in ['targeted', 'mls', 'minimum', 'strict', 'disabled']

# Generated at 2022-06-22 22:25:50.810595
# Unit test for function matchpathcon
def test_matchpathcon():
    assert not os.path.exists('/tmp/data/test_file')
    assert not os.path.exists('/tmp/data/test_dir')
    rc, con = matchpathcon('/tmp/data/test_file', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    rc, con = matchpathcon('/tmp/data/test_dir', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    assert not os.path.exists('/tmp/data/test_file')
    assert not os.path.exists('/tmp/data/test_dir')

# Generated at 2022-06-22 22:25:57.967024
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/foo/bar'
    mode = 0
    (rc, con) = matchpathcon(path, mode)

    assert type(rc) == int, 'matchpathcon returned an invalid rc %s' % rc
    assert type(con) == str, 'matchpathcon returned an invalid con %s' % con



# Generated at 2022-06-22 22:26:01.434345
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test invalid path
    assert matchpathcon('/etc/notexists', 0) == [1, '']

    # Test real path
    assert matchpathcon('/etc/hosts', 0) == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-22 22:26:03.923887
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', os.R_OK) != 0
    assert matchpathcon('/etc/resolv.conf', os.R_OK) == 0

# Generated at 2022-06-22 22:26:08.220544
# Unit test for function matchpathcon
def test_matchpathcon():
    l = matchpathcon('/sys/fs/cgroup/cpu/cpu.stat', 0)
    assert l[0] == 0
    assert l[1] == 'system_u:object_r:cgroup_t:s0'

# Generated at 2022-06-22 22:26:14.966560
# Unit test for function matchpathcon
def test_matchpathcon():
    '''Test environment is supposed to be a RHEL based container.'''

    if security_getenforce() == 1:
        rc, con = matchpathcon('/tmp', 0)

        if rc < 0:
            rc, msg = errno.errorcode[rc], os.strerror(rc)
            raise OSError(rc, msg)

        assert con == "system_u:object_r:tmp_t:s0"



# Generated at 2022-06-22 22:26:16.041685
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()


# Generated at 2022-06-22 22:26:17.716274
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return selinux_getenforcemode()


# Generated at 2022-06-22 22:26:19.142376
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:26:28.565018
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    This unit test can be run standalone to test selinux_getpolicytype();
    It will return the return code and selinux context type or throw an exception
    """

    try:
        # Call selinux_getpolicytype and return the return code and selinux context type
        print(selinux_getpolicytype())
    except OSError as e:
        # This will be raised if there is an error running the function
        print(e)
        sys.exit(1)

    sys.exit(0)



# Generated at 2022-06-22 22:26:33.887116
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/var/tmp', 0)
    rc = res[0]
    con = res[1]

    if rc == -1:
        print("No match for path '/var/tmp'")
    else:
        print("Context for '/var/tmp' is " + con)

# Generated at 2022-06-22 22:26:35.424835
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    print(result)



# Generated at 2022-06-22 22:26:38.443924
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/passwd', 1)
    assert result == [0, 'system_u:object_r:passwd_file_t:s0']
    assert type(result[1]) == str

# Generated at 2022-06-22 22:26:43.784303
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    assert rc == 0 and con == b'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-22 22:26:46.862964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    output = lgetfilecon_raw('/etc/shadow')[1]
    assert output == 'unconfined_u:object_r:shadow_t:s0'



# Generated at 2022-06-22 22:26:49.879157
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    print('selinux policy type is', policy)

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:26:53.560831
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/test_dir/test'
    mode = 0
    rc, _con = matchpathcon(path, mode)

    if rc != 0:
        raise ValueError('failed to get matchpathcon %s' % rc)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:27:00.080655
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(b"/test_dir/test.log", 0, byref(con))
        print(rc)
        print(con.value)
    finally:
        _selinux_lib.freecon(con)




# Generated at 2022-06-22 22:27:02.981947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/selinux/context"
    rc, result = lgetfilecon_raw(path)
    assert rc >= 0
    assert result is not None
    assert isinstance(result, binary_char_type)



# Generated at 2022-06-22 22:27:11.114646
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # This test case checks the if the selinux_getenforcemode
    # funtion is working correctly. The function returns the
    # selinux_getenforcemode, and the selinux_getenforcemode
    # is 0 or 1.
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] == 0 or enforcemode[0] == 1
    # The mode should be between 0 and 1
    assert enforcemode[1] >= 0 and enforcemode[1] <= 1



# Generated at 2022-06-22 22:27:14.448559
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    print(ret)



# Generated at 2022-06-22 22:27:21.700616
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        if os.path.exists("/bin/pwd"):
            el = lgetfilecon_raw("/bin/pwd")[1]
        elif os.path.exists("/usr/bin/pwd"):
            el = lgetfilecon_raw("/usr/bin/pwd")[1]
        else:
            raise RuntimeError("/bin/pwd or /usr/bin/pwd not found")
    except:
        raise RuntimeError("Could not get the context of /bin/pwd")
    if el is None:
        return False
    return True


# Generated at 2022-06-22 22:27:26.026980
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    test_file = '/tmp/foo'

    with open(test_file, 'w') as f:
        f.write("test")

    context = lgetfilecon_raw(test_file)[1]
    print(context)

    os.remove(test_file)

    assert context is not None

# Generated at 2022-06-22 22:27:32.138288
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    is_selinux_enabled = _selinux_lib.is_selinux_enabled()
    if is_selinux_enabled == 0:
        # Quick return as we don't have SELinux enabled
        return

    sample_file = "/proc/self/comm"
    rc, con = lgetfilecon_raw(sample_file)
    assert rc == 0
    assert con



# Generated at 2022-06-22 22:27:33.670316
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con is not None



# Generated at 2022-06-22 22:27:40.942349
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os
    # Create a temporary directory
    testDir = tempfile.mkdtemp()

    rc, con = lgetfilecon_raw(testDir)
    assert rc == 0, "lgetfilecon_raw for directory failed"

    # Create a temporary file
    testFile = os.path.join(testDir, 'file1')
    open(testFile, 'w').close()

    rc, con = lgetfilecon_raw(testFile)
    assert rc == 0, "lgetfilecon_raw for file failed"

    # Cleanup
    shutil.rmtree(testDir)



# Generated at 2022-06-22 22:27:46.358062
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw("/etc/passwd", byref(con))
    assert rc == 0
    assert to_native(con.value) == "system_u:object_r:etc_runtime_t:s0"
    _selinux_lib.freecon(con)

# Generated at 2022-06-22 22:27:48.077943
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon('/var/log/audit', 0) == 0


# Generated at 2022-06-22 22:27:49.435529
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home', 0)


# Generated at 2022-06-22 22:27:52.908840
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert rc == 0
    assert policytype and policytype != 'unknown'

# Generated at 2022-06-22 22:27:58.666417
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    if rc != 0:
        print("Error: unable to retrieve context for /etc/hosts")
        sys.exit(1)

    print("Context for /etc/hosts is: " + con)
    sys.exit(0)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:28:02.694983
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    # success case
    assert rc == 0 and con == 'system_u:object_r:tmp_t:s0'
    # error case
    rc, con = matchpathcon('missing', 0)
    assert rc < 0 and con is None

# Generated at 2022-06-22 22:28:06.923813
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Verify that the function is not returning None
    assert selinux_getenforcemode()[1] > -1


# Generated at 2022-06-22 22:28:08.454262
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-22 22:28:12.790499
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0 or enforcemode == 0 or enforcemode == 1


# Generated at 2022-06-22 22:28:15.814711
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test should run in a Linux system with SELinux.
    try:
        [rc, enforcemode] = selinux_getenforcemode()
        assert rc == 0
    except OSError:
        pass


# Generated at 2022-06-22 22:28:18.578959
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon_raw(b'/etc/passwd')

# Generated at 2022-06-22 22:28:22.490872
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    print("SELinux get enforce mode:")
    print("=========================")
    print("Return code: " + str(rc))
    print("Enforce mode: " + str(enforcemode))



# Generated at 2022-06-22 22:28:30.561354
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    # FIXME: this should be in a module utils utility function
    fname = tempfile.mkstemp()[1]

# Generated at 2022-06-22 22:28:32.688235
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('selinux_getpolicytype() returned: {0}'.format(selinux_getpolicytype()))

# Generated at 2022-06-22 22:28:34.031059
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert(rc == 0)
    assert(policytype == 'targeted' or policytype == 'strict')



# Generated at 2022-06-22 22:28:34.936999
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, out) = selinux_getpolicytype()
    assert rc == 0


# Generated at 2022-06-22 22:28:39.513422
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/usr/bin/passwd'
    expect_rc = 0
    expect_con = 'system_u:object_r:passwd_exec_t:s0'

    rc, con = lgetfilecon_raw(path)
    assert rc == expect_rc
    assert con == expect_con

# Generated at 2022-06-22 22:28:43.209189
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/usr/bin/ansible')
    assert result[0] == 0
    assert result[1] == 'unconfined_u:object_r:lib_t:s0'


# Generated at 2022-06-22 22:28:46.925628
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('Entering test_selinux_getpolicytype')
    print(str(selinux_getpolicytype()))
    print('Exiting test_selinux_getpolicytype')



# Generated at 2022-06-22 22:28:56.810861
# Unit test for function matchpathcon
def test_matchpathcon():

    #
    # Test with valid parameters
    #
    # Mode = 0
    # Path = /tmp
    #
    res = matchpathcon('/tmp', 0)

    if res[0] == -1:
        raise AssertionError(res[1])
    else:
        assert res[1], "tmp(/.*)?	system_u:object_r:tmp_t:s0"

    #
    # Test with invalid parameters
    #
    # Mode = 2
    # Path = /tmp
    #
    res = matchpathcon('/tmp', 2)

    if res[0] < 0:
        assert res[1] == "Invalid argument", "Expecting 'Invalid argument'"
    else:
        raise AssertionError(res[1])


test_matchpathcon()

# Generated at 2022-06-22 22:29:03.022344
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_value = [0, 'targeted']
    actual_value = selinux_getpolicytype()
    assert actual_value == expected_value, (
        'Unit test failed on {0}.\n'
        'Expected value: {1}\n'
        'Actual value: {2}').format(
            'selinux_getpolicytype',
            expected_value,
            actual_value
        )

# Generated at 2022-06-22 22:29:07.401825
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _func = globals()['lgetfilecon_raw']
    _rc, _out = _func('/bin/bash')
    assert _rc == 0
    assert _out == 'system_u:object_r:shell_exec_t:s0'

# Generated at 2022-06-22 22:29:10.440779
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/ping'
    mode = os.stat(path).st_mode
    [rc, con] = matchpathcon(path, mode)
    print("%d %s" % (rc, con))

# Generated at 2022-06-22 22:29:21.643234
# Unit test for function matchpathcon
def test_matchpathcon():
    matches = [
        ('/var/lib/puppet/ssl/certs', 0, ('system_u:object_r:puppetvar_t:s0', 0)),
        ('/var/lib/puppet/ssl/certs/ca.pem', 0, ('system_u:object_r:puppetvar_t:s0', 0)),
        ('/var/lib/puppet/ssl', 0, ('system_u:object_r:puppetvar_t:s0', 0)),
    ]

    for path, mode, rc_con in matches:
        rc, con = matchpathcon(path, mode)

# Generated at 2022-06-22 22:29:25.049552
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "test_path"
    expected_context = "system_u:object_r:etc_t:s0"
    assert matchpathcon(test_path, 0)[1] == expected_context, "Test failed"

# Generated at 2022-06-22 22:29:32.340338
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/ftp/file', 0)
    assert rc == 0
    assert con == 'system_u:object_r:var_t:s0'
    rc, con = matchpathcon('/var/ftp/file', 0)
    assert rc == 0
    assert con == 'system_u:object_r:var_t:s0'

# Generated at 2022-06-22 22:29:35.345572
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Call function
    rc, enforcemode = selinux_getenforcemode()

    # Verify results
    assert rc == 0
    assert isinstance(enforcemode, int)
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:29:37.226616
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert(policytype[0] >= 0)



# Generated at 2022-06-22 22:29:42.213701
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import selinux
    path = "/usr"
    context = selinux.lgetfilecon_raw(path)[1]
    assert context is not None, "Failed to obtain context: {0}".format(context)
    assert context is not "", "Failed to obtain context: {0}".format(context)

# Generated at 2022-06-22 22:29:44.199244
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # TODO: Implement unit test
    # assertEqual(expected, selinux_getenforcemode())
    pass


# Generated at 2022-06-22 22:29:47.338358
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Test function selinux_getpolicytype"""
    result = selinux_getpolicytype()
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)

# Generated at 2022-06-22 22:29:49.317316
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()

    assert isinstance(con, str) is True
    assert rc == 0



# Generated at 2022-06-22 22:29:59.301644
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Get the enforcement mode
    [rc, enforcemode] = selinux_getenforcemode()
    # Return 'Disabled' if not enabled
    if enforcemode == 0:
        return ('Disabled')
    # Return 'Permissive' if in permissive mode
    elif enforcemode == 1:
        return ('Permissive')
    # Return 'Enforcing' if in enforcing mode
    elif enforcemode == 2:
        return ('Enforcing')
    # Return None if something else
    else:
        return None



# Generated at 2022-06-22 22:30:03.400974
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os

    output = selinux_getenforcemode()
    if output[1] == -1:
        assert os.path.exists("/usr/sbin/selinuxenabled")
    else:
        assert os.path.exists("/usr/sbin/selinuxenabled")



# Generated at 2022-06-22 22:30:07.222756
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = to_bytes('/etc/hosts')
    context = lgetfilecon_raw(path)[1]
    assert 'system_u:object_r:etc_t:s0' in context

# Generated at 2022-06-22 22:30:14.963396
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest

    # Create a temp file for a test string
    # Don't need to write anything, just create the file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)
    # The default context is user_u:object_r:unlabeled_t:s0
    rc, con = matchpathcon(temp_file, 0)
    assert rc == 0
    assert con == "unlabeled_t"
    # Clean up temp file
    os.remove(temp_file)

    # Create a temp directory for a test string
    temp_dir = tempfile.mkdtemp()
    # The default context is user_u:object_r:unlabeled_t:s0
    rc, con = matchpathcon(temp_dir, 0)
    assert rc == 0

# Generated at 2022-06-22 22:30:18.695806
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for function lgetfilecon_raw
    """
    path = "/usr/bin/whoami"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0



# Generated at 2022-06-22 22:30:21.670321
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert isinstance(res[1], str)


# Generated at 2022-06-22 22:30:25.626156
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert type(enforcemode) == int, 'return value was not an int'
    assert enforcemode in {0, 1, 2}, 'enforcemode was not between 0 and 2'


# Generated at 2022-06-22 22:30:34.643946
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:30:42.734531
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    if rc != 0:
        return [rc, enforcemode]
    else:
        if enforcemode == 1:
            return [rc, 'Enforcing']
        elif enforcemode == 0:
            return [rc, 'Permissive']
        else:
            raise ValueError('Unexpected return value for selinux_getenforcemode')



# Generated at 2022-06-22 22:30:47.256473
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result, policytype = selinux_getpolicytype()
    assert (result == 0)
    assert (policytype == 'targeted')

# Generated at 2022-06-22 22:30:51.871802
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for function matchpathcon
    """
    # Check that we get a context back
    rc, con = matchpathcon('/tmp', os.stat('/tmp').st_mode)
    assert rc == 0
    # Check that the context is correct
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:30:54.456870
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test selinux_getenforcemode function
    '''
    [rc, enforcemode] = selinux_getenforcemode()
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-22 22:30:55.633840
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ["targeted", "mls"]

# Generated at 2022-06-22 22:30:57.294168
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, fcon = selinux_getenforcemode()
    assert rc == 0 and isinstance(fcon, int)



# Generated at 2022-06-22 22:31:00.980318
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    results = selinux_getenforcemode()
    rc = results[0]
    assert rc == 0
    assert results[1] == 1


# Generated at 2022-06-22 22:31:06.222328
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0, "Failed to get policy type"
    assert len(policytype) == 2, "Failed to get policy type"
    assert policytype[1] != "", "Failed to get policy type"


# Generated at 2022-06-22 22:31:12.236666
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    current_directory = os.getcwd()
    getfilecon_raw = lgetfilecon_raw(current_directory)
    assert isinstance(getfilecon_raw, list)
    assert(getfilecon_raw[0] == 0)
    assert getfilecon_raw[1] == 'system_u:object_r:user_home_dir_t:s0'

# Generated at 2022-06-22 22:31:16.935593
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise Exception('SELinux not enabled, cannot test')
    path = os.getcwd()
    assert matchpathcon(path, os.R_OK) == [0, 'system_u:object_r:default_t:s0']


# Generated at 2022-06-22 22:31:18.626991
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-22 22:31:20.714860
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, ptype] = selinux_getpolicytype()
    assert rc == 0
    assert ptype == 'targeted'

# Generated at 2022-06-22 22:31:24.684744
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists('/usr/bin/id') is not True:
        raise Exception('Test file /usr/bin/id cannot be found')

    ret = lgetfilecon_raw('/usr/bin/id')
    if ret[1] != 'system_u:object_r:default_t:s0':
        raise Exception('Invalid context returned')

# Generated at 2022-06-22 22:31:32.709325
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create temp dir
    folder = tempfile.mkdtemp()

    # Check value of matchpathcon when there are no errors
    # (rc is 0, when there are no errors)
    path = folder + '/test'
    os.mknod(path)
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:user_home_t:s0']

    # Check value of matchpathcon when there are errors
    # (rc is not equal 0, when there are errors)
    mode = -1
    assert matchpathcon(path, mode) != [0]

# Generated at 2022-06-22 22:31:44.927433
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Match a path to a file context.
    Since selinux is built with a path of /etc/selinux/default/contexts/files
    and a path of /etc/localtime should return a context of root:object_r:time_db_t:s0
    It also has a path of /var/db/localtime and a context of root:object_r:time_db_t:s0
    which should return the same context as /etc/localtime

    :return:
        The return values are (rc, con) which are
            rc: the return code
            con: the context for the path
    """
    (rc, con) = matchpathcon("/etc/localtime", 0)

# Generated at 2022-06-22 22:31:50.817593
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print('***')
    print('*** selinux_getenforcemode')
    print('***')

    # NOTE: for testing purposes, please run following command:
    #
    #       # /usr/sbin/setsebool -P selinuxuser_execmem true

    rc, enforcemode = selinux_getenforcemode()
    print('rc: ' + str(rc))
    print('enforcemode: ' + str(enforcemode))



# Generated at 2022-06-22 22:31:55.738275
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    path = '/etc/passwd'
    con_list = lgetfilecon_raw(path)
    # On systems where policy is not installed return value is -1
    if con_list[0] != -1:
        assert (con_list[0] == 0)
        assert (con_list[1] == 'system_u:object_r:etc_runtime_t:s0')
    else:
        assert con_list[0] == -1


# Unit Test for function matchpathcon

# Generated at 2022-06-22 22:32:00.856181
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc >= 0, 'selinux_getenforcemode failed with errno: {0}'.format(rc)
    assert policy_type == 'targeted', 'Unexpected policy_type: {0}'.format(policy_type)



# Generated at 2022-06-22 22:32:03.642033
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    print('/etc/passwd has context: %s' % con)


# Generated at 2022-06-22 22:32:10.887069
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-22 22:32:14.030680
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0



# Generated at 2022-06-22 22:32:18.922466
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    if rc == -1:
        raise OSError("Error: unable to get the selinux_getenforcemode")
    print("selinux_getenforcemode result is:", enforcemode)



# Generated at 2022-06-22 22:32:21.337518
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-22 22:32:23.920860
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/passwd')
    assert result[0] == 0 and result[1]
    assert isinstance(result[1], str)



# Generated at 2022-06-22 22:32:27.607144
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert isinstance(res, list) and len(res) == 2
    assert isinstance(res[0], int)
    assert isinstance(res[1], str) and res[1] in ('targeted', 'mls')



# Generated at 2022-06-22 22:32:33.502344
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test selinux.lgetfilecon_raw function."""
    import tempfile
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile()
    name = tmpfile.name
    # Get file context
    rc, con = lgetfilecon_raw(name)
    assert rc == 0, 'lgetfilecon_raw failed'
    assert con[:5] == 'system', "file context doesn't start with system_u:object_r"
    # Change file context
    rc, con = matchpathcon(name, 0)
    assert rc == 0, 'matchpathcon failed'
    rc = lsetfilecon(name, con)
    assert rc == 0, 'lsetfilecon failed'
    # Get file context again
    rc, con = lgetfilecon_raw(name)
    assert rc