

# Generated at 2022-06-22 22:22:37.667657
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    fmodule = sys.modules[__name__]

    rc, enforcemode = fmodule.selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-22 22:22:43.234255
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_dict = dict(
        con=["u:object_r:test_t"],
        path=["/etc/testfile"]
    )
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(test_dict['path'], byref(con))

    assert rc == 0
    assert to_native(con.value) == test_dict['con']

# Generated at 2022-06-22 22:22:47.650799
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import json
    with open('/tmp/testfile', 'w') as testfile:
        os.chmod('/tmp/testfile', 0o400)
        testfile.write('This is a testfile')
    rc, con = lgetfilecon_raw('/tmp/testfile')
    print(json.dumps(
        {
            'rc': rc,
            'con': con
        }
    ))
    os.remove('/tmp/testfile')

# Generated at 2022-06-22 22:22:50.618887
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)



# Generated at 2022-06-22 22:22:54.707124
# Unit test for function matchpathcon
def test_matchpathcon():
    # if you want to test matchpathcon, run:
    #   sudo selinuxenabled
    #   sudo setenforce 1
    #   sudo apt-get install selinux-policy-default auditd
    #   sudo apt-get install selinux-utils
    #   sudo restorecon -R /
    #   sudo dc=context1 path=/tmp/foo.txt touch
    #   sudo dc=context2 path=/foo/bar/baz.txt touch
    #   python3 -m selinux.selinux matchpathcon /tmp/foo.txt 0
    #   python3 -m selinux.selinux matchpathcon /foo/bar/baz.txt 0
    #   python3 -m selinux.selinux matchpathcon /tmp 0
    import pytest


# Generated at 2022-06-22 22:22:58.879211
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, policy] = selinux_getpolicytype()
    except Exception as e:
        return [False, e]
    except:
        return [False, 'Unhandled exception']

    if rc == 0:
        return [True, policy]
    return [False, 'Unexpected value for return code: {0}'.format(rc)]


# Generated at 2022-06-22 22:23:02.236394
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert 'targeted' in res[1]

# Generated at 2022-06-22 22:23:09.967744
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/root'

    rc, con = lgetfilecon_raw(path)
    if rc != 0:
        raise Exception("lgetfilecon_raw failed")

    # Check if valid SELinux security context
    if con is None or len(con) == 0 or con.split(b':')[1] != b'system_u':
        raise Exception("invalid SELinux security context")


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:23:12.001589
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0, 'rc={0}'.format(rc)

# Generated at 2022-06-22 22:23:14.846181
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con_returned = lgetfilecon_raw("/etc")
    # This should return 0
    assert(con_returned[0] == 0)
    # This should return a context value
    assert(con_returned[1])

# Generated at 2022-06-22 22:23:21.280200
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    mode = os.stat('/etc/motd').st_mode

    rc, con = matchpathcon('/etc/motd', mode)
    assert rc == 0
    assert con == 'system_u:object_r:motd_t:s0'



# Generated at 2022-06-22 22:23:25.535124
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()

    # Check that result is of type list
    assert type(result) == list

    # Check that rc is of type int
    assert type(result[0]) == int

    # Check that value is of type str
    assert type(result[1]) == str


# Generated at 2022-06-22 22:23:35.381377
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import subprocess
    # some applications (like zsh) appear to prevent the module from being loaded
    if 'selinux_getenforcemode' not in dir():
        subprocess.check_call(['pkill', 'zsh'])

        import site
        import imp
        site.__file__
        imp.reload(site)

        import selinux
        imp.reload(selinux)

    rc, con = lgetfilecon_raw(b'/tmp/')
    assert rc == 0
    assert con.startswith('system_u:object_r:tmp_t:')


# Generated at 2022-06-22 22:23:37.530019
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)


# Generated at 2022-06-22 22:23:39.707590
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("Return code = %d   Enforcemode = %d" % (rc, enforcemode))



# Generated at 2022-06-22 22:23:46.938987
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case for empty file that does not exist
    path = ''
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con == ''

    # Test case for file that exists
    path = "/etc/hosts"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:23:48.486409
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-22 22:23:51.474797
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test in enforcing mode
    selinux_getenforcemode()
    # Test in permissive mode
    selinux_getenforcemode()

# Generated at 2022-06-22 22:23:57.376942
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_t:s0'
    rc, con = lgetfilecon_raw(b'/invalid/path')
    assert rc == -1


# Generated at 2022-06-22 22:23:58.892098
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-22 22:24:07.666141
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/sys/devices/system/cpu/cpu0/msr', 0) == [0, 'unconfined_u:object_r:admin_home_t:s0']
    assert matchpathcon('/sys/devices/system/cpu/cpu0/msr', os.F_OK) == [0, 'unconfined_u:object_r:admin_home_t:s0']
    assert matchpathcon('/sys/devices/system/cpu/cpu0/msr', os.R_OK) == [0, 'unconfined_u:object_r:msr_device_t:s0']

# Generated at 2022-06-22 22:24:10.746469
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc == 0 and isinstance(policytype, str):
        return True
    return False

# Generated at 2022-06-22 22:24:11.992520
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[1] == "targeted"

# Generated at 2022-06-22 22:24:19.175084
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/sysconfig/network-scripts/ifcfg-eth0"
    # mode is 0
    mode = 0
    ret = matchpathcon(path, mode)
    print("\nReturned value of matchpathcon = " + str(ret))
    print("Return code = " + str(ret[0]))
    print("Context = " + str(ret[1]))
# end of matchpathcon()

# Generated at 2022-06-22 22:24:29.643940
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a file to operate on
    # Note: This file will be placed in the current working directory,
    #       which may or may not be the same dir as where the tests are being run from.
    #       If it is not the same directory, this will fail, as we are not
    #       calling os.chdir() anywhere
    #       The alternative is to use os.environ['HOME'] instead of the current working directory,
    #       but that's a different approach.
    with open("testtempfile", "w") as tempfile:
        tempfile.write("This is a test file for SELinux functions")
        tempfile.close()
        # Get the context of the file
        context = lgetfilecon_raw("testtempfile")
        os.remove("testtempfile")
        return context


# Generated at 2022-06-22 22:24:33.542294
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        pytest.fail("Unexpected negative return code {0}.".format(rc))
    if not enforcemode:
        pytest.fail("Unexpected false value for enforcemode {0}.".format(enforcemode))


# Generated at 2022-06-22 22:24:38.240889
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # if selinux is not enabled this function will return
    # [0, 'null']
    [rc, con] = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'null'

# Generated at 2022-06-22 22:24:43.237949
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    >>> rc, con = lgetfilecon_raw('/')
    >>> rc
    0
    >>> con
    '/ system_u:object_r:root_t:s0'
    '''

    rc, con = lgetfilecon_raw('/invalid/path')
    assert rc > 0
    assert con is None



# Generated at 2022-06-22 22:24:46.973124
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import doctest
    m = sys.modules[__name__]
    selinux_getenforcemode.__module__ = __name__
    m.selinux_getenforcemode.__module__ = __name__
    doctest.testmod(m)


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-22 22:24:50.295324
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    path = b"/bin/bash"
    mode = 0
    result = selinux_getpolicytype()
    assert result[0] == 0
    assert isinstance(result[1], str)


# Generated at 2022-06-22 22:24:53.586683
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, filecon = matchpathcon('/testpath', 0)
    print('rc: {0}'.format(rc))
    print('filecon: {0}'.format(filecon))


# Generated at 2022-06-22 22:24:58.335095
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import re
    test_pattern = re.compile(r"^(\w+)\((\d+)\)")
    _selinux_lib.selinux_getpolicytype.argtypes = [POINTER(c_char_p)]
    con = c_char_p()
    _selinux_lib.selinux_getpolicytype(byref(con))
    assert con.value
    assert isinstance(con.value, bytes)
    test_pattern.match(to_native(con.value))

# Generated at 2022-06-22 22:25:00.027830
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0, 'policytype failed with code: {}'.format(policytype[0])

# Generated at 2022-06-22 22:25:05.508988
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/sys/kernel/mm/ksm', 1)
    assert rc == 0
    assert con == 'system_kernel_mm_t:system_kernel_mm_t'

    rc, con = matchpathcon(b'/sys/kernel/mm/ksm', 0)
    assert rc == 0
    assert con == 'system_kernel_mm_t'

# Generated at 2022-06-22 22:25:17.089755
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # In order to run this test, you must be running on a system with selinux already enabled
    # This has been tested on RedHat 7 and Fedora 30 systems
    # In addition, the user must be in the unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023 selinux
    # context

    # Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test
    # Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test
    # Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test Test

# Generated at 2022-06-22 22:25:18.018407
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    selinux_getenforcemode()



# Generated at 2022-06-22 22:25:21.051536
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/var/log/secure', 0)
    assert rc is None
    assert con == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-22 22:25:25.300862
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:user_home_t:s0']

# Generated at 2022-06-22 22:25:27.817151
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, result = matchpathcon('/var', 0o755)
    assert rc == 0
    assert result == 'system_u:object_r:var_t:s0'



# Generated at 2022-06-22 22:25:33.290953
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json
    import tempfile

    temp_fd, temp_path = tempfile.mkstemp()
    with os.fdopen(temp_fd, 'r') as temp_file:
        test_data = {
            'changed': False,
            'policy': selinux_getpolicytype()[1],
        }
        json.dump(test_data, temp_file, indent=2)
        temp_file.write('\n')

    with open(temp_path, 'r') as temp_file:
        test_data = json.load(temp_file)
        assert test_data['policy'] == selinux_getpolicytype()[1], 'test failed!'

    os.remove(temp_path)

# Generated at 2022-06-22 22:25:38.944963
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        test_val = matchpathcon('/home', 2)
        assert test_val[0] == 0
        assert test_val[1] == 'system_u:object_r:user_home_t:s0'
    except OSError:
        assert False, "Selenium is not enabled"

# Generated at 2022-06-22 22:25:42.419054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:25:47.124639
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/etc/passwd"
    mode = 0
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    assert rc == 0
    assert con.value is not None
    _selinux_lib.freecon(con)

# Generated at 2022-06-22 22:25:48.524963
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0

# Generated at 2022-06-22 22:25:52.651510
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc != 0:
        sys.exit(1)
    if con == "":
        sys.exit(1)


# Generated at 2022-06-22 22:25:59.714917
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd')[0] == 0
    assert lgetfilecon_raw(b'/etc/passwd')[1] == b'unconfined_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw(b'/etc/non_existing_file')[0] == -1


# Generated at 2022-06-22 22:26:03.016835
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc = selinux_getenforcemode()
    except Exception:
        return False
    else:
        if isinstance(rc, list) and len(rc) == 2:
            return True
        return False


# Generated at 2022-06-22 22:26:04.281093
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:26:12.041470
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.selinux_policy import matchpathcon_raw

    path = to_bytes('/dev/null')
    mode = 0

    (rc, con) = matchpathcon_raw(path, mode)
    print("rc=", rc)
    print("con=", to_native(con))



# Generated at 2022-06-22 22:26:13.935716
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0 and 0 <= enforcemode <= 2, 'enforce mode not in range'

# Generated at 2022-06-22 22:26:16.578698
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert rc == 0, "Failed to get policy type. Check selinux settings."
    assert len(con) > 0, "Failed to get policy type. Check selinux settings."



# Generated at 2022-06-22 22:26:19.186978
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]


# Generated at 2022-06-22 22:26:21.187026
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/id'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

# Generated at 2022-06-22 22:26:25.763416
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("testing selinux_getenforcemode")
    try:
        if selinux_getenforcemode()[0] == 0:
            print("selinux_getenforcemode returned", selinux_getenforcemode()[1])
        else:
            print("selinux_getenforcemode failed")
    except (SystemError, OSError):
        print("selinux_getenforcemode failed")


# Generated at 2022-06-22 22:26:31.281664
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype
    try:
        rc, con = selinux_getpolicytype()
    except OSError as e:
        assert e.errno == 2



# Generated at 2022-06-22 22:26:37.003468
# Unit test for function matchpathcon
def test_matchpathcon():
    # Get the default selinux file context
    [rc, selinux_file_con] = matchpathcon('/foo/bar/baz', 0)
    print ("rc: %r" % rc)
    print ("selinux_file_con: %r" % selinux_file_con)


# Generated at 2022-06-22 22:26:39.540975
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    dat = selinux_getpolicytype()
    assert dat[0] >= 0


# Generated at 2022-06-22 22:26:43.080053
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/bin/bash'
    concontext = lgetfilecon_raw(path)
    assert(type(concontext[1]) is str)



# Generated at 2022-06-22 22:26:48.896056
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/testfile"
    mode = os.R_OK
    rc, security_context = matchpathcon(path, mode)
    print("Return code is: " + to_native(str(rc)))
    print("Return security context is: " + to_native(security_context))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:26:56.392502
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import NamedTemporaryFile
    import os
    import stat

    filename = NamedTemporaryFile().name
    os.mknod(filename, stat.S_IFREG | 0o600)

    try:
        res = matchpathcon(filename, stat.S_IFREG)
        if res[0] < 0:
            raise RuntimeError("lgetfilecon_raw returned error %d" % res[0])
        if res[1] is None:
            raise RuntimeError("lgetfilecon_raw returned none")
        if len(res[1]) < 2:
            raise RuntimeError("lgetfilecon_raw returned 0 a lenght string")
    finally:
        os.unlink(filename)

# Generated at 2022-06-22 22:27:00.439332
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert rc == 0, 'return code should be 0'
    assert policytype == 'targeted', 'policy type should be targeted'



# Generated at 2022-06-22 22:27:02.666034
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con is not None
    assert isinstance(con, str) is True


# Generated at 2022-06-22 22:27:04.155997
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:27:12.432660
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    con_list = lgetfilecon_raw(test_path)
    if con_list[0] == -1:
        print('lgetfilecon_raw function returned error code %s' % con_list[0])
        print('Error message: %s' % os.strerror(get_errno()))
        sys.exit(1)
    else:
        print('File %s has the following context: %s' % (test_path, con_list[1]))

# Generated at 2022-06-22 22:27:14.975231
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in [0, 1]


# Generated at 2022-06-22 22:27:23.887748
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule
    import os

    def matchpathcon_test(path, mode):
        rc, value = matchpathcon(path, mode)
        return [rc, value]

    def run_function(function, *args):
        module = AnsibleModule(
            argument_spec=dict(
                command=dict(type='str'),
            )
        )
        result = function(module, *args)
        return result['rc'], result['value']

    path = '/etc'
    mode = '0'
    fn_rc, fn_pathcon = matchpathcon_test(path, mode)
    mod_rc, mod_pathcon = run_function(matchpathcon_test, path, mode)

    # Return the function's rc and the value to the Ansible module
    module

# Generated at 2022-06-22 22:27:34.304026
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from subprocess import Popen, PIPE, STDOUT
    from os.path import exists

    # Make sure the selinux policy package is installed
    if not exists('/etc/selinux/config'):
        print('SELinux is not installed, skipping selinux_getpolicytype tests')
        return

    try:
        proc = Popen(['getenforce'], stdout=PIPE, stderr=STDOUT)
        enforcemode = proc.communicate()[0]
        if enforcemode.decode().rstrip('\n') == 'Disabled':
            print('SELinux is disabled, skipping selinux_getpolicytype tests')
            return
    except OSError:
        print('Failed to run getenforce command, skipping selinux_getpolicytype tests')
        return


# Generated at 2022-06-22 22:27:38.474769
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(b"/etc/ssh/ssh_config", byref(con))
        print(to_native(con.value))
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-22 22:27:43.971565
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tmp_path = "/tmp/" + os.path.basename(__file__)
    os.environ["PATH"] = tmp_path + ":" + os.environ["PATH"]
    rc, con = lgetfilecon_raw(tmp_path)
    assert con == 'system_u:object_r:userns_tmp_t:s0'

# Generated at 2022-06-22 22:27:49.092615
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: find an actual value to expect.
    actual = matchpathcon('/usr/bin/python', 0o755)
    expected = [0, 'staff_u:object_r:admin_home_t:s0']
    assert actual == expected, "Expected: %r, Got: %r" % (expected, actual)

# Generated at 2022-06-22 22:27:52.637094
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']



# Generated at 2022-06-22 22:27:57.024920
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Expecting the return code to be 0 as it is successful
    res = selinux_getenforcemode()
    assert res[0] == 0
    # Expecting the value to be 0 since the policy type is targeted
    assert res[1] == 0


# Generated at 2022-06-22 22:28:00.952659
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/passwd', 0)[0] == 0
    assert matchpathcon(b'/selinux/passwd', 0)[0] == -1
    assert matchpathcon(b'/no/such/file', 0)[0] == -1

# Generated at 2022-06-22 22:28:03.006874
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy] = selinux_getpolicytype()
    assert rc == 0
    assert policy == "targeted"


# Generated at 2022-06-22 22:28:06.275406
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-22 22:28:14.066284
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for real selinux environment
    is_enabled = is_selinux_enabled()
    if is_enabled == 1:
        get_con = lgetfilecon_raw("/")
        if get_con[0] != 0:
            raise AssertionError("Expected get_con[0] to be 0, received %s" % get_con[0])

        if isinstance(get_con[1], str) is False:
            raise AssertionError("Expected get_con[1] to be a type str, received %s" % type(get_con[1]))
    else:
        print("Selinux is not enabled")

# Generated at 2022-06-22 22:28:26.229303
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import platform
    import os
    import sys

    if platform.machine() != 'x86_64':
        return

    policies = ["targeted", "minimum", "mls"]

    for i in policies:
        # os.setreuid() is not supported on Windows, need to do this on linux
        if platform.system() != 'Windows':
            os.setreuid(int(os.getuid()), 0)

        [rc, policytype] = selinux_getpolicytype()

        # If a policytype is set, it must be one of the three we support
        if policytype:
            assert policytype in policies

        # os.setreuid() is not supported on Windows, need to do this on linux
        if platform.system() != 'Windows':
            os.setreuid(0, int(os.getuid()))



# Generated at 2022-06-22 22:28:28.755551
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert (enforcemode in [0, 1, 2])



# Generated at 2022-06-22 22:28:40.343779
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import functools

    # is_selinux_enabled() returns 1 if selinux is enabled on the system, else 0.
    # is_selinux_mls_enabled() returns 1 if selinux is in mls mode, else 0.
    # selinux_getenforcemode() returns 1 if selinux is in enforcing mode, else
    # 0.
    # security_getenforce() returns 1 if selinux is in enforcing mode, else 0.

    # if selinux is enabled, this test will pass and return an exit code of 0
    # if selinux is not enabled, this test will return with error code of 1 and non-zero return code
    if not is_selinux_enabled():
        sys.exit(1)


# Generated at 2022-06-22 22:28:42.846853
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    val = selinux_getenforcemode()
    assert val[0] == 0 and val[1] in [0, 1, 2]



# Generated at 2022-06-22 22:28:48.069559
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    path = '/etc/skel'
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        print(rc, to_native(con.value))
    finally:
        _selinux_lib.freecon(con)



# Generated at 2022-06-22 22:28:50.865213
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("")
    print("Test selinux_getenforcemode:")
    (rc, enforcemodevalue) = selinux_getenforcemode()
    print("rc = ", rc)
    print("enforcemodevalue = ", enforcemodevalue)
    print("")



# Generated at 2022-06-22 22:28:52.240166
# Unit test for function matchpathcon
def test_matchpathcon():
    check = matchpathcon('/', 0)
    assert check[0] == 0


# Generated at 2022-06-22 22:28:55.113633
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    assert os.path.exists('/var/log')
    rc, con = lgetfilecon_raw('/var/log')
    assert rc == 0
    assert con is not None



# Generated at 2022-06-22 22:29:06.090966
# Unit test for function matchpathcon
def test_matchpathcon():
    # Set up environment variables
    my_selinux_path = os.path.join(os.path.dirname(__file__), 'matchpathcon.selinux')
    my_semanage_path = os.path.join(os.path.dirname(__file__), 'matchpathcon.semanage')
    os.environ['SELINUX_CONFIG_FILE'] = my_selinux_path
    os.environ['SEMANAGE_CONFIG_FILE'] = my_semanage_path

    # Create a temporary file to hook our selinux context on
    tmp_filename = 'tmp.txt'
    tmp_file = open(tmp_filename, 'w')
    tmp_file.close()

    # Check the selinux context is set to the default

# Generated at 2022-06-22 22:29:08.063773
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 0] == selinux_getenforcemode()


# Generated at 2022-06-22 22:29:09.393894
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    print(rc, con)

# Generated at 2022-06-22 22:29:12.935603
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    ret_code, selinux_con = matchpathcon('/etc/passwd', 0)

    assert ret_code == 0
    assert selinux_con == 'etc_t:etc_runtime_t:s0'

# Generated at 2022-06-22 22:29:15.744898
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert type(enforcemode) == int


# Generated at 2022-06-22 22:29:18.237494
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-22 22:29:19.702046
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-22 22:29:26.407060
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/some/path'
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc == -1:
        if os.strerror(get_errno()) == 'No such file or directory':
            raise Exception('{0} : {1}'.format(path, os.strerror(get_errno())))
        else:
            raise Exception('matchpathcon syscall failed: {0}'.format(os.strerror(get_errno())))
    else:
        print('Success')

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:33.865543
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = lgetfilecon_raw("/etc/passwd")
    print("lgetfilecon_raw output is " + str(rc))
    rc = matchpathcon("/etc/passwd", 0)
    print("matchpathcon output is " + str(rc))

if __name__ == '__main__':
     test_lgetfilecon_raw()

# Generated at 2022-06-22 22:29:40.547306
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    test_mode = 32768+4+8192
    test_path = "/tmp"
    test_file = tempfile.mktemp(dir=test_path)
    # print(test_file)

    print(matchpathcon(test_path, test_mode))
    print(matchpathcon(test_file, test_mode))


# Generated at 2022-06-22 22:29:43.061580
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(enforcemode, int)


# Generated at 2022-06-22 22:29:45.385732
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config')[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:29:48.288191
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, mode = selinux_getpolicytype()
    assert rc == 0, "error getting selinux policy type"
    assert mode in ('targeted', 'mls', 'strict'), "policy type not one of (targeted, mls, strict)"



# Generated at 2022-06-22 22:29:50.795223
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert(rc == 0)
    assert(con == "admin_home_t")



# Generated at 2022-06-22 22:29:59.248833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    testfile = tempfile.NamedTemporaryFile()
    fd = testfile._file.fileno()
    testfile.close()
    con = c_char_p()
    rc = _selinux_lib.fgetfilecon_raw(fd, byref(con))
    _selinux_lib.freecon(con)
    # The return value is -1 if an error occurred, and 0 if successful
    assert rc == 0



# Generated at 2022-06-22 22:30:00.174720
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-22 22:30:02.634896
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/usr/bin/ls')
    print('{0} {1}'.format(rc, con))

# Generated at 2022-06-22 22:30:09.829781
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise Exception('SELinux is not enabled. Exiting.')

    path = b'/tmp'
    mode = 0

    ret = matchpathcon(path, mode)

    # A return value of 0 means success
    if ret[0] != 0:
        raise Exception('matchpathcon() call failed. Returned {0}'.format(ret))

    print('The context of {0} is {1}'.format(path, ret[1]))



# Generated at 2022-06-22 22:30:12.421155
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    error, policy_type = selinux_getpolicytype()
    return policy_type



# Generated at 2022-06-22 22:30:15.738185
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''This function will test if the selinux_getenforcemode function is working properly'''
    import os
    import sys
    import selinux
    try:
        assert selinux.selinux_getenforcemode() == [0, 1]
    except AssertionError:
        print("selinux_getenforcemode not working properly")
        sys.exit(1)



# Generated at 2022-06-22 22:30:21.819970
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/shadow', 0)
    if rc != 0:
        raise AssertionError('unexpected matchpathcon rc ({0})'.format(rc))

    if con != 'shadow_t:object_r:shadow_file_t:s0':
        raise AssertionError('unexpected matchpathcon con ({0})'.format(con))



# Generated at 2022-06-22 22:30:25.409348
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        getpolicytype = selinux_getpolicytype()
    except ImportError:
        import pytest

        pytest.skip('selinux could not be imported')
    assert getpolicytype[0] >= 0


# Generated at 2022-06-22 22:30:29.654046
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0, 'test selinux_getenforcemode failed'
    enforcemode != 0, 'test selinux_getenforcemode failed'



# Generated at 2022-06-22 22:30:31.562022
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    assert res[0] >= 0

# Generated at 2022-06-22 22:30:33.828390
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    actual_result = selinux_getenforcemode()
    expected_result = [0, 0]
    assert actual_result == expected_result


# Generated at 2022-06-22 22:30:43.362762
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    This function attempts to find the selinux module in the /usr/lib64/python3.6/ directory.
    It returns a tuple with the first element being the return code and the second being
    the value.
    """
    rc, enforcemode = selinux_getenforcemode()
    if rc == 0:
        assert enforcemode in [0, 1, 2], "SELinux is not enforced on this system"
    else:
        assert False, "Could not find the selinux module"



# Generated at 2022-06-22 22:30:48.328347
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected_return_value = [0, 1]
    return_value = selinux_getenforcemode()
    assert return_value == expected_return_value


# Generated at 2022-06-22 22:30:52.123335
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc >= 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


__all__ = [name for name in dir() if not name.startswith('_')]

# Generated at 2022-06-22 22:30:58.583401
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return

    try:
        res = selinux_getenforcemode()
        assert type(res[0]) == int
        assert type(res[1]) == int
    except AttributeError:
        raise NotImplementedError
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-22 22:31:03.410087
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/etc/shadow'
    rc, selabel = lgetfilecon_raw(test_path)
    assert rc == 0
    assert selabel == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-22 22:31:06.590369
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == b'unconfined_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-22 22:31:10.115639
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    retval, val = selinux_getenforcemode()
    assert type(val) == int
    assert retval == 0 or retval == 1



# Generated at 2022-06-22 22:31:11.101633
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon("/tmp", 0))

# Generated at 2022-06-22 22:31:13.015168
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc == 0:
        print(policytype)

# Generated at 2022-06-22 22:31:15.656984
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import selinux
    rc, enforcemode = selinux.selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1]


# Generated at 2022-06-22 22:31:21.459753
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = _selinux_lib.lgetfilecon_raw('/etc/passwd', byref(c_char_p()))
    assert _selinux_lib.is_selinux_enabled()
    assert rc < 0
    assert _selinux_lib.is_selinux_mls_enabled()


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:31:28.572846
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:31:36.738618
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        test_selinux_getpolicytype.__name__
    except NameError:
        test_selinux_getpolicytype.__name__ = 'test_selinux_getpolicytype'
    import textwrap
    """ Unit test for function selinux_getpolicytype - inspects selinux policy
        installed on the system
    """
    import os
    import unittest

    class SELinuxPolicyTest(unittest.TestCase):
        def setUp(self):
            self.strresult = selinux_getpolicytype()
            self.result = self.strresult[0]
            self.resulttype = self.strresult[1]

        def test_is_int(self):
            self.assertIsInstance(self.result, int)

        def test_value_0(self):
            self

# Generated at 2022-06-22 22:31:41.369829
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Testing function: selinux_getenforcemode()")
    print(selinux_getenforcemode())


if __name__ == "__main__":
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:31:48.443272
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Locate a file created by the unit test
    path = "/tmp/ansible_selinux_test_file"

    if not os.path.isfile(path):
        raise AssertionError('file not found: {0}'.format(path))

    results = lgetfilecon_raw(path)
    print(results)
    if results[1] is None:
        raise AssertionError('lgetfilecon_raw returned "None"')

    print(results[1])

# Generated at 2022-06-22 22:31:51.122492
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type is not None
    assert isinstance(policy_type, str)
    assert len(policy_type) > 0

# Generated at 2022-06-22 22:31:55.331233
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test return code
    rc, enforce_mode = selinux_getenforcemode()

    if rc < 0:
        raise Exception("test_selinux_getenforcemode failed!")

    if enforce_mode != 1:
        raise Exception("test_selinux_getenforcemode enfocing mode is not 1!")

    print("test_selinux_getenforcemode Passed")



# Generated at 2022-06-22 22:31:58.398216
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert rc == 0
    assert con == "targeted" or con == "mls"

# Generated at 2022-06-22 22:32:09.614126
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''Unit test for function selinux_getenforcemode
        Return codes:
        0 - The kernel is enforcing SELinux policy.
        1 - SELinux policy is in permissive mode. The kernel would still allow access based on the policy,
            but would print warnings about denied access in the system log.
        -1 - Failed to determine whether SELinux policy is in enforcing or permissive mode.
            For example: SELinux is enabled, but running in a kernel that does not support XSM.
    '''
    examples = [
        [0, 0],
        [1, 1],
        [-1, -1]
    ]
    for example in examples:
        try:
            selinux_getenforcemode()
        except OSError as e:
            pass
        rc, enforcemode = selinux_geten

# Generated at 2022-06-22 22:32:16.915274
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()

    assert isinstance(ret, list)
    assert len(ret) == 2
    assert isinstance(ret[0], int)
    assert isinstance(ret[1], int)
    assert ret[0] == 0

    if ret[1] == 0:
        assert ret[1] == selinux_enforce_mode_disabled
    elif ret[1] == 1:
        assert ret[1] == selinux_enforce_mode_permissive
    elif ret[1] == 2:
        assert ret[1] == selinux_enforce_mode_enforcing
    else:
        assert False


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:32:22.327687
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test a file that must exist
    p = os.path.realpath(__file__)
    result = lgetfilecon_raw(p)
    assert result[0] == 0
    assert result[1] is not None
    assert result[1].startswith('system_u:')
    rc, con = lgetfilecon_raw('/root/.bashrc')
    assert rc == -1

# Generated at 2022-06-22 22:32:30.198977
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/path/to/file'
    # Fake file context string
    con1 = b'system_u:object_r:fake_file_t:s0'
    # Fake file context string with random suffix
    con2 = b'system_u:object_r:fake_file_t:s0-s1:c0.c1023'

    # lgetfilecon_raw should return the same output
    # as a list containing a return code of 0 and the
    # fake file context string.
    assert lgetfilecon_raw(path) == [0, con1]
    assert lgetfilecon_raw(path) == [0, con2]

# Generated at 2022-06-22 22:32:33.945734
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    mode = None
    rc, con = lgetfilecon_raw(path)

# Generated at 2022-06-22 22:32:40.756541
# Unit test for function matchpathcon
def test_matchpathcon():
    '''This is a unit test for function matchpathcon. It does not have a
    meaningful return value, as it can't create the test directory
    (selinux_test_dir) in /tmp with the correct SELinux context. It is
    provided as an example of how to use the function.
    '''
    path = '/tmp/selinux_test_dir/testfile'
    mode = os.stat(path).st_mode
    rc = matchpathcon(path, mode)[0]
    print("matchpathcon returned: %d" % rc)