

# Generated at 2022-06-22 22:22:34.624483
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/home'
    rc, con = selinux.lgetfilecon_raw(path)
    print("lgetfilecon_raw('/home') =", con)



# Generated at 2022-06-22 22:22:40.302574
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/etc/shadow'
    test_rc = 0
    test_con = 'system_u:object_r:shadow_t:s0'
    rc, con = lgetfilecon_raw(test_file)
    assert rc == test_rc
    assert con == test_con


# Generated at 2022-06-22 22:22:50.613232
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _selinux_policy_type = 'targeted'

    def _set_selinux_getpolicytype_return(val):
        _selinux_lib.selinux_getpolicytype.restype = val

    def _selinux_getpolicytype_mock_success():
        return [0, _selinux_policy_type]

    def _selinux_getpolicytype_mock_fail():
        return [-1, None]

    tmp_selinux_lib_selinux_getpolicytype = _selinux_lib.selinux_getpolicytype

# Generated at 2022-06-22 22:22:59.516952
# Unit test for function matchpathcon
def test_matchpathcon():
    success, result = matchpathcon(b"/foo", 1)
    assert success == 0
    assert result == b"system_u:object_r:etc_t:s0\x00"

    success, result = matchpathcon(b"/foo", 0)
    assert success == 0
    assert result == b"system_u:object_r:etc_t:s0\x00"

    success, result = matchpathcon(b"/foo", 0o555)
    assert success == 0
    assert result == b"system_u:object_r:etc_t:s0\x00"

    success, result = matchpathcon(b"/foo", 0o777)
    assert success == 0
    assert result == b"system_u:object_r:etc_t:s0\x00"

# Generated at 2022-06-22 22:23:03.707061
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()

    assert isinstance(rc, int)
    assert rc >= 0
    assert isinstance(policy, str)



# Generated at 2022-06-22 22:23:06.933832
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_rc, expected_result = matchpathcon('/', 0)
    assert expected_rc == 0
    assert expected_result == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-22 22:23:13.036648
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Unit test for function selinux_getenforcemode
    # Ensures that selinux_getenforcemode function returns a list,
    # with a return code and a value.
    rc, value = selinux_getenforcemode()
    assert isinstance(rc, int), 'unexpected return code type: {0}'.format(type(rc))
    assert isinstance(value, int), 'unexpected return value type: {0}'.format(type(value))



# Generated at 2022-06-22 22:23:15.451112
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    results = selinux_getenforcemode()
    assert results[0] == -1 or results[0] == 0
    assert results[1] == -1 or type(results[1]) == int


# Generated at 2022-06-22 22:23:19.931704
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    con = lgetfilecon_raw(path=path)
    assert con[0] == 0
    assert isinstance(con[1], str)


# Generated at 2022-06-22 22:23:21.573120
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:23:23.143387
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc >= 0

# Generated at 2022-06-22 22:23:25.628636
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    print(result)
    assert result[0] == 0
    assert result[1] == 1


# Generated at 2022-06-22 22:23:31.270499
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exist("/etc/selinux/config"):
        print(lgetfilecon_raw("/etc/selinux/config"))
    else:
        print("No selinux config file on this system")
        return 1


# Generated at 2022-06-22 22:23:33.759362
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0)
    assert matchpathcon('/tmp', 1)


# Generated at 2022-06-22 22:23:35.851096
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert isinstance(res[1], str)



# Generated at 2022-06-22 22:23:39.240390
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Testing selinux.matchpathcon')
    import os
    [rc, con] = matchpathcon('/home/vagrant/test.test', 0)
    if rc < 0:
        print(os.strerror(rc))
    else:
        print(con)

# Generated at 2022-06-22 22:23:51.851582
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Get the policy name from the library
    policy_name = selinux_getpolicytype()[1]
    print("Policy type: " + policy_name)

    # Get the policy name from a file
    path = "/etc/selinux/config"
    poltype = ""
    with open(path, 'r') as f:
        for line in f:
            if "SELINUXTYPE=" in line:
                lineparts = line.split("=")
                poltype = lineparts[1].rstrip()
    print("Policy type: " + poltype)

    # Compare the two
    if policy_name == poltype:
        print("Policy type in config file matches policy type in library")
    else:
        print("Policy type in config file does not match policy type in library")


# Generated at 2022-06-22 22:23:54.090305
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    assert res[0] == 0
    assert res[1] == 1 or res[1] == 0



# Generated at 2022-06-22 22:24:01.066127
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    This is not a comprehensive test. Simply check that the function returns
    two values, an error code and an integer.
    """
    [rc, enforcemode] = selinux_getenforcemode()
    assert(isinstance(enforcemode, int))
    assert(isinstance(rc, int))
    if enforcemode is -1:
         assert(rc != 0)
    else:
        assert(rc == 0)


# Generated at 2022-06-22 22:24:06.111836
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    errmsg = "Return code: %d, Type of policy: %s" % (rc, policytype)
    assert rc == 0, errmsg
    # The call returned a non-empty policy type string
    assert len(policytype) > 0, errmsg
    # The policy type string is no longer than 50 characters
    assert len(policytype) <= 50, errmsg



# Generated at 2022-06-22 22:24:09.980527
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create tmpfile
    with open('tmpfile', 'w') as f:
        f.write('tmpcontent')
    # get lgetfilecon_raw
    lgetfilecon_raw('tmpfile')
    # delete tmpfile
    os.remove('tmpfile')


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:24:14.097730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    path = tempfile.mkstemp()[1]

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con != ''
    finally:
        os.remove(path)



# Generated at 2022-06-22 22:24:15.997800
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0

# Generated at 2022-06-22 22:24:24.129874
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, selinux_type = selinux_getpolicytype()
    except OSError:
        rc = 1
        selinux_type = "No policy"

    if rc < 0:
        raise OSError("selinux_getpolicytype failed with return code %s" % rc)

    assert selinux_type == "targeted", "selinux_getpolicytype returned %s" % selinux_type

    return rc


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:24:29.858792
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("selinux_getpolicytype()")
    ret, type_ = selinux_getpolicytype()
    if ret < 0:
        print("ERROR: %d" % ret)
        return ret
    print("policy type: %s" % type_)
    return 0


if __name__ == "__main__":
    ret = test_selinux_getpolicytype()
    sys.exit(ret)

# Generated at 2022-06-22 22:24:33.812232
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    results = lgetfilecon_raw(path)
    if results[0] == 0:
        print('The file %s has the security context %s' % (path, results[1]))
    else:
        print('The file %s had an error of %d' % (path, results[0]))


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:24:34.932889
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:24:38.126527
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert type(selinux_getpolicytype()[0]) == int
    assert isinstance(selinux_getpolicytype()[1], str)

# Generated at 2022-06-22 22:24:43.816517
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Test that lgetfilecon_raw returns a tuple with a status and string """
    from ctypes import c_char_p
    from ctypes import byref

    a = c_char_p(b'/path/to/file')
    rc, con = _selinux_lib.lgetfilecon_raw(a, byref(c_char_p()))

    assert isinstance(rc, int)
    assert isinstance(con, str)

# Generated at 2022-06-22 22:24:54.353493
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux/config'
    if not os.path.exists(path):
        raise ImportError('%s not found' % path)
    _, con = matchpathcon(path, os.stat(path).st_mode)
    if not con:
        raise ImportError('matchpathcon returns None')


__all__ = [
    'selinux_getenforcemode',
    'selinux_getpolicytype',
    'lgetfilecon_raw',
    'matchpathcon',
    'is_selinux_enabled',
    'is_selinux_mls_enabled',
    'security_policyvers',
    'security_getenforce',
    'lsetfilecon',
]

# Generated at 2022-06-22 22:24:57.881307
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc != 0:
        raise ValueError("selinux_getpolicytype returned failure {0}".format(rc))
    print("selinux_getpolicytype type is {0}".format(con))


# Generated at 2022-06-22 22:25:02.633721
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, con = selinux_getpolicytype()
        assert rc == 0
    except NotImplementedError as e:
        pass
    except ImportError as e:
        pass


# Generated at 2022-06-22 22:25:04.290397
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con
    assert isinstance(con, str)

# Generated at 2022-06-22 22:25:13.600635
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Note: must be run as root or with 'sudo'
    try:
        policytype = selinux_getpolicytype()
    except OSError as e:
        if e.errno == 2:
            print('unable to find policytype for {0}'.format(e.filename))
            return 0
        raise
    else:
        if policytype == 0:
            print('selinux policytype found: {0}'.format(policytype[1]))
            return 0
        else:
            print('found unexpected return code: {0}'.format(policytype[0]))
            return 1


# Generated at 2022-06-22 22:25:21.239923
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Unit test for function selinux_getenforcemode
    '''
    print('Unit test for function selinux_getenforcemode')

    rc, enforcemode = selinux_getenforcemode()
    if rc != 0:
        print('selinux_getenforcemode() returned error code: {0}'.format(rc))
        print('(This is expected, if selinux is not installed or not configured)')
    else:
        print('selinux_getenforcemode() returned enforcemode: {0}'.format(enforcemode))



# Generated at 2022-06-22 22:25:24.019431
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/foo'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

# Generated at 2022-06-22 22:25:26.877459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ctypes.util

    if lgetfilecon_raw('/bin/ls')[1] != 'system_u:object_r:bin_t:s0':
        raise Exception('lgetfilecon_raw failed on /bin/ls')

# Generated at 2022-06-22 22:25:30.024661
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test for function matchpathcon
    """
    try:
        rc, res = matchpathcon('/etc/shadow', 0)

        assert res is not None and rc == 0
    except (NotImplementedError, ImportError):
        pass



# Generated at 2022-06-22 22:25:41.536277
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import selinux
    if not selinux.is_selinux_enabled():
        print("Cannot run test as SELinux is not enabled")
        sys.exit(1)
    if not selinux.security_getenforce():
        print("Cannot run test as SELinux is not in enforcing mode")
        sys.exit(1)

    def _cleanup_tmpdir():
        os.unlink(os.path.join(tmpdir, "tmpfile"))
        os.rmdir(tmpdir)

    tmpdir = tempfile.mkdtemp()
    with open(os.path.join(tmpdir, "tmpfile"), 'w') as f:
        f.write("This is a test")


# Generated at 2022-06-22 22:25:50.335859
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/bin/ping', 0)
    assert rc == 0
    assert con == "system_u:object_r:ping_exec_t:s0"

    rc, con = matchpathcon('/usr/bin/ping', os.X_OK)
    assert rc == 0
    assert con == "system_u:object_r:ping_exec_t:s0"

    rc, con = matchpathcon('/usr/bin/ping', os.W_OK)
    assert rc == -1

    rc, con = matchpathcon('/usr/bin/ping', os.W_OK | os.X_OK)
    assert rc == -1

# Generated at 2022-06-22 22:25:56.207251
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_con = lgetfilecon_raw('/usr/bin/python')
    assert test_con[0] == 0
    assert test_con[1] == 'unconfined_u:object_r:bin_t:s0'


# Generated at 2022-06-22 22:25:59.567787
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)


# Generated at 2022-06-22 22:26:05.562046
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w'):
            pass

        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert ':' in con
    finally:
        os.unlink(testfile)
        os.rmdir(tmpdir)



# Generated at 2022-06-22 22:26:11.944751
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print("selinux is not enabled")
        return -1

    [status, pathcon] = matchpathcon('/etc/passwd', 0)
    if status == 0:
        print("/etc/passwd context is '%s'" % pathcon)
    else:
        print("matchpathcon status error")
    return 0



# Generated at 2022-06-22 22:26:20.231933
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _test_filecon(path, expected_rc, expected_con):
        rc, con = lgetfilecon_raw(path)
        assert rc == expected_rc
        assert con == expected_con

    # test a file that doesn't exist
    _test_filecon('/etc/file_that_doesnt_exist', 1, '<<none>>:<<none>>:<<none>>:<<none>>')

    # test a file that does exist
    _test_filecon('/proc/cpuinfo', 0, 'user_u:object_r:proc_cpuinfo_t:s0')

# Generated at 2022-06-22 22:26:23.330882
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:26:28.613622
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test for the function matchpathcon"""
    assert matchpathcon(b'foo', 1) == [0, b'foo']
    assert matchpathcon(b'foo/bar', 1) != [0, b'foo']
    assert matchpathcon(b'foo/bar', 1) != [0, b'bar']



# Generated at 2022-06-22 22:26:36.135919
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as tf:
        os.fchmod(tf.fileno(), 0o644)
        os.fchown(tf.fileno(), -1, -1)
        os.utime(tf.name, None)

        rc, con = lgetfilecon_raw(tf.name)

        assert rc == 0
        print(con)



# Generated at 2022-06-22 22:26:46.952333
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test file (create if not existent)
    tmp_file = '/tmp/ansible-python-test'
    if not os.path.isfile(tmp_file):
        open(tmp_file, 'a').close()
    rc, data = lgetfilecon_raw(tmp_file)
    os.unlink(tmp_file)
    if rc != 0:
        print(to_native(os.strerror(rc)))
        sys.exit(1)
    print(data)
    sys.exit(0)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:26:50.212657
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, val = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert (rc in range(0, 3))
    assert isinstance(val, int)
    assert (val in range(0, 3))



# Generated at 2022-06-22 22:26:51.543237
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/', 0)
    print(result)

# Generated at 2022-06-22 22:26:54.679692
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert type(policytype) == list, "selinux_getpolicytype should return a list"
    assert policytype[0] == 0, "selinux_getpolicytype should return 0 as first element of the list"



# Generated at 2022-06-22 22:27:00.718077
# Unit test for function matchpathcon
def test_matchpathcon():
    print('testing mpathcon...')
    # 0 - File exists with no context (this should succeed)
    print('\tpath exists, no context...')
    [rc, con] = matchpathcon('/tmp', 0)
    if rc < 0:
        print('\t\tFAILED, rc=%d' % rc)
    else:
        print('\t\tSUCCESS, rc=%d con=%s' % (rc, con))
    # 1 - File exists with correct context (this should succeed)
    print('\tpath exists, correct context...')
    [rc, con] = matchpathcon('/etc/shadow', 0)
    if rc < 0:
        print('\t\tFAILED, rc=%d' % rc)

# Generated at 2022-06-22 22:27:12.586967
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json
    import subprocess

    cmd = ['python', '-c', 'from ansible.module_utils.selinux import *; print(json.dumps(selinux_getpolicytype()))']
    out = subprocess.check_output(cmd)
    value = json.loads(out)
    if not isinstance(value, list):
        raise ValueError('expected list, got: {0}'.format(value))
    if not all(isinstance(v, int) for v in value):
        raise TypeError('expected int in list, got: {0}'.format(value))
    if value[0] == 0:
        if not isinstance(value[1], basestring):
            raise TypeError('expected string, got: {0}'.format(value))

# Generated at 2022-06-22 22:27:13.403673
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    r = selinux_getenforcemode()
    assert r == [0, 0]



# Generated at 2022-06-22 22:27:20.686900
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    This function is used to test the function matchpathcon written in selinux.py
    :return:
    '''
    print('[+] Test output: ', end='')
    rc, con = matchpathcon('/etc/passwd', 0)
    if rc == 0 and con == 'system_u:object_r:unlabeled_t:s0':
        print('\033[32mPASSED\033[0m')
    else:
        print('\033[31mFAILED\033[0m')



# Generated at 2022-06-22 22:27:26.281112
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/boot/vmlinuz-4.4.0-166-generic"
    mode = 0
    rc, relabel = matchpathcon(path, mode)
    if rc == 0:
        print("Matchpathcon return code: " + str(rc))
        print("Relabel context is: " + str(relabel))
    else:
        print("Matchpathcon failed")


# Generated at 2022-06-22 22:27:36.401358
# Unit test for function matchpathcon
def test_matchpathcon():
    mpc = matchpathcon('/etc/hosts', 0)
    assert mpc[0] == 0
    assert type(mpc[1]) is str
    assert mpc[1].startswith('system_u:object_r:etc_runtime_t')
    assert mpc[1].endswith(':s0')
    assert len(mpc[1].split(':')) == 4

    mpc = matchpathcon('/etc/hosts', 0)
    assert mpc[0] == 0
    assert type(mpc[1]) is str
    assert mpc[1].startswith('system_u:object_r:etc_runtime_t')
    assert mpc[1].endswith(':s0')
    assert len(mpc[1].split(':')) == 4

    mpc

# Generated at 2022-06-22 22:27:48.031242
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        mode = selinux_getenforcemode()
        try:
            # setenforce is not always present
            # https://github.com/ansible/ansible/issues/64224
            # FIXME: This is likely to cause unit test failure
            mode_value = open('/selinux/enforce', 'r').readline().strip()
        except IOError:
            # setenforce not available
            pass
        else:
            assert mode[1] == int(mode_value)
        assert mode[0] == 0
    except IOError as e:
        # selinux not enabled
        assert e.errno == 2

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:27:55.265416
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test path that is known to be valid in context 'system_u:object_r:svirt_sandbox_file_t:s0:c49,c14403'
    path = '/tmp/test'
    ret = matchpathcon(path, os.R_OK)
    assert not ret[0]
    assert ret[1] == 'system_u:object_r:svirt_sandbox_file_t:s0:c49,c14403'

# Generated at 2022-06-22 22:27:56.492113
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # No unit tests available
    pass



# Generated at 2022-06-22 22:27:59.167742
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # return type of enum selinux_enforce_t is int
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)


# Generated at 2022-06-22 22:28:01.801970
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert str(enforcemode) in ['1', '0']


# Generated at 2022-06-22 22:28:04.035054
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[0] == 0
    assert len(policy[1]) > 0

# Generated at 2022-06-22 22:28:14.612411
# Unit test for function matchpathcon
def test_matchpathcon():
    global _selinux_lib  # pylint: disable=global-statement

    class MockCDLL:
        def __init__(self, dll):
            self.dll = dll

        def __getattr__(self, attr):
            return getattr(self.dll, attr)

        def matchpathcon(self, path, mode, con):
            if path == b'/usr/bin/python':
                return 1
            return 0

    def _module_setup():
        global _selinux_lib  # pylint: disable=global-statement
        _selinux_lib = MockCDLL(_selinux_lib)

    # This must run after _module_setup()
    import unittest  # pylint: disable=unused-import,redefined-outer-name


# Generated at 2022-06-22 22:28:18.158224
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert type(enforcemode) is int



# Generated at 2022-06-22 22:28:21.270850
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = to_native(selinux_getenforcemode()[1])
    if enforcemode in ('1', '0'):
        return True
    else:
        return False


# Generated at 2022-06-22 22:28:26.798520
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/")
    if rc == -1:
        if con is not None:
            print("Error: %s" % con)
        else:
            print("Error: Function call failed")
        return
    else:
        assert(con == "system_u:object_r:root_t:s0")
        print("Return value: %s" % con)
    return


# Generated at 2022-06-22 22:28:32.311726
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    assert isinstance(enforcemode, int), "enforcemode is not an integer"
    enforcemode_list = [0, 1, 2]
    enforcemode_list.append(enforcemode)
    assert enforcemode in enforcemode_list, "enforcemode is not one of the possible value"


# Generated at 2022-06-22 22:28:35.958402
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        selinux_getenforcemode()
    except OSError:
        return

    rc, msg = matchpathcon('/etc/cron.daily/logrotate', 0)
    if rc != 0:
        raise Exception('selinux test failed: {0}'.format(msg))

    rc, msg = lgetfilecon_raw('/etc/cron.daily/logrotate')
    if rc != 0:
        raise Exception('selinux test failed: {0}'.format(msg))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:44.510738
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_value = matchpathcon(b"/tmp", 0)
    assert con_value == b"system_u:object_r:user_tmp_t:s0"
    assert rc == 0

    rc, con_value = matchpathcon(b"/home/myuser", 0)
    assert con_value == b"system_u:object_r:user_home_dir_t:s0"
    assert rc == 0

    rc, con_value = matchpathcon(b"/home/myuser", os.X_OK)
    assert con_value == b"system_u:object_r:user_home_dir_t:s0:c0"
    assert rc == 0



# Generated at 2022-06-22 22:28:47.059094
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0, 'unable to get enforcement mode'
    assert enforcemode in (0, 1, 2), 'enforcement mode is not valid'



# Generated at 2022-06-22 22:28:48.741674
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/enable.pl'
    return matchpathcon(path, 0)



# Generated at 2022-06-22 22:28:55.074452
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        [rc, enforcemode] = selinux_getenforcemode()
        if rc < 0:
            raise OSError(rc, os.strerror(rc))
    except OSError as e:
        rc = e.errno
        enforcemode = -1
    return [rc, enforcemode]

if __name__ == '__main__':
    print(test_selinux_getenforcemode())

# Generated at 2022-06-22 22:28:59.983768
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/dev/mapper/centos_centos-root'

    rc, _ = matchpathcon(path, os.R_OK)
    assert rc == 0


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:02.439931
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) == list, "selinux_getenforcemode() type should be list"


# Generated at 2022-06-22 22:29:04.004898
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    _, enforcemode = selinux_getenforcemode()
    assert enforcemode in (0, 1)


# Generated at 2022-06-22 22:29:09.260228
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret = selinux_getpolicytype()
    assert ret[0] == 0
    assert isinstance(ret[1], str)
    assert ret[1] in ['targeted', 'minimum', 'mls']


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:29:12.360162
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test get current process context
    rc, con = lgetfilecon_raw('/proc/self/exe')
    assert rc >= 0 and con is not None and con != '', 'Problem getting process context'



# Generated at 2022-06-22 22:29:19.849672
# Unit test for function matchpathcon
def test_matchpathcon():
    tests = (
        ('/usr/bin/ls', 0, [0, 'system_u:object_r:bin_t:s0']),
    )

    for path, mode, expected in tests:
        rc, con = matchpathcon(path, mode)
        if rc != expected[0] or con != expected[1]:
            raise Exception('Matchpathcon test failed: Expected: {0}, Actual: {1}'.format(expected, [rc, con]))



# Generated at 2022-06-22 22:29:27.142593
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype_orig = selinux_getpolicytype()[1]
    assert policytype_orig != '', 'unable to find selinux policytype'

    policytype_new = 'selinux_faketype'
    os.environ['SELINUX_DEFAULT_TYPE'] = policytype_new

    policytype_afterreload = selinux_getpolicytype()[1]
    assert policytype_afterreload != policytype_orig, 'environment did not affect selinux policytype'

    policytype_afterreload2 = selinux_getpolicytype()[1]
    assert policytype_afterreload == policytype_afterreload2, 'reloaded selinux policytype is non-deterministic'



# Generated at 2022-06-22 22:29:30.891414
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    rc, con = matchpathcon(b"/", 0)
    print(con)

# Generated at 2022-06-22 22:29:33.444943
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/proc/1/ns/mnt', 0)
    if rc == 0:
        assert con == 'system_u:object_r:nsmount_t:s0'
    else:
        assert False



# Generated at 2022-06-22 22:29:36.878113
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc > -1
    assert con == 'mcs'

# Generated at 2022-06-22 22:29:38.669301
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 1] == selinux_getenforcemode()



# Generated at 2022-06-22 22:29:47.732254
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:29:53.095416
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/tmp/selinux-ctypes-test'
    if os.path.exists(test_path):
        os.remove(test_path)
    rc, con = lgetfilecon_raw(test_path)
    assert rc == -1
    assert con is None
    assert errno.errorcode.get(errno.ENOENT) == 'ENOENT'
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert ':' in con


# Generated at 2022-06-22 22:30:00.432406
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    unit test for function matchpathcon
    """
    (rc, con) = matchpathcon("/test/testfile", 0)
    print(rc)
    print(con)
    (rc, con) = matchpathcon("/test/testfile", 0o000)
    print(rc)
    print(con)
    return rc


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-22 22:30:04.702706
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, filecon = lgetfilecon_raw("/etc/passwd")
    if rc < 0:
        raise OSError(get_errno())
    print("rc: " + str(rc) + " filecon: " + filecon)



# Generated at 2022-06-22 22:30:10.345514
# Unit test for function matchpathcon
def test_matchpathcon():
    # Does matchpathcon return a non-zero value for a path not in /path/to/source?
    rc, con = matchpathcon('/etc/passwd', 0)
    if rc:
        print('Whoops, something went wrong. {0}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:13.893281
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp'
    rc, filecon = lgetfilecon_raw(path)

    assert rc == 0
    assert filecon.startswith(b'system_u:object_r:tmp_t')

# Generated at 2022-06-22 22:30:18.202971
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/ansible/test'

    from ansible.module_utils.selinux import lgetfilecon_raw
    rc, con = lgetfilecon_raw(path)
    assert rc >= 0
    assert con is not None

# Generated at 2022-06-22 22:30:22.902181
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("selinux_getenforcemode()")
    (rc, enforcemode) = selinux_getenforcemode()
    print("selinux_getenforcemode returned {} and {}".format(rc, enforcemode))
    print("")



# Generated at 2022-06-22 22:30:25.540395
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/mnt/foo/bar", 0)
    print("rc=", rc, "con=", con)



# Generated at 2022-06-22 22:30:27.654817
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0
    assert result[1] in [0, 1]



# Generated at 2022-06-22 22:30:31.393478
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc < 0:
        raise RuntimeError('could not get policy type: rc=%d' % rc)
    print('policy type: %s' % con)



# Generated at 2022-06-22 22:30:35.224388
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    def mock_selinux_getpolicytype(arg):
        return "mock return"

    policy = selinux_getpolicytype()

    if policy:
        assert isinstance(policy, list)
        assert policy[0] == 0
        assert policy[1] == "selinux"
    else:
        assert False



# Generated at 2022-06-22 22:30:38.737830
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:30:45.685895
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0o644
    expected_out = [-1, 'system_u:object_r:unlabeled_t:s0']
    expected_in = "/var/lib/nfs/rpc_pipefs/nfs"
    actual_out = matchpathcon(expected_in, mode)
    assert expected_out == actual_out
    # Do the same validation for path that exists
    expected_in = "/etc/fstab"
    actual_out = matchpathcon(expected_in, mode)
    assert expected_out != actual_out

# Generated at 2022-06-22 22:30:50.117728
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.stat('/').st_ino == 2:
        assert matchpathcon('/', 0) == [0, 'root']
        assert matchpathcon('/etc/passwd', 0) == [0, 'etc_t']

# Generated at 2022-06-22 22:30:53.827950
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    output = lgetfilecon_raw('/usr/bin/less')
    assert output[0] == 0, 'Return code should have been 0'
    assert output[1] == 'system_u:object_r:textrel_shlib_t:s0', 'Unexpected output {}'.format(output)



# Generated at 2022-06-22 22:30:56.283798
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    selinux_enforcemode = selinux_getenforcemode()
    assert selinux_enforcemode[0] == 0
    assert selinux_enforcemode[1] == 1



# Generated at 2022-06-22 22:31:01.821015
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, result = matchpathcon('/var/log/audit/audit.log', 0)
    except ImportError:
        return

    assert rc == 0
    assert result == 'system_u:object_r:auditlog_t:s0'

# Generated at 2022-06-22 22:31:10.770605
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def do_test_lgetfilecon_raw(path, expected):
        rc, con = lgetfilecon_raw(path)
        assert rc == 0, 'lgetfilecon_raw returned %s' % rc
        assert con == expected, "%s != %s" % (con, expected)
        print("%s -> %s" % (path, con))

    do_test_lgetfilecon_raw(b'/', 'system_u:object_r:root_t:s0')
    do_test_lgetfilecon_raw(b'/etc', 'system_u:object_r:etc_t:s0')
    do_test_lgetfilecon_raw(b'/etc/passwd', 'system_u:object_r:etc_t:s0')
    do_test_lgetfilecon_

# Generated at 2022-06-22 22:31:14.488675
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    f = selinux_getenforcemode()
    assert type(f) is list
    assert len(f) is 2
    assert type(f[0]) is int
    assert type(f[1]) is int


# Generated at 2022-06-22 22:31:15.435361
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-22 22:31:19.075233
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_data = lgetfilecon_raw('/tmp/test_file')
    correct_data = [0, 'system_u:object_r:tmp_t:s0']
    assert test_data == correct_data



# Generated at 2022-06-22 22:31:23.345225
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/sys/kernel/selinux/enforce'

    for mode in (0, 1):
        try:
            rc, con = matchpathcon(path, mode)
        except OSError as e:
            print('{0}'.format(e))
        else:
            print('rc={0}, con={1}'.format(rc, con))



# Generated at 2022-06-22 22:31:34.005801
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for function matchpathcon
    :return:
    """
    from tempfile import mkdtemp

    # Create a directory and call matchpathcon with the mode set to 0
    path = mkdtemp(prefix='ansible-test')
    try:
        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con.startswith('system_u:object_r:')
    finally:
        os.rmdir(path)

    # Create a directory and call matchpathcon with the mode set to 1
    path = mkdtemp(prefix='ansible-test')
    try:
        rc, con = matchpathcon(path, 1)
        assert rc == 0
        assert con.startswith('system_u:object_r:')
    finally:
        os.r

# Generated at 2022-06-22 22:31:35.150125
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-22 22:31:39.205235
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/sys') == [0, 'system_u:object_r:sysfs_t:s0']



# Generated at 2022-06-22 22:31:49.611091
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b"/", 0)[1] == "system_u:object_r:root_t:s0"
    assert matchpathcon(b"/", 128)[1] == "user_u:object_r:root_t:s0"
    assert matchpathcon(b"/", 1024)[1] == "system_u:object_r:root_t:s0"
    assert matchpathcon(b"/aaa", 0)[1] == "system_u:object_r:admin_home_t:s0"
    assert matchpathcon(b"/bbb", 128)[1] == "user_u:object_r:admin_home_t:s0"

# Generated at 2022-06-22 22:31:50.153555
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass

# Generated at 2022-06-22 22:31:56.284953
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    test_dir_path = tempfile.TemporaryDirectory()
    test_dir = test_dir_path.name
    print("Testing matchpathcon with %s" % test_dir)

    test_file = os.path.join(test_dir, "test_file")
    test_file_fd = os.open(test_file, os.O_WRONLY | os.O_CREAT)
    os.close(test_file_fd)
    assert os.path.exists(test_file)
    rc, con = matchpathcon(test_file, os.R_OK)
    assert rc == 0
    assert con is not None

# Generated at 2022-06-22 22:31:59.791714
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()

    assert rc >= 0, "rc {0} is less than 0".format(rc)
    assert con is not None, "con is None, should not be None"



# Generated at 2022-06-22 22:32:02.371747
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon("/var/log/audit", 0)
    assert rc[0] == 0
    assert rc[1] != ""

# Generated at 2022-06-22 22:32:03.665806
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-22 22:32:08.422552
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] < 0, selinux_getenforcemode()[0]
    assert selinux_getenforcemode()[1] in [0, 1, 2], selinux_getenforcemode()[1]


# Generated at 2022-06-22 22:32:10.113812
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    x = selinux_getpolicytype()
    assert x[0] == 0
    print(x)
    print("my policy type is " + x[1])



# Generated at 2022-06-22 22:32:16.487262
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        matchpathcon('/', 0)
    except Exception as e:
        print(e)

    try:
        matchpathcon('/etc/passwd', 0)
    except Exception as e:
        print(e)

# Generated at 2022-06-22 22:32:18.922765
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("Selinux enforcemode: %s" % enforcemode)



# Generated at 2022-06-22 22:32:21.526211
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc == 0:
        assert 0 <= mode <= 2
    else:
        assert rc == -1


# Generated at 2022-06-22 22:32:24.445368
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # test_context = ...
    data = selinux_getenforcemode()
    assert data[0] == 0
    assert data[1] == 1


# Generated at 2022-06-22 22:32:29.536385
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists('/etc/passwd'):
        rc, con = lgetfilecon_raw('/etc/passwd')
        assert rc == 0
        rc, policytype = selinux_getpolicytype()
        assert rc == 0
        assert policytype in con

    else:
        # FIXME: this needs a better test, not just checking it doesn't crash on el6
        lgetfilecon_raw('/etc/passwd')

# Generated at 2022-06-22 22:32:33.717705
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, out = selinux_getpolicytype()
    assert rc >= 0, "Invalid return code"
    assert isinstance(out, str), "Returned value not a string"

