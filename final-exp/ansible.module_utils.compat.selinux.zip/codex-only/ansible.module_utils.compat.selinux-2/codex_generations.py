

# Generated at 2022-06-22 22:22:36.155636
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, mode = selinux_getenforcemode()
        assert rc == 0
        assert mode in [0, 1, 2]
    except Exception as e:
        assert False, 'unexpected exception: {0}'.format(to_native(e))


# Generated at 2022-06-22 22:22:38.737722
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert int(policytype[0]) == 0
    assert policytype[1] == 'targeted'

# Generated at 2022-06-22 22:22:43.479913
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd') == [0, b'unconfined_u:object_r:user_home_t:s0']
    assert lgetfilecon_raw(b'/etc/passwd') == [0, 'unconfined_u:object_r:user_home_t:s0']

# Generated at 2022-06-22 22:22:45.239554
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    print(rc)
    print(enforcemode)



# Generated at 2022-06-22 22:22:55.161627
# Unit test for function matchpathcon
def test_matchpathcon():
    def return_test(test_data):
        for data in test_data:
            path = data.get('path')
            mode = data.get('mode')
            expected = data.get('expected')
            result = matchpathcon(path, mode)
            if result[0] != 0:
                return (False, "Unexpected error occurred")
            if result[1] != expected:
                return (False, "Result mismatch")
        return (True, None)

    test_data = [
        {
            'path': "/etc/test/test.txt",
            'mode': os.R_OK,
            'expected': "system_u:object_r:etc_t:s0"
        }
    ]
    return return_test(test_data)

# Generated at 2022-06-22 22:23:02.583333
# Unit test for function matchpathcon
def test_matchpathcon():
    if not selinux_getpolicytype()[1] == "targeted":
        raise RuntimeError("Test only applies to targeted policy")

    if not is_selinux_enabled()[1]:
        raise RuntimeError("Test requires SELinux enabled")

    testfile = "/tmp/selinux_test"
    filecon = "system_u:object_r:tmp_t:s0"

    with open(testfile, "w") as f:
        f.write("selinux")

    rc, con = lgetfilecon_raw(testfile)
    if not rc == 0:
        # File may not have the right context
        if not rc == -1:
            raise OSError("Unable to get file context")
        rc, con = lsetfilecon(testfile, filecon)

# Generated at 2022-06-22 22:23:06.285350
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, selcon = matchpathcon('/data/t2', 0o777)
    assert rc == 0
    assert selcon == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:23:15.666210
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Unit test for function selinux_getenforcemode.
    Output of selinux_getenforce:
    [0, 1] if enabled and enforcing
    [0, 0] if enabled and permissive
    [1, -1] if disabled
    '''
    if selinux_getenforcemode()[0] == 0 and selinux_getenforcemode()[1] == 1:
        print("[PASS] selinux is enabled and enforcing")
    elif selinux_getenforcemode()[0] == 0 and selinux_getenforcemode()[1] == 0:
        print("[PASS] selinux is enabled and permissive")

# Generated at 2022-06-22 22:23:25.887897
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.stdout.write('Testing selinux.matchpathcon...')
    try:
        import tempfile
        fd, fname = tempfile.mkstemp()
        rc, con = matchpathcon('/tmp', 0)
        rc, fcon = matchpathcon(fname, 0)
        os.close(fd)
        os.unlink(fname)
        if rc != 0:
            raise RuntimeError('test_matchpathcon failed')
    except ImportError as e:
        raise RuntimeError('test_matchpathcon: Skipping due to import error: ' + str(e))
    sys.stdout.write('ok\n')



# Generated at 2022-06-22 22:23:30.398845
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    print("\nrc = {0}".format(rc))
    print("policytype = {0}".format(policytype))


# Generated at 2022-06-22 22:23:34.483230
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw('/usr/bin/python3.7')
    assert type(res) == list
    assert len(res) == 2
    assert type(res[0]) == int
    assert type(res[1]) == str



# Generated at 2022-06-22 22:23:44.705198
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Run function selinux_getpolicytype
    rc, policy = selinux_getpolicytype()
    if rc != 0:
        raise AssertionError('Expected selinux_getpolicytype to return rc 0, got {}'.format(rc))
    if not policy:
        raise AssertionError('Expected selinux_getpolicytype to return policy, got none')
    if policy not in ('targeted', 'mls'):
        raise AssertionError('Expected selinux_getpolicytype to return policy "targeted" or "mls", got {}'.format(policy))
    print('Success: selinux_getpolicytype')


if __name__ == '__main__':
    # Unit test the module
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:23:46.641422
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1]
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:23:51.762862
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/fstab') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/fstab') == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-22 22:23:54.565156
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Below is the output of "selinux_getpolicytype()" on a Debian 9 system
    # [0, 'targeted']
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:24:01.165740
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/etc/passwd', 0)
        assert rc == 0
        assert con == 'system_u:object_r:passwd_file_t:s0'
    except OSError as exception:
        raise AssertionError(
            'Execution of matchpathcon failed with message "{0}".'.format(exception.args[1])
        )

# Generated at 2022-06-22 22:24:02.602073
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 1] == selinux_getenforcemode()



# Generated at 2022-06-22 22:24:07.883826
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/con"
    f = open(path, 'w')
    f.write("foo")
    f.close()

    try:
        (rc, con) = lgetfilecon_raw(path)
        assert rc == 0
        print("con: {0}".format(con))
    finally:
        os.remove(path)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:24:11.877507
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    rc, policytype = selinux_getpolicytype()

    policy_types = [
        'strict',
        'targeted',
        'mcs',
        'mls'
    ]

    assert rc == 0
    assert policytype in policy_types

# Generated at 2022-06-22 22:24:14.116337
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(lgetfilecon_raw(b'/etc/motd'), list)


# Generated at 2022-06-22 22:24:21.929782
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        module.fail_json(msg='selinux is not enabled')

    (rc, enforcemode) = selinux_getenforcemode()
    if rc != 0 or enforcemode not in [0, 1, 2]:
        module.fail_json(msg='failed to get SELinux enforce mode')

    module.exit_json(msg='successfully got selinux enforcemode={0}'.format(enforcemode), changed=False)



# Generated at 2022-06-22 22:24:26.968728
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/ssh_config', os.R_OK)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:sshd_config_t:s0'



# Generated at 2022-06-22 22:24:29.980906
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/chmod'
    expected_con = 'system_u:object_r:chmod_exec_t:s0'

    assert lgetfilecon_raw(path)[1] == expected_con

# Generated at 2022-06-22 22:24:35.284816
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Calls matchpathcon() with file path and permission mode and returns 0 on success, -1 on failure
    """
    path = "/etc/passwd"
    mode = 0o644
    rc, con = matchpathcon(path, mode)
    if rc == 0:
        print("Success: ", con)
    else:
        print("Failure: path=%s, mode=0%o, rc=%d, con=%s" % (path, mode, rc, con))



# Generated at 2022-06-22 22:24:44.449570
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        from tempfile import TemporaryDirectory
    except ImportError:
        raise unittest.SkipTest("Tempfile module not available")

    tempdir = None

    try:
        with TemporaryDirectory() as tempdir:
            dirname = os.path.join(tempdir, "test_dir")
            os.mkdir(dirname)

            rc, con = is_selinux_enabled()
            self.assertEqual(rc, 0)
            if not rc:
                rc, con = matchpathcon(dirname, 1)
                self.assertEqual(rc, 0)

    finally:
        if tempdir:
            shutil.rmtree(tempdir)

# Generated at 2022-06-22 22:24:47.810479
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(mode, int)


# Generated at 2022-06-22 22:24:56.848591
# Unit test for function matchpathcon
def test_matchpathcon():
    # This function tests for the return value of the function matchpathcon
    # Pass a valid path and verify the return code
    assert matchpathcon('/var/lib/docker/containers/c588d28e34d99c84e5f5d5c5a3fb3a6652c9ec35b0c7d7e2d1c739694e4d4c4e/config.v2.json', 0)[0] == 0
    # Pass an invalid path and verify the return code
    assert matchpathcon('/var/lib/docker/containers/c588d28e34d99c84e5f5d5c5a3fb3a6652c9ec35b0c7d7e2d1c739694e4d4c4e/config.v2.json', 1)[0]

# Generated at 2022-06-22 22:25:01.424473
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[0] < 0:
        raise OSError(result[0], os.strerror(result[0]))
    return result[1]

# Generated at 2022-06-22 22:25:04.793558
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    func = sys.modules[__name__].selinux_getenforcemode
    assert func() == [0, 0], "selinux_getenforcemode returned {0} instead of [0, 0]".format(func())


# Generated at 2022-06-22 22:25:05.972707
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    pass


# Generated at 2022-06-22 22:25:10.983677
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not selinux_getenforcemode()[1]:
        print('SELinux is not enabled. Skipping selinux_getpolicytype test')
        return
    print('selinux_getpolicytype returned: "%s"' % selinux_getpolicytype()[1])



# Generated at 2022-06-22 22:25:13.695462
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, msg = _selinux_lib.selinux_getenforcemode()
    assert rc >= 0
    assert msg == 0 or msg == 1


# Generated at 2022-06-22 22:25:16.692153
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    policytype in ['targeted', 'strict', 'mls']



# Generated at 2022-06-22 22:25:26.736533
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Running tests on function matchpathcon ...')
    print('matchpathcon("/var/lib/libvirt/images/test.img","f")')
    print('Return code: {0}'.format(matchpathcon("/var/lib/libvirt/images/test.img","f")[0]))
    print('matchpathcon("/var/lib/libvirt/images/test.img","c")')
    print('Return code: {0}'.format(matchpathcon("/var/lib/libvirt/images/test.img","c")[0]))
    print('matchpathcon("/var/lib/libvirt/images/test.img","f")')
    print('Return code: {0}'.format(matchpathcon("/var/lib/libvirt/images/test.img","f")[0]))


# Generated at 2022-06-22 22:25:27.864045
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:25:29.910798
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw(b"/etc/passwd")
    assert rc >= 0
    assert con is not None
    assert con != b'unlabeled'

# Generated at 2022-06-22 22:25:31.969818
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/tmp/test_matchpathcon", 0)
    assert result[0] == 0


# Generated at 2022-06-22 22:25:35.693789
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    s = lgetfilecon_raw(b'/tmp/testfile')
    assert (type(s) == list and s[0] == 0)

# Generated at 2022-06-22 22:25:39.567037
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce_mode = selinux_getenforcemode()
    if enforce_mode[1] == -1:
        assert enforce_mode[0] == 1
    else:
        assert enforce_mode[0] == 0



# Generated at 2022-06-22 22:25:44.681769
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test the wrapper function
    # selinux_getenforcemode()
    [rc, enforcemode] = selinux_getenforcemode()
    print(rc, enforcemode)
    assert(type(enforcemode) == int)


# Generated at 2022-06-22 22:25:47.124516
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce_mode = selinux_getenforcemode()
    assert rc == 0
    assert enforce_mode >= 1


# Generated at 2022-06-22 22:25:50.858205
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, stdout = matchpathcon('/etc/apparmor', 0)
    if ret == 0:
        print("matchpathcon returned {}".format(stdout))
    else:
        print("matchpathcon returned an error {}".format(ret))


# Generated at 2022-06-22 22:25:59.414410
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "test_file"
    test_file_contents = "Hello World"

    try:
        with open(test_file, "w") as test_file_handle:
            test_file_handle.write(test_file_contents)

        [rc, con] = lgetfilecon_raw(test_file)

        assert rc == 0
        assert con is not None

    finally:
        os.unlink(test_file)

# Generated at 2022-06-22 22:26:01.905336
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enf = selinux_getenforcemode()
    assert rc >= 0
    assert enf in [-1, 0, 1]



# Generated at 2022-06-22 22:26:11.021904
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import selinux as selinux_utils
    path = os.path.dirname(selinux_utils.__file__)
    (rc, con) = lgetfilecon_raw(path)
    if rc >= 0:
        con = con.rstrip(b'\x00')
    else:
        con = None
    assert isinstance(con, bytes)


# Generated at 2022-06-22 22:26:14.920648
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Tests the function matchpathcon
    """
    assert matchpathcon("/etc/passwd", 0) == [0, "system_u:object_r:passwd_file_t:s0"]

# Generated at 2022-06-22 22:26:24.350964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import mkstemp
    from shutil import rmtree
    from os import mkdir, close
    from os.path import exists, isdir, dirname
    from stat import S_IWUSR

    tmpdir = mkdtemp()
    con = mktemp(dir=tmpdir)


# Generated at 2022-06-22 22:26:26.680007
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    print("Context: %s" % lgetfilecon_raw(path))


# Generated at 2022-06-22 22:26:31.558669
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/usr/bin/vim"
    mode = 0o755
    # Path and mode are given, it should return the context
    result, context = matchpathcon(path, mode)
    assert result == 0
    assert context == "system_u:object_r:bin_t"
    # Path and mode given but path is invalid, it should return an error
    result, context = matchpathcon("", mode)
    assert result == -1

# Generated at 2022-06-22 22:26:32.140678
# Unit test for function selinux_getpolicytype

# Generated at 2022-06-22 22:26:35.587686
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-22 22:26:39.218858
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw("/")
    assert ret[0] == 0, "Expected 0 for returned code, got %s" % ret[0]
    assert ret[1] != "", "Expected string returned, got %s" % ret[1]



# Generated at 2022-06-22 22:26:51.247628
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    path = '/etc/rc.d/init.d'
    mode = os.F_OK

    con_tup = matchpathcon(path, mode)
    rc = con_tup[0]
    con = con_tup[1]

    if rc < 0:
        print("matchpathcon failed")
    else:
        print(con)


__all__ = [
    'is_selinux_enabled',
    'is_selinux_mls_enabled',
    'lgetfilecon_raw',
    'matchpathcon',
    'security_getenforce',
    'security_policyvers',
    'selinux_getenforcemode',
    'selinux_getpolicytype',
    'lsetfilecon',
]


# Generated at 2022-06-22 22:26:54.097739
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Unit test for function selinux_getenforcemode
    '''
    print(selinux_getenforcemode()[1])


if __name__ == "__main__":
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:26:59.771712
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import unittest
    import tempfile
    import os

    class TestLgetfileconRaw(unittest.TestCase):
        def setUp(self):
            _, self.temp_path = tempfile.mkstemp()
            os.unlink(self.temp_path)
            os.mkdir(self.temp_path)

        def tearDown(self):
            os.rmdir(self.temp_path)

        def test_get_context(self):
            self.assertEqual([0, 'system_u:object_r:tmp_t:s0'], lgetfilecon_raw(self.temp_path))

        def test_invalid_path(self):
            self.assertRaises(OSError, lgetfilecon_raw, '/invalid_path')


# Generated at 2022-06-22 22:27:12.467538
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/foo"
    rc = 0
    con = None
    try:
        fd = os.open(path, os.O_CREAT)
        rc, con = _selinux_lib.lgetfilecon_raw(path, byref(c_char_p()))
    finally:
        os.close(fd)
        try:
            os.remove(path)
        except FileNotFoundError:
            pass

    assert rc == 0, "[{0}] lgetfilecon_raw failed".format(rc)
    assert con == "system_u:object_r:unlabeled_t:s0", "[{0}] lgetfilecon_raw did not return system_u:object_r:unlabeled_t:s0".format(con)



# Generated at 2022-06-22 22:27:22.442144
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test the lgetfilecon_raw function by running it against a symlink"""

    from tempfile import mktemp
    from os import symlink, unlink
    from os.path import exists, join as pjoin, realpath

    # Create a temporary symlink in a temporary directory
    temp_dir = mktemp()
    temp_link = pjoin(temp_dir, 'temp_link')
    temp_target = pjoin(temp_dir, 'temp_target')
    temp_file = pjoin(temp_dir, 'temp_file')


# Generated at 2022-06-22 22:27:24.650562
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''Check that selinux_getpolicytype() returns policy type.'''
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-22 22:27:27.985641
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/tmp/test_matchpathcon', 0)
    assert(rc == 0)
    assert(con == 'system_u:object_r:tmp_t')



# Generated at 2022-06-22 22:27:31.980677
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test for typical values returned by selinux_getpolicytype
    assert selinux_getpolicytype() in ([0, 'targeted'], [0, 'mls']) or selinux_getpolicytype()[0] != 0



# Generated at 2022-06-22 22:27:39.827083
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    import sys
    import pytest

    # test_selinux_getenforcemode() must be run as root
    if os.geteuid() != 0:
        pytest.skip("test_selinux_getenforcemode() can only be run as root")

    mode = selinux_getenforcemode()
    assert isinstance(mode, list) and len(mode) == 2
    assert isinstance(mode[0], int)
    assert isinstance(mode[1], int)
    if mode[0] < 0:
        raise OSError(mode[0], os.strerror(mode[0]))



# Generated at 2022-06-22 22:27:41.959494
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ['targeted', 'mls']



# Generated at 2022-06-22 22:27:46.181458
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc == 0:
        print('selinux_getpolicytype succeeded: {}'.format(con))
    else:
        print('selinux_getpolicytype failed: {} {}'.format(rc, con))


# Generated at 2022-06-22 22:27:53.061651
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Tests the following static chcon -t ssh_home_t /ssh_data/home
    on a selinux context (if selinux is enabled on the system)
    :return:
    """
    ssh_data_path, ssh_home_context_type = '/ssh_data/home', 'ssh_home_t'
    rc, context = matchpathcon(ssh_data_path, 0)
    if rc == -1:
        try:
            raise Exception("matchpathcon failed with error: %s" % context)
        except Exception as err:
            assert False, err
    assert context.split(":")[-1] == ssh_home_context_type, \
        "matchpathcon returned invalid context: %s" % context
    assert True

# Generated at 2022-06-22 22:27:57.416715
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.icontains("/usr/sbin/auditctl"):
        assert (lgetfilecon_raw("/usr/sbin/auditctl").endswith("system_u:object_r:auditctl_exec_t"))



# Generated at 2022-06-22 22:28:09.475482
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        _selinux_lib.lgetfilecon_raw
    except:
        raise RuntimeError('missing function: lgetfilecon_raw')

    fake_home = "/foo/bar"
    fake_filename = "myhostname"
    fake_path = os.path.join(fake_home, fake_filename)

    try:
        with open(fake_path, 'w') as f:
            f.write('penguin')
    except Exception as e:
        raise RuntimeError('failed to write myhostname in /foo/bar: {0}'.format(e))

    (rc, label) = lgetfilecon_raw(fake_path)

    if rc != 0:
        raise RuntimeError('Failed to get file context: %d %s' % rc)

    if label == "":
        raise

# Generated at 2022-06-22 22:28:12.499765
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0, "invalid return code"



# Generated at 2022-06-22 22:28:14.009625
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert isinstance(selinux_getpolicytype, object)



# Generated at 2022-06-22 22:28:18.266048
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-22 22:28:27.971637
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('---')[0] != 0
    assert lgetfilecon_raw('.')[1] != ""

    # Custom path to log file
    LOGFILE = '/tmp/selinux_test.log'

    # Unit test for function lsetfilecon
    def test_lsetfilecon():
        assert lsetfilecon('/etc/passwd', '---') != 0

    # Unit test for fucntion selinux_getpolicytype
    def test_selinux_getpolicytype():
        assert selinux_getpolicytype()[0] != 0
        assert selinux_getpolicytype()[1] != ""

    # Unit test for function selinux_getenforcemode
    def test_selinux_getenforcemode():
        assert selinux_getenforcemode()[0] != 0

# Generated at 2022-06-22 22:28:30.587001
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert policy == 'targeted'

# Generated at 2022-06-22 22:28:34.035173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-22 22:28:39.412557
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    if rc < 0:
        print("Unable to get file context on '/etc/selinux/config'")
    else:
        print("Success getting file context on '/etc/selinux/config' as '{0}'".format(con))



# Generated at 2022-06-22 22:28:44.761836
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.isdir('/proc'), 'This test needs /proc and container_capabilities needs host_etc_dir'
    assert os.path.isdir('/etc'), 'This test needs /etc and container_capabilities needs host_etc_dir'
    assert matchpathcon('/proc', 0) == [0, 'proc']
    # Test is only valid if /etc is labeled
    assert matchpathcon('/etc', 0) == [0, 'etc_t']

# Generated at 2022-06-22 22:28:48.023086
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    err, con = lgetfilecon_raw('/etc/passwd')
    assert err == 0
    assert con == 'unconfined_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-22 22:28:56.239508
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Running test_matchpathcon')
    # open a file in /tmp/
    with open('/tmp/foo', 'wb') as f:
        f.write(b'foo')

    path = '/tmp/foo'
    mode = os.stat(path).st_mode
    try:
        [rc, output] = matchpathcon(path, mode)
        if rc == 0:
            assert output == b'usr_t:usr_t:s0'
        else:
            print('matchpathcon error: {0}'.format(output))
    finally:
        # remove the file
        os.remove(path)



# Generated at 2022-06-22 22:28:57.266443
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return selinux_getenforcemode()



# Generated at 2022-06-22 22:28:59.491961
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0


# Generated at 2022-06-22 22:29:07.769461
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.exists("/test"):
        os.mkdir("/test")

    if not os.path.exists("/test/foo"):
        os.mkdir("/test/foo")

    if not os.path.exists("/test/foo/bar.txt"):
        open("/test/foo/bar.txt", "a").close()

    assert matchpathcon("/etc/passwd", 0) == [0, "system_u:object_r:etc_runtime_t:s0"]
    assert matchpathcon("/test/foo/bar.txt", 0) == [0, "system_u:object_r:file_t:s0"]
    assert matchpathcon("/test", 0) == [0, "system_u:object_r:file_t:s0"]

# Generated at 2022-06-22 22:29:12.252474
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    os.environ['SELINUX_SRC_PATH'] = '../selinux/'

    rv, con = matchpathcon('/var/log/messages', os.O_WRONLY)
    assert rv == 0
    assert con == 'system_u:object_r:var_log_t:s0'

# Generated at 2022-06-22 22:29:23.475031
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.isdir("/var/run"):
        print("/var/run does not exist, aborting test_matchpathcon")
        return

    if not os.path.isdir("/usr/libexec"):
        print("/usr/libexec does not exist, aborting test_matchpathcon")
        return

    # Should match the label of /var/run
    ret = matchpathcon("/var/run", 0)
    assert ret[0] == 0
    assert ret[1] == "system_u:object_r:var_run_t:s0"

    # Should match the label of /var/run
    ret = matchpathcon("/var/run/", 0)
    assert ret[0] == 0

# Generated at 2022-06-22 22:29:26.227071
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert isinstance(result, list)
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)


# Generated at 2022-06-22 22:29:34.837594
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/a/b/c', 0)
    print('matchpathcon(/a/b/c,0) -> [{0}]: {1}'.format(rc, con))
    rc, con = matchpathcon('/a/b/c', os.O_RDONLY)
    print('matchpathcon(/a/b/c,{0:#x}) -> [{1}]: {2}'.format(os.O_RDONLY, rc, con))


# Generated at 2022-06-22 22:29:38.718105
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1] == "targeted"

# Generated at 2022-06-22 22:29:47.813581
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils import basic
    import ansible.module_utils._text as text
    from ansible.module_utils.common.text.converters import to_text
    # Get selinux_getenforcemode
    enforcemode = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    enforcemode.exit_json(changed=False, ansible_facts=dict(selinux_enforcemode=selinux_getenforcemode()))

    # Unit test for function selinux_getpolicytype
    selinux = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

# Generated at 2022-06-22 22:29:50.676284
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw wrapper function"""

    # run function
    returned = lgetfilecon_raw("/dev")
    print("output = ", returned)

    # Test values
    assert returned[0] == 0, "Error getting context"
    assert "system_u:object_r" in str(returned[1])



# Generated at 2022-06-22 22:29:52.603956
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-22 22:29:54.318544
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test ignoring args
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-22 22:29:58.133864
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result[0] == 0  # rc
    assert result[1] in ['targeted', 'minimum', 'mls', 'strict']  # selinux policy type

# Generated at 2022-06-22 22:30:01.612257
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
    except OSError as exc:
        print(exc)
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:30:06.470236
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/foo/bar'
    mode = os.R_OK
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con.startswith('system_u:object_r:')


# Generated at 2022-06-22 22:30:10.817379
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0, "lgetfilecon_raw error should return 0, got {0}".format(rc)
    assert con == 'unconfined_u:object_r:etc_t:s0', "lgetfilecon_raw got invalid result {0}".format(con)


# Generated at 2022-06-22 22:30:20.325436
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:30:22.971912
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/passwd')
    assert(result[0] == 0)
    assert(result[1] == 'system_u:object_r:etc_runtime_t:s0')


# Generated at 2022-06-22 22:30:33.040367
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_test_results = [
        [0, "system_u:object_r:usr_t:s0"],
        [0, "system_u:object_r:usr_t:s0"],
        [0, "system_u:object_r:usr_t:s0"],
        [0, "system_u:object_r:usr_t:s0"],
    ]

    test_paths = [
        "/usr/bin/ls",
        "/usr/share/locale/en_US.UTF-8/LC_MESSAGES/coreutils.mo",
        "/etc/pam.d/system-login",
        "/etc/shadow",
    ]


# Generated at 2022-06-22 22:30:36.590187
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"/usr/bin/ls")

    assert rc == 0, "Failed to get conext of /usr/bin/ls"
    assert con == b"system_u:object_r:bin_t:s0", "Failed to get the right context"


# Generated at 2022-06-22 22:30:45.423588
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    We are guessing here and returning a dictionary.  The return code
    is 0 on success and the test should be implemented in the unit tests.
    '''
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    if rc == 0:
        return dict(
            changed=True,
            rc=rc,
            enforcemode=enforcemode.value,
        )
    else:
        return dict(
            failed=True,
            rc=rc,
            errmsg='selinux_getenforcemode failed'
        )



# Generated at 2022-06-22 22:30:52.900319
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/bin/passwd', 0)
    print(rc, con)
    assert rc == 0
    assert con == 'system_u:object_r:bin_t:s0'

    try:
        rc, con = matchpathcon('/bin/passwd', 0)
    except FileNotFoundError:
        pass
    else:
        raise Exception('Expected FileNotFoundError')


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:58.695845
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    This is a simple unit test for the lgetfilecon_raw
    function. You can run it by executing:
    python -c 'from ansible.module_utils.selinux import lgetfilecon_raw; print(lgetfilecon_raw("/etc/passwd")[1])'
    """
    pass

# Generated at 2022-06-22 22:31:02.203860
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        (rc, enforcemode) = selinux_getenforcemode()
        assert rc == 0 and enforcemode in [0, 1]
    except OSError:
        assert False



# Generated at 2022-06-22 22:31:06.931157
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Read type from policy
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'

    # Read type from policy with invalid path
    rc, policytype = selinux_getpolicytype('/invalid/path')
    assert rc != 0

# Generated at 2022-06-22 22:31:10.459274
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    print('selinux_getenforcemode: %d %d' % (rc, mode))



# Generated at 2022-06-22 22:31:16.446025
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test for selinux_getenforcemode
    """
    print("test_selinux_getenforcemode: ")
    [rc, value] = selinux_getenforcemode()
    if rc == 0:
        print("test_selinux_getenforcemode " + value)
    else:
        print("test_selinux_getenforcemode Unexpected return value:" + rc)



# Generated at 2022-06-22 22:31:19.323168
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/localtime'
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:usr_t:s0']


# Generated at 2022-06-22 22:31:21.021673
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/log/ansible-test'
    return lgetfilecon_raw(path)


# Generated at 2022-06-22 22:31:25.004369
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0


# Generated at 2022-06-22 22:31:27.836278
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    test_mode = os.stat('/etc/hosts').st_mode
    test_con = matchpathcon('/etc/hosts', test_mode)
    print('{0}\n{1}\n\n'.format(test_con[0], test_con[1]))


# Generated at 2022-06-22 22:31:31.830796
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, policy_type] = selinux_getpolicytype()
        to_native(policy_type)
    except OSError as exc:
        print(exc)
    except Exception as exc:
        print(exc)



# Generated at 2022-06-22 22:31:40.719483
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_rc = 0
    expected_ret = 'targeted'
    rc, ret = selinux_getpolicytype()
    assert rc == expected_rc, \
        'Expecting rc: {0}, saw: {1} when executing selinux_getpolicytype'.format(expected_rc, rc)

    assert ret == expected_ret, \
        'Expecting ret: {0}, saw: {1} when executing selinux_getpolicytype'.format(expected_ret, ret)



# Generated at 2022-06-22 22:31:42.610486
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = 1
    context = ''
    assert lgetfilecon_raw("/tmp/test") == [rc, context]

# Generated at 2022-06-22 22:31:49.816214
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    path = '/tmp'
    mode = os.R_OK
    try:
        with tempfile.TemporaryDirectory() as tmpf:
            path = tmpf
            __salt__ = {'cmd.run': lambda *a, **kw: ('test_matchpathcon', '0')}
            [rc, res] = matchpathcon(path, mode)
            assert rc == 0
            assert res is not None
    finally:
        __salt__ = None

# Generated at 2022-06-22 22:31:56.739910
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # make sure we are not in a container
        if os.environ.get("container") is not None:
            return "Skipped: container"
    except KeyError:
        pass

    rc, con = lgetfilecon_raw("/etc/passwd")

    # if lgetfilecon fails, it can indicate that selinux is not running
    if rc < 0:
        if rc == -1:
            return "Skipped: file not found"
        else:
            return "Skipped: lgetfilecon returned " + str(rc)

    # if lgetfilecon returns a value of None, it can indicate that the
    #   user has disabled selinux
    if con is None:
        return "Skipped: selinux not enabled"


# Generated at 2022-06-22 22:31:59.613174
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fpath = '/etc/shadow'
    if os.access(fpath, os.R_OK):
        lgetfilecon_raw(fpath)



# Generated at 2022-06-22 22:32:04.312955
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    errno, val = selinux_getenforcemode()
    if errno == -1:
        raise Exception("Error in function selinux_getenforcemode. errno: " + str(errno) + " Error Description: " + os.strerror(errno))
    else:
        print("selinux_getenforcemode(): " + str(val))


# Generated at 2022-06-22 22:32:08.310067
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon(b"/usr/lib/foo.so", 0)
    assert result[0] == 0, "matchpathcon returned failure: %s" % result[1]

# Generated at 2022-06-22 22:32:16.320336
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return
    from ansible.module_utils.basic import AnsibleModule
    import ansible_collections.ansible.community.plugins.module_utils.argspec.selinux

    def run_module(path=None):
        module_args = {'path': path}
        module_args.update(ansible_collections.ansible.community.plugins.module_utils.argspec.selinux.__dict__)
        module = AnsibleModule(argument_spec=module_args)
        module.run_command_environ_update = {}
        rc, con = lgetfilecon_raw(path)
        module.exit_json(rc=rc, con=con)

    run_module("/")


# Generated at 2022-06-22 22:32:25.861769
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: add unittest for other wrapper functions
    import os
    import re
    import os.path
    import subprocess

    def get_selinuxcontext(path):
        rc, ctx = matchpathcon(path, os.stat(path).st_mode)
        if rc < 0:
            errno = get_errno()
            raise OSError(errno, os.strerror(errno))
        if ctx and re.match(r"^[^:]+:[^:]+:[^:]+:[^:]+:[^:]+:[^:]+", ctx):
            return ctx
        else:
            return None

    def check_dir(dir):
        assert get_selinuxcontext(dir) is not None
        for f in os.listdir(dir):
            f = os

# Generated at 2022-06-22 22:32:27.088361
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 0] == selinux_getenforcemode()



# Generated at 2022-06-22 22:32:34.692641
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/sbin/init'
    expect_rc = 0
    expect_con = b'system_u:system_r:init_t:s0'
    rc, con = lgetfilecon_raw(path)
    if rc == expect_rc and con == expect_con:
        print("test_lgetfilecon_raw PASSED")
    else:
        print("test_lgetfilecon_raw FAILED")
