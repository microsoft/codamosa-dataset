

# Generated at 2022-06-22 22:22:37.628685
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    if rc == -1:
        (errno, msg) = (os.strerror(get_errno()))
        print ("%s" % (msg))
    else:
        print ("Enforce mode is %s" % (mode))


# Generated at 2022-06-22 22:22:42.223124
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test selinux_getenforcemode
    '''
    #
    # On target system, /etc/selinux/config must define SELINUX=enforcing
    # Run tests with 'python -m selinux'
    #
    print(selinux_getenforcemode())



# Generated at 2022-06-22 22:22:47.746567
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # The following test code is commented out because /etc/passwd is not owned by root in the test environment
    #assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    #assert lgetfilecon_raw('/nonexistent') == [-1, None]
    pass


# Generated at 2022-06-22 22:22:51.165778
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert type(result[0]) == int, 'result[0] is not an int'
    assert type(result[1]) == int, 'result[1] is not an int'



# Generated at 2022-06-22 22:22:54.503897
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(__file__)

    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))

# Generated at 2022-06-22 22:23:01.017867
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, context) = selinux_getpolicytype()
    print('SELinux Policy Type: {}'.format(context), file=sys.stderr)

    (rc, mode) = selinux_getenforcemode()
    (rc, enforced) = security_getenforce()
    print('SELinux Enforce Mode: {} (enforced={})'.format(mode, enforced), file=sys.stderr)

    # Test matchpathcon
    (rc, context) = matchpathcon('/etc/localtime', 0)
    print('Context of /etc/localtime: {}'.format(context), file=sys.stderr)

    (rc, context) = matchpathcon('/etc/localtime', os.R_OK)

# Generated at 2022-06-22 22:23:12.223375
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Expected values are from CentOS 7 with targeted selinux policy
    """
    assert lgetfilecon_raw("/") == [0, "system_u:object_r:root_t:s0"]
    assert lgetfilecon_raw("/etc") == [0, "system_u:object_r:etc_t:s0"]
    assert lgetfilecon_raw("/etc/shadow") == [0, "system_u:object_r:shadow_t:s0"]
    assert lgetfilecon_raw("/etc/shadow_as_file") == [0, "system_u:object_r:etc_t:s0"]
    assert lgetfilecon_raw("/etc/shadow/") == [0, "system_u:object_r:etc_t:s0"]
    assert lget

# Generated at 2022-06-22 22:23:14.946099
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # This test is Linux only
    if sys.platform != "linux":
        return

    rc, policy_type = selinux_getpolicytype()
    assert rc == 0 and policy_type == b'targeted', \
        'selinux_getpolicytype failed with rc=%d and policy_type=%s' % (rc, policy_type)

# Generated at 2022-06-22 22:23:16.724163
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, u'strict']

# Generated at 2022-06-22 22:23:25.153816
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    TEMPFILE = tempfile.mktemp()
    if os.path.isfile(TEMPFILE):
        rc, con = lgetfilecon_raw(TEMPFILE)
        if rc != -1:
            os.unlink(TEMPFILE)

    with open(TEMPFILE, "w") as f:
        f.close()
    rc, con = lgetfilecon_raw(TEMPFILE)

    assert(rc == 0)
    os.unlink(TEMPFILE)

# Generated at 2022-06-22 22:23:32.012877
# Unit test for function matchpathcon
def test_matchpathcon():
    sample_path = '/etc/passwd'
    sample_mode = 0
    sample_ret = 0
    sample_context = 'system_u:object_r:passwd_file_t:s0-s0:c0.c1023'
    assert matchpathcon(sample_path, sample_mode) == [sample_ret, sample_context]



# Generated at 2022-06-22 22:23:41.150292
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/bin/bash'
    expected_output = 'unconfined_u:object_r:bin_t:s0'
    actual_output = lgetfilecon_raw(test_path)
    expected_rc = 0
    if not actual_output[0] == expected_rc:
        raise AssertionError('test_lgetfilecon_raw failed for path {0}, rc {1} does not equal expected rc {2}'.format(test_path, actual_output[0], expected_rc))
    if not actual_output[1] == expected_output:
        raise AssertionError('test_lgetfilecon_raw failed for path {0}, output {1} does not equal expected output {2}'.format(test_path, actual_output[1], expected_output))


# Generated at 2022-06-22 22:23:48.181359
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.exists('/sys/fs/selinux'):
        raise OSError("selinux not enabled on this system")

    directory = '/usr/share/doc'
    expected_results = {'process_label': 'system_u:object_r:usr_t', 'result': '0'}
    obtained_results = matchpathcon(directory, 0)
    assert expected_results == obtained_results

# Generated at 2022-06-22 22:23:51.574386
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:24:00.560410
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Unit test for selinux_getenforcemode.

    This test is only run when the environment variable SELINUX_ENFORCE_MODE
    is set to a valid value (0, 1 or 2).  The return value of the function
    selinux_getenforcemode is compared to the value of the environment
    variable.

    """
    enforcemode = os.environ.get('SELINUX_ENFORCE_MODE')
    if enforcemode:
        enforcemode = int(enforcemode)
        rc, value = selinux_getenforcemode()
        assert rc == 0
        assert value == enforcemode

# Generated at 2022-06-22 22:24:06.320055
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_string = "/tmp/test_file"
    test_mode = 0
    try:
        open(test_file, 'a').close()
        rc, out_con = selinux.lgetfilecon_raw(test_file)
        assert rc == 0
        assert out_con == 'system_u:object_r:tmp_t:s0'
    finally:
        os.remove(test_file)


# Generated at 2022-06-22 22:24:08.801061
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.geteuid() != 0:
        raise AssertionError('skipping test due to insufficient privileges')

    return matchpathcon('/var/www/html', os.R_OK)



# Generated at 2022-06-22 22:24:11.411332
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    assert res[0] == 0
    assert res[1] in [0, 1, 2]



# Generated at 2022-06-22 22:24:15.034503
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', os.R_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-22 22:24:19.478392
# Unit test for function matchpathcon
def test_matchpathcon():
    """function matchpathcon tests"""
    unsafe = '/tmp/testfile'
    safe, error = matchpathcon(unsafe, 0)
    assert safe == -13, safe
    assert 'Invalid argument' in error



# Generated at 2022-06-22 22:24:21.566409
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert ret[0] == 0


# Generated at 2022-06-22 22:24:23.864237
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, context = lgetfilecon_raw(path)
    print(rc, context)


# Generated at 2022-06-22 22:24:26.535283
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert type(selinux_getpolicytype()) == type([])
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:24:28.609440
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert (rc, policytype) == (0, b'targeted')


# Generated at 2022-06-22 22:24:34.572931
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    # Parameters:
    path = "/etc/passwd"
    mode = 0

    # Call matchpathcon
    rc, con = matchpathcon(path, mode)

    # Check the returned values
    if rc == 0 and con == "system_u:object_r:passwd_file_t:s0":
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:24:38.987317
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("passwd")
    assert rc == 0
    print(con)
    assert con == "system_u:object_r:shadow_t:s0"



# Generated at 2022-06-22 22:24:42.061868
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/etc/shadow', 0))
    print(matchpathcon('/etc/selinux', 1))
    print(matchpathcon('/etc/shadow', 2))


# Generated at 2022-06-22 22:24:45.561994
# Unit test for function matchpathcon
def test_matchpathcon():
    _argv = sys.argv[1:]
    if not _argv:
        sys.exit(0)
    path, mode = _argv
    mode = int(mode)
    rc, con = matchpathcon(path, mode)
    sys.stdout.write(con)
    sys.exit(rc)

# Generated at 2022-06-22 22:24:48.557563
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-22 22:24:57.242900
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test working with con = None
    assert matchpathcon(b'/selinux/null', 0) == [0, None]

    # Test working with con != None
    assert matchpathcon(b'/etc/shadow', 0) == [0, b'db_file_t:object_r:shadow_etc_t:s0']

    # Test working with con != None
    assert matchpathcon(b'/etc/shadow', 8) == [0, b'db_file_t:object_r:shadow_etc_t:s0']

    # Test not working with con != None
    assert matchpathcon(b'/etc/shadow', 198) == [1, b'db_file_t:object_r:shadow_etc_t:s0']

    # Test not working with con != None

# Generated at 2022-06-22 22:25:01.916901
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Assert normal return
    assert selinux_getenforcemode() == [0, 1]

    # Assert error return
    assert selinux_getenforcemode() == [1, 0]

# Generated at 2022-06-22 22:25:03.830486
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()
    assert policy_type[1] == "targeted"

# Generated at 2022-06-22 22:25:11.479380
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _check_rc(_selinux_lib.is_selinux_enabled())
    if not is_selinux_enabled:
        raise AssertionError("selinux_getpolicytype failed")
    _check_rc(_selinux_lib.selinux_getpolicytype(byref(con)))
    if not rc == 0:
        raise AssertionError("selinux_getpolicytype failed")
    return [rc, to_native(con.value)]



# Generated at 2022-06-22 22:25:17.654937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # lgetfilecon_raw function returns a list that contains:
    #   0 - the return code or a negative errno value
    #   1 - the label string or None if the return code is a negative errno value
    rc, label = lgetfilecon_raw(b'/etc/passwd')
    assert rc == 0
    assert label.startswith(b'unconfined_u:object_r:user_home_t')


# Generated at 2022-06-22 22:25:18.992132
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/data/file.txt', os.R_OK))

# Generated at 2022-06-22 22:25:23.199480
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # is a simple function, so can test here
    # returns [rc, enforcemode]
    # rc is 0 if it succeeded, -1 on error
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)
    assert enforcemode in range(0, 3)


# Generated at 2022-06-22 22:25:28.202980
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    def _lgetfilecon_raw_test():
        path = "/usr/bin/getenforce"
        context = "system_u:object_r:unlabeled_t"
        rc, out = lgetfilecon_raw(path)
        assert rc == 0
        assert out == context

    if is_selinux_enabled():
        _lgetfilecon_raw_test()
        return True
    else:
        return False



# Generated at 2022-06-22 22:25:31.396037
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test for function matchpathcon"""
    testfile = '/usr/bin/passwd'
    testmode = 0
    testdir = '/usr/bin/'
    assert matchpathcon(testfile, testmode)
    assert matchpathcon(testdir, testmode)

# Generated at 2022-06-22 22:25:37.280902
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    returncode, policytype = selinux_getpolicytype()

    if returncode == 0:
        b_policytype = to_bytes(policytype)
        print('SELinux policy type: %s' % b_policytype)
    else:
        print('Unable to get policy type')



# Generated at 2022-06-22 22:25:41.042927
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Call function selinux_getpolicytype to get the policy type
    """
    rc, policy_type = selinux_getpolicytype()
    if rc == 0:
        assert type(policy_type) == str
    else:
        assert type(policy_type) == int

# Generated at 2022-06-22 22:25:45.256901
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    rc, context = lgetfilecon_raw('/etc/hosts')
    assert rc >= 0
    assert len(context) > 0

    rc, context = lgetfilecon_raw(os.devnull)
    assert rc > 0
    assert context is None

# Generated at 2022-06-22 22:25:50.430126
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:25:58.342341
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test that selinux_getenforcemode returns a non-error code,
    and a value greater than or equal to zero
    """

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, "Error calling selinux_getenforcemode"
    assert enforcemode >= 0, "Returned enforcemode is not greater than or equal to zero"



# Generated at 2022-06-22 22:26:00.649885
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, _ = matchpathcon(b'/home/user/test', 0)
    assert rc == 0


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:26:02.463371
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/selinux/config')[0] == 0



# Generated at 2022-06-22 22:26:05.354012
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()[1]



# Generated at 2022-06-22 22:26:13.477341
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.ansible.selinux.tests.unit.compat.mock import MagicMock, patch
    from ansible.module_utils.basic import AnsibleModule

    _selinux_lib.selinux_getenforcemode = MagicMock(return_value=0)
    mod = AnsibleModule(argument_spec={
        "path": {"required": True, "type": "str"},
    })
    assert mod.selinux_getenforcemode() == 0



# Generated at 2022-06-22 22:26:15.109669
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0

# Generated at 2022-06-22 22:26:17.225131
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in (0, 1, 2)



# Generated at 2022-06-22 22:26:18.604155
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:26:20.630723
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0
    assert enforcemode in [0, 1, 2]


# Generated at 2022-06-22 22:26:26.781922
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    if rc != 0:
        raise OSError('path not found: /etc/passwd : rc = {0}'.format(rc))
    print('matchpathcon(/etc/passwd) =', con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:26:29.998073
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/bar'
    result = matchpathcon(path, 0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_t:s0'


# Generated at 2022-06-22 22:26:35.206800
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/var') == [0, 'system_u:object_r:var_t:s0']

# Generated at 2022-06-22 22:26:38.613753
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    print(rc, enforcemode.value)
    return [rc, enforcemode.value]



# Generated at 2022-06-22 22:26:43.478239
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Context is disabled as we have no way of setting the mode
    assert selinux_getenforcemode()[0] == 0
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:26:52.955080
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ctypes
    test_path = '/tmp/test_selinux'
    test_context = 'system_u:object_r:user_tmp_t:s0'
    test_con = ctypes.create_string_buffer(test_context.encode('utf-8'), len(test_context))

    fp = open(test_path, 'w+')
    fp.close()
    ck_rc = lsetfilecon(test_path, test_con)
    ck_con = lgetfilecon_raw(test_path)
    rc = os.unlink(test_path)
    return ck_rc, ck_con

# Generated at 2022-06-22 22:26:58.741901
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        returncode, file_context = lgetfilecon_raw('/etc/passwd')
    except Exception as e:
        print(e)
        returncode = -1
    if returncode == -1:
        print('An error was returned running lgetfilecon_raw')



# Generated at 2022-06-22 22:27:01.397297
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    val, policy_type = selinux_getpolicytype()
    assert not val
    assert policy_type == 'targeted'



# Generated at 2022-06-22 22:27:03.486697
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

# Generated at 2022-06-22 22:27:14.235539
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-22 22:27:16.730563
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, current_mode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(current_mode, int)


# Generated at 2022-06-22 22:27:20.745656
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print(rc, con)



# Generated at 2022-06-22 22:27:22.246851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert con is not None
    assert con.startswith('system_u:object_r:etc_t:s0')


# Generated at 2022-06-22 22:27:26.577599
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert len(selinux_getenforcemode()) == 2
    assert type(selinux_getenforcemode()[0]) == int
    assert selinux_getenforcemode()[0] < 0 or type(selinux_getenforcemode()[1]) == int



# Generated at 2022-06-22 22:27:29.101874
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert (0 <= enforcemode <= 2)



# Generated at 2022-06-22 22:27:33.353034
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0, 'Error occured when calling selinux_getenforcemode()'
    assert isinstance(enforcemode, int) is True, 'enforcemode is an integer'


# Generated at 2022-06-22 22:27:36.641841
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Note: likely to fail if system enforcement is in 'permissive' mode
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1
    assert isinstance(enforcemode, int)



# Generated at 2022-06-22 22:27:43.292466
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test case to check if selinux_getenforcemode takes no argument and
    returns a list of two elements: [return-code, enforcemode]
    """
    def import_all():
        """
        Test case to check if all selinux functions are available
        """
        import ctypes
        import os
        selinux_lib = ctypes.CDLL('libselinux.so.1', use_errno=True)

# Generated at 2022-06-22 22:27:47.251914
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Not testing for return code.
    con = c_char_p()
    rc = _selinux_lib.selinux_getpolicytype(byref(con))
    print(rc)
    print(to_native(con.value))

# Generated at 2022-06-22 22:27:53.920088
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import selinux
    except ImportError as e:
        pass

    # Set this to false if you want to skip this test
    run_test_getpolicytype = True

    if run_test_getpolicytype:
        if not to_native(selinux_getpolicytype()[1]) == to_native(selinux.security_getenforce()[0]):
            print("function selinux_getpolicytype does not return the same result as expected")
            print("selinux.security_getenforce() returned: " + to_native(selinux.security_getenforce()[0]))
            print("selinux_getpolicytype() returned: " + to_native(selinux_getpolicytype()[1]))
            sys.exit(1)

# Generated at 2022-06-22 22:27:56.492284
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype is not None



# Generated at 2022-06-22 22:27:58.197632
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw('/proc'))



# Generated at 2022-06-22 22:28:10.214835
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    unit tests for matchpathcon function
    '''
    import json
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    class TestMatchpathconFunc(unittest.TestCase):
        @unittest.skipIf(os.path.exists('/usr/libexec/selinux/hll/system_u:object_r:needs_hll_semanage:s0'),
                         '/usr/libexec/selinux/hll/system_u:object_r:needs_hll_semanage:s0 exists so selinux is enabled')
        def test_selinux_disabled(self):
            '''
            selinux is disabled for this test
            '''

# Generated at 2022-06-22 22:28:13.865561
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("selinux_getenforcemode() = {0} {1}".format(rc, enforcemode))


# Generated at 2022-06-22 22:28:21.472827
# Unit test for function matchpathcon
def test_matchpathcon():
    with open("json_file", "w") as f:
        con = lgetfilecon_raw("json_file")[1]
        f.close()
        os.remove("json_file")
        rc = matchpathcon("json_file", os.R_OK)[1]
        if rc == con:
            print("matchpathcon test passed")
        else:
            print("matchpathcon test failed")

# Generated at 2022-06-22 22:28:23.319139
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    return [rc, con]

# Generated at 2022-06-22 22:28:28.850461
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/null'
    enforcemode, con = lgetfilecon_raw(path)
    assert enforcemode != -1
    assert con is not None
    assert con[:3] == 'u:o'
    assert len(con) >= 3
    enforcemode, con = lgetfilecon_raw(path)
    assert enforcemode != -1
    assert con is not None
    assert con[:3] == 'u:o'
    assert len(con) >= 3



# Generated at 2022-06-22 22:28:40.432925
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file path
    file_path = '/var/log/messages'
    # This should be a file path
    assert os.path.exists(file_path)

    # Fetch the context of the file
    [rc, context] = lgetfilecon_raw(file_path)

    # Should not be an error
    assert rc == 0

    # Context string should not be null
    assert context is not None

    # Test with a directory path
    dir_path = '/var/log/'
    # Of course this is a directory
    assert os.path.isdir(dir_path)

    # Fetch the context of the directory
    [rc, context] = lgetfilecon_raw(dir_path)

    # Should not be an error
    assert rc == 0

    # Context string should not be null


# Generated at 2022-06-22 22:28:46.825324
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, out = selinux_getpolicytype()
    if rc != 0:
        raise AssertionError("selinux_getpolicytype() expected to return rc=0 but rc={0}".format(rc))
    if out not in ['targeted', 'mls']:
        raise AssertionError("selinux_getpolicytype() expected to return result=targeted or mls but got {0}".format(out))

# Generated at 2022-06-22 22:28:49.089247
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/etc/ssh/sshd_config', 0)
    print('Test matchpathcon: rc={0}, con={1}'.format(rc, con))


# Generated at 2022-06-22 22:28:52.394530
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import selinux
    [rc, enforcemode] = selinux.selinux_getenforcemode()
    assert type(rc) == int
    assert type(enforcemode) == int

# Generated at 2022-06-22 22:28:58.106565
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    (rc, con) = matchpathcon(path, 0)
    if rc != 0:
        print("rlgetfilecon-raw(%s) failed with rc = %d." % (path, rc))
        return

    print("con on %s is %s." % (path, con))

    return

# Generated at 2022-06-22 22:29:02.088606
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Test the selinux_getpolicytype function"""
    rc, policytype = selinux_getpolicytype()
    return policytype


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:29:05.515961
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Check the SELinux context of the current process."""
    (rc, con) = lgetfilecon_raw("/proc/self/exe")
    if rc >= 0:
        print("SELinux context of this process is", con)
        return True
    else:
        return False



# Generated at 2022-06-22 22:29:17.303962
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/bin/ls')
    assert rc == 0, rc
    assert con == 'system_u:object_r:bin_t:s0', con
    rc, con = lgetfilecon_raw('/usr/lib/libselinux.so.1')
    assert rc == 0, rc
    assert con == 'system_u:object_r:lib_t:s0', con
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0, rc
    assert con == 'system_u:object_r:etc_runtime_t:s0', con
    rc, con = lgetfilecon_raw('/selinux/contexts/files/file_contexts.homedirs.local')

# Generated at 2022-06-22 22:29:23.825066
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    rc, con = selinux_getpolicytype()
    if rc == 0:
        module.exit_json(msg="selinux_getpolicytype(): policy={0}".format(con))
    else:
        module.fail_json(msg="selinux_getpolicytype(): error={0}".format(con))

from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 22:29:25.500697
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert isinstance(res[1], str)


# Generated at 2022-06-22 22:29:34.721670
# Unit test for function matchpathcon
def test_matchpathcon():
    # Would match matchpathcon with success
    result = matchpathcon('/', 0)
    assert(result[0] == 0)
    # Would match matchpathcon with fail
    result = matchpathcon(None, 0)
    assert(result[0] == -1)
    # Would match matchpathcon with fail
    result = matchpathcon('/', -1)
    assert(result[0] == -1)
    # Would match matchpathcon with fail
    result = matchpathcon('/', -1)
    assert(result[0] == -1)


# Generated at 2022-06-22 22:29:38.718220
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con_val = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con_val == 'system_u:object_r:file_t:s0'


# Generated at 2022-06-22 22:29:41.652358
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/foo', 0)[0] == 0
    assert matchpathcon('/foo', 0)[0] != 0
    assert matchpathcon('/foo/bar', 0)[1] == 'unlabeled_t'
    assert matchpathcon('/dev/null', 0)[1] == 'null_device_t'



# Generated at 2022-06-22 22:29:45.711299
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    assert _selinux_lib.selinux_getenforcemode(byref(enforcemode)) >= 0
    assert enforcemode.value in [0, 1, 2]



# Generated at 2022-06-22 22:29:48.353972
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    msg = "Incorrect selinux_getenforcemode return value"
    rc, value = selinux_getenforcemode()
    assert rc == 0, msg



# Generated at 2022-06-22 22:29:50.675532
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw("/tmp/selinux.tmptest")
    assert res[0] == 0
    # res[1] contains first part of selinux context
    assert res[1].split(':')[0] == 'system_u'


# Generated at 2022-06-22 22:29:54.144686
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert isinstance(result[0], int) and result[0] in [0, -1]
    assert isinstance(result[1], str)

# Generated at 2022-06-22 22:30:00.085582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    This is a unit test to check whether selinux library is working correctly.
    Normally this test should not be run, but if needed,
    please comment out the code below.
    '''
    # import selinux
    # cmd = selinux.lgetfilecon_raw('/etc/passwd')
    # print(cmd)
    pass

# Generated at 2022-06-22 22:30:03.438896
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, context = lgetfilecon_raw('/selinux/enforce')
    assert rc == 0
    assert context == 'system_u:object_r:selinuxfs:s0'



# Generated at 2022-06-22 22:30:08.316874
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
        assert rc == 0
        assert type(con) == str
    except (OSError, NotImplementedError):
        pass
    except (TypeError, ValueError):
        pass



# Generated at 2022-06-22 22:30:14.852510
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    if rc < 0:
        raise OSError(rc, os.strerror(rc))

    if enforcemode < 0 or enforcemode > 2:
        raise OSError('invalid enforcemode: {0}'.format(enforcemode))

    return enforcemode



# Generated at 2022-06-22 22:30:21.826480
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    from os.path import exists, join
    from os import getcwd
    current_dir = getcwd()
    filepath = join(current_dir, 'test_file')
    with open(filepath, 'w') as f:
        f.write('Testing selinux module\n')
    assert lgetfilecon_raw(filepath) == (0, 'system_u:object_r:default_t:s0')
    os.remove(filepath)
    assert lgetfilecon_raw(filepath) is None


# Generated at 2022-06-22 22:30:23.765806
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con_type = selinux_getpolicytype()
    assert con_type == 'targeted'



# Generated at 2022-06-22 22:30:31.360023
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/log/audit/audit.log"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    print("Context for {0} is {1} (rc={2})".format(path, con, rc))
    path = "/var/log/messages"
    rc, con = matchpathcon(path, mode)
    print("Context for {0} is {1} (rc={2})".format(path, con, rc))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:33.621917
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/tmp/file', 0)
    assert rc[0] == 0 and rc[1] == 'user_tmp_t'



# Generated at 2022-06-22 22:30:37.514158
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert isinstance(result, list)



# Generated at 2022-06-22 22:30:41.663597
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, type = selinux_getpolicytype()

    # Return code should be 0 on success
    assert 0 == rc

    assert 'targeted' == type or 'minimum' == type or 'mls' == type



# Generated at 2022-06-22 22:30:43.205505
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert isinstance(rc, int)
    assert isinstance(con, string_types)

# Generated at 2022-06-22 22:30:48.870420
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not is_selinux_enabled():
        print('SELinux is not enabled! Skipping test...')
        return

    rc, policy_type = selinux_getpolicytype()
    assert policy_type == 'targeted'

# Generated at 2022-06-22 22:30:55.944927
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test_lgetfilecon_raw.txt'
    mode = b'wb'
    result = b''

    try:
        f = open(path, mode)
        f.close()

        result = lgetfilecon_raw(path)
    finally:
        os.remove(path)

    if result[0] != 0:
        raise AssertionError('lgetfilecon_raw(b"{0}") did not return expected result: return code: {1}'.format(path, result[0]))


#  Unit test for function selinux_getenforcemode

# Generated at 2022-06-22 22:30:57.546599
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    print("rc={0} con={1}".format(rc, con))


# Generated at 2022-06-22 22:31:01.821952
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1
    assert type(enforcemode) is int



# Generated at 2022-06-22 22:31:05.042761
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    print("Enforcment mode: ", enforcemode)



# Generated at 2022-06-22 22:31:10.211712
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Example of calling this function with a string type parameter
    rc, con = lgetfilecon_raw("/etc/hosts")

    # Example of calling this function with a bytes type parameter
    rc, con = lgetfilecon_raw(b"/etc/hosts")



# Generated at 2022-06-22 22:31:15.750715
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    testcase selinux_getenforcemode
    """
    res = selinux_getenforcemode()
    if not res[0]:
        print("selinux_getenforcemode: %d failed" % res[0])
    else:
        print("selinux_getenforcemode: %d => %d" % (res[0], res[1]))



# Generated at 2022-06-22 22:31:19.420371
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("\nTesting function selinux_getpolicytype:")
    print("\tExpected output: 0, 'targeted'")
    print("\tActual Output: ", selinux_getpolicytype())


# Generated at 2022-06-22 22:31:24.538494
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Disabling the selinux in the system
    tmp = os.system("setenforce 0")
    assert tmp == 0
    retcode, enforce_mode = selinux_getenforcemode()
    assert enforce_mode == 0

    # Enabling the selinux in the system
    tmp = os.system("setenforce 1")
    assert tmp == 0
    retcode, enforce_mode = selinux_getenforcemode()
    assert enforce_mode == 1



# Generated at 2022-06-22 22:31:34.426396
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json
    import tempfile
    import ansible.module_utils.basic as module_utils
    import ansible.module_utils.selinux as selinux_utils

# Generated at 2022-06-22 22:31:38.942803
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if selinux_getpolicytype()[0] != -1:
        print("Policy type: %s" % selinux_getpolicytype()[1])


# Generated at 2022-06-22 22:31:44.424868
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    TEST_FILE = '/etc/shadow'
    rc, con = lgetfilecon_raw(TEST_FILE)
    assert rc == 0, "lgetfilecon_raw could not get file context for %s" % TEST_FILE
    if "object_r:" not in con:
        assert False, "%s has wrong context: %s" % (TEST_FILE, con)



# Generated at 2022-06-22 22:31:45.896654
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:31:54.803784
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.selinux import matchpathcon
    from ansible.module_utils.selinux import lgetfilecon_raw
    import os
    import tempfile

    def create_file(name, selinux_context):
        path = to_bytes(os.path.join(tempdir, name))
        os.system('touch %s' % path)
        os.system('chcon %s %s' % (selinux_context, path))
        return path


# Generated at 2022-06-22 22:31:58.455791
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc')[1] == b'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:32:02.034060
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("In test_selinux_getpolicytype")
    rc, con = selinux_getpolicytype()
    print("rc: " + str(rc))
    print("con: " + str(con))
    return rc, con


# Generated at 2022-06-22 22:32:12.683045
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:32:15.784844
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype failed, rc=%d" % rc
    assert policytype, "Policy type is empty"
    print(policytype)

# Generated at 2022-06-22 22:32:18.275357
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode = selinux_getenforcemode()
    assert mode[0] == 0
    assert mode[1] > 0



# Generated at 2022-06-22 22:32:24.895708
# Unit test for function matchpathcon
def test_matchpathcon():
    enforcemode = selinux_getenforcemode()
    policytype = selinux_getpolicytype()
    rc, con_type = lgetfilecon_raw('/etc/shadow')
    rc, con_path = matchpathcon('/etc/shadow', os.R_OK)
    if enforcemode[1] == 1 and policytype[1] == 'targeted' and con_type == con_path:
        print("matchpathcon for /etc/shadow returned expected context")
    else:
        raise Exception("matchpathcon did not return expected context")


test_matchpathcon()

# Generated at 2022-06-22 22:32:27.020976
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)


# Generated at 2022-06-22 22:32:33.218129
# Unit test for function matchpathcon
def test_matchpathcon():
    # Normally, use the python path to a test directory. The above method
    # will not return correct context as the SELinux context has not been set
    # since it this is a test directory.
    testpath = __file__
    testpath = testpath.split("/")
    testpath = "/".join(testpath[:-2]) + "/test/common"
    print("The path will be: {0}".format(testpath))
    context = matchpathcon(testpath, 0)
    print("Returned value: {0}".format(context))
    print("SELinux context: {0}".format(context[1]))
    assert context[0] == 0
    assert context[1] == "unconfined_u:object_r:user_home_dir_t:s0"


# If you