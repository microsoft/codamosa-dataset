

# Generated at 2022-06-22 22:22:35.664538
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        enforcemode = c_int()
        _selinux_lib.selinux_getenforcemode(byref(enforcemode))
        assert enforcemode.value == 1
    except AttributeError:
        pass



# Generated at 2022-06-22 22:22:37.967593
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Assert that security context is not None
    assert lgetfilecon_raw("/")[1] is not None

# Generated at 2022-06-22 22:22:43.881043
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        # This should succeed
        rc, con = matchpathcon("/var/lib/libvirt/images/ubuntuqs.img", 0)
        assert rc == 0, "Matchpathcon failed. Return code is: {}".format(rc)
        assert con is not None and len(con) > 1, "Con returned is empty or null"
    except Exception as e:
        raise Exception("Test Failed: {}".format(e)) from e

# Generated at 2022-06-22 22:22:46.674644
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype in {'targeted', 'strict'}

# Generated at 2022-06-22 22:22:57.480626
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import json
    import unittest

    class TestLGetFileConRaw(unittest.TestCase):
        def test_getfilecon_raw_with_valid_path(self):
            path = '/'
            expected_result = [0, 'system_u:object_r:rootfs:s0']
            self.assertEqual(lgetfilecon_raw(path), expected_result)

        def test_getfilecon_raw_with_invalid_path(self):
            path = '/invalid/directory'
            expected_result = [-1, 'system_u:object_r:rootfs:s0']
            self.assertEqual(lgetfilecon_raw(path), expected_result)

    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-22 22:23:05.072166
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Input value to test the function
    test_input = "/etc/shadow"
    # Expected output of the function
    expected_output = [0, 'unconfined_u:object_r:shadow_t:s0']
    # Actual output of the function
    actual_output = lgetfilecon_raw(test_input)
    # Asserting expected output and actual output
    assert expected_output == actual_output



# Generated at 2022-06-22 22:23:08.355144
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc = 0
    policy_type = ""
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert len(policy_type) > 0


# Generated at 2022-06-22 22:23:10.189853
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc = selinux_getpolicytype()
    assert rc[0] == 0
    assert rc[1] is not None

# Generated at 2022-06-22 22:23:17.970182
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/usr/bin/foo', 0) == [0, 'system_u:object_r:bin_t']
    assert matchpathcon(b'/usr/foo/bar', 0o644) == [0, 'system_u:object_r:usr_t']
    assert matchpathcon(b'/usr/foo/', 0o600) == [0, 'system_u:object_r:usr_t']
    assert matchpathcon(b'/usr/foo/bar.baz', 0o600) == [0, 'system_u:object_r:usr_t']
    assert matchpathcon(b'/usr/bin/foo', 0o600) == [0, 'system_u:object_r:bin_t']

# Generated at 2022-06-22 22:23:25.240144
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import json

    module_args = dict(
    )

    task_vars = dict(
    )

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)
    assert enforcemode == security_getenforce()

    result = dict(ansible_facts=dict(selinux=dict(enforcemode=enforcemode)))

    print(json.dumps(result, indent=4))



# Generated at 2022-06-22 22:23:37.322349
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/hosts', mode=0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"


if __name__ == '__main__':
    rc = selinux_getenforcemode()[0]
    print(rc)
    assert rc == 0

    rc, type = selinux_getpolicytype()
    assert rc == 0
    assert type == "targeted"

    rc, type = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert type == "system_u:object_r:etc_t:s0"

    rc, type = matchpathcon('/etc/hosts', mode=0)
    assert rc == 0

# Generated at 2022-06-22 22:23:39.816706
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert rc == 0
    assert policytype.startswith('selinuxfs')


# Generated at 2022-06-22 22:23:45.406820
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    if ret[0] == 0:
        print(ret[1])
        assert ret[1] in [0, 1, 2]
    else:
        raise OSError(ret[0], os.strerror(ret[0]))



# Generated at 2022-06-22 22:23:52.977504
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Unit test for function lgetfilecon_raw
    '''
    # Set up some test data
    testpath = "/etc/passwd"
    testresult = lgetfilecon_raw(testpath)
    expectedresult = [0, b"system_u:object_r:etc_runtime_t:s0"]
    # Run the test
    if testresult != expectedresult:
        # Test failed - the test result and expected result did not match
        raise AssertionError(testresult)
    # All tests passed!
    return None



# Generated at 2022-06-22 22:23:57.792561
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils import basic

    [rc, policytype] = selinux_getpolicytype()
    if rc < 0:
        policytype = "failed to get policy"
    basic.json_dict_unicode_value({'msg': 'policy type is: {0}'.format(policytype)})



# Generated at 2022-06-22 22:24:01.116407
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    if result[0] == 0:
        print('SELinux status get successfully. Enforce mode: ' + str(result[1]))


# Generated at 2022-06-22 22:24:02.603727
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) == list


# Generated at 2022-06-22 22:24:03.180836
# Unit test for function matchpathcon
def test_matchpathcon():
    pass

# Generated at 2022-06-22 22:24:11.238260
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1] != 1:
        raise Exception("SELinux not in enforcing mode")
    if selinux_getpolicytype()[1] != "targeted":
        raise Exception("SELinux policy type is not targeted")
    if lgetfilecon_raw("/etc/passwd")[1] != "unconfined_u:object_r:etc_t:s0":
        raise Exception("/etc/passwd context is not expected")
    if lgetfilecon_raw("/tmp/noexist")[1] != None:
        raise Exception("context for nonexistent file should be None")

# Generated at 2022-06-22 22:24:14.172721
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rv = matchpathcon('/etc', 1)
        print(rv)
    except Exception as e:
        print(e)



# Generated at 2022-06-22 22:24:18.380610
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[0] == -1:
        raise Exception(strerror(get_errno()))
    else:
        return result[1]


# Generated at 2022-06-22 22:24:20.885553
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()[1]
    print(policy_type)
    assert policy_type is not None



# Generated at 2022-06-22 22:24:24.235464
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[1] in (1, 2):
        assert isinstance(selinux_getenforcemode()[1], int)



# Generated at 2022-06-22 22:24:28.447011
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/proc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(con, str)
    assert con == 'system_u:object_r:proc_t:s0'


# Generated at 2022-06-22 22:24:31.926931
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp/test_matchpathcon', 0)
    assert rc >= 0, "Checking that the return code is >= 0"
    assert con == 'system_u:object_r:tmp_t:s0', "Checking that the context is correct"

# Generated at 2022-06-22 22:24:39.536492
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile, os
    _, tmp_path = tempfile.mkstemp()

    def del_tmp():
        os.unlink(tmp_path)

    try:
        print("file context of {0}: {1}".format(tmp_path, lgetfilecon_raw(tmp_path)[1]))
    finally:
        del_tmp()

# Generated at 2022-06-22 22:24:42.369513
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    data = selinux_getenforcemode()
    assert isinstance(data, list)
    assert isinstance(data[0], int)
    assert isinstance(data[1], int)


# Generated at 2022-06-22 22:24:50.557405
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # The selinux_getenforcemode function returns two values,
    # the return code and the value returned by the libselinux.so library
    # The return code is 0 when the call to selinux_getenforcemode is a success
    # The return code is not 0 when the call to selinux_getenforcemode is a failure
    # The second value returned is the value returned by libselinux.so function selinux_getenforcemode
    # The values returned by selinux_getenforcemode are:
    # 0 - permissive
    # 1 - enforcing
    # 2 - disabled
    # 3 - kern error
    assert selinux_getenforcemode()[0] == 0
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:24:54.369267
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        ret = lgetfilecon_raw(b'/')
        assert ret == [0, "system_u:object_r:root_t:s0"]
    except ImportError as e:
        raise SkipTest(e)

# Generated at 2022-06-22 22:24:58.604341
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        print("Error getting selinux enforcemode: %s" % os.strerror(rc))
        sys.exit(1)

    print("SELinux is %s" % ("enforcing", "permissive", "disabled")[enforcemode])


# Generated at 2022-06-22 22:25:08.794271
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check to see if a file exists
    rc, result = lgetfilecon_raw('/etc/hosts')

    # Check for valid return code
    if 0 != rc:
        print('Failed to get selinux label for /etc/hosts')
        sys.exit(1)

    # Check for valid result
    if '' == result:
        print('Invalid selinux label for /etc/hosts')
        sys.exit(2)

    # Validate a particular file
    rc, result = lgetfilecon_raw('/etc/hosts')
    if 0 != rc:
        print('Failed to find selinux label for /etc/hosts')
        sys.exit(3)

# Generated at 2022-06-22 22:25:10.883065
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode in (0, 1, 2)



# Generated at 2022-06-22 22:25:17.884817
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import socket
    import tempfile

    (fd, tmpfile) = tempfile.mkstemp()
    os.close(fd)
    assert os.path.isfile(tmpfile)

    class Connection:
        def __init__(self, path):
            self.path = path

        def send(self, data):
            pass

        def recv(self, bufsize, flags=0):
            return 'RC=0\nCONTEXT=unconfined\n'

    path = tmpfile.encode('utf-8') if sys.version_info[0] == 3 else tmpfile


# Generated at 2022-06-22 22:25:23.239828
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # /etc/passwd context is "system_u:object_r:shadow_t:s0"
    path = "/etc/passwd"
    context = lgetfilecon_raw(path)
    assert context == [0, "system_u:object_r:shadow_t:s0"]
    assert context[0] == 0
    assert context[1] == "system_u:object_r:shadow_t:s0"


# Generated at 2022-06-22 22:25:31.000892
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import sys
    import ctypes
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.selinux as selinux

    class Testselinux_getpolicytype(ModuleTestCase):
        def test_selinux_getpolicytype(self):
            with self.assertRaises(AnsibleExitJson) as context:
                set_module_args({})
                selinux.main()


# Generated at 2022-06-22 22:25:39.092833
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/tmp', 0) == [0, b'system_u:object_r:tmp_t:s0']
    assert matchpathcon(b'/tmp/', 0) == [0, b'system_u:object_r:tmp_t:s0']
    assert matchpathcon(b'/tmp/test_file', 0) == [0, b'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-22 22:25:43.359896
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-22 22:25:45.112182
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    return True if result[0] == 0 else False



# Generated at 2022-06-22 22:25:48.719549
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, int)
    assert isinstance(rc, int)
    assert rc >= 0 or (rc < 0 and enforcemode == -1)



# Generated at 2022-06-22 22:25:52.242824
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc < 0:
        raise OSError(os.strerror(rc))

    print(policytype)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:25:55.513918
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils._text import to_text
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, to_text)

# Generated at 2022-06-22 22:26:03.416229
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, path = lgetfilecon_raw('/')
    assert isinstance(rc, int)
    assert rc == 0
    assert isinstance(path, str)
    assert isinstance(path, str)
    assert path == 'system_u:object_r:root_t:s0'

    # set to invalid path
    rc, path = lgetfilecon_raw('/abcd1234')
    assert isinstance(rc, int)
    assert rc == -1


# Generated at 2022-06-22 22:26:05.694961
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)



# Generated at 2022-06-22 22:26:12.038161
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Unit test for function lgetfilecon_raw
    '''
    path = "/var/log/messages"
    rc, context = lgetfilecon_raw(path)
    print('rc = %d, context = %s' % (rc, context))
    assert rc == 0
    assert context == "system_u:object_r:var_log_t:s0"


# Generated at 2022-06-22 22:26:15.060268
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/missing') == [-1, None]


# Generated at 2022-06-22 22:26:19.142533
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import pytest
    try:
        import selinux
    except ImportError:
        pytest.skip("Cannot run test if selinux module is not installed")
    else:
        ptype = selinux.selinux_getpolicytype()
        assert ptype[0] == 0

# Generated at 2022-06-22 22:26:27.015668
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os
    tmpf = tempfile.NamedTemporaryFile()
    tmpf.close()
    os.chmod(tmpf.name, 0o644)

# Generated at 2022-06-22 22:26:31.485852
# Unit test for function matchpathcon
def test_matchpathcon():
    assert [0, 'system_u:object_r:usr_t:s0'] == matchpathcon(b'/usr', 0)
    assert [0, 'system_u:object_r:user_home_dir_t:s0'] == matchpathcon(b'/root', 0)
    assert [0, 'system_u:object_r:var_t:s0'] == matchpathcon(b'/var', 0)

# Generated at 2022-06-22 22:26:39.215596
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        _selinux_lib.stat
    except:
        sys.exit(77)

    fd = _selinux_lib.stat(b"/etc/passwd", None)
    [rc, con] = lgetfilecon_raw(fd)

    if rc == -13:
        sys.exit(77)
    elif rc == -1:
        sys.exit(1)
    elif rc != 0:
        sys.exit(2)

    sys.exit(0)

# Generated at 2022-06-22 22:26:42.349987
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()

    assert rc == 0
    assert mode in [0, 1, 2]



# Generated at 2022-06-22 22:26:46.158987
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return

    rc, mode = selinux_getenforcemode()

    assert rc == 0
    assert mode == security_getenforce()



# Generated at 2022-06-22 22:26:54.565969
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, output = matchpathcon('/etc/hosts', 0)
    assert rc == 0
    assert output == 'system_u:object_r:etc_runtime_t:s0'

    rc, output = matchpathcon('/etc/hosts', 1)
    assert rc == 0
    assert output == 'system_u:object_r:etc_runtime_t:s0'

    rc, output = matchpathcon('/var/log/messages', 0)
    assert rc == 0
    assert output == 'system_u:object_r:var_log_t:s0'

    rc, output = matchpathcon('/var/log/messages', 1)
    assert rc == 0
    assert output == 'system_u:object_r:var_log_t:s0'

    rc, output = matchpath

# Generated at 2022-06-22 22:26:56.235346
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-22 22:26:58.373209
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    print(enforcemode)


# Generated at 2022-06-22 22:27:06.024845
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
        if rc < 0:
            print("Error: selinux_getenforcemode: {0}".format(os.strerror(rc)))
            sys.exit(1)
        else:
            print("selinux_getenforcemode: {0}".format(enforcemode))
            sys.exit(0)
    except NotImplementedError:
        print("Error: selinux_getenforcemode is not implemented.")
        sys.exit(1)



# Generated at 2022-06-22 22:27:08.990946
# Unit test for function matchpathcon
def test_matchpathcon():
    # we don't have /tmp/foo
    assert matchpathcon('/tmp/foo', 0) == [0, 'unlabeled']


# Generated at 2022-06-22 22:27:11.463095
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    assert lgetfilecon_raw(path)[1] == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-22 22:27:16.687123
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [1, 0]
    assert selinux_getenforcemode() == [1, 1]
    assert selinux_getenforcemode() == [1, 0]



# Generated at 2022-06-22 22:27:23.127315
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/')
    if rc:
        print("Can't obtain the context of root directory")
    else:
        print("The context of root directory is", con)

if __name__ == '__main__':
    test_lgetfilecon_raw()
    # vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-22 22:27:29.052623
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert isinstance(policytype, str)
    if rc == -1 and policytype == '__default__':
        pass
    elif (rc == 0) and (policytype is not None):
        pass
    else:
        raise Exception("selinux_getpolicytype function failed, rc={}, policytype={}".format(rc, policytype))


# Generated at 2022-06-22 22:27:31.155133
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)

# Generated at 2022-06-22 22:27:36.204621
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/var/lib', 0)
    assert con == 'system_u:object_r:lib_t:s0'

    [rc, con] = matchpathcon('/var/lib/foo.png', 0)
    assert con == 'system_u:object_r:lib_t:s0'



# Generated at 2022-06-22 22:27:40.647335
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/')[1]
    assert not lgetfilecon_raw(b'/tmp/not-exists')[1]



# Generated at 2022-06-22 22:27:45.179935
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """ selinux_getpolicytype: return the current SELinux policy """
    [rc, con] = selinux_getpolicytype()
    print("Return code:", rc, "Con:", con)
    if rc == 0:
        return True
    else:
        return False


# Generated at 2022-06-22 22:27:49.266114
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "."
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_t'


if __name__ == '__main__':
    global rc, con
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:27:59.065493
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    module_name = 'selinux_getpolicytype'
    module = sys.modules['ansible.module_utils.selinux_utils']
    if module_name in dir(module):
        func = getattr(module, module_name)
        if func:
            result = func()
            print('[{0}] returned [{1}]'.format(module_name, result))
            assert len(result) == 2
            assert isinstance(result[0], int)
            assert isinstance(result[1], str)
        else:
            raise ImportError('unable to access function: {0}'.format(module_name))



# Generated at 2022-06-22 22:28:02.177149
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("Test lgetfilecon_raw()")
    rc, con = lgetfilecon_raw('/home/ansible')
    print("rc=%d con=%s" % (rc, con))


# Generated at 2022-06-22 22:28:13.501360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import mkstemp
    from os import fdopen
    from os import unlink
    from shutil import rmtree

    # Create a temp file
    fd, path = mkstemp()
    file_obj = fdopen(fd)
    file_obj.close()

    # Write test data to it
    file_obj = open(path, 'wt')
    file_obj.write("lgetfilecon_raw test data")
    file_obj.close()

    # Get the file context with lgetfilecon_raw
    status, context = lgetfilecon_raw(path)

    # Cleanup
    unlink(path)

    assert status == 0
    assert context is not None



# Generated at 2022-06-22 22:28:16.295777
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    context = lgetfilecon_raw(b"/etc/passwd")
    assert context == [0, "unconfined_u:object_r:user_home_t:s0-s0:c0.c1023"]

# Generated at 2022-06-22 22:28:20.779051
# Unit test for function matchpathcon
def test_matchpathcon():
    # test the matchpathcon that is directly attached to the module
    [rc, con] = matchpathcon(b'/usr/bin/python3', 0o777)
    assert con == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-22 22:28:22.149676
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:28:24.254516
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("selinux_getenforcemode", rc, enforcemode)



# Generated at 2022-06-22 22:28:28.516633
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    status, enforcemode = selinux_getenforcemode()
    if status != 0:
        print("status error")
        return False

    # enforcemode = 0: Permissive
    # enforcemode = 1: Enforcing
    if enforcemode != 0 and enforcemode != 1:
        print("enforcemode error")
        return False

    return True


# Generated at 2022-06-22 22:28:31.340387
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (1, 2, 3)



# Generated at 2022-06-22 22:28:32.650013
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test case matchpathcon
    """
    assert matchpathcon('/', 0) == [0, 'user_u:object_r:admin_home_t:s0']



# Generated at 2022-06-22 22:28:37.065853
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    print('selinux_getpolicytype: rc: {0}, con: {1}'.format(rc, con))
    assert rc == 0

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:28:46.774841
# Unit test for function matchpathcon
def test_matchpathcon():
    # py3 lint: disable=undefined-variable
    if not is_selinux_enabled():
        return

    # sample value from getenforce(1)
    enforcetype = {
        0: 'Disabled',
        1: 'Permissive',
        2: 'Enforcing',
    }[security_getenforce()]

    path = '/etc/passwd'
    mode = 0

    rc, con = matchpathcon(path, mode)

    module.exit_json(rc=rc, con=con, enforcetype=enforcetype)



# Generated at 2022-06-22 22:28:48.483666
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ['targeted', 'mls', 'dontaudit']

# Generated at 2022-06-22 22:28:49.818130
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert (selinux_getpolicytype())[0] == 0

# Generated at 2022-06-22 22:28:57.038396
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os

    tmpfile = tempfile.NamedTemporaryFile()
    tmpfilename = tmpfile.name
    tmpfile.close()

    # if we are running in a container, assume that selinux is disabled and fail the test
    if os.path.exists('/.dockerenv'):
        assert lgetfilecon_raw(tmpfilename) == [0, "<<none>>"]
    else:
        assert lgetfilecon_raw(tmpfilename) == [0, "unlabeled"]

    os.remove(tmpfilename)


# Generated at 2022-06-22 22:29:01.362876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/hosts'
    rc, path_context = lgetfilecon_raw(path)
    assert rc == 0
    assert type(path_context) is str
    assert path_context != 'unlabeled'


# Generated at 2022-06-22 22:29:05.880682
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test if a path is covered by a specific selinux context.
    # If it is, will return 0 and the matched context.
    # Otherwise, return -1 and the error message.
    rc, con = matchpathcon('/etc/ssh/sshd_config', 0)
    if rc < 0:
        print('Failed to match /etc/ssh/sshd_config: {}'.format(con))
    else:
        print('Matched /etc/ssh/sshd_config: {}'.format(con))

    if rc < 0:
        rc, con = matchpathcon('/etc/ssh/sshd_config', os.R_OK)
        if rc < 0:
            print('Failed to match /etc/ssh/sshd_config: {}'.format(con))

# Generated at 2022-06-22 22:29:08.019316
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-22 22:29:10.670142
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test'
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert 'test_t' in result[1]



# Generated at 2022-06-22 22:29:12.705823
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, res) = selinux_getpolicytype()
    assert rc == 0
    assert res.startswith('targeted')


# Generated at 2022-06-22 22:29:14.748235
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/mnt/")
    return con

# Generated at 2022-06-22 22:29:18.788931
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype
    [status, data] = selinux_getpolicytype()
    assert status >= 0
    assert data is not None
    assert isinstance(data, str)



# Generated at 2022-06-22 22:29:25.358476
# Unit test for function matchpathcon
def test_matchpathcon():
    s = matchpathcon('/etc/shadow', os.R_OK)
    assert s[0] == 0, (s[0], s[1])
    assert s[1] == "object_r:shadow_t", (s[0], s[1])
    s = matchpathcon('/etc/shadow', os.R_OK + os.W_OK)
    assert s[0] == 0, (s[0], s[1])
    assert s[1] == "object_r:shadow_t:s0", (s[0], s[1])

# Generated at 2022-06-22 22:29:31.356505
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/log"
    mode = 0o755
    rc, res = matchpathcon(path, mode)
    assert rc == 0
    assert res == "system_u:object_r:var_log_t:s0-s0:c0.c1023"

# Generated at 2022-06-22 22:29:33.953686
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode, _enforce = selinux_getenforcemode()
    assert mode == 0
    assert _enforce in [0, 1, 2]


# Generated at 2022-06-22 22:29:45.345868
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat

    SAMPLE_FILE = '/tmp/sample_file'
    # a stat structure to create the sample file
    # the mode is the default that python os.mkdir() uses
    sample_stat = os.stat_result((0o644, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    os.mkdir(SAMPLE_FILE, mode=sample_stat.st_mode)
    os.chmod(SAMPLE_FILE, stat.S_IRUSR)

    # we expect 'system_u:object_r:default_t' as the context
    (rc, con) = matchpathcon(SAMPLE_FILE, stat.S_IFDIR)
    assert rc == 0, rc
    assert con == 'system_u:object_r:default_t', con

    os

# Generated at 2022-06-22 22:29:51.871480
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import tempfile
    import contextlib
    import selinux

    @contextlib.contextmanager
    def tempdir():
        tmpdir = tempfile.mkdtemp()
        yield tmpdir
        # clean up
        for root, dnames, fnames in os.walk(tmpdir, topdown=False):
            for name in fnames:
                os.remove(os.path.join(root, name))
            for name in dnames:
                os.rmdir(os.path.join(root, name))
        os.rmdir(tmpdir)

    with tempdir() as tmpdir:
        # create file in the temp directory
        tmpfile = os.path.join(tmpdir, 'tmpfile')

# Generated at 2022-06-22 22:29:56.486513
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode_info = selinux_getenforcemode()
    assert type(enforcemode_info[0]) == int
    assert type(enforcemode_info[1]) == int


# Generated at 2022-06-22 22:30:04.615024
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ctypes import cdll

    lib = cdll.LoadLibrary('libc.so.6')
    lib.open.argtypes = [c_char_p, c_int]
    lib.open.restype = c_int
    fd = lib.open('/etc/shadow', os.O_RDONLY)

    # this will fail with ENOTSUP if we are not in a selinux context
    rc, con = lgetfilecon_raw(fd)
    assert rc >= 0, 'failed to get selinux context'
    print('selinux context: {0}'.format(con))

    lib.close(fd)

# Generated at 2022-06-22 22:30:10.603989
# Unit test for function matchpathcon
def test_matchpathcon():
    def _dummy_matchpathcon(path, mode):
        return [-1, '']

    original_matchpathcon = matchpathcon

    matchpathcon = _dummy_matchpathcon
    try:
        assert lgetfilecon_raw('/test_path') == [-1, '']

        assert matchpathcon('/test_path', c_int(0)) == [-1, '']
    finally:
        matchpathcon = original_matchpathcon

# Generated at 2022-06-22 22:30:20.266067
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.common.text.converters import to_native
    import os
    import sys
    import stat

    test_dir = "/var/tmp/selinux_test_dir"
    test_file = "/var/tmp/selinux_test_file"
    create_file = False
    create_dir = False

    # Remove any existing file or directory
    if os.path.exists(test_file):
        os.unlink(test_file)
    if os.path.exists(test_dir):
        os.rmdir(test_dir)

    if os.path.exists(test_file):
        rc, con = matchpathcon(test_file, stat.S_IFREG)
        assert rc == 0

# Generated at 2022-06-22 22:30:29.405524
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.selinux import selinux_getpolicytype
    except ImportError:
        raise UnitTestError("Failed to import selinux.py")
    try:
        (rc, type) = selinux_getpolicytype()
    except Exception as e:
        raise UnitTestError("is_selinux_enabled failed to execute due to exception: {0}".format(e.__str__()))

    if rc != 0:
        raise UnitTestError("selinux_getpolicytype failed to execute due to rc: {0}".format(rc))


# Generated at 2022-06-22 22:30:33.990171
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0o400)
    assert con == 'unconfined_u:object_r:user_home_t:s0'
    rc, con = matchpathcon('/etc/passwd', 0o600)
    assert con == 'unconfined_u:object_r:user_home_t:s0'

# Generated at 2022-06-22 22:30:37.191050
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:30:42.916866
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create a test file
    f = open("/tmp/testfile", "w")
    f.close()

    # get the context of the test file
    context = lgetfilecon_raw("/tmp/testfile")

    # delete the test file
    os.remove("/tmp/testfile")

    return context[1]


# Generated at 2022-06-22 22:30:47.506351
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[1] == 2, "Enfroce mode is not permissive"


# Generated at 2022-06-22 22:30:50.317144
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert (lgetfilecon_raw(b"/tmp/test"))[0] == 0, "Failed to get the context of the file /tmp/test"


# Generated at 2022-06-22 22:30:55.982751
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Call matchpathcon with a known file
    """
    assert matchpathcon('/proc/self/mounts', 0) == [0, 'system_u:object_r:proc_t:s0']
    assert matchpathcon('/proc/self/mounts', 0)[1] == 'system_u:object_r:proc_t:s0'
    # test a file which is not present
    assert matchpathcon('/var/not_here', 0) == [-1, '']

# Generated at 2022-06-22 22:31:00.800298
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    path = '/'
    mode = 0

    expected_path = path
    expected_mode = mode

    actual_path = path
    actual_mode = mode

    assert [0, 'targeted'] == selinux_getpolicytype()



# Generated at 2022-06-22 22:31:10.380742
# Unit test for function matchpathcon
def test_matchpathcon():
    MPC_FULLPATH = 1
    MPC_RUN = 1
    MPC_USER = 1
    MPC_RESULT = 0

    # lgetfilecon_raw(path)
    (rc, con) = lgetfilecon_raw(b'/etc/hosts')
    assert rc == 0
    assert con == b'system_u:object_r:etc_t:s0'

    rc = lsetfilecon(b'/etc/hosts', con)
    assert rc == 0

    # matchpathcon(path,mode)
    (rc, con) = matchpathcon(b'/etc/hosts', MPC_FULLPATH | MPC_USER | MPC_RESULT)
    assert rc == 0
    assert con == b'system_u:object_r:etc_t:s0'

   

# Generated at 2022-06-22 22:31:13.966082
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    policytype = selinux_getenforcemode()
    assert type(policytype[0]) == int
    assert type(policytype[1]) == int
    assert policytype[0] in [0, 1, -1]


# Generated at 2022-06-22 22:31:20.327782
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/etc/shadow'
    if os.path.exists(test_path):
        rc, con = matchpathcon(test_path, 0)
        assert rc == 0 and con == 'system_u:object_r:shadow_t:s0', 'expected system_u:object_r:shadow_t:s0, actual: %s' % con
    else:
        assert True, '%s not found, cannot run test' % test_path

# Generated at 2022-06-22 22:31:23.765271
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]
    if selinux_getenforcemode()[1] == 1:
        assert selinux_getenforcemode()[1] == 1
    else:
        assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:31:28.274256
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not is_selinux_enabled():
        return
    (rc, policy) = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)
    assert policy in ['targeted', 'mls']



# Generated at 2022-06-22 22:31:31.481813
# Unit test for function matchpathcon
def test_matchpathcon():
    # Assert exit code is 0 for success
    rc, msg = matchpathcon('/etc/passwd', os.R_OK)

    assert rc == 0, "function matchpathcon failed with error: %s" % msg

# Generated at 2022-06-22 22:31:35.340461
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ctypes import c_char_p, byref

    [rc, enforcemode] = selinux_getenforcemode()
    assert enforcemode == 1 or enforcemode == 0
    assert rc == 0



# Generated at 2022-06-22 22:31:38.931088
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    def __init__(self):
        print(selinux_getenforcemode())



# Generated at 2022-06-22 22:31:42.253940
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json

    ret = selinux_getpolicytype()
    print(json.dumps({'failed': False, 'changed': False, 'rc': ret[0], 'policy': ret[1]}))



# Generated at 2022-06-22 22:31:45.932174
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc')
    print('rc:{}, con:{}'.format(rc, con))



# Generated at 2022-06-22 22:31:54.803572
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/boot/vmlinuz', 0)
    assert rc == 0
    assert con == 'kernel_t:object_r:boot_t:s0'
    rc, con = matchpathcon('/boot/vmlinuz', 1)
    assert rc == 0
    assert con == 'kernel_t'
    rc, con = matchpathcon('/boot/vmlinuz', 3)
    assert rc == 0
    assert con == 'kernel_t:object_r:boot_t:s0'
    rc, con = matchpathcon('/boot/vmlinuz', 2)
    assert rc == 0
    assert con == 'system_u:object_r:boot_t:s0'
    rc, con = matchpathcon('/boot/vmlinuz', 4)
    assert rc == 0
   

# Generated at 2022-06-22 22:32:00.304157
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t']
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t']
    assert matchpathcon('/foo', 0) == [-1, None]

# Generated at 2022-06-22 22:32:08.475388
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    fd, tmp_file_path = tempfile.mkstemp()
    try:
        tmp_file_con = lgetfilecon_raw(tmp_file_path)[1]
        if not tmp_file_con:
            print('warning: SELinux is not enabled, skipping test: lgetfilecon_raw')
        else:
            assert isinstance(tmp_file_con, str)
            assert tmp_file_con != ""
    finally:
        os.close(fd)
        os.unlink(tmp_file_path)

# Generated at 2022-06-22 22:32:10.860049
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/bin/sh') == [0, 'system_u:object_r:shell_exec_t:s0']
    assert lgetfilecon_raw('/bin/doesnotexist') == [-2, None]
    assert lgetfilecon_raw(None) == [-1, None]

# Generated at 2022-06-22 22:32:20.686059
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create temporary testing file
    import tempfile
    test_file = tempfile.NamedTemporaryFile(mode='w+')

    # Make sure it exists and try to match it in the system
    # The resulting file context should be correct and should not be empty
    if os.path.isfile(test_file.name):
        full_path = os.path.abspath(test_file.name)
        rc, context = matchpathcon(full_path, 0)
        assert rc == 0 and context is not None



# Generated at 2022-06-22 22:32:22.666132
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert con == 'shadow_t'



# Generated at 2022-06-22 22:32:27.428465
# Unit test for function matchpathcon
def test_matchpathcon():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_dir, "selinux_helper.py")
    print(matchpathcon(test_file, 0))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:32:31.849400
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case-1: check file context of /etc/sysconfig/network-scripts/ifcfg-eth0
    test_path = '/etc/sysconfig/network-scripts/ifcfg-eth0'
    test_mode = 1
    test_context = 'system_u:object_r:net_conf_t:s0'
    lgetfilecon_raw_result = lgetfilecon_raw(test_path)
    assert lgetfilecon_raw_result[1] == test_context
