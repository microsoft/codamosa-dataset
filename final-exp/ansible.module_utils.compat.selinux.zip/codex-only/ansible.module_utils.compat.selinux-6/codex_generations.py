

# Generated at 2022-06-22 22:22:39.013624
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/selinux/targeted/contexts/files/file_contexts'
    mode = os.R_OK
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    print('RC = %d, Con = %s' % (rc, con))


# Generated at 2022-06-22 22:22:47.123157
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode in (0, 1, 2)

    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype in ('targeted', 'minimum', 'mls')

    rc, con = lgetfilecon_raw('/usr')
    if rc in (0, -1):
        assert rc == 0
        assert con.startswith(b'system_u:object_r:')
        assert con.endswith(b':s0')

    rc, con = matchpathcon('/usr', mode)
    assert rc == 0
    assert con.startswith('system_u:object_r:')
    assert con.endswith(':s0')

# Generated at 2022-06-22 22:22:49.031325
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:22:58.490681
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from os import unlink

    tdir = tempfile.mkdtemp()
    tf = tdir + '/test_file'
    try:
        rc, val = lgetfilecon_raw(tdir)
        assert(rc == 0)
        assert val.startswith('unlabeled')
        rc, val = lgetfilecon_raw(tf)
        assert(rc != 0)
    finally:
        unlink(tf)
        os.rmdir(tdir)



# Generated at 2022-06-22 22:23:03.561152
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc < 0:
        raise OSError(rc, to_native(os.strerror(rc)))
    return policytype


# Generated at 2022-06-22 22:23:13.745342
# Unit test for function matchpathcon
def test_matchpathcon():
    def _test(path, mode):
        rc, con = matchpathcon(path, mode)
        print('matchpathcon({0!r}, {1}) -> {2!r}'.format(path, mode, con))

        if rc < 0:
            errno = get_errno()
            raise OSError(errno, os.strerror(errno))

        return con

    def _test_fail(path, mode):
        try:
            _test(path, mode)
        except Exception as e:
            print('matchpathcon({0!r}, {1}) -> {2}: {3}'.format(path, mode, type(e), e))

    _test('/etc/passwd', 0)
    _test('/test_matchpathcon', 0)

# Generated at 2022-06-22 22:23:15.195581
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # test valid mode, 1
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:23:21.876432
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test for function selinux_getpolicytype
    """

    if not os.path.exists('/etc/selinux/config'):
        return

    rc, policy = selinux_getpolicytype()

    if rc == 0:
        print(policy)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:23:30.705295
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/bin/', 0)
    assert rc == 0
    assert con == 'system_u:object_r:bin_t:s0'
    rc, con = matchpathcon('/usr/bin/', 1)
    assert rc == 0
    assert con == 'system_u:object_r:bin_t:s0'
    rc, con = matchpathcon('/var/log/', 0)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'
    rc, con = matchpathcon('/var/log/', 1)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'

# Generated at 2022-06-22 22:23:32.988688
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, _ = selinux_getpolicytype()
    assert rc == 0



# Generated at 2022-06-22 22:23:36.685479
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype

    rc, value = selinux_getpolicytype()
    assert rc == 0, "Not returning 0, instead rc is {0}".format(rc)
    assert value is not None, "Value is None"

# Generated at 2022-06-22 22:23:39.279762
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _, policy_type = selinux_getpolicytype()
    assert policy_type in ('targeted', 'mls', 'minimum'), "Policy type is not one of 'targeted', 'mls', 'minimum'"

# Generated at 2022-06-22 22:23:48.333066
# Unit test for function matchpathcon
def test_matchpathcon():
    _test_path = '/tmp'
    _test_mode = os.R_OK
    _test_con = 'system_u:object_r:tmp_t:s0'

    # Validate that we can invoke matchpathcon ok
    rc, con = matchpathcon(_test_path, _test_mode)
    assert rc == 0
    assert con == _test_con

    # Validate that we get a useful error when fpath is invalid
    rc, con = matchpathcon('doesnt_exist', _test_mode)
    assert rc == -1
    assert rc != 0

# Generated at 2022-06-22 22:23:52.718605
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test empty string
    rc, policytype = selinux_getpolicytype()
    if rc == 0 and policytype != "":
        raise AssertionError("The selinux_getpolicytype() does not return a valid type.")



# Generated at 2022-06-22 22:24:01.426465
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os

    try:
        mod_dir = os.path.dirname(os.path.abspath(__file__))
        if not os.path.exists(os.path.join(mod_dir, "module_utils/selinux.py")):
            raise OSError

        from ansible.module_utils.selinux import selinux_getpolicytype
        policy_type = selinux_getpolicytype()[1]
        assert policy_type in ("strict", "targeted", "minimum", "mls")
    except (ImportError, OSError):
        pass

# Generated at 2022-06-22 22:24:04.269485
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    return [rc, enforcemode.value]


# Generated at 2022-06-22 22:24:10.517326
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ..common.selinux_testlib import set_selinux_enforce
    from ..common.selinux_testlib import set_selinux_type
    from ..common.selinux_testlib import set_selinux_policy

    import tempfile

    with tempfile.NamedTemporaryFile(dir='/tmp') as f:
        set_selinux_type(f.name, 'tmp_t')
        set_selinux_enforce('1')

        [rc, policytype] = selinux_getpolicytype()
        assert rc == 0
        assert policytype == 'targeted'
        set_selinux_policy('strict')
        [rc, policytype] = selinux_getpolicytype()
        assert rc == 0
        assert policytype == 'strict'
        set_sel

# Generated at 2022-06-22 22:24:17.748343
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock

    import ansible_collections.notstdlib.moveitallout.plugins.modules.selinux_permissive

    with mock.patch('ansible_collections.notstdlib.moveitallout.plugins.modules.selinux_permissive.lgetfilecon_raw', return_value=['error', '']), mock.patch.object(ansible_collections.notstdlib.moveitallout.plugins.modules.selinux_permissive, '_selinux_lib', create=True) as mock_selinux_lib:
        mock_selinux_lib.lgetfilecon_raw = mock.MagicMock(return_value=['error', ''])
        result = ansible_collections.notstd

# Generated at 2022-06-22 22:24:22.465883
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
    except OSError as e:
        # if getenforcemode fails, just pass on this test
        return

    assert isinstance(enforcemode, int)
    assert isinstance(rc, int)



# Generated at 2022-06-22 22:24:26.184295
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/shadow"
    [rc, out] = lgetfilecon_raw(path)
    # A return code of 3 means the file doesn't exist, so just skip the test
    if rc != 3:
        assert out == "system_u:object_r:shadow_t:s0"


# Generated at 2022-06-22 22:24:27.700193
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == "targeted"

# Generated at 2022-06-22 22:24:30.435210
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Get the context of a file
    path = '/tmp/something'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con != None


# Generated at 2022-06-22 22:24:34.536124
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test with valid values
    rc, enforcemode = selinux_getenforcemode()
    if rc != 0:
        print("Error in selinux_getenforcemode with valid values. Test case failed")
        exit(1)
    print("selinux_getenforcemode returned {0} and enforcemode is {1}".format(rc, enforcemode))


# Generated at 2022-06-22 22:24:45.390528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import TemporaryDirectory

    class MockArgv:
        def __init__(self, argv):
            self.argv = argv
        def __enter__(self):
            sys.argv = self.argv
        def __exit__(self, etype, value, traceback):
            sys.argv = self.argv

    with MockArgv(['ansible-test', 'units', '--python-interpreter', sys.executable]):
        from ansible.module_utils import basic
        from ansible_collections.community.general.tests.unit.compat import unittest
        import ansible_collections.community.general.plugins.modules.system.selinux


# Generated at 2022-06-22 22:24:55.657477
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[0] < 0:
        raise ImportError('selinux is not enabled')

    # This function has the same interface as _selinux_lib.matchpathcon
    def demo_matchpathcon(path, mode):
        con = c_char_p()
        try:
            rc = _selinux_lib.matchpathcon(path, mode, byref(con))
            return [rc, to_native(con.value)]
        finally:
            _selinux_lib.freecon(con)

    # Use a sample path that exists and is not a directory
    example_path = '/dev/null'
    example_mode = 0

    # Sample call
    rc, context = demo_matchpathcon(example_path, example_mode)

    if rc < 0:
        raise

# Generated at 2022-06-22 22:24:59.712976
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '.'
    mode = 0
    hash = {
        'rc': 0,
        'con': 'user_u:object_r:default_t:s0'
    }

    rc, con = matchpathcon(path, mode)

    assert rc == hash['rc']
    assert con == hash['con']


# Generated at 2022-06-22 22:25:05.155908
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux.selinux_base import selinux_enforcing, selinux_disabled, selinux_permissive
    # Should return code, enforcing if SELinux is installed and enabled
    result = selinux_getenforcemode()
    assert result == [0, selinux_enforcing]



# Generated at 2022-06-22 22:25:08.307472
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-22 22:25:12.671073
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    try:
        assert rc == 0
        assert policytype in {'targeted', 'minimum', 'mls'}
    except AssertionError as e:
        raise AssertionError('assertion error: {0}'.format(e))



# Generated at 2022-06-22 22:25:14.252780
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, mode] = selinux_getenforcemode()
    assert(rc >= 0)
    assert(0 <= mode <= 2)



# Generated at 2022-06-22 22:25:17.134952
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    if policytype[0] < 0:
        raise ValueError("Failed to get the policytype")
    else:
        print("Success, policytype is %s" % (policytype[1]))


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:25:19.943786
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, selinux_policy = selinux_getpolicytype()
    assert rc == 0, "Return code not zero. Something went wrong"
    assert selinux_policy, "Policy Type can't be null"


# Generated at 2022-06-22 22:25:23.981550
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _func = selinux_getpolicytype
    ret = _func()
    assert ret[0] == 0, 'selinux_getpolicytype returned error: {0}'.format(ret[0])
    assert ret[1] == 'targeted', 'selinux_getpolicytype returned unexpected type: {0}'.format(ret[1])

# Generated at 2022-06-22 22:25:26.840080
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test that the selinux_getenforcemode function works
    """
    rc, mode = selinux_getenforcemode()
    print('rc: {0}, mode: {1}'.format(rc, mode))



# Generated at 2022-06-22 22:25:28.138087
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-22 22:25:38.240390
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if sys.version_info[0] > 2:
        return

    # ctypes.c_int : value -1, class ctypes.c_int, typecode 'i'
    try:
        test_selinux_getenforcemode.assert_equal_unsupported(selinux_getenforcemode(), [[-1, -1]])
        test_selinux_getenforcemode.assert_equal_unsupported(selinux_getenforcemode(), [[-1, -1]])
    except:
        test_selinux_getenforcemode.exception("selinux_getenforcemode")


test_selinux_getenforcemode.unsupported = True


# Generated at 2022-06-22 22:25:41.275373
# Unit test for function matchpathcon
def test_matchpathcon():
    path = os.path.expanduser('~/file')
    with open(path, 'w'):
        pass

    try:
        print(matchpathcon(path, 0))
    finally:
        os.unlink(path)

# Generated at 2022-06-22 22:25:43.770869
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == "targeted"


# Generated at 2022-06-22 22:25:46.982512
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    return [rc, enforcemode.value]


# Generated at 2022-06-22 22:25:51.133976
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    def _selinux_getpolicytype():
        rc, kind = selinux_getpolicytype()
        if rc < 0:
            raise OSError(get_errno(), os.strerror(get_errno()))
        return kind

    assert _selinux_getpolicytype() == 'targeted'

# Generated at 2022-06-22 22:25:55.061511
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/issue'
    rc, com = matchpathcon(path, 0)
    print('rc: %s, com: %s' % (rc, com))



# Generated at 2022-06-22 22:26:00.353298
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    if result[0] == 0 and result[1] == 0:
        test_result = True
    else:
        test_result = False

    assert test_result is True


# Generated at 2022-06-22 22:26:05.631791
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.exists('/tmp/test1'):
        os.mknod('/tmp/test1')

    (rc, con) = matchpathcon('/tmp/test1', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:26:09.440034
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if is_selinux_enabled() == 0:
        assert selinux_getenforcemode() == [0, 0]
    else:
        assert selinux_getenforcemode() == [0, 1]

# Generated at 2022-06-22 22:26:20.587149
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/root') == [0, b'root:object_r:admin_home_t:s0']
    assert lgetfilecon_raw(b'/sys/module') == [0, b'sysfs:object_r:module_t:s0']
    assert lgetfilecon_raw(b'/tmp') == [0, b'tmp:object_r:tmp_t:s0']
    assert lgetfilecon_raw(b'/dev/null') == [0, b'root:object_r:null_device_t:s0']
    assert lgetfilecon_raw(b'/dev/urandom') == [0, b'root:object_r:random_device_t:s0']

# Generated at 2022-06-22 22:26:22.481580
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: how to test this?
    pass


# Generated at 2022-06-22 22:26:25.312966
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, result = selinux_getenforcemode()
    assert rc >= 0
    assert result in (0, 1, 2)



# Generated at 2022-06-22 22:26:30.113000
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, con = selinux_getpolicytype()
    except ImportError:
        assert False, 'ctypes module unable to load libselinux'

    assert rc == 0, "Error found with selinux function: selinux_getpolicytype"
    assert con != '', "Error found with selinux function: selinux_getpolicytype"


# Generated at 2022-06-22 22:26:36.709448
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc == 0:
        if not isinstance(con, str):
            raise ValueError("selinux_getpolicytype did not return 'str' data type for context")
    else:
        raise ValueError("selinux_getpolicytype return code not 0, rc = %d" % rc)


# Generated at 2022-06-22 22:26:43.080466
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/home/user1'
    test_mode = 0

    try:
        (rc, con) = matchpathcon(test_path, test_mode)
        assert con == 'user_home_t'
    except OSError as e:
        print('test_matchpathcon fails: ' + str(e))

# Generated at 2022-06-22 22:26:44.779615
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:26:56.834602
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import mock
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.selinux import selinux_getpolicytype, selinux_getenforcemode, matchpathcon, lgetfilecon_raw

    policy, rc = selinux_getpolicytype()
    if rc != 0 or policy not in ['targeted', 'strict']:
        print('Unsupported SELinux policy type: {0}'.format(policy))
        return

    enforce, rc = selinux_getenforcemode()
    if rc != 0 or enforce not in [0, 1]:
        print('Unsupported SELinux enforcing mode: {0}'.format(enforce))
        return

    path = b

# Generated at 2022-06-22 22:27:00.175170
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret = selinux_getpolicytype()

    if ret[0] < 0:
        raise Exception("Failed to get policy type")



# Generated at 2022-06-22 22:27:04.154875
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
        test_path = b'/etc/homedir/./rsync_test/test'
        result = lgetfilecon_raw(test_path)
        print("result = ", result)


# Generated at 2022-06-22 22:27:06.767198
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1


# Generated at 2022-06-22 22:27:13.144923
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not hasattr(selinux_getenforcemode, 'restype'):
        assert True
        return
    try:
        assert 'selinux_getenforcemode' in dir(selinux_getenforcemode)
        assert isinstance(selinux_getenforcemode.restype, type(None))
    except (AssertionError, AttributeError):
        pytest.fail("Potential missing function selinux_getenforcemode, check module.")


# Generated at 2022-06-22 22:27:15.743688
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("\nselinux_getpolicytype: " + str(selinux_getpolicytype()))



# Generated at 2022-06-22 22:27:18.176770
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test selinux_getenforcemode
    '''
    rc, enforcemode = selinux_getenforcemode()
    return [rc, enforcemode]



# Generated at 2022-06-22 22:27:29.718407
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Tests that selinux_getenforcemode() returns a tuple with 2 elements and second element of tuple
    is one of the constants defined in the module.
    This is not a complete test of the function as it cannot be verified how the function behaves
    in all possible conditions.
    """
    assert isinstance(selinux_getenforcemode(), tuple)
    assert len(selinux_getenforcemode()) == 2
    # second element has to be one of the constants in the module
    permitted_vals = [SELINUX_ENFORCE_DEFAULT, SELINUX_ENFORCE_PERMISSIVE, SELINUX_ENFORCE_ENFORCED]
    assert selinux_getenforcemode()[1] in permitted_vals



# Generated at 2022-06-22 22:27:34.707976
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw('/root')
    assert len(res) == 2
    assert isinstance(res[0], int)
    assert isinstance(res[1], str)
    assert res[0] != -1
    assert res[1] is not None
    assert res[1] != ''



# Generated at 2022-06-22 22:27:38.138286
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tval = lgetfilecon_raw(b"/")
    assert isinstance(tval, list)
    assert len(tval) == 2
    assert tval[0] == 0
    assert isinstance(tval[1], str)


# Generated at 2022-06-22 22:27:49.092962
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.linux.common import selinux
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    mock = patch.object(basic.AnsibleModule, '_execute_module')
    mock.start()

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    rc, value = selinux.selinux_getenforcemode()
    module.exit_json(rc=rc, value=value)

    mock.stop()

# Generated at 2022-06-22 22:27:53.077162
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)
    assert len(policytype) > 0

# Generated at 2022-06-22 22:27:54.685458
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-22 22:27:56.197680
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-22 22:27:58.076641
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0], "Should be true."


# Generated at 2022-06-22 22:28:04.085240
# Unit test for function matchpathcon
def test_matchpathcon():
    import stat
    r = matchpathcon('/etc/hosts', stat.S_IFREG)
    sys.stdout.write('Matchpathcon returned {}\n'.format(r))
    r = matchpathcon('/etc/hosts', stat.S_IFDIR)
    sys.stdout.write('Matchpathcon returned {}\n'.format(r))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:14.654436
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.basic import AnsibleModule
    import shutil
    import tempfile

    args = dict(
        path='/tmp/ansible-selinux-test',
        mode=600
    )

    module = AnsibleModule(argument_spec=args)
    if not module._name.startswith('selinux'):
        module.fail_json(msg='module not called as {0}'.format(module._name))

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:28:26.469534
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test selinux_getenforcemode function
    """
    import tempfile

    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    os.remove(path)

    # FIXME: this test is not portable, need to figure out how to test SELinux behavior
    rc, mode = selinux_getenforcemode()
    assert rc == 0

    # FIXME: this test is not portable, need to figure out how to test SELinux behavior
    rc, type_ = selinux_getpolicytype()
    assert rc == 0
    assert type_ == 'targeted'

    # this test should always succeed
    rc, context = lgetfilecon_raw(path)
    assert rc == -1
    assert context == ''

    # this test should always succeed
    rc, context = match

# Generated at 2022-06-22 22:28:29.087068
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    con = to_native(con)
    assert con in ['targeted', 'mls']


# Generated at 2022-06-22 22:28:40.477518
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Assert correct output for successful function calls
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/usr/bin/ansible-playbook') == [0, 'system_u:object_r:usr_t:s0']

    # Assert file not found error
    try:
        assert lgetfilecon_raw('/etc/fakefile') == [0, '']
    except OSError as e:
        assert e.errno == 2

    # Assert incorrect context error

# Generated at 2022-06-22 22:28:45.970705
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/somefile')
    assert rc == 0
    assert con.startswith('system_u:object_r:etc_t:s0')
    (rc, con) = lgetfilecon_raw('/etc/somefile123')
    assert rc != 0


# Generated at 2022-06-22 22:28:55.033286
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] == 0 or enforcemode[0] == 1 or enforcemode[0] == 2 or enforcemode[0] == 3
    if enforcemode[0] == 0:
        assert enforcemode[1] == 'Permissive'
    elif enforcemode[0] == 1:
        assert enforcemode[1] == 'Enforcing'
    elif enforcemode[0] == 2:
        assert enforcemode[1] == 'Policy not loaded'
    elif enforcemode[0] == 3:
        assert enforcemode[1] == 'Internal Error'
    else:
        assert False



# Generated at 2022-06-22 22:28:59.533487
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    returncode, policytype = selinux_getpolicytype()
    if returncode != 0:
        print('selinux_getpolicytype failed with return code {0}'.format(returncode))



# Generated at 2022-06-22 22:29:07.768484
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    from distutils.dir_util import mkpath
    from shutil import rmtree
    from os.path import join, dirname, realpath
    from os import chmod, mkdir
    from os import lstat
    from stat import S_ISLNK

    def _matchpathcon(path, mode):
        rc, con = matchpathcon(path, mode)

        if rc != 0:
            errno = get_errno()
            raise OSError(errno, os.strerror(errno))

        return con

    def _cleanup():
        rmtree(path)

    # prepend the system python path with our temporary path
    # in case there is an existing libselinux context on the system
    sys.path.insert(0, path)

    # create a temporary directory for this

# Generated at 2022-06-22 22:29:10.375802
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Run selinux_getpolicytype
    rc, con = selinux_getpolicytype()

    # Check rc and con return values
    assert [rc, con] == [0, 'targeted']



# Generated at 2022-06-22 22:29:12.748970
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    f = selinux_getpolicytype()
    if f[0] >= 0:
        print(f[1])
        return True
    else:
        return False


# Generated at 2022-06-22 22:29:17.209009
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode
    rc, value = selinux_getenforcemode()
    assert rc == 0
    assert value in [0, 1, 2]


# Generated at 2022-06-22 22:29:19.654129
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted' or selinux_getpolicytype()[1] == 'mls'

# Generated at 2022-06-22 22:29:23.239841
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    try:
        rc, con = matchpathcon(tmpdir, 0)
        assert rc == 0 and con
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-22 22:29:26.967773
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    if rc == 0:
        assert policy_type in ('targeted', 'mls', 'minimum', 'strict'), "Unexpected policy type '%s'" % policy_type
    else:
        assert False, "SELinux policy unavailable"

# Generated at 2022-06-22 22:29:34.721391
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.sep.encode('utf-8')

    if is_selinux_enabled():
        rc, con = lgetfilecon_raw(path)
    else:
        rc = 1
        con = None

    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))

    print(con)
    return [rc, con]

# Generated at 2022-06-22 22:29:41.946823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # lgetfilecon_raw shall return the correct mode as (rc, con)
    [rc, con] = lgetfilecon_raw('/etc')
    if rc != 0:
        raise Exception(rc, to_native(os.strerror(rc)))
    if con != 'system_u:object_r:etc_t:s0':
        raise Exception('incorrect mode: {0}'.format(con))


# Generated at 2022-06-22 22:29:45.663810
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    for value in [0, 1, 2]:
        try:
            # TODO: write test
            assert True
        except Exception:
            # TODO: write test
            assert True
    return



# Generated at 2022-06-22 22:29:47.894990
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:29:50.834296
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/selinux/config')
    assert rc == 0
    assert con == 'system_u:object_r:selinux_config_t:s0'



# Generated at 2022-06-22 22:29:54.291465
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    if rc == 0:
        return [rc, con]
    else:
        return [rc, 'None']

# Generated at 2022-06-22 22:29:57.852906
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, result = selinux_getpolicytype()
    assert rc == 0
    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-22 22:30:07.725433
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    globals().pop('lgetfilecon_raw', None)
    cmd = "sed -i -e 's/^# SELINUX=.*/SELINUX=permissive/' /etc/selinux/config"
    args = dict(warn=False, become=True, become_user='root')
    result = module.run_command(cmd, **args)
    assert result == 0
    cmd = "setenforce 0"
    result = module.run_command(cmd, **args)
    assert result == 0
    result = module.run_command('/usr/bin/getenforce')
    assert result[1] == b"Permissive\n"

    result = os.path.abspath(module.tmpdir)
    rc, stdout = lgetfilecon_raw(result)


# Generated at 2022-06-22 22:30:10.064869
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/proc'
    rc, con = lgetfilecon_raw(path)
    print("rc=%d con=%s" % (rc, con))


# Generated at 2022-06-22 22:30:17.687048
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Verify that lgetfilecon_raw returns the correct value for /etc/shadow
    results = lgetfilecon_raw(b'/etc/shadow')
    rc = results[0]
    con = results[1]
    assert rc == 0
    assert con == b'system_u:object_r:shadow_t:s0'

    # Verify that lgetfilecon_raw returns the correct value for nonexistent file
    results = lgetfilecon_raw(b'/nonexistent')
    rc = results[0]
    con = results[1]
    assert rc == -2
    assert con == b''



# Generated at 2022-06-22 22:30:20.257647
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        assert len(selinux_getpolicytype()) == 2
    except ImportError:
        pass  # do not fail if selinux is not installed


# Generated at 2022-06-22 22:30:23.288894
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _, con = lgetfilecon_raw('/etc/shadow')
    assert con, 'Expected valid con type'



# Generated at 2022-06-22 22:30:30.915582
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for /usr/bin/passwd
    path = "/usr/bin/passwd"
    [rc, policy] = matchpathcon(path, 0)
    print("con for path: %s, rc: %s" % (path, rc))
    print("policy: %s" % policy)
    # Test for /usr/lib
    path = "/usr/lib"
    [rc, policy] = matchpathcon(path, 0)
    print("con for path: %s, rc: %s" % (path, rc))
    print("policy: %s" % policy)

# Generated at 2022-06-22 22:30:36.807448
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return

    path = '/etc/passwd'
    mode = 0o600

    rc, con = matchpathcon(path, mode)
    assert rc >= 0
    assert con == 'system_u:object_r:passwd_etc_t:s0'

    path = '/etc/sssd/sssd.conf'

    rc, con = matchpathcon(path, mode)
    assert rc >= 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-22 22:30:38.838057
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    if rc < 0:
        sys.exit('{0}, {1}'.format(rc, con))
    else:
        print('{0}: {1}'.format(rc, con))


# Generated at 2022-06-22 22:30:43.114374
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, value = lgetfilecon_raw('/etc/passwd')

    assert rc == 0, "failed to get filecon"
    assert value.find(b'unconfined_u') >= 0, "the filecon should contain unconfined_u"

# Generated at 2022-06-22 22:30:51.292176
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    We'll try to read the context of /bin/ls.  If it fails, assume selinux is
    not enabled.  If it succeeds, assume selinux is enabled.
    """
    if selinux_getenforcemode()[1] == 0:
        return False
    else:
        rc, con = matchpathcon(b'/bin/ls', 0)
        if rc == 0:
            return True
        else:
            return False

# Generated at 2022-06-22 22:30:52.557525
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'selinuxfs']

# Generated at 2022-06-22 22:30:55.699966
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    t = selinux_getenforcemode()
    assert t[0] == 0, 'test failed'
    assert t[1] == 0 or t[1] == 1, 'test failed'


# Generated at 2022-06-22 22:31:07.838970
# Unit test for function matchpathcon
def test_matchpathcon():
    _selinux_lib.matchpathcon.argtypes = None
    _selinux_lib.matchpathcon.restype = None
    _selinux_lib.matchpathcon.errcheck = None
    _selinux_lib.selabel_open.return_value = 1
    _selinux_lib.selabel_lookup.return_value = 2
    _selinux_lib.fopen.return_value = 3
    _selinux_lib.fread.return_value = "a"
    _selinux_lib.selabel_close.return_value = None
    _selinux_lib.fclose.return_value = None
    _selinux_lib.asprintf.return_value = None
    matchpathcon("x", 1)
    _selinux_lib.matchpath

# Generated at 2022-06-22 22:31:19.323289
# Unit test for function matchpathcon
def test_matchpathcon():

    output = matchpathcon("/tmp", 0)
    if output[0] == 0:
        print("Success - /tmp has context %s " % output[1])
    else:
        print("Failure - matchpathcon returned %d" % output[0])
        exit(1)

    output = matchpathcon("/tmp", 0)
    if output[0] == -1:
        print("Success - Failed to match /tmp with invalid mode %d" % output[0])
    else:
        print("Failure - matchpathcon returned %d" % output[0])
        exit(1)

    output = matchpathcon("/tmp/doesnotexist", 0)
    if output[0] == -1:
        print("Success - Failed to match /tmp/doesnotexist %d" % output[0])

# Generated at 2022-06-22 22:31:25.922141
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import re

    rc, con = lgetfilecon_raw(__file__)
    assert rc == 0
    assert isinstance(con, str), con
    if rc == 0:
        assert re.match(r'^unconfined_u:object_r:python_exec_t:s0$', con), con
    del rc, con


# Generated at 2022-06-22 22:31:31.482206
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = "test/test-file"
    path = "/usr/local/bin/" + filename
    result = lgetfilecon_raw(path)
    rc = result[0]
    if rc < 0:
        raise OSError('lgetfilecon_raw returned error.')
    elif rc == 0:
        con = result[1]
    return con

# Generated at 2022-06-22 22:31:42.251870
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # my test system with selinux enabled and enforcing
    # Security context: system_u:system_r:system_dbusd_t:s0-s0:c0.c1023
    expected_result = 'MLS', 'MCS', 'targeted'
    rc, data = selinux_getpolicytype()
    assert rc == 0, ("selinux_getpolicytype: non-zero return code %s" % rc)
    assert data in expected_result, ("selinux_getpolicytype: unexpected data '%s'. Expected one of %s" % (data, expected_result))



# Generated at 2022-06-22 22:31:45.162717
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


# Generated at 2022-06-22 22:31:48.573522
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        raise Exception('selinux_getenforcemode failed: %s' % os.strerror(rc))
    return enforcemode



# Generated at 2022-06-22 22:31:53.841904
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    status, result = selinux_getpolicytype()
    policy_type = result.strip()
    if status != 0:
        raise RuntimeError('Error in selinux_getpolicytype: ' + str(policy_type))
    if not (policy_type == 'targeted' or policy_type == 'minimum' or policy_type == 'mls'):
        raise RuntimeError('Error in selinux_getpolicytype: ' + str(policy_type))



# Generated at 2022-06-22 22:31:55.803910
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_value = selinux_getpolicytype()
    assert len(test_value) == 2
    return True


# Generated at 2022-06-22 22:31:58.505873
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    return True if (result[0] == 0 and result[1] == 0) else False


# Generated at 2022-06-22 22:32:02.871522
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, con = selinux_getenforcemode()
        assert (rc, con) == (0, 1)
    except ImportError:
        pytest.skip('ansible.module_utils.selinux.selinux_getenforcemode unit test is not available')



# Generated at 2022-06-22 22:32:08.683080
# Unit test for function matchpathcon
def test_matchpathcon():
    # The mode argument to matchpathcon should be a string containing 'r', 'w' or 'x'
    legal_modes = ["r", "w", "x"]
    illegal_modes = ["rw", "rwx", "w", "", "H", "rwxr", "rX"]
    for mode in legal_modes:
        assert matchpathcon("/etc/shadow", mode)[0] >= 0
    for mode in illegal_modes:
        assert matchpathcon("/etc/shadow", mode)[0] < 0

# Generated at 2022-06-22 22:32:10.302034
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    if enforcemode is None:
        assert False, 'enforcemode should not be None'
    else:
        assert True

# Generated at 2022-06-22 22:32:23.163313
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.compat.module_utils.selinux.libselinux import selinux_getpolicytype

    with patch('ansible_collections.ansible.community.tests.unit.compat.module_utils.selinux.libselinux._selinux_lib') as mock_selinux_lib:
        mock_selinux_lib.selinux_getpolicytype.return_value = 0
        mock_selinux_lib.freecon.return_value = 0
        actual = selinux_getpolicytype()

# Generated at 2022-06-22 22:32:30.030481
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # For unit test to be useful, a '/' must be labelled as an tmpfs
    # Perhaps a tmpfs could be created for the test
    # For now, just check that the function returns [0, None]
    path = b'/'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is None

    # Must raise TypeError with invalid type argument
    path = 1
    try:
        rc, con = lgetfilecon_raw(path)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 22:32:31.455262
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-22 22:32:33.534756
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert isinstance(selinux_getpolicytype(), list)



# Generated at 2022-06-22 22:32:36.824819
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # If a SELinux boolean is set, then selinux_getenforcemode should be
    # returning an `enforcemode` value of 1
    rc, enforcemode = selinux_getenforcemode()
    if enforcemode:
        assert enforcemode == 1