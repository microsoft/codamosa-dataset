

# Generated at 2022-06-22 22:22:36.430676
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, pathcon = matchpathcon('/tmp', 0)
    assert rc == 0
    assert pathcon == 'usr_t'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:22:43.275329
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        is_selinux_enabled()
    except OSError:
        return False

    fd = open("/tmp/test_ansible_selinux", 'w')
    fd.close()
    fcon, status = lgetfilecon_raw("/tmp/test_ansible_selinux")
    os.remove("/tmp/test_ansible_selinux")
    return [fcon, status]


# Generated at 2022-06-22 22:22:45.339994
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rv = selinux_getenforcemode()
    if rv[0] == 0:
        assert rv[1] in (-1, 0, 1)



# Generated at 2022-06-22 22:22:53.496984
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkstemp
    from os import unlink, chmod, stat

    (fd, tmpfile) = mkstemp()
    st = stat(tmpfile)
    os.fchmod(fd, st.st_mode | 0o777)
    os.close(fd)

    try:
        assert isinstance(matchpathcon(tmpfile, 0), list)
        assert isinstance(matchpathcon(tmpfile, 0)[0], int)
        assert isinstance(matchpathcon(tmpfile, 0)[1], str)
    finally:
        unlink(tmpfile)


# Generated at 2022-06-22 22:22:54.694721
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc = selinux_getpolicytype()
    assert rc[1] == 'targeted'

# Generated at 2022-06-22 22:22:57.592425
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Testing function selinux_getenforcemode")
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)


# Generated at 2022-06-22 22:23:01.788619
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "./testfile"
    file = open(path, "w+")
    file.close()
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    assert rc == 0
    assert con.value is not None
    os.remove(path)
    _selinux_lib.freecon(con)



# Generated at 2022-06-22 22:23:05.739461
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filePath = '/var/log'
    rc, con = lgetfilecon_raw(filePath)
    assert rc == 0
    assert 'system_u:object_r:var_log_t:s0' == con

# Generated at 2022-06-22 22:23:10.238950
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_input = b'/usr/bin/test'
    rc, out = selinux_getenforcemode()
    assert rc == 0, 'return code not equal to 0'
    # assert out == test_input.decode(), "selinux_getenforcemode failed"


# Generated at 2022-06-22 22:23:15.195872
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        print('lgetfilecon_raw({0}): {1}: {2}'.format(path, rc, con))
    else:
        print('lgetfilecon_raw({0}): {1}'.format(path, con))


if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:23:26.861137
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux_test import SelinuxTest
    try:
        import nose
    except ImportError:
        raise SkipTest("test_selinux_getpolicytype skipped: nose unavailable")

    if not hasattr(nose, 'loader'):
        raise SkipTest("test_has_capability skipped: nose.loader unavailable")

    if not hasattr(nose.loader, 'TestLoader'):
        raise SkipTest("test_selinux_getpolicytype skipped: nose.loader.TestLoader unavailable")

    # These tests are not unit tests, but they need to be run during unit tests, so they
    # use the ctypes mockup framework to run them

# Generated at 2022-06-22 22:23:33.659540
# Unit test for function matchpathcon
def test_matchpathcon():
    if 'selinux' not in sys.modules:
        return
    import tempfile

    tempdir = tempfile.mkdtemp()
    try:
        filename = tempfile.mkstemp(dir=tempdir)[1]
        con = matchpathcon(tempdir, os.R_OK)[1]
        print(con)
        con = matchpathcon(filename, os.R_OK)[1]
        print(con)
    finally:
        os.remove(filename)
        os.rmdir(tempdir)



# Generated at 2022-06-22 22:23:38.446708
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test function matchpathcon()"""
    rc, con = matchpathcon("/etc", 0)
    if rc == 0:
        print("Security Context for '/etc' is:", con)
    else:
        print("Get Security Context for '/etc' failed, error message:", os.strerror(rc))
    assert rc == 0


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:23:40.207376
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result == [0, 1]


# Generated at 2022-06-22 22:23:50.764937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Testing lgetfilecon_raw')
    modname = 'system_u'
    classname = 'object_r'

    testdir = '/tmp/ansible_selinux_testdir'
    os.makedirs(testdir)
    try:
        lsetfilecon_raw(None, '{0}:{1}'.format(modname, classname))
        [rc, con] = lgetfilecon_raw(testdir)
        assert rc == 0 and con == '{0}:{1}'.format(modname, classname)
    finally:
        os.rmdir(testdir)



# Generated at 2022-06-22 22:23:59.180201
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: check these values
    #   assert rc == 1, "unexpected nonzero rc"
    #   assert con == b'system_u:system_r:unconfined_t:s0-s0:c0.c1023', "unexpected secontext value"
    rc, con = matchpathcon(b'/etc/anacrontab', 0)  # mode is ignored, use 0
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))



# Generated at 2022-06-22 22:24:06.118703
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/mydir/myfile'
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        raise Exception("Error calling matchpathcon: " + str(rc))
    if con != 'system_u:object_r:unlabeled_t':
        raise Exception("Error returned from matchpathcon: " + con)
    print("matchpathcon OK")


# Generated at 2022-06-22 22:24:07.466788
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # assert selinux_getpolicytype() == [0, 'targeted']
    pass

# Generated at 2022-06-22 22:24:10.698811
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils._text import to_text

    print(to_text(selinux_getenforcemode()))

# Generated at 2022-06-22 22:24:17.797960
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/log/audit/audit.log', 0) == [0, 'system_u:object_r:auditd_log_t:s0']
    assert matchpathcon('/var/log/audit/audit.log', os.O_RDONLY) == [0, 'system_u:object_r:auditd_log_t:s0']
    assert matchpathcon('/var/log/audit/audit.log', os.O_RDWR) == [0, 'system_u:object_r:auditd_log_t:s0']

# Generated at 2022-06-22 22:24:27.934539
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/tmp/foo', 1)
    assert result == [0, 'system_u:object_r:tmp_t']
    result = matchpathcon('/tmp/foo', 0)
    assert result == [0, 'system_u:object_r:tmp_t']
    result = matchpathcon('/tmp/foo', -1)
    assert result == [0, 'system_u:object_r:tmp_t']
    result = matchpathcon('/tmp/foo', 2)
    assert result == [0, 'system_u:object_r:tmp_t']
    try:
        matchpathcon('/tmp/foo', 3)
    except OSError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 22:24:35.147742
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils._text import to_text
    # Testing lgetfilecon_raw on selinux disabled system
    if not is_selinux_enabled():
        assert lgetfilecon_raw("/bin/ls") == [-1, ""]
        assert lgetfilecon_raw("/") == [-1, ""]
    else:
        assert lgetfilecon_raw("/bin/ls") == [0, b"system_u:object_r:bin_t:s0\x00"]
        assert lgetfilecon_raw("/") == [0, b"system_u:object_r:root_t:s0\x00"]

# Generated at 2022-06-22 22:24:44.410686
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        # check a path that should have a policy match (note: mode != os.stat.st_mode)
        mode = getattr(os.stat(f.name), 'st_mode', 0)
        rc, con = matchpathcon(f.name, mode)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'

        # check a path that should not have a policy match
        rc, con = matchpathcon('/proc/self/cmdline', mode)
        assert rc == 1
        assert 'Could not load policy' in con



# Generated at 2022-06-22 22:24:55.199918
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Testing function with Selinux disabled
    sys.argv = ['', '-p', 'selinux.selinux_getenforcemode()']
    os.environ['ANSIBLE_LIBRARY'] = '../library'
    os.environ['ANSIBLE_MODULE_UTILS'] = '../module_utils'
    sys.path.insert(0, '..')

    # If the Valgrind support for Memcheck is not enabled within the Valgrind tool then
    # the leak_check command is not defined and the code will raise an
    # exception when we attempt to turn it on below.
    #
    # Added the try/except around the code the catches the exception if
    # it was raised and terminates the unit test.

# Generated at 2022-06-22 22:24:58.720866
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if selinux_getpolicytype()[0] == 0:
        assert selinux_getpolicytype()[1] in ['targeted', 'mls']
    else:
        # Handle the case where no selinux policy is loaded
        assert selinux_getpolicytype()[1] is None

# Generated at 2022-06-22 22:25:02.523916
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    _, context = lgetfilecon_raw(os.__file__)
    assert context is not None


# Generated at 2022-06-22 22:25:06.792403
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    with tempfile.NamedTemporaryFile() as test_f:
        pass
    rc, con = _lgetfilecon_raw(test_f.name)
    assert rc == 0
    assert isinstance(con, str)
    assert 'unlabeled_t' in con

# Generated at 2022-06-22 22:25:15.104026
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.basic import AnsibleModule

    # Get parameters
    argument_spec = dict(
        data=dict(type='str', required=True),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
    )

    # Execute the function
    rc, res = selinux_getpolicytype()

    # Handle results
    if module._diff:
        module.exit_json(rc=rc, changed=False, data=res)
    else:
        module.exit_json(rc=0, changed=False)

# Generated at 2022-06-22 22:25:17.925553
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    func = sys._getframe().f_code.co_name
    res = getattr(sys.modules[__name__], func)()
    assert res[0] != -1, 'return code is not a success'
    assert res[1] in [0, 1, 2], 'return value is not in expected range'



# Generated at 2022-06-22 22:25:25.267278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case 1
    # If a path passed as argument contains a symbolic link, it is followed and the label of the underlying object is returned
    path = "/usr/share/locale/locale.alias"
    path_link = "/usr/share/locale/en_US/locale.alias"
    assert lgetfilecon_raw(path)[1] == lgetfilecon_raw(path_link)[1]

    # Test case 2
    # If the file has no label, return none
    path_nolabel = "/etc/password"
    assert lgetfilecon_raw(path_nolabel)[1] is None



# Generated at 2022-06-22 22:25:28.569024
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    if rc >= 0:
        print('matchpathcon: %s' % con)
    else:
        print('error: %s' % con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:25:30.565193
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert 0 <= enforcemode <= 3


# Generated at 2022-06-22 22:25:32.174895
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

# Generated at 2022-06-22 22:25:37.332660
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
    except NotImplementedError as e:
        print(e)
        assert False
    assert rc == 0
    assert enforcemode == 0


# Generated at 2022-06-22 22:25:40.423994
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    print("Function selinux_getpolicytype returned", rc)
    print("Function selinux_getpolicytype returned", con)


# Generated at 2022-06-22 22:25:47.453735
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print("SELinux is not enabled.")
        exit(0)
    ret = lgetfilecon_raw("/etc/redhat-release")
    [rc, con] = ret
    if rc == -1:
        print("Failed to get context of /etc/redhat-release")
        exit(-1)
    print("The context of /etc/redhat-release is {0}".format(con))
    # The context of /etc/redhat-release is system_u:object_r:etc_t:s0

    ret = matchpathcon("/etc/redhat-release", 0)
    [rc, con] = ret
    if rc == -1:
        print("Failed to call matchpathcon")
        exit(-1)

# Generated at 2022-06-22 22:25:48.573264
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if selinux_getpolicytype()[1] == 'targeted':
        return True
    else:
        return False


# Generated at 2022-06-22 22:25:51.439438
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_rc = 0
    expected_value = 'targeted'
    [rc, value] = selinux_getpolicytype()

    assert rc == expected_rc
    assert value == expected_value

# Generated at 2022-06-22 22:26:03.687692
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import socket
    import tempfile
    import shutil

    # Skip this unit test if selinux is not enabled
    if not is_selinux_enabled():
        return

    # Skip this unit test if selinux is disabled
    if not is_selinux_mls_enabled():
        return

    # Skip this unit test if the policy doesn't support selinux
    if not security_policyvers():
        return

    # Skip this unit test if selinux is disabled
    if not security_getenforce():
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:26:15.691507
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import pytest
    from ctypes import c_char_p

    me = sys.modules[__name__]

    # monkey patching
    selinux_getpolicytype = me.selinux_getpolicytype
    t_selinux_getpolicytype = me._selinux_lib.selinux_getpolicytype
    me._selinux_lib.selinux_getpolicytype = lambda p: 0

    con = c_char_p(b'targeted')
    try:
        rc, con = selinux_getpolicytype()
        assert rc == 0
        assert con == 'targeted'

        rc, con = selinux_getpolicytype()
        assert rc == 0
        assert con == 'targeted'
    finally:
        me._selinux_lib.selinux_getpolicytype = t_

# Generated at 2022-06-22 22:26:21.058148
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Return rc and mode values
    mode = selinux_getenforcemode()

    # Test if enforcemode is returned correctly
    if mode[0] > 0 and (mode[1] == 0 or mode[1] == 1):
        print("Test Passed: The returned mode is correct")
    else:
        print("Test Failed: The returned mode is not correct")
        exit(1)


# Generated at 2022-06-22 22:26:31.249506
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils.selinux import matchpathcon

    with patch('ansible_collections.ansible.community.plugins.module_utils.selinux.matchpathcon') as mock_matchpathcon:
        mock_matchpathcon.return_value = [0, 'system_u:object_r:sbin_exec_t:s0']
        mock_matchpathcon.side_effect = OSError
        mock_matchpathcon.side_effect = [0, 0]
        mock_matchpathcon.side_effect = [1, 0]

# Generated at 2022-06-22 22:26:38.402108
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    if con:
        print(con)
    else:
        print("Can't get context of: %s" % path)
        print("Try setenforce 1 before running this test")
        print("Expected: %s" % con)
        print("Got: %s" % con)


# Generated at 2022-06-22 22:26:49.801136
# Unit test for function matchpathcon
def test_matchpathcon():
    def match_fn(path, mode):
        import subprocess
        cmd = ['matchpathcon', '-V', str(mode), path]
        eline = subprocess.check_output(cmd)
        eline = str(eline)
        eline = eline.strip()
        print(eline)
        return eline

    # byte string version
    path = b'/usr/bin/awk'
    mode = 0
    assert matchpathcon(path, mode) == [0, match_fn(path, mode)]

    # unicode string version
    path = u'/usr/bin/awk'
    mode = 0
    assert matchpathcon(path, mode) == [0, match_fn(path, mode)]

# Generated at 2022-06-22 22:26:52.495528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import socket
    rc, con = lgetfilecon_raw(socket.__file__)
    assert rc == 0 and con == 'system_u:object_r:lib_t:s0'


# Generated at 2022-06-22 22:26:55.009365
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-22 22:26:58.911883
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test valid result
    [rc, con] = matchpathcon("/etc/hosts", 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test invalid path
    [rc, con] = matchpathcon("/invalid/path", 0)
    assert rc == -1
    assert con == "system_u:object_r:etc_t:s0"

# Generated at 2022-06-22 22:27:02.505508
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0, 'selinux getpolicytype failed'
    assert policytype[1] != '', 'selinux getpolicytype string is empty'



# Generated at 2022-06-22 22:27:06.878819
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Sanity test for function selinux_getpolicytype
    """
    [rc, type] = selinux_getpolicytype()
    assert rc >= 0
    assert type is not None
    assert isinstance(type, str)



# Generated at 2022-06-22 22:27:14.065200
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/tmp/'
    test_path_2 = u'/tmp/'
    test_path_3 = '/tmp/'

    _, result1 = lgetfilecon_raw(test_path)
    assert isinstance(result1, str)
    _, result2 = lgetfilecon_raw(test_path_2)
    assert isinstance(result2, str)
    _, result3 = lgetfilecon_raw(test_path_3)
    assert isinstance(result3, str)
    assert result1 == result2 == result3


# Generated at 2022-06-22 22:27:19.366625
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Return code, should be 0
    # 0 - enforcing
    # 1 - permissive
    # 2 - disabled
    status = selinux_getenforcemode()
    if status[0] == 0:
        assert status[1] in (0, 1, 2)
    else:
        assert False, "selinux_getenforcemode() failed with errno " + str(status[0])



# Generated at 2022-06-22 22:27:27.060473
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # return context only if selinux is enabled
    [rc, context] = lgetfilecon_raw(b'/etc/hosts')
    if is_selinux_enabled():
        assert rc == 0 and context is not None and context.startswith(b'unconfined_')

    # returns a tuple of (rc, string)
    [rc, context] = lgetfilecon_raw(b'/tmp/does_not_exist')
    assert rc == -1 and context is None



# Generated at 2022-06-22 22:27:31.130111
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_args = (None, )
    with pytest.raises(TypeError) as exc:
        selinux_getpolicytype(*test_args)
    assert 'Wrong parameter count' in to_native(exc.value)



# Generated at 2022-06-22 22:27:32.690898
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:27:34.806211
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()

    assert policytype is not None
    assert policytype == 'targeted'

# Generated at 2022-06-22 22:27:38.558565
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/tmp', 0)
    if rc == 0:
        print('Matchpathcon returns 0 on success')
    else:
        raise Exception('Matchpathcon failed with error code %d' % rc)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:27:49.920958
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import (
        is_selinux_enabled,
        is_selinux_mls_enabled,
        lgetfilecon_raw,
        selinux_getenforcemode,
        security_getenforce,
        security_policyvers)

    # lgetfilecon_raw requires selinux to be enabled
    if not is_selinux_enabled():
        sys.exit(0)

    # selinux_getenforcemode will always return an error of 0
    # when selinux is enabled even if permissive mode is set
    # skip this test if in permissive mode
    if (selinux_getenforcemode()[1] == 0):
        sys.exit(0)

    # lgetfilecon_raw requires selinux to be not in permissive mode

# Generated at 2022-06-22 22:27:53.019577
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    assert res[0] == 0
    assert res[1] in (0, 1)

# Generated at 2022-06-22 22:27:56.975018
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("selinux_getpolicytype")
    rc, policytype = selinux_getpolicytype()
    print("- rc={0}".format(rc))
    print("- policytype={0}".format(policytype))



# Generated at 2022-06-22 22:28:04.821163
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc', 0)[0] == 0
    assert matchpathcon('/etc', os.R_OK)[0] == 0
    assert matchpathcon('/etc/passwd', 0)[0] == 0
    assert matchpathcon('/etc/passwd', os.R_OK)[0] == 0
    assert matchpathcon('/etc/passwd', os.W_OK)[0] == -1
    assert matchpathcon('/foo/bar/baz', 0)[0] == -1


# Generated at 2022-06-22 22:28:05.754683
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy_type] = selinux_getpolicytype()

    assert rc == -1
    assert policy_type == ""


# Generated at 2022-06-22 22:28:10.274533
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import NamedTemporaryFile, mkdtemp
    from ansible.module_utils._text import to_native
    from shutil import rmtree

    fd = NamedTemporaryFile(delete=False, mode='w')
    fd.close()
    temp_file = fd.name
    rc, s = lgetfilecon_raw(temp_file)
    assert rc == 0, "rc = {}".format(rc)
    assert s.startswith("unconfined_u:object_r:"), "s = {}".format(s)
    rmtree(temp_file)

    temp_dir = mkdtemp()
    rc, s = lgetfilecon_raw(temp_dir)
    assert rc == 0, "rc = {}".format(rc)

# Generated at 2022-06-22 22:28:18.890869
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # https://www.ibm.com/support/knowledgecenter/en/ssw_aix_72/com.ibm.aix.genprogc/lgetfilecon.htm
    os.environ["LANG"]="C"
    os.environ["LC_ALL"]="C"

    file_path = "/usr/bin/bash"
    result = lgetfilecon_raw(file_path)
    assert result == [0, 'unconfined_u:object_r:bin_t:s0']

    file_path = "/etc/rc.d/init.d/acct"
    result = lgetfilecon_raw(file_path)
    assert result == [0, 'system_u:object_r:svc_initrc_exec_t:s0']


# Generated at 2022-06-22 22:28:20.383917
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-22 22:28:24.770289
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with some random directory
    p = '/tmp/ansible'
    rc = matchpathcon(p, 0)
    print("matchpathcon return code : %d" %rc[0])
    print("matchpathcon value code :%s" %rc[1])

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:26.918786
# Unit test for function matchpathcon
def test_matchpathcon():
    path = os.path.expanduser('~')
    (rc, con) = matchpathcon(path, 0)
    print(rc, con)

# Generated at 2022-06-22 22:28:27.894220
# Unit test for function matchpathcon
def test_matchpathcon():
    return matchpathcon('/etc/shadow', 0)



# Generated at 2022-06-22 22:28:30.962251
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'


# Generated at 2022-06-22 22:28:33.519865
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-22 22:28:35.360810
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, con = selinux_getenforcemode()
    assert rc == 0
    assert con == 0


# Generated at 2022-06-22 22:28:39.512951
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        (rc, enforce) = selinux_getenforcemode()
        if rc:
            return 1
        else:
            if enforce == 1:
                return 0
            else:
                return 1
    except NameError:
        return 1


# Generated at 2022-06-22 22:28:48.072846
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import unittest

    class TestLgetfilecon_raw(unittest.TestCase):

        def test_lgetfilecon_raw(self):
            rc, value = lgetfilecon_raw('/')
            self.assertEqual(rc, 0)
            # the value should be a string like 'system_u:object_r:root_t:s0'
            self.assertEqual(type(value), str)
            rc, value = lgetfilecon_raw('/etc')
            self.assertEqual(rc, 0)
            # the value should be a string like 'system_u:object_r:etc_t:s0'
            self.assertEqual(type(value), str)
            # test invalid path
            rc, value = lgetfilecon_raw('/invalid_path')
           

# Generated at 2022-06-22 22:28:52.878208
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test function selinux_getenforcemode
    '''
    mode = selinux_getenforcemode()[1]
    assert (mode == 0 or mode == 1), "selinux_getenforcemode returned invalid mode {0} for path /".format(mode)


# Generated at 2022-06-22 22:28:56.737822
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon("/etc/services", 0)
    assert r[0] == 0, 'Failed {}'.format(r[0])
    print("PASSED {0} {1}".format("matchpathcon", r[1]))

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-22 22:29:06.567140
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    class file(object):
        def __init__(self, name):
            self.name = name

        def fileno(self):
            return 1


# Generated at 2022-06-22 22:29:08.940052
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import json
    res = selinux_getenforcemode()
    print(json.dumps(res, indent=2))



# Generated at 2022-06-22 22:29:16.627979
# Unit test for function matchpathcon
def test_matchpathcon():
    for path, con in [
        ('/', 'system_u:object_r:root_t:s0'),
        ('/selinux', 'system_u:object_r:root_t:s0'),
        ('/dev', 'system_u:object_r:device_t:s0'),
        ('/tmp', 'system_u:object_r:tmp_t:s0'),
    ]:
        rc, matchcon = matchpathcon(path, 0)
        assert rc == 0
        assert matchcon == con



# Generated at 2022-06-22 22:29:25.960650
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    from ctypes import CDLL
    import ctypes

    libselinux = CDLL('libselinux.so.1', use_errno=True)
    libselinux.matchpathcon.argtypes = (ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(ctypes.c_char_p))
    libselinux.matchpathcon.restype = ctypes.c_int
    libselinux.freecon.argtypes = (ctypes.c_char_p, )

    def check_rc(rc):
        if rc < 0:
            errno = ctypes.get_errno()
            raise OSEr

# Generated at 2022-06-22 22:29:28.125523
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import __builtin__
    try:
        __builtin__.open = __builtin__._original_open
    except AttributeError:
        pass
    rc, mode = selinux_getenforcemode()
    assert mode in [0, 1, 2]
    assert rc == 0



# Generated at 2022-06-22 22:29:33.377328
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw('/etc/selinux/config')
    assert ret[0] == 0, 'return code should be 0, but is ' + str(ret[0])
    assert ret[1] != '', 'return context string should not be empty'


# Generated at 2022-06-22 22:29:36.877239
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
     path = '/tmp/abc'
     rc, con = lgetfilecon_raw(path)
     assert rc == 0


# Generated at 2022-06-22 22:29:41.041736
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/sys', 0)
    assert ret == [0, 'system_u:object_r:sysfs_t:s0']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:44.558096
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0x8000
    rc = matchpathcon(path, mode)
    print(rc)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:46.697122
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/sys', 0)
    assert rc >= 0
    assert con == 'system_u:object_r:sysfs_t'

# Generated at 2022-06-22 22:29:52.602336
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:device_t:s0']
    assert matchpathcon('/etc/gshadow', 0) == [0, 'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/etc/gshadow', 1) == [0, 'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/etc/gshadow', 2) == [0, 'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-22 22:29:54.147182
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw('/')[1] == 'unconfined_u:object_r:root_t:s0')


# Generated at 2022-06-22 22:29:58.948052
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr'
    rc, con_value = lgetfilecon_raw(path)
    print ("Return code: {0}".format(rc))
    print ("Security context: {0}".format(con_value))


# Generated at 2022-06-22 22:30:10.578297
# Unit test for function matchpathcon
def test_matchpathcon():

    def run_matchpathcon(rc, path, mode):
        try:
            real_rc, con = matchpathcon(path, mode)
            assert real_rc == rc, 'Expected return code {0}, got {1}'.format(rc, real_rc)
            if rc == 0:
                assert con is not None and con != '', 'Expected a non-empty context'
            else:
                assert con is None or con == '', 'Expected empty context'
        finally:
            del con

    run_matchpathcon(0, '/etc/passwd', 0)
    run_matchpathcon(0, '/etc/passwd', 511)
    run_matchpathcon(-1, '/etc/foo/bar', 0)
    run_matchpathcon(-1, '/etc/foo/bar', 511)
   

# Generated at 2022-06-22 22:30:16.856285
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for function lgetfilecon_raw
    """
    path = '/etc/passwd'
    rc = 0
    err = 'Success'
    answer = [rc, err]
    assert lgetfilecon_raw(path) == answer
    path = '/etc/passwd1'
    rc = -1
    err = 'No such file or directory'
    answer = [rc, err]
    assert lgetfilecon_raw(path) == answer



# Generated at 2022-06-22 22:30:21.226765
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Testing lgetfilecon_raw() function.
    """

    result, filecon = lgetfilecon_raw('/')
    if result != 0:
        raise Exception('lgetfilecon_raw call failed')
    print(filecon)



# Generated at 2022-06-22 22:30:24.906870
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2
    if not isinstance(selinux_getpolicytype()[1], str):
        raise TypeError('selinux_getpolicytype() implementation returns non string list item')

# Generated at 2022-06-22 22:30:29.527861
# Unit test for function matchpathcon
def test_matchpathcon():
    # This is a smoke test for ctypes wrapper for matchpathcon
    # and doesn't validate correctness of the result
    rc, con = matchpathcon("/", 0)
    assert rc == 0, con
    rc, con = matchpathcon("/", os.R_OK)
    assert rc == 0, con

# Generated at 2022-06-22 22:30:32.092273
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = selinux_getenforcemode()
    assert rc[0] == 0
    assert rc[1] == 1


# Generated at 2022-06-22 22:30:36.103430
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc', 0)[0] == 0
    assert matchpathcon(b'/dev/null', 0)[0] == 0
    assert matchpathcon(b'/tmp', 0)[0] == 0
    assert matchpathcon(b'/sys', 0)[0] == 0
    assert matchpathcon(b'/opt/foo', 0)[0] == 3

# Generated at 2022-06-22 22:30:40.487345
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print("SELinux is not enabled")
        ret = 0
    else:
        print("SELinux is enabled")
        ret = 1
    return ret



# Generated at 2022-06-22 22:30:44.782220
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK

    rc, con = matchpathcon(path, mode)
    print(rc, con)

    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-22 22:30:52.474028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Sanity check
    if not is_selinux_enabled():
        return

    from ansible.module_utils.selinux import get_context_from_string

    (rc, context) = lgetfilecon_raw("/etc/hosts")
    assert rc == 0, "lgetfilecon_raw failed"

    # This will be different on different machines
    assert get_context_from_string(context), "get_context_from_string failed"

# Generated at 2022-06-22 22:30:54.371866
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    actual_output = selinux_getpolicytype()
    print("Policy Type: {0}".format(actual_output[1]))


# Generated at 2022-06-22 22:31:00.877858
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for invalid path
    rc, con = matchpathcon('/invalid/path', 0)
    assert rc == -1, "Invalid path should return -1"

    # try to get the context of some directories
    rc, con = matchpathcon('/var', 0)
    assert rc == 0, "Path with no error should return 0"
    assert con == 'var_t', "Context of /var should be 'var_t'"

    rc, con = matchpathcon('/etc', 0)
    assert rc == 0, "Path with no error should return 0"
    assert con == 'etc_t', "Context of /etc should be 'etc_t'"

    rc, con = matchpathcon('/usr/local', 0)
    assert rc == 0, "Path with no error should return 0"

# Generated at 2022-06-22 22:31:10.409853
# Unit test for function matchpathcon
def test_matchpathcon():
    # On success, matchpathcon returns 0.
    # On error, -1 is returned, and errno is set appropriately.
    expected_return_code = 0
    expected_return_value = 'system_u:object_r:usr_t:s0'
    test_path = '/usr/foo'

    return_code, return_value = matchpathcon(test_path, 0)
    assert return_code == expected_return_code
    assert return_value == expected_return_value

    # Test failure for non existant path
    return_code, return_value = matchpathcon('/this_is_not_real', 0)
    assert return_code == -1
    assert return_value is None

    # Test failure for path to directory
    test_path = '/usr'
    return_code, return_value = matchpath

# Generated at 2022-06-22 22:31:16.776239
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Unit test for function selinux_getenforcemode

    Ensure function returns non-zero return code
    if SELinux is not enabled.  Otherwise, ensure
    the correct return code is returned.
    """

    if is_selinux_enabled() == 0:
        assert selinux_getenforcemode() == [1, 0]
    else:
        assert selinux_getenforcemode() == [0, security_getenforce()]



# Generated at 2022-06-22 22:31:19.276841
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon("/var/empty", 0)
    assert rc[0] == 0, "matchpathcon should just return with 0"

# Generated at 2022-06-22 22:31:25.880481
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ctypes import c_int
    _enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(_enforcemode))
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    return rc, _enforcemode

# Generated at 2022-06-22 22:31:31.094630
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/passwd")[0] == 0
    assert lgetfilecon_raw("/etc/passwd")[1].startswith("system_u:object_r:etc_t")
    assert lgetfilecon_raw("/etc/test_file")[0] == -1


# Generated at 2022-06-22 22:31:35.288051
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0, "getpolicytype call failed with: {0}".format(rc)
    assert policy, "Policy could not be derived from system"

# Generated at 2022-06-22 22:31:38.489393
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert [0, 'targeted'] == selinux_getpolicytype()

# Generated at 2022-06-22 22:31:41.858445
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Verify that we can get the policy type
    """
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type == 'targeted'

# Generated at 2022-06-22 22:31:52.160126
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, context = matchpathcon("/test/test_matchpathcon_file.txt", 0)
    assert rc >= 0
    rc, context = matchpathcon("/test/test_matchpathcon_file.txt", os.R_OK)
    assert rc >= 0
    rc, context = matchpathcon("/test/test_matchpathcon_file.txt", os.W_OK)
    assert rc >= 0
    rc, context = matchpathcon("/test/test_matchpathcon_file.txt", os.X_OK)
    assert rc >= 0
    rc, context = matchpathcon("/test/test_matchpathcon_file.txt", os.R_OK|os.W_OK|os.X_OK)
    assert rc >= 0

# Generated at 2022-06-22 22:31:55.699745
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from py.test import raises
    from ansible.module_utils.selinux import selinux_getpolicytype

    [rc, policytype] = selinux_getpolicytype()
    assert(rc == 0)



# Generated at 2022-06-22 22:31:57.574645
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-22 22:31:59.786058
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcement = selinux_getenforcemode()
    assert rc == 0
    assert type(enforcement) is int

# Generated at 2022-06-22 22:32:02.017163
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/hosts")[1] == "system_u:object_r:etc_t:s0"

# Generated at 2022-06-22 22:32:12.643906
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''Testing our new wrapper function'''
    _selinux_lib.is_selinux_enabled.restype = c_int

    # Python 2 and 3 call the same function
    if not _selinux_lib.is_selinux_enabled():
        print('selinux is not enabled!')
        return

    # strip trailing newline
    def rstrip_nl(line):
        return line.rstrip('\n')

    # strip trailing context sentinel
    def strip_context_sentinel(line):
        return line.rsplit('.', 1)[0]


# Generated at 2022-06-22 22:32:19.418393
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import ctypes

    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(0), ctypes.py_object())


# Generated at 2022-06-22 22:32:20.818063
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:32:31.023337
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.path.insert(0, os.path.normpath(os.path.join(os.path.dirname(__file__), '..')))
    import test_lib_selinux

    test_lib_selinux.assert_equal(matchpathcon(b'/foo/bar/baz', 0), [0, 'system_u:object_r:unlabeled_t:s0'])
    test_lib_selinux.assert_equal(matchpathcon(b'/shadow', 0), [0, 'system_u:object_r:shadow_t:s0'])
    test_lib_selinux.assert_equal(matchpathcon(b'/etc/network/interfaces.d', 0), [0, 'system_u:object_r:etc_t:s0'])
    test_lib_

# Generated at 2022-06-22 22:32:34.002549
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    r, mode = selinux_getenforcemode()
    assert r == 0
    assert mode in [0, 1, 2]
