

# Generated at 2022-06-22 22:22:40.601886
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0, 'selinux_getenforcemode returned failure code: {0}'.format(rc)
    assert enforcemode in [0, 1, 2], 'selinux_getenforcemode returned invalid enforcemode: {0}'.format(enforcemode)



# Generated at 2022-06-22 22:22:44.583463
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    if res[0] == 0:
        print("selinux_getenforcemode() returned mode %s" % res[1])
    else:
        raise Exception("selinux_getenforcemode() returned error code %s" % res[0])


# Generated at 2022-06-22 22:22:54.824555
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import sys
    import tempfile

    arg0 = None
    arg1 = sys.executable
    arg2 = '/etc/shadow'
    arg3 = '/bin/sh'
    arg4 = '/usr/bin/python'
    arg5 = '/usr/bin/ls'

# Generated at 2022-06-22 22:22:56.011267
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) == list


# Generated at 2022-06-22 22:23:03.182524
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    def is_type(t1, t2):
        return (t1.startswith(b'system_u:') and t2.startswith(b'system_u:')) or t1 == t2

    try:
        is_enabled = is_selinux_enabled()
    except:
        is_enabled = None

    if is_enabled:
        rc, con = selinux_getpolicytype()
        if not rc:
            if is_type(con, b'targeted'):
                print("selinux type: targeted")
            elif is_type(con, b'minimal'):
                print("selinux type: minimal")
            else:
                print("selinux type: unknown")
        else:
            print("selinux_getpolicytype failed")

# Generated at 2022-06-22 22:23:06.098481
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print('rc: %d' % rc)
    print('enforcemode: %d' % enforcemode)


# Generated at 2022-06-22 22:23:13.693483
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    # Create a file with a temporary file so that we can call matchpathcon on it.
    temp_fd, temp_file = tempfile.mkstemp()
    os.close(temp_fd)

    try:
        # Call matchpathcon on a file
        rc, con = matchpathcon(temp_file, os.stat(temp_file).st_mode)
        assert rc == 0, 'matchpathcon failed'
        assert con, 'No context returned'
        print("Context returned: %s" % con)

    finally:
        os.unlink(temp_file)



# Generated at 2022-06-22 22:23:20.049593
# Unit test for function matchpathcon
def test_matchpathcon():
    # pylint: disable=protected-access
    import os
    from ansible_collections.ansible.community.plugins.module_utils._text import to_text
    # NB: this test will only work when run in the context of an SELinux environment
    assert _selinux_lib.is_selinux_enabled() > 0
    assert _selinux_lib.is_selinux_mls_enabled() > 0
    # get the default context for this dir
    rc, con = matchpathcon(__file__, 0)
    assert con
    assert type(con) == type(to_text(''))
    assert rc == 0
    assert con.startswith('unconfined_u:object_r')
    # the below test matchpathcon_fini() error handling, by trying to get the context for

# Generated at 2022-06-22 22:23:22.822592
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Call function lgetfilecon_raw
    rc, output = lgetfilecon_raw('/tmp/file')

    print(rc)
    print(output)


# Generated at 2022-06-22 22:23:34.443238
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkstemp

    fd, _path = mkstemp()
    res = matchpathcon(_path, 0)
    assert res[0] >= 0, 'failed to get labels for {0}'.format(_path)
    assert ':system_r:{0}:s0'.format(_path) in res[1]
    assert ':file:file_t:s0' in res[1], '{0} does not have "file_t" label'.format(_path)
    assert ':object_r:instance_device_t' in res[1], '{0} does not have "instance_device_t" label'.format(_path)

    res = matchpathcon('/var/www/html/index.html', 0)

# Generated at 2022-06-22 22:23:36.490349
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert not rc
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-22 22:23:40.418178
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/some-file-that-doesnt-exist') == [-1, None]


__all__ = [name for name in globals() if name.startswith('selinux_')]

# Generated at 2022-06-22 22:23:46.487543
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/ansible/hosts"
    file_mode = 0
    [rc, con] = matchpathcon(path, file_mode)
    if rc != 0:
        print("Failed to matchpathcon rc is ", rc)
        return
    print("Successfully matchpathcon and con is ", con)



# Generated at 2022-06-22 22:23:54.590582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/tmp/confile'
    file_con = 'system_u:object_r:tmp_t:s0'

    def cleanup():
        if os.path.exists(filename):
            os.remove(filename)

    rc, con = lgetfilecon_raw(filename)
    if rc == 0:
        assert con == file_con
    else:
        cleanup()

        with open(filename, 'w') as confile:
            pass

        rc, con = lgetfilecon_raw(filename)
        assert rc == 0

        cleanup()


# Generated at 2022-06-22 22:23:58.478043
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, policy = selinux_getenforcemode()

    assert isinstance(policy, int)
    assert rc == 0 or rc == -1
    assert 0 <= policy <= 2


# Generated at 2022-06-22 22:24:07.432279
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import socket
    import tempfile
    import shutil
    from tempfile import NamedTemporaryFile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = NamedTemporaryFile(dir=tmpdir)

    # Get the context of the temporary directory
    tmpdircontext = lgetfilecon_raw(tmpdir)[1]

    # Get the context of the temporary file
    tmpfilecontext = lgetfilecon_raw(tmpfile.name)[1]

    # Get the context of the dev/null device
    devnullcontext = lgetfilecon_raw('/dev/null')[1]

    # Get the context of the TCP socket
    sockcontext = lgetfilecon_raw(socket.gethostname())[1]

    # Remove temporary file
    os

# Generated at 2022-06-22 22:24:14.722156
# Unit test for function matchpathcon
def test_matchpathcon():
    testpath = u'/etc/ansible'
    con = SElinux.matchpathcon(testpath, 0)
    assert con[0] == 0
    assert con[1] == 'system_u:object_r:etc_t:s0'
    con = SElinux.matchpathcon(testpath, 0o777)
    assert con[0] == 0
    assert con[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:24:23.193354
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.notstdlib.moveitallout.tests.unit import support

    # Arrange
    support.mock_libs(support.SELINUX_ENABLED_LIBS)
    os.environ["SELINUX_ENABLED"] = "True"
    os.environ["SELINUX_POLICYVERS"] = "24"

    # Act
    returned = selinux_getenforcemode()

    # Assert
    assert returned == [0, 1]


# Generated at 2022-06-22 22:24:25.419507
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enf) = selinux_getenforcemode()
    assert isinstance(rc, int) and isinstance(enf, int)


# Generated at 2022-06-22 22:24:31.723717
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/foobar', os.R_OK) == [0, 'user_home_dir_t']
    assert matchpathcon('/this/path/does/not/exist/ever', os.R_OK) == [0, '<<none>>']
    assert matchpathcon('/etc/foobar', os.R_OK) == [0, 'etc_t']
    assert matchpathcon('/etc/foobar', os.W_OK) == [0, 'ect_t']

# Generated at 2022-06-22 22:24:37.725828
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    f_out = open('testoutput.txt','a')
    f_out.write('selinux_getpolicytype returned {0} and {1}'.format(rc, con))
    f_out.close()


# Generated at 2022-06-22 22:24:46.092491
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    test_path = '/etc/hosts'

    # Test matchpathcon
    matchpathcon_result = matchpathcon(test_path, 0)
    assert matchpathcon_result[0] == 0
    assert matchpathcon_result[1] == 'system_u:object_r:etc_t:s0'

    matchpathcon_result = matchpathcon(test_path, 0o2000)
    assert matchpathcon_result[0] == 0
    assert matchpathcon_result[1] == '(system_u:object_r:etc_t:s0,unconfined_u:object_r:etc_t:s0)'


# Generated at 2022-06-22 22:24:48.240969
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import pytest
    assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-22 22:24:57.048631
# Unit test for function matchpathcon
def test_matchpathcon():
    # The following file was created when the module was imported and is used throughout the unit tests
    # for function matchpathcon.
    #
    # # touch /tmp/unit_test_file
    # # setfattr -n security.selinux -v system_u:object_r:usr_t:s0 /tmp/unit_test_file
    file_path = '/tmp/unit_test_file'

    (rc, con) = matchpathcon(file_path, 0)
    # The return value should be 0 because the operation was successful.
    if rc != 0:
        raise AssertionError("matchpathcon: Unexpected return value {}".format(rc))

    # Compare the context of the file against the return value of matchpathcon.
    # Use the '-q' option to prevent errors when running `getfattr` if the

# Generated at 2022-06-22 22:25:02.469526
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test if file context is given in the output
    rc, result = lgetfilecon_raw(b'/')
    assert rc == 0
    assert result is not None
    assert result != b''


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:25:04.070844
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    err, rc = selinux_getpolicytype()
    assert err == 0
    assert rc in ('targeted', 'mcs')

# Generated at 2022-06-22 22:25:09.493463
# Unit test for function matchpathcon
def test_matchpathcon():
    # test for file which does not exists
    data = matchpathcon("/tmp/test_selinux", 0)
    assert data == [0, 'system_u:object_r:bin_t:s0']


if __name__ == '__main__':
    test_matchpathcon()  # Run unit test

# Generated at 2022-06-22 22:25:10.840136
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


# Generated at 2022-06-22 22:25:13.194914
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:25:16.956982
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon = lgetfilecon_raw('/etc/shadow')
    assert lgetfilecon[0] == 0
    assert lgetfilecon[1] == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-22 22:25:19.758609
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc, enforcemode = selinux_getenforcemode()
    print('enforcemode: {}, rc: {}'.format(enforcemode, rc))



# Generated at 2022-06-22 22:25:27.149315
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Test selinux_getenforcemode")
    [rc, enforcemode] = selinux_getenforcemode()
    if rc == 0:
        print("return code: " + str(rc))
        print("enforcemode: " + str(enforcemode))
    else:
        # return code -1 means library tools is not installed
        if rc == -1:
            print("return code: " + str(rc) + " (library libselinux.so not installed or not found)")
        else:
            # return code -2 means error while getting info
            print("return code: " + str(rc) + " (error while getting information)")



# Generated at 2022-06-22 22:25:30.540871
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        selinux_status = _selinux_lib.selinux_getenforcemode()
    except AttributeError:
        pytest.skip('selinux_getenforcemode not available')
    else:
        assert selinux_status == 1 or selinux_status == 0



# Generated at 2022-06-22 22:25:33.603386
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon("/tmp", 0)
    print("rc: " + str(rc))
    print("con: " + con)



# Generated at 2022-06-22 22:25:43.671804
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        from selinux.selinux import matchpathcon
    except ImportError:
        import selinux
        matchpathcon = selinux.matchpathcon

    if matchpathcon('/etc/passwd', 0):
        # This check won't work on Fedora since selinux is disabled by default
        assert security_getenforce() != 0
        assert matchpathcon('/etc/passwd', 0) == ('system_u:object_r:passwd_file_t:s0', 0)

        import tempfile
        with tempfile.TemporaryDirectory() as tdir:
            path = os.path.join(tdir, 'file')
            open(path, 'w').close()
            assert matchpathcon(path, 0) == ('system_u:object_r:default_t:s0', 0)


# Generated at 2022-06-22 22:25:45.450454
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ('targeted', 'strict', 'mls')



# Generated at 2022-06-22 22:25:52.034816
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # The path must exist and must be a file
    path = '/etc/ansible/ansible.cfg'
    assert os.path.exists(path)
    assert os.path.isfile(path)

    expected_return_code = 0
    actual_return_code, actual_con_context = lgetfilecon_raw(path)
    assert actual_return_code == expected_return_code
    assert 'system_u:object_r:etc_t' in actual_con_context


# Generated at 2022-06-22 22:25:57.603029
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/etc/shadow')
    assert rc == 0
    assert con != b''
    assert b'unconfined_u:object_r:shadow_t:s0' in con.split(b':')


# Generated at 2022-06-22 22:26:00.316915
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, result = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert result == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-22 22:26:08.709358
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    /bin/ls
    /selinux/null
    """
    examples = [
        ('/bin/ls', '/usr/bin(/.*)?'),
        ('/selinux/null', '/selinux/null'),
    ]
    for path, expected_con in examples:
        actual = lgetfilecon_raw(path)
        assert actual[0] == 0
        actual_con = actual[1]
        if expected_con != actual_con:
            raise Exception("expected con '%s' doesn't match actual con '%s'" % (expected_con, actual_con))


# Generated at 2022-06-22 22:26:13.380748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/localtime')
    print('lgetfilecon_raw: rc=%s con=%s' % (rc, con))
    assert rc == 0
    assert con and isinstance(con, str)



# Generated at 2022-06-22 22:26:15.434763
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    code, value = selinux_getpolicytype()
    assert isinstance(value, str)


# Generated at 2022-06-22 22:26:24.745086
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.selinux import selinux_getenforcemode
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import selinux

    enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, list)
    assert len(enforcemode) == 2
    assert isinstance(enforcemode[0], int)
    assert isinstance(enforcemode[1], int) or enforcemode[1] is None
    assert enforcemode[1] in [selinux.SELINUX_ENFORCE_DISABLED, selinux.SELINUX_ENFORCE_PERMISSIVE, selinux.SELINUX_ENFORCE_ENABLED]



# Generated at 2022-06-22 22:26:28.754934
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    rc, ret = matchpathcon("/tmp", 1)
    print('Return code is %d' % rc)
    print('Selinux context is %s' % ret)



# Generated at 2022-06-22 22:26:38.617130
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    results = selinux_getenforcemode()
    success = results[0]
    enforce_mode = results[1]
    if enforce_mode == 0:
        enforce_mode = 'disabled'
    elif enforce_mode == 1:
        enforce_mode = 'permissive'
    elif enforce_mode == 2:
        enforce_mode = 'enforcing'
    else:
        enforce_mode = str(enforce_mode)
    module.exit_json(changed=False, msg='success', success=success, enforce_mode=enforce_mode)



# Generated at 2022-06-22 22:26:45.395539
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.realpath(__file__)
    test_rc, test_con = lgetfilecon_raw(path)
    assert test_rc > 0
    assert test_con is not None
    assert test_con == 'unconfined_u:object_r:user_tmp_t:s0'



# Generated at 2022-06-22 22:26:46.148018
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:26:48.588566
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con == b'MLS'


# Generated at 2022-06-22 22:26:52.156423
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/issue'
    con = lgetfilecon_raw(path)
    assert con[1] == 'system_u:object_r:etc_runtime_t:s0', 'test_lgetfilecon_raw failed'


# Generated at 2022-06-22 22:26:59.319548
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    test_dir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(test_dir, 'test_file')
        with open(test_file, 'w') as f:
            f.write('test file content')
        [rc, con] = lgetfilecon_raw(test_file)
        assert rc == 0
        assert con == 'unconfined_u:object_r:user_tmp_t:s0'
        [rc, con] = lgetfilecon_raw(test_dir)
        assert rc == 0
        assert con == 'unconfined_u:object_r:tmp_t:s0'
    finally:
        os.remove(test_file)

# Generated at 2022-06-22 22:27:02.529145
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[1] == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-22 22:27:05.160217
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert(isinstance(result, list))
    assert(len(result) == 2)



# Generated at 2022-06-22 22:27:12.888223
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc < 0:
        errno = get_errno()
        # ENOENT means file not found
        # EPERM is permission error
        # ENOTSUP is no context support on filesystem (e.g. NFS)
        if errno == 2 or errno == 1 or errno == 95:
            return
        raise OSError(errno, os.strerror(errno))
    return con

# Generated at 2022-06-22 22:27:15.548589
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1



# Generated at 2022-06-22 22:27:16.685202
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: implement this unit test
    pass

# Generated at 2022-06-22 22:27:21.971612
# Unit test for function matchpathcon
def test_matchpathcon():
    msg = ("\nExpected return code of -1 with the following error message:"
           "\n\n\tContext not found for ijklmnopqr.stuvwx.")
    rc, con = matchpathcon("file_name", 0)
    assert rc == -1, msg

# Generated at 2022-06-22 22:27:25.529815
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/tmp/foo', 0)
    if rc < 0:
        raise OSError(get_errno(), os.strerror(get_errno()))
    print('matchpathcon: ' + con)

# Generated at 2022-06-22 22:27:35.962946
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    rc, con = lgetfilecon_raw(b'/bin/bash')
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:27:40.647383
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1 or enforcemode == 2


# Generated at 2022-06-22 22:27:45.644262
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/usr/bin/')
    assert rc == -1
    assert not con

    (rc, con) = lgetfilecon_raw('/usr/bin')
    assert rc == 0
    assert con == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-22 22:27:52.414734
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for function lgetfilecon_raw
    """
    _selinux_lib = CDLL('libselinux.so.1', use_errno=True)
    path = '.'
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    if rc == -1:
        raise OSError(get_errno(), os.strerror(get_errno()))
    print(con.value)
    os.system("echo %s > /tmp/con" % con.value)
    _selinux_lib.freecon(con)


# Generated at 2022-06-22 22:27:55.359548
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, value = selinux_getenforcemode()
    print('The value of selinux_getenforcemode is: ', rc, value)



# Generated at 2022-06-22 22:27:57.416374
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/selinux')
    assert rc == 0
    assert con is not None

# Generated at 2022-06-22 22:27:58.582466
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-22 22:28:06.532086
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test_lgetfilecon_raw'

    f = open(path, 'w')
    f.close()

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert len(con.split(b':')) >= 3

        rc, con = lgetfilecon_raw(path + '_bad')
        assert rc == -1
        assert con is None
    finally:
        os.unlink(path)

# Generated at 2022-06-22 22:28:09.222680
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test function selinux_getpolicytype()
    """
    version = selinux_getpolicytype()
    assert version[0] == 0 and version[1] == 'targeted'

# Generated at 2022-06-22 22:28:13.308103
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mod = sys.modules[__name__]
    rc, mode = mod.selinux_getenforcemode()
    assert rc >= 0 and mode in [0, 1, 2]

# Generated at 2022-06-22 22:28:15.293055
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    out, error = selinux_getpolicytype()
    assert not error
    assert out.startswith('selinuxfs')


# Generated at 2022-06-22 22:28:21.323388
# Unit test for function matchpathcon
def test_matchpathcon():
    # when tmp filesystem is not mounted, the matchpathcon should raise error
    try:
        matchpathcon('/tmp', os.R_OK)
    except OSError as e:
        if e.errno != 95:
            raise AssertionError("Unexpected error raised {}".format(e))

# Generated at 2022-06-22 22:28:25.245672
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    try:
        lgetfilecon_raw("/etc/hosts")
    except OSError as e:
        assert e.errno == 22
    temp_dir = tempfile.TemporaryDirectory()
    assert lgetfilecon_raw(temp_dir.name)[0] == 0

# Generated at 2022-06-22 22:28:26.715542
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()



# Generated at 2022-06-22 22:28:28.929847
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/bin/ls', 0)
    assert rc == 0 and con == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-22 22:28:31.341198
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0, 'Failed to retrieve policytype'

# Generated at 2022-06-22 22:28:33.010099
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:28:34.858184
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result == [0, 1]


# Generated at 2022-06-22 22:28:40.604369
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    #For example, /proc directory should have system_u:object_r:proc_t:s0 context.
    path = b"/proc"
    rc = lgetfilecon_raw(path)
    if rc[0] == 0:
        assert rc[1] == b"system_u:object_r:proc_t:s0"
    else:
        assert False



# Generated at 2022-06-22 22:28:45.084240
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return
    rc, mode = selinux_getenforcemode()
    assert isinstance(rc, int) and 0 <= rc <= 1
    assert isinstance(mode, int) and 0 <= mode <= 2



# Generated at 2022-06-22 22:28:49.869688
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    import sys
    try:
        enforcemode = os.environ['SELINUX_ENFORCE']
    except KeyError:
        enforcemode = '0'
    if sys.platform.startswith('linux'):
        assert to_native(selinux_getenforcemode()[1]) == to_native(enforcemode)
    else:
        assert to_native(selinux_getenforcemode()[0]) == -1


# Generated at 2022-06-22 22:28:52.394619
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test selinux_getenforcemode
    assert selinux_getenforcemode() == [0, 0]

# Generated at 2022-06-22 22:28:55.173176
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test whether selinux_getenforcemode returns the expected value
    '''
    rc, enforcemode = selinux_getenforcemode()

    assert enforcemode == 1 or enforcemode == 0

    if enforcemode == 0:
        assert rc == 0

    if enforcemode == 1:
        assert rc == 2



# Generated at 2022-06-22 22:29:03.402638
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import tempfile

    if os.path.exists('/lib/libselinux.so'):
        try:
            CDLL('libselinux.so.1', use_errno=True)
        except OSError:
            raise ImportError('unable to load libselinux.so')
    else:
        print("Could not find libselinux.so")


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:08.064304
# Unit test for function matchpathcon
def test_matchpathcon():
    policy_version = security_policyvers()
    con = matchpathcon("/", 0)[1]

    if policy_version < 24 and ':' in con:
        con = con.split(':')[0]

    return con

# Generated at 2022-06-22 22:29:16.485700
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil


# Generated at 2022-06-22 22:29:22.568240
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, out = selinux_getpolicytype()
    if rc != 0:
        raise AssertionError('selinux_getpolicytype: test failed, rc={0}, out={1}'.format(to_native(rc), to_native(out)))
    else:
        print('selinux_getpolicytype: test passed, rc={0}, out={1}'.format(to_native(rc), to_native(out)))



# Generated at 2022-06-22 22:29:31.446770
# Unit test for function matchpathcon
def test_matchpathcon():
    # Return code from loading a policy from a file that does not exist
    fail_load = -1
    # Returns the expected rte if it matches the file under path
    match_file_rule = -2
    # Return value of mode (see man matchpathcon)
    mode = 0

    # Test with a valid domain transition file
    path = '/usr/sbin/usermod'
    rc, con = matchpathcon(path, mode)
    # Verify the rc return code is a match or a load failure
    assert rc in [match_file_rule, fail_load]
    assert isinstance(con, str)

    # Test with a file that does not exist
    path = '/usr/foo/bar'
    rc, con = matchpathcon(path, mode)
    # Verify the rc return code is a match or a load failure

# Generated at 2022-06-22 22:29:39.725971
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    _selinux_lib.lgetfilecon_raw.return_value = 0
    _selinux_lib.strerror.return_value = b'Test'
    con = b'email_spool_t'
    _selinux_lib.lgetfilecon_raw.return_value = 0
    _selinux_lib.lgetfilecon_raw.restype = c_int
    _selinux_lib.lgetfilecon_raw.argtypes = [c_char_p, POINTER(c_char_p)]

# Generated at 2022-06-22 22:29:44.075693
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This function needs an actual system with a working selinux library
    # but it should fail without an actual file
    result = lgetfilecon_raw('/tmp/some_non-existent_file')
    assert result[0] == -1
    assert result[1] == os.strerror(errno.ENOENT)



# Generated at 2022-06-22 22:29:50.515226
# Unit test for function matchpathcon
def test_matchpathcon():
    # matchpathcon is deprecated, but there is no suitable replacement
    # available in libselinux.so.1, so test it here.
    # See https://github.com/SELinuxProject/selinux/issues/377
    import os
    import tempfile

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    try:
        rc, con = matchpathcon(fname, os.R_OK)
        assert rc == 0
        assert con == 'user_u:object_r:unlabeled_t:s0'
    finally:
        os.remove(fname)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:53.333892
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw(b"/usr/bin/python3"))
    print((1, 'unlabeled'))



# Generated at 2022-06-22 22:29:58.645658
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print('selinux_getenforcemode:')
    ret = selinux_getenforcemode()
    print('- return code: {}'.format(ret[0]),
          'enforce mode: {}\n'.format(ret[1]))


# Generated at 2022-06-22 22:30:01.954955
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0

# Generated at 2022-06-22 22:30:06.376612
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) == list
    assert type(selinux_getenforcemode())[0] == int
    assert type(selinux_getenforcemode())[1] == int


# Generated at 2022-06-22 22:30:08.359327
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, _ = selinux_getenforcemode()
    assert rc == 0, "Function selinux_getenforcemode failed"


# Generated at 2022-06-22 22:30:12.122368
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(os.path.realpath(__file__))
    print(rc, con)



# Generated at 2022-06-22 22:30:15.785915
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test function selinux_getpolicytype.
    """
    actual = selinux_getpolicytype()
    expected = [0, " targeted "]
    assert actual == expected,\
        "expected {0} and got {1}".format(expected, actual)

# Generated at 2022-06-22 22:30:17.771054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, policy_type = selinux_getenforcemode()
    if rc == -1:
        raise OSError(get_errno(), os.strerror(get_errno()))

    assert policy_type in [-1, 0, 1]



# Generated at 2022-06-22 22:30:23.574042
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = "/etc/passwd"
    res = lgetfilecon_raw(filepath)
    rc = res[0]
    assert rc == 0, "lgetfilecon_raw returns non-zero return code: %s" % rc
    con = res[1]
    assert len(con) > 0, "lgetfilecon_raw returns empty context"


# Generated at 2022-06-22 22:30:27.310399
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw(b"/etc/hosts")
    assert rc == 0

    [rc, con] = lgetfilecon_raw(b"/etc/hosts-not")
    assert rc != 0



# Generated at 2022-06-22 22:30:36.492375
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    mode = None
    path = '/etc/shadow'
    plain_con = 'system_u:object_r:shadow_t:s0'
    is_enabled, is_mls_enabled, enforce_mode, policy_version, selinux_version = selinux_getenforcemode(), is_selinux_mls_enabled(), selinux_getenforce(), security_policyvers(), selinux_getpolicytype()
    if is_enabled[0] == -1 or is_mls_enabled[0] == -1 or enforce_mode[0] == -1 or policy_version[0] == -1 or selinux_version[0] == -1:
        return
    if is_enabled[1] and not is_mls_enabled[1]:
        mode = 0
        con, rc = lgetfilecon_raw(path)

# Generated at 2022-06-22 22:30:46.905434
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        import selinux
        if selinux.is_selinux_enabled() == 0:
            raise ImportError
    except ImportError:
        raise ImportError('SELinux not enabled')

    def _validate(path, con):
        if not to_native(con).startswith(('u:object_r:', 'u:object_r:unlabeled:')):
            raise AssertionError('bad context: {0}'.format(to_native(con)))

    _validate(b'/usr/bin/python', _selinux_lib.lgetfilecon_raw(b'/usr/bin/python', None))

    con = c_char_p()

# Generated at 2022-06-22 22:30:50.438193
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Make sure the function does not throw an exception.
    try:
        lgetfilecon_raw('/etc/passwd')
    except Exception:
        assert False, 'Function lgetfilecon_raw() threw an exception'
    assert True

# Generated at 2022-06-22 22:30:58.439034
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    import sys
    import textwrap

    class TestCfg(object):
        pass

    test_cfg = TestCfg()
    test_cfg.selinux = True
    test_cfg.selinux_mls = True
    test_cfg.selinux_policy = "minimum"
    test_cfg.selinux_checkreqprot = True
    test_cfg.selinux_enforce = True
    test_cfg.selinux_ignore_defaults = False

    # Create empty module
    utils_module = type(os)(os.__name__)
    # Set module attributes
    # get policy type from selinux library
    type_ret, type_value = selinux_getpolicytype()

# Generated at 2022-06-22 22:31:09.000442
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, value] = selinux_getpolicytype()
    if rc != 0:
        raise ValueError("Function selinux_getpolicytype returned error {}".format(rc))
    print("selinux_getpolicytype returned {0}".format(value))
    if value == b'standalone' or value == b'mls':
        pass # success
    else:
        raise ValueError("selinux_getpolicytype returned unexpected value {}".format(value))

if __name__ == '__main__':

    print("SELinux enabled = {0}".format(is_selinux_enabled()))

    if is_selinux_enabled():
        print('MLS SELinux enabled = {0}'.format(is_selinux_mls_enabled()))

# Generated at 2022-06-22 22:31:16.396816
# Unit test for function matchpathcon
def test_matchpathcon():
    # testing that an error code is returned when the path is null
    rc, con = matchpathcon(None, 0)
    assert rc < 0
    assert con is None

    # testing that an error code is returned when the path is empty
    rc, con = matchpathcon('', 0)
    assert rc < 0
    assert con is None

    # testing that an error code is returned when the path is not valid
    rc, con = matchpathcon('/no/such/path', 0)
    assert rc < 0
    assert con is None



# Generated at 2022-06-22 22:31:20.413191
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """ check that we get 1 for enabled and 0 for disabled
    """
    enf_mode = selinux_getenforcemode()
    assert enf_mode[0] == 0
    assert enf_mode[1] in [0, 1]
    return 0



# Generated at 2022-06-22 22:31:22.574594
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0 or rc == -1
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:31:26.750963
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/passwd")
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-22 22:31:30.242503
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/etc/selinux/config', 0)
    assert res[0] == 0
    assert res[1] == "system_u:object_r:etc_runtime_t:s0"

# Generated at 2022-06-22 22:31:30.871256
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    pass

# Generated at 2022-06-22 22:31:35.235879
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("SELINUX_ENFORCE_MODE: %d" % (enforcemode))
    assert rc == 0


# Generated at 2022-06-22 22:31:39.257550
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, "system_u:object_r:var_t:s0"]


# Generated at 2022-06-22 22:31:41.269005
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    assert isinstance(policytype, str)
    assert policytype in ['targeted', 'mls', 'minimum', 'strict']

# Generated at 2022-06-22 22:31:51.482063
# Unit test for function matchpathcon
def test_matchpathcon():
    # These return an error code, and a string containing a context or security_level or None.
    print("'{1}': {0}".format(*matchpathcon('/usr/sbin/squid', 0)))
    print("'{1}': {0}".format(*matchpathcon('/usr/sbin/squid', 1)))
    print("'{1}': {0}".format(*matchpathcon('/usr/sbin/squid', 2)))
    print("'{1}': {0}".format(*matchpathcon('/etc/shadow', 0)))
    print("'{1}': {0}".format(*matchpathcon('/etc/shadow', 1)))
    print("'{1}': {0}".format(*matchpathcon('/etc/shadow', 2)))

# Generated at 2022-06-22 22:31:55.345981
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    l = selinux_getpolicytype()
    assert l[0] == 0
    assert isinstance(l[1], str)
    assert l[1] in ['targeted', 'minimum', 'mls']

if __name__ == '__main__':
    from ansible.module_utils._text import to_text

    print(to_text(selinux_getpolicytype()))

# Generated at 2022-06-22 22:32:02.279860
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = "testfile"
    with open(filepath, "w+") as f:
        f.write("test")
    f.close()
    try:
        [rc, result] = lgetfilecon_raw(filepath)
        os.remove(filepath)
        if rc == 0:
            assert result is not None
    except:
        os.remove(filepath)
        raise


# Generated at 2022-06-22 22:32:12.564607
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_bytes
    import os
    import gettext

    _ = gettext.gettext

    (rc, con) = matchpathcon(to_bytes('/foo/bar'), 0);
    if rc == 0:
        os.putenv(to_bytes('SELINUX_INITIAL_CONTEXT'), con)
        os.execve(to_bytes('/bin/touch'), [to_bytes('touch'), to_bytes('/foo/bar/baz')], os.environ)
    elif rc == -1:
        raise OSError(_('Unable to get file context for /foo/bar'))
    else:
        raise OSError(_('Unable to lookup SID for context %s') % con)

# Generated at 2022-06-22 22:32:18.173901
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, ptype) = selinux_getpolicytype()
    assert rc == -1 or rc == 0
    assert ptype == 'targeted' or ptype == 'minimum' or ptype == 'mls' or ptype == 'strict'


# Generated at 2022-06-22 22:32:26.635352
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    with tempfile.NamedTemporaryFile('w+') as f:
        f.write('tempfile content')
    import syslog
    syslog.openlog()
    syslog.syslog(syslog.LOG_NOTICE, 'test: file: {}'.format(f.name))
    rc, con = lgetfilecon_raw(f.name)
    syslog.syslog(syslog.LOG_NOTICE, 'test: file: {}, rc: {}, con: {}'.format(f.name, rc, con))

    assert rc == 0, 'Unexpected non-zero return value'
    assert con.startswith('system_u:object_r:default_t:'), 'Unexpected file context'


# Generated at 2022-06-22 22:32:31.402022
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/proc/self/fd/1'
    mode = 0o600
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:initrc_tmp_t:s0'

# Generated at 2022-06-22 22:32:36.363514
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    print("\npolicytype returned: " + str(policytype))
    assert policytype[0] == 0, "Error getting policy type: " + str(policytype[0])
    assert policytype[1] is not None, "Policy type is None: " + str(policytype)
