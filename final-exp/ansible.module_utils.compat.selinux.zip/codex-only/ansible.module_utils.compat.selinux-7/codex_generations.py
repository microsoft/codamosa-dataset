

# Generated at 2022-06-22 22:22:32.820188
# Unit test for function matchpathcon
def test_matchpathcon():
    assert_matchpathcon = matchpathcon('/tmp', 0)
    assert assert_matchpathcon[0] == 0
    assert assert_matchpathcon[1] == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:22:44.044237
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    import os

    os.chdir('/usr/bin')
    rc, con = matchpathcon('bash', 0)
    assert rc == 0
    assert con == 'system_u:object_r:bash_exec_t:s0-s0:c0.c1023'

    os.chdir('/proc/self/fd')
    rc, con = matchpathcon('0', 0)
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'

    rc, con = matchpathcon('/proc/self/fd/0', 0)
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-22 22:22:46.641692
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this is not a real unit test
    for path in ('/', '/home'):
        for mode in (0, 1):
            rc, con = matchpathcon(path, mode)
            print("{0}:{1}: {2}".format(path, mode, con))

# Generated at 2022-06-22 22:22:57.478195
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat

    def mkdir_with_selinux_label(path, label):
        rc = matchpathcon(path, stat.S_IFDIR)[0]
        if rc != 0:
            raise Exception ("matchpathcon failed")

        rc = lsetfilecon(path, label)[0]
        if rc != 0:
            raise Exception ("lsetfilecon failed")

    def assert_matchpathcon(path, mode, label):
        print("matchpathcon(%s, %s)" % (path, mode))

        rc, con = matchpathcon(path, mode)
        if rc != 0:
            raise Exception ("matchpathcon failed")

        if con != label:
            raise Exception ("Unexpected label: %s" % con)

    def assert_lgetfilecon(path, label):
        print

# Generated at 2022-06-22 22:23:02.183043
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = lgetfilecon_raw('/')
    assert rc[0] == 0
    assert rc[1].startswith('unconfined_u:object_r:root_t:s0')


# Generated at 2022-06-22 22:23:08.771889
# Unit test for function matchpathcon
def test_matchpathcon():
    file_path = '/tmp/test_matchpathcon'
    os.system('touch /tmp/test_matchpathcon')
    rc, con = matchpathcon(file_path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'
    os.system('rm /tmp/test_matchpathcon')


# Generated at 2022-06-22 22:23:12.311793
# Unit test for function matchpathcon
def test_matchpathcon():
    # On a system with a selinux policy, the SELinux context usually matches the name of the file
    assert matchpathcon('/etc/passwd', 0) == [0, 'etc_t:object_r:etc_runtime_t:s0']



# Generated at 2022-06-22 22:23:13.853129
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print('selinux_getenforcemode:', selinux_getenforcemode())



# Generated at 2022-06-22 22:23:25.534228
# Unit test for function matchpathcon
def test_matchpathcon():
    # Tested on a system which is not SELinux
    print('Running test_matchpathcon:')
    try:
        rc, con = matchpathcon('/etc/passwd', 0)
    except OSError:
        rc, con = matchpathcon('/etc/passwd', 1)
    print('type: {0}'.format(con))
    # Tested on a SELinux system
    if rc == 0:
        print('Running test_matchpathcon:')
        try:
            rc, con = matchpathcon('/etc/passwd', 0)
        except OSError:
            rc, con = matchpathcon('/etc/passwd', 1)
        print('type: {0}'.format(con))



# Generated at 2022-06-22 22:23:31.216772
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policytype = selinux_getpolicytype()
        assert rc == 0
        assert policytype == 'targeted' or policytype == 'mcs'
    except NotImplementedError:
        pass
    except OSError:
        pass


# Generated at 2022-06-22 22:23:33.609883
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    status, policy = selinux_getpolicytype()
    assert status == 0
    assert policy == 'targeted'


# Generated at 2022-06-22 22:23:36.070725
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/hosts') == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-22 22:23:37.640203
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert to_native(_selinux_getenforcemode()) == [0, 1]



# Generated at 2022-06-22 22:23:44.493130
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create test file
    TEST_FILE = "/tmp/test_libselinux_lgetfilecon_raw"
    test_file = open(TEST_FILE,'w')
    test_file.close()

    # Get context on test file
    [rc, context] = lgetfilecon_raw('/tmp/test_libselinux_lgetfilecon_raw')

    # Delete test file
    os.remove(TEST_FILE)

    # Check for successful return code
    if rc == 0:
        pass
    else:
        raise Exception("lgetfilecon_raw returned error code {0}".format(rc))

    # Check for valid context
    if context:
        pass
    else:
        raise Exception("lgetfilecon_raw returned a null context")

    # Check for selinux enabled

# Generated at 2022-06-22 22:23:49.262356
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0, "failed to get policy type with rc {}, errno {}".format(rc, os.strerror(get_errno()))
    assert policy_type == "targeted", "policy type {} is not equal to targeted".format(policy_type)

# Generated at 2022-06-22 22:23:54.552195
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return

    try:
        result = selinux_getenforcemode()
        assert result[0] == 0
        assert result[1] in (0, 1)
    except Exception as e:
        raise AssertionError("function selinux_getenforcemode failed: " + to_native(e))



# Generated at 2022-06-22 22:24:01.916054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        result = selinux_getenforcemode()
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)
    except:
        assert False, "Unexpected exception raised"
    else:
        assert result[0] >= 0, "Unexpected return code: " + str(result[0])
        assert isinstance(result[1], int), "Unexpected type: " + str(type(result[1]))


# Generated at 2022-06-22 22:24:06.714353
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    import tempfile

    if PY3:
        tempfile.mkstemp = tempfile._mkstemp_unsafe_inner

    with tempfile.NamedTemporaryFile() as temp:
        (r, _) = lgetfilecon_raw(to_text(temp.name))
        assert r in (0, -1)

# Generated at 2022-06-22 22:24:11.756428
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:24:14.680528
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:24:24.218800
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/tmp/test_lgetfilecon_raw.txt"
    f = open(test_file, "w")
    f.write("test")
    f.close()
    con = lgetfilecon_raw(test_file)
    os.remove(test_file)
    if con[0] != 0:
        raise ValueError("Return value mismatch: actual=%s, expected=0" % (con[0]))
    if con[1] is None or con[1] == "":
        raise ValueError("Return value mismatch: actual=%s, expected=somevalue" % (con[1]))


# Generated at 2022-06-22 22:24:29.155546
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Check selinux_getpolicytype function.

    If selinux is not enabled we do not have a policy
    """
    if not is_selinux_enabled():
        assert selinux_getpolicytype() == [0, '<<none>>']
    else:
        assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-22 22:24:36.319595
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    p = "/bin/ls"
    (rc, con) = _selinux_lib.lgetfilecon_raw(p, None)
    assert rc == 0, "lgetfilecon_raw failed with returncode {0}".format(rc)
    assert con == 'system_u:object_r:bin_t:s0'.encode(), "Unexpected SELinux context {}".format(con)


# For backwards compatibility:
# NOTE: lgetfilecon and lsetfilecon do not support raw context,
# so they're just wrappers around lgetfilecon_raw and lsetfilecon_raw
getfilecon = lgetfilecon_raw
setfilecon = lsetfilecon_raw

# Generated at 2022-06-22 22:24:41.638400
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # set the mode to 0 (disabled)
    # call selinux_getenforcemode
    # ensure it returns 0 and the mode is correctly set
    _selinux_lib.security_setenforce(0)
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode == 0



# Generated at 2022-06-22 22:24:43.281385
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
        assert selinux_getpolicytype()[1] == "targeted"  # targetd is the default policy type

# Generated at 2022-06-22 22:24:45.972044
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()
    # Check the return code of selinux_getpolicytype
    assert not policy_type[0]
    # Check if we get the correct policy type
    assert policy_type[1] == b"targeted"

# Generated at 2022-06-22 22:24:50.560604
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()

    if result[0] != 0:
        raise AssertionError("SELinux get enforce mode failed: %s" % result[0])
    else:
        print("SELinux get enforce mode succeeded: %s" % result[1])



# Generated at 2022-06-22 22:24:52.571552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw("/")
    assert rc is not None

# Generated at 2022-06-22 22:24:54.931823
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert 0 <= rc <= 1
    assert 0 <= enforcemode <= 2



# Generated at 2022-06-22 22:25:00.253081
# Unit test for function matchpathcon
def test_matchpathcon():
    if _selinux_lib.is_selinux_enabled():
        # Check if matchpathcon returns a context for a file
        file = '/etc/hosts'
        rc, con = matchpathcon(file, 0)
        if rc == 0:
            print("The context of the file is %s" % con)
        else:
            print("matchpathcon returned error: %s" % rc)
    else:
        print("SELinux is disabled")

# Generated at 2022-06-22 22:25:06.995619
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, filecon) = lgetfilecon_raw(to_bytes(u'/var/run/libvirt'))
    assert rc == 0 and filecon == u'system_u:object_r:virt_var_run_t:s0'
    (rc, filecon) = lgetfilecon_raw(to_bytes(u'/var/run/libvirt/'))
    assert rc == 0 and filecon == u'system_u:object_r:virt_var_run_t:s0'


# Generated at 2022-06-22 22:25:11.922995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/etc/fstab')
    assert rc == 0
    assert con is not None
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:25:16.207628
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for valid path
    path = '/etc'
    [rc,filecon] = lgetfilecon_raw(path)
    assert rc == 0
    assert filecon == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:25:25.305816
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Unit tests for selinux_getpolicytype
    # selinux_getpolicytype is a ctypes wrapper for selinux_getpolicytype()
    # selinux_getpolicytype() returns a string and an error code
    # selinux_getpolicytype() returns 0 on success
    # selinux_getpolicytype() returns a -1 on error

    # To test, we call selinux_getpolicytype()
    # It should return a -1 and raise an OSError
    # The OSError message should be "Operation not permitted"
    # The OSError errno should be 1

    rc, con = selinux_getpolicytype()
    assert rc == -1

    OSErrorMessage = "Operation not permitted"  # noqa
    OSErrorErrno = 1  # noqa

    err = None

   

# Generated at 2022-06-22 22:25:27.109969
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:25:29.954972
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dir/test'
    con_expected = 'user_u:object_r:user_home_t:s0'

    result = lgetfilecon_raw(path)
    con_actual = result[1]
    assert con_expected == con_actual



# Generated at 2022-06-22 22:25:37.332354
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    # FIXME: expand this test

    try:
        rc, con = matchpathcon('/etc/passwd', 0)
        assert rc == 0
        assert con == 'system_u:object_r:passwd_file_t:s0'
    except Exception as e:
        print('TEST FAILED: {0}'.format(e))



# Generated at 2022-06-22 22:25:40.086968
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce_mode = selinux_getenforcemode()
    assert rc == 0
    assert enforce_mode in [0, 1, 2]


# Generated at 2022-06-22 22:25:44.773862
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/selinux/test', 0)
    if rc == -1:
        raise OSError(rc, 'error while running %s' % con)
    print(rc, con)



# Generated at 2022-06-22 22:25:50.764521
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    tmp_path = tempfile.mkdtemp()
    assert(isinstance(tmp_path, str))
    assert(len(tmp_path) > 0)
    assert(tmp_path.startswith('/tmp/'))
    rc, con = matchpathcon(tmp_path, 0)
    assert(rc == 0)
    assert(isinstance(con, str))
    assert(len(con) > 0)

# Generated at 2022-06-22 22:25:53.661727
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1, enforcemode


# Generated at 2022-06-22 22:25:59.616200
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)
    assert len(selinux_getenforcemode()) == 2
    assert isinstance(selinux_getenforcemode()[0], int) and \
        isinstance(selinux_getenforcemode()[1], int)


# Generated at 2022-06-22 22:26:03.234329
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce = selinux_getenforcemode()
    print(enforce)
    assert type(enforce) == list
    assert len(enforce) == 2
    assert type(enforce[0]) == int
    assert type(enforce[1]) == int


# Generated at 2022-06-22 22:26:06.169983
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return [0, 0]

    rc, enforcemode = selinux_getenforcemode()
    return [rc, enforcemode]



# Generated at 2022-06-22 22:26:11.290002
# Unit test for function matchpathcon
def test_matchpathcon():
    import doctest

    rc, con = matchpathcon('/foo', 0)
    assert rc == 0

    rc, con = matchpathcon('/foo', os.R_OK)
    assert rc == 0

    rc, con = matchpathcon('/foo', 0)
    assert rc == 0
    assert con == '(null)'



# Generated at 2022-06-22 22:26:13.330149
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert -1 not in selinux_getenforcemode()



# Generated at 2022-06-22 22:26:15.795181
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from selinux import selinux_getpolicytype
    assert selinux_getpolicytype()[1] == 'targeted'


# Generated at 2022-06-22 22:26:21.821866
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()
    if rc >= 0:
        print('selinux_getpolicytype rc: %s' % rc)
        print('selinux_getpolicytype policy: %s' % policy)
        return 0
    else:
        print('selinux_getpolicytype failed')
        return -1

# NB: must be defined after the function wrappers
# this will be removed when module_init() is deprecated

# Generated at 2022-06-22 22:26:24.275348
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc >= 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-22 22:26:27.932877
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw(b'/etc/hosts')
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:26:39.538193
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not isinstance(sys.argv, list):
        raise ImportError('The sys.argv is not a list')
    if len(sys.argv) < 2:
        raise ImportError('The len(sys.argv) < 1')
    file_path = sys.argv[1]
    try:
        file_con = lgetfilecon_raw(file_path)
        if len(file_con) == 2:
            exit_code, con_val = file_con
            print(con_val)
        else:
            raise ImportError('The lgetfilecon_raw() list is too long')
    except OSError as err:
        print('Error: {0}'.format(to_native(err)))
        exit_code = 1
    sys.exit(exit_code)


__all__

# Generated at 2022-06-22 22:26:49.070170
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/usr')
    if rc == -1:
        if os.strerror(get_errno()) == 'No such file or directory':
            print("Failed as expected.")
        else:
            # Some other failure.
            print("Failed with unexpected errno: %d (%s)" % (get_errno(), os.strerror(get_errno())))
            sys.exit(1)
    else:
        # Succeeded when it should have failed.
        print("Failed as expected.")
        sys.exit(1)


# Generated at 2022-06-22 22:26:51.075592
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, val = selinux_getpolicytype()
    assert(rc == 0)
    assert(isinstance(val, str))



# Generated at 2022-06-22 22:26:56.109457
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Call function
    rc, enforcemode = selinux_getenforcemode()
    # Assert that the return code is zero
    assert rc == 0
    # The possible values for enforcemode are as follows:
    # 0 if SELinux is in permissive mode
    # 1 if SELinux is in enforcing mode
    # -1 if SELinux is disabled or in an unknown state
    assert enforcemode in [0, 1, -1]



# Generated at 2022-06-22 22:27:06.390631
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/log', 0)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'
    rc, con = matchpathcon('/var/log', 4)
    assert rc == -1
    try:
        rc, con = matchpathcon(None, 0)
    except TypeError:
        pass
    else:
        assert False
    try:
        rc, con = matchpathcon('/var/log', None)
    except TypeError:
        pass
    else:
        assert False
    try:
        rc, con = matchpathcon('/var/log', '0')
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-22 22:27:11.247307
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        import selinux
    except ImportError:
        raise Exception('selinux not available for testing')
    assert selinux_getenforcemode() == selinux.security_getenforce()


# Generated at 2022-06-22 22:27:16.686955
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon('/sys/kernel/mm', 0)
    assert r[0] == 0
    assert r[1] == 'system_u:object_r:sysfs_t:s0'



# Generated at 2022-06-22 22:27:20.250253
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (ret, value) = selinux_getenforcemode()
    assert ret == 1
    assert value in [0, 1, 2]



# Generated at 2022-06-22 22:27:22.928434
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert ret[0] == 0
    assert ret[1] == 0
    print("Unit test result - SUCCESS")


# Generated at 2022-06-22 22:27:25.679484
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'



# Generated at 2022-06-22 22:27:33.247716
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    results = lgetfilecon_raw('/etc/shadow')
    assert results[0] == 0
    assert results[1] == 'system_u:object_r:shadow_t:s0'

    results = lgetfilecon_raw('/etc/shadow/broken')
    assert results[0] == -1
    assert results[1] is None

    results = lgetfilecon_raw('/etc/shadow/broken', False)
    assert results[0] == -1
    assert results[1] is None



# Generated at 2022-06-22 22:27:41.613447
# Unit test for function matchpathcon
def test_matchpathcon():
    # matchpathcon for /var/ansible
    rc, con = matchpathcon("/var/ansible", 0)
    assert rc == 0
    assert con == "var_t:object_r:ansible_var_t:s0"

    # matchpathcon for /dev/tty
    rc, con = matchpathcon("/dev/tty", 0)
    assert rc == 0
    assert con == "chr_file(system_u:object_r:tty_device_t)";

    # Did we set the context as expected on /var/ansible ?
    rc, con = lgetfilecon_raw("/var/ansible")
    assert rc == 0
    assert con == "var_t:object_r:ansible_var_t:s0"

    # Did we set the context as expected on /dev/

# Generated at 2022-06-22 22:27:44.018233
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/mdm/logs/debug')
    assert rc == 0
    assert con is not None



# Generated at 2022-06-22 22:27:47.252365
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1



# Generated at 2022-06-22 22:27:51.792130
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        print('SELinux is not enabled. Skipping lgetfilecon_raw test')
        return

    print('Running lgetfilecon_raw...')

    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    if rc == -1:
        return -1

    print('Test successful')
    return 0



# Generated at 2022-06-22 22:27:54.242835
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_rc, test_value = selinux_getpolicytype()

    assert test_rc == 0
    assert test_value

# Generated at 2022-06-22 22:27:57.573420
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test that lgetfilecon_raw returns the context of /tmp
    try:
        rc, con = lgetfilecon_raw("/tmp")
        assert rc == 0
        assert con == "system_u:object_r:tmp_t:s0"
    except Exception:
        assert False

# Generated at 2022-06-22 22:28:01.048483
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = _selinux_lib.matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == b'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-22 22:28:04.034814
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
  assert lgetfilecon_raw("/etc/selinux/config") == [0, 'system_u:object_r:etc_t:s0\n']

# Generated at 2022-06-22 22:28:09.392272
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/root'
    mode = 0
    test = matchpathcon(to_bytes(path, errors='surrogate_or_strict'), mode)
    assert test == [0, 'system_u:object_r:root_t:s0'], test



# Generated at 2022-06-22 22:28:13.754822
# Unit test for function matchpathcon
def test_matchpathcon():
    # test empty path
    path = ""
    mode = 0
    assert matchpathcon(path, mode) == [0, '']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:18.837478
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_rc, test_enforcemode = selinux_getenforcemode()
    assert test_rc == 0
    assert test_enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:28:21.125814
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    print("Policy type:", to_native(policy))
    assert rc == 0



# Generated at 2022-06-22 22:28:24.074885
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    con_type = selinux_getpolicytype()
    assert con_type[1] == 'targeted', "targeted selinux policy_type expected, found {0}".format(con_type[1])



# Generated at 2022-06-22 22:28:25.455163
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-22 22:28:26.918136
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:28:30.203148
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    if rc != 0:
        raise Exception("rc: %s", rc)

    print("Enforcement mode: %s", enforcemode)


# Generated at 2022-06-22 22:28:33.674565
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test selinux_getenforcemode
    """
    (rc, enforcemode) = selinux_getenforcemode()
    assert enforcemode in [0, 1, 2]
    assert rc == 0



# Generated at 2022-06-22 22:28:36.695156
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_case = "Permissive"
    try:
        result, enforcemode = selinux_getenforcemode()
        assert enforcemode == test_case
    except Exception:
        raise


# Generated at 2022-06-22 22:28:43.585341
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('TESTING selinux_getpolicytype')
    (rc, policytype) = selinux_getpolicytype()
    if rc < 0:
        print('selinux_getpolicytype FAILED, rc=%d' % (rc))
    elif policytype != 'targeted':
        print('selinux_getpolicytype FAILED, policytype="%s", expected "targeted"' % (policytype))
    else:
        print('selinux_getpolicytype successful')
    print()


# Generated at 2022-06-22 22:28:54.872195
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test Python 2 and 3
    try:
        import __builtin__ as builtin
    except ImportError:
        import builtin

    def check_result(result, expected):
        assert sort_and_as_bytes(result) == sort_and_as_bytes(expected)

    class MockFile(builtin.file):
        def __init__(self, path, mode):
            self.fname = path
            self.mode = mode

        def write(self, bytes):
            if not hasattr(self, 'written'):
                self.written = bytes
            else:
                self.written += bytes

        def close(self):
            pass


# Generated at 2022-06-22 22:28:59.533374
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/shadow', 0)
    print('{0} {1}'.format(rc, con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:07.769358
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1:  Pass '/selinux/boolean' without a mode and assert that the boolean is present.
    (rc, con) = matchpathcon("/selinux/boolean", 0)
    assert(rc == 0)
    assert("allow_ssh_root_user" in con)

    # Test 2:  Pass '/etc/selinux/config' without a mode and assert that the config is present.
    (rc, con) = matchpathcon("/etc/selinux/config", 0)
    assert(rc == 0)
    assert("# This file controls the state of SELinux on the system." in con)

    # Test 3:  Pass '/selinux/boolean' with a mode and assert that the boolean is present.

# Generated at 2022-06-22 22:29:13.008803
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/var/log/audit/audit.log'
    rc, out = lgetfilecon_raw(test_file)
    if rc >= 0:
        print('File %s context: %s' % (test_file, out))
    else:
        print('Error getting file context for %s' % test_file)
        print('Are you running with --privileged?')
    return rc



# Generated at 2022-06-22 22:29:19.798686
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import shutil
    import tempfile

    if not os.path.exists('/selinux/'):
        return

    test_dir = to_native(tempfile.mkdtemp())

    try:
        rc, con = lgetfilecon_raw(test_dir)
        assert rc == 0
    finally:
        shutil.rmtree(test_dir)



# Generated at 2022-06-22 22:29:25.769781
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path
    import tempfile

    if not os.path.isdir('/tmp/test/'):
        os.mkdir('/tmp/test/')

    filename = tempfile.mktemp(dir='/tmp/test')

    if os.path.exists(filename):
        rc, con = matchpathcon(filename, 0)

        if rc == -1:  # SELinux not enabled
            return True

        print(con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:27.263033
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    print(path, con, rc)
    assert rc == 0


# Generated at 2022-06-22 22:29:32.876613
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Make sure we're running on an SELinux system
    if not is_selinux_enabled():
        return False
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'
    return True

# Generated at 2022-06-22 22:29:33.908778
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    selinux_getenforcemode()


# Generated at 2022-06-22 22:29:38.089484
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    return _selinux_lib.matchpathcon(b'/tmp', os.W_OK, None)


if __name__ == '__main__':
    sys.exit(test_matchpathcon())

# Generated at 2022-06-22 22:29:47.667448
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon('/lib64/libc-2.12.so', 0) == 0
    assert _selinux_lib.matchpathcon('/lib64/libc-2.12.so', 0)[1] == 'system_u:object_r:lib_t:s0'
    assert _selinux_lib.matchpathcon('/tmp/test1', 0) == 0
    assert _selinux_lib.matchpathcon('/tmp/test1', 0)[1] == 'system_u:object_r:tmp_t:s0'
    assert _selinux_lib.matchpathcon('/tmp/test2', 0) == 0

# Generated at 2022-06-22 22:29:51.253761
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()
    assert policy == "targeted"

if __name__ == '__main__':
    (rc, policy) = selinux_getpolicytype()
    print("rc: %d" % rc)
    print("policy: %s" % policy)

# Generated at 2022-06-22 22:30:03.404626
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    fd, tmpfile = tempfile.mkstemp()
    try:
        # test good path
        assert lgetfilecon_raw(tmpfile)[0] == 0

        # test invalid path
        assert lgetfilecon_raw('/non/existent/file')[0] < 0

        # attempt to read a symlink we can't traverse to
        # test bad link
        os.write(fd, b'asdf')
        os.close(fd)
        os.symlink('/non/existent/file', tmpfile + '.link')
        assert lgetfilecon_raw(tmpfile + '.link')[0] < 0

    finally:
        os.unlink(tmpfile)
        if os.path.exists(tmpfile + '.link'):
            os.unlink(tmpfile + '.link')

# Generated at 2022-06-22 22:30:08.006382
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.dirname(os.path.abspath(__file__)) + '/../../../../../../tests/unit/utils/selinux_utils/selinux_helpers_test.py'
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:ansible_test_t:s0']

# Generated at 2022-06-22 22:30:13.548023
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, label) = lgetfilecon_raw('/etc/selinux/config')
    if rc == 0:
        print("context: " + label)
    else:
        print("Error calling lgetfilecon_raw: " + str(rc))

# Generated at 2022-06-22 22:30:16.866215
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    print(result)
    assert isinstance(result, list)



# Generated at 2022-06-22 22:30:18.239531
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/"
    mode = 0
    result = matchpathcon(path, mode)
    print(result)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:22.932375
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test type of rc
    assert type(selinux_getenforcemode()[0]) == int

    # Test of return value
    assert selinux_getenforcemode()[1] == 1 or selinux_getenforcemode()[1] == 0



# Generated at 2022-06-22 22:30:30.553098
# Unit test for function matchpathcon
def test_matchpathcon():
    if (is_selinux_enabled() == 1 and is_selinux_mls_enabled() == 1):
        mpc = matchpathcon('/etc/hosts', 0)
        assert mpc[0] == 0
        assert mpc[1] == 'system_u:object_r:etc_t:s0'
    else:
        mpc = matchpathcon('/etc/hosts', 0)
        assert mpc[0] == -1
        assert mpc[1] is None

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-22 22:30:37.043722
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check we can get the security context of a file
    rc, context = lgetfilecon_raw(b"/tmp")
    assert context.find(b"tmp_t") > 0
    assert rc == 0

    # Check that the function returns an error if the path does not exist
    rc, context = lgetfilecon_raw(b"/tmp/does-not-exist")
    assert rc == -1
    assert context is None
    # TODO: This would be better if the error was raised as an exception, because then this test
    # would fail if _selinux_lib.lgetfilecon_raw is not implemented.


# Generated at 2022-06-22 22:30:39.728064
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-22 22:30:44.563814
# Unit test for function matchpathcon
def test_matchpathcon():
    print('[+] test_matchpathcon')
    path = '/etc/somedir'
    (rc, con) = matchpathcon(path, 0)
    print('[+] rc, con: {} {}'.format(rc, con))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:52.428705
# Unit test for function matchpathcon
def test_matchpathcon():
    """Testing matchpathcon function."""
    rc, con = matchpathcon('/tmp/test', 0)
    assert rc == 0  # return code
    assert con == 'system_u:object_r:tmp_t:s0'
    rc, con = matchpathcon('no_exist_path', 0)
    assert rc == 0  # return code
    assert con == 'system_u:object_r:default_t:s0'



# Generated at 2022-06-22 22:30:55.632008
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rval = selinux_getpolicytype()
    ret_code = rval[0]
    policy = rval[1]
    assert policy in ('targeted', 'strict', 'mcs', 'minimum', 'mls') and ret_code == 0


# Generated at 2022-06-22 22:31:01.820854
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = selinux.matchpathcon(b'/var', 0)

    if sys.modules[__name__].__name__ == 'selinux':
        assert rc == 0
        assert con == "system_u:object_r:var_t:s0"
    else:
        assert rc == -1


# Generated at 2022-06-22 22:31:03.827240
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # TODO: please, do some actual testing
    pass

# Generated at 2022-06-22 22:31:06.970323
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing function matchpathcon")

# Generated at 2022-06-22 22:31:11.253566
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # file.te
    con = lgetfilecon_raw('/etc/group')
    assert con[0] == 0
    assert con[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-22 22:31:15.967421
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    (rc, errmsg) = lgetfilecon_raw("/etc/resolv.conf")
    if rc == -1:
        print("lgetfilecon_raw error: " + os.strerror(rc))
    else:
        print("lgetfilecon_raw: " + errmsg)



# Generated at 2022-06-22 22:31:19.995941
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # SELinux is disabled by default on Ubuntu.
    assert lgetfilecon_raw('/')[1] == ''
    assert lgetfilecon_raw('/bin')[1] == ''
    assert lgetfilecon_raw('/bin/ls')[1] == ''

# Generated at 2022-06-22 22:31:21.578389
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode = selinux_getenforcemode()[1]
    assert mode == 0


# Generated at 2022-06-22 22:31:30.181522
# Unit test for function matchpathcon
def test_matchpathcon():
    if not sys.platform.startswith('linux'):
        print('Skipping test_matchpathcon on non-Linux')
        return

    con = c_char_p()
    try:
        # path must exist for it to work
        # expect failure
        rc, out = matchpathcon('/ansible/unit/test', 0)
        assert rc == -1
        assert out == ''
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-22 22:31:34.348211
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        assert _selinux_lib.selinux_getpolicytype is not None
    except AssertionError:
        print('selinux_getpolicytype() function is missing. Test could not run.')
        return
    assert selinux_getpolicytype()[1] != ''
    print('Successfully tested selinux_getpolicytype()')



# Generated at 2022-06-22 22:31:40.767476
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _selinux_lib.selinux_getpolicytype.restype = c_int
    _selinux_lib.selinux_getpolicytype = lambda p: ['mls', p]
    policytype = selinux_getpolicytype()
    assert policytype[1] == 'mls'

# Generated at 2022-06-22 22:31:45.804345
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # SELinux is available on this system
    enable = _selinux_lib.is_selinux_enabled()
    if enable == 1:
        # extract SELinux permissions for file /etc/passwd
        path = b'/etc/passwd'
        con = lgetfilecon_raw(path)
        print(con)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:31:48.795358
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    rc, context = matchpathcon('/tmp', 0)
    print(rc)
    print(context)


# Generated at 2022-06-22 22:31:50.064986
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0



# Generated at 2022-06-22 22:31:52.342159
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert len(res) == 2
    assert res[0] == 0
    assert res[1] == 'targeted'



# Generated at 2022-06-22 22:31:57.681399
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    selinux.selinux_getpolicytype()
    """
    type_ = selinux_getpolicytype()[1]
    assert type_ in ('targeted', 'mls', 'minimum', 'strict', 'permissive'), \
           "selinux.selinux_getpolicytype(): " \
           "Invalid type %r, must be in ('targeted', 'mls', 'minimum', 'strict', 'permissive')." % type_

# Generated at 2022-06-22 22:32:00.910288
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        print(selinux_getenforcemode())
    except NotImplementedError:
        print('Function selinux_getenforcemode is not implemented')


# Generated at 2022-06-22 22:32:04.667316
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Get the policy type
    rc, policytype = selinux_getpolicytype()
    # Ensure the policy type is valid
    assert policytype in ['targeted', 'minimum', 'mls', 'strict']
    # Ensure the return code is 0
    assert rc == 0

# Generated at 2022-06-22 22:32:11.338974
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:32:15.526953
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/etc/passwd')
    print(r)



# Generated at 2022-06-22 22:32:19.262160
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-22 22:32:27.168496
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test selinux function selinux_getenforcemode using mocked library."""
    from ansible.module_utils.selinux import _selinux_lib

    _selinux_lib.selinux_getenforcemode.return_value = 1

    assert _selinux_lib.selinux_getenforcemode() == 1

    enforcemode = c_int()
    _selinux_lib.selinux_getenforcemode.return_value = 0

    assert _selinux_lib.selinux_getenforcemode(byref(enforcemode)) == 0
    assert enforcemode.value == 1
    _selinux_lib.selinux_getenforcemode.reset_mock()

# Generated at 2022-06-22 22:32:32.141791
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    if rc != 0:
        print(rc)
        raise AssertionError('selinux_getenforcemode() failed!')

    assert(isinstance(enforcemode, int))

