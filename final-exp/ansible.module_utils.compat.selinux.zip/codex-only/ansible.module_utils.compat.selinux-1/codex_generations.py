

# Generated at 2022-06-22 22:22:36.562921
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/tmp/test"
    rc, result = matchpathcon(path, 0)
    assert rc == -1 and result == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:22:39.069555
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1


# Generated at 2022-06-22 22:22:46.390208
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/var/log/messages', 0)
    assert isinstance(res, list), "res is a list"
    assert len(res) == 2, "res has 2 items"
    assert isinstance(res[0], int), "res[0] is an int"
    assert isinstance(res[1], str), "res[1] is a str"
    assert res[0] == -1, "res[0] is -1"
    assert res[1] == 'system_u:object_r:var_log_t:s0', "res[1] is system_u:object_r:var_log_t:s0"

# Generated at 2022-06-22 22:22:49.677172
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert rc == 0
    # Policy type can be one of mls, targeted, minimum, or strict.
    assert policytype in ['mls', 'targeted', 'minimum', 'strict']

# Generated at 2022-06-22 22:22:52.238988
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/log', 0)
    assert rc == 0
    assert con == 'var_log_t'



# Generated at 2022-06-22 22:22:54.906372
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = '/'
    result = lgetfilecon_raw(f)
    assert result[0] == 0
    assert 'system_u:object_r:root_t' in result[1]


# Generated at 2022-06-22 22:22:55.771573
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2

# Generated at 2022-06-22 22:22:59.553710
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This is unit test for function matchpathcon
    Returns:
        boolean: True if test passed, otherwise False
    """

    import tempfile

    temp_file = tempfile.NamedTemporaryFile()
    if matchpathcon(temp_file.name, 0)[1] is not None:
        return True
    return False

# Generated at 2022-06-22 22:23:05.940508
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Check the return value of selinux_getpolicytype when selinux is disabled
    rc, policytype = selinux_getpolicytype()
    if rc != 0:
        raise AssertionError("selinux is enabled but should be disabled")
    if policytype is not None:
        raise AssertionError("policytype should not be defined")

# Generated at 2022-06-22 22:23:15.416571
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """This is a basic unit test for the lgetfilecon_raw
    """
    import tempfile
    import base64
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.selinux_common import lgetfilecon_raw

    fd, name = tempfile.mkstemp()

# Generated at 2022-06-22 22:23:19.878351
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, "Could not get policy type"
    assert policytype == "targeted", "Policy type is not targeted"


# Generated at 2022-06-22 22:23:26.607375
# Unit test for function matchpathcon
def test_matchpathcon():
    # First test: should not fail
    filepath = '/etc/mock/fcgi.conf'
    mode = os.stat(filepath).st_mode
    rc, con = matchpathcon(filepath, mode)
    assert rc == 0, "{0} with mode {1} should not fail".format(filepath, mode)
    assert con == 'system_conf_t', "Wrong context '%s' for file %s with mode %s" % (con, filepath, mode)



# Generated at 2022-06-22 22:23:30.227398
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b"/bin/ls", 0)
    assert rc == 0
    assert con == "bin_t"


# Generated at 2022-06-22 22:23:32.842260
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode == 0 or mode == 1



# Generated at 2022-06-22 22:23:43.538348
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    f = open(test_file, 'w')
    f.close()
    try:
        result = lgetfilecon_raw(test_file)
        rc = result[0]
        if rc < 0:
            raise OSError(rc, os.strerror(rc))
        if '<<none>>' in result[1]:
            print('test_lgetfilecon_raw failed: context returned is <<none>>')
            return False
    finally:
        shutil.rmtree(test_dir)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:23:54.737582
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1:
    #
    #   Assert that match pathcon for /sys/kernel/security/selinux returns
    #   0 as the return code and that the correct context string is returned
    #   (unconfined_r:unconfined_t:system_r:security_t:system_security_t)
    #
    ref_context = "unconfined_r:unconfined_t:system_r:security_t:system_security_t"
    test_name = sys._getframe().f_code.co_name
    os.chdir("/sys/kernel/security/selinux")
    ret_rc, ret_str = matchpathcon(".", 0)
    if ret_rc == 0 and ret_str == ref_context:
        test_str = "PASSED"

# Generated at 2022-06-22 22:23:58.531493
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/shadow', 0)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'



# Generated at 2022-06-22 22:24:04.633160
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check that the function returns a list of two ints.
    assert isinstance(selinux_getenforcemode(), list)
    assert len(selinux_getenforcemode()) == 2
    assert isinstance(selinux_getenforcemode()[0], int)
    assert isinstance(selinux_getenforcemode()[1], int)



# Generated at 2022-06-22 22:24:07.096733
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw("/usr/bin/python")
    assert(result[0] == 0)
    assert(result[1] == "system_u:object_r:usr_t:s0")



# Generated at 2022-06-22 22:24:14.964998
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/group', 0)
    assert rc == 0
    assert con == 'clamav_var_run_t'

    rc, con = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert con == 'clamav_var_run_t'

# Generated at 2022-06-22 22:24:19.827774
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw.

    This test is expected to fail if selinux is not available.
    """
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as tmpfile:
        lgetfilecon_raw(tmpfile.name)

# Generated at 2022-06-22 22:24:23.193802
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        raise ImportError('Running unit test failed with rc: %s' % (str(rc)))



# Generated at 2022-06-22 22:24:29.278404
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Passing invalid file path should return 'None'
    assert lgetfilecon_raw('invalid_file_path') == [1, None]
    # Passing valid file should return 'system_u:object_r:tmp_t:s0'
    assert lgetfilecon_raw('/etc/hosts') == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-22 22:24:31.722625
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Should return 0, 'targeted'
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'

# Generated at 2022-06-22 22:24:36.319932
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    import sys
    import subprocess
    try:
        output = subprocess.check_output(['selinuxenabled'], shell=True, universal_newlines=True)
    except subprocess.CalledProcessError as e:
        output = e.output

    assert output == "SELinux status is enabled\n"
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode == 1



# Generated at 2022-06-22 22:24:38.240820
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print(selinux_getenforcemode())



# Generated at 2022-06-22 22:24:40.705128
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/foo/bar', 1) == [1, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-22 22:24:42.763768
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    assert rc >= 0
    assert isinstance(mode, int)



# Generated at 2022-06-22 22:24:45.051523
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'



# Generated at 2022-06-22 22:24:52.748632
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            test_string=dict(type='str', default='../test/files/selinux_getenforcemode'),
        ),
        supports_check_mode=True
    )
    selinux_getenforcemode_result = selinux_getenforcemode()
    module.exit_json(
        selinux_getenforcemode=selinux_getenforcemode_result,
    )



# Generated at 2022-06-22 22:24:56.606111
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    for i in range(40):
        try:
            selinux_getpolicytype()
        except OSError:
            pass
        else:
            assert True  # This is expected
            break
    else:
        assert False, "Expected selinux_getpolicytype to throw"

# Generated at 2022-06-22 22:24:59.532428
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert isinstance(res[0], int)
    assert isinstance(res[1], str)
    assert res[0] == 0
    assert 'targeted' in res[1]


# Generated at 2022-06-22 22:25:02.578528
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == is_selinux_enabled()



# Generated at 2022-06-22 22:25:08.875442
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    msg = "selinux_getenforcemode - "
    rc, rval = selinux_getenforcemode()
    if rval < 0 or rval > 2:
        module.fail_json(msg="%s Expected return value between 0 - 2 but found %d" % (msg, rval))
    module.exit_json(msg="SELinux is %s" % ("enabled" if rval == 1 else "disabled"))



# Generated at 2022-06-22 22:25:11.213528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.realpath(__file__)
    assert path

    # Ensures that the function is callable
    lgetfilecon_raw(path)



# Generated at 2022-06-22 22:25:17.043976
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/selinux/config2') == [
        -1, 'no such file or directory'
    ]


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:25:21.848079
# Unit test for function matchpathcon
def test_matchpathcon():
    # result from matchpathcon on a file
    (rc, con) = matchpathcon('/etc/passwd', os.stat('/etc/passwd').st_mode)
    # result from matchpathcon on a directory
    (rc, con) = matchpathcon('/etc', os.stat('/etc').st_mode)
    print(con)


# Generated at 2022-06-22 22:25:26.235481
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/foo', 0) == [0, b'system_u:object_r:foo_t:s0']


# Generated at 2022-06-22 22:25:28.450023
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert ret[1] in [0, 1, 2], "Expecting 0, 1 or 2 in ret[1]"



# Generated at 2022-06-22 22:25:30.094824
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy_type] = selinux_getpolicytype()
    assert rc == 0
    assert policy_type == 'targeted'


# Generated at 2022-06-22 22:25:31.353042
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:25:37.644731
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled()[1]:
        [rc, con] = matchpathcon("/home", os.R_OK)
        assert con == "user_home_t"
    else:
        [rc, con] = matchpathcon("/home", os.R_OK)
        assert con == "unlabeled_t"

# Generated at 2022-06-22 22:25:42.419151
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''Test selinux_getpolicytype'''
    import json

    results = selinux_getpolicytype()
    print(json.dumps(results, indent=4, sort_keys=True))

# Generated at 2022-06-22 22:25:45.651747
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import pytest
    from ansible.module_utils.selinux import selinux_getpolicytype
    [rc, type] = selinux_getpolicytype()
    assert rc == 0
    assert type == "targeted"



# Generated at 2022-06-22 22:25:56.589010
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.ansible.community.plugins.module_utils.selinux import matchpathcon
    from ansible_collections.ansible.community.plugins.module_utils.selinux import lgetfilecon_raw
    import tempfile

    error_msg = None
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.mkstemp(dir=tmp_dir)
    tmp_con = lgetfilecon_raw(tmp_dir)[1]
    file_con = lgetfilecon_raw(tmp_file[1])[1]


# Generated at 2022-06-22 22:25:59.896267
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.ansible.community.tests.unit.modules.utils.selinux_policycontext import SELinuxPolicyContext
    sys.path.append('../utils')
    policy_context = SELinuxPolicyContext()
    # Test for get default selinux context
    path = to_bytes(policy_context.src_dir)
    assert matchpathcon(path, 0)[0] == 0

# Generated at 2022-06-22 22:26:03.087810
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/shadow'
    mode = os.R_OK
    ret, context = matchpathcon(path, mode)
    assert ret == 0
    assert context == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-22 22:26:10.489991
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    rc, con = lgetfilecon_raw(os.path.join(__location__, 'lgetfilecon_raw.py'))

    if rc < 0 and rc != -1:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))

    print(con)



# Generated at 2022-06-22 22:26:20.453719
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted'], 'Expected selinux policy to be targeted'
    assert selinux_getpolicytype()[0] == 0, \
        'Expected selinux getpolicytype to return a 0 status, but got {0}:{1}'.format(selinux_getpolicytype()[0],
                                                                                      os.strerror(selinux_getpolicytype()[0]))
    assert selinux_getpolicytype()[1] == 'targeted', \
        'Expected selinux getpolicytype to return a targeted policy type, but got {0}'.format(
            selinux_getpolicytype()[1])


# Generated at 2022-06-22 22:26:23.376519
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'


# Generated at 2022-06-22 22:26:29.344832
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    assert rc >= 0, "lgetfilecon_raw returned -1"
    assert len(con) > 0, "lgetfilecon_raw returned an empty string for /tmp"
    assert con.split(':')[2] == "tmp_t", "lgetfilecon_raw returned an incorrect context: " + con


# Generated at 2022-06-22 22:26:36.709414
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy_type) = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype failed with rc={0}".format(rc)
    assert policy_type == 'targeted', "selinux_getpolicytype failed, result={0}".format(policy_type)


if __name__ == "__main__":
    import sys

    test_selinux_getpolicytype()

    sys.exit(0)

# Generated at 2022-06-22 22:26:49.400911
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[0] == 0
    assert matchpathcon('/', 1)[0] == 0
    assert matchpathcon('/boot', 1)[0] == 0
    assert matchpathcon('/boot/grub2/grub.cfg', 1)[0] == 0
    assert matchpathcon('/dev/null', 1)[0] == 0
    assert matchpathcon('/dev/sda', 1)[0] == 0
    assert matchpathcon('/etc', 1)[0] == 0
    assert matchpathcon('/etc/shadow', 1)[0] == 0
    assert matchpathcon('/etc/hosts', 1)[0] == 0
    assert matchpathcon('/etc/passwd', 1)[0] == 0
    assert matchpathcon('/etc/shadow', 1)[0] == 0

# Generated at 2022-06-22 22:26:57.563493
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux_common import selinux_preserve_path_context, SELINUX_POLICY_MINIMUM_VERSION
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text

    if not matchpathcon('/tmp', os.R_OK)[1]:
        raise AssertionError('TEST FAILURE: Unable to test selinux_common.selinux_preserve_path_context()')

    paths = [
        '/tmp/var/tmp',
        '/tmp/var/tmp/etc/tmp',
        '/tmp/var/tmp/etc/tmp/var/tmp/etc/tmp']

# Generated at 2022-06-22 22:27:02.505776
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('\n\nFunction test.selinux_getpolicytype')
    [rc, policy_type] = selinux_getpolicytype()
    if rc < 0:
        print('Error:', os.strerror(rc))
    else:
        print('Policy type:', policy_type)


# Generated at 2022-06-22 22:27:12.137791
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    try:
        i, fname = tempfile.mkstemp()
        with os.fdopen(i, 'w') as fh:
            fh.write("sample")
        rc, con = matchpathcon(fname, 0)
        # File exists and matches context, so rc=0
        assert rc == 0, "unexpected failure"
        print("rc=%d con=%s" % (rc, con))

    except OSError as e:
        print("unexpected OSError: %s" % e)
    finally:
        os.unlink(fname)

# Generated at 2022-06-22 22:27:16.307096
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test success scenario
    assert lgetfilecon_raw('/etc')[0] == 0
    # Test failure scenario
    assert lgetfilecon_raw('/blah')[0] == -1


# Generated at 2022-06-22 22:27:17.949873
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforce, int)
    # FIXME: check that the resulting value makes sense


# Generated at 2022-06-22 22:27:20.049590
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-22 22:27:20.749562
# Unit test for function matchpathcon
def test_matchpathcon():
    pass

# Generated at 2022-06-22 22:27:25.929578
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest

    class SelinuxGetpolicytypeTestCase(unittest.TestCase):
        def test_selinux_getpolicytype(self):
            rc, policy_type = selinux_getpolicytype()
            self.assertEqual(rc, 0)
            self.assertNotEqual(policy_type, '')

    unittest.main()


# Generated at 2022-06-22 22:27:30.730056
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, "Error: %s" % policytype
    assert isinstance(policytype, str), "Invalid type for policytype " + policytype
    assert len(policytype) > 0, "policytype cannot be empty."



# Generated at 2022-06-22 22:27:33.442696
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0
    assert result[1] in [0, 1, 2]


# Generated at 2022-06-22 22:27:34.856271
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]

# Generated at 2022-06-22 22:27:37.919731
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    t_con = "unconfined_u:object_r:user_tmp_t:s0" # Test file has this context
    assert lgetfilecon_raw("/tmp/context_test.txt")[1] == t_con

# Generated at 2022-06-22 22:27:42.006212
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    getpolicytype = selinux_getpolicytype()
    assert getpolicytype[0] == 0
    assert getpolicytype[1].startswith('selinuxfs')

# Generated at 2022-06-22 22:27:44.062982
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert isinstance(res[1], str)


# Generated at 2022-06-22 22:27:48.030619
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    assert policytype in ['targeted', 'mls', 'strict']


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:27:54.258770
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for function matchpathcon with mode = 0
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t:s0']
    # Test for function matchpathcon with mode = 1
    assert matchpathcon('/tmp', 1) == [0, 'system_u:object_r:tmp_t']
    # Test for function matchpathcon with mode = 2
    assert matchpathcon('/tmp', 2) == [1, 'system_u:object_r:tmp_t']
    # Test for function matchpathcon with mode = 3
    assert matchpathcon('/tmp', 3) == [1, 'system_u:object_r:tmp_t']
    # Test for function matchpathcon with mode = 4

# Generated at 2022-06-22 22:28:04.085113
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/passwd', 0)
    assert result[0] == 0
    assert result == [0, 'system_u:object_r:passwd_file_t:s0']

    result = matchpathcon(b'/etc/passwd', 0)
    assert result[0] == 0
    assert result == [0, 'system_u:object_r:passwd_file_t:s0']

    try:
        result = matchpathcon(25, 0)
        assert False, "matchpathcon should raise a TypeError for all arguments"
    except TypeError:
        pass

    try:
        result = matchpathcon('/etc/passwd', 'test')
        assert False, "matchpathcon should raise a TypeError for all arguments"
    except TypeError:
        pass


# Generated at 2022-06-22 22:28:10.293737
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/python'
    mode = os.R_OK
    rc = matchpathcon(path, mode)
    assert rc[0] == 0
    assert rc[1] is not None
    assert rc[1] != ""


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:12.978851
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)

# Generated at 2022-06-22 22:28:15.360849
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import _selinux
    [rc, ptype] = _selinux.selinux_getpolicytype()
    print(rc, ptype)



# Generated at 2022-06-22 22:28:21.368727
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import ansible.module_utils.basic as basic
    rc, policytype = selinux_getpolicytype()
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    module.exit_json(selinux_getpolicytype=policytype)



# Generated at 2022-06-22 22:28:23.900368
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert (rc == 0)
    assert (enforcemode == 1)



# Generated at 2022-06-22 22:28:27.902677
# Unit test for function matchpathcon
def test_matchpathcon():
    out = matchpathcon("/var/www", 0)
    assert out[0] == 0
    assert out[1] == "system_u:object_r:httpd_sys_content_t:s0"



# Generated at 2022-06-22 22:28:37.562945
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return

    import tempfile
    import shutil
    try:
        tmpdir = tempfile.mkdtemp()
        sample_path = tmpdir + '/sample'
        ret = lgetfilecon_raw(sample_path)
        assert ret[0] == -1 and ret[1] is None

        with open(sample_path, 'w') as f:
            pass
        ret = lgetfilecon_raw(sample_path)
        assert ret[0] == -1 and ret[1] is None

        shutil.rmtree(tmpdir)
    finally:
        pass

# Generated at 2022-06-22 22:28:49.106498
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json
    import subprocess
    import tempfile
    import time

    tmpfile = tempfile.NamedTemporaryFile()


# Generated at 2022-06-22 22:28:52.394534
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        if not is_selinux_enabled():
            return
        rc = selinux_getpolicytype()
    except OSError:
        pass

# Generated at 2022-06-22 22:28:56.209170
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: this will likely fail for users that do not have selinux enabled
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:29:06.380607
# Unit test for function matchpathcon
def test_matchpathcon():
    # matchpathcon
    #   no default context
    #   invalid path
    #   negative mode
    #   default context
    #   default context on invalid path

    def_con_path, def_con_mode, def_con_context = 'etc/ssh/sshd_config', 7, 'ssh_config_t'

    # no default context
    #   path: /etc/ssh/sshd_config
    #   mode: 7
    rc, context = matchpathcon(def_con_path, def_con_mode)
    assert rc == 0
    assert context == def_con_context

    # invalid path
    rc, context = matchpathcon('/invalid/test123', def_con_mode)
    assert rc == -1
    assert context == 'No such file or directory'

    # negative mode
    rc

# Generated at 2022-06-22 22:29:08.196201
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2


# Generated at 2022-06-22 22:29:11.700068
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    errmsg = "Return value is not 1"
    assert rc == 1, errmsg

    errmsg = "Boolean value is not set correctly"
    assert enforcemode == 1, errmsg



# Generated at 2022-06-22 22:29:14.797507
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-22 22:29:15.744938
# Unit test for function matchpathcon
def test_matchpathcon():
    if __name__ == '__main__':
        pass

# Generated at 2022-06-22 22:29:18.638358
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon(b'/etc/foo', 0))
    print(matchpathcon('/etc/foo', os.R_OK))

# Generated at 2022-06-22 22:29:23.119434
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from types import BuiltinFunctionType

    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(enforcemode, int)
    assert rc in (0, 1, 2)
    assert enforcemode in (0, 1, 2)
    assert rc == enforcemode



# Generated at 2022-06-22 22:29:24.465807
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:29:25.537171
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == lgetfilecon_raw('/')[0]

# Generated at 2022-06-22 22:29:30.725341
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = 'test_path'
    test_mode = 0
    rc, result = matchpathcon(test_path, test_mode)
    print("%s: %s" % (rc, result))



# Generated at 2022-06-22 22:29:38.676743
# Unit test for function matchpathcon
def test_matchpathcon():
    import os.path

    # This will change whether the path already exists
    # We want to return an error to the user, because
    # the path might not exist, and the user might not
    # have the perms to create subdirs, etc.

    dont_exist_path = os.path.join('/', 'tmp', 'pysidu', 'doesnt_exist')
    this_path = os.path.abspath(__file__)

    assert os.path.exists(this_path)

    # should raise OSError with errno 2 from linux kernel
    try:
        # should fail
        matchpathcon(dont_exist_path, 0)
    except OSError as ose:
        assert ose.errno == 2

    # should not raise OSError
    assert matchpathcon

# Generated at 2022-06-22 22:29:46.121536
# Unit test for function matchpathcon
def test_matchpathcon():
    # if ctypes can't load selinux, we don't want to run
    assert hasattr(selinux_getenforcemode, 'restype')

    # test with a real file
    touch('/tmp/test_selinux.txt')
    try:
        assert matchpathcon('/tmp/test_selinux.txt', 0) == 0, 'could not find a default context for /tmp/test_selinux.txt'
    finally:
        os.unlink('/tmp/test_selinux.txt')

    # test with a real directory
    assert matchpathcon('/tmp', 0) == 0, 'could not find a default context for /tmp'

# Generated at 2022-06-22 22:29:52.332193
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test the case of a directory
    path = '/usr'
    mode = 0

    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith('system_u:object_r:usr_t')

    # Test the case of a file
    path = '/usr/bin/python3'
    mode = 0

    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith('system_u:object_r:usr_t')



# Generated at 2022-06-22 22:29:55.841312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/bin/bash') == [0, 'system_u:object_r:shell_exec_t:s0']



# Generated at 2022-06-22 22:29:58.681614
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    rc, con = matchpathcon(os.path.realpath(__file__), 0)
    assert rc == 0

# Generated at 2022-06-22 22:30:02.946722
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        assert selinux_getenforcemode()[1] in (0, 1)
    except OSError:
        # skip if selinux is not enabled
        pass



# Generated at 2022-06-22 22:30:05.955556
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode in [0, 1, 2]



# Generated at 2022-06-22 22:30:09.543968
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: need to test when SELinux is disabled
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:30:19.571509
# Unit test for function matchpathcon
def test_matchpathcon():
    # The mode for file
    mode = 0o666
    # The path
    path = '/etc/test'
    # The expected context
    exp_context = 'system_u:object_r:etc_t:s0'
    # Test the functions
    [rc, context] = matchpathcon(path, mode)
    if rc != 0:
        print('Error: %d %s' % (rc, context))
        sys.exit(rc)
    if context != exp_context:
        print('Error: context %s != %s' % (context, exp_context))
        sys.exit(1)
    sys.exit(0)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:29.141742
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a test file and test dir
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile()

    # Test matchpathcon
    assert(matchpathcon(temp_file.name, os.R_OK)[1] == 'system_u:object_r:tmp_t:s0')
    assert(matchpathcon(temp_dir, os.R_OK)[1] == 'system_u:object_r:tmp_t:s0')
    assert(matchpathcon('/tmp', os.R_OK)[1] == 'system_u:object_r:tmp_t:s0')



# Generated at 2022-06-22 22:30:33.798577
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    (rc, con) = lgetfilecon_raw("/etc/shadow")
    assert rc == 0
    assert con == "system_u:object_r:shadow_t:s0"
    print("getfilecon_raw rc: " + str(rc))
    print("getfilecon_raw con: " + con)



# Generated at 2022-06-22 22:30:45.929370
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_attrs = dict(
        path=os.path.expanduser('~'),
        exp_result=0,
    )
    with open(__file__) as f:
        test_text = f.read()

    try:
        with open('/tmp/selinux_test_lgetfilecon', 'w') as f:
            f.write(test_text)
        rc, result = lgetfilecon_raw('/tmp/selinux_test_lgetfilecon')
        os.remove('/tmp/selinux_test_lgetfilecon')
    except OSError:
        return 'SKIP: unable to create file for testing'


# Generated at 2022-06-22 22:30:52.927979
# Unit test for function matchpathcon

# Generated at 2022-06-22 22:30:55.237977
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode in (0, 1, 2)


# Generated at 2022-06-22 22:30:58.967082
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/foo'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print(rc, con)



# Generated at 2022-06-22 22:31:06.428131
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Test the matchpathcon() wrapper function
    :return:
    '''
    path = '/tmp/foo'
    mode = 0
    rc = matchpathcon(path, mode)
    print("Return code: " + str(rc[0]) + ", Con: " + str(rc[1]))
    assert rc[0] >= 0

if __name__ == "__main__":
    # Run the function test
    test_matchpathcon()

# Generated at 2022-06-22 22:31:15.701600
# Unit test for function matchpathcon
def test_matchpathcon():

    results = matchpathcon('/etc/passwd', os.R_OK)
    assert results[0] == 0
    assert results[1] == 'system_u:object_r:etc_runtime_t:s0'

    results = matchpathcon('/etc/passwd', os.W_OK)
    assert results[0] != 0

    results = matchpathcon('/foo/bar', os.R_OK)
    assert results[0] != 0

    results = matchpathcon('/foo/bar', os.R_OK | os.X_OK | os.W_OK | os.F_OK)
    assert results[0] != 0

# Generated at 2022-06-22 22:31:18.976727
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode_rc, enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, int)
    assert isinstance(enforcemode_rc, int)



# Generated at 2022-06-22 22:31:26.139810
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from distutils.version import LooseVersion

    min_ver = LooseVersion('3.12')
    max_ver = LooseVersion('3.13')

    # Skip test if system libselinux version outside acceptable range
    # NB: Version strings are from test system, not selinux project
    ver = LooseVersion(selinux_getpolicytype.__doc__.split('ver')[1].split()[0])
    if not (min_ver < ver < max_ver):
        pytest.skip('Test requires selinux version {}-{}'.format(min_ver, max_ver))

    # Check if policy version is nonzero
    assert selinux_getpolicytype()[0] > 0

# Generated at 2022-06-22 22:31:32.369972
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce_mode = selinux_getenforcemode()

    if enforce_mode[0] == 0:
        if enforce_mode[1] == 1:
            assert enforce_mode[1] == 1
        elif enforce_mode[1] == 0:
            assert enforce_mode[1] == 0
        else:
            assert False, 'enforce_mode[1] should be 1 or 0'
    else:
        assert False


# Generated at 2022-06-22 22:31:39.740353
# Unit test for function matchpathcon
def test_matchpathcon():
    import os.path

    test_dir = os.path.dirname(os.path.abspath(__file__))
    f = os.path.join(test_dir, 'ansible.py')
    assert matchpathcon(f, os.stat(f).st_mode)[1] == 'system_u:object_r:ansible_python_exec_t:s0'

# Generated at 2022-06-22 22:31:49.919489
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import filecmp

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    f = open(tmpfile, 'w')
    f.close()
    # call function on none existing file
    try:
        os.remove(tmpfile)
        rc, con = lgetfilecon_raw(tmpfile)
        # the call should fail because the file does not exist
        assert rc == -1
        assert con == ''
    except:
        assert False

    # create the file again and set its context
    f = open(tmpfile, 'w')
    f.close()

# Generated at 2022-06-22 22:31:54.656906
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: add a real unit test here
    from ansible.module_utils._text import to_native
    result = selinux_getenforcemode()
    # the result is a tuple, but the first element is the only thing that matters
    rc = result[0]
    if rc is not 0:
        raise OSError(rc, to_native(os.strerror(rc)))
    return 1



# Generated at 2022-06-22 22:32:00.710556
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fd, fn = mkstemp()
    try:
        path = '/tmp/' + fn
        rc, con = lgetfilecon_raw(path)
        if rc < 0:
            raise Exception(os.strerror(get_errno()))
        print(con)
    finally:
        unlink(path)



# Generated at 2022-06-22 22:32:03.500592
# Unit test for function matchpathcon
def test_matchpathcon():
    # Check for root directory
    [rc, con] = matchpathcon('/', 0)
    if rc != 0:
        raise AssertionError('matchpathcon failed')
    print(con)



# Generated at 2022-06-22 22:32:08.629026
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/ansible95394'
    open(path, 'a').close()
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_tmp_t:s0'
    os.remove(path)

# Generated at 2022-06-22 22:32:10.264680
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # returns a list instead of just the integer
    assert selinux_getenforcemode()[0] >= 0, to_native(selinux_getenforcemode())



# Generated at 2022-06-22 22:32:17.401178
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/this_file_doesnt_exist", os.R_OK)[0] != 0
    assert matchpathcon("/tmp", os.R_OK)[0] == 0
    assert matchpathcon("/tmp", os.R_OK)[1] is not None



# Generated at 2022-06-22 22:32:23.323620
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.basic import AnsibleModule
    import textwrap

    results = selinux_getpolicytype()

    if results[0] != 0:
        raise Exception('SELinux get policy type failed: {0}'.format(results[0]))

    module_args = dict(get_policy_type='yes')

    module = AnsibleModule(argument_spec=module_args)
    module.exit_json(policy_type=results[1])

# Generated at 2022-06-22 22:32:26.938451
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policy_type = selinux_getpolicytype()
    except ImportError:
        rc = -1
        policy_type = None

    assert rc == 0
    assert isinstance(policy_type, str)



# Generated at 2022-06-22 22:32:30.264353
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = '/etc/passwd'
    rc, con = lgetfilecon_raw(filepath)
    if rc >= 0:
        print ("The file " + filepath + " has context " + con)
    else:
        print ("An error occurred while retrieving context of file " + filepath)


# Generated at 2022-06-22 22:32:36.679615
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return_data = selinux_getenforcemode()
    rc = return_data[0]
    mode = return_data[1]

    return_error = "rc=" + str(rc) + ", mode=" + str(mode)
    assert rc >= 0, return_error

    if rc == 0:
        assert mode == 0 or mode == 1, return_error
    else:
        assert mode == -1, return_error

