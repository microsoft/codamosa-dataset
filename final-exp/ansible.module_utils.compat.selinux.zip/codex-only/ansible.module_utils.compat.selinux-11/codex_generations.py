

# Generated at 2022-06-22 22:22:35.977862
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    def _run_test():
        from ansible.module_utils._text import to_native
        from ansible.module_utils.selinux import selinux_getpolicytype

        success, policytype = selinux_getpolicytype()
        print('SELinux get policytype: {0} {1}'.format(success, to_native(policytype)))
        assert success == 0

    if __name__ == "__main__":
        _run_test()

# Generated at 2022-06-22 22:22:38.584951
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, result = selinux_getenforcemode()
    print('SELinux Enforcemode:')
    print(result)



# Generated at 2022-06-22 22:22:41.144942
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, filecon) = lgetfilecon_raw('/etc/passwd')
    return (rc, filecon)


# Generated at 2022-06-22 22:22:51.484850
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import random
    import string
    import tempfile
    import subprocess
    from ctypes import create_string_buffer

    policy_type = selinux_getpolicytype()[1]
    if policy_type == "modules":
        if selinux_getenforcemode()[1] == -1:
            subprocess.check_output(["/usr/sbin/semodule", "-n", "--force"])
        subprocess.check_output(["/usr/sbin/semodule", "-e", "ansible-test"])
        subprocess.check_output(["/usr/bin/semanage", "fcontext", "-a", "-t", "ansible_test_file_t", "/tmp/ansible_test(/.*)?"])

# Generated at 2022-06-22 22:22:54.528497
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, typ = selinux_getpolicytype()
    print('selinux_getpolicytype rc: {0}'.format(rc))
    print('selinux_getpolicytype return: {0}'.format(typ))



# Generated at 2022-06-22 22:22:56.801298
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()

    assert rc == 0
    assert policy_type == 'targeted'


# Generated at 2022-06-22 22:22:57.970841
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:23:06.337407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Get the path to the current file and run a lgetfilecon_raw check against the file
    path_to_file = os.path.dirname(os.path.abspath(__file__))
    path_to_file = path_to_file + '/test_selinux.py'
    con_list = lgetfilecon_raw(path_to_file)
    print('test_lgetfilecon_raw:', con_list)



# Generated at 2022-06-22 22:23:10.375695
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    def test_selinux_getpolicytype_impl():
        rc, value = selinux_getpolicytype()
        assert rc == 0
        assert (value == 'targeted' or value == 'mls')

    test_selinux_getpolicytype_impl()

# Generated at 2022-06-22 22:23:18.041825
# Unit test for function matchpathcon
def test_matchpathcon():
    got = selinux_getenforcemode()
    assert type(got) is list
    assert len(got) == 2
    assert got[0] == 0
    assert type(got[1]) is int

    got = selinux_getpolicytype()
    assert type(got) is list
    assert len(got) == 2
    assert got[0] == 0
    assert type(got[1]) is str

    got = lgetfilecon_raw('/foo')
    assert type(got) is list
    assert len(got) == 2
    assert got[0] == 0
    assert type(got[1]) is str

    got = matchpathcon('/foo', 0)
    assert type(got) is list
    assert len(got) == 2
    assert got[0] == 0
    assert type(got[1])

# Generated at 2022-06-22 22:23:21.320593
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test when selinux is disabled
    try:
        os.environ['SELINUX_ENFORCING'] = '0'
        assert selinux_getenforcemode()[1] == 0
        assert security_policyvers() == 0
    finally:
        del os.environ['SELINUX_ENFORCING']
        assert selinux_getenforcemode()[1] == 1
        assert security_policyvers() > 0



# Generated at 2022-06-22 22:23:22.337078
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype

# Generated at 2022-06-22 22:23:26.496543
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/tmp/test', 0)
        print(con)
    except NotImplementedError:
        pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-22 22:23:29.257295
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[0] == 0
    assert type(policy[1]) == str

# Generated at 2022-06-22 22:23:32.746350
# Unit test for function matchpathcon
def test_matchpathcon():
    path = os.path.dirname(__file__)
    assert matchpathcon(path, 0) == [0, 'object_r:ansible_python_plugin_t:s0:c0,c106']

# Generated at 2022-06-22 22:23:41.499410
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for CentOS, should provide context
    if lgetfilecon_raw("/usr")[0] == 0:
        assert lgetfilecon_raw("/usr")[1] == "system_u:object_r:usr_t:s0"
    # Test for Debian, should provide context
    elif lgetfilecon_raw("/lib")[0] == 0:
        assert lgetfilecon_raw("/lib")[1] == "system_u:object_r:lib_t:s0"
    # Test for Fedora, should provide context
    elif lgetfilecon_raw("/bin")[0] == 0:
        assert lgetfilecon_raw("/bin")[1] == "system_u:object_r:bin_t:s0"
    # Test for Ubuntu, should provide context
   

# Generated at 2022-06-22 22:23:47.393579
# Unit test for function matchpathcon
def test_matchpathcon():
    test_string = '/var/tmp/test_matchpathcon'

    rc, con = matchpathcon(test_string, 0)
    if rc != 0:
        print('matchpathcon failed with error %d' % rc)
    else:
        print('matchpathcon returned context %s' % con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:23:51.762073
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # FIXME: this should be a doctest
    try:
        rc = selinux_getpolicytype()
    except NotImplementedError:
        return
    print('rc={0}'.format(rc))
    return rc

# Generated at 2022-06-22 22:24:03.020329
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path

    def _assert(path, res):
        rc, con = matchpathcon(path, os.R_OK)
        assert rc == 0, 'matchpathcon returned an error, con is invalid. rc=%s' % rc
        assert con == res, 'matchpathcon failed to return the correct context for %s, got "%s" instead' % (path, con)

    # /dev/null is a special case to test on all platforms
    _assert('/dev/null', 'system_u:object_r:devnull_t:s0')

    # On Fedora, /srv/nfs is SELinux enabled

# Generated at 2022-06-22 22:24:05.454586
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Calls function
    rc, con = selinux_getpolicytype()

    assert (rc == 0)
    assert (con == "targeted" or con == "mls")



# Generated at 2022-06-22 22:24:15.397773
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a temporary directory that is used for testing
    import tempfile
    import shutil
    testdir = tempfile.mkdtemp()
    
    # Create a file in that directory
    with open(os.path.join(testdir, 'hello.txt'), 'wb') as f:
        f.write(b'hello')

    # Match the context of that file
    rc, con = matchpathcon(os.path.join(testdir, 'hello.txt'), 0)
    assert rc == 0, 'matchpathcon failed'

    # Delete the temporary directory
    shutil.rmtree(testdir)

# Generated at 2022-06-22 22:24:18.647217
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1], 'Invalid selinux_getenforcemode() return value'


# Generated at 2022-06-22 22:24:21.163437
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/passwd')[1] == 'system_u:object_r:usr_t:s0'

# Generated at 2022-06-22 22:24:23.096075
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test = selinux_getpolicytype()
    if test[0]:
        return False
    return True


# Generated at 2022-06-22 22:24:25.033122
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, res = selinux_getpolicytype()
    assert rc == 0, res
    assert res == 'targeted', res



# Generated at 2022-06-22 22:24:31.561235
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'test_selinux_getpolicytype: selinux_getpolicytype failed to get policy type'
    assert len(policytype) > 0, 'test_selinux_getpolicytype: selinux_getpolicytype failed to get non-empty policy type'
    assert policytype.find('.') > 1, 'test_selinux_getpolicytype: selinux_getpolicytype failed to get policy version'


# Generated at 2022-06-22 22:24:38.439485
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:file_t:s0']
    assert matchpathcon('/', 2) == [0, 'system_u:object_r:file_t:s0']
    assert matchpathcon('/home', 0) == [0, 'system_u:object_r:home_root_t:s0']
    assert matchpathcon('/home', 2) == [0, 'system_u:object_r:home_root_t:s0']
    assert matchpathcon('/home/foo', 0) == [0, 'unconfined_u:object_r:user_home_t:s0']

# Generated at 2022-06-22 22:24:43.737796
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest
    try:
        rc, con = matchpathcon('/etc/passwd', 0)
    except OSError:
        pytest.skip("permission denied, or SELinux not enabled")
    assert rc == 0
    assert con is not None
    rc, con = matchpathcon('./passwd', 0)
    assert rc == -1
    assert con is None

# Generated at 2022-06-22 22:24:46.842369
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var'
    mode = 0o7
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert 'system_u:object_r:usr_t:s0' in result[1]

# Note: matchpathcon is deprecated and should be rewritten on selabel_lookup (but will be a PITA)

# Generated at 2022-06-22 22:24:49.800664
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert(rc >= 0)
    assert(enforcemode in [0, 1, 2])



# Generated at 2022-06-22 22:24:53.813169
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (_rc, policytype) = selinux_getpolicytype()
    assert _rc == 0
    assert isinstance(policytype, basestring)
    print("selinux_getpolicytype()=%s" % policytype)


# Generated at 2022-06-22 22:24:58.081910
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path='/etc/ansible/ansible.cfg'
    rc, con = lgetfilecon_raw(path)
    assert(rc == 0)
    assert(con is not None)
    assert(con != '')
    assert(con != 'system_u:object_r:default_t:s0')



# Generated at 2022-06-22 22:25:00.990984
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:25:06.339380
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/usr/bin/python2.7'
    test_con = 'system_u:object_r:bin_t:s0'
    rc, con = lgetfilecon_raw(test_path)

    if rc == 0:
        assert(test_con == con)
    else:
        print("FAILED: rc is {0} and con is {1}".format(rc, con))


# Generated at 2022-06-22 22:25:14.125656
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test the return value of selinux_getenforcemode
    '''
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0
    #
    # Test the return value of _selinux_lib.selinux_getenforcemode
    #
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert rc == 0
    assert enforcemode == 0
#

# Generated at 2022-06-22 22:25:17.350871
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/selinux")
    assert rc is 0
    assert con == "ug:object_r:semanage_store_t:s0"


# Generated at 2022-06-22 22:25:20.592748
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_result = selinux_getenforcemode()
    if test_result[0] >= 0 and test_result[1] in [0, 1]:
        return test_result[1]
    else:
        return -1



# Generated at 2022-06-22 22:25:25.007187
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    print("policy type is " + str(policytype))


# Unittest for function selinux_getenforcemode

# Generated at 2022-06-22 22:25:27.148492
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils._selinux import selinux_getpolicytype
    assert selinux_getpolicytype()[1].startswith('targeted')

# Generated at 2022-06-22 22:25:29.414674
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = _selinux_lib.matchpathcon('/tmp', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:25:32.934405
# Unit test for function matchpathcon
def test_matchpathcon():
    d = {}
    rc, selinux_context = matchpathcon(b"/etc/passwd", 0)
    d['rc'] = rc
    d['selinux_context'] = selinux_context
    return d

# Generated at 2022-06-22 22:25:43.387745
# Unit test for function matchpathcon
def test_matchpathcon():
    # C lib returns ENOENT if path not found
    # File not found, mode 0
    rc, con = matchpathcon('/tmp/test_file', 0)
    assert rc == -2
    rc, con = matchpathcon('/bin/ls', 0)
    assert rc == 0
    rc, con = matchpathcon('/bin/ls', 1)
    assert rc == 0
    rc, con = matchpathcon('/bin/ls', 2)
    assert rc == 0
    rc, con = matchpathcon('/bin/ls', 3)
    assert rc == 0
    rc, con = matchpathcon('/bin/ls', 32)
    assert rc == 0
    rc, con = matchpathcon('/bin/ls', 33)
    assert rc == 0

# Generated at 2022-06-22 22:25:45.190417
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b"/etc/passwd")
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-22 22:25:51.483436
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled() or not is_selinux_mls_enabled():
        return

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, 'could not get selinux mode: {0}'.format(rc)
    assert enforcemode in [0, 1, 2], 'invalid selinux mode returned: {0}'.format(enforcemode)
# end unit test for function selinux_getenforcemode


# Generated at 2022-06-22 22:25:53.117281
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0

# Generated at 2022-06-22 22:25:55.791412
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, ret) = selinux_getpolicytype()
    print("Function: selinux_getpolicytype")
    print("RC: %s" % rc)
    print("Return: %s" % ret)


# Generated at 2022-06-22 22:26:01.044038
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()
    print(policy_type)


__all__ = [
    'selinux_getenforcemode',
    'selinux_getpolicytype',
    'lgetfilecon_raw',
    'matchpathcon',
]

# Generated at 2022-06-22 22:26:05.538499
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # This can't be run because it requires a full selinux environment
    assert False


# Generated at 2022-06-22 22:26:09.340371
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/haha'
    mode = 0
    print(matchpathcon(path, mode))
    path = None
    mode = 0
    print(matchpathcon(path, mode))



# Generated at 2022-06-22 22:26:16.677060
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foo"
    fd = os.open(path, os.O_CREAT)
    out = matchpathcon(path, fd)
    os.close(fd)
    os.unlink(path)
    if out[0] != 0:
        raise Exception("Unexpected error: ({0}, {1})".format(out[0], out[1]))
    print("Matchpathcon: {0}".format(out[1]))


# Generated at 2022-06-22 22:26:18.904598
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, ret) = selinux_getpolicytype()
    assert rc == 0
    assert ret == 'targeted'


# Generated at 2022-06-22 22:26:25.630519
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import mock
    import os
    # Mock the call to lgetfilecon_raw with a valid return code
    _selinux_lib.selinux_getenforcemode = mock.MagicMock(return_value=0)

    # Call the function
    actual_return_code, actual_value = selinux_getenforcemode()
    expected_return_code = 0

    # Run the assertions
    _selinux_lib.selinux_getenforcemode.assert_called_once_with(mock.ANY)
    assert actual_return_code == expected_return_code
    assert actual_value == 1



# Generated at 2022-06-22 22:26:35.354649
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def assert_match(expected):
        test_path = to_bytes(os.path.dirname(os.path.realpath(__file__)))
        rc, selinux_label = lgetfilecon_raw(test_path)
        assert rc == 0
        assert selinux_label == expected

    if is_selinux_enabled():
        if os.path.exists('/etc/selinux/config'):
            with open('/etc/selinux/config') as f:
                for line in f.readlines():
                    if line.startswith('SELINUXTYPE='):
                        expected_label = '{0}_u:object_r:{0}_t'.format(
                            line.split('=')[1].strip().lower()
                        )
                        assert_match(expected_label)


# Generated at 2022-06-22 22:26:37.705968
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    assert rc == 0
    assert enforcemode in [0, 1, 2]


# Generated at 2022-06-22 22:26:43.895063
# Unit test for function matchpathcon
def test_matchpathcon():
    # Try to set a file with a non existing context
    assert matchpathcon('/proc', 0) == [0, '<<none>>:system_r:proc_t:s0']
    assert matchpathcon('/proc', 1) == [0, '<<none>>:system_r:proc_t:s0']

# Generated at 2022-06-22 22:26:47.491005
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check the return code and the value of enforcemode.
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:26:49.113070
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME
    return 'matchpathcon is deprecated and should be rewritten on selabel_lookup'

# Generated at 2022-06-22 22:26:51.460555
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    print(rc, con)


if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:26:52.712219
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-22 22:26:58.373874
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    (rc, con) = lgetfilecon_raw('/etc/resolv.conf')

    if rc != 0:
        print("Error: failed to get context of resolv.conf")
        print(os.strerror(rc))
        sys.exit(rc)

    print(con)

# Generated at 2022-06-22 22:27:03.742835
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # mock
    selinux_getenforcemode = Mock(return_value=[0, 2])

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, 'selinux_getenforcemode failed with rc={0}'.format(rc)
    assert enforcemode == 2, 'selinux_getenforcemode failed with enforcemode={0}'.format(enforcemode)


# Generated at 2022-06-22 22:27:07.228192
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # return: [0, 'targeted']
    print(selinux_getpolicytype())

test_selinux_getpolicytype()


# Generated at 2022-06-22 22:27:10.850112
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()[1]
    assert enforcemode in (0, 1, 2), "Expected selinux_getenforcemode() to return 0, 1, or 2."


# Generated at 2022-06-22 22:27:19.019128
# Unit test for function matchpathcon
def test_matchpathcon():
    with open('test.txt', 'w') as file:
        file.write('test_content')

    try:
        path = '/tmp/test.txt'
        mode = os.stat(path).st_mode
        rc, con = matchpathcon(path, mode)
        if rc != 0:
            sys.exit(1)
        else:
            print('Context for %s is %s.' % (path, con))
    finally:
        os.remove(path)

# Generated at 2022-06-22 22:27:20.632600
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret_code, policy_type = selinux_getpolicytype()
    assert ret_code == 0
    assert policy_type == 'targeted' or policy_type == 'mls'



# Generated at 2022-06-22 22:27:25.828155
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # File /etc/localtime exists, assert it succeeds and returns a value
    assert lgetfilecon_raw("/etc/localtime")[0] == 0
    # File /etc/localtime.bak does not exist, assert it fails
    assert lgetfilecon_raw("/etc/localtime.bak")[0] == -1


# Generated at 2022-06-22 22:27:27.460164
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:27:30.528152
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc'
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-22 22:27:31.879072
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0

# Generated at 2022-06-22 22:27:34.263194
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce_mode = selinux_getenforcemode()
    assert enforce_mode in [0, 1, 2]
    assert rc == 0

# Generated at 2022-06-22 22:27:40.531347
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/var/log/audit"
    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        raise Exception("Failed to get file context. Return code: %d. Errno: %d. Error msg: %s" % (rc, get_errno(), os.strerror(get_errno())))

    if con != b"system_u:object_r:auditd_log_t:s0":
        raise Exception("Unexpected context for the file: %s" % con)



# Generated at 2022-06-22 22:27:50.621664
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-22 22:27:58.582623
# Unit test for function matchpathcon
def test_matchpathcon():
    mpc = matchpathcon
    # Verify that the test symlinks work as expected
    assert mpc('/tmp/test_matchpathcon.succeed', 0) == [0, 'system_u:object_r:admin_home_t:s0']
    assert mpc('/tmp/test_matchpathcon.fail', 0) == [-1, None]
    assert mpc('/tmp/test_matchpathcon.succeed', 0)[1] == 'system_u:object_r:admin_home_t:s0'

# Generated at 2022-06-22 22:28:01.892081
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0, "Failed to get selinux enforce mode"

# Run the unit test after setting up the selinux lib
test_selinux_getenforcemode()

# Generated at 2022-06-22 22:28:07.335509
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


_ENFORCE_MODES = {
    0: 'enforcing',
    1: 'permissive',
    2: 'disabled',
}



# Generated at 2022-06-22 22:28:10.626699
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # selinux_getpolicytype should return the correct policy type
    # if selinux is enabled.
    if selinux_getenforcemode()[1]:
        assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-22 22:28:17.702817
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    MODE_PERMISSIVE = 1
    MODE_ENFORCING = 2
    MODE_DISABLED = 0

    for mode in [MODE_ENFORCING, MODE_PERMISSIVE, MODE_DISABLED]:
        if mode == MODE_DISABLED:
            return_code, value = selinux_getenforcemode()
            assert value == MODE_DISABLED
        else:
            return_code = _selinux_lib.security_setenforce(mode)
            assert return_code == 0

            return_code, value = selinux_getenforcemode()
            assert value == mode



# Generated at 2022-06-22 22:28:22.888317
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, con] = selinux_getpolicytype()
        assert rc == 0, "Unexpected rc value: {0}".format(rc)
    except NotImplementedError:
        raise Exception("Cannot call selinux_getpolicytype, not implemented")

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:28:24.858809
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()[1]
    assert isinstance(enforcemode, int)
    return enforcemode



# Generated at 2022-06-22 22:28:33.534763
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import platform
    import subprocess
    # Tests are run on a RHEL8 machine with SELinux in Enforcing mode
    # Enforcing mode can be set by running:
    # sudo setenforce Enforcing
    # Permissive mode can be set by running:
    # sudo setenforce Permissive
    # Disabled mode can be set by running:
    # sudo setenforce 0
    #
    # Test selinux_getenforcemode() function
    [rc, enforcemode] = selinux_getenforcemode()
    if platform.python_implementation() == 'CPython':
        assert rc == 0
        assert enforcemode == 1
    else:
        assert rc == 1       # A non-zero value is returned when using PyPy

    # Verify the values returned when SELinux is in enforcing, permissive and disabled modes
    subprocess

# Generated at 2022-06-22 22:28:35.424063
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-22 22:28:38.034383
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)



# Generated at 2022-06-22 22:28:46.940906
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule
    import pwd
    import grp

    # user used for testing
    user = pwd.getpwnam('ansible')
    uid = user.pw_uid
    gid = user.pw_gid

    if security_getenforce() == 0:
        mode = 0
    else:
        mode = 1

    module = AnsibleModule(
        argument_spec=dict(
            file=dict(
                required=True
            ),
            mode=dict(
                required=True,
                type='int'
            )
        ),
        supports_check_mode=False
    )

    file = module.params.get('file')
    # file must belong to ansible user
    os.chown(file, uid, gid)


# Generated at 2022-06-22 22:28:56.847022
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from .ansible_test_mock import patch
    import ctypes
    import os

    class Mock_CDLL:
        def __init__(self, lib):
            self.lib = lib

        def __getattr__(self, name):
            def f(*args):
                if name == 'lgetfilecon_raw':
                    return 0

            return f

    class Mock_c_char_p(ctypes.c_char_p):
        def __init__(self, val):
            self.value = val

    class Mock_byref:
        def __init__(self, obj):
            self.obj = obj


# Generated at 2022-06-22 22:29:02.445064
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import shutil
    import tempfile
    import selinux
    import stat


# Generated at 2022-06-22 22:29:08.461378
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    if not is_selinux_enabled():
        print('selinux is not enabled')
        return

    rc, policytype = selinux_getpolicytype()
    if rc < 0:
        raise RuntimeError('Failed to get policy type')

    print('selinux policy type: {0}'.format(policytype))



# Generated at 2022-06-22 22:29:11.257620
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy_name) = selinux_getpolicytype()
    if policy_name == 'targeted':
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-22 22:29:12.934741
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] == 1 or selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:29:17.026583
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/passwd', 0)
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_t:s0'

# Generated at 2022-06-22 22:29:21.122430
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert type(selinux_getpolicytype()) is list
    assert len(selinux_getpolicytype()) == 2
    assert type(selinux_getpolicytype()[0]) is int
    assert type(selinux_getpolicytype()[1]) is str


# Generated at 2022-06-22 22:29:29.973063
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # test sysfs /sys/fs/selinux
    assert lgetfilecon_raw("/sys/fs/selinux/enforce") == [0, "system_u:object_r:selinuxfs:s0"]

    # test /sys/devices/virtual/tty/console
    assert lgetfilecon_raw("/sys/devices/virtual/tty/console") == [0, "system_u:object_r:tty_device_t:s0"]

    # test /sys/fs/selinux/null
    assert lgetfilecon_raw("/sys/fs/selinux/null") == [0, "system_u:object_r:null_device_t:s0"]



# Generated at 2022-06-22 22:29:32.542898
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1, "Enforcing mode is %d" % enforcemode
    assert rc == 0, "selinux_getenforcemode rc is %d" % rc

# Generated at 2022-06-22 22:29:34.913822
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/tmp')
    assert len(r) == 2
    assert r[0] == 0
    assert isinstance(r[1], str)

# Generated at 2022-06-22 22:29:40.783820
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import libselinux
    enforcemode = c_int()
    rc = libselinux.selinux_getenforcemode(byref(enforcemode))
    if rc > 0:
        raise Exception(rc)

    print("SELinux enforcemode is: %d" % enforcemode.value)


# Generated at 2022-06-22 22:29:43.994015
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import ctypes
    rc, enforcemode = selinux_getenforcemode()
    if (enforcemode == ctypes.c_int(0).value):
       assert True
    else:
       assert False


# Generated at 2022-06-22 22:29:49.068686
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    results = selinux_getenforcemode()
    assert(len(results) == 2)
    assert(type(results[0]) == int)
    assert(type(results[1]) == int)
    assert(((results[0] == 0) and (results[1] == 1)) or ((results[0] == 0) and (results[1] == 0)))



# Generated at 2022-06-22 22:29:52.873112
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/')
    assert result[1] == "system_u:object_r:root_t:s0"

# Generated at 2022-06-22 22:29:55.894297
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, selinux_policy = selinux_getpolicytype()
    if not rc:
        print(selinux_policy)


# Generated at 2022-06-22 22:29:57.540975
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass



# Generated at 2022-06-22 22:30:04.712076
# Unit test for function matchpathcon
def test_matchpathcon():
    fd = os.open('foo.txt', os.O_RDWR | os.O_CREAT, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write('some data')
    [rc, con] = matchpathcon('foo.txt', 0)
    if rc != 0:
        raise OSError(rc, os.strerror(rc))
    assert con == "user_u:object_r:user_home_t:s0-s0:c0.c1023"
    os.unlink('foo.txt')

# Generated at 2022-06-22 22:30:06.961667
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con == "targeted"


# Generated at 2022-06-22 22:30:08.232457
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-22 22:30:11.118814
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)
    assert len(policytype) > 0
    assert policytype == "targeted"


# Generated at 2022-06-22 22:30:13.101443
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test for get the selinux enforcing mode"""
    rc, mode = selinux_getenforcemode()
    assert mode in (0, 1, 2)
    return rc



# Generated at 2022-06-22 22:30:16.583520
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/fstab')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-22 22:30:20.256705
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype failed with error code: %d" % rc
    assert con is not None, "selinux_getpolicytype returned a null pointer to the policy type"

# Generated at 2022-06-22 22:30:22.933964
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    mod = selinux_getpolicytype()
    assert mod[1][-len('_policy'):] == '_policy'

# Generated at 2022-06-22 22:30:27.384427
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Testing selinux_getenforcemode")
    [rc, result] = selinux_getenforcemode()
    print("result: \'{0}\'".format(result))
    assert rc == 0
    assert result in (0, 1, 2)
    print("Test selinux_getenforcemode: PASS")



# Generated at 2022-06-22 22:30:29.425987
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert policytype == "targeted"


# Generated at 2022-06-22 22:30:35.559999
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import errno
    from random import randrange
    from var_dump import var_dump
    logfile = '/var/log/audit/audit.log'
    rc, con = lgetfilecon_raw(logfile)
    if rc == -1:
        assert errno.errorcode[get_errno()] == 'EINVAL'
    elif rc == 0:
        var_dump(con)
    else:
        assert False, 'lgetfilecon_raw returned {0}'.format(rc)


# Generated at 2022-06-22 22:30:43.601278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/tmp')
    except OSError as e:
        if e.errno == 2:
            print('ISSUES: Invalid file path used. /tmp is not present in system')
        else:
            print('ISSUES: lgetfilecon_raw() -', e)
    else:
        print('SUCCESS: lgetfilecon_raw() -', con)


# Generated at 2022-06-22 22:30:55.433168
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    if rc < 0:
        if rc == -2:
            print("selinux getenforcemode returned -2, which means enforcemode is not applicable for the policy.")
        else:
            print("selinux_getenforcemode returned an unexpected return code of %d" % rc)
    else:
        # Enforcemode can be 1, 2 or 0
        # 1 => Enforcing, 0 => Permissive, 2 => Unknown
        if enforcemode <= 2 and enforcemode >= 0:
            print("selinux enforcemode is %d, which means %s" % (enforcemode, ENFORCEMENT_MODES[enforcemode]))

# Generated at 2022-06-22 22:31:00.106118
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/to/dir'
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc == 0:
        print(con)
    else:
        print(con)


# Generated at 2022-06-22 22:31:05.616229
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode()[0], int), "Return value for selinux_getenforcemode() is not an int"
    assert isinstance(selinux_getenforcemode()[1], int), "Return value for selinux_getenforcemode() is not an int"


# Generated at 2022-06-22 22:31:13.572242
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = None
    rc = None
    try:
        rc, enforcemode = selinux_getenforcemode()
        assert isinstance(rc, int)
        assert rc in [0, 1], "return code"
        assert isinstance(enforcemode, int), "enforcemode"
        assert enforcemode in [0, 1, 2], "enforcemode"
    except ImportError as e:
        print("selinux module: function selinux_getenforcemode: {}".format(e))


# Generated at 2022-06-22 22:31:23.300515
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import tempfile

    # should be a temporary file
    path = tempfile.mktemp()

    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 0

    rc, type = selinux_getpolicytype()
    assert type == 'targeted'

    rc, con = lgetfilecon_raw(path)
    assert con.split(':')[0] == 'unconfined_u'

    rc, con = matchpathcon(path, os.R_OK)
    assert con == 'system_u:object_r:unlabeled_t:s0'

    # FIXME: selinux_lsetfilecon requires root.unit tests should be run as root.
    # rc, con = selinux_lsetfilecon(path, 'system_u:object_r:unlabeled_t:s

# Generated at 2022-06-22 22:31:30.868681
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/selinux_context'
    f = open(path, 'w')
    f.write('test')
    f.close()

    rc, con = lgetfilecon_raw(path)
    print(rc, con)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    os.remove(path)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:31:35.663505
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    A module test using the ctypes library
    """
    rc, out = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(out, str)
    assert out == 'targeted'



# Generated at 2022-06-22 22:31:46.194662
# Unit test for function matchpathcon
def test_matchpathcon():
    # Unit test for matchpathcon
    import os.path
    from ansible.module_utils.selinux import (matchpathcon, SELINUX_ANDROID_RESTORECON_DATADATA)

    TEST_PATH = '/data/data/com.example/test/test'

    rc, out = matchpathcon(TEST_PATH, SELINUX_ANDROID_RESTORECON_DATADATA)
    # In an SELinux enabled system rc is non-zero. The output is the parent directory context on failure.
    assert rc == 1, 'Expected matchpathcon to return 1'
    assert out == os.path.basename(os.path.dirname(TEST_PATH))

# Generated at 2022-06-22 22:31:51.931206
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Use the function to get the selinux policy type
    policytype = selinux_getpolicytype()
    try:
        assert policytype[0] == -1 and policytype[1] == 'selinuxfs'
    except (AssertionError, IndexError):
        # Test failed
        sys.exit(1)

    # Test passed
    sys.exit(0)

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:32:02.472546
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import selinux

    path = "/tmp"
    fd, name = os.mkstemp(prefix="", dir=path)
    rc, con = matchpathcon(path, os.stat(name)[stat.ST_MODE])
    print("matchpathcon('%s', 0%o) returned %d, context '%s'" % (path, os.stat(name)[stat.ST_MODE], rc, con))
    os.close(fd)
    os.unlink(name)

    print("selinux_getenforcemode() returned %d, mode %d" % selinux_getenforcemode())

    # All of the above is really meant to be a complicated way of calling
    # selinux.matchpathcon.  To verify that this wrapper is working:

# Generated at 2022-06-22 22:32:09.085669
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """selinux_getpolicytype test"""
    # Verify that the module is loaded
    assert hasattr(_selinux_lib, 'selinux_getpolicytype')

    # Call the function selinux_getpolicytype
    rc, result = selinux_getpolicytype()

    # Check the return code of the function
    assert rc == 0

    # Check the result of the function
    assert result == 'targeted'



# Generated at 2022-06-22 22:32:13.816564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw returns proper tuple."""
    path = "/etc/selinux/config"
    return_code, con = lgetfilecon_raw(path)
    assert(return_code >= 0)
    assert(con == "system_u:object_r:etc_runtime_t:s0")

if __name__ == '__main__':
    test()  # noqa

# Generated at 2022-06-22 22:32:24.418334
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/usr/include', 0)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:usr_t:s0'
    res = matchpathcon('/usr/include', 0o40)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:usr_t:s0'
    res = matchpathcon('/usr/include', 0o400)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:usr_t:s0'
    res = matchpathcon('/usr/include', 0o4000)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:usr_t:s0'
   

# Generated at 2022-06-22 22:32:27.638637
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = [0, 0]
    enforcemode[0], enforcemode[1] = selinux_getenforcemode()
    assert enforcemode[0] == 0
    assert enforcemode[1] in [0, 1]


# Generated at 2022-06-22 22:32:38.407372
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Tests whether selinux module is functional by calling function selinux_getenforcemode."""
    (rc, enforcemode_val) = selinux_getenforcemode()
    print("SELinux enforcemode value (0=disabled, 1=enabled): " + str(enforcemode_val))
    # If the selinux module or library file is not found the return code will be -1
    try:
        print("SELinux return code: " + str(rc))
    except:
        print("SELinux return code: " + os.strerror(rc))

    assert rc >= 0, \
        ("Test of function selinux_getenforcemode() failed!")
