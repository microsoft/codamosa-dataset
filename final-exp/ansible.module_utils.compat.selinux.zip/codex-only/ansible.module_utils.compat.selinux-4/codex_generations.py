

# Generated at 2022-06-22 22:22:40.451996
# Unit test for function matchpathcon
def test_matchpathcon():
    # Fails on unknown context param
    assert matchpathcon('/foo/bar', 0)[0] == -1

    # Fails on unknown context param
    assert matchpathcon('/foo/bar', 1)[0] == -1

    # Successful lookup of file context
    assert matchpathcon('/etc/hosts', 0)[0] == 0

    # Failure due to unknown path
    assert matchpathcon('/foo/bar', 2)[0] == -1

# Generated at 2022-06-22 22:22:47.307569
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # The function selinux_getpolicytype returns a tuple with two values
    # The first value will be the return code of the underlying
    #   libselinux function and the second element will be the actual return
    #   value from the underlying libselinux function
    rc, policytype = selinux_getpolicytype()
    # The function selinux_getpolicytype should return a
    #   value with index 1 of 'targeted'
    assert policytype == 'targeted'


# Generated at 2022-06-22 22:22:49.555321
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, int)
    assert isinstance(rc, int)


# Generated at 2022-06-22 22:22:54.911905
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Assert that the function return the values returned by the C library
    test_case = (
        (1, 0),
        (0, 1),
        (0, 2),
        (0, -1)
    )
    for result, enforcemode in test_case:
        _selinux_lib.selinux_getenforcemode = lambda _: enforcemode
        assert selinux_getenforcemode() == [result, enforcemode]

# Generated at 2022-06-22 22:22:57.019439
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # pylint: disable=invalid-name
    ret = lgetfilecon_raw('/etc/issue')
    assert isinstance(ret, list)
    assert len(ret) == 2
    assert ret[0] == 0
    assert ret[1].startswith('system_u:object_r:etc_t:s0')


# Generated at 2022-06-22 22:22:58.833775
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type == "targeted"



# Generated at 2022-06-22 22:23:09.023974
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.NamedTemporaryFile(dir='/tmp', delete=False) as fh:
        fh.write(b'')

    try:
        rc, out = lgetfilecon_raw(fh.name)
        assert rc == 0, "test_lgetfilecon_raw: unexpected return code"
        assert out == "unconfined_u:object_r:user_tmp_t:s0", \
            "test_lgetfilecon_raw: unexpected context '%s'" % out
    finally:
        os.unlink(fh.name)

# Generated at 2022-06-22 22:23:12.524789
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import sys
    import doctest
    module = sys.modules[__name__]
    failed, tested = doctest.testmod(module)
    assert tested > 0
    assert failed == 0, '{0} of {1} tests failed'.format(failed, tested)



# Generated at 2022-06-22 22:23:14.377610
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:23:16.826528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    test_con = 'system_u:object_r:passwd_file_t:s0'

    assert lgetfilecon_raw(test_path)[1] == test_con

# Generated at 2022-06-22 22:23:21.162211
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/selinux')
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:23:25.065120
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc >= 0:
        print(con)
    else:
        print('Security context not available')

if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:23:30.083403
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert 'targeted' in selinux_getpolicytype()[1]

# Make this module idempotent by collecting only the functions
__all__ = [k for k in dir() if k != '_selinux_lib']

# Generated at 2022-06-22 22:23:33.085761
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-22 22:23:36.446709
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, context_tuple = matchpathcon('foo',0)
    assert rc == 0
    assert context_tuple == '(system_u:object_r:root_t:s0)'

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:23:47.798816
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os
    import shutil
    import sys

    # Create directory structure to test
    testdir = tempfile.mkdtemp()
    testdir_file = os.path.join(testdir, 'test_file')
    testdir_dir = os.path.join(testdir, 'test_dir')
    os.mkdir(testdir_dir)
    testdir_file_file = os.path.join(testdir, 'test_dir/test_file_file')
    testdir_dir_file = os.path.join(testdir, 'test_dir/test_dir_file')
    testdir_dir_dir = os.path.join(testdir, 'test_dir/test_dir_dir')

# Generated at 2022-06-22 22:23:53.388620
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    if rc == -1:
        raise Exception('SELinux is not enabled')
    elif rc != 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))


# Generated at 2022-06-22 22:24:04.385825
# Unit test for function matchpathcon
def test_matchpathcon():
    # Call matchpathcon to set context of /tmp path
    result = matchpathcon("/tmp", 0)
    if result[0] == -1:
        # If matchpathcon returns an error, print the error and exit
        raise RuntimeError("matchpathcon({}, {}) returned error: {}".format("/tmp", 0, result[0]))
    else:
        # Get current context of /tmp path
        context = matchpathcon("/tmp", 0)[1]
        # Check if current context of /tmp path is same as the just set
        if context == "system_u:object_r:tmp_t:s0":
            print("Successfully set context of /tmp path to {}".format(result[1]))
            sys.exit(0)
        else:
            print("Failed to set context of /tmp path")


# Generated at 2022-06-22 22:24:09.337518
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/usr/bin/python3'
    test_mode = 0o700
    os.chmod(test_path, test_mode)
    get_con = lgetfilecon_raw(test_path)[1]
    os.chmod(test_path, 0o755)
    expected_output = 'unconfined_u:object_r:usr_t:s0'
    return get_con == expected_output

# Generated at 2022-06-22 22:24:12.179715
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/tmp')
        assert rc == 0
        assert len(con) > 0
    except OSError:
        pass



# Generated at 2022-06-22 22:24:24.389203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    from os.path import abspath, join
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.six import StringIO
    import sys

    # Redirect stdout to a buffer for testing
    saved_stdout = sys.stdout

# Generated at 2022-06-22 22:24:32.820557
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import mkstemp
    import os

    temp_file_path, temp_file_fd = None, None
    try:
        temp_file_fd, temp_file_path = mkstemp()
        os.close(temp_file_fd)

        print('testing lgetfilecon_raw...')
        rc, con = lgetfilecon_raw(temp_file_path)
        print('lgetfilecon_raw rc: %s, con: %s' % (rc, con))
    finally:
        try:
            os.remove(temp_file_path)
        except (IOError, OSError, TypeError):
            pass



# Generated at 2022-06-22 22:24:39.185974
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/"
    mode = 0
    print(matchpathcon(path, mode))
    out = matchpathcon(path, mode)
    print(type(out[0]))
    print(type(out[1]))
    assert type(out[0]) is int
    assert type(out[1]) is str

# Generated at 2022-06-22 22:24:43.573351
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/hosts'
    rc, con = lgetfilecon_raw(path)
    if rc >= 0:
        print("{0} {1}".format(unexpected_success, path))
    else:
        print("{0} {1} {2}".format(unexpected_failure, path, con))


# Generated at 2022-06-22 22:24:49.803760
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.exists('/etc/shadow'):
        if os.path.exists('/etc/foobar'):
            rc, con = matchpathcon('/etc/foobar', os.R_OK)
            assert rc == 0
            rc, con = matchpathcon('/etc/shadow', os.R_OK)
            assert rc == -1
            errno = get_errno()
            assert errno == 13
        else:
            raise Exception('Unable to test matchpathcon()')
    else:
        raise Exception('Unable to test matchpathcon()')



# Generated at 2022-06-22 22:24:52.442521
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    data = selinux_getenforcemode()
    assert data[0] == 0
    assert data[1] == 1


# Generated at 2022-06-22 22:24:54.456948
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    print("Policytype: {}".format(policytype))

# Generated at 2022-06-22 22:25:01.013752
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if enforcemode == 0:
        print("SELinux is not enabled. (SELinux_ENFORCE_DISABLED)")
    elif enforcemode == 1:
        print("SELinux is in permissive mode. (SELINUX_ENFORCE_PERMISSIVE)")
    elif enforcemode == 2:
        print("SELinux is in enforcing mode. (SELINUX_ENFORCE_ENFORCING)")
    else:
        print("Invalid return value.")


# Generated at 2022-06-22 22:25:03.841259
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0 and isinstance(res[1], str)
    print("selinux_getpolicytype: ", res)

# Generated at 2022-06-22 22:25:05.923791
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/dev/sda') == [0, 'sda_t']



# Generated at 2022-06-22 22:25:11.281648
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/passwd', 0) == [0, 'system_u:object_r:passwd_file_t:s0']
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:passwd_file_t:s0']


# Generated at 2022-06-22 22:25:13.557956
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    returncode, policytype = selinux_getpolicytype()
    assert returncode == 0
    assert policytype == 'targeted'



# Generated at 2022-06-22 22:25:16.250449
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    rc, value = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(value, str)



# Generated at 2022-06-22 22:25:18.995942
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _, con = lgetfilecon_raw("/etc/hosts")
    assert con is not None
    assert con.startswith("system_u:object_r:etc_t:s0")

# Generated at 2022-06-22 22:25:21.974008
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    if rc == 0:
        print(policy)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:25:27.941695
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, msg = selinux_getenforcemode()
    if rc == 0:
        assert msg in [0, 1], 'Failed to execute selinux_getenforcemode'
    else:
        assert msg is None, 'Failed to execute selinux_getenforcemode'


# Generated at 2022-06-22 22:25:33.304961
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, mode = selinux_getenforcemode()
        assert rc == 0, "Failed to get enforcing mode, Error:{}".format(rc)
        assert mode in [0, 1, 2], "Invalid enforcing mode, Value:{}".format(mode)
    except (OSError, NotImplementedError) as exc:
        assert False, "Failed to get enforcing mode, Error:{}".format(to_native(exc))

# Generated at 2022-06-22 22:25:36.613249
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Initialize the expected result, initialize the module and invoke the function
    result = 1
    selinux_getenforcemode()


# Generated at 2022-06-22 22:25:41.191816
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/log/audit/audit.log"
    mode = os.R_OK
    assert matchpathcon(path, mode)[0] == 0
    assert matchpathcon(path, mode)[1] == "system_u:object_r:auditd_log_t:s0"



# Generated at 2022-06-22 22:25:43.725382
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode in (0, 1, 2)
    assert rc == 0



# Generated at 2022-06-22 22:25:46.929993
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('Attempting to get policy type')
    rc, policy_type = selinux_getpolicytype()
    print('SELinux policy type: {0}'.format(policy_type))



# Generated at 2022-06-22 22:25:50.714569
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    path = "/tmp"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-22 22:25:54.092699
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    path = "/tmp"
    result = lgetfilecon_raw(path)
    assert result[0] == 0


# Generated at 2022-06-22 22:26:02.565296
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/sbin/init')
    assert rc == 0
    assert con.startswith('unconfined_u:system_r:init_t')
    # Raise error for invalid path
    rc, con = lgetfilecon_raw(b'/sbin/inita')
    assert rc == -1
    # Raise error for invalid parameter
    rc, con = lgetfilecon_raw(None)
    assert rc == -1



# Generated at 2022-06-22 22:26:09.701900
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    The selinux_getenforcemode() function returns an int
        representing the current status of SELinux.
    """
    result = selinux_getenforcemode()
    if result[0] == 0:
        assert result[1] in [0, 1, 2]
    elif result[0] < 0:
        assert result[1] is None
    else:
        assert False == True


# Generated at 2022-06-22 22:26:14.816964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/tmp'
    res = lgetfilecon_raw(path)
    if res[0] != 0:
        raise RuntimeError('Function lgetfilecon_raw failed')
    print('Context of {0}: {1}'.format(path, res[1]))


# Generated at 2022-06-22 22:26:15.845132
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()


# Generated at 2022-06-22 22:26:22.187387
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    # Valid path
    assert len(lgetfilecon_raw('/var')) == 2
    # Invalid path
    assert lgetfilecon_raw('/does_not_exist')[0] != 0
    if not os.path.exists('/bin/logger'):
        # Running the test suite in a container
        return
    # Valid path on a file that has the selinux context set
    assert len(lgetfilecon_raw('/bin/logger')) == 2



# Generated at 2022-06-22 22:26:25.068191
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-22 22:26:26.934771
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)

# Generated at 2022-06-22 22:26:29.793206
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    path_con = lgetfilecon_raw(path)[1]
    tmp_con = path_con.split(':')[2]
    assert tmp_con == 'tmp_t'

# Generated at 2022-06-22 22:26:39.254513
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """ This function tests the function getenforcemode"""
    result = selinux_getenforcemode()
    assert type(result) is list, "Expected a list"
    assert len(result) == 2, "Expected a list of size 2"
    assert type(result[0]) is int, "Expected an integer as the first element"
    assert result[0] in [-1, 0, 1], "Expected -1, 0 or 1"
    assert type(result[1]) is int, "Expected an integer as the second element"
    assert result[1] in [0, 1, 2], "Expected 0, 1 or 2"


# Generated at 2022-06-22 22:26:43.931311
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    f = selinux_getpolicytype()
    print(f)
    # print the type of the returned object
    print(type(f))
    # print the data type of the object returned
    print(type(f[1]))


# Generated at 2022-06-22 22:26:47.003381
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()[1]
    if enforcemode in [0, 1]:
        return True
    else:
        return False


# Generated at 2022-06-22 22:26:55.849908
# Unit test for function matchpathcon
def test_matchpathcon():
    def _utf8_convert(input):
        if not isinstance(input, bytes):
            return to_bytes(input)
        return input

    test_data = [
        {
            'description': 'should be able to convert path',
            'path': 'foo/bar/baz',
            'mode': 0,
            'want': [
                0,
                r'user_u:object_r:usr_t:s0',
            ],
        },
        {
            'description': 'should raise OSError when context not found',
            'path': 'nonexistent/foo/bar/baz',
            'mode': 0,
            'want': [
                -1,
            ],
        },
    ]


# Generated at 2022-06-22 22:26:58.417486
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected_result = [0, 1]
    result = selinux_getenforcemode()
    assert result == expected_result


# Generated at 2022-06-22 22:27:06.024937
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        raise NotImplementedError('selinux disabled')
    func = selinux_getenforcemode()
    # If selinux_getenforcemode() return 0, SELinux is disabled,
    # If selinux_getenforcemode() return 1, SELinux is enabled in permissive mode
    # If selinux_getenforcemode() return 2, SELinux is enabled in enforcing mode
    # Return value must be 0, 1 or 2
    assert func[0] in (0, 1, 2)


# Generated at 2022-06-22 22:27:07.121150
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-22 22:27:15.879441
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os
    import stat

    fd, filename = tempfile.mkstemp()
    os.close(fd)
    os.unlink(filename)

    print("create '%s'" % filename)
    f = open(filename, 'w')
    f.close()

    print("change mode on '%s'" % filename)
    os.chmod(filename, stat.S_IRWXU)

    print("set context on '%s'" % filename)
    os.lchown(filename, 0, 0)
    os.lsetxattr(filename, 'security.selinux', 'system_u:object_r:unconfined_t:s0\0')

# Generated at 2022-06-22 22:27:17.256555
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) == list

# Generated at 2022-06-22 22:27:23.273863
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    if result[0] != 0:
        msg = "selinux_getenforcemode return error code: {}".format(result[0])
        raise AssertionError(msg)
    expected = [0, security_getenforce()]
    assert expected == result



# Generated at 2022-06-22 22:27:26.426514
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if is_selinux_enabled() == 0:
        return
    for x in range(0, 10000):
        lgetfilecon_raw(b'/etc/passwd') == 0



# Generated at 2022-06-22 22:27:34.039293
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils import basic
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.selinux.selinux import lgetfilecon_raw
    file_path = '/etc/passwd'
    rc, result = lgetfilecon_raw(file_path)
    assert rc == 0
    assert result == 'system_u:object_r:file_t:s0'
    rc, result = lgetfilecon_raw('/etc/notreal')
    assert rc == -1
    assert result is None

# Generated at 2022-06-22 22:27:42.065611
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # 'selinux_getpolicytype' is not easy to test as it depends on the
    # SELinux policy files installed on the system.
    #
    # Therefore we use the mock test framework to replace the ctypes
    # function to return the result we expect.
    from ansible_collections.ansible.community.tests.unit.plugins.module_utils import basic
    from ansible_collections.ansible.community.tests.unit.plugins.module_utils.basic import AnsibleModule

    result = dict(
        rc=0,
        stdout='targeted',
    )

    test_module_selinux = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )


# Generated at 2022-06-22 22:27:43.747543
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/hosts')[1] != 'File does not exist'


# Generated at 2022-06-22 22:27:50.748563
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for path, expected in [
        ('/etc/selinux/config', 'system_u:object_r:etc_runtime_t:s0'),
        ('/not/a/real/file', 'system_u:object_r:default_t:s0'),
        ('/not/a/real/file', 'system_u:object_r:default_t:s0'),
    ]:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == expected


# Generated at 2022-06-22 22:27:52.744438
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()


# Generated at 2022-06-22 22:27:56.718296
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        import selinux
        rc = selinux.security_getenforce()
        (rc, enforcemode) = selinux.selinux_getenforcemode()
        assert enforcemode == rc
    except ImportError:
        pass

# Generated at 2022-06-22 22:28:00.000641
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if security_policyvers() == 0:
        return
    rc, con = selinux_getpolicytype()
    assert type(con) == str
    assert rc == 0
    assert con != ''



# Generated at 2022-06-22 22:28:02.628252
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[0] != 0:
        return False
    return result[1] == 'targeted' or result[1] == 'mls'



# Generated at 2022-06-22 22:28:06.791149
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/tmp', 0)
    assert rc == 0
    assert con == 'user_tmp_t'



# Generated at 2022-06-22 22:28:09.899330
# Unit test for function matchpathcon
def test_matchpathcon():
    import json
    import os
    test_dir = os.path.dirname(__file__)
    con = matchpathcon(test_dir)
    print(json.dumps(con))

# Generated at 2022-06-22 22:28:13.808556
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import platform

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [-1, 0, 1]
    assert isinstance(enforcemode, int)



# Generated at 2022-06-22 22:28:20.236071
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        path = b"/tmp/test/.ssh/authorized_keys"
        (_, con) = lgetfilecon_raw(path)
        print("Context for %s is %s" % (path, con))
    except OSError as err:
        print("ERROR: %s" % err)

# Generated at 2022-06-22 22:28:27.535312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''Test lgetfilecon_raw for return code and return value'''
    if os.path.exists('/selinux/enforce'):
        rc, con = lgetfilecon_raw('/selinux/enforce')
        if rc < 0:
            print('Failed. Test return code: %s' % rc)
            return 1
        else:
            print('Test return code: %s' % rc)
            print('Test return value: %s' % con)
            return 0
    else:
        print('File /selinux/enforce not found')
        return 1


# Generated at 2022-06-22 22:28:32.311873
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type is not None
    # Policy type is either targeted or mls
    assert policy_type.startswith('targeted') or policy_type == 'mls'



# Generated at 2022-06-22 22:28:34.699477
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce = selinux_getenforcemode()
    assert rc == 0
    assert enforce in [0, 1, 2]



# Generated at 2022-06-22 22:28:44.476459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    def _getfilecon_raw(path):
        return lgetfilecon_raw(path)[1]

    def _gen_tempfile():
        import tempfile

        temp = tempfile.NamedTemporaryFile(delete=False)
        temp_name = temp.name
        temp.close()
        return temp_name

    def _remove_tempfile(path):
        try:
            os.remove(path)
        except Exception:
            pass

    def _test_path():
        temp_file = _gen_tempfile()

        # NB: realpath will resolve any symlinks prior to returning the full path
        real_path = os.path.realpath(temp_file)
        context = _getfilecon_raw(temp_file)

        _remove_tempfile(temp_file)


# Generated at 2022-06-22 22:28:47.624677
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/lib/foo"
    mode = 755
    i, rc = matchpathcon(path, mode)
    print("i: {} rc: {}".format(i, rc))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:54.520676
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import tempfile

    tempdir_name = tempfile.mkdtemp()
    # Create a temporary file and call matchpathcon()
    # This file should have the default context on the system
    tempfile_name = 'tempfile.txt'
    tempfile_path = os.path.join(tempdir_name, tempfile_name)

    fd, tempfile_path = tempfile.mkstemp(dir=tempdir_name)
    os.close(fd)

    try:
        tempfile_mode = os.stat(tempfile_path).st_mode
        rc, con = matchpathcon(tempfile_path, tempfile_mode)
    finally:
        os.unlink(tempfile_path)

    assert rc == 0
    print(con)


# Generated at 2022-06-22 22:29:00.999213
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, result) = lgetfilecon_raw(b'/etc/')
    if rc != 0:
        print("Unit test for lgetfilecon_raw failed")
        print("Error code: %s" % rc)
        print("Error message: %s" % result)
        raise Exception
    return rc

# Generated at 2022-06-22 22:29:08.019179
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test 1: unreadable file with no selinux
    rc, _ = lgetfilecon_raw('/etc/shadow')
    assert rc == errno.EACCES

    # test 2: unreadable file with selinux enabled
    assert selinux_getenforcemode()[1] == 1

    rc, _ = lgetfilecon_raw('/etc/shadow')
    assert rc == errno.ENOENT

# Generated at 2022-06-22 22:29:10.060208
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] == 1 or selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:29:14.993126
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    with tempfile.NamedTemporaryFile('w') as fi:
        fi.write('')
        fi.flush()
        rc, con = lgetfilecon_raw(fi.name)
        assert rc == 0
        assert con == "system_u:object_r:default_t:s0"



# Generated at 2022-06-22 22:29:25.137265
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))
    (rc, con) = matchpathcon('/etc/passwd', 1)
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))
    (rc, con) = matchpathcon('/etc/passwd', 2)
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))
    (rc, con) = matchpathcon('/etc/passwd', 3)
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))

# Generated at 2022-06-22 22:29:27.017461
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print('selinux_getenforcemode() = {0}, {1}'.format(rc, enforcemode))
    assert rc == 0



# Generated at 2022-06-22 22:29:31.852230
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Unit test for function selinux_getenforcemode

    """
    ret, val = selinux_getenforcemode()
    assert val in (0, 1, 2)



# Generated at 2022-06-22 22:29:34.038869
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/foo/bar/', 0) == [0, 'system_u:object_r:user_home_dir_t:s0']

# Generated at 2022-06-22 22:29:40.952402
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/log/messages'
    mode = os.R_OK | os.W_OK
    [rc, con] = matchpathcon(path, mode)
    assert to_native(con).endswith('system_u:object_r:var_log_t:s0')
    assert rc == 0


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:43.106366
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type == 'targeted'

# Generated at 2022-06-22 22:29:47.131959
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    con = c_char_p()
    _selinux_lib.lgetfilecon_raw(path, byref(con))
    print(to_native(con.value))

# Generated at 2022-06-22 22:29:49.479433
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result, policy_type = selinux_getpolicytype()
    assert isinstance(result, int)
    assert isinstance(policy_type, str)

# Generated at 2022-06-22 22:29:55.637769
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    import filecmp

    test_dir = tempfile.mkdtemp()
    _, fname = tempfile.mkstemp(dir=test_dir)
    open(fname, 'a').close()


# Generated at 2022-06-22 22:30:05.960086
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    with patch.object(basic.AnsibleModule, 'exit_json') as exit_json_mock:
        with patch.object(basic.AnsibleModule, 'fail_json') as fail_json_mock:
            [rc, con] = lgetfilecon_raw('/etc/passwd')
            if rc >= 0:
                exit_json_mock.return_value = {
                    'rc': rc,
                    'con': con,
                }

# Generated at 2022-06-22 22:30:09.544073
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert(isinstance(result, list))
    assert(len(result) == 2)
    assert(isinstance(result[0], int))
    assert(isinstance(result[1], str))


# Generated at 2022-06-22 22:30:20.037269
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest

    class TestMatchpathcon(unittest.TestCase):
        def test_matchpathcon(self):
            rc, context = matchpathcon('/tmp', 0)
            self.assertEqual(rc, 0)
            self.assertEqual(context, 'system_u:object_r:tmp_t:s0')
            rc, context = matchpathcon('/tmp', os.R_OK)
            self.assertEqual(rc, 0)
            self.assertEqual(context, 'system_u:object_r:tmp_t:s0')

# Generated at 2022-06-22 22:30:26.597024
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    if res[0] != 0:
        print("Error: selinux_getpolicytype returned {}".format(res[0]))
        sys.exit(1)
    if res[1] != "targeted":
        print("Error: selinux_getpolicytype returned {}, expected 'targeted'".format(res[1]))
        sys.exit(1)



# Generated at 2022-06-22 22:30:33.869587
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # if selinux is disabled this function fails
    try:
        if selinux_getenforcemode()[1] == 0:
            print("SELinux is not enabled")
            exit(1)
    except:
        print("SELinux is not enabled")
        exit(1)
    rc, policy = selinux_getpolicytype()
    if rc is not 0:
        exit(1)
    sys.stdout.write(policy)
    exit(0)


if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:30:39.025258
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]
    assert selinux_getenforcemode.restype == c_int
    assert selinux_getenforcemode.argtypes == None


# Generated at 2022-06-22 22:30:40.999852
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] != -1



# Generated at 2022-06-22 22:30:45.866991
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Unit test for function lgetfilecon_raw

    '''
    from ansible.module_utils.selinux import lgetfilecon_raw

    result = lgetfilecon_raw('/etc/')
    assert result[0] == 0, 'Expected return code 0'
    assert result[1] == 'system_u:object_r:etc_t:s0', 'Expected file context /etc/'

# Generated at 2022-06-22 22:30:47.060949
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Tested by selinux module
    assert selinux_getenforcemode() is not None

# Generated at 2022-06-22 22:30:56.322287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test if the module function 'lgetfilecon_raw' returns the right context
    as defined in the current selinux policy.
    """
    if not is_selinux_enabled():
        sys.exit()

    rc, context_out = lgetfilecon_raw('/etc/shadow')
    if rc < 0:
        sys.exit('lgetfilecon_raw failed: rc={}'.format(rc))

    rc, context_out = matchpathcon('/etc/shadow', 0)
    if rc < 0:
        sys.exit('matchpathcon failed: rc={}'.format(rc))

    # Check if the context matches

# Generated at 2022-06-22 22:31:01.820759
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    def test_selinux_getpolicytype_helper(expected_val):
        val = selinux_getpolicytype()
        assert expected_val == val

    test_selinux_getpolicytype_helper([0, 'targeted'])



# Generated at 2022-06-22 22:31:06.095577
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        for policytype in selinux_getpolicytype():
            assert isinstance(policytype, str)
    except AttributeError:
        print("selinux_getpolicytype() function not implemented")


# Generated at 2022-06-22 22:31:07.177115
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO
    assert False

# Generated at 2022-06-22 22:31:16.396816
# Unit test for function matchpathcon
def test_matchpathcon():
    # Conformant path, mode
    data = matchpathcon('/usr/bin/ansible', 0)
    assert data[0] == 0, data[0]
    assert 'system_u:object_r:usr_t:s0' in data[1], data[1]

    # Non-conformant path
    data = matchpathcon('/usr/bin/doesnotexist', 0)
    assert data[0] == -1, data[0]

    # Non-conformant mode
    data = matchpathcon('/etc/ansible/ansible.cfg', 1)
    assert data[0] == -1, data[0]

# Generated at 2022-06-22 22:31:25.392900
# Unit test for function matchpathcon
def test_matchpathcon():
    # create a directory and a file.
    os.mkdir('/tmp/selinux/dir', 0o700)
    os.chmod('/tmp/selinux/dir', 0o700)
    os.mkdir('/tmp/selinux/dir/subdir', 0o700)
    with open('/tmp/selinux/dir/subdir/file1', 'w') as fd:
        fd.write('test')
    os.chmod('/tmp/selinux/dir/subdir/file1', 0o700)

    # test matchpathcon function with full context that is not assigned to a file.
    context = 'system_u:object_r:initrc_exec_t:s0'

# Generated at 2022-06-22 22:31:27.760972
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/selinux/config', 0)[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-22 22:31:34.602293
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    pytest_selinux_getpolicytype = selinux_getpolicytype
    if sys.platform == 'darwin':
        assert pytest_selinux_getpolicytype()[1] == 'none', 'selinux policy might not be disable correctly'
    elif sys.platform.startswith('linux'):
        assert pytest_selinux_getpolicytype()[1] == 'refpolicy', 'selinux policy might not be disable correctly'
    else:
        raise OSError('selinux policy can not be disable on this OS')



# Generated at 2022-06-22 22:31:41.370374
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a sample file
    f = open('/etc/shadow', mode='r')
    print(lgetfilecon_raw(f.name))
    f.close()

    # Now test with a file that isn't there
    print(lgetfilecon_raw('/no/such/file'))



# Generated at 2022-06-22 22:31:46.492412
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.common.text.converters import to_text
    rc, con = lgetfilecon_raw(to_text("/tmp"))
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'



# Generated at 2022-06-22 22:31:49.425348
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("Return Code:", rc)
    if rc >= 0:
        print("enforcemode:", enforcemode)


# Generated at 2022-06-22 22:31:53.019261
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/usr/bin/ping')
    # ping binary is labeled sysadm_u:sysadm_r:sysadm_t:s0
    assert rc == 0
    assert con.startswith('sysadm_u')



# Generated at 2022-06-22 22:31:55.770052
# Unit test for function matchpathcon
def test_matchpathcon():
    testfile = os.path.realpath(__file__)
    assert matchpathcon(testfile, 0)[1] == 'system_u:object_r:usr_t:s0'



# Generated at 2022-06-22 22:32:02.732997
# Unit test for function matchpathcon
def test_matchpathcon():
    import stat
    import tempfile

    with tempfile.NamedTemporaryFile('wb') as fh:
        fh.write(b'hello')
        fh.flush()
        rc, con = matchpathcon(fh.name, stat.S_IFREG)
        os.unlink(fh.name)

    assert rc == 0
    assert con == 'system_u:object_r:admin_home_t:s0'



# Generated at 2022-06-22 22:32:12.006555
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if enforcemode == 0:
        if rc != 0:
            print("Expected errors: rc == 0 and enforcemode == 0")
        else:
            print("Everything seems to be fine, SELinux is disabled (permissive mode)")
    elif enforcemode == 1:
        if rc != 0:
            print("Expected errors: rc == 0 and enforcemode == 0, enforced mode")
        else:
            print("Everything seems to be fine, SELinux is enabled (enforced mode)")
    else:
        print("Expected errors: rc == 0, enforcemode == 0 or 1")



# Generated at 2022-06-22 22:32:23.922280
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test a path that has a match
    path = '/tmp/etc/passwd'
    expected_con = 'system_u:object_r:etc_t:s0'
    mode = os.stat(path).st_mode
    found_con = matchpathcon(path, mode)

    if found_con != expected_con:
        raise ValueError("Invalid context %s for test path %s" % (found_con, path))

    # Test a path that does not have a match (since it does not exist)
    path = '/tmp/etc/passwd-not-found'
    expected_con = '<<none>>'
    mode = os.stat(path).st_mode
    found_con = matchpathcon(path, mode)


# Generated at 2022-06-22 22:32:29.756467
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/etc/resolv.conf") == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw(b"/etc/resolv.conf1") != [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw(b"/etc/resolv.conf1") == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-22 22:32:33.461491
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/mtab', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']

