

# Generated at 2022-06-22 22:22:38.491271
# Unit test for function matchpathcon
def test_matchpathcon():
    testpath1 = '/var/log/messages'
    mode = 0
    [rc, con] = matchpathcon(testpath1, mode)
    print("%s;%s;%s" % (rc, con, testpath1))



# Generated at 2022-06-22 22:22:40.866102
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[0] == 0



# Generated at 2022-06-22 22:22:43.551971
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test function lgetfilecon_raw
    """
    assert lgetfilecon_raw('/usr/bin/hostname') == [0, 'system_u:object_r:bin_t:s0']

# Generated at 2022-06-22 22:22:48.639794
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0, "selinux_getenforcemode return code: %d" % rc
    print("selinux_getenforcemode: %d" % mode)

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:22:54.321403
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    for enforcemodevalue in [0, 1]:
        def mock_getenforcemode(ptr_enforcemode):
            enforcemode = ptr_enforcemode.contents
            enforcemode.value = enforcemodevalue
            return 0

        _selinux_lib.selinux_getenforcemode.side_effect = mock_getenforcemode
        result = selinux_getenforcemode()
        assert result == [0, enforcemodevalue]



# Generated at 2022-06-22 22:22:57.532842
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/atd.conf', 0) == [0, 'system_u:object_r:bin_t']
    assert matchpathcon('/some/path/that/does/not/exist', 0) == [-1, None]



# Generated at 2022-06-22 22:23:03.269109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.exists('/proc/self/attr/current'):
        pass
    else:
        rc, con = lgetfilecon_raw('/proc/self/attr/current')
        print('rc=%d, con=%s' % (rc, con))


# Generated at 2022-06-22 22:23:06.137990
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Return:
        [0, "system_u:object_r:usr_t:s0"]
    """
    return matchpathcon(b'/usr', 0)

# Generated at 2022-06-22 22:23:07.519679
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: not yet implemented
    pass


# Generated at 2022-06-22 22:23:11.478216
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'

    [rc, con] = lgetfilecon_raw(path)

    assert rc == 0
    assert "system_u:object_r:etc_t:s0" == con
    assert isinstance(con, str)

# Generated at 2022-06-22 22:23:15.003825
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_keys = ['result', 'result_raw']
    expected_values = [0, 'targeted']
    outcome = selinux_getpolicytype()

    assert all(key in outcome for key in expected_keys)
    assert all(key == expected_values[i] for i, key in enumerate(outcome))

# Generated at 2022-06-22 22:23:16.592467
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result[0] == 0
    assert result[1] == 'targeted'

# Generated at 2022-06-22 22:23:20.532020
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_type = to_native('targeted')
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == expected_type



# Generated at 2022-06-22 22:23:22.030628
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:23:26.861318
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise OSError('selinux is not enabled')

    path = '/etc'
    mode = os.F_OK
    result = matchpathcon(path, mode)
    print(('matchpathcon(%s, %s) returned: %s' % (path, mode, result)))



# Generated at 2022-06-22 22:23:30.672545
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:user_tmp_t:s0')



# Generated at 2022-06-22 22:23:32.941725
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[0] == 0
    assert policy[1] != ""

# Generated at 2022-06-22 22:23:36.642406
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/log/audit"
    mode = 3
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:auditd_log_t:s0"



# Generated at 2022-06-22 22:23:39.279672
# Unit test for function matchpathcon
def test_matchpathcon():
    retval = matchpathcon('/etc/hosts', 0)
    assert retval[0] == 0
    assert retval[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-22 22:23:51.892573
# Unit test for function matchpathcon
def test_matchpathcon():
    expected1 = (0, 'system_u:object_r:admin_home_t:s0')
    expected2 = (1, 'system_u:object_r:admin_home_t:s0')
    expected3 = (1, 'system_u:object_r:admin_home_t:s0')
    expected4 = (1, 'system_u:object_r:admin_home_t:s0')
    expected5 = (1, 'system_u:object_r:admin_home_t:s0')
    expected6 = (0, 'system_u:object_r:admin_home_t:s0')
    expected7 = (1, 'system_u:object_r:admin_home_t:s0')

# Generated at 2022-06-22 22:23:54.397733
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy_type] = selinux_getpolicytype()
    assert rc == 0
    assert(policy_type == b"targeted")


# Generated at 2022-06-22 22:24:00.201669
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/etc/shadow', os.O_RDWR))
    print(matchpathcon('/etc/shadow', os.O_RDONLY))
    print(matchpathcon('/etc/shadow', os.O_WRONLY))
    print(matchpathcon('/noexist', os.O_RDWR))


# Generated at 2022-06-22 22:24:05.158433
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        raise ModuleFailException("selinux is not enabled")
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] == 0, "selinux_getenforcemode failed"
    assert enforcemode[1] >= 0 and enforcemode[1] <= 2, "invalid enforcemode: %d" % enforcemode[1]



# Generated at 2022-06-22 22:24:13.968969
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test selinux_getpolicytype() against expected return values

    Tests conducted:
        * Validate that the return code from selinux_getpolicytype is 0
        * Compare the returned policy type with the policy type set in the
          environment variable SELINUXTYPE under the /etc/selinux directory
    """

# Generated at 2022-06-22 22:24:17.846750
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not isinstance(lgetfilecon_raw('/etc/sysconfig/selinux'), list):
        raise AssertionError('Expected a list')



# Generated at 2022-06-22 22:24:19.595414
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[0] == 0:
        print(result[1])


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:24:24.130657
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    if res[0] != 0:
        raise ValueError('selinux_getpolicytype failed with code {0}'.format(res[0]))
    if res[1] is None:
        raise ValueError('selinux_getpolicytype returned None')

# Generated at 2022-06-22 22:24:26.428658
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0, rc



# Generated at 2022-06-22 22:24:30.018981
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Call function
    result = selinux_getenforcemode()
    # Check return type
    assert (isinstance(result, list))
    # Check return value
    assert (isinstance(result[0], int))
    assert (isinstance(result[1], int))



# Generated at 2022-06-22 22:24:37.492786
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()
    print("Policy Type: %s" % policy)

    (rc, enforcemode) = selinux_getenforcemode()
    print("Enforcing Mode: %s" % enforcemode)

    print("is_selinux_enabled rc: %d" % is_selinux_enabled())
    print("is_selinux_enabled rc: %d" % is_selinux_enabled())
    print("is_selinux_mls_enabled rc: %d" % is_selinux_mls_enabled())
    print("is_selinux_mls_enabled rc: %d" % is_selinux_mls_enabled())
    print("security_getenforce rc: %d" % security_getenforce())

# Generated at 2022-06-22 22:24:39.139311
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:24:40.011792
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:24:43.097171
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config')[1] == 'system_u:object_r:etc_t:s0'
    assert lgetfilecon_raw('/usr/bin')[1] == 'system_u:object_r:usr_t:s0'

# Generated at 2022-06-22 22:24:45.320146
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(enforcemode, int)


# Generated at 2022-06-22 22:24:48.803787
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert isinstance(rc, int)
    assert isinstance(policytype, str)



# Generated at 2022-06-22 22:24:54.517109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/ls') == [0, 'system_u:object_r:bin_t:s0']
    assert lgetfilecon_raw('/usr/bin/false') == [0, 'system_u:object_r:bin_t:s0']
    assert lgetfilecon_raw('/usr/bin/true') == [0, 'system_u:object_r:bin_t:s0']



# Generated at 2022-06-22 22:24:59.958947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Path does not exist
    assert lgetfilecon_raw('/var/foo') == [-1, None]
    # Path with incorrect context
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    # Path with correct context
    assert lgetfilecon_raw('/etc/') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-22 22:25:06.414468
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    test_path = "/tmp/selinux_ctypes_test_file"

    os.open(test_path, os.O_CREAT, 0o644)

    rc, con = lgetfilecon_raw(test_path)
    if rc != 0:
        raise OSError("lgetfilecon_raw failed, RC: %d\n" % rc)

    os.remove(test_path)

    return con



# Generated at 2022-06-22 22:25:09.344017
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res[0] == 0
    assert isinstance(res[1], str)

# Generated at 2022-06-22 22:25:11.479215
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] == 0
    assert enforcemode[1] == 1


# Generated at 2022-06-22 22:25:21.848797
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_value = matchpathcon('/etc', 0)
    if rc != 0:
        raise Exception("matchpathcon returned error {}".format(os.strerror(rc)))

    if con_value.split(':')[0] == 'root':
        raise Exception("recipient is not root")

    rc, con_value = lgetfilecon_raw('/etc')
    if rc != 0:
        raise Exception("lgetfilecon_raw returned error {}".format(os.strerror(rc)))

    if con_value.split(':')[0] == 'root':
        raise Exception("recipient is not root")

    rc, con_value = selinux_getpolicytype()

# Generated at 2022-06-22 22:25:26.235208
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype is not None



# Generated at 2022-06-22 22:25:30.306323
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Tests that matchpathcon returns an error code of -1 and an error message when the path does not exist
    :return: None
    """
    path = '/tmp/doesnotexist/'
    mode = 0

    rc, con = matchpathcon(path, mode)

    assert (rc == -1 and con == 'No such file or directory')


# Generated at 2022-06-22 22:25:33.247386
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert [0, 'system_u:object_r:bin_t:s0'] == lgetfilecon_raw(b'/bin/ls')



# Generated at 2022-06-22 22:25:36.554457
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert enforcemode >= 0
    assert enforcemode <= 2
    assert rc == 0

# Generated at 2022-06-22 22:25:39.829830
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # check if the selinux is enabled
    try:
        [rc, enforcemode] = selinux_getenforcemode()
    except OSError as e:
        return 0
    return enforcemode



# Generated at 2022-06-22 22:25:48.172818
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # NOTE: These values are from selinux/include/selinux/selinux.h
    enforcemode_val_to_name = {
        0: 'Disabled',
        1: 'Permissive',
        2: 'Enforcing',
    }
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in enforcemode_val_to_name
    assert enforcemode_val_to_name[enforcemode]



# Generated at 2022-06-22 22:25:51.825725
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_rc, expected_con = matchpathcon("/tmp/t.txt", 0)
    assert expected_rc == 0, "Function returned unexpected value"
    assert expected_con == "system_u:object_r:user_tmp_t", "Function returned unexpected value"


# Generated at 2022-06-22 22:25:58.904681
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # path = b"/etc/passwd"
    path = to_bytes("/etc/passwd")
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == b"system_u:object_r:etc_runtime_t:s0"
    assert type(con) is bytes
    assert type(rc) is int



# Generated at 2022-06-22 22:26:06.419830
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Create a file in the temporary directory and get the SELinux context of the file
    :return:
    """

    import tempfile
    import selinux

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, "test_file")

    with open(test_file, 'a'):
        os.utime(test_file, None)

    [rc, cxt_str] = selinux.lgetfilecon_raw(test_file)
    assert rc == 0
    cxt = selinux.matchpathcon(test_file, 0)
    assert cxt == cxt_str

    os.unlink(test_file)
    os.rmdir(test_dir)

# Generated at 2022-06-22 22:26:09.888740
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _con = lgetfilecon_raw('/usr/bin/python3')[1]
    assert _con == b'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-22 22:26:16.821937
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, policytype] = selinux_getpolicytype()
        assert rc == 0, '{} != 0'.format(rc)
        assert policytype, policytype
    except OSError as e:
        assert False, 'platform does not support SELinux: {}'.format(to_native(e))
    except Exception as e:
        assert False, 'unexpected exception: {}'.format(to_native(e))

# Generated at 2022-06-22 22:26:19.003415
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 'system_u:object_r:tmp_t' == matchpathcon('/tmp', 0)[1]



# Generated at 2022-06-22 22:26:21.696288
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc == 0:
        print('SELinux is in ', end='')
        if enforcemode == 0:
            pr

# Generated at 2022-06-22 22:26:27.789839
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat

    test_file = '/tmp/selinux_test_file'
    if not os.path.exists(test_file):
        with open(test_file, 'w'):
            pass
    if stat.S_ISLNK(os.lstat(test_file).st_mode):
        print("Skipping matchpathcon test on symlinks for now.")
        return
    test_mode = stat.S_IMODE(os.lstat(test_file).st_mode)
    res = matchpathcon(test_file, test_mode)
    assert res[0] == 0
    assert isinstance(res[1], str)

# Generated at 2022-06-22 22:26:31.331227
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0
    assert len(policytype[1]) > 0
    assert isinstance(policytype[1], str)


# Generated at 2022-06-22 22:26:37.051839
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/var/log/audit/audit.log')
    print('calling lgetfilecon_raw /var/log/audit/audit.log')
    print('return code rc:', rc)
    print('con:', con)


# Generated at 2022-06-22 22:26:45.622757
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    testresult = selinux_getenforcemode()
    assert isinstance(testresult, list)
    if (testresult[0]) == -1:
        assert 'not implemented' in testresult[1]
    else:
        assert isinstance(testresult[0], int)
        assert isinstance(testresult[1], int)
        assert (testresult[1] == 0 or testresult[1] == 1 or testresult[1] == 2)


# Generated at 2022-06-22 22:26:51.019124
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest
    from ansible.module_utils._text import to_bytes

    class TestSelinuxGetpolicytype(unittest.TestCase):
        def test_selinux_getpolicytype(self):
            self.assertEqual(selinux_getpolicytype()[1], 'targeted')
    unittest.main(argv=[to_bytes(sys.argv[0])])

# Generated at 2022-06-22 22:26:52.636946
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con



# Generated at 2022-06-22 22:26:54.099506
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy, _ = selinux_getpolicytype()
    assert policy >= 0


# Generated at 2022-06-22 22:26:55.512898
# Unit test for function matchpathcon
def test_matchpathcon():
    _out, _rc = matchpathcon('/var/log', 0)
    assert _rc == 0

# Generated at 2022-06-22 22:26:58.227663
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/tmp")[1] == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-22 22:27:04.227448
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.six.moves import shlex_quote
    (rc, con) = matchpathcon(shlex_quote('/etc/passwd'), 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    assert lgetfilecon_raw(shlex_quote('/etc/passwd'))[1] == con


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:27:11.803387
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/selinux/test', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/selinux/test', 1) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/selinux/test', 2) == [0, '']
    assert matchpathcon('/selinux/test', 3) == [0, '']


# Generated at 2022-06-22 22:27:22.374587
# Unit test for function matchpathcon
def test_matchpathcon():
    # NB: using /tmp here
    # will not work on selinux
    # test_file = open('/tmp/tmpfile', 'w+')
    # test_file.write('this is a test\n')
    # test_file.close()
    test_file = '/tmp/tmpfile'
    rc, con = matchpathcon(test_file, 7)
    print (con)
    # rc, con = lgetfilecon_raw(test_file)
    # print (con)
    # rc, con = lsetfilecon(test_file, "system_u:object_r:user_tmp_t:s0")
    # print (rc)
    # rc, con = lgetfilecon_raw(test_file)
    # print (con)
    # rc, con = lsetfilecon(test

# Generated at 2022-06-22 22:27:27.360273
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        _selinux_lib.lgetfilecon_raw(b"/", byref(c_char_p()))
    except OSError as e:
        if "Permission denied" in str(e):
            # On older systems selinux is disabled and will return "Permission denied".
            return
        raise

# Generated at 2022-06-22 22:27:29.991851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"/")
    assert rc >= 0
    assert con == "system_u:object_r:root_t:s0"

# Generated at 2022-06-22 22:27:38.474856
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == lgetfilecon_raw("/bin/bash")[0]
    assert 0 == lgetfilecon_raw("/sbin/zfs")[0]
    assert 0 == lgetfilecon_raw("/etc/aliases")[0]
    assert 0 == lgetfilecon_raw("/usr/bin/python3")[0]

    # Test that it returns an error string for a file that doesn't exist
    assert -1 == lgetfilecon_raw("/path/to/no/file")[0]
    assert "No such file or directory" in lgetfilecon_raw("/path/to/no/file")[1]


# Generated at 2022-06-22 22:27:44.811739
# Unit test for function matchpathcon
def test_matchpathcon():
    # not sure how to write a unit test that is cross platform
    # so here is a simple example to print the path context
    # of the test file to the screen
    print("context: '{0}'".format(matchpathcon("selinux.py", 0)[1]))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:27:52.868971
# Unit test for function matchpathcon
def test_matchpathcon():
    # test matchpathcon function
    # this test requires the selinux_testuser_u:selinux_testrole_r:selinux_testtype_t:s0 context
    rc = lsetfilecon("/tmp/test", 'selinux_testuser_u:selinux_testrole_r:selinux_testtype_t:s0')
    assert rc == 0
    # test matchpathcon function
    [rc, con] = matchpathcon("/tmp/test", os.R_OK)
    assert rc == 0
    assert con == 'selinux_testuser_u:selinux_testrole_r:selinux_testtype_t:s0'
    # test matchpathcon function

# Generated at 2022-06-22 22:27:54.464190
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:27:57.025060
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: write this unit test
    pass


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:28:01.697497
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/log'
    rc, result = lgetfilecon_raw(path)
    assert rc == 0, 'Errno {0}: {1}'.format(rc, os.strerror(rc))
    assert result == 'system_u:object_r:syslogd_devlog_t:s0'



# Generated at 2022-06-22 22:28:03.902002
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0



# Generated at 2022-06-22 22:28:07.736841
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/test', 0) == [0, "system_u:object_r:admin_home_t:s0"]



# Generated at 2022-06-22 22:28:10.943345
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == 0
    assert _selinux_lib.selinux_getpolicytype.argtypes is not None
    assert _selinux_lib.selinux_getpolicytype.restype is not None

# Generated at 2022-06-22 22:28:12.500069
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0

# Generated at 2022-06-22 22:28:15.096506
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    (rc, policy_type) = res
    print("rc: {}".format(rc))
    print("policy type: {}".format(policy_type))



# Generated at 2022-06-22 22:28:19.943045
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0o777
    result = matchpathcon(path, mode)
    assert result == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-22 22:28:20.889911
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-22 22:28:23.856771
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        con = lgetfilecon_raw("/")
        print("/:", con)
    except OSError as err:
        print("Error: %s" % str(err))


# Generated at 2022-06-22 22:28:25.461043
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    print(enforcemode)


# Generated at 2022-06-22 22:28:27.230476
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-22 22:28:31.797672
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0, 'selinux_getpolicytype failed, rc = {0}'.format(rc)
    print('selinux_getpolicytype returned: {0}'.format(con))


# Generated at 2022-06-22 22:28:33.422657
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-22 22:28:39.218929
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw(__file__)
    except OSError as e:
        sys.exit('UNTRUSTED: errno=%d: %s' % (e.args[0], e.args[1]))
    else:
        if rc < 0:
            sys.exit(con)
        else:
            sys.exit('TRUSTED: ' + con)

# Generated at 2022-06-22 22:28:41.592664
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tmpfile = '/tmp/ansible_test_module_selinux'
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0


# Generated at 2022-06-22 22:28:44.108053
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/tmp/test.txt', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-22 22:28:53.414544
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == lgetfilecon_raw('/')[0]
    assert 0 == lgetfilecon_raw('/usr')[0]
    # should handle file not found gracefully
    assert -1 == lgetfilecon_raw('/file/not/exist')[0]
    # There is no way to check for errno due to string conversion
    # this test will pass in any isolinux
    # the only way to fix that is to isolate the errno
    # assert 2 == lgetfilecon_raw('/file/not/exist')[0]
    assert -1 == lgetfilecon_raw('/usr/')[0]


# Generated at 2022-06-22 22:28:57.074009
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode = selinux_getenforcemode()
    try:
        assert isinstance(mode, list)
        assert mode[0] == 0
        assert mode[1] in [0, 1, 2]
    except AssertionError:
        raise AssertionError("Test failed when running selinux_getenforcemode()")


# Generated at 2022-06-22 22:28:59.105438
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/etc')
        assert rc >= 0
        assert con == 'system_u:object_r:etc_t:s0'
    except Exception:
        pass



# Generated at 2022-06-22 22:29:06.442042
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import subprocess
    child = subprocess.Popen(['getenforce'], stdout=subprocess.PIPE)
    child.wait()
    child_stdout = child.stdout.read().decode('utf-8').strip()
    if child_stdout == 'Enforcing':
        assert [0, 1] == selinux_getenforcemode()
    elif child_stdout == 'Permissive':
        assert [0, 0] == selinux_getenforcemode()
    elif child_stdout == 'Disabled':
        assert [0, -1] == selinux_getenforcemode()



# Generated at 2022-06-22 22:29:09.352505
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    data = selinux_getenforcemode()
    assert len(data) == 2
    if not isinstance(data[1], int):
        raise AssertionError


# Generated at 2022-06-22 22:29:12.435417
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    rc, value = lgetfilecon_raw(path)
    assert(rc == 0)
    assert(to_native(value) == "system_u:object_r:root_t:s0")


# Generated at 2022-06-22 22:29:17.304316
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/selinux/config'
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:29:20.551408
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        result = matchpathcon(f.name, 0)
        assert result[0] == 0


# Generated at 2022-06-22 22:29:24.286427
# Unit test for function matchpathcon
def test_matchpathcon():
    import unittest
    rv = matchpathcon('/foo', os.R_OK)
    assert rv[0] == 0
    assert rv[1] == 'system_u:object_r:default_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:29:30.992255
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Functional unit test for selinux/selinux_getenforcemode.py
    Ansible module_utils function.
    '''
    # Some possible return codes
    return_code_0 = 0
    return_code_minus_1 = -1

    rc, enforcemode = selinux_getenforcemode()
    if (rc == return_code_0) and (enforcemode == 1):
        print('successfull call to selinux_getenforcemode')
    else:
        print('unsuccessfull call to selinux_getenforcemode')
    return



# Generated at 2022-06-22 22:29:38.729804
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    def _try_matchpathcon(path):
        rc, con = matchpathcon(path, 0)
        print(path, rc, con)
        if rc < 0:
            errno = get_errno()
            print(errno, os.strerror(errno))

    print('\nTest matchpathcon...')
    _try_matchpathcon('/etc/')
    _try_matchpathcon('/etc/passwd')
    _try_matchpathcon('/etc/passwd-')
    _try_matchpathcon('/root/')
    _try_matchpathcon('/etc/passwd-' + 'x' * 1024)
    _try_matchpathcon('/etc/passwd-' + 'x' * 2048)

# Generated at 2022-06-22 22:29:40.974069
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = "/bin/ls"
    rc, file_context = lgetfilecon_raw(file,)
    print("rc: %d, file_context: %s" % (rc, file_context))



# Generated at 2022-06-22 22:29:44.142465
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:29:51.928593
# Unit test for function matchpathcon
def test_matchpathcon():
    testpath = b'/etc/hosts'
    mode = 0

    rc, con = matchpathcon(testpath, mode)
    selinux_context = to_native(con)
    print('selinux_context: {}'.format(selinux_context))

    rc, con = lgetfilecon_raw(testpath)
    raw_context = to_native(con)
    print('raw_context: {}'.format(raw_context))
    rc, con = matchpathcon(testpath, mode)
    selinux_context = to_native(con)
    print('selinux_context: {}'.format(selinux_context))



# Generated at 2022-06-22 22:29:55.312017
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy_type, str)

# Generated at 2022-06-22 22:30:03.728310
# Unit test for function matchpathcon
def test_matchpathcon():
    """Unit test for function matchpathcon"""

    # Test path '/etc/passwd' exists
    (rc, con) = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test path '/etc/password' does not exist
    (rc, con) = matchpathcon('/etc/password', 0)
    assert rc == -1
    assert con is None
    assert 'No such file or directory' in os.strerror(get_errno())


# Generated at 2022-06-22 22:30:12.481966
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    dirname = tempfile.mkdtemp()
    try:
        path = os.path.join(dirname, "testfile")
        mode = os.O_CREAT | os.O_WRONLY
        open(path, mode).close()
        assert matchpathcon(path, mode)[1] == "unconfined_u:object_r:user_tmp_t:s0"
        with open(path, "r") as f:
            assert matchpathcon(f, mode)[1] == "unconfined_u:object_r:user_tmp_t:s0"
    finally:
        shutil.rmtree(dirname)

# Generated at 2022-06-22 22:30:15.758380
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    selinux_getpolicytype() should return a string for policytype
    """
    policytype = selinux_getpolicytype()
    assert isinstance(policytype[1], str)
    assert policytype[0] >= 0



# Generated at 2022-06-22 22:30:20.327508
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    p = tempfile.mkstemp()[1]
    mode, con = matchpathcon(p, 0)
    assert mode == 0
    assert con == 'u:object_r:tmp_t:s0'

    os.chmod(p, 0o777)
    mode, con = matchpathcon(p, os.R_OK)
    assert mode == 0
    assert con == 'u:object_r:tmp_t:s0'

    mode, con = matchpathcon(p, os.W_OK)
    assert mode == 0
    assert con == 'u:object_r:tmp_t:s0'

    mode, con = matchpathcon(p, os.X_OK)
    assert mode == 0

# Generated at 2022-06-22 22:30:23.718111
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert len(enforcemode) == 2
    assert isinstance(enforcemode, list)
    assert enforcemode[0] >= 0
    assert enforcemode[1] in ['enforcing', 'permissive', 'disabled']


# unit test for function selinux_getpolicytype

# Generated at 2022-06-22 22:30:27.841961
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    failed_policytypes = []
    try:
        rc, policytype = selinux_getpolicytype()
        if rc != 0:
            failed_policytypes.append([rc, policytype])
    except NotImplementedError as e:
        failed_policytypes.append(e)

    return failed_policytypes

# Generated at 2022-06-22 22:30:32.528832
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Test lgetfilecon_raw function
    '''
    path = "/bin/bash"
    res = lgetfilecon_raw(path)
    assert isinstance(res, tuple)
    assert len(res) == 2
    assert res == (0, 'system_u:object_r:bin_t:s0')

# Generated at 2022-06-22 22:30:38.015812
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:boot_t:s0']
    assert matchpathcon('/var', 0) == [0, 'system_u:object_r:var_t:s0']
    assert matchpathcon('/var/log', 0) == [0, 'system_u:object_r:var_log_t:s0']
    assert matchpathcon('/var/log/audit', 0) == [0, 'system_u:object_r:auditd_log_t:s0']



# Generated at 2022-06-22 22:30:41.713385
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0
    assert selinux_getenforcemode()[1] in [0, 1, 2]


# Generated at 2022-06-22 22:30:43.950912
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc != 0:
        raise Exception("selinux_getpolicytype: {0}".format(rc))


# Generated at 2022-06-22 22:30:55.512968
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matching on file
    [rc, con] = matchpathcon("/etc/passwd", 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test matching on directory
    [rc, con] = matchpathcon("/etc", 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test matching on symlink
    [rc, con] = matchpathcon("/etc/resolv.conf", 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test matching on non-existant file
    [rc, con] = matchpathcon("/non-existant-file", 0)

# Generated at 2022-06-22 22:30:58.858208
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, retval = selinux_getpolicytype()
    assert type(retval) is str
    assert rc == 0


# Generated at 2022-06-22 22:31:09.223400
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    fname = None
    con = None

# Generated at 2022-06-22 22:31:15.033233
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, context) = matchpathcon('/', 0)
    assert rc == -1
    assert context == 'unconfined_u:object_r:usr_t:s0'
    # Ignore the rc, just check if environ is produced
    assert matchpathcon('/etc/passwd', 0)[1] == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-22 22:31:19.420324
# Unit test for function matchpathcon
def test_matchpathcon():
    # This is a very basic smoke test for the matchpathcon function,
    # but the selinux tests are in test/sanity/selinux/
    rc, output = matchpathcon('/', 0)
    assert rc == 0, 'rc should be 0'
    assert output, 'output should not be empty'

# Generated at 2022-06-22 22:31:22.148161
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert type(enforcemode) == int


# Generated at 2022-06-22 22:31:26.481601
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Check selinux_getpolicytype when selinux is not disabled.
    """
    is_enabled = is_selinux_enabled()
    if not is_enabled:
        raise Exception('selinux is not enabled')
    rc, policy_type = selinux_getpolicytype()
    if rc:
        raise Exception('selinux_getpolicytype failed')
    print("Policy type: {}".format(policy_type))


# Generated at 2022-06-22 22:31:29.347734
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''Test selinux_getenforcemode function'''
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1


# Generated at 2022-06-22 22:31:31.693049
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'

# Generated at 2022-06-22 22:31:33.725947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """lgetfilecon_raw functions correctly if we can get a file context"""
    assert lgetfilecon_raw('/')[0] == 0


# Generated at 2022-06-22 22:31:38.774831
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/foo/bar', os.R_OK)
    if rc == -1:
        raise OSError(os.strerror(get_errno()))



# Generated at 2022-06-22 22:31:41.371965
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type, policytype = selinux_getpolicytype()
    assert policy_type == 0
    assert policytype != ''



# Generated at 2022-06-22 22:31:44.188668
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    x = lgetfilecon_raw(path)
    print(x[0])
    print(x[1])
    print(type(x[1]))


# Generated at 2022-06-22 22:31:45.785700
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1]



# Generated at 2022-06-22 22:31:48.078644
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    if rc == 0:
        print('The context of /tmp is {}.'.format(con))

# Generated at 2022-06-22 22:31:54.905650
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for lgetfilecon_raw

    # Disable selinux as selinux checks are not enabled in this environmnet
    assert (selinux_getenforcemode()[1] == 0)

    if not is_selinux_enabled():
        assert (False, "selinux not enabled")
    if not is_selinux_mls_enabled():
        assert (False, "Multilevel selinux not enabled")
    rc, type = lgetfilecon_raw("/etc/shadow")
    assert (rc == 0)
    rc, type = lgetfilecon_raw("/etc/shadow")
    assert (rc == 0)

# Generated at 2022-06-22 22:31:58.505773
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/home/system/.ssh/authorized_keys", 0)
    assert rc == 0
    assert con == 'ssh_home_t'

# Generated at 2022-06-22 22:32:04.615955
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fd = open("sample.log", 'w')
    fd.close()
    ret = lgetfilecon_raw("sample.log")
    assert ret[0] == 0
    assert ret[1] != ''
    # assert ret[1] == 'unconfined_u:object_r:user_tmp_t:s0\0'

if __name__ == '__main__':
    # Unit tests for user_info.py
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:32:08.945014
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Validate that the basic selinux_getenforcemode function works"""
    from selinux import (SELINUX_MANDATORY_POLICY, SELINUX_ENFORCING)
    assert selinux_getenforcemode() == [0, SELINUX_MANDATORY_POLICY]
    assert security_getenforce() == SELINUX_ENFORCING



# Generated at 2022-06-22 22:32:11.824928
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert len(res) == 2
    assert type(res[0]) == int
    assert type(res[1]) == unicode


# Generated at 2022-06-22 22:32:20.050885
# Unit test for function matchpathcon
def test_matchpathcon():
    lib = CDLL('libselinux.so.1', use_errno=True)
    con = c_char_p()
    path = b"/usr/bin"
    mode = 0o755
    rc = lib.matchpathcon(path, mode, byref(con))
    assert rc == 0
    assert con.value == b'unconfined_u:object_r:usr_t:s0'


# Generated at 2022-06-22 22:32:24.379268
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/foo/bar', 0))
    print(matchpathcon('/foo/bar', 0))
    print(matchpathcon('/foo/bar', 0))
    print(matchpathcon('/foo/bar', 0))
    print(matchpathcon('/foo/bar', 0))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:32:28.907996
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.exists('/etc/selinux/config'):
        return
    if is_selinux_enabled() != 1:
        return
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    if rc != 0:
        raise RuntimeError('Failed to get context')
    print(con)



# Generated at 2022-06-22 22:32:30.714586
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, int), "Returned enforcemode is not an integer"


# Generated at 2022-06-22 22:32:34.609541
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    if policytype not in ['targeted', 'minimum', 'mls']:
        raise ValueError(policytype)
