

# Generated at 2022-06-11 17:13:36.829437
# Unit test for function safe_eval
def test_safe_eval():
    # pass
    assert safe_eval('1 + 1') == 2
    assert safe_eval('dict(a=1, b=2)') == dict(a=1, b=2)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('True')
    assert safe_eval('False')
    assert safe_eval('None')
    assert safe_eval('-1') == -1
    assert safe_eval('(-1)') == -1
    assert safe_eval('dict(a=1, b=2)') == dict(a=1, b=2)
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('dict(a=[1, 2])') == dict(a=[1,2])
   

# Generated at 2022-06-11 17:13:44.823844
# Unit test for function safe_eval
def test_safe_eval():
    _locals = {
        'a': {
            'b': "bar",
            'c': "baz"
        },
        'd': "hello world",
        'e': [0, 1, 2],
        'f': True,
        'g': False,
        'h': None,
        'i': 100,
        'j': ['a', 'b', 'c'],
        'k': 100.1
    }


# Generated at 2022-06-11 17:13:55.655881
# Unit test for function safe_eval
def test_safe_eval():
    ev = safe_eval
    eq = lambda x,y: ev(x) == ev(y)
    ok = lambda x: eq(x, x)
    ok('locals()["x"]')
    ok('10/3')
    ok('10/3.0')
    ok('[1,2,3]')
    ok('true')
    ok('false')
    ok('null')
    ok('{"a": "a", "b": "b"}')
    #ok('"a" + "b"')
    #ok('"a" * 2')
    ok('len([1,2,3])')
    assert ev('len()') == 'len()'
    assert ev('len') == 'len'
    assert ev('len([1,2,3]') == 'len([1,2,3]'


# Generated at 2022-06-11 17:14:06.410600
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:14.633078
# Unit test for function safe_eval
def test_safe_eval():
    ''' test_safe_eval

    returns:
      True if safe_eval passes all of the tests
    '''

# Generated at 2022-06-11 17:14:22.920643
# Unit test for function safe_eval
def test_safe_eval():
    def check(test_input, test_result, test_exception):
        c = 'test_input: %s, test_result: %s, test_exception: %s' % (test_input, test_result, test_exception)
        try:
            (result, error) = safe_eval(test_input, include_exceptions=True)
            assert result == test_result
            assert error == test_exception
            if C.DEFAULT_DEBUG:
                print('%s: Success' % c)
        except AssertionError:
            print('%s: Failed' % c)
            print('test_eval: %s' % result)
            print('test_error: %s' % error)

            if error is not None:
                raise error

    # check constant success

# Generated at 2022-06-11 17:14:31.198917
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:38.121423
# Unit test for function safe_eval
def test_safe_eval():

    # define a whitelist of functions to enable in safe_eval
    # in this case we want to allow len()
    CALL_ENABLED.append('len')

    # run the tests
    def _test_safe_eval(input, expected, fail_msg, locals=None):
        try:
            out = safe_eval(input, locals=locals)
            passed = out == expected
        except Exception:
            passed = False

        if not passed:
            print("{0} Expression: {1}".format(fail_msg, input))
            print("Expected: {0}\nGot: {1}\n".format(expected, out))
        assert passed

    _test_safe_eval("len(foo)", 3,
        "safe_eval failed when calling white listed function",
        {'foo': [1, 2, 3]})

# Generated at 2022-06-11 17:14:48.410196
# Unit test for function safe_eval
def test_safe_eval():
    # test valid expressions
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 * 1") == 1
    assert safe_eval("1 / 1") == 1
    assert safe_eval("1 - 1") == 0
    assert safe_eval("1 - -1") == 2
    assert safe_eval("1 + 1 + 1") == 3
    assert safe_eval("1 + -1 + 1") == 1
    assert safe_eval("1 + (5 - 3) + 1") == 4
    assert safe_eval(str(sys.maxsize + 1)) == (sys.maxsize + 1)
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval('"a string"') == "a string"
    assert safe_eval("1 == 1") is True


# Generated at 2022-06-11 17:14:56.955415
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:07.822484
# Unit test for function safe_eval
def test_safe_eval():
    # TEST FAILURES

    try:
        safe_eval("fnord")
        assert False, "expected exception"
    except Exception as e:
        if not str(e).startswith('invalid expression'):
            raise

    try:
        safe_eval("fnord")
        assert False, "expected exception"
    except Exception as e:
        if not str(e).startswith('invalid expression'):
            raise

    try:
        safe_eval("warning('')")
        assert False, "expected exception"
    except Exception as e:
        if not str(e).startswith('invalid expression'):
            raise


# Generated at 2022-06-11 17:15:17.385638
# Unit test for function safe_eval
def test_safe_eval():

    FAIL_TESTS = [
        '__import__("os").geteuid()',
        '__import__("os").system("ls")',
        '__import__("os").system("rm -rf /")',
        # This can be enabled with the 'set' node, but is
        # left disabled for now to prevent anyone from
        # overriding a constant set in ansible with_items:
        #'a=1;print(a);a=2;print(a)',
        #'a=12345;b=3;print(a*b)',
        #'a=12345;b=3;print(a**b)',
        'a=12345;b=0;print(a/b)',
    ]


# Generated at 2022-06-11 17:15:27.378961
# Unit test for function safe_eval
def test_safe_eval():

    safe_funcs = {
        'min': [int, float],
        'max': [int, float],
    }

    for func_name, arg_types in safe_funcs.items():
        for arg_type in arg_types:
            CALL_ENABLED.append(func_name)
            try:
                expr = '%s(1, 2)' % func_name
                result = safe_eval(expr)
                assert result == arg_type(1)
            except:
                raise Exception("safe_eval unexpectedly failed to allow call to %s" % func_name)

    CALL_ENABLED = list(safe_funcs)


# Generated at 2022-06-11 17:15:36.957526
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('"some text"') == "some text"
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('a + b', dict(a=1, b=2)) == 3
    assert safe_eval('1 - -1') == 2
    assert safe_eval('6/2') == 3

# Generated at 2022-06-11 17:15:45.656438
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run tests of the safe_eval function.
    '''
    # Most of these tests were directly taken from the safe_eval docstring
    # (see above)

# Generated at 2022-06-11 17:15:55.722064
# Unit test for function safe_eval
def test_safe_eval():
    expr = '1 + 2'
    assert safe_eval(expr) == 3

    expr = '3 - 2'
    assert safe_eval(expr) == 1

    expr = '5 * 2'
    assert safe_eval(expr) == 10

    expr = '6 / 2'
    assert safe_eval(expr) == 3

    expr = '-5'
    assert safe_eval(expr) == -5

    expr = '4 ** 2'
    assert safe_eval(expr) == 16

    expr = '[1, 2, 3]'
    assert safe_eval(expr) == [1, 2, 3]

    expr = '{"a": "b"}'
    assert safe_eval(expr) == {u'a': u'b'}

    expr = '"a"'

# Generated at 2022-06-11 17:16:06.667180
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:15.752754
# Unit test for function safe_eval
def test_safe_eval():
    # unicode should pass
    assert safe_eval(u'{"foo": "bar"}') == {u'foo': u'bar'}
    # now str
    assert safe_eval('{"foo": "bar"}') == {u'foo': u'bar'}

    # unicode should pass
    assert safe_eval(u'1 + 1') == 2
    # now str
    assert safe_eval('1 + 1') == 2

    # unicode should pass
    assert safe_eval(u'["a", "b", "c"]') == [u'a', u'b', u'c']
    # now str
    assert safe_eval('["a", "b", "c"]') == [u'a', u'b', u'c']

    # unicode should pass

# Generated at 2022-06-11 17:16:23.957595
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('[1, 2] + [3, 4]') == [1, 2, 3, 4]
    assert safe_eval('foo(bar)') == 'foo(bar)'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo(1,2,3)') == 'foo(1,2,3)'
    assert safe_eval('{"foo": 1}') == {'foo': 1}
    assert safe_eval('foo(bar[1])') == 'foo(bar[1])'
    assert safe_eval('foo(bar(1))') == 'foo(bar(1))'

# Generated at 2022-06-11 17:16:34.591972
# Unit test for function safe_eval
def test_safe_eval():
    # simple tests - should return values without an exception
    assert safe_eval(None) is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('1') == 1 and type(safe_eval('1')) == int
    assert safe_eval('1.1') == 1.1 and type(safe_eval('1.1')) == float
    assert safe_eval('[1, 2]') == [1, 2] and type(safe_eval('[1, 2]')) == list

# Generated at 2022-06-11 17:16:43.942421
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-argument
    for expr, expected in C.SAFE_EVAL_TESTS:
        result, e = safe_eval(expr, include_exceptions=True)
        print('safe_eval: `{}` -> `{}`'.format(expr, result))
        print(' safe_eval: Exception `{}`'.format(e))
        assert result == expected
        assert e is None

# Generated at 2022-06-11 17:16:51.503091
# Unit test for function safe_eval
def test_safe_eval():
    # test literal strings
    assert safe_eval('string') == 'string'
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') is None
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.0') == 1
    assert safe_eval('1') == 1
    assert safe_eval('1l') == 1
    assert safe_eval('True') == True
    assert safe_eval('false') == False
    assert safe_eval('true') == True
    assert safe_eval('zero') == 'zero'
    assert safe_eval('null') is None

    # test math
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1')

# Generated at 2022-06-11 17:17:00.559159
# Unit test for function safe_eval
def test_safe_eval():
    # Test that we can evaluate an expression, as long as it's safe.
    # These should all pass
    check_safe_eval("['a', 'b', 'c']")
    check_safe_eval("'foo'")
    check_safe_eval("True and False")
    check_safe_eval("True or False")
    check_safe_eval("False and False")
    check_safe_eval("False or True")
    check_safe_eval("'foo' in 'foobar'")
    check_safe_eval("1 == 1")
    check_safe_eval("1 > 1")
    check_safe_eval("1 < 1")
    check_safe_eval("True == False or True")
    check_safe_eval("True or False == True")
    check_safe_eval("True")
    check_safe_

# Generated at 2022-06-11 17:17:11.235985
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:20.318312
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('3 + 5')

    # This should throw an exception
    try:
        safe_eval('__import__("os").listdir')
    except Exception as e:
        if 'invalid expression' in to_native(e):
            print("Caught expected invalid expression exception")
        else:
            raise e

    # This should throw an exception
    try:
        safe_eval('hasattr(foo, "bar")')
    except Exception as e:
        if 'invalid expression' in to_native(e):
            print("Caught expected invalid expression exception")
        else:
            raise e

    # This should throw an exception

# Generated at 2022-06-11 17:17:28.851510
# Unit test for function safe_eval
def test_safe_eval():
    try:
        assert safe_eval("1") == 1
        assert safe_eval("'hello'") == 'hello'
        assert safe_eval("dict(a=1)") == dict(a=1)
        assert safe_eval("[1,2,3]") == [1,2,3]
        assert safe_eval("[1,2,3,a]", {'a': 4}) == [1,2,3,4]
        assert safe_eval("a", {'a': 4}) == 4
        assert safe_eval("False") == False
        assert safe_eval("ls") == 'ls'
        assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    except AssertionError as e:
        print("Error: %s" % e)
        sys.exit

# Generated at 2022-06-11 17:17:39.351614
# Unit test for function safe_eval
def test_safe_eval():
    PASSED = "PASSED: %s is okay to eval"
    FAIL = "FAIL: %s raised %s"
    FAIL_EVAL = "FAIL: %s could not be eval'd: %s"
    failed = 0
    call_enabled = ['min', 'max']

    exprs = (
        "{foo: 'bar'}",
        "[1, 2, 3]",
        "a_list[0]",
        "a_list[0] + 1",
        "a_list[0] + '1'",
        "a_list[0] + a_list[1]",
        "a_list + [True, False]",
        "'abc' + 'def'",
        "False or True",
        "True and True",
        "min(a_list)"
    )



# Generated at 2022-06-11 17:17:46.894002
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This test checks to make sure that we are executing safe_eval
    correctly. It's not exhaustive but will hopefully catch the
    majority of stupid errors we could make.
    '''
    builtins_set = set(dir(builtins))

    # these are the callable builtins that we allow
    tested_builtins = set((
        'len',
        'min',
        'max',
    ))

    untested_builtins = builtins_set - tested_builtins

    if untested_builtins:
        print("ERROR: Untested builtins!")
        print(untested_builtins)
        sys.exit(1)

    # use assert to make sure we get useful output that
    # doesn't just look like a stack trace

    # FIXME: add a test that checks that anonymous functions and
    # other function

# Generated at 2022-06-11 17:17:56.555471
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:03.537075
# Unit test for function safe_eval
def test_safe_eval():
    res, exc = safe_eval('{{foo}} + {{bar}}', dict(foo=1, bar=2), True)
    assert res == 3
    assert not exc

    res, exc = safe_eval('{{foo}} + {{bar}}', dict(foo=1, bar='a'), True)
    assert res == '1 + a'
    assert exc

    res, exc = safe_eval('{{foo}} + bar', dict(foo=1, bar='a'), True)
    assert res == '1 + bar'
    assert exc

    res, exc = safe_eval('{{foo}} + {{bar}}', dict(foo=1, bar='"Hello" if True else "Goodbye"'), True)
    assert res == '1 + Hello'
    assert not exc


# Generated at 2022-06-11 17:18:18.071724
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2+2") == 4
    assert safe_eval("2+3") == 5
    assert safe_eval("2+2.2") == 4.2
    assert safe_eval("(1,2)") == (1, 2)
    assert safe_eval("[1,2]") == [1, 2]
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("None") is None
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("none") == "none"
    assert safe_eval("true") == "true"
    assert safe_eval("false") == "false"

# Generated at 2022-06-11 17:18:27.974316
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:37.147480
# Unit test for function safe_eval
def test_safe_eval():
    # simple tests
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + foo', {'foo': 3}) == 4
    assert safe_eval('1 + foo', {'foo': 3}, include_exceptions=True)[0] == 4
    assert safe_eval('1 + foo', {'foo': 3}, include_exceptions=True)[1] is None
    assert safe_eval('1 + [1]') == 2
    assert safe_eval('1 + [1]', include_exceptions=True)[0] == 2
    assert safe_eval('1 + [1]', include_exceptions=True)[1] is None

# Generated at 2022-06-11 17:18:47.095191
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("[1,1]") == [1, 1]
    assert safe_eval("(1,2)") == (1, 2)
    assert safe_eval("{1:2}") == {1: 2}
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)

    assert safe_eval("3 + 4") == 7
    assert safe_eval("3 + 4", include_exceptions=True) == (7, None)
    assert safe_eval("2 * 3", include_exceptions=True) == (6, None)
    assert safe_eval("1 + 2 * 3", include_exceptions=True) == (7, None)

# Generated at 2022-06-11 17:18:53.538276
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    class TestSafeEval(unittest.TestCase):
        ''' basic tests for safe_eval '''
        # these are all expected to succeed

# Generated at 2022-06-11 17:19:02.743620
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:12.896612
# Unit test for function safe_eval
def test_safe_eval():

    # python syntax error (not possible   )
    try:
        assert safe_eval('foo(bar(3)') is None, "Should be None"
    except:
        print("Unexpected exception: ", sys.exc_info()[0])
        raise
    else:
        pass
    # Jinja2 syntax error
    assert safe_eval('foo["bar"]') == 'foo["bar"]', "Should be 'foo[\"bar\"]'"

    # Jinja2 dictionaries
    assert safe_eval('{ foo : "baz" }') == {'foo': 'baz'}, "Should be {'foo': 'baz'}"

# Generated at 2022-06-11 17:19:20.236298
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:30.459561
# Unit test for function safe_eval
def test_safe_eval():
    print("\nTesting function safe_eval")
    # List of test cases

# Generated at 2022-06-11 17:19:40.397476
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:02.825483
# Unit test for function safe_eval
def test_safe_eval():
    # Safe
    assert safe_eval('[True, False, None]') == [True, False, None]
    assert safe_eval('["a", "b"]') == ['a', 'b']
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('"abc"') == "abc"
    assert safe_eval('1') == 1
    assert safe_eval('None') == None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('(True, False)') == (True, False)
    assert safe_eval('(True, 2)') == (True, 2)
    assert safe_eval('(True, "a")') == (True, "a")

# Generated at 2022-06-11 17:20:12.053718
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval by successively adding a bad AST node to the code
    # we are trying to execute.  the set of nodes is the complement of
    # the SAFE_NODES set defined above.

    # We do not want to test execution of builtin functions, so we
    # exclude their names from the AST nodes we try to evaluate.
    # Specifically, we are looking for the ast.Name() node.
    safe_names = set([n.id for n in SAFE_NODES if isinstance(n, ast.Name)])

    # get a list of all builtins, then convert it to a set
    # for faster lookup
    blacklist = set(dir(__builtins__))

    # now generate a list of all builtins that aren't in the safe set
    # this will serve as the list of AST nodes to exclude from our tests

# Generated at 2022-06-11 17:20:19.314741
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo["bar"]') == 'foo["bar"]'
    assert safe_eval('foo.1') == 'foo.1'
    assert safe_eval('range(10)') == 'range(10)'
    assert safe_eval('foo - bar', dict(bar=1, foo=2)) == 1
    assert safe_eval('foo - bar', dict(bar=1)) == 'foo - bar'


# Generated at 2022-06-11 17:20:26.904434
# Unit test for function safe_eval
def test_safe_eval():
    # These are the exceptions we should be raising
    function_exceptions = []
    # These are the exceptions we should not be raising
    function_safe = []

    # Exceptions should be raised for the following lines
    function_exceptions.append('socket.gethostname()')
    function_exceptions.append('os.path()')
    function_exceptions.append('[1,2,3].remove()')
    function_exceptions.append('repr(locals())')
    function_exceptions.append('json.dumps({})')
    function_exceptions.append('open(\'/tmp/foo\')')

    # Exceptions should not be raised for the following lines
    function_safe.append('True')
    function_safe.append('False')
    function_safe.append('1 + 1')

# Generated at 2022-06-11 17:20:35.834380
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2', locals={}, include_exceptions=True)[0] == 2
    assert safe_eval('a', locals={'a': 2}, include_exceptions=True)[0] == 2
    assert safe_eval('c', locals={'c': 'b'}, include_exceptions=True)[0] == 'b'
    assert safe_eval('a + b', locals={'a': 1, 'b': 2}, include_exceptions=True)[0] == 3
    assert safe_eval('a + b + c', locals={'a': 1, 'b': 2, 'c': '3'}, include_exceptions=True)[0] == '13'
    assert safe_eval('1 + 2 + 3', locals={}, include_exceptions=True)[0] == 6

# Generated at 2022-06-11 17:20:45.884486
# Unit test for function safe_eval
def test_safe_eval():
    CALL_ENABLED.extend(C.JINJA2_OVERRIDE)
    CALL_ENABLED.extend(C.JINJA2_EXTRA_OVERRIDE)


# Generated at 2022-06-11 17:20:57.638243
# Unit test for function safe_eval
def test_safe_eval():
    # Setup
    import collections
    import datetime
    import doctest
    import json

    class Foo(object):
        def func(self):
            pass

    def dummyfunc():
        pass

    foo_object = Foo()
    foo_object.func()

    # list of tuples with values to test and expected results

# Generated at 2022-06-11 17:21:05.306882
# Unit test for function safe_eval
def test_safe_eval():

    # Test expression contains valid syntax
    good_eval = safe_eval('some_var')
    assert good_eval == 'some_var', good_eval

    # Test expression contains valid syntax with function and list
    good_eval = safe_eval('some_func(some_var)')
    assert good_eval == 'some_func(some_var)', good_eval

    # Test expression contains invalid syntax
    bad_eval = safe_eval('some_func(some_var) + some_func2(some_var)')
    assert bad_eval == 'some_func(some_var) + some_func2(some_var)', bad_eval

    # Test expression contains invalid syntax with a JSON true
    bad_eval = safe_eval('%(some_var)s is true' % dict(some_var=True))
    assert bad

# Generated at 2022-06-11 17:21:14.453362
# Unit test for function safe_eval
def test_safe_eval():
    def test_eval(input_data, output, options=None):
        '''
        Test helper that:
        - Runs safe_eval against the specified input, with the specified options.
        - Validates the output of safe_eval is equivalent to the specified output.
        '''

        if options is None:
            options = {}

        include_exceptions = options.get('include_exceptions', False)

        if include_exceptions:
            (result, exception) = safe_eval(input_data, include_exceptions=True)

            # Verify the exception is valid
            if exception is None:
                if exception is not output[1]:
                    raise AssertionError('Exception mismatch: expected: %s, actual: %s' % (output[1], exception))

# Generated at 2022-06-11 17:21:24.372816
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{ a_variable }}"
    result = safe_eval(expr)
    assert result == expr

    expr = "[1,2,3]"
    result = safe_eval(expr)
    assert result == [1, 2, 3]

    expr = "{{ a_list_variable }}"
    result = safe_eval(expr)
    assert result == expr

    expr = "{'a': 1, 'b': 2}"
    result = safe_eval(expr)
    assert result == {'a': 1, 'b': 2}

    expr = "{{ a_dict_variable }}"
    result = safe_eval(expr)
    assert result == expr

    expr = "{{ a_string }}"
    result = safe_eval(expr)
    assert result == expr


# Generated at 2022-06-11 17:21:56.506759
# Unit test for function safe_eval
def test_safe_eval():
    # testing a bunch of valid statements
    assert None == safe_eval('null')
    assert True == safe_eval('true')
    assert False == safe_eval('false')
    assert 1 == safe_eval('1')
    assert 1.0 == safe_eval('1.0')
    assert 1 == safe_eval('1.0+0')
    assert 1 == safe_eval('2+-1')
    assert 1 == safe_eval('1 + (((2)))')
    assert "abcd" == safe_eval('"abcd"')
    assert "abcd" == safe_eval("'''abcd'''")
    assert ["abcd"] == safe_eval('["abcd"]')
    assert ["abcd", "efgh"] == safe_eval('["abcd", "efgh"]')

# Generated at 2022-06-11 17:22:05.509053
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:16.139363
# Unit test for function safe_eval
def test_safe_eval():
    # This is just a basic test of the safe_eval function, since it
    # is so important to the operation of Ansible we should test
    # it and update it when bugs are found
    expr = dict(
        num_expr = 1,
        str_expr = "string",
        list_expr = [1, 2, 3],
        dict_expr = dict(a=1, b=2, c=3),
    )
    for test in expr:
        e = expr[test]

        # test using safe_eval to evaluate the expression
        evaled = safe_eval(e)
        assert evaled == e
        assert not isinstance(evaled, string_types)

        # Test safe eval with string value
        evaled = safe_eval(str(e))
        assert evaled == e

# Generated at 2022-06-11 17:22:26.610457
# Unit test for function safe_eval
def test_safe_eval():
    # Test with invalid expression
    expr = "{{ invalid_expr }}"
    result, e = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert e is not None
    assert e.message == 'invalid expression ({{ invalid_expr }})'

    # Test with invalid function in expression
    expr = "{{ open('/dev/sda1') }}"
    result, e = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert e is not None
    assert e.message == 'invalid function: open'

    # Test with invalid builtin in expression
    expr = "{{ __builtin__.open('/dev/sda1') }}"
    result, e = safe_eval(expr, include_exceptions=True)
    assert result == expr
   

# Generated at 2022-06-11 17:22:37.320515
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('False') == False
    assert safe_eval('true') == True
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":false, "b":1, "c":true, "d":null}') == {"a":False, "b":1, "c":True, "d":None}
    assert safe_eval('"hello"') == "hello"
    assert safe_eval('1+1') == 2
    assert safe_eval('1-1') == 0
    assert safe_eval('1*1') == 1
    assert safe_eval('1/1') == 1
    assert safe_

# Generated at 2022-06-11 17:22:47.294210
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six.moves import xrange


# Generated at 2022-06-11 17:22:56.769443
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.parsing.dataloader import DataLoader

    #
    # Simple cases
    #
    # eval should pass through simple expressions
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 7, "b": 10}') == {'a': 7, 'b': 10}

    # eval should pass through non-string types
    assert safe_eval(1) == 1

    # eval should ignore strings that look like expressions
    test_str = '{"unlikely": "to be an expression at all"}'
    assert safe_eval(test_str) == test_str

    #
    # Complex cases
    #
    # safe_eval should evaluate a json-like expression

# Generated at 2022-06-11 17:23:03.469243
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ a }}") is None
    assert safe_eval("{{ a | map(attribute='username') }}") is None
    assert safe_eval("{{ a | sum(start=1) }}") is None
    assert safe_eval("{{ a | count }}") == 0
    assert safe_eval("{{ (1, 2, 3) }}") == (1, 2, 3)
    assert safe_eval("{{ [1, 2, 3] }}") == [1, 2, 3]
    assert safe_eval("{{ {'a': 1, 'b': 2} }}") == {"a": 1, "b": 2}
    assert safe_eval("{{ a|bool }}") is False
    assert safe_eval("{{ a is defined }}") is False
    assert safe_eval("{{ not a is defined }}") is True
    assert safe

# Generated at 2022-06-11 17:23:13.901798
# Unit test for function safe_eval
def test_safe_eval():

    # Good expression 1
    assert safe_eval('foo') == 'foo'

    # Good expression 2
    assert safe_eval('foo[0]') == 'foo[0]'

    # Good expression 3
    assert safe_eval('foo == "bar"') == 'foo == "bar"'

    # Good expression 4
    assert safe_eval('foo != "bar"') == 'foo != "bar"'

    # Good expression 5
    assert safe_eval('foo.bar') == 'foo.bar'

    # Good expression 6
    assert safe_eval('foo.bar()') == 'foo.bar()'

    # Good expression 7
    assert safe_eval('foo[bar]') == 'foo[bar]'

    # Bad expression 1

# Generated at 2022-06-11 17:23:23.400902
# Unit test for function safe_eval