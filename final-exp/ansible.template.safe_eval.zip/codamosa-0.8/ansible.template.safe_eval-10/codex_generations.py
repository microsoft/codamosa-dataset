

# Generated at 2022-06-11 17:13:36.494709
# Unit test for function safe_eval
def test_safe_eval():
    facts = dict()
    tests = dict()

    tests['simple_dictionary'] = {
        'expression': '{"foo": "bar"}',
        'expected': {'foo': 'bar'},
        'comment': 'create a simple dictionary'
    }

    tests['simple_list'] = {
        'expression': '[1,2,3,4,5]',
        'expected': [1, 2, 3, 4, 5],
        'comment': 'create a simple list'
    }

    tests['simple_tuple'] = {
        'expression': '(1, 2)',
        'expected': (1, 2),
        'comment': 'create a simple tuple'
    }


# Generated at 2022-06-11 17:13:44.554381
# Unit test for function safe_eval
def test_safe_eval():
    # Test functions and their return value
    eq = 'equal(2+2,4)'
    eq_ans = 4

    ne = 'not equal(2+2,3)'
    ne_ans = True

    gt = 'greater than(5,2)'
    gt_ans = True

    ge = 'greater than or equal to(5,5)'
    ge_ans = 5

    lt = 'less than(2,5)'
    lt_ans = 2

    le = 'less than or equal to(2,2)'
    le_ans = True

    # Test of safe_eval on simple expressions
    assert safe_eval('2+2') == 4
    assert safe_eval('2+2') == 4

    # test of safe_eval on functions - these should raise a SyntaxError
    # because the functions are

# Generated at 2022-06-11 17:13:55.433197
# Unit test for function safe_eval
def test_safe_eval():
    # set constants
    test_eval_result_valid = 1
    test_eval_result_valid_include_exc = (1, None)
    test_eval_result_valid_quoted = 'abc'
    test_eval_result_valid_quoted_include_exc = ('abc', None)
    test_eval_result_valid_dict = {'a': 'b'}
    test_eval_result_valid_dict_include_exc = ({'a': 'b'}, None)
    test_eval_result_valid_list = ['a', 'b', 'c']
    test_eval_result_valid_list_include_exc = (['a', 'b', 'c'], None)
    test_eval_result_invalid = '{{abc}}'

# Generated at 2022-06-11 17:14:06.290908
# Unit test for function safe_eval
def test_safe_eval():
    # test with a valid expression
    expr = '1+1'
    result = safe_eval(expr)
    assert(result == 2)

    # test with a invalid expression
    expr = '__import__("os").remove("/tmp/testfile")'
    result = safe_eval(expr)
    assert(result == expr)

    # test with a simple list expression
    expr = '["foo", "bar"]'
    result = safe_eval(expr)
    assert(result == ["foo", "bar"])

    # test with a simple dict expression
    expr = "{'one': 'foo', 'two': 'bar'}"
    result = safe_eval(expr)
    assert(result == {"one": "foo", "two": "bar"})

    # test with a list expression that contains an invalid element

# Generated at 2022-06-11 17:14:14.610305
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval()
    '''
    if sys.version_info[0:2] != (2, 7):
        # ast.parse() is not implemented in Python 2.6
        return

    # Valid boolean values
    assert(safe_eval('true') == True)
    assert(safe_eval('false') == False)
    assert(safe_eval('null') == None)
    assert(safe_eval('True') == True)
    assert(safe_eval('False') == False)
    assert(safe_eval('NULL') == None)
    assert(safe_eval('True') == True)
    assert(safe_eval('false') == False)
    assert(safe_eval('null') == None)
    assert(safe_eval('true, false') == [True, False])

# Generated at 2022-06-11 17:14:22.921099
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:34.071267
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_MODULE_UTILS != 'ansible.module_utils.basic':
        print('FAILED: ansible_module_utils was not ansible.module_utils.basic, it was %s' % C.DEFAULT_MODULE_UTILS)
        sys.exit(1)

    # These strings should be run through safe_eval and should return
    # the value in the comments, or the 'raises' keyword if it raises
    # an exception. If no exception is raised, the string evaluted
    # should match the type of the type given in the comment.


# Generated at 2022-06-11 17:14:46.156479
# Unit test for function safe_eval
def test_safe_eval():
    # Check if exceptions are included
    expr1 = '2 + 2 == 4'
    assert safe_eval(expr=expr1, include_exceptions=True) == (True, None)
    expr_err = '2 + 2 == fish'
    (result, exception) = safe_eval(expr=expr_err, include_exceptions=True)
    assert result == expr_err
    assert isinstance(exception, Exception)
    assert safe_eval(expr=expr_err, include_exceptions=False) == expr_err

    # check if builtins are not available
    global_exception = 'abs(-12)'
    assert safe_eval(expr=global_exception, include_exceptions=True) == (global_exception, None)
    import_expr = 'any([False, False, False])'
    assert safe_eval

# Generated at 2022-06-11 17:14:55.997867
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test whether safe_eval is preventing invalid expressions
    '''

    # Test with invalid expression
    assert safe_eval('a_list_variable + 1') == 'a_list_variable + 1'
    assert safe_eval('a_list_variable + 1', include_exceptions=True)[0] == 'a_list_variable + 1'

    # Test with valid expression
    assert safe_eval('a_list_variable * 2') == 'a_list_variable * 2'
    assert safe_eval('a_list_variable * 2', include_exceptions=True)[0] == 'a_list_variable * 2'

    # Test with valid expression and dict variables
    dict1 = {'inside': 'a_dict_variable'}
    assert safe_eval('a_dict_variable') == 'a_dict_variable'


# Generated at 2022-06-11 17:15:05.663026
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__

    orig_builtins = __builtin__.__dict__.keys()
    if C.DEFAULT_MODULE_CALLABLE not in orig_builtins:
        orig_builtins.append(C.DEFAULT_MODULE_CALLABLE)

    default_module_callable = 'ansible_module_callable'

    # First set of tests: make sure we don't allow calls to builtin functions
    # NOTE: we assume here that our current environment has not overridden
    # any of the builtins that we allow in the safe evaluator.  The safe
    # evaluator tests in the unit test suite assume the same, so if you change
    # this list, you'll need to update those tests as well.
    allowed

# Generated at 2022-06-11 17:15:18.125779
# Unit test for function safe_eval
def test_safe_eval():

    # check basic jinja expressions
    assert safe_eval('{{ names | join(", ") }}') == '{{ names | join(", ") }}'

    # check some unsafe things
    assert safe_eval('__import__("os").remove("/tmp/foo")') == '__import__("os").remove("/tmp/foo")'

    # make sure we can do some basic math operations
    assert safe_eval('3 + 2') == 5
    assert safe_eval('10 - 3') == 7
    assert safe_eval('3 * 5') == 15
    assert safe_eval('10 / 2') == 5
    assert safe_eval('10 % 3') == 1
    assert safe_eval('10 / 4') == 2.5

    assert safe_eval('-1') == -1
    assert safe_eval('+1') == 1


# Generated at 2022-06-11 17:15:27.858826
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{"somejson": true}'
    print(safe_eval(expr))
    expr = 'True'
    print(safe_eval(expr))
    expr = 'False'
    print(safe_eval(expr))
    expr = 'null'
    print(safe_eval(expr))
    expr = '{"somejson": "somevalue"}'
    print(safe_eval(expr))
    expr = '{"somejson": "somevalue"} + "foo"'
    print(safe_eval(expr))
    expr = '{"somejson": "somevalue"} + {"someotherjson": "someothervalue"}'
    print(safe_eval(expr))
    expr = '1+1'
    print(safe_eval(expr))
    expr = '2+2'
    print(safe_eval(expr))
    expr

# Generated at 2022-06-11 17:15:37.288674
# Unit test for function safe_eval
def test_safe_eval():
    # Arrange
    # --no-print-ansible-deprecation

    # Act
    # Assert
    try:
        safe_eval("a_list_variable")
        print('ok')
    except Exception as e:
        print('not ok', e)

    # Act
    # Assert
    try:
        safe_eval("{ foo: 'bar' }")
        print('ok')
    except Exception as e:
        print('not ok', e)

    # Act
    # Assert
    try:
        safe_eval("[ foo, 'bar' ]")
        print('ok')
    except Exception as e:
        print('not ok', e)

    # Act
    # Assert

# Generated at 2022-06-11 17:15:45.760845
# Unit test for function safe_eval
def test_safe_eval():
    # Test successful execution
    expression = "ansible_architecture == 'x86_64'"
    result = safe_eval(expression, {'ansible_architecture': 'x86_64'})
    assert result is True

    # Test not equal comparison
    expression = "ansible_architecture != 'x86_64'"
    result = safe_eval(expression, {'ansible_architecture': 'i386'})
    assert result is True

    # Test operators
    expression = "(ansible_architecture == 'x86_64') and (ansible_distribution == 'Fedora')"
    result = safe_eval(expression, {'ansible_architecture': 'x86_64', 'ansible_distribution': 'Fedora'})
    assert result is True


# Generated at 2022-06-11 17:15:55.745073
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('1') == 1
    assert safe_eval('0') == 0
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 - 3') == 0
    assert safe_eval('1 + 2 - 3 + 4') == 4
    assert safe_eval('1 + 2 - (3 + 4)') == -4
    assert safe_eval('1 + 2 - (3 + 4)')

# Generated at 2022-06-11 17:16:06.708046
# Unit test for function safe_eval
def test_safe_eval():

    # simple items
    assert safe_eval('10') == 10
    assert safe_eval('"10"') == "10"
    assert safe_eval('"a string"') == "a string"
    assert safe_eval('[10]') == [10]

    # builtin functions
    assert safe_eval('len("ab")', include_exceptions=True)[1] is not None
    assert safe_eval('len("ab")') == 'len("ab")'
    assert safe_eval('"ab" in "abc"') == True
    assert safe_eval('"ad" in "abc"') == False

    # nested items
    assert safe_eval('[10, [20, 30]]') == [10, [20, 30]]

# Generated at 2022-06-11 17:16:17.019769
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for boolean (true, false)
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('False') is False
    assert safe_eval('True') is True

    # Tests for None
    assert safe_eval('null') is None
    assert safe_eval('None') is None

    # Tests for numeric types
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1*3') == 4
    assert safe_eval('2**2') == 4
    assert safe_eval('5-2') == 3

    # Tests for strings
    assert safe_eval("'1'") == '1'
    assert safe_eval("'a'*4") == 'aaaa'

# Generated at 2022-06-11 17:16:24.394079
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic

    def varargs_undefined_handler(funcname, *args, **kwargs):
        try:
            raise Exception("undefined_variable")
        except Exception as e:
            return basic.AnsibleModule.fail_json(msg=to_native(e))


# Generated at 2022-06-11 17:16:34.738054
# Unit test for function safe_eval
def test_safe_eval():
    # assert(safe_eval('{ "one": 1, "two": 2 }') == { "one": 1, "two": 2 })
    # assert(safe_eval('[ "one", "two" ]') == [ "one", "two" ])
    assert(safe_eval('foo') == 'foo')
    assert(safe_eval('foo.bar') == 'foo.bar')
    assert(safe_eval('foo()') == 'foo()')
    assert(safe_eval('foo.bar()') == 'foo.bar()')
    assert(safe_eval('1 + 1') == 2)
    assert(safe_eval('1 + 2 * 5 + 1') == 12)
    assert(safe_eval('1 < 2') is True)
    assert(safe_eval('1 > 2') is False)

# Generated at 2022-06-11 17:16:44.586090
# Unit test for function safe_eval
def test_safe_eval():
    import re
    import pytest
    import six

    expr = "dict(a='{{ foo }}', b='{% if foo == 1 %}{{ bar }}{% endif %}')"
    with pytest.raises(Exception):
        safe_eval(expr)


# Generated at 2022-06-11 17:16:59.842050
# Unit test for function safe_eval
def test_safe_eval():
    ###########################################################################
    # This set of tests is used to test the values before and after being sent
    # through safe_eval().  In this test the value before sending through safe_eval()
    # might not be able to be used in Python which is why the test results were
    # manually checked for accuracy.  The tests were generated using the following
    # Python code:
    #
    #   import random
    #   for i in range(0,100):
    #       print("        values.append({})".format(repr(random.getrandbits(133))))
    ###########################################################################
    values = list()
    values.append('y')
    values.append('0')
    values.append('7g')
    values.append('\u001d')
    values.append(2157)

# Generated at 2022-06-11 17:17:10.568817
# Unit test for function safe_eval
def test_safe_eval():
    '''
    simple test to verify safe_eval is functioning as expected
    '''
    a = {'k':'v'}

    test = 'test'
    assert test == safe_eval(test)

    test = 'test'
    assert test == safe_eval(test, dict(a=a))

    test = 'test'
    assert test == safe_eval(test, dict(a=a))

    test = 'test'
    assert test == safe_eval(test, dict(a=a))

    test = 'a["k"]'
    assert 'v' == safe_eval(test, dict(a=a))
    test = 'a["k"]'
    assert 'v' == safe_eval(test, dict(a=a), True)

    test = 'dict(a=a)'

# Generated at 2022-06-11 17:17:19.629392
# Unit test for function safe_eval
def test_safe_eval():

    # ensure that numeric values work
    assert safe_eval('1 + 1') == 2

    # ensure list syntax works
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

    # ensure string syntax works
    assert safe_eval('"foo" + "bar"') == 'foobar'

    # ensure additional basic operators work
    assert safe_eval('1 - 2') == -1
    assert safe_eval('2 * 5') == 10
    assert safe_eval('10 / 2') == 5

    # ensure unary operators work
    assert safe_eval('3 ** 2') == 9
    assert safe_eval('-3') == -3

    # ensure bool operators work

# Generated at 2022-06-11 17:17:28.325204
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:34.462953
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:43.779433
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval in isolation, outside of Ansible
    '''
    # test to verify that syntax errors or calls to
    # unsafe functions or attributes raise exceptions.
    # we also test to make sure that the expression is
    # correctly evaluated if it is safe.

    def test_expr_invalid(expr):
        try:
            result, err = safe_eval(expr, include_exceptions=True)
            assert result == expr and err is not None, 'expr should be invalid: %s' % expr
        except Exception as e:
            assert e is not None, 'expr should be invalid: %s' % expr

    def test_expr_valid(expr):
        result, err = safe_eval(expr, include_exceptions=True)
        assert err is None, 'expr should be valid: %s' % expr
       

# Generated at 2022-06-11 17:17:53.959633
# Unit test for function safe_eval
def test_safe_eval():
    # invalid expression
    expr = "[1,2,3"
    expected = expr
    result = safe_eval(expr)
    assert result == expected, "%s != %s" % (result, expected)

    # test names
    expr = "false"
    expected = False
    result = safe_eval(expr)
    assert result == expected, "%s != %s" % (result, expected)

    # test numbers
    expr = "1 + 1"
    expected = 2
    result = safe_eval(expr)
    assert result == expected, "%s != %s" % (result, expected)

    # test strings
    expr = "'1'"
    expected = "1"
    result = safe_eval(expr)
    assert result == expected, "%s != %s" % (result, expected)

    # test compares
    expr

# Generated at 2022-06-11 17:18:01.925179
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:08.984370
# Unit test for function safe_eval
def test_safe_eval():

    if sys.version_info < (2, 7):
        # not everything works under Python 2.6 so just test what does
        tests = {
            '[]': [],
            '{}': {},
            'True': True,
            'False': False,
            'None': None,
            '1+1': 2
        }

# Generated at 2022-06-11 17:18:17.725442
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests to ensure that safe_eval keeps evaluating safe code
    assert safe_eval('1 + 1') == 2
    assert safe_eval('True and (1 == 1)')
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('None') is None
    assert safe_eval('1 or 2') == 1
    assert safe_eval('2 and 3') == 3

    # Basic tests to ensure that safe_eval is rejecting unsafe code
    with_items_expression = '["foo", "bar"]'
    assert safe_eval(with_items_expression) == ["foo", "bar"]
    with_items_expression = 'foo'

# Generated at 2022-06-11 17:18:29.852941
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_bytes

    # Make sure Jinja2 cannot create Python code that evaluates to something unsafe

# Generated at 2022-06-11 17:18:38.608337
# Unit test for function safe_eval
def test_safe_eval():
    def test(s, d):
        result, exception = safe_eval(s, locals=d, include_exceptions=True)
        if exception:
            print(u"FAILED: <%s> : %s" % (to_native(s), to_native(exception)))
            sys.exit(1)
        elif result != d[s]:
            print(u"FAILED: <%s> %r != %r" % (to_native(s), result, d[s]))
            sys.exit(1)
        else:
            print(u"PASSED: <%s>" % to_native(s))

    print("Test safe_eval")
    print("=============")

    test('d', dict(d="d"))

# Generated at 2022-06-11 17:18:47.524717
# Unit test for function safe_eval
def test_safe_eval():
    """
    This function tests safe_eval function.

    safe_eval function is found in:
    ansible/lib/ansible/module_utils/facts.py

    This test will test this function with various values to make sure the
    function returns what we expect it to.
    This test script can be ran with --tb=long to debug test failures.

    :return: no return value
    """
    try:
        # test for ansible 2.4 and above
        from ansible.module_utils.facts import Facts
        facts = Facts()
    # test for ansible 2.2 and below
    except ImportError:
        from ansible.module_utils.facts import get_file_content

# Generated at 2022-06-11 17:18:57.646814
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 2") == 3
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("(1,2,3)") == (1, 2, 3)
    assert safe_eval("dict(a=1, b=2)") == dict(a=1, b=2)
    assert safe_eval("1 + 2", include_exceptions=True)[0] == 3
    assert safe_eval("[1,2,3]", include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval("(1,2,3)", include_exceptions=True)[0] == (1, 2, 3)

# Generated at 2022-06-11 17:19:06.950266
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:16.468193
# Unit test for function safe_eval
def test_safe_eval():
    import os
    from ansible.module_utils import basic

    # This is a list of test tuples which should evaluate correctly
    # (expression, expected_value)

# Generated at 2022-06-11 17:19:27.193391
# Unit test for function safe_eval
def test_safe_eval():
    def test_expr(expr, result):
        assert safe_eval(expr) == result

    test_expr("2 + 3", 5)
    test_expr("foo", "foo")
    test_expr("1 + [1]", [1, 1])
    test_expr("{'a': 'b'}", {'a': 'b'})
    test_expr("dict(a='b')", {'a': 'b'})
    test_expr("dict([['a', 'b']])", {'a': 'b'})
    test_expr("zip([1,2], [3,4])", [(1,3), (2,4)])
    test_expr("script", "script")
    test_expr("dict(zip([1,2], [3,4]))", {1: 3, 2: 4})

# Generated at 2022-06-11 17:19:36.739764
# Unit test for function safe_eval
def test_safe_eval():
    def old_eval(expr):
        return eval(expr, {'__builtins__':{}}, {})

# Generated at 2022-06-11 17:19:42.888457
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for safe_eval function
    _test_safe_eval_normal_with_python_functions()
    _test_safe_eval_with_list_variable()
    _test_safe_eval_with_dict_variable()
    _test_safe_eval_with_unsupported_expression()
    _test_safe_eval_with_unsupported_function()
    _test_safe_eval_with_mixed_dict_and_list()
    _test_safe_eval_with_nested_lists()
    _test_safe_eval_with_nested_dicts()
    _test_safe_eval_with_nested_dicts_and_lists()


# Generated at 2022-06-11 17:19:49.899857
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:05.745944
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('(1+1)*2') == 4
    assert safe_eval('(1)') == 1
    assert safe_eval('1+1', locals={'bar': 'baz'}) == 2
    assert safe_eval('(1+1)*foo', locals={'foo': 2}) == 4
    assert safe_eval('foo', locals={'foo': 2}) == 2
   

# Generated at 2022-06-11 17:20:15.461201
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:22.629269
# Unit test for function safe_eval
def test_safe_eval():
    def test_safe_eval_inner(eval_str, expected, return_exceptions=False, exception=None):
        if return_exceptions:
            actual, exc = safe_eval(eval_str, include_exceptions=return_exceptions)
        else:
            actual = safe_eval(eval_str, include_exceptions=return_exceptions)
        if exception:
            assert exc
        assert actual == expected

    # simple test
    test_safe_eval_inner('1 + 1', 2)
    # doens't change original data
    test_safe_eval_inner('[1, 2]', [1, 2])
    test_safe_eval_inner('{"foo": "bar"}', {"foo": "bar"})

# Generated at 2022-06-11 17:20:29.401699
# Unit test for function safe_eval
def test_safe_eval():
    ''' Unit test for safe_eval '''
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class SafeEvalTestCase(unittest.TestCase):
        def setUp(self):
            '''
            This is going to get run on every test.
            '''
            self.disable_safe_eval = False
            self.enable_call = False

            if self.disable_safe_eval:
                self.safeeval = eval
            else:
                # wrap safe_eval in a function to set the call_enabled list
                def safeeval(expr, locals=None, include_exceptions=False):
                    if self.enable_call:
                        CALL_ENABLED.append(expr)

# Generated at 2022-06-11 17:20:38.552266
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:46.084460
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"foo": 1, "bar": false}') == {"foo": 1, "bar": False}
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]

    data = {'foo': ['bar', 'baz'], 'blip': dict(q='p', w=9)}
    assert safe_eval('foo') == data['foo']
    assert safe_eval('blip') == data['blip']

    assert safe_eval('foo[1]') == data['foo'][1]
    assert safe_eval('blip.q') == data['blip']['q']
    assert safe_eval('blip[q]') == data['blip']['q']

# Generated at 2022-06-11 17:20:57.832280
# Unit test for function safe_eval
def test_safe_eval():

    def assert_safe_eval(expr, exp_result=None, locals=None):
        result, exception = safe_eval(expr, locals, include_exceptions=True)
        if exp_result:
            if callable(exp_result):
                try:
                    assert exp_result(result)
                except AssertionError as e:
                    raise AssertionError("%s != %s" % (result, exp_result.__name__))
            else:
                assert result == exp_result, "%s != %s" % (to_native(result), to_native(exp_result))
        if exception:
            raise AssertionError("Exception raised: %s" % to_native(exception))

    assert_safe_eval("1 + 2 + 3", 6)

# Generated at 2022-06-11 17:21:05.394131
# Unit test for function safe_eval
def test_safe_eval():
    class Test(Exception):
        pass

    # Test basic functionality
    assert safe_eval('1 + 1', dict()) == 2
    assert safe_eval('2 - 1', dict()) == 1
    assert safe_eval('2 * 3', dict()) == 6
    assert safe_eval('6 / 2', dict()) == 3
    assert safe_eval('"1" + "1"', dict()) == "11"
    assert safe_eval('"2" - "1"', dict()) == "1"
    assert safe_eval('"2" * 3', dict()) == "222"
    assert safe_eval('"6" / "2"', dict()) == "3"
    assert safe_eval('6 // 2', dict()) == 3
    assert safe_eval('6 % 2', dict()) == 0

# Generated at 2022-06-11 17:21:14.547932
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval with simple expressions
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar.baz") == "foo.bar.baz"
    assert safe_eval("foo.bar.baz.bat") == "foo.bar.baz.bat"

    # Test safe_eval with numbers
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 - 1") == 1
    assert safe_eval("2 * 10") == 20
    assert safe_eval("5 / 2") == 2.5
    assert safe_eval("11.76 / 2") == 5.88
    assert safe_eval("11 / 2") == 5.5
    assert safe_eval("11 // 2") == 5
   

# Generated at 2022-06-11 17:21:24.414149
# Unit test for function safe_eval
def test_safe_eval():
    success = True

    for expr, expected in (
            ('1 + 2', 3),
            ('-2', -2),
            ('[1, 2, 3]', [1, 2, 3]),
            ('{"a": 1, "b": 2}', {"a": 1, "b": 2}),
            ('true', True),
            ('false', False),
            ('null', None)):

        result = safe_eval(expr)
        if isinstance(expected, type):
            success = success and (isinstance(result, expected))
        else:
            success = success and (result == expected)


# Generated at 2022-06-11 17:21:48.805626
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:56.454517
# Unit test for function safe_eval
def test_safe_eval():

    if False:
        # This is used to determine which builtin functions are callable
        # in the safe_eval function.
        safe_funcs = {}
        for i in dir(__builtins__):
            try:
                safe_eval('%s()' % i)
                safe_funcs[i] = 'safe'
            except Exception:
                safe_funcs[i] = 'unsafe'

        print(safe_funcs)

    # Tests of safe_eval

# Generated at 2022-06-11 17:22:05.453310
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    from ansible.template import Templar

    class TestModule(object):
        def __init__(self, verbosity):
            self.verbosity = verbosity

    # expression which should evaluate to True
    assert safe_eval(True) is True
    assert safe_eval(1) == 1
    assert safe_eval('true') is True
    assert safe_eval('1') == 1
    assert safe_eval('TRUE') is True
    assert safe_eval('1') == 1
    assert safe_eval('foo') == 'foo'
    assert safe_eval('{foo:1,bar:2}') == {'foo':1, 'bar':2}
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('foo.bar') == 'foo.bar'

# Generated at 2022-06-11 17:22:16.110254
# Unit test for function safe_eval
def test_safe_eval():

    def test_check(expression, should_pass):
        """
        Test an expression with safe_eval and check if the expression is parsed as expected.
        Parameter 'expression' is passed to safe_eval.
        Parameter 'should_pass' controls if an exception is expected or not.
        """
        result, exception = safe_eval(expression, include_exceptions=True)
        if should_pass:
            if exception is not None:
                raise Exception('Exception "%s" was raised when evaluating expression "%s"' % (exception, expression))
        else:
            if exception is None:
                raise Exception('No exception was raised when evaluating expression "%s"' % expression)

    # Basic number tests
    test_check('1', True)
    test_check('-1', True)
    test_check('1 * 3', True)
    test_

# Generated at 2022-06-11 17:22:26.573966
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:37.286586
# Unit test for function safe_eval
def test_safe_eval():
    # Test good expression
    expr = '1+1'
    result, exc = safe_eval(expr, include_exceptions=True)
    assert result == 2
    assert exc is None
    result = safe_eval(expr)
    assert result == 2

    # Test bad expression
    expr = '1+'
    result, exc = safe_eval(expr, include_exceptions=True)
    assert result == '1+'
    assert exc is not None
    result = safe_eval(expr)
    assert result == '1+'

    # Test with_items syntax
    expr = u'range(10)'
    result, exc = safe_eval(expr, include_exceptions=True)
    expr = u'[1,2,3,4]'

# Generated at 2022-06-11 17:22:47.293591
# Unit test for function safe_eval
def test_safe_eval():
    """AnsibleModule unit test for module ansible.module_utils.common.text.eval.safe_eval()
    """
    _s = {}
    _s['_ansible_verbosity'] = 0
    _s['_ansible_version'] = C.__version__
    _s['_ansible_module_name'] = 'ansible.module_utils.common.text.safe_eval.safe_eval'
    _s['_ansible_no_log'] = False
    _s['_ansible_debug'] = True
    _s['_ansible_diff'] = False
    _s['_ansible_check_mode'] = False
    _s['_ansible_remote_tmp'] = None
    _s['_ansible_keep_remote_files'] = False

# Generated at 2022-06-11 17:22:56.769156
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("20 + 30") == 50
    assert safe_eval("20 / 30") == 0.6666666666666666

    # Exercise the branch which handles strings, possibly containing Jinja2
    assert safe_eval("this is a str") == "this is a str"

    # Test dict
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}

    # Test list
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']

    # Test tuple, (foo)
    assert safe_eval("('foo',)") == ('foo',)

    # Test tuple, (foo, bar)
    assert safe_eval("('foo', 'bar')") == ('foo', 'bar')

    # Test nested list

# Generated at 2022-06-11 17:23:03.469575
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval function
    assert safe_eval('2 + 3') == 5
    assert safe_eval('[1,3,3]') == [1,3,3]
    assert safe_eval('{"a":3, "b":4}') == {"a":3,"b":4}
    assert safe_eval('"test_string"') == "test_string"
    assert safe_eval('test_string', {}, True) == ("test_string", None)
    assert safe_eval('test_string') == "test_string"
    assert safe_eval('2 + 3', {}, True) == (5, None)
    assert safe_eval('2 + 3', {'a':3}, True) == (5, None)

# Generated at 2022-06-11 17:23:13.901364
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('4 + 4') == 8
    assert safe_eval('4 + 4', include_exceptions=True) == (8, None)

    assert safe_eval('4 + 4 + "fake"') == '4 + 4 + "fake"'
    assert safe_eval('4 + 4 + "fake"', include_exceptions=True) == ('4 + 4 + "fake"', None)

    assert safe_eval('4 + 4 + foo', {'foo': 'fake'}) == '4 + 4 + fake'
    assert safe_eval('4 + 4 + foo', {'foo': 'fake'}, include_exceptions=True) == ('4 + 4 + fake', None)

    assert safe_eval('foo', {'foo': eval}) == "Name('foo', Load()) is not allowed"