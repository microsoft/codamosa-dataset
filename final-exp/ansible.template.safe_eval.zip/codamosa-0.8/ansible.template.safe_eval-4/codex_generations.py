

# Generated at 2022-06-11 17:13:34.412614
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('-1') == -1
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('{"a": 1}') == {'a': 1}
    assert safe_eval('""') == ''
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" * 3') == 'foofoofoo'
    assert safe_eval('1+2', include_exceptions=True)[0] == 3
    assert safe_eval('{}', include_exceptions=True)[0] == {}
    # assert safe_eval('foo

# Generated at 2022-06-11 17:13:43.112472
# Unit test for function safe_eval
def test_safe_eval():
    import nose

    # test this function with our own function to test 'call'
    def square_me(a):
        return a * a

    test_vars = {'square_me': square_me, 'a': 5}

    # basic test for which we expect success
    res, err = safe_eval(expr="square_me(a)", locals=test_vars, include_exceptions=True)
    nose.tools.ok_(err is None, "Evaluation should have succeeded.")
    nose.tools.assert_equal(res, 25, "Evaluation should have succeeded.")

    # try to call a function that's not in the dictionary
    res, err = safe_eval(expr="square_me(b)", locals=test_vars, include_exceptions=True)

# Generated at 2022-06-11 17:13:54.330749
# Unit test for function safe_eval
def test_safe_eval():
    test_expr = "5 * 5"
    test_expr_int = 5 * 5
    test_expr2 = "foo_var"
    test_expr2_int = "foo_var"
    test_expr3 = "d[k]"
    test_expr3_int = "d[k]"
    test_expr4 = [1, 2, 3]
    test_expr4_int = [1, 2, 3]
    test_expr5 = "foo()"
    test_expr5_str = "foo()"
    test_dict = {"k": "v"}
    test_list = ["k", "v"]
    test_list_str = str(test_list)
    foo_var = "foo_var"
    foo_var_int = "foo_var"


# Generated at 2022-06-11 17:14:05.743205
# Unit test for function safe_eval
def test_safe_eval():
    ''' test cases for safe_eval '''
    # a whitelisted expression
    result, exception = safe_eval('1+1', include_exceptions=True)
    if exception is not None:
        print("test_safe_eval failed: %s" % exception, file=sys.stderr)
        sys.exit(1)
    if result != 2:
        print("test_safe_eval failed", file=sys.stderr)
        sys.exit(1)

    # an invalid expression
    result, exception = safe_eval('__import__("os").system("rm -rf")', include_exceptions=True)
    if exception is None:
        print("test_safe_eval failed", file=sys.stderr)
        sys.exit(1)

# Generated at 2022-06-11 17:14:14.395592
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    # pylint: disable=unused-variable,too-many-nested-blocks
    #
    # The following test conditions are being verified:
    # 1) an expression that evaluates to a bool (False)
    # 2) an expression that evaluates to a bool (True)
    # 3) an expression that evaluates to a string
    # 4) an expression that evaluates to a list
    # 5) an expression that evaluates to a dict
    # 6) an expression that evaluates to a number
    # 7) a compound expression
    # 8) a nested compound expression
    # 9) an invalid expression (name error)
    # 10) a call to an invalid function (raise exception)
    # 11) a call to a valid function
    # 12) a call to a valid function with arguments


# Generated at 2022-06-11 17:14:22.966383
# Unit test for function safe_eval
def test_safe_eval():
    # test ok str
    expr = '4 * 6'
    v = safe_eval(expr)
    assert v == 24

    # test ok literal
    expr = 24
    v = safe_eval(expr)
    assert v == 24

    # test fail str
    expr = 'a = 4 * 6'
    v = safe_eval(expr)
    assert v == expr

    # test fail str
    expr = '__import__("os").listdir(".")'
    v = safe_eval(expr)
    assert v == expr

    # test fail literal

# Generated at 2022-06-11 17:14:30.573704
# Unit test for function safe_eval
def test_safe_eval():
    try:
        # 1. test when syntax error occurs in the code
        safe_eval('abc}')
    except Exception as e:
        if not isinstance(e, SyntaxError):
            raise

    # 2. test when syntax is correct but not allowed node type exists
    try:
        safe_eval('[x**3 for x in range(10)]')
    except Exception as e:
        if not isinstance(e, SyntaxError):
            raise

    # 3. test when disallowed function call exists
    try:
        safe_eval('[str(x) for x in range(10)]')
    except Exception as e:
        if not isinstance(e, SyntaxError):
            raise

    # 4. test when allowed function call exists
    safe_eval('[range(3) for _ in range(10)]')

   

# Generated at 2022-06-11 17:14:37.851276
# Unit test for function safe_eval
def test_safe_eval():
    # The idea of this test is to provide numerous examples of valid and invalid
    # expressions and make sure the safe_eval correctly identifies which are valid
    # and which are not.  It is a good idea to check both exception-raising and
    # non-exception-raising modes
    params = dict(
        a_string='test',
        a_list=['a',2,3],
        a_dict={'a': 'b'}
    )

# Generated at 2022-06-11 17:14:48.276812
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:56.845990
# Unit test for function safe_eval
def test_safe_eval():
    def t(s, r):
        assert safe_eval(s) == r
    t('1 + 2 * 3', 7)
    t('1 + 2 * 3 ** 2', 19)
    t('(1 + 2) * 3 ** 2', 45)
    t('true', True)
    t('false', False)
    t('null', None)
    t('True', True)
    t('False', False)
    t('None', None)
    t('[1, 2]', [1, 2])
    t('(1, 2)', (1, 2))
    t('{"a": 1, "b": "foo"}', {'a': 1, 'b': 'foo'})
    t('null if true else false', None)
    t('null if false else true', True)

# Generated at 2022-06-11 17:15:07.760964
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1,"b":2}') == {'a': 1, 'b': 2}
    assert safe_eval('"abc"') == "abc"
    assert safe_eval('1+2') == 3
    assert safe_eval('1+1') == 2
    assert safe_eval('0+7') == 7
    assert safe_eval('1+1-1') == 1
    assert safe_eval('2*3') == 6
    assert safe_eval('7/3') == 2
    assert safe_eval('2**3') == 8
    assert safe_eval('-3') == -3

# Generated at 2022-06-11 17:15:17.328831
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:27.356323
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the safe_eval function
    '''
    # Python evaluates the following to 10.
    # If there is no exception raised, the test has passed
    assert safe_eval('1 + 2 + 3 + 4') == 10

    # assert is used with safe_eval to check for an exception
    # TODO: this test is not portable across Python 2 and 3,
    #       because the exception raised is different, and the
    #       exception text is localized and has a different
    #       exact content across supported languages.
    # assert safe_eval('1 +')                  # Raises SyntaxError : invalid syntax
    # assert safe_eval('__import__("os").')    # Raises Exception: invalid expression (__import__("os").)
    # assert safe_eval('foo("bar")')           # Raises Exception: invalid expression (foo("

# Generated at 2022-06-11 17:15:36.955050
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval(5) == 5
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "abc": "xyz"}') == {'foo': 'bar', 'abc': 'xyz'}
    assert safe_eval('{"foo": {"bar": "baz"}}') == {'foo': {'bar': 'baz'}}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'

# Generated at 2022-06-11 17:15:45.656585
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}
    assert safe_eval('3 + 4 * 10') == 43
    assert safe_eval('[1,2,3,4]') == [1,2,3,4]
    assert safe_eval('-1234') == -1234
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # invalid expressions
    assert safe_eval('3 + 4 * 10 ** 2') == '3 + 4 * 10 ** 2'
    assert safe_eval('[1,2,3,4] + [4, 5, 6]') == '[1,2,3,4] + [4, 5, 6]'

# Generated at 2022-06-11 17:15:55.729650
# Unit test for function safe_eval
def test_safe_eval():
    ''' safe_eval() unit tests '''

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Check simple dicts
    assert safe_eval('{ "foo" : "bar", "bar" : "something" }') == { "foo" : "bar", "bar" : "something" }
    # Check simple lists
    assert safe_eval('["foo", "bar", "something"]') == ["foo", "bar", "something"]
    # Check simple string
    assert safe_eval('foo') == 'foo'
    # Check simple number
    assert safe_eval(123) == 123
    # Check simple expression
    assert safe_eval('1 + 1') == 2
    # Check simple expression

# Generated at 2022-06-11 17:16:06.676968
# Unit test for function safe_eval
def test_safe_eval():
    # from ansible code base
    # FIXME: rewrite this test once when the new return value is available
    # (with include_exceptions=True)
    assert C.DEFAULT_KEEP_REMOTE_FILES == safe_eval(C.DEFAULT_KEEP_REMOTE_FILES)

    # the following expressions are just hardcoded
    # examples copied verbatim from the documentation
    assert 1 == safe_eval("1")
    assert -2 == safe_eval("-2")
    assert 3 == safe_eval("1 + 2")
    assert 6 == safe_eval("(1 + 2) * 2")
    assert 2.5 == safe_eval("5 / 2")
    assert 1.5 == safe_eval("5 // 2")
    assert 5 == safe_eval("5 % 2")

# Generated at 2022-06-11 17:16:16.966122
# Unit test for function safe_eval
def test_safe_eval():
  assert safe_eval('1') == 1
  assert safe_eval('1 + 1') == 2
  assert safe_eval('1.1 + 1') == 2.1
  assert safe_eval('a', {'a': 1}) == 1
  assert safe_eval('a', {'a': 1.1}) == 1.1
  assert safe_eval('a[1]', {'a': [0, 1, 2]}) == 1
  assert safe_eval('a', {'a': {'a': 0}}) == {'a': 0}
  assert safe_eval('a', {'a': False}) == False
  assert safe_eval('a', {'a': True}) == True
  assert safe_eval('a', {'a': None}) == None

# Generated at 2022-06-11 17:16:24.384435
# Unit test for function safe_eval
def test_safe_eval():

    # just to be sure there's nothing broken in ast.parse
    with open(__file__, 'r') as f:
        tree = ast.parse(f.read())

    # with_items: a_list_variable, missing the double quotes
    # it actually makes the test fail if the double quotes are here
    # and the function safe_eval is broken
    expr = "{{a_list_variable}}"
    expr_ok = "[u'item1', u'item2', u'item3']"
    (result, dummy) = safe_eval(expr, dict(a_list_variable=expr_ok), True)
    assert(result == expr_ok)

    # with_items: a_string_variable
    # with_items: 1
    expr = "{{a_string_variable}}"

# Generated at 2022-06-11 17:16:34.739556
# Unit test for function safe_eval
def test_safe_eval():
    # This is safe because it only contains names and literals
    safe_expr = "foo and bar and ['simple', 'list'] or {'simple': 'dict'}"
    safe_expr2 = "foo and bar and [1==1]"

    # The 'import os' part is unsafe because it can import a malicious module
    unsafe_expr = "foo and bar and [1==1] or import os"

    # The '__import__' function is unsafe because it can import a malicious module
    unsafe_expr2 = "__import__('os').listdir('.')"

    # The 'open' function is unsafe because it can open a file for read or
    # write.
    unsafe_expr3 = "open('foo.txt','a')"

    assert safe_eval(safe_expr) is not None
    assert safe_eval(safe_expr2)

# Generated at 2022-06-11 17:16:49.602489
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run unit tests for function safe_eval
    '''
    def _run_test_case(test_case):
        '''
        Run the test case and return the error if the test case fails.
        '''
        try:
            result, error = safe_eval(
                test_case['data'],
                include_exceptions=True
            )
        except Exception as e:
            result = None
            error = e

        if result != test_case['expected_result']:
            err_msg = 'Failed test: input: %s output: %s expected: %s' % (
                test_case['data'],
                result,
                test_case['expected_result']
            )

# Generated at 2022-06-11 17:16:59.388797
# Unit test for function safe_eval
def test_safe_eval():
    def assert_eval(expression, expected_value, locals=None):
        value, e = safe_eval(expression, locals, include_exceptions=True)
        assert value == expected_value
        assert e is None
    assert_eval('a', 'a')
    assert_eval('a + b', 'a + b')
    assert_eval('a + b', 'a + b', dict(a=1))
    assert_eval('1', 1)
    assert_eval('1', 1, dict(a=1))
    assert_eval('1 + 1', 2)
    assert_eval('1 + 1', 2, dict(a=1))
    assert_eval('a', 'a', dict(a=1))
    assert_eval('a', 'a', dict(a='a'))

# Generated at 2022-06-11 17:17:10.333665
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple cases
    assert safe_eval("[1,2]") == [1,2]
    assert safe_eval("{'a':'b'}") == {'a':'b'}
    assert safe_eval("false") is False
    assert safe_eval("true") is True
    assert safe_eval("(1,2)") == (1,2)

    # Parenthesized expression should be treated as the most nested child
    assert safe_eval("((1,2),3)") == ((1,2),3)

    # Invalid strings should be treated as-is
    assert safe_eval("(1,2) *") == "(1,2) *"

    # Strings containing colons should be treated as-is
    assert safe_eval("foo:bar") == "foo:bar"

    # Should return string if

# Generated at 2022-06-11 17:17:18.990851
# Unit test for function safe_eval
def test_safe_eval():
    success = []
    failure = []

    def report_results(title, log, expect_fail=False):
        print("**** %s ****" % title)
        for (count, (value, result)) in enumerate(log):
            print("[%s] %s => %s" % (count + 1, repr(value), repr(result)))
        if expect_fail:
            num_success = len(filter(lambda x: x[0] == x[1], log))
            success.append((title, num_success))
            print("%s of %s tests passed" % (num_success, len(log)))
        else:
            num_fail = len(filter(lambda x: x[0] != x[1], log))
            failure.append((title, num_fail))

# Generated at 2022-06-11 17:17:27.947012
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 + 3') == 5
    assert safe_eval('a_list_variable') is None
    assert safe_eval('a_list_variable', dict(a_list_variable=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval('a_list_variable + [4]', dict(a_list_variable=[1, 2, 3])) == [1, 2, 3, 4]
    assert safe_eval('a_list_variable + a_list_variable', dict(a_list_variable=[1, 2, 3])) == [1, 2, 3, 1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)


# Generated at 2022-06-11 17:17:37.578845
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1.0 + 1.0") == 2.0
    assert safe_eval("1 + 1.0") == 2.0
    assert safe_eval("'hello ' + 'world'") == "hello world"
    assert safe_eval("'hello' in 'hello world'") is True
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 == 2") is False
    assert safe_eval("'quux' in ['foo', 'bar', 'baz']") is False

# Generated at 2022-06-11 17:17:43.632711
# Unit test for function safe_eval
def test_safe_eval():
    # test a safe expression
    test_result = safe_eval("[1,2,3] if (True is True) else False")
    assert test_result == [1,2,3]
    # test a non-safe expression
    test_result = safe_eval("[1,2,3] if (__import__('os').system('echo hi')) else False")
    assert test_result == "[1,2,3] if (__import__('os').system('echo hi')) else False"


# Generated at 2022-06-11 17:17:52.164436
# Unit test for function safe_eval
def test_safe_eval():
    evaluation = safe_eval
    assert evaluation('') == ''
    assert evaluation('1') == 1
    assert 'evaluation - SyntaxError' not in evaluation('a')
    assert 'evaluation - SyntaxError' not in evaluation('{"foo": "bar"}')
    assert evaluation('[1,2,3]') == [1,2,3]
    assert evaluation('{"foo":"bar"}') == {"foo":"bar"}

    # test safe_eval with invalid/unsafe code
    code = "{'foo':%s}" % "__import__('os').system('echo oh no!')"
    assert evaluation(code, include_exceptions=True) == (code, None)
    assert evaluation(code) == code

# Generated at 2022-06-11 17:17:59.996012
# Unit test for function safe_eval
def test_safe_eval():
    '''Test function for safe_eval'''
    def test_fail(s):
        assert not safe_eval(s)

    def test_pass(s, r):
        assert safe_eval(s) == r

    def test_ret(s, r):
        e = safe_eval(s, include_exceptions=True)
        assert e[0] == r, e[1]

    test_ret('None', None)
    test_ret('true', True)
    test_ret('false', False)
    test_ret('foo', 'foo')
    test_ret('9876543210', 9876543210)
    test_ret('[ "foo", "bar", "baz" ]', ["foo", "bar", "baz"])

    # test_ret('x + y + z', )
    test

# Generated at 2022-06-11 17:18:07.737512
# Unit test for function safe_eval
def test_safe_eval():

    # Basic eval, should return True
    test1 = safe_eval("True")
    assert test1 is True
    test1 = safe_eval("true")
    assert test1 is True

    # Eval a boolean expression with Jinja2
    test2 = safe_eval("{{ True or False }}")
    assert test2 is True

    # Eval a boolean expression with Jinja2
    test3 = safe_eval("{{ True or False }}")
    assert test3 is True

    # Eval a boolean expression with Jinja2
    test4 = safe_eval("{{ True and False }}")
    assert test4 is False

    # Eval a boolean expression with parentheses
    test5 = safe_eval("True and (False or True)")
    assert test5 is True

    # Eval a boolean expression with parentheses

# Generated at 2022-06-11 17:18:23.908314
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('None') == None
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('1+2') == 3
    assert safe_eval('1+2', locals=dict(a=1, b=2)) == 3
    assert safe_eval('1+2 if (False) else 2+3') == 5
    assert safe_eval('a', locals=dict(a=1, b=2)) == 1
    assert safe_eval('a', locals=dict(a=[1, 2], b=2)) == [1, 2]
    assert safe_eval('a', locals=dict(a=None, b=2)) == None

# Generated at 2022-06-11 17:18:29.899887
# Unit test for function safe_eval
def test_safe_eval():

    # enable all builtins we need and allow calls to them.
    # see: https://docs.python.org/2/library/functions.html
    safe_eval("foo", locals={"foo": "bar"})
    safe_eval("'foo'.capitalize()", locals={"foo": "bar"})
    safe_eval("' foo '.lstrip()", locals={"foo": "bar"})
    safe_eval("'foo'.rstrip('')", locals={"foo": "bar"})
    safe_eval("'foo'.strip()", locals={"foo": "bar"})
    safe_eval("'foo'.ljust(5)", locals={"foo": "bar"})
    safe_eval("'foo'.rjust(5)", locals={"foo": "bar"})

# Generated at 2022-06-11 17:18:38.636630
# Unit test for function safe_eval
def test_safe_eval():
    # test all literal data types in the code above
    # to ensure they are evaluated properly
    safe_eval("true")
    safe_eval("false")
    safe_eval("null")
    safe_eval("1")
    safe_eval("1.1")
    safe_eval("'one'")
    safe_eval("'a string with a single quote (\')'")
    safe_eval('"a string with a double quote (\")"')
    safe_eval('["a", "list"]')
    safe_eval('["a", "list", ["of", ["nested"]]]')
    safe_eval('{"a": "dict"}')
    safe_eval('{"a": "dict", "with": {"nested": "dicts"}}')

# Generated at 2022-06-11 17:18:48.240045
# Unit test for function safe_eval
def test_safe_eval():

    class Test(object):
        pass

    # error syntax
    assert safe_eval("a(") is False
    assert type(safe_eval("a(", include_exceptions=True)) == tuple
    assert type(safe_eval("a(", include_exceptions=True)[1]) == SyntaxError

    # try to overflow the stack
    assert safe_eval("[1,2,3][3]") is False

    # we should not be able to import a module
    assert safe_eval("from x import y") is False

    # we should not be able to execute code
    assert safe_eval("__import__('sys').exit()") is False

    # we should not be able to access a function from the function locals()
    def x():
        return 1
    assert safe_eval("x()", {"x": x}) is False

   

# Generated at 2022-06-11 17:18:58.193431
# Unit test for function safe_eval
def test_safe_eval():
    # Here, we test safe_eval with a whitelist of AST nodes
    MY_GLOBALS = {}
    MY_LOCALS = {'foo': 42}

# Generated at 2022-06-11 17:19:07.518597
# Unit test for function safe_eval
def test_safe_eval():
    strict = False
    expr = 'foo'
    result = safe_eval(expr, dict(foo='bar'))
    assert result == 'bar'
    expr = 'foo == "bar"'
    result = safe_eval(expr, dict(foo='bar'))
    assert result is True
    if strict:
        return
    expr = 'foo.lower()'
    try:
        result = safe_eval(expr, dict(foo='bar'))
        raise Exception("should have raised an exception")
    except Exception as e:
        assert "invalid expression" in str(e)
    expr = 'foo.split(".")'
    result = safe_eval(expr, dict(foo='test.test'))
    assert len(result) == 2 and result[0] == 'test' and result[1] == 'test'
    expr

# Generated at 2022-06-11 17:19:17.031345
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:27.724981
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("[1,2,3,4]", {}, include_exceptions=True) == ([1, 2, 3, 4], None)
    assert safe_eval("[1,2,3,4]") == [1, 2, 3, 4]

    try:
        safe_eval("[1,2,3,4}", {}, include_exceptions=True) == ("[1,2,3,4}", "invalid expression")
        assert False
    except Exception as e:
        assert e.message == "invalid expression ([1,2,3,4})"

    assert safe_eval("{ 'a': 1, 'b': 2}", {}, include_exceptions=True) == ({"a": 1, "b": 2}, None)

# Generated at 2022-06-11 17:19:37.605490
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # Test that safe_eval raises an exception when given an expression which
    # is not safe.
    with pytest.raises(Exception) as excinfo:
        safe_eval("__import__('os').system('/bin/true')")
    assert 'invalid function: __import__' in str(excinfo)

    # Test that safe_eval returns the expected result when the expression is
    # safe and simple.
    assert safe_eval("1 + 2") == 3
    assert safe_eval("'a' + 'b'") == 'ab'
    assert safe_eval("1 == 2") is False

    # Test that safe_eval returns the expected result when the expression
    # contains an identifier.
    x = 1
    assert safe_eval("x + 2", locals={'x' : 1}) == 3


# Generated at 2022-06-11 17:19:47.059264
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3,4]') == [1,2,3,4]
    assert safe_eval('{}') == {}
    assert safe_eval('{"a":1,"b":2,"c":3,"d":4}') == {"a":1,"b":2,"c":3,"d":4}
    assert safe_eval('()') == ()
    assert safe_eval('(1,2,3,4)') == (1,2,3,4)
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('null') == None


# Generated at 2022-06-11 17:20:05.875441
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval with good, bad and edge cases

    Also test that the following builtin functions are disabled:
    - compile
    '''
    # NOTE: these tests have been disabled because they should be moved to the
    #       test/integration/targets/script directory
    #       see: https://github.com/ansible/ansible/pull/44364
    #       DO NOT re-enable them here
    #
    #assert safe_eval("2 + 3") == 5
    #assert safe_eval("'2' + '3'") == '23'
    #assert safe_eval("['a'] + ['b']") == ['a', 'b']
    #with pytest.raises(Exception) as e:
    #    safe_eval("__import__('os').system('id')")
    #

# Generated at 2022-06-11 17:20:15.591478
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:22.729181
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval in various scenarios

    # Test simple expressions
    expr = "1 + 2"
    assert safe_eval(expr) == 3

    expr = "1 - 2"
    assert safe_eval(expr) == -1

    expr = "2 * 3"
    assert safe_eval(expr) == 6

    expr = "10 / 2"
    assert safe_eval(expr) == 5

    # Test precedence
    expr = "1 + 2 * 3"
    assert safe_eval(expr) == 7

    expr = "(1 + 2) * 3"
    assert safe_eval(expr) == 9

    # Make sure we can handle booleans and None as well
    expr = "'foo' is defined and 'foo' == 'bar'"
    assert safe_eval(expr, {'foo': 'bar'}) is True

   

# Generated at 2022-06-11 17:20:29.481153
# Unit test for function safe_eval
def test_safe_eval():
    # test with Jinja2 template string
    e = '{{ 6 + 6 }}'
    assert safe_eval(e) == 12

    # test with Jinja2 template list
    e = ['1', '2', '{{ 6 + 6 }}', '4', '5']
    assert safe_eval(e) == ['1', '2', 12, '4', '5']

    # test with Jinja2 template dictionary
    e = {'a': '1', 'b': '2', 'c': '{{ 6 + 6 }}', 'd': '4', 'e': '5'}
    assert safe_eval(e) == {'a': '1', 'b': '2', 'c': 12, 'd': '4', 'e': '5'}

    # test with a list

# Generated at 2022-06-11 17:20:38.595140
# Unit test for function safe_eval
def test_safe_eval():

    # Test the evaluation of an empty expression
    result, exception = safe_eval("", include_exceptions=True)
    assert result == ""
    assert exception is None

    # Test the correct evaluation of a valid expression
    result, exception = safe_eval("True or False", include_exceptions=True)
    assert result is True
    assert exception is None

    result, exception = safe_eval("5*5", include_exceptions=True)
    assert result == 25
    assert exception is None

    # Test the incorrect evaluation of an invalid expression
    result, exception = safe_eval("1+2+", include_exceptions=True)
    assert exception.__class__.__name__ == 'SyntaxError'

    result, exception = safe_eval("3**3**3", include_exceptions=True)

# Generated at 2022-06-11 17:20:46.146393
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:57.898924
# Unit test for function safe_eval
def test_safe_eval():
    ''' make sure our safe eval implementation is behaving correctly '''
    # these are valid expressions that are allowed and would have been
    # caught by the original exception, but now must not raise any
    # errors

    assert safe_eval('True')
    assert safe_eval('True and False')
    assert safe_eval('True and False or True')
    assert safe_eval('True and False or False')
    assert safe_eval('True or False')
    assert not safe_eval('False or False')
    assert not safe_eval('False and False')
    assert safe_eval('False and False or True')
    assert safe_eval('False or True')
    assert safe_eval('False or True or False')
    assert safe_eval('False or False or False')
    assert not safe_eval('False and False and False')

# Generated at 2022-06-11 17:21:05.432752
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test that it rejects code containing various kinds of things
    '''
    known_good = [
        '3',
        '{foo: "bar"}',
        '"bar"',
        'foo',
        '[]',
        '[1]',
        'a'
    ]

    known_bad = [
        '{"foo": "bar"}',
        '3.0',
        'bar',
        '[]()',
        '[1]()',
        "a['foo']",
        "a.foo",
        '{}.foo',
        'a()'
    ]

    for k in known_good:
        assert safe_eval(k) is not None


# Generated at 2022-06-11 17:21:14.574540
# Unit test for function safe_eval
def test_safe_eval():

    # test a simple eval
    assert safe_eval('1 + 1') == 2

    # test a simple eval with a variable
    test = 42
    assert safe_eval('1 + test', locals={'test': 42}) == 43

    # test a simple eval with a variable and function call
    assert safe_eval('1 + test', locals={'test': 42}) == 43
    assert safe_eval("'foo' in ['foo', 'bar']", locals={'test': 42}) is True

    # test safe_eval raising an error
    success = False
    try:
        safe_eval("__import__('os').system('rm -rf /')")
        success = False
    except:
        success = True
    assert success

    # test with function calls enabled
    success = False

# Generated at 2022-06-11 17:21:24.413968
# Unit test for function safe_eval
def test_safe_eval():
    # this tests the cases in library/show_tasks.py which used to fail
    safe_eval("[]")
    safe_eval("[1]")
    safe_eval("[1,2,3]")
    safe_eval("{}")
    safe_eval("{'a':1}")
    safe_eval("'a'")
    safe_eval("1")
    safe_eval("1+1")
    safe_eval("[] or {}")
    safe_eval("[1] or {'a':1}")
    safe_eval("'' or 'a'")
    safe_eval("1 or 2")
    safe_eval("1 > 0")
    safe_eval("0 > 1")

    try:
        safe_eval("repr(globals())")
    except:
        pass

# Generated at 2022-06-11 17:21:44.722510
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    assert safe_eval('1+1') == 2
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 - 1') == 0
    assert safe_eval('1 - - 1') == 2
    assert safe_eval('1 + 1 == 2') == True
    assert safe_eval('1 + 1 == 3') == False
    assert safe_eval('True and True') == True
    assert safe_eval('True and False') == False
    assert safe_eval('True or False') == True
    assert safe_eval('False or False') == False
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('"foo" + "bar" == "foobar"') == True

    # Dicts

# Generated at 2022-06-11 17:21:53.525016
# Unit test for function safe_eval
def test_safe_eval():
    ''' safe_eval() unit tests '''

    assert safe_eval('my_test_var') == 'my_test_var'
    assert safe_eval('1') == 1
    assert safe_eval('["a", "b", "c"]') == ['a', 'b', 'c']
    assert safe_eval('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert safe_eval('{"a": {"b": "c"}, "d": "e"}') == {'a': {'b': 'c'}, 'd': 'e'}
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('a_string_variable') == 'a_string_variable'

# Generated at 2022-06-11 17:22:03.531717
# Unit test for function safe_eval
def test_safe_eval():
    # error output is inconsistent across python versions, so we strip
    # before testing
    def sanitize(s):
        return s.strip().splitlines()[0]

    assert safe_eval('foo') == 'foo'
    assert safe_eval(['foo', 'bar']) == ['foo', 'bar']
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('1 + 1') == 2
    assert safe_eval('"foo" in bar') == '"foo" in bar'
    assert safe_eval('"foo" * 2') == 'foofoo'

    try:
        safe_eval('__import__("os").listdir()')
        assert False, 'should have raised an exception'
    except Exception:
        pass


# Generated at 2022-06-11 17:22:14.866880
# Unit test for function safe_eval
def test_safe_eval():
    # test fail conditions
    fail_strings = [
        # 'hashlib',
        # 'func()',
        'a + 3',
        'a == 3',
        'a is 3',
        '[x for x in range(3)]',
        '[x for x in range(10)]',
        'os.getcwd()',
        # 'filter(None, x)',
        '{"a":1,"b":2}',
        '{"a":1,"b":2}',
        '1 if True else 2',
        '(x for x in range(10))',
    ]
    for x in fail_strings:
        assert safe_eval(x) == x

    # test success conditions

# Generated at 2022-06-11 17:22:25.679535
# Unit test for function safe_eval
def test_safe_eval():
    # Empty string should return an empty string
    assert safe_eval('') == ''
    # Numeric string should return an integer
    assert safe_eval('1') == 1
    # Python True and False should return their counterpart
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    # String should return itself
    assert safe_eval('"TEST"') == 'TEST'
    # Dict should return dict
    assert isinstance(safe_eval('{"TEST": "TEST"}'), dict)
    assert safe_eval('{"TEST": "TEST"}').get("TEST") == "TEST"
    assert not safe_eval('{"TEST": "TEST"}').get("blah")
    # List should return list
    assert isinstance(safe_eval('["TEST"]'), list)

# Generated at 2022-06-11 17:22:36.598867
# Unit test for function safe_eval
def test_safe_eval():

    # Note: SyntaxError is a subclass of ValueError
    assert safe_eval("{{foo}}") == "{{foo}}"
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar()") == "foo.bar()"
    assert safe_eval("foo.bar().bam") == "foo.bar().bam"
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{1:2,3:4}") == {1: 2, 3: 4}
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("true") is True

# Generated at 2022-06-11 17:22:46.245003
# Unit test for function safe_eval
def test_safe_eval():
    v = safe_eval("{{ ansible_distribution }}", dict(ansible_distribution='ArgleBargle'), include_exceptions=True)
    assert len(v) == 2, "tuple expected"
    assert v[0] == 'ArgleBargle', "incorrect evaluation"
    assert v[1] is None, "non-None exception received"

    v = safe_eval("{{ ansible_distribution }}", dict(ansible_distribution='ArgleBargle'))
    assert v == 'ArgleBargle', "incorrect evaluation"

    v = safe_eval("{{ ansible_distribution }}", dict(ansible_distribution=['Argle', 'Bargle']))
    assert v == ['Argle', 'Bargle'], "incorrect evaluation"


# Generated at 2022-06-11 17:22:55.724331
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit tests for the safe_eval function
    '''
    # Invalid expressions

# Generated at 2022-06-11 17:23:02.994285
# Unit test for function safe_eval
def test_safe_eval():

    # Test for true and false boolean values
    result = safe_eval('true')
    assert result is True

    result = safe_eval('false')
    assert result is False

    # Test for None
    result = safe_eval('null')
    assert result is None

    # Test for floats
    result = safe_eval('1.1')
    assert type(result) == float

    result = safe_eval('1')
    assert type(result) == int

    # Test for strings
    result = safe_eval('"hello"')
    assert type(result) == str

    result = safe_eval('hello')
    assert type(result) == str

    result = safe_eval('u"hello"')
    assert type(result) == str

    # Test for lists
    result = safe_eval('[1,2,3]')

# Generated at 2022-06-11 17:23:13.697999
# Unit test for function safe_eval
def test_safe_eval():
    # check different ways to specify a list
    assert safe_eval("[1]") == [1]
    assert safe_eval("[1,2]") == [1,2]
    assert safe_eval("[1,2,]") == [1,2]
    assert safe_eval("[1, 2,]") == [1,2]
    assert safe_eval("[1,     2,]") == [1,2]
    assert safe_eval("[1  ,2,]") == [1,2]
    assert safe_eval("[1,  2,]") == [1,2]
    assert safe_eval("[1,2  ,]") == [1,2]
    assert safe_eval("[1,2,  ]") == [1,2]