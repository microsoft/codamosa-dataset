

# Generated at 2022-06-11 17:13:38.488489
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for safe_eval
    '''

    # basic tests
    assert safe_eval(42) == 42
    assert safe_eval("42") == 42
    assert safe_eval("a_string") == "a_string"
    assert safe_eval("2 * 3") == 6
    assert safe_eval("-2 + 3") == 1
    assert safe_eval("foo.bar()") == "foo.bar()"

    assert not isinstance(safe_eval("[1, 2, 3]"), string_types)
    assert isinstance(safe_eval("[1, 2, {{foo}}, 4, 5]", dict(foo='3')), list)

    # existing things should not be changed
    existing = [1,2,3]
    assert not isinstance(safe_eval("existing"), list)

    # and

# Generated at 2022-06-11 17:13:45.750009
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]') == []
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('[1, 2,]') == [1, 2]
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{}') == {}
    assert safe_eval('{"A": "a"}') == {'A': 'a'}
    assert safe_eval('{"A": "a"}') == {'A': 'a'}
    assert safe_eval('{"A": "a",}') == {'A': 'a'}
    assert safe_eval('{"A": "a", "B": "b"}') == {'A': 'a', 'B': 'b'}

# Generated at 2022-06-11 17:13:56.103774
# Unit test for function safe_eval
def test_safe_eval():

    # Test basic evalution
    assert safe_eval('1') == 1

    # Test tuple evaluation
    assert safe_eval('(1,2,3)') == (1, 2, 3)

    # Test dict evaluation
    assert safe_eval('({1:1,"2":"2"})') == ({1: 1, "2": "2"})

    # Test multiple operations
    assert safe_eval('1 + 1') == 2
    assert safe_eval('4 - 2') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('10 / 2') == 5
    assert safe_eval('2**3') == 8

    # Test comparisons
    assert safe_eval('10 > 4') == True
    assert safe_eval('2 < 3') == True
    assert safe_eval('10 >= 4') == True


# Generated at 2022-06-11 17:14:06.550300
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    import ansible.constants as C
    import sys

    if sys.version_info < (2, 7):
        print("Unable to run tests for safe_eval as python version does not meet minimal requirement 2.7\n")
        return

    my_dict = {
        'a_string': 'dummy',
        'a_list': [1, 2, 3],
        'a_dict': {
            'key1': 'val1',
            'key2': 'val2'
        },
        'a_num': 10
    }

    # Test string evaluation
    assert safe_eval('a_string', variables=my_dict) == 'dummy'
    assert safe_eval('"a_string"', variables=my_dict) == 'a_string'

# Generated at 2022-06-11 17:14:14.677916
# Unit test for function safe_eval
def test_safe_eval():
    # FIXME: We need to use a test fixture here which should be
    # defined in test/units/module_utils/text/common/test_converters.py

    def test_eval(expr, expected_result, expected_error=None):
        # When no errors are expected, we do not need to pass 'include_exceptions'
        # to the call to safe_eval, but in case we do, we need to ignore the
        # error raised
        if expected_error is None:
            ret = safe_eval(expr, include_exceptions=False)
        else:
            ret, err = safe_eval(expr, include_exceptions=True)

# Generated at 2022-06-11 17:14:22.944342
# Unit test for function safe_eval
def test_safe_eval():
    """Validate safe_eval function."""
    params = {
        'string_arg': 'Hello',
        'empty_string': '',
        'empty_list': [],
        'list_with_values': ['Hello', 'World', '!'],
        'multidict': [{'k1': 'v1', 'k2': 'v2'}, {'k3': 'v3', 'k4': 'v4'}],
    }

    expr = 'string_arg'
    assert safe_eval(expr) == 'Hello'
    assert safe_eval(expr, params) == 'Hello'

    expr = 'string_arg == "Hello"'
    assert safe_eval(expr) is True
    assert safe_eval(expr, params) is True

    expr = "string_arg.startswith('H')"


# Generated at 2022-06-11 17:14:34.045901
# Unit test for function safe_eval
def test_safe_eval():
    class TestClass(object):
        test_attr = 'attr_value'

    test_obj = TestClass()
    test_dict = {
        'test_attr': 'dict_value',
        'test_obj': test_obj,
    }

    def test_func():
        return 'func_value'

    test_locals = {
        'test_attr': 'local_value',
        'test_dict': test_dict,
        'test_func': test_func,
        'test_obj': test_obj,
    }


# Generated at 2022-06-11 17:14:46.160796
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:55.997663
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:05.665346
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:17.582723
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # Test safe_eval with a list
    test_list = '[1,2,3]'
    result = safe_eval(test_list)
    assert isinstance(result, list)

    # Test safe_eval with a list and a variable
    test_list = '[1,2,3,var_test]'
    var_test = 4
    result = safe_eval(test_list, locals={'var_test': var_test})
    assert isinstance(result, list)
    assert result[-1] == var_test

    # Test safe_eval with a list and an unsafe expression
    test_list = '[1,2,3,(4*4)]'
    result = safe_eval(test_list)
    assert result == '(4*4)'

    # Test safe_eval with a list and a safe

# Generated at 2022-06-11 17:15:27.526355
# Unit test for function safe_eval
def test_safe_eval():
    def test(input, expected_result, expected_exception=None):
        result, exception = safe_eval(input, include_exceptions=True)
        if exception is not None:
            if not sys.version_info[0] == 2:
                exception = exception.__traceback__
            if not isinstance(expected_exception, string_types):
                if not isinstance(expected_exception, type(exception)) or not issubclass(type(expected_exception), type(exception)):
                    raise AssertionError("safe_eval raised exception %s and not %s" % (type(exception).__name__, type(expected_exception).__name__))

# Generated at 2022-06-11 17:15:37.082564
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:45.663869
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:55.718301
# Unit test for function safe_eval
def test_safe_eval():
    fname = sys._getframe().f_code.co_name
    result = safe_eval('{"a": "1", "b": false, "c": true, "d": null}')
    assert result == {'a': '1', 'b': False, 'c': True, 'd': None}, \
        "%s: Expected result is not equal to %s" % (fname, str(result))

    result = safe_eval('(1 in [1])')
    assert result is True, "%s: Expected result is not equal to %s" % (fname, str(result))

    result = safe_eval('(1 in [1, 2])')
    assert result is True, "%s: Expected result is not equal to %s" % (fname, str(result))


# Generated at 2022-06-11 17:16:06.668803
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a == b") == "a == b"
    assert safe_eval("a == \"foo\"") == "a == \"foo\""
    assert safe_eval("a != 'foo'") == "a != 'foo'"
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval("('a', 'b')") == ('a', 'b')
    assert safe_eval("('a', 'b', 'c')") == ('a', 'b', 'c')
    assert safe_eval("{'a': ['a', 'b']}") == {'a': ['a', 'b']}
    assert safe_eval("{'a': ['a', 'b', 'c']}") == {'a': ['a', 'b', 'c']}
    assert safe_

# Generated at 2022-06-11 17:16:16.965795
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar', {'foo': {'bar': 'foobar'}}) == 'foobar'
    assert safe_eval('foo.bar', {'foo': {'bar': 'foobar'}}, True) == ('foobar', None)
    assert safe_eval('foo.bar', {'foo': {'bar': 'foobar'}}, True)[0] == 'foobar'
    assert safe_eval('foo.bar', {'foo': {'bar': 'foobar'}}, True)[1] is None
    assert safe_eval('foo.bar', {'foo': {'bar': 'foobar'}}) == 'foobar'

# Generated at 2022-06-11 17:16:24.374277
# Unit test for function safe_eval
def test_safe_eval():
    # test for valid syntax
    def test_expr(expr, expected, locals=None):
        result, err = safe_eval(expr, locals, include_exceptions=True)
        assert result == expected and err is None, \
            "Expected: %s, Got: %s" % (expected, result)

    test_expr("3", 3)
    test_expr("a", 5, dict(a=5))
    test_expr("a + 5", 10, dict(a=5))

    # test for invalid syntax
    def test_invalid_expr(expr):
        result, err = safe_eval(expr, dict(), include_exceptions=True)
        assert result == expr and isinstance(err, SyntaxError), \
            "Expected: %s, Got: %s" % (expr, result)

    test_

# Generated at 2022-06-11 17:16:34.737501
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval()
    '''
    # simple expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('[1, 2, {"a": 1}]') == [1, 2, {"a": 1}]
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('[1, 2, 3]', include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval('{"a": 1}', include_exceptions=True)[0] == {"a": 1}

# Generated at 2022-06-11 17:16:44.584975
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:57.307981
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ hostvars[inventory_hostname].ansible_os_family }}") == '{{ hostvars[inventory_hostname].ansible_os_family }}'
    assert safe_eval("hostvars[inventory_hostname].ansible_os_family") == 'hostvars[inventory_hostname].ansible_os_family'

    # actual hostvars value is a dict
    test_hostvars = {'foo': {'bar': 'baz'}}
    assert safe_eval("{{ hostvars['foo']['bar'] }}", dict(hostvars=test_hostvars)) == '{{ hostvars[\'foo\'][\'bar\'] }}'

# Generated at 2022-06-11 17:17:08.331812
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('(1 + 1)') == 2
    assert safe_eval('(foo + bar)', dict(foo=5, bar=6)) == 11
    assert safe_eval('(foo + bar)', dict(foo=5, bar=6)) == 11
    assert safe_eval('foo', dict(foo=[1,2,3])) == [1,2,3]
    assert safe_eval('foo', dict(foo=1)) == 1
    assert safe_eval('foo', dict(foo=True)) == True
    assert safe_eval('foo', dict(foo=False)) == False
    try:
        safe_eval('foo')
        assert False
    except:
        assert True

# Generated at 2022-06-11 17:17:17.127718
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This test function is here for debugging purposes
    python -m ansible.template test_safe_eval
    '''
    from ansible.utils.display import Display

    display = Display()

    any_exception = None

# Generated at 2022-06-11 17:17:26.552090
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple, safe things
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('1+1') == 2
    assert safe_eval('3.14') == 3.14
    assert safe_eval('1 + 1') == 2
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    if sys.version_info[:2] < (2, 7):
        assert safe_eval('None') is None

# Generated at 2022-06-11 17:17:33.326132
# Unit test for function safe_eval
def test_safe_eval():
    # NOTE: Strings here passed to safe_eval must be quoted, as they simulate
    #       variable strings passed to a Jinja2 template, which automatically
    #       quotes them.
    #       If a single quote is needed inside the value, it must be preceded
    #       by a backslash, and should be enclosed in double quotes:
    #       e.g.: "{{'it\'s a test'}}"

    # Test simple expressions
    assert safe_eval("'test'") == 'test'
    assert safe_eval("{{'test'}}") == 'test'
    assert safe_eval("{{'te\\'st'}}") == "te'st"
    assert safe_eval("1+1") == 2
    assert safe_eval("0xff") == 0xff

# Generated at 2022-06-11 17:17:43.209983
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:49.464997
# Unit test for function safe_eval
def test_safe_eval():
    expr = '12 + 12 * (12 + 12)'
    correct_result = '((12 + 12) * 12) + 12'

    # This should work and return the correct result
    assert safe_eval(expr) == ast.literal_eval(correct_result)

    # This should raise an exception as we are trying to create a complex number
    expr = '2j'
    if (C.DEFAULT_DEBUG):
        # Internally we catch the exepction and return the expression string
        # without the eval
        assert safe_eval(expr) == expr
    else:
        # When not debugging, the exception is raised
        try:
            safe_eval(expr)
        except:
            return

        assert False, "Expected an exception from safe_eval"

    # This should raise an exception as we are trying to do an invalid call


# Generated at 2022-06-11 17:17:58.263726
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:04.431372
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import astor
    except:
        print("The astor module is not installed.  Please install it before running the tests")
        sys.exit(2)

    # This test is designed to cover all of the unit tests at
    # https://github.com/ansible/ansibullbot/pull/250
    # which are based on the safe_eval blacklist.  Any changes to
    # the blacklist will require changes to this test, as well as
    # additional unit tests as needed.

    # Test whitelisted nodes.  All of these should be able to be evaluated.

# Generated at 2022-06-11 17:18:14.878714
# Unit test for function safe_eval
def test_safe_eval():
    # Test empty string
    assert safe_eval("") == ""

    # Test good, simple values
    assert safe_eval("1") == 1
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("'foo' + 'bar'") == "foobar"

    # Test good, complex values
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}

    # Test bad things
    if C.DEFAULT_KEEP_REMOTE_FILES:
        assert safe_eval("open('/tmp/somefile', 'w')") == "open('/tmp/somefile', 'w')"

# Generated at 2022-06-11 17:18:28.924059
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    f = open(sys.modules[__name__].__file__, 'r')
    module_source = f.read()

# Generated at 2022-06-11 17:18:38.020012
# Unit test for function safe_eval
def test_safe_eval():

    # Arrange
    # Note: If a test fails, then the error message will be displayed in the
    # terminal. To debug, you can put a print statement in the except block to
    # print out the expression that the the safe_eval failed on.
    # Also, you can add more test cases.

    # Expression list that we expect to evaluate to a list
    LIST_EXPRESSIONS = [
        "a_list_variable",
        "['a'] + ['b']",
        "['a', 'b']",
        "['a', 'b', 'a' + 'b']",
        "[i for i in ('a', 'b')]",
        "range(1, 2)",
        "[i for i in ('a', 'b') if i == 'a']",
    ]

    # Expression list that we expect to evaluate to a string

# Generated at 2022-06-11 17:18:47.696878
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(7) == 7
    assert safe_eval('7') == 7
    assert safe_eval('7 + 3') == 10
    assert safe_eval('7 + 3 + 2') == 12
    assert safe_eval('a', dict(a=7)) == 7

    # Uses the safe dict from above to ensure we restrict what eval()
    # can do.  This also tests that we allow for dict/list/set/tuple
    # types:
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('()') == ()
    assert safe_eval('set()') == set()
    assert safe_eval('set([1,2,3])') == set([1, 2, 3])

    # now try some unsafe things

# Generated at 2022-06-11 17:18:57.754706
# Unit test for function safe_eval
def test_safe_eval():
    # print("TODO: convert test_safe_eval to pytest format")
    # return
    # don't use pytest.skipif here as it is not imported yet
    # at import time of this module
    if sys.version_info[:2] >= (2, 7):
        # TODO: convert test_safe_eval to pytest format
        # pytest.skip("test_safe_eval is not yet ported to pytest")
        pass
    else:
        # TODO: convert test_safe_eval to pytest format
        # pytest.skip("test_safe_eval requires python 2.7+")
        pass

    # simple expressions
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval

# Generated at 2022-06-11 17:19:07.032447
# Unit test for function safe_eval
def test_safe_eval():
    # Note: Some of these tests are specific to Python 2.x, but
    # we can't use Python 3 syntax for calling safe_eval() as that
    # would cause a SyntaxError at module load time
    from ansible.module_utils.common.text.compat import binary_type

    # define some test variables

# Generated at 2022-06-11 17:19:16.506044
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a', {'a': 1}) == 1
    assert safe_eval('a', {'a': 1.0}, include_exceptions=True) == (1.0, None)
    assert safe_eval('a.b', {'a': {'b': 1}}) == 1
    assert safe_eval('a.b', {'a': {'b': 1.0}}, include_exceptions=True) == (1.0, None)
    assert safe_eval('a', {'a': [1, 2]}) == [1, 2]
    assert safe_eval('a', {'a': {'a': 1}}) == {'a': 1}
    assert safe_eval('a', {'a': {'a': 1}}, include_exceptions=True) == ({'a': 1}, None)

# Generated at 2022-06-11 17:19:27.278369
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a list of tests to make sure that safe_eval is working
    correctly.  When adding tests for safe_eval, make sure to only
    add tests that are safe to execute from the command line.  Tests
    which can be used to demo a vulnerable eval() call should go in
    test/vuln_safe_eval.py.
    '''
    from ansible.module_utils.six import PY3

    def result(test_name, result, expected=None):
        if expected:
            if result != expected:
                print("%s: %s != %s" % (test_name, to_native(result), to_native(expected)))
                return False
        else:
            if isinstance(result, Exception):
                raise result

# Generated at 2022-06-11 17:19:36.885100
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval
    The safe_eval function should allow:
    (1) constants
    (2) basic operators and parentheses
    (3) list literals
    (4) dictionary literals
    (5) builtin types (such as None and False)
    """
    # Test constants
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'string'") == 'string'
    assert safe_eval("1.0") == 1.0
    assert safe_eval("1.0") == 1.0
    assert safe_eval("{True: None}") == {True: None}

    # Test basic operators and parentheses
    assert safe_eval("1+2") == 3
    assert safe_eval("1+2*4") == 9

# Generated at 2022-06-11 17:19:45.681661
# Unit test for function safe_eval
def test_safe_eval():
    def _eval(expr, expected_result=None, should_pass=True):

        if should_pass:
            result, exception = safe_eval(expr, include_exceptions=True)
            if exception:
                raise AssertionError('safe eval exception: %s' % exception)
            if result != expected_result:
                raise AssertionError('%s != %s' % (result, expected_result))
        else:
            try:
                result = safe_eval(expr)
                raise AssertionError('This expression should have failed: %s' % expr)
            except Exception:
                # exception is expected, no need to assert
                pass

    # Test to check valid expressions

# Generated at 2022-06-11 17:19:51.222556
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test for function safe_eval.
    """
    from ansible.module_utils import basic
    import os
    import json

    # parameters
    orig_locals = locals()
    include_exceptions = True

    # list of tuples composed of:
    # - test expression
    # - expected result after evaluating the expression
    # - the test name
    # - the locals to be passed to safe_eval

# Generated at 2022-06-11 17:20:04.779135
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:13.990720
# Unit test for function safe_eval
def test_safe_eval():
    variable_manager = MockVariableManager()
    res, exc = safe_eval('1 + 1', variable_manager.get_vars(loader=None, play=None), include_exceptions=True)
    assert res == 2
    assert exc is None

    res, exc = safe_eval('1 + a_non_existent_identifier', variable_manager.get_vars(loader=None, play=None), include_exceptions=True)
    assert res == '1 + a_non_existent_identifier'
    assert type(exc) == NameError

    res, exc = safe_eval('[1, 2, 3]', variable_manager.get_vars(loader=None, play=None), include_exceptions=True)
    assert res == [1, 2, 3]
    assert exc is None

    res, exc = safe_

# Generated at 2022-06-11 17:20:21.431542
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("A", locals=locals()) == "A"
    assert safe_eval("123") == 123
    assert safe_eval("5+5") == 10
    assert safe_eval("1 + 2 * 3 / 4") == 1 + 2 * 3 / 4
    assert safe_eval("1 + 2 * 3 // 4") == 1 + 2 * 3 // 4
    assert safe_eval("1 + 2 * 3 % 4") == 1 + 2 * 3 % 4
    assert safe_eval("1 + 2 ** 3") == 1 + 2 ** 3
    assert safe_eval("1 < 2") == 1 < 2
    assert safe_eval("1 > 2") == 1 > 2
    assert safe_eval("1 >= 2") == 1 >= 2
    assert safe_eval("1 <= 2") == 1 <= 2

# Generated at 2022-06-11 17:20:28.438178
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure we can't access the non-white listed name 'open'
    assert safe_eval('open') == 'open'
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('1 + 1 + 1') == 3
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('()') == ()
    assert safe_eval('[1, 2, (3, 4)]') == [1, 2, (3, 4)]
    assert safe_eval('[1, 2, (3, [4, 5])]') == [1, 2, (3, [4, 5])]

# Generated at 2022-06-11 17:20:37.552983
# Unit test for function safe_eval
def test_safe_eval():
    # Test with no exceptions
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('"foo" + "bar"') == "foobar"
    assert safe_eval('1/2') == 0.5
    assert safe_eval('"foo" == "foo"') == True
    assert safe_eval('1 == 1') == True
    assert safe_eval('{ "a": 1, "b": 2 }') == {"a": 1, "b": 2}
    assert safe_eval('( 1, 2, 3, 4, 5 )') == (1, 2, 3, 4, 5)
    assert safe_eval('1-1') == 0
    assert safe_eval('1*1') == 1
    assert safe_

# Generated at 2022-06-11 17:20:47.786412
# Unit test for function safe_eval
def test_safe_eval():
    def assert_equal(a,b):
        if a != b:
            print(a)
            print(b)
            assert a == b

    assert_equal(safe_eval("foo", {"foo": "bar"}), "bar")
    assert_equal(safe_eval("foo", {"foo": None}), None)
    assert_equal(safe_eval("foo", {"foo": True}), True)
    assert_equal(safe_eval("foo", {"foo": False}), False)
    assert safe_eval("foo", {"foo": False}) is False
    assert safe_eval("foo", {"foo": []}) == []
    assert safe_eval("foo", {"foo": [1,2,3]}) == [1,2,3]
    assert safe_eval("foo", {"foo": {}}) == {}
    assert safe_

# Generated at 2022-06-11 17:20:59.064045
# Unit test for function safe_eval
def test_safe_eval():
    # This is an eval()-safe version of the following:
    #  a = [1,2,3]
    #  b = [ "a", "b", "c" ]
    #  c = [ (1,2), (3,4), (5,6) ]
    #  with_items: a | intersect(b) | intersect(c)
    example_jinja = [(1, 2), (3, 4), (5, 6)]

    # Basic test, should work
    actual_result = safe_eval(example_jinja)
    assert actual_result == example_jinja

    # Check handling of scalars:
    assert safe_eval(True) is True
    assert safe_eval('True') is True
    assert safe_eval(0) == 0
    assert safe_eval('0') == 0

    # Check

# Generated at 2022-06-11 17:21:06.040475
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('1')
    safe_eval('1 + 1')
    safe_eval('[1, 2, 3]')
    safe_eval('[1, 2, 3] + [4, 5, 6]')
    safe_eval('1 in [1, 2, 3]')
    safe_eval('False')
    safe_eval('True')
    safe_eval('None')
    safe_eval('1 + 2 + 3')
    safe_eval('-, 32')
    safe_eval('type(42)')
    safe_eval("type(type(42))")
    safe_eval('{"foo": "bar"}')
    safe_eval("{42: 'foo'}")
    safe_eval("{1: [2, 3]}")
    safe_eval("{'a': 1, 'b': 2}")


# Generated at 2022-06-11 17:21:14.887301
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{ foo }}-{{ bar }}"
    result = safe_eval(expr)
    assert result == expr

    expr = "foo - bar"
    result = safe_eval(expr)
    assert result == expr

    expr = "foo.bar"
    result = safe_eval(expr)
    assert result == expr

    expr = "1+1"
    result = safe_eval(expr)
    assert result == 2

    expr = "1 + 1"
    result = safe_eval(expr)
    assert result == 2

    expr = "6 * 7"
    result = safe_eval(expr)
    assert result == 42

    expr = "{ 'foo': 1, 'bar': 2, 'baz': 3 }"
    result = safe_eval(expr)

# Generated at 2022-06-11 17:21:24.530278
# Unit test for function safe_eval
def test_safe_eval():
    # constant types
    assert safe_eval("'one'") == 'one'
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None

    # math
    assert safe_eval("1+1") == 2
    assert safe_eval("2-1") == 1
    assert safe_eval("2*2") == 4
    assert safe_eval("3/2") == 1.5

    # unary operations
    assert safe_eval("-1") == -1
    assert safe_eval("+1") == 1

    # comparison
    assert safe_eval("1 < 1") is False
    assert safe_eval("1 > 1") is False
   

# Generated at 2022-06-11 17:21:39.583695
# Unit test for function safe_eval
def test_safe_eval():
    """ simple unit test to make sure safe eval works """

    # we are going to eval() this expression
    test_expression = "[1,2] + [3,4]"

    # expected results of the eval()
    expected_result = [1, 2, 3, 4]

    # perform the eval
    result = safe_eval(test_expression)

    # make sure we got the expected result
    assert result == expected_result, "Result (%s) does not match expected result (%s)" % (result, expected_result)

# class to display properly a complex variable

# Generated at 2022-06-11 17:21:48.079494
# Unit test for function safe_eval
def test_safe_eval():
    # Valid expressions:
    # --------------------
    if sys.version_info < (2, 7):
        # dict() is not allowed in safe_eval()
        # This is because in ast.py we have:
        # elif isinstance(node, ast.Dict):
        # which means that dict() is not allowed
        # but dict([(x,y),(p,q)]) is allowed
        assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("1 + 2") == 3
    assert safe_eval('(True in [False, False, True])')
    assert not safe_eval('(True in [False, False, False])')
    assert safe_eval('len(["foo", "bar"])') == 2

# Generated at 2022-06-11 17:21:56.009866
# Unit test for function safe_eval
def test_safe_eval():
    # Test to make sure safe_eval() will not allow anything unsafe
    try:
        safe_eval(
            "from subprocess import call;call(['touch','deleteme.txt'])"
        )
    except:
        pass
    else:
        print(
            "safe_eval() should not allow calling arbitrary functions!"
        )
        sys.exit(1)

    # Test to make sure safe_eval() will allow valid expressions
    safe_eval(
        "["
        "   'the cow jumped over', "
        "   'the moon was full',"
        "   'the cheese was moldy',"
        "   'and the aligators were hungry',"
        "   'and the wind was calm',"
        "   'and the sun began to set',"
        "   'in the distance',"
        "]"
    )



# Generated at 2022-06-11 17:22:05.326072
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info.major > 2:
        from ansible.module_utils.six.moves import unittest
    else:
        import unittest

    class TestSafeEval(unittest.TestCase):
        def test_simple(self):
            data = safe_eval('[1,2,3]')
            self.assertEqual(data, [1, 2, 3])

        def test_not_a_list(self):
            data = safe_eval('pow(2,10)')
            self.assertEqual(data, 1024)

        def test_function_call(self):
            data = safe_eval('range(3)')
            self.assertEqual(data, [0, 1, 2])


# Generated at 2022-06-11 17:22:16.013481
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:26.491881
# Unit test for function safe_eval
def test_safe_eval():
    # add some more ast.node types to the SAFE_NODES list
    SAFE_NODES.update(
        (
            ast.BitAnd,
            ast.BitOr,
            ast.BitXor,
            ast.And,
            ast.Or,
            ast.Mod,
            ast.Pow,
            ast.LShift,
            ast.RShift,
            ast.Attribute,
        )
    )

    def _assert_expr_true(expr):
        result, err = safe_eval(expr, {}, include_exceptions=True)
        assert result is True
        if C.DEFAULT_DEBUG:
            print('%s is %s' % (expr, container_to_text(result)))


# Generated at 2022-06-11 17:22:37.220052
# Unit test for function safe_eval
def test_safe_eval():
    # Define some locals for testing
    a = {"a": 1}
    b = {'a': 1, 'b': "c"}
    c = ['a', 'b', 'c', 1, 2, 3]
    d = ('a', 'b', 'c', 1, 2, 3)
    e = {"a": 1, "b": {'c': 3, 'd': "e"}, "f": ['a', 'b', 'c']}
    f = (1, 2, 3)
    g = 1
    h = (1, 2, 3)
    i = [1, 2, 3]
    j = {'a': 1, 'b': 2}
    k = ['a', 'b', 'c', 1, 2, 3]
    l = (1,)

    # Define the expressions to evaluate
    expressions

# Generated at 2022-06-11 17:22:47.186990
# Unit test for function safe_eval
def test_safe_eval():
    current_sys_version = ".".join(map(str, sys.version_info[0:3]))

# Generated at 2022-06-11 17:22:56.630008
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test function for function safe_eval
    '''
    def _test(expr, expected_value, expected_exception=None, locals=None):
        retval, exception = safe_eval(expr, locals=locals, include_exceptions=True)
        if retval != expected_value:
            raise Exception("Expected (%s), Got (%s)" % (expected_value, retval))
        if expected_exception is None and exception is not None:
            raise Exception("Expected no exception, Got (%s)" % (exception))
        if expected_exception is not None and exception is None:
            raise Exception("Expected exception (%s), Got no exception" % (expected_exception))

    # test a few ways to spell True
    _test('True', True)
    _test('true', True)
   

# Generated at 2022-06-11 17:23:03.397669
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:29.057884
# Unit test for function safe_eval