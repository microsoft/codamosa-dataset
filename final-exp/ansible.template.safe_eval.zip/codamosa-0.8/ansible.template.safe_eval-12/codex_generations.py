

# Generated at 2022-06-11 17:13:39.485188
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval() function.
    '''
    # Disallow calling functions from the whitelist
    CALL_ENABLED = []

    # Test 1: Basic example.
    expr = '1 + 2'
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == 3

    # Test 2: Disallow expressions with function call that is
    # not in the whitelist.
    expr = 'myfunction(10, 20)'
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr

    # Test 3: Allow expressions with function call that is
    # in the whitelist.
    expr = 'myfunction(10, 20)'
    CALL_ENABLED.append('myfunction')

# Generated at 2022-06-11 17:13:50.566724
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic

    failed = False
    output = ""
    msg = "Running basic tests for safe_eval"
    print(msg)
    output += msg + "\n"

    (rc, out, err) = basic.run_command("python -V")
    (pyver, _) = err.rsplit(' ', 1)
    (majv, minv) = pyver.split('.')[:2]
    pyver = '%s.%s' % (minv, majv)

    msg = "Python version : %s" % pyver
    print(msg)
    output += msg + "\n"

    # Test safe_eval()

# Generated at 2022-06-11 17:13:58.444462
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from jinja2 import Environment, FileSystemLoader
    except ImportError:
        jinja2_available = False
    else:
        jinja2_available = True

    save_stdout = sys.stdout
    save_stderr = sys.stderr
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

    # Setup all test cases
    # NOTE: Or you can use yaml or something to load the test cases
    #       in following format:
    #
    #       TESTCASE:
    #         JINJA2: "{{ list }}"
    #         JINJA2_ENABLED: True
    #         JINJA2_RESULT: "foo"
    #         SAFE_EVAL_ENABLED

# Generated at 2022-06-11 17:14:07.316744
# Unit test for function safe_eval
def test_safe_eval():
    """
    Check secure_eval is working properly.
    """
    failed = False
    failed_list = []
    failed_msg = ''
    failed_count = 0
    total_count = 0

    # Test positive eval

# Generated at 2022-06-11 17:14:18.784171
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval(" 123  ") == 123
    assert safe_eval("1 + 2") == 3
    assert safe_eval("'a' * 3") == 'aaa'
    assert safe_eval("5 - 3") == 2

    # this is not ok, see GH #28284
    # assert safe_eval("len([])") == 0

    # this is ok, because we allow calls to functions built into python
    assert safe_eval("str([])") == '[]'

    with_items_list = [{'foo': 'bar'}, {'bam': 'boz'}]

# Generated at 2022-06-11 17:14:27.804745
# Unit test for function safe_eval
def test_safe_eval():
    for expr, expected in unit_test_safe_eval_expressions:
        if expected is True:
            # We expect to eval (and thus parse) expr, but we don't
            # actually care about the value returned
            safe_eval(expr)
        elif expected is False:
            # We expect an exception to be raised when parsing and evaling
            # expr
            try:
                safe_eval(expr)
            except Exception:
                pass
            else:
                raise AssertionError("Unexpected success for eval'ing expr=%r" % expr)
        else:
            # We expect safe_eval to return the exact object `expected`
            # when parsing and evaling expr
            retval = safe_eval(expr)

# Generated at 2022-06-11 17:14:35.244984
# Unit test for function safe_eval
def test_safe_eval():
    assert 42 == safe_eval('6 * 7')
    assert 42 == safe_eval('6 * ( 7 )')
    assert 21 == safe_eval('6 * (1 + 1 + 1 + 1 + 1 + 1 + 1)')
    assert 21 == safe_eval('21')
    assert 21 == safe_eval('9 + 12')
    assert 42 == safe_eval('1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1')
    assert [1, 1, 2, 3, 5, 8, 'boom'] == safe_eval('[1, 1, 2, 3, 5, 8, "boom"]')
    assert {'foo': 'bar'} == safe

# Generated at 2022-06-11 17:14:47.053458
# Unit test for function safe_eval
def test_safe_eval():
    '''This test is written using the unittest module, but it is not
    enabled as a full-scale unit test.  To run it, just execute this
    file directly:
    $ python utils/unsafe_proxy.py
    '''
    import unittest

    class TestEval(unittest.TestCase):

        def test_safe_eval_numbers_strings(self):
            # test integers, floats, strings
            self.assertEqual(safe_eval('1'), 1)
            self.assertEqual(safe_eval('-2'), -2)
            self.assertEqual(safe_eval('1 + 2'), 1 + 2)
            self.assertEqual(safe_eval('-34 - 90'), -34 - 90)

# Generated at 2022-06-11 17:14:56.330329
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import astor
    except ImportError:
        raise AssertionError('The "astor" Python module is required to run the safe_eval tests.')

    # Test basic functionality

# Generated at 2022-06-11 17:15:05.825989
# Unit test for function safe_eval
def test_safe_eval():
    too_many_errs = 0

# Generated at 2022-06-11 17:15:17.711683
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval"""

    def _test(expr, locals, include_exceptions=False):
        if include_exceptions:
            result, err = safe_eval(expr, locals, include_exceptions=True)
            if err:
                raise Exception("error during safe_eval (%s): %s" % (expr, err))
            return result

        return safe_eval(expr, locals, include_exceptions=False)

    # Success tests
    assert _test("1+2", {}) == 3
    assert _test("1+2", {}, include_exceptions=True) == 3
    assert _test("1+2", {'one': 1}, include_exceptions=True) == 3
    assert _test("one+2", {'one': 1}, include_exceptions=True) == 3
    assert _

# Generated at 2022-06-11 17:15:27.644764
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import astor
    except ImportError:
        print('skipping astor tests because astor is not installed')
        return

    # The string must be generated by ast.dump() and not by astor.to_source() since the latter
    # arranges the code in a more readable way but that makes the AST different from ast.parse().

# Generated at 2022-06-11 17:15:37.172762
# Unit test for function safe_eval
def test_safe_eval():

    # using assert_raises from the unittest package
    from ansible.module_utils.six.moves import unittest

# Generated at 2022-06-11 17:15:45.709828
# Unit test for function safe_eval
def test_safe_eval():
    # Empty input should return empty string
    assert safe_eval('') == ''

    # String input should return input string
    test_string = 'this is a test string'
    assert safe_eval(test_string) == test_string

    # Basic constant should return itself
    assert safe_eval('True')

    # Random function call should fail
    try:
        safe_eval('eval("hello")')
        assert False
    except:
        pass

    # Basic arithmetic should work
    assert safe_eval('1+1') == 2

    # Multiplication should work
    assert safe_eval('2*2') == 4

    # Subtraction should work
    assert safe_eval('2-1') == 1

    # Division should work
    assert safe_eval('4/2') == 2

    # Exponents should work
    assert safe

# Generated at 2022-06-11 17:15:55.745870
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:06.708041
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:15.783870
# Unit test for function safe_eval
def test_safe_eval():
    # We don't test the AST restriction stuff because that's tested
    # in the unit tests for CleansingNodeVisitor.

    # Some basic literal values
    assert safe_eval('"foobar"') == 'foobar'
    assert safe_eval('42') == 42
    assert safe_eval('3.14') == 3.14
    assert safe_eval('true') == True
    assert safe_eval('false') == False

    # Builtin functions
    assert safe_eval('len("foobar")') == 6
    assert safe_eval('abs(-42)') == 42
    assert safe_eval('int(3.14)') == 3
    assert safe_eval('str(3.14)') == "3.14"

    # Handle some unsupported python types...
    # This is sort of important because Python 3.5+ adds support
   

# Generated at 2022-06-11 17:16:24.117068
# Unit test for function safe_eval
def test_safe_eval():
    # test failure cases
    expr = 'a_list_variable'
    expected = expr
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expected and exception is not None

    expr = []
    expected = expr
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expected and exception is None

    # test success cases
    # 1.0, 2
    expr = "1.0 + 2"
    expected = 3.0
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expected and exception is None

    # ['a', 'b', 'c'], 'd', 'e'
    expr = "['a', 'b', 'c'] + ['d', 'e']"

# Generated at 2022-06-11 17:16:34.704443
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('1+1') == 2
    assert safe_eval('2*2') == 4
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1, "b":2}') == {'a': 1, 'b': 2}
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None

    # Avoid syntax errors
    assert safe_eval('a') == 'a'
    assert safe_eval('[a, b, c]') == '[a, b, c]'
    assert safe_eval('{"a": b, "c": d}') == '{"a": b, "c": d}'

# Generated at 2022-06-11 17:16:44.544358
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:59.547038
# Unit test for function safe_eval
def test_safe_eval():
    global CALL_ENABLED

    # we need these for the assertions below
    CALL_ENABLED.extend(('int', 'list', 'dict', 'sorted', 'join'))

    # test that we immediately die on invalid syntax
    try:
        safe_eval("dict(a=1, b=2)")
    except Exception as e:
        assert e.message.startswith("invalid expression")

    # test that we immediately die on invalid function calls
    try:
        safe_eval("re.compile('foo')")
    except Exception as e:
        assert e.message.startswith("invalid function")

    # test that we immediately die on invalid function calls

# Generated at 2022-06-11 17:17:10.411923
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("{foo: 'bar'}") == {'foo': 'bar'})
    assert(safe_eval("[1,2,3,4]") == [1, 2, 3, 4])
    assert(safe_eval("'bar'") == 'bar')
    assert(safe_eval('["a", "b", c]', locals={'c': 'c'}) == ['a', 'b', 'c'])
    assert(safe_eval('["a", "b", c]', locals={'c': 'c'}) == ['a', 'b', 'c'])
    assert(safe_eval('a', locals={'a': 'b'}) == 'b')
    assert(safe_eval('a.b', locals={'a': {'b': 'c'}}) == 'c')

# Generated at 2022-06-11 17:17:19.355079
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":"b"}') == {"a": "b"}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[1+1]') == [2]
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]
    assert safe_eval('["a", "b", 3]') == ["a", "b", 3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}

# Generated at 2022-06-11 17:17:28.105645
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:34.320769
# Unit test for function safe_eval
def test_safe_eval():
    # check that empty expressions work
    assert safe_eval("") == ""

    # check basic types
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("'foobar'") == 'foobar'
    assert safe_eval("1") == 1
    assert safe_eval("1.2") == 1.2  # note no safe_eval of floats
    # generate a long string of length C.DEFAULT_

# Generated at 2022-06-11 17:17:43.670035
# Unit test for function safe_eval
def test_safe_eval():
    # To successfully run all tests, we need to use the same
    # safe_eval function as we'll use in the rest of Ansible,
    # and we can't monkey patch code in modules loaded at import
    # time (namely, ansible.module_utils.six).  Since this file
    # is not imported as a module, we can monkey patch it here.
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['safe_eval'] = safe_eval

    assert eval('4 + 3') == safe_eval('4 + 3')
    assert eval('[1,2,3]') == safe_eval('[1,2,3]')
    assert eval('(1,2,3)') == safe_eval('(1,2,3)')

# Generated at 2022-06-11 17:17:53.813353
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval.  This function generates a
    traceback on failure so we do not need to import the unittest
    module.
    '''
    def test_eval(s):
        try:
            safe_eval(s)
            return True
        except:
            traceback.print_exc()
            return False

    # simple expressions
    assert test_eval("a + b")
    assert not test_eval("a.split()")
    assert test_eval("a and b")
    assert not test_eval("a.split and b")
    assert not test_eval("a and b.split()")
    assert test_eval("1 + 2")
    assert test_eval("[1,2]")
    assert test_eval("(1,2)")

# Generated at 2022-06-11 17:18:01.808448
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('1.0') == 1.0
    assert safe_eval('a', {"a": 42}) == 42
    assert safe_eval('a', {"a": True}) == True
    assert safe_eval('a', {"a": False}) == False
    assert safe_eval('a', {"a": "hello"}) == "hello"
    assert safe_eval('a+a', {"a": 42}) == 84
    assert safe_eval('a|bool', {"a": 42}) == True
    assert safe_eval('a|bool', {"a": []}) == False
    assert safe_eval('a|bool', {"a": [1]}) == True
    assert safe_eval('a|bool', {"a": ""}) == False

# Generated at 2022-06-11 17:18:08.961045
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This provides some basic tests around the safe_eval function.
    '''
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    if C.DEFAULT_DEBUG:
        import logging
        logger = logging.getLogger('jctanner.safe_eval')
        logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler(sys.stdout)
        logger.addHandler(ch)
        loader.set_basedir('/tmp')

    # Note: we run the basic test cases first, followed by the ones which
    #       have been moved to the complex test file (since they take so long)
    #
    # basic expressions
    #

# Generated at 2022-06-11 17:18:17.724687
# Unit test for function safe_eval
def test_safe_eval():
    # simple test of the safe_eval function
    def check_eval(expr, result):
        # Test both with and without CALL_ENABLED
        global CALL_ENABLED
        CALL_ENABLED = []
        e, _ = safe_eval(expr, include_exceptions=True)
        assert e == result, "safe_eval('%s') == %s, expected %s" % (expr, e, result)

        CALL_ENABLED = ['enumerate']
        e, _ = safe_eval(expr, include_exceptions=True)
        assert e == result, "safe_eval('%s') == %s, expected %s" % (expr, e, result)

    # Test the simple cases
    check_eval('1', 1)
    check_eval('1 + 1', 2)

    # Test raising an

# Generated at 2022-06-11 17:18:37.815457
# Unit test for function safe_eval
def test_safe_eval():
    """Test the safe_eval function"""
    # Evaluate some string expressions
    assert safe_eval("1 + 2") == 3
    assert safe_eval("(1 + 2) == 3") is True

    # Strings can be treated as list elements
    assert safe_eval("[1,2]+['a','b']") == [1, 2, 'a', 'b']

    # Unicode strings are excluded, since they can return arbitrary
    # objects
    with pytest.raises(Exception) as excinfo:
        safe_eval(u"{'a':1, 'b':2}")
    assert "invalid expression" in str(excinfo.value)

    # Objects can't be created, since we don't know what they might do
    with pytest.raises(Exception) as excinfo:
        safe_eval("object()")


# Generated at 2022-06-11 17:18:47.527070
# Unit test for function safe_eval
def test_safe_eval():
    # Add some builtins to our whitelist
    CALL_ENABLED.append('len')
    CALL_ENABLED.append('min')
    CALL_ENABLED.append('max')
    CALL_ENABLED.append('any')
    CALL_ENABLED.append('all')
    # This eval should be safe
    assert safe_eval('x') == 'x'
    assert safe_eval('-x') == '-x'
    assert safe_eval('x + y') == 'x + y'
    assert safe_eval('x + 1') == 'x + 1'
    assert safe_eval('1 + x') == '1 + x'
    assert safe_eval('x - 1') == 'x - 1'
    assert safe_eval('1 - x') == '1 - x'

# Generated at 2022-06-11 17:18:57.645262
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-argument
    class LookupModule(object):
        def run(self, terms, variables, **kwargs):
            return {}

    original_method = sys.modules['ansible.plugins.lookup.tree'].LookupModule.run
    sys.modules['ansible.plugins.lookup.tree'].LookupModule.run = LookupModule.run

    # sanity check our function
    assert 'bar' == safe_eval('foo', dict(foo='bar'))
    assert 'bar' == safe_eval('foo', dict(foo='bar'), include_exceptions=True)[0]
    assert '{{ foo }}' == safe_eval('{{ foo }}')
    assert '{{ foo }}' == safe_eval('{{ foo }}', include_exceptions=True)[0]

    # test our function with

# Generated at 2022-06-11 17:19:06.912139
# Unit test for function safe_eval
def test_safe_eval():
    # common evaluation cases
    assert safe_eval('1 + 1') == 2
    assert safe_eval('"a" in foo') == "'a' in foo"

    # such evals should raise a defensive exception at the parser level
    for expr in [
        '__import__("os").system("echo hi")',
        '__import__("os").system("/bin/rm -rf /")',
        '__import__("sys").exit(1)',
        'exec("print 1")',
        'open("/etc/passwd").read()',
        'foo[open("/etc/passwd").read()]'
    ]:
        try:
            safe_eval(expr)
            assert False, "Expected Exception"
        except Exception as e:
            assert str(e) == "invalid expression (%s)" % expr

   

# Generated at 2022-06-11 17:19:16.394805
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[True]') == [True], 'safe_eval: did not correctly handle a correctly formatted list'
    assert safe_eval('[True, False]') == [True, False], 'safe_eval: did not correctly handle a correctly formatted list'
    assert safe_eval('{"string": "hello", "number": 1}') == {'number': 1, 'string': 'hello'}, 'safe_eval: did not correctly handle a correctly formatted dictionary'
    assert safe_eval('true') == True, 'safe_eval: did not correctly handle a correctly formatted boolean'
    assert safe_eval('false') == False, 'safe_eval: did not correctly handle a correctly formatted boolean'
    assert safe_eval('null') == None, 'safe_eval: did not correctly handle a correctly formatted null'

# Generated at 2022-06-11 17:19:27.063778
# Unit test for function safe_eval
def test_safe_eval():
    test_value = '{foo:"bar", "baz": true, "ansible": "cool"}'
    result = safe_eval(test_value, None)
    assert result == {u'foo': u'bar', u'baz': True, u'ansible': u'cool'}

    test_value = 'foo.bar()'
    result = safe_eval(test_value, None)
    assert result == test_value

    test_value = 'foo.bar().baz()'
    result = safe_eval(test_value, None)
    assert result == test_value

    test_value = 'foo.bar().baz(ham=spam, egg=nil)'
    result = safe_eval(test_value, None)
    assert result == test_value


# Generated at 2022-06-11 17:19:36.629866
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:43.678641
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:50.312300
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves.builtins import map # pylint: disable=redefined-builtin,import-error
    import ansible.errors
    import ansible.module_utils.common.json_utils
    import json
    import os
    import copy

    # We don't do "from ansible.parsing.yaml.loader import AnsilbeSafeLoader as SafeLoader" because in the unit tests
    # we have the yaml module installed and we don't need to use our custom AnsilbeSafeLoader.
    from ansible.parsing.yaml.loader import SafeLoader

    # These are all from the original safe_eval unit test, with the addition of testing with include_exceptions=True

# Generated at 2022-06-11 17:20:00.971392
# Unit test for function safe_eval
def test_safe_eval():
    '''
    basic test of safe_eval
    '''

    # Ensure that safe_eval does not evaluate a list comprehension,
    # which may execute arbitrary code
    result_tuple = safe_eval("[foo for foo in [1,2,3]]", {}, include_exceptions=True)
    result = result_tuple[0]
    exception = result_tuple[1]
    assert(type(result) == str)
    assert(exception is not None)

    # Ensure that safe_eval does not evaluate a dict comprehension,
    # which may execute arbitrary code
    result_tuple = safe_eval("{foo:foo for foo in [1,2,3]}", {}, include_exceptions=True)
    result = result_tuple[0]
    exception = result_tuple[1]

# Generated at 2022-06-11 17:20:37.210912
# Unit test for function safe_eval
def test_safe_eval():
    # Test non string values
    assert safe_eval(True, {}) is True
    assert safe_eval(False, {}) is False
    assert safe_eval(5, {}) == 5
    assert safe_eval(dict(a=1, b=2), {}) == dict(a=1, b=2)
    assert safe_eval(list(range(3)), {}) == [0, 1, 2]
    assert safe_eval(('abc', 'def'), {}) == ['abc', 'def']

    # Test string values
    assert safe_eval('True', {}) is True
    assert safe_eval('False', {}) is False
    assert safe_eval('5', {}) == 5
    assert safe_eval('dict(a=1, b=2)', {}) == dict(a=1, b=2)

# Generated at 2022-06-11 17:20:47.405834
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{ foo: { bar: [1, 2] }, baz: "ok" }'
    x = safe_eval(expr)
    assert isinstance(x, dict)
    assert len(x) == 2
    assert set(x.keys()) == set(('foo', 'baz'))
    assert isinstance(x['foo'], dict)
    assert isinstance(x['foo']['bar'], list)
    assert x['foo']['bar'] == [1, 2]
    assert x['baz'] == 'ok'

    expr = '[foo, bar]'
    x = safe_eval(expr)
    assert isinstance(x, list)
    assert set(x) == set(('foo', 'bar'))

    expr = "foo"
    x = safe_eval(expr)

# Generated at 2022-06-11 17:20:58.847726
# Unit test for function safe_eval
def test_safe_eval():

    # Before, this would raise an exception
    assert(safe_eval("foo", locals={'foo': 'bar'}) == 'bar')

    # Before, this would raise an exception
    assert(safe_eval("foo if foo else False", locals={'foo': 'bar'}) == 'bar')

    # Before, this would raise an exception
    assert(safe_eval("[]") == [])

    # Before, this would raise an exception
    assert(safe_eval("{}") == {})

    # Before, this would raise an exception
    assert(safe_eval("{'a': 'b'}") == {'a': 'b'})

    # Before, this would raise an exception
    assert(safe_eval("['a', 'b']") == ['a', 'b'])

    # Before, this would raise an exception

# Generated at 2022-06-11 17:21:05.898758
# Unit test for function safe_eval
def test_safe_eval():
    def check(expr, success=True):
        (value, exception) = safe_eval(expr, include_exceptions=True)
        if exception is None:
            if success:
                return
            else:
                print("UNEXPECTED SUCCESS: %s" % expr)
        else:
            if success:
                print("UNEXPECTED FAILURE: %s" % expr)
            else:
                return

    # Test that some bad things fail
    check('__import__("os").system("ls")', success=False)

    # Test that some good things pass
    check('{"a":1}')
    check('a == 1', locals={'a': 1})
    check('a == 1', locals=dict(a=1))

# Generated at 2022-06-11 17:21:14.783208
# Unit test for function safe_eval
def test_safe_eval():
    # These tests are only valid with Python 2.7.5 or newer.
    if sys.version_info[:3] < (2, 7, 5):
        return

    # Set CALL_ENABLED to a list of callables that are known as safe and that
    # work in the whitelist.  This is a problem with the whitelist approach
    # in general and further illustrates why this should be deprecated.
    #
    # Also, we do not want to re-enable getattr to prevent this from working:
    # "foo".__class__.__mro__[1].__subclasses__()
    #
    # Finally, we need to allow use of the 'object' class for creating
    # objects in Python3.
    CALL_ENABLED.extend(['object'])

# Generated at 2022-06-11 17:21:24.413972
# Unit test for function safe_eval
def test_safe_eval():
    # Test clearing of white-listed nodes
    safe_eval('[]')
    safe_eval('None')
    safe_eval('{}')
    safe_eval('True')
    safe_eval('False')
    safe_eval('true')
    safe_eval('null')
    safe_eval('2 + 2')
    safe_eval('2 - 2')
    safe_eval('2 * 2')
    safe_eval('2 / 2')
    safe_eval('-2')
    safe_eval('"foo"')
    safe_eval('["foo", "bar"]')
    safe_eval('["foo", "bar", 2 + 3]')

    # Test safety of passing local variables
    safe_eval('foo', {'foo': 'bar'})

    # Test remaining edge cases

# Generated at 2022-06-11 17:21:32.581210
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:42.075224
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:50.889201
# Unit test for function safe_eval
def test_safe_eval():

    # string should be returned unchanged
    result = safe_eval('{{ foo }}')
    assert result == '{{ foo }}'

    # list is returned as python list (not string)
    result = safe_eval('[1, 2, 3]')
    assert result == [1, 2, 3]

    # dictionary is returned as python dictionary (not string)
    result = safe_eval('{"one": 1, "two": 2, "three": 3}')
    assert result == {"one": 1, "two": 2, "three": 3}

    # string of a python list is returned as a list (instead of a string)
    result = safe_eval('["a", "b", "c"]')
    assert result == ["a", "b", "c"]

    # constant boolean values are converted into the corresponding Python values

# Generated at 2022-06-11 17:21:57.419014
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This method tests the safe_eval function thoroughly
    '''

    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.common.text.converters import container_to_text

    # list of tuples to test expression, expected result,
    # and whether an exception is to be expected or not

# Generated at 2022-06-11 17:22:49.671112
# Unit test for function safe_eval
def test_safe_eval():
    # Test container_to_text
    assert container_to_text(["foo", "bar"]) == "{'bar', 'foo'}"
    assert container_to_text({"foo", "bar"}) == "{'bar', 'foo'}"
    assert container_to_text({"foo": "bar"}) == "{'foo': 'bar'}"
    assert container_to_text({"foo": "bar", "baz": "qux"}) == "{'baz': 'qux', 'foo': 'bar'}"
    assert container_to_text({"foo": {"bar": "baz", "qux": "quux"}}) == "{'foo': {'bar': 'baz', 'qux': 'quux'}}"

# Generated at 2022-06-11 17:22:59.018640
# Unit test for function safe_eval
def test_safe_eval():
    """Test that safe_eval doesn't allow code that shouldn't be allowed."""
    # Some simple correct expressions
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": 42}') == {"foo": 42}
    assert safe_eval('2 + 3') == 5
    assert safe_eval('(2, 3)') == (2, 3)
    assert safe_eval('2*3 + 5') == 11
    assert safe_eval('foo(bar)', locals={'foo': lambda x: x, 'bar': 42}) == 42
    # Empty expression
    assert safe_eval('') == ''
    # Byte string literals should not be interpreted as unicode
    assert safe_eval(b'b"foo"') == 'foo'

    # Wrong syntax

# Generated at 2022-06-11 17:23:09.637831
# Unit test for function safe_eval
def test_safe_eval():
    def assert_raises(msg):
        try:
            safe_eval(msg)
            raise AssertionError("safe_eval(%s) should have raised" % msg)
        except Exception:
            pass

    assert_raises("malicious_function()")
    assert_raises("builtins.file()")
    assert_raises("builtins.open()")
    assert_raises("var.keys()")
    assert_raises("var.values()")
    assert_raises("__import__('os').system('rm -rf /')")
    assert_raises("__import__('os').remove('/etc/passwd')")
    assert safe_eval("1 + 2") == 3
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
   

# Generated at 2022-06-11 17:23:17.475020
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:27.735676
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 - 1') == 1
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('foo', dict(foo=False)) is False
    assert safe_eval('foo', dict(foo=True)) is True
    assert safe_eval('foo', dict(foo=None)) is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('foo', dict(foo=[1, 2, 3])) == [1, 2, 3]