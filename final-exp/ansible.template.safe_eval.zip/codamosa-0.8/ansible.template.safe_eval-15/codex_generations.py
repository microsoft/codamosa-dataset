

# Generated at 2022-06-11 17:13:36.536002
# Unit test for function safe_eval
def test_safe_eval():
    # disable this test for Python 2.6
    if sys.version_info < (2, 7):
        return

    # test for certain exceptions
    # This test must be run with Python 2.6 because Python 2.6 does not support
    # raising from within an except clause.
    if sys.version_info >= (2, 7):
        try:
            safe_eval('__import__("os")')
            assert False
        except Exception as e:
            assert isinstance(e, Exception)

        try:
            safe_eval('[x for x in range(100)]')
            assert False
        except Exception as e:
            assert isinstance(e, Exception)

        try:
            safe_eval('(x for x in range(100))')
            assert False
        except Exception as e:
            assert isinstance(e, Exception)

# Generated at 2022-06-11 17:13:44.583217
# Unit test for function safe_eval

# Generated at 2022-06-11 17:13:55.469225
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_bytes, to_text
    from sys import version_info

    def to_str(x):
        # Cope with different Python 3 versions, where encoding defaults changed
        # This is needed for Python 3.4 through to Python 3.6 inclusive
        if version_info[0] == 3 and version_info[1] < 7:
            default_encoding = sys.getdefaultencoding()
            if default_encoding == 'utf-8':
                return to_text(x)
        return to_text(x, encoding='unicode_escape')

    def test(expr, expected_result, expected_type, **kwargs):

        if "locals" in kwargs:
            local_copy = kwargs["locals"].copy()

# Generated at 2022-06-11 17:14:06.291122
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:14.608963
# Unit test for function safe_eval
def test_safe_eval():

    def test_safe_eval_nodes(expr):
        builtins_dict = {}
        for e in dir(__builtins__):
            builtins_dict[e] = getattr(__builtins__, e)
        OUR_GLOBALS = {
            '__builtins__': builtins_dict,  # avoid global builtins as per eval docs
            'false': False,
            'null': None,
            'true': True,
            # also add back some builtins we do need
            'True': True,
            'False': False,
            'None': None
        }

        # this is the whitelist of AST nodes we are going to
        # allow in the evaluation. Any node type other than
        # those listed here will raise an exception in our custom
        # visitor class defined below.

# Generated at 2022-06-11 17:14:22.921218
# Unit test for function safe_eval
def test_safe_eval():
    class TestNodeVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            if type(node) in set((ast.List, ast.Expression, ast.Tuple, ast.Set)):
                print("Node type %s:" % type(node).__name__)
                print(ast.dump(node))

    # safe_eval accepts either string or list as input
    # (used mainly by with_items to take in both)
    data_str = '[1, 2, 3]'
    # the following should fail, but we allow it because the
    # string wrapper is caught by CleansingNodeVisitor
    data_str_list = '[1, 2, 3, [4, "oops"]]'
    data_list = [1, 2, 3, [4, "oops"]]

# Generated at 2022-06-11 17:14:34.014348
# Unit test for function safe_eval
def test_safe_eval():
    # Assert that we can safely eval a number of whitelisted expressions
    # (but not more complex ones like assignments, method calls, etc.)
    #
    # Note: This test pattern differs from how ansible.module_utils.common.utils
    # uses safe_eval, but we're testing the evaluation of strings, not already
    # parsed python data structures.
    #
    # TODO: is there a better way to do this?
    safe_eval('True')
    safe_eval('False')
    safe_eval('None')
    safe_eval('true')
    safe_eval('false')
    safe_eval('null')
    safe_eval('1 + 2')
    safe_eval('1 + 2 * 3')
    safe_eval('1 + 2 + 3')
    safe_eval('(1 + 2) * 3')


# Generated at 2022-06-11 17:14:46.160990
# Unit test for function safe_eval
def test_safe_eval():
    # Tests of safe eval. These should work.
    assert not safe_eval("foo.bar(baz)", dict(foo=dict(bar='x')))
    assert not safe_eval("foo.bar(baz)", dict(foo=dict(bar='x', baz=1)))
    assert safe_eval("foo.bar(baz)", dict(foo=dict(bar='x', baz=1)), include_exceptions=True) == (None, None)
    assert safe_eval("foo.bar(baz)", dict(foo=dict(bar='x')), include_exceptions=True) == (None, None)
    assert safe_eval("foo.bar(baz)", dict(foo=dict(bar='x')), include_exceptions=True) == (None, None)

# Generated at 2022-06-11 17:14:49.748108
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('"[1,2]"' ) == '[1,2]'
    assert safe_eval('[1,2] + [3,4]') == [1, 2, 3, 4]
    assert safe_eval('{"a":1}') == {'a': 1}
    assert safe_eval('''
    {% if True %}
        "True"
    {% else %}
        "False"
    {% endif %}
    ''') == "True"


# Generated at 2022-06-11 17:14:57.286660
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test some known good and bad syntaxes.
    '''

    # test some known good expressions

# Generated at 2022-06-11 17:15:07.839528
# Unit test for function safe_eval
def test_safe_eval():
    """
    This should be used with nose to test the safe_eval function
    """
    import os
    import json

    expressions = ['true', 'false', 'null',
                   '42',
                   '4.2',
                   '"42"',
                   '"4.2"',
                   '[]',
                   '{}',
                   '["test", "a_string"]',
                   '{"test": "a_string"}',
                   '["test", 42, null, false]',
                   '{"test": 42, "foo": null, "bar": false}',
                   ]

# Generated at 2022-06-11 17:15:17.387771
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:27.383424
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:36.988784
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("1 + 1", locals={'1': 2}) == 3
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']
    assert safe_eval("{'foo': 'bar', 'baz': 'buz'}") == {'foo': 'bar', 'baz': 'buz'}
    assert safe_eval("['foo', 'bar', 'baz']", locals={'1': 2}) == ['foo', 'bar', 'baz']

# Generated at 2022-06-11 17:15:45.666253
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("ansible_host.split('.')[0]", locals=dict(ansible_host='127.0.0.1')) == '127'
    assert safe_eval("{{ foo }}", locals=dict(foo='bar')) == 'bar'
    assert safe_eval("{{ foo }}") == '{{ foo }}'
    assert safe_eval("{{ foo.strip() }}") == '{{ foo.strip() }}'
    assert safe_eval("{{ foo.strip().split(',') }}") == '{{ foo.strip().split(",") }}'
    assert safe_eval("{{ foo }}", locals=dict(foo='127.0.0.1')) == '127.0.0.1'

# Generated at 2022-06-11 17:15:55.721295
# Unit test for function safe_eval
def test_safe_eval():

    try:
        safe_eval('''
[
    with_items:
        - {{ a }}
]
''')

        raise Exception('Should have thrown an exception')
    except Exception:
        pass

    assert 42 == safe_eval('42')

    if C.DEFAULT_KEEP_REMOTE_FILES:
        d = {'hostvars': {'localhost': {'inventory_hostname': 'localhost'}}}
        assert '/tmp/ansible-tmp-local.123' == safe_eval('''
{{ '/tmp/ansible-tmp-local.%s'|format(
    hostvars['localhost'].ansible_local.temp_dir.pid) }}
''', d)


# Generated at 2022-06-11 17:16:06.667508
# Unit test for function safe_eval
def test_safe_eval():
    mock_locals = {
        'foo': 'bar',
        'test_var': 1,
        'test_var2': 2,
        'test_var3': 3,
    }

    def test_expr(expr, result):
        assert safe_eval(expr, locals=mock_locals) == result
        assert safe_eval(expr, locals=mock_locals, include_exceptions=True)[0] == result
        assert isinstance(safe_eval(expr, locals=mock_locals, include_exceptions=True)[1], Exception) == False

    test_expr('[1]', [1])
    test_expr('(1 in [1])', True)
    test_expr('(2 in [1])', False)
    test_expr('test_var', 1)

# Generated at 2022-06-11 17:16:15.779472
# Unit test for function safe_eval
def test_safe_eval():
    from ansible import constants as C

    # Test with string type

# Generated at 2022-06-11 17:16:24.168203
# Unit test for function safe_eval
def test_safe_eval():

    # define unit test parameters
    safe_test_expr = "{{ [1,2,3,4] | map('int') | sum }}"
    safe_test_locals = {"ansible_version": "2.2.0.0"}
    safe_test_expected = 10
    safe_test_msg = 'safe_eval: int sum of list'

    # perform test
    try:
        safe_result = safe_eval(safe_test_expr, safe_test_locals, include_exceptions=True)
        assert safe_result[0] == safe_test_expected
        assert safe_result[1] is None
        print(safe_test_msg + " : ok")
    except AssertionError as e:
        print(safe_test_msg + " : FAILED: " + str(e))

# Generated at 2022-06-11 17:16:34.705482
# Unit test for function safe_eval
def test_safe_eval():
    # This tests the success cases (should not raise exception)
    safe_eval("[]")
    safe_eval("[1, 2, 3]")
    safe_eval("{}")
    safe_eval("{'a': 1, 'b': 2}")
    safe_eval("'a string'")
    safe_eval("1 + 1")
    safe_eval("1 + 1 * 3")
    safe_eval("(1 + 1) * 3")
    safe_eval("1 + (1 + 1) * 3")
    safe_eval("0 - 1")
    safe_eval("1 * -3")
    safe_eval("1 in [1, 2, 3]")
    safe_eval("{'a': 1}['a']")
    safe_eval("{'a': 1}.get('a')")
    safe_

# Generated at 2022-06-11 17:16:49.254345
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:59.191524
# Unit test for function safe_eval
def test_safe_eval():
    # Testing this function with various inputs and asserts
    # based on what is expected to be returned as a result.
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo == "foo"')
    assert not safe_eval('foo == "bar"')
    assert safe_eval('3+7') == 10
    assert safe_eval('3+7') != 3
    assert safe_eval('7*2') == 14
    assert safe_eval('7*2') != 7
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('[1,2,3]') != [1,2,4]
    assert safe_eval('{"a": "b"}') == {"a": "b"}

# Generated at 2022-06-11 17:17:10.295231
# Unit test for function safe_eval
def test_safe_eval():
    """Test safe_eval function in module utils/template.py"""
    record = {'b': 'bbb'}

# Generated at 2022-06-11 17:17:18.990195
# Unit test for function safe_eval
def test_safe_eval():

    def _test_eval_success(actual, expected):
        result, err = safe_eval(actual, include_exceptions=True)
        assert result == expected
        assert err is None

    def _test_eval_fail(actual):
        result, err = safe_eval(actual, include_exceptions=True)
        assert result == actual
        assert isinstance(err, Exception)

    # Test builtin functions.
    _test_eval_success('abs(-1)', 1)
    _test_eval_success('bool(0)', False)
    # _test_eval_fail('divmod(5,2)')

    # Test invalid builtin functions
    _test_eval_fail('set(1)')
    _test_eval_fail('pow(1,2)')

# Generated at 2022-06-11 17:17:27.946249
# Unit test for function safe_eval
def test_safe_eval():

    # This should return True
    assert safe_eval('1 is 1')

    # This should be a syntax error
    try:
        safe_eval('1 is')
    except SyntaxError:
        pass
    else:
        assert False

    # This should raise a custom exception
    try:
        safe_eval('a')
    except Exception as e:
        assert 'invalid expression' in to_native(e)
    else:
        assert False

    # This should raise a custom exception
    try:
        safe_eval('str(1)')
    except Exception as e:
        assert 'invalid expression' in to_native(e)
    else:
        assert False

    # This should return 2
    assert safe_eval('1 + 1')

    # This should return 2, the Call node is allowed.
    assert safe_

# Generated at 2022-06-11 17:17:34.254094
# Unit test for function safe_eval
def test_safe_eval():
    """Tests for function safe_eval"""

    ###
    # Test for expression
    ###

# Generated at 2022-06-11 17:17:43.633631
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('value') == 'value'
    assert safe_eval('a + b', dict(a=1, b=3)) == 4
    assert safe_eval('value', dict(value=4)) == 4
    assert safe_eval('dict(a=1, b=2)') == {'a': 1, 'b': 2}
    assert safe_eval('list(a=1, b=2)') == ['a', 'b']
    assert safe_eval('value', dict(), include_exceptions=True) == ('value', None)
    assert safe_eval('{1: 2}', dict(), include_exceptions=True) == ({1: 2}, None)
    assert safe_eval('a + b', dict(a=1, b=3), include_exceptions=True) == (4, None)
    assert safe

# Generated at 2022-06-11 17:17:53.765617
# Unit test for function safe_eval
def test_safe_eval():
    pass_tests = [
        '1',
        '1 + 1',
        (1, 2, 3),
        [1, 2, 3],
        {'a': 1, 'b': 2},
        ['a', 1, 'b', 2],
        'string'
    ]
    for test_str in pass_tests:
        res = safe_eval(test_str, dict(foo='bar'), include_exceptions=True)
        assert res == (ast.literal_eval(test_str), None)

    fail_tests = [
        '1 + foo',
        'foo',
        'foo + 1',
        '__builtins__.__import__("os").system("halt")',
        '__builtins__.__import__("os").system("halt")',
    ]

# Generated at 2022-06-11 17:18:01.778000
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[{}]') == [{}]
    assert safe_eval('{}') == {}
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('1+1') == 2
    assert safe_eval('(1+1)') == 2
    assert safe_eval('-1') == -1
    assert safe_eval('-1') == -1
    assert safe_eval('1 + -1') == 0
    assert safe_eval('1 + -1') == 0
    assert safe_eval('2+2') == 4
    assert safe_eval('1 + 2+3') == 6

# Generated at 2022-06-11 17:18:08.961597
# Unit test for function safe_eval
def test_safe_eval():
    # basic test
    c = safe_eval("6 + 2")
    assert type(c) is int and c == 8

    # list concatenation
    c = safe_eval("[1,2] + [3,4]")
    assert type(c) is list and c == [1,2,3,4]

    # dict creation
    c = safe_eval("{'a':1, 'b':2}")
    assert type(c) is dict and c == {'a':1, 'b':2}

    # dict access
    c = safe_eval("{'a':1, 'b':2}['a']")
    assert type(c) is int and c == 1

    # dict access with variable

# Generated at 2022-06-11 17:18:28.639076
# Unit test for function safe_eval
def test_safe_eval():
    # regular use cases
    failed_cases = []

# Generated at 2022-06-11 17:18:37.707181
# Unit test for function safe_eval
def test_safe_eval():

    def run_assertion(expr, result=None):
        if result:
            assert safe_eval(expr) == result
        else:
            assert safe_eval(expr)

    # Test basic expression
    run_assertion('True')
    run_assertion('True and not False')
    run_assertion('1 + 2 == 3')
    run_assertion('[1, 2, 3]')

    # Test local variable usage
    run_assertion('a_list_variable', [1, 2, 3])

    # Don't allow creation of new variables
    try:
        safe_eval('new_variable = 1')
    except Exception as e:
        print("Caught exception as expected: {e}".format(e=e))
    else:
        print("Did not catch expected exception")
        sys.exit(1)

# Generated at 2022-06-11 17:18:47.388352
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    # Evaluate 'None'
    assert safe_eval("None") is None
    # Evaluate to 'True'
    assert safe_eval("True") is True
    # Evaluate to '3 + 4'
    assert safe_eval("3 + 4") == 7
    # Evaluate to '3 + 4 / 2'
    assert safe_eval("3 + 4 / 2") == 5
    # Evaluate to '3 + 4 * 2'
    assert safe_eval("3 + 4 * 2") == 11
    # Evaluate to '5 * 1 // 2'
    assert safe_eval("5 * 1 // 2") == 2
    # Evaluate to '5 * 1 - 2'
    assert safe_eval("5 * 1 - 2") == 3
    # Evaluate to '5 * 1 - 2 / 1'
    assert safe_

# Generated at 2022-06-11 17:18:57.517007
# Unit test for function safe_eval
def test_safe_eval():
    # Python 3.2 doesn't have assertRaisesRegexp, so we use a context manager instead
    class assertRaisesContext(object):
        def __init__(self, expected_exception, expected_regexp=None):
            self.expected_exception = expected_exception
            self.expected_regexp = expected_regexp

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            if exc_type is None:
                raise AssertionError("{0} not raised".format(self.expected_exception.__name__))

            if not issubclass(exc_type, self.expected_exception):
                return False # re-raise exception

            if self.expected_regexp is None:
                return True

           

# Generated at 2022-06-11 17:19:06.791378
# Unit test for function safe_eval
def test_safe_eval():

    # 1. Enable all call functions
    CALL_ENABLED.append('some_function')

    # 2. Try a simple expression
    expr = '"a" + "b"'
    result = safe_eval(expr)
    assert result == 'ab'

    # 3. Try a complex expression
    expr = '[a for a in [1, 2, 3]] + ["a", "b", "c"]'
    result = safe_eval(expr)
    assert result == [1, 2, 3, 'a', 'b', 'c']

    # 4. Try a constant expression
    expr = '1+1'
    result = safe_eval(expr)
    assert result == 2

    # 5. Try a invalid operation, should throw an exception.
    expr = '{"a": "b"}["b"]'

# Generated at 2022-06-11 17:19:16.276775
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:26.885302
# Unit test for function safe_eval
def test_safe_eval():
    # Basic syntax and types
    assert safe_eval('True') is True
    assert safe_eval('true') is True
    assert safe_eval('True and False') is False
    assert safe_eval('false or false') is False
    assert safe_eval('true and True') is True
    assert safe_eval('None') is None
    assert safe_eval('null') is None
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_eval('1') == 1
    assert safe_eval('2.2') == 2.2
    assert safe_eval('"1"') == '1'
    assert safe_eval('"a"') == 'a'
    assert safe_eval('["foo","bar"]') == ['foo','bar']
    assert safe_eval('{"foo":"bar"}')

# Generated at 2022-06-11 17:19:36.483076
# Unit test for function safe_eval
def test_safe_eval():
    # The goal of this function is to avoid accidental execution of
    # rogue python code which would allow access to any python function, class,
    # factory, etc.
    #
    # Although we perform additional filtering of builtins in safe_eval,
    # we add a simple whitelist of callables here as a simple way to
    # ensure we only allow vetted functions
    CALL_ENABLED.extend(['str', 'any', 'all', 'lists', 'dicts', 'tuples'])

    # We need to allow regexes for use with the regex_replace filter, e.g.
    # regex_replace:
    #    path: /etc/file
    #    regexp: 'regex'
    #    replace: 'replacement'
    # TODO: This is a temporary solution until we move to a safer templating
    # system

# Generated at 2022-06-11 17:19:43.606662
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('a_list_variable', dict(a_list_variable=[])) == []
    assert safe_eval('2*2') == 4
    assert safe_eval('a_dict["string key"]') == 'a_dict["string key"]'
    assert safe_eval('a_dict["string key"]', dict(a_dict={'string key': 'value'})) == 'value'
    assert safe_eval('a_list[1]') == 'a_list[1]'
    assert safe_eval('a_list[1]', dict(a_list=[1, 2, 3])) == 2
    assert safe_eval('a_list[-1]', dict(a_list=[1, 2, 3])) == 3


# Generated at 2022-06-11 17:19:50.264070
# Unit test for function safe_eval
def test_safe_eval():
    # Test some safe functions
    if sys.version_info[0] < 3:
        # assert is not a keyword in Python 2.6
        safe_eval('foo')
    assert safe_eval('[]') == []
    assert safe_eval('dict()') == {}
    assert safe_eval('foo = "bar"') == 'bar'
    assert safe_eval('foo', {'foo': 'bar'}) == 'bar'
    assert safe_eval('foo.bar', {'foo': {'bar': 'baz'}}) == 'baz'
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo', {'foo': 1}) == 1
    assert safe_eval('foo', {'foo': 1.2}) == 1.2

# Generated at 2022-06-11 17:20:05.997266
# Unit test for function safe_eval
def test_safe_eval():

    # test string results
    e = None
    s = safe_eval("foo", include_exceptions=True)
    assert s == ("foo", e)

    e = Exception("invalid function: %s" % "foo")
    s = safe_eval("foo(1)", include_exceptions=True)
    assert s == ("foo(1)", e)

    s = safe_eval("\"foo(1)\"", include_exceptions=True)
    assert s == ("foo(1)", e)

    s = safe_eval("'foo(1)'", include_exceptions=True)
    assert s == ("foo(1)", e)

    e = Exception("invalid expression (foo())")
    s = safe_eval("foo()", include_exceptions=True)
    assert s == ("foo()", e)

    e = None

# Generated at 2022-06-11 17:20:15.738325
# Unit test for function safe_eval
def test_safe_eval():
    # These tests should pass
    assert safe_eval("1") == 1
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("[1, 2, 3, 4]") == [1, 2, 3, 4]
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar", locals={'foo': {'bar': 'baz'}}) == "baz"
    assert safe_eval("foo.bar", locals={'foo': {'bar': [1, 2]}})[1] == 2
    assert safe_eval("foo[1]", locals={'foo': ['foo', 'bar']}) == 'bar'
    assert safe_eval("1 + 2 + 3") == 6

# Generated at 2022-06-11 17:20:22.862351
# Unit test for function safe_eval
def test_safe_eval():
    # Test data
    # Good expressions
    e1 = '1'
    e2 = '1 + 1'
    e3 = '1 - 1'
    e4 = '1 * 1'
    e5 = '1 / 1'
    e6 = '1.0 + 1.1'
    e7 = '1.0 - 1.1'
    e8 = '1.0 * 1.1'
    e9 = '1.0 / 1.1'
    e10 = '1 + 1.1'
    e11 = '1 - 1.1'
    e12 = '1 * 1.1'
    e13 = '1 / 1.1'
    e14 = 'True + True'
    e15 = 'True - True'
    e16 = 'True * True'

# Generated at 2022-06-11 17:20:29.579129
# Unit test for function safe_eval
def test_safe_eval():
    '''
    >>> test_safe_eval()
    True
    '''

# Generated at 2022-06-11 17:20:38.676158
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    test_methods = {
        'safe_eval': safe_eval
    }

    test_locals = {
        'easy': 9,
        'simple': 'bob',
        'string': 'hello world',
        'callable_func': lambda x: x * 9,
        'callable_obj': CallableOne(),
        'not_callable': 'bob',
        'a_list': ['a', 'b', 'c'],
        'a_tuple': ('a', 'b', 'c'),
        'a_dict': {'a': '1', 'b': '2', 'c': '3'},
    }

    test_globals = {
        'True': True,
        'False': False,
        'None': None,
    }


# Generated at 2022-06-11 17:20:46.176993
# Unit test for function safe_eval
def test_safe_eval():
    some_list = ['foo', 'bar', 'baz']
    result, exception = safe_eval('a_list_variable', locals={'a_list_variable': some_list}, include_exceptions=True)
    assert exception is None, 'Expected no exception'
    assert some_list == result, 'Expected result to be %s, got %s instead' % (some_list, result)
    result, exception = safe_eval('[-1, -2, -3]', locals={}, include_exceptions=True)
    assert exception is None, 'Expected no exception'
    assert [-1, -2, -3] == result, 'Expected result to be [-1, -2, -3], got %s instead' % (result,)

# Generated at 2022-06-11 17:20:57.960730
# Unit test for function safe_eval
def test_safe_eval():

    LOCALS_1 = {'a': 10, 'b': 20, 'foo': 'bar', 'list': [1, 2, 3], 'dict': {'a': 10, 'b': 20}}
    json_data = {'a': 10, 'b': 20, 'foo': 'bar', 'list': [1, 2, 3], 'dict': {'a': 10, 'b': 20}}
    json_string = '{"a": 10, "b": 20, "foo": "bar", "list": [1, 2, 3], "dict": {"a": 10, "b": 20}}'
    json_boolean = True
    json_none = None
    json_string_none = 'None'
    json_string_true = 'True'
    json_string_false = 'False'

# Generated at 2022-06-11 17:21:05.449645
# Unit test for function safe_eval
def test_safe_eval():
    source = "ansible_hostname in groups['webservers']"
    # Test safe eval, inside_call is false
    result = safe_eval(source, {'groups': {'webservers': ['a', 'b']}})
    assert result
    # Test safe eval, inside_call is true
    result = safe_eval("str(x) in ['a', 'b']", {'x': 'a'}, include_exceptions=True)
    assert result[0]
    # Test safe eval, inside_call is false
    result = safe_eval("str(x) in ['a', 'b']", {'x': 'c'}, include_exceptions=True)
    assert not result[0]
    # Test safe eval, inside_call is true

# Generated at 2022-06-11 17:21:14.573352
# Unit test for function safe_eval
def test_safe_eval():
    # test safe evaluation of various data structures
    assert safe_eval("[1,2,3]") == ast.literal_eval("[1,2,3]")
    assert safe_eval("{'a': 'dict', 'b': {'c': 'nested'}}") == ast.literal_eval("{'a': 'dict', 'b': {'c': 'nested'}}")
    assert safe_eval("1+2") == 3
    assert safe_eval("1+2", include_exceptions=True)[0] == 3

    # test unsafe evaluation
    assert safe_eval("1+__import__('os').system('echo hi')") == 1
    assert isinstance(safe_eval("1+__import__('os').system('echo hi')", include_exceptions=True)[1], Exception)

    # test safe

# Generated at 2022-06-11 17:21:24.413166
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3,4]') == [1,2,3,4]
    assert safe_eval('{"a":1}') == {'a': 1}
    assert safe_eval('"a string"') == "a string"

    # These should fail
    assert safe_eval('[1,2,3,4]()') == "[1,2,3,4]()"
    assert safe_eval('(2+2)*5') == "(2+2)*5"
    assert safe_eval('{"a":1}()') == '{"a":1}()'
    assert safe_eval('{"a":1}["a"]()') == '{"a":1}["a"]()'
    assert safe_eval('1+1') == '1+1'

# Generated at 2022-06-11 17:21:49.190815
# Unit test for function safe_eval
def test_safe_eval():
    # simple case
    assert safe_eval('CONFIG_STRING') == None
    # dict type
    assert safe_eval('dict(changed=True)') == {'changed': True}
    # simple case
    assert safe_eval('CONFIG_STRING') == None
    # dict type
    assert safe_eval('dict(changed=True)') == {'changed': True}
    # dict type with string value
    assert safe_eval('dict(changed="yes")') == {'changed': 'yes'}
    # dict with constant value
    assert safe_eval('dict(changed=True)') == {'changed': True}
    # dict with variable value
    assert safe_eval('dict(changed=changed)', dict(changed='yes')) == {'changed': 'yes'}
    # dict with variable value, explicit

# Generated at 2022-06-11 17:21:56.719169
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:05.653416
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval(u"{u'a': 1, u'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval(u"{u'a': 1, u'b': 2}", include_exceptions=True)[0] == {'a': 1, 'b': 2}
    assert safe_eval(u"[u'a', u'b']") == [u'a', u'b']
    assert safe_eval(u"[u'a', u'b']", include_exceptions=True)[0] == [u'a', u'b']
    assert safe_eval

# Generated at 2022-06-11 17:22:16.250788
# Unit test for function safe_eval
def test_safe_eval():

    # set list of functions to allow
    global CALL_ENABLED
    CALL_ENABLED = ['len']

    # test a valid expression
    expr = '1 + 2'
    result = safe_eval(expr)
    assert(result == 3)

    # test a valid expression with a builtin function
    expr = 'len(foo)'
    locals = {'foo': [1, 2, 3]}
    result = safe_eval(expr, locals)
    assert(result == 3)

    # test an invalid expression
    expr = '__builtins__.open("/etc/passwd").read()'
    result = safe_eval(expr)
    assert(result == expr)

    # test an invalid function
    expr = 'foo.bar()'
    locals = {'foo': 'bar'}
    result = safe_eval

# Generated at 2022-06-11 17:22:26.679252
# Unit test for function safe_eval
def test_safe_eval():
    # the safe_eval() function should take a string expression
    # and return the evaluated data structure

    # when given a non string argument, it should
    # just return the argument
    a_list = ["Hello", "World"]
    assert safe_eval(a_list) == a_list

    # when given a non-evaluable data structure, it should return
    # the data structure as-is
    assert safe_eval("{{ myvar }}") == "{{ myvar }}"
    assert safe_eval("{{ myvar }}") == "{{ myvar }}"

    assert safe_eval("{'foo': 'bar'}") == "{'foo': 'bar'}"
    assert safe_eval("a_list") == "a_list"

    # it should allow lookups in the locals dictionary
    myvar = "bar"
    assert safe_eval

# Generated at 2022-06-11 17:22:37.379293
# Unit test for function safe_eval
def test_safe_eval():

    class TestModule(object):
        '''
        This is needed to make some Jinja2 objects work in the test cases.
        '''
        def __init__(self):
            self.params = {}

    tm = TestModule()

    assert safe_eval("a + b", dict(a=1, b=2)) == 3
    assert safe_eval("a + b", dict(a=1, b="2")) == "12"
    assert safe_eval("a + b", dict(a=1, b='"2"')) == '1"2"'
    assert safe_eval("a + b", dict(a=1, b='u"2"')) == '1u"2"'
    assert safe_eval("a + b", dict(a=1, b='u"foo"')) == '1u"foo"'

# Generated at 2022-06-11 17:22:47.337522
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from nose.tools import assert_equal, assert_raises  # type: ignore
        from nose import SkipTest  # type: ignore
    except:
        raise SkipTest("nose not installed")
    assert_equal(safe_eval("2+2"), 4)
    assert_equal(safe_eval("2**3"), 8)
    assert_equal(safe_eval("a_list_variable", dict(a_list_variable=[1, 2])), [1, 2])
    assert_equal(safe_eval("a_dict_variable", dict(a_dict_variable=dict(a=1))), dict(a=1))
    assert_equal(safe_eval("[]", dict(a_dict_variable=dict(a=1))), [])

# Generated at 2022-06-11 17:22:56.810843
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    def _my_func(arg):
        return True

    # These should all pass without exception
    safe_eval("2+2")
    safe_eval("_my_func('arg')")
    safe_eval("{0: 'a', '1': 'b'}")
    safe_eval("[1,2,3]")
    safe_eval("(1,2,3)")
    safe_eval("2+2==4")
    safe_eval("True")
    safe_eval("'a'")
    safe_eval("(2+2)==4")
    safe_eval("null")
    safe_eval("false")
    safe_eval("True")
    safe_eval("2*2")
    safe_eval("10/5")
    safe_eval("2-2")
   

# Generated at 2022-06-11 17:23:03.490948
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:13.934321
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, expected):
        assert expected == safe_eval(expr)

    # expr, expected result
    _test("1 + 2", 3)
    _test("a + b", "a + b")
    _test("a + b", "a + b")
    _test("a and b", "a and b")
    _test("a.b", "a.b")
    _test("1 + 2 + a", "1 + 2 + a")
    _test("a | b", "a | b")
    _test("a or b", "a or b")
    _test("[1, 2]", [1, 2])
    _test("{'a': 1, 'b': 'foo'}", {'a': 1, 'b': 'foo'})