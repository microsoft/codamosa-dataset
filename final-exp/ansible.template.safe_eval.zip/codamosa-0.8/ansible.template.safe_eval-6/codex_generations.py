

# Generated at 2022-06-11 17:13:41.584001
# Unit test for function safe_eval
def test_safe_eval():
    """
    >>> test_safe_eval()
    0
    """
    # imports were being redefined in doctests in earlier versions of python.
    # now this is fixed, so we can use proper imports here.
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None

    def test_tests(tests, value, include_exceptions=False):
        '''
        Run a set of tests, where value is the expected result, and
        tests is a list of tuples containing the test expression and
        the expected exception (if include_exceptions is True).
        '''
        for test in tests:
            if len(test) == 1:
                expr = test[0]
                exp_exc = None
            else:
                expr, exp_exc = test

            if include_exceptions:
                value,

# Generated at 2022-06-11 17:13:52.983724
# Unit test for function safe_eval
def test_safe_eval():
    def check_exception(expr, msg):
        try:
            safe_eval(expr)
        except Exception as e:
            if msg not in to_native(e):
                print("UNEXPECTED ERROR: {}".format(to_native(e)))
            return
        # If we get here, we didn't raise an exception
        print("UNEXPECTED SUCCESS: {}".format(expr))

    # These should not raise an exception
    safe_eval("10")
    safe_eval("-10")
    safe_eval("10 + -10")
    safe_eval("10 + 2 * 6")
    safe_eval("-(10 + 2) * 6")
    safe_eval("True")
    safe_eval("False")
    safe_eval("None")
    safe_eval("1 == 1")
    safe_eval

# Generated at 2022-06-11 17:13:59.646432
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:07.759454
# Unit test for function safe_eval
def test_safe_eval():
    """Test the safe_eval function above.
    """
    # enable some safe calls that we need to do things like eval vars
    CALL_ENABLED.extend((
        'dict',
        'bool',
        'float',
        'int',
        'list',
        'str',
        'set',
        'tuple',
    ))

    assert safe_eval("""
        [item for item in [1,2,3] if item > 1]
    """) == [2,3]
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval("1 + 2 * 3") == 7
    assert safe_eval("(1 + 2) * 3") == 9
    assert safe_eval("input") == 'input'

# Generated at 2022-06-11 17:14:19.139375
# Unit test for function safe_eval
def test_safe_eval():
    # Test with a literal input
    assert safe_eval('5+5') == 10
    assert isinstance(safe_eval('5+5'), int)
    assert safe_eval('[1,2,3]+[4,5,6]') == [1, 2, 3, 4, 5, 6]
    assert isinstance(safe_eval('[1,2,3]+[4,5,6]'), list)

    # Test with a variable
    result = safe_eval('a_list_variable', dict(a_list_variable=[1,2,3]))
    assert result == [1, 2, 3]
    assert isinstance(result, list)

    # Test with an invalid expression
    result = safe_eval('a_list_variable.append(1)', dict(a_list_variable=[1,2,3]))

# Generated at 2022-06-11 17:14:27.983634
# Unit test for function safe_eval
def test_safe_eval():
    default_allowed = '''
    false
    true
    null
    {'a': 3, 'b': 5}
    [1,2,3,4]
    foo
    None
    True
    False
    'foo'
    [1,2,3]+[4,5]
    [1,2,3]-[4,5]
    [1,2,3]*2
    [1,2,3]/2
    -1
    -(1+2)
    '1+2'
    '''

    for d in default_allowed.split('\n'):
        d = d.strip()
        # Can be stripped entirely due to indentation
        if not d:
            continue

        assert safe_eval(d) == eval(d)

    # Ensure that these aren't valid
    #

# Generated at 2022-06-11 17:14:35.335467
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:47.091917
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("somevar") == "somevar"
    assert safe_eval("some_long_var") == "some_long_var"
    assert safe_eval("{{somevar}}") == "{{somevar}}"
    assert safe_eval(1) == 1

    assert safe_eval("somevar", dict(somevar=True)) is True
    assert safe_eval("somevar", dict(somevar=1)) == 1
    assert safe_eval("somevar", dict(somevar='foo')) == "foo"
    assert safe_eval("somevar", dict(somevar=1.2)) == 1.2

    assert safe_eval("1 + 2") == 3
    assert safe_eval("somevar + 1", dict(somevar=2)) == 3

    assert safe_eval("True") is True
    assert safe_eval

# Generated at 2022-06-11 17:14:53.567131
# Unit test for function safe_eval
def test_safe_eval():
    # Base test. Basic Python expression
    result_expr, exception = safe_eval("5 + 6", include_exceptions=True)
    assert '11' == result_expr and isinstance(exception, type(None))
    # Test error handling and reporting.
    result_expr, exception = safe_eval("5 + 6; print('Hello')",
                                        include_exceptions=True)
    assert isinstance(exception, Exception)
    assert 'Hello' != result_expr
    # Test for returning the expression in case of Parse Syntax Errors
    result_expr, exception = safe_eval("5 + 6; pprint('Hello')",
                                        include_exceptions=True)
    assert isinstance(exception, SyntaxError)
    assert '5 + 6; pprint(\'Hello\')' == result_expr

# Test to

# Generated at 2022-06-11 17:15:04.669430
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This can be run as a standalone script to test the safe_eval works as expected.
    '''

    def test_expr(expr):
        print('Expression: %s' % expr)
        if isinstance(expr, list):
            orig = [container_to_text(x) for x in expr]
            actual = safe_eval(expr)
            expected = orig
        else:
            orig = container_to_text(expr)
            actual = safe_eval(expr)
            expected = orig
        print('Actual  : %s' % actual)
        print('Expected: %s' % expected)
        if actual != expected:
            raise Exception('Test failed for %s' % expr)

    print('*** Testing safe_eval ***')

    # Valid
    test_expr('True')
    test_expr

# Generated at 2022-06-11 17:15:15.674524
# Unit test for function safe_eval
def test_safe_eval():

    # The safe_eval function is only used by the lookup module
    # Specifically, the lookup('template', filename) function
    # When the string is not a template, it is returned as is.
    # Hence, we expect ansible.poc.template to be returned.

    TEST_VALUE = 'ansible.poc.template'

    result, e = safe_eval(TEST_VALUE, include_exceptions=True)
    if result != TEST_VALUE:
        sys.stderr.write("safe_eval failed: Expected %s, got %s\n" % (TEST_VALUE, result))
        return False
    else:
        return True

# Generated at 2022-06-11 17:15:25.923190
# Unit test for function safe_eval
def test_safe_eval():

    # Test function to run safe_eval() with a set of data structures
    # and verify the output matches what we expect.
    def _test_safe_eval(data, expected_result, expected_type=None):
        result, exception = safe_eval(data, include_exceptions=True)
        if exception is not None:
            raise exception

        if expected_type is not None:
            assert isinstance(result, expected_type)

        assert result == expected_result

    # Test safe_eval for these data structures
    _test_safe_eval('foo', 'foo', str)
    _test_safe_eval('foo.bar', 'foo.bar', str)
    _test_safe_eval('', '', str)
    _test_safe_eval('{}', {}, dict)

# Generated at 2022-06-11 17:15:35.734901
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('True')
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') is None
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') is None
    assert safe_eval('{"a": 1}') == {"a": 1}

# Generated at 2022-06-11 17:15:42.846280
# Unit test for function safe_eval
def test_safe_eval():
    # test 1 should succeed
    rc, out = safe_eval("['foo','bar','baz'][0]", include_exceptions=True)
    assert rc == 'foo'
    assert out is None
    # test 2 should raise an exception
    rc, out = safe_eval("filters.join(',', ['foo','bar','baz'])", include_exceptions=True)
    assert rc == "filters.join(',', ['foo','bar','baz'])"
    assert out is not None
    assert isinstance(out, Exception)
    # test 3 should return a string
    rc, out = safe_eval("foo.bar()", include_exceptions=True)
    assert rc == 'foo.bar()'
    assert out is None
    # test 4 should return an integer

# Generated at 2022-06-11 17:15:53.900931
# Unit test for function safe_eval
def test_safe_eval():
    # Test with good
    assert safe_eval('1 + 2') == 3
    assert safe_eval('2 - 3') == -1
    assert safe_eval('2 * 5') == 10
    assert safe_eval('5 / 2') == 2.5
    assert safe_eval('3 ** 4') == 81
    assert safe_eval('4 ** 3') == 64
    assert safe_eval('True') == True

    # Test bad
    try:
        safe_eval('__import__("os").system("ls")')
        raise Exception("__import__ is not allowed in safe_eval()!")
    except Exception:
        pass

    # Test dict
    assert safe_eval("{'a': 1, 'b':2}") == {'a': 1, 'b':2}

# Generated at 2022-06-11 17:16:03.447346
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Make sure that the safe_eval function returns the expected results.
    '''

# Generated at 2022-06-11 17:16:13.710439
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:22.466615
# Unit test for function safe_eval
def test_safe_eval():
    # Test syntax errors
    assert safe_eval('1 +') == '1 +'
    assert safe_eval('1 + 2 *') == '1 + 2 *'

    # Test invalid expressions
    assert safe_eval('import os') == 'import os'
    assert safe_eval('1 + 2 for i in [1,2,3]') == '1 + 2 for i in [1,2,3]'
    assert safe_eval('open("/etc/passwd")') == 'open("/etc/passwd")'
    assert safe_eval('os.system("rm -rf /")') == 'os.system("rm -rf /")'

    # Test valid expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 * 2') == 3
    assert safe_eval('2 * 3 + 4')

# Generated at 2022-06-11 17:16:33.555818
# Unit test for function safe_eval
def test_safe_eval():
    failures = []

    # verify that the function works as expected
    if safe_eval("{{ a_list_variable }}", dict(a_list_variable=[])) != []:
        failures.append("failed to correctly evaluate a list")
    if safe_eval("{{ a_dict_variable }}", dict(a_dict_variable={})) != {}:
        failures.append("failed to correctly evaluate a dict")
    if safe_eval("{{ a_string_variable }}", dict(a_string_variable='hello')) != 'hello':
        failures.append("failed to correctly evaluate a string")
    if safe_eval("{{ a_string_variable }}", dict(a_string_variable=u'hello')) != u'hello':
        failures.append("failed to correctly evaluate a string")

# Generated at 2022-06-11 17:16:43.088981
# Unit test for function safe_eval
def test_safe_eval():
    # test assignment to a variable
    assert safe_eval('FOO = 1') == 1
    assert safe_eval('FOO = 1.0') == 1.0
    assert safe_eval('FOO = "1"') == "1"
    assert safe_eval('FOO = "1.0"') == "1.0"
    assert safe_eval('FOO = None') is None
    assert safe_eval('FOO = false') is False
    assert safe_eval('FOO = true') is True
    assert safe_eval('FOO = null') is None
    assert safe_eval('FOO = [1,2,3]') == [1,2,3]
    assert safe_eval('FOO = (1,2,3)') == (1,2,3)

# Generated at 2022-06-11 17:16:52.379922
# Unit test for function safe_eval
def test_safe_eval():

    # invalid literal for int() with base 10
    assert safe_eval("1 + 1 = 2") == "1 + 1 = 2"
    # unsupported operand type(s) for +: 'int' and 'unicode'
    assert safe_eval("1 + '1'") == "1 + '1'"

    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"

    # should be supported
    assert safe_eval("1 + 1") == 2
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo[0]") == "foo[0]"
    assert safe_eval("foo[bar]") == "foo[bar]"

# Generated at 2022-06-11 17:17:01.117336
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2+2") == 4
    assert safe_eval("a.replace('a', 'b')", locals={'a': "a"}) == 'b'
    assert safe_eval("a", locals={'a': 4}) == 4
    assert safe_eval("a", locals={'a': 'hello'}) == 'hello'
    assert safe_eval("a", locals={'a': True}) is True
    assert safe_eval("a", locals={'a': False}) is False
    assert safe_eval("a", locals={'a': None}) is None
    assert safe_eval("a", locals={'a': {"b": "c"}}) == {"b": "c"}
    assert safe_eval("a", locals={'a': ["b", "c", "d"]}) == ["b", "c", "d"]

# Generated at 2022-06-11 17:17:11.663956
# Unit test for function safe_eval
def test_safe_eval():
    # Can eval constant things
    assert safe_eval('{"a": 1, "b": 3.14, "c": "string", "d": true, "e": null}') == {'a': 1, 'b': 3.14, 'c': 'string', 'd': True, 'e': None}
    assert safe_eval('[1, 2.14, "string", false, null, ["a", {"b": 2}]]') == [1, 2.14, 'string', False, None, ['a', {'b': 2}]]

    # Can eval list and dictionary comprehensions
    assert safe_eval('[x + 1 for x in [1, 2, 3]]') == [2, 3, 4]
    assert safe_eval('[x + 1 for x in (1, 2, 3)]') == [2, 3, 4]


# Generated at 2022-06-11 17:17:20.804437
# Unit test for function safe_eval
def test_safe_eval():
    # Test that safe_eval accepts valid Python syntax
    assert safe_eval('(1 + 1) * 3') == 6

    # Test that safe_eval rejects invalid Python syntax
    try:
        safe_eval('(foo + 1) * 3')
    except Exception:
        # The syntax error was caught
        pass
    else:
        # The syntax error was not caught
        raise AssertionError('Safe eval did not catch syntax error.')

    # Test that safe_eval rejects dangerous functions
    try:
        safe_eval('open("/etc/passwd").read()')
    except Exception:
        # The call to the dangerous function was caught
        pass
    else:
        # The call to the dangerous function was not caught
        raise AssertionError('Safe eval did not catch dangerous call to open().')

    # Test that safe_eval does

# Generated at 2022-06-11 17:17:29.257582
# Unit test for function safe_eval
def test_safe_eval():
    flag = True

# Generated at 2022-06-11 17:17:35.033503
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[3, 4]') == [3, 4]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('[{ "a": 1 }]') == [{"a": 1}]
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('{"a": 1, "b": ["c", "d"]}') == {"a": 1, "b": ["c", "d"]}
    assert safe_eval('[3, 1]') == [3, 1]
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False

# Generated at 2022-06-11 17:17:44.200689
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("var") == "var"
    assert safe_eval("[]") == []
    assert safe_eval("['item']") == ['item']
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    assert safe_eval("{'a': null}") == {'a': None}
    assert safe_eval("{'a': true}") == {'a': True}
    assert safe_eval("{'a': false}") == {'a': False}
    assert safe_eval("{'a': 1 + 2}") == {'a': 3}


# Generated at 2022-06-11 17:17:54.488700
# Unit test for function safe_eval
def test_safe_eval():
    # type of safe_eval
    assert safe_eval('{"hello": "world"}') == {"hello": "world"}
    assert safe_eval('33 + 22') == 55
    assert safe_eval('[33, 22]') == [33, 22]
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('5') == 5
    assert safe_eval('1/2') == .5  # Python 2/3 compat
    assert safe_eval('"5"') == '5'
    assert safe_eval('"1/2"') == '1/2'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('{}') == {}

# Generated at 2022-06-11 17:18:02.329268
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __future__
    except ImportError:
        pass

    # Python 2.4 does not support the following:
    try:
        eval("""(x for x in range(10))""")
        genexps = True
    except:
        genexps = False

    # Test simple expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1: 2, 3: 4}') == {1: 2, 3: 4}
    assert safe_eval('set([1, 2, 3])') == set([1, 2, 3])
    assert safe_eval('"x" * 3') == "xxx"
    assert safe_eval('None') is None

# Generated at 2022-06-11 17:18:09.211163
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple integer
    assert safe_eval("10") == 10
    assert safe_eval("1+10") == 11
    assert safe_eval("1+10/20") == 1
    assert safe_eval("1+10/20+42") == 43
    assert safe_eval("1+10/20+42-1") == 42
    assert safe_eval("1+10/20+42-1*2") == 42
    assert safe_eval("1+10/20+42-1*2/2") == 42
    assert safe_eval("1+(10/20)+42-1*2/2") == 42
    assert safe_eval("-1") == -1
    assert safe_eval("-(10)") == -10
    assert safe_eval("10-1") == 9

# Generated at 2022-06-11 17:18:18.531872
# Unit test for function safe_eval
def test_safe_eval():
    # Basic testing of simple strings
    assert safe_eval("7") == 7
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    assert safe_eval("undefined") == 'undefined'

    # Test of complex expressions
    ans = safe_eval("[x*x for x in range(10)]")
    assert ans[0] == 0 and ans[-1] == 81

    # Test of basic exception handling
    assert safe_eval("1 +") == "1 +"

    # Test of expression syntax errors
    try:
        safe_eval("[x*x for x in range(10")
    except SyntaxError:
        pass

# Generated at 2022-06-11 17:18:28.356218
# Unit test for function safe_eval
def test_safe_eval():
    test = 'foo.bar("baz")'
    result = safe_eval(test)
    assert result == test
    test = 'a_list_variable[0]'
    result = safe_eval(test, dict(a_list_variable=[True]))
    assert result is True
    test = 'true'
    result = safe_eval(test)
    assert result is True
    test = 'false'
    result = safe_eval(test)
    assert result is False
    test = 'null'
    result = safe_eval(test)
    assert result is None
    test = '1 + 2'
    result = safe_eval(test)
    assert result == 3
    test = '1 - 2'
    result = safe_eval(test)
    assert result == -1
    test = '1 * 2'
   

# Generated at 2022-06-11 17:18:37.498691
# Unit test for function safe_eval
def test_safe_eval():
    # The following four tests are from the sample program given in the URL
    # http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    # The sample code is based on the idea that the program should
    # test_safe_eval() should return 3 when called with the expression '1+2'
    # but return the disallowed string "__import__('os').system('rm -rf /')"
    # as-is.
    assert (safe_eval('1+2') == 3)
    assert (safe_eval('__import__("os").system("rm -rf /")') == "__import__('os').system('rm -rf /')")

# Generated at 2022-06-11 17:18:46.442524
# Unit test for function safe_eval
def test_safe_eval():
    # No exception should be raised
    expr = """{% if (ansible_distribution is sameas 'RedHat') or (ansible_distribution is sameas 'CentOS') %}centos{% endif %}"""
    (result, e) = safe_eval(expr, {'ansible_distribution': 'RedHat'}, True)
    assert result == 'centos'
    assert e is None

    (result, e) = safe_eval(expr, {'ansible_distribution': 'CentOS'}, True)
    assert result == 'centos'
    assert e is None

    # Exception should be raised
    result = safe_eval(expr, {'ansible_distribution': 'Ubuntu'})
    assert result == expr


# Generated at 2022-06-11 17:18:53.128017
# Unit test for function safe_eval
def test_safe_eval():
    x = [1,2,3]
    x.append(x)
    print("safe_eval().test_safe_eval(): x='%s'." % x)
    result = safe_eval(x)
    print("safe_eval().test_safe_eval(): result='%s'." % result)
    assert result == x

    # Test an evaled variable dictionary
    # Test an evaled variable dictionary
    x = "{{x}}"
    x = safe_eval(x, dict(x=7))
    print("safe_eval().test_safe_eval(): x='%s'." % x)
    assert x == 7

    # Test a list (as a string)
    # Test a list (as a string)
    x = "['a', 'b', 'c']"
    x = safe_eval(x)
    print

# Generated at 2022-06-11 17:19:02.416240
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('"1" + "1"') == '11'

    # Test that comparison operators work
    assert safe_eval('1 < 1') == False
    assert safe_eval('1 <= 1') == True
    assert safe_eval('1 == 1') == True
    assert safe_eval('1 != 1') == False
    assert safe_eval('1 >= 1') == True
    assert safe_eval('1 > 1') == False

    # Test more complex comparisons
    assert safe_eval('(1, 2) == (1, 2)') == True

    # Test calls not enabled by default
    try:
        assert safe_eval('flat([1, [2, 3]])')
    except Exception as e:
        assert 'invalid function' in str(e)

# Generated at 2022-06-11 17:19:12.385868
# Unit test for function safe_eval
def test_safe_eval():
    def fail(*args, **kwargs):
        raise Exception()

    locals = {'foo': 'FOO'}

# Generated at 2022-06-11 17:19:20.052968
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate a simple expression
    result = safe_eval('foo')
    assert result == 'foo'

    # Evaluate a simple expression that works as python
    result = safe_eval('foo > 1')
    assert type(result).__name__ == 'bool'

    # Evaluate an expression with a function call
    result = safe_eval('foo')
    assert result == 'foo'

    # Evaluate a constant
    result = safe_eval('123')
    assert type(result).__name__ == 'int'

    # Evaluate a list
    result = safe_eval('[1,2,3]')
    assert type(result).__name__ == 'list'

    # Evaluate a dict
    result = safe_eval('{ "k1": "v1" }')

# Generated at 2022-06-11 17:19:30.271539
# Unit test for function safe_eval
def test_safe_eval():
    # Test that we can safely eval constant values
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("null") is None

    # Test that we can safely eval with operators
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 - 1") == 0
    assert safe_eval("1 * 1") == 1
    assert safe_eval("1 / 1") == 1

    # Test that we can safely eval boolean expressions
    assert safe_eval("1 > 1") == False
    assert safe_eval("1 >= 1") == True
    assert safe_eval("1 <= 1") == True
   

# Generated at 2022-06-11 17:19:40.162860
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:50.824215
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test cases for `safe_eval`, using the example in the docstring
    '''
    assert safe_eval("1 + 2") == 1 + 2
    assert safe_eval("1 + [2, 3]") == 1 + [2, 3]
    assert safe_eval("1 + {2:3}") == 1 + {2: 3}
    assert safe_eval("true") == True
    assert safe_eval("true and false") == False
    assert safe_eval("1 + true and false") == 1 + True and False
    assert safe_eval("false or true") == False or True
    assert safe_eval("1+-2") == 1+-2
    assert safe_eval("1 + -1") == 0
    assert safe_eval("1 + - [1, 2]") == 1 + [-1, -2]

# Generated at 2022-06-11 17:20:01.372927
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This unit test ensures that safe_eval() only adds a few things to eval(),
    but still allows some stuff that eval() would not.
    '''

    # the goal was to make it so that the above statement, in addition to
    # some other useful things, was allowed by safe_eval() but not by
    # normal eval()

    # this would not be allowed by eval()
    assert "this is a test" == safe_eval('"this is a test"')

    # these should raise exceptions
    try:
        safe_eval("import sys")
    except Exception:
        sys.stderr.write("safe_eval properly failed on an attempt to "
                         "call a function in a python module\n")

    try:
        safe_eval("a_list_variable")
    except Exception:
        sys.stderr

# Generated at 2022-06-11 17:20:09.693187
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("foo") == 'foo'
    assert safe_eval("foo.bar") == 'foo.bar'
    assert safe_eval("foo.bar()") == 'foo.bar()'
    assert safe_eval("foo()") == 'foo()'
    assert safe_eval("foo.bar()") == 'foo.bar()'
    assert safe_eval("dict(x=1, y=2)") == {'x': 1, 'y': 2}
    assert safe_eval("dict(a='b')") == {'a': 'b'}

# Generated at 2022-06-11 17:20:18.510322
# Unit test for function safe_eval
def test_safe_eval():
    class TestException(Exception):
        pass

    # Test that safe_eval detects an invalid/unsafe expression
    with open('%s/sanity/invalid_expression.txt' % C.TEST_DIR) as fh:
        for test_case in fh:
            test_case = test_case.strip()
            try:
                safe_eval(test_case)
            except Exception:
                pass
            else:
                assert False, 'safe_eval did not detect invalid expression: %s' % test_case

    # Test that safe_eval works as expected, using a variety of
    # valid expressions
    with open('%s/sanity/valid_expression.txt' % C.TEST_DIR) as fh:
        for test_case in fh:
            test_case = test_case.strip()
           

# Generated at 2022-06-11 17:20:24.112724
# Unit test for function safe_eval
def test_safe_eval():
    good_expressions = [
        "1 + 1",
        "foo.lower()",
        "' '.join(bar)"
    ]
    bad_expressions = [
        "1/0",
        "foo.bar()",
        "__builtins__",
        "open('/foo')",
    ]

    # test good expressions
    for expr in good_expressions:
        assert safe_eval(expr) is not None

    # test bad expressions
    for expr in bad_expressions:
        assert safe_eval(expr) is None

# Generated at 2022-06-11 17:20:32.722506
# Unit test for function safe_eval
def test_safe_eval():
    """Return a list of tuples with the test name and error if any"""
    failed_tests = []

    def _test_safe_eval(name, expr, expected, include_exceptions=False, locals=None):
        if locals is None:
            locals = {}
        result = safe_eval(expr, locals, include_exceptions)
        if isinstance(result, tuple):
            result = result[0]
        if result != expected:
            failed_tests.append((name, None))

    _test_safe_eval("test_safe_eval_basic", "a", 'a')
    _test_safe_eval("test_safe_eval_basic_dict", "{'a':'b'}", {'a':'b'})

# Generated at 2022-06-11 17:20:41.357477
# Unit test for function safe_eval
def test_safe_eval():
    # list of tuples: (expression, expected_result)
    data = [
        ('1 + 1', 2),
        ('true', True),
        ('false', False),
        ('null', None),
        ('["a", "b"]', ['a', 'b']),
        ('["a", "b"] + ["c"]', ['a', 'b', 'c']),
        ('{"a": "b"}', {'a': 'b'}),
        ('{"a": "b"} + {"c": "d"}', {'a': 'b', 'c': 'd'}),
        ('"foo"', 'foo'),
        ('"foo" + "bar"', 'foobar'),
    ]

    for expr, expected in data:
        actual = safe_eval(expr)
        assert actual == expected

    # ensure that

# Generated at 2022-06-11 17:20:53.491511
# Unit test for function safe_eval
def test_safe_eval():
    import random
    import string

    def id_generator(size=6, chars=string.ascii_lowercase):
        return ''.join(random.choice(chars) for x in range(size))

    # list of valid python expressions

# Generated at 2022-06-11 17:21:02.564182
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import astor
    except ImportError:
        print('Safe_eval unit tests require astor, which is not installed')
        sys.exit(0)

    # Test safe_eval with various types of expressions and variables
    eval_dict = dict(
        mylist=[1,2,3],
        mydict=dict(a=1, b=2),
        mybool=True,
        myint=0,
        mystr="foobar",
        myotherstr="a string with 'single quotes'",
        myunicode=u"Unicode string",
        myfloat=3.14,
        mynone=None,
        myrepr="a string with 'single quotes'",
        myreprunicode=u"Unicode string",
    )


# Generated at 2022-06-11 17:21:12.416231
# Unit test for function safe_eval
def test_safe_eval():
    # Test for the syntax error exception
    expr = "default(present)"
    (result, exception) = safe_eval(expr, locals=None, include_exceptions=True)
    assert exception is not None and isinstance(exception, SyntaxError)
    assert result == expr

    # Test for the string containing jinja2 expression
    expr = "{{ default(present) }}"
    (result, exception) = safe_eval(expr, locals=None, include_exceptions=True)
    assert exception is not None and isinstance(exception, Exception)
    assert result == expr

    # Test for the string containing jinja2 expression
    expr = "{{ true }}"
    (result, exception) = safe_eval(expr, locals=None, include_exceptions=True)

# Generated at 2022-06-11 17:21:30.137150
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:35.718017
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:44.544440
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('[1,2] + [3,4]') == [1, 2, 3, 4]
    assert safe_eval('[1,2] + (3,4)') == [1, 2, 3, 4]
    assert safe_eval('{1:2} + {"3":4}') == {1: 2, "3": 4}
    assert safe_eval("'ab' + 'cd'") == 'abcd'
    assert safe_eval("'1'*2") == '11'
    assert safe_eval("'ab' - 'a'") == 'b'
    assert safe_eval("{1,2} - {2}") == {1}
    assert safe_eval("[1,2] - [2]") == [1]


# Generated at 2022-06-11 17:21:53.452330
# Unit test for function safe_eval
def test_safe_eval():
    import ast


# Generated at 2022-06-11 17:21:59.803408
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('a_list_variable[0]')
    with open(C.DEFAULT_MODULE_UTILS_PATH + '/facts.py', 'r') as f:
        safe_eval(f.read())
        # The following should fail
        try:
            safe_eval('import os; os.system("touch BAD_TOUCH")')
        except Exception as e:
            pass
        else:
            sys.exit('safe_eval failed to catch untrusted code')

# Generated at 2022-06-11 17:22:06.956941
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1}') == {'a': 1}
    assert safe_eval('1 + 2') == 3
    assert safe_eval('"a" in test_vars') is False

    # call_function_whitelist
    assert safe_eval('to_yaml(test_variable)') == safe_eval('test_variable')
    assert safe_eval('to_json(test_variable)') == safe_eval('test_variable')

    # disallowed calls
    exc = None
    try:
        safe_eval('min(test_variable)')
    except Exception as e:
        exc = e
    assert exc is not None

    # failed to evaluate

# Generated at 2022-06-11 17:22:16.906736
# Unit test for function safe_eval
def test_safe_eval():
    '''
    test_safe_eval:
    Tests safe_eval()
    '''
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('a_list_variable', dict(a_list_variable=[1,2,3])) == [1,2,3]
    assert safe_eval('a_dict_variable', dict(a_dict_variable=dict(a='b'))) == dict(a='b')
    assert safe_eval('a_dict_variable.a', dict(a_dict_variable=dict(a='b'))) == 'b'
    assert safe_eval('a_list_variable[0]', dict(a_list_variable=[1,2,3])) == 1
    assert safe

# Generated at 2022-06-11 17:22:27.061784
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for function safe_eval
    # The following are all "safe" examples
    # Safe examples should return exactly what is given
    assert safe_eval('5 * 8 * 2') == 80
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('(false and []) or true') is True
    assert safe_eval('foo in bar or baz') == "foo in bar or baz"
    assert safe_eval('((5 * 2) + 3) * 4 * 2') == 80
    assert safe_eval('2 ** 3 - 1') == 7
    assert safe_eval('(1, 2, 3, 4, 5)') == (1, 2, 3, 4, 5)

# Generated at 2022-06-11 17:22:37.639426
# Unit test for function safe_eval
def test_safe_eval():
    import os
    import sys
    import stat

    TESTFILE = "/tmp/ansible_test_file"
    SEVENS = 47
    TWELVES = 144
    TWENTYSIX = 26

    # Cleanup leftover test files
    if os.path.exists(TESTFILE):
        os.unlink(TESTFILE)

    def cleanup():
        '''Cleanup created by test_templates'''
        if os.path.exists(TESTFILE):
            os.unlink(TESTFILE)


# Generated at 2022-06-11 17:22:47.593639
# Unit test for function safe_eval
def test_safe_eval():
    def assert_success(result, expected_result, code):
        if result is None:
            print("ERROR parsing expression %s" % code)
            sys.exit(1)
        if result != expected_result:
            print("ERROR evaluating %s as %s instead of %s" % (code, result, expected_result))
            sys.exit(1)

    def assert_failure(result, code):
        if result is not None:
            print("ERROR, %s should not have evaluated" % (code))
            sys.exit(1)

    # Basic expressions
    assert_success(safe_eval('2 + 3'), 5, '2 + 3')
    assert_success(safe_eval('-(2 + 3)'), -5, '-(2 + 3)')

# Generated at 2022-06-11 17:23:02.865466
# Unit test for function safe_eval
def test_safe_eval():

    # Test whether valid Python constructs are left unmodified
    # Examples taken from http://docs.python.org/2/tutorial/introduction.html#strings
    assert safe_eval('2 + 3') == 5
    assert safe_eval('x * 2') == 10
    assert safe_eval('m, n = 5, 6') == None
    assert safe_eval('m + n') == 11
    assert safe_eval('a = True') == True
    assert safe_eval('b = False') == False
    assert safe_eval('c = None') == None
    assert safe_eval('2 + 3') == 5
    assert safe_eval('x * 2') == 10
    assert safe_eval('m, n = 5, 6') == None
    assert safe_eval('m + n') == 11

# Generated at 2022-06-11 17:23:13.636717
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    if not C.DEFAULT_KEEP_REMOTE_FILES:
        raise AssertionError("C.DEFAULT_KEEP_REMOTE_FILES needs to be set to True for safe_eval tests")

    expr = '{{ [ 1, 2, 3 ] + [ 4, 5 ] }}'
    expected = "[1, 2, 3, 4, 5]"
    result, err = safe_eval(to_text(expr), {}, include_exceptions=True)
    if err is not None:
        raise AssertionError("expected no exception for %s, got %s" % (expr, err))
    if result != expected:
        raise AssertionError("expected %s, got %s" % (expected, result))


# Generated at 2022-06-11 17:23:23.189944
# Unit test for function safe_eval
def test_safe_eval():
    expression = '{a:1, b:2}'
    if sys.version_info < (2, 7):
        expected_result = '{u\'b\': 2, u\'a\': 1}'
    else:
        expected_result = '{u\'a\': 1, u\'b\': 2}'
    assert container_to_text(safe_eval(expression)) == expected_result

    expression = '{a:1, b:2'
    if C.DEFAULT_ANSIBLE_MODULE_COMPATIBLE:
        if sys.version_info < (2, 7):
            expected_result = '{u\'a\': 1, u\'b\': 2}'
        else:
            expected_result = '{u\'a\': 1, u\'b\': 2}'

# Generated at 2022-06-11 17:23:34.216606
# Unit test for function safe_eval