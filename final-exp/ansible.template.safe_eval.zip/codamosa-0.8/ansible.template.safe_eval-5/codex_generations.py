

# Generated at 2022-06-11 17:13:44.096105
# Unit test for function safe_eval

# Generated at 2022-06-11 17:13:55.048636
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:06.123975
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:14.549692
# Unit test for function safe_eval
def test_safe_eval():
    expr = "2*2"
    assert safe_eval(expr) == 4
    expr = "'%s' % 'foo'"
    assert safe_eval(expr) == '%s' % 'foo'
    expr = "[x for x in range(10)]"
    assert safe_eval(expr) == [x for x in range(10)]
    expr = "{'foo': 'bar'}"
    assert safe_eval(expr) == {'foo': 'bar'}
    expr = "foo"
    assert safe_eval(expr) == "foo"
    assert safe_eval(expr, dict(foo=42)) == 42
    expr = "[x for x in range(10) if x > 5]"
    assert safe_eval(expr) == [x for x in range(10) if x > 5]

# Generated at 2022-06-11 17:14:22.867155
# Unit test for function safe_eval
def test_safe_eval():
    jinja2_vars = {
        'my_var': 'my_value',
        'my_int': 3,
        'my_fact': 'some_fact',
    }

    def my_func():
        return 'hello'

    # set up test cases to run through eval()

# Generated at 2022-06-11 17:14:33.981918
# Unit test for function safe_eval
def test_safe_eval():
    def _do_test(expr, expected=None, locals=None):
        if expected is not None:
            r, e = safe_eval(expr, locals=locals, include_exceptions=True)
            if e is None:
                assert r == expected
            else:
                message = 'Expected "%s" to evaluate to %s, but it raised %s: %s' % (expr, expected, type(e), e)
                assert False, message
        else:
            r = safe_eval(expr, locals=locals, include_exceptions=False)
            assert r == expr

    # Test non-string input
    _do_test(10, 10)
    _do_test({'a': 'b'}, {'a': 'b'})
    _do_test(None, None)

    # Basic test


# Generated at 2022-06-11 17:14:46.153313
# Unit test for function safe_eval
def test_safe_eval():
    sys.stdout.write("Testing function safe_eval\n")
    sys.stdout.write("Test 1: Pass\n")
    data = {
        "test_list": ["val1", "val2"],
        "test_var": "test_list",
        "var to test": "test_var",
    }
    string = "[{0}]".format(data.get("var to test"))

# Generated at 2022-06-11 17:14:52.913660
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.playbook.play_context import PlayContext

    playcontext = PlayContext()

    # Test basic functionality
    string = "((4 + 5 - 1) * 20)"
    value = 80
    result, exception = safe_eval(string, include_exceptions=True)
    assert result == value, result
    assert exception == None, exception
    result = safe_eval(string)
    assert result == value, result

    # Test with locals
    string = "foo"
    value = "baz"
    result, exception = safe_eval(string, dict(foo=value), include_exceptions=True)
    assert result == value, result
    assert exception == None, exception
    result = safe_eval(string, dict(foo=value))
    assert result == value, result

    # Test with mix of locals and jinja

# Generated at 2022-06-11 17:15:04.331097
# Unit test for function safe_eval
def test_safe_eval():
    def my_generator():
        yield 3
    try:
        import datetime
        import decimal
        import json
        has_data = True
    except ImportError:
        has_data = False
    # Basic expressions
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo == bar') == 'foo == bar'
    assert safe_eval('123') == 123
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo + 3') == 'foo + 3'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[i + 2 for i in range(3)]') == [2, 3, 4]

# Generated at 2022-06-11 17:15:14.469708
# Unit test for function safe_eval
def test_safe_eval():
    # Test a valid expression
    result = safe_eval('1 + 1', include_exceptions=True)
    assert result[0] == 2
    assert result[1] is None

    # Test an invalid syntax expression
    result = safe_eval('1 + + 1', include_exceptions=True)
    assert result[0] == '1 + + 1'
    assert isinstance(result[1], SyntaxError)

    # Test an invalid function call
    result = safe_eval('abs(-1)', include_exceptions=True)
    assert result[0] == 'abs(-1)'
    assert isinstance(result[1], Exception)

    # Test an invalid identifier
    result = safe_eval('nonexistent_variable', include_exceptions=True)
    assert result[0] == 'nonexistent_variable'

# Generated at 2022-06-11 17:15:26.881261
# Unit test for function safe_eval
def test_safe_eval():

    def test_safe_eval_one(safe_eval_fn, eval_str, should_succeed, eval_result=None):
        if eval_result is not None:
            (result, exception) = safe_eval_fn(eval_str, include_exceptions=True)
        else:
            result = safe_eval_fn(eval_str)

        if should_succeed:
            if eval_result is not None:
                assert eval_result == result and exception is None, 'test_safe_eval failed: %s %s %s %s' % (to_native(eval_str), to_native(repr(eval_result)), to_native(repr(result)), to_native(repr(exception)))

# Generated at 2022-06-11 17:15:36.519679
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr, expected, enable_call=True):
        try:
            if enable_call:
                CALL_ENABLED.append('str')
            result = safe_eval(expr)
        finally:
            if enable_call:
                del CALL_ENABLED[-1]

        if expected != result:
            raise AssertionError("safe_eval('%s') = %s should be %s" %
                                 (expr, to_native(result), to_native(expected)))

    test('True', True)
    test('False', False)
    test('None', None)
    test('2 + 3', 5)
    test('2 + 3 * 4', 14)
    test('"a" + "b"', "ab")
    test('["a", "b"]', ["a", "b"])


# Generated at 2022-06-11 17:15:45.389598
# Unit test for function safe_eval
def test_safe_eval():

    def _test_eval(expr, result, should_pass=True):
        res, out = safe_eval(expr, include_exceptions=True)
        if not should_pass:
            if isinstance(out, Exception):
                pass
            else:
                raise AssertionError('Expected failure, got %s' % res)
        else:
            if isinstance(out, Exception):
                raise AssertionError('Expected success, got %s' % out)
            else:
                if isinstance(res, dict) and isinstance(result, dict):
                    if len(res) != len(result):
                        raise AssertionError('Expected %s, got %s' % (result, res))

# Generated at 2022-06-11 17:15:55.577397
# Unit test for function safe_eval
def test_safe_eval():
    def _test_safe_eval(expr, expected_result, expected_exception=None):
        result, exception = safe_eval(expr, include_exceptions=True)
        if expected_exception:
            assert isinstance(exception, expected_exception), '%s: expected %s, got %s' % (expr, expected_exception, exception)
            assert result == expr
        else:
            assert not exception, '%s: unexpected exception: %s' % (expr, exception)
            assert result == expected_result
        result = safe_eval(expr)
        assert result == expected_result, '%s: expected %s, got %s' % (expr, expected_result, result)

    # expected to succeed

# Generated at 2022-06-11 17:16:06.332882
# Unit test for function safe_eval
def test_safe_eval():
    # Test values
    true_values = [True, 'True', 'true', '1', 1]
    false_values = [False, 'False', 'false', '0', 0]
    string_values = ['hello', 'world']
    number_values = [34, 2.3, -3, -3.3]
    number_range = range(0, 500)
    array_values = [['array', 'of', 'strings'],
                    ['array', 'of', 'numbers', 1, 2, 3],
                    ['array', 'of', 'True', True],
                    ['array', 'of', 'False', False],
                    ['array', 'of', 'True', 'and', 'False', True, False],
                    ['array', 'of', 'arrays', [1, 2], [3, 4]]]
    dict_values

# Generated at 2022-06-11 17:16:15.571476
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.common.text.converters import text_type

    # Basic sanity check for valid expressions

# Generated at 2022-06-11 17:16:23.820229
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar"}', None, True) == ({'foo': 'bar'}, None)
    assert safe_eval('{"foo": "bar"}', None, False) == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "ansible": "Cool!"}') == {'foo': 'bar', 'ansible': 'Cool!'}
    assert safe_eval('{"foo": "bar", "ansible": "Cool!"}', None, True) == ({'foo': 'bar', 'ansible': 'Cool!'}, None)

# Generated at 2022-06-11 17:16:34.475437
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validate the safe_eval function
    '''

    # Test literal int
    assert(safe_eval("1") == 1)

    # Test literal string
    assert(safe_eval("'hello'") == 'hello')

    # Test literal list
    assert(safe_eval("[]") == [])

    # Test literal dict
    assert(safe_eval("{}") == {})

    # Test arithmatic
    assert(safe_eval("1 + 2") == (1+2))

    # Test boolean
    assert(safe_eval("false") == False)
    assert(safe_eval("true") == True)

    # Test boolean with space
    assert(safe_eval(" false ") == False)

    # Test function call

# Generated at 2022-06-11 17:16:44.256950
# Unit test for function safe_eval
def test_safe_eval():

    # test functionality of importing json types
    json_types = ['null', 'true', 'false']
    for x in json_types:
        assert safe_eval(x) == ast.literal_eval(x)

    # test functionality of all other evaluated types
    tested_types = ['1', '1.4', '"foo"', "'foo'", '["bar", "baz"]', '{"bar": "baz"}']
    for x in tested_types:
        assert safe_eval(x) == ast.literal_eval(x)

    # test functionality of all allowed ast nodes
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 - 1') == 0
    assert safe_eval('2 * 3') == 6
    assert safe_eval('6 / 2') == 3

# Generated at 2022-06-11 17:16:51.688280
# Unit test for function safe_eval
def test_safe_eval():
    class FakeJinja2Environment():
        def __init__(self):
            import jinja2
            self.environment = jinja2.Environment()

        def from_string(self, template):
            return self.environment.from_string(template)

        def from_native(self, data):
            return data

    j2env = FakeJinja2Environment()
    example_hostvars = {
        'nested_dict': {
            'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}
        }
    }

# Generated at 2022-06-11 17:17:01.728186
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', dict()) == 2
    assert safe_eval('1+1', dict(a=2)) == 2
    assert safe_eval('1+k', dict(k=1)) == 2

    # We do not allow calls to unknown functions
    value, exception = safe_eval('lala(1)', dict(k=1), include_exceptions=True)
    assert value == 'lala(1)'
    assert str(exception) == "invalid function: lala"

    assert safe_eval('a_string', dict(a_string='two')) == 'two'

    # Strings are not accepted
    value, exception = safe_eval('a_string', dict(a_string='two'), include_exceptions=True)

# Generated at 2022-06-11 17:17:12.176778
# Unit test for function safe_eval
def test_safe_eval():
    # Define our whitelist of whitelisted functions that we want to
    # allow to be called from the 'safe_eval' context.
    _ALLOWED_CALLS = (
        'min',
    )

    def _allowed_function(name):
        return name in _ALLOWED_CALLS

    # Define some test expressions to safely eval.

# Generated at 2022-06-11 17:17:21.359274
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:29.729399
# Unit test for function safe_eval
def test_safe_eval():
    # json types
    assert safe_eval('false') == False
    assert safe_eval('true') == True
    assert safe_eval('null') == None
    assert safe_eval('42') == 42
    assert safe_eval('42.87') == 42.87
    assert safe_eval('"foo"') == "foo"

    # valid operations
    assert safe_eval('42 + 87') == 129
    assert safe_eval('42 - 87') == -45
    assert safe_eval('42 * 87') == 3694
    assert safe_eval('42 / 87') == 0
    assert safe_eval('42 / 87.0') == 0.4827586206896552

    # invalid operations
    assert safe_eval('True + False') == 'True + False'
    assert safe_eval('True == False') == 'True == False'

# Generated at 2022-06-11 17:17:40.772915
# Unit test for function safe_eval
def test_safe_eval():
    # Test with good data
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a':1,'b':2}") == {'a':1,'b':2}
    assert safe_eval("True") is True
    assert safe_eval("names.append(1)", dict(names=[0])) == None
    assert safe_eval("-1 + -3") == -4
    assert safe_eval("4*5", dict(pi=3.14159)) == 20
    assert safe_eval("-x", dict(x=1)) == -1
    assert safe_eval("1 if 'foo' in bar else 2", dict(bar=['baz','foo'])) == 1

# Generated at 2022-06-11 17:17:47.846943
# Unit test for function safe_eval
def test_safe_eval():
    # disable deprecations in the unit tests
    import warnings
    warnings.filterwarnings('ignore')

    # List of tuples of form: (expression, expected result)

# Generated at 2022-06-11 17:17:57.184853
# Unit test for function safe_eval
def test_safe_eval():
    # Simple test to check for desired behaviour of safe_eval
    if not C.DEFAULT_KEEP_REMOTE_FILES:
        # The tests in this function require Ansible to keep
        # the Jinja2 templates for the command and shell
        # modules.  This causes a resource leak for now,
        # because the remote files are not properly deleted
        # if C.DEFAULT_KEEP_REMOTE_FILES is False.
        #
        # Once the resource leak is fixed, we can enable these
        # tests even if C.DEFAULT_KEEP_REMOTE_FILES is False.
        return

    class TestModule(object):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-11 17:18:03.860020
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    # The following values are allowed
    res=safe_eval('"string"')
    assert res == "string"
    res=safe_eval('""')
    assert res == ""
    res=safe_eval('[1,2]')
    assert res == [1,2]
    res=safe_eval('[1,[2,3],4]')
    assert res == [1,[2,3],4]
    res=safe_eval('{"key1":"value1","key2":"value2"}')
    assert res == {"key1":"value1","key2":"value2"}
    res=safe_eval('{"key1":["value1","value2"]}')
    assert res == {"key1":["value1","value2"]}
    res=safe_eval('{"key1":{},"key2":{}}')

# Generated at 2022-06-11 17:18:14.585593
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Taken from:
    https://github.com/ansible/ansible/blob/devel/lib/ansible/playbook/conditional.py
    '''

    # normal conditionals
    assert safe_eval("'foo' in foo", dict(foo='foobar'))
    assert safe_eval("foo in 'foobar'", dict(foo='foo'))
    assert safe_eval("blah in ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']")

# Generated at 2022-06-11 17:18:24.649183
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:38.018819
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval() function and ensure that it works as expected
    '''
    try:
        from ansible.playbook.conditional import Conditional
        from ansible.plugins.loader import lookup_loader
    except ImportError:
        # If the ansible modules are not in the module_utils path, then this doesn't work
        return

    # Construct a fake lookup plugin called 'env'
    old_env = dict(os.environ)
    os.environ["ANSIBLE_LOOKUP_PLUGINS"] = './lookup_plugins'
    try:
        lookup_plugin = lookup_loader.get('env', class_only=True)
    finally:
        os.environ.clear()
        os.environ.update(old_env)

# Generated at 2022-06-11 17:18:47.696434
# Unit test for function safe_eval
def test_safe_eval():
    # Successful evaluations
    test_param = [
        "foo",
        "'foo'",
        "{'foo': 'bar'}",
        '{"foo": "bar"}',
        "['foo', 'bar']",
        '["foo", "bar"]',
        "{'foo': ['bar', 'baz']}",
        '{"foo": ["bar", "baz"]}',
        "['foo', {'bar': 'baz'}]",
        '["foo", {"bar": "baz"}]',
        "foo in ['bar', 'baz']",
        'foo == "bar"',
        "foo == true",
        "'foo' in bar.keys()",
    ]

# Generated at 2022-06-11 17:18:57.753959
# Unit test for function safe_eval
def test_safe_eval():
    '''Test for when safe_eval is used as a standalone function'''

# Generated at 2022-06-11 17:19:07.032424
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    # these are strings, but could be represented as numbers
    assert safe_eval('0') == '0'
    assert safe_eval('123456789') == '123456789'
    assert safe_eval('0.0') == '0.0'
    assert safe_eval('3.14159') == '3.14159'
    # this is a string, but could be evaluated as a number
    assert safe_eval('3.14159') == '3.14159'
    # a dict is a dict, even if it holds ints that could be long

# Generated at 2022-06-11 17:19:16.506085
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:27.278790
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Ensure that safe_eval behaves as expected
    '''
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 - 1") == 1
    assert safe_eval("6 / 2") == 3
    assert safe_eval("2 * 3") == 6
    assert safe_eval("2 ** 16") == 65536
    assert safe_eval("[1, 2, 3, 4]") == [1, 2, 3, 4]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

    # Test that we reject all the things we expect to be rejected

# Generated at 2022-06-11 17:19:36.885018
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:43.748395
# Unit test for function safe_eval
def test_safe_eval():
    # Python code to demonstrate naive implementation
    # of safe_eval()
    import ast
    import traceback
    try:
        # side effect of input()
        expr = input('Enter the expression: ')

        # Parse the expression into an AST
        n = ast.parse(expr, mode='eval')

        # Evaluate the AST
        print(eval(compile(n, '<string>', 'eval')))
    except:
        print('Caught this error: ' + str(traceback.format_exc()))

    # Python code to demonstrate safe_eval()
    import ast
    import traceback

# Generated at 2022-06-11 17:19:50.350492
# Unit test for function safe_eval
def test_safe_eval():

    # This should allow Jinja2 to work properly
    assert safe_eval("a_list_variable|join(', ')") == "a_list_variable|join(', ')"

    # This is not a function call, so we should see no change
    assert safe_eval("a_list_variable") == "a_list_variable"

    # This is a dict, which is allowed
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

    # This is a list, which is allowed
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]

    # This is a constant (string), which is allowed
    assert safe_eval('"A String"') == "A String"

    # This is a constant (unicode),

# Generated at 2022-06-11 17:20:01.008827
# Unit test for function safe_eval
def test_safe_eval():
    # some tests to verify proper operation
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1 * 2") == 3
    assert safe_eval("1 - 7") == -6
    assert safe_eval("-1 - 7") == -8
    assert safe_eval("7 - -4") == 11
    assert safe_eval("1 - -4") == 5

    assert safe_eval("'foo' + 'bar'") == "foobar"
    assert safe_eval("'foo' * 3") == "foofoofoo"
    assert safe_eval("'foo' * 3 + 'bar'") == "foofoofoobar"

    assert safe_eval("['foo', 'bar', 'baz']") == ["foo", "bar", "baz"]

# Generated at 2022-06-11 17:20:17.965136
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test valid expressions
    '''
    def test_safe_eval_good(expr):
        try:
            safe_eval(expr)
            raise AssertionError("safe_eval incorrectly accepted %s" % expr)
        except:
            pass

    # valid expressions
    test_safe_eval_good('foobar')
    test_safe_eval_good('-1 * 5')
    test_safe_eval_good('length(foobar) > 0')
    test_safe_eval_good('1 < 2')
    test_safe_eval_good('foo in bar')
    test_safe_eval_good('foo[1]')
    test_safe_eval_good('foo.bar')
    test_safe_eval_good('a > 2 or a < 2')

# Generated at 2022-06-11 17:20:25.804213
# Unit test for function safe_eval
def test_safe_eval():
    # These expressions are valid
    assert safe_eval(u"foo == 'bar' and baz == 2") == (u"foo == 'bar' and baz == 2", None)
    assert safe_eval(u"foo == 'bar' and baz == 2", {u'baz': 2, u'foo': u'bar'})
    assert safe_eval(u"foo == 'bar' and baz == 2", {u'baz': 22, u'foo': u'bar'}) is False
    assert safe_eval(u"foo == 'bar' and baz == 2", {u'baz': 2, u'foo': u'barr'}) is False
    assert safe_eval(u'foo == "bar" and baz == 2', {u'baz': u'2', u'foo': u'bar'})


# Generated at 2022-06-11 17:20:34.807970
# Unit test for function safe_eval
def test_safe_eval():
    # Expected success
    assert safe_eval("a.split()|regex_search('.*a.*')") is True
    assert safe_eval("'a' in a") is True
    assert safe_eval("a=='a'") is True
    assert safe_eval('a[-1]') == 'a'
    assert safe_eval('a.split()', locals={'a': 'a/b/c'}) == ['a', 'b', 'c']
    assert safe_eval('len(a)', locals={'a': 'abc'}) == 3
    assert safe_eval('5 + 2 * 3') == 11
    assert safe_eval('5 + 5 + 5') == 15
    assert safe_eval('(5 + 5) * 2') == 20

# Generated at 2022-06-11 17:20:42.844125
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate simple expressions
    assert safe_eval('1') == 1
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('"abc"') == 'abc'
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('["a", "b", "c"]') == ['a', 'b', 'c']
    assert safe_eval('(True, False)') == (True, False)
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-11 17:20:54.423335
# Unit test for function safe_eval
def test_safe_eval():
    # enable a call to useful builtin
    CALL_ENABLED.append('len')

    assert safe_eval('1') == 1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None

    assert safe_eval('True and False', include_exceptions=True)[0] is False
    assert safe_eval('True and False') is False
    assert safe_eval('False or True', include_exceptions=True)[0] is True
    assert safe_eval('False or True') is True
    assert safe_eval('1 and 0', include_exceptions=True)[0] == 0
    assert safe_eval('1 and 0') == 0
    assert safe_eval('1 or 0', include_exceptions=True)[0] == 1

# Generated at 2022-06-11 17:21:03.362327
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ 1 + 1 }}") == "{{ 1 + 1 }}"
    assert safe_eval("{{ 1 + 1 }}", include_exceptions=True) == ("{{ 1 + 1 }}", None)
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"
    assert safe_eval("{{ foo.bar }}", include_exceptions=True) == ("{{ foo.bar }}", None)
    assert safe_eval("{{ 1 + 1 }}", include_exceptions=True)[0] == 2
    assert safe_eval("{{ 1 + 1 }}", include_exceptions=True)[1] == None
    assert safe_eval("{{ 1 + 1 }}", include_exceptions=True)[0] == 2
    assert safe_eval("{{ 1 + 1 }}", include_exceptions=True)[1] == None
   

# Generated at 2022-06-11 17:21:12.803266
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function
    '''

    # Test normal modes
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1') != 3
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True) != (3, None)

    # Test unquoted string
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1') != '1 + 1'
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True) != ('1 + 1', None)

    # Test quoted string

# Generated at 2022-06-11 17:21:22.573548
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:31.570190
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for tuple/list/dict
    e = safe_eval('(1, 2, 3)')
    assert type(e) is tuple
    assert len(e) == 3

    e = safe_eval('[1, 2, 3]')
    assert type(e) is list
    assert len(e) == 3

    e = safe_eval('{1: 1, 2: 2}')
    assert type(e) is dict
    assert len(e) == 2
    assert e[1] == 1
    assert e[2] == 2

    # Test boolean constants
    e = safe_eval('true')
    assert type(e) is bool
    assert e is True

    e = safe_eval('false')
    assert type(e) is bool
    assert e is False

    e = safe_eval('null')
   

# Generated at 2022-06-11 17:21:41.207911
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('a_list_variable', dict(a_list_variable=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('my_int', dict(my_int=42)) == 42
    assert safe_eval('my_string', dict(my_string='42')) == '42'
    assert safe_eval('my_list', dict(my_list=[42])) == [42]
    assert safe_eval('my_list', dict(my_list=['42'])) == ['42']

# Generated at 2022-06-11 17:22:06.274986
# Unit test for function safe_eval
def test_safe_eval():
    """
    This test is not meant to be complete, for a complete test, copy paste the
    contents of this test function to the end of the file and call this test
    function from main() (and make sure you keep main() as defined here after
    copying the function with its content).
    """
    def _test_safe_eval(expression, expected_result):
        # first test with include_exceptions=False
        result = safe_eval(expression)
        if result != expected_result:
            print("safe_eval(%s) failed" % expression)
            print("expected: %s" % container_to_text(expected_result))
            print("got: %s" % container_to_text(result))
            sys.exit(1)
        # now verify that result does not contain an exception

# Generated at 2022-06-11 17:22:16.551022
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run safe_eval through a battery of tests.
    This function will raise an exception if any of the tests fail.
    '''
    # Inputs and outputs

# Generated at 2022-06-11 17:22:26.751717
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is a basic unit test for the function safe_eval. It tests the
    validity of the various data types as well as to ensure that invalid
    data types fail.
    """

    # test passing in values for locals that we want to access in our
    # expression
    test_locals = {'test_data': 'foobar'}

    # test passing in a variable for our locals dict
    # import pdb; pdb.set_trace()
    assert safe_eval("test_data", test_locals) == 'foobar'
    # test passing in a variable for our locals dict
    assert safe_eval("test_data.upper()", test_locals) == 'FOOBAR'

    # test some basic python math
    assert safe_eval("1 + 1") == 2

# Generated at 2022-06-11 17:22:37.433185
# Unit test for function safe_eval
def test_safe_eval():
    # This is a subset of tests from library/python_utils.py.
    #
    # We don't need to test all the corner cases because Ansible is
    # calling the function in a very constrained context and those
    # tests aren't really germane to the use case here.

    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo[0]') == 'foo[0]'
    assert safe_eval('foo["bar"]') == 'foo["bar"]'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('1 + 1', dict(a=3)) == 2
    assert safe_eval('items[0]', dict(items=['foo', 'bar'])) == 'foo'

# Generated at 2022-06-11 17:22:47.383885
# Unit test for function safe_eval
def test_safe_eval():
    # Check Python 3 syntax errors
    try:
        safe_eval("a = []")
    except SyntaxError:
        pass
    else:
        raise AssertionError("Should have raised SyntaxError")

    # Test native Python types
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1+2") == 3
    assert safe_eval("'abc'") == "abc"
    assert safe_eval("1+2*3") == 7
    assert safe_eval("(1+2)*3") == 9
    assert safe_eval("()") == ()
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}

    # Test safe_eval with local context
    assert safe_eval

# Generated at 2022-06-11 17:22:56.809491
# Unit test for function safe_eval
def test_safe_eval():
    def check_eval(expr, want, locals=None):
        got, _ = safe_eval(expr, locals, include_exceptions=True)
        assert got == want, '%r != %r' % (got, want)

    # Add support for boolean constants.
    check_eval('true', True)
    check_eval('false', False)

    # Add support for integer constants.
    check_eval('42', 42)

    # Add support for string constants.
    check_eval("'foo'", 'foo')

    # Add support for list constants.
    check_eval('[1, 2, 3]', [1, 2, 3])

    # Add support for dict constants.
    check_eval('{"a": "b"}', {"a": "b"})

    # Add support for set constants.

# Generated at 2022-06-11 17:23:03.491390
# Unit test for function safe_eval
def test_safe_eval():
    expr = '6 * 7'
    res = safe_eval(expr)
    assert res == 42

    res = safe_eval('foo', locals={'foo':42})
    assert res == 42

    expr = 'foo'
    res = safe_eval(expr, locals={'foo':42})
    assert res == 42

    expr = 'foo["bar"]'
    res = safe_eval(expr, locals={'foo':{'bar':42}})
    assert res == 42

    expr = 'foo[0]'
    res = safe_eval(expr, locals={'foo':["bar"]})
    assert res == 'bar'

    expr = 'foo["bar"][0]'
    res = safe_eval(expr, locals={'foo':{"bar":(1,2,3,4)}})
    assert res == 1



# Generated at 2022-06-11 17:23:13.934430
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:23.400874
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, result, locals=None):
        the_globals = dict(globals(), __builtins__=dict())
        r = safe_eval(expr, locals, include_exceptions=False)
        assert r == result, 'failed: safe_eval(%s) returned %s, expected %s' % (expr, r, result)
        # second test makes sure we are not just relying on the python eval()
        # doing the right thing
        r2 = eval(expr, the_globals, locals)
        assert r == r2, 'failed: python eval(%s) returned %s, expected %s' % (expr, r2, result)

    # dicts are not supported in safe_eval
    _test("{'a': 1}", "{'a': 1}")

# Generated at 2022-06-11 17:23:34.314879
# Unit test for function safe_eval
def test_safe_eval():
    # simple test
    assert safe_eval('1 + 2') == 3
    # a failing test
    assert safe_eval('1 + 3') == '1 + 3'

    # list test
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    # list failing test
    assert safe_eval('[1, "foo", 3]') == '[1, "foo", 3]'

    # dict test
    assert safe_eval('{ "foo": "bar" }') == {'foo': 'bar'}
    # dict failing test
    assert safe_eval('{ "foo": 1 + "foo" }') == '{ "foo": 1 + "foo" }'

    # test of complex