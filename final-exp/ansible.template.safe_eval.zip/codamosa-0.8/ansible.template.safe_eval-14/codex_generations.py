

# Generated at 2022-06-11 17:13:33.702542
# Unit test for function safe_eval
def test_safe_eval():
    # Test with simple expressions

    # Test a dict expression
    dict_str = "{'foo': 'bar'}"
    assert safe_eval(dict_str) == {'foo': 'bar'}

    # Test a list expression
    list_str = "[1, 2, 3]"
    assert safe_eval(list_str) == [1, 2, 3]

    # Test a string expression
    string_str = "'hello'"
    assert safe_eval(string_str) == 'hello'

    # Test a binary expression
    binary_str = "1 + 4"
    assert safe_eval(binary_str) == 5

    # Test a unary expression
    unary_str = "-3"
    assert safe_eval(unary_str) == -3

    # Test a complex expression

# Generated at 2022-06-11 17:13:42.430914
# Unit test for function safe_eval

# Generated at 2022-06-11 17:13:53.757280
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'hello'") == 'hello'
    value = 42
    assert safe_eval("a_variable") == 'a_variable'
    assert safe_eval("{{ a_variable }}") == '{{ a_variable }}'
    assert safe_eval("a_variable", dict(a_variable=value)) == value
    assert safe_eval("{{ a_variable }}", dict(a_variable=value)) == value
    assert safe_eval("{{ '%s' % a_variable }}", dict(a_variable=value)) == str(value)
    assert safe_eval("foo[0]", dict(foo=[value])) == value
    assert safe_eval("{'a': value}", dict(value=value)) == {'a': value}

# Generated at 2022-06-11 17:14:05.450002
# Unit test for function safe_eval
def test_safe_eval():

    def _test_safe_eval(msg, expr, expect):
        '''
        The function that does the single safe_eval test
        '''
        # note, the "msg" kw is going to be deprecated, so just
        # include it as the first thing in the assertion message
        try:
            result = safe_eval(expr)
            assert result == expect, "%s: result: %s, expected: %s" % (msg, result, expect)
        except Exception as e:
            if expect is None:
                assert expect is None, "%s: Safe eval should have raised exception: %s" % (msg, e)
            else:
                raise

    # Test the test

# Generated at 2022-06-11 17:14:14.227842
# Unit test for function safe_eval
def test_safe_eval():
    # Test for valid Expressions
    assert isinstance(safe_eval("10"), int)
    assert isinstance(safe_eval("10 * 3"), int)
    assert isinstance(safe_eval("10 / 3"), int)
    assert isinstance(safe_eval("10 + 3"), int)
    assert isinstance(safe_eval("10 - 3"), int)
    assert isinstance(safe_eval("10 // 3"), int)
    assert isinstance(safe_eval("10 % 3"), int)
    assert isinstance(safe_eval("10.0"), float)
    assert isinstance(safe_eval("10.0 + 3.0"), float)
    assert isinstance(safe_eval("10.0 - 3.0"), float)
    assert isinstance(safe_eval("10.0 * 3.0"), float)

# Generated at 2022-06-11 17:14:22.757478
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(C.DEFAULT_SUDO_PASS) == C.DEFAULT_SUDO_PASS
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo }}", include_exceptions=True) == ("{{ foo }}", None)
    assert safe_eval("{{ bogusvariable }}") == "{{ bogusvariable }}"
    assert safe_eval("{{ bogusvariable }}", include_exceptions=True) == ("{{ bogusvariable }}", None)
    assert safe_eval('["foo", "bar", "baz"]') == ["foo", "bar", "baz"]
    assert safe_eval('["foo", "bar", "baz", 1 / 0]') == '["foo", "bar", "baz", 1 / 0]'

# Generated at 2022-06-11 17:14:34.045666
# Unit test for function safe_eval
def test_safe_eval():
    # Specify the CALL_ENABLED here
    CALL_ENABLED.extend(['map', 'zip', 'strict_host_key_checking'])
    # Setup some test cases

# Generated at 2022-06-11 17:14:46.151512
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe eval
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval("['a', 1]") == ['a', 1]
    assert safe_eval("['a', 1, {'a': 1}]") == ['a', 1, {'a': 1}]
    assert safe_eval("'a'") == 'a'
    assert safe_eval("1") == 1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("1.1+1.2") == 2.3
    assert safe_eval("-'a'") == -'a'
    assert safe_eval("-1") == -1
    assert safe_eval("-True") == -True
    assert safe_eval("~1") == ~1
    assert safe_eval

# Generated at 2022-06-11 17:14:55.969215
# Unit test for function safe_eval
def test_safe_eval():
    '''test safe_eval function'''
    # Test list comprehensions
    test_string = "[i for i in range(10)]"
    test_result = safe_eval(test_string)
    assert test_result == test_result
    test_string = "[i for i in range(10)]"
    test_result = safe_eval(test_string)
    test_expected = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert test_result == test_expected
    test_string = "[i for i in range(10)]"
    test_result = safe_eval(test_string)
    test_expected = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert test_result == test_expected

# Generated at 2022-06-11 17:15:05.656067
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.parsing.splitter import parse_kv

    def _t(s, expected, locals=None, e=None):
        t = safe_eval(s, locals=locals)
        assert t == expected, "%s != %s" % (t, expected)

    # various datatypes
    _t("foo", "foo")
    _t('"foo"', "foo")
    _t('"foo bar"', "foo bar")
    _t('["foo"|to_json]', ["foo"])
    _t('{"foo": "bar"|to_json}', {"foo": "bar"})
    _t('True', True)
    _t('False', False)
    _t('None', None)

# Generated at 2022-06-11 17:15:17.712577
# Unit test for function safe_eval
def test_safe_eval():

    # define some data that uses complex objects and a function call
    data = dict(
        list_variable = [1,2,3],
        dictionary_variable = dict(
            a = 1,
            b = 2,
            c = 3,
        ),
        test_bool = True,
        test_none = None,
        test_multiply = '{{ 2 * 2 }}',
    )

    # run against a number of expressions including those that should fail

# Generated at 2022-06-11 17:15:27.645276
# Unit test for function safe_eval
def test_safe_eval():
    def check_eval(expr, expected):
        # Check that expr evals to the given value, with or without
        # callables enabled
        for call_enabled in [True, False]:
            if call_enabled:
                CALL_ENABLED.append(expr)
            try:
                result = safe_eval(expr)
            finally:
                if call_enabled:
                    CALL_ENABLED.remove(expr)

            if result != expected:
                print(expr, 'got:', result, 'expected:', expected)
                return False

        return True

    if sys.version_info.major > 2:
        # dict unpacking is only supported in python3, so don't test it
        check_eval('{k: v for k, v in sample_dict.items()}', {'a': 1, 'b': 2})



# Generated at 2022-06-11 17:15:37.171800
# Unit test for function safe_eval
def test_safe_eval():
    # basic string
    assert safe_eval('foo') == 'foo'
    # basic variables
    assert safe_eval('a', dict(a=True)) is True
    # basic variable substitution
    assert safe_eval('a', dict(a=True)) is True
    # variable with underscore
    assert safe_eval('a_b', dict(a_b=True)) is True
    # missing variable
    assert safe_eval('a') == 'a'
    # complex variable
    assert safe_eval('a.b', dict(a=dict(b=True))) is True
    # complex missing variable
    assert safe_eval('a.b') == 'a.b'

    # bool values
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    #

# Generated at 2022-06-11 17:15:45.709319
# Unit test for function safe_eval
def test_safe_eval():
    # Test if safe_eval prevents unsafe syntax
    assert safe_eval("__import__('os').system('echo pwned')") is None
    assert safe_eval("__import__('__builtin__').eval('__import__(\"os\").system(\"echo pwned\")')") is None

    # Test if safe_eval allows safe syntax
    assert safe_eval("(1 + 2)") == 3
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("'bar'") == 'bar'

    # Test if safe_eval allows safe syntax with locals
    locals = {"foo": "bar"}
    assert safe_eval("foo", locals) == 'bar'

# Generated at 2022-06-11 17:15:55.745275
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval(1) == 1
    assert safe_eval({}) == {}
    assert safe_eval([]) == []

    assert safe_eval("__import__('os').system('id > /tmp/winning')") == "__import__('os').system('id > /tmp/winning')"
    assert safe_eval("1", dict(__import__=__import__)) == "1"
    assert safe_eval("1", dict(__import__=__import__)) == "1"
    assert safe_eval("1", dict(__import__=__import__)).__class__ == str

# Generated at 2022-06-11 17:16:06.667607
# Unit test for function safe_eval
def test_safe_eval():
    # these should pass
    if safe_eval('1 + 1') != 2 or \
       safe_eval('b[2] + c[0]',
                 dict(b=[1, 2, 3], c=[4, 5, 6])) != 5 or \
       safe_eval('foo',
                 dict(foo='bar')) != 'bar' or \
       safe_eval('dict(a=1, b=2)', {}) != dict(a=1, b=2):
        raise Exception("safe_eval doesn't work")

    # these should fail
    failed = 0
    for expr in ['a + b',  # missing locals definition
                 'a[0]']:  # ast.Call is disabled by default
        try:
            safe_eval(expr)
            failed += 1
        except Exception:
            pass

# Generated at 2022-06-11 17:16:16.847874
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:24.329579
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.basic
    # Success case
    expr = 'a_list_variable'
    locals = {'a_list_variable': [1]}
    result, exception = safe_eval(expr, locals, include_exceptions=True)
    assert result == [1]
    assert exception is None

    # Failure case
    expr = 'illegal_function()'
    result, exception = safe_eval(expr, locals, include_exceptions=True)
    assert result == expr
    assert isinstance(exception, Exception)

    # Success case for dict
    expr = 'a_dict_variable'
    locals = {'a_dict_variable': {'a': 1}}
    result, exception = safe_eval(expr, locals, include_exceptions=True)
    assert result == {'a': 1}
   

# Generated at 2022-06-11 17:16:34.738386
# Unit test for function safe_eval
def test_safe_eval():
    """
    Run unit tests for the safe_eval function.
    """

    # needed by python to make sure the module can actually be run.
    if (len(sys.argv) >= 2) and (sys.argv[1] == '--unit'):
        print('Running unit test on safe_eval()')
    else:
        return

    # 1. Testing a number
    try:
        print('Testing a number.')
        result, exception = safe_eval('42', include_exceptions=True)
        if not exception:
            print('Result: {}'.format(result))
        else:
            print('Got an exception: {}'.format(exception))
        print('Result type: {}'.format(type(result)))
    except Exception as e:
        print('Got an exception: {}'.format(e))

    # 2

# Generated at 2022-06-11 17:16:44.585705
# Unit test for function safe_eval
def test_safe_eval():
    # Simple test for safe_eval, check that it does not fail and returns a list
    # for this expression
    test_expression = "[1, 2]"
    test_result = safe_eval(test_expression)
    assert(isinstance(test_result, list))
    # Check for error when passing a function that isn't allowed
    test_expression = "assert"
    try:
        test_result = safe_eval(test_expression)
    except Exception as e:
        assert("assert" in to_native(e))
    # Check that it throws an exception when passing a function
    test_expression = "len('test')"
    try:
        test_result = safe_eval(test_expression)
    except Exception as e:
        pass
    # Check that passing a value that is already templated to a datastructure works
   

# Generated at 2022-06-11 17:16:57.668725
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:08.830978
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2') == 2
    assert safe_eval('-2') == -2
    assert safe_eval('2+2') == 4
    assert safe_eval('2+2*3') == 8
    assert safe_eval('4-(1+1)') == 2
    assert safe_eval('4-1+1') == 4
    assert safe_eval('(4-1)+1') == 4
    assert safe_eval('(4-1)-1') == 2
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('2.2') == 2.2
    assert safe_eval('2.2+2') == 4.2
    assert safe_eval('"a_string"') == "a_string"


# Generated at 2022-06-11 17:17:17.452949
# Unit test for function safe_eval
def test_safe_eval():
    CONF_KEYS = {}

    # some basic data types
    assert(safe_eval('foo') == 'foo')
    assert(safe_eval(42) == 42)
    assert(safe_eval(3.14) == 3.14)
    assert(safe_eval(True) == True)
    assert(safe_eval(None) == None)
    assert(safe_eval({}) == {})
    assert(safe_eval([]) == [])

    # basic arithmetic
    assert(safe_eval('2+3') == 5)
    assert(safe_eval('2-3') == -1)
    assert(safe_eval('2*3') == 6)
    assert(safe_eval('2/3') == 2/3)
    assert(safe_eval('2**3') == 8)

    # parentheses

# Generated at 2022-06-11 17:17:26.960209
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:33.588384
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:43.367989
# Unit test for function safe_eval
def test_safe_eval():
    success = True


# Generated at 2022-06-11 17:17:49.556286
# Unit test for function safe_eval
def test_safe_eval():
    # when we eval a list, it should return a list
    assert isinstance(safe_eval('[1,2,3]'), list)
    assert isinstance(safe_eval('[1,"2",3]'), list)
    assert isinstance(safe_eval('["a","b"]'), list)
    assert isinstance(safe_eval('[[1,2],[1,2]]'), list)
    assert isinstance(safe_eval('[[1,2],[1,"2"]]'), list)

    # when we eval a dict, it should return a dict
    assert isinstance(safe_eval('{1:2,3:4}'), dict)
    assert isinstance(safe_eval('{1:2,3:"4"}'), dict)
    assert isinstance(safe_eval('{"a":2}'), dict)

# Generated at 2022-06-11 17:17:58.287311
# Unit test for function safe_eval
def test_safe_eval():
    def test_expectation(expr, expected):
        result, exception = safe_eval(expr, include_exceptions=True)
        if exception is None:
            if result != expected:
                raise AssertionError("Expected %s from '%s', got %s" % (expected, expr, result))
        else:
            if str(exception) != expected:
                raise AssertionError("Expected exception %s from '%s', got %s" % (expected, expr, result))

    test_expectation('{}', {})
    test_expectation('[]', [])
    test_expectation('1', 1)
    test_expectation('1 + 2', 3)
    test_expectation('1 + 2 * 3', 7)

# Generated at 2022-06-11 17:18:01.953321
# Unit test for function safe_eval
def test_safe_eval():
    if C.ANSIBLE_TEST_FLAGS.get('all', False) or C.ANSIBLE_TEST_FLAGS.get('unit', False):
        import doctest
        doctest.testmod(optionflags=doctest.ELLIPSIS)

# convenience function to do a safe_eval of a list of items, works with
# both strings and datastructures

# Generated at 2022-06-11 17:18:05.489788
# Unit test for function safe_eval
def test_safe_eval():

    # Test for it to run without exceptions
    safe_eval('{ "foo": "bar", "testing": 123 }')

    # Test for exceptions
    try:
        safe_eval("input('test')")
        assert False, "Should have raised exception"
    except Exception:
        pass



# Generated at 2022-06-11 17:18:23.537342
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    # this must be run as python2.
    if sys.version_info[0] != 2:
        print('This must be run as python2.x')
        sys.exit(0)

    # run tests as python2.x
    # first, ensure we exclude the safe functions
    # git fetch origin refs/changes/29/26429/1:refs/changes/29/26429/1 && git checkout FETCH_HEAD
    # remotes/origin/refs/changes/29/26429/1
    # remove the comment so the assert always works.
    if 'func2' in dir(__builtins__):
        del __builtins__.func2

    def func1():
        pass

    def func2():
        pass

    __builtins__.func1 = func1

# Generated at 2022-06-11 17:18:29.702848
# Unit test for function safe_eval
def test_safe_eval():

    # Test 0: Normal python expressions should pass through
    result, exception = safe_eval("foo == 1 or foo == 2", include_exceptions=True)
    assert (result == "foo == 1 or foo == 2")
    assert (exception is None)

    # Test 1: Jinja2 types should pass through
    result, exception = safe_eval("{{foo}}", include_exceptions=True)
    assert (result == "{{foo}}")
    assert (exception is None)

    # Test 2: Invalid expressions should fail
    result, exception = safe_eval('foo()', include_exceptions=True)
    assert (result == 'foo()')
    assert (isinstance(exception, Exception))

    # Test 3: Invalid expressions should fail

# Generated at 2022-06-11 17:18:38.515965
# Unit test for function safe_eval
def test_safe_eval():
    # since this test is only run on python 2.6, we can't rely on
    # the from import syntax that's used in the real function to
    # get ast.Constant so fix up our imports for this test
    if sys.version_info < (2, 7):
        # Need to get ast.Constant from ast library
        import ast
    # Add a couple of extra builtins to our list
    builtins.foo = lambda: 'bar'
    builtins.get = lambda arg: arg

    def test(expr, locals, expected_result=None, expected_exception=None):
        result = safe_eval(expr, locals, include_exceptions=True)
        if expected_result is None:
            expected_result = expr

# Generated at 2022-06-11 17:18:48.163817
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('') is None
    assert safe_eval('none') is None
    assert safe_eval('True') is True
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('False') is False
    assert safe_eval('"a string"') == 'a string'
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('0.1') == 0.1
    assert safe_eval('True or False') is True
    assert safe_eval('True and False') is False
    assert safe_eval('True and True') is True
    assert safe_eval('False and False') is False
    assert safe_eval('True or False') is True
    assert safe_eval('False or False') is False

# Generated at 2022-06-11 17:18:58.157047
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:07.478759
# Unit test for function safe_eval
def test_safe_eval():
    data = [
            ("{{ opt }}", dict(opt="1 + 2"), "3"),
            ("{{ opt|int + 2 }}", dict(opt="1"), "3"),
            ("{{ opt.1 }}", dict(opt=[0, 1, 2]), "1"),
            ("{{ opt.length }}", dict(opt=[0, 1, 2]), "3"),
            ("{{ opt|int + 2 }}", dict(opt={"foo": 3}), "5"),
            ("{{ opt + 2 }}", dict(opt="1"), "None"),
            ("{{ opt + 2 }}", dict(opt="1"), "None"),
            ("{{ opt + 2 }}", dict(opt=[0, 1, 2]), "None"),
            ("{{ opt + 2 }}", dict(opt=[0, 1, 2]), "None"),
        ]


# Generated at 2022-06-11 17:19:16.961332
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0:2] >= (3, 9):
        # dicts are ordered in python3.9+
        rejected_expressions = [
            'dict(a=1, b=2)',
            '{a:1, b:2}',
            '{a:1, b:2,}',
            '{a:1, b:2, "c":3}',
            '{1, 2, 3}',
            'dict([1, 2, 3])',
            'dict((1, 2), (3, 4))',
            'dict([(1, 2), (3, 4)])',
        ]

# Generated at 2022-06-11 17:19:27.683895
# Unit test for function safe_eval
def test_safe_eval():
    assert isinstance(safe_eval("{{foo}}"), string_types)
    assert isinstance(safe_eval('foo'), string_types)
    assert safe_eval('foo', include_exceptions=True)[1] is not None
    assert isinstance(safe_eval('{ "a": 1 }'), dict)
    assert isinstance(safe_eval('[ 1, 2, 3 ]'), list)
    assert isinstance(safe_eval('"foo"'), string_types)
    assert safe_eval('"foo"', include_exceptions=True)[1] is None
    assert safe_eval('foo', include_exceptions=True)[1] is not None
    assert isinstance(safe_eval('bar', locals={'bar': 'foo'}), string_types)
    assert isinstance(safe_eval('1 + 1'), int)

# Generated at 2022-06-11 17:19:37.558564
# Unit test for function safe_eval
def test_safe_eval():
    # success cases
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('{"foo": {"baz": "bar"}}') == {"foo": {"baz": "bar"}}
    assert safe_eval('42') == 42
    assert safe_eval('true')
    assert safe_eval('!true') is False
    assert safe_eval('2+2') == 4
    assert safe_eval('2*3') == 6
    assert safe_eval('"a" * 5') == "aaaaa"
    assert safe_eval('"a" + "b"') == "ab"
    assert safe

# Generated at 2022-06-11 17:19:43.974025
# Unit test for function safe_eval
def test_safe_eval():
    # tests for safe_eval(expr, locals)
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a == 1', dict(a=1)) == True
    assert safe_eval('a_list', dict(a_list=[1,2,3])) == [1,2,3]
    assert safe_eval('a_list[1]', dict(a_list=[1,2,3])) == 2
    assert safe_eval('a_dictionary', dict(a_dictionary={'a': 1, 'b': 2})) == {'a': 1, 'b': 2}
    assert safe_eval('a_dictionary["a"]', dict(a_dictionary={'a': 1, 'b': 2})) == 1
    # specific exceptions

# Generated at 2022-06-11 17:19:58.286749
# Unit test for function safe_eval
def test_safe_eval():
    # this should return 10
    val = safe_eval("5 + 5")
    assert val == 10

    # this should be "unsafe" and return None
    val = safe_eval("__import__('os').system('touch /tmp/evil')")
    assert val is None, val

    # This should return None as well, because it attempts to access
    # a restricted builtin.
    val = safe_eval("__import__('datetime').datetime.now()")
    assert val is None, val

    # This should return None as well, because str() is not a safe callable
    val = safe_eval("str(5)")
    assert val is None, val

    # this should return the string "5" (as a string)
    val = safe_eval("str(5)", include_exceptions=True)
    assert val

# Generated at 2022-06-11 17:20:05.823767
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:15.550454
# Unit test for function safe_eval
def test_safe_eval():
    import nose.tools

    nose.tools.raises(Exception, safe_eval, "a.b.c")
    nose.tools.raises(Exception, safe_eval, "{{ a.b.c }}")
    nose.tools.raises(Exception, safe_eval, "{% for a in b %}{% endfor %}")
    nose.tools.raises(Exception, safe_eval, "{# a #}")
    nose.tools.raises(Exception, safe_eval, "a + b[c]")
    nose.tools.raises(Exception, safe_eval, "d()")
    nose.tools.raises(Exception, safe_eval, "len(a)")
    nose.tools.raises(Exception, safe_eval, "pow(a,b)")

# Generated at 2022-06-11 17:20:22.696846
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test for function safe_eval
    '''
    def test_okay(expr):
        '''
        Test that safe_eval() works correctly when given an ok expression
        '''
        result = safe_eval(expr)
        expected = eval(expr)
        assert result == expected

    def test_fail(expr):
        '''
        Test that safe_eval() raises an exception when the expression is not safe
        '''
        try:
            safe_eval(expr)
        except Exception as e:
            # check if the error message has been correctly passed in
            assert 'invalid expression' in str(e)
        else:
            # test failed if no exception was raised
            assert False

    test_okay("1 + 2")
    test_okay("-10 + -4")
    test_okay

# Generated at 2022-06-11 17:20:29.454173
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.common.text.converters import to_text

    with pytest.raises(Exception) as e:
        safe_eval('foo()')
    assert 'invalid function' in to_text(e)

    with pytest.raises(Exception) as e:
        safe_eval('a.b.c.d')
    assert 'invalid expression' in to_text(e)

    # this should just return the string
    assert safe_eval('foo()') == 'foo()'

    # basic math expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 + 1') == 3
    assert safe_eval('f + f', dict(f=3)) == 6

# Generated at 2022-06-11 17:20:38.551830
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval.
    '''

    # These lines will fail when safe_eval is fixed
    #
    # The following test cases are based on the discussion here:
    # http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    #
    # For example, this expression is evil because it does not
    # belong to the whitelist:
    evil_code = """
                    __import__("subprocess").check_output("touch /tmp/pwned", shell=True)
                """
    # No matter how you try to disguise it, we'll detect it:
    evil_code_disguised = evil_code.replace("subprocess", "spam")
    evil_code_disguised = evil_code_

# Generated at 2022-06-11 17:20:46.161636
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Function to unit test expression evaluation using safe_eval()
    '''
    expr_ok = dict(
        dict_expr="{'a': 1, 'b': 2}",
        list_expr="[1, 2, 3]",
        string_expr="'abc'",
        num_expr="1",
        true_expr="true",
        false_expr="false",
        none_expr="null",
        bool_expr="true and false or true"
    )
    builtin_functions = dict(
        open='open',
        execfile='execfile',
        range='range',
        enumerate='enumerate'
    )

# Generated at 2022-06-11 17:20:57.963003
# Unit test for function safe_eval
def test_safe_eval():
    # Some safe expressions
    assert 'foo' == safe_eval("'foo'")
    assert 'foo' == safe_eval("\"foo\"")
    assert 'foo' == safe_eval("u'foo'")
    assert 'foo' == safe_eval("u\"foo\"")
    assert 'foo' == safe_eval("vars()['foo']")
    assert 'foo' == safe_eval("vars().get('foo')")
    assert ['foo'] == safe_eval("['foo']")
    assert ['foo'] == safe_eval("vars()['foo'] or ['foo']")
    assert [] == safe_eval("[]")
    assert [] == safe_eval("vars()['foo'] or []")
    assert (1, 2, 3) == safe_eval("(1, 2, 3)")
    assert None is safe

# Generated at 2022-06-11 17:21:06.841022
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:15.278319
# Unit test for function safe_eval
def test_safe_eval():

    # dicts
    expr = '{\'a\':1,\'b\':2,\'c\':True}'
    evaluated = safe_eval(expr)
    assert isinstance(evaluated, dict)
    assert evaluated['a'] == 1

    # tuples
    expr = '("a", "b", "c")'
    evaluated = safe_eval(expr)
    assert isinstance(evaluated, tuple)
    assert evaluated[0] == 'a'

    # lists
    expr = '["a", "b", "c"]'
    evaluated = safe_eval(expr)
    assert isinstance(evaluated, list)
    assert evaluated[0] == 'a'

    # unicode
    expr = 'u"foo"'

# Generated at 2022-06-11 17:21:31.804170
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:41.338137
# Unit test for function safe_eval
def test_safe_eval():
    dump_errors = True
    if dump_errors:
        def assert_false(expr):
            actual, error = safe_eval(expr, include_exceptions=True)
            if error is None:
                raise Exception("expected error for: %s" % expr)
            return False

        def assert_true(expr):
            actual, error = safe_eval(expr, include_exceptions=True)
            if error is not None:
                raise Exception("unexpected error for: %s" % expr)
            return True

        def assert_eval(expr, expected):
            actual, error = safe_eval(expr, include_exceptions=True)
            if error is not None:
                raise Exception("unexpected error for: %s" % expr)

# Generated at 2022-06-11 17:21:49.849408
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic tests for safe_eval()
    '''

    # Lists should eval
    lst = [1, 2, 3]
    lst_str = "[1, 2, 3]"
    assert safe_eval(lst_str) == lst

    # Dictionaries should eval
    dct = {'a': 1, 'b': 2}
    dct_str = "{'a': 1, 'b': 2}"
    assert safe_eval(dct_str) == dct

    # Tuples should eval
    tpl = (1, 2)
    tpl_str = "(1, 2)"
    assert safe_eval(tpl_str) == tpl

    # Basic addition and subtraction
    assert safe_eval('1 + 2') == 3
    assert safe_eval('2 - 1') == 1


# Generated at 2022-06-11 17:21:57.040166
# Unit test for function safe_eval
def test_safe_eval():
    # Different types of expressions
    expressions = (
        "1 == 1",
        "true",
        "false",
        "null",
        "[1, 2, 3]",
        "[1, 2, { 'foo': 1 + 2, 'bar': '{ \"hi\": \"there\" }' }]",
        "(1, 2, 3)",
        "foo",
        "foo or bar",
        "foo and bar",
        "foo in bar",
        "foo not in bar",
        "foo and bar or baz",
    )

    # Unit tests to test that all expressions return correctly
    # without raising any exceptions
    def test_success(module):
        for expression in expressions:
            assert module.safe_eval(expression) is not None

    # Unit tests to test that some specified expressions return
    # an exception when tested by

# Generated at 2022-06-11 17:22:05.838743
# Unit test for function safe_eval
def test_safe_eval():
    # eval should fail on malicious code
    assert None == safe_eval('__import__("os").system("touch /tmp/ansible-test")')

    # json types
    assert True == safe_eval('true')
    assert False == safe_eval('false')
    assert None == safe_eval('null')

    # normal evaluation
    assert 2 == safe_eval('(1 + 1)')
    assert 2 == safe_eval('((1 + 1))')
    assert 2 == safe_eval('(((1 + 1)))')
    assert 2 == safe_eval('1 + 1')
    assert 2 == safe_eval('1 +\n 1')
    assert 2 == safe_eval('(1 +\n 1)')
    assert 3 == safe_eval('(1 +\n 1 + 1)')

# Generated at 2022-06-11 17:22:16.373377
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:26.680017
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test that safe_eval does not permit calling of builtins other than those
    included in the CALL_ENABLED list.
    """
    # These builtin functions are permitted
    CALL_ENABLED.extend(['dict', 'len', 'list'])

    # These calls are valid, should not raise an exception
    safe_eval('dict(a=1)')
    safe_eval('len(a)', {'a': range(5)})
    safe_eval('list(a)', {'a': range(5)})


# Generated at 2022-06-11 17:22:37.378949
# Unit test for function safe_eval
def test_safe_eval():
    def raise_exception(msg):
        raise Exception(msg)

    assert safe_eval(None) is None

    # test strings
    assert safe_eval('string') == 'string'

    # test numbers
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1

    # test booleans
    assert safe_eval('true') is True
    assert safe_eval('false') is False

    # test lists
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

    # test tuples
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

    # test sets
    assert safe_eval('{1, 2, 3}') == {1, 2, 3}

    # test dicts

# Generated at 2022-06-11 17:22:47.293937
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests
    assert safe_eval('"  "') == '  '

    # try some arithmetic expressions
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 - 2') == -1
    assert safe_eval('1 * 2') == 2
    assert safe_eval('1 / 2') == 0.5

    # try some boolean expressions
    assert safe_eval('1 == 2') is False
    assert safe_eval('1 != 2') is True
    assert safe_eval('1 < 2') is True
    assert safe_eval('1 > 2') is False
    assert safe_eval('1 <= 2') is True
    assert safe_eval('1 >= 2') is False

    # try a boolean expression with parentheses
    assert safe_eval('(1 < 2) and (2 < 3)') is True

    #

# Generated at 2022-06-11 17:22:51.269953
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:15.527545
# Unit test for function safe_eval
def test_safe_eval():
    # constants
    assert safe_eval('123') == 123
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    # arithmetic operations
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('6 / 2') == 3
    assert safe_eval('1 - 2') == -1
    assert safe_eval('-2') == -2
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('1/2') == 0.5
    assert safe_eval('True and False') is False
    assert safe_eval('1 == 2 and 2 == 2') is False
    assert safe

# Generated at 2022-06-11 17:23:21.304298
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid inputs
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']
    assert safe_eval("['foo', null, 'baz']") == ['foo', None, 'baz']
    assert safe_eval("['foo', true, 'baz']") == ['foo', True, 'baz']
    assert safe_eval("['foo', false, 'baz']") == ['foo', False, 'baz']
    assert safe_eval("['foo', true, 'baz']") == ['foo', True, 'baz']
    assert safe_eval("['foo', 'bar', null, 'baz']") == ['foo', 'bar', None, 'baz']
    assert safe_eval("[('foo', 'bar'), ('baz', 'bam')]")

# Generated at 2022-06-11 17:23:32.644421
# Unit test for function safe_eval
def test_safe_eval():
    # Test that we can evaluate a constant string
    assert safe_eval('a constant string') == 'a constant string'
    # Test that we return strings as is if they cannot be evaluated
    assert safe_eval('{{a_function()}}') == '{{a_function()}}'
    # Test that we return strings as is if they cannot be evaluated
    assert safe_eval('{{a_function()}}') == '{{a_function()}}'
    # Test that we can evaluate an integer
    assert safe_eval('{{ 1 }}') == 1
    # Test that we can evaluate an integer plus another integer
    assert safe_eval('{{ 1 + 1 }}') == 2
    # Test that we can evaluate an integer minus another integer
    assert safe_eval('{{ 1 - 1 }}') == 0
    # Test that we can evaluate an integer times another integer
    assert safe