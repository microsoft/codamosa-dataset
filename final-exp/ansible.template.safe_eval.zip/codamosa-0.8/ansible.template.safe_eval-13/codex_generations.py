

# Generated at 2022-06-11 17:13:33.991237
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval with a more complex string with conditions
    assert safe_eval('foo == bar') is False
    assert safe_eval('foo == foo') is True
    assert safe_eval('foo != bar') is True
    assert safe_eval('foo != foo') is False
    assert safe_eval('foo and bar') is None
    assert safe_eval('foo or bar') is 'foo'
    assert safe_eval('not foo') is False
    assert safe_eval('not not foo') is 'foo'
    assert safe_eval('foo <= bar') is False
    assert safe_eval('foo <= foo') is True
    assert safe_eval('foo >= bar') is True
    assert safe_eval('foo >= foo') is True
    assert safe_eval('foo < bar') is False
    assert safe_eval('foo < foo') is False


# Generated at 2022-06-11 17:13:42.718610
# Unit test for function safe_eval

# Generated at 2022-06-11 17:13:54.047515
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function safe_eval
    '''
    # True
    expr = 'True'
    result = safe_eval(expr)
    assert isinstance(result, bool), "Boolean failed for %s" % expr

    # False
    expr = 'False'
    result = safe_eval(expr)
    assert isinstance(result, bool), "Boolean failed for %s" % expr

    # None
    expr = 'None'
    result = safe_eval(expr)
    assert result is None, "None failed for %s" % expr

    # define a list
    expr = '["item_1", "item_2", "item_3"]'
    result = safe_eval(expr)
    assert isinstance(result, list), "List failed for %s" % expr

    # define a list

# Generated at 2022-06-11 17:14:05.523542
# Unit test for function safe_eval
def test_safe_eval():
    # Test to ensure that safe_eval blocks dangerous constructs
    # before parsing begins
    assert safe_eval('__import__("os")') == '__import__("os")'

    # Test for the three types of values supported by safe_eval
    assert safe_eval('1') == 1
    assert safe_eval('"1"') == "1"
    assert safe_eval('["a", "b"]') == ["a", "b"]

    # Test for proper handling of Python data structures
    assert safe_eval('[1, [2, 3]]') == [1, [2, 3]]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('["a", {"b": 1}]') == ["a", {"b": 1}]

    # Test

# Generated at 2022-06-11 17:14:14.263438
# Unit test for function safe_eval
def test_safe_eval():
    # Simple safe values
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval('{{ lookup("file", "/etc/hosts") }}', include_exceptions=True) == ('{{ lookup("file", "/etc/hosts") }}', None)

    # boolean as a string

# Generated at 2022-06-11 17:14:22.787132
# Unit test for function safe_eval
def test_safe_eval():
    '''This test is a basic validation of safe_eval. It is by no means
    complete, as the Python AST syntax is quite large. It should be
    extended as bugs are discovered.'''

    # Test simple built-in functions
    assert safe_eval("len([1,2,3])") == 3
    assert safe_eval("abs(-20)") == 20

    # Test allowed math operators
    assert safe_eval("3+3") == 6
    assert safe_eval("3-3") == 0
    assert safe_eval("3*3") == 9
    assert safe_eval("15/3") == 5
    assert safe_eval("15//3") == 5
    assert safe_eval("2**3") == 8
    assert safe_eval("-3") == -3

    # Test boolean constants

# Generated at 2022-06-11 17:14:33.946627
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:46.151762
# Unit test for function safe_eval
def test_safe_eval():
    def assert_safe_eval_success(expr, expected):
        result = safe_eval(expr)
        assert result == expected, "safe_eval failed: '%s' -> '%s' != '%s'" % (expr, result, expected)

    def assert_safe_eval_fail(expr, expected_error_msg):
        result = safe_eval(expr)
        assert result == expr, "safe_eval failed: '%s' -> '%s' != '%s'" % (expr, result, expr)


# Generated at 2022-06-11 17:14:52.913634
# Unit test for function safe_eval
def test_safe_eval():
    # test that following Python expressions are equivalent to their
    # expected results.

    def _assert_safe_eval(expr, expected):
        result, exception = safe_eval(expr, include_exceptions=True)
        if exception is not None:
            assert False, "Unexpected exception from safe_eval: %s" % exception
        assert (result == expected), "safe_eval returned '%s' for expression %s, expected %s" % (result, expr, expected)

    # used to ensure our set of safenode types is sufficient
    # to support these items
    _assert_safe_eval("[1,2,3 + 4, True and False]", [1, 2, 7, False])
    _assert_safe_eval("{'a':5, 'b':10}", {"a": 5, "b": 10})

    #

# Generated at 2022-06-11 17:15:04.331071
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:17.043065
# Unit test for function safe_eval
def test_safe_eval():

    safe_eval("'a string'")
    safe_eval("[1,2,3]")
    safe_eval("{'a':True}")
    safe_eval("43")
    safe_eval("[1,2,3,(4,5,6)]")
    safe_eval("-32")
    safe_eval("-32+1")
    safe_eval("-32-1")
    safe_eval("True")
    safe_eval("False")
    safe_eval("None")
    safe_eval("false")
    safe_eval("true")
    safe_eval("null")

    # TODO: these cause SyntaxError, is that expected?
    #safe_eval("{u'a':True}")
    #safe_eval("{u'a':True, u'b':False}")

   

# Generated at 2022-06-11 17:15:27.104518
# Unit test for function safe_eval
def test_safe_eval():
    # For a syntax error we return the string
    # Note : this test will fail if the 'eval' string is changed to 'exec' instead of 'eval'
    test_str = u'this_is_a_s_tr!n(g'
    assert safe_eval(test_str) == test_str

    # Constant should be returned as a number
    test_str = u'42'
    assert safe_eval(test_str) == 42

    # Constant should be returned as a boolean
    test_str = u'True'
    assert safe_eval(test_str) == True

    # Constant should be returned as a boolean
    test_str = u'False'
    assert safe_eval(test_str) == False

    # Constant should be returned as None
    test_str = u'None'

# Generated at 2022-06-11 17:15:36.745239
# Unit test for function safe_eval
def test_safe_eval():
    # Test that a string with unallowed calls cannot be evaluated
    assert safe_eval("'foo'.upper()") == "'foo'.upper()"
    # Test that a simple list can be evaled
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    # Test that a builtin operator can be evaled
    assert safe_eval("2**2") == 4
    # Test that a builtin operator with unallowed calls cannot be evaled
    assert safe_eval("'foo'.upper()=='foo'.upper()") == "'foo'.upper()=='foo'.upper()"
    # Test that a simple dict can be evaled
    assert safe_eval("{'foo':'bar'}") == {'foo': 'bar'}
    # Test that a simple boolean can be evaled
    assert safe_eval("True")

# Generated at 2022-06-11 17:15:45.528351
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:55.649210
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a * (b + c)') == 'a * (b + c)'
    assert safe_eval('foo') == 'foo'
    assert not safe_eval('foo')
    assert safe_eval('1') == 1
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval(10) == 10
    assert safe_eval('10') == 10
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.1') != 1
    assert safe_eval(True)
    assert safe_eval('true')
    assert safe_eval({'a': 'b'}) == {'a': 'b'}
    assert safe_eval([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 17:16:06.489652
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:15.639962
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:23.877375
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:34.555746
# Unit test for function safe_eval
def test_safe_eval():

    # Test 1: Basic operation
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}

    # Test 2: Make sure we can't call things that aren't whitelisted
    assert safe_eval('open') == 'open'

    # Test 3: Make sure we can't get to builtins
    assert safe_eval('__import__("sys").version') == '__import__("sys").version'

    # Test 4: Make sure we can't get to builtins with a nested function call
    assert safe_eval('"abc".join(["a", "b", "c"])') == '"abc".join(["a", "b", "c"])'

    # Test 5: Make sure we can't get to builtins by passing a string as a kwarg

# Generated at 2022-06-11 17:16:44.380713
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This function should return True if all the tests pass,
    and False if any of the tests fail. The test set includes
    the following tests:
    1) Evaluate safe expressions (should pass)
    2) Evaluate unsafe expressions (should fail)
    3) Evaluate an expression with a function call (should pass or fail depending on the include_exceptions parameter)
    4) Evaluate a string that is not an expression (should pass)
    Return (True, [passed, failed, total]) if all pass,
    (False, [passed, failed, total]) if at least one fails.
    '''

    call_enabled = ['enumerate', 'min', 'max', 'print']
    for f in call_enabled:
        CALL_ENABLED.append(f)

# Generated at 2022-06-11 17:16:59.387741
# Unit test for function safe_eval
def test_safe_eval():
    #Test simple
    test_dict = {'a': 'foo', 'b': 42}
    assert safe_eval("a", test_dict) == 'foo'
    assert safe_eval("b", test_dict) == 42

    #Test Arithmetic
    assert safe_eval("1+1", test_dict) == 2
    assert safe_eval("0+0", test_dict) == 0
    assert safe_eval("-1+1", test_dict) == 0
    assert safe_eval("b % 1", test_dict) == 0
    assert safe_eval("b * b", test_dict) == 1764
    assert safe_eval("b - b", test_dict) == 0
    assert safe_eval("b ** b", test_dict) == 4228250625
    assert safe_eval("b / b", test_dict)

# Generated at 2022-06-11 17:17:10.372474
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("a_list_variable", {"a_list_variable": [1, 2, 3]}) == [1, 2, 3]
    assert safe_eval("a_dict_variable", {"a_dict_variable": {'a': 1, 'b': 2}}) == {'a': 1, 'b': 2}
    assert safe_eval("a_string_variable", {"a_string_variable": "a_string"}) == "a_string"
    assert safe_eval("a_set_variable", {"a_set_variable": set([1,2,3])}) == set([1,2,3])

    # Ensure that we properly handle in-line comments
    assert safe_eval("1 + 1 # This is a comment") == 2

    # Ensure that we return

# Generated at 2022-06-11 17:17:19.146257
# Unit test for function safe_eval
def test_safe_eval():
    # This function should not raise an exception
    assert safe_eval('1 + 1') == 2
    # These functions should raise an exception
    assert safe_eval('sys') != None
    assert safe_eval('__import__') != None
    assert safe_eval('__import__("os").system("echo hello")') != None
    # This should not raise an exception
    assert safe_eval('__builtins__.str(1)') == '1'
    # This should raise an exception
    assert safe_eval('__builtins__.str(__import__("os").system("echo hello"))') != None
    # This should not raise an exception
    assert safe_eval('false') == False
    # This should raise an exception
    assert safe_eval('globals()["__builtins__"]["__import__"]') != None
    #

# Generated at 2022-06-11 17:17:27.986960
# Unit test for function safe_eval
def test_safe_eval():
    # test safe eval
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('2 + 3 + 4') == 9
    assert safe_eval('2 * 3 * 4') == 24
    assert safe_eval('2**64') == 2**64
    assert safe_eval('[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('1 < 2')
    assert not safe_eval('1 > 2')
    assert safe_eval('1 <= 2')
    assert not safe_eval('1 >= 2')
    assert safe_eval('1 == 1')
    assert not safe_eval('1 == 2')
    assert safe_eval('1 != 2')
   

# Generated at 2022-06-11 17:17:37.640638
# Unit test for function safe_eval
def test_safe_eval():
    if safe_eval("'foo'") != 'foo':
        raise Exception("safe_eval 1 failed")
    if safe_eval("a.keys()", dict(a=dict(b=1))) != ['b']:
        raise Exception("safe_eval 2 failed")
    if safe_eval("a.keys()", dict(a=10)) != 10:
        raise Exception("safe_eval 3 failed")
    if safe_eval("7") != 7:
        raise Exception("safe_eval 4 failed")
    if safe_eval("'7'") != '7':
        raise Exception("safe_eval 5 failed")
    if safe_eval("7", dict(a=10)) != 7:
        raise Exception("safe_eval 6 failed")

# Generated at 2022-06-11 17:17:43.401224
# Unit test for function safe_eval
def test_safe_eval():
    """
    This function performs a unit test for safe_eval.  It is
    meant to be called from the command line.

    This is a subset of tests performed by the same function
    in test/sanity/code-smell/eval.yml, which is a more complete
    set of tests.
    """
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils import basic

    num_failed = 0
    num_testcases = 0


# Generated at 2022-06-11 17:17:49.578065
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:58.309624
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('5') == 5
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{1: "a"}') == {1: "a"}
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []
    assert safe_eval('"foo"') == 'foo'

    # math
    assert safe_eval('5 + 5') == 10
    assert safe_eval('5 + 5 + 5') == 15
    assert safe_eval('5 - 1') == 4
    assert safe_eval('5 + 1 - 3') == 3
    assert safe_eval('5 * 2') == 10
    assert safe_eval('5 * 5 * 2') == 50
    assert safe_eval('10 / 2') == 5
    assert safe_eval

# Generated at 2022-06-11 17:18:06.288399
# Unit test for function safe_eval
def test_safe_eval():
    '''
    function to return results of unit test for function safe_eval
    '''

    # change ansible config options to allow more calls
    C.ANSIBLE_ALLOW_CALL_MODULES = True
    C.ANSIBLE_ALLOW_CALL_FUNCTIONS = True
    C.ANSIBLE_ALLOW_SIMPLE_CALLABLE_TYPES = True
    C.ANSIBLE_ALLOW_COMPLEX_CALLABLE_TYPES = True

    # set call_enabled to the list of callable names
    call_enabled = list(set(C.CALLABLE_WHITELIST + C.ALWAYS_SAFE_CALLABLES))

    # set call_enabled to the list of callable names

# Generated at 2022-06-11 17:18:15.849155
# Unit test for function safe_eval
def test_safe_eval():
    # Assertions are used by unit tests and in the code itself to check for violations
    # of the rules governing safe evaluation of Jinja2 expressions.

    # Allowed Operations and Constructs
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo == "foo"')
    assert safe_eval('foo is defined')
    assert safe_eval('foo is not defined')
    assert safe_eval('foo in [1, 2, 3]')
    assert safe_eval('foo not in [1, 2, 3]')
    assert safe_eval('foo in bar')
    assert safe_eval('foo not in bar')
    assert safe_eval('foo == [1, 2, 3]')
    assert safe_eval('foo != [1, 2, 3]')
    assert safe_eval('foo is bar')
    assert safe

# Generated at 2022-06-11 17:18:30.046964
# Unit test for function safe_eval
def test_safe_eval():
    # This tests the basic functionality of safe_eval.
    # TODO: Add more tests
    # TODO: Should this be moved to a test module?

    def safe_test(test_case):
        """
        Safely evaluate test_case[0] using safe_eval,
        compare it to test_case[1] and test_case[2]
        """
        expr = test_case[0]
        expected = test_case[1]
        expected_result = test_case[2]

        result = safe_eval(expr, include_exceptions=True)

        if isinstance(expected_result, Exception):
            assert isinstance(result[1], expected_result.__class__), 'Failed to catch exception for %s. "%s" != "%s"' % (expr, result[1], expected_result)

# Generated at 2022-06-11 17:18:38.721560
# Unit test for function safe_eval
def test_safe_eval():
    import os.path
    env = os.environ
    sys.path.append('/tmp/')
    locals = {'__file__': '/tmp/test_safe_eval'}


# Generated at 2022-06-11 17:18:48.312350
# Unit test for function safe_eval
def test_safe_eval():

    # Note: we cannot check the same strings in Python 2.x and 3.x, so
    # we need to define the expected expression valies twice:
    if sys.version_info < (3,):
        true_val = True
        false_val = False
        none_val = None
        int_val = 47
        float_val = 5.75
        string_val = 'hello'
        string2_val = 'world'
        list_val = [1, 2, 3, "hello", None]
        dict_val = {
            "a": 1,
            "b": [2, 3, "hello", None],
            "c": {
                "d": 5,
                "e": "world",
            }
        }
    else:
        true_val = True
        false_val = False
        none

# Generated at 2022-06-11 17:18:58.227922
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test suite for function safe_eval
    '''
    # Test list
    test_list = []

    # Test class
    class TestClass(object):
        def __init__(self, name, enabled):
            self.name = name
            self.enabled = enabled

        def must_be_called(self):
            return 'Called'

    # Test dict
    test_dict = {
        'foo': 'bar',
        'baz': 'qux'
    }

    # Test list
    test_list = ['foo', 'bar']

    # Test object
    test_obj = TestClass('Foo', True)

    # Test cases

# Generated at 2022-06-11 17:19:07.555923
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:17.031128
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, expected, local=None):
        if local is None:
            local = {}
        result = safe_eval(expr, local)
        if result != expected:
            print("TEST FAILED: safe_eval(%s) returned %s, but expected %s" % (expr, result, expected))
            sys.exit(1)
        print("TEST SUCCEEDED: safe_eval(%s) returned %s, expected %s" % (expr, result, expected))

    _test('foo', 'foo')
    # test some dict and lists
    _test('{ "a": 1, "b": 2 }', {'a': 1, 'b': 2})
    _test('[ "a", "b" ]', ['a', 'b'])
    # test dict and lists with jinja2

# Generated at 2022-06-11 17:19:27.723069
# Unit test for function safe_eval
def test_safe_eval():
    # Test if a valid expression evalutes correctly
    expr = 'ansible_memtotal_mb > 512'
    result = safe_eval(expr, dict(ansible_memtotal_mb=1024), include_exceptions=True)
    assert result[0] is True

    # Test if invalid expression raises an exception
    expr = 'ansible_memtotal_mb >'
    result = safe_eval(expr, dict(ansible_memtotal_mb=1024), include_exceptions=True)
    assert isinstance(result[1], Exception)

    # Test if a string (non-evaluable) simply returns back
    expr = 'ansible_memtotal_mb'
    result = safe_eval(expr, dict(ansible_memtotal_mb=1024), include_exceptions=True)
    assert result[0] == expr

    # Test

# Generated at 2022-06-11 17:19:37.605427
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:47.060388
# Unit test for function safe_eval
def test_safe_eval():
    from random import choice


# Generated at 2022-06-11 17:19:57.092899
# Unit test for function safe_eval
def test_safe_eval():

    constants = dir(C)

    # add in a few special cases that are different
    constants += ['null', 'false', 'true']

    print("\n")
    print("UNIT TEST START: test_safe_eval")
    print("==============================")

    # test data - input_expr, expected, safe_expr
    # expected is the expected result of safe_eval()
    # safe_expr is the expected result of safe_eval(include_exceptions=True)
    #
    # The two different types of tests:
    #   test_data_00: a valid expression which should evaluate OK
    #   test_data_01: an invalid expression which should throw an exception


# Generated at 2022-06-11 17:20:19.513799
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:27.090046
# Unit test for function safe_eval
def test_safe_eval():
    class TestException(Exception):
        pass

    class CleansingNodeVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            raise TestException("ast.NodeVisitor shouldn't be called!")

    cnv = CleansingNodeVisitor()
    field = 'name'
    good_expr_1 = "some" + field + "string"
    ast.parse(good_expr_1, mode='eval')
    good_expr_2 = "a" + "b" + "c"
    ast.parse(good_expr_2, mode='eval')
    good_expr_3 = "some_number * 2.0"
    ast.parse(good_expr_3, mode='eval')
    good_expr_4 = "a_list_variable"

# Generated at 2022-06-11 17:20:36.038845
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'a[1] + b[2] + foo(z=3) + false + null + true + True + False'
    expected = {'a': [1], 'b': [2], 'z': 3}
    locals = expected.copy()

    # test default behavior
    assert expr == safe_eval(expr)

    # test with valid expression
    result = expr
    for k in expected:
        result = result.replace(k, '%s' % expected[k])
    result = ast.literal_eval(result)
    assert result == safe_eval(expr, locals)

    # test with invalid expression
    # note: this is a valid expression but we don't permit Call nodes
    assert expr == safe_eval('2 + 3')

    # test with invalid function call

# Generated at 2022-06-11 17:20:46.117503
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 < 2') is True
    assert safe_eval('1 < 0') is False
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1*2') == 3
    assert safe_eval('1/2') == 0.5
    assert safe_eval('2**10') == 1024
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a":1, "b":2}') == {"a": 1, "b": 2}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('str(1)') == "1"



# Generated at 2022-06-11 17:20:57.900141
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:05.423494
# Unit test for function safe_eval
def test_safe_eval():
    C.DEFAULT_KEEP_REMOTE_FILES = True
    from io import StringIO

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout

    with Capturing() as output:
        print("** expression: foo")

        ret = safe_eval("foo")
        print(" safe_eval returns:", to_native(ret))

        print("** expression: 1")

        ret = safe_eval("1")

# Generated at 2022-06-11 17:21:14.546515
# Unit test for function safe_eval
def test_safe_eval():
    # basic math stuff
    assert safe_eval('2 * 3 + 5') == 11

    # dictionaries
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("dict(a=1,b=2)") == dict(a=1,b=2)

    # tuples
    assert safe_eval("(1,2,3)") == (1,2,3)
    assert safe_eval("1,2,3") == (1,2,3)

    # lists
    assert safe_eval("[1,2,3]") == [1,2,3]

    # booleans
    assert safe_eval("true") == True
    assert safe_eval("false") == False

    # null
    assert safe_eval("null") == None



# Generated at 2022-06-11 17:21:20.691286
# Unit test for function safe_eval
def test_safe_eval():
    # Check safe_eval
    if sys.version_info[0] >= 3:
        exec("def unit_test_function():\n  return True")
        unit_test_function = locals()["unit_test_function"]
    else:
        exec("def unit_test_function():\n  return True\nunit_test_function = locals()['unit_test_function']")
    try:
        safe_eval(unit_test_function())
    except Exception as e:
        raise AssertionError("safe_eval should return function value")



# Generated at 2022-06-11 17:21:30.561317
# Unit test for function safe_eval
def test_safe_eval():
    # we don't care too much about the specific exceptions that might be thrown
    # by safe_eval, the important thing is that no exceptions should be thrown
    # by valid expressions and some exceptions should be thrown by invalid ones
    def assert_no_exceptions_raised(expr):
        ret, e = safe_eval(expr, {}, include_exceptions=True)
        assert ret is not None, "%s: no exception but ret is None" % expr
        assert e is None, "%s: not exception but got %s" % (expr, e)

    def assert_exception_raised(expr):
        ret, e = safe_eval(expr, {}, include_exceptions=True)
        assert ret is None, "%s: exception but ret is not None" % expr

# Generated at 2022-06-11 17:21:40.188257
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Testing the safe_eval function.
    '''

    # Test a few valid expressions
    assert safe_eval('1') == 1
    assert safe_eval('2 + 3') == 5
    assert eval(safe_eval('[1, 2, 3]')) == [1, 2, 3]
    assert eval(safe_eval('{1: 2, 2: 3, 3: 4}')) == {1: 2, 2: 3, 3: 4}
    assert safe_eval('1 == 1')

    # Boolean expressions
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('null') is None
    assert safe_eval('1 and true') is True
    assert safe

# Generated at 2022-06-11 17:22:18.089596
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluating Insecure Expression
    try:
        result = safe_eval('dict')
    except Exception as e:
        assert str(e).startswith('invalid expression (dict)')
    else:
        raise AssertionError('Evaluating Insecure Expression should throw exception.')

    # Evaluating Secure Expression
    result = safe_eval('[0, 1, 2, 3]')
    assert result == [0, 1, 2, 3], result

    # Evaluating Secure String
    result = safe_eval('[]')
    assert result == [], result

    # Evaluating An Invalid Expression, we just return
    # the expression string back as-is to support late evaluation
    result = safe_eval('foobar')
    assert result == 'foobar', result

    # Evaluating Secure Expression with custom locals

# Generated at 2022-06-11 17:22:28.078958
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:38.226568
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 + 2 * 3") == 7
    assert safe_eval("(1 + 2) * 3") == 9
    assert safe_eval("-3") == -3
    assert safe_eval("1.5 * 2.5") == 3.75

    # lists
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("[1,[2,3]]") == [1,[2,3]]

    # dicts
    assert safe_eval("{'a':1}") == {'a':1}
    assert safe_eval("{'a':[1,2]}") == {'a':[1,2]}

    # tuple

# Generated at 2022-06-11 17:22:48.167009
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval('[1,2,3]') == [1,2,3])
    assert(safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3], None))

    # This will raise an exception because the caller
    # tries to call string.join()
    assert(safe_eval("{% if True %}Foo{% endif %}") == 'Foo')
    assert(safe_eval("{% if True %}Foo{% endif %}", include_exceptions=True) == ('Foo', None))

    # This will raise an exception because the caller
    # tries to call string.join()
    assert(safe_eval("{{ foo }}", {'foo': 'bar'}) == 'bar')

# Generated at 2022-06-11 17:22:57.710863
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("5 * 5") == 25
    assert safe_eval("-5 * 5") == -25
    assert safe_eval("8/5") == 1.6
    assert safe_eval("2**3") == 8
    assert safe_eval("~4") == -5
    assert safe_eval("-4") == -4
    assert safe_eval("-4 - 2") == -6
    assert safe_eval("-4 - +2") == -6
    assert safe_eval("-4 - -2") == -2
    assert safe_eval("-4--2") == -2
    assert safe_eval("+-1") == -1
    assert safe_eval("-6 - -2") == -4
    assert safe_eval("1 > 2") is False
    assert safe_eval("1 != 1") is False

# Generated at 2022-06-11 17:23:07.107219
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:15.952996
# Unit test for function safe_eval
def test_safe_eval():

    def check_value_and_type(value, expected_value, expected_type):
        assert value == expected_value
        assert type(value) == expected_type

    check_value_and_type(safe_eval('True'), True, bool)
    check_value_and_type(safe_eval('False'), False, bool)
    check_value_and_type(safe_eval('None'), None, type(None))
    check_value_and_type(safe_eval('1 + 2'), 3, int)
    check_value_and_type(safe_eval('1 - 2'), -1, int)
    check_value_and_type(safe_eval('1 * 2'), 2, int)
    check_value_and_type(safe_eval('1 / 2'), 0.5, float)
    check_value_and

# Generated at 2022-06-11 17:23:21.554915
# Unit test for function safe_eval
def test_safe_eval():
    # simple examples, these should all pass
    assert safe_eval("1 + 1") == 2

    # more complex example
    assert safe_eval("foo[0]", locals={'foo': [1, 2]}) == 1
    assert safe_eval("foo[0]", locals={'foo': ('one', 'two')}) == 'one'
    assert safe_eval("foo[0]", locals={'foo': {'one': 1, 'two': 2}}) == 'one'

    # should return the expr string, not evaluate it
    assert safe_eval("1 + 1 +") == "1 + 1 +"
    assert safe_eval("a_list[0]", locals={'foo': [1, 2]}) == "a_list[0]"

    # test that expressions which are already templated to a datastructure
    # are

# Generated at 2022-06-11 17:23:32.931051
# Unit test for function safe_eval
def test_safe_eval():
    # test safe evaluation of a literal list
    result, exception = safe_eval('[1, 2, 3]', include_exceptions=True)
    assert result == [1, 2, 3]
    assert exception is None

    # test safe evaluation of a literal string
    result, exception = safe_eval('"some string"', include_exceptions=True)
    assert result == "some string"
    assert exception is None

    # test safe evaluation of a variable
    result, exception = safe_eval('a_string', include_exceptions=True, locals={'a_string': "some string"})
    assert result == "some string"
    assert exception is None

    # test safe evaluation of a variable