

# Generated at 2022-06-11 17:13:37.006613
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('1+1') == 2
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval("foo.bar()", {'foo': {'bar': lambda: 'baz'}}) == 'baz'
    assert safe_eval("0") == 0
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("1+2") == 3
    assert safe_eval("-1+3") == 2
    assert safe_eval("6-1") == 5
    assert safe_eval("6-1-1") == 4
    assert safe_eval("6*4") == 24

# Generated at 2022-06-11 17:13:44.938404
# Unit test for function safe_eval
def test_safe_eval():
    # check that we are in fact not allowing everything
    try:
        safe_eval("__import__('os').system('ls')")
        assert True is False, 'This should never be reached'
    except:
        pass

    # check that we are not allowing _() to be passed through
    assert 'foo' == safe_eval("_('foo')")

    # check that we are allowing simple list and dict
    assert [1, 2] == safe_eval("[1, 2]")
    assert {'a': 1} == safe_eval("{'a': 1}")

    # check that we are allowing calls to builtin functions that are
    # whitelisted
    assert 'teststring' == safe_eval("str('teststring')")

    # check that we disallow calls to builtin functions that are
    # not whitelisted
   

# Generated at 2022-06-11 17:13:55.727279
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure it works for simple expressions
    assert safe_eval("1 + 2 * 3") == 7
    assert safe_eval("(1 + 2) * 3") == 9
    # Make sure it works for variables
    assert safe_eval("a", dict(a=42)) == 42
    # Make sure it only works for a limited subset of Python syntax
    try:
        safe_eval("__import__('os').system('rm -rf /')")
        assert 0, "safe_eval() should not allow __import__"
    except Exception:
        pass
    # Make sure it only works for a limited subset of builtins
    try:
        safe_eval("{'a': True, 'b': False}")
        assert 0, "safe_eval() should not allow dicts"
    except Exception:
        pass
    # Make sure it does

# Generated at 2022-06-11 17:14:06.440429
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_bytes
    failed = False


# Generated at 2022-06-11 17:14:14.633764
# Unit test for function safe_eval
def test_safe_eval():

    # Simple test for eval(metaclass='safe')
    def test_safe_eval_unit(expr, result):
        this_result = safe_eval(expr)
        if this_result != result:
            print("Expected %s to be %s, got %s" % (expr, result, this_result))
            return False
        else:
            return True

    test_safe_eval_unit('123', 123)
    test_safe_eval_unit('123 + 123', 246)
    test_safe_eval_unit('123 + 123 + "bob"', '246bob')
    test_safe_eval_unit('1234 - "bob"', 1234)
    test_safe_eval_unit('1234 * "bob"', 'bobbobbobbobbobbob')
    test_safe_eval_unit

# Generated at 2022-06-11 17:14:22.950891
# Unit test for function safe_eval
def test_safe_eval():
    # call with a normal python expression
    result = safe_eval('(8 + 7) * 2')
    assert result == 30

    # call with a string, which should be returned as a string
    result = safe_eval('"some string"')
    assert result == "some string"

    # call with a JSON-compatible boolean
    result = safe_eval('true')
    assert result == True

    # call with a JSON-compatible null
    result = safe_eval('null')
    assert result is None

    # call with a JSON-compatible dict
    result = safe_eval('{"a":1, "b":2, "c":[3, 4, 5]}')
    assert result == {"a":1, "b":2, "c":[3, 4, 5]}

    # call with a JSON-compatible list

# Generated at 2022-06-11 17:14:30.516644
# Unit test for function safe_eval
def test_safe_eval():
    # First, some valid expressions
    expr = '{{ foo }}'
    assert safe_eval(expr) == expr
    expr = '{{ foo }} + 1'
    assert safe_eval(expr) == expr
    expr = '{{ foo }} + {{ bar }}'
    assert safe_eval(expr) == expr
    expr = '{{ foo }}' * 3
    assert safe_eval(expr) == expr
    expr = '{{ foo }} + {{ bar }} == "stuff"'
    assert safe_eval(expr) == expr
    expr = '{{ foo }} == "stuff"'
    assert safe_eval(expr) == expr
    expr = '{{ foo }} == "stuff" or {{ bar }} == "stuff"'
    assert safe_eval(expr) == expr
    expr = '{{ foo }} + {{ bar }}'

# Generated at 2022-06-11 17:14:37.821317
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validate safe_eval function.
    '''
    def _test(expr, locals):
        result, exception = safe_eval(expr, locals, include_exceptions=True)
        if exception:
            print('"%s" failed eval\n%s' % (expr, exception))
        else:
            print('"%s" evaluated as\n%s' % (expr, result))
        print()

    _test('[True, False]', {})
    _test('[True, True or False]', {})
    _test('[True, False and True]', {})
    _test('[True, False and True or False]', {})
    _test('[True, (False and True) or False]', {})

# Generated at 2022-06-11 17:14:48.277081
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + '1'") == '11'
    assert safe_eval("1 + '1'", include_exceptions=True) == ('1 + \'1\'', None)
    assert safe_eval("1 + '1'", include_exceptions=False) == "1 + '1'"
    assert safe_eval("1 + []") == 1
    assert safe_eval("1 + []", include_exceptions=True) == ('1 + []', None)
    assert safe_eval("1 + []", include_exceptions=False) == "1 + []"
    assert safe_eval("1 + {}", include_exceptions=True) == ('1 + {}', None)
    assert safe_eval("1 + {}", include_exceptions=False) == "1 + {}"

# Generated at 2022-06-11 17:14:56.846844
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info < (2, 7):
        # simple test cases
        assert safe_eval('True') is True
        assert safe_eval('False') is False
        assert safe_eval('None') is None
        assert safe_eval('1') == 1
        assert safe_eval('1.2') == 1.2
        assert safe_eval('"x"') == 'x'
        assert safe_eval('u"x"') == 'x'
        assert safe_eval('u"\xab"') == u'\xab'
        assert safe_eval('[1,2,3]') == [1, 2, 3]
        assert safe_eval('(1,2,3)') == (1, 2, 3)
        assert safe_eval('x', dict(x='foo')) == 'foo'

# Generated at 2022-06-11 17:15:07.310571
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:17.128588
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'foo and bar'
    expr = safe_eval(expr)
    assert expr == 'foo and bar'

    expr = 'foo and bar'
    expr = safe_eval(expr, locals={'foo': 'foo', 'bar': 'bar'})
    assert expr == 'foo and bar'

    expr = "dict(changed=False)"
    expr = safe_eval(expr)
    assert expr == {'changed': False}

    expr = "dict(changed='False')"
    expr = safe_eval(expr)
    assert expr == {'changed': 'False'}

    expr = "dict(checked=1)"
    expr = safe_eval(expr)
    assert expr == {'checked': 1}

    expr = "dict(checked='1')"
    expr = safe_eval(expr)

# Generated at 2022-06-11 17:15:27.176781
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:36.816140
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    if sys.version_info >= (3, 0):
        b_literal = "b'abc'"
    else:
        b_literal = "'abc'"

    # Pass
    assert safe_eval('{"a": "b"}', include_exceptions=True)[0] == {"a": "b"}, \
        "Dictionary failed to evaluate"
    assert safe_eval(to_bytes(b_literal), include_exceptions=True)[0] == "abc", \
        "Byte literal failed to evaluate"
    assert safe_eval('["a", "b", "c"]', include_exceptions=True)[0] == ["a", "b", "c"], \
        "List failed to evaluate"
    assert safe_eval

# Generated at 2022-06-11 17:15:45.564678
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid container types
    assert safe_eval("[1,2,'3',1.4,[4.4,3]]") == [1, 2, '3', 1.4, [4.4, 3]]
    assert safe_eval("{'k1':1,'k2':2,'key3':'33','k4':[4.4,3],'key5':{'kk1':1}}") == {'k1': 1, 'k2': 2, 'key3': '33', 'k4': [4.4, 3], 'key5': {'kk1': 1}}

# Generated at 2022-06-11 17:15:55.648666
# Unit test for function safe_eval
def test_safe_eval():
    test_failed = False

# Generated at 2022-06-11 17:16:06.434880
# Unit test for function safe_eval
def test_safe_eval():
    # Test builtin functions
    for fn in ("range", "set", "sorted", "str", "reversed", "len", "bool", "zip", "frozenset"):
        assert safe_eval(fn + "(42)") == getattr(builtins, fn)(42)

    # Test basic math
    for expression in ("2+2", "6*7", "2**16"):
        assert safe_eval(expression) == eval(expression)

    assert safe_eval("range(5, 11)") == list(range(5, 11))
    assert safe_eval("'foo'") == "foo"

    # Test lists, tuples and sets
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-11 17:16:15.639928
# Unit test for function safe_eval
def test_safe_eval():
    """
    >>> test_safe_eval()
    """
    def test(a):
        pass

    expr = "a == 'foo'"
    value = safe_eval(expr, dict(a='foo'))
    assert value is True

    expr = "1 + 1"
    value = safe_eval(expr)
    assert value == 2

    expr = "a + 1"
    value = safe_eval(expr, dict(a=2))
    assert value == 3

    expr = "a + 'foo'"
    value = safe_eval(expr, dict(a='bar'))
    assert value == 'barfoo'

    expr = "['foo', 'bar']"
    value = safe_eval(expr)
    assert value == ['foo', 'bar']

    expr = "['foo', 'bar'][i]"
    value

# Generated at 2022-06-11 17:16:23.877339
# Unit test for function safe_eval
def test_safe_eval():
    our_vars = {
        'a': 'some string',
        'b': [1, 2, 3],
        'c': {
            'dict': 'inside a string',
            'list': [1, 2, 3],
        },
        'd': {
            'foo': "{{ c.dict }}",
            'bar': [1, 2, 3],
        },
        'e': [1, 2, 3],
        'f': set([1, 2, 3]),
        'g': True,
        'h': False,
        'i': [1, 2, 3],
    }
    # simple test cases, should all evaluate to True
    assert safe_eval("a == 'some string'", our_vars)
    assert safe_eval("b == [1, 2, 3]", our_vars)

# Generated at 2022-06-11 17:16:34.553462
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text

    def assert_safe_eval_fails(expr, exception_msg):
        expr = to_text(expr)
        (return_value, exception) = safe_eval(expr, include_exceptions=True)
        if exception is None:
            raise AssertionError("Unexpected success evaluating: %s" % expr)
        if to_native(exception_msg) not in str(exception):
            raise AssertionError("Failed to raise expected exception when evaluating: %s: %s" % (expr, exception))
        if return_value != expr:
            raise AssertionError("Failed to return original expression when evaluating: %s" % (expr))


# Generated at 2022-06-11 17:16:46.826630
# Unit test for function safe_eval
def test_safe_eval():
    # Tests which are valid python
    assert safe_eval('{a: b for a, b in d.items()}') == {'a': 'b'}
    assert safe_eval('[i for i in l]') == [1, 2, 3]
    assert safe_eval('[i for i in l if i < 3]') == [1, 2]
    assert safe_eval('[i+1 for i in l]') == [2, 3, 4]
    assert safe_eval('l[0]') == 1
    assert safe_eval('foo.bar') == 'baz'
    assert safe_eval('foo["bar"]') == 'baz'
    assert safe_eval('d1 == d2', locals={'d1': {'a': 1}, 'd2': {'a': 1}}) == True

# Generated at 2022-06-11 17:16:57.188132
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit tests to ensure the safe_eval function behaves
    as expected.

    """

    def _test_good_eval(expr):
        """
        Perform a safe_eval and ensure the result is as expected.
        """
        result, error = safe_eval(expr, include_exceptions=True)
        if error:
            raise error
        else:
            assert result == eval(expr)

    def _test_bad_eval(expr):
        """
        Perform a safe_eval and ensure the result is as expected.
        """

# Generated at 2022-06-11 17:17:07.981335
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1", include_exceptions=True) == (2, None)
    assert safe_eval("1!1") == "1!1"
    assert safe_eval("1!1", include_exceptions=True) == ("1!1", None)
    assert safe_eval("1 + (1 if 1>2 else 2)") == 2
    assert safe_eval("i+2", locals=dict(i=1)) == 3
    assert safe_eval("i+2", locals=dict(i=1), include_exceptions=True) == (3, None)
    assert safe_eval("i+2", locals=dict(i=None)) == "i+2"

# Generated at 2022-06-11 17:17:16.926817
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval(None) is None
    assert safe_eval(True) is True
    assert safe_eval(False) is False
    assert safe_eval(1) == 1
    assert safe_eval(1.1) == 1.1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('1 == 1') is True
    assert safe_eval('[1, 2, 3]*2') == [1, 2, 3, 1, 2, 3]
    assert safe_eval('2-1') == 1
    assert safe_eval('2+2') == 4
    assert safe_eval('2*3') == 6


# Generated at 2022-06-11 17:17:26.369345
# Unit test for function safe_eval
def test_safe_eval():

    print("Testing single expression")
    expression = "2 + 2"
    result = safe_eval(expression)
    print("Expression: '%s' = %s" % (expression, result))
    assert result == 4

    print("Testing single expression in string context")
    expression = "2 + 2"
    result = safe_eval(expression, context="string")
    print("Expression: '%s' = '%s'" % (expression, str(result)))
    assert str(result) == "4"

    print("Testing multiple expressions")
    expression = "[2 + 2, 3 + 3]"
    result = safe_eval(expression)
    print("Expression: '%s' = %s" % (expression, container_to_text(result)))
    assert len(result) == 2
    assert result[0] == 4


# Generated at 2022-06-11 17:17:34.839032
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:44.030425
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:54.316542
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo['bar']") == "foo['bar']"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo().bar") == "foo().bar"
    assert safe_eval("foo().bar['baz']") == "foo().bar['baz']"
    assert safe_eval("foo().bar().baz") == "foo().bar().baz"
    assert safe_eval("foo.bar.baz") == "foo.bar.baz"
    assert safe_eval("foo.bar[1]") == "foo.bar[1]"
    assert safe_eval("foo['bar']['baz']") == "foo['bar']['baz']"

# Generated at 2022-06-11 17:18:02.201599
# Unit test for function safe_eval
def test_safe_eval():
    """The function safe_eval is tested with data from the yaml test
    cases
    """
    import yaml
    yamlfd = open(C.YAML_FILENAME_JINJA2_EVAL_TESTS, 'r')
    testcases = yaml.safe_load(yamlfd)
    yamlfd.close()
    for test in testcases:
        for testcase in testcases[test]:
            testcase_parts = testcase.split(' -> ')
            expr = testcase_parts[0]
            expected_result = ast.literal_eval(testcase_parts[1])
            actual_result = safe_eval(expr)

# Generated at 2022-06-11 17:18:09.168843
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure safe_eval returns string if error occurs
    # Note that if the error is a syntax error, safe_eval returns the
    # string
    assert safe_eval("with open('/etc/passwd', 'r') as f: print f.read()") == \
        "with open('/etc/passwd', 'r') as f: print f.read()"
    assert safe_eval("/etc/passwd") != "/etc/passwd"
    assert safe_eval("/etc/passwd") == "/etc/passwd"
    assert safe_eval("/foo/bar") == "/foo/bar"
    assert safe_eval("None") is None
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("1 + 1") == 2

# Generated at 2022-06-11 17:18:24.073098
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import dict2yaml
    try:
        from yaml import safe_load as yaml_safe_load
    except ImportError:
        from ansible.module_utils.six.moves import cStringIO
        import yaml
        def yaml_safe_load(stream):
            class AnsibleLoader(yaml.SafeLoader):
                pass
            AnsibleLoader.add_constructor(u'tag:yaml.org,2002:str', type(u''))
            AnsibleLoader.add_constructor(u'tag:yaml.org,2002:map', dict)

# Generated at 2022-06-11 17:18:29.965408
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    class TestSafeEval(unittest.TestCase):

        def test_safe_names(self):
            safe_names = [
                'True',
                'False',
                'None',
                'ansible_ssh_host',
                'inventory_hostname',
                'group_names',
                'groups',
                'play_hosts',
            ]
            for n in safe_names:
                t = safe_eval(n)
                self.assertEqual(t, n)

        def test_safe_literals(self):
            safe_literals = [
                "True or False",
                "True and False",
                "1 + 1 == 2",
                "1 + 1 == 3",
                "1 + 1",
            ]

# Generated at 2022-06-11 17:18:38.666616
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:48.278872
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.plugins.test.test_utils import TestModule
    # create a fake module so we can test safe_eval
    module = TestModule(' ')
    # our globals
    fake_globals = {
        'somevar': 1,
    }
    # our local variables
    fake_locals = {
        'dict1': {
            'a': 1,
            'b': 2,
        },
        'dict2': {
            'a': 1,
            'b': 2,
        },
        'l': ['a', 'b', 'c'],
        's': 'abc',
        'i': 1,
        'j': 2,
        'k': 3,
    }
    # setup a module for the fake module so we can test late eval

# Generated at 2022-06-11 17:18:58.226898
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:07.596137
# Unit test for function safe_eval
def test_safe_eval():
    cases = [
        ('5 * 7 + 3', 36),
        ('[]', []),
        ('{}', {}),
        ('()', ()),
        ('[1,2,"foo"]', [1,2,"foo"]),
        ('{"a":1,"b":2}', {u"a":1,"b":2}),
        ('1 == 1', True),
        ('1 != 1', False),
        ('(7, 8)', (7,8)),
        ('(1,)', (1,)),
        ('7 in [1,2,3,4,5]', False),
        ('! true', False),
        ('true and false', False),
        ('true or false', True),
        ('5 * 7 + 3 * 8', 64),
    ]


# Generated at 2022-06-11 17:19:13.710447
# Unit test for function safe_eval
def test_safe_eval():
    print('safe_eval({0!r}, {1!r}, {2!r}) =>'.format(sys.argv[1], sys.argv[2], sys.argv[3]))
    print(safe_eval(sys.argv[1], ast.literal_eval(sys.argv[2]), ast.literal_eval(sys.argv[3])))

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-11 17:19:20.753977
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Define the data to be used in the test.

    We use a dict with keys describing the data and values containing a tuple
    with three items:
    1. the JSON string to be converted to a Python data structure
    2. the expected Python data structure
    3. a boolean that if True, indicates the JSON string is invalid and
       should result in a failure. If False, the result should be a the
       conversion should be a success.

    The dict data_to_test is a series of tests to run that test some of the
    boundary conditions of the function.
    '''

# Generated at 2022-06-11 17:19:30.718797
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Here we can test safe_eval to ensure is does not allow malicious
    calls.  We could also have tests for ensuring that allowed
    things are properly parsed and evaluated as desired, but we'd
    probably be better off moving to a full-featured expression
    evaluator for that.

    Right now this is significantly constrained, so we are pretty
    well covered if these tests pass.
    '''
    import sys

    # test expressions we want to allow

# Generated at 2022-06-11 17:19:40.551233
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval(None) is None
    assert safe_eval(123) == 123
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo + bar') == container_to_text('foo + bar')
    assert safe_eval('3 + 2') == 5
    assert safe_eval('true') == True
    assert safe_eval('null') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('''{% set foo = [1, 2, 3] %}foo''') == [1, 2, 3]
    assert safe_eval('''{% set foo = [1, 2, 3] %}foo[1]''') == 2

# Generated at 2022-06-11 17:20:03.579471
# Unit test for function safe_eval
def test_safe_eval():
    constants = C.__dict__
    def test_eval(expression, expected, locals=None, include_exceptions=False):
        if locals is None:
            locals = dict()
        result, exception = safe_eval(expression, locals=locals, include_exceptions=True)
        assert result == expected, '"%s" failed. Expected: %r, got %r' % (expression, expected, result)
        # if we expected an exception, assert that one was raised
        if isinstance(expected, Exception):
            assert exception is not None, '"%s" failed. Expected exception: %r, got no exception' % (expression, expected)
        # if we expected no exception, assert that one wasn't raised

# Generated at 2022-06-11 17:20:12.710724
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] == 2:
        from ansible.utils.unicode import to_unicode
    else:
        def to_unicode(x):
            return x
    assert safe_eval(to_native("1 + 2")) == 3
    assert safe_eval(to_native("[1, 2]")) == [1, 2]
    assert safe_eval(to_native("{'key': 'value'}")) == {'key': 'value'}
    assert safe_eval(to_native("a_list_variable")) == "a_list_variable"
    assert safe_eval("1 + 2") == 3
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}
   

# Generated at 2022-06-11 17:20:19.645425
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info >= (3, 0):
        assert safe_eval('false') == False
        assert safe_eval('null') == None
        assert safe_eval('true') == True
        assert safe_eval('True') == True
        assert safe_eval('False') == False
        assert safe_eval('None') == None

    # simple string and numeric types
    assert safe_eval('1') == 1
    assert safe_eval('"a"') == "a"

    # simple dict and list types
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('["a", 1]') == ["a", 1]
    assert safe_eval('[1]') == [1]

# Generated at 2022-06-11 17:20:27.213073
# Unit test for function safe_eval
def test_safe_eval():
    # basic evaluations
    assert safe_eval("10") == 10
    assert safe_eval("[10]") == [10]
    assert safe_eval("{'a': 10}") == {'a': 10}

    # safe builtin functions
    assert safe_eval("len([10])") == 1
    assert safe_eval("len({'a': 10})") == 1
    assert safe_eval("[10, 20][1]") == 20
    assert safe_eval("{'a': 10, 'b': 20}['b']") == 20

    # safe constant types
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None

    # unsafe functions

# Generated at 2022-06-11 17:20:36.155801
# Unit test for function safe_eval
def test_safe_eval():
    # A couple of simple tests to test our custom safe_eval implementation
    # More thorough tests are implemented in test/units/module_utils/test_common_utils.py
    expr1 = u"foo"
    expr2 = u"{'a': 5, 'b': 7}"
    expr3 = u"['a']"
    expr4 = u"{'a', 'b'}"
    expr5 = u"{'a', 'b', 'c'}"
    expr6 = u"['a', 'b']"
    expr7 = u"[1, 'b', 'c']"
    expr8 = u"{5, 7}"
    expr9 = u"foo()"
    expr10 = u"foo(1, None)"
    expr11 = u"fil1(1, 2)"

# Generated at 2022-06-11 17:20:46.235722
# Unit test for function safe_eval
def test_safe_eval():
    """
    Run a simple unit test on the safe_eval function.
    """
    from ansible.module_utils.six.moves import builtins

    # No locals defined
    expr = '2 + 3'
    assert safe_eval(expr) == 5
    expr = '2 + 3.2'
    assert safe_eval(expr) == 5.2
    expr = 'len([1, 2, 3])'
    assert safe_eval(expr) == 3
    expr = 'len([1, 2, 3]) + 2'
    assert safe_eval(expr) == 5

    # Some locals defined
    expr = 'a + a'
    assert safe_eval(expr, dict(a=5)) == 10
    expr = 'a + b'

# Generated at 2022-06-11 17:20:58.022837
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("['1', '2', '3']") == ['1', '2', '3']
    assert safe_eval("'1,2,3'") == '1,2,3'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("True == False") is False
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-11 17:21:04.471572
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-variable
    true_literals = [
        True,
        'True',
        'true',
        'TRUE',
    ]
    for item in true_literals:
        assert safe_eval(item)

    false_literals = [
        False,
        'False',
        'false',
        'FALSE',
    ]
    for item in false_literals:
        assert not safe_eval(item)

    none_literals = [
        None,
        'None',
        'none',
        'NULL',
    ]
    for item in none_literals:
        assert not safe_eval(item)



# Generated at 2022-06-11 17:21:13.650789
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic operations
    assert safe_eval('2 + 2') == 4
    assert safe_eval('7 * 8') == 56
    assert safe_eval('10 - 1') == 9
    assert safe_eval('10 / 2') == 5

    # Test unary operations
    assert safe_eval('-2') == -2

    # Test simple boolean operations
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # Test simple boolean operations
    assert safe_eval('2 < 3') is True
    assert safe_eval('2 > 3') is False
    assert safe_eval('2 == 2') is True
    assert safe_eval('2 != 2') is False



# Generated at 2022-06-11 17:21:23.956277
# Unit test for function safe_eval
def test_safe_eval():
    class TestExceptions(Exception):
        pass


# Generated at 2022-06-11 17:21:48.736119
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-11 17:21:56.398129
# Unit test for function safe_eval
def test_safe_eval():

    def run_test(expr, include_exceptions, value):
        result = safe_eval(expr, include_exceptions=include_exceptions)
        if include_exceptions:
            result, err = result
        if result != value:
            raise AssertionError("safe_eval('%s') -> '%s' != '%s'" % (expr, result, value))

    # constant
    run_test('1', False, 1)
    run_test('1', True, 1)
    run_test('1+1', False, 2)
    run_test('1+1', True, 2)
    run_test('"hello"', False, 'hello')
    run_test('"hello"', True, 'hello')
    run_test("'hello'", False, 'hello')

# Generated at 2022-06-11 17:22:05.422692
# Unit test for function safe_eval
def test_safe_eval():
    import string

    # simple tests
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo or bar', locals={'bar': None}) is None
    assert safe_eval('foo or bar', locals={'bar': "baz"}) == 'foo'
    assert safe_eval('z = [1, 2, 3]') == [1, 2, 3]

    # contains an invalid type, raises exception
    try:
        safe_eval("exec 'print to_native(""this is not allowed"")'")
    except Exception as e:
        assert "invalid expression (exec 'print to_native(""this is not allowed"")')" in str(e)
    else:
        assert False, 'safe_eval() failed to raise exception'

    # test

# Generated at 2022-06-11 17:22:16.080062
# Unit test for function safe_eval
def test_safe_eval():
    ''' tests the safe_eval function '''
    # set these to warn, not fail
    old_d = C.ERROR_ON_UNDEFINED_VARS
    old_m = C.ERROR_ON_MISSING_VARS


# Generated at 2022-06-11 17:22:26.532327
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is not a true unit test as it relies on the default
    behavior of ast.literal_eval to reject input which is not
    valid JSON-like structure.  In Python 3, the json module
    is used for this purpose.
    """


# Generated at 2022-06-11 17:22:37.253350
# Unit test for function safe_eval
def test_safe_eval():
    '''
    test method safe_eval
    '''
    assert 'bar' == safe_eval("'bar'")
    assert 'bar' == safe_eval("\"bar\"")
    assert 1 == safe_eval("1")
    assert 1 == safe_eval("1 + 0")
    assert 2 == safe_eval("1 + 1")
    assert 1 == safe_eval("2 - 1")
    assert 6 == safe_eval("2 * 3")
    assert 3 == safe_eval("9 / 3")
    assert True == safe_eval("True")
    assert False == safe_eval("False")
    assert True == safe_eval("true")
    assert False == safe_eval("false")
    assert 2 == safe_eval("len([1,2,3])")

# Generated at 2022-06-11 17:22:47.294753
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:56.772683
# Unit test for function safe_eval
def test_safe_eval():
    # Test each type of simple JSON type
    assert safe_eval('true')
    assert not safe_eval('false')
    assert safe_eval('null') is None
    assert safe_eval('1') == 1
    assert safe_eval('1') != '1'
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"one"') == "one"
    assert safe_eval('["one"]') == ["one"]
    assert safe_eval('{"one": "two"}') == {"one": "two"}

    # Test compound expressions
    assert safe_eval('["one", "two"] + ["three"]') == ["one", "two", "three"]
    assert safe_eval('{"one": "two"} + {"three": "four"}') == {"one": "two", "three": "four"}
   

# Generated at 2022-06-11 17:23:03.470521
# Unit test for function safe_eval
def test_safe_eval():
    # First test that simple literals/constants can be evaluated
    test_value = 'test'
    evaluated = safe_eval(test_value)
    assert evaluated == 'test'

    test_value = '"test"'
    evaluated = safe_eval(test_value)
    assert evaluated == 'test'

    test_value = '5'
    evaluated = safe_eval(test_value)
    assert evaluated == 5

    test_value = '5.5'
    evaluated = safe_eval(test_value)
    assert evaluated == 5.5

    test_value = 'true'
    evaluated = safe_eval(test_value)
    assert evaluated is True

    # Make sure that we can evaluate lists and tuples
    # Note that this will be converted to a list, not a tuple

# Generated at 2022-06-11 17:23:13.901398
# Unit test for function safe_eval
def test_safe_eval():
    # test various valid expressions with math operators
    res = safe_eval("(((12 + 2) / 4) - 1) * 10")
    assert res == 10

    # test various invalid expressions
    try:
        safe_eval("12 + / 2")
    except Exception as e:
        assert str(e) == "invalid expression (12 + / 2)"

    # test calls to builtin functions (which are not allowed)
    try:
        safe_eval("sys.version")
    except Exception as e:
        assert str(e) == "invalid function: sys"

    # test calls to builtin functions we've allowed
    CALL_ENABLED.append('len')
    res = safe_eval("len([1, 2, 3, 4])")
    assert res == 4
    CALL_ENABLED.remove('len')

   