

# Generated at 2022-06-11 17:13:38.965838
# Unit test for function safe_eval
def test_safe_eval():
    # regular expression to match traceback head
    import re
    traceback_head = re.compile("Traceback \(most recent call last\):")

    def filter_traceback(value):
        # remove traceback and python version information
        if isinstance(value, string_types):
            return "\n".join(filter(traceback_head.search, value.split("\n")))

    # all the test cases

# Generated at 2022-06-11 17:13:45.922326
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for function safe_eval()
    '''

# Generated at 2022-06-11 17:13:56.197796
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{{ ansible_all_ipv4_addresses | join(":") }}'
    print("Testing safe_eval on expression: '%s'" % expr)
    result, err = safe_eval(expr, dict(ansible_all_ipv4_addresses=['192.168.1.1', '192.168.1.2']), include_exceptions=True)
    assert result == '192.168.1.1:192.168.1.2'
    assert err is None
    print("Success: safe_eval returns '%s' on expression: '%s'" % (result, expr))
    expr = '{{ ansible_all_ipv4_addresses | join("|") }} {{ foo("\x00") }}'
    print("Testing safe_eval on expression: '%s'" % expr)


# Generated at 2022-06-11 17:14:01.636719
# Unit test for function safe_eval
def test_safe_eval():
    # whitespace removed
    assert safe_eval("1+(1-1)") == 1

    # whitespace removed, list
    assert safe_eval("[1,2,3]") == [1, 2, 3]

    # whitespace removed, dict
    assert safe_eval("{'foo': 'stuff'}") == {u'foo': u'stuff'}

    # valid unary operation
    assert safe_eval("-2") == -2

    # added new valid keywords, true, false, and null

    # boolean
    assert safe_eval("true") == True

    # boolean
    assert safe_eval("false") == False

    # null
    assert safe_eval("null") == None

    # dict with true and dict

# Generated at 2022-06-11 17:14:08.648428
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:20.020071
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo.bar().baz') == 'foo.bar().baz'
    assert safe_eval('foo.bar().baz()') == 'foo.bar().baz()'
    assert safe_eval('foo + bar') == 'foo + bar'
    assert safe_eval('foo + bar()') == 'foo + bar()'
    assert safe_eval('foo + bar().baz') == 'foo + bar().baz'
    assert safe_eval('foo + bar().baz()') == 'foo + bar().baz()'

# Generated at 2022-06-11 17:14:28.581479
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:35.528040
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import unittest

    # define a set of AST nodes we are going to allow in the evaluation.
    SAFE_NODES = set(
        (
            ast.Add,
            ast.BinOp,
            ast.Call,
            ast.Compare,
            ast.Constant,
            ast.Dict,
            ast.Div,
            ast.Expression,
            ast.List,
            ast.Load,
            ast.Mult,
            ast.Num,
            ast.Name,
            ast.Set,
            ast.Str,
            ast.Sub,
            ast.USub,
            ast.Tuple,
            ast.UnaryOp,
        )
    )


# Generated at 2022-06-11 17:14:47.198105
# Unit test for function safe_eval
def test_safe_eval():
    """
    call the function safe_eval() and confirm it returns the value we expect
    """

    test_values = (
        ['a', 'b', 'c'],
        {'a': 1, 'b': 2, 'c': 3},
        (1, 2, 3),
        'foo',
        '1',
        '"a"',
        '["a", "b", "c"]',
        "{'a': 'b'}",
        "datetime.datetime.now()",
        "{'one', '2'}",
        "1 in {'one', '2'}",
    )

    # test with the include_exceptions flag, expect 2nd value to be None
    for value in test_values:
        result, exception = safe_eval(value, include_exceptions=True)

# Generated at 2022-06-11 17:14:56.357035
# Unit test for function safe_eval
def test_safe_eval():
    # Test that we can evaluate a simple string value
    result = safe_eval("myvalue")
    assert result == "myvalue"

    # Test that we can evaluate a simple list value
    result = safe_eval("mylist", dict(mylist=[1, 2, 3]))
    assert result == [1, 2, 3]

    # Test that we can evaluate a simple dict value
    result = safe_eval("mydict", dict(mydict=dict(one=1, two=2, three=3)))
    assert result == dict(one=1, two=2, three=3)

    # Test that we can evaluate a simple number
    result = safe_eval("7")
    assert result == 7

    # Test that we can evaluate a simple boolean
    result = safe_eval("true")
    assert result is True

    result = safe_

# Generated at 2022-06-11 17:15:07.283048
# Unit test for function safe_eval
def test_safe_eval():
    # check for unsafe function
    result = safe_eval('__import__("os").system("id")')
    assert result == '__import__("os").system("id")'

    # check for valid expression without builtin functions
    result = safe_eval('[1,2,3]')
    assert result == [1, 2, 3]

    # check for valid expression with builtin functions
    # note: the list cast is needed for Python3 compatibility
    result = safe_eval('len([1,2,3])')
    assert result == 3

    # check for invalid expression
    result = safe_eval('[1,2,3][__import__("os").system("id")]')
    assert result == '[1,2,3][__import__("os").system("id")]'


# Generated at 2022-06-11 17:15:17.115248
# Unit test for function safe_eval
def test_safe_eval():
    import pytest


# Generated at 2022-06-11 17:15:27.141605
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:36.781028
# Unit test for function safe_eval
def test_safe_eval():
    # Success cases
    assert safe_eval('True') is True
    assert safe_eval('12') == 12
    assert safe_eval('12 + 34') == 46
    assert safe_eval('12 + 34 * 5 / 2') == 57.0
    assert safe_eval('12 - 5') == 7
    assert safe_eval('12 - -5') == 17
    assert safe_eval('12 + -5') == 7
    assert safe_eval('12 + - -5') == 17
    assert safe_eval('12.3') == 12.3
    assert safe_eval('12.3 - 2') == 10.3
    assert safe_eval('"hello"') == "hello"

# Generated at 2022-06-11 17:15:45.578622
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval("'one'") == 'one'
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{a: 'b', c: 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("safe_eval('[1, 2, 3]')") == [1,2,3]
    assert safe_eval("safe_eval(a_list)") == [1,2,3]
    assert safe_eval("2*3") == 6
    assert safe_eval("a_dict['c']") == 'd'
    assert safe_eval("len([1,2,3])") == 3

# Generated at 2022-06-11 17:15:55.684425
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info >= (3, 0):
        # On Python 3, we need to test the local safe_eval to make sure
        # that it did not import anything before we started to override
        # builtins.
        local_safe_eval = safe_eval

        def raise_exception(msg, *args):
            raise Exception(msg % args)

        def open_func(fn):
            raise_exception('Unexpected call to %s()', 'open')

        def os_func(fn):
            raise_exception('Unexpected call to %s()', 'os')

        def file_func(fn):
            raise_exception('Unexpected call to %s()', 'file')

        def blah_func(fn):
            raise_exception('Unexpected call to %s()', 'blah')


# Generated at 2022-06-11 17:16:06.523963
# Unit test for function safe_eval
def test_safe_eval():
    f = open('lib/ansible/module_utils/facts.py', 'rb')

    fun = safe_eval
    a = fun('foo.isoformat()')
    b = fun('a')
    c = fun('{0:.1%}'.format(1/3))
    d = fun('f')
    e = fun('foo.isoformat() if foo else "abc"')
    z = fun('foo[0]')

    s = 'michael'
    g = fun('s.capitalize()')
    h = fun('s')

    # List comprehension
    i = fun('[ x for x in range(10) if x % 3 == 0 ]')
    j = fun('[ x if x % 3 == 0 else None for x in range(10) ]')

    # Dictionaries

# Generated at 2022-06-11 17:16:15.668933
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure valid expressions succeed, invalid expressions fail
    assert safe_eval('2') == 2
    assert safe_eval('2 + 3') == 5
    assert safe_eval('foo.bar(x, y)', dict(foo=dict(bar=lambda x, y: x + y)), True)[0] == 3
    assert safe_eval('foo.bar(x, y)', dict(foo=dict(bar=lambda x, y: x + y))) == 3
    assert safe_eval('foo.bar(x, y)', dict(foo=dict(bar=lambda x, y: x + y))) == 3
    assert safe_eval('foo.bar(x, y)', dict(foo=dict(bar=lambda x, y: x + y))) == 3

# Generated at 2022-06-11 17:16:24.006707
# Unit test for function safe_eval
def test_safe_eval():
    expression = dict(a=dict(b=1, c=2), d=[3, 4])
    assert expression == safe_eval(container_to_text(expression))
    assert 1 == safe_eval(container_to_text(1))
    assert container_to_text(1) == safe_eval(container_to_text(container_to_text(1)))
    assert dict(b=1, c=2) == safe_eval(container_to_text(dict(b=1, c=2)))
    assert [3, 4] == safe_eval(container_to_text([3, 4]))
    assert dict(b=1, c=2) == safe_eval(container_to_text(dict(b=1, c=2)))

# Generated at 2022-06-11 17:16:34.666718
# Unit test for function safe_eval
def test_safe_eval():
    # We test for exceptions as well as for sane values

    safe_eval(1) == 1
    safe_eval('1+1') == 2
    safe_eval('1 + 1') == 2
    safe_eval('1+1==2') == True
    safe_eval('2+2==5') == False
    safe_eval('1+1==(2*1)') == True
    safe_eval('2-2==0') == True

    # now we try expressions that should throw exceptions

    throws_exception = False
    try:
        safe_eval('1+1==__import__("os").system("ls /")')
        throws_exception = False
    except:
        throws_exception = True
    assert(throws_exception)

    throws_exception = False

# Generated at 2022-06-11 17:16:46.826169
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("{{foo}}")
    assert result == "{{foo}}"

    result = safe_eval("{{foo.bar}}")
    assert result == "{{foo.bar}}"

    result = safe_eval("foo.bar")
    assert result == "foo.bar"

    result = safe_eval("{ 'name': 'foobar' }")
    assert result == { 'name': 'foobar' }

    result = safe_eval("{ 'name': 'foobar', 'age': 20 }")
    assert result == { 'name': 'foobar', 'age': 20 }

    result = safe_eval("[ 'foo', 'bar', 'baz' ]")
    assert result == [ 'foo', 'bar', 'baz' ]


# Generated at 2022-06-11 17:16:57.187395
# Unit test for function safe_eval
def test_safe_eval():
    # true
    assert safe_eval("True") == True
    assert safe_eval("1 == 1") == True
    assert safe_eval("2 > 1") == True
    assert safe_eval("1 != 2") == True
    assert safe_eval("2 >= 2") == True
    assert safe_eval("1 <= 2") == True
    assert safe_eval("foo == 'foo'") == True

    # false
    assert safe_eval("False") == False
    assert safe_eval("1 == 2") == False
    assert safe_eval("1 > 2") == False
    assert safe_eval("2 < 1") == False
    assert safe_eval("1 >= 2") == False
    assert safe_eval("2 <= 1") == False

    # constants
    assert safe_eval("None") == None

# Generated at 2022-06-11 17:17:07.988886
# Unit test for function safe_eval
def test_safe_eval():
    # Basic
    assert safe_eval('1 + 1') == 2
    assert safe_eval('5 + 3') == 8
    assert safe_eval('"hello"') == 'hello'
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    # Data structures
    assert safe_eval('''{
      "hello": "world",
      "foo":   "bar",
      "one":   1,
      "two":   2,
      "null":  null,
      "empty": {},
      "list":  [],
      "list2": ["oh", "hai"],
      "nested": {
        "1": "one",
        "a": "b"
      },
      "a": "value"
    }''')

# Generated at 2022-06-11 17:17:11.812397
# Unit test for function safe_eval
def test_safe_eval():
    """
    >>> test_safe_eval()
    True
    """
    # Clears the environment so that previous test runs do not interfere
    OUR_GLOBALS = {
        '__builtins__': {},
    }

    # test parsing and evaluation of python datatypes
    tests = [
        ('True', True),
        ('False', False),
        ('{}', {}),
        ('[]', []),
        ('1', 1),
        ('()', ()),
        ('1+1', 2),
        ('"foo"', "foo"),
        ('["foo", "bar"]', ["foo", "bar"]),
        ('"a"*10', "aaaaaaaaaa"),
        ('"{"', "{"),
        ('[1,2,3]', [1, 2, 3])
    ]


# Generated at 2022-06-11 17:17:20.967547
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Make sure that safe_eval works as expected
    '''

    # First we execute test cases with syntax errors and ensure
    # that the original expression comes back unchanged
    assert safe_eval("{'a':1,'b':2}") == "{'a':1,'b':2}"
    assert safe_eval("[1,2,3]") == "[1,2,3]"
    assert safe_eval("abc") == "abc"

    # Now, test with valid syntax but using functions that should
    # not be allowed in safe mode
    assert safe_eval("eval('1+1')") == "eval('1+1')"

    # and finally, test some standard python syntax
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("1+1") == 2

# Generated at 2022-06-11 17:17:23.785276
# Unit test for function safe_eval
def test_safe_eval():
    f = open("lib/ansible/module_utils/facts/hardware.py")
    for line in f:
        line=line.strip()
        if not line.startswith("#"):
            safe_eval(line)



# Generated at 2022-06-11 17:17:31.593823
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    assert 'foo' == safe_eval("foo")
    assert '42' == safe_eval("42")
    assert 42 == safe_eval("42" if C.DEFAULT_KEEP_REMOTE_FILES else "42.0")
    assert 42 == safe_eval("42.0" if C.DEFAULT_KEEP_REMOTE_FILES else "42")
    assert 42 == safe_eval("42.0")
    assert 42 == safe_eval("42")
    assert '42' == safe_eval("'42'")
    assert '42' == safe_eval("\"42\"")
    assert '42.0' == safe_eval("42.0")
    assert '42.0' == safe_eval("'42.0'")
    assert 42.

# Generated at 2022-06-11 17:17:42.298573
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("'a'+'b'") == 'ab'
    assert safe_eval("2+2") == 4
    assert safe_eval("(1,2)") == (1, 2)

    assert safe_eval("'a'+'b'", include_exceptions=True) == ('ab', None)

    assert safe_eval("2 / 0") == "'2 / 0'"
    assert safe_eval("1 / 0", include_exceptions=True) == ("1 / 0", ZeroDivisionError)


# Generated at 2022-06-11 17:17:48.959477
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:57.958643
# Unit test for function safe_eval
def test_safe_eval():
    # Python3 has a different exception
    if sys.version_info[0] > 2:
        exception = SyntaxError
    else:
        exception = NameError

    # These should throw an exception
    assert safe_eval('0', include_exceptions=True)[1] is not None
    assert safe_eval('[0] * 0', include_exceptions=True)[1] is not None
    assert safe_eval('{0}', include_exceptions=True)[1] is not None
    assert safe_eval('set([0])', include_exceptions=True)[1] is not None

    # These should return the evaluated expression
    assert safe_eval('0') == 0
    assert safe_eval('[0] * 1') == [0]
    assert safe_eval('[0] * 2') == [0, 0]

# Generated at 2022-06-11 17:18:09.080310
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('False or True')
    assert not safe_eval('False and True')
    assert safe_eval('a in [1,2,3]', dict(a=3))
    assert not safe_eval('a in [1,2,3]', dict(a=4))
    assert not safe_eval('a == 4', dict(a=4))
    assert safe_eval('a == 4', dict(a=4)) or safe_eval('b == 4', dict(b=4))
    assert not safe_eval('a in b', dict(a=4, b=3))
    assert safe_eval('a in b', dict(a=4, b=[4]))

# Generated at 2022-06-11 17:18:17.786749
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a test function for safe_eval. To test a function,
    a new method should be added to this class with a name starting
    with 'test_'. The function should check for the expected results.
    '''
    from ansible.module_utils.common.text.converters import to_unicode
    from units.compat import unittest

    class TestSafeEval(unittest.TestCase):
        ''' Test class for safe_eval '''
        def setUp(self):
            ''' setup method to setup basic parameters '''
            self.safe_eval = safe_eval
            self.true_val = True
            self.false_val = False

        def test_integer(self):
            ''' test cases for integer '''

# Generated at 2022-06-11 17:18:27.766113
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:36.915790
# Unit test for function safe_eval
def test_safe_eval():
    '''
    [
    "{{ foo }}",
    "{{ foo.bar() }}",
    "{{ foo['bar'] }}",
    "{% if True %}True{% endif %}",
    "{% if False %}True{% endif %}",
    ]

    '''

# Generated at 2022-06-11 17:18:42.652677
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == 'foo'
    assert safe_eval("foo + bar") == 'foo + bar'
    assert safe_eval("foo in bar") == 'foo in bar'
    assert safe_eval("foo in [1,2,3]") == 'foo in [1,2,3]'
    assert safe_eval("5 + 10") == 15
    assert safe_eval("[1,2,3,4]") == [1, 2, 3, 4]
    assert safe_eval("{ 'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{ 'a': 1, 'b': (1, 2)}") == {'a': 1, 'b': (1, 2)}
    assert safe_eval("1 + 2 + 3") == 6
   

# Generated at 2022-06-11 17:18:50.857034
# Unit test for function safe_eval
def test_safe_eval():
    tdata = [
        # these are expected to pass and return a useful result
        (1, 1),
        ("1", 1),
        ("foo", "foo"),
        ("null", None),
        ("true", True),
        ("false", False),
        ("[1, 2, 3]", [1, 2, 3]),
        ("[a, b, c]", ['a', 'b', 'c']),
        ("[1, 2, 3]", [1, 2, 3]),
        ("[1, 1+1, 3]", [1, 2, 3]),
        ("{'a':1, 'b':2}", dict(a=1, b=2)),
        ("{'a':1, 'b':1+1}", dict(a=1, b=2)),
    ]

# Generated at 2022-06-11 17:19:00.697364
# Unit test for function safe_eval
def test_safe_eval():
    # assert that the following expressions are all valid
    VALID_EXPRS = (
        "1",
        "1 + 1",
        "True",
        "True or False",
        "True and False",
        "True and (1 == 1)",
        "True and (1 == 2)",
        "True and (1 == 1) or (1 == 2)",
        "1 + 1 or 1 + 2 or 3 + 3",
        "['a', 'b', 'c']",
        "{'a': 1, 'b': 2, 'c': 3}",
        "a",
    )

    # make sure that safe_eval raises exceptions for invalid expressions

# Generated at 2022-06-11 17:19:10.379084
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:18.943567
# Unit test for function safe_eval
def test_safe_eval():
    # basic variable
    assert 42 == safe_eval('42')
    # basic string
    assert '42' == safe_eval('"42"')
    # basic variable plus 1
    assert 43 == safe_eval('a + 1', dict(a=42))
    # basic variable plus 1
    assert 43 == safe_eval('a+1', dict(a=42))
    # basic variable plus 1
    assert 43 == safe_eval('a+1', dict(a='42'))

    if sys.version_info[0] == 2:
        # basic True
        assert True == safe_eval('True')
        # basic False
        assert False == safe_eval('False')
        # basic None
        assert None == safe_eval('None')
        # complex list

# Generated at 2022-06-11 17:19:29.170900
# Unit test for function safe_eval
def test_safe_eval():
    '''This function is used to test safe_eval for various testcases.
    Some of the testcases are as follows:

    If the given expression is not a string, then it will return the
    given expression.
    If the given expression string is a valid expression, then it will
    return the expression result.
    If the given expression contains a invalid string, then it will
    return the expression string.
    If the given expression contains a invalid function, then it will
    raise an exception

    '''
    # If the given expression is not a string, then it will return the given expression.
    # Eg: s = ['k', 'k1', 'k2']
    #     safe_eval(s)
    #     return: ['k', 'k1', 'k2']
    s = ['k', 'k1', 'k2']
    assert safe

# Generated at 2022-06-11 17:19:43.769481
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Function safe_eval unit tests, by testing different types
    '''
    # Test ast.Expression
    result, _ = safe_eval('[1, 2, 3]', {}, include_exceptions=True)
    assert result == [1, 2, 3]

    # Test ast.Num
    result, _ = safe_eval('1', {}, include_exceptions=True)
    assert result == 1

    # Test ast.Str
    result, _ = safe_eval('"foo"', {}, include_exceptions=True)
    assert result == "foo"

    # Test ast.Name
    result, _ = safe_eval('a', {'a': 'my_string'}, include_exceptions=True)
    assert result == 'my_string'

    # Test ast.Tuple

# Generated at 2022-06-11 17:19:50.334649
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("1") == 1
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("None") == None
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{'foo':'bar'}") == {'foo':'bar'}
    assert safe_eval("1-1") == 0
    assert safe_eval("1+1") == 2
    assert safe_eval("2*2") == 4
    assert safe_eval("2**2") == 4
    assert safe_eval("1+1", locals={'foo':'bar'}) == 2
    assert safe_eval("foo", locals={'foo':'bar'}) == 'bar'

# Generated at 2022-06-11 17:20:01.008525
# Unit test for function safe_eval
def test_safe_eval():
    # Test with a string
    result = safe_eval('1')
    assert result == 1
    # Test with a string and a complex expression
    result = safe_eval('1 + 4 * 3')
    assert result == 13
    # Test type comparison
    result = safe_eval('type([]) == list')
    assert result is True
    # Test with a string and a complex expression having a builtin function call
    result = safe_eval('str(1) + 4 * 3')
    assert result == '143'
    # Test with a string and a complex expression having a builtin function call
    result = safe_eval('[1, 2, 3] + [1, 2, 3]')
    assert result == [1, 2, 3, 1, 2, 3]
    # Test with a string and a complex expression having a builtin function call
   

# Generated at 2022-06-11 17:20:09.475437
# Unit test for function safe_eval
def test_safe_eval():
    # We expect to get a SyntaxError exception when we pass a literal string
    # literal_string_data = "test"
    # worked, syntax_error = safe_eval(literal_string_data, include_exceptions=True)
    # assert(isinstance(syntax_error, SyntaxError))

    # Expressions with only string literals are allowed
    string_literal_data = "'test'"
    worked, syntax_error = safe_eval(string_literal_data, include_exceptions=True)
    assert(worked == "test" and syntax_error is None)

    # Expressions with only numbers are allowed
    number_data = "6"
    worked, syntax_error = safe_eval(number_data, include_exceptions=True)
    assert(worked == 6 and syntax_error is None)

    # Express

# Generated at 2022-06-11 17:20:18.311765
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("dict(a=1, b=2)") == {'a': 1, 'b': 2}
    assert safe_eval("[1,2]") == [1, 2]

    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("dict(a=1, b=2)", include_exceptions=True) == ({'a': 1, 'b': 2}, None)
    assert safe_eval("[1,2]", include_exceptions=True) == ([1, 2], None)

    assert safe_eval("myutil.myfunc()", {"myutil": {"myfunc": lambda: "OK"}}, include_exceptions=True) == ("OK", None)

# Generated at 2022-06-11 17:20:26.180376
# Unit test for function safe_eval
def test_safe_eval():
    # A collection of test vectors to ensure that safe_eval returns
    # the expected data type
    inputs = [
        '"lol"',
        '23',
        '"8"',
        'false',
        'true',
        'null',
        '[]',
        '[1,2,3]',
        '{"foo": "bar"}',
        '[{"foo": "bar"}]',
        '("one", "two")',
        '{"a": 1, "b": 2}',
        '{"a": [1, 2, 3], "b": [4, 5, 6]}',
        '{"a": "foo", "b": "bar"}'
    ]


# Generated at 2022-06-11 17:20:35.140559
# Unit test for function safe_eval
def test_safe_eval():
    def assert_safe_eval(before, after):
        assert safe_eval(before) == after
        assert safe_eval(repr(before)) == after

    # same as Jinja, constants like true, false, none evaluate to themselves
    assert_safe_eval('true', 'true')
    assert_safe_eval('false', 'false')
    assert_safe_eval('null', 'null')

    # basic math operations
    assert_safe_eval('6 * 7', 42)
    assert_safe_eval('2 + 3 * 4', 14)
    assert_safe_eval('2 * 3 + 4', 10)

    # string operations
    assert_safe_eval('"a" + "b"', 'ab')
    assert_safe_eval('"a" * 3', 'aaa')

    # comparison operations
    assert_safe_eval

# Generated at 2022-06-11 17:20:43.120290
# Unit test for function safe_eval
def test_safe_eval():
    expr = "a_list_variable"
    locals = {'a_list_variable': [1, 2, 3]}
    assert safe_eval(expr, locals) == locals['a_list_variable']

    expr = "a_list_variable | map(attribute='split') | list"
    locals = {'a_list_variable': {'k1': 'v1 v2', 'k2': 'v3 v4'}}

    try:
        if sys.version_info < (3, 0):
            # Python 2.6..2.7 not able to handle dicts
            assert safe_eval(expr, locals) == [[u'v1', u'v2'], [u'v3', u'v4']]
    except Exception:
        pass


# Generated at 2022-06-11 17:20:54.734649
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval for simple variable
    a = 1
    simple_var = 'a'
    assert safe_eval(simple_var) == 1
    assert safe_eval(simple_var, locals={'a': 2}) == 2
    assert safe_eval(simple_var, include_exceptions=True) == (1, None)
    assert safe_eval(simple_var, locals={'a': 2}, include_exceptions=True) == (2, None)

    # Test safe_eval for json variable
    json_var = '{"key": "value"}'
    assert safe_eval(json_var) == {"key": "value"}
    assert safe_eval(json_var, include_exceptions=True) == ({"key": "value"}, None)

    # Test safe_eval for simple expression

# Generated at 2022-06-11 17:20:59.593135
# Unit test for function safe_eval
def test_safe_eval():
    # Arrange
    expr = 'foo'
    locals = {'foo': 'bar'}

    # Act
    result = safe_eval(expr, locals)

    # Assert
    if result != 'bar':
        raise AssertionError("Unit test for safe_eval failed: %s != bar" % str(result))



# Generated at 2022-06-11 17:21:24.697554
# Unit test for function safe_eval
def test_safe_eval():
    # Tests valid input
    expr = '[2*x for x in range(10) if x > 2]'
    res = safe_eval(expr)
    assert res == [4, 6, 8]

    expr = '{"foo": "bar", "biz": "baz"}'
    res = safe_eval(expr)
    assert res == {"foo": "bar", "biz": "baz"}

    expr = '{"foo": False}'
    res = safe_eval(expr)
    assert res == {"foo": False}

    expr = '{"foo": None}'
    res = safe_eval(expr)
    assert res == {"foo": None}

    expr = '{"foo": "{{ 5 }}"}'
    res = safe_eval(expr)
    assert res == {"foo": "{{ 5 }}"}

    # Invalid expressions



# Generated at 2022-06-11 17:21:32.789953
# Unit test for function safe_eval
def test_safe_eval():
    # basic string/number literals
    assert safe_eval('"42"') == '42'
    assert safe_eval('42') == 42
    assert safe_eval('42.0') == 42.0
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('{ "foo": 42, "bar": 43 }') == {'foo': 42, 'bar': 43}

    # numeric expressions
    assert safe_eval('41 + 1') == 42

# Generated at 2022-06-11 17:21:42.277409
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('true') is True
    assert safe_eval('abc') == 'abc'
    assert safe_eval('abc', include_exceptions=True) == ('abc', None)
    assert safe_eval('(1 + [2])') == [1,2]
    assert safe_eval('{"a":1}') == {"a":1}
    assert safe_eval('{"a":1+1}') == {"a": 2}
    assert safe_eval('(1 + [2]) and true') == True
    assert safe_eval('(1 + [2]) and true or false') == True
    assert safe_eval('(1 + [2]) and true or true and false') == False

# Generated at 2022-06-11 17:21:51.142825
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:57.522383
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1
    expr = 'price * qty'
    result = safe_eval(expr, locals())
    assert result == 0

    # Test 2
    expr = 'price * qty'
    result = safe_eval(expr, locals())
    assert result == 0

    # Test 3
    expr = '-price'
    result = safe_eval(expr, locals())
    assert result == 0

    # Test 4
    expr = '-price * -qty'
    result = safe_eval(expr, locals())
    assert result == 0

    # Test 5
    expr = 'a and b'
    result = safe_eval(expr, locals())
    assert result == 0

    # Test 6
    expr = 'a and b or c'
    result = safe_eval(expr, locals())
    assert result == 0

   

# Generated at 2022-06-11 17:22:05.965805
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:16.441861
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:26.716045
# Unit test for function safe_eval
def test_safe_eval():

    def run_test_set(test_set):
        # Test set is a collection of test cases
        # Each test is a tuple of (test_string, result_of_eval)

        print("\n### Test safe_eval() using test set: %s" % test_set)

        for test_string, expected_eval_result in test_set:
            print("\n> test_string: %s" % test_string)
            if expected_eval_result is None:
                try:
                    result = safe_eval(test_string)
                    # This should result in an exception being thrown
                    assert False, "test_string: %s - safe_eval() did not throw exception" % test_string
                except Exception as e:
                    print("- expected exception thrown: %s" % to_native(e))

# Generated at 2022-06-11 17:22:37.406015
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "456"}') == {"a": "456"}
    assert safe_eval('a + b', locals={'a': 1, 'b': 2}) == 3
    assert safe_eval('a + b', locals={'a': "foo", 'b': "bar"}) == "foobar"
    assert safe_eval('a in b', locals={'a': "foo", 'b': ["bar", "baz", "foo"]}) is True
    assert safe_eval('a in b', locals={'a': "foo", 'b': ["bar", "baz", "qux"]}) is False
    assert safe_eval('True') is True
    assert safe_eval('False') is False

# Generated at 2022-06-11 17:22:47.336767
# Unit test for function safe_eval
def test_safe_eval():
    # A syntax error should return itself and no exception
    assert (safe_eval("{{ foo", include_exceptions=True)) == ("{{ foo", None)

    # A parsing exception should return itself and no exception
    assert (safe_eval("{% foo %}", include_exceptions=True)) == ("{% foo %}", None)

    # A type of exception should return itself and the exception
    assert (safe_eval("[x for x in range(10)]", include_exceptions=True)) == ("[x for x in range(10)]", None)
    assert (safe_eval("[x for x in range(10)", include_exceptions=True)) == ("[x for x in range(10)", None)

# Generated at 2022-06-11 17:23:27.621233
# Unit test for function safe_eval
def test_safe_eval():
    def check(expr, ref, locals=None):
        res = safe_eval(expr, locals=locals)
        if res != ref:
            print("ERROR: `%s` evaluated to %s instead of %s" % (expr, res, ref))
            sys.exit(1)

    check('{ test: value }', {'test': 'value'})
    check('[v1, v2]', ['v1', 'v2'])
    check('item.0', 'val0', {'item': ['val0', 'val1']})
    check('4', 4)
    check('4.2', 4.2)
    check('val1', 'val1', {'val1': 'val1'})

