

# Generated at 2022-06-11 17:13:38.526475
# Unit test for function safe_eval
def test_safe_eval():
    # Function safe_eval is only intended to handle simple expressions,
    # it is NOT intended to evaluate complex python statements.

    # In general, functions that are defined in the __builtin__
    # module are disallowed.  This covers both python2 and python3.
    # In python2, they are in the __builtin__ module and
    # in python3 they are in the builtins module.
    # However, we make an exception for min, max, and abs
    # as those are the only functions that are whitelisted
    # in the safe_eval function.

    # tests intended to pass
    assert safe_eval("'a string literal'") == 'a string literal'
    assert safe_eval("[]") == []
    assert safe_eval("[1,2,3]") == [1,2,3]

# Generated at 2022-06-11 17:13:45.748199
# Unit test for function safe_eval
def test_safe_eval():
    # define certain JSON types
    # eg. JSON booleans are unknown to python eval()
    OUR_GLOBALS = {
        '__builtins__': {},  # avoid global builtins as per eval docs
        'false': False,
        'null': None,
        'true': True,
        # also add back some builtins we do need
        'True': True,
        'False': False,
        'None': None
    }
    expr = '''[1, 2, (3, 4)]'''
    parsed_tree = ast.parse(expr, mode='eval')
    # iterate over all child nodes
    for child_node in ast.iter_child_nodes(parsed_tree):
        print(child_node)

# Generated at 2022-06-11 17:13:56.103628
# Unit test for function safe_eval
def test_safe_eval():
    assert "my_var" == safe_eval('"my_var"')
    assert 123 == safe_eval('123')
    assert 123.0 == safe_eval('123.0')
    assert -123 == safe_eval('-123')
    assert -123.0 == safe_eval('-123.0')
    assert 1 == safe_eval('1')
    assert -1 == safe_eval('-1')
    assert 1.0 == safe_eval('1.0')
    assert -1.0 == safe_eval('-1.0')
    assert 1.0 == safe_eval('0+1.0')
    assert -1.0 == safe_eval('0+(-1.0)')
    assert 1.0 == safe_eval('1.0 - 0')

# Generated at 2022-06-11 17:14:06.550890
# Unit test for function safe_eval
def test_safe_eval():

    class E(Exception):
        pass

    # test that a simple list definition works
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

    # test that a simple dict definition works
    assert safe_eval('{"foo": 1, "bar": "buzz"}') == {"foo": 1, "bar": "buzz"}

    # simple bool test
    assert safe_eval('true') is True
    assert safe_eval('false') is False

    # simple None test
    assert safe_eval('null') is None

    # simple expression
    assert safe_eval('1 + 1') == 2

    # simple expression with a variable
    assert safe_eval('var + 1', dict(var=2)) == 3

    # expression using a variable that is not defined

# Generated at 2022-06-11 17:14:14.682513
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-11 17:14:22.944933
# Unit test for function safe_eval
def test_safe_eval():
    assert C.DEFAULT_KEEP_REMOTE_FILES != safe_eval("C.DEFAULT_KEEP_REMOTE_FILES")
    assert not safe_eval("None")
    assert 0 == safe_eval("0")
    assert 10.3 == safe_eval("10.3")
    assert 1 == safe_eval("1")
    assert "string" == safe_eval('"string"')
    assert ["a", "b", "c"] == safe_eval("[\"a\", \"b\", \"c\"]")
    assert {"a": "b"} == safe_eval("{\"a\": \"b\"}")
    assert (1, 3, 4) == safe_eval("(1, 3, 4)")
    assert [0, 1, 0] == safe_eval("[False, True, False]")

# Generated at 2022-06-11 17:14:34.072715
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:39.687603
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('""') == ''
    assert safe_eval('[]') == []
    assert safe_eval('()') == ()
    assert safe_eval('{}') == {}
    assert safe_eval('{ "foo": "bar" }') == { 'foo': 'bar' }
    assert safe_eval('"foo" in vars') == 'foo' in vars
    assert safe_eval('"foo" in dict(x=1)', dict(x=1)) == 'foo' in dict(x=1)
    assert safe_eval('True and False') is False
    assert safe_eval('True or False') is True
    assert safe_eval('1 + 1') == 2
   

# Generated at 2022-06-11 17:14:49.027828
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Return the results as a dict
    result: the result of the computation
    exception: None, or the Exception instance
    '''
    def check(expr):
        result, exception = safe_eval(expr, include_exceptions=True)
        return dict(
            result=result,
            exception=exception,
        )

    def check_syntaxerror(expr):
        result = safe_eval(expr)
        return dict(
            result=result,
            exception=None,
        )

    # Ensure that the exception is raised
    assert check('a_dict["b"]') == dict(
        result=None,
        exception=Exception('invalid expression (a_dict["b"])'),
    )
    # OK

# Generated at 2022-06-11 17:14:57.143485
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    arguments = {'a': 10, 'b': 20}


# Generated at 2022-06-11 17:15:07.680551
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inv = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inv)
    play_context = PlayContext(variable_manager=variable_manager)

    # tests of basic datastructures
    test_cases = [
        ('[foo, bar]', ['foo', 'bar']),
        ('{foo: bar}', {'foo': 'bar'}),
        ('(foo, bar)', ('foo', 'bar')),
        ('foo', 'foo'),
        ('123', 123),
        ('foo.bar', 'foo.bar'),
    ]


# Generated at 2022-06-11 17:15:17.296652
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests
    assert safe_eval('1 + 2') == 3
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # test json types
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # test lists and dicts
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}

    # full, real world example

# Generated at 2022-06-11 17:15:27.314824
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1 == 2') is True
    assert safe_eval("'foo' in ['bar', 'baz', 'foo']") is True
    assert safe_eval("1 in [1, 2, 3]") is True
    assert safe_eval("1 in {1: 1, 2: 2, 3: 3}") is True
    assert safe_eval("'foo' in {'bar': 'baz', 'foo': 'quux'}") is True
    assert safe_eval("foo in bar") == "foo in bar"
    assert safe_eval("print('foo')") == "print('foo')"
    assert safe_eval("['foo'] + 'bar'") == "['foo'] + 'bar'"
    assert safe_eval("['foo'] + u'bar'") == "['foo'] + u'bar'"


# Generated at 2022-06-11 17:15:36.932080
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:45.662086
# Unit test for function safe_eval
def test_safe_eval():
    '''Unit test for function safe_eval()'''

    # define some variables to be used in the expressions
    a = 10
    b = 'foobar'
    c = {'key1': 'val1', 'key2': 'val2'}
    d = ('one', 'two', 'three')
    e = ['a', 'b', 'c']
    f = False
    g = 'false'
    h = None
    i = 50
    j = '50'
    k = {'a': {'b': 'c'}}
    l = []
    m = ['test', '123']

    # test with single expressions that should fail

# Generated at 2022-06-11 17:15:55.721206
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:06.668703
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the safe_eval function
    '''
    # test with valid data
    assert safe_eval("len([1,2,3,4,5]) == 5") == True
    assert safe_eval("len([1,2,3,4,5]) == 6") == False
    assert safe_eval("[1,2,3,4,5][3]") == 4
    assert safe_eval("{'a':'b','c':'d','e':'f'}['c']") == 'd'
    assert safe_eval("{'a':'b','c':'d','e':'f'}") == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert safe_eval("['a','b','c','d','e'][2]") == 'c'

# Generated at 2022-06-11 17:16:15.752804
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test cases for safe_eval
    '''
    assert safe_eval('1+1') == 2
    assert safe_eval('[1+1]') == [2]
    assert safe_eval('{1+1: 2+2}') == {2: 4}
    assert safe_eval('int(7)') == 7
    assert safe_eval('len([1,2,3,4])') == 4
    assert safe_eval('[1,2,3,4][1:3]') == [2, 3]
    assert safe_eval('None') == None
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('True and False') is False
    assert safe_

# Generated at 2022-06-11 17:16:23.957335
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic sanity test for function safe_eval
    '''

    # Validate that we can use if xxx in (1,2,3) and it is tested as a tuple
    expr = 'if xxx in (1,2,3): yyy'
    locals = {'xxx': 2, 'yyy': 'yyy'}
    result, error = safe_eval(expr, locals, include_exceptions=True)
    assert result == 'yyy'
    assert error is None

    # Validate that we can use if xxx in [1,2,3] and it is tested as a list
    expr = 'if xxx in [1,2,3]: yyy'
    locals = {'xxx': 2, 'yyy': 'yyy'}

# Generated at 2022-06-11 17:16:34.592435
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:49.013900
# Unit test for function safe_eval
def test_safe_eval():
    def assert_safe(expr, expected):
        actual, error = safe_eval(expr, include_exceptions=True)
        assert actual == expected
        assert error is None

    def assert_unsafe(expr, expected):
        actual, error = safe_eval(expr, include_exceptions=True)
        assert actual == expected
        assert isinstance(error, Exception)

    # simple literals are allowed
    assert_safe('None', None)
    assert_safe('True', True)
    assert_safe('False', False)
    assert_safe('1', 1)
    assert_safe('1.0', 1.0)
    assert_safe('"a string"', "a string")

    # a couple of unary operations are allowed
    assert_safe('-1', -1)

# Generated at 2022-06-11 17:16:59.055504
# Unit test for function safe_eval
def test_safe_eval():
    '''
    A simple test to make sure we can eval simple expressions.
    '''
    # eval() is a builtin function, so should not be allowed in custom eval()
    # functions.
    assert safe_eval("eval('1 + 1')") == "eval('1 + 1')"

    # 1 + 2, 3 - 2 and similar expressions should be evaluated.
    # Note: made (3 - 2) a tuple for easier testing
    assert safe_eval("1 + 2, (3 - 2)") == (3, (3 - 2))

    # str concatenation should be evaluated.
    assert safe_eval('"foo" + "bar"') == "foobar"

    # Make sure we can handle "in" operator.
    assert safe_eval('"foo" in ["foo", "bar"]') is True

    # Make sure whitespaces

# Generated at 2022-06-11 17:17:10.174419
# Unit test for function safe_eval
def test_safe_eval():
    # test basic arithmetic
    assert safe_eval('1 + 1') == 2

    # test string literal
    assert safe_eval('"foo"') == "foo"

    # test boolean literal
    assert safe_eval('true') == True

    # test string concat via %
    assert safe_eval('"%s %s" % ("foo", "bar")') == 'foo bar'

    # test dict literal
    assert safe_eval('{"a": 1, "b": "foo"}') == {'a': 1, 'b': 'foo'}

    # test list literal
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']

    # test set literal
    assert safe_eval('{"foo", "bar"}') == set(['foo', 'bar'])

    # test tuple literal
    assert safe_eval

# Generated at 2022-06-11 17:17:18.822571
# Unit test for function safe_eval
def test_safe_eval():
    # This needs to be kept in sync with what is allowed in filters
    # and what is allowed in jinja2, see the filters/jinja2 files.
    #
    # Some of these are commented out because the tests are not passing
    # yet.  These should be uncommented once fixed.

    # This is a simple expression, it should be returned unchanged.
    assert safe_eval('1+1') == '1+1'

    # This is a valid expression, it should be evaluated.
    assert safe_eval('1+1') == 2

    # This is a valid JSON expression, it should be evaluated.
    assert safe_eval('{"a": 1}') == {"a": 1}

    # This is an invalid expression, it should fail with an exception
    # and the expression returned unchanged.

    # assert safe_eval("open('/tmp/

# Generated at 2022-06-11 17:17:27.908800
# Unit test for function safe_eval
def test_safe_eval():
    # Check safe_eval can evaluate safe expressions
    expr = "item + 1"
    item = 1
    result = safe_eval(expr, dict(item=item))
    assert result == 2

    # Check safe_eval returns expression in a string if there is a syntax error
    expr = "item++"
    item = 1
    result = safe_eval(expr, dict(item=item))
    assert result == expr

    # Check safe_eval returns expression in a string if there is a variable
    # not defined in locals
    expr = "item"
    result = safe_eval(expr)
    assert result == expr

    # Check safe_eval returns expression in a string if there is a
    # unsafe function
    expr = "abs(item)"
    item = 1
    result = safe_eval(expr, dict(item=item))
   

# Generated at 2022-06-11 17:17:37.587278
# Unit test for function safe_eval
def test_safe_eval():
    locals_dict = {"a_list": [1,2,3], "ansible_testvar": "test"}
    del locals_dict['ansible_testvar']
    del locals_dict['a_list']
    result, exception = safe_eval("a_list[0]", locals_dict, True)
    if exception is not None:
        print(exception)
    print(result)
    result, exception = safe_eval("ansible_testvar", locals_dict, True)
    if exception is not None:
        print(exception)
    print(result)
    result, exception = safe_eval("{{ ansible_testvar }}", locals_dict, True)
    if exception is not None:
        print(exception)
    print(result)

# Generated at 2022-06-11 17:17:46.074956
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2') == 2  # simple expression
    assert safe_eval('a', {'a': 42}) == 42  # lookup name in locals
    assert safe_eval('a.b.c') == 'a.b.c'  # allow dotted names
    assert safe_eval('true') is True  # allow JSON booleans
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('3 + 4') == 7  # allow arithmetic operators
    assert safe_eval('len(a)', {'a': [1, 2, 3]}) == 3  # allow len()
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]  # allow JSON lists

# Generated at 2022-06-11 17:17:55.922012
# Unit test for function safe_eval
def test_safe_eval():

    # true and false are now allowed, as well as JSON true, false, and null
    assert safe_eval("true") is True
    assert safe_eval("false") is False

    # Python 3 is disallowing octal literals, so 255 being octal is not allowed
    # in Python 3.  This value will be legal in Python 2 and will be treated
    # as a distinct value from 255 in Python 3.
    if sys.version_info[0] == 3 and sys.version_info[1] >= 6:
        # The assertion below this comment wouldn't work before Python 3.6
        # because in Python 3.5 and older, the octal literal would be evaluated
        # early and would cause an error during execution of CleansingNodeVisitor.
        assert safe_eval("0o377") == 0o377
    else:
        assert safe_

# Generated at 2022-06-11 17:18:03.131429
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:09.554317
# Unit test for function safe_eval
def test_safe_eval():
    invalid_expr = "{{a + b}}"
    valid_expr = "a + b"
    valid_expr_multiline = "a + b\nc + d"
    valid_expr_with_function_call = "a.split()"
    invalid_expr_with_function_call = "a.b.c()"
    valid_expr_split_with_function_call = "a.split()"
    invalid_expr_with_unexpected_operator = "a + -b"
    invalid_expr_with_invalid_unicode = "a + b\n# -*- coding:  -*-"
    valid_expr_with_valid_unicode = "a + b\n# -*- coding: utf-8 -*-"


# Generated at 2022-06-11 17:18:27.893141
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:37.032079
# Unit test for function safe_eval
def test_safe_eval():
    # we start with a string
    assert safe_eval('10') == 10
    assert safe_eval('10.23') == 10.23
    assert safe_eval('10.23') != 10

    # validate that list works
    assert safe_eval("['item']") == ['item']

    # dict should work
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}

    # negation should work
    assert safe_eval("-10") == -10

    # addition should work
    assert safe_eval("10 + 10") == 20

    # subtraction should work
    assert safe_eval("10 - 10") == 0

    # multiplication should work
    assert safe_eval("10 * 10") == 100

    # division should work
    assert safe_eval("10 / 10") == 1

    #

# Generated at 2022-06-11 17:18:42.719971
# Unit test for function safe_eval
def test_safe_eval():
    # test boolean evaluation
    expr1 = 'false == False and true == True'
    result1, exc1 = safe_eval(expr1, locals={}, include_exceptions=True)
    assert result1 == True
    assert exc1 == None

    # test integer evaluation
    expr2 = 'a == 1 and b == 2'
    result2, exc2 = safe_eval(expr2, locals={'a': 1, 'b': 2}, include_exceptions=True)
    assert result2 == True
    assert exc2 == None

    # test string evaluation
    expr3 = 'a == "abc" and b == "def"'
    result3, exc3 = safe_eval(expr3, locals={'a': 'abc', 'b': 'def'}, include_exceptions=True)
    assert result3 == True

# Generated at 2022-06-11 17:18:50.856553
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test for function safe_eval()
    '''

    try:
        from ansible.module_utils.common.text.converters import container_to_text
    except ImportError:
        # missing dependency, can't do tests
        return


# Generated at 2022-06-11 17:19:00.697699
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    def assert_eval(expr, expected, locals=None, pass_exceptions=True):
        if pass_exceptions:
            result, exception = safe_eval(expr, locals, pass_exceptions)
            assert exception is None, exception
        else:
            result = safe_eval(expr, locals, pass_exceptions)
        assert isinstance(result, string_types)
        assert expected == result

    assert_eval("1", "1")
    assert_eval("1 + 3", "4")
    # Python3 int + bytes is evaluated as bytes
    assert_eval("1 + u'foo'", "'foo1'")
    assert_eval("1 + b'foo'", "'foo1'")

# Generated at 2022-06-11 17:19:10.377766
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:18.941566
# Unit test for function safe_eval
def test_safe_eval():
    # Test exclusion of non-whitelisted nodes
    assert safe_eval("__import__('sys').path") == '__import__(\'sys\').path'
    assert safe_eval("__import__('os').path") == '__import__(\'os\').path'
    # Test for invalid function call
    assert safe_eval("__builtins__.open('filename')") == '__builtins__.open(\'filename\')'
    assert safe_eval("__builtins__.open('filename', 'r')") == '__builtins__.open(\'filename\', \'r\')'
    # Test containment of builtins into OUR_GLOBALS
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    # Test for JSON types
   

# Generated at 2022-06-11 17:19:29.176775
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: more tests
    expr = "a_list_variable"
    # Python 2 and 3 returns different strings
    if sys.version_info < (3, 0, 0):
        assert safe_eval(expr) == "a_list_variable"
    else:
        assert safe_eval(expr) == "a_list_variable"
    # default locals in the safe_eval function do not include a_list_variable
    expr = "a_list_variable[0]"
    assert safe_eval(expr) == "a_list_variable[0]"
    # pass in a_list_variable with value of ['a'] and expr should be evaluated
    expr = "a_list_variable[0]"
    assert safe_eval(expr, locals={'a_list_variable': ['a']}) == "a"
    # Jinja2

# Generated at 2022-06-11 17:19:34.118132
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import copy
    import traceback
    import unittest

    # Make sure that the environment is clean before we begin
    assert(not any(env_var in C.DEFAULT_MODULE_UTILS_PATH for env_var in ('ANSIBLE_LIBRARY', 'ANSIBLE_MODULE_UTILS')))

    # Non-string inputs are non-evalable so they should be returned as-is.
    non_string_inputs = (True, 42, [1, 2, 3], {"a": 1, "b": 2})
    for non_string_input in non_string_inputs:
        expected = copy.deepcopy(non_string_input)
        actual = safe_eval(non_string_input)
        assert(expected == actual)

    # Make sure lists are eval'd correctly.

# Generated at 2022-06-11 17:19:42.390362
# Unit test for function safe_eval
def test_safe_eval():
    # this test should pass, with the exception being None
    assert safe_eval("1 + 2") == 3, "simple arithmetic test failed"

    # this test should fail with an exception about invalid tokens
    assert safe_eval("a = 1 + 2", include_exceptions=True)[1] is not None

    # this test should fail, the exception being about invalid function calls
    assert safe_eval("__import__()", include_exceptions=True)[1] is not None

    # this test should fail, the exception being about invalid function calls
    assert safe_eval("open()", include_exceptions=True)[1] is not None

    # this test should fail, the exception being about invalid function calls
    assert safe_eval("fail_if()", include_exceptions=True)[1] is not None

    # this test should pass, with the exception being None


# Generated at 2022-06-11 17:19:57.470107
# Unit test for function safe_eval
def test_safe_eval():
    """
    Code coverage can't see into this function, so it doesn't get
    tested by default.  It's not a big deal to test this explicitly,
    however.

    :return:
    """

# Generated at 2022-06-11 17:20:05.498319
# Unit test for function safe_eval
def test_safe_eval():
    # make sure that in a safe env, safe_eval() works
    def testit(expr, result):
        assert safe_eval(expr) == result
        assert safe_eval(expr, include_exceptions=True)[0] == result

    testit('True', True)
    testit('False', False)
    testit('None', None)
    testit('["foo", "bar"]', ['foo', 'bar'])
    testit('["foo", "bar", "baz"][0]', 'foo')
    testit('["foo", "bar", "baz"]|first', 'foo')
    testit('["foo", "bar", "baz"]|join("-")', 'foo-bar-baz')

# Generated at 2022-06-11 17:20:15.187548
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:22.389507
# Unit test for function safe_eval
def test_safe_eval():
    containers = ['', (), [], {}, set()]
    truthy = ['True', 'true', 'TRUE']
    falsey = ['False', 'false', 'FALSE']
    class MyClass:
        pass
    my_object = MyClass()

    # Test valid syntax
    if not isinstance(safe_eval(''),             string_types):      raise Exception('not a string')
    if not isinstance(safe_eval(()),             tuple):             raise Exception('not a tuple')
    if not isinstance(safe_eval([]),             list):              raise Exception('not a list')
    if not isinstance(safe_eval({}),             dict):              raise Exception('not a dict')
    if not isinstance(safe_eval(set()),          set):               raise Exception('not a set')

# Generated at 2022-06-11 17:20:29.211090
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:38.330096
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test various aspects of safe_eval()
    '''
    # Test that safe_eval() returns the same result as eval()
    # given an expression consisting of basic operators and
    # data types.
    expr = '(1 + 2) * (3 + 4)'
    assert safe_eval(expr) == eval(expr)

    # Test that safe_eval() raises an exception when given
    # an expression containing an unsupported node type.
    try:
        expr = '__import__("os").getcwd()'
        result = safe_eval(expr)
    except Exception as e:
        if 'invalid expression' in to_native(e):
            pass
        else:
            raise

    # Test that safe_eval() returns the same result as eval()
    # when given an expression that accesses elements on the
    # locals

# Generated at 2022-06-11 17:20:45.921400
# Unit test for function safe_eval
def test_safe_eval():
    # Simple valid expressions
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('1.0') == 1.0
    assert safe_eval('1.0+2.0') == 3.0
    assert safe_eval('a', dict(a=42)) == 42
    assert safe_eval('a == 1', dict(a=1)) is True
    assert safe_eval('a == 2', dict(a=1)) is False
    assert safe_eval('a + b', dict(a=1, b=3)) == 4
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('1 == 1') is True

# Generated at 2022-06-11 17:20:57.702326
# Unit test for function safe_eval
def test_safe_eval():
    data = {
        'foo': 'bar',
        'fro': 'baz',
        'some': 'list',
        'some_dict': {'foo': 'bar'},
        'some_list': ['foo', 'bar'],
    }


# Generated at 2022-06-11 17:21:05.336585
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:14.483794
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function safe_eval
    '''
    # Make some variables available for testing
    result = safe_eval('item')
    assert result == 'item'
    result = safe_eval('item', dict(item='item'))
    assert result == 'item'
    result = safe_eval('item', dict(item=1))
    assert result == 1
    result = safe_eval('item', dict(item=[1]))
    assert result == [1]
    result = safe_eval('item', dict(item={'foo': 'bar'}))
    assert result == {'foo': 'bar'}
    result = safe_eval('item', dict(item=(1, 2)))
    assert result == (1, 2)
    result = safe_eval('item', dict(item=[1, 2]))
    assert result

# Generated at 2022-06-11 17:21:29.523765
# Unit test for function safe_eval
def test_safe_eval():
    try:
        # import unit test frameworks
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestSafeEval(unittest.TestCase):
        def setUp(self):
            None

        def tearDown(self):
            None

        def test_safe_eval(self):
            self.assertEqual(safe_eval('1'), 1)
            self.assertEqual(safe_eval('true'), True)
            self.assertEqual(safe_eval('false'), False)
            self.assertEqual(safe_eval('null'), None)
            self.assertEqual(safe_eval('''['foo', 'bar', 'baz', 1, 2, 3]'''), ['foo', 'bar', 'baz', 1, 2, 3])
            self.assertE

# Generated at 2022-06-11 17:21:35.322168
# Unit test for function safe_eval
def test_safe_eval():
    # set some initial values
    true_val = True
    false_val = False
    null_val = None
    v1 = 1
    v2 = 2
    v3 = 3
    list_val = [ 1, 2, 3 ]
    dict_val = { 'a': 1, 'b': 2 }
    str1 = 'foo'
    str2 = 'bar'
    str3 = 'baz'

    # expressions which should be parsed as expected

# Generated at 2022-06-11 17:21:44.179365
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:53.073041
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ 1 + 2 }}") == "{{ 1 + 2 }}"
    assert safe_eval("{{ 2 + 3 }}", dict(dict(a=1))) == "{{ 2 + 3 }}"
    assert safe_eval("{{ 1 + 2 }}", dict(dict(a=1)), include_exceptions=True) == ("{{ 1 + 2 }}", None)
    assert safe_eval("{{ \"myvar\" }}", dict(dict(a=1)), include_exceptions=True) == ("{{ \"myvar\" }}", None)

    assert safe_eval("{{ a.b }}", dict(dict(a=dict(b=1)))) == 1
    assert safe_eval("{{ a.b.c.d }}", dict(dict(a=dict(b=dict(c=dict(d=3)))))) == 3

    assert safe_

# Generated at 2022-06-11 17:22:03.237984
# Unit test for function safe_eval
def test_safe_eval():
    ''' test_safe_eval '''

    # These tests should be safe
    tests_safe = [
        ('1 + 3', 4),
        ('4 - 2', 2),
        ('8 * 2', 16),
        ('9 / 3', 3),
        ('["a", "b", "c"]', ['a', 'b', 'c']),
        ('["a", "b", "c"][1]', 'b'),
        ('["a", "b", "c"][:]', ['a', 'b', 'c']),
        ('["a", "b", "c"][1:]', ['b', 'c']),
        ('["a", "b", "c"][:-1]', ['a', 'b']),
    ]

    # These tests should fail, but do not
    # We will be back to them later

# Generated at 2022-06-11 17:22:14.597989
# Unit test for function safe_eval
def test_safe_eval():
    '''
    safe_eval tests:
    '''
    # We do not want to traceback for these, just bail with a safe value
    # (i.e., the incoming value)
    #
    # Simple values which are OK
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("'mystring'") == 'mystring'
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("1.5") == 1.5
    assert safe_eval("1+1") == 1+1
    assert safe_eval("[1,2,3]") == [1, 2, 3]

# Generated at 2022-06-11 17:22:25.529323
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:36.449361
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:46.018283
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:55.256217
# Unit test for function safe_eval
def test_safe_eval():
    expr = '5'
    from ansible.module_utils.common.text.converters import to_text
    assert '5' == to_text(safe_eval(expr))
    assert '5' == to_text(safe_eval(expr))

    if not sys.version_info[0] == 2:
        # With python3 and literal_eval() we get a different value than with ast.literal_eval()
        # With python2 we get the same result
        expr = 'b"foo"'
        assert b'foo' == safe_eval(expr)

    expr = "'foo'"
    assert 'foo' == to_text(safe_eval(expr))

    expr = "'foo' + 'bar'"
    assert 'foobar' == to_text(safe_eval(expr))


# Generated at 2022-06-11 17:23:12.779391
# Unit test for function safe_eval
def test_safe_eval():
    tests = [
        ("a_list_variable", False),
        ("a_list_variable | count", False),
        ("{{ a_list_variable }}", True),
        ("{{ a_list_variable | count }}", True),
        ("{{ a_list_variable }, bad_variable", True),
        ("", True),
        ("[]", False),
        ("{}", False),
    ]
    for test in tests:
        test_str, should_fail = test
        result = safe_eval(test_str)
        assert (result is None) == should_fail, test_str


# Generated at 2022-06-11 17:23:21.868971
# Unit test for function safe_eval
def test_safe_eval():

    # test a variable
    variable = dict(a=1, b=2, c=3)
    assert safe_eval("{{ a }}", variable) == 1
    assert safe_eval("{{ a + b }}", variable) == 3
    assert safe_eval("{{ a + b + c }}", variable) == 6
    assert safe_eval("{{ a - b - c }}", variable) == -4

    # test a list
    assert safe_eval("{{ [1, 2, 3] }}") == [1, 2, 3]
    assert safe_eval("{{ [1, 2, 3] + [4, 5, 6] }}") == [1, 2, 3, 4, 5, 6]

    # test a dictionary

# Generated at 2022-06-11 17:23:33.232864
# Unit test for function safe_eval
def test_safe_eval():
    # Test good expressions
    assert safe_eval("2 + 2") == 4
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("{'foo': 1, 'bar': 2}") == {'foo': 1, 'bar': 2}
    assert safe_eval("foo == 'bar'") == 'foo == \'bar\''
    assert safe_eval("2 + '3'") == '23'
    assert safe_eval("2 * 3") == 6
    assert safe_eval("-1 * 2") == -2
    assert safe_eval("-1 * -2") == 2
    assert safe_eval("2 ** 3") == 8

    # Test bad expressions