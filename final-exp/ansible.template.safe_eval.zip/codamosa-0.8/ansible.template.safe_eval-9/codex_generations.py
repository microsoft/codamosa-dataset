

# Generated at 2022-06-11 17:13:36.129657
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Usage: python -c "import ansible.module_utils.common.text.converters; ansible.module_utils.common.text.converters.test_safe_eval()"
    '''

    # TODO: python3
    # FIXME: if we ever add more CALL_ENABLED entries to safe_eval() we will have to add more tests here
    CALL_ENABLED.append('min')

    if sys.version_info[:2] != (2, 7):
        print("Skipping test_safe_eval, need to use python2.7 for this test")
        return

    print("Testing ansible.module_utils.common.text.converters.safe_eval")

    # Test list comprehension
    x = [i * 2 for i in [1, 2, 3]]

# Generated at 2022-06-11 17:13:44.344895
# Unit test for function safe_eval

# Generated at 2022-06-11 17:13:49.910156
# Unit test for function safe_eval
def test_safe_eval():
    expressions = [
        '"a string"',  # A string
        '1 < 2',  # A boolean expression
        '1 + 2',  # An expression
        'a_list_variable'  # A variable name
    ]
    for expr in expressions:
        assert safe_eval(expr) == eval(expr)


# Generated at 2022-06-11 17:13:58.116234
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:07.241164
# Unit test for function safe_eval
def test_safe_eval():

    # most data structures that we use do not need to be parsed
    for value in (1, "foobar", {}, [], ()):
        assert value == safe_eval(value)

    # test for invalid expressions
    for expr in ('__import__("os").system("echo BOOM!")', '__builtins__["open"]("/etc/passwd").read()'):
        try:
            safe_eval(expr)
        except Exception:
            pass
        else:
            raise Exception("should have raised exception for eval(%s)" % expr)

    # test with local variables
    try:
        assert safe_eval('foo', {'foo': 42}) == 42
    except Exception:
        raise Exception("should not have raised exception for eval('foo', {'foo': 42})")


# Generated at 2022-06-11 17:14:14.894412
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:23.035191
# Unit test for function safe_eval
def test_safe_eval():

    # Dictionary keys must be an actual string
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}

    # Test functions
    (val, err) = safe_eval('mycall()', locals={'mycall': lambda: 'foo'}, include_exceptions=True)
    assert val == 'foo' and err is None
    assert safe_eval('range(5)') == range(5)

    # Test tuples
    assert safe_eval('(1,2,3)') == (1, 2, 3)

    # Test lists
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # Test array index
    assert safe_eval('mylist[1]', locals={'mylist': [1, 2, 3]}) == 2

    # Test set


# Generated at 2022-06-11 17:14:34.072291
# Unit test for function safe_eval
def test_safe_eval():
    print('### Testing safe_eval')
    assert safe_eval("10") == 10
    assert safe_eval("10 * 10") == 100
    assert safe_eval("foo.count(bar) > 0") == "foo.count(bar) > 0"
    assert safe_eval("1 + 1") == 2
    assert safe_eval("(True, False)") == (True, False)
    assert safe_eval("[1,2,3,4,5]") == [1, 2, 3, 4, 5]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': 1, 'b': '2+2'}") == {'a': 1, 'b': '2+2'}
    assert safe_eval

# Generated at 2022-06-11 17:14:40.440534
# Unit test for function safe_eval
def test_safe_eval():
    # contains a non-whitelisted function: len
    assert safe_eval('foo in bar') is None
    assert safe_eval('1 + 2') == 3
    assert safe_eval('bar.lower() in baz') is None
    assert safe_eval('foo in bar', dict(foo='foo', bar='bar')) is None



# Generated at 2022-06-11 17:14:49.441797
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:57.969082
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1:
    # Test safe eval using an integer value
    yaml_val_1 = '5'
    assert safe_eval(yaml_val_1) == 5

    # Test 2:
    # Test safe eval using a string
    yaml_val_2 = 'a'
    assert safe_eval(yaml_val_2) == 'a'

    # Test 3:
    # Test safe eval using a dict
    yaml_val_3 = '{"one": 1, "two": 2, "three": 3}'
    assert safe_eval(yaml_val_3)[1] == {"one": 1, "two": 2, "three": 3}

    # Test 4:
    # Test safe eval using a variable
    yaml_val_4 = 'x'

# Generated at 2022-06-11 17:15:06.735095
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:16.667693
# Unit test for function safe_eval
def test_safe_eval():
    # test simple variable passing
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', dict(foo='bar')) == 'bar'

    assert safe_eval('foo in bar', dict(foo='bar',bar='baz')) == False
    assert safe_eval('foo in bar', dict(foo='foo',bar='foo')) == True

    assert safe_eval('foo.bar', dict(foo=dict(bar=1))) == 1
    assert safe_eval('foo.bar', dict(foo=dict(bar=1), bar=1)) == 1
    assert safe_eval('foo.bar', dict(foo=dict(bar=1)), dict(bar=1)) == 1

    assert safe_eval('foo.bar', dict(foo=dict(bar=1,ansible=1))) == 1
    assert safe

# Generated at 2022-06-11 17:15:26.692070
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval with valid expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('4 / 2') == 2
    assert safe_eval('4 // 2') == 2
    assert safe_eval('4 - 2') == 2
    assert safe_eval('4 % 2') == 0
    assert safe_eval('-4') == -4
    assert safe_eval('-5 + 2') == -3
    assert safe_eval('1 == 1') == True
    assert safe_eval('1 != 1') == False
    assert safe_eval('1 > 0') == True
    assert safe_eval('1 < 0') == False
    assert safe_eval('1 >= 1') == True
    assert safe_eval

# Generated at 2022-06-11 17:15:36.364654
# Unit test for function safe_eval
def test_safe_eval():
    # Test success
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("[1,2,3]", dict(a_list_variable="[1,2,3]")) == [1, 2, 3]
    assert safe_eval("[1,2,3]", dict(a_list_variable="[1,2,3]"), True) == ([1, 2, 3], None)

    # Test failure
    assert safe_eval("[1,2,3]", dict(a_list_variable="[1,2,3]"), True) != ([1, 2, 3], None)
    assert safe_eval("[1,2,3]", dict(a_list_variable="[1,2,3]"), True)[1] is not None

    # Test

# Generated at 2022-06-11 17:15:45.283374
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("True") is True
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("a or b", dict(a=1, b=2)) == 1
    assert safe_eval("a and b", dict(a=1, b=0)) == 0
    assert safe_eval("a and b", dict(a=1, b=2)) == 2
    assert safe_eval("a + b", dict(a=1, b=2)) == 3
    assert safe_eval("a - b", dict(a=1, b=2)) == -1
    assert safe_eval("a * b", dict(a=4, b=2)) == 8

# Generated at 2022-06-11 17:15:55.504667
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")

    # test disabled calls
    CALL_ENABLED.append('zip')
    # system call
    if sys.version_info[0] == 2:
        safe_eval('open("/tmp/foo")')
    else:
        safe_eval('open("/tmp/foo", "r")')
    # module call
    safe_eval('os.getenv("HOME")')
    # builtin call
    safe_eval('zip(range(3), range(3))')

    # test allowed calls
    CALL_ENABLED.append('os.getenv')
    # system call
    if sys.version_info[0] == 2:
        safe_eval('open("/tmp/foo")')
    else:
        safe_eval('open("/tmp/foo", "r")')
   

# Generated at 2022-06-11 17:16:06.110790
# Unit test for function safe_eval
def test_safe_eval():
    # Tests that haven't been converted to use the new include_exceptions
    # format for reporting errors (to be removed at some point):

    # These are safe to parse, but not safe to execute
    assert safe_eval("__import__('os').system('rm -rf /')") == '__import__(\'os\').system(\'rm -rf /\')'

    # These are safe to eval
    assert safe_eval("1234") == 1234
    assert safe_eval("3.5") == 3.5
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("a_var") == 'a_var'
    assert safe_eval("'hello'") == 'hello'

# Generated at 2022-06-11 17:16:15.467024
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This tests the following basic conditions for safe_eval:
    * Ensuring that it correctly parses valid literals and evaluate them
    * Ensuring that it correctly fails on invalid literals
    * Ensuring that it correctly fails on literals containing restricted
    functions and operators
    '''
    # Valid literals
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('-1') == -1
    assert safe_eval('-1 + 1') == 0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-11 17:16:23.762128
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for bug: https://github.com/ansible/ansible/issues/11210
    assert "invalid expression" in safe_eval("'foo' + 'bar'")

# Generated at 2022-06-11 17:16:35.558453
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:45.534484
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"foo"', {}) == "foo"
    assert safe_eval('foo', {}) == "foo"
    assert safe_eval('foo', {'foo': "bar"}) == "bar"
    assert safe_eval('foo.split(" ")', {'foo': "bar"}) == ['bar']

    assert safe_eval('true', {}) == True
    assert safe_eval('false', {}) == False
    assert safe_eval('null', {}) == None
    assert safe_eval('[]', {}) == []
    assert safe_eval('{}', {}) == {}
    assert safe_eval('2 + 3', {}) == 5
    assert safe_eval('2 - 3', {}) == -1
    assert safe_eval('2 * 3', {}) == 6

# Generated at 2022-06-11 17:16:52.379953
# Unit test for function safe_eval
def test_safe_eval():
    # these all should success
    safe_eval("foo")
    safe_eval("foo.bar")
    safe_eval("foo[0]")
    safe_eval("foo[0].bar")
    safe_eval("foo[2][1]")
    safe_eval("foo[2][1].bar")
    safe_eval("foo[2][1].bar.baz")
    safe_eval("foo is bar")
    safe_eval("foo is not bar")
    safe_eval("foo in bar")
    safe_eval("foo not in bar")
    safe_eval("foo == bar")
    safe_eval("foo != bar")
    safe_eval("foo + bar")
    safe_eval("foo - bar")
    safe_eval("foo * bar")
    safe_eval("foo / bar")

# Generated at 2022-06-11 17:17:01.141703
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:11.664146
# Unit test for function safe_eval
def test_safe_eval():
    '''
    >>> test_safe_eval()
    '''
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ lookup('foo') }}") == "{{ lookup('foo') }}"
    assert safe_eval("{{ lookup('foo', convert=int) }}") == "{{ lookup('foo', convert=int) }}"
    assert safe_eval("{{ something('foo') }}") == "{{ something('foo') }}"
    assert safe_eval("{{ some_func(a) }}") == "{{ some_func(a) }}"
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval

# Generated at 2022-06-11 17:17:20.804747
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:29.295149
# Unit test for function safe_eval
def test_safe_eval():
    # Inline function calls should always fail when using safe_eval
    assert safe_eval(
        '"{0} world".format("hello")') == '"{0} world".format("hello")'

    # Test boolean types
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None

    # Test unary operator
    assert safe_eval('-2') == -2

    # Test binary operators
    assert safe_eval('2 / 3') == 2 / 3
    assert safe_eval('2 * 3') == 6
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 - 3') == -1
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('2 == 3') == 2 == 3

# Generated at 2022-06-11 17:17:31.308964
# Unit test for function safe_eval
def test_safe_eval():
    """
    safe_eval should not allow arbitrary code execution

    >>> safe_eval('__import__("os").system("ls")')
    '__import__("os").system("ls")'
    """
    pass

# Generated at 2022-06-11 17:17:41.248623
# Unit test for function safe_eval
def test_safe_eval():
    # global result
    result = None
    # test safe_eval with a safe expression
    result = safe_eval("1 + 1")
    assert result == 2

    # test safe_eval with a dangerous expression, should still be safe and return the expression
    result = safe_eval("__import__('os').system('touch /tmp/testing123')")
    assert result == "__import__('os').system('touch /tmp/testing123')"

    # test safe_eval with a dangerous expression, should still be safe and return the expression
    result = safe_eval("__import__('os').system('touch /tmp/testing123')")
    assert result == "__import__('os').system('touch /tmp/testing123')"



# Generated at 2022-06-11 17:17:48.178765
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:58.641701
# Unit test for function safe_eval
def test_safe_eval():
    assert isinstance(safe_eval("['foo', 'bar', 'baz']"), list)
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']

    assert isinstance(safe_eval("{'foo': 1, 'bar': 2, 'baz': 3}"), dict)
    assert safe_eval("{'foo': 1, 'bar': 2, 'baz': 3}") == {'foo': 1, 'bar': 2, 'baz': 3}

    assert isinstance(safe_eval("[{'foo': 1}, {'bar': 2}, {'baz': 3}]"), list)

# Generated at 2022-06-11 17:18:06.705168
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info >= (3, 0):
        print('Testing function safe_eval...')

        # Test safe_eval with a valid expression
        valid_expr = "1 + 1"
        result, exception = safe_eval(valid_expr, include_exceptions=True)
        assert result == 2
        assert exception is None

        # Test safe_eval with a valid expression with a variable
        valid_expr = "1 + a_var"
        result, exception = safe_eval(valid_expr, dict(a_var=1), include_exceptions=True)
        assert result == 2
        assert exception is None

        # Test safe_eval with an invalid expression
        invalid_expr = "for x in range(10): print x"
        result, exception = safe_eval(invalid_expr, include_exceptions=True)
       

# Generated at 2022-06-11 17:18:16.209590
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("false or true") is True
    assert safe_eval("null or false") is False
    assert safe_eval("'a' + 'b'") == 'ab'
    assert safe_eval("'%s' % 'ansible'") == 'ansible'
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']

# Generated at 2022-06-11 17:18:26.169015
# Unit test for function safe_eval
def test_safe_eval():
    def _t(input_str, output, do_raise=False):
        rc, err = safe_eval(input_str, include_exceptions=True)
        assert rc == output
        if do_raise:
            assert err is not None
        else:
            assert err is None

    # Ensure these test cases produce exceptions
    _t("import os", None, True)
    _t("open('/etc/passwd')", None, True)
    _t("open()", None, True)
    _t("__import__('os').system('/bin/echo foo')", None, True)
    _t("len([1, 2, 3])", None, True)
    _t("abs(2-4)", None, True)
    _t("abs(out=4)", None, True)

# Generated at 2022-06-11 17:18:35.689911
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six import PY3
    # This is only designed to test the potential failures
    # The cases that are expected to succeed are covered by other tests


# Generated at 2022-06-11 17:18:41.891821
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text

    # the following tests come from the example code in the docstring for
    # the safe_eval function

    # this is the list of AST nodes we are going to allow in the evaluation.
    SAFE_NODES = set((ast.Add, ast.BinOp, ast.Compare, ast.Constant, ast.Dict, ast.Div, ast.Expression, ast.List, ast.Load, ast.Mult, ast.Name, ast.Num, ast.Set, ast.Str, ast.Sub, ast.USub, ast.Tuple, ast.UnaryOp))


# Generated at 2022-06-11 17:18:50.506185
# Unit test for function safe_eval
def test_safe_eval():
    # Handle Invalid Expressions
    expr = '3 + ('
    result = safe_eval(expr)
    if result != expr:
        print("Error evaluating '%s' : %s" % (expr, result))
    expr = 'echo("hello")'
    result = safe_eval(expr)
    if result != expr:
        print("Error evaluating '%s' : %s" % (expr, result))

    # Handle Safe Expressions
    expr = 'True'
    result = safe_eval(expr)
    if result != True:
        print("Error evaluating '%s' : %s" % (expr, result))
    expr = 'False'
    result = safe_eval(expr)
    if result != False:
        print("Error evaluating '%s' : %s" % (expr, result))

# Generated at 2022-06-11 17:19:00.308350
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:09.946209
# Unit test for function safe_eval
def test_safe_eval():
    # http://json.org/example
    test_expr = '''
{
    "image": {
        "width":  800,
        "height": 600,
        "title":  "View from 15th Floor",
        "thumbnail": {
            "url":    "http://www.example.com/image/481989943",
            "height": 125,
            "width":  100
        },
        "ids": [116, 943, 234, 38793]
    }
}
'''
    res = safe_eval(test_expr, include_exceptions=True)
    assert res[0]['image']['ids'] == [116, 943, 234, 38793]
    assert res[1] is None

    # This is allowed by the python eval() function but we do
    # not want to allow

# Generated at 2022-06-11 17:19:18.651707
# Unit test for function safe_eval
def test_safe_eval():
    '''Unit test of function safe_eval.'''

    # These are safe and should evaluate properly

    # Simple integer
    test_val = '5'
    result, err = safe_eval(test_val, include_exceptions=True)
    assert result == 5, 'Invalid evaluation of %s: expected %s, got %s' % (test_val, 5, result)
    assert err is None, 'Invalid evaluation of "%s": %s' % (test_val, err)

    # Simple string
    test_val = "'A string'"
    result, err = safe_eval(test_val, include_exceptions=True)
    assert result == 'A string', 'Invalid evaluation of %s: expected %s, got %s' % (test_val, 5, result)

# Generated at 2022-06-11 17:19:30.719236
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text

    # Test all objects that should pass safe_eval

# Generated at 2022-06-11 17:19:40.552154
# Unit test for function safe_eval
def test_safe_eval():
    # Success tests
    test_exprs = [
        "a",
        "'a'",
        "5",
        "1+1",
        "1+1+'a'",
        "[1,2,3]",
        "(1,2,3)",
        {"a": "b"},
    ]
    for expr in test_exprs:
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result is not None, "Result of evaluation is none for %s" % expr
        assert exception is None, "Exception occurred for %s" % expr
        print("expression (%s) evaluated to %s" % (expr, result))

    # Failure tests

# Generated at 2022-06-11 17:19:48.516663
# Unit test for function safe_eval
def test_safe_eval():
    # Basic safe evaluations
    assert 1 == safe_eval('1')
    assert True == safe_eval('True')
    assert False == safe_eval('False')
    assert None == safe_eval('None')
    assert 10 == safe_eval('10')
    assert (1,True,False,None,10) == safe_eval('(1,True,False,None,10)')

    # Basic unsafe evaluations
    assert None == safe_eval('open')
    assert None == safe_eval('__import__')
    assert None == safe_eval('eval')
    assert None == safe_eval('dir')
    assert None == safe_eval('foo')
    assert None == safe_eval('')

    # Safe evaluations with invalid arguments
    assert None == safe_eval('open(1,2)')

# Generated at 2022-06-11 17:19:58.682298
# Unit test for function safe_eval
def test_safe_eval():
    '''
    There is a unit test, implemented as a function instead of the usual
    class-based approach, because the test needs to be imported by the
    cli/adhoc.py and cli/playbook.py modules, which use the CLI options
    to determine when to skip tests, and the class-based tests can't be
    loaded without running the tests.
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.listify import listify_lookup_plugin_terms

    sys.modules['ansible'] = ImmutableDict(
        _ = to_bytes,
        to_native = to_bytes
    )


# Generated at 2022-06-11 17:20:06.046782
# Unit test for function safe_eval
def test_safe_eval():
    # variables for testing
    a = 1
    b = 2
    c = 'c'
    d = True

    import unittest

# Generated at 2022-06-11 17:20:15.803495
# Unit test for function safe_eval
def test_safe_eval():
    # test that literal values evaluate as expected
    assert safe_eval("1") == 1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("u'foo'") == "foo"
    assert safe_eval("u'\u20ac'") == "€"
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{'a':1,'b':2}") == {'a':1,'b':2}
    assert safe_eval("1 == 1") == True
    assert safe_eval("1 != 1") == False
    assert safe_eval("1 in [1,2,3]") == True
    assert safe_eval("0 in [1,2,3]")

# Generated at 2022-06-11 17:20:22.893355
# Unit test for function safe_eval
def test_safe_eval():
    # If a string evaluates to a non-string type, then turn it into a string
    assert isinstance(safe_eval('5'), int)
    assert isinstance(safe_eval('5'), string_types)

    # If a string evaluates to a string, then leave it alone
    assert isinstance(safe_eval('"5"'), string_types)

    # Test exception handling
    (result, exception) = safe_eval('a + b', {'a': 5, 'b': 4}, include_exceptions=True)
    assert result == 'a + b'
    assert exception is not None

    # Test nested lists are handled
    (result, exception) = safe_eval('[[1], [2]]', include_exceptions=True)
    assert result == [[1], [2]]
    assert exception is None

    # Test nested dictionaries
   

# Generated at 2022-06-11 17:20:29.601891
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:38.713395
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Ensure that expressions that we expect to be safe are evaluated and
    expressions that we expect to be dangerous are not.
    '''
    # list of tuples, where each tuple is (expr, result)
    # each expr will be evaluated and should return the result

# Generated at 2022-06-11 17:20:44.060375
# Unit test for function safe_eval
def test_safe_eval():

    # Test no eval needed
    test_str = 'test string'
    result = safe_eval(test_str)
    assert result == 'test string'

    # Test eval needed
    test_str = '{{ test_string }}'
    result = safe_eval(test_str)
    assert result == 'eval needed'

    # Test jinja2 string
    test_str = '{% if True %}test string{% endif %}'
    result = safe_eval(test_str)
    assert result == 'test string'

# Generated at 2022-06-11 17:20:59.134472
# Unit test for function safe_eval
def test_safe_eval():

    #Helper function to run the test for a given tuple
    def test_eval_tuple(input, output, include_exceptions=False):

        res = safe_eval(input, include_exceptions=include_exceptions)
        assert (res == output or ((include_exceptions and res[0] == output) or ((include_exceptions and res[1].__str__() == output))))

    #Test failing limits with single number
    test_eval_tuple('1 + 1', "2")
    test_eval_tuple('1 - 1', "0")
    test_eval_tuple('1 * 2', "2")
    test_eval_tuple('2 / 2', "1")
    test_eval_tuple('1', "1")
    test_eval_tuple('-1', "-1")
    test_eval

# Generated at 2022-06-11 17:21:06.047911
# Unit test for function safe_eval
def test_safe_eval():
    # check if syntax error
    result, err = safe_eval("{{ bad_syntax }}", include_exceptions=True)
    assert result == "{{ bad_syntax }}"
    assert err is None

    # check if name exception
    result, err = safe_eval("{{ open('/tmp/xxx') }}", include_exceptions=True)
    assert result == "{{ open('/tmp/xxx') }}"
    assert isinstance(err, Exception) and to_native(err).find("invalid function") != -1

    # check for a_list_variable
    result, err = safe_eval("{{ a_list_variable }}", include_exceptions=True)
    assert result == "{{ a_list_variable }}"
    assert err is None

    # check for bad tuple

# Generated at 2022-06-11 17:21:14.886398
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:24.529731
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:32.659303
# Unit test for function safe_eval
def test_safe_eval():

    assert "foo" == safe_eval("foo")
    assert 1 == safe_eval("1")
    assert 1 == safe_eval("'1'")
    assert "1" == safe_eval('"1"')
    assert 1 == safe_eval("1 + 0")
    assert 2 == safe_eval("1 + 1")
    assert 1 == safe_eval("2 - 1")
    assert 2 == safe_eval("2 * 1")
    assert 2 == safe_eval("2 / 1")
    assert 2 == safe_eval("2 // 1")
    assert 3 == safe_eval("2 ** 3")
    assert 1 == safe_eval("2 + -1")
    assert 2 == safe_eval("2 * 1 * 1")
    assert 1 == safe_eval("2 * 1 / 2")

# Generated at 2022-06-11 17:21:42.142707
# Unit test for function safe_eval
def test_safe_eval():
    # Note: these tests are brittle because new builtin functions are added
    # over time.  So if one of these tests fails then we need to revisit it
    # and determine if a new entry needs to be added to CALL_ENABLED, if the
    # test is no longer valid, or if the builtin function should be added to
    # the blacklist.
    assert safe_eval("[1,2,3,4]") == [1, 2, 3, 4]
    assert safe_eval("[1,2,3,4]", include_exceptions=True) == ([1, 2, 3, 4], None)
    assert safe_eval("{1:2,3:4}") == {1: 2, 3: 4}


# Generated at 2022-06-11 17:21:50.975133
# Unit test for function safe_eval

# Generated at 2022-06-11 17:21:57.454947
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('my_list', {'my_list': [1, 2]}) == [1,2]
    assert safe_eval('my_string', {'my_string': 'test'}) == 'test'
    assert safe_eval('5') == 5
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval(None) is None
    assert safe_eval('True or False') == True
    assert safe_eval('4-4*4') == -12
    assert safe_eval('len([1, 2])') == 2
    assert safe_eval('str(["test", "test"])') == "['test', 'test']"
    assert safe_eval('not None') == True

# Generated at 2022-06-11 17:22:05.911832
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 3') == 4
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1,"b":2,"c":3}') == {'a':1,'b':2,'c':3}
    assert safe_eval('1,2,3') == (1,2,3)
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('None') is None

    # without setting globals/locals, we should
    # not be able to access variables or functions
    try:
        safe_eval('hostvars')
        assert False
    except Exception:
        assert True

# Generated at 2022-06-11 17:22:16.420056
# Unit test for function safe_eval
def test_safe_eval():
    # No string with Call
    safe_eval('[]')
    # String with Call
    safe_eval('i.split()')
    # Will raise exception
    safe_eval('len(i)')
    # Having '#' in string and eval'ing it.
    var = '''{
      "a": {
        "b": {
          "c": "d#e"
        }
      }
    }'''
    safe_eval(var)
    # Will raise exception
    var = '''{
      "a": {
        "b": {
          "c": "d len(i) e"
        }
      }
    }'''
    safe_eval(var)
    # Python2 dictionary iteration is random,
    # Hence the order of items will be random in the output

# Generated at 2022-06-11 17:22:35.362384
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a + b') == 'a + b'
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2', locals={'b': 1}) == 3
    assert safe_eval('1 + 2', locals={'a': 1}) == '1 + 2'
    # ast.Call no longer needs to be whitelisted, since parsing of calls is now done in
    # CleansingNodeVisitor.
    assert safe_eval('len("abc")') == 3
    assert safe_eval('True') is True
    assert safe_eval('True and False or False') is False
    assert safe_eval('True or False and False') is True
    assert safe_eval('1 == 2 - 1 and 2 == 2') is True
    assert safe_eval('10 / 2') == 5
    assert safe_eval

# Generated at 2022-06-11 17:22:40.984405
# Unit test for function safe_eval
def test_safe_eval():
    # simple tests
    assert safe_eval("2 + 3") == 5
    assert safe_eval("2 + 3", include_exceptions=True)[0] == 5
    assert safe_eval("None") is None
    assert safe_eval("[1,2,3,4]") == [1, 2, 3, 4]
    assert safe_eval("{ 'a' : 1, 'b' : 2 }") == {'a': 1, 'b': 2}
    assert safe_eval("(1,2,3,4)") == (1, 2, 3, 4)
    assert safe_eval("True") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    # add one function to whitelist
    CALL_ENABLED.append('bool')

# Generated at 2022-06-11 17:22:51.057964
# Unit test for function safe_eval
def test_safe_eval():
    '''
    ansible.utils.unsafe_proxy.safe_eval: Assert safe (and unsafe) python eval
    '''
    # vars
    data = frozenset(('alpha', 'beta', 'gamma'))
    expr1 = 'data & {0}'.format(data)
    expr2 = 'data & {0}'.format(container_to_text(data))
    expr3 = 'python_statement'
    expr4 = 'python_function()'

# Generated at 2022-06-11 17:23:00.093345
# Unit test for function safe_eval

# Generated at 2022-06-11 17:23:11.275000
# Unit test for function safe_eval
def test_safe_eval():
    """Test eval of various expression (good and bad)"""

    def test_good_expr(expr, expected):
        """Test a good expression evaluation"""
        result, err = safe_eval(expr, include_exceptions=True)
        assert result == expected, "Expected %s, got %s" % (expected, result)
        assert err is None, "Expected None, got %s" % err

    def test_bad_expr(expr):
        """Test a bad expression evaluation"""
        result, err = safe_eval(expr, include_exceptions=True)
        assert result == expr, "Expected %s, got %s" % (expr, result)
        assert err is not None, "Expected None, got %s" % err


# Generated at 2022-06-11 17:23:18.417846
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic tests for safe_eval.
    '''
    def assert_valid(expr):
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result is not expr
        assert exception is None

    def assert_invalid(expr):
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result is expr
        assert type(exception) == Exception

    assert_valid('1')
    assert_valid('1 + 2')
    assert_valid('1 + 2 * 3')
    assert_valid('1 + (2 * 3)')
    assert_valid('(1 + 2) * 3')
    assert_valid('1 + [1]')
    assert_valid('1 + (1,)')
    assert_valid('1 + (1, 2)')


# Generated at 2022-06-11 17:23:28.971831
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo.bar") == "foo.bar"

    assert safe_eval("a_str_var") == "a_str_var"

    assert safe_eval("a_str_var.split()") == "a_str_var.split()"

    assert safe_eval("a_dict_var.keys()") == "a_dict_var.keys()"

    assert safe_eval("a_list_var") == "a_list_var"

    assert safe_eval("a_list_var[0]") == "a_list_var[0]"

    assert safe_eval("dict(a_list_var)") == "dict(a_list_var)"

    assert safe_eval("-1") == -1