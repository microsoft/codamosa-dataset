

# Generated at 2022-06-11 17:13:37.906808
# Unit test for function safe_eval
def test_safe_eval():
    ''' test safe_eval() '''
    # ensure that bad syntax throws an exception
    try:
        safe_eval('{{ foo( ')
        raise AssertionError('Expected exception for "{{ foo( "')
    except Exception:
        pass

    # ensure that invalid function calls throw an exception
    try:
        safe_eval('{{ open(1).read() }}')
        raise AssertionError('Expected exception for "{{ open(1).read() }}"')
    except Exception:
        pass

    # ensure that invalid function calls which are valid in Python 3 don't throw an exception

# Generated at 2022-06-11 17:13:45.483761
# Unit test for function safe_eval
def test_safe_eval():
    # the following code snippets are taken from the documentation
    # of the ast module (https://docs.python.org/3/library/ast.html)
    # we parse these using ast.parse() and then try to compile and eval them
    # with safe_eval() to see if it works as expected

    # 1. Literals
    ast_literal = ast.parse("[1, 2, (3, 4), {'foo': 'bar'}]")
    safe_eval(ast_literal)

    # 2. Name
    ast_name = ast.parse("max(1, 2, 3)")
    safe_eval(ast_name)

    # 3. IfExp
    ast_if_exp = ast.parse("'first' if True else 'last'")
    safe_eval(ast_if_exp)

    # 4.

# Generated at 2022-06-11 17:13:55.941773
# Unit test for function safe_eval
def test_safe_eval():

    # Some basic tests for safe_eval
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1.0') == 1.0
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"1": 2, "3": 4}') == {"1": 2, "3": 4}
    assert safe_eval('12345') == 12345
    assert safe_eval('"hello"') == "hello"
    assert safe_eval('1.0 + 1.0') == 2.0
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('-10') == -10

# Generated at 2022-06-11 17:14:05.741899
# Unit test for function safe_eval
def test_safe_eval():
    """Test basic safe_eval functionality"""
    safe_eval('[1,2]')
    safe_eval('{"foo": "bar"}')
    safe_eval('1+1')
    safe_eval('6*7')

    # test exception handling
    safe_eval('1+')
    safe_eval('foo')
    safe_eval('__import__("os").system("touch /tmp/evil")')
    safe_eval('True or __import__("os").system("touch /tmp/evil")')


if __name__ == '__main__':
    # unit test this function if invoked directly
    # run as python lib/ansible/utils/unsafe_proxy.py
    test_safe_eval()

# Generated at 2022-06-11 17:14:14.394931
# Unit test for function safe_eval

# Generated at 2022-06-11 17:14:22.841568
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo.bar(baz).bing") == "foo.bar(baz).bing"
    assert safe_eval("3 + 5") == 8
    assert safe_eval("7 * 9") == 63
    assert safe_eval("2**8") == 256
    assert safe_eval("len('hello world')") == 11
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("{'a':'b', 'c':'d'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("a in b", {"a": 5, "b": [1,2,3,4,5]})

# Generated at 2022-06-11 17:14:34.073084
# Unit test for function safe_eval
def test_safe_eval():
    import doctest
    doctest.testmod()
    try:
        from ansible.module_utils.basic import AnsibleModule
        m = AnsibleModule(argument_spec=dict())
        assert m is not None
    except ImportError:
        # if we're not running via ansible-test/tox, we can just skip this test
        pass
    else:
        # run the tests using AnsibleModule.exit_json()
        m = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 17:14:46.152721
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe eval
    # it should return the same as orig
    orig = {'test': [1, 2, 3], 'test2': {'foo': 'bar'}}
    expr = container_to_text(orig)
    assert safe_eval(expr) == orig, '"%s" -> "%s" != "%s"' % (expr, safe_eval(expr), orig)

    # simple add
    expr = '1 + 1'
    assert safe_eval(expr) == 2, '"%s" -> "%s" != "%s"' % (expr, safe_eval(expr), 2)

    # simple add
    expr = '1 + 2 - 3'
    assert safe_eval(expr) == 0, '"%s" -> "%s" != "%s"' % (expr, safe_eval(expr), 0)

    # simple

# Generated at 2022-06-11 17:14:52.915841
# Unit test for function safe_eval
def test_safe_eval():

    # Tests for when CALL_ENABLED is [] (i.e. nothing enabled)
    assert safe_eval('1 + 2') == 3
    assert safe_eval('10 - 5') == 5
    assert safe_eval('1.3 + 2.3') == 3.6
    assert safe_eval('10.6 - 5.6') == 5.0
    assert safe_eval('True and False') is False
    assert safe_eval('False or True') is True
    assert safe_eval('True and True') is True
    assert safe_eval('True or False') is True
    assert safe_eval('False or False') is False
    assert safe_eval('False and False') is False

    # Strings (unsupported by eval)
    assert safe_eval('"foo"') == '"foo"'

# Generated at 2022-06-11 17:15:04.330501
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:17.026360
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:27.068769
# Unit test for function safe_eval
def test_safe_eval():
    # A simple expression, this should evaluate successfully
    simple_expr = "{{ ((1 + 2) * 3) }}"
    simple_expected = 9
    simple_result = safe_eval(simple_expr)
    assert simple_result == simple_expected

    # Here we call a function in the expression.  We only allow a whitelist
    # of functions to be evaluated successfully.  All others will fail.
    # builtin_expr = "[1,2,3].index(2) == 1"
    builtin_expr = "[1,2,3].index('2') == 1"
    builtin_expected = True
    builtin_result = safe_eval(builtin_expr)
    assert builtin_result == builtin_expected

    # Now try the same thing, but with a function not in our whitelist.
    # This will raise an

# Generated at 2022-06-11 17:15:36.707187
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:45.494881
# Unit test for function safe_eval
def test_safe_eval():
    # Setup test environment
    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['a_var'] = 'foobar'
            self.params['a_list_var'] = [1, 2, 3]

    fm = FakeModule()

# Generated at 2022-06-11 17:15:55.616352
# Unit test for function safe_eval
def test_safe_eval():

    # These are safe
    assert safe_eval("1 + 1") == (2,)
    assert safe_eval("2 * 3") == (6,)
    assert safe_eval("5 - 2") == (3,)
    assert safe_eval("6 / 2") == (3,)
    assert safe_eval("value1", dict(value1=True)) == (True,)
    assert safe_eval("value2", dict(value2=False)) == (False,)
    assert safe_eval("value3", dict(value3=None)) == (None,)
    assert safe_eval("value4", dict(value4=1234)) == (1234,)
    assert safe_eval("value4", dict(value4="hello")) == ("hello",)
    assert safe_eval("value4", dict(value4="1234")) == ("1234",)
   

# Generated at 2022-06-11 17:16:06.435068
# Unit test for function safe_eval
def test_safe_eval():

    # We need to override builtins here so that our test target
    # function (ie. safe_eval) really is using the builtins we're
    # passing it
    class CustomBuiltinsGetter(dict):
        def __getitem__(self, item):
            return eval(item)

    class TestBuiltins:
        # We can add items to this in the tests below...
        __getitem__ = CustomBuiltinsGetter()

    backup_builtins = builtins.__dict__.copy()
    backup_ansible_constants = C.__dict__.copy()

    def cleanup():
        builtins.__dict__ = backup_builtins
        C.__dict__ = backup_ansible_constants

    # Replace both builtins and ansible.constants with a test target
    # so that we test the code in safe_eval

# Generated at 2022-06-11 17:16:15.640655
# Unit test for function safe_eval
def test_safe_eval():
    # for code coverage
    try:
        import astunparse
    except ImportError:
        pass

    def _test(expr_string, expected, **expr_kwargs):
        result = safe_eval(expr_string, **expr_kwargs)
        if expected != result:
            msg = "test failure: expr: %s, safe_eval(expr): %s, expected: %s" % (expr_string, result, expected)
            if hasattr(astunparse, 'unparse'):
                msg += "; ast: %s" % astunparse.unparse(ast.parse(expr_string)).rstrip()
            raise AssertionError(msg)

    _test('{}', {})
    _test('foo', 'foo')
    _test('foo.bar', 'foo.bar')

# Generated at 2022-06-11 17:16:23.877727
# Unit test for function safe_eval
def test_safe_eval():
    # test constants
    assert safe_eval('false', {}) == False
    assert safe_eval('true', {})  == True
    assert safe_eval('null', {})  == None

    # test addition
    assert safe_eval('2+2', {}) == 4

    # test subtration
    assert safe_eval('2-2', {}) == 0

    # test multiplication
    assert safe_eval('2*2', {}) == 4

    # test division
    assert safe_eval('2/2', {}) == 1

    # test lists
    assert safe_eval('[1]', {}) == [1]
    assert safe_eval('[1,2]', {}) == [1,2]

    # test tuples
    assert safe_eval('(1,)', {}) == (1,)

# Generated at 2022-06-11 17:16:34.565721
# Unit test for function safe_eval
def test_safe_eval():
    # no exception
    safe_eval('1 + 1')
    # contains invalid expression
    with pytest.raises(Exception) as e:
        safe_eval('__import__("os").system("/bin/echo pwned")')
    assert to_native(e.value) == 'invalid expression (__import__("os").system("/bin/echo pwned"))'
    # contains invalid function
    with pytest.raises(Exception) as e:
        safe_eval('open("/etc/passwd")')
    assert to_native(e.value) == 'invalid function: open'
    # contains invalid expression and invalid function
    with pytest.raises(Exception) as e:
        safe_eval('1 + os.system("/bin/echo pwned")')

# Generated at 2022-06-11 17:16:44.381404
# Unit test for function safe_eval
def test_safe_eval():
    # expression which should work
    test_string = '["a", "a", "b", "c"][1]'
    test_result = safe_eval(test_string)
    assert test_result == "a", "safe_eval failed to evaluate a valid expression"

    # expression for looping
    test_string = '{"a": "b", "b": "c"}'
    test_result = safe_eval(test_string)
    assert test_result == {"a": "b", "b": "c"}, "safe_eval failed to evaluate a valid expression"

    # invalid expression
    test_string = 'import os'
    test_result = safe_eval(test_string)
    assert test_result == test_string, "safe_eval did not return the original string back"

    # invalid expression

# Generated at 2022-06-11 17:16:57.346095
# Unit test for function safe_eval
def test_safe_eval():

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping

    # safe_eval should not return AnsibleUnicode in all cases
    assert(safe_eval(AnsibleUnicode("abcdef", 'utf-8')) == "abcdef")

    # safe_eval should not return AnsibleMapping in all cases
    assert(isinstance(safe_eval(AnsibleMapping({"a": "b"})), MutableMapping))

    # safe_eval should not return AnsibleSequence in all cases
    assert(isinstance(safe_eval("{{ a }}"), MutableSequence))

    # safe_eval should not return AnsibleUnicode in all

# Generated at 2022-06-11 17:17:08.394011
# Unit test for function safe_eval
def test_safe_eval():

    def test(expr, good):
        res, e = safe_eval(expr, include_exceptions=True)
        if good:
            if e:
                print("GOOD: expr %s failed with exception %s" % (expr, e))
            else:
                print("GOOD: expr %s succeeded, result %s" % (expr, res))
        else:
            if e:
                print("GOOD: expr %s failed with exception %s" % (expr, e))
            else:
                print("BAD: expr %s succeeded, result %s" % (expr, res))

    test('-1', True)
    test('-2 - 1', True)
    test('[1,2,3]', True)
    test('{1:2,3:4,5:6}', True)
    test

# Generated at 2022-06-11 17:17:17.169294
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("0") == 0
    assert safe_eval("[ 1, 'foo', false ]") == [1, 'foo', False]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("-1") == -1
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1", include_exceptions=True) == (2, None)
    assert safe_eval("1+1", locals={'foo': 'bar'}) == 2

# Generated at 2022-06-11 17:17:26.628434
# Unit test for function safe_eval
def test_safe_eval():
    # These strings should return the value None
    strings = [
        'null',
        'true and false',
        'something else',
        'True and false',
        'True and false or null',
        'true and false or null',
        'true or false and null',
        'True or false and null',
        'true or false or null',
        'True or false or null'
    ]
    for s in strings:
        assert safe_eval(s) == None, "Expected None for %s" % s

    # These strings should return the value True or False

# Generated at 2022-06-11 17:17:33.380158
# Unit test for function safe_eval
def test_safe_eval():
    # Some of the tests are commented out because they are hit by the
    # "type" not in SAFE_NODES tests
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('-1') == -1
    assert safe_eval('-1.0') == -1.0
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1.0 + 1') == 2.0
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('1.0 + 1.0') == 2.0
    assert safe_eval('2 - 1') == 1
    assert safe_eval('2.0 - 1') == 1.0
   

# Generated at 2022-06-11 17:17:43.209838
# Unit test for function safe_eval
def test_safe_eval():
    C.DEFAULT_DEBUG = 1
    # Sample code provided by user.
    # We want to make sure we do not allow function calls.
    # We also want to allow various combinations of
    # quotes and brackets in list/dict structure definitions.

# Generated at 2022-06-11 17:17:49.466034
# Unit test for function safe_eval
def test_safe_eval():
    # tests for a list
    test_string_good = """
    [ 1,
      { 'asd': [] },
      3
    ]
    """
    test_exp = safe_eval(test_string_good)
    assert isinstance(test_exp, list), test_exp

    # tests for a list comprehension
    test_string_good = """
   [ x for x in range(10) ]
    """
    test_exp = safe_eval(test_string_good)
    assert isinstance(test_exp, list), test_exp

    # tests for a function call
    if sys.version_info >= (3, 0):
        # Python 3 has no apply anymore
        test_string_bad = """
        apply()
        """

# Generated at 2022-06-11 17:17:58.263709
# Unit test for function safe_eval
def test_safe_eval():
    '''
    run with: python -m ansible.utils.unsafe_proxy test_safe_eval
    '''
    import doctest

    def testing_function(arg):
        print("you called testing_function() with: %s" % arg)

    class SkippedObject(object):
        def __init__(self):
            pass

    def whitelist_function(arg):
        print("you called a whitelisted function with: %s" % arg)


# Generated at 2022-06-11 17:18:04.452097
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('x') == 'x'
    assert safe_eval('foo') == 'foo'

    assert safe_eval('bar', dict(bar="bar")) == 'bar'
    assert safe_eval('foo + 1', dict(foo=1)) == 2

    assert safe_eval('x', dict(x=5)) == 5
    assert safe_eval('x and y', dict(x=5, y=True))

    assert safe_eval('x[0]', dict(x=[5])) == 5
    assert safe_eval('x[1]', dict(x=[5])) == None

    assert safe_eval('x[0]', dict(x=(5,))) == 5
    assert safe_eval('x[1]', dict(x=(5,))) == None


# Generated at 2022-06-11 17:18:14.881097
# Unit test for function safe_eval
def test_safe_eval():
    # these are ok
    safe_eval("{'foo': 'bar'}")
    safe_eval("{a: b, c: d}")
    safe_eval("{'foo': 'bar', 'baz': 'faz'}")
    safe_eval("{'foo': 'bar', 'baz': 'faz', 'bing': 'bam'}")
    safe_eval("{'foo': 'bar', 'baz': 'faz', 'bing': 'bam', 'bong': 'ferret'}")
    safe_eval("123 + 456")
    safe_eval("123 + 456 + 54325234535")
    safe_eval("123 + 456 + 54325234535 + 23232523523")
    safe_eval("123 + 456 + 24432523523")
   

# Generated at 2022-06-11 17:18:27.539402
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:36.723873
# Unit test for function safe_eval
def test_safe_eval():
    import inspect
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-11 17:18:42.559190
# Unit test for function safe_eval
def test_safe_eval():
    # These tests are not exhaustive, but should give some confidence
    # that the code does what it says on the box.

    def assert_safe_eval(expr, locals=None, expected=None):
        if expected is None:
            expected = expr
        result, exception = safe_eval(expr, locals=locals, include_exceptions=True)
        assert result == expected
        assert exception is None

    def assert_unsafe_eval(expr, locals=None, expected=None, exception_type=Exception):
        if expected is None:
            expected = expr
        result, exception = safe_eval(expr, locals=locals, include_exceptions=True)
        assert result == expected
        assert isinstance(exception, exception_type)

    assert_safe_eval('abc')
    assert_safe_eval(u'abc')
   

# Generated at 2022-06-11 17:18:50.831875
# Unit test for function safe_eval
def test_safe_eval():
    # No exception expected
    expr_ok = "a_list_variable"
    result, exception = safe_eval(expr_ok, include_exceptions=True)
    assert result == expr_ok
    assert exception is None

    # Exception expected
    expr_ko = "a_list_variable[0]"
    result, exception = safe_eval(expr_ko, include_exceptions=True)
    assert result == expr_ko
    assert exception is not None

    # No exception expected
    expr_ok = "a_list_variable[index]"
    result, exception = safe_eval(expr_ok, include_exceptions={'index': 0}, include_exceptions=True)
    assert result == expr_ok
    assert exception is None

    # Exception expected
    expr_ko = "a_list_variable[index].test"
   

# Generated at 2022-06-11 17:19:00.697791
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1, literal dict
    expr = "{ 'a': 'b' }"
    test = safe_eval(expr)
    assert type(test) == dict
    assert len(test) == 1
    assert test['a'] == 'b'

    # Test 2, boolean
    expr = "True"
    test = safe_eval(expr)
    assert type(test) == bool
    assert test

    # Test 3, nested dict
    expr = "{ 'a': { 'b': { 'c': 'd', 'e': 'f'} } }"
    test = safe_eval(expr)
    assert type(test) == dict
    assert len(test) == 1
    assert type(test['a']) == dict
    assert len(test['a']) == 1
    assert type(test['a']['b'])

# Generated at 2022-06-11 17:19:10.376792
# Unit test for function safe_eval
def test_safe_eval():
    # Test whitelisted / safe operations
    expr = "3+3"
    result = safe_eval(expr)
    assert result == 6
    expr = "3*3"
    result = safe_eval(expr)
    assert result == 9
    expr = "3-2"
    result = safe_eval(expr)
    assert result == 1
    expr = "3/3"
    result = safe_eval(expr)
    assert result == 1
    expr = "0-3"
    result = safe_eval(expr)
    assert result == -3
    expr = "3**3"
    result = safe_eval(expr)
    assert result == 27
    expr = "'foo'.replace('o', 'e')"
    result = safe_eval(expr)
    assert result == 'fee'

# Generated at 2022-06-11 17:19:18.957183
# Unit test for function safe_eval
def test_safe_eval():
    # ast.parse is only available natively in python 2.6+
    if sys.version_info >= (2, 6):
        from ansible.module_utils import basic

        def test(expr, expect):
            basic._ANSIBLE_ARGS = None
            (result, error) = safe_eval(expr, include_exceptions=True)
            basic._ANSIBLE_ARGS = None
            assert expect == (result, error)

        # strings
        test(u"foo", (u"foo", None))

        # builtins
        test(u"abs(-1)", (1, None))
        test(u"__builtins__", (u"__builtins__", Exception(u"invalid expression (__builtins__)")))

# Generated at 2022-06-11 17:19:29.170965
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval() with string expression
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == {'a': 1}

    # Test safe_eval() with expressions that raise exceptions
    assert safe_eval('raise ValueError') == 'raise ValueError'
    assert safe_eval('''
import json
json.dumps({'a': 1})
''') == '''
import json
json.dumps({'a': 1})'''

    # Test safe_eval() with a string of a datastructure,
    # and then with a datastructure.
    assert safe_eval('[1,2,3]') == safe_eval([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 17:19:34.117839
# Unit test for function safe_eval
def test_safe_eval():
    # assert safe_eval(expr, locals=None, include_exceptions=False)
    # Test cases with valid expressions
    assert safe_eval('1 + 1')
    assert safe_eval('1 + 1', include_exceptions=True)
    assert safe_eval('[1, 2, 3]')
    assert safe_eval('[1, 2, 3]', include_exceptions=True)
    assert safe_eval('(1, 2)')
    assert safe_eval('(1, 2)', include_exceptions=True)
    assert safe_eval('{1, 2}')
    assert safe_eval('{1, 2}', include_exceptions=True)
    assert safe_eval('{1: 2}')
    assert safe_eval('{1: 2}', include_exceptions=True)
    assert safe_eval

# Generated at 2022-06-11 17:19:37.953362
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    class TestSafeEval(unittest.TestCase):
        # In this file we're mostly testing for exceptions
        # so we don't need as much test coverage here as
        # we do in some other modules.
        maxDiff = None

        def do_test(self, value, expected):
            self.assertEqual(safe_eval(value), expected)

        def test_string(self):
            self.do_test("the cow jumped over the moon", "the cow jumped over the moon")

        def test_list_string(self):
            self.do_test("[1, 2, 3]", [1, 2, 3])


# Generated at 2022-06-11 17:19:48.492557
# Unit test for function safe_eval
def test_safe_eval():
    # Just ensure exception isn't thrown
    safe_eval('True')
    safe_eval({'foo': 'bar'})
    safe_eval('foo')
    safe_eval(["foo", "bar", "baz"])
    safe_eval('{foo: "bar", baz: "baz"}')
    # Test for exception
    try:
        safe_eval('__import__("os").listdir')
    except Exception:
        pass
    else:
        assert False, "safe_eval should have thrown"
    # Test for exception
    try:
        safe_eval('True == False')
    except Exception:
        pass
    else:
        assert False, "safe_eval should have thrown"
    # Test for exception

# Generated at 2022-06-11 17:19:58.634045
# Unit test for function safe_eval
def test_safe_eval():
    for expr in (
            "1 + 1",
            "{'a': 1}",
            "[1, 2]",
            "1 == 1",
            "null",
            "false",
            "true",
            "True",
            "False",
            "None",
    ):
        result = safe_eval(expr, include_exceptions=True)
        if not result[1]:
            print("%s => %s" % (expr, result[0]))
        else:
            print("%s => <exception> %s" % (expr, to_native(result[1])))
    # Exception: invalid function
    safe_eval("len([1,2,3])", include_exceptions=True)
    # Exception: invalid expression
    safe_eval("__import__", include_exceptions=True)
   

# Generated at 2022-06-11 17:20:05.996854
# Unit test for function safe_eval
def test_safe_eval():
    strings = (
        """{{ test }}""",
        """a_variable + 5""",
        """a_variable in somelist""",
        """a_variable[1]""",
        """somelist[a_variable]""",
        """a_variable['somekey']""",
        """a_variable is None""",
        """a_variable == 1""",
        """a_variable is True""",
        """a_variable[0:5]""",
        """a_variable.split()""",
    )

# Generated at 2022-06-11 17:20:15.738589
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('None') == None
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('0') == 0
    assert safe_eval('0.0') == 0.0
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('"string"') == 'string'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[1,2,3] + [4,5,6]') == [1, 2, 3, 4, 5, 6]
    assert safe_eval('(1,2,3) + (4,5,6)') == (1, 2, 3, 4, 5, 6)
    assert safe_eval

# Generated at 2022-06-11 17:20:22.870904
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import PY3

    play_context = PlayContext()

    assert safe_eval('foo', dict(foo='bar'), True)[0] == 'bar'
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('foo', dict(foo=42.3)) == 42.3
    assert safe_eval('foo', dict(foo=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval('foo', dict(foo={'a': 'b'})) == {'a': 'b'}
    assert safe_eval('foo', dict(foo=True)) is True
    assert safe_

# Generated at 2022-06-11 17:20:29.581225
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:38.675121
# Unit test for function safe_eval
def test_safe_eval():
    """
    Examples of safe_eval that pass.
    """
    assert safe_eval("1") == 1
    assert safe_eval("'hello, world'") == 'hello, world'
    assert safe_eval("[ 1, 2 ]") == [ 1, 2 ]
    assert safe_eval("{ 1, 2 }") == { 1, 2 }
    assert safe_eval("( 1, 2 )") == ( 1, 2 )
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("{1: 2}") == { 1: 2 }
    assert safe_eval("{'a': 'b'}") == { 'a': 'b' }

    # safe_eval should also return a string if given one
    assert safe_eval

# Generated at 2022-06-11 17:20:46.206369
# Unit test for function safe_eval
def test_safe_eval():
    import os
    import tempfile

    # Helper to create a temporary file
    def create_tempfile(contents):
        fd, path = tempfile.mkstemp(prefix='ansible_test_safe_eval_')
        try:
            os.write(fd, contents)
        finally:
            os.close(fd)
        return path

    # test that builtin functions are not allowed
    # they should be filtered out by the CleansingNodeVisitor
    # set some common builtins
    builtin_list = ['int', 'str', 'float', 'unicode', 'bool']
    for b in builtin_list:
        assert sys.version_info[0] == 2 or b != 'unicode'
        t = "({0}(2))".format(b)

# Generated at 2022-06-11 17:20:57.961876
# Unit test for function safe_eval
def test_safe_eval():
    def _test(string, result, error=None):
        if not C.DEFAULT_KEEP_REMOTE_FILES:
            # we're using code from a temp file, so this must be enabled
            # to prevent file deletion failures
            C.DEFAULT_KEEP_REMOTE_FILES = True

        actual_result, actual_exception = safe_eval(string, include_exceptions=True)

        if actual_exception:
            actual_exception = to_native(actual_exception)

        assert actual_result == result, \
                'safe_eval("%s") returned "%s" but we expected "%s" (Exception: %s)' % (string, actual_result, result, actual_exception)


# Generated at 2022-06-11 17:21:06.841518
# Unit test for function safe_eval
def test_safe_eval():
    # a long test with a long list to catch long running issues.
    expr = "[x for x in range(0,{})]".format(sys.maxsize)
    assert safe_eval(expr) == ast.literal_eval(expr)

    # all expressions are valid python, but the call to range() is not allowed.
    # in this case, we simply return the expression unevaluated,
    # for possible later evaluation
    expr = "[x for x in range(0,1)]"
    assert safe_eval(expr) == expr

    # malformed expression, should raise an exception
    expr = "WTF"
    try:
        safe_eval(expr)
    except Exception:
        pass
    else:
        print("test 1 failed")
        raise AssertionError("test 1 failed")

    # dangerous expression, should raise an

# Generated at 2022-06-11 17:21:21.571761
# Unit test for function safe_eval
def test_safe_eval():
    for tt in True, False, None:
        assert(tt == safe_eval(repr(tt)))
    for tt in True, False, None:
        assert(tt == safe_eval(tt))
    assert(safe_eval('{"a": 3}') == dict(a=3))
    assert(safe_eval('[1, 2, 3]') == [1, 2, 3])
    assert(safe_eval('("a", 2, 3)') == ("a", 2, 3))
    assert(safe_eval('1 + 2') == 3)
    assert(safe_eval('foo["bar"]') == 'baz')
    assert("PTR" == safe_eval('lookup("dig", "localhost")'))


# Generated at 2022-06-11 17:21:31.052333
# Unit test for function safe_eval
def test_safe_eval():

    ######################################################################
    # Testing constants
    ######################################################################
    e1 = "42"
    v1 = ast.Expression(ast.Constant(42))
    assert(ast.dump(ast.parse(e1, mode='eval')) == ast.dump(v1))
    assert(safe_eval(e1, include_exceptions=True) == (42, None))

    # With _ansible_verbosity = 0, we expect the traceback to be suppressed.
    # Simulate verbosity setting by monkey patching constants.VERBOSITY
    original_verbosity = C.VERBOSITY
    C.VERBOSITY = 0
    e2 = "null"
    v2 = ast.Expression(ast.Name("null", ast.Load()))

# Generated at 2022-06-11 17:21:40.648107
# Unit test for function safe_eval
def test_safe_eval():
    # the expected result of applying safe_eval to each input expression
    tests = {
        'some_var + 10': 'Some text' + 10,
        '"\U0001f60a"': "😊"  # emojis in python 3
    }

    passed = True
    for expr, expected in tests.items():
        try:
            actual = safe_eval(expr, {'some_var': 'Some text'})
            if actual != expected:
                raise AssertionError("safe_eval(%r) returned %r instead of %r"
                                     % (expr, actual, expected))
        except Exception as e:
            print("safe_eval(%r) raised %s instead of %s"
                  % (expr, e.__class__.__name__, expected.__class__.__name__))
            passed

# Generated at 2022-06-11 17:21:49.154760
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1,"foo"]') == [1, 'foo']
    assert safe_eval('{"a":1,"b":"foo"}') == {'a': 1, 'b': 'foo'}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 - 2') == -1
    assert safe_eval('1 - 2', include_exceptions=True) == (-1, None)
    assert safe_eval('1 + 1 - 2') == 0
    assert safe_eval('1 * 2') == 2
    assert safe_eval('1 / 2') == 0.5
    assert safe_

# Generated at 2022-06-11 17:21:56.696607
# Unit test for function safe_eval
def test_safe_eval():
    # Test a good expression
    expr = "a_list_variable"
    res = safe_eval(expr, dict(a_list_variable=['foo', 'bar']))
    assert res == ['foo', 'bar']
    # Test a bad expression
    expr = "__import__('subprocess').call('echo HACKED')"
    res = safe_eval(expr, dict(a_list_variable=['foo', 'bar']))
    assert res == expr
    # Test a good nested expression
    expr = "a_list_variable[0]"
    res = safe_eval(expr, dict(a_list_variable=['foo', 'bar']))
    assert res == 'foo'
    # Test a bad nested expression

# Generated at 2022-06-11 17:22:05.657195
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as conv
    """
    This function is used to test if safe_eval understands the same
    expressions as Jinja2 and will return the same values.  In case
    of failure the function will print the expression that caused
    the failure and in case of a mismatch the expected and actual
    values will be printed to stdout.

    The following functions are intentionally excluded from tests:

        - regex_replace
        - regex_search
        - regex_findall
        - to_yaml
        - to_nice_yaml
        - to_json
        - random
        - template
        - version_compare
        - strftime

    The functions are excluded because they are not available in Jinja2
    or because they are too difficult to provide sane samples for
    (eg. random).
    """

# Generated at 2022-06-11 17:22:16.251123
# Unit test for function safe_eval

# Generated at 2022-06-11 17:22:26.678987
# Unit test for function safe_eval
def test_safe_eval():
    """
    Validate evaluation of known safe expressions.
    """

# Generated at 2022-06-11 17:22:37.381178
# Unit test for function safe_eval
def test_safe_eval():

    def assert_raises(expr):
        (value, exception) = safe_eval(expr, include_exceptions=True)
        assert value == expr
        assert exception is not None

    assert safe_eval(True) == True
    assert safe_eval(42) == 42
    assert safe_eval(42.0) == 42.0
    assert safe_eval("hello") == "hello"
    assert safe_eval(u"hello") == u"hello"
    assert safe_eval("hello") == "hello"
    assert safe_eval("'hello'") == "hello"
    assert safe_eval('"hello"') == "hello"
    assert safe_eval("(1,2)") == (1,2)
    assert safe_eval("[1,2]") == [1,2]

# Generated at 2022-06-11 17:22:47.337025
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("123") == 123
    assert safe_eval("-123") == -123
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1==2")
    assert not safe_eval("2+2==5")

    # Test var replacement
    var = 'ansible'
    assert safe_eval("'a' + var") == 'aansible'

    # Test builtin replacement
    assert safe_eval("len(var) == 7")
    assert safe_eval("False or True")
    assert safe_eval("False or var") == 'ansible'

    # Test literal types
    assert safe_eval("123") == 123
    assert safe_eval("[1,2,3]") == [1,2,3]

# Generated at 2022-06-11 17:23:06.391319
# Unit test for function safe_eval
def test_safe_eval():
    # test no exceptions
    res = safe_eval('1 + 1')
    if res != 2:
        raise Exception("expected 2, got %s" % res)
    res = safe_eval('[1,2,3]')
    if res != [1,2,3]:
        raise Exception("expected [1,2,3], got %s" % res)
    res = safe_eval('dict(a=1,b=2)')
    if res != dict(a=1,b=2):
        raise Exception("expected dict(a=1,b=2), got %s" % res)

    # test exceptions
    res = safe_eval('1 + "string"')
    if not isinstance(res, Exception):
        raise Exception("expected an exception, got %s" % res)

    # test functions

# Generated at 2022-06-11 17:23:15.467507
# Unit test for function safe_eval
def test_safe_eval():

    assert len(safe_eval('len(foo)==1')) == 1
    assert len(safe_eval('foo')) == 1
    assert safe_eval('foo') == 1

    # test with some bad data
    junk = "assert False"
    assert safe_eval(junk) == junk
    junk = "1 + foo()"
    assert safe_eval(junk) == junk
    junk = "__import__('sys').exit(1)"
    assert safe_eval(junk) == junk

    # unicode
    assert len(safe_eval(u'u"foo"')) == 3
    assert len(safe_eval(u"'foo'")) == 3
    assert safe_eval(u"'foo'") == 'foo'

    # test short circuit logic
    assert safe_eval('1 or bogus') == 1
    assert safe

# Generated at 2022-06-11 17:23:21.258890
# Unit test for function safe_eval
def test_safe_eval():
    def _test_safe_eval(expr, expected):
        C.DEFAULT_CALLABLE_WHITELIST = tuple()
        ret = safe_eval(expr, include_exceptions=True)
        assert ret[0] == expected, 'Eval error: %s is not %s' % (ret[0], expected)

    _test_safe_eval("", "")
    _test_safe_eval("'String'", "String")
    _test_safe_eval("true", True)
    _test_safe_eval("false", False)
    _test_safe_eval("None", None)
    _test_safe_eval("[]", [])
    _test_safe_eval("[1, 2, 3]", [1, 2, 3])

# Generated at 2022-06-11 17:23:32.589608
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This method is only used by the unit test to ensure
    the functionality provided by safe_eval works.
    Do not remove.
    '''