

# Generated at 2022-06-11 17:13:33.768030
# Unit test for function safe_eval
def test_safe_eval():
    # Test invalid expressions
    expr = 'if True: pass'
    assert safe_eval(expr) == expr

    expr = 'def foo(): pass'
    assert safe_eval(expr) == expr

    expr = 'import os'
    assert safe_eval(expr) == expr

    expr = 'len("abc")'
    assert safe_eval(expr) == expr

    expr = '["a", "b", len("abc")]'
    assert safe_eval(expr) == expr

    # Test valid expressions
    expr = '["a", "b", "c"]'
    assert safe_eval(expr) == ["a", "b", "c"]

    expr = '("a", "b", "c")'
    assert safe_eval(expr) == ("a", "b", "c")


# Generated at 2022-06-11 17:13:42.503053
# Unit test for function safe_eval
def test_safe_eval():
    # simple expressions
    assert 1 == safe_eval("1")
    assert 1 == safe_eval("1 + 0")
    assert 1 == safe_eval("2 - 1")
    assert 2 == safe_eval("2 * 1")
    assert 2 == safe_eval("4 / 2")
    assert 2 == safe_eval("2 ** 1")
    assert 1 == safe_eval("2 ** 0")
    assert 1 == safe_eval("1 + 0 == 1")
    assert 1 == safe_eval("0 + 1 == 1")
    assert 1 == safe_eval("1 == 0 + 1")
    assert 1 == safe_eval("1 == 1")
    assert 1 == safe_eval("1 == 1")
    assert 0 == safe_eval("1 == 0")
    assert 0 == safe_eval("1 != 1")

# Generated at 2022-06-11 17:13:53.841663
# Unit test for function safe_eval
def test_safe_eval():
    # test a variety of simple valid expressions
    assert safe_eval("[1,2]") == [1,2]
    assert safe_eval("[1,2]+[3,4]") == [1,2,3,4]
    assert safe_eval("1 == 2") == False
    assert safe_eval("1+2") == 3
    assert safe_eval('"foo" in "foobar"') == True
    assert safe_eval("{'a':1,'b':2}") == {'a':1,'b':2}
    assert safe_eval("{'a':1,'b':2}['a']") == 1

    # test expressions that should reject
    assert safe_eval("(1,2)") == "(1,2)"
    assert safe_eval("foo") == "foo"

# Generated at 2022-06-11 17:14:05.524661
# Unit test for function safe_eval
def test_safe_eval():
    # Simple tests
    assert safe_eval(u'[1,2,3]') == [1, 2, 3]
    assert safe_eval(u'{"a": "foo", "b": "bar"}') == {'a': "foo", 'b': "bar"}
    assert safe_eval(u'{"a": 1 + 2}') == {'a': 3}
    assert safe_eval(u'{"a": false}') == {'a': False}
    assert safe_eval(u'{"a": true}') == {'a': True}
    assert safe_eval(u'{"a": none}') == {'a': None}
    assert safe_eval(u'[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)

# Generated at 2022-06-11 17:14:14.263065
# Unit test for function safe_eval
def test_safe_eval():
    # To be converted to a proper unit test
    def test(expr, expected_result, error_expected=False):
        if error_expected:
            try:
                result = safe_eval(expr)
            except Exception as e:
                print("got exception %s, as expected" % to_native(e))
            else:
                raise Exception("Expected error, got %s instead" % result)
        else:
            try:
                result = safe_eval(expr)
            except Exception as e:
                raise Exception("Got exception %s, did not expect" % to_native(e))
            else:
                print("%s => %s" % (result, expected_result))
                if result != expected_result:
                    raise Exception("Expression evaluated to %s, not %s" % (result, expected_result))

    #

# Generated at 2022-06-11 17:14:22.756977
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple expressions like 3+5
    single_expr = "3+5"
    res = safe_eval(single_expr)
    assert res == 8

    # Test complex expressions like 3+5*2
    complex_expr = "3+5*2"
    res = safe_eval(complex_expr)
    assert res == 13

    # Test expressions with parenthesis
    expr_with_paren = "3+(5*2)"
    res = safe_eval(expr_with_paren)
    assert res == 13

    # Test expressions with dicts
    dict_expr = "{'key1': 'value1', 'key2': 'value2'}"
    res = safe_eval(dict_expr)
    assert type(res) == dict
    assert res['key1'] == 'value1'

# Generated at 2022-06-11 17:14:33.915186
# Unit test for function safe_eval
def test_safe_eval():
    # check a simple expression
    result = safe_eval("1")
    assert(result == 1)

    # check a simple boolean expression
    result = safe_eval("1==1")
    assert(result is True)

    result = safe_eval("1==2")
    assert(result is False)

    # check a simple boolean expression
    result = safe_eval("'hello' == 'world'")
    assert(result is False)

    result = safe_eval("'hello' != 'world'")
    assert(result is True)

    result = safe_eval("('hello' != 'world') and (1==1)")
    assert(result is True)

    # check a list expression
    result = safe_eval("['a', 'b', 'c']")
    assert(result == ['a', 'b', 'c'])

# Generated at 2022-06-11 17:14:46.154442
# Unit test for function safe_eval
def test_safe_eval():
    class TestSafeEval(object):

        def test_simple_variable(self):
            assert safe_eval("var1") == "var1"

        def test_string_variable(self):
            variable = "'var1'"
            assert safe_eval(variable) == "var1"

        def test_variable_simple_concat(self):
            variable = "var1 + var2"
            assert safe_eval(variable) == "var1var2"

        def test_variable_simple_concat_space(self):
            variable = "var1 + ' ' + var2"
            assert safe_eval(variable) == "var1 var2"

        def test_variable_simple_concat_list(self):
            variable = "var1 + [var2, var3]"

# Generated at 2022-06-11 17:14:52.916259
# Unit test for function safe_eval
def test_safe_eval():
    '''
    For now, just a sanity test.
    '''

    import os
    import tempfile

    tmp_target = tempfile.mkstemp()[1]


# Generated at 2022-06-11 17:15:04.330851
# Unit test for function safe_eval

# Generated at 2022-06-11 17:15:18.460438
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('"a" + "b"') == 'ab'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

    # ones that should fail (return the expression string)
    assert safe_eval('__import__("os").getcwd()') == '__import__("os").getcwd()'
    assert safe_eval('open("/etc/passwd").read()') == 'open("/etc/passwd").read()'



# Generated at 2022-06-11 17:15:28.067555
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('[]') == []
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('[x for x in range(10)]') == [x for x in range(10)]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('ansible_distribution') == 'ansible_distribution'
    assert safe_eval('1 + ansible_distribution', dict(ansible_distribution=2)) == 3
    assert safe_eval('ansible_distribution + 1', dict(ansible_distribution=2)) == 3
    assert safe_eval('1 + true', dict(ansible_distribution=2)) == 2

# Generated at 2022-06-11 17:15:37.316108
# Unit test for function safe_eval
def test_safe_eval():
    # Try to evaluate some code that should work
    assert (safe_eval("a_list_variable", {'a_list_variable': [3, 4, 5]})) == [3, 4, 5]
    assert (safe_eval("a_list_variable", {"a_list_variable" : [3, 4, 5]})) == [3, 4, 5]
    assert (safe_eval("a_list_variable", {"a_list_variable" : [3, 4, 5, 6]})) == [3, 4, 5, 6]
    assert (safe_eval("a_list_variable", {"a_list_variable" : ([3, 4, 5],)})) == ([3, 4, 5],)

# Generated at 2022-06-11 17:15:45.804255
# Unit test for function safe_eval
def test_safe_eval():

    # Tests below are from the URL above

    # Test a couple of basic types
    assert safe_eval('42') == 42
    assert safe_eval('"foo"') == 'foo'

    # Test addition and subtraction
    assert safe_eval('4 + 4') == 8
    assert safe_eval('9 - 1') == 8
    assert safe_eval('1 + 2 + 3 + 4') == 10

    # Test multiplication and division
    assert safe_eval('2 * 3') == 6
    assert safe_eval('12 / 2') == 6
    assert safe_eval('2 * 3 * 4') == 24
    assert safe_eval('12 / 2 / 3') == 2

    # Test boolean values
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('a_list_variable')

# Generated at 2022-06-11 17:15:55.745501
# Unit test for function safe_eval
def test_safe_eval():
    # Expected to pass
    test_safe_eval_assert(True, "'foo' in ['foo','bar','baz']")
    test_safe_eval_assert(True, "'fOo' in ['foo','bar','baz']")
    test_safe_eval_assert(True, "'foo' is 'foo'")
    test_safe_eval_assert(True, "'foo' is not 'bar'")
    test_safe_eval_assert(True, "'f' in 'foo'")
    test_safe_eval_assert(True, "'foo' not in 'bar'")
    test_safe_eval_assert(True, "('foo' in ['foo','bar','baz']) and ('foo' is 'foo')")

# Generated at 2022-06-11 17:16:05.152173
# Unit test for function safe_eval
def test_safe_eval():
    # simple expression
    expr = '2 + 3'
    assert safe_eval(expr) == 5

    # k8s_secret lookup
    expr = 'lookup("k8s_secret", "default/mysecret", "key1")'
    assert safe_eval(expr) == 'key1-value'

    # list with k8s_secret lookup
    expr = '[{"var1":"var1-value"}, {"var2":"{{ lookup("k8s_secret", "default/mysecret", "key2") }}"}]'
    assert safe_eval(expr) == [{u'var1': u'var1-value'}, {u'var2': u'key2-value'}]



# Generated at 2022-06-11 17:16:14.555610
# Unit test for function safe_eval

# Generated at 2022-06-11 17:16:19.768037
# Unit test for function safe_eval
def test_safe_eval():
    # Some safe examples
    assert safe_eval("1 + 1") == 2
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("foo.bar.baz()") == "foo.bar.baz()"
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("[i for i in range(1, 11)]") == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert safe_eval("False") is False
    assert safe_eval("'False'") == "False"
    assert safe_eval("True") is True
    assert safe_eval("{'a': False}")

# Generated at 2022-06-11 17:16:30.872405
# Unit test for function safe_eval
def test_safe_eval():

    # Test basic literals
    assert safe_eval('1') == 1
    assert safe_eval('2.2') == 2.2
    assert safe_eval('null') == None
    assert safe_eval('false') == False
    assert safe_eval('true') == True

    # Test basic expressions
    assert safe_eval('2+2') == 4
    assert safe_eval('2*2') == 4
    assert safe_eval('2-2') == 0
    assert safe_eval('2/2') == 1
    assert safe_eval('-(1)') == -1

    # Test basic variable names
    assert safe_eval('a', {'a': 1}) == 1

    # Test basic variable names with expressions
    assert safe_eval('a*a', {'a':2}) == 4

# Generated at 2022-06-11 17:16:37.737134
# Unit test for function safe_eval
def test_safe_eval():
    # need to add back 'json' and 'random' here so that
    # our test cases will work.
    CALL_ENABLED.append('random')
    CALL_ENABLED.append('json')

    # Test to make sure expressions are evaluated correctly

# Generated at 2022-06-11 17:16:51.476384
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2]") == [1, 2]
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("2 + 2") == 4
    assert safe_eval("7 - 1") == 6
    assert safe_eval("2 * 3") == 6
    assert safe_eval("2 ** 3") == 8
    assert safe_eval("3 * 3") == 9
    assert safe_eval("4 / 2") == 2.0
    assert safe_eval("4 % 2") == 0
    assert safe_eval("4.0 / 2") == 2.0
    assert safe_eval("4.2 / 2.1") == 2.0
    assert safe_eval("4.2 % 2.1")

# Generated at 2022-06-11 17:17:00.559826
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:11.230834
# Unit test for function safe_eval

# Generated at 2022-06-11 17:17:20.317942
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a.b.c(1).d") == "a.b.c(1).d"
    assert safe_eval("a['b']['c'](1).d") == "a['b']['c'](1).d"
    assert safe_eval("a[b][c](1).d") == "a[b][c](1).d"
    assert safe_eval("a[0]") == "a[0]"
    assert safe_eval("0") == 0
    assert safe_eval("-1") == -1
    assert safe_eval("-1.5") == -1.5
    assert safe_eval("-1.5e1") == -1.5e1
    assert safe_eval("-1.5e-1") == -1.5e-1
    assert safe

# Generated at 2022-06-11 17:17:28.850813
# Unit test for function safe_eval
def test_safe_eval():
    """
    Call safe_eval on some expressions and
    make sure the results are what we expect
    """
    # If the expression is not a string, return it as-is
    statement = "this is a statement"
    assert safe_eval(statement) == statement

    # A JSON literal
    assert safe_eval('{ "morx": "bar", "foo": "bar", "baz": null }') == { u'morx': u'bar', u'foo': u'bar', u'baz': None }

    # We cannot pass extra globals in
    try:
        assert safe_eval('pythoneval') == None
        assert False
    except Exception as e:
        assert str(e).find("invalid expression") != -1


# Generated at 2022-06-11 17:17:34.775695
# Unit test for function safe_eval
def test_safe_eval():
    res, err = safe_eval("1", include_exceptions=True)
    assert res == 1 and err is None
    res, err = safe_eval("a", {"a": 1}, include_exceptions=True)
    assert res == 1 and err is None
    res, err = safe_eval("a.keys()", {"a": {"b": 1}}, include_exceptions=True)
    assert res == ["b"] and err is None
    res, err = safe_eval("a.keys()", {"a": 1}, include_exceptions=True)
    assert res == "a.keys()" and err is None
    res, err = safe_eval("len(a)", {"a": 1}, include_exceptions=True)
    assert res == "len(a)" and err is None

# Generated at 2022-06-11 17:17:43.996189
# Unit test for function safe_eval
def test_safe_eval():

    # The following should not raise an exception
    e_list = ['True', 'False', 'None', '2', '2.0', '[]',
              '["foo", "bar"]', '{"a": "b"}', '()', '("foo", "bar")',
              '2+2', '2+2 == 4', '2+2 == 5', '2+2 in [3, 4]', '"foo" in ["foo", "bar"]',
              '"foo" not in ["foo", "bar"]', '"foo" in ("foo", "bar")',
              '-2', '-"foo"', '-2.0', '2.0', '-True', 'not True', 'not False']
    for e in e_list:
        assert safe_eval(e)

    # The following should raise an exception
    e

# Generated at 2022-06-11 17:17:54.270504
# Unit test for function safe_eval
def test_safe_eval():
    # These tests are to ensure that the function `safe_eval`
    # can evaluate various cases and will raise an exception
    # when it should.  The test cases below are mostly copied
    # from the comments in the function code, though some
    # additional cases have been added.

    safe_eval('1 + 1')
    safe_eval('[1, 2, 3, 4]')
    safe_eval('["a", "b", "c"]')
    safe_eval('{"k1": "v1", "k2": "v2", "k3": "v3"}')
    safe_eval('True')

    # TODO: Add more tests
    #       ...

    # These checks should raise an exception
    # safe_eval('foo')
    # safe_eval('__import__("os").listdir()')
    # safe_

# Generated at 2022-06-11 17:18:02.176393
# Unit test for function safe_eval

# Generated at 2022-06-11 17:18:06.973106
# Unit test for function safe_eval
def test_safe_eval():
    # an expression that should work
    try:
        assert safe_eval("foo == 'bar'")
    except Exception:
        assert False, 'foo == "bar" failed.'
    # an expression that should fail
    try:
        assert safe_eval("__import__('os').remove('/tmp/evil')")
    except Exception:
        pass
    else:
        assert False, '__import__("os").remove("/tmp/evil") worked.'


# Generated at 2022-06-11 17:18:23.783590
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('1 + 2')
    safe_eval('a + b')
    safe_eval('a + b', {'a': 1, 'b': 5})
    safe_eval('c[0]')
    safe_eval('c[0]', {'c': [1, 2]})
    try:
        safe_eval('__import__')
        assert False
    except:
        pass
    try:
        safe_eval('open')
        assert False
    except:
        pass
    try:
        safe_eval('open("/tmp/foo")')
        assert False
    except:
        pass



# Generated at 2022-06-11 17:18:29.829079
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for safe_eval function

    This function tests safe_eval() with various inputs to see
    if it returns what is expected.
    '''

    # Ensure that safe_eval returns a value when we have a
    # boolean value for expr
    assert safe_eval(True) is True
    assert safe_eval(False) is False

    # Test with various datatypes
    assert safe_eval(20) == 20
    assert safe_eval(1.0) == 1.0
    assert safe_eval(2.0/3.0) == 2.0/3.0
    assert safe_eval('foo') == 'foo'
    assert safe_eval('20') == '20'
    assert safe_eval('2.0/3.0') == '2.0/3.0'

# Generated at 2022-06-11 17:18:38.578317
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("1") == 1)
    assert(safe_eval("str(1)") == '1')
    assert(safe_eval("str(1) + 'a'") == '1a')
    assert(safe_eval("['a', 'b']") == ['a', 'b'])
    assert(safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2})
    assert(safe_eval("1 + 2") == 3)
    assert(safe_eval("1 + 2", include_exceptions=True) == (3, None))
    assert(safe_eval("1 + 2", {}, include_exceptions=True) == (3, None))

# Generated at 2022-06-11 17:18:48.240169
# Unit test for function safe_eval
def test_safe_eval():
    # ensure safe_eval raises exception when not safe
    expr = '__import__("os").system("/bin/echo hello world")'
    try:
        safe_eval(expr)
        raise Exception('fail: "%s" eval did not error as expected' % expr)
    except:
        pass

    # ensure safe_eval does not raise exception when safe
    expr = '{"key": "value"}'
    try:
        safe_eval(expr)
    except:
        raise Exception('fail: "%s" eval did not succeed as expected' % expr)

    # ensure safe_eval does not allow calling arbitrary functions
    expr = '__import__("os").system("/bin/echo hello world")'
    try:
        safe_eval(expr)
    except:
        pass

# Generated at 2022-06-11 17:18:58.192765
# Unit test for function safe_eval
def test_safe_eval():
    from ansible import errors

    assert safe_eval('2') == 2
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 * 3') == 6
    assert safe_eval('3 / 2') == 1
    assert safe_eval('2 - 3') == -1
    assert safe_eval('-3') == -3
    assert safe_eval('-(3)') == -3
    assert safe_eval('2 * 3 + 4') == 10
    assert safe_eval('2 * (3 + 4)') == 14
    assert safe_eval('(2 * 3) + 4') == 10
    assert safe_eval('-(2 * 3) + 4') == -2
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('2 ** 3 ** 2') == 512

# Generated at 2022-06-11 17:19:07.520170
# Unit test for function safe_eval

# Generated at 2022-06-11 17:19:14.323898
# Unit test for function safe_eval
def test_safe_eval():
    """
    Run tests for this function.
    """

    # No tests are run by default.  This is to avoid having to install extra
    # testing packages when not running tests.
    if not C.DEFAULT_LOAD_CALLBACK_PLUGINS:
        return

    import doctest
    try:
        results = doctest.testmod()
        if results.failed > 0:
            raise Exception('None of the %s tests should have failed in test_safe_eval' % results.attempted)
    except ImportError:
        pass


# Generated at 2022-06-11 17:19:21.086026
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic constants
    assert safe_eval("2+2") == 4
    assert safe_eval("7-5") == 2
    assert safe_eval("3*3") == 9
    assert safe_eval("103 // 5") == 20
    assert safe_eval("2**4") == 16
    assert safe_eval("2+2") == 4
    assert safe_eval("9 != 3")
    assert safe_eval("9 == 9")
    assert not safe_eval("10 > 10")
    assert safe_eval("10 >= 10")
    assert not safe_eval("10 < 10")
    assert safe_eval("10 <= 10")
    assert safe_eval("-3") == -3
    assert safe_eval("+3") == 3
    assert safe_eval("\"Hello\"") == "Hello"

# Generated at 2022-06-11 17:19:31.068733
# Unit test for function safe_eval
def test_safe_eval():
    # Test common cases
    assert(safe_eval("1 + 1") == 2)
    assert(safe_eval("'string'") == u'string')
    assert(safe_eval("True") is True)
    assert(safe_eval("False") is False)
    assert(safe_eval("None") is None)
    assert(safe_eval("true") is True)
    assert(safe_eval("false") is False)
    assert(safe_eval("null") is None)
    assert(safe_eval("[1,2,3]") == [1,2,3])
    assert(safe_eval("{'foo': 'bar'}") == {'foo': 'bar'})

    # Invalid Expression
    assert(safe_eval("eval('1+1')") == u"eval('1+1')")

    #

# Generated at 2022-06-11 17:19:40.696444
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:05.244146
# Unit test for function safe_eval

# Generated at 2022-06-11 17:20:14.896992
# Unit test for function safe_eval
def test_safe_eval():
    # define some JSON-like structures
    A1 = "{'foo': ['bar', {'baz': 'qux'}]}"
    B1 = "[1, 2, 3, 'abc', {'foo': 'bar'}]"
    C1 = "['foo', ['bar', ['baz', ['qux', 'zap']]]]"
    D1 = "{'foo': 'bar', 'baz': 'qux'}"
    E1 = "'foo'"
    F1 = "'a foo'"
    G1 = "1"
    H1 = "2 + 3"
    I1 = "2 + 3 * 4"
    J1 = "1 + (2 if bar else 3) * 4"
    K1 = "foo([1,2,3,4])"

# Generated at 2022-06-11 17:20:22.110453
# Unit test for function safe_eval
def test_safe_eval():
    correct_parse_string = []
    correct_parse_string.append("2+2")
    correct_parse_string.append("a < b and b > c")
    correct_parse_string.append("a < b > c")
    correct_parse_string.append("a < (b + c)")
    correct_parse_string.append("a < b <= c")
    correct_parse_string.append("[1, 2, 3, 4]")
    correct_parse_string.append("['a', 2, 3, 'd']")
    correct_parse_string.append("{a: 'x', b: 'y'}")
    correct_parse_string.append("{'a': 'x', 2: 'y'}")
    correct_parse_string.append("'a'")
    correct_parse_string

# Generated at 2022-06-11 17:20:28.984474
# Unit test for function safe_eval
def test_safe_eval():
    def run_eval(input, should_succeed=True):
        result, error = safe_eval(input, include_exceptions=True)
        if error:
            # The test failed, which indicates this is a
            # test of an expression we want to reject
            if should_succeed:
                print("FAIL: Unexpected error on input %s: %s" % (input, error))
                sys.exit(1)
        else:
            if not should_succeed:
                print("FAIL: Expected error on input %s but got success" % input)
                sys.exit(1)

    print("Testing safe_eval")

    # non-string inputs should be returned as-is
    assert safe_eval(1) == 1

    # simple expressions
    run_eval("1")

# Generated at 2022-06-11 17:20:38.073414
# Unit test for function safe_eval
def test_safe_eval():
    '''basic test of safe_eval'''
    # not using assertRaises() because we want to see the error message
    # to help diagnose the problem
    failed = False
    msg = ''
    try:
        safe_eval("foo == 'bar'")
        msg = 'This should have failed'
        failed = True
    except Exception as e:
        if str(e) != "invalid expression (foo == 'bar')":
            failed = True
            msg = 'Unexpected %s exception: %s' % (type(e), to_native(e))

    if failed:
        raise AssertionError(msg)

    failed = False
    msg = ''

# Generated at 2022-06-11 17:20:48.497296
# Unit test for function safe_eval
def test_safe_eval():
    # simple expr
    safe_eval("")
    safe_eval("foo")
    safe_eval("'foo'")
    safe_eval("'fo o'")
    safe_eval("'fo''o'")
    safe_eval("'fo\"o'")
    safe_eval("'%s'" % "f" * C.DEFAULT_INVENTORY_MAX_HOST_LIST)
    safe_eval("'%s'" % ("f" * C.DEFAULT_INVENTORY_MAX_HOST_LIST) + "f")
    safe_eval("1+1")
    safe_eval("1+1==2")
    safe_eval("foo in ['bar', 'baz', 'bam']")
    safe_eval("foo not in ['bar', 'baz', 'bam']")
    safe_

# Generated at 2022-06-11 17:20:59.480308
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval() function
    '''
    # Setup environment
    locals = {'ansible_os_family': 'freebsd'}
    expected = (u'ansible_os_family == "freebsd"', None)
    # Run the unit test
    result = safe_eval('ansible_os_family == "freebsd"', locals, True)
    assert result == expected
    result = safe_eval('ansible_os_family == "freebsd"', locals, True)
    assert result == expected

    locals = {
        'ansible_os_family': 'freebsd',
        'ansible_distribution': 'openbsd'
    }

# Generated at 2022-06-11 17:21:06.230041
# Unit test for function safe_eval
def test_safe_eval():
    '''
    These values are taken from the deprecated
    module_utils.basic.container_munge function, this is to ensure that
    the safe_eval function works as expected in all cases for Ansible
    '''

# Generated at 2022-06-11 17:21:15.004751
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function
    '''

# Generated at 2022-06-11 17:21:24.655748
# Unit test for function safe_eval
def test_safe_eval():
    class TestException(Exception):
        pass

    # test successful data evaluation
    assert safe_eval("5+5") == 10

    # test data evaluation errors
    assert safe_eval("5.+5") == "5.+5"

    # Test exception handling
    try:
        safe_eval("5 + 5", include_exceptions=True)
        assert False
    except TestException:
        assert True

    # Test data type handling
    assert safe_eval("False") == False
    assert safe_eval("(['test1', 'test2'], 'test3')") == (['test1', 'test2'], 'test3')

# Generated at 2022-06-11 17:22:05.453208
# Unit test for function safe_eval
def test_safe_eval():
    '''
    this is not intended as comprehensive coverage, but rather
    to be a regression test that ensures the safe_eval() function
    behaves as expected
    '''

    # good cases
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3],None)
    assert safe_eval('[1,2,"foo",None]', dict(foo="bar"), include_exceptions=True) == ([1,2,"foo",None],None)
    assert safe_eval('{1:2,3:4}', include_exceptions=True) == ({1:2,3:4},None)
    assert safe_eval('{"a":1,"b":2}', include_exceptions=True) == ({"a":1,"b":2},None)

# Generated at 2022-06-11 17:22:16.110082
# Unit test for function safe_eval
def test_safe_eval():
    # test 1
    expr = "1 + 1"

    ret, err = safe_eval(expr, include_exceptions=True)
    if err is not None:
        print("test_safe_eval: failed test1: %s" % err)
        sys.exit(1)
    if ret != 2:
        print("test_safe_eval: failed test1: got %s, expected 2" % ret)
        sys.exit(1)

    # test 2
    expr = "1 + 1 + 'a'"

    ret, err = safe_eval(expr, include_exceptions=True)
    if err is None:
        print("test_safe_eval: failed test2.  expected an error")
        sys.exit(1)

    # test 3
    expr = "1 + 1 + (1 + 1)"

    ret

# Generated at 2022-06-11 17:22:26.575150
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"test"') == "test"
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"k1": "v1", "k2": "v2"}') == {"k1": "v1", "k2": "v2"}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('container_to_text([1, 2, 3])') == '1 2 3'

    assert safe_eval('1 + 2') == 3
    assert safe_eval('2 - 1') == 1

# Generated at 2022-06-11 17:22:37.320617
# Unit test for function safe_eval
def test_safe_eval():
    # import runpy
    # runpy.run_module('ansible.utils.unsafe_proxy')
    import ansible.utils.unsafe_proxy

    expr = '''
    [ "{{ foo.bar }}", {{ baz }} ]
    '''
    result, exc = safe_eval(expr, dict(foo={'bar': 'a string'}, baz=42), include_exceptions=True)
    assert result == ['a string', 42], 'result was %s' % result
    assert exc is None, 'exception was %s' % exc

    expr = '''
    [ "{{ foo.bar }}", {{ baz }}, {{ bad.function() }} ]
    '''

# Generated at 2022-06-11 17:22:47.294086
# Unit test for function safe_eval
def test_safe_eval():
    def test(s, locals=None, include_exceptions=False):
        ret, err = safe_eval(s, locals=locals, include_exceptions=include_exceptions)
        if err:
            print("'%s' failed test: %s" % (s, err))
        else:
            print("'%s' passed test" % (s))

    print("Testing safe_eval()")

    # OK to pass
    test("42")
    test("[1, 2, 3]")
    test("a.b.c")
    test("'testing'")
    test("{'a': 'testing'}")
    test("1 + 2")
    test("{{foo}}")
    test("1 if true else 0")
    test("'%s' % foo")
    test("1 and 0")


# Generated at 2022-06-11 17:22:51.278174
# Unit test for function safe_eval
def test_safe_eval():
    # Test that safe eval is safe
    try:
        result = safe_eval('_', include_exceptions=True)
    except Exception as e:
        result = e
    assert (isinstance(result, Exception))

    # Test that safe eval can return strings
    result = safe_eval('foo')
    assert (isinstance(result, str))

    # Test that safe eval can return lists
    result = safe_eval('["foo", "bar"]')
    assert (isinstance(result, list))

    # Test that safe eval can return dicts
    result = safe_eval('{"foo": "bar"}')
    assert (isinstance(result, dict))

    # Test that safe eval can return booleans
    result = safe_eval('true')
    assert (isinstance(result, bool))

    # Test that safe eval can return integers

# Generated at 2022-06-11 17:23:00.262164
# Unit test for function safe_eval
def test_safe_eval():
    old_display = C.DEFAULT_UNDEFINED_VAR_BEHAVIOR
    C.DEFAULT_UNDEFINED_VAR_BEHAVIOR = 'warn'


# Generated at 2022-06-11 17:23:11.448610
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'some_string'") == 'some_string'
    assert safe_eval("10") == 10
    assert safe_eval("10 + 11") == 21
    assert safe_eval("a_var", dict(a_var=123)) == 123
    assert safe_eval("a_var", dict(a_var='some_string')) == 'some_string'
    assert safe_eval("a_var", dict(a_var='some_string')) == 'some_string'
    assert safe_eval("a_var", dict(a_var=[123, 456])) == [123, 456]

    # examples from the Jinja2 docs
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-11 17:23:18.537955
# Unit test for function safe_eval
def test_safe_eval():

    # Ensure use of `safe_eval()` with a string of a Python builtin
    # raises an error, as it is a subset of the CALL_ENABLED whitelist,
    # and hence not allowed by the custom AST visitor.
    assert safe_eval('object()') == 'object()'

    # Ensure that variables can be used to lookup builtins with
    # the same name.
    assert safe_eval('str(2)') == '2'

    # Test a more complex expression
    assert safe_eval('(True and 48) or "a string"') == 48

    # Evaluate a dict
    assert safe_eval('{"k": "v", "k2": "v2"}') == {"k": "v", "k2": "v2"}

    # Evaluate a list

# Generated at 2022-06-11 17:23:29.058006
# Unit test for function safe_eval
def test_safe_eval():
    # Valid expressions:
    assert safe_eval('1') is 1
    assert safe_eval('1 + 1') is 2
    assert safe_eval('1 + 1 * 3') is 4
    assert safe_eval('1 < 2') is True
    assert safe_eval('"a" in [1, "a"]') is True
    assert safe_eval('"a" + "a"') == "aa"
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert safe_eval('None') is None
    # Invalid expressions:
