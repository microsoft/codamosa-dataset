

# Generated at 2022-06-25 12:29:40.414207
# Unit test for function safe_eval
def test_safe_eval():
    # FIXME: Pick a better set of values to test, this isn't really testing anything.
    print(safe_eval('1'))
    print(safe_eval('[1, 2, 3]'))
    print(safe_eval('[1, 2, 3]', include_exceptions=True))
    print(safe_eval('{"foo": "bar"}'))
    print(safe_eval('3 + 4'))
    print(safe_eval('{"foo": "bar"}'))



# Generated at 2022-06-25 12:29:42.207068
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{"a": "b"}'
    result = safe_eval(expr)
    assert result == {u'a': u'b'}



# Generated at 2022-06-25 12:29:45.111691
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception:
        raise AssertionError()



# Generated at 2022-06-25 12:29:55.583673
# Unit test for function safe_eval
def test_safe_eval():
    # Simple expressions
    if not safe_eval('1+1') == 2 or safe_eval('1+1') != 2:
        print ("Test 1 failed. {0} does not equal {1}\n".format(str(safe_eval('1+1')), str(2)))
    else:
        print ("Test 1 passed. {0} equals {1}\n".format(str(safe_eval('1+1')), str(2)))

    # expressions with variables

# Generated at 2022-06-25 12:30:05.196683
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # list of (expr, expected_value, expected_error_message)

# Generated at 2022-06-25 12:30:12.791571
# Unit test for function safe_eval
def test_safe_eval():
    test1 = '"hello"'
    test2 = '"hello" + to_text("world")'
    test3 = '"hello" + to_text("world", trim_blocks=True)'
    test4 = '1+2'
    test5 = '{"a": 1+2}'
    test6 = '{"a": [1+2, "hello"]}'
    test7 = '{"a": {"b": {"c": [1+2, "hello"]}}}'
    test8 = None
    test9 = 'to_text("hello", trim_blocks=True)'

    args = [
        test1,
        test2,
        test3,
        test4,
        test5,
        test6,
        test7,
        test8,
        test9,
    ]
    # The assertEqual

# Generated at 2022-06-25 12:30:21.747150
# Unit test for function safe_eval
def test_safe_eval():
    print(safe_eval('''
a = [1, 2, 3]
a[1]
'''))
    print(safe_eval('''
a = [1, 2, 3]
a[1] + 1
'''))
    print(safe_eval('''
a = [1, 2, 3]
a[1] + 1
a[4]
'''))
    print(safe_eval('''
a = [1, 2, 3]
a[1] + 1
a[4]
a[1+2]
'''))
    print(safe_eval('''
a = [1, 2, 3]
a[1] + 1
a[4]
a[1+2]
a[2] + a[3]
'''))

# Generated at 2022-06-25 12:30:25.381202
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = "a = 5"
    var_0 = safe_eval(var_1)

    assert var_0 == 5, "Expected value is 5, but actual is %s" % var_0


# Generated at 2022-06-25 12:30:35.298074
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = True
    bool_1 = False
    num_0 = 10
    num_1 = 20
    str_0 = "hi"
    str_1 = "hello"
    str_2 = 'universe'
    list_0 = [1,2,3,4]
    list_1 = ['a', 'b', 'c', 'd']
    list_2 = [str_0, str_1, str_2]
    list_3 = [num_0, num_1]
    list_4 = [list_0, list_1]
    list_5 = [list_1, list_2]
    list_6 = [list_3, list_4, list_5]
    i = 0
    j = 0
    k = 0
    temp_0 = list_0[i]


# Generated at 2022-06-25 12:30:44.806181
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval

    Example:
    structure:
    - name: validate {{var_1}} == 'hello world'
      assert:
        that:
          - var_1 == 'hello world'
        msg: 'var_1 is not equal to hello world'
    """
    # Test call with these parameters:
    # name=validate {{var_1}} == 'hello world', assert={'that': [{'var_1 == 'hello world''}], 'msg': 'var_1 is not equal to hello world'}
    # For testing purposes it is useful to make the 'msg' really obvious so
    # that when it is output, it is clear where the message came from.
    #
    # Note: Jinja2 will do some evaluation to escape quotes, but this is not
    # a significant security hole in Ansible, since

# Generated at 2022-06-25 12:30:49.940552
# Unit test for function safe_eval
def test_safe_eval():
    arg_0 = 'a_list_variable'
    ret_0 = safe_eval(arg_0)
    assert ret_0 == 'a_list_variable'

# This will run all the test cases in the above block

# Generated at 2022-06-25 12:30:55.264190
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:56.644297
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None


# Generated at 2022-06-25 12:30:57.794927
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(var_0) == var_0


# Generated at 2022-06-25 12:31:01.814464
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval(): return value
    retval = safe_eval("fooo", var_0)
    assert(retval == "fooo")

    # safe_eval(): return exception
    retval = safe_eval("fooo", var_0, True)
    assert(retval[0] == "fooo")
    assert(retval[1] == None)

# Generated at 2022-06-25 12:31:08.868952
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval...")

    constants = C.__dict__
    constants['var_0'] = dict()
    constants['var_1'] = 1
    constants['var_2'] = '2'
    # constants['var_3'] = 'true'
    constants['var_4'] = True
    constants['var_5'] = 'false'
    constants['var_6'] = False
    constants['var_7'] = None
    constants['var_8'] = [1, 2, 3, 4]
    constants['var_9'] = {'k': 'v'}
    constants['var_10'] = {'k1': {'k2': 'v2'}}
    constants['var_11'] = 'a string with it'
    constants['var_12'] = 'a string without it'

# Generated at 2022-06-25 12:31:18.666077
# Unit test for function safe_eval
def test_safe_eval():
    ansible_0 = dict(foo='{{ [1, 2, 3] }}')
    assertion_0 = safe_eval(ansible_0['foo'])
    assert assertion_0 == [1, 2, 3], "Failed: safe_eval({}) == {}, got {}".format(ansible_0['foo'], [1, 2, 3], assertion_0)
    ansible_1 = dict(foo='{{ (1, 2, 3) }}')
    assertion_1 = safe_eval(ansible_1['foo'])
    assert assertion_1 == (1, 2, 3), "Failed: safe_eval({}) == {}, got {}".format(ansible_1['foo'], (1, 2, 3), assertion_1)
    ansible_2 = dict(foo='{{ {1, 2, 3} }}')


# Generated at 2022-06-25 12:31:26.161780
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval with different types of arguments
    test_result = safe_eval(['0', '1', '2'])
    assert test_result == ['0', '1', '2']

    test_result = safe_eval('/bin:/usr/bin:/sbin:/usr/sbin')
    assert test_result == '/bin:/usr/bin:/sbin:/usr/sbin'

    # Test safe_eval with invalid values in expression (should return None)
    test_result = safe_eval("{{'0'|int * '1'|int}}")
    assert test_result == "{{'0'|int * '1'|int}}"

if __name__ == '__main__':
    # Generate callstack to inspect test_case_0 function
    test_case_0()
    test_safe_eval

# Generated at 2022-06-25 12:31:29.767342
# Unit test for function safe_eval
def test_safe_eval():
    assert callable(safe_eval) # Test whether function exists
    test_case_0() # Test with a dict

test_safe_eval() # Run the test


# Generated at 2022-06-25 12:31:31.005284
# Unit test for function safe_eval
def test_safe_eval():
    # call function safe_eval with arguments
    assert safe_eval() == dict()


# Generated at 2022-06-25 12:31:34.560132
# Unit test for function safe_eval
def test_safe_eval():
    res = safe_eval("a_list_variable", locals())


# Generated at 2022-06-25 12:31:37.228083
# Unit test for function safe_eval
def test_safe_eval():
    # Test when expr is of type 'str'
    assert safe_eval('foo') == 'foo'
    # Test when expr is not of type 'str'
    assert safe_eval([]) == []

# Generated at 2022-06-25 12:31:39.344994
# Unit test for function safe_eval
def test_safe_eval():
    val = safe_eval(test_case_0, dict(v=dict()))
    assert val == dict()


# Generated at 2022-06-25 12:31:46.851227
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = 0
    var_1 = "b"
    var_2 = 2
    var_3 = 3
    var_4 = 4

    vars = {'var_0': var_0, 'var_1': var_1, 'var_2': var_2, 'var_3': var_3}
    expr = "var_0 + var_1 + var_2 + var_3"
    result = safe_eval(expr, vars)
    assert result == "0b23"

    expr = "var_0 + var_1 - var_2 + var_3"
    result = safe_eval(expr, vars)
    assert result == "0b1"

    expr = "var_0 + var_1 * var_2 + var_3"

# Generated at 2022-06-25 12:31:58.631964
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = dict()
    var_1 = 'foo'
    var_2 = safe_eval(var_1, locals=var_0)
    var_3 = 'foo {{ bar }}'
    var_4 = safe_eval(var_3, locals=var_0)
    var_5 = 'foo {{ bar }}'
    var_6 = safe_eval(var_5, locals=var_0)
    var_7 = 'foo {{ bar }}'
    var_8 = safe_eval(var_7, locals=var_0)
    var_9 = 'foo {{ bar }}'
    var_10 = safe_eval(var_9, locals=var_0)
    var_11 = 'foo {{ bar }}'
    var_12 = safe_eval(var_11, locals=var_0)
    var

# Generated at 2022-06-25 12:32:05.435431
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('(1)') == 1
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'baz': 'qux', 'foo': 'bar'}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo["bar"]') == 'foo["bar"]'
   

# Generated at 2022-06-25 12:32:16.659726
# Unit test for function safe_eval
def test_safe_eval():
    print('TESTING safe_eval()')
    errors = 0

    expr = '2 + 3'
    expected_result = 5
    result = safe_eval(expr)
    if result != expected_result:
        print('FAIL: safe_eval({}) returned {} expected {}'.format(expr, result, expected_result))
        errors += 1
    else:
        print('PASS: safe_eval({}) returned {}'.format(expr, result))

    expr = '3**3'
    expected_result = 27
    result = safe_eval(expr)
    if result != expected_result:
        print('FAIL: safe_eval({}) returned {} expected {}'.format(expr, result, expected_result))
        errors += 1
    else:
        print('PASS: safe_eval({}) returned {}'.format(expr, result))



# Generated at 2022-06-25 12:32:25.413178
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = dict()
    var_1['foo'] = "Simple expression"
    var_1['bar'] = "{{ true }}"
    var_1['baz'] = "{{ false }}"
    var_1['bing'] = "{{ true and false }}"
    var_1['bang'] = "{{ true or (true and false) }}"
    var_1['boo'] = "{{ (true or false) and (false or true or false) }}"

    var_0['test_case_0'] = var_1

    for key, var in var_0.items():
        for key, var_2 in var.items():
            print(safe_eval(var_2, dict(), True))


# Generated at 2022-06-25 12:32:35.615855
# Unit test for function safe_eval
def test_safe_eval():
    ansible_vars = dict(
        string='string',
        integer=1,
        float=3.14159265359,
        boolean=True,
        list=['string', 1, 3.14159265359, True],
        tuple=('string', 1, 3.14159265359, True),
        dict={'string':'string', 'integer':1, 'float':3.14159265359, 'boolean':True, 'list':['string', 1, 3.14159265359, True], 'tuple':('string', 1, 3.14159265359, True)},
        unicode=u'unicode'
    )
    # evaluate strings

# Generated at 2022-06-25 12:32:40.968862
# Unit test for function safe_eval
def test_safe_eval():
    # init
    var_0 = dict()

    # init
    var_1 = list()

    # init
    var_2 = str()

    # init
    var_3 = int()

    # init
    var_4 = str()

    # init
    var_5 = str()

    # init
    var_6 = str()

    # init
    var_7 = str()

    # init
    var_8 = str()

    # init
    var_9 = str()

    # init
    var_10 = str()

    # init
    var_11 = str()

    # init
    var_12 = str()

    # init
    var_13 = str()

    # init
    var_14 = str()

    # init
    var_15 = str()

    # init
    var_

# Generated at 2022-06-25 12:32:55.935855
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    test_string = "var_0"
    test_dict = dict()
    test_dict['var_0'] = "test_var"
    test_dict['test_0'] = "test_test"
    test_dict['test_1'] = "test_test1"
    test_dict['test_2'] = "test_test2"
    test_dict['test_3'] = "test_test3"
    test_dict['test_4'] = "test_test4"
    test_dict['test_5'] = "test_test5"
    test_dict['test_6'] = "test_test6"
    test_dict['test_7'] = "test_test7"
    test_dict['test_8'] = "test_test8"

# Generated at 2022-06-25 12:33:06.426693
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = dict()

    var_1 = safe_eval("{'a': 'b'}")

    var_2 = dict()
    var_2['a'] = 'b'
    assert var_1 == var_2, "Assertion failed"
    var_1 = safe_eval("'damn'")

    var_2 = 'damn'
    assert var_1 == var_2, "Assertion failed"
    var_1 = safe_eval("2+2")

    var_2 = 4
    assert var_1 == var_2, "Assertion failed"
    var_1 = safe_eval("[1,2,3]")

    var_2 = [1, 2, 3]
    assert var_1 == var_2, "Assertion failed"
    var_1 = safe_

# Generated at 2022-06-25 12:33:08.115952
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print('FAILURE:test_case_0: ' + str(e))
    else:
        print('SUCCESS:test_case_0')

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:33:14.832532
# Unit test for function safe_eval
def test_safe_eval():
    # run_safe_eval(path_to_module, function_name, list_of_arguments)
    # run_safe_eval(path_to_module, function_name, list_of_arguments)
    exception = None
    try:
        safe_eval("{'a': 1, 'b': 2}", {}, False)
    except Exception as e:
        exception = e
    assert(exception == None)


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:33:28.047280
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:32.126875
# Unit test for function safe_eval
def test_safe_eval():
    # ensure safe_eval throws an exception when it is passed a dictionary
    try:
        test_case_0()
        print("fail: safe_eval did not throw an exception")
    except (TypeError, NameError) as e:
        print("ok: safe_eval threw an exception as expected: %s" % e)

if __name__ == "__main__":
    test_safe_eval()
    sys.exit(0)

# Generated at 2022-06-25 12:33:43.678877
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval')
    e = safe_eval('{"a": 1}')
    assert e == {'a': 1}
    e = safe_eval('1 + 1')
    assert e == 2
    #e = safe_eval('file("/proc/cpuinfo").read()')
    #assert e == {'a': 1}
    #e = safe_eval('{a}')
    #print(dir(e))
    #assert e == {'a': 1}
    #e = safe_eval('[a, b]')
    #assert e == 2
    #e = safe_eval('foo(a, b)')
    #assert e == 2
    #e = safe_eval('file("/proc/cpuinfo").read()')
    #assert e == 2
    #e = safe_eval('file

# Generated at 2022-06-25 12:33:53.140560
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = dict()
    var = safe_eval('dict(a=1, b=2, c=3)', {'dict': dict})
    try:
        assert var == dict(a=1, b=2, c=3)
    except AssertionError as e:
        print("[FAIL]", file=sys.stderr)
        raise(e)
    print("[OK]", file=sys.stderr)

    var = safe_eval('{a=1, b=2, c=3}')
    try:
        assert var == dict(a=1, b=2, c=3)
    except AssertionError as e:
        print("[FAIL]", file=sys.stderr)
        raise(e)

# Generated at 2022-06-25 12:34:00.791627
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic

    print('Running safe_eval tests')

    rc, out, err = basic.run_command('python -c "import sys; print(sys.version_info[:])"')

    # Python 2.7.9 and greater require ssl to verify SSL certificates.
    # This will cause the test suite to fail if you do not have an unbroken SSL cipher or
    # you are running the tests in a container where you can't install the CA certificate.
    if out.find('2.7.9') != -1:
        rc, out, err = basic.run_command('python -c "import ssl; print(ssl.OPENSSL_VERSION)"')
        if out.startswith('OpenSSL 0.9.'):
            print('Unsupported SSL version detected, skipping tests for this case')
            return

# Generated at 2022-06-25 12:34:03.398175
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval('abc')
    except Exception as e:
        if e.message == 'invalid expression (abc)':
            return True
    return False


# Generated at 2022-06-25 12:34:17.282701
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    # Test with valid expressions
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 * 3") == 6
    assert safe_eval("8 - 5") == 3
    assert safe_eval("8 / 4") == 2
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("42") == 42
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("true") == True
   

# Generated at 2022-06-25 12:34:27.614348
# Unit test for function safe_eval
def test_safe_eval():
    import inspect
    import sys

    # First, we check to see if this function has actually been implemented
    assert(len(inspect.getargspec(safe_eval).args) > 0)

    # We attempt to manually generate the test cases
    
    test_case_0_expr = 'dict()'
    test_case_0_result = dict()
    test_case_0_result_text = container_to_text(test_case_0_result)
    test_case_0_locals_before = locals().copy()
    
    safe_eval(test_case_0_expr, test_case_0_locals_before.copy())
    test_case_0_locals_after = locals().copy()
    test_case_0_result = test_case_0_locals_after["var_0"]


# Generated at 2022-06-25 12:34:37.280688
# Unit test for function safe_eval
def test_safe_eval():
    test_return = safe_eval("GITHUB.get('repos', [])", include_exceptions=True)
    assert test_return[0] == None
    assert test_return[1] == None
    print("Return: %s" % test_return)

    test_return = safe_eval("GITHUB.get('repos', [])")
    assert test_return == []
    print("Return: %s" % test_return)

    test_return = safe_eval("GITHUB['repos']", include_exceptions=True)
    assert test_return[0] == None
    assert test_return[1] == None
    print("Return: %s" % test_return)

    test_return = safe_eval("GITHUB['repos']")
    assert test_return == None

# Generated at 2022-06-25 12:34:45.814109
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = {"a": 1, "b": "bar"}
    var_1 = safe_eval("a", var_0)
    assert (var_1 == 1)
    var_2 = safe_eval("a == 1", var_0)
    assert (var_2 is True)
    var_3 = safe_eval("a == 2", var_0)
    assert (var_3 is False)
    var_4 = safe_eval("a == b", var_0)
    assert (var_4 is False)


# Generated at 2022-06-25 12:34:53.575130
# Unit test for function safe_eval
def test_safe_eval():
    try:
        assert(ast.dump(ast.parse('1')) == 'Module(body=[Expr(value=Num(n=1))])')
        assert safe_eval('1') == 1
    except AssertionError:
        print(sys.exc_info())
        raise AssertionError('test_safe_eval failed for ast.parse and safe_eval')

    try:
        assert safe_eval('0.0') == 0
    except AssertionError:
        print(sys.exc_info())
        raise AssertionError('test_safe_eval failed for safe_eval')

    try:
        assert safe_eval('1 + 2') == 3
    except AssertionError:
        print(sys.exc_info())
        raise AssertionError('test_safe_eval failed for safe_eval')

   

# Generated at 2022-06-25 12:34:55.039971
# Unit test for function safe_eval
def test_safe_eval():
    # FIXME: write test cases
    assert True



# Generated at 2022-06-25 12:35:04.231834
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"k1":"v1"}') == {"k1":"v1"}
    assert safe_eval('a_var') == 'a_var'
    assert safe_eval('a_var[1]') == 'a_var[1]'
    assert safe_eval('a_var["index_key"]') == 'a_var["index_key"]'
    assert safe_eval('a_var.key') == 'a_var.key'
    assert safe_eval('a_var.key.key2') == 'a_var.key.key2'
    assert safe_eval('a_var.key.key2.key3') == 'a_var.key.key2.key3'

# Generated at 2022-06-25 12:35:06.650009
# Unit test for function safe_eval
def test_safe_eval():
    # Get parameters for testcase 0
    var_0 = dict()
    assert safe_eval(var_0) == dict(), "Failed safe_eval with params."


# Generated at 2022-06-25 12:35:15.835247
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:22.177173
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]', dict()) == []
    assert safe_eval('[1, 2, 3]', dict()) == [1, 2, 3]
    assert safe_eval('[1, [2, [3, [4, "foo"]]]]', dict()) == [1, [2, [3, [4, "foo"]]]]
    assert safe_eval('{}', dict()) == {}
    assert safe_eval('{"a": "b"}', dict()) == {'a': 'b'}
    assert safe_eval('{"a": {"b": "c"}}', dict()) == {'a': {'b': 'c'}}
    assert safe_eval('{"a": {"b": {"c": "d"}}}', dict()) == {'a': {'b': {'c': 'd'}}}
    assert safe_

# Generated at 2022-06-25 12:35:27.719314
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:35:29.454345
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:35:32.774876
# Unit test for function safe_eval
def test_safe_eval():
    # case 0
    test_case_0()

# Unit test entry
if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:35:35.524104
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval() with fake data ...")
    test_case_0()


# Generated at 2022-06-25 12:35:42.686637
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for the safe_eval function.

    Arguments:
    None.

    Returns:
    None.

    '''
    # this is a non-sensical string that could have been returned
    # by a filter function to test the ability to call things like
    # this without trying to actually call subclasses of str.
    str_0 = 'RVxAwp9/SZwsQ'
    var_0 = safe_eval(str_0)
    print(var_0)


if __name__ == "__main__":

    if C.DEFAULT_DEBUG:
        test_safe_eval()

# Generated at 2022-06-25 12:35:46.752264
# Unit test for function safe_eval
def test_safe_eval():
    # Part B
    # Replacement for function call in Part A
    # Note: This code can be separated into two parts,
    #       one that does something,
    #       and one that does nothing.
    # If a function returns a variable that is used in the SUT,
    #     then that variable is part of the SUT
    test_case_0()


# Generated at 2022-06-25 12:35:56.168971
# Unit test for function safe_eval
def test_safe_eval():
    # Test groups
    # 1. Successful expressions
    # 2. Failed expressions (should always return the original input)

    # Set expected return values
    expected_result_1 = [1, 2]
    expected_result_2 = "{{this is not valid JSON}}"
    expected_result_3 = u"[u'{{This is a string}}']"
    expected_result_4 = "ansible_os_family"
    expected_result_5 = u'agtest\x00commiter@agtest.io'
    expected_result_6 = u"\u001b[1;31m"  # red
    expected_result_7 = u"\u001b[39m"  # default to non-color
    expected_result_8 = [1, 2, 3]

# Generated at 2022-06-25 12:36:01.419014
# Unit test for function safe_eval
def test_safe_eval():
    # type: () -> bool
    '''
    safe_eval
    :return:
    '''
    try:
        test_case_0()
    except Exception as e:
        print(e.args)
        traceback.print_exc(file=sys.stdout)
        return False
    return True


# Generated at 2022-06-25 12:36:03.817433
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '"hello" in ansible_hostname'
    var_0 = safe_eval(str_0)
    assert var_0 == False



# Generated at 2022-06-25 12:36:05.238312
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 12:36:18.947268
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('-10') == -10
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('()') == ()
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('[2, 3*2, ([])]') == [2, 6, ([])]
    assert safe_eval('[2, 3*2, ([])]', include_exceptions=True)[0] == [2, 6, ([])]

# Generated at 2022-06-25 12:36:20.633427
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:36:30.214360
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    # Set up test
    test_vars = {
        '_id':
            'RVxAwp9/SZwsQ',
        'fqdn':
            'my-policy-template.my-company.com',
        'id':
            'RVxAwp9/SZwsQ',
        'package_version':
            '1.0.0',
        'provider':
            'MyCompany',
        'template_version':
            '1.0.0',
        'version':
            '1.0.0',
    }

# Generated at 2022-06-25 12:36:40.173313
# Unit test for function safe_eval
def test_safe_eval():
    # First test case
    test_case_0()

    # Second test case
    dict_1 = dict()
    dict_1['another_dict'] = dict()
    dict_1['another_dict']['michael'] = 'cool'
    dict_1['another_dict']['mathieu'] = 'cooler'
    dict_1['hello'] = 'world'
    dict_1['count'] = 1
    dict_1['some_list'] = ['a', 'b', 'c']
    str_1 = '{{ "hello" if count == 1 else "goodbye" }}'
    var_1 = safe_eval(str_1, dict_1)
    str_2 = '{{ (1,2,3) if count == 1 else (4,5,6) }}'
    var_2 = safe_eval

# Generated at 2022-06-25 12:36:47.050484
# Unit test for function safe_eval
def test_safe_eval():
    testing_var = 1
    assert safe_eval('testing_var + 1') == 2
    assert safe_eval('testing_var', {'testing_var': 1}) == 1
    assert safe_eval('[testing_var for testing_var in (1,2,3)]') == [1, 2, 3]
    assert safe_eval('[testing_var for testing_var in (1,2,3)]', {'testing_var': 3}) == [1, 2, 3]
    assert safe_eval('[testing_var for testing_var in (1,2,3)]', {'testing_var': 1}) == [1, 2, 3]



# Generated at 2022-06-25 12:36:48.553163
# Unit test for function safe_eval
def test_safe_eval():
    # An example for using safe_eval
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:36:50.478274
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:36:52.932432
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'RVxAwp9/SZwsQ'
    var_1 = safe_eval(str_1)
    # truthy value
    if var_1:
        test_case_0()



# Generated at 2022-06-25 12:36:54.824991
# Unit test for function safe_eval
def test_safe_eval():
    assert_0 = 'RVxAwp9/SZwsQ'
    assert_1 = safe_eval(assert_0)
    assert assert_1 == assert_0



# Generated at 2022-06-25 12:36:58.104278
# Unit test for function safe_eval
def test_safe_eval():
    # Try a string variable
    assert safe_eval("'Foo'") == 'Foo'

    # Try a numeric variable
    assert safe_eval("300") == 300


# Generated at 2022-06-25 12:37:13.321972
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'RVxAwp9/SZwsQ'
    var_0 = safe_eval(str_0)
    assert str_0 == var_0

    str_0 = 'bW9yZQ=='
    var_0 = safe_eval(str_0)
    assert str_0 == var_0

    str_0 = 'SSBhbSBub3QgYW4gb2JqZWN0IQ=='
    var_0 = safe_eval(str_0)
    assert str_0 == var_0


# Generated at 2022-06-25 12:37:16.227770
# Unit test for function safe_eval
def test_safe_eval():
    arr = [test_case_0]

    for func in arr:
        func()


if __name__ == '__main__':
    # test_safe_eval()
    test_case_0()

# Generated at 2022-06-25 12:37:24.044618
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '2**2'
    var_0 = safe_eval(str_0)
    assert var_0 == 4

    str_1 = 'RVxAwp9/SZwsQ'
    var_1 = safe_eval(str_1)
    assert var_1 == 'RVxAwp9/SZwsQ'

    str_2 = 'RVxAwp9/SZwsQ'
    var_2 = safe_eval(str_2)
    assert var_2 == 'RVxAwp9/SZwsQ'

    str_3 = 'RVxAwp9/SZwsQ'
    var_3 = safe_eval(str_3)
    assert var_3 == 'RVxAwp9/SZwsQ'


# Generated at 2022-06-25 12:37:24.973422
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:37:34.285454
# Unit test for function safe_eval
def test_safe_eval():

    # Test for exceptions validation
    with pytest.raises(Exception) as e_info:
        str_0 = 'fn(x'
        var_0 = safe_eval(str_0)

    # Test for exceptions validation
    with pytest.raises(Exception) as e_info:
        str_0 = 'RVxAwp9/SZwsQ'
        var_0 = safe_eval(str_0)

    # Test for exceptions validation
    with pytest.raises(Exception) as e_info:
        str_0 = '\'YXAaPdbTw52E\''
        var_0 = safe_eval(str_0)

    # Test for exceptions validation
    with pytest.raises(Exception) as e_info:
        str_0 = 'True'
        var_0 = safe_

# Generated at 2022-06-25 12:37:42.688428
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'RVxAwp9/SZwsQ'
    str_2 = '{{ a }}'
    str_3 = '1+1'
    str_4 = 'foo.bar()'
    str_5 = 'foo.bar()|1'
    str_6 = 'foo.bar()|int'
    str_7 = 'a.b.c|json_query(foo)'


# Generated at 2022-06-25 12:37:43.445361
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:37:53.849798
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(str) == str
    assert safe_eval(str('')) == ''
    assert safe_eval(str(None)) == None
    assert safe_eval(str(False)) == False

    assert safe_eval(str(True)) == True
    assert safe_eval(str([])) == []
    assert safe_eval(str(())) == ()
    assert safe_eval(str('')) == ''
    assert safe_eval(str(True)) == True
    assert safe_eval(str(1)) == 1
    assert safe_eval(str(1.0)) == 1.0
    assert safe_eval(str('1')) == '1'
    assert safe_eval(str('True')) == 'True'
    assert safe_eval(str('False')) == 'False'

# Generated at 2022-06-25 12:37:56.773142
# Unit test for function safe_eval
def test_safe_eval():
    # Test template with str input
    str_2 = 'RVxAwp9/SZwsQ'
    var_2 = safe_eval(str_2)


# Generated at 2022-06-25 12:38:02.304794
# Unit test for function safe_eval
def test_safe_eval():
    # Convenience function for basic tests.
    def is_safe(expr, expected=None):
        try:
            result = safe_eval(expr)
            if result != expected:
                print("test_case_1(): Expected %s, but got %s" % (str(expected), str(result)))
                return False
            else:
                return True
        except Exception as e:
            print("test_case_1(): Failed for: %s (%s)" % (str(expr), str(e)))
            return False

    # test case 0
    test_case_0()

    # Basic tests.
    assert(is_safe('[1,2,3]', [1,2,3]))
    assert(is_safe('{"a":5}', {'a': 5}))

# Generated at 2022-06-25 12:38:17.989813
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import ast
        import astor
    except ImportError:
        return

    # Test 0
    var_0 = 'RVxAwp9/SZwsQ'
    var_1 = safe_eval(var_0)
    var_2 = "RVxAwp9/SZwsQ"
    var_3 = None
    var_4 = var_2 == var_3
    assert var_1 == var_4

    # Test 1
    var_0 = 'mypassword'
    var_1 = "{{ 'mypassword' }}"
    var_2 = safe_eval(var_1, dict(mypassword=var_0))
    var_3 = "mypassword"
    var_4 = None
    var_5 = var_3 == var_4
    assert var_2 == var_

# Generated at 2022-06-25 12:38:19.315998
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

################################################################################
# main():

# Generated at 2022-06-25 12:38:29.654608
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:32.504119
# Unit test for function safe_eval
def test_safe_eval():
    # Jiajun's test case
    # test_case_0()
    # Jiajun's test case

    # test_case_1()
    test_case_2()


# Generated at 2022-06-25 12:38:37.415453
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# ----------------------------------------------------------------------
# |
# |  Main
# |
# ----------------------------------------------------------------------
if __name__ == "__main__":
    try:
        sys.exit(
            main()
        )
    except KeyboardInterrupt:
        pass


# ----------------------------------------------------------------------
# |
# |  Extensions
# |
# ----------------------------------------------------------------------

# Generated at 2022-06-25 12:38:39.121914
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:38:47.097422
# Unit test for function safe_eval
def test_safe_eval():
    # verify that syntax errors are not swallowed
    try:
        safe_eval('foo()', include_exceptions=True)
    except Exception:
        pass
    else:
        raise AssertionError("safe_eval didn't raise an exception for foo()")

    # verify that exceptions are not wrapped by default
    test_cases = (
        'foo()',
        '1 + "1"',
        'foo.__class__',
        '__import__("sys")',
        '1 == 1',
        '1 + 1',
        'foo(bar)',
        'bar(foo)',
    )
    for test_case in test_cases:
        try:
            safe_eval(test_case)
        except Exception:
            raise AssertionError("safe_eval wrapped exception for '%s'" % test_case)

# Generated at 2022-06-25 12:38:56.380882
# Unit test for function safe_eval
def test_safe_eval():
    assert 'RVxAwp9/SZwsQ' == safe_eval('RVxAwp9/SZwsQ')
    assert 42 == safe_eval('42')
    assert 42 == safe_eval('42')
    assert b'foo bar' == safe_eval('b"foo bar"')
    assert b'foo bar' == safe_eval('b\'foo bar\'')
    assert [1, 2] == safe_eval('[1, 2]')
    assert [1, 2] == safe_eval('[1, 2]')
    assert [1, 2] == safe_eval('[1, 2]')
    assert [1, 2] == safe_eval('[1, 2]')
    assert [1, 2] == safe_eval('[1, 2]')
    assert 'foo bar' == safe_eval

# Generated at 2022-06-25 12:39:00.898993
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('test_case_0()') == 'RVxAwp9/SZwsQ'
    assert safe_eval('1 + 1') == 2
    assert safe_eval('(1 + 1) - 1') == 1
    assert safe_eval('({0: 1, 1: 0}[1])'.format(1)) == 0

# Generated at 2022-06-25 12:39:08.849376
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'Container(abc)'
    var_1 = safe_eval(str_1)
    str_2 = 'Container(abc, name=def)'
    var_2 = safe_eval(str_2, include_exceptions=True)
    str_3 = 'Container(abc).name'
    var_3 = safe_eval(str_3, include_exceptions=True)
    str_4 = 'Container(abc).name.attr'
    var_4 = safe_eval(str_4)
    str_5 = 'Container(abc).name.attr.abc'
    var_5 = safe_eval(str_5, include_exceptions=True)
    str_6 = 'Container(abc).name.attr.abc'
    var_6 = safe_eval(str_6, include_exceptions=True)

# Generated at 2022-06-25 12:39:21.050375
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()

# Testing with the following expression:
# [x for x in "abcdef" if x not in "ab"]

# Generated at 2022-06-25 12:39:22.260260
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "foo"
    var_0 = safe_eval(str_0)


# Generated at 2022-06-25 12:39:23.974939
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval()")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    print("safe_eval PASSED")


# Generated at 2022-06-25 12:39:24.613991
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:39:25.347408
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 12:39:30.936020
# Unit test for function safe_eval
def test_safe_eval():
    args = {u'this_is_a_string': u'RVxAwp9/SZwsQ'}
    kwargs = {u"this_is_a_dict": {u"a_key": [0, 1, 2]}}
    #import pdb; pdb.set_trace()
    result = safe_eval(u"this_is_a_dict")
    #assert result == {u"a_key": [0, 1, 2]}
    assert result == {u"a_key": [0, 1, 2]}
