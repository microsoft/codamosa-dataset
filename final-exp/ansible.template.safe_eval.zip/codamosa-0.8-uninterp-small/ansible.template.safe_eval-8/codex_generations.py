

# Generated at 2022-06-25 12:29:38.769842
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_MODULE_UTILS == 'basic':
        # run basic tests only when default module_utils is 'basic'
        test_case_0()

# Generated at 2022-06-25 12:29:41.398709
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'grep booted /var/log/vmksummary.log | tail -n 1'
    var_0 = safe_eval(str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 12:29:52.279358
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '1 + 3'
    var_1 = safe_eval(str_1)
    assert var_1 == 4

    str_2 = '1 + 3 < 4'
    var_2 = safe_eval(str_2)
    assert var_2 == True

    str_3 = 'a_list_variable'
    var_3 = safe_eval(str_3)
    assert var_3 == 'a_list_variable'

    if sys.version_info[0] >= 3:
        str_4 = 'print("this should fail", file=sys.stderr)'
    else:
        str_4 = 'print "this should fail"'

    try:
        var_4 = safe_eval(str_4)
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-25 12:30:02.108960
# Unit test for function safe_eval
def test_safe_eval():

    # The following expression is not valid Python syntax and should
    # raise SyntaxError at compile time.  Instead we return the string
    # back as-is, to allow late evaluation.
    #
    str_0 = 'grep booted /var/log/vmksummary.log | tail -n 1'
    var_0 = safe_eval(str_0)
    if not isinstance(var_0, string_types):
        print("Problem with test #0")
        fail

    # The following expression is valid Python syntax, but includes
    # a call to an unsafe builtin
    str_1 = '__import__(\'os\').path.isfile(\'/etc/shadow\')'
    var_1 = safe_eval(str_1)

# Generated at 2022-06-25 12:30:12.022426
# Unit test for function safe_eval
def test_safe_eval():
    # Test call.
    assert safe_eval('1+1') == 2
    d = dict(a=dict(b='c'))
    assert safe_eval('a.b', locals=d) == 'c'

    # Test call to a disabled builtin function.
    try:
        safe_eval('len(1,2,3)')
        assert False
    except Exception:
        assert True

    # Test call to enabled builtin function.
    CALL_ENABLED.extend(['len'])
    assert safe_eval('len(1,2,3)') == 3

    # Test no exceptions
    try:
        safe_eval('len(1,2,3)', include_exceptions=True)
        assert True
    except Exception:
        assert False

# Needs to be called at the end of the test to

# Generated at 2022-06-25 12:30:21.219299
# Unit test for function safe_eval
def test_safe_eval():
    # In [17]: safe_eval('1 + 2')
    # Out[17]: 3
    assert safe_eval('1 + 2') == 3
    # In [18]: safe_eval('1 + 2 + bad_var')
    # Out[18]: '1 + 2 + bad_var'
    assert safe_eval('1 + 2 + bad_var') == '1 + 2 + bad_var'

    # In [19]: safe_eval('[1, 2, 3]')
    # Out[19]: [1, 2, 3]
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    # In [20]: safe_eval('[1, 2, 3')
    # Out[20]: '[1, 2, 3'

# Generated at 2022-06-25 12:30:27.981517
# Unit test for function safe_eval
def test_safe_eval():
    test = safe_eval("[{'fail': 'False'}, {'rc': 0, 'stdout_lines': ['OK: sshd running'], 'stdout': 'OK: sshd running\n'}]",
                     include_exceptions=True)
    assert test == ([{'fail': False}, {'rc': 0, 'stdout_lines': ['OK: sshd running'], 'stdout': 'OK: sshd running\n'}], None)



# Generated at 2022-06-25 12:30:37.143766
# Unit test for function safe_eval
def test_safe_eval():

    # Simple test
    test_str = "{{ 1 + 1 }}"
    result = safe_eval(test_str)
    assert result == 2

    # Test with nested jinja2 expression
    test_str = "{{ [1, 2, 3] | map('int') | list }}"
    result = safe_eval(test_str)
    assert result == [1, 2, 3]

    # Test with expression that throws exception
    test_str = "{{ 1 + '1' }}"
    try:
        result = safe_eval(test_str)
        # result should be test_str as it will not evaluate to a valid expression
        assert result == test_str
    except:
        assert False

    # Test with expression that throws exception
    # to check if jinja2 is converting unicode to string

# Generated at 2022-06-25 12:30:46.667375
# Unit test for function safe_eval
def test_safe_eval():
    # dict
    dict_string_1 = '{"key1": "value1", "key2": "value2"}'
    dict_1 = safe_eval(dict_string_1)
    assert isinstance(dict_1, dict)
    assert dict_1['key1'] == 'value1'

    dict_string_2 = '{"key1": "value1", "key2": {"key3": "value3"}}'
    dict_2 = safe_eval(dict_string_2)
    assert isinstance(dict_2, dict)
    assert dict_2['key2']['key3'] == 'value3'


# Generated at 2022-06-25 12:30:49.835214
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'grep booted /var/log/vmksummary.log | tail -n 1'
    var_0 = safe_eval(str_0)
    assert var_0 is not None

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:30:53.499468
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Provided main() calls the above functions

# Generated at 2022-06-25 12:31:01.263449
# Unit test for function safe_eval
def test_safe_eval():

    # Checks for the unittest for func safe_eval
    str_1 = '5 * 8'
    str_2 = '[1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584]'
    str_3 = '5 * 8 and not 5 * 8'
    str_4 = '5 * 8 and not 5 * 8 or (5 * 8 and not 5 * 8)'
    str_5 = '5 * 8 and not 5 * 8 or 5 * 8 and not 5 * 8 or (5 * 8 and not 5 * 8)'
    str_6 = '5 * 8 and not 5 * 8 or 5 * 8 and not 5 * 8 or 5 * 8 and not 5 * 8 or (5 * 8 and not 5 * 8)'

# Generated at 2022-06-25 12:31:08.477446
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '2 + 2'
    exp_1 = 4
    var_1 = safe_eval(str_1)
    assert(var_1 == exp_1)

    str_2 = '2 + 2 - 1'
    exp_2 = 3
    var_2 = safe_eval(str_2)
    assert(var_2 == exp_2)

    str_3 = '(2 + 2) * 2'
    exp_3 = 8
    var_3 = safe_eval(str_3)
    assert(var_3 == exp_3)

    str_4 = '8/2'
    exp_4 = 4
    var_4 = safe_eval(str_4)
    assert(var_4 == exp_4)

    str_5 = '8/0'

# Generated at 2022-06-25 12:31:18.159780
# Unit test for function safe_eval
def test_safe_eval():
    # without any locals
    str1 = 'True and false or not False'
    expected1 = True and False or not False
    ret1 = safe_eval(str1)
    assert ret1 == expected1
    # this should throw an exception
    str2 = 'True and false or not False and non_existent_var'
    expected2 = True and False or not False and None
    ret2 = safe_eval(str2, include_exceptions=True)
    assert ret2 == (expected2, None)
    # with locals
    str3 = '{{ mydata.username }}'
    mydata = {'username': 'johndoe'}
    expected3 = 'johndoe'
    ret3 = safe_eval(str3, mydata)
    assert ret3 == expected3
    # with locals and non-existent var


# Generated at 2022-06-25 12:31:25.946769
# Unit test for function safe_eval
def test_safe_eval():
    # This code will run the test in this file.'
    import sys
    import types
    import pytest
    #from test.lib import TestLoader
    #from test.lib import TestResult
    import unittest
    #from test.support import run_unittest
    test = unittest.TestCase()

    # import the testing framework
    import tests.utils.module_loader

    # This class contains the unit tests.
    class TestSafeEval(unittest.TestCase):

        # Each method in this class is a test to be run.
        def test_safe_eval_0(self):
            str_0 = 'grep booted /var/log/vmksummary.log | tail -n 1'
            var_0 = safe_eval(str_0)
            assert var_0 == str_0


# Generated at 2022-06-25 12:31:36.809704
# Unit test for function safe_eval
def test_safe_eval():

    # test for string
    str_0 = 'grep booted /var/log/vmksummary.log | tail -n 1'
    var_0 = safe_eval(str_0)
    assert var_0 == 'grep booted /var/log/vmksummary.log | tail -n 1'

    # test for variable
    var_1 = 'grep booted /var/log/vmksummary.log | tail -n 1'
    var_2 = safe_eval(var_1)
    assert var_2 == 'grep booted /var/log/vmksummary.log | tail -n 1'

    # test for list
    list_0 = ['grep booted /var/log/vmksummary.log | tail -n 1']
    var_3 = safe_eval(list_0)

# Generated at 2022-06-25 12:31:45.190737
# Unit test for function safe_eval
def test_safe_eval():
    #Test case 1
    str_1 = '1 + 2'
    var_1 = safe_eval(str_1).n

    #Test case 2
    str_2 = '1 + {{ two }}'
    var_2 = safe_eval(str_2).calculate()

    #Test case 3
    str_3 = '1 + {{ foo }}'
    var_3 = safe_eval(str_3).n

    #Test case 4
    str_4 = '{{ list }}'
    var_4 = safe_eval(str_4)

    #Test case 5
    str_5 = '{{ dict }}'
    var_5 = safe_eval(str_5)

    #Test case 6

# Generated at 2022-06-25 12:31:50.622185
# Unit test for function safe_eval
def test_safe_eval():
    """Testing the safe_eval function."""

    from ansible.module_utils.common.text.converters import container_to_text, to_native

    # test various valid input possibilities

# Generated at 2022-06-25 12:32:01.016894
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEFAULT_KEEP_REMOTE_FILES:
        str_0 = '[ {0} ]'.format(constants.DEFAULT_REMOTE_TMP)
        var_0 = safe_eval(str_0)
        str_1 = '[ {0} ]'.format(constants.DEFAULT_REMOTE_TMP_CONNECT_TIMEOUT)
        var_1 = safe_eval(str_1)
        str_2 = '[ {0} ]'.format(constants.DEFAULT_REMOTE_TMP_INTERMEDIATE_DIR)
        var_2 = safe_eval(str_2)
        str_3 = '[ {0} ]'.format(constants.DEFAULT_REMOTE_TMP_MAX_BYTES)
        var_3 = safe_eval(str_3)
        str

# Generated at 2022-06-25 12:32:11.693275
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval')

    variable_0 = 'ansible_default_ipv4'
    variable_1 = str
    variable_2 = dict
    dict_0 = dict
    dict_1 = dict
    dict_1['k1'] = variable_0
    dict_1['k2'] = variable_1
    dict_1['k3'] = variable_2
    dict_0['ansible_all_ipv4_addresses'] = dict_1
    dict_0['ansible_check_mode'] = False
    dict_0['ansible_connection'] = 'local'
    dict_0['ansible_connection_plugins'] = dict
    dict_0['ansible_default_ipv4'] = dict

# Generated at 2022-06-25 12:32:26.481008
# Unit test for function safe_eval
def test_safe_eval():
    print("Test case 0")
    print("Testing the safe_eval function.")

    print ("Test case 1")
    print ("Testing safe_eval('True')")
    result = safe_eval('True')
    assert result == True

    print ("Test case 2")
    print ("Testing safe_eval('False')")
    result = safe_eval('False')
    assert result == False

    print ("Test case 3")
    print ("Testing safe_eval('None')")
    result = safe_eval('None')
    assert result == None

    print ("Test case 4")
    print ("Testing safe_eval('false')")
    result = safe_eval('false')
    assert result == False

    print ("Test case 5")
    print ("Testing safe_eval('null')")
    result = safe_eval('null')
    assert result == None



# Generated at 2022-06-25 12:32:30.737645
# Unit test for function safe_eval
def test_safe_eval():
    expr_0 = 'a[1]'
    results = safe_eval(expr_0, globals())
    print(results)

# Main test program
if __name__ == '__main__':
    test_case_0()
    test_safe_eval()

# Generated at 2022-06-25 12:32:37.447707
# Unit test for function safe_eval
def test_safe_eval():
    print("Running safe_eval unit test")

    passed = True

    print("Test 0", end=' ')
    try:
        test_case_0()
        print("Passed")
    except Exception as e:
        print("Failed")
        print(e)
        passed = False
    print("-----")

    if passed:
        print("All safe_eval unit tests passed")
    else:
        print("All safe_eval unit tests failed")

# Dict used for testing the safe_eval function
# All dict keys should be legal for safe_eval to accept

# Generated at 2022-06-25 12:32:41.418407
# Unit test for function safe_eval
def test_safe_eval():
    print(safe_eval('True'))
    print(safe_eval('1 + 1'))
    print(safe_eval('["a"]'))
    print(safe_eval('[1, [1, 2]]'))

if __name__ == '__main__':
    test_case_0()
    test_safe_eval()
    print('OK')
    # EOF

# Generated at 2022-06-25 12:32:47.421871
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''

    assert safe_eval('3 + 2') == 5
    assert safe_eval('3 + 2') != 4
    assert safe_eval('[1,2,3,4]') == [1,2,3,4]
    assert safe_eval('(1,2,3,4)') == (1,2,3,4)
    assert safe_eval('{"a": "Hello", "b": "World"}') == {'a': 'Hello', 'b': 'World'}
    assert safe_eval('3 + 2', include_exceptions=True) == (5, None)
    assert safe_eval('[1,2,3,4]', include_exceptions=True) == ([1,2,3,4], None)

# Generated at 2022-06-25 12:32:57.572875
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(str_0) == str_0
    assert safe_eval('42') == 42
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('[]') == []
    assert safe_eval('()') == ()
    assert safe_eval('{}') == {}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('42 + 42') == 84

# Generated at 2022-06-25 12:33:05.598319
# Unit test for function safe_eval
def test_safe_eval():
    func_safe_eval_to_test = safe_eval

    # Mock "builtin.openssl_privatekey_info"
    # This is used internally to expose openssl_privatekey_info to the module
    # to avoid import time evaluation of this and other utilities.
    real_openssl_privatekey_info = builtins.openssl_privatekey_info

# Generated at 2022-06-25 12:33:13.069172
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys
    import os
    import ssl
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import container_to_text
    import random
    import string
    def test_case_0():
        str_0 = 'Testing the safe_eval function.'
        result = safe_eval(str_0)
        assert result == str_0

    def test_case_1():
        str_0 = 'Testing the safe_eval function.'
        result = safe_eval(str_0, {})
        assert result == str_0


# Generated at 2022-06-25 12:33:18.498713
# Unit test for function safe_eval
def test_safe_eval():
    # check if str_0 is correct
    if (safe_eval('Testing the safe_eval function.') != 'Testing the safe_eval function.'):
        print("str_0 is incorrect")

# Main function

# Generated at 2022-06-25 12:33:28.201241
# Unit test for function safe_eval
def test_safe_eval():

    # test case 0
    str_0 = 'Testing the safe_eval function.'
    ans_0 = safe_eval(str_0)
    assert ans_0 == 'Testing the safe_eval function.'

    # test case 1
    str_1 = "1 == 1"
    ans_1 = safe_eval(str_1)
    assert ans_1 == True

    # test case 2
    my_dict = {'a':'b'}
    str_2 = 'my_dict'
    ans_2 = safe_eval(str_2, {'my_dict': my_dict})
    assert ans_2 == my_dict

    # test case 3
    str_3 = "not 1 == 1"
    ans_3 = safe_eval(str_3)
    assert ans_3 == False

    # test case 4


# Generated at 2022-06-25 12:33:31.920912
# Unit test for function safe_eval
def test_safe_eval():
    # Just pass
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:33:37.596496
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1+1') == 3
    assert safe_eval('"testing"') == "testing"
    assert safe_eval('"testing"+"testing"') == "testingtesting"
    assert safe_eval('"testing" in "testing"') == True
    assert safe_eval('"testing" in "testing testing"') == True
    assert safe_eval('"nottesting" in "testing"') == False
    assert safe_eval('"nottesting" not in "testing"') == True
    assert safe_eval('"testing" not in "testing"') == False
    assert safe_eval('1 in [1,2]') == True
    assert safe_eval('1 in ["1",2]') == False

# Generated at 2022-06-25 12:33:40.647527
# Unit test for function safe_eval
def test_safe_eval():
    # Should return 'Testing the safe_eval function.'
    result = safe_eval(str_0)
    print(result)


# Generated at 2022-06-25 12:33:50.101284
# Unit test for function safe_eval
def test_safe_eval():
    # Test for type error
    try:
        safe_eval(None)
    except TypeError as e:
        print("TypeError: ", e.msg)
    try:
        safe_eval(None, None)
    except TypeError as e:
        print("TypeError: ", e.msg)
    try:
        safe_eval("Testing")
    except TypeError as e:
        print("TypeError: ", e.msg)
    try:
        safe_eval("Testing", "None")
    except TypeError as e:
        print("TypeError: ", e.msg)
    # Test for SyntaxError
    try:
        safe_eval("Testing\n")
    except SyntaxError as e:
        print("SyntaxError: ", e.msg)

# Generated at 2022-06-25 12:33:58.764871
# Unit test for function safe_eval
def test_safe_eval():
    pass
    # from ansible.module_utils.common.text.converters import safe_eval
    # str_0 = 'Testing the safe_eval function.'
    # result = safe_eval(
    #     str_0
    # )
    # assert result == 'Testing the safe_eval function.'
    # str_0 = 'Testing the safe_eval function.'
    # result = safe_eval(
    #     str_0,
    #     {'foo': 'bar'}
    # )
    # assert result == 'Testing the safe_eval function.'
    # str_0 = 'foo.bar'
    # result = safe_eval(
    #     str_0,
    #     {'foo': 'bar'}
    # )
    # assert result == 'bar.bar'
    # str_0 = '

# Generated at 2022-06-25 12:34:10.158805
# Unit test for function safe_eval
def test_safe_eval():
    # List of invalid expressions
    expr_list_0 = [
        'false && true',
        '"true"',
        'null and false',
        'true > false',
        'True and False',
        '3+3',
        '""',
        '3 <= 3',
        '"asdfasdf"',
        'True or False',
        '{ "blah": "foo", "blee": "bar" }',
        '18',
        '{}',
        '9*9',
        '{ "foo": "bar" }',
        'True',
        'False',
        'int()',
    ]


# Generated at 2022-06-25 12:34:16.236896
# Unit test for function safe_eval
def test_safe_eval():
    # str_0 = 'Testing the safe_eval function.'
    # result = safe_eval(str_0)
    # assert (result == 'Testing the safe_eval function.')

    # str_0 = '{{ expr }}'
    # result = safe_eval(str_0)
    # assert (result == 'Testing the safe_eval function.')

    str_0 = '{{ expr }}'
    result = safe_eval(str_0)
    assert (True)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:34:17.512294
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print_error_msg(e)
        raise



# Generated at 2022-06-25 12:34:20.312601
# Unit test for function safe_eval
def test_safe_eval():
    # If a particular test case fails, add the locals() dictionary
    # for that test case as a parameter to safe_eval(...). This
    # will allow safe_eval to find any variables that need to be
    # defined in order for the test case to pass.
    #
    # For example:
    #   safe_eval(test_case_0(), locals())

    safe_eval(test_case_0())



# Generated at 2022-06-25 12:34:32.258221
# Unit test for function safe_eval
def test_safe_eval():
    # One single value
    expr_0 = 'true'
    assert safe_eval(expr_0) is True

    # One single value, but not json-ified
    expr_0 = 'True'
    assert safe_eval(expr_0) is True

    # An expression with operators
    expr_1 = 'true and false'
    assert safe_eval(expr_1) is False

    # An expression with operators and grouping
    expr_2 = '(true and false) or true'
    assert safe_eval(expr_2) is True

    # A list
    expr_3 = '[1, 2, 3, 4, 5]'
    assert safe_eval(expr_3) == [1, 2, 3, 4, 5]

    # A list in a list

# Generated at 2022-06-25 12:34:39.312905
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    var_0 = safe_eval(str_0)

    assert var_0 == 'Q'

    str_1 = 'Q/5'
    var_1 = safe_eval(str_1)

    assert var_1 == 'Q/5'


# Generated at 2022-06-25 12:34:45.180149
# Unit test for function safe_eval
def test_safe_eval():

    test_case_0()

# Retrieve all the test functions from this module
from ansible.module_utils.facts.network.base import *
all_functions = inspect.getmembers(sys.modules[__name__], inspect.isfunction)

# Run all the functions starting with 'test_'
for name, test_func in all_functions:
    if name.startswith('test_'):
        test_func()

# Generated at 2022-06-25 12:34:51.497123
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.constants as C
    import ansible.module_utils.common.text.converters as converters
    import ast
    import sys

    C.DEFAULT_VAULT_PASSWORD_FILE = "~/.vault_pass.txt"
    C.ANSIBLE_CONFIG = "ansible.cfg"
    # print("Executing " + sys.argv[0])
    # safe_eval(sys.argv[1])
    print("Resetting all statics")
    converters.container_to_text = container_to_text
    converters.to_native = to_native
    converters.safe_eval = safe_eval
    test_case_0()

# Generated at 2022-06-25 12:35:01.224749
# Unit test for function safe_eval
def test_safe_eval():
    t = "Q"
    actual = safe_eval(t)
    expected = "Q"
    assert actual == expected
    t = "hello"
    actual = safe_eval(t)
    expected = "hello"
    assert actual == expected
    t = "goodbye"
    actual = safe_eval(t)
    expected = "goodbye"
    assert actual == expected
    t = ""
    actual = safe_eval(t)
    expected = ""
    assert actual == expected
    t = "Z"
    actual = safe_eval(t)
    expected = "Z"
    assert actual == expected

    t = "Q"
    actual = safe_eval(t)
    expected = "Q"
    assert actual == expected
    t = "hello"
    actual = safe_eval(t)

# Generated at 2022-06-25 12:35:06.115781
# Unit test for function safe_eval
def test_safe_eval():
    # Test 0
    var_0 = "1 + 2"
    assert safe_eval(var_0) == 3, "Wrong answer."


# Generated at 2022-06-25 12:35:10.392837
# Unit test for function safe_eval
def test_safe_eval():
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    print(the_exception)
    assert the_exception
    assert the_exception.args[0] == "invalid expression (Q)"

# Generated at 2022-06-25 12:35:16.601550
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:19.950515
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = ['a', 1, None, True]
    str_0 = container_to_text(list_0, 'ast')
    var_0 = safe_eval(str_0)
    assert var_0 == list_0


# Generated at 2022-06-25 12:35:29.141146
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    str_1 = '0'
    str_2 = 'Q0'
    var_0 = safe_eval(str_0)
    assert var_0 == 'Q', 'Failed to assert that %s is equal to Q' % repr(var_0)
    var_1 = safe_eval(str_1)
    assert var_1 == 0, 'Failed to assert that %s is equal to 0' % repr(var_1)
    var_2 = safe_eval(str_2)
    assert var_2 == 'Q0', 'Failed to assert that %s is equal to Q0' % repr(var_2)
    str_3 = '12'
    var_3 = safe_eval(str_3)

# Generated at 2022-06-25 12:35:30.129366
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:35:40.423768
# Unit test for function safe_eval
def test_safe_eval():
    with open('safe_eval_tests.txt', 'r') as test_cases:
        for test in test_cases:
            test = test.strip()
            if len(test) == 0 or test.startswith('#'):
                continue
            if test.startswith('>>> '):
                test_str = test[4:]
                (result, err) = safe_eval(test_str, include_exceptions=True)
                print("{} | {}".format(result, err))
            else:
                print("{}".format(safe_eval(test)))



# Generated at 2022-06-25 12:35:49.229420
# Unit test for function safe_eval
def test_safe_eval():
    # No module specified
    var_0 = 'Q'

    # No module specified - test 2
    var_1 = safe_eval('Q')

    # Module specified
    var_2 = safe_eval('Q', {'Q': 'R'})

    # Module specified - test 2
    var_3 = safe_eval('P', {'Q': 'R'})

    # One module specified
    var_4 = ''

    # One module specified - test 2
    var_5 = safe_eval('Q', {'Q': ''})

    # One module specified - test 3
    var_6 = safe_eval('Q', {'Q': 'R'})

    # Multiple modules specified
    var_7 = 'R'

    # Multiple modules specified - test 2

# Generated at 2022-06-25 12:35:59.540373
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "1+1"
    var_0 = safe_eval(str_0)
    assert var_0 == 2
    str_1 = '["a", "b", "c"]'
    var_1 = safe_eval(str_1)
    assert var_1 == ["a", "b", "c"]
    str_2 = '["a", "b", {"foo":"bar"}]'
    var_2 = safe_eval(str_2)
    assert var_2 == ["a", "b", {"foo": "bar"}]
    str_3 = '["a", "b", {"a": "b", "c":"d"}]'
    var_3 = safe_eval(str_3)
    assert var_3 == ["a", "b", {"a": "b", "c": "d"}]
   

# Generated at 2022-06-25 12:36:01.418654
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    assert safe_eval(str_0) == 'Q'

# Generated at 2022-06-25 12:36:04.124878
# Unit test for function safe_eval
def test_safe_eval():
    print("Inside test safe eval")
    # Check if 1 is returned by the function
    assert test_case_0() == None

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:36:08.125997
# Unit test for function safe_eval
def test_safe_eval():
    # expected exception
    try:
        test_case_0()
    except Exception:
        pass

# def main():
#     test_safe_eval()
#     # call function that tests the safe_eval function
#     # safe_eval() is called inside the test_safe_eval function
#
# if __name__ == "__main__":
#     # calling main function
#     main()

# Generated at 2022-06-25 12:36:10.221417
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    var_0 = safe_eval(str_0)
    assert "Q" == var_0, "String expected to be Q"



# Generated at 2022-06-25 12:36:19.502937
# Unit test for function safe_eval
def test_safe_eval():
    print("************** test_safe_eval **************")
    # Example 1
    str_0 = "\"{{ vars['host_name'] + '-fact' }}\""
    var_0 = safe_eval(str_0)
    print('var_0: ', var_0)

    # Example 2
    str_1 = "{{ foo[bar] }}"
    var_1 = safe_eval(str_1)
    print('var_1: ', var_1)

    # Example 3
    str_2 = "[1,2,3,4,5]"
    var_2 = safe_eval(str_2)
    print('var_2: ', var_2)

    # Example 4
    str_3 = "{{ ansible_local['additional_facts']['foo']['bar'] }}"


# Generated at 2022-06-25 12:36:28.062910
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True  # constant
    assert safe_eval('None') is None  # constant
    assert safe_eval('7') is 7  # constant
    assert safe_eval('7') == 7  # constant
    assert safe_eval('True') == True  # constant
    assert safe_eval('False') == False  # constant
    assert safe_eval('None') == None  # constant
    assert safe_eval('7') == 7  # constant
    assert safe_eval('2 + 3') == 5  # binary operator
    assert safe_eval('2 - 3') == -1  # binary operator
    assert safe_eval('2 * 3') == 6  # binary operator
    assert safe_eval('2 / 3') == 0.6666666666666666  # binary operator
    assert safe_eval('2 ** 3') == 8  # binary

# Generated at 2022-06-25 12:36:32.993504
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        sys.exit(1)


if __name__ == "__main__":
    # test_safe_eval()
    from pudb import set_trace; set_trace()
    str_0 = "{{ '1.2' > '1.3' }}"
    var_0 = safe_eval(str_0)
    print(var_0)

# Generated at 2022-06-25 12:36:46.470553
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:51.424694
# Unit test for function safe_eval
def test_safe_eval():
    try:
        if C.DEFAULT_DEBUG:
            print('TESTING safe_eval PLUGIN')

        if C.DEFAULT_DEBUG:
            print('TESTING test_case_0')
        test_case_0()
        if C.DEFAULT_DEBUG:
            print('PASSED')
    except:
        print('EXCEPTION RAISED')
        print(sys.exc_info())
        raise


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:36:58.108201
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    result_0 = safe_eval(str_0)
    assert C.STRING_TYPES == type(result_0)
    str_0 = "alice['a'] + 1"
    result_0 = safe_eval(str_0, dict(alice=dict(a=1)))
    assert type(result_0) == type(int())
    str_0 = "alice['a'] + 1"
    result_0 = safe_eval(str_0, dict(alice=dict(a=1.0)))
    assert type(result_0) == type(1.0)
    locals_1 = dict(alice=dict(a=1))
    str_0 = "alice['a'] + 1"

# Generated at 2022-06-25 12:37:02.226986
# Unit test for function safe_eval
def test_safe_eval():
    actions_result = test_case_0()
    if not actions_result:
        raise Exception("Test Case 0 failed: safe_eval")

# Main function for test execution
if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:12.708620
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = ''
    var_0 = safe_eval(str_0)
    str_1 = '12345'
    var_1 = safe_eval(str_1)
    str_2 = '-12345'
    var_2 = safe_eval(str_2)
    str_3 = 'type(foo).__name__'
    var_3 = safe_eval(str_3)
    str_4 = '[1, 2, foo]'
    var_4 = safe_eval(str_4)
    str_5 = '{1: 2, 3: foo}'
    var_5 = safe_eval(str_5)
    str_6 = '(1, 2, foo)'
    var_6 = safe_eval(str_6)
    str_7 = '"foo"'

# Generated at 2022-06-25 12:37:18.991443
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("Q") is 'Q'
    assert safe_eval("{{foo}}") is '{{foo}}'
    assert safe_eval("a | b", dict(a="a", b=dict(c="c"))) == "a | b"
    # Calling a python function is not safe, we should get back the original expression
    assert safe_eval("call()", locals=dict(call=lambda: "foo")) == "call()"
    assert safe_eval("{{foo()}}") == "{{foo()}}"
    assert safe_eval("foo[1]", dict(foo=[1, 2, 3])) == 2
    assert safe_eval("foo[1]", dict(foo=dict(a=1, b=2, c=3))) == 2

# Generated at 2022-06-25 12:37:20.857536
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info < (2, 7):
        test_case_0()
        test_case_0()



# Generated at 2022-06-25 12:37:22.473158
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:37:25.484869
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    var_0 = safe_eval(str_0)

# Generated from test_function at 2020-06-30 19:01:13.549305


# Generated at 2022-06-25 12:37:34.343123
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Q'
    var_0 = safe_eval(str_0)
    # Check variable var_0 type
    assert isinstance(var_0, string_types)

    str_0 = '4'
    var_0 = safe_eval(str_0)
    # Check variable var_0 type
    assert isinstance(var_0, int)

    str_0 = u'Q'
    var_0 = safe_eval(str_0)
    # Check variable var_0 type
    assert isinstance(var_0, string_types)

    str_0 = u'4'
    var_0 =safe_eval(str_0)
    # Check variable var_0 type
    assert isinstance(var_0, int)


# Generated at 2022-06-25 12:37:48.154561
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
        # successful test
        return {'success': 'true'}
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        trace = ''.join('!! ' + line for line in lines)
        return {'success': 'false', 'trace': trace}

# --------------------------------------------------------------------------------------------------


# Generated at 2022-06-25 12:37:58.464602
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    expression = ('Q')
    expected_result = safe_eval(expression)
    actual_result = 'Q'
    assert expected_result == actual_result
    # Test case 1
    expression = ('Q')
    expected_result = safe_eval(expression)
    actual_result = 'Q'
    assert expected_result == actual_result
    # Test case 2
    expression = ('Q')
    expected_result = safe_eval(expression)
    actual_result = 'Q'
    assert expected_result == actual_result
    # Test case 3
    expression = ('Q')
    expected_result = safe_eval(expression)
    actual_result = 'Q'
    assert expected_result == actual_result
    # Test case 4
    expression = ('Q')

# Generated at 2022-06-25 12:38:06.635634
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'Q'
    var_1 = safe_eval(str_1)
    print ('var_1:')
    print (var_1)
    print ('type:')
    print (type(var_1))
    str_2 = "{{ Q }}"
    var_2 = safe_eval(str_2)
    print ('var_2:')
    print (var_2)
    print ('type:')
    print (type(var_2))
    str_3 = 'mytest.test_var'
    var_3 = safe_eval(str_3)
    print ('var_3:')
    print (var_3)
    print ('type:')
    print (type(var_3))
    str_4 = "'mytest.test_var' in groups"
    var_4

# Generated at 2022-06-25 12:38:16.892382
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("2 + 2") == 4
    assert safe_eval("None") is None
    assert safe_eval("()") == ()
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("[]") == []
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{}") == {}
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("{'foo': 'bar', 'baz': 'quux'}") == {'foo': 'bar', 'baz': 'quux'}


# Generated at 2022-06-25 12:38:27.779576
# Unit test for function safe_eval
def test_safe_eval():
    pass

if __name__ == "__main__":
    # sys.setrecursionlimit(10000)     # this is to silence the default 1000
    sys.setrecursionlimit(1000000)  # this is to silence the default 1000

    if len(sys.argv) > 1:
        try:
            test_name = sys.argv[1]
            test_case = getattr(sys.modules[__name__], test_name)
            test_case()
            print("Passed test case: " + test_name)
        except AttributeError:
            print("No test case named: " + test_name)
        except RecursionError:
            print("RecursionError: maximum recursion depth exceeded")
    else:
        test_safe_eval()

# Generated at 2022-06-25 12:38:28.706290
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: Do we need to test this?
    pass


# Generated at 2022-06-25 12:38:38.871720
# Unit test for function safe_eval
def test_safe_eval():
    #
    # normal cases
    #

    expr_0 = 'Q'
    expected_0 = 'Q'
    actual_0 = safe_eval(expr_0)
    if expected_0 != actual_0:
        sys.stderr.write('expected: %s\n' % to_native(expected_0))
        sys.stderr.write('actual  : %s\n' % to_native(actual_0))
        assert expected_0 == actual_0

    expr_1 = 'True'
    expected_1 = True
    actual_1 = safe_eval(expr_1)
    if expected_1 != actual_1:
        sys.stderr.write('expected: %s\n' % to_native(expected_1))

# Generated at 2022-06-25 12:38:40.022735
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('[1,2,3]')
    assert result != '[1,2,3]'
    assert result != 'Q'

# Generated at 2022-06-25 12:38:44.039321
# Unit test for function safe_eval
def test_safe_eval():
    # Set argument prompt to true, so that we get prompted with all the possible tests
    sys.argv.append('-p')
    import ansible.utils.test_ansible_module as test_ansible_module

    test_ansible_module.test_module()


if __name__ == "__main__":
    test_safe_eval()

    # test_case_0()

# Generated at 2022-06-25 12:38:45.545061
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Read the file.

# Generated at 2022-06-25 12:38:58.116915
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{{foo}}'
    var_0 = safe_eval(str_0)
    # call function safe_eval with argument str_0
    var_1 = safe_eval(str_0)
    # check that var_0 and var_1 contain the same value
    assert var_0 == var_1


# Generated at 2022-06-25 12:39:00.898861
# Unit test for function safe_eval
def test_safe_eval():
    expr = '1 + 1'
    actual = safe_eval(expr)
    expected = 2
    assert actual == expected


# Generated at 2022-06-25 12:39:02.032296
# Unit test for function safe_eval
def test_safe_eval():
    # Test a single-character string
    assert test_case_0() == 'Q'


# Generated at 2022-06-25 12:39:09.835376
# Unit test for function safe_eval
def test_safe_eval():
    # Test #0
    str_0 = 'Q'
    var_0 = safe_eval(str_0)
    assert var_0 == 'Q'

    # Test #1
    str_1 = '\'Q\''
    var_1 = safe_eval(str_1)
    assert var_1 == 'Q'

    # Test #2
    str_2 = '["Q"]'
    var_2 = safe_eval(str_2)
    assert var_2 == ['Q']

    # Test #3
    str_3 = '["Q"]'
    var_3 = safe_eval(str_3)
    assert var_3 == ['Q']

    # Test #4
    str_4 = '{"Q": "V"}'
    var_4 = safe_eval(str_4)
    assert var

# Generated at 2022-06-25 12:39:12.290353
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_bytes
    # Test case 0
    try:
        test_case_0()
    except Exception:
        print(sys.exc_info())
        raise



# Generated at 2022-06-25 12:39:21.083882
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: correct input
    ans, err = safe_eval('True', include_exceptions=True)
    assert ans is True, 'test_safe_eval: actual: {}'.format(ans)
    assert err is None, 'test_safe_eval: actual: {}'.format(err)
    ans, err = safe_eval('False', include_exceptions=True)
    assert ans is False, 'test_safe_eval: actual: {}'.format(ans)
    assert err is None, 'test_safe_eval: actual: {}'.format(err)
    ans, err = safe_eval('null', include_exceptions=True)
    assert ans is None, 'test_safe_eval: actual: {}'.format(ans)
    assert err is None, 'test_safe_eval: actual: {}'.format(err)
    ans

# Generated at 2022-06-25 12:39:25.032247
# Unit test for function safe_eval
def test_safe_eval():
    with open('test_safe_eval.txt') as data_file:
        tests = data_file.readlines()
    for t in tests:
        a, b = t.strip().split('|')
        print(a, ' --> ', b)
        result = safe_eval(a)
        if eval(b) != result:
            print('Error: ' + a + ' --> ' + str(result) + ' not ' + str(b))
        assert(eval(b) == result)


# Generated at 2022-06-25 12:39:30.095024
# Unit test for function safe_eval
def test_safe_eval():
    # When we are unable to evaluate a string, an exception is raised
    str_1 = 'a, b = b, a'
    assert safe_eval(str_1) == 'a, b = b, a'
    # When we can evaluate the string, the evaluated string is returned
    str_2 = 'hello'
    assert safe_eval(str_2) == 'hello'
    # When we can evaluate the string, the evaluated string is returned
    str_3 = 'hello, world'
    assert safe_eval(str_3) == 'hello, world'
    # When the string contains quotes, the evaluated string is returned
    str_4 = 'hello, "world"'
    assert safe_eval(str_4) == 'hello, "world"'
    # When the string contains a tuple, the evaluated string is returned