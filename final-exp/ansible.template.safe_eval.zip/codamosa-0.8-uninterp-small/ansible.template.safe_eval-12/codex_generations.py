

# Generated at 2022-06-25 12:29:38.876234
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:29:46.720853
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("-279.0") == -279.0)
    try:
        safe_eval("'{'+'}'")
    except SyntaxError as e:
        assert("invalid syntax" in e.msg)
    assert(safe_eval("[1, 2, 3]", {}, True)[0] == [1, 2, 3])
    assert(safe_eval("'hi'", {}, True)[0] == 'hi')
    dict_0 = {'a':'test', 'b':'test1'}
    assert(safe_eval("{'a':'test', 'b':'test1'}") == dict_0)
    assert(isinstance(safe_eval("{'a':'test', 'b':'test1'}"), dict))

# Generated at 2022-06-25 12:29:57.176618
# Unit test for function safe_eval
def test_safe_eval():
    # Test number 0
    expr = "-279.0"
    result = safe_eval(expr)
    expected = -279.0
    assert float(result) == expected, f"Test number 0 failed: expected: {expected}, got: {result}"
    print(f"Test number 0 passed: {result} == {expected}")

    # Test number 1
    expr = "True or False"
    result = safe_eval(expr)
    expected = True
    assert float(result) == expected, f"Test number 1 failed: expected: {expected}, got: {result}"
    print(f"Test number 1 passed: {result} == {expected}")

    # Test number 2
    expr = "a or b"
    locals = {'a': True, 'b': False}
    result = safe_eval(expr, locals=locals)

# Generated at 2022-06-25 12:30:05.580504
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("3 + 4 + 5", locals=None, include_exceptions=False)
    assert result == 12
    result = safe_eval("3 + 4 + 5", locals=None, include_exceptions=True)
    assert result[0] == 12
    result = safe_eval("3 + 4 + 5", locals=None, include_exceptions=True)
    assert isinstance(result[0], int)
    assert result[1] == None

    result = safe_eval("3.0 + 4.0 + 5.0", locals=None, include_exceptions=False)
    assert result == 12.0
    result = safe_eval("3.0 + 4.0 + 5.0", locals=None, include_exceptions=True)
    assert result[0] == 12.0

# Generated at 2022-06-25 12:30:09.223130
# Unit test for function safe_eval
def test_safe_eval():
    ab_expr_0 = "case_0"
    ab_expr_1 = "var_1"
    func_0 = [ab_expr_0, ab_expr_1]
    var_0 = safe_eval(func_0)
    var_1 = safe_eval(func_0, locals())


# Generated at 2022-06-25 12:30:14.966626
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    test_case_0()
    # Test case 1
    var_0 = safe_eval("6 - 5")
    assert var_0 == 1
    # Test case 2
    var_0 = safe_eval("6+5")
    assert var_0 == 11
    # Test case 3
    var_0 = safe_eval("True")
    assert var_0 is True
    # Test case 4
    var_0 = safe_eval("False")
    assert var_0 is False
    # Test case 5
    var_0 = safe_eval("'string'")
    assert var_0 == 'string'
    # Test case 6
    var_0 = safe_eval("None")
    assert var_0 is None
    # Test case 7
    var_0 = safe_eval("True and False")
   

# Generated at 2022-06-25 12:30:22.837504
# Unit test for function safe_eval
def test_safe_eval():
    # Safe expressions
    expr1 = "2 + 3"
    expr2 = "-1 * 2"
    expr3 = "'a' != 'b'"
    expr4 = "1 + (1 if 2 == 3 else 1)"
    expr5 = "if 2 == 3: 1 else: 1"
    expr6 = "if 2 == 3: 1"
    expr7 = "1 if 2 == 3 else 1"
    expr8 = "True"
    expr9 = "False"
    expr10 = "1 == 1"
    expr11 = "1 == 2"
    expr12 = "3.14159"
    expr13 = "3.14159 if 2 == 3 else 3"
    expr14 = "\"This is a string\""
    expr15 = "{'key': 'value'}"

# Generated at 2022-06-25 12:30:33.870500
# Unit test for function safe_eval
def test_safe_eval():
    ut_safe_eval_0()
    ut_safe_eval_1()
    ut_safe_eval_2()
    ut_safe_eval_3()
    ut_safe_eval_4()
    ut_safe_eval_5()
    ut_safe_eval_6()
    ut_safe_eval_7()
    ut_safe_eval_8()
    ut_safe_eval_9()
    ut_safe_eval_10()
    ut_safe_eval_11()
    ut_safe_eval_12()
    ut_safe_eval_13()
    ut_safe_eval_14()
    ut_safe_eval_15()
    ut_safe_eval_16()
    ut_safe_eval_17()
    ut_safe_eval_18()
    ut_safe_eval_19()

# Generated at 2022-06-25 12:30:44.359322
# Unit test for function safe_eval
def test_safe_eval():
    for safe_class in SAFE_NODES:
        assert safe_eval(safe_class) == safe_class
        # TODO: assert safe_eval(safe_class(), include_exceptions=True)
        #       is None

    # Test with a call to a function
    assert safe_eval("len([])") == 0

    # Test with a call to a builtin
    assert safe_eval("len([])") == 0

    # Test with a call to a not-builtin
    CALL_ENABLED.append("ansible")
    assert safe_eval("ansible([])") == "[]"

    # Test with a call to a builtin but not enabled
    assert safe_eval("str([])") is "[]"

    # Test with a call to a builtin but not enabled
    assert safe_eval("len([])") == 0

# Generated at 2022-06-25 12:30:52.341337
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 5   # add
    assert safe_eval('2 - 3') == -1  # subtract
    assert safe_eval('2 * 3') == 6   # multiply
    assert safe_eval('2 / 3') == 0.6666666666666666  # divide
    assert safe_eval('2 ** 3') == 8  # power
    assert safe_eval('("a", "b")') == ('a', 'b')  # tuple
    assert safe_eval('["a", "b"]') == ['a', 'b']  # list
    assert safe_eval('{"a": "b"}') == {'a': 'b'}  # dict
    assert safe_eval("True") is True  # boolean
    assert safe_eval("False") is False  # boolean
    assert safe_eval("None") is None  # null

# Generated at 2022-06-25 12:31:01.932162
# Unit test for function safe_eval
def test_safe_eval():
    print("\nBEGIN UNIT TEST: safe_eval")
    print("\n** Test case 0:")
    test_case_0()

    # Test needs to be updated before re-enabling
    #print("\n** Test case 1:")
    #test_case_1()
    print("\nEND UNIT TEST: safe_eval")


if __name__ == "__main__":
    if sys.version_info[0] >= 3:
        test_safe_eval()
    else:
        print("Needed Python 3 to run unit tests")
        sys.exit(1)

# Generated at 2022-06-25 12:31:04.681270
# Unit test for function safe_eval
def test_safe_eval():
    complex_0 = '-("abc123" + "abcd1234")'
    result, exception = safe_eval(complex_0, include_exceptions=True)

    if result == "abc123abcd1234":
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:31:05.485841
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == 0, "test_case_0()"

# Generated at 2022-06-25 12:31:15.274879
# Unit test for function safe_eval
def test_safe_eval():
    expr = u"a['a'] == 0 and 'b' in a"
    eval_result = safe_eval(expr)
    print(type(eval_result))
    print(expr, "-", eval_result)

    expr = "a['a'] == 0 and 'b' in a"
    eval_result = safe_eval(expr)
    print(type(eval_result))
    print(expr, "-", eval_result)

    expr = 'myvar == "foo"'
    result = safe_eval(expr)
    print(type(result))
    print(expr, "-", result)

    expr = "'foo' == 'foo'"
    result = safe_eval(expr)
    print(type(result))
    print(expr, "-", result)

    expr = "myvar in [ 1, 2, 3 ]"


# Generated at 2022-06-25 12:31:23.982799
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval("value_0")
    assert var_0 is "value_0"
    int_0 = -1
    var_1 = safe_eval(int_0)
    assert var_1 is -1
    var_2 = safe_eval('[value_0, value_1]')
    assert var_2 is ['value_0', 'value_1']
    float_0 = -279.0
    var_3 = safe_eval(float_0)
    assert var_3 is -279.0
    var_4 = safe_eval('{"key_0": "value_1", "key_1": "value_0"}')
    assert var_4 == {"key_0": "value_1", "key_1": "value_0"}
    str_0 = "key_0"
   

# Generated at 2022-06-25 12:31:27.706660
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        fail_msg = "Unable to perform safe eval: " + str(e)
        assert False, fail_msg



# Generated at 2022-06-25 12:31:31.445186
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval...')

    try:
        test_case_0()
        print('safe_eval test passed')
    except Exception as e:
        print('safe_eval test failed with exception: ' + str(e))
        sys.exit(1)



# Generated at 2022-06-25 12:31:32.960597
# Unit test for function safe_eval
def test_safe_eval():
    s = '{"somekey": [1,2,3]}'
    fail_eval = safe_eval(s)
    right_eval = eval(s)
    assert fail_eval == right_eval




# Generated at 2022-06-25 12:31:42.025153
# Unit test for function safe_eval
def test_safe_eval():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class TestSafeEval(unittest.TestCase):

        def setUp(self):
            self.float_0 = -279.0
            self.float_0_str = "-279.0"
            self.float_0_eval = safe_eval(self.float_0)

            self.float_1 = +212.0
            self.float_1_str = "+212.0"
            self.float_1_eval = safe_eval(self.float_1)

            self.float_2 = -341.0

# Generated at 2022-06-25 12:31:54.793663
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:03.676725
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_set = safe_eval('[True, False, None]')
        test_dict = safe_eval('{ "foo" : "bar" }')
        test_math = safe_eval('(1 * 2) + 4')
        test_str = safe_eval('"this is a string"')
    except Exception as e:
        print(e)
    else:
        assert isinstance(test_set, list)
        assert isinstance(test_dict, dict)
        assert test_math == 6
        assert test_str == 'this is a string'


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:04.595391
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:32:15.842257
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('_ansible_retry') is not None
    assert safe_eval('_ansible_retry', include_exceptions=True)[0] is not None
    assert safe_eval('_ansible_retry', include_exceptions=True)[1] is None
    assert safe_eval("[1,2,3]", include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval("{1:[2]}", include_exceptions=True)[0] == {1: [2]}

    try:
        assert safe_eval("a + 2", include_exceptions=True)[0] == 2
        assert False, 'Eval of a + 2 should not have passed'
    except:
        pass

# Generated at 2022-06-25 12:32:26.527936
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('1+1')
    assert result == 2

    result = safe_eval('a_list_variable')
    assert result == 'a_list_variable'

    result = safe_eval('name in groups')
    assert result == 'name in groups'

    result = safe_eval('a.b.c', dict(a=dict(b=dict(c='foo'))))
    assert result == 'foo'

    result = safe_eval('a.b.c', dict(a=dict(b=dict(c='foo'))))
    assert result == 'foo'

    result = safe_eval('a.b.c', dict(a=dict(b=dict(c='foo'))))
    assert result == 'foo'


# Generated at 2022-06-25 12:32:35.809589
# Unit test for function safe_eval
def test_safe_eval():

    # test case with invalid syntax
    expr, exception = safe_eval("[1,2", include_exceptions=True)
    print(expr)
    print(exception)

    # test case with invalid expression
    expr, exception = safe_eval("[1,2].func()", include_exceptions=True)
    print(expr)
    print(exception)

    # test case with invalid expression
    expr = safe_eval("[1,2].append(2)")
    print(expr)

    # test case with valid expression
    expr = safe_eval("[1,2]")
    print(expr)

if __name__ == '__main__':
    test_case_0()
    test_safe_eval()

# Generated at 2022-06-25 12:32:37.674997
# Unit test for function safe_eval
def test_safe_eval():
    # test case 0
    test_case_0()



# Generated at 2022-06-25 12:32:39.115577
# Unit test for function safe_eval
def test_safe_eval():
    # valid expressions
    test_case_0()

# Print function with the function name and its arguments.

# Generated at 2022-06-25 12:32:48.872157
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    var_0 = safe_eval(str_0)

    str_1 = 'a'
    var_1 = safe_eval(str_1)

    str_2 = 'a.b'
    var_2 = safe_eval(str_2)

    str_3 = 'a.b.c'
    var_3 = safe_eval(str_3)

    str_4 = 'a.b.c.d'
    var_4 = safe_eval(str_4)

    str_5 = 'a.b.c.d.e'
    var_5 = safe_eval(str_5)

    str_6 = 'a.b.c.d.e.f.g.h.i.j'

# Generated at 2022-06-25 12:32:53.836157
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    res_1 = safe_eval(str_0)
    assert res_1 == '_ansible_retry'

    str_2 = '_ansible_item'
    res_3 = safe_eval(str_2)
    assert res_3 == '_ansible_item'

    # ... and other tests have been removed ...




# Generated at 2022-06-25 12:33:01.104520
# Unit test for function safe_eval
def test_safe_eval():
    # Test to check the functionality of safe_eval
    str_1 = '1'
    var_1 = safe_eval(str_1)
    print(var_1)
    print(type(var_1))
    str_2 = '[1,2,3]'
    var_2 = safe_eval(str_2)
    print(var_2)
    print(type(var_2))
    str_3 = '{"k1":"v1", "k2":"v2"}'
    var_3 = safe_eval(str_3)
    print(var_3)
    print(type(var_3))
    str_4 = 'foo'
    var_4 = safe_eval(str_4)
    print(var_4)
    print(type(var_4))
    str_5 = ''

# Generated at 2022-06-25 12:33:08.342500
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    var_0 = safe_eval(str_0)
    # <Value expr='_ansible_retry'/>
    # Will fail because retry never gets set in the scope
    assert  var_0 == safe_eval(str_0)
    # <Value expr='a_list_variable'/>



# Generated at 2022-06-25 12:33:12.282020
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print('test 0 failed')
    print('test 0 passed')


if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:33:13.955026
# Unit test for function safe_eval
def test_safe_eval():
    var = safe_eval('[]', include_exceptions=True)
    print(var)



# Generated at 2022-06-25 12:33:23.184656
# Unit test for function safe_eval
def test_safe_eval():
    x = safe_eval('[1, 2, 3]')
    assert type(x) is list
    assert x == [1, 2, 3]
    x = safe_eval('{"a": "b"}')
    assert type(x) is dict
    assert x == {"a": "b"}
    x = safe_eval('(True, False)')
    assert type(x) is tuple
    assert x == (True, False)
    x = safe_eval('False')
    assert type(x) is bool
    assert x == False
    x = safe_eval('False or True')
    assert type(x) is bool
    assert x == True
    x = safe_eval('False and True')
    assert type(x) is bool
    assert x == False
    x = safe_eval('False or True and True')
   

# Generated at 2022-06-25 12:33:31.734385
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "['a', 'b', 'c']"
    var_0 = safe_eval(str_0)
    assert var_0 == ['a', 'b', 'c'], 'Expected values to be equal'

    str_0 = '{"a": "b", "b": "c"}'
    var_0 = safe_eval(str_0)
    assert var_0 == {'a': 'b', 'b': 'c'}, 'Expected values to be equal'

    str_0 = '{ a: b, b: c}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{ a: b, b: c}', 'Expected values to be equal'

    str_0 = '{"a": "b", "b": "c"}'
    var_

# Generated at 2022-06-25 12:33:32.462188
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:33:33.616609
# Unit test for function safe_eval
def test_safe_eval():
  # Test case 0
  test_case_0()


if __name__ == '__main__':
  test_safe_eval()

# Generated at 2022-06-25 12:33:38.065811
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:48.118407
# Unit test for function safe_eval
def test_safe_eval():
    print('Test safe_eval')
    
    # Test 0
    print('    Test 0')
    print('        Input:')

# Generated at 2022-06-25 12:33:57.304073
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'a == b'
    var_0 = safe_eval(str_0)
    print(var_0)
    print('str_0: ' + str_0)

    str_1 = 'a >= b'
    var_1 = safe_eval(str_1)
    print(var_1)
    print('str_1: ' + str_1)

    str_2 = 'a + b'
    var_2 = safe_eval(str_2)
    print(var_2)
    print('str_2: ' + str_2)

    str_3 = 'a - b'
    var_3 = safe_eval(str_3)
    print(var_3)
    print('str_3: ' + str_3)

    str_4 = 'not a'
   

# Generated at 2022-06-25 12:34:03.386873
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:34:10.581485
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    var_0 = safe_eval(str_0)
    print("var_0 = {}".format(var_0))

    str_1 = 'myhost'
    var_1 = safe_eval(str_1)
    print("var_1 = {}".format(var_1))

    str_2 = 'myhost.stdout_lines'
    var_2 = safe_eval(str_2)
    print("var_2 = {}".format(var_2))


test_safe_eval()



# Generated at 2022-06-25 12:34:19.170794
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    var_0 = safe_eval(str_0)
    str_1 = '_ansible_parsed | default(omit) + _ansible_item_label'
    var_1 = safe_eval(str_1)
    str_2 = '_ansible_version | float'
    var_2 = safe_eval(str_2)
    str_3 = 'nested_something[0]'
    var_3 = safe_eval(str_3)
    str_4 = 'nested_something[0].something_else'
    var_4 = safe_eval(str_4)
    str_5 = 'dict_something.something_else'
    var_5 = safe_eval(str_5)

# Generated at 2022-06-25 12:34:21.445518
# Unit test for function safe_eval
def test_safe_eval():
    print("TESTING: ", sys._getframe(0).f_code.co_name)
    print("TEST CASE: 0")
    test_case_0()


# Generated at 2022-06-25 12:34:28.065488
# Unit test for function safe_eval
def test_safe_eval():
    # check for valid input
    
    print("Test Case 0 Passed")
    # check for when safe_eval throws an exception
    try:
        safe_eval("test string")
    except:
        print("Test Case 1 Passed")
    
    
if __name__ == "__main__":
    # test_safe_eval()
    test_case_0()

# Generated at 2022-06-25 12:34:37.604800
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:44.452248
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo', locals=dict(foo='bar')) == "bar"
    assert safe_eval('foo', locals=dict(foo=['a', 'b', 'c'])) == ['a', 'b', 'c']

    try:
        safe_eval('1 + 1')
    except Exception as e:
        assert "invalid expression" in to_native(e)



# Generated at 2022-06-25 12:34:52.384191
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('', {})
    # AnsibleModule does not exist in ec2-consistency-check's path.
    # result = safe_eval('', {'module': AnsibleModule(argument_spec={})})
    assert result is None

    result = safe_eval('1')
    assert result == 1
    result = safe_eval('_ansible_retry')
    assert result == '_ansible_retry'
    result = safe_eval('_ansible_retry', {'_ansible_retry': 'foo'})
    assert result == 'foo'
    result = safe_eval('not_a_var')
    assert result == 'not_a_var'
    result = safe_eval('_ansible_retry', {'_ansible_retry': False})
    assert not result


# Generated at 2022-06-25 12:35:02.056807
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("a + 1") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("'asdf'") == 'asdf'
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("a in b", dict(a=1, b=[1, 2, 3]))
    assert safe_eval("a not in b", dict(a=1, b=[1, 2, 3]))
    assert safe_eval("a in b", dict(a=1, b={1, 2, 3}))
    assert safe_

# Generated at 2022-06-25 12:35:11.335277
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = u'foo'
    str_3 = u'bar'
    var_0 = safe_eval(str_0)
    assert var_0 == 'foo'
    var_1 = safe_eval(str_1)
    assert var_1 == 'bar'
    var_2 = safe_eval(str_2)
    assert var_2 == 'foo'
    var_3 = safe_eval(str_3)
    assert var_3 == 'bar'


test_safe_eval()


# Generated at 2022-06-25 12:35:23.116858
# Unit test for function safe_eval
def test_safe_eval():
    """
    safe_eval
    """
    str_0 = 'ansible_os_family'
    var_0 = safe_eval(str_0)
    assert var_0 == 'RedHat'

    dict_0 = dict(a=1,b=2)
    str_1 = 'ansible_local.test_dict.a'
    var_1 = safe_eval(str_1)
    assert var_1 == dict_0.get('a')

    dict_1 = dict(c=3, d=4)
    str_2 = 'ansible_local.test_dict.e'
    var_2 = safe_eval(str_2)
    assert var_2 == dict_1.get('e')

    dict_2 = dict(c=7)

# Generated at 2022-06-25 12:35:30.495514
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True', locals(), include_exceptions=True)
    assert safe_eval('False', locals(), include_exceptions=True)
    assert safe_eval('None', locals(), include_exceptions=True)
    assert safe_eval('[1, 2, 3]', locals(), include_exceptions=True)
    assert safe_eval('{"a": 1, "b": 2}', locals(), include_exceptions=True)
    assert safe_eval('1 + 2', locals(), include_exceptions=True)
    assert safe_eval('1 == 2', locals(), include_exceptions=True)



# Generated at 2022-06-25 12:35:42.648047
# Unit test for function safe_eval
def test_safe_eval():

    # str_0: '_ansible_retry'
    str_0 = '_ansible_retry'

    var_0 = safe_eval(str_0)
    assert var_0 == '_ansible_retry'

    # str_1: '_ansible_no_log'
    str_1 = '_ansible_no_log'

    var_1 = safe_eval(str_1)
    assert var_1 == '_ansible_no_log'

    # str_2: False
    str_2_1 = 'False'
    str_2_2 = 'false'

    # bool_1: True
    bool_1 = False

    var_2_1 = safe_eval(str_2_1)
    var_2_2 = safe_eval(str_2_2)

# Generated at 2022-06-25 12:35:51.618882
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:01.832740
# Unit test for function safe_eval
def test_safe_eval():
    # test with a string
    try:
        eval('_ansible_retry')
    except:
        pass
    else:
        assert False, "An error occurred"

    try:
        safe_eval('_ansible_retry')
    except:
        pass
    else:
        assert False, "An error occurred"

    # test with a string and a list
    try:
        eval('_ansible + [\'retry\']', {'_ansible': ['foo', 'bar']})
    except:
        pass
    else:
        assert False, "An error occurred"

    try:
        safe_eval('_ansible + [\'retry\']', {'_ansible': ['foo', 'bar']})
    except:
        assert False, "An error occurred"
    else:
        pass


# Generated at 2022-06-25 12:36:09.365064
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '1 + 2'
    var_1 = safe_eval(str_1)
    assert isinstance(var_1, int)
    assert var_1 == 3
    str_2 = ' _ansible_retry'
    var_2 = safe_eval(str_2)
    assert isinstance(var_2, string_types)
    assert var_2 == '_ansible_retry'
    str_3 = '_ansible_retry'
    var_3 = safe_eval(str_3)
    assert isinstance(var_3, string_types)
    assert var_3 == '_ansible_retry'
    str_4 = ' {{ _ansible_retry }}'
    var_4 = safe_eval(str_4)

# Generated at 2022-06-25 12:36:18.584374
# Unit test for function safe_eval
def test_safe_eval():
    print('Test safe_eval function')

    test_case_0()

    ok_0 = safe_eval(None)
    ok_1 = safe_eval('')
    ok_2 = safe_eval('[]')
    ok_3 = safe_eval('{}')
    ok_4 = safe_eval('1 + 2')

    assert(ok_0 is None)
    assert(ok_1 == [])
    assert(ok_2 == [])
    assert(ok_3 == {})
    assert(ok_4 == 3)

    if sys.version_info[0] < 3:
        err_0 = safe_eval(u"1 > u'2'")
    else:
        err_0 = safe_eval("1 > '2'")

    assert(err_0 == "1 > '2'")



# Generated at 2022-06-25 12:36:19.426376
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:36:21.301964
# Unit test for function safe_eval
def test_safe_eval():
    arg0 = "_ansible_retry"
    obj0 = safe_eval(arg0)



# Generated at 2022-06-25 12:36:23.940736
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# main for testing ansible.utils.safe_eval module
if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:36:47.976128
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '_ansible_retry'
    var_0 = safe_eval(str_0)
    assert var_0 == '_ansible_retry', 'Failed to assert that variable var_0 is equal to literal _ansible_retry'

    str_1 = 'a_list_variable'
    var_1 = safe_eval(str_1)
    assert var_1 == 'a_list_variable', 'Failed to assert that variable var_1 is equal to literal a_list_variable'

    str_2 = '_ansible_facts["ansible_net_model"]'
    var_2 = safe_eval(str_2)

# Generated at 2022-06-25 12:36:54.797553
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('ansible_facts') == {'ansible_facts': {}}
    assert safe_eval('ansible_facts', include_exceptions=True)[0] == {'ansible_facts': {}}
    assert safe_eval('ansible_facts.foo', include_exceptions=True)[0] == {'ansible_facts': {}}
    assert safe_eval('ansible_facts.foo', include_exceptions=True)[1] is not None
    assert safe_eval('ansible_facts["ansible_facts"]') == {}
    assert safe_eval('ansible_facts["ansible_facts"]["bar"]')

# Generated at 2022-06-25 12:37:04.430653
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval(test_case_0)

# Construct a dictionary of all the test cases
test_cases = { 'test_safe_eval': test_safe_eval }

# Construct a list of all the test cases
# Note that we don't need to construct the values of test_cases
# by hand.
# The values will be filled in by the exec statement below.
test_case_list = list(test_cases.keys())

# Add the test cases to the module
mod = sys.modules[__name__]
for test_case, test_function in test_cases.items():
    setattr(mod, test_case, test_function)

if __name__ == '__main__':
    print('Running tests...')
    print('Press Ctrl-C to abort')


# Generated at 2022-06-25 12:37:14.965405
# Unit test for function safe_eval
def test_safe_eval():
    ret, err = safe_eval('variable_name', include_exceptions=True)
    assert ret == 'variable_name'
    assert isinstance(err, Exception)

    ret, err = safe_eval('["1", "2"]', include_exceptions=True)
    assert ret == ['1', '2']
    assert err is None

    ret, err = safe_eval('{"k1": "v1", "k2": "v2"}', include_exceptions=True)
    assert ret == {'k1': 'v1', 'k2': 'v2'}
    assert err is None

    ret, err = safe_eval('1 + 1', include_exceptions=True)
    assert ret == 2
    assert err is None


# Generated at 2022-06-25 12:37:22.601708
# Unit test for function safe_eval
def test_safe_eval():
    # Test when a filter expression is valid
    expr = "range(1, 10)"
    result, err = safe_eval(expr, include_exceptions=True)

    assert (type(result) is type(range(0, 10)))
    assert err is None

    # Test when a filter expression is not valid
    expr = "range(0, len(this_list), -1)"
    result, err = safe_eval(expr, include_exceptions=True)

    assert result is expr
    assert (isinstance(err, Exception))

    # Test when a filter expression is not valid
    expr = "this_list.split(',')"
    result, err = safe_eval(expr, include_exceptions=True)

    assert result is expr
    assert (isinstance(err, Exception))

    # Test when a filter expression is not valid

# Generated at 2022-06-25 12:37:31.406252
# Unit test for function safe_eval
def test_safe_eval():
    print('Starting test_safe_eval')
    try:
        str_0 = '_ansible_retry'
        var_0 = safe_eval(str_0)
        if not var_0 == 1:
            sys.exit(1)
        else:
            print('Computed value is: '+str(var_0))
            test_case_0()
        print('safe_eval test completed.')

    except Exception as e:
        print('Caught exception: '+to_native(e))
        print('safe_eval test failed.')
        sys.exit(1)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:41.192170
# Unit test for function safe_eval
def test_safe_eval():
    s = "{'a': 'b'}"
    assert safe_eval(s) == {'a': 'b'}
    s = "['a', 'b']"
    assert safe_eval(s) == ['a', 'b']
    s = "a"
    assert safe_eval(s) == "a"
    s = "'a'"
    assert safe_eval(s) == "a"
    s = "1"
    assert safe_eval(s) == 1
    s = "1.1"
    assert safe_eval(s) == 1.1
    s = ".1"
    assert safe_eval(s) == .1
    s = "'1'"
    assert safe_eval(s) == "1"
    s = "True"
    assert safe_eval(s) is True

# Generated at 2022-06-25 12:37:51.064733
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test 1
    str_0 = '{7:3,4:4}'
    var_0 = safe_eval(str_0)
    if var_0 != {7: 3, 4: 4}:
        print('safe_eval() test 1 failed, returned value was: %s' % to_native(var_0))
        sys.exit(1)

    # test 2
    str_0 = '{7:3,4:4'
    var_0 = safe_eval(str_0)
    if var_0 != '{7:3,4:4':
        print('safe_eval() test 2 failed, returned value was: %s' % to_native(var_0))
        sys.exit(1)

    # test 3


# Generated at 2022-06-25 12:38:00.230911
# Unit test for function safe_eval
def test_safe_eval():
    # We simply select the functions to unit test here.
    # Both test_case_0 and test_case_1 should be unit tested.
    for f in [test_case_0]:
        f()


if __name__ == '__main__':
    from unit.ansible_module_common import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Manually create Ansible arguments as if by AnsibleModule
    sys.argv = [to_bytes(s) for s in []]
    basic._ANSIBLE_ARGS = to_bytes(C.DEFAULT_ANSIBLE_MODULE_ARGS)

    # Set up support for unit test function
    test_safe_eval()

    # Mock Ansible

# Generated at 2022-06-25 12:38:03.664003
# Unit test for function safe_eval
def test_safe_eval():
    x = 7
    expr = '3 * x'
    result = safe_eval(expr, dict(x=x))
    assert result == 21
    expr = '3 * 12'
    result = safe_eval(expr)
    assert result == 36



# Generated at 2022-06-25 12:38:38.060426
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluates the test_case_0 method
    test_case_0()



# Generated at 2022-06-25 12:38:38.486562
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:38:44.356088
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval('2 * 3')
    assert var_0 == 6
    var_0 = safe_eval('dict(one=1, two=2, three=3)')
    #dict_items([('two', 2), ('three', 3), ('one', 1)])
    assert var_0 == {'three': 3, 'two': 2, 'one': 1}
    var_0 = safe_eval('list(x * x for x in range(10))')
    assert var_0 == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    var_0 = safe_eval('[1, 2, 3]')
    assert var_0 == [1, 2, 3]
    var_0 = safe_eval('1')
    assert var_0 == 1
    var_

# Generated at 2022-06-25 12:38:45.510147
# Unit test for function safe_eval
def test_safe_eval():
    # calls test_case_0
    test_case_0()


# Generated at 2022-06-25 12:38:47.397690
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except SystemExit:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        raise (exc_type, exc_value, exc_traceback)



# Generated at 2022-06-25 12:38:56.814108
# Unit test for function safe_eval
def test_safe_eval():
    # Python 3.6 started returning 'True' and 'False' instead of True and False
    # so to be consistent with 2.7 we need to convert those strings back to
    # bool type.
    if sys.version_info[0] == 3 and sys.version_info[1] >= 6:
        true_str = 'True'
        false_str = 'False'
    else:
        true_str = True
        false_str = False

    assert true_str == safe_eval(true_str)
    assert false_str == safe_eval(false_str)
    assert true_str == safe_eval('True')
    assert false_str == safe_eval('False')

    expr = '{}: "bar"'.format(true_str)

# Generated at 2022-06-25 12:39:03.881860
# Unit test for function safe_eval
def test_safe_eval():

    # This test case is to make sure that safe_eval works correctly
    # The input to safe_eval is a dictionary, and the expected output
    # is the same dictionary.
    test_case_0()

if __name__ == '__main__':

    # Verify that the environment variable is set correctly
    if C.DEFAULT_MODULE_COMMON_CONTEXT_PATH != 'ansible.module_utils.common.context':
        print('Please export ANSIBLE_MODULE_COMMON_CONTEXT_PATH as ansible.module_utils.common.context')
        sys.exit(1)

    test_safe_eval()

# Generated at 2022-06-25 12:39:05.970710
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print ("TestCase 0 Failed : " + str(e))
        sys.exit (1)


# Generated at 2022-06-25 12:39:12.691838
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEFAULT_DEBUG:
        return

    res = safe_eval('empty_list')
    assert res == [], res

    res = safe_eval('vars.some_var')
    assert res == 'some_value', res

    res = safe_eval('vars.other_var')
    assert res == 'some_other_value', res

    res = safe_eval('var_with_dots.some_var')
    assert res == 'some_value', res

    res = safe_eval('var_with_dots.other_var')
    assert res == 'some_other_value', res

    res = safe_eval('vars.var_with_dots.some_var')
    assert res == 'some_value', res


# Generated at 2022-06-25 12:39:21.399903
# Unit test for function safe_eval
def test_safe_eval():
    a = safe_eval('{"foo":"bar"}')
    assert isinstance(a, dict)
    b = safe_eval('["1","2","3"]')
    assert isinstance(b, list)
    c = safe_eval('foo_var')
    assert isinstance(c, str)
    d = safe_eval('a+b')
    assert d == 'ab'
    e = safe_eval('a+b', dict(a="1", b="2"))
    assert e == "12"
    f = safe_eval('a+b', dict(a=None, b="1"), include_exceptions=True)
    assert f[0] == 'None1'
    g = safe_eval('a+b', dict(a=None, b="1"))
    assert g == 'None1'
    h = safe_