

# Generated at 2022-06-25 12:29:44.555520
# Unit test for function safe_eval
def test_safe_eval():
    s = 'hello'
    assert safe_eval(s) == 'hello'

    s = 'ansible_test_variable'
    assert safe_eval(s) == 'ansible_test_variable'

    s = '10'
    assert safe_eval(s) == 10

    s = 'foo.bar'
    assert safe_eval(s) == 'foo.bar'

    s = '"hello"'
    assert safe_eval(s) == 'hello'

    s = 'foo == "bar"'
    assert safe_eval(s) == 'foo == "bar"'

    s = 'foo.bar == "baz"'
    assert safe_eval(s) == 'foo.bar == "baz"'

    s = u'foo.bar.baz == "frozz"'
    assert safe_eval(s) == u

# Generated at 2022-06-25 12:29:55.380950
# Unit test for function safe_eval
def test_safe_eval():
    print("Test safe_eval ...")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    print("Done!")


# Test case functions


# Generated at 2022-06-25 12:29:56.638803
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases for safe_eval
    test_case_0()



# Generated at 2022-06-25 12:30:04.077668
# Unit test for function safe_eval
def test_safe_eval():
    # Make a list of expected results and actual results
    expected_result_list = []
    actual_result_list = []

    # Test Case: 0
    test_case_0()
    test_case_0_actual = complex_0
    test_case_0_expected = None
    expected_result_list.append(test_case_0_expected)
    actual_result_list.append(test_case_0_actual)

    # Compare all expected results with actual results
    for expected, actual in zip(expected_result_list, actual_result_list):
        if container_to_text(expected) != container_to_text(actual):
            print("Test failed\n Expected result: %s\n Actual result: %s"
                  % (expected, actual))



# Generated at 2022-06-25 12:30:06.807311
# Unit test for function safe_eval
def test_safe_eval():
    for test_case in [test_case_0]:
        test_case()

test_safe_eval()

# Generated at 2022-06-25 12:30:13.566786
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("[1,2,3]")
    assert result == [1, 2, 3]

    result = safe_eval("{'a':1, 'b':2}")
    assert result == {'a': 1, 'b': 2}

    result = safe_eval("{'a':[1,2,3,4], 'b':2}")
    assert result == {'a': [1, 2, 3, 4], 'b': 2}

    result = safe_eval("1+1")
    assert result == 2

    result = safe_eval("1+1", include_exceptions=True)
    assert result == (2, None)

    result = safe_eval("1+1")
    assert result == 2

    result = safe_eval("1+1", include_exceptions=True)
   

# Generated at 2022-06-25 12:30:14.667303
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:30:22.694861
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:33.745646
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:44.360129
# Unit test for function safe_eval
def test_safe_eval():

    # test_case_0
    complex_0 = None
    var_0 = safe_eval(complex_0)

    # test_case_1
    complex_1 = ''
    var_1 = safe_eval(complex_1)

    # test_case_2
    complex_2 = None
    var_2 = safe_eval(complex_2)

    # test_case_3
    complex_3 = '{{ foo }}'
    var_3 = safe_eval(complex_3)

    # test_case_4
    complex_4 = '{{ (5 * 5) - 5 }}'
    var_4 = safe_eval(complex_4)

    # test_case_5
    complex_5 = '{{ (((5 * 5) - 5) * 10) | int - 3 }}'
    var_5 = safe

# Generated at 2022-06-25 12:30:56.809330
# Unit test for function safe_eval
def test_safe_eval():
    a_str = "a_str"
    a_str_expected = a_str
    a_str_ret = safe_eval(a_str)
    assert a_str_expected == a_str_ret

    a_var = "a_str"
    a_var_expected = a_var
    a_var_ret = safe_eval("a_var", locals={"a_var" : a_var})
    assert a_var_expected == a_var_ret

    a_func = "a_str"
    a_func_expected = a_func
    a_func_ret = safe_eval("a_func()", locals={"a_func" : lambda: a_func})
    assert a_func_expected == a_func_ret

    list_0 = [1, 2, 3]
    list_

# Generated at 2022-06-25 12:31:04.651061
# Unit test for function safe_eval
def test_safe_eval():

    # Try some basic stuff that should work
    # Probably safe to assume that if this doesn't work, nothing will ;-)
    var_1 = safe_eval('({})')
    assert isinstance(var_1, dict)

    # Test some things that should fail
    var_2 = safe_eval('__import__(\'os\').system(\'touch /tmp/test_safe_eval\')')
    assert not var_2

    var_2_1 = safe_eval('__import__(\'os\').system(\'touch /tmp/test_safe_eval\')', include_exceptions=True)
    assert var_2_1[0] == '__import__(\'os\').system(\'touch /tmp/test_safe_eval\')'


# Generated at 2022-06-25 12:31:13.911921
# Unit test for function safe_eval
def test_safe_eval():
    exp_0 = "'1.3.6.1.4.1.9.9.188.1.2.2'"
    exp_1 = 1
    exp_2 = "'{}'"
    exp_3 = "'{ 'foo': 'bar' }'"
    exp_4 = "'{ 'foo': 'bar', 'bam': 'boozle' }'"
    exp_5 = "'{ 'foo': 'bar', 'bam': ['boozle', 'whaa'] }'"
    exp_6 = "'{ 'foo': 'bar', 'bam': ['goozle', 'zozzle'] }'"
    exp_7 = "'{ 'foo': 'bar', 'bam': [{'goozle': 'hi'}, {'zozzle': 'eh'}] }'"

# Generated at 2022-06-25 12:31:17.824022
# Unit test for function safe_eval
def test_safe_eval():
    e = None
    try:
        complex_0 = '{{ [1, 2, 3 ] }}'
        var_0 = safe_eval(complex_0)
        print(var_0)
    except Exception as e:
        print(e)


# this is only used by test_safe_eval() below

# Generated at 2022-06-25 12:31:25.767110
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'foo in bar'

    # test 0: basic
    result = safe_eval(expr, locals={'bar': [1, 2, 3]}, include_exceptions=True)
    assert result == ('foo in bar', None)

    result = safe_eval(expr, locals={'bar': [1, 2, 3], 'foo': 1}, include_exceptions=True)
    assert result == (True, None)

    # test 1: short circuit expressions
    expr = 'foo in bar or baz'
    result = safe_eval(expr, locals={'bar': [1, 2, 3], 'baz': 'yes'}, include_exceptions=True)
    assert result == (True, None)

    # test 2: complex expressions

# Generated at 2022-06-25 12:31:36.590251
# Unit test for function safe_eval
def test_safe_eval():
    complex_0 = '((1-2+3)-4)'
    var_0 = safe_eval(complex_0)
    assert var_0 == -2
    complex_1 = '{1:3}'
    var_1 = safe_eval(complex_1)
    assert var_1 == {u'1': 3}
    complex_2 = '1 in [1,2,3]'
    var_2 = safe_eval(complex_2)
    assert var_2 == True
    complex_3 = '1 in [1,2,3] and 3 in [1,2,3]'
    var_3 = safe_eval(complex_3)
    assert var_3 == True
    complex_4 = '1 in [1,2,3] and 3 not in [1,2,3]'
    var_4 = safe

# Generated at 2022-06-25 12:31:45.029671
# Unit test for function safe_eval
def test_safe_eval():
    complex_0 = "a + b"
    var_0 = safe_eval(complex_0)
    if not isinstance(var_0, str):
        print("Expected {0}, got {1}".format(str, type(var_0)))
        sys.exit(1)

    complex_1 = "a == 0"
    var_1 = safe_eval(complex_1)
    if not isinstance(var_1, str):
        print("Expected {0}, got {1}".format(str, type(var_1)))
        sys.exit(1)

    complex_2 = [{'a': 'b'}, 'a', 0]
    var_2 = safe_eval(complex_2)

# Generated at 2022-06-25 12:31:50.530351
# Unit test for function safe_eval
def test_safe_eval():
    # the test case
    complex_0 = """1"""
    var_0 = safe_eval(complex_0)
    assert var_0 == 1
    # the test case
    complex_1 = """1+1"""
    var_1 = safe_eval(complex_1)
    assert var_1 == 2
    # the test case
    complex_2 = """1-1"""
    var_2 = safe_eval(complex_2)
    assert var_2 == 0
    # the test case
    complex_3 = """2*2"""
    var_3 = safe_eval(complex_3)
    assert var_3 == 4
    # the test case
    complex_4 = """2/2"""
    var_4 = safe_eval(complex_4)
    assert var_4 == 1
    # the test case


# Generated at 2022-06-25 12:32:00.953201
# Unit test for function safe_eval
def test_safe_eval():
    assert callable(safe_eval), "safe_eval is not a function"
    assert safe_eval(1) == 1
    assert safe_eval('1 + 1') == 2
    var_0 = 'foo'
    var_1 = safe_eval('bar', {'bar': 'baz'})
    assert var_1 == 'baz'
    for var_2 in list(range(10)):
        var_3 = var_2
    assert var_3 == 9
    assert safe_eval("var_3", {"var_3": 42}) == 42
    assert safe_eval("unrecognized", {"unrecognized": 42}) == 42
    assert safe_eval("'foo' + 'bar'") == 'foobar'

# Generated at 2022-06-25 12:32:11.645906
# Unit test for function safe_eval
def test_safe_eval():

    # simple expression
    assert safe_eval('1 + 1') == 2

    # simple expression with a variable and whitespace
    assert safe_eval('foo + bar * 2', {"bar": 2}) == 6

    # test a subset of all possible operations
    assert safe_eval('foo * bar + bam / 2', {"bar": 12.0, "foo": 2, "bam": 5}) == 32.5

    # test a set construct
    assert safe_eval(
        '#frozenset([ 1, 2, 3 ])',
        {"frozenset": frozenset}
    ) == frozenset([1, 2, 3])

    # test an empty list
    assert safe_eval(
        '#[]'
    ) == []

    # test a list with multiple elements

# Generated at 2022-06-25 12:32:26.227784
# Unit test for function safe_eval
def test_safe_eval():
    '''
    tests for safe_eval

    TODO:
    - clean up return values, add exceptions
    - add more tests
    '''
    print('=========== test_safe_eval ================')

    # Test case 0
    print('Running test case 0:')
    print('Expected outcome:')
    print('Actual outcome:')
    print(test_case_0())

    # Test case 1
    print('Running test case 1:')
    print('Expected outcome:')
    print('Actual outcome:')
    result = safe_eval("mydict['key']")
    print(result)

    # Test case 2
    print('Running test case 2:')
    print('Expected outcome:')
    print('Actual outcome:')

# Generated at 2022-06-25 12:32:36.798377
# Unit test for function safe_eval
def test_safe_eval():
    # Exception cases
    # Expression is not valid
    expr_0 = ""
    expr_0_exception = None
    try:
        safe_eval(expr_0)
    except Exception as e:
        expr_0_exception = e

    expr_1 = "test_one"
    expr_1_exception = None
    try:
        safe_eval(expr_1)
    except Exception as e:
        expr_1_exception = e

    expr_2 = "test_one^test_two"
    expr_2_exception = None
    try:
        safe_eval(expr_2)
    except Exception as e:
        expr_2_exception = e

    expr_3 = "test_one+test_two"
    expr_3_exception = None

# Generated at 2022-06-25 12:32:41.772522
# Unit test for function safe_eval
def test_safe_eval():
    results = []

    # test case 0
    try:
        test_case_0()
        results.append((0, None))
    except Exception as e:
        results.append((0, e))

    # test case 1
    try:
        safe_eval('1+1')
        results.append((1, None))
    except Exception as e:
        results.append((1, e))

    # test case 2
    try:
        safe_eval('1+1', include_exceptions=True)
        results.append((2, None))
    except Exception as e:
        results.append((2, e))

    # test case 3

# Generated at 2022-06-25 12:32:51.654854
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:53.393803
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0()


# Generated at 2022-06-25 12:32:54.429651
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: Need to add testing for negative tests
    test_case_0()

# Generated at 2022-06-25 12:33:04.676528
# Unit test for function safe_eval
def test_safe_eval():
    complex_0 = "%s" % (__file__)
    var_0 = safe_eval(complex_0)
    if not var_0 == __file__:
        raise AssertionError("Value is: %s" %(var_0))
    complex_1 = "{{ test }} + 6"
    var_1 = safe_eval(complex_1)
    if not var_1 == "{{ test }} + 6":
        raise AssertionError("Value is: %s" %(var_1))
    complex_2 = "%s" % (container_to_text(container_to_text(container_to_text(container_to_text(container_to_text(container_to_text(__file__)))))))
    var_2 = safe_eval(complex_2)

# Generated at 2022-06-25 12:33:12.189829
# Unit test for function safe_eval
def test_safe_eval():
    import ast

    # Test 1:
    complex_0 = "a_dict[1]['a'][2]['b'][3]"
    expected_0 = ast.parse(complex_0, mode='eval')
    var_0 = safe_eval(complex_0)
    assert type(var_0) == type(expected_0)
    assert var_0 == expected_0

    # Test 2:
    complex_1 = "a_dict[1]['a'] in a_dict[2]['b'][3]"
    expected_1 = ast.parse(complex_1, mode='eval')
    var_1 = safe_eval(complex_1)
    assert type(var_1) == type(expected_1)
    assert var_1 == expected_1

    # Test 3:

# Generated at 2022-06-25 12:33:19.527350
# Unit test for function safe_eval
def test_safe_eval():
    complex_0 = None
    p = safe_eval(complex_0)
    assert p == None, 'Expected None, but got %s instead' % repr(p)

    str_0 = '[1, 2, 3]'
    str_1 = '1 + 2'
    str_2 = 'foo.bar()'
    p = safe_eval(str_0)
    assert p == [1, 2, 3], 'Expected [1, 2, 3], but got %s instead' % repr(p)

    if sys.version_info >= (3, 0):
        expected_result = 3
    else:
        expected_result = long(3)
    p = safe_eval(str_1)

# Generated at 2022-06-25 12:33:21.334225
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")
    # Insert tests
    test_case_0()



# Generated at 2022-06-25 12:33:31.876946
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None
    assert safe_eval("foo") == 'foo'
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('5') == 5
    assert safe_eval('"5"') == '5'
    assert safe_eval('3 + 5') == 8
    assert safe_eval('[1,"foo",[True, False]]') == [1, 'foo', [True, False]]
    assert safe_eval('{"foo": ["bar","baz"], "value": 3.14}') == {'foo': ['bar', 'baz'], 'value': 3.14}

# Generated at 2022-06-25 12:33:37.462413
# Unit test for function safe_eval
def test_safe_eval():
    # Use hash, brackets, braces and quotes in a single expression
    complex_0 = '{hash: {1: {2: [3], 4: (5, 6), "7": 8, "9": ["a", "b"], "c": "d", "e": "f"}, 10: 11}, "12": "13"}'
    var_1 = {'hash': {1: {2: [3], 4: (5, 6), '7': 8, '9': ['a', 'b'], 'c': 'd', 'e': 'f'}, 10: 11}, '12': '13'}
    var_0 = safe_eval(complex_0)
    assert var_0 == var_1
    # Evaluate a complex expression with a fraction

# Generated at 2022-06-25 12:33:47.863372
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:57.113775
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(None) is None
    assert safe_eval("") == ""
    assert safe_eval("123") == 123
    assert safe_eval("1.5") == 1.5
    assert safe_eval("123.45") == 123.45
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("'abc'") == "abc"
    assert safe_eval('"abc"') == "abc"
    assert safe_eval("[]") == []
    assert safe_eval("()") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-25 12:33:57.761842
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None

# Generated at 2022-06-25 12:34:10.113960
# Unit test for function safe_eval
def test_safe_eval():

    # Test case 0
    complex_0 = "a + b"
    var_0 = safe_eval(complex_0)

    assert var_0 == "a + b"

    # Test case 1
    complex_1 = " a + b "
    var_1 = safe_eval(complex_1)

    assert var_1 == " a + b "

    # Test case 2
    complex_2 = "[a, b, c]"
    var_2 = safe_eval(complex_2)

    assert var_2 == "[a, b, c]"

    # Test case 3
    complex_3 = "[a, b, True, False, None]"
    var_3 = safe_eval(complex_3)

    assert var_3 == "[a, b, True, False, None]"

    # Test case 4

# Generated at 2022-06-25 12:34:14.017904
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")
        sys.exit(1)

    # If we get here, the test cases did not throw exceptions
    sys.exit(0)

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:34:20.822572
# Unit test for function safe_eval
def test_safe_eval():
    expression = "{{ foo }}"
    evaled = safe_eval(expression)
    assert evaled == "{{ foo }}"

    expression = "{{ foo }}"
    evaled = safe_eval(expression, {'foo': 'bar'})
    assert evaled == "{{ foo }}"

    expression = "{{ foo }}"
    evaled = safe_eval(expression, {'foo': 'bar'}, include_exceptions=True)
    assert evaled[0] == "{{ foo }}"

    expression = "foo"
    evaled = safe_eval(expression)
    assert evaled == 'foo'

    expression = "foo"
    evaled = safe_eval(expression, {'foo': 'bar'})
    assert evaled == 'foo'

    expression = "foo"

# Generated at 2022-06-25 12:34:27.347580
# Unit test for function safe_eval
def test_safe_eval():
    """Return the result of a limited eval."""
    # Test a simple expression
    assert safe_eval("1 + 1") == 2
    # Test a list comprehension
    assert safe_eval("[i for i in range(3)]") == [0, 1, 2]
    # Test a ternary operation
    assert safe_eval("1 if True else 2") == 1


# Generated at 2022-06-25 12:34:37.035880
# Unit test for function safe_eval
def test_safe_eval():
    # Unit test for function safe_eval
    complex_0 = complex(0, 1)
    complex_0 = safe_eval(complex_0)
    if sys.version_info >= (3,):
        assert complex_0.real == 0.0 and complex_0.imag == 1.0
    else:
        assert complex_0.real == 0 and complex_0.imag == 1

    int_0 = 0
    int_0 = safe_eval(int_0)
    assert int_0 == 0
    int_1 = 1
    int_1 = safe_eval(int_1)
    assert int_1 == 1
    float_0 = 0.0
    float_0 = safe_eval(float_0)
    assert float_0 == 0.0

    expr_0 = 'True'
    expr_0 = safe

# Generated at 2022-06-25 12:34:44.404556
# Unit test for function safe_eval
def test_safe_eval():
    text_0 = '192.168.1.1'
    ret_0 = safe_eval(text_0)
    assert ret_0 == '192.168.1.1', \
        "Value expected: '192.168.1.1', value returned: '%s'" % ret_0

    # test_case_0()

# test_safe_eval()


# Generated at 2022-06-25 12:34:50.971539
# Unit test for function safe_eval
def test_safe_eval():

    test_case_name = 'test_case_0'

    locals()[test_case_name]()

    test_dict = {'var':'val'}

    expr = 'a_list_variable'
    result = safe_eval(expr, locals(), include_exceptions=True)
    # if (result[0] != 1) or (result[1].__class__ != ZeroDivisionError):
    #     print("safe_eval unit test failed: %s" % test_case_name)
    #     sys.exit(1)
    print("safe_eval unit test passed: %s" % test_case_name)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:35:00.656997
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is the unit test function for function safe_eval.
    '''

    # Test the basic functionality of safe_eval
    test_expr = "5"
    test_result = 5

    assert(safe_eval(test_expr) == test_result)

    # Test the safe_eval function with different options
    # Test the safe_eval function with no only_known option
    test_expr_1 = "len"
    test_result_1 = "len"

    assert(safe_eval(test_expr_1) == test_result_1)

    # Test the safe_eval function with no only_known option and with the include_exceptions option

# Generated at 2022-06-25 12:35:07.351691
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six import PY3

    assert isinstance(safe_eval("[ 1, 2, 3 ]"), list)
    assert isinstance(safe_eval("{ 'a': 1, 'b': 2 }"), dict)
    assert isinstance(safe_eval("( 1, 2, 3 )"), tuple)
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 - 2") == -1
    assert safe_eval("2 * 3") == 6
    assert safe_eval("6 / 2") == 3
    assert safe_eval("~7") == - 8
    assert not safe_eval("true and false")
    assert not safe_eval("null")
    assert safe_eval("null or 5") == 5

# Generated at 2022-06-25 12:35:16.302621
# Unit test for function safe_eval
def test_safe_eval():
    #Test case 0
    result = safe_eval('1')
    assert result == 1
    result = safe_eval('1+2-3')
    assert result == 0
    result = safe_eval('1+2-3/4')
    assert result == 0.75
    result = safe_eval('1-2+3/4')
    assert result == 0.25
    result = safe_eval('(1-2+3)/4')
    assert result == 0.25
    result = safe_eval('1 + "string"')
    assert result == "1string"
    result = safe_eval('"string" + "another string"')
    assert result == "stringanother string"
    result = safe_eval('1/0')
    assert result == 1
    result = safe_eval('-1')

# Generated at 2022-06-25 12:35:17.130119
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval() with No Exception")
    test_case_0()


# Generated at 2022-06-25 12:35:26.927345
# Unit test for function safe_eval
def test_safe_eval():

    # Test case 0 - just a negative number
    try:
        safe_eval('-1')
    except Exception as exc:
        sys.exit(1)
    # Test case 1 - function call
    try:
        safe_eval('len(1)')
    except Exception as exc:
        sys.exit(1)
    # Test case 1 - module call
    try:
        safe_eval('abs(-1)')
    except Exception as exc:
        sys.exit(1)
    # Test case 2 - function call
    try:
        safe_eval('len(1)', {'len' : len})
    except Exception as exc:
        sys.exit(1)
    # Test case 3 - module call

# Generated at 2022-06-25 12:35:37.730247
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.compat.tests import unittest

    def eval_expression(expr):
        return safe_eval(expr, dict(a=2, b=3), True)

    class TestSafeEval(unittest.TestCase):

        def test_0(self):
            """Call a function defined within the function under test"""
            expr = 'test_case_0()'
            self.assertRaises(Exception, eval_expression, expr)

        def test_1(self):
            """Define a function within the function under test"""
            expr = 'def test_case_1(): pass'
            self.assertRaises(Exception, eval_expression, expr)

        def test_2(self):
            """Call a function defined in a global namespace"""
            expr = 'abs(a)'

# Generated at 2022-06-25 12:35:43.964359
# Unit test for function safe_eval
def test_safe_eval():

    # test constants

    TEST_STR_0 = "false"
    TEST_STR_1 = "null"
    TEST_STR_2 = "0"
    TEST_STR_3 = "1"
    TEST_STR_4 = "'abc'"

    TEST_STR_5 = "false and 0"
    TEST_STR_6 = "0 or 1"
    TEST_STR_7 = "0 or true"

    TEST_STR_8 = "0+1"
    TEST_STR_9 = "'a'+'bc'"
    TEST_STR_10 = "0 and 1"
    TEST_STR_11 = "0 and 1"

    TEST_STR_12 = "False and 0"
    TEST_STR_13 = "False or 1"
    TEST_STR_14 = "False or False"

# Generated at 2022-06-25 12:35:53.139921
# Unit test for function safe_eval
def test_safe_eval():
    # This is just a basic test to show that it works in a few cases
    tests = dict(
        int_0=0,
        dict_a={'a': 2},
        dict_b={'b': 2},
        list_b=[1, 2, 3],
        list_c=[{'a': 2}, {'b': 1}],
        dict_d={'a': {'a': {'a': 1}}},
    )

    for t, r in tests.items():
        v = safe_eval('%s' % t)
        # print(v, r)
        assert v == r
    assert safe_eval('dict_a == dict_b') is False
    assert safe_eval('dict_a == dict_a') is True
    assert safe_eval('list_b[0]') == 1
   

# Generated at 2022-06-25 12:36:06.827197
# Unit test for function safe_eval
def test_safe_eval():
    expected = dict()
    expected['int_0'] = 0
    expected['int_-1'] = -1
    expected['int_99999999999999999'] = 99999999999999999
    expected['float_0.9'] = 0.9
    expected['float_-5.001'] = -5.001
    expected['false'] = False
    expected['true'] = True
    expected['null'] = None
    expected['list_list'] = [['string', 'list'], ['list', 'string']]
    expected['list_of_list'] = [expected['list_list']]
    expected['dict_dict'] = {'key': 'value'}
    expected['list_of_dict'] = [expected['dict_dict']]
    expected['dict_of_dict'] = {'key': expected['dict_dict']}


# Generated at 2022-06-25 12:36:11.721324
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:21.507064
# Unit test for function safe_eval
def test_safe_eval():
    # Case 0:
    # Input:
    #   expr = '0'
    # Expected Output:
    #   0
    test_case_0()
    expr = '0'
    assert safe_eval(expr) == 0

    # Case 1:
    # Input:
    #   expr = '0 + 1'
    # Expected Output:
    #   1
    expr = '0 + 1'
    assert safe_eval(expr) == 1

    # Case 2:
    # Input:
    #   expr = '0 + 1 + 2'
    # Expected Output:
    #   3
    expr = '0 + 1 + 2'
    assert safe_eval(expr) == 3

    # Case 3:
    # Input:
    #   expr = '0 + 1 - 1'
    # Expected Output

# Generated at 2022-06-25 12:36:31.184441
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("0", locals={}) == 0

    # It should return a string when it can't evaluate the expression
    assert safe_eval("int_0", locals={}) == "int_0"
    assert safe_eval("0 + 1") == 1
    assert safe_eval("1 + 1") == 2
    assert safe_eval("0 + 1") == 1
    assert safe_eval("0 - 1") == -1
    assert safe_eval("0 + 1 + 2") == 3
    assert safe_eval("1 * 2 * 3") == 6
    assert safe_eval("2/2") == 1
    assert safe_eval("2**2") == 4
    assert safe_eval("2**2*2") == 8
    assert safe_eval("2*2**2") == 8

# Generated at 2022-06-25 12:36:41.337763
# Unit test for function safe_eval
def test_safe_eval():
    # test basic functionality
    assert(safe_eval("1+1") == 2)
    assert(safe_eval("a_list_variable") == "['foo', 'bar', 'baz']")
    assert(safe_eval("a_list_variable | join(', ')") == "'foo, bar, baz'")
    assert(safe_eval("a_list_variable | count") == 3)
    assert(safe_eval("'%s' % a_list_variable") == "['foo', 'bar', 'baz']")
    assert(safe_eval("'a_string'") == "'a_string'")

    # test handling of non-whitelisted syntax
    try:
        safe_eval("[i for i in range(10)]")
    except Exception:
        pass

# Generated at 2022-06-25 12:36:49.029466
# Unit test for function safe_eval
def test_safe_eval():
    # evaluate an expression with no variables
    eval_0 = "1 + 2"
    assert(safe_eval(eval_0) == 3)

    # evaluate an expression with no variables (complex case)
    eval_1 = "false and false or true and true"
    assert(safe_eval(eval_1) == True)
    eval_1 = "false and false or true and true and false or false"
    assert(safe_eval(eval_1) == True)
    eval_1 = "false and false or false and true or true and false"
    assert(safe_eval(eval_1) == False)

    # evaluate an expression with basic variables
    eval_2 = "int_0 + 1"
    d = {"int_0": 0}
    assert(safe_eval(eval_2, d) == 1)

    # evaluate

# Generated at 2022-06-25 12:36:56.255268
# Unit test for function safe_eval
def test_safe_eval():
    # Pass
    assert safe_eval('1') == 1
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo()') == 'foo()'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo.bar["baz"]()') == 'foo.bar["baz"]()'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-25 12:37:04.738606
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEVELOPMENT:
        raise Exception("Unit tests should only be run inside of a development checkout!")

    # invalid expression
    try:
        safe_eval("0 + {")
    except Exception as e:
        pass
    else:
        raise Exception("Invalid expression did not raise exception")

    # unsafe function
    try:
        safe_eval("open('/etc/passwd', 'r')")
    except Exception as e:
        pass
    else:
        raise Exception("Unsafe function did not raise exception")

    # simple types
    int_0 = safe_eval("0")
    assert isinstance(int_0, int)
    assert int_0 == 0

    int_1 = safe_eval("1")
    assert isinstance(int_1, int)
    assert int_1 == 1

    float

# Generated at 2022-06-25 12:37:15.239986
# Unit test for function safe_eval
def test_safe_eval():

    try:
        safe_eval('2 + 3')
        print('Expression: 2 + 3    Result: PASS')
    except:
        print('Expression: 2 + 3    Result: FAIL')

    try:
        safe_eval('2 + 3', {}, False)
        print('Expression: 2 + 3, locals = {}, include_exceptions = False    Result: PASS')
    except:
        print('Expression: 2 + 3, locals = {}, include_exceptions = False    Result: FAIL')


# Generated at 2022-06-25 12:37:23.414366
# Unit test for function safe_eval
def test_safe_eval():
    global int_0
    int_0 = 0
    expr = "True"
    print('expr: %s, type: %s' % (expr, type(expr)))
    expr_result = safe_eval(expr)
    print('expr_result: %s, type: %s' % (expr_result, type(expr_result)))
    print('-------------------------------------------------------------------')

    expr = "False"
    print('expr: %s, type: %s' % (expr, type(expr)))
    expr_result = safe_eval(expr)
    print('expr_result: %s, type: %s' % (expr_result, type(expr_result)))
    print('-------------------------------------------------------------------')

    expr = "a"
    print('expr: %s, type: %s' % (expr, type(expr)))

# Generated at 2022-06-25 12:37:36.788840
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_KEEP_REMOTE_FILES:
        if sys.version_info[:2] == (2, 6):
            test_case_0()

# Generated at 2022-06-25 12:37:38.719263
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval("int_0 = {{ int_0 }}")
        test_case_0()
    except:
        sys.exit(1)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:46.022745
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test case for function safe_eval
    """
    # Define tests
    # boolean types

# Generated at 2022-06-25 12:37:57.401584
# Unit test for function safe_eval
def test_safe_eval():
    print(safe_eval('1'))

#print(safe_eval('1+1'))
#print(safe_eval('2*2'))
#print(safe_eval('2*2+2'))
#print(safe_eval('"Hi"'))
#print(safe_eval('"Hi"+"Me"'))
#print(safe_eval('"Hi"+"Me"+"You"'))
#print(safe_eval('"Hi"+" "+"Me"'))
#print(safe_eval('"Hi"+" "+"Me"+" "+"You"'))
#print(safe_eval('["Hi"]'))
#print(safe_eval('[1]'))
#print(safe_eval('["Hi","Me"]'))
#print(safe_eval('["Hi","Me","You"]'))

# Generated at 2022-06-25 12:38:06.313388
# Unit test for function safe_eval
def test_safe_eval():
    # Test that safe_eval works in the trivial case where no data is passed
    int_0 = safe_eval(0)
    if not isinstance(int_0, int):
        raise AssertionError('safe_eval did not return an int.')

    # Test that safe_eval works when arbitrary literals are passed
    int_123 = safe_eval('123')
    if not isinstance(int_123, int):
        raise AssertionError('safe_eval did not return an int.')

    # Test that safe_eval works when variables are passed
    int_0 = 0
    int_0_copy = safe_eval('int_0')
    if not isinstance(int_0_copy, int):
        raise AssertionError('safe_eval did not return an int.')

    # Test that safe_eval works when basic arithmetic

# Generated at 2022-06-25 12:38:16.604664
# Unit test for function safe_eval
def test_safe_eval():
    try:
        # test exceptions
        safe_eval("__import__('os').system('uptime')")
        # exception is already handled,
        # so we should not reach here
        assert False, "test_case_0: safe_eval with unsafe statements"
    except Exception as e:
        # print exception
        print(e)

    try:
        # test exceptions
        safe_eval("__import__('os').system('uptime')", include_exceptions=True)
        # exception is already handled,
        # so we should not reach here
        assert False, "test_case_0: safe_eval with unsafe statements"
    except Exception as e:
        # print exception
        print(e)

    # test with safe evaluation

# Generated at 2022-06-25 12:38:27.501419
# Unit test for function safe_eval
def test_safe_eval():

    ### This should all work ###

    # int
    result = safe_eval("0")
    assert isinstance(result, int)
    assert result == 0

    # float
    result = safe_eval("0.0")
    assert isinstance(result, float)
    assert result == 0.0

    # string
    result = safe_eval("'0'")
    assert isinstance(result, str)
    assert result == '0'

    # dict
    result = safe_eval("{'a': 'b'}")
    assert isinstance(result, dict)
    assert result == {'a': 'b'}

    # list
    result = safe_eval("[0]")
    assert isinstance(result, list)
    assert result == [0]

    # tuple
    result = safe_eval("(0,)")

# Generated at 2022-06-25 12:38:37.075367
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:45.397309
# Unit test for function safe_eval
def test_safe_eval():
    def _test_safe_eval(string, expected_result=None, locals=None):
        if locals is None:
            locals = {}
        if expected_result is None:
            expected_result = string
        if expected_result is True:
            expected_result = True

        result = safe_eval(string, locals=locals)
        if result != expected_result:
            raise AssertionError("safe_eval evaluation of expression %s failed. Returned %s instead of %s" % (string, result, expected_result))
        else:
            print("safe_eval evaluation of expression %s succeeded. Returned %s." % (string, result))


# Generated at 2022-06-25 12:38:52.104422
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('false')
    safe_eval('true')
    safe_eval('null')
    safe_eval('1')
    safe_eval('1 + 1')
    safe_eval('True')
    safe_eval('False')
    safe_eval('None')
    safe_eval('1')
    safe_eval('1 + 1')
    safe_eval('1 - 1')
    safe_eval('1 * 1')
    safe_eval('1 / 1')
    safe_eval('-1')
    safe_eval('not False')
    safe_eval('1 == 1')
    safe_eval('1 != 1')
    safe_eval('["a", "b"]')
    safe_eval('{"a": "b"}')
    safe_eval('["a", "b", "c", "d"]')
    safe

# Generated at 2022-06-25 12:39:06.533917
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('1') == 1
    assert safe_eval('False') == False
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []
    assert safe_eval('None') == None
    assert safe_eval('1 + 2') == 3
    assert safe_eval('a', locals={'a': 1}) == 1
    assert safe_eval({'a': 1}) == {'a': 1}
    assert safe_eval('True and False') == False
    assert safe_eval('True or False') == True
    assert safe_eval('False or True') == True
    assert safe_eval('[1, 2, 3, 4]') == [1, 2, 3, 4]

# Generated at 2022-06-25 12:39:14.743859
# Unit test for function safe_eval

# Generated at 2022-06-25 12:39:15.875531
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_DEBUG:
        print('in test_safe_eval')
    # test case 0
    test_case_0()


# Generated at 2022-06-25 12:39:17.177620
# Unit test for function safe_eval
def test_safe_eval():
    assert True

# This is executed if you call the module directly.
if __name__ == "__main__":
    test_case_0()
    # test_safe_eval()

# Generated at 2022-06-25 12:39:21.937149
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'certificate_key_pnem'
    var_0 = safe_eval(str_0)
    str_1 = 'certificate_key_pnem'
    var_1 = safe_eval(str_1)
    str_2 = 'certificate_key_pnem'
    var_2 = safe_eval(str_2)
    str_3 = 'certificate_key_pnem'
    var_3 = safe_eval(str_3)
    str_4 = 'certificate_key_pnem'
    var_4 = safe_eval(str_4)
    str_5 = 'certificate_key_pnem'
    var_5 = safe_eval(str_5)
    str_6 = 'certificate_key_pnem'

# Generated at 2022-06-25 12:39:23.317207
# Unit test for function safe_eval
def test_safe_eval():
    # Function safe_eval without argument
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:39:24.717390
# Unit test for function safe_eval
def test_safe_eval():
    """
    @summary: Evaluate a string which is a Python expression
    """

    # todo: add tests
    return False



# Generated at 2022-06-25 12:39:25.942186
# Unit test for function safe_eval
def test_safe_eval():
    # assert safe_eval('1 + 1') == 2
    assert safe_eval('5') == 5

# Generated at 2022-06-25 12:39:27.218179
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:39:33.866858
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '-1'
    try:
        var_0 = safe_eval(str_0)
        assert var_0 == -1
    except Exception as e:
        print('Error: ', e)
        assert False
    print('Test case 0 passed: ', str_0)

    str_0 = 'certificate_key_pnem'
    try:
        var_0 = safe_eval(str_0)
        assert var_0 == 'certificate_key_pnem'
    except Exception as e:
        print('Error: ', e)
        assert False
    print('Test case 1 passed: ', str_0)

    str_0 = 'config.get("certificate_key_pnem")'