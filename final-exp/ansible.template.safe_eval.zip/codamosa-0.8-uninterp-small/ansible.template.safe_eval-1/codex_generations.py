

# Generated at 2022-06-25 12:29:41.237137
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Check that safe_eval works for various kinds of inputs
    '''

    assert True
    # simple variable
    assert safe_eval("foo") == "foo"

    # literals
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None

    # basic math
    assert safe_eval("1+1") == 2
    assert safe_eval("2-3") == -1
    assert safe_eval("10*20") == 200
    assert safe_eval("1/2") == 0.5

    # bool ops
    assert safe_eval("true and false") is False
    assert safe_eval("true or false") is True
    assert safe_eval("not false") is True

    # comparison ops
    assert safe_eval("1 == 1")

# Generated at 2022-06-25 12:29:42.981400
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from nose import SkipTest
    except:
        from unittest import SkipTest
    raise SkipTest('Not yet implemented')

# Generated at 2022-06-25 12:29:49.233070
# Unit test for function safe_eval
def test_safe_eval():
    eval_result = safe_eval('foo[0]["bar"]')
    assert eval_result == 'foo[0]["bar"]', "safe_eval for normal strings, should return the string itself"

    eval_result = safe_eval('$foo.bar')
    assert eval_result == '$foo.bar', "safe_eval should return the string itself"

    eval_result = safe_eval('{{ $foo.bar }}')
    assert eval_result == '{{ $foo.bar }}', "safe_eval should return the string itself"

    eval_result = safe_eval('"{{ $foo.bar }}"')
    assert eval_result == '{{ $foo.bar }}', "safe_eval should return the string itself"

    eval_result = safe_eval('{a: "b"}')

# Generated at 2022-06-25 12:30:00.135241
# Unit test for function safe_eval
def test_safe_eval():

    # Unit test for safe_eval
    var_0 = safe_eval(0.0)
    assert var_0 == 0.0, "var_0 is: {}. It should be: 0.0".format(var_0)
    # Unit test for safe_eval
    var_1 = safe_eval(0.0)
    assert var_1 == 0.0, "var_1 is: {}. It should be: 0.0".format(var_1)
    # Unit test for safe_eval
    var_2 = safe_eval(0.0)
    assert var_2 == 0.0, "var_2 is: {}. It should be: 0.0".format(var_2)
    # Unit test for safe_eval
    var_3 = safe_eval(0.0)
    assert var_3 == 0.

# Generated at 2022-06-25 12:30:11.259910
# Unit test for function safe_eval
def test_safe_eval():

    # This test will fail, we require a string
    try:
        out = safe_eval(1)
    except Exception:
        pass

    # This test will pass
    out = safe_eval("1")

    # This test will fail, we don't allow calls to len
    try:
        out = safe_eval("len([1,2,3])")
    except Exception:
        pass
    if out != "len([1,2,3])":
        out = "fail"

    # This test will fail, we don't allow calls to __builtin__
    try:
        out = safe_eval("__builtins__.len([1,2,3])")
    except Exception:
        pass
    if out != "__builtins__.len([1,2,3])":
        out = "fail"

    # This

# Generated at 2022-06-25 12:30:20.871994
# Unit test for function safe_eval
def test_safe_eval():
    import random
    print('Testing %s...' % safe_eval.__name__)
    float_0 = float(random.randint(0, 100))
    if float_0 >= float_0:
        var_0 = safe_eval(float_0)
        if var_0 > float_0:
            print('float_0 is %s' % float_0)
            print('var_0 is %s' %  var_0)
        elif var_0 <= float_0:
            print('float_0 is %s' % float_0)
            print('var_0 is %s' %  var_0)
            print('to_native(var_0) is %s' % to_native(var_0))

# Generated at 2022-06-25 12:30:26.661795
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = """{{ each_hostvars['localhost']['ansible_facts']['distribution'] }}"""
    var_1 = safe_eval(var_0, {'hostvars': {'localhost': {'ansible_facts': {'distribution': 'CentOS Linux'}}}})
    assert var_1 == 'CentOS Linux'


# Generated at 2022-06-25 12:30:36.215851
# Unit test for function safe_eval
def test_safe_eval():
    # Test variables
    var_0 = safe_eval('5-5')
    var_1 = safe_eval('5 - 5')
    var_2 = safe_eval(' 5 - 5 ')
    var_3 = safe_eval('5 - 5 - 5')

    # Test Assertions, should all be true
    assert isinstance(var_0, (int, float))
    assert isinstance(var_1, (int, float))
    assert isinstance(var_2, (int, float))
    assert isinstance(var_3, (int, float))
    assert var_0 == var_1 == var_2 == var_3 == 0
    assert type(var_0) == type(var_1) == type(var_2) == type(var_3) == int


# Generated at 2022-06-25 12:30:37.479342
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:30:47.008402
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = 53.93
    var_1 = safe_eval(var_0)
    assert type(var_1) is float
    assert var_1 == var_0
    var_2 = "{'test_key': 'test_value'}"
    var_3 = safe_eval(var_2)
    assert type(var_3) is dict
    assert var_3['test_key'] == 'test_value'
    var_4 = [{'key': 'value'}, 'list']
    var_5 = safe_eval(var_4)
    assert type(var_5) is list
    assert var_5[0]['key'] == 'value'
    assert var_5[1] == 'list'
    var_6 = ['a', 'list']

# Generated at 2022-06-25 12:30:51.741268
# Unit test for function safe_eval
def test_safe_eval():
    assert(str_0 == safe_eval(str_0))


# Generated at 2022-06-25 12:30:59.857363
# Unit test for function safe_eval
def test_safe_eval():
    # no callables allowed
    assert safe_eval("'a string'") == 'a string'
    assert safe_eval("5") == 5
    assert safe_eval("True") is True
    assert safe_eval("10 + 10") == 20
    assert safe_eval("10 - 10") == 0
    assert safe_eval("10 * 10") == 100
    assert safe_eval("10 / 10") == 1
    assert safe_eval("- 1") == -1
    assert safe_eval("10 % 3") == 1
    assert safe_eval("1 in [1]") is True
    assert safe_eval("'foo' in 'this is foo string'") is True
    assert safe_eval("'foo' not in 'this is bar string'") is True
    assert safe_eval("1 == 1") is True

# Generated at 2022-06-25 12:31:05.680808
# Unit test for function safe_eval
def test_safe_eval():
    test_name = 'safe_eval'

    try:
        expr = 'a + b'
        locals = {'a': 1, 'b': 2}
        err = None
        try:
            safe_eval(expr, locals)
        except Exception as e:
            err = e

        test_result = err is None
        if test_result:
            test_result_msg = "OK"
        else:
            test_result_msg = "Failed"
            test_result_msg += ": " + "Got error while evaluating expression '%s' using locals %s" % (expr, locals)
    except NotImplementedError as e:
        test_result = False
        test_result_msg = "Not implemented"

    print_test_result(test_name, test_result, test_result_msg)




# Generated at 2022-06-25 12:31:15.515272
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('some.thing', locals={ 'some': { 'thing': True }}) == True
    assert safe_eval('some.thing', locals={ 'some': { 'thing': False }}) == False
    assert safe_eval('some.thing', locals={ 'some': { 'thing': None }}) == None
    assert safe_eval('some.thing', locals={ 'some': { 'thing': "foo" }}) == "foo"

    assert safe_eval('some.thing.foo', locals={ 'some': { 'thing': { 'foo': True }}}) == True
    assert safe_eval('some.thing.foo', locals={ 'some': { 'thing': { 'foo': False }}}) == False
    assert safe_eval('some.thing.foo', locals={ 'some': { 'thing': { 'foo': None }}}) == None

# Generated at 2022-06-25 12:31:21.102604
# Unit test for function safe_eval
def test_safe_eval():
    res_0 = safe_eval('a_list_variable')
    res_1 = safe_eval('a_list_variable', { 'a_list_variable': ['localhost'] })
    if C.DEFAULT_DEBUG:
        print('res_0 = {0}'.format(res_0))
        print('res_1 = {0}'.format(res_1))
    assert res_0 == 'a_list_variable'
    assert res_1 == ['localhost']



# Generated at 2022-06-25 12:31:32.514596
# Unit test for function safe_eval
def test_safe_eval():
    # Test 'expr': Any valid python expression
    def test_expr(expr):
        print('expr: %s' % expr)
        print('type(expr): %s' % type(expr))
        print(safe_eval(expr))
        print('')

    test_expr('len([1, 2, 3]) + len([1, 2, 3])')
    test_expr('len([1, 2, 3]) + len([1, 2, "a"])')
    test_expr('len([1, 2, 3]) + len([1, 2, 3])')
    test_expr('len([1, 2, 3]) + len([1, 2, "a"])')
    test_expr('len([1, 2, 3]) + len([1, 2, 3])')

# Generated at 2022-06-25 12:31:41.651136
# Unit test for function safe_eval
def test_safe_eval():

    str_0 = '{{ hello }}'
    str_1 = 'not yet implemented'
    str_2 = '-33'
    str_3 = '33'
    str_4 = '"33"'
    str_5 = '33.0'
    str_6 = '"33.0"'
    str_7 = '-33.0'
    str_8 = 'True'
    str_9 = 'False'
    str_10 = 'true'
    str_11 = 'false'
    str_12 = 'null'
    str_13 = 'None'
    str_14 = '{"a": 1, "b": 2}'
    str_15 = '1.0'
    str_16 = '"a"'
    str_17 = '2.0'
    str_18 = '"b"'

# Generated at 2022-06-25 12:31:47.670637
# Unit test for function safe_eval
def test_safe_eval():
    import types

    result_0 = safe_eval('This is a string')
    assert type(result_0) == str
    assert result_0 == 'This is a string'

    result_1 = safe_eval(1)
    assert type(result_1) == int
    assert result_1 == 1

    result_2 = safe_eval(1.1)
    assert type(result_2) == float
    assert result_2 == 1.1

    result_3 = safe_eval(True)
    assert type(result_3) == bool
    assert result_3 == True

    result_4 = safe_eval(None)
    assert type(result_4) == type(None)
    assert result_4 == None

    result_5 = safe_eval('[[1, 2], [3, 4], [5, 6]]')

# Generated at 2022-06-25 12:31:56.517400
# Unit test for function safe_eval
def test_safe_eval():
    data_to_test = 'I like Python'
    # Set str_0 as a global variable
    global str_0
    str_0 = safe_eval(data_to_test)
    # Test if the data_to_test is the same as str_0
    if (data_to_test == str_0):
        print('{0} is {1}'.format(data_to_test, str_0))
    else:
        print('{0} is not {1}'.format(data_to_test, str_0))

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:04.057344
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:23.785706
# Unit test for function safe_eval
def test_safe_eval():
    # Print a helpful message if the assert fails
    def safe_eval_test(actual, expected):
        try:
            assert actual == expected
        except AssertionError:
            print("safe_eval_test(%s, %s) failed" % (actual, expected), file=sys.stderr)
            print("safe_eval_test() expected: %s" % expected, file=sys.stderr)
            print("safe_eval_test()   actual: %s" % actual, file=sys.stderr)

    # Test a dict
    test_dict = { "a": 1, "b": 2, "c": 3 }
    actual = safe_eval(test_dict)
    safe_eval_test(actual, test_dict)

    # Test a dict with a string

# Generated at 2022-06-25 12:32:33.700897
# Unit test for function safe_eval
def test_safe_eval():
    # Unit test for function safe_eval
    # Test of safe_eval with a simple list
    # str_1 = '["a", "b", "c"]'
    # assert safe_eval(str_1) == ["a", "b", "c"], "Incorrect evaluation of a string with a simple list"
    # Test of safe_eval with a combination of operations
    str_2 = "[5 * 2, 3 * 3 * 3, 2 ** 10]"
    assert safe_eval(str_2) == [10, 27, 1024], "Incorrect evaluation of a string with a combination of operations"
    # Test of safe_eval with a dictionary
    str_3 = "{'key1': 'value1', 'key2': {'key3': 'value3', 'key4': 'value4'}}"
    assert safe_eval(str_3)

# Generated at 2022-06-25 12:32:40.497725
# Unit test for function safe_eval
def test_safe_eval():
    # Mock data
    str_0 = 'foo is bar'
    dict_1 = {}
    dict_1['rc'] = 0
    dict_1['results'] = ['foo is bar']

    # Call function
    result = safe_eval(str_0)

    # Print result
    #print(result)

    # Check
    if(result == dict_1):
        return True
    else:
        return False


if __name__ == '__main__':
    # Untested
    str_0 = 'Not yet implemented'
    test_case_0()

# Generated at 2022-06-25 12:32:43.043621
# Unit test for function safe_eval
def test_safe_eval():
    if not hasattr(safe_eval, "__call__"):
        raise Exception("safe_eval is not callable")


# Generated at 2022-06-25 12:32:53.764628
# Unit test for function safe_eval
def test_safe_eval():
    # The following command uses the current value of "f" to create a new
    # fake, a process known as forking.
    str_0 = "{{ a }}"
    str_1 = 'Not yet implemented'

    vars_0 = dict(a=1)

    str_2 = "{{ a + 1 }}"
    str_3 = 'Not yet implemented'

    vars_1 = dict(a=1)

    str_4 = "{{ a | b }}"
    str_5 = 'Not yet implemented'

    vars_2 = dict(a=1, b=2)

    str_6 = "{{ a | b + 1 }}"
    str_7 = 'Not yet implemented'

    vars_3 = dict(a=1, b=2)

    str_8 = 'Not yet implemented'

    str

# Generated at 2022-06-25 12:32:56.179433
# Unit test for function safe_eval
def test_safe_eval():
    try:
        str_0 = 'Not yet implemented'
        assert None == safe_eval(str_0)
    except Exception as e:
        print(e)
        return False

    return True


# Generated at 2022-06-25 12:33:06.636468
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(0, include_exceptions=True) == (0, None)
    assert safe_eval(1, include_exceptions=True) == (1, None)
    assert safe_eval('a'*1024, include_exceptions=True) == ('a'*1024, None)
    assert safe_eval('a * b', dict(a=10, b=2), include_exceptions=True) == (20, None)
    # Test for python2.x vs python3.x
    if sys.version_info < (3,):
        assert safe_eval(unicode('a * b'), dict(a=10, b=2), include_exceptions=True) == (20, None)

# Generated at 2022-06-25 12:33:10.334192
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1') is not 2
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo"') is not 'foo'
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3], None)
    assert safe_eval('[1,2,3][0]', include_exceptions=True) == (1, None)
    assert safe_eval('[1,2,3][0]', include_exceptions=True)[0] == 1

# Generated at 2022-06-25 12:33:12.597237
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Not yet implemented'


# Generated at 2022-06-25 12:33:14.639898
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Not yet implemented'

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:33:28.469499
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        (str_0, str_0),
    ]
    ans_str_0 = ast.dump(ast.parse(str_0))

    for t in test_cases:
        in_0 = t[0]
        expected = (t[1], None)
        actual = safe_eval(in_0, include_exceptions=True)
        assert actual == expected, "safe_eval('{0:s}') should have returned ('{1:s}', None), but returned ('{2:s}', '{3:s}') instead.".format(in_0, expected, actual)

    print("test_safe_eval(): all test cases passed!")

# # if we're not being run via py.test, run the test suite we just created
# if __name__ == '__main__':


# Generated at 2022-06-25 12:33:34.644402
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = "{{ 'foo'.upper }}"
    str_2 = "{{ 'foo'.upper() }}"
    str_3 = "[1, 2, 3]"
    str_4 = "[1, 2, 3]"

    # Test with a string containing reference to upper()
    # Result must be an exception of the type SyntaxError
    # Thus, we will check the type of the exception
    try:
        safe_eval(str_1)
    except SyntaxError as e:
        assert True
    else:
        assert False

    # Test with a string containing a reference to upper() and ()
    # Result must be an exception of the type SyntaxError
    # Thus, we will check the type of the exception
    try:
        safe_eval(str_2)
    except SyntaxError as e:
        assert True
   

# Generated at 2022-06-25 12:33:36.228328
# Unit test for function safe_eval
def test_safe_eval():
    print("Test safe_eval")
    test_case_0()

# Not used

# Generated at 2022-06-25 12:33:47.703441
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval()
    """

    # TODO: Add more test cases after safe_eval() is enhanced.
    # This is a placeholder for demonstration.
    expr = '1 + 1'
    expected = 2
    actual = safe_eval(expr)
    assert actual == expected, "Actual: %s. Expected: %s" % (actual, expected)


# Include some basic tests in the MAIN section in case the script is run standalone.
# We do not use the Python "unittest" module because of the difficulty in
# mixing that with the Ansible code and getting unittest to understand the code
# being tested (which is what we want to do in Ansible).

# Generated at 2022-06-25 12:33:55.687629
# Unit test for function safe_eval
def test_safe_eval():
    f = open(sys.argv[1], "r")
    lines = f.read()
    f.close()
    lines = lines.split('\n')
    for i in range(len(lines)):
        if lines[i] == "":
            continue
        if lines[i][0] == '#':
            continue
        if lines[i][0:5] == "expr_":
            exec(lines[i])
        if lines[i][0:8] == "returns_":
            exec(lines[i])
        if lines[i][0:6] == "tests_":
            exec(lines[i])

# Functions to process JSON tests


# Generated at 2022-06-25 12:34:02.361825
# Unit test for function safe_eval
def test_safe_eval():
    # Simple dict
    assert safe_eval('{ foo: "bar" }') == safe_eval('{"foo": "bar"}')
    assert safe_eval('{ foo: "bar" }', include_exceptions=True)[0] == safe_eval('{"foo": "bar"}', include_exceptions=True)[0]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('{"foo": "bar"}', include_exceptions=True)[0] == {"foo": "bar"}
    #Simple list
    assert safe_eval('[ foo, bar ]') == safe_eval('[ "foo", "bar" ]')

# Generated at 2022-06-25 12:34:12.206959
# Unit test for function safe_eval
def test_safe_eval():
    print ("test_safe_eval: ")

# Generated at 2022-06-25 12:34:14.241505
# Unit test for function safe_eval
def test_safe_eval():
    casenum = 0
    print("\nTesting case: " + str(casenum))
    test_case_0()


# Generated at 2022-06-25 12:34:16.980503
# Unit test for function safe_eval
def test_safe_eval():
    expr = "str(2) == '2'"
    expr_eval = safe_eval(expr)
    assert expr_eval == True, "expr_eval is %s" % expr_eval
    test_case_0()
    if __name__ == "__main__":
        test_safe_eval()

# Generated at 2022-06-25 12:34:26.948804
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    str_0 = 'Not yet implemented'
    str_1 = 'Not yet implemented'
    str_2 = 'Not yet implemented'
    str_3 = 'Not yet implemented'
    str_4 = 'Not yet implemented'
    str_5 = 'Not yet implemented'
    str_6 = 'Not yet implemented'
    str_7 = 'Not yet implemented'
    str_8 = 'Not yet implemented'
    str_9 = 'Not yet implemented'
    str_10 = 'Not yet implemented'
    str_11 = 'Not yet implemented'
    str_12 = 'Not yet implemented'
    str_13 = 'Not yet implemented'
    str_14 = 'Not yet implemented'
    str_15 = 'Not yet implemented'
    str_16 = 'Not yet implemented'
    str_17

# Generated at 2022-06-25 12:34:39.387194
# Unit test for function safe_eval
def test_safe_eval():

    print('Testing safe_eval')

    with open('safe_eval_data.txt', 'r') as f:
        data = f.readlines()

    expected_output = []

    for line in data:
        # Strip comments
        if '#' in line:
            line = line[:line.index('#')]

        line = line.strip()
        if not line:
            continue

        if line.startswith('['):
            # Mark the start of a new test case
            expected_output = ast.literal_eval(line)
            continue

        if '=' not in line:
            raise Exception('Invalid input; should be "actual = expected"')

        actual, expected = line.split('=')


# Generated at 2022-06-25 12:34:40.694806
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Not yet implemented'


# Generated at 2022-06-25 12:34:49.758576
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "6 * 7"
    str_1 = "{{ foo }}"
    str_2 = '{{ foo }'
    str_3 = "{{ foo }} {{ bar }}"
    str_4 = "'{{ foo }}'"
    str_5 = "6 * {{ foo }}"
    str_6 = "'foo' + 'bar'"
    str_7 = 'foo in bar'
    str_8 = "foo in bar"
    str_9 = "foo not in bar"

    # Simple operations (eg. 6 * 7)
    assert 42 == safe_eval(str_0)

    # Double brace templates, recursive template
    # W/ no context
    assert '{{ foo }}' == safe_eval(str_1)
    # W/ dict context

# Generated at 2022-06-25 12:34:52.299544
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")
    test_case_0()

if __name__ == "__main__":
  sys.exit(test_safe_eval())

# Generated at 2022-06-25 12:35:01.979564
# Unit test for function safe_eval
def test_safe_eval():
    # Test if safe_eval function can evaluate a constant string
    assert safe_eval('\'Some constant string\'') == 'Some constant string'
    # Test if safe_eval can evaluate a constant list
    assert safe_eval('[0, 1, 2]') == [0, 1, 2]
    # Test if safe_eval can evaluate a constant dictionary
    assert safe_eval('{0: 1, 1: 0}') == {0: 1, 1: 0}
    # Test if safe_eval can evaluate a constant tuple
    assert safe_eval('(0, 1, 2)') == (0, 1, 2)
    # Test if safe_eval can evaluate a list with a string element
    assert safe_eval('[0, 1, \'a string\', 3]') == [0, 1, 'a string', 3]
    # Test if safe

# Generated at 2022-06-25 12:35:13.345635
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = ['list', 'stuff']
    dict_0 = {'dict': 'some', 'values': ['list', 'stuff']}
    test_str = '{{ list_0 }}'

    # Assert basic string evaluation
    assert safe_eval(test_str, dict(locals())) == list_0

    test_str = '{{ dict_0 }}'
    assert safe_eval(test_str, dict(locals())) == dict_0

    # Assert embedded item retrieval
    test_str = '{{ dict_0["values"] }}'
    assert safe_eval(test_str, dict(locals())) == ['list', 'stuff']

    test_str = '{{ dict_0["dict"] }}'
    assert safe_eval(test_str, dict(locals())) == 'some'

    # Ass

# Generated at 2022-06-25 12:35:20.337127
# Unit test for function safe_eval
def test_safe_eval():
    if not HAS_AST:
        if sys.version_info.major == 2:
            print("ast module not available, safe_eval test cases will be skipped")
        else:
            # ast module is always available in python versions > 2.6
            print("ast module is always available in python versions > 2.6. It is not known why the module is not available.")
        return

    print("Testing safe_eval function")
    # Test case 0
    print("Starting test case 0")
    str_0 = 'Not yet implemented'
    #print("Result: " + safe_eval(str_0))
    #print("Expected: ")
    
    # Test case 1
    print("Starting test case 1")
    str_1 = 'b'
    #print("Result: " + safe_eval(str_1))
    #print("

# Generated at 2022-06-25 12:35:24.114830
# Unit test for function safe_eval
def test_safe_eval():
    # Input Variables
    test_case = 0
    print('')
    print('**** Unit Test for function safe_eval ****')

    if test_case == '0':
        print('\nTest Case #0: Not yet implemented')
        test_case_0()

    if test_case == '1':
        print('\nTest Case #1: ')
        print('Expected Outcome: ')
        print('Actual Outcome: ')
        test_case_1()

if __name__ == "__main__":
    # Show full stack trace in case of exceptions
    sys.tracebacklimit = None
    test_safe_eval()

# Generated at 2022-06-25 12:35:35.412382
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:37.833280
# Unit test for function safe_eval
def test_safe_eval():
    # call function `safe_eval`
    print('Output: %s\n' % (safe_eval('len(str_0)'),))
    print('Output: %s\n' % (safe_eval('str_0.split()'),))


# Generated at 2022-06-25 12:35:55.303659
# Unit test for function safe_eval
def test_safe_eval():

    bad_value = 'Almost to a python list (]]]'
    test_string = "{{ ansible_processor_vcpus_with_hyperthreads }}"
    result = container_to_text(safe_eval(test_string))
    print(result)
    sys.exit(0)
    #assert result == "{{ ansible_processor_vcpus_with_hyperthreads }}", "Wrong result"

    test_string = "{{ ansible_processor_vcpus }}"
    result = safe_eval(test_string)
    if C.DEFAULT_DEBUG:
        print()
        print(test_string)
        print(result)
    assert result == "{{ ansible_processor_vcpus }}", "Wrong result"


# Generated at 2022-06-25 12:35:58.084840
# Unit test for function safe_eval
def test_safe_eval():
    # Test with a string containing a simple expression
    assert safe_eval('1 + 1') == 2
    # Test with a string containing a complex expression
    assert safe_eval('1 + 1 + 1') == 3


# Generated at 2022-06-25 12:36:03.544350
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    # str_0 = 'Not yet implemented'
    try:
        safe_eval(str_0)
    except Exception as e:
        print("Exception raised:")
        print(e)
        return
    print("Result of safe_eval:")
    print(safe_eval(str_0))
    return safe_eval(str_0)


# Generated at 2022-06-25 12:36:10.173030
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:19.427427
# Unit test for function safe_eval
def test_safe_eval():
    # If include_exceptions is False, safe_eval should return
    # the result of the expression
    assert safe_eval('True and False') == False
    assert safe_eval('True or False') == True
    assert safe_eval('True and False or True') == True
    assert safe_eval('True or False or True') == True
    assert safe_eval("""
        '''
        This is a
        multi-line
        string.
        '''
    """) == '\n        This is a\n        multi-line\n        string.\n        '
    assert safe_eval("'a' in ['boo', 'a', 'foo', 5]") == True
    assert safe_eval("'z' in ['boo', 'a', 'foo', 5]") == False

# Generated at 2022-06-25 12:36:27.871874
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:37.345445
# Unit test for function safe_eval
def test_safe_eval():
    # This is an example of what is not allowed
    try:
        safe_eval("__import__('os').system('rm -rf /')")
        assert False, "Allowed import"
    except Exception as e:
        assert str(e).find("import") != -1

    # This is an example of what is allowed
    try:
        safe_eval("a in b")
    except Exception as e:
        assert False, "Did not allow a in b"

    # This is currently allowed but should raise an exception when 'call'
    # is removed from ALLOWED_NODES
    try:
        safe_eval("len(a)")
    except Exception as e:
        assert False, "Did not allow len(a)"

    # This is an example of a nested list, which should be allowed

# Generated at 2022-06-25 12:36:46.565229
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_DEBUG:
        test_case_0()

    # Make sure safe_eval blocks searching through the `__builtins__` dict
    # and calling functions from it.
    assert safe_eval('__builtins__') == '__builtins__'
    assert safe_eval('__builtins__.dict') == '__builtins__.dict'
    assert safe_eval('__builtins__.dict()') == '__builtins__.dict()'
    assert safe_eval('__builtins__.dict().keys') == '__builtins__.dict().keys'
    assert safe_eval('__builtins__.dict().keys()') == '__builtins__.dict().keys()'

    # Make sure safe_eval works with functions we allow.
    assert safe_eval('abs') == 'abs'
    assert safe

# Generated at 2022-06-25 12:36:47.920496
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('[1, 2, 3]')
    assert result == [1, 2, 3]



# Generated at 2022-06-25 12:36:54.741419
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This function tests safe_eval for the following conditions:
    1. safe_eval returns a string
    2. safe_eval returns a dict
    3. safe_eval returns a list
    '''

    print("Testing safe_eval...")

    # Test Case 1: String
    str_0 = 'Not yet implemented'
    # test_str_0 = safe_eval(str_0)
    # print("Test Case 1 - String:", test_str_0)

    # Test Case 2: Dict
    dict_0 = '{"foo": "bar"}'
    test_dict_0 = safe_eval(dict_0)
    print("Test Case 2 - Dict:", test_dict_0)

    # Test Case 3: List
    list_0 = "['one', 'two', 'three', 'four']"

# Generated at 2022-06-25 12:37:05.490251
# Unit test for function safe_eval
def test_safe_eval():
    # Specifying expected exception to be raised
    with pytest.raises(SyntaxError):
        assert safe_eval(test_case_0()) == None


# Generated at 2022-06-25 12:37:16.047605
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:20.955684
# Unit test for function safe_eval
def test_safe_eval():
    test_input_0 = 'not_implemented'
    expected_0 = 'Not yet implemented'

    actual_0 = safe_eval(test_input_0)

    if (actual_0 != expected_0):
        raise AssertionError("Expected result: %s Actual result: %s" % (expected_0, actual_0))

# unit tests
if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:31.871831
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing Function safe_eval")
    try:
        expr = 'result = 6 * 7'
        test_safe_eval_result = safe_eval(expr)
        expected_result = 42
        if expected_result != test_safe_eval_result:
            print("Error: Test 1")
    except Exception as e:
        print("Error: Test 1")
    try:
        expr = 'result = range(5)'
        test_safe_eval_result = safe_eval(expr)
        expected_result = range(5)
        if expected_result != test_safe_eval_result:
            print("Error: Test 2")
    except Exception as e:
        print("Error: Test 2")

# Generated at 2022-06-25 12:37:41.348785
# Unit test for function safe_eval
def test_safe_eval():
    # check basic functionality
    arg_0 = "'{{ ansible_hostname }}'"
    expect_0 = "'{{ ansible_hostname }}'"
    actual_0 = safe_eval(arg_0)
    assert actual_0 == expect_0

    # function calls are disallowed
    arg_1 = "'{{ ansible_hostname|upper }}'"
    expect_1 = "'{{ ansible_hostname|upper }}'"
    actual_1 = safe_eval(arg_1)
    assert actual_1 == expect_1

    # tuple is allowed
    arg_2 = "(1, 2, 3)"
    expect_2 = (1, 2, 3)
    actual_2 = safe_eval(arg_2)
    assert actual_2 == expect_2

    # tuple is allowed
    arg_3 = "True"
    expect

# Generated at 2022-06-25 12:37:51.109596
# Unit test for function safe_eval
def test_safe_eval():

    # case 0
    # test with a string
    result = safe_eval('"Not yet implemented"')
    assert(result == 'Not yet implemented')

    # case 1
    # test with an integer
    result = safe_eval('10')
    assert(result == 10)

    # case 2
    # test with a floating point number
    result = safe_eval('10.0')
    assert(result == 10.0)

    # case 3
    # test with a positive number
    result = safe_eval('+10.0')
    assert(result == 10.0)

    # case 4
    # test with a negative number
    result = safe_eval('-10.0')
    assert(result == -10.0)

    # case 5
    # test with an expression

# Generated at 2022-06-25 12:38:00.231095
# Unit test for function safe_eval
def test_safe_eval():
    """
    Tests for safe_eval
    """

    # Make sure safe_eval is a function
    assert callable(safe_eval)

    # Test for safe_eval() returning a string
    assert isinstance(safe_eval(''), string_types)

    # Test for safe_eval() returning an int
    assert isinstance(safe_eval('123'), int)

    # Test for safe_eval() returning a boolean
    assert safe_eval('True') is True
    assert safe_eval('False') is False

    # Test for safe_eval() returning a list
    assert isinstance(safe_eval('["a", "b", "c"]'), list)

    # Test for safe_eval() returning a dict
    assert isinstance(safe_eval('{"a": 1, "b": 2, "c": 3}'), dict)

    # Test

# Generated at 2022-06-25 12:38:10.538941
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:14.281732
# Unit test for function safe_eval
def test_safe_eval():
    # test case 0
    str_0 = 'Not yet implemented'
    assert safe_eval(str_0) is None


# Generated at 2022-06-25 12:38:17.607472
# Unit test for function safe_eval
def test_safe_eval():
    try:
        # Test with Not yet implemented
        test_case_0()
    except Exception as e:
        AssertionError(str(e))


# Generated at 2022-06-25 12:38:44.029913
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:46.420446
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        # test_case_0()
    ]
    for t in test_cases:
        print('Executing test case: %s' % t.__name__)
        t()

# Generated at 2022-06-25 12:38:54.895716
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test for safe_eval
    '''
    assert 'MISSING' == safe_eval('{{ foo }}', dict(foo='MISSING'))

    # handle bare strings
    assert 'hello' == safe_eval('hello')
    # string args
    assert 'HELLO' == safe_eval('"HELLO"')
    # number args
    assert 42 == safe_eval('42')
    assert 4.2 == safe_eval('4.2')
    # None
    assert None == safe_eval('None')
    # list args
    assert [1, 2, 3] == safe_eval('[1,2,3]')
    # dict args
    assert dict(a='foo', b='bar') == safe_eval('{"a":"foo", "b":"bar"}')
    # bool args

# Generated at 2022-06-25 12:39:01.400457
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:39:03.183306
# Unit test for function safe_eval
def test_safe_eval():
    print('\nUnit test for function safe_eval')
    results = safe_eval('3.5')
    print(results)


# Generated at 2022-06-25 12:39:06.204336
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '{"a": "b"}'
    str_2 = 'a'
    map_1 = safe_eval(str_1)
    print(map_1)
    map_2 = safe_eval(str_2)
    print(map_2)


# Generated at 2022-06-25 12:39:10.390727
# Unit test for function safe_eval
def test_safe_eval():
    # Initialize parameters
    expr = "{{ foo }}"
    locals = None
    include_exceptions = False
    expected_result = None
    expected_exception = None

    # Call function to test
    result = safe_eval(expr, locals, include_exceptions)

    # Compare result and expected
    assert result == expected_result
    assert sys.exc_info()[0] == expected_exception


# Generated at 2022-06-25 12:39:19.205173
# Unit test for function safe_eval
def test_safe_eval():
    from datetime import datetime
    from collections import defaultdict
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()

# Generated at 2022-06-25 12:39:22.795003
# Unit test for function safe_eval
def test_safe_eval():
    test_data = '"{{ ansible_facts.distribution }}"'
    str_0 = '"{{ ansible_facts.distribution }}"'
    result_0 = safe_eval(str_0)
    if result_0 == test_data:
        sys.stdout.write('SUCCESS\n')
    else:
        sys.stdout.write('FAILURE\n')
        sys.exit(1)


test_case_0()
test_safe_eval()

# Generated at 2022-06-25 12:39:24.617576
# Unit test for function safe_eval
def test_safe_eval():
    """
    Function calls are not allowed in safe_eval,
    but builtin functions are allowed.
    """
    assert safe_eval('1 + 1') == 2
    assert safe_eval('len') == len  # builtin functions are allowed
