

# Generated at 2022-06-25 12:29:46.833661
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = [(0, 'a'), (1, 'b'), (2, 'c')]
    dict_0 = {'a': 0, 'b': 1, 'c': 2}

    # Test case to check if the safe_eval function properly converts a when_item running with_items
    # with a list variable as the expression.
    assert safe_eval('a', dict_0) == 0
    assert safe_eval('b', dict_0) == 1
    assert safe_eval('c', dict_0) == 2

    # Test case to check if the safe_eval function properly converts a when_item running with_items
    # with a item variable as the expression.
    assert safe_eval('0', dict_0) == 0
    assert safe_eval('1', dict_0) == 1

# Generated at 2022-06-25 12:29:57.312068
# Unit test for function safe_eval
def test_safe_eval():

    # Tests the safe_eval function on a string with a list
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # Tests the safe_eval function on a string with a tuple
    assert safe_eval('(1,2,3)') == (1, 2, 3)

    # Tests the safe_eval function on a string with a dictionary
    assert safe_eval('{1:2,3:4}') == {1: 2, 3: 4}

    # Tests the safe_eval function on a string with a dictionary
    assert safe_eval('{1}') == {1}

    # Tests the safe_eval function on a string with a set
    assert safe_eval('{1}') == {1}

    # Tests the safe_eval function on a string with a float

# Generated at 2022-06-25 12:30:05.621746
# Unit test for function safe_eval
def test_safe_eval():
    arg0 = "{{hi}}"
    arg1 = None
    mylist_static_var = ['hi', 'by', 'bye']
    mydict_static_var = {'test1': 'test2', 'test3': 'test4'}
    mystring_static_var = 'test_string'
    myint_static_var = 1
    myfloat_static_var = 3.14

    # Case 1 - test a dictionay variable
    # Input:
    #   arg1 = {'some_key': 'some_value'}
    # Expected output:
    #   ['something_else']
    my_dict = {'some_key': 'some_value'}
    expected_output = ['something_else']
    assert safe_eval('something_else', my_dict) == expected_output

    # Case

# Generated at 2022-06-25 12:30:16.749249
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:20.315853
# Unit test for function safe_eval
def test_safe_eval():
    print("Test safe_eval:")
    bool_0 = None
    var_0 = safe_eval(bool_0, bool_0)
    print(" type(var_0) = ", type(var_0))
    print(" var_0 = ", var_0)
    print("")



# Generated at 2022-06-25 12:30:22.636797
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = None
    var_0 = safe_eval(bool_0, bool_0)
    assert var_0 is not None



# Generated at 2022-06-25 12:30:33.699239
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys
    import os
    from ansible.module_utils.common.text.converters import container_to_text, to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    #from ansible.module_utils.common.text.converters import string_to_bool
    #from ansible.module_utils.common.text.converters import boolean
    #from ansible.module_utils.common.text.converters import to_native
    #from ansible.module_utils.common.text.converters import to_text
    #from ansible.module_utils.common.text.converters import to_bytes
    #from ansible.module_utils.common.text.converters import

# Generated at 2022-06-25 12:30:44.360506
# Unit test for function safe_eval
def test_safe_eval():
    # Test all types of input
    assert safe_eval("1+1") == 2
    assert safe_eval("2") == 2
    assert safe_eval("'1'+'1'") == '11'
    assert safe_eval("'2'") == '2'
    assert safe_eval("None") is None
    assert safe_eval("1.1+1.1") == 2.2
    assert safe_eval("2.2") == 2.2
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("({})") == {}
    assert safe_eval("[]") == []
    assert safe_eval("()") == ()

    # Test invalid input

# Generated at 2022-06-25 12:30:53.600840
# Unit test for function safe_eval
def test_safe_eval():
    variables = dict(test_bool='yes')
    result, exception = safe_eval("test_bool == 'yes'", variables, True)
    assert result
    assert exception is None

    result, exception = safe_eval("test_bool == 'no'", variables, True)
    assert not result
    assert exception is None

    result, exception = safe_eval("test_bool == '1'", variables, True)
    assert not result
    assert exception is None

    result, exception = safe_eval("test_bool == '0'", variables, True)
    assert not result
    assert exception is None

    result, exception = safe_eval("test_bool in ['yes', 'no']", variables, True)
    assert result
    assert exception is None

    result, exception = safe_eval("test_bool in ['no']", variables, True)

# Generated at 2022-06-25 12:30:57.412250
# Unit test for function safe_eval
def test_safe_eval():
    # create test case
    bool_0 = False
    var_0 = safe_eval(bool_0, bool_0)
    assert (var_0 == False)
    class_0 = type(bool_0)
    assert (class_0 is bool)

    func_0 = type(safe_eval)
    assert (func_0 is type)


# Generated at 2022-06-25 12:31:06.680809
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = None
    bool_1 = True
    bool_2 = False
    op_1 = '='
    op_2 = '=='
    op_3 = '!='
    op_4 = '<'
    op_5 = '<='
    op_6 = '>'
    op_7 = '>='
    op_8 = 'and'
    op_9 = 'or'
    op_10 = 'not'
    op_11 = 'in'
    op_12 = 'not in'
    op_13 = 'is'
    op_14 = 'is not'
    var_0 = safe_eval('foo', dict(foo='bar'))
    var_1 = safe_eval('foo', dict(foo=None))
    var_2 = safe_eval('foo' 'bar')

# Generated at 2022-06-25 12:31:11.393876
# Unit test for function safe_eval
def test_safe_eval():
    TEST_CASE_0 = ['test_case_0',[None]]
    test_cases = {0: TEST_CASE_0}
    for test_case in test_cases:
        if test_case == 0:
            # test_case_0
            result = test_case_0()
            assert result == None


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:31:21.261308
# Unit test for function safe_eval
def test_safe_eval():
    val = safe_eval("[1,2,3]")
    assert val == [1, 2, 3]
    val = safe_eval("{'a': 'b'}")
    assert val == {'a': 'b'}
    val = safe_eval("foo")
    assert val == 'foo'
    val = safe_eval("False or False")
    assert val is False
    val = safe_eval("True and False")
    assert val is False
    val = safe_eval("42")
    assert val == 42
    val = safe_eval("-42")
    assert val == -42
    val = safe_eval("-42.0")
    assert val == -42.0
    val = safe_eval("'foo'")
    assert val == 'foo'

# Generated at 2022-06-25 12:31:30.116650
# Unit test for function safe_eval
def test_safe_eval():

    # CASE 0
    try:
        test_case_0()
    except SyntaxError:
        pass
    except SystemExit:
        pass
    except:
        print(sys.exc_info())
        raise


if __name__ == '__main__':

    if len(sys.argv) == 2:
        C.DEFAULT_MODULE_PATH = sys.argv.pop()
        if len(sys.argv) > 1:
            sys.stderr.write("usage: safe_eval.py [ansible_module_directory]\n")
            sys.exit(1)

    test_safe_eval()

# Generated at 2022-06-25 12:31:39.844768
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:46.954449
# Unit test for function safe_eval
def test_safe_eval():
    the_dict = {'a_list': [1, 2, 3], 'a_dict': {1: 'a', 2: 'b', 3: 'c'}}
    the_dict['a_list_var'] = '{{a_list}}'
    the_dict['a_dict_var'] = '{{a_dict}}'
    the_dict['a_str_var'] = 'str'

    # Case 0: bool_0 = None
    bool_0 = None
    var_0 = safe_eval(bool_0, the_dict)
    if var_0 != bool_0:
        raise AssertionError("Case 0: safe_eval should return None")

    # Case 1: bool_1 = True
    bool_1 = True
    var_1 = safe_eval(bool_1, the_dict)
   

# Generated at 2022-06-25 12:31:48.427147
# Unit test for function safe_eval
def test_safe_eval():
    # case 0
    assert test_case_0() == None



# Generated at 2022-06-25 12:31:59.944018
# Unit test for function safe_eval
def test_safe_eval():
    # import module snippets
    no_temp_vars = dict(
        a_list_variable = dict(
            first_item = 1,
            second_item = 2,
            third_item = 3
        )
    )

    temp_vars = dict(
        a_list_variable = [1,2,3]
    )

    # no temp vars
    # with_items: a_list_variable
    val = safe_eval('a_list_variable', temp_vars, False)
    assert val == temp_vars['a_list_variable']

    # no temp vars
    # with_items: a_list_variable
    val = safe_eval('a_list_variable', no_temp_vars, False)
    assert isinstance(val, string_types)

    # temp vars


# Generated at 2022-06-25 12:32:04.433536
# Unit test for function safe_eval
def test_safe_eval():
    print('Unit test for function safe_eval')
    try:
        test_case_0()
    except Exception as e:
        print('Exception raised:', e)
        traceback.print_exc()
        print('Unit test failed')
    print('Unit test completed')
    print('----------------------------------------------------------------------')


# Generated at 2022-06-25 12:32:15.667750
# Unit test for function safe_eval
def test_safe_eval():
    # Try to evaluate a variable with type bool
    #
    # Input:
    #   bool_0: None
    #   dict_0: None
    #
    # Expected Output:
    #   bool_0
    #
    bool_0 = None
    dict_0 = None
    var_0 = safe_eval(bool_0, dict_0)
    if var_0 is None:
        sys.exit(1)

    # Try to evaluate a variable with type str
    #
    # Input:
    #   str_0: "This is a string"
    #   dict_0: None
    #
    # Expected Output:
    #   str_0
    #
    str_0 = "This is a string"
    dict_0 = None

# Generated at 2022-06-25 12:32:33.065434
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:35.643136
# Unit test for function safe_eval
def test_safe_eval():
    print("*** Test safe_eval: String passed to safe_eval is parsed correctly.")
    test_case_0()
    print("*** Test safe_eval: Test Passed")

if __name__ == "__main__":
    if C.DEFAULT_DEBUG:
        test_safe_eval()

# Generated at 2022-06-25 12:32:44.239324
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:54.933418
# Unit test for function safe_eval
def test_safe_eval():

    # 1. test simple case of an integer expression
    str_0 = '3 + 4'
    result_0 = safe_eval(str_0)
    assert(result_0 == 7)

    # 2. test simple case of a string expression
    str_1 = "'string'"
    result_1 = safe_eval(str_1)
    assert(result_1 == 'string')

    # 3. test simple case of a boolean expression
    str_2 = "(1 == 1)"
    result_2 = safe_eval(str_2)
    assert(result_2 == True)

    # 4. test simple case of a boolean expression
    str_3 = "(1 != 1)"
    result_3 = safe_eval(str_3)
    assert(result_3 == False)

    # 5. test simple case of a boolean expression


# Generated at 2022-06-25 12:32:55.771352
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:33:01.128498
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ansible_facts'  # Good string
    str_1 = 'ansible_fact'   # Bad string
    var_0 = safe_eval(str_0)
    var_1 = safe_eval(str_1)
    assert var_0 == 'ansible_facts' and var_1 == 'ansible_fact'


# Generated at 2022-06-25 12:33:10.501870
# Unit test for function safe_eval
def test_safe_eval():
    print('test_safe_eval')
    # Evaluate with no exceptions
    str1 = 'ansible_facts'
    var1 = safe_eval(str1)
    print('var1', var1)
    assert var1 == 'ansible_facts'

    # Evaluate with exceptions
    str2 = 'ansible_facts'
    var2 = safe_eval(str2, include_exceptions=True)
    print('var2', var2)
    assert var2 == ('ansible_facts', None)

    # Evaluate with a valid Python expression
    str3 = 'ansible_facts.get("ansible_os_family")'
    var3 = safe_eval(str3)
    print('var3', var3)
    assert var3 == 'ansible_facts.get("ansible_os_family")'



# Generated at 2022-06-25 12:33:19.058264
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('test_list') == ['test_list']
    assert safe_eval('test_dict') == {'test_dict': ['test_dict']}
    assert safe_eval('test') == 'test'
    assert safe_eval('["test_list"]') == ['test_list']
    assert safe_eval('{"test_dict": ["test_dict"]}') == {'test_dict': ['test_dict']}
    assert safe_eval('"test"') == 'test'
    assert safe_eval('123', {}, None) == 123
    assert safe_eval('123', None, None) == 123
    assert safe_eval('0', None, None) == 0
    assert safe_eval('-123', None, None) == -123
    assert safe_eval('True', None, None) is True

# Generated at 2022-06-25 12:33:28.508824
# Unit test for function safe_eval
def test_safe_eval():
    # Note: some of these tests are known to fail, but are kept here as a reference
    # of the desired behavior and to make sure we don't introduce regressions
    # in the future.

    # Test 0
    str_0 = 'ansible_facts'
    var_0 = safe_eval(str_0)
    # Test 1
    str_1 = 'foo'
    var_1 = safe_eval(str_1)
    # Test 2
    str_2 = 'foo | map(attribute=\'bar\') | list'
    var_2 = safe_eval(str_2)
    # Test 3
    str_3 = 'foo | map(attribute=\'bar\') | list | sum(start=5)'
    var_3 = safe_eval(str_3)
    # Test 4

# Generated at 2022-06-25 12:33:34.590372
# Unit test for function safe_eval
def test_safe_eval():
    def test_case_1():
        str_0 = "'a' in ['a', 'b']"
        var_0 = safe_eval(str_0)
        msg_0 = "result: %s" % (to_native(var_0))
        assert var_0 is True, msg_0

    def test_case_2():
        str_0 = 'a in ["a", "b"]'
        var_0 = safe_eval(str_0)
        msg_0 = "result: %s" % (to_native(var_0))
        assert var_0 is True, msg_0

    def test_case_3():
        str_0 = "ansible_facts['ansible_os_family'] == 'RedHat'"

# Generated at 2022-06-25 12:33:51.473150
# Unit test for function safe_eval
def test_safe_eval():
    print('in test_safe_eval')
    test_case_0()

# Unit test if this file is called directly
if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:33:56.108777
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = "{{ansible_local.test.test_var_1}}"
    var_1 = safe_eval(str_1)
    assert var_1 == "some string"

    str_2 = "{{ansible_local.test.test_var_1}}"
    var_2 = safe_eval(str_2)
    assert var_2 == "some string"

    str_3 = "[1, 2, 3]"
    var_3 = safe_eval(str_3)
    assert var_3 == [1, 2, 3]

    str_4 = "[1, 2, 3]"
    var_4 = safe_eval(str_4)
    assert var_4 == [1, 2, 3]

    str_5 = "{'this': 'that'}"

# Generated at 2022-06-25 12:33:58.725046
# Unit test for function safe_eval
def test_safe_eval():
    print("INFO: Start unit test for function safe_eval.")
    test_case_0()
    print("INFO: Finish unit test for function safe_eval.")

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:34:10.158181
# Unit test for function safe_eval
def test_safe_eval():
    TEST_DATAS = [
        (1, 1),
        ('[1, 2]', [1, 2]),
        ('a_list_variable', u'a_list_variable'),
        ('((1, 2, 3), (4, 5, 6))', ((1, 2, 3), (4, 5, 6))),
        ('a_list_variable[0]', u'a_list_variable[0]'),
    ]

    for args, exp_result in TEST_DATAS:
        result = safe_eval(args)
        if result != exp_result:
            raise AssertionError("Expected: {} Got: {}".format(exp_result, result))

if __name__ == '__main__':
    #test_safe_eval()
    test_case_0()

# Generated at 2022-06-25 12:34:18.890898
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('[1,2,3]', include_exceptions=True)[0] == [1,2,3]
    assert safe_eval('[1,2,3]', include_exceptions=True)[1] is None
    assert safe_eval('{"a":"b"}') == {"a":"b"}
    assert safe_eval('{"a":"b"}', include_exceptions=True)[0] == {"a":"b"}
    assert safe_eval('{"a":"b"}', include_exceptions=True)[1] is None
    assert safe_eval('"a"') == "a"
    assert safe_eval('"a"', include_exceptions=True)[0] == "a"

# Generated at 2022-06-25 12:34:22.193388
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        {
            "input": 'ansible_facts',
            "want": 'ansible_facts',
        }
    ]
    for t in test_cases:
        assert safe_eval(t["input"]) == t["want"]



# Generated at 2022-06-25 12:34:25.541154
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 12:34:35.608331
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = 'ansible_facts'

    assert(safe_eval(var_0) == var_0)

    var_1 = 'foo'

    assert(safe_eval(var_1) == var_1)

    var_2 = 'hostname'

    assert(safe_eval(var_2) == var_2)

    var_3 = 'hostvars[hostname]'

    assert(safe_eval(var_3) == var_3)

    var_4 = 'hostvars[hostname][\'ansible_facts\']'

    assert(safe_eval(var_4) == var_4)

    var_5 = 'hostvars[hostname][\'ansible_default_ipv4\'][\'address\']'

    assert(safe_eval(var_5) == var_5)



# Generated at 2022-06-25 12:34:39.944321
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test cases for function safe_eval
    '''
    test_case_0()


# Unit tests for function safe_eval
if __name__ == '__main__':
    sys.exit(1)
    test_safe_eval()

# Generated at 2022-06-25 12:34:49.248208
# Unit test for function safe_eval
def test_safe_eval():
    # Try everything in our whitelist
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('None')
    assert safe_eval('null') is None
    assert safe_eval('true')
    assert not safe_eval('false')
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"hello"') == "hello"
    assert safe_eval("'hello'") == "hello"
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 - 1') == 0
    assert safe_

# Generated at 2022-06-25 12:35:26.843329
# Unit test for function safe_eval
def test_safe_eval():

    # No additional args
    var_1 = safe_eval('True')
    assert var_1 == True

    # Single arg
    var_2 = safe_eval('True and False')
    assert var_2 == False

    # Multiple args
    var_3 = safe_eval('False or True and False')
    assert var_3 == False

    # Incl. parentheses
    var_4 = safe_eval('(True and False) or (False and True)')
    assert var_4 == False

    # Incl. not
    var_5 = safe_eval('not False')
    assert var_5 == True

    # Boolean Operation
    var_6 = safe_eval('True and False')
    assert var_6 == False

    # Boolean Operator
    var_7 = safe_eval('True or False')

# Generated at 2022-06-25 12:35:27.858702
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:35:28.846263
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:35:35.007604
# Unit test for function safe_eval
def test_safe_eval():
    # '''
    # Test for safe_eval

    # This is intended for allowing things like:
    # with_items: a_list_variable

    # Where Jinja2 would return a string but we do not want to allow it to
    # call functions (outside of Jinja2, where the env is constrained).
    # '''
    pass



# Generated at 2022-06-25 12:35:43.746391
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended for allowing things like:
    with_items: a_list_variable

    Where Jinja2 would return a string but we do not want to allow it to
    call functions (outside of Jinja2, where the env is constrained).

    Based on:
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''

    # initializer
    safe_eval_str = '''
    [{
        "foo": 1,
        "bar": "baz"
    },
    {"foo": 2, "bar": "baz"}
    ]
    '''

# Generated at 2022-06-25 12:35:45.502410
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval(1)
    except Exception as e:
        print("EXCEPTION:", repr(e))


# Generated at 2022-06-25 12:35:55.024900
# Unit test for function safe_eval
def test_safe_eval():
    str1 = 'ansible_facts'
    assert safe_eval(str1) == 'ansible_facts'

    str1 = '10'
    assert safe_eval(str1) == 10

    str2 = '10 / 2'
    assert safe_eval(str2) == 5

    str3 = '10 / 2 * 4'
    assert safe_eval(str3) == 20

    str4 = '10 / (2 * 4)'
    assert safe_eval(str4) == 1.25

    str5 = '4 + 5'
    assert safe_eval(str5) == 9

    str6 = '4 + 5 / 2'
    assert safe_eval(str6) == 7

    str7 = '4 + 5 / 2 + 1'
    assert safe_eval(str7) == 8


# Generated at 2022-06-25 12:36:04.745480
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{"ansible_fact": "ansible_all_ipv4_addresses"}'
    str_1 = 'ansible_all_ipv4_addresses'

    # Evaluate string
    var_0 = safe_eval(str_0)
    assert type(var_0) == dict

    # Evaluate dict item
    var_1 = safe_eval(str_1)
    assert type(var_1) is list

    # Squeeze variable output to string and compare
    str_2 = container_to_text(var_1)
    assert type(str_2) == str

    # Convert variable output to JSON and compare
    str_3 = to_native(var_1)
    assert type(str_3) == str


# Generated at 2022-06-25 12:36:10.300292
# Unit test for function safe_eval
def test_safe_eval():

    # Example
    str_1 = 'ansible_facts'
    ansible_facts = {'test_1': 'foo'}
    result = safe_eval(str_1, dict(ansible_facts=ansible_facts))
    print('Example -- str_1: %s  result: %s' % (str_1, result))

    # Example
    str_2 = 'ansible_facts["test_1"]'
    result = safe_eval(str_2, dict(ansible_facts=ansible_facts))
    print('Example -- str_2: %s  result: %s' % (str_2, result))

    # Example
    str_3 = 'ansible_facts["test_1"]["foo"]["bar"]'

# Generated at 2022-06-25 12:36:19.823735
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "test_string_0"
    result = safe_eval(str_0)
    assert type(result) == str
    assert result == "test_string_0"
    # test for datastructure evaluation
    test_list = [1, 2, 3]
    result = safe_eval(test_list)
    assert type(result) == list
    assert result == test_list
    test_dict = {'test': 'dict'}
    result = safe_eval(test_dict)
    assert type(result) == dict
    assert result == test_dict
    test_tuple = (1, 2, 3)
    result = safe_eval(test_tuple)
    assert type(result) == tuple
    assert result == test_tuple
    # test for string evaluation

# Generated at 2022-06-25 12:37:23.812240
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:24.720093
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:37:34.108280
# Unit test for function safe_eval
def test_safe_eval():
    print("In test_safe_eval")

    # Check for invalid expression
    str_0 = "ansible_facts.get('ansible_os_family') == " + "'RedHat' and ansible_distribution_major_version == '7'"
    result, error = safe_eval(str_0, include_exceptions=True)
    if error is not None:
        print("Invalid expression: %s" % str_0)
        sys.exit(-1)
    else:
        print("Valid expression: %s" % str_0)

    # Check for valid expression
    str_0 = "'ansible_facts' in facts"
    result, error = safe_eval(str_0, include_exceptions=True)
    if error is not None:
        print("Invalid expression: %s" % str_0)
        sys

# Generated at 2022-06-25 12:37:36.118641
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing function safe_eval')
    assert test_case_0() == 'ansible_facts'
    print('safe_eval works')



# Generated at 2022-06-25 12:37:44.066480
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'ansible_facts'
    str_1_res = safe_eval(str_1)
    assert str_1_res == 'ansible_facts'

    str_2 = '{`test_val_2`}'
    str_2_res = safe_eval(str_2)
    assert str_2_res == '{`test_val_2`}'

    str_3 = '{{ test_val_3 }}'
    str_3_res = safe_eval(str_3)
    assert str_3_res == '{{ test_val_3 }}'

    str_4 = '{{{ test_val_4 }}}'
    str_4_res = safe_eval(str_4)
    assert str_4_res == '{{{ test_val_4 }}}'

   

# Generated at 2022-06-25 12:37:54.624608
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = '({0:3})'
    var_1 = '({0:3})'.format(1)
    var_2 = '({0:3})'.format(2)
    var_3 = '({0:3})'.format(3)
    var_4 = '({0:3})'.format(4)
    var_5 = '({0:3})'.format(5)
    var_6 = '({0:3})'.format(6)
    var_7 = '({0:3})'.format(7)
    var_8 = '({0:3})'.format(8)
    var_9 = '({0:3})'.format(9)
    var_10 = '({0:3})'.format(10)
    var_11 = '({0:3})'.format(11)

# Generated at 2022-06-25 12:38:06.220288
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval('jkl')
    assert var_0 == 'jkl'

    var_1 = safe_eval('True')
    assert var_1 is True

    var_2 = safe_eval('False')
    assert var_2 is False

    var_3 = safe_eval('1 + 2')
    assert var_3 == 3

    var_4 = safe_eval('1 - 2')
    assert var_4 == -1

    # var_5 = safe_eval('1 * 2')
    # assert var_5 == 2

    var_6 = safe_eval('1 / 2')
    assert var_6 == 0.5

    var_7 = safe_eval('1 // 2')
    assert var_7 == 0

    var_8 = safe_eval('1 ** 2')

# Generated at 2022-06-25 12:38:08.179560
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval('1+1')
    if var_0 == 2:
        print("test_safe_eval() passed.")


# Generated at 2022-06-25 12:38:17.733748
# Unit test for function safe_eval
def test_safe_eval():
    '''Exercise the safe_eval function and its embedded code,
    capturing the output in the event of an exception
    '''

    class Logger(object):
        '''Create a logger that records what was written to it
        and can print the results as debugging information if
        an exception is raised.
        '''

        def __init__(self):
            self.log = []

        def write(self, buf):
            self.log.append(buf)

        def flush(self):
            pass

        def print_log(self, exc_info, test_case_str):
            '''Print the log information to the screen
            in a way that makes it clear which unit test
            failed and what the exception was.
            '''
            print("Unit test failed: %s" % test_case_str)

# Generated at 2022-06-25 12:38:19.016251
# Unit test for function safe_eval
def test_safe_eval():
    assert 'ansible_facts' == safe_eval('ansible_facts')


# Generated at 2022-06-25 12:39:03.183870
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('ansible_facts') == 'ansible_facts'
    assert safe_eval('ansible_facts.a.b.c', {'ansible_facts': {'a': {'b': {'c': 1}}}}) == 1
    assert safe_eval('ansible_facts["a"]["b"]["c"]', {'ansible_facts': {'a': {'b': {'c': 1}}}}) == 1
    assert safe_eval('ansible_facts.a.b.c', {'ansible_facts': {'a': {'b': {'c': []}}}}) == []

# Generated at 2022-06-25 12:39:05.227434
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ansible_facts'
    var_0 = safe_eval(str_0)

    assert var_0 == 'ansible_facts'


# Generated at 2022-06-25 12:39:12.234804
# Unit test for function safe_eval
def test_safe_eval():

    # Given test case data
    str_0 = 'ansible_facts'
    str_1 = 'ansible_facts["network"]["interfaces"]["eth0"]["ipv4"]["address"]'
    str_2 = 'ansible_facts["string_var"] + ansible_facts["fact"]'
    str_3 = "ansible_facts['network']['interfaces']['eth0']['ipv4']['address']"
    str_4 = "ansible_facts['string_var'] + ansible_facts['fact']"
    str_5 = 'ansible_facts["string_var"] + ansible_facts["fact"]'
    str_6 = 'ansible_facts["network"]["interfaces"]["eth0"]["ipv4"]["netmask"]'

# Generated at 2022-06-25 12:39:15.308473
# Unit test for function safe_eval
def test_safe_eval():
    # Check if variable 'ansible_facts' is defined
    assert builtins.isinstance(safe_eval('ansible_facts'), type(None)) is True


# Generated at 2022-06-25 12:39:22.653993
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ansible_facts'
    var_0 = safe_eval(str_0)
    assert 'ansible_facts' in sys.modules
    assert sys.modules['ansible_facts'] == var_0
    assert isinstance(var_0, dict)

    str_1 = 'ansible_facts.get("os_family", "")'
    var_1 = safe_eval(str_1)
    assert var_1 == 'RedHat'

    str_2 = 'ansible_facts.get("invalid_key", "")'
    var_2 = safe_eval(str_2)
    assert var_2 == ''

    str_3 = 'ansible_facts["hostvars"]["localhost"]["ansible_facts"]["os_family"]'
    var_3 = safe_eval

# Generated at 2022-06-25 12:39:25.262559
# Unit test for function safe_eval
def test_safe_eval():
    arg_0 = 'ansible_facts'
    arg_1 = dict()
    arg_2 = True

    (returned_val, exc) = safe_eval(arg_0, arg_1, arg_2)
    assert exc != None
    assert returned_val != None



# Generated at 2022-06-25 12:39:26.399217
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:39:33.368798
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit tests for safe_eval
    '''
    def test_case_0(test_file):
        '''
        Test for str(ansible_facts)
        '''
        str_0 = 'ansible_facts'
        result_0 = safe_eval(str_0)
        assert (result_0 == 'ansible_facts')

        # if result_0 == 'ansible_facts':
        #     test_file.write('Test case test_case_0 passed\n')
        # else:
        #     test_file.write('Test case test_case_0 failed!\n')

    def test_case_1(test_file):
        '''
        Test for str(ansible_facts.os_family)
        '''