

# Generated at 2022-06-25 12:29:41.599071
# Unit test for function safe_eval
def test_safe_eval():
    input_1 = [[1, 2], [3, 4]]
    expected_result = [[1, 2], [3, 4]]
    actual_result = safe_eval(input_1, {})
    assert expected_result == actual_result

    input_2 = [1, 2, 3]
    expected_result = [1, 2, 3]
    actual_result = safe_eval(input_2, {})
    assert expected_result == actual_result

    input_3 = 5
    expected_result = 5
    actual_result = safe_eval(input_3, {})
    assert expected_result == type(actual_result)

    input_4 = 'str'
    expected_result = 'str'
    actual_result = safe_eval(input_4, {})
    assert expected_result == type(actual_result)

# Generated at 2022-06-25 12:29:45.665878
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = {'T', 'r', 'u', 'e'}
    result = safe_eval(list_0, list_0)

    # Testing the result
    if (result == True):
        print("The result is " + str(result) + ". This is correct.")
    else:
        print("The result is " + str(result) + ". This is incorrect.")


# Generated at 2022-06-25 12:29:56.209476
# Unit test for function safe_eval
def test_safe_eval():

    # setup for test case 0
    bool_0 = True
    set_0 = {bool_0, bool_0}
    var_0 = safe_eval(set_0, set_0)
    # assert that the results of safe_eval are as expected
    assert var_0 == set_0
    pass


# this is a bit of a hack, but it works
#
# the approach is that any user-defined function can be called in a Jinja2 context
# but it can not be called in an eval() context so we add all of the names
# of funcs to the module's __dict__ and then iterate through them and add them
# to our CONSTANTS hash above. This allows Jinja2 to call them, but does not
# allow them to be called from an eval context
#
# we also add back some builtins that are required

# Generated at 2022-06-25 12:30:03.660723
# Unit test for function safe_eval
def test_safe_eval():
    test_result = ast.parse('(1 + 1) * 2', mode='eval')
    expected_result = ast.Expression(ast.BinOp(ast.BinOp(ast.Num(1), ast.Add(), ast.Num(1)), ast.Mult(), ast.Num(2)))
    assert safe_eval('(1 + 1) * 2') == eval(str(safe_eval('(1 + 1) * 2')))
    assert test_result == expected_result, "The parsed expression should match the expected result"


# Generated at 2022-06-25 12:30:09.140694
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval('1 + 1') == 2)
    assert(safe_eval('1 + True') == 2)
    assert(safe_eval('1 + "2"') == Exception)
    assert(safe_eval('1 + [1,2]') == Exception)
    assert(safe_eval('2 * [1,2]') == [1, 2, 1, 2])
    assert(safe_eval('{1} + {1}') == Exception)


# Generated at 2022-06-25 12:30:19.706059
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing: In function test_safe_eval')

    # test_case_0
    bool_0 = True
    set_0 = {bool_0, bool_0}
    var_0 = safe_eval(set_0, set_0)
    assert var_0 == set_0

    # test_case_1
    dict_0 = {'True': True, 'False': False, 'None': None}
    list_0 = [True, dict_0, dict_0, dict_0]
    var_0 = safe_eval(list_0, dict_0)
    assert var_0 == list_0

    # test_case_2
    dict_0 = {'True': True, 'False': False, 'None': None}

# Generated at 2022-06-25 12:30:25.771469
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        test_case_0
    ]
    for test_case in test_cases:
        try:
            test_case()
        except Exception as err:
            print("ERROR: function safe_eval failed in test_case {}".format(test_case.__name__), file=sys.stderr)
            raise err


# Generated at 2022-06-25 12:30:35.611352
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1", {}) == 2
    assert safe_eval("1+1", {}, True) == (2, None)
    assert safe_eval("1+1") == 2
    assert safe_eval("POWEROFF", {}, True) == ('POWEROFF', None)
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("2+2") == 4
    assert safe_eval("[1,2]") == [1, 2]
    assert safe_eval("(1,2)") == (1, 2)
    assert safe_eval("{}") == {}
    assert safe_eval("{1:2}") == {1: 2}

# Generated at 2022-06-25 12:30:45.111992
# Unit test for function safe_eval
def test_safe_eval():

    # Here is the list of variables I will be using in the
    # test:

    # Booleans:
    bool_true = True
    bool_false = False

    # Integers:
    int_neg_1 = -1
    int_pos_1 = 1
    int_0 = 0
    int_pos_2 = 2
    int_neg_2 = -2
    int_100 = 100
    int_neg_100 = -100

    # Floats:
    float_pos_1_1 = 1.1
    float_neg_1_1 = -1.1
    float_neg_2_2 = -2.2
    float_pos_2_2 = 2.2

    # Strings:
    str_0 = '0'
    str_1 = '1'

# Generated at 2022-06-25 12:30:53.073067
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval for syntax error
    try:
        safe_eval('"')
        sys.exit(-1)
    except SyntaxError:
        pass

    # Test safe_eval for allowed expression
    assert safe_eval('"a"') == 'a'
    assert safe_eval('{}') == {}
    assert safe_eval('{"a"}') == {'a'}
    assert safe_eval('{"a", "b"}') == {'a', 'b'}
    assert safe_eval('["a", "b"]') == ["a", "b"]
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval("('a', 'b')") == ('a', 'b')

# Generated at 2022-06-25 12:31:03.098588
# Unit test for function safe_eval
def test_safe_eval():
    '''
    The following tests are disabled as they
    cause ansible to fail.
    '''
    list_0 = sys.argv
    int_0 = 0
    set_0 = {int_0}
    list_1 = [int_0]
    list_2 = list_1
    bool_0 = True
    bool_1 = bool_0
    bool_2 = bool_0
    str_0 = "str1"
    str_1 = str_0
    str_2 = str_0
    list_3 = [list_2]
    list_4 = [str_2]
    float_0 = float(str_0)
    float_1 = float(str_1)
    float_2 = float(float_0)
    float_3 = float(float_1)
    float_

# Generated at 2022-06-25 12:31:03.783685
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:31:10.342805
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:20.347043
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    # simple test
    result = safe_eval('myvar + 15')
    assert result == 'myvar + 15'

    # simple test
    result = safe_eval('15 - 12')
    assert result == 3

    # simple test
    result = safe_eval('[1,2,3]')
    assert result == [1,2,3]

    # simple test with bad nodes
    try:
        result = safe_eval('[1,2,3](4,5,6)')
    except Exception as e:
        assert to_text(e) == 'invalid expression ([1,2,3](4,5,6))'

    # str, then repr
    s = '[1,2,3]'
    result = safe_eval(s)

# Generated at 2022-06-25 12:31:21.898592
# Unit test for function safe_eval
def test_safe_eval():
    """
    Run unit tests for safe_eval
    """
    test_case_0()

# Generated at 2022-06-25 12:31:23.009168
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == True


# Generated at 2022-06-25 12:31:33.708119
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = True
    str_0 = "qM"
    str_1 = "V"
    str_2 = "7"
    dict_0 = {
        "f": str_1,
        str_0: str_1,
        str_2: str_1
    }
    set_0 = {dict_0, dict_0}
    list_0 = [str_1]
    list_1 = [str_2]
    dict_1 = {
        str_0: dict_0,
        str_1: list_1,
        str_2: bool_0
    }
    list_2 = [list_0, list_1, dict_0, dict_1]
    list_3 = [list_2, dict_1, dict_0, dict_1, dict_0]


# Generated at 2022-06-25 12:31:42.687413
# Unit test for function safe_eval
def test_safe_eval():
    success = True


# Generated at 2022-06-25 12:31:48.455083
# Unit test for function safe_eval
def test_safe_eval():
    # Mock variable for set_0
    set_0 = None

    # Mock variable for bool_0
    bool_0 = None
    assert isinstance(bool_0, bool)
    assert bool_0 == True
    assert bool_0 == True
    assert bool_0 == True
    assert bool_0 == True
    assert bool_0 == True
    assert bool_0 == True
    assert bool_0 == True

    # Mock variable for bool_1
    bool_1 = None
    assert isinstance(bool_1, bool)
    assert bool_1 == False
    assert bool_1 == False
    assert bool_1 == False
    assert bool_1 == False
    assert bool_1 == False
    assert bool_1 == False
    assert bool_1 == False

    # Mock variable for bool_2
    bool_2 = None

# Generated at 2022-06-25 12:31:59.942371
# Unit test for function safe_eval
def test_safe_eval():
    dict_0 = {'a': '1'}
    list_0 = [1, 2, 3, 4, 5]
    set_0 = {1, 2, 3, 4, 5, 6, 7}
    set_3 = {'False', 'False'}
    set_1 = {'True', 'True'}
    dict_2 = {'a': '1'}
    dict_4 = {'a': '1', 'b': '2'}
    dict_5 = {'a': '1', 'b': '2'}
    dict_6 = dict(dict_5)
    dict_6['a'] = '2'
    dict_6['b'] = '3'

    set_6 = {'1', '2'}

# Generated at 2022-06-25 12:32:13.440690
# Unit test for function safe_eval
def test_safe_eval():
    # tests when a string is passed and is already templated
    my_str = "{{ foo }}"
    assert type(safe_eval(my_str)) == str
    assert safe_eval(my_str) == "{{ foo }}"

    # tests when a string is passed and is already templated
    my_str = "{{ foo }}"
    assert type(safe_eval(my_str)) == str
    assert safe_eval(my_str) == "{{ foo }}"

    # tests when a list is passed and is already templated
    my_list = ['{{ foo }}', '{{ bar }}']
    assert type(safe_eval(my_list)) == list
    assert safe_eval(my_list) == ['{{ foo }}', '{{ bar }}']

    # tests when a dict is passed and is already templated


# Generated at 2022-06-25 12:32:16.244162
# Unit test for function safe_eval
def test_safe_eval():
    assert bool_0 is True
    assert bool_0 is not False
    assert bool_0 is not None
    safe_eval(bool_0)

# Test case to test safe_eval with bad values

# Generated at 2022-06-25 12:32:26.582730
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:37.084620
# Unit test for function safe_eval
def test_safe_eval():
    with pytest.raises(SystemExit):
        assert not safe_eval('true and false')
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 == 2') == True
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') is None
    assert safe_eval('true == true') == True
    assert safe_eval('false == false') == True
    assert safe_eval('1 + true') == 2
    assert safe_eval('1 + false') == 1
    assert safe_eval('null == null') == True
    assert safe_eval('"foo" == "foo"') == True
    assert safe_eval('"bar" == "foo"') == False
    assert safe_eval('1 == "1"') == False


# Generated at 2022-06-25 12:32:44.959799
# Unit test for function safe_eval
def test_safe_eval():
    print("===== test_safe_eval =====")

    # Test empty input
    print(" - Test empty input")
    result, err = safe_eval('', {'locals': None}, True)
    assert result == '', "Unexpected result: %s" % result

    # Test true
    print(" - Test true")
    result, err = safe_eval('true', {'locals': None}, True)
    assert result == True, "Unexpected result: %s" % result

    # Test true
    print(" - Test True")
    result, err = safe_eval('True', {'locals': None}, True)
    assert result == True, "Unexpected result: %s" % result

    # Test false
    print(" - Test false")

# Generated at 2022-06-25 12:32:51.037869
# Unit test for function safe_eval
def test_safe_eval():
    test_case_list = [
        test_case_0
    ]

    for test_case in test_case_list:
        try:
            test_case()
        except SystemExit:
            # This is how Ansible will exit when this module raises an exception
            sys.exit(1)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:57.933317
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    str_0 = "true"
    bool_1 = safe_eval(str_0)
    if bool_1 is True:
        bool_0 = True

    str_0 = "false"
    bool_1 = safe_eval(str_0)
    if bool_1 is False:
        bool_0 = True

    str_0 = "null"
    bool_1 = safe_eval(str_0)
    if bool_1 is None:
        bool_0 = True

    str_0 = "null"
    bool_1 = safe_eval(str_0)
    if bool_1 is None:
        bool_0 = True

    str_0 = "True"
    bool_1 = safe_eval(str_0)
    if bool_1 is True:
        bool_0

# Generated at 2022-06-25 12:33:07.503446
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('1 + 2')
    assert result == 3

    result = safe_eval('1 + 2 - 3')
    assert result == 0

    result = safe_eval('2 * 3')
    assert result == 6

    result = safe_eval('4 / 2')
    assert result == 2

    result = safe_eval('3 > 2')
    assert result == True

    result = safe_eval('3 < 2')
    assert result == False

    result = safe_eval('3 >= 2')
    assert result == True

    result = safe_eval('3 <= 2')
    assert result == False

    result = safe_eval('3 == 2')
    assert result == False

    result = safe_eval('3 != 2')
    assert result == True

    # result = safe_eval('"foo" + "bar"')


# Generated at 2022-06-25 12:33:14.583405
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval('true')
    except SyntaxError:
        print("SyntaxError: Invalid expression: true")

    try:
        safe_eval(test_case_0)
    except Exception:
        print("Exception: Invalid expression: test_case_0")

    try:
        safe_eval(0)
    except SyntaxError:
        print("SyntaxError: Invalid expression: 0")

    try:
        safe_eval('False')
    except SyntaxError:
        print("SyntaxError: Invalid expression: False")



# Generated at 2022-06-25 12:33:23.237200
# Unit test for function safe_eval
def test_safe_eval():
    if False:
        # check for exception occurred inside the safe_eval
        # is caught as a string
        assert safe_eval('{{1/0}}') == '{{1/0}}', 'should catch a divide by zero'
        # if a variable was not defined, we do not want a crash
        assert safe_eval('{{i_do_not_exist}}') == '{{i_do_not_exist}}', 'should catch variable not defined'
        assert safe_eval('{{i_do_not_exist}}', {'i_do_not_exist': 'defined'}) == 'defined', 'should catch variable not defined'
        assert safe_eval('{{i_do_not_exist * 2}}') == '{{i_do_not_exist * 2}}', 'should catch variable not defined'

# Generated at 2022-06-25 12:33:34.046882
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:45.527171
# Unit test for function safe_eval
def test_safe_eval():
    # Case 0: simple values
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('42') == 42
    assert safe_eval('42.0') == 42.0
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"foo":42}') == {"foo":42}
    assert safe_eval('foo') != "foo"
    # Case 1: try json deserialization
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    assert safe_eval('"foo"') == "foo"
    assert safe

# Generated at 2022-06-25 12:33:51.087667
# Unit test for function safe_eval
def test_safe_eval():
    test_variables = dict(
        a='0',
        b='1',
        c='2',
    )
    # Test basic literals

# Generated at 2022-06-25 12:33:55.766523
# Unit test for function safe_eval
def test_safe_eval():

    try:
        # Test for invalid expression format
        safe_eval("aaaa")
    except Exception as e:
        if "invalid expression" in str(e) and "aaaa" in str(e):
            pass
        else:
            raise AssertionError("Failed to raise 'invalid expression' exception on a invalid expression.")

    # Test for invalid function
    try:
        safe_eval("__import__('os').system('true')")
    except Exception as e:
        if "invalid function" in str(e):
            pass
        else:
            raise AssertionError("Failed to raise 'invalid function' exception on an invalid function.")

    # Test for valid expressions
    assert safe_eval("aaaa") == "aaaa"
    assert safe_eval(3) == 3

# Generated at 2022-06-25 12:34:02.413575
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('True and False') == False
    try:
        safe_eval('__import__("os")')
        # this one should fail
        assert False
    except:
        pass
    try:
        safe_eval('__import__("os").remove(".ssh/authorized_keys")')
        # this one should fail
        assert False
    except:
        pass
    try:
        # this one should fail
        safe_eval('__import__("os").remove(".ssh/authorized_keys") and True')
        assert False
    except:
        pass
    # try:
    #     safe_eval('abs(1)')
    #     # this one should fail
    #     assert False
    # except:
    #     pass


# Generated at 2022-06-25 12:34:10.619374
# Unit test for function safe_eval
def test_safe_eval():

    # Get the test environment variable.
    # This test is only implemented for linux and darwin.
    if C.DEFAULT_SYS_MODULE == 'posix':
      env_var = "CI"

    # Test case with invalid expression.
    print("Running test case 0")
    with open("test_cases/safe_eval_test_case_0.template", 'r') as file:
      data0 = file.read()
    if env_var not in builtins.__dict__:
        builtins.__dict__[env_var] = False
    test_case_0()
    if env_var in builtins.__dict__:
        delattr(builtins, env_var)
    result0 = safe_eval(data0)
    expected_result0 = "CI"

# Generated at 2022-06-25 12:34:19.200437
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:29.056590
# Unit test for function safe_eval
def test_safe_eval():
    # Test if expected values are returned for various input
    with open(C.TEST_DATA_ROOT + '/test_safe_value_eval.yml', 'r') as mock_data:
        for data in mock_data:
            if data.startswith('#'):
                continue
            data = ast.literal_eval(data)

            # Check if correct value is returned from safe_eval()
            result, exception = safe_eval(data['input'], include_exceptions=True)
            assert result == data['expected']

            # Check if all the exceptions are handled
            if data['expected'] == 'exception':
                assert exception is not None



# Generated at 2022-06-25 12:34:38.403802
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("ansible_facts['os_family']")
    assert result == "RedHat"
    result = safe_eval("ansible_facts['os_family'] == 'RedHat'")
    assert result == True
    result = safe_eval("ansible_facts['os_family'] == 'Debian'")
    assert result == False
    assert safe_eval("ansible_facts['os_family'] == ansible_facts['os_family']") == True
    result = safe_eval("true")
    assert result == True
    result = safe_eval("true == 'true'")
    assert result == False
    result = safe_eval("false")
    assert result == False
    result = safe_eval("'true'")
    assert result == "true"
    result = safe_eval("True")
    assert result

# Generated at 2022-06-25 12:34:48.506691
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') is 0
    assert safe_eval('1') is 1
    assert safe_eval('-1') == -1
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('0+1') == 1
    assert safe_eval('1-1') == 0
    assert safe_eval('1*1') == 1
    assert safe_eval('1/1') == 1
    assert safe_eval('1**1') == 1
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('[1, 2]*3')

# Generated at 2022-06-25 12:35:05.791101
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 1") == 2
    assert safe_eval("[1, 2, 3][0]") == 1
    assert safe_eval("[i for i in range(3)]") == [0, 1, 2]
    assert safe_eval("1 + 2 + 3") == 6
    assert safe_eval("false") is False

# Generated at 2022-06-25 12:35:14.990590
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Should succeed with:
    * True
    * False
    * None
    * string with octal digits (not a number)
    * string with hexadecimal digits (not a number)
    * string with decimal digits (not a number)
    * tuple of safe items
    * list of safe items
    * dict of safe items
    * int
    * float
    * string
    * list index
    * binary arithmetic operators
    * unary arithmetic operators
    * comparisons
    * multiple comparisons

    Should fail with:
    * a random string (not a number)
    * floating-point numbers (with a leading zero)
    * keywords in expressions
    * a new-style string (not a number)
    * a template string (not a number)
    * simple calls
    * attribute access
    '''

    assert safe

# Generated at 2022-06-25 12:35:21.405239
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test whether safe_eval is actually safe, with a large number of
    different strings to be evaluated.
    """
    # Tests are tuples of (string_to_evaluate, expected_result).
    # If the test is invalid, the string is the expected error.
    # The test is expected to raise an exception with that string.

# Generated at 2022-06-25 12:35:32.027310
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=too-many-branches, too-many-statements
    # these two statements should evaluate to true, no matter what
    assert safe_eval('true')
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # should raise an exception since foo is not a boolean
    try:
        safe_eval('foo')
        assert False
    except Exception as err:
        assert str(err) == "invalid expression (foo)"

    # should be the value of the local variable
    safe_eval('bool_0', dict(bool_0=True))

    # should raise an exception since foo is not a valid name

# Generated at 2022-06-25 12:35:33.589087
# Unit test for function safe_eval
def test_safe_eval():
    # Test that valid expressions evaluate properly
    test_case_0()



# Generated at 2022-06-25 12:35:41.544282
# Unit test for function safe_eval
def test_safe_eval():
    # function test_case_0:
    bool_0 = safe_eval("True")
    # function test_case_1:
    str_0 = safe_eval("'abc'")
    # function test_case_2:
    str_1 = safe_eval("'%s' % 'abc'")
    # function test_case_3:
    list_0 = safe_eval("[1, 'abc']")
    # function test_case_4:
    list_1 = safe_eval("[i for i in range(3)]")
    # function test_case_5:
    dict_0 = safe_eval("{'a': 1, 'b': 'abc'}")
    # function test_case_6:
    dict_1 = safe_eval("{i: i for i in range(3)}")
   

# Generated at 2022-06-25 12:35:50.211068
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a basic test case that ensures that safe_eval
    works with a couple of simple expressions.
    It is meant to be expanded upon.
    '''
    # No exception should be thrown
    assert safe_eval("{{ a }}") == "{{ a }}"
    assert safe_eval("a") == "a"
    assert safe_eval("a + b", dict(a=5, b=10)) == 15
    assert safe_eval("a + b", dict(a=1, b=True)) == 2
    assert safe_eval("a * b", dict(a=2.5, b=10)) == 25.0
    assert safe_eval("a + b", dict(a='foo', b='bar')) == 'foobar'

# Generated at 2022-06-25 12:35:52.353488
# Unit test for function safe_eval
def test_safe_eval():
    test_code = 'False'
    expected_result = False
    result = safe_eval(test_code)

    assert result == expected_result


# Generated at 2022-06-25 12:36:02.651225
# Unit test for function safe_eval
def test_safe_eval():
    assert True == safe_eval('true')
    assert False == safe_eval('false')
    assert None == safe_eval('null')
    assert [True, False] == safe_eval('[true, false]')
    assert {'true': False, "false": None} == safe_eval("{'true': false, \"false\": null}")
    assert (True, False) == safe_eval("(true, false)")
    with pytest.raises(Exception):
        assert {'true': False, "false": None} == safe_eval("{'true': false, 4: null}")
    assert {'true': False, 4: None} == safe_eval("{'true': false, 4: null}", include_exceptions=True)

# Generated at 2022-06-25 12:36:08.262667
# Unit test for function safe_eval
def test_safe_eval():
    # Handle if safe_eval(expr, locals=None, include_exceptions=False)
    # Create args
    args = []
    if len(args) == 1:
        expr = args[0]
    elif len(args) == 2:
        expr = args[0]
        locals = args[1]
    elif len(args) == 3:
        expr = args[0]
        locals = args[1]
        include_exceptions = args[2]
    else:
        expr = None
        locals = None
        include_exceptions = False

    # Unit test for safe_eval(expr)
    result = safe_eval(expr)

    # Unit test for safe_eval(expr, locals=None)
    result = safe_eval(expr, locals=locals)

    # Unit test for safe_eval(

# Generated at 2022-06-25 12:36:24.321387
# Unit test for function safe_eval
def test_safe_eval():
    print()
    #Test case 1
    if (safe_eval('true') is True):
        print('Test case 1: Passed')
    else:
        print('Test case 1: Failed')

    #Test case 2
    if (safe_eval('false') is False):
        print('Test case 2: Passed')
    else:
        print('Test case 2: Failed')

    #Test case 3
    if (safe_eval('1') == 1):
        print('Test case 3: Passed')
    else:
        print('Test case 3: Failed')

    #Test case 4
    if (safe_eval('1.0') == 1.0):
        print('Test case 4: Passed')
    else:
        print('Test case 4: Failed')

    #Test case 5

# Generated at 2022-06-25 12:36:30.291799
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info < (2, 7):
        module = AnsibleModule(argument_spec=dict(ex=dict(required=False, type='str')))
        try:
            result = safe_eval(module.params['ex'])
        except Exception as e:
            module.fail_json(msg=to_native(e))
        else:
            module.exit_json(result=result)



# Generated at 2022-06-25 12:36:40.268570
# Unit test for function safe_eval
def test_safe_eval():
    global bool_0
    # set bool_0
    bool_0 = False
    # push in constant string
    expr = 'my_host'
    data = safe_eval(expr)
    assert data == 'my_host'
    data = safe_eval(expr, locals={'my_host':'localhost'})
    assert data == 'localhost'

    # push in object and try to render that object
    expr = 'bool_0'
    data = safe_eval(expr)
    assert data == False
    data = safe_eval(expr, locals={'bool_0':True})
    assert data == True

    # push in JSON boolean
    expr = 'True'
    data = safe_eval(expr)
    assert data == True

    # push in list and try to render that list
    expr = 'my_list'
   

# Generated at 2022-06-25 12:36:45.106725
# Unit test for function safe_eval
def test_safe_eval():
    expr = "({'a': 1, 'b': 2, 'c': 3} | selectattr('unknown_key', 'equalto', '1'))"
    expr = "({'a': 1, 'b': 2, 'c': 3} | selectattr('unknown_key', 'equalto', '1') | list)"
    result = safe_eval(expr)
    print(result)


# Generated at 2022-06-25 12:36:51.889142
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:01.973331
# Unit test for function safe_eval
def test_safe_eval():
    # Tests that certain strings, when evaluated, return
    # the value of an AST node, rather than the string itself
    # Due to the way Jinja2 works, this will be the case for
    # variable expressions, since they are templated before
    # being sent to safe_eval
    assert safe_eval('1') == 1
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo"+"bar"') == 'foobar'

    # Tests that these same values will properly evaluate when
    # templated prior to being sent to safe_eval, due to the
    # way Jinja2 handles evaluating variable expressions
    assert safe_eval('{{ 1 }}') == 1
    assert safe_eval('{{ True }}')

# Generated at 2022-06-25 12:37:12.429227
# Unit test for function safe_eval
def test_safe_eval():
    # Test returned values from safe_eval()
    assert safe_eval("15", locals=None, include_exceptions=False) == 15
    assert safe_eval("[1, 2, 3]", locals=None, include_exceptions=False) == [1, 2, 3]
    assert safe_eval("(1, 2, 3)", locals=None, include_exceptions=False) == (1, 2, 3)
    assert safe_eval("'test'", locals=None, include_exceptions=False) == 'test'
    assert safe_eval("[7, {'test': 'this'}, 3]", locals=None, include_exceptions=False) == [7, {'test': 'this'}, 3]
    assert safe_eval("null", locals=None, include_exceptions=False) == None
    assert safe_eval

# Generated at 2022-06-25 12:37:16.576574
# Unit test for function safe_eval
def test_safe_eval():
    try:
        assert test_case_0() == safe_eval('', False)
        assert test_case_0() == safe_eval('', True)
    except Exception as e:
        print('safe_eval Test #0 failed: ' + str(e))
        raise e
# End of safe_eval testing



# Generated at 2022-06-25 12:37:24.285302
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    assert safe_eval('1') == 1
    assert safe_eval('3.14') == 3.14
    assert safe_eval('"bar"') == 'bar'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"key":"value"}') == {"key": "value"}
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('{1,2,3}') == {1, 2, 3}
    assert safe_eval('not True') == False
    assert safe_eval('{1,2,3}') == {1, 2, 3}

   

# Generated at 2022-06-25 12:37:25.640060
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None, "test_case_0"



# Generated at 2022-06-25 12:37:51.113879
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    expr = 'a_1 == "1"'
    locals = {'a_1': '1'}
    assert safe_eval(expr, locals)
    assert safe_eval(safe_eval(expr, locals))
    assert not safe_eval("a_1 == '2'", locals)
    assert safe_eval("a_1 == '2'", {'a_1': '2'})
    assert not safe_eval("a_1 == '2'", {'a_1': '1'})
    assert safe_eval("a_1 == '1'", {'a_1': '1'})
    assert not safe_eval("a_1 == '1'", {'a_1': '2'})
    assert not safe_eval("a_1 == '1'")
    assert safe

# Generated at 2022-06-25 12:38:00.258369
# Unit test for function safe_eval
def test_safe_eval():
    # success case
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("(1,2,3)") == (1,2,3)
    assert safe_eval("{'a':'b'}") == {'a':'b'}

    # invalid expressions
    with pytest.raises(Exception):
        safe_eval("'''a'''")
    with pytest.raises(Exception):
        safe_eval(";")
    with pytest.raises(Exception):
        safe_eval("import json")
    with pytest.raises(Exception):
        safe_eval("[1,2,3)")
    with pytest.raises(Exception):
        safe_eval("[1,2,3}")

# Generated at 2022-06-25 12:38:06.952742
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Boolean tests, enabled boolean AST type
    '''
    assert safe_eval('True')
    assert safe_eval('False')
    assert not safe_eval('False')
    assert safe_eval('true')
    assert safe_eval('false')

    '''
    Boolean tests, disabled boolean AST type, force str return
    '''
    assert not safe_eval('false', include_exceptions=True)[0]
    assert safe_eval('False', include_exceptions=True)[0]

    '''
    Arithmetic tests, enabled math AST types
    '''
    assert safe_eval('1+1') == 2
    assert safe_eval('3-1') == 2
    assert safe_eval('3*9') == 27
    assert safe_eval('15/3') == 5

# Generated at 2022-06-25 12:38:08.355955
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None

# The true main function

# Generated at 2022-06-25 12:38:17.855667
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("1+1")
    print(result)
    result = safe_eval("1+1", include_exceptions=True)
    print(result)
    result = safe_eval("{{ [1] + [2] }}", include_exceptions=True)
    print(result)
    result = safe_eval("{{ [1] + True }}", include_exceptions=True)
    print(result)
    result = safe_eval("{{ [1] + 1 }}", include_exceptions=True)
    print(result)
    result = safe_eval("{{ [1] + 3 }}", include_exceptions=True)
    print(result)
    result = safe_eval("{{ [1] + True }}", include_exceptions=True)
    print(result)

# Generated at 2022-06-25 12:38:28.672361
# Unit test for function safe_eval
def test_safe_eval():
    expression_0 = 'foo'
    expression_1 = 'foo.bar'
    expression_2 = 'foo.bar.baz'
    expression_3 = 'foo * 2'
    expression_4 = 'foo | length'
    expression_5 = 'foo and bar'
    expression_6 = 'foo or bar'
    expression_7 = 'foo and bar or baz'
    expression_8 = '(foo.bar or true) and (foo.baz or true)'
    expression_9 = 'foo[bar] / 2'
    expression_10 = 'foo | reject("match", "^#")'
    expression_11 = 'foo | reject("match", "^#", true)'
    expression_12 = 'foo[0] | from_json'
    expression_13 = 'foo[0] | from_json | int'


# Generated at 2022-06-25 12:38:38.831956
# Unit test for function safe_eval
def test_safe_eval():
    global bool_0
    bool_0 = False
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1') == 2
    assert safe_eval('-1 + 1') == 0
    assert safe_eval('1 + -1') == 0
    assert safe_eval('1 - 1') == 0
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('1.0 + 1') == 2.0
    assert safe_eval('1-1') == 0
    assert safe_eval('1.0 - 1') == 0.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None


# Generated at 2022-06-25 12:38:44.587908
# Unit test for function safe_eval
def test_safe_eval():
    global result
    global expr
    global exception
    print("Test safe_eval")

    result = safe_eval('True', {})
    print("Result: " + str(result))

    result = safe_eval('1')
    print("Result: " + str(result))

    result = safe_eval('1 + 2')
    print("Result: " + str(result))

    result = safe_eval('[1,2,3]')
    print("Result: " + str(result))

    result = safe_eval('range(5)')
    print("Result: " + str(result))

    # Testing for results that should fail
    result, exception = safe_eval('os.getcwd()', {}, True)
    print("Result: " + str(result))

# Generated at 2022-06-25 12:38:51.578736
# Unit test for function safe_eval
def test_safe_eval():
    #
    # Example from http://docs.python.org/2/library/ast.html
    #
    test = '2 + 3'
    # Compile into AST
    node = ast.parse(test, mode='eval')
    # Remove nodes we don't want to allow
    # node.body = filter(lambda node: isinstance(node, ast.Num), node.body)
    # Execute AST
    compiled = compile(node, '<string>', 'eval')
    result = eval(compiled)
    result = safe_eval(test)
    assert result == 5

    #
    # Example from comments on http://stackoverflow.com/questions/865115/how-do-i-correctly-clean-up-a-python-string-for-json-serialization
    #
    # Original version accepts "true

# Generated at 2022-06-25 12:39:01.613718
# Unit test for function safe_eval
def test_safe_eval():
    expr_list = []
    expr_list.append('true')
    expr_list.append('false')
    expr_list.append('1 == 1')
    expr_list.append('1 != 1')
    expr_list.append('(1,2)')
    expr_list.append('["a","b","c"]')
    expr_list.append('{"a":1, "b":2}')
    expr_list.append('false and true')
    expr_list.append('false and false')
    expr_list.append('true and false')
    expr_list.append('true and true')
    expr_list.append('false or true')
    expr_list.append('false or false')
    expr_list.append('true or false')
    expr_list.append('true or true')
    expr_