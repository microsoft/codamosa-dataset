

# Generated at 2022-06-25 12:29:38.325697
# Unit test for function safe_eval
def test_safe_eval():
    # test case: test the possible values of string
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:29:46.332635
# Unit test for function safe_eval
def test_safe_eval():
    float_0 = 322.1
    var_0 = safe_eval(float_0)
    assert var_0 == 322.1, 'Expected 322.1 to equal 322.1'

    float_1 = 2.3
    var_1 = safe_eval(float_1)
    assert var_1 == 2.3, 'Expected 2.3 to equal 2.3'

    float_2 = -9.9
    var_2 = safe_eval(float_2)
    assert var_2 == -9.9, 'Expected -9.9 to equal -9.9'

    float_3 = 0.0
    var_3 = safe_eval(float_3)
    assert var_3 == 0.0, 'Expected 0.0 to equal 0.0'

    float_4 = 1.0
    var

# Generated at 2022-06-25 12:29:56.884259
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == 322.1

    dict_0 = dict(a='b', b='c')
    dict_0_copy = dict(a='b', b='c')
    dict_0 = safe_eval(dict_0)
    for i, key in enumerate(dict_0):
        assert dict_0[key] == dict_0_copy[key]


# Generated at 2022-06-25 12:30:04.212732
# Unit test for function safe_eval
def test_safe_eval():

    import sys

    # original: dict_0 = {u'disk_sda': u'(sda) some_disk', 'num_cpus': 1, u'disk_sda_foo': u'(sda) some_disk'}
    dict_0 = {'disk_sda': '(sda) some_disk', 'num_cpus': 1, 'disk_sda_foo': '(sda) some_disk'}

    # Evaluate expr 'num_cpus'
    dict_0_result = safe_eval('num_cpus', dict_0, True)
    dict_0_result_actual = dict_0_result[0]
    dict_0_result_exception = dict_0_result[1]

# Generated at 2022-06-25 12:30:08.422522
# Unit test for function safe_eval
def test_safe_eval():
    if test_case_0() == 322.1:
        print("Test case 0: PASS")
    else:
        print("Test case 0: FAIL")


if __name__ == "__main__":
    # Test function safe_eval
    test_safe_eval()

# Generated at 2022-06-25 12:30:19.052906
# Unit test for function safe_eval
def test_safe_eval():
    # Test good cases
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 * 4') == 9
    assert safe_eval('abs(-1)') == 1
    assert safe_eval('bool(1)') is True
    assert safe_eval('bool(0)') is False
    assert safe_eval('bool(0.0)') is False
    assert safe_eval('bool(1.234)') is True
    assert safe_eval('bool(1.0)') is True
    assert safe_eval('bool("")') is False
    assert safe_eval('bool("asdf")') is True
    assert safe_eval('bool([])') is False
    assert safe_eval('bool({})') is False

# Generated at 2022-06-25 12:30:29.031103
# Unit test for function safe_eval
def test_safe_eval():
    # Test with a float
    test_float = 3.2
    assert safe_eval(test_float) == test_float

    # Test with a string
    test_str = "this is a string"
    assert safe_eval(test_str) == test_str

    # Test with a list
    test_list = [1, 2, 3, 4]
    assert safe_eval(test_list) == test_list

    # Test with a dict
    test_dict = {"key1": "value1", "key2": "value2"}
    assert safe_eval(test_dict) == test_dict


# Generated at 2022-06-25 12:30:31.139735
# Unit test for function safe_eval
def test_safe_eval():
    float_0 = 322.1
    var_0 = safe_eval(float_0)
    assert (var_0 == 322.1)


# Generated at 2022-06-25 12:30:32.098130
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:30:39.840931
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:47.407595
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = bool(safe_eval('true'))
    bool_1 = bool(safe_eval(322))
    assert bool_0 == True
    assert bool_1 == True
    print("safe_eval(true): %s" % str(bool_0))
    print("safe_eval(322): %s" % str(bool_1))


# Generated at 2022-06-25 12:30:52.661135
# Unit test for function safe_eval
def test_safe_eval():
    f = open("test_safe_eval.out", "w")
    orig_err = sys.stderr
    sys.stderr = f

    # test_case_0
    f.write("\nTest Case 0\n")
    test_case_0()

    sys.stderr = orig_err
    f.close()
    return "Unit Test for function safe_eval completed"


# Generated at 2022-06-25 12:30:53.827742
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}



# Generated at 2022-06-25 12:30:59.564133
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval("foo[0]")
    assert var_0 == "foo[0]"

    true_0 = True
    var_1 = safe_eval(true_0)
    assert var_1

    var_2 = safe_eval("bar")
    assert var_2 == "bar"

    var_3 = safe_eval(1)
    assert var_3 == 1

    var_4 = safe_eval("{{ foo.bar }}")
    assert var_4 == "{{ foo.bar }}"

    foo_0 = [1, 2, 3]
    var_5 = safe_eval(foo_0)
    assert var_5 == [1, 2, 3]


# Generated at 2022-06-25 12:31:07.233805
# Unit test for function safe_eval
def test_safe_eval():
    # Test that an integer evaluates to an integer
    int_1 = safe_eval(1)
    if int_1 != 1:
        raise AssertionError('Integer not an integer')

    # Test that an integer evaluates to an integer
    float_0 = safe_eval(3.14159)
    if float_0 != 3.14159:
        raise AssertionError('Float not a float')

    # Test that an integer evaluates to an integer
    str_1 = safe_eval('"string"')
    if str_1 != 'string':
        raise AssertionError('String not a string')

    # Test that an integer evaluates to an integer
    array_list_1 = safe_eval('[1,2,3]')

# Generated at 2022-06-25 12:31:17.126506
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:24.019275
# Unit test for function safe_eval
def test_safe_eval():
    data = "{{ ''.join(['www.', 'example', '.', 'org']) }}"
    try:
        # From module docs:
        # expr - The expression to evaluate.  This is NOT a string, but has been
        #        parsed into an AST node (or nodes) already.
        safe_eval(ast.parse(data))
    # On Python 2.x, we get an AttributeError
    except AttributeError as e:
        sys.exit(1)
    # On Python 3.x, we get a ValueError
    except ValueError as e:
        sys.exit(1)
#

# Generated at 2022-06-25 12:31:34.773145
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(["/etc/ansible/hosts"], [], True)[0] == ["/etc/ansible/hosts"]
    assert safe_eval(["/etc/ansible/hosts"], None, True)[0] == ["/etc/ansible/hosts"]
    assert safe_eval(["/etc/ansible/hosts"])[0] == ["/etc/ansible/hosts"]
    assert safe_eval(["/etc/ansible/hosts"])[0] == ["/etc/ansible/hosts"]
    assert safe_eval(["/etc/ansible/hosts"])[0] == ["/etc/ansible/hosts"]
    assert safe_eval(["/etc/ansible/hosts"])[0] == ["/etc/ansible/hosts"]

# Generated at 2022-06-25 12:31:39.722536
# Unit test for function safe_eval
def test_safe_eval():
    # Capture the result in a variable for inspection
    result = safe_eval("1+1")
    # Use assertions to confirm expected results
    assert(result == 2)
    # Example to call "container_to_text" function used in the code
    v = container_to_text(1234)

if __name__ == "__main__":
    test_safe_eval()
    sys.exit(0)

# Generated at 2022-06-25 12:31:46.881340
# Unit test for function safe_eval
def test_safe_eval():
    for key, val in safe_eval(to_native('{"a": "hello", "b": [1,2,3], "c": {"d": true, "e": "123.456"}}')).items():
        assert isinstance(key, string_types)
        if key == "b":
            assert isinstance(val, list)
            assert val[0] == 1 and val[1] == 2 and val[2] == 3
        elif key == "c":
            assert isinstance(val, dict)
            assert "d" in val and "e" in val
            assert val["d"] is True
            assert isinstance(val["e"], float)
        else:
            assert isinstance(val, string_types)

    # check a few basic types and values
    assert safe_eval('true') is True
    assert safe

# Generated at 2022-06-25 12:32:00.237433
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    float_0 = 322.1
    var_0 = safe_eval(float_0)
    assert float(var_0) == float(float_0)

    # Test case 1
    var_1 = 'this is not evaluated'
    var_2 = safe_eval(var_1)
    assert var_1 == var_2, 'This should not be evaluated, all types must pass'

    # Test case 2
    var_3 = safe_eval(None)
    assert var_3 is None, 'This should not be evaluated, all types must pass'

    # Test case 3
    var_4 = 0
    var_5 = safe_eval(var_4)
    assert var_4 == var_5, 'This should not be evaluated, all types must pass'

    # Test case 4
    var_4

# Generated at 2022-06-25 12:32:11.061538
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")
    assert safe_eval("1 + 5") == 6
    assert safe_eval("'hi'") == "hi"
    assert safe_eval("'1 + 5'") == "1 + 5"
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("[1, 'a', 3]") == [1, 'a', 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': 1, 'b': 'x'}") == {'a': 1, 'b': 'x'}
    assert safe_eval("{ 1: 'x' }") == {1: 'x'}


# Generated at 2022-06-25 12:32:16.898820
# Unit test for function safe_eval
def test_safe_eval():
    try:
        # import pdb; pdb.set_trace()
        test_case_0()
        print("TEST PASSED: test_case_0")


        # print(safe_eval(None, None, None))
    except Exception as e:
        print("TEST FAILED: test_safe_eval")
        sys.exit(1)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:19.584465
# Unit test for function safe_eval
def test_safe_eval():
    float_0 = 322.1
    var_0 = safe_eval(float_0)
    assert float(var_0) == float(float_0)


# Generated at 2022-06-25 12:32:28.145748
# Unit test for function safe_eval
def test_safe_eval():
    # Test Case 0
    float_0 = 322.1
    var_mode_0 = safe_eval(float_0)
    assert isinstance(var_mode_0, float)
    # Test Case 1
    list_0 = [1, 2, 3, "Hello", 4.5]
    var_mode_1 = safe_eval(list_0)
    assert isinstance(var_mode_1, list)
    # Test Case 2
    list_0 = [1, 2, 3, "Hello", 4.5]
    var_mode_2 = safe_eval(list_0, include_exceptions=True)
    assert isinstance(var_mode_2[0], list)
    assert isinstance(var_mode_2[1], tuple)
    # Test Case 3

# Generated at 2022-06-25 12:32:37.896132
# Unit test for function safe_eval
def test_safe_eval():
    # Use 'safe_eval' to check the result of expression 1 + 1
    expression = '1 + 1'
    float_0 = 2.0
    # The expected result of 1 + 1 is a float
    var_0 = safe_eval(expression)
    if var_0 == float_0:
        print('Pass: Expression: ' + expression)
    else:
        print('Fail: Expression: ' + expression)
        print('  Result: ' + str(var_0))
        print('Expect: ' + str(float_0))
    print('')

    # Use 'safe_eval' to check the result of expression 2 * 3
    expression = '2 * 3'
    int_0 = 6
    # The expected result of 2 * 3 is an int
    var_1 = safe_eval(expression)

# Generated at 2022-06-25 12:32:45.511869
# Unit test for function safe_eval
def test_safe_eval():
    # locals are passed through
    result = safe_eval('3 + 7', dict(a='b'))
    assert result == 10

    # literals are not evaluated
    result = safe_eval('3 + 7', dict(a=3))
    assert result == '3 + 7'

    # int
    result = safe_eval('3 + 7', dict(a=3))
    assert result == 10
    result = safe_eval('3 + a', dict(a=7))
    assert result == 10
    result = safe_eval('a + 3', dict(a=7))
    assert result == 10
    result = safe_eval('a + a', dict(a=3))
    assert result == 6

    # float
    result = safe_eval('3.2 + 7.1', dict(a=3.1))
    assert result

# Generated at 2022-06-25 12:32:55.934960
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Expected outputs:
#   (1.0, None)
#   ('string', None)
#   ([1, 2, 3], None)
#   ('1+1', None)
#   ('1plus1', None)
#   ('abs', None)
#   ('1+abs', <class 'exceptions.Exception'>)
#   ('1+1+1', <class 'exceptions.Exception'>)
#   ('[1,2,3]+1', <class 'exceptions.Exception'>)
#   ('[1,2,3]+[1,2,3]', <class 'exceptions.Exception'>)
#   ('[1,abs,3]', <class 'exceptions

# Generated at 2022-06-25 12:33:06.384776
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:13.712755
# Unit test for function safe_eval
def test_safe_eval():
    float_0 = 322.1
    var_0 = safe_eval(float_0)
    # Call the function
    var_return = safe_eval(var_0, include_exceptions=True)
    eq_(var_return[0], var_0)
    eq_(var_return[1], None)

    float_0 = 322.1
    var_0 = safe_eval(float_0)
    # Call the function
    var_return = safe_eval(var_0, include_exceptions=True)
    eq_(var_return[0], var_0)
    eq_(var_return[1], None)


# Generated at 2022-06-25 12:33:28.086142
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the functionality of the safe_eval function that can be used to
    evaluate variables for different uses.
    '''
    # Test a simple variable
    variable = 'example variable'
    var_eval = safe_eval(variable)
    assert variable == var_eval

    # Test a variable that contains one or more objects (dict, string, list, etc.)
    variable_2 = [{'key1': 'value1', 'key2': 'value2'}, 'value3', 'value4']
    var_eval_2 = safe_eval(variable_2)
    assert variable_2 == var_eval_2

    # Test a variable that contains a mixture of different objects (dict, string, list, etc.)
    variable_3 = "{'key1': 'value1', 'key2': 'value2'}"
    var_eval

# Generated at 2022-06-25 12:33:29.238377
# Unit test for function safe_eval
def test_safe_eval():
    for x in range(0, 100):
        test_case_0()

# Main function

# Generated at 2022-06-25 12:33:35.191763
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import string_types

    float_0 = 322.1
    var_0 = safe_eval(float_0)
    assert var_0 == 322.1

    list_0 = [0]
    var_1 = safe_eval(list_0)
    assert var_1 == [0]

    dict_0 = {'a': 0, 'b': 1}
    var_2 = safe_eval(dict_0)
    assert var_2 == {'a': 0, 'b': 1}

    str_0 = 'a string'
    var_3 = safe_eval(str_0)
   

# Generated at 2022-06-25 12:33:36.177776
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None

# Generated at 2022-06-25 12:33:47.701786
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(1) == 1
    assert safe_eval(safe_eval(2)) == 2
    assert safe_eval('2') == 2
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval(2) == 2
    assert safe_eval('[1, [2, [3]]]') == [1, [2, [3]]]
    assert safe_eval('[]') == []
    assert safe_eval('[1, [2, [a]]]') == [1, [2, [a]]]
    assert safe_eval('[1, [2, [a]]]', {'a': 1}) == [1, [2, [1]]]

# Generated at 2022-06-25 12:33:51.044563
# Unit test for function safe_eval
def test_safe_eval():
    # type: () -> None
    '''
    safe_eval unit test
    '''
    # TestCase 0

    try:
        test_case_0()
    except Exception:
        print("test_case_0 failed")



# Generated at 2022-06-25 12:33:59.393905
# Unit test for function safe_eval
def test_safe_eval():
    test_0 = '322.1'
    test_1 = 'isinstance(str, type)'
    test_2 = '(1 + 2) * (1 + 3)'
    test_3 = 'isinstance(str, unk)'
    test_4 = '(1 + 2) * (1 + 3) + unk'
    test_5 = 'str()'
    test_6 = '(1 + 2) * (1 + 3) + str()'
    test_7 = 'foo'
    test_8 = 'foo()'
    test_9 = '(1 + 2) * (1 + 3) + foo()'

    float_0 = 322.1

    assert safe_eval(test_0) == float_0, "Failed for [%s]" % test_0

# Generated at 2022-06-25 12:34:10.255828
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:11.238094
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval(1)


# Generated at 2022-06-25 12:34:16.200759
# Unit test for function safe_eval
def test_safe_eval():
    MAPPING_0 = { 'a': 'b' }
    var_1 = safe_eval(MAPPING_0)
    ADD_0 = (1 + 2)
    var_2 = safe_eval(ADD_0)
    try:
        safe_eval("builtins.open('')")
        test_passed = False
    except Exception:
        test_passed = True
    return [test_passed, False]



# Generated at 2022-06-25 12:34:29.008269
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    dict_0 = {
        'str_0': str_0
    }
    expr_0 = "str_0"
    result_0 = safe_eval(expr_0, dict_0, False)
    assert result_0 == str_0

    # nested dict
    dict_1 = {
        'dict_0': dict_0
    }
    expr_1 = "dict_0"
    result_1 = safe_eval(expr_1, dict_1, False)
    assert result_1 == dict_0
    expr_1 = "dict_0['str_0']"
    result_1 = safe_eval(expr_1, dict_1, False)
    assert result_1 == str_0

    # nested list
    list

# Generated at 2022-06-25 12:34:38.370208
# Unit test for function safe_eval
def test_safe_eval():
    print(test_case_0.__doc__)
    print(safe_eval.__doc__)

    _test_assert(safe_eval('"a".replace("a", "b")') == 'b')
    _test_assert(safe_eval('"dictionary" in ["dictionary", "list"]') is True)
    _test_assert(safe_eval('True') is True)
    _test_assert(safe_eval('False') is False)
    _test_assert(safe_eval('{"a": 1}') == {"a": 1})
    _test_assert(safe_eval('{"a": 1}["a"]') == 1)
    _test_assert(safe_eval('[1, 2, 3]') == [1, 2, 3])

# Generated at 2022-06-25 12:34:48.506884
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '10*10'
    assert safe_eval(str_0) == 100

    str_0 = '10 + 10'
    assert safe_eval(str_0) == 20

    str_0 = '10 - 10'
    assert safe_eval(str_0) == 0

    str_0 = '10 / 10'
    assert safe_eval(str_0) == 1

    str_0 = '10 + 10 + 10'
    assert safe_eval(str_0) == 30

    str_0 = '10 + 10 - 10'
    assert safe_eval(str_0) == 20

    str_0 = '10 / 2 + 10'
    assert safe_eval(str_0) == 15

    str_0 = '10 / 2 - 10'

# Generated at 2022-06-25 12:34:54.155471
# Unit test for function safe_eval
def test_safe_eval():
    # Test AnsibleModule version
    if sys.version_info >= (3, 0):
        from ansible.module_utils.pycompat24 import mod_dict_init
        mod_dict_init('ansible.module_utils.pycompat24')

    # Test safe_eval
    expr_1 = 'item in my_list'
    locals_1 = dict(item='1', my_list='[1,2,3]')
    test_result_1 = safe_eval(expr_1, locals_1)
    expected_result_1 = True
    assert test_result_1 == expected_result_1,  "safe_eval unit test failed"

if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-25 12:35:03.460718
# Unit test for function safe_eval
def test_safe_eval():
    rval, err = safe_eval('Today is {0}', {'0': 'sunny'}, True)
    assert type(rval) == str
    assert err == None

    rval, err = safe_eval('Today is {0}', {'0': 'sunny'}, True)
    assert type(rval) == str
    assert err == None

    rval, err = safe_eval(2+3, {'0': 'sunny'}, True)
    assert type(rval) == int
    assert err == None

    rval, err = safe_eval('2+3', {'0': 'sunny'}, True)
    assert type(rval) == int
    assert err == None

    rval, err = safe_eval('len("longer")', {'0': 'sunny'}, True)

# Generated at 2022-06-25 12:35:13.443374
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = u'{0:s}'
    str_1 = u'{0:s} {1:s}'
    str_2 = u'{0:s} {1:s} {2:s}'
    str_3 = u'{0:s} {1:s} {2:s} {3:s}'
    str_4 = u'{0:s} {1:s} {2:s} {3:s} {4:s}'
    str_5 = u'{0:s} {1:s} {2:s} {3:s} {4:s} {5:s}'

# Generated at 2022-06-25 12:35:16.902238
# Unit test for function safe_eval
def test_safe_eval():
    # This code will run the test in this file.'
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False,
    )
    print('Running the tests for safe_eval')
    test_case_0()

    module.exit_json(msg='safe_eval tests passed')


# Generated at 2022-06-25 12:35:22.643225
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types

    # Test0:
    str_0 = "a_list_variable"
    locals_dict = dict()
    locals_dict["a_list_variable"] = []
    locals_dict["a_list_variable"].append(str_0)
    output_0 = safe_eval(str_0, locals_dict)
    assert isinstance(output_0, list)
    assert output_0 == locals_dict["a_list_variable"]

    # Test1:
    str_1 = "a_list_variable"
    locals_dict = dict()
    locals_dict["a_list_variable"] = []

# Generated at 2022-06-25 12:35:28.892574
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('7', include_exceptions=True)[0] == 7
    assert 'invalid expression' in to_native(safe_eval('__import__("os").system("ls")', include_exceptions=True)[1])
    assert 'invalid function' in to_native(safe_eval('int("a")', include_exceptions=True)[1])
    assert 'invalid function' in to_native(safe_eval('oct("a")', include_exceptions=True)[1])


# Generated at 2022-06-25 12:35:39.200421
# Unit test for function safe_eval
def test_safe_eval():
    empty_str = ''
    str_0 = '\n    safe_eval unit test\n    '
    str_1 = 'mystring'
    str_2 = '2 + 3'
    str_3 = 'mydict_1'
    dict_1 = {'a': 1}
    dict_2 = {'a': 1}
    str_4 = 'mylist_1'
    list_1 = [1, 2]
    str_5 = 'a'
    str_6 = 'f'
    str_7 = 'p'
    str_8 = 'c'
    str_9 = 'z'
    str_10 = 'range(1,1)'
    str_11 = 'a'
    str_12 = 'mylist_2'
    list_2 = ['a', 2]
    str_

# Generated at 2022-06-25 12:35:52.309947
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    str_1 = '1,'
    str_2 = '1, 2'
    str_3 = '(1,)'
    str_4 = '(1, 2)'
    str_5 = '[1]'
    str_6 = '[1, 2]'
    str_7 = '{1: 1}'
    str_8 = '{1: 1, 2: 2}'
    str_9 = '1'
    str_10 = '"1"'
    str_11 = '1.'
    str_12 = '-1'
    str_13 = '+1'
    str_14 = '1 + 2'
    str_15 = '1 + 2 * 3'
    str_16 = '1 + 2 * 3 ==7'
    str

# Generated at 2022-06-25 12:36:02.612731
# Unit test for function safe_eval
def test_safe_eval():
    # set our test parameters
    locals_0 = {
        'a_list_variable': [
            'foo',
            'bar',
            'baz',
            'qux'
        ]
    }
    param_0 = 'a_list_variable'
    expected_0 = locals_0['a_list_variable']
    result_0 = safe_eval(param_0, locals_0)
    assert result_0 == expected_0


    # test a numeric value:
    locals_1 = {
        'a_numeric_variable': 123464
    }
    param_1 = 'a_numeric_variable'
    expected_1 = locals_1['a_numeric_variable']
    result_1 = safe_eval(param_1, locals_1)
    assert result_1 == expected_1

# Generated at 2022-06-25 12:36:09.722269
# Unit test for function safe_eval
def test_safe_eval():
    assert '1' == safe_eval("1")
    assert '1' == safe_eval("1+0")
    assert '2' == safe_eval("1+1")
    assert 'one' == safe_eval("'one'")
    assert 'one two' == safe_eval("'one '+'two'")
    assert '1' == safe_eval("'1'")
    assert '' == safe_eval("''")
    assert '1' == safe_eval('1')
    assert '1' == safe_eval('1+0')
    assert '2' == safe_eval('1+1')
    assert 'one' == safe_eval("'one'")
    assert 'one two' == safe_eval("'one '+'two'")
    assert '1' == safe_eval("'1'")

# Generated at 2022-06-25 12:36:10.570110
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:36:20.128905
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo=="foo"')
    assert safe_eval('foo in bar')
    assert safe_eval('foo + bar') is 3
    assert safe_eval('foo - bar') is 1
    assert safe_eval('foo / bar') is 2
    assert safe_eval('foo * bar') is 6
    assert safe_eval('foo - -bar') is 5
    assert safe_eval('-foo + -bar') == -5
    assert safe_eval('-foo / -bar') is -2
    assert safe_eval('-foo * -bar') is 6
    assert safe_eval('-foo + bar') is -1
    assert safe_eval('-foo / bar') == 1
    assert safe_eval('-foo * bar') is -6
    assert safe_eval

# Generated at 2022-06-25 12:36:26.768321
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    expr = 'ops == "p" or (ops == "d" and t2.a in t1.b)'
    locals = {'t1': {'a': 'b'}, 't2': {'a': 'b'}}
    result = safe_eval(expr, locals)
    assert result is False
    str_1 = "foo % (1)"
    result = safe_eval(str_1)
    assert result == str_1
    str_2 = "foo % (1)"
    result = safe_eval(str_2, include_exceptions=True)
    assert result == (str_2, None)
    str_3 = "foo % (1)"
    result = safe_eval(str_3, include_exceptions=True)

# Generated at 2022-06-25 12:36:36.279290
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    test_case_0()

    # check basic constant evaluation
    for expr in (
        "42",
        "True",
        "False",
        "'hello'",
        "null",
        '["foo","bar",null]',
        "{'foo':'bar'}"
    ):
        result = safe_eval(expr)
        if result != ast.literal_eval(expr):
            raise Exception('safe_eval test failed! Expected safe_eval(%s) == %s but got %s' % (expr, ast.literal_eval(expr), result))

    # check list concatenation

# Generated at 2022-06-25 12:36:45.551884
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:46.499141
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for boilerplate"""
    test_case_0()


# Generated at 2022-06-25 12:36:47.343177
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:36:58.188332
# Unit test for function safe_eval
def test_safe_eval():

    # See test_case_0 for example usage

    expr = '"foobar"'
    locals = None
    expected = 'foobar'
    actual = safe_eval(expr, locals)
    len_expected = len(expected)
    len_actual = len(actual)
    assert actual == expected, 'Expected: %s in len %s, but got: %s in len %s' % (expected, len_expected, actual, len_actual)

    expr = '"foobar" * 3'
    locals = None
    expected = 'foobarfoobarfoobar'
    actual = safe_eval(expr, locals)
    len_expected = len(expected)
    len_actual = len(actual)

# Generated at 2022-06-25 12:37:04.584506
# Unit test for function safe_eval
def test_safe_eval():
    # Test with a dictionary
    safe_eval('dict(a=True)')

    # Test with a list
    safe_eval('list(a,b)')

    # Test with a boolean
    safe_eval('True')

    # Test with a string
    safe_eval('"Hello World"')

    # Test with a number
    safe_eval('1234')

    # Test with an invalid function
    safe_eval('os')

    # Test with a string that should be returned back untouched
    safe_eval('Hello World')

from ansible.module_utils._text import to_text, to_bytes


# Generated at 2022-06-25 12:37:06.869792
# Unit test for function safe_eval
def test_safe_eval():
    print('Test 0')
    str_0 = '\n    safe_eval unit test\n    '
    print(safe_eval(str_0))


# Generated at 2022-06-25 12:37:17.413245
# Unit test for function safe_eval
def test_safe_eval():
    print('')
    print('safe_eval unit test')
    print('===================')
    print('')
    expr = 'foo'
    print('Expression: %s' % expr)
    result = safe_eval(expr)
    print('Result: %s' % result)
    print('')
    print('Expression: %s' % expr)
    result = safe_eval(expr, dict(foo=12345))
    print('Result: %s' % result)
    print('')
    expr = '{"foo": "bar", "blah": 12345}'
    print('Expression: %s' % expr)
    result = safe_eval(expr)
    print('Result: %s' % result)
    print('')

# Generated at 2022-06-25 12:37:27.590747
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('splunk_server.lower()') == 'devops-srv'
    assert safe_eval('4*4') == 16
    assert safe_eval('4+4') == 8
    assert safe_eval('4-4') == 0
    assert safe_eval('4/2') == 2
    assert safe_eval('8-4*2') == 0
    assert safe_eval('8-(4*2)') == 0
    assert safe_eval('8-(4*2)') == 0
    assert safe_eval('8 - 4*2') == 0
    assert safe_eval('8 - (3 + 1) * 2') == 0
    assert safe_eval('8 - (3 + (1)) * 2') == 0

# Generated at 2022-06-25 12:37:35.479961
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    str_1 = '2 + 3'
    str_2 = 'a + b'
    str_3 = '1 + 2 + 3'
    str_4 = 'a + 1'
    str_5 = '2 + a'
    str_6 = '2 < 3'
    str_7 = '3 > 2'
    str_8 = '3 <= 3'
    str_9 = '3 >= 3'
    str_10 = '2 == 3'
    str_11 = '2 != 3'
    str_12 = '2 in [2, 3]'
    str_13 = '2 not in [2, 3]'
    str_14 = '2 is 3'
    str_15 = '2 is not 3'

# Generated at 2022-06-25 12:37:43.574407
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    str_1 = '1+1'
    assert safe_eval(str_1) == 2
    str_2 = '1 + 1'
    assert safe_eval(str_2) == 2
    str_3 = '1+1+1'
    assert safe_eval(str_3) == 3
    str_4 = '1+1+2'
    assert safe_eval(str_4) == 4
    str_5 = '1+1+2+1'
    assert safe_eval(str_5) == 5
    str_6 = '1*1+2'
    assert safe_eval(str_6) == 3
    str_7 = '(1*1)+(2*1)'
    assert safe_eval(str_7)

# Generated at 2022-06-25 12:37:46.149423
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = list()
    test_case_0.description = 'Base test case'
    test_cases.append(test_case_0)
    for t in test_cases:
        t()
    return 0


# Generated at 2022-06-25 12:37:56.955712
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"hello world"') == 'hello world'
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('{"a": 1}') == {'a': 1}
    assert safe_eval('\n    safe_eval unit test\n    ') == '\n    safe_eval unit test\n    '
    assert safe_eval('{\n    safe_eval unit test\n    }') == '{\n    safe_eval unit test\n    }'
    assert safe_eval('[\n    safe_eval unit test\n    ]') == '[\n    safe_eval unit test\n    ]'



# Generated at 2022-06-25 12:38:06.292456
# Unit test for function safe_eval
def test_safe_eval():
    # string is a valid expression
    s = safe_eval('[1, 2, 3]')
    assert(s == [1, 2, 3])

    # string is a valid expression
    s = safe_eval('1')
    assert(s == 1)

    # string is not a valid expression
    s = safe_eval('1 +')
    assert(s == '1 +')

    # string is not a valid expression
    s = safe_eval('[[1, 2], 3]')
    assert(s == [[1, 2], 3])

    # string is not a valid expression
    s = safe_eval('[1, 2, 3')
    assert(s == '[1, 2, 3')

    # string is not a valid expression
    s = safe_eval('{1, 2, 3}')

# Generated at 2022-06-25 12:38:26.801811
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:32.704443
# Unit test for function safe_eval
def test_safe_eval():
    a = safe_eval('x')
    assert a == 'x'

    a = safe_eval('1')
    assert a == 1

    a = safe_eval('[1,2,5,6]')
    assert a == [1, 2, 5, 6]

    a = safe_eval('{"a": 3}')
    assert a == {"a": 3}

    # a = safe_eval('{% if x %}yes{% else %}no{% endif %}')
    # print(a)
    # assert a == ''

    a = safe_eval('None')
    assert a is None

    a = safe_eval('true')
    assert a is True

    a = safe_eval('false')
    assert a is False

    a = safe_eval('null')
    assert a is None

    # a

# Generated at 2022-06-25 12:38:38.476122
# Unit test for function safe_eval
def test_safe_eval():
    test_keyword = dict(
        with_items = 'item'
    )
    test_keyword = dict(
        with_items = 'item'
    )

    test_keyword['with_items'] = safe_eval(test_keyword['with_items'])

    print('Test 0: Test on normal string')

if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 12:38:39.627758
# Unit test for function safe_eval
def test_safe_eval():
    if True:
        test_case_0()
    return 42


# Generated at 2022-06-25 12:38:47.572302
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\n    safe_eval unit test\n    '
    dict_1 = dict({u'1': 2, u'3': u'4'})
    bool_0 = True
    bool_1 = False
    float_0 = 10.0
    float_1 = 1.0
    int_0 = 1
    int_1 = 0
    int_2 = -1
    list_0 = [0, True, False, 2.0]
    list_1 = [1, 2, 3]
    list_2 = [u'1', u'2', u'3']
    str_1 = u'a_str'
    dict_0 = dict()
    str_2 = '{{ a_str }}'
    str_3 = '{{ a_str }}'

# Generated at 2022-06-25 12:38:56.984973
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import container_to_text

    value_0 = safe_eval('[1,2,3]')
    assert value_0 == [1, 2, 3]
    value_1 = safe_eval('1+1')
    assert value_1 == 2
    value_2 = safe_eval('1+2*2')
    assert value_2 == 5
    value_3 = safe_eval('[1, 2, 3, 4]', dict(a=[1, 2, 3, 4]))
    assert value_3 == [1, 2, 3, 4]
    value_4 = safe_eval('a', dict(a=[1, 2, 3, 4]))
    assert value_4 == [1, 2, 3, 4]
    value_5 = safe_eval

# Generated at 2022-06-25 12:39:01.464992
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    return True

# Calculate and return results of the unit test

# Generated at 2022-06-25 12:39:09.368382
# Unit test for function safe_eval
def test_safe_eval():
    import copy
    # From /usr/lib/python2.7/ast.py
    #
    # A Node visitor base class that walks the abstract syntax tree and calls a
    # visitor function for every node found.  This function may return a value
    # which is forwarded by the `visit` method.
    # This class is meant to be subclassed, with the subclass adding visitor
    # methods.
    # Per default the visitor functions for the nodes are ``'visit_'`` +
    # class name of the node.  So a `TryFinally` node visit function would
    # be `visit_TryFinally`.  This behavior can be changed by overriding
    # the `visit` method.  If no visitor function exists for a node
    # (return value `None`) the `generic_visit` visitor is used instead.
    # Don't use

# Generated at 2022-06-25 12:39:18.519237
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2*2') == 4
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('{1:2,3:4}') == {1: 2, 3: 4}
    assert container_to_text(safe_eval('({1:2,3:4},)')) == u'(map(int, [1, 3]),)'
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('-1') == -1
    assert safe_eval('-1+2') == 1
    assert safe_eval('1-2') == -1
    assert safe_eval('True') == True

# Generated at 2022-06-25 12:39:22.345601
# Unit test for function safe_eval
def test_safe_eval():
    """
    SyntaxError: invalid syntax (test_safe_eval, line 45)
    """
    expr_0 = '1'
    result = safe_eval(expr_0)
    assert expr_0 == 1
    expr_1 = '1 + 2'
    result = safe_eval(expr_1)
    assert expr_1 == 3
    expr_2 = '1 + 2 + 3'
    result = safe_eval(expr_2)
    assert expr_2 == 6
    expr_3 = '1+2+3'
    result = safe_eval(expr_3)
    assert expr_3 == 6
    expr_4 = '1+2*3'
    result = safe_eval(expr_4)
    assert expr_4 == 7
    expr_5 = '1*2+3'