

# Generated at 2022-06-25 12:29:42.108822
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'{ foo: bar }'
    var_0 = safe_eval(bytes_0)
    bytes_1 = b'{{ foo }}: {{ bar }}'
    var_1 = safe_eval(bytes_1)
    if type(var_0) is not dict:
        raise Exception('Failed test 0')
    if type(var_1) is not str:
        raise Exception('Failed test 1')



# Generated at 2022-06-25 12:29:46.103303
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing function 'test_safe_eval'")
    try:
        test_case_0()
    except Exception:
        print("Hmmmmmm ... this should not happen")
        raise



# Generated at 2022-06-25 12:29:56.638785
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] == 2:
        bytes_0 = b'X{'
        var_0 = safe_eval(bytes_0)
        assert var_0 == bytes_0

    int_0 = 1
    safe_eval(int_0)

    str_0 = 'A{'
    var_1 = safe_eval(str_0)
    assert var_1 == str_0

    str_1 = 'A{'
    var_2 = safe_eval(str_1, include_exceptions=True)
    assert var_2[0] == str_1 and var_2[1] == None

    str_2 = '1'
    var_3 = safe_eval(str_2)
    assert var_3 == 1

    str_3 = '1'
    var_4 = safe

# Generated at 2022-06-25 12:29:57.829837
# Unit test for function safe_eval
def test_safe_eval():
    assert b'X{' == safe_eval(b'X{')



# Generated at 2022-06-25 12:30:01.721088
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X{'
    var_0 = safe_eval(bytes_0)
    assert var_0 == b'X{'


# Generated at 2022-06-25 12:30:11.394186
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:20.978878
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'True'") == True
    assert safe_eval("True") == True
    assert safe_eval("'False'") == False
    assert safe_eval("False") == False
    assert safe_eval("'None'") == None
    assert safe_eval("None") == None
    assert safe_eval("'test1'") == 'test1'
    assert safe_eval("test2") == 'test2'
    assert safe_eval("['test1', 'test2']") == ["test1", "test2"]
    assert safe_eval("{'test1': 1}") == {"test1": 1}

    # Test not in safe nodes

# Generated at 2022-06-25 12:30:22.725423
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]



# Generated at 2022-06-25 12:30:33.787085
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval')
    # Test #0: Hanging Keyboard
    try:
        test_case_0()
    except KeyboardInterrupt as e:
        print('Failed Test #0: Hanging Keyboard: ' + str(e))
    else:
        print('Passed Test #0: Hanging Keyboard')
    # Test #1: Without locals
    try:
        safe_eval('x')
    except Exception as e:
        print('Failed Test #1: Without locals: ' + str(e))
    else:
        print('Passed Test #1: Without locals')
    # Test #2: Safe eval with locals
    try:
        safe_eval('x', {'x': 1})
    except Exception as e:
        print('Failed Test #2: Safe eval with locals: ' + str(e))


# Generated at 2022-06-25 12:30:44.364887
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(0) == 0
    assert safe_eval(1) == 1
    assert safe_eval('a_string') == 'a_string'
    assert safe_eval('a_string') == 'a_string'
    assert safe_eval(True) == True
    assert safe_eval(False) == False
    assert safe_eval({'a':1}) == {'a':1}

    # comparison operators
    assert safe_eval('a < b') == 'a < b'
    assert safe_eval('a > b') == 'a > b'
    assert safe_eval('a >= b') == 'a >= b'
    assert safe_eval('a <= b') == 'a <= b'
    assert safe_eval('a == b') == 'a == b'

# Generated at 2022-06-25 12:30:47.710673
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:30:55.624793
# Unit test for function safe_eval
def test_safe_eval():
    # Test for a sys.version_info earlier than 2.6.9
    if sys.version_info < (2, 6, 9):
        try:
            test_case_0()
            # This should never happen.
            assert False
        except Exception:
            pass

    else:
        # Test for a sys.version_info of 2.6.9 and later
        # Test for a sys.version_info following 2.6.9
        try:
            # Call test case 0
            test_case_0()
            # This should never happen.
            assert False
        except Exception:
            # Check if the SystemExit exception
            # is raised
            pass



# Generated at 2022-06-25 12:31:03.822988
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure the module is set up correctly
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("'foo'", include_exceptions=True)[0] == "foo"
    assert safe_eval("6") == 6
    assert safe_eval("6") == 6

    # Test that a dict expression works
    assert safe_eval("{'bar': 6}") == {'bar': 6}
    assert safe_eval("{'bar': 6}") == {'bar': 6}

    # Test that an array expression works
    assert safe_eval("['bar', 'baz']") == ['bar', 'baz']
    assert safe_eval("['bar', 'baz']") == ['bar', 'baz']

    # Test that an array expression with a variable works

# Generated at 2022-06-25 12:31:10.388814
# Unit test for function safe_eval
def test_safe_eval():

    source_0 = b'a_list'
    source_1 = b'a_dict'
    source_2 = b'a_string'
    source_3 = b"'a_string'"
    source_4 = b'[]'
    source_5 = b'[1,2,3,4,5]'
    source_6 = b'[a_list]'
    source_7 = b'my_module'
    source_8 = b'd | length'
    source_9 = b'd | join'
    source_10 = b'[1,2,3,4,5] | map(attribute="name") | list'
    source_11 = b'true'
    source_12 = b'false'
    source_13 = b'null'
    source_14 = b'bar'
    source_15 = b

# Generated at 2022-06-25 12:31:20.388541
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:26.982434
# Unit test for function safe_eval
def test_safe_eval():

    bytes_0 = b'[4, 6, 8]'
    var_0 = safe_eval(bytes_0)
    tuple_0 = (4, 6, 8)

    assert(var_0 == tuple_0)

    bytes_1 = b"{'puppies': 'schnauzer'}"
    var_1 = safe_eval(bytes_1)
    dict_0 = {'puppies': 'schnauzer'}
    assert(var_1 == dict_0)

    bytes_2 = b'5 * 20'
    var_2 = safe_eval(bytes_2)
    assert(var_2 == 100)

    bytes_3 = b'(5 * 20) + (4 * 17)'
    var_3 = safe_eval(bytes_3)
    assert(var_3 == 154)



# Generated at 2022-06-25 12:31:37.394711
# Unit test for function safe_eval
def test_safe_eval():
    # Test json-like python constructs identified as unsafe.
    case_0 = b"{'a': b, 'b': c}"
    case_1 = b"{'a': b, 'b': 'c'}"
    case_2 = b"{b: 'c', 'a': 1}"
    case_3 = b"{'a': b, 'b': ('c')}"
    case_4 = b"{'a': b, 'b': [c]}"
    case_5 = b"{b: {'c': 'd'}}"
    case_6 = b"[a, b, c]"
    case_7 = b"[a, 'b', 'c']"
    case_8 = b"['a', b, c]"
    case_9 = b"['a', 'b', c]"
    case_

# Generated at 2022-06-25 12:31:45.598111
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{inventory_hostname}}"
    result, ex = safe_eval(expr, include_exceptions=True)
    assert result == expr and ex is None, "didn't return template string, got: %s" % result

    expr = "inventory_hostname + x"
    result, ex = safe_eval(expr, include_exceptions=True)
    assert result == expr and ex is None, "didn't return template string, got: %s" % result

    expr = "{a:2, b:3}"
    result = safe_eval(expr, include_exceptions=False)
    assert isinstance(result, dict) and result == {'a': 2, 'b': 3}, "didn't return dict, got: %s" % result

    expr = "[2, 3]"

# Generated at 2022-06-25 12:31:50.112594
# Unit test for function safe_eval
def test_safe_eval():

    try:
        test_case_0()
    except Exception as err:
        #print(str(err))
        pass

#
# Main starts here
#
if __name__ == '__main__':

    test_safe_eval()
    sys.exit(0)

# Generated at 2022-06-25 12:32:00.624351
# Unit test for function safe_eval
def test_safe_eval():

    # Check the safe_eval function with a empty expression
    expr_0 = ""
    try:
        safe_eval(expr_0)
    except Exception as e:
        print("safe_eval('%s') threw exception '%s' as expected" % (expr_0, e.message))
    print("safe_eval('%s') returned empty expression as expected" % expr_0)

    # Check the safe_eval function with a unsafe expression
    expr_1 = "__import__('os').system('whoami')"
    try:
        safe_eval(expr_1)
    except Exception as e:
        print("safe_eval('%s') threw exception '%s' as expected" % (expr_1, e.message))
    print("safe_eval('%s') returned expression as expected" % expr_1)

    #

# Generated at 2022-06-25 12:32:16.733923
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("True and False") is False
    assert safe_eval("True or False") is True
    assert safe_eval("True or False") is True
    assert safe_eval("None or False is False or None") is True
    assert safe_eval("True if False else False") is False
    assert safe_eval("True if False else True") is True
    assert safe_eval("False if True else None") is None
    assert safe_eval("None if False else False") is False
    assert safe_eval("{}") == {}
    assert safe_eval("False if False else {}") == {}
    assert safe_eval("{'a': 5}['a']") == 5
    assert safe_eval("{'a': 5}['a'] + 1") == 6
    assert safe_eval

# Generated at 2022-06-25 12:32:26.343203
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X'
    bool_0 = safe_eval('Y', locals = { 'Y' : True })
    bool_1 = safe_eval('Y')
    bool_2 = safe_eval('Y', locals = { 'Y' : True })
    bytes_1 = b'X'
    bool_3 = safe_eval('Y', locals = { 'Y' : True })
    bool_4 = safe_eval('Y')
    bool_5 = safe_eval('Y', locals = { 'Y' : True })
    bytes_2 = b'X'
    bool_6 = safe_eval('Y', locals = { 'Y' : True })
    bool_7 = safe_eval('Y')
    bool_8 = safe_eval('Y', locals = { 'Y' : True })

# Generated at 2022-06-25 12:32:31.537572
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{0}'
    expected = {'a':1}
    locals = {'a':1}
    result = safe_eval(expr, locals)
    assert result == expected, "expected safe_eval to return %s but it returned %s" % (expected, result)


# Generated at 2022-06-25 12:32:38.165295
# Unit test for function safe_eval
def test_safe_eval():

    from json import dumps
    from pprint import PrettyPrinter
    pp = PrettyPrinter()
    ansible_stderr = sys.stderr
    sys.stderr = open('/dev/null', 'w')

    # test simple literal
    e = 'null'
    r = safe_eval(e)
    assert r == None

    # test numbers
    e = '1234567890'
    r = safe_eval(e)
    assert r == 1234567890
    e = '-1234567890'
    r = safe_eval(e)
    assert r == -1234567890
    e = '0b1111'
    r = safe_eval(e)
    assert r == 15
    e = '0o17'
    r = safe_eval(e)
    assert r == 15


# Generated at 2022-06-25 12:32:43.599572
# Unit test for function safe_eval
def test_safe_eval():
    # Test for basic sanity
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 2 + 3') == 6
    assert safe_eval('1 + (2 * 3)') == 7
    assert safe_eval('1 + (2 * 3) + 4') == 11
    assert safe_eval('(1 + 2) * 3') == 9
    # Test for invalid characters
    try:
        safe_eval('@')
    except Exception:
        pass
    else:
        raise Exception('Did not raise exception on unexpected character')



# Generated at 2022-06-25 12:32:54.286839
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X{}'
    assert isinstance(var_0, string_types)
    assert var_0 == bytes_0

    bytes_1 = b'{"a":1, "b":2}'
    var_1 = safe_eval(bytes_1)
    assert isinstance(var_1, dict)
    assert var_1 == ast.literal_eval(bytes_1)

    bytes_2 = b'1 + 1'
    var_2 = safe_eval(bytes_2)
    assert isinstance(var_2, int)
    assert var_2 == 2

    bytes_3 = b'1 + 1 + 1'
    var_3 = safe_eval(bytes_3)
    assert isinstance(var_3, int)
    assert var_3 == 3

    bytes_4 = b

# Generated at 2022-06-25 12:33:04.586293
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluates safe expression
    a = 300
    result = safe_eval('a > 100')
    assert result == True

    # Evaluates safe expression (with_items)
    b = ['A', 'B', 'C']
    result = safe_eval('b', locals=dict(b=b))
    assert result == ['A', 'B', 'C']

    # Safe evaluation raises an exception
    bytes_0 = b'X{'
    try:
        result = safe_eval(bytes_0, include_exceptions=True)
    except AssertionError:
        assert result == (bytes_0, None)

    # Safe evaluation raises an exception
    result = safe_eval('d+1', locals=dict(), include_exceptions=True)
    assert result == ('d+1', None)

    # Safe evaluation raises an exception

# Generated at 2022-06-25 12:33:12.145186
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:19.503178
# Unit test for function safe_eval
def test_safe_eval():
    # Sample data
    bytes_0 = b'X{'
    str_0 = 'False'
    str_1 = 'blah'
    str_2 = 'True'
    str_3 = 'None'
    str_4 = 'False or True'
    str_5 = 'True if False else False'
    str_6 = '1'
    str_7 = 'True and False'
    str_8 = '1 if False else False'
    str_9 = 'True if True else False'
    str_10 = 'True if True else None'
    str_11 = 'True if not False else False'
    str_12 = 'True if False else True'
    str_13 = '{'
    str_14 = 'True if False else True if True else True'

# Generated at 2022-06-25 12:33:28.771219
# Unit test for function safe_eval
def test_safe_eval():
    constant_0 = str('no')
    expr = '1 + 1'
    expr_0 = '1 + 1'
    expr_1 = 1
    expr_2 = '3 + 3'
    expr_3 = 1
    expr_4 = '1 + 1'
    expr_5 = '100 * 100'
    expr_6 = '1'
    expr_7 = 'my_list|length'
    # tuples should be converted to lists
    expr_8 = '(1,2,3)'
    expr_9 = '(1, 2, 3)'
    expr_10 = '1 + 1'
    expr_11 = 'a_string'
    expr_12 = '1 + 1'
    expr_13 = 'abc'
    expr_14 = '1 + 1'
    expr_15 = '1'
    expr

# Generated at 2022-06-25 12:33:48.461619
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(b'True') is True
    assert safe_eval(b'False') is False
    assert safe_eval(b'None') is None
    assert safe_eval(b'"asdf"') == "asdf"
    assert safe_eval(b'"a{{s}}df"') == "a{{s}}df"
    assert safe_eval(b'"a{{s}}{{"') == "a{{s}}{{"
    assert safe_eval(b'"a{{"') == "a{{"
    assert safe_eval(b"u'asdf'") == "asdf"
    assert safe_eval(b"u'a{{s}}df'") == "a{{s}}df"
    assert safe_eval(b"u'a{{s}}{{") == "a{{s}}{{"
    assert safe_

# Generated at 2022-06-25 12:33:57.452125
# Unit test for function safe_eval
def test_safe_eval():
    a_list = ['a', {'b': 'c'}]
    a_dict = {
        'a': 'b',
        'list': a_list,
        'int': 1,
        'float': 3.1,
        'none': None,
        'true': True,
        'false': False,
    }

    for (k, v) in a_dict.items():
        assert k == safe_eval(k)

    for (k, v) in a_dict.items():
        assert v == safe_eval(v)

    for (k, v) in a_dict.items():
        assert v == safe_eval(repr(v))

    assert a_list == safe_eval(repr(a_list))

    assert 1 == safe_eval('1')
    assert 1 == safe_eval

# Generated at 2022-06-25 12:34:00.974795
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(b'X{') == b'X{'



# Generated at 2022-06-25 12:34:10.895607
# Unit test for function safe_eval
def test_safe_eval():
    # This test does not compile, so it errors out
    # bytes_0 = b'X{'
    # var_0 = safe_eval(bytes_0)
    # assert var_0 is bytes_0

    # This test was added by the original author, but it is true
    # based on the value of C.DEFAULT_DEBUG which is False
    assert C.DEFAULT_DEBUG is False

    # Test new lines that should not be stripped
    bytes_0 = b'{}\n{}'
    var_0 = safe_eval(bytes_0)
    assert var_0 is bytes_0

    bytes_1 = b'{}'
    bytes_2 = b'{}'
    var_0 = safe_eval(bytes_0)
    assert var_0 is bytes_0

# Generated at 2022-06-25 12:34:19.345258
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:27.040342
# Unit test for function safe_eval
def test_safe_eval():
    unicode_0 = u'[{}]'
    result_safe_eval_0 = safe_eval(unicode_0)
    unicode_1 = u'[{}]'
    result_safe_eval_1 = safe_eval(unicode_1, dict(), True)
    assert result_safe_eval_0 == [{}]
    assert result_safe_eval_1[1] is None
    assert (result_safe_eval_1[0] == [{}])

# Generated at 2022-06-25 12:34:28.615019
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Function to test function safe_eval

# Generated at 2022-06-25 12:34:38.087144
# Unit test for function safe_eval
def test_safe_eval():
    expr_0 = 'uname'
    var_0 = safe_eval(expr_0)
    if not var_0:
        # I don't know how to test the output.  It's wrong
        raise AssertionError()

    expr_1 = 'uname'
    var_1 = safe_eval(expr_1)
    assert var_1 == expr_1

    expr_2 = 'uname - a'
    var_2 = safe_eval(expr_2)
    assert var_2 == expr_2

    expr_3 = 'uname - a'
    var_3 = safe_eval(expr_3)
    assert var_3 == expr_3

    expr_4 = 'uname - a'
    var_4 = safe_eval(expr_4)
    assert var_4 == expr_4


# Generated at 2022-06-25 12:34:48.506787
# Unit test for function safe_eval
def test_safe_eval():
    # Initialize test data.
    # Assumption: dict_test contains only JSON-serializable python objects.
    dict_test = {
        'test_bool_true': True,
        'test_bool_false': False,
        'test_string': 'This is a test',
        'test_number': 123,
        'test_list': [1, 2],
        'test_subdict': {'subdict_key': 'subdict_value'},
        'test_subdict_none_val': {'subdict_key': None},
        'test_sublist': [1, {'sublist_subdict_key': 'sublist_subdict_value'}],
    }

    # Iterate through test data to test safe_eval for all the cases.

# Generated at 2022-06-25 12:34:54.570192
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(b'foo') == 'foo'
    assert safe_eval(b'bar') == 'bar'
    assert safe_eval(b'foo,bar') == 'foo,bar'
    assert safe_eval(b'foo, bar') == 'foo, bar'
    assert safe_eval(b'foo,bar, baz') == 'foo,bar, baz'
    assert safe_eval(b'foo, bar, baz') == 'foo, bar, baz'
    assert safe_eval(b'foo, bar,baz') == 'foo, bar,baz'
    assert safe_eval(b'foo, bar, baz,') == 'foo, bar, baz,'
    assert safe_eval(b'foo, bar, baz, ') == 'foo, bar, baz, '

# Generated at 2022-06-25 12:35:06.503889
# Unit test for function safe_eval
def test_safe_eval():
    for arg in (b'X{"Foo": "Bar"}', b'X[1,2,3]', b'X{"a": "1", "b": "2"}'):
        assert safe_eval(arg) == eval(to_native(arg))



# Generated at 2022-06-25 12:35:08.161076
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:35:16.303472
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X{'
    var_0 = safe_eval(bytes_0)
    assert var_0 is not None
    assert var_0 == 'X{'

    assert safe_eval(None) is None
    assert safe_eval(dict()) == dict()
    assert safe_eval(dict(a=1)) == dict(a=1)
    assert safe_eval(False) is False
    assert safe_eval(True) is True
    assert safe_eval(bytes_0) == 'X{'
    assert safe_eval(0) == 0
    assert safe_eval(10) == 10
    assert safe_eval('0') == 0
    assert safe_eval('10') == 10
    assert safe_eval('10.1') == 10.1
    assert safe_eval('0x10') == 16
   

# Generated at 2022-06-25 12:35:25.244519
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = safe_eval('{"a": ["bar", "baz"], "foo": "foobarbaz"}')

# Generated at 2022-06-25 12:35:36.300819
# Unit test for function safe_eval
def test_safe_eval():

    # no exception raised
    try:
        test_case_0()
        test_ok = True
    except Exception:
        test_ok = False
    print('test_case_0:', test_ok)

    # another test case for safe_eval()
    result = safe_eval('{foo: bar,}', dict(foo='baz'),
                       include_exceptions=True)
    assert result == ('{foo: bar,}', None), result
    print('test_case_1: OK')

    # another test case for safe_eval()

# Generated at 2022-06-25 12:35:43.007923
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0 crashes in Python 2.7
    # test_case_0()
    # Test case 1
    bytes_1 = b'X{{ foo }}Z'
    var_1 = safe_eval(bytes_1)
    # Test case 2
    bytes_2 = b'{"foo": "bar"}'
    var_2 = safe_eval(bytes_2)
    # Test case 3
    bytes_3 = b'{foo: bar}'
    var_3 = safe_eval(bytes_3)
    # Test case 4
    bytes_4 = b'{"foo": "bar", "ansible_facts": {"foo": [1, 2], "bar": {"baz": [3, 4]}}}'
    var_4 = safe_eval(bytes_4)
    # Test case 5

# Generated at 2022-06-25 12:35:43.602854
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:35:44.793467
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Entry point for running this file standalone

# Generated at 2022-06-25 12:35:54.221426
# Unit test for function safe_eval
def test_safe_eval():
    print("Test safe_eval")

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test 1: Expression evaluates to itself when exceptions are included
    print("Test 1")
    expr = AnsibleUnsafeText(u"1")
    expected_result = u"1"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expected_result
    assert exception is None

    # Test 2: Expression evaluates to itself when exceptions are not included
    print("Test 2")
    expr = AnsibleUnsafeText(u"1")
    expected_result = u"1"
    result = safe_eval(expr)
    assert result == expected_result

    # Test 3: Expression evaluates to itself when exceptions are included
    print("Test 3")

# Generated at 2022-06-25 12:36:01.462249
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('None') is None

    assert safe_eval('[1,2,3]') != '["1","2","3"]'
    assert safe_eval('{"a": "b"}') != '{"a": "b"}'
    assert safe_eval('None') == 'None'

# Test case for function safe_eval

# Generated at 2022-06-25 12:36:14.759401
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_safe_eval()
    sys.exit(0)

# Generated at 2022-06-25 12:36:23.191343
# Unit test for function safe_eval
def test_safe_eval():
    with open("./test/eval_test/safe_eval.json", "r") as input_file:
        for line in input_file.readlines():
            try:
                j = ast.literal_eval(line)
            except SyntaxError:
                continue
            if j[0] == "eval":
                with open("./test/eval_test/safe_eval.log", 'a') as log_file:
                    try:
                        result = safe_eval(j[1])
                        print(j, "=>", result, file=log_file)
                    except SyntaxError as e:
                        print(j, "=>", "SyntaxError", file=log_file)
                    except Exception:
                        print(j, "=>", "Exception", file=log_file)
                log_file.close()

#

# Generated at 2022-06-25 12:36:32.366204
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(expr=b'[1, 2]') == [1, 2]
    assert safe_eval(expr=b'[1,2]') == [1, 2]
    assert safe_eval(expr=b'[1, 2]') == [1, 2]
    assert safe_eval(expr=b'[1,2,]') == [1, 2]
    assert safe_eval(expr=b'[1,2,]') == [1, 2]
    assert safe_eval(expr=b'[1, 2]') == [1, 2]
    assert safe_eval(expr=b'[1,2]') == [1, 2]
    assert safe_eval(expr=b'[1, 2]') == [1, 2]

# Generated at 2022-06-25 12:36:42.633623
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'{"a":3}'
    result = safe_eval(bytes_0)
    assert result == {"a": 3}

    # simple use of a dict expression
    result = safe_eval("{'a': 3}")
    assert result == {"a": 3}

    # simple use of a list expression
    result = safe_eval("[1,2,3]")
    assert result == [1,2,3]

    # simple use of a dict expression with call
    result = safe_eval("{'a': []}")
    assert result == {"a": []}

    # simple use of a dict expression with call
    result = safe_eval("{'a': ()}")
    assert result == {"a": ()}

    # simple use of dict expression with call

# Generated at 2022-06-25 12:36:44.147884
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X{'
    # Call to safe_eval
    var_0 = safe_eval(bytes_0)
    assert var_0 == b'X{'


# Generated at 2022-06-25 12:36:48.809549
# Unit test for function safe_eval
def test_safe_eval():
    # verify that we do not allow malformed expressions
    try:
        x = safe_eval('{{ foo')
    except Exception as e:
        print(e)

    # verify that safe_eval is the same as eval
    # with the exception of offending syntax
    y = eval("[1, 2, 3]")
    x = safe_eval("[1, 2, 3]")
    assert x == y

    # verify that we do not allow AST nodes with invalid
    # children (allowing a set node)
    try:
        x = safe_eval('{1, 2, 3}')
    except Exception as e:
        print(e)

    # verify that we allow dicts
    x = safe_eval('{"a": 1, "b": 2, "c": 3}')

# Generated at 2022-06-25 12:36:55.979956
# Unit test for function safe_eval
def test_safe_eval():
    # Unicode string
    u = u'foo'
    assert safe_eval(u) == u

    # Bytestring
    b = b'foo'
    assert safe_eval(b) == b

    # Integers
    i = 12345
    assert safe_eval(i) == i

    # Lists
    n = [1, 2, 3, 4]
    assert safe_eval(n) == n

    # Dictionaries
    d = {u'a': u'b', u'c': u'd', u'e': u'f'}
    assert safe_eval(d) == d

    # Tuples
    t = (u'a', 2, ['a', 'b'])
    assert safe_eval(t) == t

    # Sets

# Generated at 2022-06-25 12:37:04.625346
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'X{}'
    var_0 = safe_eval(bytes_0)
    assert var_0 == 'X{}'
    bytes_1 = b': a == "abc'
    var_1 = safe_eval(bytes_1)
    assert var_1 == ': a == "abc'
    bytes_2 = b'a\tb\nc\n"def"\u00a9\u00ae'
    var_2 = safe_eval(bytes_2)
    assert var_2 == 'a\tb\nc\n"def"©®'
    bytes_3 = b'a\tb\nc\n"def"\u00a9\u00ae'
    var_3 = safe_eval(bytes_3)

# Generated at 2022-06-25 12:37:15.150588
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")

    shouldFail = False
    failedTest = 0

    # Safe evaluation
    print("Testing safe evaluation")
    try:
        test_case_0()
    except Exception:
        failedTest = 1
        shouldFail = True
    assert failedTest == 0, "Test failed"
    if shouldFail:
        sys.exit()

    print("Testing safe evaluation - Done!")

    # Unsafe evaluation
    print("Testing unsafe evaluation")
    test_bytes = b'__import__("os").system("ls") #'
    try:
        result_bytes = safe_eval(test_bytes)
    except Exception as e:
        # Encountered an exception
        expectedException = e
        print("Encountered an exception: " + str(expectedException))

# Generated at 2022-06-25 12:37:17.158210
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval()")
    test_case_0()
    print("Passed safe_eval() tests")
    print("")

# Generated at 2022-06-25 12:37:28.894363
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except:
        res = 1
    assert res == 0, "Test safe_eval error."



# Generated at 2022-06-25 12:37:30.170637
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:37:37.017573
# Unit test for function safe_eval
def test_safe_eval():
    # Testing to ensure safe_eval raises an exception
    try:
        safe_eval("__import__('os').system('ls')", include_exceptions=True)
    except Exception:
        pass
    else:
        raise AssertionError("No exception raised.")

    # Testing to ensure safe_eval raises an exception
    try:
        safe_eval("__import__('os').system('ls')")
    except Exception:
        pass
    else:
        raise AssertionError("No exception raised.")

    # Testing to ensure safe_eval raises an exception
    try:
        safe_eval("[] in a")
    except Exception:
        pass
    else:
        raise AssertionError("No exception raised.")

    # Testing to ensure safe_eval raises an exception

# Generated at 2022-06-25 12:37:42.278247
# Unit test for function safe_eval
def test_safe_eval():

    # evaluates true
    try:
        var_0 = safe_eval('true')
        assert var_0
    except:
        raise AssertionError('Failed')

    # evaluates false
    try:
        var_1 = safe_eval('false')
        assert var_1 == False
    except:
        raise AssertionError('Failed')

    # evaluates null
    try:
        var_2 = safe_eval('null')
        assert var_2 is None
    except:
        raise AssertionError('Failed')

    # evaluates number
    try:
        var_3 = safe_eval('123')
        assert var_3 == 123
    except:
        raise AssertionError('Failed')

    # evaluates string

# Generated at 2022-06-25 12:37:43.495451
# Unit test for function safe_eval
def test_safe_eval():
    # Uncomment to show test case
    # test_case_0()
    pass

if __name__ == '__main__':
    # Testing
    test_safe_eval()

# Generated at 2022-06-25 12:37:45.135180
# Unit test for function safe_eval
def test_safe_eval():
    # replace this with the call to your function or class. 
    # You may need to change the function name
    var_0 = test_case_0()

# Generated at 2022-06-25 12:37:55.857902
# Unit test for function safe_eval
def test_safe_eval():
    print('Test Case 1')

# Generated at 2022-06-25 12:38:06.269399
# Unit test for function safe_eval
def test_safe_eval():
    # python2
    if sys.version_info[0] < 3:
        bytes_0 = b'X{'
        unicode_0 = u'X{'

        var_0 = safe_eval(bytes_0)
        assert var_0 == bytes_0

        var_1 = safe_eval(unicode_0)
        assert var_1 == unicode_0

        bytes_0 = b'\xe4\xb8\x8b\xe8\xbf\x94\xe7\x8a\xb6\xe6\x80\x81\xe8\xa7\x84\xe5\x88\x99'

# Generated at 2022-06-25 12:38:09.112151
# Unit test for function safe_eval
def test_safe_eval():
    expression = [b'foo', b'bar', b'baz', u'foo', u'bar', u'baz']
    for entry in expression:
        result = safe_eval(entry)
        assert result == entry



# Generated at 2022-06-25 12:38:10.045317
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:38:29.735741
# Unit test for function safe_eval
def test_safe_eval():
    # Test with the expected JSON types
    str_0 = '{"foo":"bar"}'
    var_0 = safe_eval(str_0)

    assert isinstance(var_0, dict)
    assert isinstance(var_0.keys()[0], str)
    assert isinstance(var_0['foo'], str)
    assert var_0['foo'] == "bar"

    # Test with a few literals
    str_0 = '42'
    var_0 = safe_eval(str_0)
    assert isinstance(var_0, int)
    assert var_0 == 42

    str_0 = '42.0'
    var_0 = safe_eval(str_0)
    assert isinstance(var_0, float)
    assert var_0 == 42.0


# Generated at 2022-06-25 12:38:31.371388
# Unit test for function safe_eval
def test_safe_eval():
    assert False


# Generated at 2022-06-25 12:38:40.894743
# Unit test for function safe_eval
def test_safe_eval():
    f_globals = {}
    f_globals['safe_eval'] = safe_eval
    exec('''def test_case_0():
    str_0 = 'available_api_versions'
    var_0 = safe_eval(str_0)''', f_globals)
    f_globals['test_case_0']()

    try:
        exec('''def test_case_1():
    str_0 = 'a_list_variable'
    var_0 = safe_eval(str_0)''', f_globals)
        f_globals['test_case_1']()
    except Exception as e:
        pass

test_safe_eval()


# Make coding more python3-ish
__metaclass__ = type


# Generated at 2022-06-25 12:38:48.745364
# Unit test for function safe_eval
def test_safe_eval():
    import collections
    import inspect
    import os
    import sys
    import types

    from ansible.module_utils.common.text import safe_eval

    TestCase = collections.namedtuple('TestCase', 'expression expected')


# Generated at 2022-06-25 12:38:54.191040
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('1') == 1
    assert safe_eval('"a string"') == 'a string'
    assert safe_eval('1+1') == 2
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1,"b":2,"c":3}') == {"a":1,"b":2,"c":3}
    assert safe_eval('var', {'var': 'value'}) == 'value'

# Generated at 2022-06-25 12:39:04.000515
# Unit test for function safe_eval

# Generated at 2022-06-25 12:39:10.828560
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('not "a" in ["a", "b"]') is True
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('{"a":1,"b":2}') == {"a": 1, "b": 2}
    assert safe_eval('"a_string"') == "a_string"
    # Assert that it raises an exception when given a string with a callable
    try:
        res = safe_eval('len(["a", "b"])')
        assert res is not 3, "Expected safe_eval to raise exception"
    except:
        pass



# Generated at 2022-06-25 12:39:11.615261
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:39:20.413112
# Unit test for function safe_eval
def test_safe_eval():
    # The following strings are valid
    str_0 = "'str'"
    str_1 = '"str"'
    str_2 = "'''str'''"
    str_3 = '''"""str"""'''
    str_4 = 'True'
    str_5 = 'False'
    str_6 = 'None'
    str_7 = '1'
    str_8 = '1.0'
    str_9 = '0'
    str_10 = '0.0'
    str_11 = 'True and False or True'
    str_12 = 'True and False or True and False'
    str_13 = '''True or False and (1+1 == 2) and "bool"'''
    str_14 = '{}'

# Generated at 2022-06-25 12:39:21.151145
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

