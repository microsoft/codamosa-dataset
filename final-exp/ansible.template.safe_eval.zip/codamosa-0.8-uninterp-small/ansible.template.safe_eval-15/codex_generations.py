

# Generated at 2022-06-25 12:29:46.111629
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(b'False') == False
    assert safe_eval(b'null') is None
    assert safe_eval(b'true') == True
    assert safe_eval(b'9') == 9
    assert safe_eval(b'[1,2,3]') == [1,2,3]
    assert safe_eval(b'(1,2,3)') == (1,2,3)
    assert safe_eval(b'{"a": "A", "b": "B"}') == {"a": "A", "b": "B"}
    assert safe_eval(b'foo') == "foo"



# Generated at 2022-06-25 12:29:56.680424
# Unit test for function safe_eval
def test_safe_eval():
    answers = list()
    answers.append(['foo', None])
    answers.append(['\'bar\'', None])
    answers.append(['baz', None])
    answers.append(['true', None])
    answers.append(['false', None])
    answers.append(['null', None])
    answers.append(['1 + 2', None])
    answers.append(['4 * 5 / 2', None])
    answers.append(['1 + 2 + 3', None])
    answers.append(['1 + 2 + 3 + 4', None])
    answers.append(['1 + 2 + 3 + 4 + 5', None])
    answers.append(['1 + 2 + 3 + 4 + 5 + 6', None])
    answers.append(['1 + 2 + 3 + 4 + 5 + 6 + 7', None])
   

# Generated at 2022-06-25 12:30:04.097692
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:12.683319
# Unit test for function safe_eval
def test_safe_eval():
    # NOTE (to be cleaned up): these tests are in a very fragile state as
    # we attempt to allow/disallow more functionality.  Eventually this
    # will be rewritten so that we have a whitelist of AST nodes that are
    # allowed.  The blacklisting of builtins is a stopgap until then.
    #
    # The current blacklist implementation is incorrect, we need to
    # modify the return value of the ast.builtin_type_names global
    # to filter out any callables that we don't want to allow.

    # Test that we can evaluate non-strings
    assert safe_eval(12345) == 12345
    assert safe_eval(False) is False
    assert safe_eval(None) is None
    assert safe_eval([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-25 12:30:21.717660
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']")
    assert result == ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    result = safe_eval([1,2,3,4,5,6])
    assert result == [1,2,3,4,5,6]

# Generated at 2022-06-25 12:30:32.743332
# Unit test for function safe_eval
def test_safe_eval():
    assert "invalid expression (not_an_int)" in str(safe_eval("not_an_int", include_exceptions=True)[1])
    assert -1 == safe_eval("-1")
    assert 1 == safe_eval("1")
    assert "invalid function: open" in str(safe_eval("open('/etc/passwd')", include_exceptions=True)[1])
    assert "invalid function: system" in str(safe_eval("system('ls /')", include_exceptions=True)[1])
    assert "invalid expression (var_0)" in str(safe_eval("var_0", include_exceptions=True)[1])
    assert "invalid expression (not_an_int)" in str(safe_eval("not_an_int", include_exceptions=True)[1])

# Generated at 2022-06-25 12:30:40.142359
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = True
    bool_1 = False
    str_0 = 'person'
    str_1 = 'person'
    int_0 = 555
    int_1 = 555
    float_0 = 3.3
    list_0 = [str_0, int_0]
    list_1 = [str_1, int_1]

    # True
    result = safe_eval(bool_0)
    assert result == True

    # False
    result = safe_eval(bool_1)
    assert result == False

    # 'person' (str)
    result = safe_eval(str_0)
    assert result == 'person'

    # 'person' (str)
    result = safe_eval(str_1)
    assert result == 'person'

    # 555 (int)
    result = safe_

# Generated at 2022-06-25 12:30:49.621446
# Unit test for function safe_eval
def test_safe_eval():
    # Good values
    good_test_values = [
        'True',
        'False',
        '"Hello World!"',
        'True or False',
        'True and False',
        'True and False or True',
        'True or False and True',
        '1 + 1',
        '"Hello World!" + "!"',
        '"Hello" + " World!"',
        '"Hello World!" * 3',
        '[1, 2, 3]',
        '(1, 2, 3)',
        '{1, 2, 3}',
        '{1: 1, 2: 2, 3: 3}'
    ]

    # Bad values

# Generated at 2022-06-25 12:30:57.756286
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1, 2, 3}') == {1, 2, 3}
    assert safe_eval('{"k1": "v1", "k2": "v2"}') == {"k1": "v1", "k2": "v2"}
    assert safe_eval('{"k1": "v1", "k2": "v2", "k3": ["1", "2", "3"], "k4": {"k41": "v41", "k42": "v42"}}') == {
        "k1": "v1", "k2": "v2", "k3": ["1", "2", "3"], "k4": {"k41": "v41", "k42": "v42"}}


# Generated at 2022-06-25 12:31:01.782125
# Unit test for function safe_eval
def test_safe_eval():
    # this test just makes sure the function will run without exceptions
    # the actual results are not verified here

    # run test with and without the boolean to insure the code still works
    # even when the W_SAFE_EVAL_BOOL is set to either True or False
    safe_eval_bool = True
    test_case_0()
    safe_eval_bool = False
    test_case_0()

# Generated at 2022-06-25 12:31:10.499406
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:20.516943
# Unit test for function safe_eval
def test_safe_eval():
    # Test for bool_0
    bool_0 = False
    var_0 = safe_eval(bool_0)
    assert var_0 is False

    # Test for bool_1
    bool_1 = True
    var_1 = safe_eval(bool_1)
    assert var_1 is True

    # Test for complex_1
    complex_1 = (2+3j)
    var_2 = safe_eval(complex_1)
    assert var_2 == (2+3j)

    # Test for float_0
    float_0 = 3.14
    var_3 = safe_eval(float_0)
    assert var_3 == 3.14

    # Test for int_0
    int_0 = 100
    var_4 = safe_eval(int_0)
    assert var_4 == 100



# Generated at 2022-06-25 12:31:31.211176
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure that Booleans are preserved from the string
    result_bool_true = safe_eval('true')
    assert result_bool_true is True
    result_bool_false = safe_eval('false')
    assert result_bool_false is False

    # Ensure that None is preserved from the string
    result_none = safe_eval('null')
    assert result_none is None

    # Ensure that lists are preserved from the string
    result_list_empty = safe_eval('[]')
    assert result_list_empty == []
    result_list_one = safe_eval('["one"]')
    assert result_list_one == ["one"]
    result_list_two = safe_eval('["one", "two"]')
    assert result_list_two == ["one", "two"]

    # Ensure that dictionaries are preserved from the string

# Generated at 2022-06-25 12:31:41.103891
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("true")

    assert safe_eval("null is None")

    assert safe_eval("'hi'+'there'") == 'hithere'

    assert safe_eval("[1,2,3]") == [1, 2, 3]

    assert safe_eval("(1,2,3)") == (1, 2, 3)

    assert safe_eval("[1,'2',3]") == [1, '2', 3]

    assert safe_eval("[1,2,3]+[4,5,6]") == [1, 2, 3, 4, 5, 6]

    assert safe_eval("dict(a=1,b=2)") == dict(a=1, b=2)

    assert safe_eval("5 > 3")


# Generated at 2022-06-25 12:31:47.604016
# Unit test for function safe_eval
def test_safe_eval():
    # test constant strings
    assert safe_eval('0') == 0
    assert safe_eval('2') == 2
    assert safe_eval('4.3') == 4.3
    assert safe_eval('foo') == "foo"
    assert safe_eval('"bar"') == "bar"
    assert safe_eval("'baz'") == "baz"
    assert safe_eval('"bam"') == "bam"
    assert safe_eval('"foo bar"') == "foo bar"
    assert safe_eval('"foo\nbar"') == "foo\nbar"
    assert safe_eval('"foo\"bar"') == 'foo"bar'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_

# Generated at 2022-06-25 12:31:57.532148
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval(4)
    assert result == 4
    result = safe_eval('4')
    assert result == 4
    result = safe_eval('4 + 3')
    assert result == 7
    result = safe_eval('[1,2,3]')
    assert result == [1, 2, 3]
    result = safe_eval('1 in [1,2,3]')
    assert result
    result = safe_eval('False')
    assert result is False
    result = safe_eval('True')
    assert result is True
    result = safe_eval('None')
    assert result is None
    result = safe_eval('4 if 4 > 3 else 3')
    assert result == 4



# Generated at 2022-06-25 12:31:59.438688
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('2 + 3')
    assert result == 5



# Generated at 2022-06-25 12:32:07.038980
# Unit test for function safe_eval
def test_safe_eval():
    # Set the following variables
    # bool_0 = False
    # var_0 = safe_eval(bool_0)
    # var_0 = safe_eval("var_0")
    var_0 = safe_eval("var_0")
    var_1 = safe_eval("var_0")
    # var_1 = safe_eval("var_0")

    # Outputs
    print("This should be False: " + str(var_0))
    print("This should be False: " + str(var_1))


# test_case_0()
# test_safe_eval()

# Generated at 2022-06-25 12:32:17.977700
# Unit test for function safe_eval
def test_safe_eval():

    # Test with literal booleans
    bool_1 = "false"
    bool_2 = "true"
    bool_3 = "True"
    bool_4 = "False"
    var_0 = safe_eval(bool_1)
    assert var_0 == False, "Expected false!"
    var_1 = safe_eval(bool_2)
    assert var_1 == True, "Expected true!"
    var_2 = safe_eval(bool_3)
    assert var_2 == True, "Expected true!"
    var_3 = safe_eval(bool_4)
    assert var_3 == False, "Expected false!"

    # Test with non-literal booleans (in quotes)
    bool_5 = "'false'"
    bool_6 = "'true'"
    bool_7 = "'True'"

# Generated at 2022-06-25 12:32:27.905327
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_bool, to_text


# Generated at 2022-06-25 12:32:37.892536
# Unit test for function safe_eval
def test_safe_eval():
    v = safe_eval('{{ foo }}')
    assert(type(v) == str)
    v = safe_eval(u'{{ foo }}')
    assert(type(v) == str)
    v = safe_eval('[1, 2, 3]')
    assert(type(v) == list)
    v = safe_eval(u'[1, 2, 3]')
    assert(type(v) == list)
    v = safe_eval('{"foo": "bar"}')
    assert(type(v) == dict)
    v = safe_eval(u'{"foo": "bar"}')
    assert(type(v) == dict)
    v = safe_eval('{{ foo }}', include_exceptions=True)
    assert(type(v) == tuple)

# Generated at 2022-06-25 12:32:39.352403
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:49.425050
# Unit test for function safe_eval
def test_safe_eval():
    try:
        assert safe_eval('42') == 42
    except:
        assert False, "simple int literal failed"
    try:
        assert safe_eval('(22,33)') == (22, 33)
    except:
        assert False, "simple tuple failed"
    try:
        assert safe_eval('a_dict', {'a_dict': "{'foo': 'bar'}"}) == {'foo': 'bar'}
    except:
        assert False, "simple dict failed"
    try:
        assert safe_eval("(a_dict['foo'], a_dict['foo'])", {'a_dict': "{'foo': 'bar'}"}) == ('bar', 'bar')
    except:
        assert False, "dict lookup failed"

# Generated at 2022-06-25 12:32:50.924076
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:33:00.868849
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic
    import os

    global_var = 'abc'

    dummy_variable_dict = dict()
    dummy_variable_dict['ansible_diff_mode'] = 'yes'

    results = dict(skipped=False, msg='', failed=False, changed=False, skipped_reason='')

# Generated at 2022-06-25 12:33:10.252348
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:15.576186
# Unit test for function safe_eval
def test_safe_eval():
    success, result = safe_eval('1+2', include_exceptions=True)
    if success:
        assert result == 3
    else:
        assert False
    success, result = safe_eval('1+2+3+4', include_exceptions=True)
    if success:
        assert result == 10
    else:
        assert False


# Generated at 2022-06-25 12:33:28.046676
# Unit test for function safe_eval
def test_safe_eval():
    # this test case was taken from the bug report:
    # https://github.com/ansible/ansible/issues/12403
    str_0 = '{u\'7\': u\'invalid-email\', u\'4\': u\'domain-name-invalid\', u\'1\': u\'has-dynamic-name\', u\'6\': u\'invalid-server-name\', u\'9\': u\'deactivated\', u\'10\': u\'invalid\', u\'5\': u\'domain-name-not-found\', u\'8\': u\'has-dynamic-ip\', u\'3\': u\'no-dns-entries\', u\'2\': u\'is-srv-record\'}'
    var_0 = safe_eval(str_0)

    #

# Generated at 2022-06-25 12:33:34.105223
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{0: 1, 1: 2}') == {0: 1, 1: 2}
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('3') == 3
    assert safe_eval('3.1') == 3.1
    assert safe_eval('"hello"') == "hello"
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{1:2,2:3}') == {1:2, 2:3}

# Generated at 2022-06-25 12:33:45.617150
# Unit test for function safe_eval
def test_safe_eval():
    func_ret_0 = safe_eval('[1,2,3]')
    assert func_ret_0 == [1,2,3]
    func_ret_1 = safe_eval('{1:2,3:4}')
    assert func_ret_1 == {1:2,3:4}
    func_ret_2 = safe_eval('(1,2,3)')
    assert func_ret_2 == (1,2,3)
    func_ret_3 = safe_eval('{"a":1,"b":2}')
    assert func_ret_3 == {"a":1,"b":2}
    func_ret_4 = safe_eval('true')
    assert func_ret_4 == True
    func_ret_5 = safe_eval('null')
    assert func_ret_5 is None

# Generated at 2022-06-25 12:33:49.099610
# Unit test for function safe_eval
def test_safe_eval():
    assert True


# Generated at 2022-06-25 12:33:50.050743
# Unit test for function safe_eval
def test_safe_eval():
    assert False


# Generated at 2022-06-25 12:33:57.861456
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'atoi'
    try:
        var_0 = safe_eval(str_0)
    except Exception as e:
        # print(e)
        pass
    else:
        print("Exception not raised")
        sys.exit(1)
    str_1 = '1'
    var_1 = safe_eval(str_1)
    str_2 = 'x=1'
    try:
        var_2 = safe_eval(str_2)
    except Exception as e:
        # print(e)
        pass
    else:
        print("Exception not raised")
        sys.exit(1)


if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:34:06.679254
# Unit test for function safe_eval
def test_safe_eval():
    # Convert the expected output to a string to make it easier to read
    str_safe_eval = container_to_text(test_case_0())

    # Print the 2 strings for comparison
    print("%s\n%s\n" % (test_case_0(), str_safe_eval))

    # Return the result of the test case
    return test_case_0() == str_safe_eval

if __name__ == '__main__':
    if not test_safe_eval():
        sys.exit(1)

# Generated at 2022-06-25 12:34:15.907676
# Unit test for function safe_eval
def test_safe_eval():
    global CALL_ENABLED
    CALL_ENABLED = []
    CALL_ENABLED.append('bool')
    var_0 = safe_eval('(1 < 2) and (4 > 3) or (5 * (4 % 3))', {'unicorn': 'horse'}, True)
    assert var_0[0] == True, "safe_eval returned (%s) instead of (%s)" % (var_0[0], True)
    var_1 = safe_eval('(1 < 2) and (4 > 3) or (x * (4 % 3))', {'x': -4, 'unicorn': 'horse'}, True)
    assert var_1[0] == 16, "safe_eval returned (%s) instead of (%s)" % (var_1[0], 16)

# Generated at 2022-06-25 12:34:22.337056
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:25.697323
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'n*w'
    var_0 = safe_eval(str_0)



# Generated at 2022-06-25 12:34:26.700099
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:34:36.664534
# Unit test for function safe_eval
def test_safe_eval():
    passed = True
    var_0 = safe_eval('false', dict(false=False))
    if var_0 is not False:
        passed = False
    var_1 = safe_eval('true', dict(true=True))
    if var_1 is not True:
        passed = False
    var_2 = safe_eval('none', dict(none=None))
    if var_2 is not None:
        passed = False
    var_3 = safe_eval('null', dict(null=None))
    if var_3 is not None:
        passed = False
    var_4 = safe_eval('int0', dict(int0=0))
    if var_4 is not 0:
        passed = False
    var_5 = safe_eval('int1', dict(int1=1))

# Generated at 2022-06-25 12:34:48.230990
# Unit test for function safe_eval
def test_safe_eval():

    test_case_0()

#   Test to see that a variable results in an exception
    str_0 = 'a'
    var_0 = safe_eval(str_0)

    if(var_0 == 'a'):
        print("Failed to catch simple variable")


#   Test to see that a variable with a number results in an exception
    str_0 = 'a1'
    var_0 = safe_eval(str_0)

    if(var_0 == 'a1'):
        print("Failed to catch variable with number")


#   Test to see that a variable with a underscore results in an exception
    str_0 = 'a_1'
    var_0 = safe_eval(str_0)


# Generated at 2022-06-25 12:34:59.145433
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'phYv3G'
    assert safe_eval(str_0) is str_0, "Expected: 'phYv3G', Actual: " + repr(safe_eval(str_0))

    str_1 = 'Y8W7dk3P'
    assert safe_eval(str_1) is str_1, "Expected: 'Y8W7dk3P', Actual: " + repr(safe_eval(str_1))

    str_2 = '7xuF5p'
    assert safe_eval(str_2) is str_2, "Expected: '7xuF5p', Actual: " + repr(safe_eval(str_2))

    str_3 = 'UW3qgP2x'

# Generated at 2022-06-25 12:35:07.138937
# Unit test for function safe_eval
def test_safe_eval():
    tup_0 = (1, 2, 3)
    assert safe_eval(tup_0) == tup_0
    str_0 = 'False'
    assert safe_eval(str_0) == False
    # Test the case where tup_0 is not a variable but a value,
    # and assert that the same value is returned.
    tup_1 = (1, 2, 3)
    assert safe_eval(tup_1) == tup_1
    tup_2 = (1, 2, 3)
    assert safe_eval(tup_2) == tup_2
    str_1 = 'False'
    assert safe_eval(str_1) == False
    # Test the case where tup_2 is not a variable but a value,
    # and assert that the same value is returned.


# Generated at 2022-06-25 12:35:16.271253
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[a, b, c]', {'a': 1, 'b': 2, 'c': 3}) == [1, 2, 3]
    assert safe_eval('foo', {'foo': 42}) == 42
    assert safe_eval('foo', {'bar': 42}) == 'foo'
    assert safe_eval('foo + 42', {'foo': 23}) == 65
    assert safe_eval('1 + 2') == 3
    assert safe_eval('2 * 3') == 6
    assert safe_eval("'a'.join('b')") == 'a'
    assert safe_eval("'a'+'b'") == 'ab'
    assert safe_eval("'%s' % 'ab'") == 'ab'
    assert safe_eval("'a' in 'ab'") is True
    assert safe_

# Generated at 2022-06-25 12:35:20.458560
# Unit test for function safe_eval
def test_safe_eval():
    test0 = test_case_0()


if __name__ == "__main__":
    if C.DEFAULT_DEBUG:
        test_safe_eval()
    else:
        # Test a simple addition dictionnary
        results = safe_eval('{"a": ["b", "c"], "d": "e"}')
        assert(dict, type(results))
        assert(results == {"a": ["b", "c"], "d": "e"})

        # Test a simple addition dictionnary
        # and add an exception
        results = safe_eval('{"a": ["b", "c"], "d": "e"}', include_exceptions=True)
        assert(dict, type(results[0]))
        assert(results[0] == {"a": ["b", "c"], "d": "e"})

# Generated at 2022-06-25 12:35:29.830867
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1: 2, 3: 4}') == {1: 2, 3: 4}
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('1 + 2') == (1 + 2)
    assert safe_eval('1 - 2') == (1 - 2)
    assert safe_eval('1 * 2') == (1 * 2)
    assert safe_eval('1 / 2')  # python3 returns float

# Generated at 2022-06-25 12:35:39.927196
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'Kv'
    var_0 = safe_eval(str_0)

    str_1 = 'hDtNb'
    var_1 = safe_eval(str_1)

    str_2 = 't2'
    var_2 = safe_eval(str_2)

    str_3 = 'n2'
    var_3 = safe_eval(str_3)

    str_4 = 'var_3 == var_2'
    var_4 = safe_eval(str_4)

    str_5 = 'var_1 == var_0'
    var_5 = safe_eval(str_5)

    str_6 = 'var_4 and var_5'
    var_6 = safe_eval(str_6)
    if (var_6):
        return -1



# Generated at 2022-06-25 12:35:48.623308
# Unit test for function safe_eval
def test_safe_eval():
    print()
    print('Testing function safe_eval')


# Generated at 2022-06-25 12:35:58.975914
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys
    import json

    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins


    # Define function 'safe_eval'

# Generated at 2022-06-25 12:36:00.123517
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:36:01.912766
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '5 * 7'
    var_0 = safe_eval(str_0)


# Generated at 2022-06-25 12:36:06.431307
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'phYv3G'
    var_0 = safe_eval(str_0)
    assert var_0 == 'phYv3G'
    
# Test for function test_case_0

# Generated at 2022-06-25 12:36:11.887894
# Unit test for function safe_eval
def test_safe_eval():
    print('Test case 0')
    test_case_0()
    print('Test case 1')
    test_case_1()
    print('Test case 2')
    test_case_2()
    print('Test case 3')
    test_case_3()
    print('Test case 4')
    test_case_4()
    print('Test case 5')
    test_case_5()
    print('Test case 6')
    test_case_6()
    print('Test case 7')
    test_case_7()
    print('Test case 8')
    test_case_8()
    print('Test case 9')
    test_case_9()
    print('Test case 10')
    test_case_10()
    print('Test case 11')
    test_case_11()
    print('Test case 12')

# Generated at 2022-06-25 12:36:12.579593
# Unit test for function safe_eval
def test_safe_eval():
    print("==== test safe_eval ====")
    test_case_0()

test_safe_eval()

# Generated at 2022-06-25 12:36:21.655154
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2+2') == 4
    assert safe_eval('2**2') == 4
    assert safe_eval('foo') is None        # missing 'foo'
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('foo(1, 2, 3)', dict(foo=lambda a, b, c: a+b+c)) == 6
    assert safe_eval('2 + 2') == 4
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a + b', dict(a=1, b=2)) == 3
    assert safe_eval('1 + 1') == 2

# Generated at 2022-06-25 12:36:23.352245
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() is not None


# Generated at 2022-06-25 12:36:32.404512
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    test_case_0()
    # Test case 1
    str_0 = 'True'
    var_0 = safe_eval(str_0)
    assert var_0 == True
    # Test case 2
    str_0 = 'input + 3'
    var_0 = safe_eval(str_0, locals={'input': 2})
    assert var_0 == 5
    # Test case 3
    str_0 = '1,2,3'
    var_0 = safe_eval(str_0)
    assert var_0 == (1, 2, 3)
    # Test case 4
    str_0 = '1,2,3'
    var_0 = safe_eval(str_0)
    assert var_0 == (1, 2, 3)
    # Test case 5
    str

# Generated at 2022-06-25 12:36:42.645566
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'sas'") == 'sas'
    assert safe_eval("['sa', 'sas']") == ['sa', 'sas']
    assert safe_eval("('sa', 'sas')") == ('sa', 'sas')
    assert safe_eval("{'a': 'sas'}") == {'a': 'sas'}
    assert safe_eval("0x12") == 0x12
    assert safe_eval("1e6") == 1e6
    assert safe_eval("2.3e-2") == 2.3e-2
    assert safe_eval("0b0110") == 6
    assert safe_eval("False") == False
    assert safe_eval("True") == True
    assert safe_eval("None") == None

# Generated at 2022-06-25 12:36:43.181130
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:36:43.828473
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:36:44.996420
# Unit test for function safe_eval
def test_safe_eval():
    print("TEST CASE 0")
    test_case_0()
    print(safe_eval("me: {% if something == 'other' %}nope{% else %}yes{% endif %}"))

# Generated at 2022-06-25 12:36:56.558656
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(True) == True
    assert safe_eval('True') == True
    assert safe_eval('a') == 'a'
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]
    assert safe_eval('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert safe_eval(dict(a=1, b=2)) == {'a': 1, 'b': 2}

    # Check error report
    try:
        safe_eval('foo(bar)')
    except Exception as e:
        assert 'foo' in str(e)

    # Check representation of None
    assert safe_eval('null') is None

    # Check variables

# Generated at 2022-06-25 12:37:01.896857
# Unit test for function safe_eval
def test_safe_eval():
    filename = 'data/argv.json'
    with open(filename) as f:
        for i,line in enumerate(f):
            result= safe_eval(line)
            print(result)
            break
    return

if __name__ == '__main__':
    # test_safe_eval()
    test_case_0()

# Generated at 2022-06-25 12:37:05.629213
# Unit test for function safe_eval
def test_safe_eval():
    expr = '"phYv3G"'

    # Call function safe_eval with appropriate arguments
    result = safe_eval(expr)

    # Check if the result obtained is equal to the expected result.
    assert result == 'phYv3G'


# Generated at 2022-06-25 12:37:16.092439
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('abc', dict(abc=dict(a='a'))) == dict(a='a')
    assert safe_eval('abc', dict(abc=dict(a='a')), True) == (dict(a='a'), None)
    assert safe_eval('abc', dict(abc=dict(a='a')), True)[0] == dict(a='a')
    assert safe_eval(None, dict(abc=dict(a='a'))) == None
    assert safe_eval(None, dict(abc=dict(a='a')), True) == (None, None)
    assert safe_eval(None, dict(abc=dict(a='a')), True)[0] == None
    assert safe_eval(['a'], dict(abc=dict(a='a'))) == ['a']

# Generated at 2022-06-25 12:37:23.988750
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('phYv3G') == 'phYv3G'
    assert safe_eval('2 + 3') == 5
    assert safe_eval('0.02') == 0.02
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('phYv3G', {}) == 'phYv3G'
    assert safe_eval('2 + 3', {}) == 5
    assert safe_eval('0.02', {}) == 0.02
    assert safe_eval('[1, 2, 3]', {}) == [1, 2, 3]

# Generated at 2022-06-25 12:37:33.586368
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'phYv3G'
    var_0 = safe_eval(str_0)
    str_1 = 'phYv3G'
    var_1 = safe_eval(str_1)
    str_2 = 'phYv3G'
    var_2 = safe_eval(str_2)
    str_3 = 'phYv3G'
    var_3 = safe_eval(str_3)
    str_4 = 'phYv3G'
    var_4 = safe_eval(str_4)
    str_5 = 'phYv3G'
    var_5 = safe_eval(str_5)
    str_6 = 'phYv3G'
    var_6 = safe_eval(str_6)

# Generated at 2022-06-25 12:37:34.912733
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(str_0)



# Generated at 2022-06-25 12:37:43.102819
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a', {'a': 'b'}) == 'b'
    assert safe_eval('a', {'a': 2}) == 2
    assert safe_eval('a', {'a': [1,2,3]}) == [1,2,3]
    assert safe_eval('a', {'a': {'a': 'b'}}) == {'a': 'b'}
    assert safe_eval('a', {'a': {'a': 'b'}}, include_exceptions=True) == ({'a': 'b'}, None)
    assert safe_eval('a', {'a': True}) == True
    assert safe_eval('a', {'a': False}) == False
    assert safe_eval('a', {'a': None})

# Generated at 2022-06-25 12:37:47.494132
# Unit test for function safe_eval
def test_safe_eval():
    # Test with string argument
    str_0 = 'phYv3G'
    var_0 = safe_eval(str_0)
    assert(var_0 == str_0)

    # Test with expression string argument
    str_1 = '1 + 1'
    var_1 = safe_eval(str_1)
    assert(var_1 == 2)

    # Test with expression list argument
    list_0 = ['1 + 1']
    var_2 = safe_eval(list_0)
    assert(var_2 == ['1 + 1'])


# Generated at 2022-06-25 12:37:52.762994
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure variables are created in the function
    global str_0, var_0
    str_0 = "phYv3G"
    var_0 = None
    var_0 = safe_eval(str_0)

    # Make sure variables are not accidentally shared between tests
    test_case_0()

    assert var_0 == str_0


# Generated at 2022-06-25 12:37:58.144308
# Unit test for function safe_eval
def test_safe_eval():
    print('')
    test_case_0()

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:38:00.173741
# Unit test for function safe_eval
def test_safe_eval():
    # Basic use case
    test_case_0()
    # Basic use case, with optional `include_exceptions` argument
    test_case_1()

# Basic use case, with optional `include_exceptions` argument

# Generated at 2022-06-25 12:38:10.538830
# Unit test for function safe_eval
def test_safe_eval():
    # Tests the scenario in which a string is passed as a parameter
    # to the safe_eval function.
    str_0 = 'a + b'
    assert safe_eval(str_0) == str_0
    str_1 = 'a + b == c'
    assert safe_eval(str_1) == str_1
    str_2 = '3'
    assert safe_eval(str_2) == 3
    str_3 = '3.333333'
    assert safe_eval(str_3) == 3.333333
    str_4 = 'False'
    assert safe_eval(str_4) == False
    str_5 = 'True'
    assert safe_eval(str_5) == True
    str_6 = 'True and False'
    assert safe_eval(str_6) == str_6


# Generated at 2022-06-25 12:38:18.951428
# Unit test for function safe_eval
def test_safe_eval():
    # Parse a Python string into an AST.
    # ast.parse("print('Selam')", mode='exec')
    # <_ast.Module object at 0x000002066E7A3F60>

    # Evaluate an expression node or a string containing a Python expression.
    # The expression may be a string, a bytes-like object or AST object.
    # globals and locals are dictionaries,
    # in the example below we are passing in empty dicts for both of them.
    # exec(compile("print('Selam')", filename="<string>", mode="exec"))

    # The ast.NodeVisitor is a base class for walking the abstract syntax
    # tree (AST) created from the code string.

    str_0 = 'a'
    var_0 = safe_eval(str_0)
    assert str_0

# Generated at 2022-06-25 12:38:27.353411
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'phYv3G'
    var_0 = safe_eval(str_0)
    assert type(var_0) == str
    assert var_0 == str_0

    with open('ansible/test/unit/module_utils/safe_eval_test.yml') as f:
        str_0 = f.read()
        var_0 = safe_eval(str_0)
        assert type(var_0) == str
        assert var_0 == str_0

    test_case_0()

# Generated at 2022-06-25 12:38:28.011565
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:38:38.000716
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '42'
    var_0 = safe_eval(str_0)
    assert var_0 == 42

    str_0 = '"42"'
    var_0 = safe_eval(str_0)
    assert var_0 == "42"
    # this returns an Exception object, which we don't care about in a unit test
    safe_eval('/nonexistent', include_exceptions=True)

    # before refactoring, we had to pass in locals=dict(hello='world'), so test that
    str_0 = '{{ hello }}'
    var_0 = safe_eval(str_0, locals=dict(hello='world'))
    assert var_0 == 'world'

    # test that a function argument does not get evaluated by safe_eval
    # by itself, which would introduce a security hole.


# Generated at 2022-06-25 12:38:38.831920
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == None

# Generated at 2022-06-25 12:38:46.835484
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    # For this test, we will be testing the 'safe_eval' function to evaluate
    # a string expression.
    # For this string expression, we will be testing the following:
    # - Name
    # - Add
    # - Subscript
    # - Compare
    str_exp = "a + b[0] == 1"
    # Set the local value for 'a' and 'b'. 
    local_vars = {"a": 1, "b": [1]}
    result = safe_eval(str_exp, locals=local_vars)
    assert result == True

    # Test case for 2nd test:
    # Test the following:
    # - Expression with 'list'
    # - Expression with 'tuple'
    # - Expression with 'dict'

# Generated at 2022-06-25 12:38:47.693581
# Unit test for function safe_eval
def test_safe_eval():

    test_case_0()

# Test whether function safe_eval raises exceptions correctly

# Generated at 2022-06-25 12:38:52.744204
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval')
    test_case_0()



# Generated at 2022-06-25 12:38:53.908519
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    #sys.exit(0)

# Generated at 2022-06-25 12:38:56.204131
# Unit test for function safe_eval
def test_safe_eval():
    # First test, called test_case_0, a string should be returned
    test_case_0()



# Generated at 2022-06-25 12:39:01.172144
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == 'phYv3G'

# Generated at 2022-06-25 12:39:09.094364
# Unit test for function safe_eval
def test_safe_eval():
    # Check whether the function is called
    try:
        safe_eval.__wrapped__('foo')
    except:
        assert False
    # Check return for non-string expression
    if safe_eval(False) != False:
        assert False
    if safe_eval(True) != True:
        assert False
    if safe_eval('True') != True:
        assert False
    if safe_eval('False') != False:
        assert False
    if safe_eval(1) != 1:
        assert False
    if safe_eval('1') != 1:
        assert False
    if safe_eval(1.02) != 1.02:
        assert False
    if safe_eval('1.02') != 1.02:
        assert False
    if safe_eval(0.0) != 0.0:
        assert False

# Generated at 2022-06-25 12:39:18.520062
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    str_1 = 'null'
    var_1 = safe_eval(str_1)
    assert str_1 == var_1
    str_2 = 'true'
    var_2 = safe_eval(str_2)
    assert str_2 == var_2
    str_3 = 'false'
    var_3 = safe_eval(str_3)
    assert str_3 == var_3
    str_4 = '0.0'
    var_4 = safe_eval(str_4)
    assert str_4 == var_4
    str_5 = '[]'
    var_5 = safe_eval(str_5)
    assert str_5 == var_5
    str_6 = '{}'
    var_6 = safe_eval(str_6)


# Generated at 2022-06-25 12:39:19.320231
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:39:25.275768
# Unit test for function safe_eval
def test_safe_eval():
    # Setup
    str_0 = 'Y'
    str_1 = 'w'
    str_2 = 'zrB\x7f0L'
    str_3 = 'it\x7f'
    str_4 = '|'
    str_5 = 'o'
    str_6 = '$$'
    str_7 = '$'
    str_8 = 'z\x7f'
    str_9 = 'g{$'
    str_10 = 'o'
    str_11 = 'y\x7f'
    str_12 = 'g'
    str_13 = 'g'
    str_14 = '`'
    str_15 = 'h'
    str_16 = 'l'
    str_17 = '`'
    str_18 = '`'
    str

# Generated at 2022-06-25 12:39:26.172020
# Unit test for function safe_eval
def test_safe_eval():
    cases = [
    test_case_0,
    ]
    return cases



# Generated at 2022-06-25 12:39:28.172223
# Unit test for function safe_eval
def test_safe_eval():

    print("---TESTING safe_eval()---")

    test_case_0()

if __name__ == '__main__':
    test_safe_eval()