

# Generated at 2022-06-25 12:29:41.359987
# Unit test for function safe_eval

# Generated at 2022-06-25 12:29:43.540858
# Unit test for function safe_eval
def test_safe_eval():
    v = safe_eval('1 + 1')
    assert v == 2



# Generated at 2022-06-25 12:29:50.234461
# Unit test for function safe_eval
def test_safe_eval():
    a_string = "{{ random_string }}"
    result = safe_eval(a_string)
    assert (isinstance(result, string_types))

    a_dict = "{ 'network': 'public' }"
    result = safe_eval(a_dict)
    assert (isinstance(result, dict))

    a_list = "[ 1, 2, 3, 4 ]"
    result = safe_eval(a_list)
    assert (isinstance(result, list))


# Generated at 2022-06-25 12:29:53.724462
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases
    test_case_0()


if __name__ == "__main__":
    # Unit tests
    test_safe_eval()
    sys.exit(0)

# Generated at 2022-06-25 12:29:55.080501
# Unit test for function safe_eval
def test_safe_eval():
    testcase_0 = test_case_0
    testcase_0()



# Generated at 2022-06-25 12:30:03.188853
# Unit test for function safe_eval
def test_safe_eval():
    # test_case_0
    bool_0 = False
    try:
        res_0 = safe_eval(bool_0)
    except Exception as e:
        print("Exception in test_case_0: %s" % str(e))
    else:
        print(res_0)

    # test_case_1
    string_0 = "True"
    try:
        res_1 = safe_eval(string_0)
    except Exception as e:
        print("Exception in test_case_1: %s" % str(e))
    else:
        print(res_1)

    # test_case_2
    num_0 = 9

# Generated at 2022-06-25 12:30:13.242011
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('5 * 20 * 2 + 10') == 110
    assert safe_eval('[1, 2, 3][0] + [1, 2, 3][2]') == 4
    assert safe_eval('[1, 2, 3] | length') == 3
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('3 + 2 - 5') == 0
    assert safe_eval('-7') == -7
    assert safe_eval('1 + "3"') == '13'
    assert safe_eval('-2**2') == -4
    assert safe_eval('1 + -1') == 0
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_

# Generated at 2022-06-25 12:30:21.971814
# Unit test for function safe_eval
def test_safe_eval():
    passed = True
    # TEST CASE 1
    # Call function safe_eval with arguments '1', and 'None' function returns value
    # '1'
    bool_1 = True
    var_1 = safe_eval('1', None)
    if not isinstance(var_1, int) or int(var_1) != 1:
        passed = False
    # TEST CASE 2
    # Call function safe_eval with arguments '1-1', and 'None' function returns
    # value '0'
    bool_2 = True
    var_2 = safe_eval('1-1', None)
    if not isinstance(var_2, int) or int(var_2) != 0:
        passed = False
    # TEST CASE 3
    # Call function safe_eval with arguments '1+1', and 'None' function returns
   

# Generated at 2022-06-25 12:30:33.014907
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval(False) == False)
    assert(safe_eval(True) == True)
    assert(safe_eval(None) == None)
    assert(safe_eval(1) == 1)
    assert(safe_eval(1.1) == 1.1)
    assert(isinstance(safe_eval("1.1"), float))
    assert(isinstance(safe_eval("1"), int))
    assert(isinstance(safe_eval("a"), str))
    assert(isinstance(safe_eval("\"a\""), str))
    assert(isinstance(safe_eval("\"\""), str))
    assert(isinstance(safe_eval("'a'"), str))
    assert(isinstance(safe_eval("''"), str))
    assert(isinstance(safe_eval("a"), str))

# Generated at 2022-06-25 12:30:43.566144
# Unit test for function safe_eval
def test_safe_eval():
    bool_1 = True
    float_0 = 1.23
    int_0 = 10
    int_1 = 0
    str_0 = 'this is a str'
    str_1 = 'one.two'
    str_2 = 'one two'
    tuple_1 = (1, 2, 3)

    # tests for safe_eval() with no errors
    result = safe_eval(bool_1)
    if not isinstance(result, bool):
        print('Wrong output')
    result = safe_eval(float_0)
    if not isinstance(result, float):
        print('Wrong output')
    result = safe_eval(int_0)
    if not isinstance(result, int):
        print('Wrong output')
    result = safe_eval(int_1)

# Generated at 2022-06-25 12:30:48.943343
# Unit test for function safe_eval
def test_safe_eval():
    v = safe_eval('A[B]')
    assert v == 'A[B]'
    v = 'A[B]'
    v = safe_eval(v)
    assert v == 'A[B]'


# Generated at 2022-06-25 12:30:57.510106
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('a') == 'a'
    assert safe_eval('a', dict(a=1)) == 1
    assert safe_eval('a', include_exceptions=True) == ('a', None)
    assert safe_eval('# this is a comment\n1') == 1
    assert safe_eval('# this is a comment\n1', include_exceptions=True) == (1, None)
    assert safe_eval('a', dict(a=1), include_exceptions=True) == (1, None)
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('{1: True}', include_exceptions=True) == ({1: True}, None)
    assert safe

# Generated at 2022-06-25 12:31:05.147092
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    var_0 = safe_eval(bool_0)
    var_1 = safe_eval('1+1')
    var_2 = safe_eval('a.b.c')
    var_3 = safe_eval('a+b')
    var_4 = safe_eval('a[0]')
    var_5 = safe_eval('bool_0')
    var_6 = safe_eval('a[b]')
    var_7 = safe_eval('a and b')
    var_8 = safe_eval('a or b')
    var_9 = safe_eval('1+1-1')
    var_10 = safe_eval('{0: "A", 1: "B"}')
    var_11 = safe_eval('{"a": 1, "b": 2}')
    var_

# Generated at 2022-06-25 12:31:11.020475
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] >= 3:
        assert safe_eval("True") is True
        assert safe_eval("False") is False
        assert safe_eval("None") is None
        assert safe_eval("'a_string'") is "a_string"
        assert safe_eval("[1, 2, 3]") == [1, 2, 3]
        assert safe_eval("1 + 2 + 3") == 6
        assert safe_eval("(1 + 2) * 3") == 9
        assert safe_eval("1.0 + 2.0") == 3.0
        assert safe_eval("[1, 2, 3] * 2") == [1, 2, 3, 1, 2, 3]

# Generated at 2022-06-25 12:31:20.979301
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    bool_1 = True
    float_0 = 3.14
    float_1 = 5.40
    float_2 = -8.58
    float_3 = 2.34
    float_4 = -2.21
    float_5 = 9.98
    float_6 = -2.00
    int_0 = 2
    int_1 = -10
    int_2 = -8
    int_3 = -10
    int_4 = 4
    int_5 = -3
    int_6 = -3
    int_7 = 6
    int_8 = -6
    int_9 = 8
    int_10 = -1
    int_11 = 0
    int_12 = -4
    int_13 = -9
    int_14 = 6

# Generated at 2022-06-25 12:31:27.903600
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = dict()
    test_cases[0] = dict()
    test_cases[0]['bool_0'] = False
    test_cases[0]['var_0'] = safe_eval(test_cases[0]['bool_0'])

    print(container_to_text(test_cases[0], format=C.DEFAULT_HASH_BEHAVIOUR))

    pass


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:31:37.901273
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo_var") == 'foo_var'
    assert safe_eval("foo_var.bar") == 'foo_var.bar'
    assert safe_eval("1 + 1") == 2
    assert safe_eval("{{ 1 + 1 }}") == "{{ 1 + 1 }}"
    assert safe_eval("{{ '1' + '1' }}") == "{{ '1' + '1' }}"
    assert safe_eval("{{ '1' + var }}", dict(var='1')) == "11"
    assert safe_eval("foo {{ foo | indented(width=bar, indent=1) }}", dict(foo='bar', bar=1)) == "foo bar"
    assert safe_eval("foo {{ foo | indented(width=bar, indent=2) }}", dict(foo='bar', bar=1))

# Generated at 2022-06-25 12:31:39.344451
# Unit test for function safe_eval
def test_safe_eval():
    ret_0 = safe_eval(True)
    return ret_0


# Generated at 2022-06-25 12:31:46.656211
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys

    #sys.path.append('/usr/lib/python2.6/site-packages/')
    #import pytest

    # Test safe_eval to see if the call is working correctly
    #  Invoke with a return value
    #  Invoke with a return value, no raised exception
    #  Invoke with a return value, with a raised exception
    #  Invoke with None as an argument
    #  Invoke with a tuple as an argument
    #  Invoke with a dict as an argument
    #  Invoke with a set as an argument
    #  Invoke with a list as an argument
    #  Invoke with a string as an argument
    #  Invoke with int as an argument
    #  Invoke with a long as an argument
    #  Invoke with a float as an argument
   

# Generated at 2022-06-25 12:31:57.742098
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    bool_1 = True
    float_0 = 0.01
    float_1 = 1.0
    int_0 = 0  
    int_1 = -1
    int_2 = 1
    str_0 = "123"
    var_0 = { "key_0": "value_0", "key_1": "value_1", "key_2": "value_2"}
    var_1 = {"key_0": {"key_0": "value_0", "key_1": "value_1", "key_2": "value_2"}}
    var_2 = [{"key_0": "value_0"}, {"key_0": "value_1"}, {"key_0": "value_2"}]
    var_3 = [1, 2, 3]

# Generated at 2022-06-25 12:32:06.303332
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '{"test":{{ random_string }}'
    str_2 = '{"test":{{ random_string }}'
    var_1 = safe_eval(str_1)
    var_2 = safe_eval(str_2)
    assert var_1 == str_1
    assert var_2 == str_2
    str_3 = '12345'
    var_3 = safe_eval(str_3)
    assert var_3 == int(str_3)


# Generated at 2022-06-25 12:32:17.377664
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}
    assert safe_eval(u'[1, 2, 3]') == [1,2,3]
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('30 - 1') == 29
    assert safe_eval('2 * 5') == 10
    assert safe_eval('6 / 3') == 2
    assert safe_eval('3 ** 2') == 9
    assert safe_eval('3 - (-2)') == 5
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('3 * 1 + 2') == 5

# Generated at 2022-06-25 12:32:26.676574
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:37.084661
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:44.928438
# Unit test for function safe_eval
def test_safe_eval():
    # Provide input for the parameter expr
    expr = '{{ random_string }}'
    assert safe_eval(expr) == '{{ random_string }}'

    # Provide input for the parameter locals
    locals = {}
    assert safe_eval(expr, locals, True) == ({'random_string': '{{ random_string }}'}, None)

    # Provide input for the parameter include_exceptions
    include_exceptions = False
    assert safe_eval(expr, locals, include_exceptions) == '{{ random_string }}'

    # Provide input for the parameter expr
    expr = "{'myvar': 'myvalue'}"
    assert safe_eval(expr) == {'myvar': 'myvalue'}

    # Provide input for the parameter locals
    locals = {}

# Generated at 2022-06-25 12:32:47.175078
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:32:57.552008
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval('{{ random_string }}') == '{{ random_string }}')
    assert(safe_eval("{{ random_string }}") == "{{ random_string }}")
    assert(safe_eval("{{ random_string | quote }}") == "{{ random_string | quote }}")
    assert(safe_eval("{{ [ random_string, range(1,5) ] }}") == "{{ [ random_string, range(1,5) ] }}")

    assert(safe_eval("{{ [ random_string, [1,2,3] ] }}") == "{{ [ random_string, [1,2,3] ] }}")
    assert(safe_eval('{{ [ range(1,5), "random_string" ] }}') == '{{ [ range(1,5), "random_string" ] }}')


# Generated at 2022-06-25 12:32:58.915233
# Unit test for function safe_eval
def test_safe_eval():
    assert False, 'test_safe_eval is not implemented'


# Generated at 2022-06-25 12:33:08.427189
# Unit test for function safe_eval
def test_safe_eval():
    assert isinstance(safe_eval('"{{ random_string }}"', locals=dict(random_string='value')), str), "safe eval with quotes"
    assert isinstance(safe_eval('[ "foo", "bar" ]'), list), "safe eval list"
    assert isinstance(safe_eval('{ "foo": "bar" }'), dict), "safe eval dict"
    assert safe_eval('"foo"', locals=dict(method='something')) == 'foo', "safe eval with locals"
    assert safe_eval('"foo"', locals=dict(method=dict(something='something'))) == 'foo', "safe eval dict with locals"
    assert isinstance(safe_eval('"foo"', locals=dict(method='something', random_string='value')), str), "safe eval with locals None"


# Generated at 2022-06-25 12:33:17.713300
# Unit test for function safe_eval
def test_safe_eval():
    # Jinja2 filters
    for x in ['default', 'int', 'bool', 'float', 'regex_replace', 'to_yaml', 'to_json', 'to_nice_json']:
        f = '{{ a | %s }}' % x
        try:
            safe_eval(f)
        except Exception as e:
            raise AssertionError('failed on %s: %s' % (f, to_native(e)))

    # C-style loop
    f = "{% for i in range(10) %} {{ i }} {% endfor %}"
    try:
        safe_eval(f)
    except Exception as e:
        raise AssertionError('failed on %s: %s' % (f, to_native(e)))

    # passing a list into ansible_variable

# Generated at 2022-06-25 12:33:22.522542
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:33:31.172831
# Unit test for function safe_eval
def test_safe_eval():
    # assert safe_eval('a, b', {'a':1, 'b':2}) == (1, 2)
    tstr = 'display.default("{{localhost}}")'
    assert safe_eval(tstr, {'localhost': '127.0.0.1'}, False) == '127.0.0.1'
    tstr = 'display.default({{localhost}})'
    assert safe_eval(tstr, {'localhost': '127.0.0.1'}, False) == '127.0.0.1'
    tstr = 'display.default({{localhost}})'
    assert safe_eval(tstr, {'localhost': '127.0.0.1'}, False) == '127.0.0.1'
    tstr = '{{localhost}}'

# Generated at 2022-06-25 12:33:37.291676
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:47.782777
# Unit test for function safe_eval
def test_safe_eval():
    # Valid expression, nothing else.
    str_0 = "foo"
    var_0 = safe_eval(str_0)
    assert str_0 == var_0

    # Global variables should not be available
    str_1 = "True"
    assert safe_eval(str_1)

    # None of these are allowed
    str_1 = 'list(range(0,10))'
    assert not safe_eval(str_1)

    # None of these are allowed
    str_2 = 'foo + randint(0,10)'
    assert not safe_eval(str_2)

    # None of these are allowed
    str_3 = '1 == 1 or 2 == 2'
    assert not safe_eval(str_3)

    # None of these are allowed
    str_4 = 'False'
    assert not safe

# Generated at 2022-06-25 12:33:57.037548
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{0, 1, 2}'
    s_var = safe_eval(str_0)
    if isinstance(s_var, set):
        print("test_safe_eval: test_0 passed")
    else:
        print("test_safe_eval: test_0 failed")

    str_1 = '{0: 1, 2: 3, 4: 5}'
    s_var = safe_eval(str_1)
    if isinstance(s_var, dict):
        print("test_safe_eval: test_1 passed")
    else:
        print("test_safe_eval: test_1 failed")

    str_2 = 'hello'
    s_var = safe_eval(str_2)

# Generated at 2022-06-25 12:34:08.844117
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate expression, but do not format output
    str_0 = '"{{ hello }}"'
    expr_0 = safe_eval(str_0)
    # Evaluate expression, but do not format output
    str_1 = '{{ some_dict.keys() }}'
    expr_1 = safe_eval(str_1)
    # Evaluate expression, but do not format output
    str_2 = '{{ random_string }}'
    expr_2 = safe_eval(str_2)
    # Evaluate expression, but do not format output
    str_3 = '{{ random_string }}'
    expr_3 = safe_eval(str_3)
    # Evaluate expression, but do not format output
    str_4 = '{{ random_string }}'
    expr_4 = safe_eval(str_4)
    #

# Generated at 2022-06-25 12:34:17.906720
# Unit test for function safe_eval
def test_safe_eval():
    # Testing '{{ random_string' }
    result, exception = safe_eval("{{ random_string", include_exceptions=True)
    assert result == "{{ random_string"
    assert exception is None

    # Testing '{{ jinja_var }}_with_a_suffix'
    result, exception = safe_eval("{{ jinja_var }}_with_a_suffix", include_exceptions=True)
    assert result == "{{ jinja_var }}_with_a_suffix"
    assert exception is None

    # Testing '{{ jinja_var + 1 }}'
    result, exception = safe_eval("{{ jinja_var + 1 }}", include_exceptions=True)
    assert result == "{{ jinja_var + 1 }}"
    assert exception is None

    # Testing '1'

# Generated at 2022-06-25 12:34:28.615083
# Unit test for function safe_eval

# Generated at 2022-06-25 12:34:38.090394
# Unit test for function safe_eval
def test_safe_eval():
    # list_0
    list_0 = [
        1,
        2.0,
        'three',
        {
            'key1': 'value1',
            'key2': 2.0
        }
    ]

    # test with various combinations of argv options
    # test 0
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{{ random_string }}', "%s != %s" % (var_0, '{{ random_string }}')

    # test 1
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{{ random_string }}', "%s != %s" % (var_0, '{{ random_string }}')

    #

# Generated at 2022-06-25 12:34:48.508659
# Unit test for function safe_eval
def test_safe_eval():
    assert sys.version_info[0] == 2
    # Test an empty string
    (result, exception) = safe_eval('', include_exceptions=True)
    assert result == ''
    assert exception is None

    # Test 'string'
    (result, exception) = safe_eval('string', include_exceptions=True)
    assert result == 'string'
    assert exception is None

    # Test 'string' on ansible v2.4
    (result, exception) = safe_eval('string', include_exceptions=True)
    assert result == 'string'
    assert exception is None

    # Test 'string' on ansible v2.5
    (result, exception) = safe_eval('string', include_exceptions=True)
    assert result == 'string'
    assert exception is None

    # Test 'string' on

# Generated at 2022-06-25 12:35:02.250105
# Unit test for function safe_eval
def test_safe_eval():

    # This test is intended to verify that the function safe_eval
    # returns a value, when given a string containing a dictionary
    # object and a list object
    result = safe_eval("{\"a\": 1, \"b\": [1, 2, 3]}")
    assert type(result) == dict
    assert result == {u'a': 1, u'b': [1, 2, 3]}



# Generated at 2022-06-25 12:35:11.450303
# Unit test for function safe_eval
def test_safe_eval():
    inp_0 = '{{ random_string }}'
    inp_1 = '{{ true }}'
    inp_2 = '{{ false }}'
    inp_3 = '{{ null }}'
    inp_4 = '{{ a.b.c }}'
    inp_5 = '{{ [ "a", "b", "c" ] }}'
    inp_6 = '{{ { "a": 1, "b": 2, "c": 3 } }}'
    inp_7 = '{{ random_string }}'
    inp_8 = '{{ random_string }}'
    inp_9 = '{{ random_string }}'
    inp_10 = '{{ random_string }}'
    inp_11 = '{{ random_string }}'
    inp_12 = '{{ random_string }}'


# Generated at 2022-06-25 12:35:15.027099
# Unit test for function safe_eval
def test_safe_eval():
    # Verify calling safe_eval with correct arguments does not raise exceptions
    try:
        constants.ANSIBLE_NOCOLOR = False
        safe_eval('')
    except:
        exception = sys.exc_info()[1]
        raise AssertionError('safe_eval raised "%s" when called with the correct arguments' % exception)


# Generated at 2022-06-25 12:35:15.490167
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:35:18.456030
# Unit test for function safe_eval
def test_safe_eval():
    ansible_utils_set_module_args({
        'expr': '{{ random_string }}'
    })
    cnt = safe_eval(module.params['expr'])
    if not cnt:
        ansible_utils_fail_json(msg='safe_eval did not evaluate the expression!')



# Generated at 2022-06-25 12:35:28.634445
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases
    # Basic test case
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)

    # Test case with math and var
    str_1 = '{{ var1 }}' + ' + ' + '{{ var2 }}'
    var_1 = safe_eval(str_1)

    # Test case with a more complicated expression
    str_2 = '{{ var1 }} + ({{ var2 }} - {{ var3 }})'
    var_2 = safe_eval(str_2)

    # Test case with a more complicated expression and a function call
    str_3 = '{{ var1 }} + ({{ var2 }} + {{ var3 }})|round(1)'
    var_3 = safe_eval(str_3)

    # Test case with a string variable
    str_

# Generated at 2022-06-25 12:35:32.028544
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0:
    # Test with a string literal

    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:35:42.685117
# Unit test for function safe_eval
def test_safe_eval():
    # container_to_text() is tested in unit test under test/unit/module_utils/common/text/converters.py

    # dict
    dict_input = "{'a': 1, 'b': 2}"

    (result, exception_type) = safe_eval(dict_input, include_exceptions=True)
    assert(result == {'a': 1, 'b': 2}, "Expected {'a': 1, 'b': 2}, got %s" % result)
    assert(exception_type is None, "Expected exception_type is None, got %s" % exception_type)

    # str
    str_input = "result"

    (result, exception_type) = safe_eval(str_input, include_exceptions=True)

# Generated at 2022-06-25 12:35:51.665129
# Unit test for function safe_eval
def test_safe_eval():
    # Check type of safe_eval output
    str_0 = '{{ random_string }}'
    assert (type(safe_eval(str_0)) is str), 'The output of safe_eval should be of type str'

    # Check output of safe_eval when the expression cannot be evaluated
    str_1 = '{{ random_string|something() }}'
    assert (safe_eval(str_1) == str_1), 'The output of safe_eval should be the string itself'

    # Check output of safe_eval when we try to call a forbidden function
    str_2 = '{{ random_string|__import__() }}'
    assert (safe_eval(str_2) == str_2), 'The output of safe_eval should be the string itself'

    # Check output of safe_eval when the expression can be evaluated

# Generated at 2022-06-25 12:36:01.872473
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + disabled_function(2)') == '1 + disabled_function(2)'
    assert safe_eval('1 + disabled_function(2)', include_exceptions=True)[0] == '1 + disabled_function(2)'
    assert isinstance(safe_eval('1 + disabled_function(2)', include_exceptions=True)[1], Exception)
    assert safe_eval('"some_string_with_numbers_123"') == 'some_string_with_numbers_123'

# Generated at 2022-06-25 12:36:21.936797
# Unit test for function safe_eval
def test_safe_eval():

    # Test cases for safe_eval
    if 0 == test_case_0():
        print('Test case 0 for safe_eval failed')
        sys.exit(1)
    print('Test cases for function safe_eval passed')
    sys.exit(0)


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:36:31.783943
# Unit test for function safe_eval
def test_safe_eval():
    assert True == safe_eval(True)
    assert False == safe_eval(False)

    assert '123' == safe_eval('123')
    assert '1.23' == safe_eval('1.23')
    assert '-123' == safe_eval('-123')

    assert 'abc' == safe_eval('abc')
    assert 'abc' == safe_eval('"abc"')
    assert "'abc'" == safe_eval("'abc'")

    assert '"abc"' == safe_eval('"\\"abc\\""')

    assert True == safe_eval('true')
    assert True == safe_eval('True')
    assert True == safe_eval('TRUE')
    assert False == safe_eval('false')
    assert False == safe_eval('False')
    assert False == safe_eval('FALSE')


# Generated at 2022-06-25 12:36:42.019129
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'sys.modules'
    str_1 = 'sys'
    str_2 = 'ast'
    str_3 = '1+1'
    str_4 = 'len([1,2,3])'
    str_5 = '1 == 1'
    str_6 = '{"a": 1, "b": 2}'
    str_7 = '1.0/3.0'
    str_8 = '5*5'
    str_9 = '1 + 2 * 3 +4'
    str_10 = '1 + 2 * (3 + 4)'
    str_11 = '1 + 2 * (3 + 4) / 2'
    str_12 = '1 + 2 * (3 + 4) + 8 / 2'

# Generated at 2022-06-25 12:36:49.561904
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)

    assert isinstance(var_0, str)

    str_1 = '{{ random_string }}'
    var_1 = safe_eval(str_1, include_exceptions=True)

    assert isinstance(var_1[0], str)
    assert var_1[1] is None

    str_2 = '{{ random_string|to_json }}'
    var_2 = safe_eval(str_2)

    assert isinstance(var_2, str)

    str_3 = '{{ random_string|to_json }}'
    var_3 = safe_eval(str_3, include_exceptions=True)

    assert isinstance(var_3[0], str)

# Generated at 2022-06-25 12:36:51.881910
# Unit test for function safe_eval
def test_safe_eval():
    # ensure that this function is actually run as part of
    # the functional tests of the base module.
    assert C.DEFAULT_MODULE_UTILS == 'ansible.module_utils.basic'

# Generated at 2022-06-25 12:37:01.897724
# Unit test for function safe_eval
def test_safe_eval():
    # TODO
    # There is a failure to match input message: str_0.
    # It seems that test message can not be a list/tuple.
    # Rewrite test case to avoid list/tuple, since the test case is single file.
    test_cases = [
        {
            'input': ['foo', (), {}],
            'expected_output': 'foo'
        },
        {
            'input': [('foo', 'bar', 'baz'), (), {}],
            'expected_output': 'foo',
            'expect_exception': TypeError
        },
        {
            'input': ['{{ random_string }}', ()]
        }
    ]

    for case in test_cases:
        args = case.get('input', None)

# Generated at 2022-06-25 12:37:12.383479
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_native
    assert safe_eval("1") == 1
    assert safe_eval("1+2") == 3
    assert safe_eval("a_list_variable", dict(a_list_variable=[1,2,3])) == [1,2,3]
    assert safe_eval("a_dict_variable", dict(a_dict_variable={'a':1,'b':2,'c':3})) == {'a':1,'b':2,'c':3}
    assert safe_eval("a_dict_variable['a']", dict(a_dict_variable={'a':1,'b':2,'c':3})) == 1

# Generated at 2022-06-25 12:37:21.490251
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{{ random_string }}'

    str_1 = '{{ [1, 2, 3] }}'
    var_1 = safe_eval(str_1)
    assert var_1 == '{{ [1, 2, 3] }}'

    str_2 = "{{ 'foo' }}"
    var_2 = safe_eval(str_2)
    assert var_2 == "{{ 'foo' }}"

    str_3 = "{{ ansible_default_ipv4['address'] }}"
    var_3 = safe_eval(str_3)
    assert var_3 == "{{ ansible_default_ipv4['address'] }}"


# Generated at 2022-06-25 12:37:32.320743
# Unit test for function safe_eval
def test_safe_eval():

    print("Testing safe_eval:")

    results = safe_eval('42')
    assert results == 42
    results = safe_eval('42 + 42')
    assert results == 84
    results = safe_eval('"A String"')
    assert results == "A String"
    results = safe_eval('["A", "List"]')
    assert results == ["A", "List"]
    results = safe_eval('{"A": "Dict"}')
    assert results == {"A": "Dict"}
    results = safe_eval('-0')
    assert results == -0
    results = safe_eval('{"string": "1", "int": 1}')
    assert results == {"string": "1", "int": 1}
    results = safe_eval('[]')
    assert results == []

# Generated at 2022-06-25 12:37:34.872401
# Unit test for function safe_eval
def test_safe_eval():

    print("Hello from safe_eval!")

    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:38:16.778902
# Unit test for function safe_eval
def test_safe_eval():
    actual = safe_eval('[1,2,3]')
    expected = [1, 2, 3]
    assert actual == expected
    actual = safe_eval('[1,2,"3"]')
    expected = [1, 2, "3"]
    assert actual == expected
    actual = safe_eval('{1:"1", 2:"2"}')
    expected = {1: "1", 2: "2"}
    assert actual == expected
    actual = safe_eval('{"1":"1","2":"2"}')
    expected = {"1": "1", "2": "2"}
    assert actual == expected

# Test for invalid expression

# Generated at 2022-06-25 12:38:18.402942
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{{ random_string }}'
    assert(safe_eval(str_0) != str_0)



# Generated at 2022-06-25 12:38:20.712765
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing function safe_eval")
    test_case_0()



# Generated at 2022-06-25 12:38:22.142517
# Unit test for function safe_eval
def test_safe_eval():
    """Unit tests for function safe_eval."""
    test_case_0()



# Generated at 2022-06-25 12:38:30.751775
# Unit test for function safe_eval
def test_safe_eval():
    # W0511: Used when a warning note as FIXME or XXX is detected
    # pylint: disable=W0511
    # R0201: Method could be a function
    # pylint: disable=R0201

    # String
    result_0 = safe_eval('Hello Ansible')
    assert result_0 == 'Hello Ansible'

    # Integer
    result_1 = safe_eval('42')
    assert result_1 == 42

    # Dict
    result_2 = safe_eval('{ "test": 42 }')
    assert result_2 == { 'test': 42 }

    # Variable
    result_3 = safe_eval('{{ foo }}')
    assert result_3 == '{{ foo }}'

    # String
    result_0 = safe_eval('Hello Ansible')

# Generated at 2022-06-25 12:38:40.396731
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for safe_eval
    '''
    assert 'str' == type(safe_eval('/path/to/some/file')).__name__
    assert 'str' == type(safe_eval('/path/to/some/file', include_exceptions=True)[0]).__name__
    assert 'NoneType' == type(safe_eval('/path/to/some/file', include_exceptions=True)[1]).__name__
    assert 'bool' == type(safe_eval('True')).__name__
    assert 'list' == type(safe_eval('[1,2,3]')).__name__
    assert 'tuple' == type(safe_eval('(1,2,3)')).__name__

# Generated at 2022-06-25 12:38:48.282972
# Unit test for function safe_eval
def test_safe_eval():

    # Check the return type of the safe evaluation of a constant
    assert type(safe_eval('"foo"')) is str
    assert type(safe_eval(2)) is int
    assert type(safe_eval(2.5)) is float
    assert type(safe_eval('{"foo": 1}')) is dict
    assert type(safe_eval('true')) is bool
    assert type(safe_eval('false')) is bool

    # Check the return type of the safe evaluation of a variable
    assert type(safe_eval('foo', {'foo': True})) is bool

    # Check the return type of the safe evaluation of a function
    assert type(safe_eval('foo()', {'foo': lambda: 1})) is int

    # Check the return type of the safe evaluation of a string concatenation

# Generated at 2022-06-25 12:38:57.935138
# Unit test for function safe_eval
def test_safe_eval():
    # example code to test the function
    # pass
    str_0 = '{{ x }}'
    var_0 = safe_eval(str_0)
    # pass
    str_0 = '{{ 1 + 2 }}'
    var_0 = safe_eval(str_0)
    # pass
    str_0 = '{{ [1, 2] }}'
    var_0 = safe_eval(str_0)
    # pass
    str_0 = '{{ [1, 2] | map("int") }}'
    var_0 = safe_eval(str_0)
    # pass
    str_0 = '{{ random_string }}'
    var_0 = safe_eval(str_0)
    # fail
    str_0 = '{{ x | map("int") }}'
    var_0 = safe_eval

# Generated at 2022-06-25 12:39:00.423413
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-25 12:39:08.452601
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2 + 3") == 5
    assert safe_eval("'a'") == 'a'
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval("{'name': 'John'}") == {'name': 'John'}
    assert safe_eval("{'name': 'John', 'address': {'city': 'NY', 'zipcode': 888}}") == {'name': 'John', 'address': {'city': 'NY', 'zipcode': 888}}
    assert safe_eval("'abcd' * 2") == 'abcdabcd'
    assert safe_eval("2 * 2") == 4
    assert safe_eval("'abc' in ['cba', 'abc']") == True