

# Generated at 2022-06-25 12:29:40.103758
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'l,v-w5<80(t'
    set_0 = {
        'dJ': 'AZ]',
        '#': '+1'
    }
    str_0 = 'C,v-w5<80(t'
    safe_eval(str_1, set_0)
    result_0 = safe_eval(str_0, set_0) == 98.0
    assert result_0



# Generated at 2022-06-25 12:29:50.233715
# Unit test for function safe_eval
def test_safe_eval():
    # Tests the following cases:
    # test_case_0
    # test_case_1
    # test_case_2
    # test_case_3
    # test_case_4
    # test_case_5
    # test_case_6
    # test_case_7
    # test_case_8
    # test_case_9
    # test_case_10
    # test_case_11
    # test_case_12
    # test_case_13
    # test_case_14
    # test_case_15
    # test_case_16
    # test_case_17
    # test_case_18
    # test_case_19
    test_case_0()
    str_0 = 'K9Q]Nz!*;0,Wl'
    str

# Generated at 2022-06-25 12:29:52.597171
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except:
        print("Exception caught in safe_eval")


# Generated at 2022-06-25 12:30:02.137285
# Unit test for function safe_eval
def test_safe_eval():
    # Test #0
    str_0 = 'cJ,A*;?slgU'
    bool_0 = True
    result = safe_eval(str_0, bool_0)
    assert isinstance(str_0, str), "Expected an instance of %s, got %s" % (str, type(str_0))
    assert isinstance(bool_0, bool), "Expected an instance of %s, got %s" % (bool, type(bool_0))
    assert isinstance(result, str), "Expected an instance of %s, got %s" % (str, type(result))
    assert result == 'cJ,A*;?slgU', "Expected %s, got %s" % ('cJ,A*;?slgU', result)

    # Test #1
    str_

# Generated at 2022-06-25 12:30:11.727286
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for bareword expressions
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("-1.0") == -1.0
    assert safe_eval("'Test'") == 'Test'
    assert safe_eval('"Test"') == 'Test'
    assert safe_eval("'Singles\\' Quotes'") == 'Singles\' Quotes'
    assert safe_eval('"Doubles\\\\ Quotes"') == 'Doubles\\ Quotes'

    # Tests for string expressions
    assert safe_eval("'1'") == '1'
    assert safe_eval("'-1'") == '-1'
    assert safe_eval("'1.0'") == '1.0'
   

# Generated at 2022-06-25 12:30:14.155118
# Unit test for function safe_eval
def test_safe_eval():
    # This test fails because it is not using EvalContext
    # as described in issue #35482.
    # test_case_0()
    pass


# Generated at 2022-06-25 12:30:18.511038
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('a') == 'a'
    assert safe_eval('1 + 2') == 3
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": 2}') == {'a': 2}


# Generated at 2022-06-25 12:30:31.278749
# Unit test for function safe_eval
def test_safe_eval():
    # 7
    str_0 = 'cJ,A*;?slgU'
    bool_0 = True
    var_0 = safe_eval(str_0, bool_0)
    # 8
    str_1 = 'bY.F|uKj'
    str_2 = 'bY.F|uKj'
    var_1 = safe_eval(str_1, str_2)
    # 8
    str_3 = 'sHZTK{TWn'
    str_4 = 'sHZTK{TWn'
    var_2 = safe_eval(str_3, str_4)
    # 8
    str_5 = 'X@qjO*h$ayAK'
    int_0 = 3

# Generated at 2022-06-25 12:30:39.321248
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "`\x89"",\x01\x8f\xdfk\x88\xb4\xff\xf0\x8f\x02\x9e\x1f\xff\xfb\xb3\xfe\xe6\x8c\x93\x04\x89\x07\x8b\x93\x01\x88\x02\xe8\x8f\x06\x98\x1c\x1f\xff\xfb\xb3\xfe\xe7\x8d\x93\x05\x89\x03\x8b\x93\x01\x88\x08\xe8\x8f\x06\x98\x1c\x1f\xff\xfb"

# Generated at 2022-06-25 12:30:48.865429
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_KEEP_REMOTE_FILES is not 0:
        data_type_0 = type(C.DEFAULT_KEEP_REMOTE_FILES)
    else:
        data_type_0 = not 0
    assert data_type_0 == type(0), 'AssertionError: %s != %s' % (type(0), data_type_0)

    if C.DEFAULT_KEEP_REMOTE_FILES is not 0:
        data_type_1 = type(C.DEFAULT_KEEP_REMOTE_FILES)
    else:
        data_type_1 = not 0
    assert data_type_1 == type(0), 'AssertionError: %s != %s' % (type(0), data_type_1)


# Generated at 2022-06-25 12:30:57.089862
# Unit test for function safe_eval
def test_safe_eval():
    # No exception if the string is a valid expression
    try:
        test_case_0()
    except TypeError:
        # Expected exception
        if sys.exc_info()[0] != TypeError:
            raise
    except Exception:
        if sys.exc_info()[0] != TypeError:
            raise


SUCCESS = 0
FAILURE = 1

# For more information about this function, see _eval_statements()

# Generated at 2022-06-25 12:30:59.825788
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Note: this requires that the json module is installed.  It's a new requirement
# on Python 2.6, though.

# Generated at 2022-06-25 12:31:07.447274
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'foo'
    var_0 = safe_eval(str_0)
    assert var_0 == 'foo'
    str_1 = '"bar"'
    var_1 = safe_eval(str_1)
    assert var_1 == 'bar'
    str_2 = '"baz"'
    var_2 = safe_eval(str_2)
    assert var_2 == 'baz'
    str_3 = '1'
    var_3 = safe_eval(str_3)
    assert var_3 == 1
    str_4 = 'true'
    var_4 = safe_eval(str_4)
    assert var_4 == True
    str_5 = 'true'
    var_5 = safe_eval(str_5)
    assert var_5 == True
    str_

# Generated at 2022-06-25 12:31:17.211764
# Unit test for function safe_eval
def test_safe_eval():
    passed = True

    # Test case 3
    str_1 = 'True'
    str_2 = 'False'
    str_3 = 'None'
    str_4 = '1'
    str_5 = '16'
    str_6 = '1.6'
    str_7 = "-1"
    str_8 = '-11.6'
    str_9 = '- -1'
    str_10 = '"String"'
    str_11 = '["a","b","c"]'
    str_12 = '("a","b","c")'
    str_13 = '("a","b","c")'
    str_14 = '("a","b","c")'
    str_15 = '("a","b","c")'
    str_16 = '("a","b","c")'


# Generated at 2022-06-25 12:31:25.391178
# Unit test for function safe_eval
def test_safe_eval():
    # str_0 = "{{ hostvars[inventory_hostname]['ansible_default_ipv4']['address'] }}"
    str_0 = "2 * 3 + 4 * 5"
    var_0 = safe_eval(str_0)
    print(var_0)
    # str_1 = '{{ hostvars[inventory_hostname]["ansible_default_ipv4"]["address"] }}'
    # str_1 = 'hostvars_ansible_default_ipv4_address'
    # var_1 = safe_eval(str_1)
    # print(var_1)
    # str_2 = '{{ hostvars[inventory_hostname]["ansible_default_ipv4"]["address"] }}'
    # str_2 = 'hostvars_ansible

# Generated at 2022-06-25 12:31:26.265329
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:31:32.601473
# Unit test for function safe_eval
def test_safe_eval():
    # str_0 = "{{ lookup('template', './templates/show_int_brief.j2') }}"
    # var_0 = safe_eval(str_0)
    test_case_0()
    # print("safe eval: " + var_0)


if __name__ == '__main__':
    sys.exit(test_safe_eval())

# Generated at 2022-06-25 12:31:41.727885
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '"+a"'
    var_0 = safe_eval(str_0)

    str_1 = '"a+b"'
    var_1 = safe_eval(str_1)

    str_2 = '"a+b"'
    var_2 = safe_eval(str_2)

    str_3 = '"+a"'
    var_3 = safe_eval(str_3)

    str_4 = '"+a"'
    var_4 = safe_eval(str_4)

    str_5 = '"+a"'
    var_5 = safe_eval(str_5)

    str_6 = '"+a"'
    var_6 = safe_eval(str_6)

    str_7 = '"+a"'

# Generated at 2022-06-25 12:31:42.702912
# Unit test for function safe_eval
def test_safe_eval():
    # case 0: ppp
    test_case_0()



# Generated at 2022-06-25 12:31:48.474327
# Unit test for function safe_eval
def test_safe_eval():
    import stringdist
    from random import choice
    from random import randint
    from random import random
    from random import shuffle
    from random import uniform
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    str_1 = 'true'
    var_1 = safe_eval(str_1)
    str_2 = 'ppp'
    var_2 = safe_eval(str_2)
    str_3 = 'ppp'
    var_3 = safe_eval(str_3)
    str_4 = 'ppp'
    var_4 = safe_eval(str_4)
    str_5 = 'ppp'
    var_5 = safe_eval(str_5)
    str_6 = 'ppp'

# Generated at 2022-06-25 12:32:02.144271
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('4') == 4
    assert safe_eval('2 + 3') == 5
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{1, 2, 3}') == {1, 2, 3}

    # Make sure we can evaluate dicts
    assert safe_eval('{\"foo\":\"bar\"}') == {'foo': 'bar'}

    # Make sure we can evaluate list of lists
    assert safe_eval('[[1, 2], [3, 4]]') == [[1, 2], [3, 4]]

    # Make sure we can evaluate dict of lists

# Generated at 2022-06-25 12:32:12.894920
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ppp'
    var_1 = safe_eval(str_0)
    assert var_1 == 'ppp'
    str_1 = '2*2'
    var_2 = safe_eval(str_1)
    assert var_2 == 4
    str_2 = '"abc"'
    var_3 = safe_eval(str_2)
    assert var_3 == 'abc'
    str_3 = "'abc'"
    var_4 = safe_eval(str_3)
    assert var_4 == 'abc'
    str_4 = '2 > 1'
    var_5 = safe_eval(str_4)
    assert var_5 == True
    str_5 = '1 > 2'
    var_6 = safe_eval(str_5)

# Generated at 2022-06-25 12:32:20.395688
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '1111'
    var_1 = safe_eval(str_1)
    assert var_1 == 1111
    str_2 = '1111 + 1'
    var_2 = safe_eval(str_2)
    assert var_2 == 1112
    str_3 = '1 + 2 - 3'
    var_3 = safe_eval(str_3)
    assert var_3 == 0
    str_4 = '3 - 4 - 5'
    var_4 = safe_eval(str_4)
    assert var_4 == -6
    str_5 = '1 + 2 * 3'
    var_5 = safe_eval(str_5)
    assert var_5 == 7
    str_6 = '(1 + 2) * 3'
    var_6 = safe_eval(str_6)

# Generated at 2022-06-25 12:32:28.666588
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:30.468182
# Unit test for function safe_eval
def test_safe_eval():
    for i in range(0, 10):
        test_case_0()
    print('All unit tests passed!')

# Generated at 2022-06-25 12:32:33.884184
# Unit test for function safe_eval
def test_safe_eval():
    '''test_safe_eval()'''
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)

    # check that it is safe (by design we cannot check if the output is correct)
    # assert var_0 == 'ppp'
    # check the safe eval
    assert isinstance(var_0, str)



# Generated at 2022-06-25 12:32:41.910820
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing 'safe_eval' function for valid input")
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == 'ppp'
    str_1 = 'ppp.bbb'
    var_1 = safe_eval(str_1)
    assert var_1 == 'ppp.bbb'
    str_2 = "'ppp'"
    var_2 = safe_eval(str_2)
    assert var_2 == 'ppp'
    str_3 = "'ppp.bbb'"
    var_3 = safe_eval(str_3)
    assert var_3 == 'ppp.bbb'


# Generated at 2022-06-25 12:32:51.825345
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing function safe_eval')

    # Test #0
    print('  Test #0:', end='')
    try:
        test_case_0()
    except Exception:
        print('Exception caught:', sys.exc_info()[0])
        print('  Test #0 Failed')
        return

    print('  Test #0 Passed')

    print('  Test #1:', end='')
    str_1 = '''[safe_eval(x, locals={'x':22}, include_exceptions=True) for x in ['null', 'None', 'false', 'true']]'''
    var_1 = safe_eval(str_1)
    print('  Test #1 Passed')
    print('  Test #2:', end='')

# Generated at 2022-06-25 12:33:02.356609
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = '1'
    var_1 = safe_eval(str_1)
    print (var_1)

    str_2 = '1+1'
    var_2 = safe_eval(str_2)
    print (var_2)

    str_3 = '1+1 == 2'
    var_3 = safe_eval(str_3)
    print (var_3)

    str_4 = '1+1 == 2 and True'
    var_4 = safe_eval(str_4)
    print (var_4)

    str_5 = 'true and 1+1 == 2'
    var_5 = safe_eval(str_5)
    print (var_5)

    str_6 = 'a+b == 2'

# Generated at 2022-06-25 12:33:04.861171
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:33:14.248291
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    try:
        test_case_0()
        assert True
    except:
        assert False

# are_conditional

# Generated at 2022-06-25 12:33:23.212741
# Unit test for function safe_eval
def test_safe_eval():
    # Module needs to be tested separately, not using pytest
    if __name__ == '__main__':
        # Provide a string for us to evaluate.
        # This string will be evaluated as a python literal.
        # So if we want to evaluate the string 'False',
        #  we need to wrap it in quotes.
        # In the case of the string 'False', we want to evaluate
        #  what it means to be false, so we just pass in 'False'.
        # In the case of the string '"False"', we want to evaluate
        #  what it means to be the word 'False', so we pass in "'False'".
        string_to_evaluate = "'False'"
        
        # Call our function.
        # If there is no exception raised, then we are good.
        # If there is an exception raised, then we have an

# Generated at 2022-06-25 12:33:31.764369
# Unit test for function safe_eval
def test_safe_eval():

    # Case 0: The evaluated string is a string
    try:
        str_0 = 'ppp'
        var_0 = safe_eval(str_0)
        assert var_0 == 'ppp', "Case 0 failed after evaluating 'ppp'"
    except:
        print("Case 0 failed with 'ppp'")

    # Case 1: The evaluated string should be the value of the string
    try:
        str_1 = '"ppp"'
        var_1 = safe_eval(str_1)
        assert var_1 == 'ppp', "Case 1 failed after evaluating '\"ppp\"'"
    except:
        print("Case 1 failed with '\"ppp\"'")

    # Case 2: The evaluated string is an int

# Generated at 2022-06-25 12:33:36.344079
# Unit test for function safe_eval
def test_safe_eval():
    # Code for testing safe_eval
    # Tests for test_case_0:
    test_case_0_str_actual = safe_eval('ppp')
    test_case_0_str_expected = 'ppp'
    test_case_0_str_result = test_case_0_str_actual == test_case_0_str_expected
    test_case_0_int_actual = safe_eval('123')
    test_case_0_int_expected = 123
    test_case_0_int_result = test_case_0_int_actual == test_case_0_int_expected
    test_case_0_bool_false_actual = safe_eval('false')
    test_case_0_bool_false_expected = False
    test_case_0_bool_false_result = test_case

# Generated at 2022-06-25 12:33:47.702331
# Unit test for function safe_eval
def test_safe_eval():

    # Test with a valid expression
    expr = "1+1"
    ret = safe_eval(expr)
    assert ret == eval(expr)

    # Test with an invalid expression
    expr = "1+"
    ret = safe_eval(expr)
    assert ret == expr

    # Test with a valid element
    expr = "true"
    ret = safe_eval(expr)
    assert ret == True

    # Test with an invalid element
    expr = "True"
    ret = safe_eval(expr)
    assert ret == expr

    # Test with the expression with a call on function
    expr = "abs(-1)"
    ret = safe_eval(expr)
    assert ret == 1

    # Test with the expression with a call on function
    expr = "abs(1)"
    ret = safe_eval(expr)
   

# Generated at 2022-06-25 12:33:56.997752
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == "ppp"


if __name__ == '__main__':
    # test_safe_eval()
    test_case_0()
    # print(safe_eval('["asdfh","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hsgdfjh","jsdhgf","hs

# Generated at 2022-06-25 12:34:08.756285
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = 'hello, world'
    var_1 = safe_eval(var_0)
    assert var_0 == var_1
    var_0 = '{{ test1 }} and {{ test2 }}'
    var_1 = safe_eval(var_0)
    assert var_0 == var_1
    var_0 = ['{{ test1 }}', '{{ test2 }}']
    var_1 = safe_eval(var_0)
    assert var_0 == var_1
    var_0 = ('{{ test1 }}', '{{ test2 }}')
    var_1 = safe_eval(var_0)
    assert var_0 == var_1

# Generated at 2022-06-25 12:34:13.445105
# Unit test for function safe_eval
def test_safe_eval():
    # Write code here to test safe_eval
    # Change this variable as needed
    expected = None
    actual = safe_eval("test")

    if actual != expected:
        print("safe_eval test failed, expected: " + str(expected) + ", actual: " + str(actual))
    else:
        print("safe_eval test passed!")


# Generated at 2022-06-25 12:34:19.492819
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval function')
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    str_1 = 'ppp'
    var_1 = safe_eval(str_1)
    assert str_0 == str_1
    assert var_0 == var_1
    assert str(var_0) == str(var_1)
    str_2 = 'True'
    str_3 = 'False'
    assert bool(safe_eval(str_2)) == bool(safe_eval(str_3))
    str_4 = 'None'
    assert safe_eval(str_4) is None
    str_5 = 'true'
    str_6 = 'false'
    assert bool(safe_eval(str_5)) == bool(safe_eval(str_6))

# Generated at 2022-06-25 12:34:31.110068
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("None") == None
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("1") == 1
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 + 2 + 3") == 6
    assert safe_eval("true and true") == True
    assert safe_eval("true and false") == False
    assert safe_eval("true or false") == True
    assert safe_eval("true or false or true") == True
    assert safe_eval("true == true") == True
    assert safe_eval("true == false") == False
    assert safe_eval("true != true") == False
    assert safe_eval("true != false") == True
    assert safe_eval("1 != 1") == False

# Generated at 2022-06-25 12:34:40.695502
# Unit test for function safe_eval
def test_safe_eval():
    print("test_case_0")
    test_case_0()

test_safe_eval()

# Generated at 2022-06-25 12:34:42.661306
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'hello'
    var_0 = safe_eval(str_0)
    assert var_0 == 'hello'


# Generated at 2022-06-25 12:34:48.652274
# Unit test for function safe_eval
def test_safe_eval():
    # Input parameters
    str_0 = 'ppp'

    # Output
    var_0 = safe_eval(str_0)

    # Assert
    # Assert safe_eval(str_0)

    # Assert str_0
    str_0 = str_0

    # Assert var_0
    var_0 = var_0
    assert var_0 == 'ppp', "Expected: ppp, Actual: %s" % (var_0,)

	

# Generated at 2022-06-25 12:34:52.445948
# Unit test for function safe_eval
def test_safe_eval():
    # s = '["a","b"]'
    # s = "['a','b']"
    s = "['a', 'b', 'c']"
    t = safe_eval(s)
    print(t)
    print(type(t))
    print(dir(t))

    assert(str(t) == "['a', 'b', 'c']")
    assert(type(t) == list)



# Generated at 2022-06-25 12:35:02.135320
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'ppp'
    var_1 = safe_eval(str_1)
    print(var_1)
    print(type(var_1))

    str_2 = 'http'
    var_2 = safe_eval(str_2)
    print(var_2)
    print(type(var_2))

    str_3 = 'http == 80'
    var_3 = safe_eval(str_3)
    print(var_3)
    print(type(var_3))

    str_4 = '3*2 - 3'
    var_4 = safe_eval(str_4)
    print(var_4)
    print(type(var_4))


# Generated at 2022-06-25 12:35:11.450334
# Unit test for function safe_eval
def test_safe_eval():
    print("TESTING SAFE EVAL")
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    if var_0 == 'ppp':
        print(" - eval: %s == 'ppp' Success" % var_0)
    else:
        print(" - eval: %s == 'ppp' Failed" % var_0)
        sys.exit(1)

    str_1 = 'a_list_variable'
    var_1 = safe_eval(str_1)
    if var_1 == 'a_list_variable':
        print(" - eval: %s == 'a_list_variable' Success" % var_1)
    else:
        print(" - eval: %s == 'a_list_variable' Failed" % var_1)

# Generated at 2022-06-25 12:35:13.219561
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    print ('success')

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:35:20.215019
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', locals={'foo': 'bar'}) == 'bar'
    assert safe_eval('foo', locals={'foo': True}) is True

    # test that the 'call' rule works:
    assert safe_eval('foo.get("bar", "baz")', locals={'foo': {'bar': 'blerg'}}) == 'blerg'
    assert safe_eval('len(foo)', locals={'foo': [1, 2]}) == 2

# Generated at 2022-06-25 12:35:29.496570
# Unit test for function safe_eval
def test_safe_eval():

    # exp_0 = ['string', 'list']
    exp_0 = 'string'
    str_0 = '["string", "list"]'
    var_0 = safe_eval(str_0)
    assert(var_0 == exp_0)

    # exp_1 = ['string', 'list']
    exp_1 = 'string'
    str_1 = "['string', 'list']"
    var_1 = safe_eval(str_1)
    assert(var_1 == exp_1)

    # exp_2 = ['string', 'list']
    exp_2 = 'string'
    str_2 = "['string', 'list']"
    var_2 = safe_eval(str_2)
    assert(var_2 == exp_2)

    # exp_3 = ['string', 'list']


# Generated at 2022-06-25 12:35:39.687343
# Unit test for function safe_eval
def test_safe_eval():

    # Test case 0
    str_0 = "{{ VAR | to_json }}"
    result_0 = safe_eval(str_0)
    assert isinstance(result_0, string_types)
    assert result_0 == "{{ VAR | to_json }}"

    # Test case 1
    str_1 = "{{ VAR }}"
    result_1 = safe_eval(str_1)
    assert isinstance(result_1, string_types)
    assert result_1 == "{{ VAR }}"

    # Test case 2
    str_2 = ""
    result_2 = safe_eval(str_2)
    assert isinstance(result_2, string_types)
    assert result_2 == ""

    # Test case 3
    str_3 = "{{ VAR | join(', ') }}"


# Generated at 2022-06-25 12:35:56.933397
# Unit test for function safe_eval
def test_safe_eval():
    num_1 = 1
    var_1 = safe_eval(num_1)
    assert var_1 == num_1

    num_2 = 2
    var_2 = safe_eval(num_2)
    assert var_2 == num_2

    str_3 = 'ppp'
    var_3 = safe_eval(str_3)
    assert var_3 == str_3

    str_4 = 'ppp'
    var_4 = safe_eval(str_4)
    assert var_4 == str_4

    dict_5 = dict(key_0=0, key_1=1, key_2=2)
    var_5 = safe_eval(dict_5)
    assert var_5 == dict_5


# Generated at 2022-06-25 12:36:06.581359
# Unit test for function safe_eval
def test_safe_eval():
    s = "a.b.c"
    d = {"a" : {"b" : {"c" : "1"}}}
    assert(safe_eval(s, variables=d) == "1")

    s = "[1, 2, 3]"
    assert(safe_eval(s) == [1, 2, 3])

    s = "foo"
    assert(safe_eval(s) == "foo")

    s = "True"
    assert(safe_eval(s) == True)

    s = "null"
    assert(safe_eval(s) == None)

    s = "[a, b, c]"
    d = {"a" : 1, "b" : 2, "c" : 3}
    assert(safe_eval(s, variables=d) == [1, 2, 3])


# Generated at 2022-06-25 12:36:10.004874
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = str('var_1')
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    var_2 = ast.NodeVisitor()
    var_3 = str('var_3')
    var_4 = callable()
    var_2 = ast.NodeVisitor()
    var_3 = str('var_3')
    var_4 = callable()


# Generated at 2022-06-25 12:36:19.267484
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "1"
    var_0 = safe_eval(str_0)
    assert var_0 == 1

    str_1 = "1+2"
    var_1 = safe_eval(str_1)
    assert var_1 == 3

    str_2 = "1+2*3-4"
    var_2 = safe_eval(str_2)
    assert var_2 == 3

    str_3 = "True"
    var_3 = safe_eval(str_3)
    assert var_3 is True

    str_4 = "False"
    var_4 = safe_eval(str_4)
    assert var_4 is False

    str_5 = "None"
    var_5 = safe_eval(str_5)
    assert var_5 is None


# Generated at 2022-06-25 12:36:22.596636
# Unit test for function safe_eval
def test_safe_eval():
    string = '1 + 1'
    expected = 2
    actual = safe_eval(string)
    assert actual == expected
    try:
        string = '1 + "1"'
        actual = safe_eval(string)
        assert False
    except:
        assert True


# Generated at 2022-06-25 12:36:32.329161
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('p') == 'p'
    assert safe_eval('ppp') == 'ppp'
    assert safe_eval('True') is True
    assert safe_eval('true') is True
    assert safe_eval('False') is False
    assert safe_eval('false') is False
    assert safe_eval('None') is None
    assert safe_eval('null') is None
    assert safe_eval('10') == 10
    assert safe_eval('-10') == -10
    assert safe_eval('10 + 20') == 30
    assert safe_eval('-10 + 20') == 10
    assert safe_eval('10 - 20') == -10
    assert safe_eval('10.0 -20.0') == -10.0
    assert safe_eval('10 / 2') == 5

# Generated at 2022-06-25 12:36:36.685493
# Unit test for function safe_eval
def test_safe_eval():
    print("TESTING safe_eval")
    global str_0
    test_case_0()
    assert str_0 == 'ppp', "Expected ppp, got %s" % str_0
    print("SUCCESS: safe_eval")



# Generated at 2022-06-25 12:36:45.916682
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0: Name
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)

# Generated at 2022-06-25 12:36:52.849176
# Unit test for function safe_eval
def test_safe_eval():
    try:
        str_1 = 'asdf'
        # Important! We need to make sure that our custom exception is being
        # propogated when its used in a context which does not require
        # include_exceptions to be True
        var_1 = safe_eval(str_1)
    except Exception as e:
        assert isinstance(e, Exception)

    str_2 = '1+1'
    var_2 = safe_eval(str_2)
    assert var_2 == 2

    str_3 = 'True'
    var_3 = safe_eval(str_3)
    assert var_3 is True

    str_4 = 'false'
    var_4 = safe_eval(str_4)
    assert var_4 is False

    str_5 = 'null'
    var_5 = safe_eval

# Generated at 2022-06-25 12:36:59.094320
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test for safe_eval()
    """
    # [0]: variable-like evaluation
    test_str_0 = 'ppp'
    assert safe_eval(test_str_0) == 'ppp'
    assert isinstance(safe_eval(test_str_0), (str, bool, type(None)))
    # [1]: dict-like evaluation
    test_str_1 = "{'a': 1, 'b': 2}"
    assert safe_eval(test_str_1) == {'a': 1, 'b': 2}
    assert isinstance(safe_eval(test_str_1), dict)
    # [2]: list-like evaluation
    test_str_2 = "['a', 'b']"
    assert safe_eval(test_str_2) == ['a', 'b']
   

# Generated at 2022-06-25 12:37:19.998758
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '{"a": "b"}'
    var_0 = safe_eval(str_0)
    assert var_0 == {"a": "b"}

    str_0 = "'asdf'"
    var_0 = safe_eval(str_0)
    assert var_0 == "asdf"

    str_0 = "'asdf', 'zxcv'"
    var_0 = safe_eval(str_0)
    assert var_0 == ("asdf", "zxcv")

    str_0 = "foobar"
    var_0 = safe_eval(str_0)
    assert var_0 == "foobar"

    str_0 = "foobar"
    var_0 = safe_eval(str_0)
    assert var_0 == "foobar"
    # str_0 = "['

# Generated at 2022-06-25 12:37:30.790830
# Unit test for function safe_eval
def test_safe_eval():
    # make sure we can process some simple items
    for x in ('1', '1+2', 'foo.bar()', 'foo[1]'):
        assert safe_eval(x) == eval(x)

    # make sure we can handle some simple math
    for x in ('1+1', '1 - 1', '1*1', '1 / 1', '(1 + 1) / 2'):
        assert safe_eval(x) == eval(x)

    # make sure we fail on the stuff we should fail on
    for x in ('1+1; foo()', 'open("/etc/passwd")', '1+1\nfoo()', 'dict(1=1)', 'dict["foo"]'):
        try:
            safe_eval(x)
            # should have failed
            assert False
        except:
            pass



# Generated at 2022-06-25 12:37:40.532428
# Unit test for function safe_eval
def test_safe_eval():
    # UNIT TEST BEGIN
    # Below is some basic tests, to use as a guide. Pay attention to the
    # number of spaces in front of the line. To make it easier to remove
    # or add tests, they are all indented equally. They are all indented
    # so that they can easily be selected as a block to comment out or
    # comment in.
    #
    # These tests are provided as a guide for the new unit test, but
    # please modify the tests for each function for your own use case.

    # TEST safe_eval
    # test 0
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == 'ppp'

    # test 1
    str_1 = '4 * 5'
    var_1 = safe_eval(str_1)

# Generated at 2022-06-25 12:37:43.136343
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print('Error: ' + e.message)
    else:
        print('Pass')

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:53.227771
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'true'
    var_0 = safe_eval(str_0)
    assert var_0 == True

    str_1 = 'false'
    var_1 = safe_eval(str_1)
    assert var_1 == False

    str_2 = "1==1"
    var_2 = safe_eval(str_2)
    assert var_2 == True

    str_3 = "1==2"
    var_3 = safe_eval(str_3)
    assert var_3 == False

    str_4 = "1=='1'"
    var_4 = safe_eval(str_4)
    assert var_4 == True

    dict_0 = {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-25 12:37:54.367273
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:37:59.280017
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(str) == str



# Generated at 2022-06-25 12:38:06.819829
# Unit test for function safe_eval
def test_safe_eval():

    # Test for a string with a single quote
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)

    # Test for a string with a single quote
    str_0 = 'pp\'p'
    var_0 = safe_eval(str_0)

    # Test for a string with a double qoute
    str_0 = 'pp\"p'
    var_0 = safe_eval(str_0)

    # Test for a string with a backslash
    str_0 = 'pp\\p'
    var_0 = safe_eval(str_0)

    # Test for an empty string
    str_0 = ''
    var_0 = safe_eval(str_0)

    # Test for a single quoted string with a single quote
    str_0 = '\'ppp\''


# Generated at 2022-06-25 12:38:14.002448
# Unit test for function safe_eval
def test_safe_eval():
    try:
        if C.DEFAULT_DEBUG:
            print("\n***** BEGIN TESTING: safe eval *****")
            print("Test Case 0:")

        test_case_0()
        print("Test Case 0: Passed")

    except:
        print("***** TESTING FAILED *****")
        raise

    finally:
        if C.DEFAULT_DEBUG:
            print("***** END TESTING: safe eval *****\n")



# Generated at 2022-06-25 12:38:26.514811
# Unit test for function safe_eval
def test_safe_eval():
    # Test 0
    # {
    #     template: 'ppp'
    #     var: safe_eval(template)
    # }
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == 'ppp', "safe_eval() returned unexpected value (0)"

    # Test 1
    # {
    #     template: '{{ var_1 | to_native }}'
    #     var: safe_eval(template)
    # }
    str_1 = '{{ var_1 | to_native }}'
    var_1 = safe_eval(str_1)
    assert var_1 == '{{ var_1 | to_native }}', "safe_eval() returned unexpected value (1)"

    # Test 2
    # {
    #     template: 'True

# Generated at 2022-06-25 12:38:38.634365
# Unit test for function safe_eval
def test_safe_eval():
    #'''
    #Unit test for function safe_eval
    #'''
    print("running unit test for safe_eval")
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:38:44.813856
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == 'ppp'

    str_1 = 'ppp'
    var_1 = safe_eval(str_1)
    assert var_1 == 'ppp'

    str_2 = 'ppp'
    var_2 = safe_eval(str_2)
    assert var_2 == 'ppp'

    str_3 = 'ppp'
    var_3 = safe_eval(str_3)
    assert var_3 == 'ppp'


# Generated at 2022-06-25 12:38:47.664564
# Unit test for function safe_eval
def test_safe_eval():
    print('In test_safe_eval')
    try:
        test_case_0()
    except Exception as e:
        print('Exception: %s' % str(e))
        sys.exit(1)


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:38:57.129490
# Unit test for function safe_eval

# Generated at 2022-06-25 12:39:01.112682
# Unit test for function safe_eval
def test_safe_eval():
    print ("Test safe_eval():")
    try:
        test_case_0()
    except Exception as e:
        print (e)
        raise
    else:
        print ("Test Passed")


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:39:03.490906
# Unit test for function safe_eval
def test_safe_eval():
    # Expression to test
    expr = 'a = 5'

    # Check if expr is safe
    assert safe_eval(expr, None, True)[0] != expr, 'Expression not safe'



# Generated at 2022-06-25 12:39:10.978971
# Unit test for function safe_eval

# Generated at 2022-06-25 12:39:11.715388
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Main function

# Generated at 2022-06-25 12:39:20.517053
# Unit test for function safe_eval
def test_safe_eval():

    # Test 0
    str_0 = 'ppp'
    var_0 = safe_eval(str_0)
    assert var_0 == "ppp"

    # Test 1
    #str_1 = 'a*b'
    #var_1 = safe_eval(str_1)
    #assert var_1 == None

    # Test 2
    str_2 = 'a+b'
    var_2 = safe_eval(str_2)
    assert var_2 == "a+b"

    # Test 3
    str_3 = 'a,b'
    var_3 = safe_eval(str_3)
    assert var_3 == "a,b"

    # Test 4
    str_4 = 'aaa,bbb'
    var_4 = safe_eval(str_4)
    assert var

# Generated at 2022-06-25 12:39:21.737876
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    test_case_0()
