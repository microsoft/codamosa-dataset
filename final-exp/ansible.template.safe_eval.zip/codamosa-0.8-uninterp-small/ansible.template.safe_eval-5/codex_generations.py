

# Generated at 2022-06-25 12:29:44.194061
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")

# Generated at 2022-06-25 12:29:55.265275
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function

    :return:
    '''
    # Test with string data type and check the return type is safely evaluated

    str_0 = 't'
    var_0 = safe_eval(str_0)
    if sys.version_info.major == 3:
        assert isinstance(var_0, str)
    else:
        assert isinstance(var_0, unicode)
    assert var_0 == 't'

    # Check the return type is unsafe when function is not in safe_nodes
    str_1 = 't.replace("t","tt")'
    var_1 = safe_eval(str_1)
    assert isinstance(var_1, str)
    if sys.version_info.major == 3:
        assert var_1 == str_1

# Generated at 2022-06-25 12:29:56.554895
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() is None  # added to silence pyflakes warnings


# Generated at 2022-06-25 12:30:04.032729
# Unit test for function safe_eval
def test_safe_eval():
    e = safe_eval(b'a + b')
    assert e == 'a + b'

    e = safe_eval(b'a + b', dict(a=5, b=6))
    assert e == 11

    e = safe_eval(b'a + b', dict(a=5, b=6), include_exceptions=True)
    assert e[0] == 11
    assert e[1] is None

    e = safe_eval(b'a + 5', dict(a=5, b=6), include_exceptions=True)
    assert e[0] == 10
    assert e[1] is None

    e = safe_eval(b'a + 5', dict(b=6), include_exceptions=True)
    assert e[0] == 'a + 5'

# Generated at 2022-06-25 12:30:14.502739
# Unit test for function safe_eval
def test_safe_eval():
    # bytes data
    byte_0 = b'V1ZQNjZzc0ZCMzY5YmM4bGp4Vjh4d0lTRVN3ejJZM3NhYzlLa0hGa3R5RzZ5VmF5Q2Nwdm5RbXJzWXZjQ2hyY2wwbA=='
    bytes_0 = base64.b64decode(byte_0)
    res_0 = safe_eval(bytes_0)
    assert res_0 == 'U6cgscFC369bc8ljxV8xwISTESwz2Y3saacK4HFktuG6yVayCcpvnQmrsYvcChrcp0l'

    # test with bytes

# Generated at 2022-06-25 12:30:22.599307
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'W'
    assert safe_eval(bytes_0) == 'W'
    bytes_1 = b'M\xdb\xd4\x1a\xd7\xd4\x1a\xd5\xeb\xcb\x1a\xda\xd4\x1a\xd6Q\x1a\x0c'
    assert safe_eval(bytes_1) == 'M\xdb\xd4\x1a\xd7\xd4\x1a\xd5\xeb\xcb\x1a\xda\xd4\x1a\xd6Q\x1a\x0c'

# Generated at 2022-06-25 12:30:33.656685
# Unit test for function safe_eval
def test_safe_eval():
    # ast.parse will fail when passed bytes on Python 2,
    # so use a text string instead
    bytes_0 = u'1 + 1'
    var_0 = safe_eval(bytes_0)
    assert var_0 == 2

    # Test that unsafe calls are disallowed
    bytes_1 = u'len(1)'
    var_1 = safe_eval(bytes_1)
    assert var_1 == u'len(1)'

    bytes_2 = u'isinstance(1)'
    var_2 = safe_eval(bytes_2)
    assert var_2 == u'isinstance(1)'

    bytes_3 = u'len(1)'
    var_3 = safe_eval(bytes_3, {'len': True})
    assert var_3 == u'len(1)'

    bytes_4 = u

# Generated at 2022-06-25 12:30:44.367737
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("1") == 1)
    assert(safe_eval("0o11") == 9)
    assert(safe_eval("0x11") == 17)
    assert(safe_eval("True") == True)
    assert(safe_eval("False") == False)
    assert(safe_eval("None") == None)
    assert(safe_eval("'abc'") == 'abc')
    assert(safe_eval("['abc', 'def']") == ['abc', 'def'])
    assert(safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'})
    assert(safe_eval("set(['a'])") == set(['a']))

# Generated at 2022-06-25 12:30:53.601423
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:59.333868
# Unit test for function safe_eval
def test_safe_eval():
    print("test with normal string")
    assert(safe_eval("ca'r") == "ca'r")
    print("test with a dangerous string")
    assert(safe_eval("__import__('os').system('echo hi')") == "__import__('os').system('echo hi')")
    print("test with an evaluable string")
    assert(safe_eval("'ca\'r'.capitalize()") == "Ca'r")
    print("test with an evaluable string that is dangerous")
    assert(
        safe_eval("'__import__(\'os\').system(\'echo hi\')'.upper()") == "'__IMPORT__('OS').SYSTEM('ECHO HI')'")

if __name__ == '__main__':
    test_case_0()
    test_safe_eval()

# Generated at 2022-06-25 12:31:10.621575
# Unit test for function safe_eval
def test_safe_eval():

    for test in ['{"test": { "test2": 1}}',
                 '{"test": {"test2": 1, "test3": "string"}}',
                 '{"test": {"test2": 1, "test3": "string"}}',
                 '[1, 2, "a", "b", "c"]',
                 '[1, 2, "a", "b", "c", {"test1": "test2"}, {"test2": "test3"}]',
                 ],:
        result = safe_eval(test)
        print(result)
        assert isinstance(result, dict) or isinstance(result, list)
        print("------")
        test2 = container_to_text(result, indent=2)
        print(test2)
        print("================================")
        result = ast.literal_eval(test2)
       

# Generated at 2022-06-25 12:31:20.641833
# Unit test for function safe_eval

# Generated at 2022-06-25 12:31:31.369852
# Unit test for function safe_eval
def test_safe_eval():
    s = "None"
    result = safe_eval(s)
    assert result == None, "Expected None, actual value: %s" % result

    s = "1"
    result = safe_eval(s)
    assert result == 1, "Expected 1, actual value: %s" % result

    s = "1.2"
    result = safe_eval(s)
    assert result == 1.2, "Expected 1.2, actual value: %s" % result

    s = "true"
    result = safe_eval(s)
    assert result == True, "Expected True, actual value: %s" % result

    s = "{}"
    result = safe_eval(s)
    assert result == {}, "Expected {}, actual value: %s" % result

    s = "[]"

# Generated at 2022-06-25 12:31:41.226013
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval with a list of safe expression
    tests = [
        '[ 1, 2, 3, 4, 5 ]',
        '{ "name": "test", "something": "else" }',
        'True',
        'False',
        'None',
    ]
    for test in tests:
        # Note: if the test fails, an exception will be raised
        result, exception = safe_eval(test, include_exceptions=True)
        if result == test:
            raise AssertionError('Unabled to evaluate %s' % test)
        if exception is not None:
            raise AssertionError('Unabled to evaluate %s, exception raised %s' % (test, exception))

    # test safe_eval with a list of unsafe expression

# Generated at 2022-06-25 12:31:54.186190
# Unit test for function safe_eval

# Generated at 2022-06-25 12:32:03.360375
# Unit test for function safe_eval
def test_safe_eval():

    # Test for basic math operations
    expr = '2 + 2'
    result = safe_eval(expr, locals=None)
    assert result == 4, "Expected result is %s , got %s" % (4, result)

    # Test for variables
    expr = 'x + y'
    result = safe_eval(expr, locals={'x':1, 'y':3})
    assert result == 4, "Expected result is %s , got %s" % (4, result)

    # Test for array
    expr = [1,2,3]
    result = safe_eval(expr, locals=None)
    assert result == [1,2,3], "Expected result is %s , got %s" % ([1,2,3], result)

    # Test for dictionary

# Generated at 2022-06-25 12:32:09.485792
# Unit test for function safe_eval
def test_safe_eval():
    #C.ANSIBLE_STRIP_EXTERNAL_KEYS = False
    expr = "['a', 'b', 'c']"
    l = {'a': 1, 'b': 2, 'c': 3}
    (result, error) = safe_eval(expr, l, True)
    if error:
        print("Error: %s" % repr(error))
    else:
        print("Result: %s" % repr(result))


# Generated at 2022-06-25 12:32:19.178089
# Unit test for function safe_eval
def test_safe_eval():
    # Check for integer, boolean
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('2 * 3') == 6
    assert safe_eval('1 == 1') is True
    assert safe_eval('1 != 1') is False
    assert safe_eval('1 >= 1') is True
    assert safe_eval('1 <= 1') is True
    assert safe_eval('a_list[1]') == 2
    assert safe_eval('a_list[1] + 1') == 3
    assert safe_eval('a_list[1] < 4') is True
    assert safe_eval('a_list[1] > 4') is False

# Generated at 2022-06-25 12:32:27.921370
# Unit test for function safe_eval
def test_safe_eval():
    test_val_str = 'str'
    test_val_number = 2
    test_val_list = ['a', 'b']
    test_val_dict = {'a': 'str', 'b': 'str'}

    # Test expressions of type str
    expr = '"%s"' % (test_val_str)
    # Test with different variable names - locals must contain variable
    for var_name in ('test', 'expression'):
        (result, exception) = safe_eval(expr, locals={var_name: test_val_str}, include_exceptions=True)
        assert result == test_val_str and not exception, \
            "Test failed for expression: %s, var name: %s" % (expr, var_name)
    # Test with different variable names - locals must not contain variable

# Generated at 2022-06-25 12:32:37.748920
# Unit test for function safe_eval
def test_safe_eval():
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    assert safe_eval(expr)
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    assert safe_eval(expr)
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 + 1'
    assert safe_eval(expr) == 2
   

# Generated at 2022-06-25 12:32:51.727105
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure list, dict, and string literals work with no overrides
    if safe_eval('[1, 2, 3]') != [1, 2, 3]:
        raise Exception("safe_eval failed")
    if safe_eval('[1, 2, a]', {'a': 3}) != [1, 2, 3]:
        raise Exception("safe_eval failed")
    if safe_eval('{ "foo": 1, "bar": a }', {'a': 2}) != {'foo': 1, 'bar': 2}:
        raise Exception("safe_eval failed")
    if safe_eval('a', {'a': 1}) != 1:
        raise Exception("safe_eval failed")
    if safe_eval('"a"') != 'a':
        raise Exception("safe_eval failed")

# Generated at 2022-06-25 12:32:53.747698
# Unit test for function safe_eval
def test_safe_eval():
    cases = []
    for case in cases:
        case()
    pass


# Generated at 2022-06-25 12:33:03.898213
# Unit test for function safe_eval
def test_safe_eval():
    # Simple expressions
    assert safe_eval("a + b", dict(a=1, b=1)) == 2
    assert safe_eval("a - b", dict(a=1, b=1)) == 0
    assert safe_eval("a * b", dict(a=2, b=3)) == 6
    assert safe_eval("a / b", dict(a=5, b=5)) == 1

    # List operations
    assert safe_eval("a[0]", dict(a=[0, 1, 2])) == 0
    assert safe_eval("a[0]", dict(a=('foo', 'bar'))) == 'foo'
    assert safe_eval("a[1:]", dict(a=[0, 1, 2])) == [1, 2]

    # TODO: Dict operations

# Generated at 2022-06-25 12:33:13.828026
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('5') == 5
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo is bar') == 'foo is bar'

    assert safe_eval('1+1') == 2
    assert safe_eval('[1+1]') == [2]
    assert safe_eval('[1+1] + [1+1]') == [2, 2]
    assert safe_eval('[1+1] + [1+1] + {"key": [1+1]}') == [2, 2, {"key": 2}]
    assert safe_eval('[1+1] + [1+1] + {"key": [1+1]}').__class__

# Generated at 2022-06-25 12:33:16.274274
# Unit test for function safe_eval
def test_safe_eval():
    expr = "False and True"

    expected = False

    result = safe_eval(expr)

    assert result == expected, 'Expected: %s, Received: %s' % (expected, result)



# Generated at 2022-06-25 12:33:28.085155
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a', {'a': 2}) == 2
    assert safe_eval('a', {'a': '2'}) == '2'
    assert safe_eval('a', {'a': '2'}, include_exceptions=True) == ('2', None)
    assert safe_eval('a.b', {'a': {'b': 'c'}}) == 'c'
    assert safe_eval('a.b()', {'a': {'b': lambda: 'c'}}) == 'c'
    assert safe_eval('a.b', {'a': {'b': lambda: 'c'}}) == '[object object]'
    assert safe_eval('a.b', {'a': {'b': 3}}) == 3

# Generated at 2022-06-25 12:33:34.312057
# Unit test for function safe_eval
def test_safe_eval():
    # simple tests
    assert safe_eval("a", locals={'a': 1}) == 1
    assert safe_eval("a", locals={'a': True}) == True
    assert safe_eval("a", locals={'a': True}) == 1
    assert safe_eval("a", locals={'a': 1}) == True
    assert safe_eval("a", locals={'a': True}) is True
    assert safe_eval("a", locals={'a': []}) == []
    assert safe_eval("a", locals={'a': {}}) == {}
    assert safe_eval("a", locals={'a': None}) == None
    assert safe_eval("a", locals={'a': {1: 2}}) == {1: 2}
    assert safe_eval("a", locals={'a': "test"}) == "test"

   

# Generated at 2022-06-25 12:33:45.913431
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:51.389621
# Unit test for function safe_eval

# Generated at 2022-06-25 12:33:59.603856
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    assert safe_eval('[1, true, false, null, "foo"]') == [1, True, False, None, 'foo']

    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1:2, 3:4}') == {1: 2, 3: 4}
    assert safe_eval('-3') == -3
    assert safe_eval('1 - 3') == -2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('True and False') is False
    assert safe_eval('True or False') is True
    assert safe_

# Generated at 2022-06-25 12:34:13.398172
# Unit test for function safe_eval
def test_safe_eval():
    # test with string input
    result = safe_eval('1 + 1')
    assert result == 2

    assert isinstance(safe_eval('[1+1]'), list)
    assert isinstance(safe_eval('{"foo": "bar"}'), dict)
    assert isinstance(safe_eval('{"foo": "bar"}["foo"]'), string_types)
    assert safe_eval('{"foo": "bar"}["foo"]') == "bar"
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert isinstance(safe_eval('{"foo": "bar"}'), dict)
    assert safe_eval('{"foo": "bar"}["foo"]') == "bar"
    assert safe

# Generated at 2022-06-25 12:34:19.050939
# Unit test for function safe_eval
def test_safe_eval():
    # test dict_to_sequence function
    assert safe_eval("{'a':'b'}", include_exceptions=True) == ({'a': 'b'}, None)
    assert safe_eval(" 1 ", include_exceptions=True) == (1, None)
    assert safe_eval("1+1", include_exceptions=True) == (2, None)
    assert safe_eval("1+1-1", include_exceptions=True) == (1, None)
    assert safe_eval("1+1-1*1", include_exceptions=True) == (1, None)
    assert safe_eval("1**1", include_exceptions=True) == (1, None)
    assert safe_eval("1^1", include_exceptions=True) == (0, None)

# Generated at 2022-06-25 12:34:30.413163
# Unit test for function safe_eval
def test_safe_eval():
    v = safe_eval('1 + 2')
    assert v == 3

    #v = safe_eval('import sys')
    #assert v == 'import sys'

    v = safe_eval('{"a": "b"}')
    assert v == {'a': 'b'}

    v = safe_eval('["a", "b"]')
    assert v == ['a', 'b']

    v = safe_eval('[a, b]', dict(a=2, b=3))
    assert v == [2, 3]

    v = safe_eval('2 + 3', include_exceptions=True)
    assert v == (5, None)

    v = safe_eval('{"a": "b"}', include_exceptions=True)
    assert v == ({'a': 'b'}, None)

    v = safe_

# Generated at 2022-06-25 12:34:39.140747
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[]") == []
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("1+2") == 3
    assert safe_eval("3-3") == 0
    assert safe_eval("'a' in 'b'") == False
    assert safe_eval("'a' in 'abc'") == True
    assert safe_eval("1 in [1,2,3]") == True
    assert safe_eval("'a' in ['a', 'b', 'c']") == True
    assert safe_eval("{'a':1} in [ { 'a': 1 } ]") == True

# Generated at 2022-06-25 12:34:48.685970
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing 'safe_eval' function")

# Generated at 2022-06-25 12:34:54.636117
# Unit test for function safe_eval
def test_safe_eval():

    # Tests for module_utils.common.text.converters.safe_eval

    # test: basic sanity check
    assert safe_eval('{"a": "test"}') == {'a': 'test'}
    assert safe_eval('["test", "test"]') == ['test', 'test']
    assert safe_eval('test') == 'test'

    # test: basic sanity check with string var passed in
    assert safe_eval('["test", "test", {{ test_var }}]', locals={'test_var': 'test'}) == ['test', 'test', 'test']

    # invalid expression
    assert safe_eval('["test", "test", {{ test_var }}]', include_exceptions=True)[0] == '["test", "test", {{ test_var }}]'
    # test: invalid expression
    assert safe_eval

# Generated at 2022-06-25 12:35:03.922697
# Unit test for function safe_eval
def test_safe_eval():
    # test case 1
    expr_1 = "{{ ansible_lsb.major_release }}"
    constants_1 = {'ansible_lsb':
                    {'minor_release': '3',
                     'release': '3.0.4-1.el6.ngx',
                     'major_release': '6',
                     'description': 'CentOS release 6.8 (Final)',
                     'id': 'centos'
                    }
                  }
    result_1 = safe_eval(expr_1, constants_1)
    assert result_1 == '6'

    # test case 2
    expr_2 = "{{ ansible_lsb.description }}"

# Generated at 2022-06-25 12:35:13.638949
# Unit test for function safe_eval
def test_safe_eval():
    # with_items: a_list_variable
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", locals=dict(foo="bar")) == "bar"
    assert safe_eval("foo.bar",
                     locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("foo.bar",
                     locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("foo.bar",
                     locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("foo.bar.baz.quux",
                     locals=dict(foo=dict(bar=dict(baz=dict(quux="whee"))))) == "whee"


# Generated at 2022-06-25 12:35:20.520623
# Unit test for function safe_eval
def test_safe_eval():
    x = 1
    y = 2

# Generated at 2022-06-25 12:35:29.973795
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:44.094482
# Unit test for function safe_eval
def test_safe_eval():
    # No exception should be raised, and a non-false result should be returned
    assert safe_eval([], include_exceptions=True) == ([], None)

    # No exception should be raised and False should be returned
    assert not safe_eval('false', include_exceptions=True)[0]

    # No exception should be raised and True should be returned
    assert safe_eval('true', include_exceptions=True)[0]

    # No exception should be raised, and a non-false result should be returned
    assert safe_eval({}, include_exceptions=True) == ({}, None)

    # No exception should be raised, and a non-false result should be returned
    assert safe_eval([1, 2, 3], include_exceptions=True) == ([1, 2, 3], None)

    # No exception should be raised, and a non-

# Generated at 2022-06-25 12:35:53.264730
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1') != 3

    # json boolean
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # json string
    assert safe_eval('"foo"') == 'foo'

    # list
    assert safe_eval('[1, 2]') == [1, 2]

    # tuple
    assert safe_eval('(1,)') == (1,)

    # dict
    assert safe_eval('{"test": true}') == {"test": True}

    # simple expression
    assert safe_eval('a + b', {'a': 1, 'b': 2}) == 3

    # localhost string

# Generated at 2022-06-25 12:36:03.544110
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:04.464167
# Unit test for function safe_eval
def test_safe_eval():
    data = '{"is_correct": True}'
    assert safe_eval(data) == {u'is_correct': True}


# Generated at 2022-06-25 12:36:09.975280
# Unit test for function safe_eval
def test_safe_eval():
    eval_result = safe_eval('1 + 1', dict(thousand=1000))
    assert eval_result == 2
    eval_result = safe_eval('thousand + 1')
    assert eval_result == 1001
    eval_result = safe_eval('1 / 2')
    assert eval_result == 0.5
    eval_result = safe_eval('a_list_variable')
    assert eval_result == 'a_list_variable'
    # safe_eval should not error if expression is already a list/dict
    eval_result = safe_eval(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'])

# Generated at 2022-06-25 12:36:19.227591
# Unit test for function safe_eval
def test_safe_eval():
    # Test different cases
    assert safe_eval(b'123') == 123
    assert safe_eval(b'None') is None
    assert safe_eval(b'True') is True
    assert safe_eval(b'False') is False
    assert safe_eval(b'[1,2,3]') == [1, 2, 3]
    assert safe_eval(b'[1,2,{}]') == [1, 2, {}]
    assert safe_eval(b'[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval(b'[1,2,3,4,5]') == [1, 2, 3, 4, 5]
    assert safe_eval(b'{"ansible": "cool"}') == {'ansible': 'cool'}
   

# Generated at 2022-06-25 12:36:26.092120
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(True, include_exceptions=True) == (True, None)
    assert safe_eval(False, include_exceptions=True) == (False, None)
    assert safe_eval(None, include_exceptions=True) == (None, None)
    assert safe_eval(3, include_exceptions=True) == (3, None)
    assert safe_eval(3.14, include_exceptions=True) == (3.14, None)
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('a', include_exceptions=True, locals=dict(a='b')) == ('b', None)

# Generated at 2022-06-25 12:36:28.831619
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval("[[1,2],[3,4,5]]")
    safe_eval("[1,2,3,4,5,6,7]")
    safe_eval("'hello'")



# Generated at 2022-06-25 12:36:38.116033
# Unit test for function safe_eval
def test_safe_eval():
    # Test various datatypes
    expr = u'{ "fetch" : { "src" : "some-file.txt", "dest" : "some-file.remote.txt" } }'
    data = safe_eval(expr)
    assert isinstance(data, dict)

    expr = u'{ "shell" : "echo some-string" }'
    data = safe_eval(expr)
    assert isinstance(data, dict)

    expr = u"1"
    data = safe_eval(expr)
    assert isinstance(data, int)
    assert data == 1

    expr = u'1.0'
    data = safe_eval(expr)
    assert isinstance(data, float)
    assert data == 1.0

    expr = u"1"
    data = safe_eval(expr)

# Generated at 2022-06-25 12:36:47.160824
# Unit test for function safe_eval
def test_safe_eval():
    print("--- TEST: safe_eval")
    if C.DEFAULT_DEBUG:
        sys.stderr.write("\n--- test_case_0: safe_eval")
    r0 = safe_eval("a_var")
    assert r0 == "a_var", r0
    if C.DEFAULT_DEBUG:
        sys.stderr.write("\n--- test_case_1: safe_eval")
    r1 = safe_eval("{{a_var}}")
    assert r1 == "{{a_var}}", r1
    if C.DEFAULT_DEBUG:
        sys.stderr.write("\n--- test_case_2: safe_eval")
    r2 = safe_eval("michael.dehaan")
    assert r2 == "michael.dehaan", r2
   

# Generated at 2022-06-25 12:37:04.477392
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('foo(1,2,3)') == 'foo(1,2,3)'
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', {'foo': 'bar'}) == 'bar'
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('["foo"]') == ['foo']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('[{"foo": "bar"}]') == [{'foo': 'bar'}]
    assert safe_eval('1') == 1

# Generated at 2022-06-25 12:37:14.964171
# Unit test for function safe_eval
def test_safe_eval():
    # This should work
    val, err = safe_eval("[1,2,3,4]")
    assert type(val) is list, 'Expected list type, got: %s' % type(val)
    # This should not work
    val, err = safe_eval("exec('rm -rf /')", include_exceptions=True)
    assert type(val) is str, 'Expected string type, got: %s' % type(val)
    assert type(err) is Exception
    if C.ANSIBLE_STRICT_TASK_NAMES:
        val, err = safe_eval("test cases", include_exceptions=True)
        assert type(val) is str, 'Expected string type, got: %s' % type(val)
        assert type(err) is Exception
    else:
        val,

# Generated at 2022-06-25 12:37:18.362564
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test that safe_eval passes the control over to Jinja2 template engine
    when we pass bytestring.
    '''

    bts = b'foo'
    ret = safe_eval(bts)
    assert ret == bts


# Generated at 2022-06-25 12:37:28.897866
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:36.459246
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:38.654540
# Unit test for function safe_eval
def test_safe_eval():
    # Example usage of safe_eval
    try:
        result = safe_eval('4 + x')
        assert result == 4
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:37:43.559249
# Unit test for function safe_eval
def test_safe_eval():
    failures = 0
    failures += _test_safe("1")
    failures += _test_safe("{ 'a': 'b' }")
    failures += _test_safe("[ 'a', 'b' ]")
    failures += _test_safe("not True")
    failures += _test_safe("True and False")
    failures += _test_unsafe("__import__('expat')")
    failures += _test_unsafe("a = open('/etc/passwd')")
    failures += _test_unsafe("__builtins__.open('/etc/passwd')")
    failures += _test_unsafe("[x for x in ['a'] if x is None]")

    # Issue #19455: safe_eval should allow creation of
    # complex numbers in Python 2.

# Generated at 2022-06-25 12:37:54.021619
# Unit test for function safe_eval
def test_safe_eval():
    # test_safe_eval:test_case_0
    bytes_0 = b'V1ZQNjZzc0ZCMzY5YmM4bGp4Vjh4d0lTRVN3ejJZM3NhYzlLa0hGa3R5RzZ5VmF5Q2Nwdm5RbXJzWXZjQ2hyY2wwbA=='
    assert safe_eval(bytes_0) == bytes_0
    # test_safe_eval:test_case_1

# Generated at 2022-06-25 12:38:06.221339
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure safe_eval works when the test string is non unicode
    test_string_1 = b'V1ZQNjZzc0ZCMzY5YmM4bGp4Vjh4d0lTRVN3ejJZM3NhYzlLa0hGa3R5RzZ5VmF5Q2Nwdm5RbXJzWXZjQ2hyY2wwbA=='
    result = safe_eval(test_string_1)
    assert result == test_string_1
    result = container_to_text(result)
    assert result == "WVP66sseBC369bcm8ljxV8xwISEStz2Y3saac9KkHFityG6yVayCcpmRaMrsvcChrcll"

# Generated at 2022-06-25 12:38:16.515058
# Unit test for function safe_eval

# Generated at 2022-06-25 12:38:32.724899
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("name", locals={"name":"Joe"})
    assert result == "Joe"
    try:
        result = safe_eval("int(1)")
        assert False
    except Exception as e:
        pass
    result = safe_eval("'string'")
    assert result == "string"
    try:
        result = safe_eval("'.join(1,2)")
        assert False
    except Exception as e:
        pass
    result = safe_eval("1 + 2")
    assert result == 3
    result = safe_eval("1 - 2")
    assert result == -1
    result = safe_eval("1 * 2")
    assert result == 2
    result = safe_eval("1 / 2")
    assert result == 0.5
    result = safe_eval("1.0 / 2")

# Generated at 2022-06-25 12:38:42.243633
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'V1ZQNjZzc0ZCMzY5YmM4bGp4Vjh4d0lTRVN3ejJZM3NhYzlLa0hGa3R5RzZ5VmF5Q2Nwdm5RbXJzWXZjQ2hyY2wwbA=='
    str_0 = u'WVP66gs0FC369bc8ljxV8xwISESwz2Y3saacKkHFktyG6yVayCcpmRmrsYvcChrcL0l'

# Generated at 2022-06-25 12:38:49.808216
# Unit test for function safe_eval
def test_safe_eval():
    ansible_version = sys.modules['ansible'].__version__
    if isinstance(ansible_version, bytes):
        # The following tests are for Ansible 1.9 only.
        # Once Ansible 2.0 is released, we can remove this section.
        most_of_opcodes = dict([(k,v) for k,v in sys.modules['ansible'].__builtin__.__dict__.iteritems() if not k.startswith('__')])
        most_of_opcodes['bytes'] = bytes

# Generated at 2022-06-25 12:38:59.101330
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("a_list_variable")
    assert isinstance(result, string_types)

    result = safe_eval("{{ [] | to_json }}")
    assert isinstance(result, list)

    result = safe_eval("{{ 1 + 2 }}")
    assert isinstance(result, int)
    assert result == 3

    result = safe_eval("{{ a + b }}", dict(a=1, b=2))
    assert isinstance(result, int)
    assert result == 3

    result = safe_eval("{{ [ a + b ] }}", dict(a=1, b=2))
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == 3

    # ensure builtin names are not available in the eval

# Generated at 2022-06-25 12:39:06.268532
# Unit test for function safe_eval
def test_safe_eval():
    # Test strings that evaluate without error
    # Test strings that evaluate without error
    assert safe_eval('True') == True
    assert safe_eval('name') == 'name'
    assert safe_eval('False') == False
    assert safe_eval('23') == 23
    assert safe_eval('23.0') == 23.0
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1)') == 1
    assert safe_eval('([1,2,3],4)') == ([1, 2, 3], 4)
    assert safe_eval('{"name":"joe"}') == {"name": "joe"}

# Generated at 2022-06-25 12:39:13.979510
# Unit test for function safe_eval

# Generated at 2022-06-25 12:39:18.855985
# Unit test for function safe_eval
def test_safe_eval():
    # Uncomment the following line if you want to test this code
    # return True

    (result, e) = safe_eval("4*4", include_exceptions=True)
    assert result == 16
    assert e is None

    (result, e) = safe_eval("a*b", include_exceptions=True, locals={'a': 1, 'b': 2})
    assert result == 2
    assert e is None

    (result, e) = safe_eval("a*b", include_exceptions=True, locals={'a': 1})
    assert result == "a*b"
    assert isinstance(e, NameError)


# Generated at 2022-06-25 12:39:24.777175
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test a few things
    '''

    # this will raise a safe_eval exception
    try:
        assert safe_eval('foo') == "foo"
    except Exception as e:
        assert isinstance(e, Exception)

    # this is fine
    assert safe_eval('{"foo":"bar"}') == {"foo":"bar"}

    # this will raise a safe_eval exception
    try:
        assert safe_eval('foo()') == "foo()"
    except Exception as e:
        assert isinstance(e, Exception)

    # this will raise a safe_eval exception
    try:
        assert safe_eval('foo.bar()') == "foo.bar()"
    except Exception as e:
        assert isinstance(e, Exception)

    # this is fine

# Generated at 2022-06-25 12:39:32.155972
# Unit test for function safe_eval
def test_safe_eval():
    # Check some safe evals
    assert safe_eval("5") == 5
    assert safe_eval("[5,3]") == [5,3]
    assert safe_eval("{'a': 2, 'b': 3}") == {'a': 2, 'b': 3}
    assert safe_eval("[1,2,(3,4)]") == [1,2,(3,4)]

    # Check some evals with exception
    assert safe_eval("int('a')", include_exceptions=True) == ("int('a')", None)
    assert safe_eval("[1,2,(3,4)", include_exceptions=True) == ("[1,2,(3,4)", None)

    # Check some evals with exception