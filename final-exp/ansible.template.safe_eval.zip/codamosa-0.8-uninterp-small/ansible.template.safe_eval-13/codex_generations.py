

# Generated at 2022-06-25 12:29:41.322653
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval(expr='__import__("sys").stdout.write("hello world")', include_exceptions=True)
    safe_eval(expr='__import__("sys").stdout.write("hello world")', include_exceptions=False)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:29:48.198233
# Unit test for function safe_eval
def test_safe_eval():
    """
        Test basic usage of safe_eval
    """
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo['bar']") == "foo['bar']"
    assert safe_eval("foo[\"bar\"]") == "foo[\"bar\"]"
    assert safe_eval("A == B", locals={"A": "1", "B": "2"}) == "1 == 2"
    assert safe_eval("A == B", locals={"A": 1, "B": 2}) == 1 == 2
    assert safe_eval("A == B", locals={"A": 1}) == "1 == B"

# Generated at 2022-06-25 12:29:59.347922
# Unit test for function safe_eval
def test_safe_eval():
    # test syntax errors
    import datetime
    from ansible.module_utils.common.text.converters import to_text

    # test syntax errors
    with open('tests/ansible-syntax-error.py') as f:
        syntax_error = f.read()
    assert safe_eval(syntax_error) == syntax_error

    # unicode should work
    assert safe_eval(to_text(C.DEFAULT_SUDO_USER, errors='surrogate_or_strict')) == C.DEFAULT_SUDO_USER

    # safely evaluate basic JSON forms
    assert safe_eval(True) is True
    assert safe_eval(False) is False
    assert safe_eval(None) is None
    assert safe_eval(47) == 47

# Generated at 2022-06-25 12:30:05.685253
# Unit test for function safe_eval

# Generated at 2022-06-25 12:30:12.940790
# Unit test for function safe_eval
def test_safe_eval():
    # Test case with empty input
    try:
        safe_eval('test')
    except Exception as e:
        assert 'invalid expression' in str(e)
    else:
        assert False

    assert safe_eval(True) is True
    assert safe_eval(False) is False

    # test valid strings for safe_eval
    assert safe_eval('var_0 is True')
    assert safe_eval('var_0 is False')
    assert safe_eval('var_0 is None')
    assert safe_eval('true')
    assert safe_eval('false')
    assert safe_eval('null')
    assert safe_eval('True')
    assert safe_eval('False')
    assert safe_eval('None')

    assert safe_eval('1 == 1')
    assert safe_eval('var_0 == 0')


# Generated at 2022-06-25 12:30:21.804583
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    import datetime

    from ansible.module_utils.common.text.converters import to_text

    test_list = [
        'True',
        'False',
        'None',
        '6',
        '"six"',
        'datetime.date(2016, 7, 15)',
        'datetime.datetime(2016, 7, 15, 8, 0, 0, 0)',
        'datetime.datetime.now()',
        'datetime.date.today()',
        'datetime.datetime.combine(datetime.date.today(), datetime.time())',
    ]


# Generated at 2022-06-25 12:30:23.450914
# Unit test for function safe_eval
def test_safe_eval():
    print("Test 1")
    test_case_0()
    print("Passed")



# Generated at 2022-06-25 12:30:34.366672
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate a simple expression
    assert safe_eval('1+1') == 2
    assert safe_eval('2*2') == 4
    assert safe_eval('2+2') == 4
    assert safe_eval('1/1') == 1

    # Evaluate an expression with some variables
    # Using the locals() function is used to pass the local variables
    # containing the values for the free variables in the evaluated expression
    var_0 = 3
    var_1 = 2
    assert safe_eval('var_0 + var_1', locals()) == 5
    assert safe_eval('var_0 * var_1', locals()) == 6

    # Evaluate a nested expression
    var_0 = 3
    var_1 = 2
    assert safe_eval('var_0 + 2 * var_1', locals()) == 7

    # Evaluate a

# Generated at 2022-06-25 12:30:44.677800
# Unit test for function safe_eval
def test_safe_eval():
    # This is a list of tuples - the first element of the tuple is the input
    # to the function, the second element of the tuple is the expected output
    # from the function.
    # The expected output is used as a 'answer key' - the function's output
    # is compared to this value and the test is deemed passed if they match,
    # and failed otherwise.
    test_cases = [
        (1, 1),
        (3 + 5, 8),
        (test_case_0, None)
    ]

    # Iterate through all test cases
    for test_case in test_cases:
        # Print the test case that is being run
        print('\n'+ 'Running test case: ' + str(test_case))
        # Get the input and expected output
        input = test_case[0]
        expected_

# Generated at 2022-06-25 12:30:53.824836
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    bool_1 = True
    dict_0 = dict({False: '', True: 1})
    list_0 = [False, True, '', 1]
    list_1 = ['', 1]
    list_2 = [False, True]
    string_0 = '0'
    string_1 = '1'
    string_2 = 'False'
    string_3 = 'True'

    # this is bad but safe_eval handles it gracefully
    var_1 = safe_eval("a")
    print(var_1)

    # call to safe_eval with arguments: list_0 ,
    var_2 = safe_eval(list_0)
    print(var_2)

    # call to safe_eval with arguments: string_0 ,

# Generated at 2022-06-25 12:31:06.740079
# Unit test for function safe_eval
def test_safe_eval():
    # Basic type
    i = 1
    assert safe_eval(i) == 1

    # Basic type as string
    s = '1'
    assert safe_eval(s) == '1'

    # Basic type as string
    s = "'1'"
    assert safe_eval(s) == "'1'"

    # Basic type as string enclosed in quotes
    s = '"1"'
    assert safe_eval(s) == '"1"'

    # Basic type as string enclosed in single quotes
    s = "'1'"
    assert safe_eval(s) == "'1'"

    # Basic type as string enclosed in double quotes
    s = '"1"'
    assert safe_eval(s) == '"1"'

    # Variable
    v = 'var_0'
    assert safe_eval(v) == 'var_0'



# Generated at 2022-06-25 12:31:16.527250
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = '["foo", "bar"]'
    assert safe_eval(var_1) == ['foo', 'bar']

    var_2 = '{"foo": "bar"}'
    assert safe_eval(var_2) == {'foo': 'bar'}

    var_using_true_false_none = '{"a": true, "b": false, "c": null}'
    assert safe_eval(var_using_true_false_none) == {'a': True, 'b': False, 'c': None}

    var_3 = '123'
    assert safe_eval(var_3) == 123

    var_4 = '"123"'
    assert safe_eval(var_4) == '123'

    failure_string = '{"a": "b", "c": "d"}'

# Generated at 2022-06-25 12:31:24.920260
# Unit test for function safe_eval
def test_safe_eval():
    # test_case_0
    bool_0 = True
    var_0 = safe_eval(bool_0)
    # test_case_1
    string_0 = 'string'
    var_0 = safe_eval(string_0)
    # test_case_2
    string_0 = 'string'
    list_0 = [string_0]
    dict_0 = {'key_0': list_0}
    var_0 = safe_eval(dict_0)
    # test_case_3
    string_0 = 'string'
    list_1 = [string_0]
    dict_0 = {'key_0': list_1}
    list_0 = [dict_0]
    var_0 = safe_eval(list_0)
    # test_case_4
    string_0

# Generated at 2022-06-25 12:31:27.590551
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception:
        print('FAIL: safe_eval')
        sys.exit(1)



# Generated at 2022-06-25 12:31:37.601195
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEFAULT_JINJA2_NATIVE:
        raise AssertionError()
    x = safe_eval('')
    assert x == ''
    x = safe_eval('variable')
    assert x == 'variable'
    x = safe_eval('variable_name')
    assert x == 'variable_name'
    x = safe_eval('False')
    assert x is False
    x = safe_eval('False')
    assert x is False
    x = safe_eval('True')
    assert x is True
    x = safe_eval('-5')
    assert x == -5
    x = safe_eval('-5')
    assert x == -5
    x = safe_eval('my_dict[0]')
    assert x == 'my_dict[0]'

# Generated at 2022-06-25 12:31:45.737700
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases for data type bool
    bool_0 = True
    var_0 = safe_eval(bool_0)
    assert var_0 == True

    bool_1 = False
    var_1 = safe_eval(bool_1)
    assert var_1 == False

    # Test case for data type string

    string_0 = 'hello'
    var_0 = safe_eval(string_0)
    assert var_0 == 'hello'

    # Test cases for data types int

    int_0 = 1
    var_0 = safe_eval(int_0)
    assert var_0 == 1

    int_0 = 0
    var_0 = safe_eval(int_0)
    assert var_0 == 0

    int_0 = -1
    var_0 = safe_eval(int_0)
   

# Generated at 2022-06-25 12:31:48.687318
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print('Error raised: ' + repr(e))
        raise

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:32:00.213138
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestSafeEval(unittest.TestCase):

        def setUp(self):
            # Here we patch out isinstance().  Ideally we'd patch it only for
            # the duration of the test, but this is a near-term workaround to
            # get the isinstance() call in safe_eval() to fail.  We must fail
            # the isinstance check safely because we're testing that safe_eval
            # returns the original expression if it is not a string.
            self.isinstance_patcher = patch('ansible.utils.unsafe_proxy.isinstance')
            self.mock_isinstance = self.isinstance_patcher.start()
            self.mock_isinstance.return_value = False



# Generated at 2022-06-25 12:32:01.556365
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("10 + 20") == 30

# Generated at 2022-06-25 12:32:02.498647
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:32:12.752384
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception in test_safe_eval: %s" % err)
        raise

if __name__ == "__main__":
    # Run unit test
    test_safe_eval()

# Generated at 2022-06-25 12:32:20.350948
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    str_1 = '[1, 2, 3]'
    var_1 = safe_eval(str_1)
    assert var_1 == [1, 2, 3]

    str_2 = '{\"b\": \"c\"}'
    var_2 = safe_eval(str_2)
    assert var_2 == {'b': 'c'}

    str_3 = '{\"var\": \"{{%s}}\"}' % str_2
    var_3 = safe_eval(str_3)
    assert var_3 == {'var': '{{\"b\": \"c\"}}'}

    str_4 = '{{%s}}' % str_2
    var_

# Generated at 2022-06-25 12:32:27.875079
# Unit test for function safe_eval
def test_safe_eval():
    enclose_list = [0,0,0,0,0]

    # Case 0
    enclose_list[0] = enclose_list[0] + 1
    try:
        test_case_0()
    except:
        enclose_list[0] = enclose_list[0] + 1

    if(enclose_list[0] == 2):
        enclose_list[4] = enclose_list[4] + 1

    # print enclose_list

    if(enclose_list[4] == 1):
        sys.exit(0)
    else:
        sys.exit(1)

# Execute function safe_eval
test_safe_eval()

# Generated at 2022-06-25 12:32:37.711221
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'some_var'
    res_0 = safe_eval(str_0)
    try:
        assert res_0 == 'some_var'
    except AssertionError:
        print("AssertionError: " + str(res_0))
    print(res_0)

    str_0 = 'some_var'
    res_0 = safe_eval(str_0, {'some_var': 'one'})
    try:
        assert res_0 == 'one'
    except AssertionError:
        print("AssertionError: " + str(res_0))
    print(res_0)

    str_0 = '1 + 2'
    res_0 = safe_eval(str_0)

# Generated at 2022-06-25 12:32:45.344991
# Unit test for function safe_eval
def test_safe_eval():
    # Test #0
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    print('safe_eval returned %s' % var_0)
    assert var_0 == 'SA7'

    str_1 = 'SA7[0]'
    var_1 = safe_eval(str_1)
    print('safe_eval returned %s' % var_1)
    assert var_1 == 'SA7[0]'

    str_2 = "${SA7[0]}"
    var_2 = safe_eval(str_2)
    print('safe_eval returned %s' % var_2)
    assert var_2 == '${SA7[0]}'

    # valid expression + no added local variables
    str_3 = '["a","b","c"]'
    var_

# Generated at 2022-06-25 12:32:48.994409
# Unit test for function safe_eval
def test_safe_eval():
    # Case 0
    test_case_0()


if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:32:58.734237
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    str_1 = 'SA7'
    var_1 = safe_eval(str_1)
    assert var_1 == 'SA7', "Expected other result from safe_eval: '%s' != '%s'" % ('SA7', str(var_1))

    str_2 = 'SA7 < 7'
    var_2 = safe_eval(str_2)
    assert var_2 == 'SA7 < 7', "Expected other result from safe_eval: '%s' != '%s'" % ('SA7 < 7', str(var_2))

    str_3 = 'SA7 < 7'
    var_3 = safe_eval(str_3)

# Generated at 2022-06-25 12:33:00.066214
# Unit test for function safe_eval
def test_safe_eval():
    ret = safe_eval('SA7')
    assert ret == 'SA7'

# Generated at 2022-06-25 12:33:04.677549
# Unit test for function safe_eval
def test_safe_eval():
    print("TEST BEGIN")
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert(var_0 == 'SA7')
    print("TEST END")


if __name__ == '__main__':
    # test_case_0()
    test_safe_eval()

# Generated at 2022-06-25 12:33:07.007543
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Unable to evaluate safe_eval: " + str(e)



# Generated at 2022-06-25 12:33:28.048179
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    str_0 = 'SA{{7}}'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA{{7}}'

    str_0 = "{'SA': 'SA7'}"
    var_0 = safe_eval(str_0)
    assert var_0 == {'SA': 'SA7'}

    str_0 = " {'hello': 'world', 'a list': [1, 2, 3], True: 'True', False: 'False', None: 'None', 'dict': {'foo': 'bar'}} "
    var_0 = safe_eval(str_0)

# Generated at 2022-06-25 12:33:34.287765
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    str_1 = '[ "SA7", "SA8" ]'
    var_1 = safe_eval(str_1)
    assert isinstance(var_1, list)
    assert len(var_1) == 2
    assert var_1[0] == 'SA7'
    assert var_1[1] == 'SA8'

    str_2 = 'any(['
    var_2 = safe_eval(str_2)
    assert var_2 == str_2

    str_3 = '"a" + "b"'
    var_3 = safe_eval(str_3)
    assert var_3 == 'ab'


# Generated at 2022-06-25 12:33:45.871285
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('10 / 3') == 10 / 3
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a":1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('{"a":1, "b": [2, 3]}') == {"a": 1, "b": [2, 3]}
    assert safe_eval('2 + 3') == 5
    assert safe_eval('10 - 2') == 8
    assert safe_eval('2 * 3') == 6
    assert safe_eval('25 / 5') == 5
   

# Generated at 2022-06-25 12:33:47.278696
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable", dict(a_list_variable=[1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-25 12:33:54.869823
# Unit test for function safe_eval
def test_safe_eval():
    with open('/home/vchaska1/protobuf/ansible/test/playbooks/playbook_safe_eval.yml', 'r') as stream:
        try:
            print('---Testing safe_eval---')
            print('---Reading yaml file---')
            set_module_args(yaml.load(stream))
            result = map_params_to_obj()
            call_safe_eval()
        except YAMLError as exc:
            print(exc)

'''
This is not a complete unit test because we are yet to figure out how to get the function to execute and return the value
'''

# Generated at 2022-06-25 12:34:01.854313
# Unit test for function safe_eval
def test_safe_eval():
   str_0 = "SA7"
   res_0 = safe_eval(str_0)
   assert res_0 == "SA7", "Expected: " + "SA7" + ", Actual: " + res_0 
   str_1 = "SA73"
   res_1 = safe_eval(str_1)
   assert res_1 == "SA73", "Expected: " + "SA73" + ", Actual: " + res_1 
   str_2 = [1,2,3]
   try:
       res_2 = safe_eval(str_2)
       assert False
   except:
       assert True
   str_3 = ['VIP', '+', 'Client_IP']
   res_3 = safe_eval(str_3)

# Generated at 2022-06-25 12:34:04.295046
# Unit test for function safe_eval
def test_safe_eval():
    aconst = safe_eval('[1,2,3]')
    print(aconst)

if __name__ == '__main__':
    test_case_0()
    test_safe_eval()

# Generated at 2022-06-25 12:34:14.020120
# Unit test for function safe_eval
def test_safe_eval():
    # Testing for good input
    variable = 'dict(foo=1, bar=2)'
    result = dict(foo=1, bar=2)
    assert safe_eval(variable) == result

    variable = 'dict(a=1, b=2)'
    result = dict(a=1, b=2)
    assert safe_eval(variable) == result

    # Testing for bad input.
    variable = 'import os'
    result = variable
    assert safe_eval(variable) == result

    variable = 'os.path.basename'
    result = variable
    assert safe_eval(variable) == result

    variable = 'dict(a=1, b=os)'
    result = variable
    assert safe_eval(variable) == result

    variable = 'dict(a=1, b=os.path)'
    result = variable

# Generated at 2022-06-25 12:34:20.915667
# Unit test for function safe_eval
def test_safe_eval():

    str_0 = 'SA7'
    print(safe_eval(str_0))
    str_0 = 'S2'
    print(safe_eval(str_0))
    str_0 = 'S'
    print(safe_eval(str_0))
    str_0 = 'T'
    print(safe_eval(str_0))
    str_0 = 'S2 * T'
    print(safe_eval(str_0))
    str_0 = 'S2 * T * S2'
    print(safe_eval(str_0))
    str_0 = 'SA7[2 - S2:T:S2]'
    print(safe_eval(str_0))
    str_0 = True
    print(safe_eval(str_0))
    str_0 = False

# Generated at 2022-06-25 12:34:28.664732
# Unit test for function safe_eval
def test_safe_eval():
    with open('tests/module_utils/safe_eval_test.txt', 'r') as file:
        data = file.readlines()
        for line in data:
            func_name, _, input_var, expected_output = line.split(',')
            if func_name == 'safe_eval':
                var_0 = safe_eval(input_var, include_exceptions=True)
                assert var_0[0] == expected_output


# Generated at 2022-06-25 12:34:46.823506
# Unit test for function safe_eval
def test_safe_eval():

    # Call function safe_eval with arguments: str_0
    str_0 = 'SA7'
    try:
        safe_eval(str_0)
    except SystemExit:
        pass



# Generated at 2022-06-25 12:34:56.488987
# Unit test for function safe_eval
def test_safe_eval():
    str_1 = 'SA7'
    var_1 = safe_eval(str_1)
    str_2 = '1'
    var_2 = safe_eval(str_2)
    if var_1 != 'SA7':
        raise AssertionError("safe_eval %s %s" % (str_1, var_1))
    if var_2 != 1:
        raise AssertionError("safe_eval %s %s" % (str_2, var_2))


if __name__ == "__main__":

    test_case_0()
    #test_safe_eval()

# Generated at 2022-06-25 12:35:05.505664
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.modules.system import service
    from ansible.module_utils.facts import cache
    from ansible.module_utils._text import to_text

    service_ret = service.main()
    module_args = dict(
        name='foo',
        state='started'
    )
    service_ret.update(module_args)
    service_ret.update(cache.facts)
    print(json.dumps(service_ret))

# Generated at 2022-06-25 12:35:14.740389
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 3 + 5') == 9
    assert safe_eval('6 // 2') == 3
    assert safe_eval('1 == 1') == True
    assert safe_eval('[1]') == [1]
    assert safe_eval('{"1": "2"}') == {"1": "2"}
    assert safe_eval('false') == False
    assert safe_eval('true') == True
    assert safe_eval('null') == None
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
   

# Generated at 2022-06-25 12:35:21.272633
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:24.317243
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval()...')
    test_case_0()
    print('Done')
    exit(0)

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:35:35.530891
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        {'safe_eval': test_case_0},
    ]

    for test_case in test_cases:
        print('eval case: [{}]'.format(test_case))
        test_case['safe_eval']()

# Run test generate json descriptor
if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'json':
        op = {
            'name': 'safe_eval',
            'callstack': safe_eval,
            'testcases': [
                {
                    'name': 'test_case_0',
                    'params': [
                        {
                            'name': 'str_0',
                            'value': 'SA7',
                        },
                    ],
                }
            ]
        }



# Generated at 2022-06-25 12:35:44.219268
# Unit test for function safe_eval
def test_safe_eval():

    # test 0: ensure safe_eval passes when given a string
    test_case_0()

    # test 1: ensure safe_eval passes when given an int
    str = '12345'
    var = safe_eval(str)
    assert isinstance(var, int)

    # test 2: ensure safe_eval passes when given a float
    str = '0.123'
    var = safe_eval(str)
    assert isinstance(var, float)

    # test 3: ensure safe_eval passes when given a list
    str = ('[1, 2, 3]')
    var = safe_eval(str)
    assert isinstance(var, list)

    # test 4: ensure safe_eval passes when given a tuple
    str = ('(1, 2, 3)')
    var = safe_eval(str)

# Generated at 2022-06-25 12:35:53.343203
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] > 2:
        str_0 = 'SA7'
        var_0 = safe_eval(str_0)
        assert var_0 == 'SA7'

        str_0 = 'SA7 is OK!'
        var_0 = safe_eval(str_0)
        assert var_0 == 'SA7 is OK!'

        str_0 = 'SA7'
        var_0 = safe_eval(str_0, {"SA7": "OK"})
        assert var_0 == 'OK'

        str_0 = 'SA7 is OK!'
        var_0 = safe_eval(str_0, {"SA7": "OK"})
        assert var_0 == 'SA7 is OK!'

        str_0 = 'SA7'

# Generated at 2022-06-25 12:35:59.690444
# Unit test for function safe_eval
def test_safe_eval():
    with open('test_cases/test_safe_eval.txt') as f:
        content = f.readlines()

    # you may also want to remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]

    for str_0 in content:
        str_0 = str_0.encode('ascii','ignore')
        var_0 = safe_eval(str_0)


# Generated at 2022-06-25 12:36:24.043403
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    str_1 = ''
    str_2 = '123'
    str_3 = '"123"'
    str_4 = '"123"'
    str_5 = '{"a": "b"}'
    str_6 = '123'
    str_7 = 'false'
    str_8 = 'null'
    str_9 = 'true'
    str_10 = '[1, 2, 3]'
    str_11 = '\\n'
    str_12 = 'SA7'
    str_13 = '"\\n"'
    str_14 = '"\\n"'
    str_15 = '"\\n"'
    str_16 = '"\\n"'
    str_17 = '"\\n"'
    str_18 = '"\\n"'
    str_19

# Generated at 2022-06-25 12:36:26.947971
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-25 12:36:36.484518
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var = safe_eval(str_0)
    assert var == 'SA7'
    str_0 = 'SA7+3'
    var = safe_eval(str_0)
    assert var == 10
    str_0 = '[1,2,3]'
    var = safe_eval(str_0)
    assert var == [1,2,3]
    str_0 = '''['ssssssssssssss', 'ttttttttt']'''
    var = safe_eval(str_0)
    assert var == ['ssssssssssssss', 'ttttttttt']
    str_0 = '''['ssssssssssssss', 'ttttttttt', {'1':'2'}]'''

# Generated at 2022-06-25 12:36:45.736726
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('SA7') == 'SA7'
    assert safe_eval('SA7.1') == 'SA7.1'
    assert safe_eval('SA7_') == 'SA7_'
    assert safe_eval('SA7_1') == 'SA7_1'
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1+1') == 2
    assert safe_eval(' 1+1 ') == 2
    assert safe_eval(' 1 + 1 ') == 2
    assert safe_eval(' 1 + 1') == 2
    assert safe_eval('1 + 1 ') == 2
    assert safe_eval('1.1+1') == 2.1
    assert safe_eval('1+1.1') == 2.1
   

# Generated at 2022-06-25 12:36:52.725561
# Unit test for function safe_eval
def test_safe_eval():
    '''test_safe_eval'''
    # Test with a literal value
    str_0 = '5'
    var_0 = safe_eval(str_0)
    assert var_0 == 5

    # Test with a string literal
    str_0 = '"foo"'
    var_0 = safe_eval(str_0)
    assert var_0 == 'foo'

    # Test with a variable
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    # Test with an expression
    str_0 = 'SA7 + SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7SA7'

    # Test with an expression

# Generated at 2022-06-25 12:37:02.969469
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'
    str_1 = '7SA'
    var_1 = safe_eval(str_1)
    assert var_1 == '7SA'
    str_2 = 'SA'
    var_2 = safe_eval(str_2)
    assert var_2 == 'SA'
    str_3 = 'SA'
    var_3 = safe_eval(str_3)
    assert var_3 == 'SA'
    str_4 = 'SA'
    var_4 = safe_eval(str_4)
    assert var_4 == 'SA'
    str_5 = 'SA'
    var_5 = safe_eval(str_5)

# Generated at 2022-06-25 12:37:06.134224
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_safe_eval()
    print('done')

# Generated at 2022-06-25 12:37:16.664486
# Unit test for function safe_eval
def test_safe_eval():
    # Must be string.
    expr_0 = None
    result_0 = safe_eval(expr_0)
    assert result_0 == None

    # Must be a valid python expression.
    expr_1 = 'None'
    result_1 = safe_eval(expr_1)
    assert result_1 == None

    # Must be a valid python expression.
    expr_2 = 'True'
    result_2 = safe_eval(expr_2)
    assert result_2 == True

    # Must be a valid python expression.
    expr_3 = 'False'
    result_3 = safe_eval(expr_3)
    assert result_3 == False

    # Must be a valid python expression.
    expr_4 = '0'
    result_4 = safe_eval(expr_4)
    assert result_4 == 0

# Generated at 2022-06-25 12:37:24.312925
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    str_0 = '{{ 3 + 5 }}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{{ 3 + 5 }}'

    str_0 = '{{ 3 | ternary(7, 9) }}'
    var_0 = safe_eval(str_0)
    assert var_0 == '{{ 3 | ternary(7, 9) }}'

    str_0 = '{{ 3 | ternary(7, 9) }}'
    locals_0 = {'3': 3}
    var_0 = safe_eval(str_0, locals=locals_0)
    assert var_0 == 7


# Generated at 2022-06-25 12:37:33.833649
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    print(var_0)
    print(type(var_0))
    str_1 = "'SA7'"
    var_1 = safe_eval(str_1)
    print(var_1)
    print(type(var_1))
    str_2 = '"SA7"'
    var_2 = safe_eval(str_2)
    print(var_2)
    print(type(var_2))
    str_3 = 'a'
    var_3 = safe_eval(str_3)
    print(var_3)
    print(type(var_3))
    str_4 = '7'
    var_4 = safe_eval(str_4)
    print(var_4)


# Generated at 2022-06-25 12:38:09.340438
# Unit test for function safe_eval
def test_safe_eval():
    assert(test_case_0() == None)

if __name__ == "__main__":
    import nose
    nose.main(defaultTest=__name__)

# Generated at 2022-06-25 12:38:17.310353
# Unit test for function safe_eval
def test_safe_eval():

    # Here we validate that the safe_eval function returns a string type
    # and the input is not modified.
    assert isinstance(test_case_0(),string_types), 'Expecting the safe_eval function to return a string type'
    assert test_case_0() == 'SA7', 'Expecting the safe_eval function to return the equivalent of the input string'

    # Here we check that the safe_eval function does not allow
    # function calls.
    assert not hasattr(safe_eval('safe_eval("print hello")'), '__call__'), 'Function call in safe_eval is not expected'



# Generated at 2022-06-25 12:38:28.204832
# Unit test for function safe_eval
def test_safe_eval():
    print("test_safe_eval")
    # Use a string to test safe_eval function
    var_0 = 'SA7'
    safe_eval(var_0)
    # Use a list to test safe_eval function
    var_1 = [1,2,3,4,5]
    safe_eval(var_1)
    # Use a dict to test safe_eval function
    var_2 = {'name': 'Dave', 'age': '35'}
    safe_eval(var_2)
    # Use a bool to test safe_eval function
    var_3 = True
    safe_eval(var_3)
    # Use a tuple to test safe_eval function
    var_4 = (1,2,3,4,5)
    safe_eval(var_4)
    # Use a number to test safe

# Generated at 2022-06-25 12:38:31.136495
# Unit test for function safe_eval
def test_safe_eval():
    """ Test safe_eval by passing 'SA7' as a parameter """
    assert str(test_case_0()) == 'SA7', 'Expected return value for safe_eval is SA7'


# Generated at 2022-06-25 12:38:40.635877
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('True') == True
    assert safe_eval('true') == True
    assert safe_eval('TRUE') == True
    assert safe_eval('false') == False
    assert safe_eval('FALSE') == False
    assert safe_eval('False') == False
    assert safe_eval('nUlL') == None
    assert safe_eval('null') == None
    assert safe_eval('None') == None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == dict(a=1)
    assert safe_eval('bool(1)') == True
    assert safe_eval('abs(-1)') == 1

# Generated at 2022-06-25 12:38:48.530695
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert isinstance(var_0,int) == True
    assert var_0 == 7
    str_1 = '7 + 14'
    var_1 = safe_eval(str_1)
    assert isinstance(var_1,int) == True
    assert var_1 == 21
    str_2 = 'data is True'
    var_2 = safe_eval(str_2)
    assert var_2 == True
    str_3 = 'data is False'
    var_3 = safe_eval(str_3)
    assert var_3 == False
    str_4 = 'data is None'
    var_4 = safe_eval(str_4)
    assert var_4 == None

# Generated at 2022-06-25 12:38:56.766073
# Unit test for function safe_eval
def test_safe_eval():
    # Run unit test
    try:
        print("Start test...")
        print("Test case 0: SA7")
        test_case_0()
        print("Test case 1: ['SA7', 'AR3']")
        test_case_1()
        print("Test case 2: false")
        test_case_2()
        print("Test case 3: null")
        test_case_3()
        print("Test case 4: true")
        test_case_4()
        print("All test case passed!")
    except Exception as error:
        print("Error: " + str(error))

# Test case 1

# Generated at 2022-06-25 12:39:05.685933
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7'

    str_0 = 'SA7 + SA8'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7 + SA8'

    str_0 = 'SA7*SA8'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7*SA8'

    str_0 = 'SA7/SA8'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7/SA8'

    str_0 = 'SA7 - SA8'
    var_0 = safe_eval(str_0)
    assert var_0 == 'SA7 - SA8'



# Generated at 2022-06-25 12:39:12.521272
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2 + 3') == 6
    assert safe_eval('True and True') == True
    assert safe_eval('["foo", "bar", "baz"]') == ['foo', 'bar', 'baz']
    assert safe_eval('dict(a=1, b=2)') == dict(a=1, b=2)
    assert safe_eval('foo.bar(a, b=1)') == 'foo.bar(a, b=1)'
    assert safe_eval('[x for x in range(10)]') == [x for x in range(10)]
    assert safe_eval('[x for x in range(10) if x % 2 == 0]') == [x for x in range(10) if x % 2 == 0]

# Generated at 2022-06-25 12:39:16.761814
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'SA7'
    str_1 = 'SA7'
    var_0 = safe_eval(str_0)
    var_1 = safe_eval(str_0)
    assert var_0 == var_1, "test_safe_eval FAIL"

test_safe_eval()