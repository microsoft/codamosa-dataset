

# Generated at 2022-06-25 12:29:45.158610
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")
    test_case_0()
    # Only test the safe_eval function in the module if the eval_tool config option is set to ast.
    if C.ANSIBLE_EVAL_TOOLS == 'ast':
        test_safe_eval_ast()

# Uncomment below to test with all eval tools.
#    if C.ANSIBLE_EVAL_TOOLS == 'safe_eval':
#        test_safe_eval_ast()
#    elif C.ANSIBLE_EVAL_TOOLS == 'eval':
#        test_safe_eval_ast()

# Generated at 2022-06-25 12:29:49.342581
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        test_case_0,
    ]

    for case in test_cases:
        try:
            case()
        except Exception as e:
            print(e)
            return 1
    return 0


if __name__ == '__main__':
    ret = test_safe_eval()
    sys.exit(ret)

# Generated at 2022-06-25 12:29:50.275849
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:30:00.924468
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_0)
    assert var_0 == 'g\'t.C'
    str_1 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_1 = safe_eval(str_1)
    assert var_1 == 'g\'t.C'
    str_2 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_2 = safe_eval(str_2)
    assert var_2 == 'g\'t.C'
    str_3 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_3 = safe_

# Generated at 2022-06-25 12:30:11.303932
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    str_1 = "g't.C\n{%)H_+\x0cQ,\nm-"
    str_2 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_2)
    assert var_0 == "g't.C\n{%)H_+\x0cQ,\nm-"
    str_3 = "^x\x1a\x1d\x1aU\x0c\x1f"
    str_4 = "^x\x1a\x1d\x1aU\x0c\x1f"

# Generated at 2022-06-25 12:30:20.908487
# Unit test for function safe_eval
def test_safe_eval():
    tests = [
            "(a + b)",
            "(1 - 2)",
            "[1, 2, 3, 4]",
            "{'a': 1, 'b': 2}",
            "{'a': [1, 2, 3, 4]}",
            "{'a': (1, 2, b, 4)}",
            "a + b",
            "a + [1, 2, 3, 4]",
            "a + {'a': 1, 'b': 2}",
            "a + {'a': [1, 2, 3, 4]}",
            "a + {'a': (1, 2, b, 4)}",
    ]

    # Note: this test should be run with PY_VARS_ALLOWED_IN_SAFE_EVAL set to
    #       True in constants.py


# Generated at 2022-06-25 12:30:23.404815
# Unit test for function safe_eval
def test_safe_eval():
    succeed = True
    try:
        test_case_0()
    except:
        succeed = False
    assert succeed, 'Test failed'


# Generated at 2022-06-25 12:30:34.326034
# Unit test for function safe_eval
def test_safe_eval():
    """Tests for safe_eval"""
    # Basic case: pass in a string
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_0)
    assert var_0 == "g't.C\n{%)H_+\x0cQ,\nm-"

    # Basic case: pass in a string
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_0)
    assert var_0 == "g't.C\n{%)H_+\x0cQ,\nm-"

    # Basic case: pass in a string

# Generated at 2022-06-25 12:30:44.710117
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_0)
    str_1 = "'{{ ansible_hostname }}' == inventory_hostname"
    var_1 = safe_eval(str_1)
    str_2 = "j.a\x0bQ\xe8\x00\t\r\tP\x0e\x00\x16('\x0c\x07\t\r\tP\x0e\x00\x16('\x0c\x07\x00\t\r\tP\x0e\x00\x16('\x0c\x07\x00\x02\x00\x00\x00\n"
    var_2 = safe

# Generated at 2022-06-25 12:30:53.856512
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "g't.C\n{%)H_+\x0cQ,\nm-"
    var_0 = safe_eval(str_0)
    assert var_0 == "g't.C\n{%)H_+\x0cQ,\nm-", "Unexpected safe_eval result for safe_eval"
    str_1 = '_0x6d61[32] + _0x6d61[67]'
    var_1 = safe_eval(str_1)
    assert var_1 == "am' + 'c", "Unexpected safe_eval result for safe_eval"
    str_2 = '(_0x6d61[1]+_0x6d61[17] +_0x6d61[52] + _0x6d61[55])'

# Generated at 2022-06-25 12:30:59.443692
# Unit test for function safe_eval
def test_safe_eval():
    try:
        expr = "0"
        assert safe_eval(expr) == 0
    except Exception as e:
        print("Error: " + str(e))
        test_case_0()


# Generated at 2022-06-25 12:31:07.092615
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a unit test for the function safe_eval
    '''
    class SimpleObject(object):
        pass

    int_obj = SimpleObject()
    int_obj.id = 'int'
    # Override the standard int type
    builtins.int = int_obj

    # Check that safe_eval calls the custom int
    assert int_obj == safe_eval('int(1)')
    # Check that safe_eval does not call the standard int
    assert test_case_0 != safe_eval('test_case_0()')

    # Check that safe_eval calls the standard int
    CALL_ENABLED.append('int')
    assert int_obj != safe_eval('int(1)')
    # Check that safe_eval does not call the custom int

# Generated at 2022-06-25 12:31:16.950237
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'1 + 1'") == '1 + 1'
    assert safe_eval("'1 + 1'", include_exceptions=True)[0] == '1 + 1'
    assert safe_eval("'1 + 1'", include_exceptions=True)[1] == None
    assert safe_eval("1 + 1", locale=dict(int_0='0')) == 2
    assert safe_eval("1 + 1", locale=dict(int_0=0)) == 2
    assert safe_eval("1 + 1", locale=dict(int_0='0')) == 2
    assert safe_eval("1 + 1", locale=dict(int_0=0)) == 2

# Generated at 2022-06-25 12:31:25.221122
# Unit test for function safe_eval
def test_safe_eval():
    d = dict(a=1, b=2, c=3)
    assert safe_eval('a + b', d) == 3
    assert safe_eval('a + b + c', d) == 6
    assert safe_eval('a + b', dict(a=1, b=2, c=3, d=1)) == 3
    assert safe_eval('[1,2,3]', dict(a=1, b=2, c=3, d=1)) == [1, 2, 3]
    assert safe_eval('[a,b,c]', dict(a=1, b=2, c=3, d=1)) == [1, 2, 3]

# Generated at 2022-06-25 12:31:36.044072
# Unit test for function safe_eval
def test_safe_eval():
    temp_stdout = None

    if not sys.stdout.isatty():
        temp_stdout = sys.stdout
        sys.stdout = sys.stderr

    # This test case is a 'valid' Python statement,
    # ansible should be able to parse it
    test_case_0()

    # These test cases should all fail to parse

# Generated at 2022-06-25 12:31:44.581154
# Unit test for function safe_eval
def test_safe_eval():
    res, err = safe_eval('{{true}}', include_exceptions=True)
    assert res == True
    assert err is None

    res, err = safe_eval('{{false}}', include_exceptions=True)
    assert res == False
    assert err is None

    res, err = safe_eval('{{null}}', include_exceptions=True)
    assert res == None
    assert err is None

    res, err = safe_eval('{{[1,2,3]}}', include_exceptions=True)
    assert res == [1,2,3]
    assert err is None

    res, err = safe_eval('{{{"a": "b", "c": "d"}}}', include_exceptions=True)
    assert res == {"a": "b", "c": "d"}
    assert err is None



# Generated at 2022-06-25 12:31:49.766076
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0 
    # This test case is for a expression 
    # that is not an valid expression (True or False)
    # Desired result: The method should return the expression
    # as it is (True or False)
    assert safe_eval(True)
    assert safe_eval(False)
    assert safe_eval(None)
    assert safe_eval(0)
    assert not safe_eval(1)
    assert safe_eval(1) == 1
    assert safe_eval(0.0) == 0.0
    assert safe_eval(1.0) == 1.0
    assert safe_eval(0.0)
    assert safe_eval(1.0)
    assert safe_eval(1)
    assert not safe_eval(0)
    assert safe_eval(1, {"test": 0})
   

# Generated at 2022-06-25 12:32:00.348979
# Unit test for function safe_eval
def test_safe_eval():
    # Mock
    test_data_0 = '0'
    test_data_1 = '1'
    test_data_2 = '2'
    test_data_3 = '-1'
    test_data_4 = '-1.1'
    test_data_5 = '1.1'
    expected_result_0 = 0
    expected_result_1 = 1
    expected_result_2 = 2
    expected_result_3 = -1
    expected_result_4 = -1.1
    expected_result_5 = 1.1
    # Test
    result_0 = safe_eval(test_data_0)
    result_1 = safe_eval(test_data_1)
    result_2 = safe_eval(test_data_2)

# Generated at 2022-06-25 12:32:11.113545
# Unit test for function safe_eval
def test_safe_eval():
    # check for basic expression
    assert safe_eval('2 + 2') == 4
    assert safe_eval('2 * 2') == 4
    assert safe_eval('2 - 2') == 0
    assert safe_eval('2 / 2') == 1
    assert safe_eval('2 ** 2') == 4
    assert safe_eval('2 % 2') == 0

    # check for negative numbers
    assert safe_eval('-2') == -2
    assert safe_eval('-2 + 2') == 0
    assert safe_eval('-2 - 2') == -4
    assert safe_eval('-2 * 2') == -4
    assert safe_eval('-2 / 2') == -1
    assert safe_eval('-2 ** 2') == -4
    assert safe_eval('-2 % 2') == 0

    # check for strings and

# Generated at 2022-06-25 12:32:13.445021
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    print("Test Case 0 Passed. No Error")

# Main Function

# Generated at 2022-06-25 12:32:26.527816
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure safe eval only allows for simple expressions.
    for test_case in [
        'test_case_0',
        'test_case_0()',
        'test_case_0().foo',
        'dict(a=1)',
        'dict(a=dict(b=1))',
        '1 + 1',
        '1 + 1 * 2',
        '1 + (1 * 2)',
        'True',
        'False',
        'None',
        'True and False',
        'None or False'
    ]:
        try:
            # Safe eval should return the evaluated expression.
            assert safe_eval(test_case) == eval(test_case)
        except SyntaxError:
            # Safe eval should return the expression on syntax error.
            assert safe_eval(test_case) == test

# Generated at 2022-06-25 12:32:32.885163
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 0
    in_str_0 = "{{ int_0 }}"
    out_str_0 = safe_eval(in_str_0)
    if out_str_0 == 0:
        print("test case 0 passed.")

if __name__ == "__main__":
    # Test case 0
    test_case_0()
    # Unit test safe_eval
    test_safe_eval()

# Generated at 2022-06-25 12:32:39.111532
# Unit test for function safe_eval
def test_safe_eval():
    global int_0
    if sys.version_info[0] < 3:
        assert safe_eval('0') == 0
        assert safe_eval('0', include_exceptions=True) == (0, None)
        assert safe_eval('True') == True
        assert safe_eval('false') == False
        assert safe_eval('[1]') == [1]
        assert safe_eval('(1, 2)') == (1, 2)
        assert safe_eval('{"a": 1}') == { 'a': 1 }
        assert safe_eval('0.1') == 0.1
        assert safe_eval('foo', {'foo': 'bar'}) == 'bar'
        assert safe_eval('foo') == 'foo'  # built-in function
        assert safe_eval('tuple') == tuple
        assert safe

# Generated at 2022-06-25 12:32:46.299341
# Unit test for function safe_eval
def test_safe_eval():
    # Test for int with value 0
    # test_case_0()
    result = safe_eval("0")
    if result != 0:
        raise AssertionError("safe_eval fails on int test case 0.")

    # Test for int with value 1
    # test_case_1()
    result = safe_eval("1")
    if result != 1:
        raise AssertionError("safe_eval fails on int test case 1.")

    # Test for int with value 1000
    # test_case_2()
    result = safe_eval("1000")
    if result != 1000:
        raise AssertionError("safe_eval fails on int test case 2.")

    # Test for int with value -1
    # test_case_3()
    result = safe_eval("-1")
    if result != -1:
        raise

# Generated at 2022-06-25 12:32:57.530681
# Unit test for function safe_eval
def test_safe_eval():
    expr_0 = None
    result_0 = safe_eval(expr_0)
    assert result_0 is expr_0

    # Testing whether the function returns expr_0 if the
    # result of safe_eval(expr) is equivalent to expr
    expr_1 = "h"
    result_1 = safe_eval(expr_1)
    assert result_1 is expr_1

    # Testing whether the function returns expr_0 if value of
    # expr is of type int
    expr_2 = 2
    result_2 = safe_eval(expr_2)
    assert result_2 is expr_2

    # Testing whether the function returns expr_0 if the
    # result of safe_eval(expr) is equivalent to expr
    expr_3 = "h"
    result_3 = safe_eval(expr_3)
    assert result

# Generated at 2022-06-25 12:33:07.179420
# Unit test for function safe_eval
def test_safe_eval():
    # Test for syntax error
    failure_msg = []
    failure_msg.append('Expecting eval to return a string if a syntax error is encountered')
    test_0 = safe_eval("{{ 'ansible')")
    test_1 = safe_eval("{{ 'ansible' }}")
    failure_msg.append('Expecting eval to return a string if a syntax error is encountered, got %s' % test_0)
    assert isinstance(test_0, string_types), ' '.join(failure_msg)
    assert isinstance(test_1, string_types), ' '.join(failure_msg)

    # Test for builtin functions
    failure_msg = []
    failure_msg.append('Expecting eval to return a string if a syntax error is encountered')

# Generated at 2022-06-25 12:33:16.772888
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_KEEP_REMOTE_FILES or C.DEFAULT_REMOTE_TMP != "/tmp":
        # do not perform test here as it is not valid
        return

    try:
        test_case_0()
    except:
        # not able to test function safe_eval, we just return
        # the expression string back as-is
        return

    # test safe_eval without exceptions

# Generated at 2022-06-25 12:33:27.507519
# Unit test for function safe_eval
def test_safe_eval():
    global int_0
    int_0 = 1
    assert safe_eval('42', locals()) == 42
    assert safe_eval('40+2', locals()) == 42
    assert safe_eval('false') == False
    assert safe_eval('false and true') == False
    assert safe_eval('false or true') == True
    assert safe_eval('null') == None
    assert safe_eval('true') == True
    assert safe_eval('true and false') == False
    assert safe_eval('true or false') == True
    assert safe_eval('int_0') == 1
    assert safe_eval('len([4,2])') == 2
    assert safe_eval('test_case_0()') == None


# Generated at 2022-06-25 12:33:33.708542
# Unit test for function safe_eval
def test_safe_eval():
    # create a set of objects which are of various types, and
    # use them as input parameters to test safe_eval function
    test_obj_1 = {"test_var_1": "test_val_1",
                  "test_var_2": {"test_var_3": "test_val_3"}}
    test_obj_2 = ["test_var_1", "test_val_1"]
    test_obj_3 = "test_var_1"
    test_obj_4 = "{{test_var_1}}"
    test_obj_5 = "{{test_var_1.strip('test')}}"
    test_obj_6 = "{{test_var_1.strip('test')|default('test')}}"

# Generated at 2022-06-25 12:33:45.036238
# Unit test for function safe_eval
def test_safe_eval():
    # int_0 is not a string, should pass unchanged
    int_0 = 0
    assert safe_eval(int_0) == 0

    # str_0 is a string, should get evaluated
    str_0 = '0'
    assert safe_eval(str_0) == 0

    # str_1 is not a valid number, should return unchanged
    str_1 = 'a'
    assert safe_eval(str_1) == 'a'

    # str_2 is not a valid number, should return unchanged
    str_2 = '1+2'
    assert safe_eval(str_2) == '1+2'

    # str_3 is a valid number, should get evaluated
    str_3 = '1+1'
    assert safe_eval(str_3) == 2

    # dict_0 is a dict, should

# Generated at 2022-06-25 12:33:57.973629
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 1 - test the use of builtin functions,
    # which should be disallowed.
    try:
        safe_eval('abs(1)')
        test_case_0()
    except SyntaxError:
        pass
    except Exception as e:
        if not isinstance(e, TypeError):
            test_case_0()

    # Test case 2 - test the use of non-builtin functions,
    # which should be allowed.
    safe_eval('foo(1)', locals={'foo': lambda x: x ** 2})


    # Test case 3 - Test the disallowing of calls
    # to builtin function that could be dangerous
    # like `eval` or `open`.

# Generated at 2022-06-25 12:34:10.114046
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing safe_eval...')

    # Test case 0: simple value, constant int 0
    print('Test case 0')
    try:
        result = safe_eval("0")
        assert result == 0
        assert isinstance(result, int)
    except Exception as e:
        print("Test case 0 failed: {}".format(to_native(e)))

    # Test case 1: expression, two integers added
    print('Test case 1')
    try:
        result = safe_eval("1+1")
        assert result == 2
        assert isinstance(result, int)
    except Exception as e:
        print("Test case 1 failed: {}".format(to_native(e)))

    # Test case 2: binary operation, two constant integers and an operator
    print('Test case 2')

# Generated at 2022-06-25 12:34:18.857857
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    eval_int = safe_eval('0')
    assert isinstance(eval_int, int)
    assert eval_int == 0
    eval_bool = safe_eval('true')
    assert eval_bool is True
    eval_bool = safe_eval('false')
    assert eval_bool is False
    eval_none = safe_eval('null')
    assert eval_none is None
    eval_str = safe_eval('ansible')
    assert isinstance(eval_str, str)
    assert eval_str == 'ansible'
    eval_str = safe_eval('"ansible"')
    assert isinstance(eval_str, str)
    assert eval_str == 'ansible'
    eval_list = safe_eval('["ansible", "simple", "uncomplicated"]')

# Generated at 2022-06-25 12:34:30.127178
# Unit test for function safe_eval
def test_safe_eval():

    # test 0:
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('false') == False
    assert safe_eval('true') == True
    assert safe_eval('null') == None
    assert safe_eval('False and true') == False
    assert safe_eval('true and False') == False
    assert safe_eval('None or False') == False
    assert safe_eval('False or None') == None
    assert safe_eval('false or True') == True
    assert safe_eval('null and False') == False
    assert safe_eval('True or null') == True
    assert safe_eval('true or none') == True
    assert safe_eval('3') == 3
    assert safe_eval('3 - 1 + 4')

# Generated at 2022-06-25 12:34:39.013532
# Unit test for function safe_eval
def test_safe_eval():
    # To make sure the pytest use the right python version
    assert(sys.version_info >= (3,0))

    # Verify that a simple safe expression is executed successfully
    result = safe_eval('1 + 2')
    assert(result == 3)

    # Verify that a safe expression is executed successfully
    result = safe_eval('1 + 2 * 3')
    assert(result == 7)

    # Verify that an expression with a built-in function is executed successfully
    result = safe_eval('len([1,2,3])')
    assert(result == 3)

    # verify that an expression with a simple function is executed successfully
    result = safe_eval('max([1,2,3])')
    assert(result == 3)

    # verify that an expression with a built-in function is executed successfully

# Generated at 2022-06-25 12:34:48.618823
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 == 2') == True
    assert safe_eval('1 + "A" == "1A"') == True
    assert safe_eval('"1" == 1') == False
    assert safe_eval('"A" + 1') == "A1"
    assert safe_eval('"A" + "B"') == "AB"
    assert safe_eval('1 == True') == False
    assert safe_eval('1 != True') == True
    assert safe_eval('1 is True') == False
    assert safe_eval('1 is not True') == True
    assert safe_eval('True or False') == True
    assert safe_eval('True and False') == False

# Generated at 2022-06-25 12:34:54.597669
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:03.889017
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval("1")
    safe_eval("1 + 1")
    safe_eval("'this is a string'")
    safe_eval("'this is a string' + ' and concatenated'")
    safe_eval("5 / 2")
    safe_eval("5.0 / 2")
    safe_eval("True")
    safe_eval("True and False")
    safe_eval("True or False")
    safe_eval("[1, 2, 3]")
    safe_eval("[1, 2, 3] + [4, 5, 6]")
    safe_eval("[1, 2, 3] * 2")
    safe_eval("(1, 2, 3)")
    safe_eval("(1, 2, 3) + (4, 5, 6)")

# Generated at 2022-06-25 12:35:13.639207
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ [1,2,3] }}") == [1,2,3]
    assert safe_eval("{{ [1,2,3] }}").__class__ == builtins.list
    assert safe_eval("[1,foo]") == [1, 'foo']
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}
    assert safe_eval("{'key': 'value'}").__class__ == builtins.dict

    assert safe_eval("{{ (1, 2, 3) }}") == (1, 2, 3)
    assert safe_eval("(1, foo)") == (1, 'foo')

    assert safe_eval("{{ 1 + 10 }}") == 11
    assert safe_eval("{{ 1 * 10 }}") == 10
    assert safe_eval

# Generated at 2022-06-25 12:35:18.522667
# Unit test for function safe_eval

# Generated at 2022-06-25 12:35:37.006521
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(sys._getframe().f_code.co_name) == 0

    assert safe_eval('a_list_variable') == 'a_list_variable'

    assert safe_eval('a_list_variable', dict(a_list_variable=[])) == []
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('[a_list_variable, a_dict_variable, a_string_variable, 1, 2, 3]', dict(
        a_list_variable=[],
        a_dict_variable={},
        a_string_variable='test',
    )) == [[], {}, 'test', 1, 2, 3]
    assert safe_eval

# Generated at 2022-06-25 12:35:43.530438
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('1 + 2') == 1 + 2
    assert safe_eval('-3') == -3
    assert safe_eval('-3 * -3') == 9
    assert safe_eval('+6') == 6
    assert safe_eval('false') == False
    assert safe_eval('true') == True
    assert safe_eval('null') == None
    assert safe_eval('true and false') == False
    assert safe_eval('true or false') == True
    assert safe_eval('true and not false') == True
    assert safe_eval('true or not false') == True
    assert safe_eval('true and true') == True
    assert safe_eval('false or false') == False
    assert safe_eval('3 > 2') == True

# Generated at 2022-06-25 12:35:48.171679
# Unit test for function safe_eval
def test_safe_eval():
    #load all the modules we will call into later
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ########################################################
    # Units tests for safe_eval
    ########################################################

# Generated at 2022-06-25 12:35:56.367584
# Unit test for function safe_eval
def test_safe_eval():
    err = 0
    expr = '1 + 2 + 3'

    try:
        safe_eval(expr)
    except Exception as e:
        print("fail: got exception for valid expression: '%s'" % expr, file=sys.stderr)
        raise e

    expr = '1 + 2 +'

    try:
        safe_eval(expr)
        err += 1
        print("fail: expected exception for invalid expression: '%s'" % expr, file=sys.stderr)
    except Exception:
        pass

    if err == 0:
        print("%s: passed - no errors" % __file__, file=sys.stderr)


# Generated at 2022-06-25 12:36:06.242407
# Unit test for function safe_eval
def test_safe_eval():
    # Test a simple expression including integer and string
    assert safe_eval("item_x[0] + '_test'") == 'item_x[0] + \'_test\''
    assert safe_eval("'a' + 'b'") == "'a' + 'b'"
    assert safe_eval("item_x[0] + '_test'", {'item_x[0]': 'a'}) == 'a_test'
    assert safe_eval("'a' + 'b'", {'item_x[0]': 'a'}) == 'ab'
    print("test_safe_eval: test a simple expression including integer and string passed")

    # Test list
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-25 12:36:11.738872
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:21.496310
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_KEEP_REMOTE_FILES is False:
        # true test

        # valid constants
        assert safe_eval("0") == 0
        assert safe_eval("true") is True
        assert safe_eval("TRUE") is True
        assert safe_eval("null") is None
        assert safe_eval("none") is None
        assert safe_eval("false") is False
        assert safe_eval("False") is False
        assert safe_eval("[0]") == [0]
        assert safe_eval("{\"a\": 0}") == {"a": 0}
        assert safe_eval("{\"a\": [0,1]}") == {"a": [0, 1]}
        assert safe_eval("None") is None
        assert safe_eval("true") is True

# Generated at 2022-06-25 12:36:31.185484
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:41.297335
# Unit test for function safe_eval
def test_safe_eval():

    # Evaluate a simple arithmetic expr
    x = safe_eval('1+1')
    assert x == 2

    # Evaluate a boolean expr
    x = safe_eval('False or True')
    assert x == True

    # Evaluate a test_case with a string
    x = safe_eval('"Hello"')
    assert x == "Hello"

    # Evaluate a test_case with a list
    x = safe_eval('[1,2,3]')
    assert x == [1, 2, 3]

    # Evaluate a test_case with a dictionary
    x = safe_eval('{"a":1,"b":2}')
    assert x == {"a":1,"b":2}

    # Evaluate a test_case with a call

# Generated at 2022-06-25 12:36:49.002545
# Unit test for function safe_eval

# Generated at 2022-06-25 12:36:57.871322
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:37:02.046555
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    print(safe_eval('{"a": 1}'))
    print(safe_eval('["a", "b", "c"]'))
    print(safe_eval("a_list_var"))



# Generated at 2022-06-25 12:37:12.566722
# Unit test for function safe_eval
def test_safe_eval():
    # Don't change value of variables used in these tests
    str_0 = 'io_buffer_size'
    str_1 = '-1'
    str_2 = '1 | 2'
    str_3 = 'io_buffer_size - 1'

    str_val = safe_eval(str_0)
    if not isinstance(str_val, str):
        print('safe_eval: string test failed')
        sys.exit(1)

    int_val = safe_eval(str_1)
    if not isinstance(int_val, int):
        print('safe_eval: integer test failed')
        sys.exit(1)
    if int_val != -1:
        print('safe_eval: integer value test failed')
        sys.exit(1)


# Generated at 2022-06-25 12:37:21.639920
# Unit test for function safe_eval

# Generated at 2022-06-25 12:37:31.405917
# Unit test for function safe_eval
def test_safe_eval():
    # Init default Ansible options
    C.config = C.Config()
    C.config.parse()

    # Expected result of parsed
    correct_parsed = 'io_buffer_size'

    # Expected result of call_str
    correct_call_str = 'C.config.get("io_buffer_size")'

    # Generated result from parsed string
    parsed = safe_eval(safe_eval(correct_parsed))

    # Generated result from call str
    call_str = safe_eval(correct_call_str)

    # Checker
    assert parsed == correct_parsed
    assert call_str == C.CONFIG.get("io_buffer_size")


# Generated at 2022-06-25 12:37:34.864457
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('False') == False
    # assert safe_eval("file_recurse('/var/tmp')") == "/var/tmp"



# Generated at 2022-06-25 12:37:38.081803
# Unit test for function safe_eval
def test_safe_eval():
    print('Running test 1')
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e.message))
        raise


if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-25 12:37:45.544347
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'ex__.copy() | selectattr("writable", "truthy")'
    # Test 1
    assert safe_eval(expr) is None

    # Test 2
    expr = 'true'
    assert safe_eval(expr)

    # Test 3
    expr = '"1"'
    assert safe_eval(expr) == '1'

    # Test 4
    expr = '0'
    assert safe_eval(expr) == 0

    # Test 5
    expr = 'false'
    assert not safe_eval(expr)

    # Test 6
    expr = 'ex__.copy() | selectattr("writable", "truthy") | list'
    assert safe_eval(expr) is None

    # Test 7: Invalid callable
    expr = 'say_hello'
    assert safe_eval(expr) is None



# Generated at 2022-06-25 12:37:56.991206
# Unit test for function safe_eval
def test_safe_eval():
    # test "localhost"
    res = safe_eval("localhost")
    assert res == "localhost"

    # test "ansible_lsb["major"]"
    res = safe_eval("ansible_lsb['major']")
    assert res == "'major'"

    # test "ansible_lsb.major"
    res = safe_eval("ansible_lsb.major")
    assert res == ".major"

    # test "1+1"
    res = safe_eval("1+1")
    assert res == 2

    # test "1+1.0"
    res = safe_eval("1+1.0")
    assert res == 2.0

    # test "1.0+1"
    res = safe_eval("1.0+1")
    assert res == 2.0

    # test "True

# Generated at 2022-06-25 12:38:02.421995
# Unit test for function safe_eval
def test_safe_eval():
    # 1.Test 'io_buffer_size'
    str_0 = 'io_buffer_size'
    var_0 = safe_eval(str_0, str_0)
    assert var_0 == 'io_buffer_size'

    # 2.Test '| some_handler'
    str_0 = '| some_handler'
    var_0 = safe_eval(str_0, str_0)
    assert var_0 == '| some_handler'

    # 3.Test '"var_name"'
    str_0 = '"var_name"'
    var_0 = safe_eval(str_0, str_0)
    assert var_0 == "var_name"

    # 4.Test '1'
    str_0 = '1'

# Generated at 2022-06-25 12:38:43.828836
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test to verify the safe_eval function
    '''
    items = ['item', 'item1', 'item2', 'item3', 'item4', 'item5']
    items_str = ' '.join(items)
    items_str = items_str.encode('utf-8')

    # TODO: Follow-up on this, or remove it?
    items_str = "['item1', 'item2', 'item3', 'item4', 'item5']"
    items_str = "[u'item1', u'item2', u'item3', u'item4', u'item5']"

    # Check that safe_eval raises exception when an invalid expression is passed
    with pytest.raises(Exception) as excinfo:
        safe_eval('a + b; import os')
    expected_err

# Generated at 2022-06-25 12:38:44.966673
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Main function to run test

# Generated at 2022-06-25 12:38:45.778058
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-25 12:38:52.360378
# Unit test for function safe_eval
def test_safe_eval():
    res = safe_eval("my_var")
    assert res.__class__ == builtins.str, 'Failed to handle a string variable'

    res = safe_eval('"my_var"')
    assert res.__class__ == builtins.str, 'Failed to handle a string variable'

    res = safe_eval('["my_var"]')
    assert res.__class__ == builtins.list, 'Failed to handle a string variable'

    res = safe_eval('{"my_var": "foo"}')
    assert res.__class__ == builtins.dict, 'Failed to handle a string variable'

    res = safe_eval('{"my_var": ["foo"]}')
    assert res.__class__ == builtins.dict, 'Failed to handle a string variable'


# Generated at 2022-06-25 12:38:56.651496
# Unit test for function safe_eval
def test_safe_eval():
    try:
        if sys.version_info >= (2, 7):
            test_case_0()
    except Exception as e:
        print("test_safe_eval: Caught exception: " + str(e))
        raise



# ===========================================
# Module execution.
#


# Generated at 2022-06-25 12:39:01.171772
# Unit test for function safe_eval
def test_safe_eval():
    assert test_case_0() == 'io_buffer_size'



# Generated at 2022-06-25 12:39:01.803804
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()

# Generated at 2022-06-25 12:39:07.317663
# Unit test for function safe_eval
def test_safe_eval():
    condition = '1'
    iterable = ['1', '2', '3']
    result = safe_eval(condition)
    if result == 1:
        print('safe_eval() test case 0 passes.')
    else:
        print('safe_eval() test case 0 fails.')
    result = safe_eval(iterable)
    if result == ['1', '2', '3']:
        print('safe_eval() test case 1 passes.')
    else:
        print('safe_eval() test case 1 fails.')
    return


# Generated at 2022-06-25 12:39:12.151304
# Unit test for function safe_eval
def test_safe_eval():
    e = None
    var = safe_eval("1 == 1", include_exceptions=True)
    assert var[0]
    safe_eval("1 == 1")
    try:
        safe_eval("1 == 2")
    except Exception as ex:
        e = ex
    assert e is not None
    var = safe_eval("[1, 2, 3]", include_exceptions=True)
    assert var[0] == [1, 2, 3]
    print("safe_eval: success")

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-25 12:39:12.930790
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()
    test_case_1()
