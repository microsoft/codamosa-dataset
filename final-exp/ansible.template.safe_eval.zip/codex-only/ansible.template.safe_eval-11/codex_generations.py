

# Generated at 2022-06-23 13:22:56.711941
# Unit test for function safe_eval
def test_safe_eval():

    def _test(expr, exception=False, result=None, locals=None):
        r, e = safe_eval(expr, locals, include_exceptions=True)
        assert C.jsonify(r) == C.jsonify(result), "Failed for '%s': Expected '%s', got  '%s'.\nException = %s" % (expr, result, r, e)

    def _test_bad(expr, locals=None):
        try:
            result = safe_eval(expr, locals)
            assert False, "Test succeeded when it should have failed: %s --> %s" % (expr, result)
        except Exception as e:
            pass

    _test("1 + 1 == 2")
    _test("1 + 1 == 2", result=True)


# Generated at 2022-06-23 13:23:08.662667
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid values
    # Data types
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("None") is None
    assert safe_eval("123") == 123
    assert safe_eval("'example'") == 'example'
    assert safe_eval("['a','b','c']") == ['a','b','c']
    assert safe_eval("('a','b','c')") == ('a','b','c')
    assert safe_eval("['a','b','c'] + ['d','e','f']") == ['a','b','c','d','e','f']
    assert safe_eval("('a','b','c') + ('d','e','f')") == ('a','b','c','d','e','f')

# Generated at 2022-06-23 13:23:18.901487
# Unit test for function safe_eval
def test_safe_eval():
    """
    >>> test_safe_eval()
    True
    """

# Generated at 2022-06-23 13:23:29.511868
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:37.574007
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:48.958028
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('ansible_distribution + ansible_distribution_version') == 'None+None'
    assert safe_eval('ansible_distribution + 1', dict(ansible_distribution='bogus')) == 'bogus+1'
    assert safe_eval('a_list', dict(a_list=['bogus', 'bogus'])) == ['bogus', 'bogus']
    assert safe_eval('a_dict', dict(a_dict={'bogus': 'bogus'})) == dict(bogus='bogus')
    assert safe_eval('a_string', dict(a_string='bogus string')) == 'bogus string'

# Generated at 2022-06-23 13:23:58.230687
# Unit test for function safe_eval
def test_safe_eval():
    """Runs a series of test cases to verify the functionality of the safe_eval() function"""
    # Import the unit test module
    import unittest

    # List of test cases
    # Each test case is represented by a tuple containing three items:
    #    (1) The expression to evaluate
    #    (2) The expected output of the expression
    #    (3) A tuple of exceptions that are expected to occur (if any)
    # Note: All test cases below will be successful

# Generated at 2022-06-23 13:24:05.469233
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:14.883793
# Unit test for function safe_eval
def test_safe_eval():
    # Normal expressions
    assert safe_eval("4 + 5") == 9
    assert safe_eval("4 + 5", include_exceptions=True) == (9, None)
    assert safe_eval("4 + 5 > 1 + 3") == True
    assert safe_eval("(4 + 5) * 3") == 27

    # We do not allow function calls
    assert safe_eval("abs(-1)") == "abs(-1)"
    assert safe_eval("abs(-1)", include_exceptions=True) == ("abs(-1)", None)

    # We allow list, tuples and dicts
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{ 'foo': 'bar' }") == { 'foo': 'bar' }

# Generated at 2022-06-23 13:24:26.678657
# Unit test for function safe_eval
def test_safe_eval():
    # Replacement for ansible.module_utils.basic.AnsibleModule.exit_json()
    # (since we can't import this)
    def exit_json(x, **kwargs):
        # print(x)
        pass
    # Replacement for ansible.module_utils.basic.AnsibleModule.fail_json()
    # (since we can't import this)
    def fail_json(msg):
        raise Exception(msg)

    if len(sys.argv) < 2:
        exit_json({'msg': 'missing eval expression to test'})

    try:
        result = safe_eval(sys.argv[1])
    except Exception as e:
        fail_json('eval error: %s' % to_native(e))

    exit_json({'result': container_to_text(result)})

# Generated at 2022-06-23 13:24:32.962167
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid expressions
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('foo == "bar"') is False
    assert safe_eval('foo in ["foo", "bar"]') is False

    # Test invalid expressions
    try:
        safe_eval('__import__("os").listdir()')
    except:
        pass
    else:
        raise Exception(safe_eval.__name__ + " did not raise an exception")

    # Test invalid expressions with include_exceptions=True
    expr, exc = safe_eval('__import__("os").listdir()', include_exceptions=True)
    assert expr == '__import__("os").listdir()'

# Generated at 2022-06-23 13:24:42.014674
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:50.604082
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval"""
    # 100% coverage for the control structure of the function
    expr = '[x for x in a]'
    safe_eval(expr)
    expr = '[x for x in a] and True'
    safe_eval(expr)
    expr = 'not [x for x in a]'
    safe_eval(expr)
    expr = 'not [x for x in a] or True'
    safe_eval(expr)

    # test with an exception
    expr = 'not a_list_variable'
    (result, exception) = safe_eval(expr, include_exceptions=True)
    assert result == 'not a_list_variable'
    assert exception.__class__.__name__ == 'NameError'
    assert 'name ' in str(exception)

# Generated at 2022-06-23 13:24:59.558240
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:10.505275
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('[foo, bar]', {'foo': 1, 'bar': 2}) == [1, 2]
    assert safe_eval('[foo]', {'foo': [1, 2, 3]}) == [[1, 2, 3]]
    assert safe_eval('foo[1]', {'foo': [1, 2, 3]}) == 2
    assert safe_eval('{foo: bar}', {'foo': 'x', 'bar': 123}) == {'x': 123}
    assert safe_eval('True', {}, include_exceptions=True) == (True, None)
    assert safe_eval('True', {'True': 'yes'}) == 'yes'

# Generated at 2022-06-23 13:25:19.848147
# Unit test for function safe_eval
def test_safe_eval():

    from ansible.utils import template

    # cannot test on all types, so let's just test the ones that are used
    # in the module/action plugins
    for test in [
        "a.replace('b', 'c')",
        "a | b",
        "a + b",
        "a[0]",
        "[a]",
        "{0: a}",
    ]:
        assert safe_eval(test, dict(a='foo', b='bar')) == template.template(test, dict(a='foo', b='bar'))

    # test boolean expressions

# Generated at 2022-06-23 13:25:30.073883
# Unit test for function safe_eval
def test_safe_eval():
    import os

    # bogus expressions and the error message they should generate

# Generated at 2022-06-23 13:25:39.775467
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run tests on the safe_eval function.
    '''
    import unittest
    import json
    import textwrap

    class SafeEvalTestCase(unittest.TestCase):
        def test_disable_builtins(self):
            # Test that default safe_eval() disables built-in functions
            for function_name in ('split', 'basestring', 'object', 'list', 'dict', 'len'):
                self.assertRaises(Exception, safe_eval, "%s('foo', 'bar')" % function_name)

            # Test that safe_eval with builtins enabled does not disable built-in functions

# Generated at 2022-06-23 13:25:47.420190
# Unit test for function safe_eval
def test_safe_eval():
    """Ensure that safe_eval returns what is expected"""
    # basic types
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('None') == [None]
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {'a':1, 'b':2, 'c':3}
    assert safe_eval('dict(a=1, b=2, c=3)') == {'a':1, 'b':2, 'c':3}
    assert safe_eval('tuple(a=1, b=2, c=3)') == (1, 2, 3)

    # strings

# Generated at 2022-06-23 13:25:57.389567
# Unit test for function safe_eval
def test_safe_eval():
    # should fail
    expr = 'a + b + [1,2,3] + {"a": "b"}'
    val, exc = safe_eval(expr, include_exceptions=True)
    # (a + b + [1,2,3] + {"a": "b"}, None)
    assert val == expr
    assert exc is None

    expr = '1 + 2 + "foo"'
    val, exc = safe_eval(expr, include_exceptions=True)
    # (1 + 2 + "foo", None)
    assert val == expr
    assert exc is None

    expr = '1 + {1: 2}'
    val, exc = safe_eval(expr, include_exceptions=True)
    # (1 + {1:2}, None)
    assert val == expr
    assert exc is None

    expr

# Generated at 2022-06-23 13:26:08.562587
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval with a valid expression
    test = safe_eval('1 + 1')
    assert test == 2

    # test safe_eval with an invalid expression
    test = safe_eval('_ + _')
    assert test == '_ + _'

    # test safe_eval with a dict
    test = safe_eval('{"a": "b"}')
    assert test == {u'a': u'b'}

    # test safe_eval with a list
    test = safe_eval('[1, 2, 3]')
    assert test == [1, 2, 3]

    # test safe_eval with a string
    test = safe_eval('foo')
    assert test == 'foo'

    # test safe_eval with a False value
    test = safe_eval('false')
    assert test == False

    # test safe

# Generated at 2022-06-23 13:26:19.372021
# Unit test for function safe_eval
def test_safe_eval():
    # Test that only dict and list can be used for defaults
    for default in [dict(), list(), set(), u"foo bar"]:
        result = safe_eval(default)
        assert result == default

    # Test that the empty dict is the same as no dict
    assert safe_eval({}) == {}

    for bad_value in ['[]', '{}', 'list()', 'dict()']:
        if sys.version_info >= (3,):
            # Python3 has no types module
            bad_value = bad_value.replace("types.", "")
        try:
            safe_eval(bad_value)
            assert False, 'This should have failed'
        except Exception:
            pass

    # Test that simple string literals are supported
    assert safe_eval("string") == u"string"

# Generated at 2022-06-23 13:26:31.723668
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("['foo','bar','baz']") == ['foo','bar','baz']
    assert safe_eval("{'foo': 5, 'bar': [1,2,3]}") == {'foo': 5, 'bar': [1,2,3]}
    assert safe_eval("a == 'b' or c == 'd'") == "a == 'b' or c == 'd'"
    assert safe_eval("a == 'b' or c == 'd'", dict(a='b')) == True
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar", dict(foo=dict(bar='baz'))) == "baz"
    assert safe_eval("foo == 1", dict(foo=0)) == False

# Generated at 2022-06-23 13:26:42.889723
# Unit test for function safe_eval
def test_safe_eval():

    # these are included by intention
    SAFE_EXPR = {
        '{ foo: [1,2,3], bar: { baz: qux } }',
        'foo in bar',
        '{1:{2:[31,32,33]}, 2:{4:44,5:55,6:66}}',
        '1 + 2 + 3',
        '1 - 2 - 3',
        '1 * 2 * 3',
        '1 / 2 / 3',
        '1 // 2 // 3',
        '1 in [1, 2, 3]',
        '"foo"',
        '1 < 2 > 3',
        'len([1,2,3])',
        '[]',
    }

    # these are not

# Generated at 2022-06-23 13:26:52.605190
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('[1, 2] + [3, 4]') == [1, 2, 3, 4]
    assert safe_eval('{"a": 1}') == {'a': 1}
    assert safe_eval('1 in [1, 2, 3]') is True
    assert safe_eval('1 not in [1, 2, 3]') is False
    assert safe_eval('True and True') is True
    assert safe_eval('False and True') is False
    assert safe_eval('True or False') is True
    assert safe_eval('False or False') is False

    # Simple

# Generated at 2022-06-23 13:27:03.634523
# Unit test for function safe_eval
def test_safe_eval():

    old_ansible_python_interpreter = C.DEFAULT_PYTHON_INTERPRETER
    old_ansible_python_interpreter_flag = sys.flags.ignore_environment
    sys.flags.ignore_environment = True
    C.DEFAULT_PYTHON_INTERPRETER = '/bin/false'

    fails = 0
    # test some basic expressions

# Generated at 2022-06-23 13:27:14.238644
# Unit test for function safe_eval
def test_safe_eval():
    # Test true and false as word, with and without quotes
    expr = "true"
    result = safe_eval(expr)
    assert result is True
    expr = "'true'"
    result = safe_eval(expr)
    assert result == "true"
    expr = "false"
    result = safe_eval(expr)
    assert result is False
    expr = "'false'"
    result = safe_eval(expr)
    assert result == "false"

    # Test true and false as lowercase
    expr = "True"
    result = safe_eval(expr)
    assert result is True
    expr = "'True'"
    result = safe_eval(expr)
    assert result == "True"
    expr = "False"
    result = safe_eval(expr)
    assert result is False
    expr = "'False'"
   

# Generated at 2022-06-23 13:27:24.314788
# Unit test for function safe_eval
def test_safe_eval():
    # these are safe and should return results
    assert safe_eval('True') is True
    assert safe_eval('1') == 1
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar.baz') == "foo.bar.baz"
    # with_items: a_list_variable
    assert safe_eval('a_list_variable') == "a_list_variable"
    # these are unsafe and should raise an exception
    # from ansible.module_utils.six import iteritems
    # iteritems()


# Generated at 2022-06-23 13:27:30.756813
# Unit test for function safe_eval
def test_safe_eval():

    # success cases
    assert safe_eval('[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval('[1,2,3,4]*4') == [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]
    assert safe_eval('(1,2,3,4)*4') == (1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4)
    assert safe_eval('{"a":1, "b":2}') == {"a": 1, "b": 2}

# Generated at 2022-06-23 13:27:40.009199
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic safe evals with no builtins
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1==2") is True
    assert safe_eval("'str'") == 'str'
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("['a', 'b', 'c'][1]") == 'b'
    assert safe_eval("['a', 'b', 'c'][1:2]") == ['b']
    assert safe_eval("{'a': 1, 'b': 2, 'c': 3}") == {'a': 1, 'b': 2, 'c': 3}
    assert safe_eval("1+1", include_exceptions = True) == (2, None)

# Generated at 2022-06-23 13:27:50.282145
# Unit test for function safe_eval
def test_safe_eval():
    # Does not show NULL flag in conversion to string
    assert 'false' == str(safe_eval("false"))
    assert 'true' == str(safe_eval("true"))
    assert 'true' == str(safe_eval("true"))
    assert 'null' == str(safe_eval("null"))
    assert 'null' == str(safe_eval("None"))

    # Shows NULL flag in conversion to string
    assert 'None' == container_to_text(safe_eval("null"), False, True)
    assert 'None' == container_to_text(safe_eval("None"), False, True)
    assert 'null' == container_to_text(safe_eval("null"), False, True)
    assert 'None' == container_to_text(safe_eval("None"), False, True)

    # Booleans converted to their boolean representation


# Generated at 2022-06-23 13:28:01.190121
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:09.294710
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:19.335267
# Unit test for function safe_eval
def test_safe_eval():

    # call the C implementation of boolean type
    t = C.mk_boolean(True)
    assert t is True

    t = C.mk_boolean(False)
    assert t is False

    t = C.mk_boolean('yes')
    assert t is True

    t = C.mk_boolean('no')
    assert t is False

    t = C.mk_boolean(1)
    assert t is True

    t = C.mk_boolean(0)
    assert t is False

    t = C.mk_boolean('on')
    assert t is True

    t = C.mk_boolean('off')
    assert t is False

    t = C.mk_boolean('true')
    assert t is True

    t = C.mk_boolean('false')
    assert t is False

# Generated at 2022-06-23 13:28:30.783106
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: this was a quick and dirty first test. More tests are needed
    ansible_vars = dict(foo='bar', bam=42, stuff={'a': 5})

# Generated at 2022-06-23 13:28:42.349451
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This tests safe_eval for a bunch of basic things to ensure
    we do not regress in the future.  Include more as needed.
    '''
    my_vars = dict(
        foo=True,
        bar=[1,2,3]
    )

    def eval_test(expr, result):
        if isinstance(result, bool):
            return safe_eval(expr, vars=my_vars) == result
        else:
            return safe_eval(expr, vars=my_vars) == result

    assert eval_test("foo", True)
    assert eval_test("foo or False", True)
    assert eval_test("not foo or True", True)
    assert eval_test("not (foo or False)", False)
    assert eval_test("bar", [1,2,3])


# Generated at 2022-06-23 13:28:49.358289
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:58.737315
# Unit test for function safe_eval
def test_safe_eval():
    # a dict with a dict, a number, a string, a list, and a key with a dash
    safe = "{'a': 1, 'b': 'some string', 'c': [1,2,3], 'd': {'x': 'y'}, 'e-f': 1}"
    # an empty dict
    safe2 = "{}"
    # an empty list
    safe3 = "[]"

    # a function call
    evil = "{ 'a': [ func() for a in range(0, 10) ] }"

    # a multiline complex statement, with a string and a number
    evil2 = r'''
{'a': 'lala',
 'b': 1,
 'c': [1,2,3],
 'd': {'x': 'y'},
 'e-f': 1
}
'''

   

# Generated at 2022-06-23 13:29:10.590153
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic operations
    assert safe_eval("a + b", dict(a=1, b=2)) == 3
    assert safe_eval("a + 2", dict(a=1)) == 3
    assert safe_eval("a*b + b*c + a*c", dict(a=1, b=2, c=3)) == 12
    assert safe_eval("a and b or c", dict(a=1, b=2, c=3)) == 2
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("[1, 2]") == [1, 2]
   

# Generated at 2022-06-23 13:29:19.253652
# Unit test for function safe_eval
def test_safe_eval():
    # Expected to pass
    safe_eval("a_dict['test']")
    safe_eval("a_dict['test']['foo']")
    safe_eval("[1, 2, 3]")
    safe_eval("{'key': 'value'}")
    safe_eval("[1, 2, 3, {'a': 'b', 'c': 'd', 'e': [1, 2, 3]}]")
    safe_eval("['test', 'value']")
    safe_eval("'test'")
    safe_eval("1+2")
    safe_eval("'x' if True else 'y'")
    safe_eval("[value for value in my_list if value > 0]")
    safe_eval("['%s' % x for x in my_list]")

# Generated at 2022-06-23 13:29:27.723276
# Unit test for function safe_eval
def test_safe_eval():
    # valid expressions
    assert safe_eval("1") == 1
    assert safe_eval("1+1") == 2
    assert safe_eval("[ 'foo', 'bar', (1, 2, 3) ]") == ['foo', 'bar', (1, 2, 3)]
    assert safe_eval("{ 'a': 'b' }") == {'a': 'b'}
    assert safe_eval("1 + 1 == 2") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("[ 1, 2 ] in [ [ 1, 2 ], [ 3 ] ]") is True

# Generated at 2022-06-23 13:29:37.980182
# Unit test for function safe_eval
def test_safe_eval():
    # 1. Simple expression
    result, err = safe_eval("(1+2)*3 + 4", include_exceptions=True)
    assert result == 13
    assert err is None
    result = safe_eval("(1+2)*3 + 4")
    assert result == 13

    # 2. Callable
    result, err = safe_eval("a_var.replace('a', 'b')", dict(a_var='abc'), include_exceptions=True)
    assert result == 'bbc'
    assert err is None
    result = safe_eval("a_var.replace('a', 'b')", dict(a_var='abc'))
    assert result == 'bbc'

    # 3. Unsafe expression

# Generated at 2022-06-23 13:29:44.130769
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr):
        # Equivalent to:
        #    try:
        #        safe_eval(expr)
        #        return True
        #    except:
        #        return False
        return safe_eval(expr, include_exceptions=True)[1] is None

    # Builtins now filtered
    assert not test('__import__("os").remove("/etc/nologin")')

    # Never allow executing code objects
    assert not test('__import__("os").__dict__.keys()')

    # Verify we are not allowing safe builtin functions by accident
    assert not test('None()')

    # Verify we are not allowing calls to objects that happen to have __call__ defined
    assert not test('set()')

    # Check that we are allowing objects with __call__ defined only where explicitly enabled
    CALL_ENABLED

# Generated at 2022-06-23 13:29:56.121387
# Unit test for function safe_eval
def test_safe_eval():
    # No exceptions
    assert safe_eval("1+1") == 1+1
    assert safe_eval("'1'+'1'") == '11'
    assert safe_eval("['a','b','c']") == ['a','b','c']
    assert safe_eval("{'a': 1, 'b': 'c'}") == {'a': 1, 'b': 'c'}
    assert safe_eval("(1,2,3)") == (1,2,3)
    b = True
    assert safe_eval("True and b") == True and b

    # Exceptions are raised
    try:
        safe_eval("a + b")
    except Exception as e:
        assert isinstance(e, Exception)


# Generated at 2022-06-23 13:30:08.801320
# Unit test for function safe_eval
def test_safe_eval():
    item = 'foo'

    assert safe_eval(item) == 'foo'
    assert safe_eval(item, {'item': 'nope'}) == 'foo'
    assert safe_eval(item, {'foo': 'nope'}) == 'nope'
    assert safe_eval('foo + 1', include_exceptions=True) == ('foo + 1', None)
    assert safe_eval('container_to_text(foo)', include_exceptions=True) == ('container_to_text(foo)', None)
    assert safe_eval('foo + 1') == 2
    assert safe_eval('foo + 1', {'foo': 2}) == 3
    assert safe_eval('foo + 1', {'foo': [2]}) == 'foo + 1'

# Generated at 2022-06-23 13:30:20.209273
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_DEBUG:
        print("TESTING safe_eval.")

    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{ "foo": "bar" }') == {'foo': 'bar'}

    try:
        safe_eval('__builtins__')
        assert False, '__builtins__ did not raise error'
    except Exception:
        assert True

    try:
        safe_eval('int("2")')
        assert False, 'int function did not raise error'
    except Exception:
        assert True

    # exceptions should be empty for successful evals
    result, exception = safe_eval('1 + 1', include_exceptions=True)
    assert result == 2
    assert exception

# Generated at 2022-06-23 13:30:27.273018
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{ a + b }}"
    locals = dict(a=1, b=2)
    result = safe_eval(expr, locals=locals)
    assert result == 3

    expr = "{{ a + b }}"
    locals = None
    result = safe_eval(expr, locals=locals)
    assert result == expr

    expr = "{{ _a + b }}"
    locals = dict(a=1, b=2)
    result = safe_eval(expr, locals=locals)
    assert result == expr

    expr = "{{ 1+2 }}"
    locals = dict(a=1, b=2)
    result = safe_eval(expr, locals=locals)
    assert result == 3

    expr = "{{ true and false }}"
    locals = None

# Generated at 2022-06-23 13:30:35.065675
# Unit test for function safe_eval
def test_safe_eval():
    for x in [
        ('1 + 1', 2),
        ('2 * 3', 6),
        ('len("ansible")', 7),
        ('"a" + "b"', 'ab'),
        ('["a", "b"]', ['a', 'b']),
        ('["a", "b", "{{ invalid }}"]', ['a', 'b', '{{ invalid }}']),
    ]:
        test, value = x
        assert safe_eval(test) == value, 'Failed to evaluate expression "%s" properly.' % test

    # Make sure the following expressions raise the appropriate exceptions
    bad_expressions = [
        'len(invalid_var)',
        'open("/etc/passwd")',
        '1 + "string"',
        '["a", "b", "{{ invalid }}"]'
    ]


# Generated at 2022-06-23 13:30:45.797324
# Unit test for function safe_eval
def test_safe_eval():
    global CALL_ENABLED

    # Allowed expressions
    CALL_ENABLED = ['abs', 'dict', 'list', 'min', 'max']
    assert safe_eval('ansible_facts["distribution"]') == "UnsupportedOS"
    assert safe_eval('len(foo_bar) > 2') is True
    assert safe_eval('foo == 42') is False
    assert safe_eval('foo[1]') == "baz"
    assert safe_eval('[foo, bar]') == ["foo", "bar"]
    assert safe_eval('(foo, bar)') == ("foo", "bar")
    assert safe_eval('foo_bar') == ["a", "b", "c", "d", "e"]
    assert safe_eval('foo_bar.0') == "a"

# Generated at 2022-06-23 13:30:55.873572
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:06.435515
# Unit test for function safe_eval
def test_safe_eval():
    # Test that all safe_eval examples in the docs work as expected
    # Generate the test cases from the docs...
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    import re

    doc_str = safe_eval.__doc__
    test_cases = re.findall(r'\(.*?\)', doc_str)

    # ... and iterate through each one
    for case in test_cases:
        try:
            test_result, err = safe_eval(case, locals={'boolean': boolean}, include_exceptions=True)
        except Exception as e:
            # This should never happen.  If it does, let's see why
            test_result, err = None, e

# Generated at 2022-06-23 13:31:17.553569
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run unit tests for function safe_eval by calling it and comparing
    the result against expected results.
    '''

    def do_test(test_string, expected, raise_exception=False):
        result = safe_eval(test_string)
        if not raise_exception:
            assert result == expected, "expected '%s', got '%s' for safe_eval('%s')" % (expected, result, test_string)
        else:
            assert type(result) == type(expected), "expected '%s', got '%s' for safe_eval('%s')" % (expected, result, test_string)

    # Our allowed functions
    do_test('True', True)
    do_test('False', False)
    do_test('None', None)

# Generated at 2022-06-23 13:31:27.620416
# Unit test for function safe_eval
def test_safe_eval():
    # Case when expression is correct. We should pass
    assert safe_eval('1 + 2') == 3

    # Case when expression is incorrect. We should fail
    try:
        safe_eval('2 + + 2')
        assert False
    except Exception:
        assert True

    # Case when expression is a complex (list). We should pass
    assert safe_eval('[1, 2, 3, 4]') == [1, 2, 3, 4]

    # Case when expression is a complex (dict). We should pass
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}

    # Case when expression is a complex (dict with one value as a list). We should pass

# Generated at 2022-06-23 13:31:39.153879
# Unit test for function safe_eval
def test_safe_eval():

    # Test most of the accepted nodes
    # Note: ast.Call is excluded because we don't test it
    # Note: ast.Name is tested if it is used inside a call
    for node in (ast.Add, ast.BinOp, ast.Compare, ast.Constant,
                 ast.Dict, ast.Div, ast.Expression, ast.List,
                 ast.Load, ast.Mult, ast.Num, ast.Set, ast.Str,
                 ast.Sub, ast.USub, ast.Tuple, ast.UnaryOp):

        code = node(left=node(1), right=node(2))
        compiled = compile(code, '<test_safe_eval>', 'eval')
        assert eval(compiled) == eval(code)
        assert safe_eval(compiled) == eval(code)

    #

# Generated at 2022-06-23 13:31:47.139874
# Unit test for function safe_eval
def test_safe_eval():
    test_data = (
        "{{ 2 }}",
        "{{ [2, 3] }}",
        "[{{ 2 }}, {{ 3 }}]",
        "{'a':{{ 2 }},'b':{{ 3 }}}",
        "{{ {'a':{{ 2 }},'b':{{ 3 }}} }}",
        """{{
        { 'a' : { 'b' : { 'c' : 3 } } }
        }}""",
        "{{ a + b }}",
        "{{ [{'a': {'b': '{{c}}'}}] }}",
    )
    for data in test_data:
        result, exception = safe_eval(data, dict(a=1, b=1), include_exceptions=True)
        assert result == eval(data)


# Generated at 2022-06-23 13:31:58.993727
# Unit test for function safe_eval
def test_safe_eval():
    """ very simple test, subclasses could add more tests. """
    try:
        from ansible.utils import context_objects as co
        from ansible.template import Templar
        from ansible.module_utils.common._collections_compat import Mapping
        import ansible
    except ImportError:
        print('The test suite requires ansible to be installed')
        sys.exit(1)

    json_data = '{"a": 1, "b": "foo", "c": true, "d": false, "e": null, "f": []}'
    python_data = dict(a=1, b='foo', c=True, d=False, e=None, f=[])

# Generated at 2022-06-23 13:32:09.848725
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Note: Tests are not exhaustive
    :return:
    '''
    assert safe_eval('a + b', dict(a=10, b=50)) == 60
    assert safe_eval('a + b', dict(a=10, b=50), True)[0] == 60

    assert safe_eval('a + b', dict(a=10, b=50, __builtins__=dict(__import__=__import__))) == 60
    assert safe_eval('a + b', dict(a=10, b=50), True)[0] == 60

    assert safe_eval('a + b', dict(a=10, b=50, __builtins__=dict(__import__=__import__, open=open))) == 60

# Generated at 2022-06-23 13:32:16.634143
# Unit test for function safe_eval
def test_safe_eval():
    # setup the module args with a list
    s = "[1,2,3]"
    safe = safe_eval(s)
    assert isinstance(safe, (list, tuple)) and isinstance(safe[0], int)
    # setup the module args with a dict
    s = "{'a':1,'b':2,'c':3}"
    safe = safe_eval(s)
    assert isinstance(safe, dict) and isinstance(safe['a'], int)
    # setup the module args with a string
    s = "foo"
    safe = safe_eval(s)
    assert safe == "foo"
    # setup the module args with a string, with a jinja2 filter
    s = "foo|bar"
    safe = safe_eval(s)
    assert safe == "foo|bar"
    # setup the

# Generated at 2022-06-23 13:32:28.775043
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:41.124236
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo(1, 2)', locals={'foo': lambda a, b: a + b}) == 3
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo(1, 2)') == 'foo(1, 2)'
    assert safe_eval([1, 2]) == [1, 2]

    # json style bools/null (even though this is not safe for json)
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # Only these builtins are safe
    assert safe_eval('max(1, 2)') == 2
    assert safe_eval('None') is None

    # Invalid syntax

# Generated at 2022-06-23 13:32:53.258144
# Unit test for function safe_eval