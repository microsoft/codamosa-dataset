

# Generated at 2022-06-23 13:23:04.004147
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is only a unit test for the Jinja2 usage.  The safe_eval function may have a broader usablity.
    '''

    # base test
    assert(safe_eval("var"))

    # basic expression tests
    assert(safe_eval("var + 42") == "var + 42")
    assert(safe_eval("var + 42", locals={'var': 4}) == 6)
    assert(safe_eval("var + [2]", locals={'var': [1]}) == [1,2])
    assert(safe_eval("var + [2]", locals={'var': [1]}) == [1,2])
    assert(safe_eval("var + {1:2}", locals={'var': {2:3}}) == [2,3])

# Generated at 2022-06-23 13:23:12.729610
# Unit test for function safe_eval
def test_safe_eval():
    symtab = {
        'a_dict': {
            'a_key': "a_value",
            },
        'a_string': "a_string",
        'a_list': ["a_string"],
        'a_integer': 1,
        'a_float': 1.1,
        'a_boolean_true': True,
        'a_boolean_false': False,
        'a_none': None,
        }
    failed = 0
    for expr, value in symtab.items():
        print(expr)
        result = safe_eval(expr, symtab)
        if result != value:
            print("FAIL: Eval of %s returned %s, should have returned %s"
                  % (expr, result, value))
            failed += 1

# Generated at 2022-06-23 13:23:22.549548
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    expr1 = safe_eval('[1,2,3]')
    assert expr1 == [1, 2, 3]
    expr2 = safe_eval('{"first_name": "John", "last_name": "Doe"}')
    assert expr2 == {'first_name': 'John', 'last_name': 'Doe'}
    expr3 = safe_eval('foo.bar')
    assert expr3 == 'foo.bar'
    # Test include_exceptions
    (result, err) = safe_eval('[1,2,3]', include_exceptions=True)
    assert result == [1, 2, 3]
    assert err is None
    (result, err) = safe_eval('foo.bar', include_exceptions=True)
    assert result == 'foo.bar'

# Generated at 2022-06-23 13:23:30.809057
# Unit test for function safe_eval
def test_safe_eval():

    good_str = "a_list_variable|map(attribute='stdout')|list"
    bad_str = "a_list_variable|map(attribute='stdout')|list|foo()"

    # Test safe eval
    result = safe_eval(good_str)

    if isinstance(result, string_types):
        print("safe_eval did not parse correctly")
        sys.exit(1)

    try:
        result = safe_eval(bad_str)
    except:
        print("safe_eval correctly throws error")
    else:
        print("safe_eval should have thrown an exception")
        sys.exit(1)

    print("safe_eval unit test passed")


# Generated at 2022-06-23 13:23:38.427577
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('null') is None
    assert safe_eval('10') == 10
    assert safe_eval('10 + 10') == 20
    assert safe_eval('10*10') == 100
    assert safe_eval('-10') == -10
    assert safe_eval('(True, False)') == (True, False)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('{"a": "b" + "c"}') == {"a": "bc"}
    assert safe_eval('(1 in [1,2])') is True

# Generated at 2022-06-23 13:23:49.037074
# Unit test for function safe_eval
def test_safe_eval():
    # Test for valid expressions
    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('1 < 2')
    assert not safe_eval('1 > 2')
    assert safe_eval('1 <= 2')
    assert not safe_eval('1 >= 2')
    assert safe_eval('1 == 2')
    assert not safe_eval('1 != 2')
    assert safe_eval('True == 1')
    assert not safe_eval('True != 1')
    assert safe_eval('False == 0')
    assert not safe_eval('False != 0')
    assert safe_eval('True == "TRUE"')
    assert not safe_eval('True != "TRUE"')
    assert safe_eval('False == "False"')
    assert not safe_eval('False != "False"')

# Generated at 2022-06-23 13:23:58.266741
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval with a number
    expr = 42
    val, err = safe_eval(expr, include_exceptions=True)
    assert val == 42
    assert err is None

    # bad expression: just a bare string
    expr = 'some string'
    val, err = safe_eval(expr, include_exceptions=True)
    assert val == expr and err is None

    # bad expression: a bare string that is a valid python expression
    expr = 'some_var'
    val, err = safe_eval(expr, include_exceptions=True)
    assert val == expr and err is None

    # bad expression: not a list and not a string
    expr = None
    val, err = safe_eval(expr, include_exceptions=True)
    assert val == expr and err is None

    # good expression
   

# Generated at 2022-06-23 13:24:08.949554
# Unit test for function safe_eval
def test_safe_eval():

    # Test 1: Test with a simple math statement with no variables
    #         This should simply evaluate to the answer
    expr = "5 + 5"
    result = safe_eval(expr)
    assert result == 10

    # Test 2: Test with a simple math statement with variables
    #         This should evaluate to the answer
    a = 5
    expr = "a + 5"
    result = safe_eval(expr, locals())
    assert result == 10

    # Test 3: Test division by zero
    #         This should evaluate to a float using python2
    expr = "5 / 0"
    if sys.version_info[0] < 3:
        result = safe_eval(expr)
        assert isinstance(result, float)
        assert result == float('inf')

# Generated at 2022-06-23 13:24:18.977061
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native

    # tests on valid expressions
    data = dict(
        valid_exprs=[
            ('foo.bar', ('foo.bar')),
            ('foo.bar.baz.foobar', ('foo.bar.baz.foobar')),
            ('foo.bar.baz.foobar.foo.bar.baz.foobar', ('foo.bar.baz.foobar.foo.bar.baz.foobar'))
        ]
    )
    for expr, expected in data['valid_exprs']:
        assert (safe_eval(expr) == expected)

    # tests on invalid expressions

# Generated at 2022-06-23 13:24:28.741996
# Unit test for function safe_eval
def test_safe_eval():
    def test(input, expected):
        (result, exception) = safe_eval(input, include_exceptions=True)
        if exception is not None:
            print("\nERROR ON: %s" % (input))
            raise exception
        assert result == expected, "%s != %s" % (result, expected)

    test('42', 42)
    test('[1,2,3]', [1,2,3])
    test('{"foo": "bar"}', {"foo": "bar"})
    test('foo', 'foo')
    test('False', False)
    test('True', True)
    test('null', None)
    test('false', False)
    test('true', True)
    test('True and False', False)
    test('"ansible" if True else "fail"', "ansible")

# Generated at 2022-06-23 13:24:34.817328
# Unit test for function safe_eval
def test_safe_eval():
    def test_expr(expr, expected):
        expression, exception = safe_eval(expr, include_exceptions=True)
        assert expression == expected
        assert exception is None

    # basic things that should work
    test_expr('{"a": 1}', {u'a': 1})
    test_expr('[1,2,3]', [1, 2, 3])
    test_expr('-1 * 2', -2)
    test_expr('"foo" in "foobar"', True)
    test_expr('foo.bar', u'baz')
    test_expr('foo[1]', u'bar')

    # things that should fail
    assert safe_eval(None, include_exceptions=True)[0] is None

# Generated at 2022-06-23 13:24:47.081590
# Unit test for function safe_eval
def test_safe_eval():
    """Test safe evaluation of expression strings"""

# Generated at 2022-06-23 13:24:57.756547
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr, expected, additional_local_vars={}, enable_call=False):
        CALL_ENABLED.append(enable_call)
        result = safe_eval(expr, locals=dict(additional_local_vars))
        CALL_ENABLED.pop()
        assert result == expected

    # Basic math
    test('1 + 1', 2)
    test('1 - 1', 0)
    test('-5', -5)
    test('2 * 3', 6)
    test('3 / 2', 1.5)

    # Variable binding
    test('foo + 1', 2, {'foo': 1})
    test('foo - 1', 0, {'foo': 1})
    test('foo - bar', -2, {'foo': 1, 'bar': 3})

    # Strings

# Generated at 2022-06-23 13:25:07.853579
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: add more tests to exercise other AST nodes
    from ansible.module_utils.common.text.converters import to_text

    # simple tests
    assert safe_eval("4 + 4") == 8
    assert safe_eval("4 - 4") == 0
    assert safe_eval("4 * 4") == 16
    assert safe_eval("4 ** 4") == 256
    assert safe_eval("-8") == -8
    assert safe_eval("1==1") is True
    assert safe_eval("true") is True

    assert safe_eval("'foo' + 'bar'") == 'foobar'
    assert safe_eval("'foo' + 'bar' + 'baz'") == 'foobarbaz'

# Generated at 2022-06-23 13:25:18.181995
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval with exception handling
    assert safe_eval('1 + 2', include_exceptions=True) == (3, None)
    assert safe_eval('1 + 2 + bogus', include_exceptions=True) == ('1 + 2 + bogus', None)
    assert safe_eval('1 + 2 + None', include_exceptions=True) == (3, None)
    assert safe_eval('1 + 2 + null', include_exceptions=True) == (3, None)
    assert safe_eval('1 + 2 + true', include_exceptions=True) == (4, None)
    assert safe_eval('1 + 2 + false', include_exceptions=True) == (3, None)
    assert safe_eval('1 + 2 + bogus', include_exceptions=True) == ('1 + 2 + bogus', None)
   

# Generated at 2022-06-23 13:25:28.925835
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-argument,unused-variable,expression-not-assigned,bare-except

    def assert_safe_eval(expr, expected):
        ''' assert safe_eval(expr) == expected '''
        result = safe_eval(expr)
        assert result == expected, 'safe_eval failed: result is %s, expected %s' % (result, expected)

    def assert_safe_eval_exception(expr):
        ''' assert safe_eval(expr) raises '''
        if not isinstance(expr, string_types):
            # already templated to a datastructure, perhaps?
            return
        try:
            safe_eval(expr)
        except Exception:
            return
        raise AssertionError('safe_eval did not raise exception')

    # simple ops
    assert_safe

# Generated at 2022-06-23 13:25:38.898128
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:46.581209
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate the expression and compare the result with the expected result
    def _check(expr, result):
        actual_result, failure = safe_eval(expr, include_exceptions=True)
        assert failure is None, 'Failed to evaluate: %s' % expr
        assert actual_result == result, '%s != %s' % (actual_result, result)


# Generated at 2022-06-23 13:25:55.747371
# Unit test for function safe_eval
def test_safe_eval():
    # test basic data types
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", dict(foo=1)) == 1
    assert safe_eval("foo", dict(foo='bar')) == "bar"
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("(1,2,3)") == (1, 2, 3)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

    # test that unsafe constructs raise an error
    error = None

# Generated at 2022-06-23 13:26:07.380367
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('[1,2]')
    safe_eval('{"a":1}')
    safe_eval("'foo'")
    try:
        safe_eval("__builtins__.open('/etc/passwd')")
        assert False
    except Exception:
        pass
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None

    assert safe_eval("5<6") is True
    assert safe_eval("5+6") == 11
    assert safe_eval("5+true") == 6
    assert safe_eval("6+true") == 7

# Generated at 2022-06-23 13:26:19.212551
# Unit test for function safe_eval
def test_safe_eval():

    # Test string parsing
    assert safe_eval("a") == "a", "String parsing is broken"
    assert safe_eval("a.b") == "a.b", "String parsing is broken"
    assert safe_eval("a.b.c") == "a.b.c", "String parsing is broken"

    # Test eval of integers
    assert safe_eval("4") == 4, "Salary does not match"
    assert safe_eval("-4") == -4, "Negative salary does not match"

    # Test addition and subtraction
    assert safe_eval("3 + 2"), "Addition with integers failed"
    assert safe_eval("1 - 4"), "Subtraction with integers failed"
    assert safe_eval("1 + 1 - 4"), "Addition and subtraction with integers failed"

# Generated at 2022-06-23 13:26:31.540986
# Unit test for function safe_eval
def test_safe_eval():
    def _assert(expr, expected):
        result = safe_eval(expr)
        if result != expected:
            print("ASSERTION FAILED: Expected %s in '%s' but result is %s" % (expected, expr, result))
            sys.exit(-1)

    def _assert_unevaluatable(expr):
        result = safe_eval(expr)
        if result != expr:
            print("ASSERTION FAILED: Expected unevaluatable expression in '%s' but result is %s" % (expr, result))
            sys.exit(-1)

    print("Running unit test on function safe_eval")

    _assert("1", 1)
    _assert("true", True)
    _assert("false", False)
    _assert("null", None)

# Generated at 2022-06-23 13:26:42.480274
# Unit test for function safe_eval
def test_safe_eval():

    def _test_safe_eval(expr, expected):
        """
        Parses and evaluates ``expr`` in a safe environment.
        Should raise an exception if there is a syntax error,
        or if ``expr`` tries to access or define anything
        not explicitly whitelisted in ``SAFE_NODES``.
        """
        result, err = safe_eval(expr, include_exceptions=True)
        if err:
            raise AssertionError('Failed to parse %s: %s' % (expr, to_native(err)))
        if result != expected:
            raise AssertionError('%s != %s\n  %s\n  %s' % (expected, result, type(expected), type(result)))

    _test_safe_eval('{ "a": 1 }', {u'a': 1})
    _

# Generated at 2022-06-23 13:26:52.335036
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test syntax errors are caught and wrapped.
    Test built-in functions are not allowed.
    Test most operators are allowed.
    Test some simple expressions.
    Test access to builtins is allowed.
    Test access to an object is allowed if that object's name is in locals().
    """

    # Test syntax errors
    for expr in ('for x in : pass', '2 + 3 +', '{]', '()'):
        try:
            safe_eval(expr)
            print('safe_eval("%s") should have raised SyntaxError!' % expr)
            sys.exit(1)
        except Exception as e:
            assert isinstance(e, SyntaxError)

    # Test built-in functions are not allowed

# Generated at 2022-06-23 13:27:03.369880
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_unicode
    import ast
    import datetime
    import json
    import sys

    # create test as string for Python 2 and 3
    if sys.version_info < (3,):
        func_name = 'function'
    else:
        func_name = 'builtin_function_or_method'


# Generated at 2022-06-23 13:27:14.048663
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval() with various expressions
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('1') == 1
    assert safe_eval('"one"') == "one"

    # test safe_eval() with unsafe expressions
    failed = False
    try:
        safe_eval('[1, 2, 3].extend(a)')
    except Exception:
        failed = True
    assert failed

    # test safe_eval() with jinja2 variables
    class JinjaVariable(object):
        def __init__(self, val):
            self.val = val
        def __str__(self):
            return to_native(self.val)
        def __repr__(self):
            return to_native(self.val)

    a = Jin

# Generated at 2022-06-23 13:27:24.205588
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 1:
    result, exc = safe_eval('{{ ansible_play_hosts }}', {'ansible_play_hosts': ['host1', 'host2']}, True)
    assert result == ['host1', 'host2']
    assert exc is None

    # Test case 2:
    result, exc = safe_eval('{{ ansible_play_hosts }}', {'ansible_play_hosts': 'host1'}, True)
    assert result == 'host1'
    assert exc is None

    # Test case 3:
    result, exc = safe_eval('{{ ansible_play_hosts }}', {'ansible_play_hosts': ['host1']}, True)
    assert result == ['host1']
    assert exc is None

    # Test case 4:
    result, exc = safe_

# Generated at 2022-06-23 13:27:35.551140
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Verify that safe_eval does not execute unsafe code.
    '''
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1 + 1]') == [2]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}

    # A few different ways to create a list:
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('list((1, 2, 3))') == [1, 2, 3]
    assert safe_eval('tuple((1, 2, 3))') == (1, 2, 3)
    assert safe_eval('{1, 2, 3}') == {1, 2, 3}

    # A few different ways to create a dict:

# Generated at 2022-06-23 13:27:46.899181
# Unit test for function safe_eval
def test_safe_eval():
    # test list
    exp = 'a + [1,2,3] + c'
    vars = dict(a=[1,2,3], b=[4,5,6], c=[4,5,6])
    res = safe_eval(exp, vars)
    assert(res == [1,2,3,1,2,3,4,5,6])
    # test dict
    exp = 'a + {1,2} + b'
    vars = dict(a={1,2}, b={3,4})
    res = safe_eval(exp, vars)
    assert(res == {1,2,3,4})
    # test tuple
    exp = 'a + (1,2) + b'
    vars = dict(a=(1,2), b=(3,4))
    res

# Generated at 2022-06-23 13:27:58.747474
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('{"a":1}') == {'a': 1}
    assert safe_eval('[foo]') is None
    assert safe_eval('[foo]', {'foo': 1}) == [1]
    assert safe_eval('[foo, [bar]]', {'foo': 1, 'bar': 2}) == [1, [2]]
    assert safe_eval('[foo, [bar]]', {'foo': 1, 'bar': 2, 'baz': 3}) == [1, [2]]
    assert safe_eval('dict(a=1,b=2)') == {'a': 1, 'b': 2}

# Generated at 2022-06-23 13:28:05.631771
# Unit test for function safe_eval
def test_safe_eval():

    # should pass
    assert safe_eval('42') == 42
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('"some string"') == 'some string'
    assert safe_eval('"{{foo}}"') == '{{foo}}'
    assert safe_eval('1+1') == 2
    assert safe_eval('1+2+3') == 6
    assert safe_eval('1<2') is True
    assert safe_eval('1+1<3') is True
   

# Generated at 2022-06-23 13:28:17.612054
# Unit test for function safe_eval
def test_safe_eval():
    # a couple of data structures (the original coding of which was used to
    # find bugs in the code above)
    a = [1,3,4]
    b = ["a","b","c"]
    c = [a,b]
    d = ("s", "l", "i", "c", "e")
    e = ("e", "g", "g", "s", "b", "a", "c", "o", "n")
    f = { 'a': 1, 'b': 2, 'c': 3}
    g = { 'a': [1,2], 'b': { 'ba': 10, 'bb': [1,2,3,4] }, 'c': f}
    h = [1, { 'a': 1, 'b': 2, 'c': 3} , 3, 4]

# Generated at 2022-06-23 13:28:30.223704
# Unit test for function safe_eval
def test_safe_eval():
    # we want to test calling safe_eval explicitly, so
    # we need to temporarily disable the jinja2_evaluate
    # filter to prevent the filter from being called
    __import__("ansible.plugins.filter.jinja2")
    j2_filter = sys.modules["ansible.plugins.filter.jinja2"]
    old_filter = getattr(j2_filter, "FILTER_SINGLETON")
    j2_filter.FILTER_SINGLETON = None

# Generated at 2022-06-23 13:28:41.960923
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:53.374244
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:05.017545
# Unit test for function safe_eval
def test_safe_eval():

    # Test some valid expressions
    expr = "A and B"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert exception is not None

    expr = "A or B"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert exception is not None

    expr = "A or 'B'"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert exception is not None

    expr = "A and ('B' + 'C')"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert exception is not None

    expr = "A and (B + C)"

# Generated at 2022-06-23 13:29:09.388374
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2 + 2") == 4
    assert safe_eval("0 - (-2)") == 2
    assert safe_eval('["a","b"]') == ["a", "b"]
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a':1,'b':['c','d']}") == {'a': 1, 'b': ['c', 'd']}
    assert safe_eval("{'a':[1,2],'b':{'c':3,'d':4}}") == {'a': [1, 2], 'b': {'c': 3, 'd': 4}}
    assert safe_eval("(1,2)") == (1, 2)

# Generated at 2022-06-23 13:29:21.870610
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("range(10)") == list(range(10))
    assert safe_eval("1 in range(10)") == True
    assert safe_eval("dict(a=1)") == dict(a=1)
    assert safe_eval("dict(a=range(10))") == dict(a=list(range(10)))
    assert safe_eval("{'a': [1, 2, 3]}") == dict(a=[1, 2, 3])
    assert safe_eval("a") == 'a'
    assert safe_eval("'a'") == 'a'
    assert safe_eval("True") == True
    assert safe_eval("False") == False

    # should cause a SyntaxError exception
    assert safe

# Generated at 2022-06-23 13:29:29.594680
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.compat.tests import unittest

    class TestSafeEval(unittest.TestCase):
        ''' Test the safe_eval function '''
        # Tests for valid expressions

# Generated at 2022-06-23 13:29:39.180026
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.lower()') == 'foo.lower()'
    assert safe_eval('foo[bar]') == 'foo[bar]'
    assert safe_eval('foo().split(".")') == 'foo().split(".")'

# Generated at 2022-06-23 13:29:48.884120
# Unit test for function safe_eval
def test_safe_eval():
    # no quotes around strings
    result, exception = safe_eval('foo', include_exceptions=True)
    assert result == 'foo'
    assert exception is not None

    # strings as values
    result, exception = safe_eval('{"foo": "bar"}', include_exceptions=True)
    assert result == {"foo": "bar"}
    assert exception is None

    # strings as keys
    result, exception = safe_eval('{"foo": "bar"}', include_exceptions=True)
    assert result == {"foo": "bar"}
    assert exception is None

    # integers
    result, exception = safe_eval('{"foo": 2}', include_exceptions=True)
    assert result == {"foo": 2}
    assert exception is None

    # arithmetic

# Generated at 2022-06-23 13:29:58.639224
# Unit test for function safe_eval
def test_safe_eval():
    for s in [
        "a_list_variable",
        'an_integer_5',
        'True',
        'False',
        '{foo: bar}',
        '[foo, bar]',
        '"foo" in bar',
    ]:
        assert safe_eval(s) == s


# Generated at 2022-06-23 13:30:09.803376
# Unit test for function safe_eval
def test_safe_eval():
    # Check the following safe_eval with both the old API
    # and the new API
    # Old API:
    #   safe_eval(expr)
    # New API:
    #   safe_eval(expr, include_exceptions=True)
    #   safe_eval(expr, include_exceptions=False)

    # Test one expression with safe_eval,
    # expect both to return True.
    expr = '1 == 1'
    if not safe_eval(expr):
        raise Exception('safe_eval(%s) failed' % expr)

    # safe_eval(expr, include_exceptions=True)
    (result, exception) = safe_eval(expr, include_exceptions=True)
    if not result:
        raise Exception('safe_eval(%s) failed' % expr)

    # safe_eval(

# Generated at 2022-06-23 13:30:19.173919
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo", include_exceptions=True) == ("foo", None)
    assert safe_eval("foo['bar']", include_exceptions=True) == ("foo['bar']", None)
    assert safe_eval("[]", include_exceptions=True) == ([], None)
    assert safe_eval("{}", include_exceptions=True) == ({}, None)
    assert safe_eval("{}", locals={"foo": "bar"}, include_exceptions=True) == ({}, None)
    assert safe_eval("foo", locals={"foo": "bar"}, include_exceptions=True) == ('bar', None)
    assert safe_eval("foo.bar", locals={"foo": "bar"}, include_exceptions=True) == ('foo.bar', None)

# Generated at 2022-06-23 13:30:26.324176
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:35.484682
# Unit test for function safe_eval
def test_safe_eval():
    # Test the safe_eval function by passing valid expressions, invalid expressions
    # and expressions that expect a certain result and validating the correct output.

    # Passing a None expr to safe_eval, it should return None
    assert safe_eval(None) == None

    # Passing 1 to safe_eval, it should return 1
    assert safe_eval('1') == 1

    # Passing 1+2 to safe_eval, it should return 3
    assert safe_eval('1+2') == 3

    # Passing (1+2) to safe_eval, it should return 3
    assert safe_eval('(1+2)') == 3

    # Passing 2*(1+2) to safe_eval, it should return 6
    assert safe_eval('2*(1+2)') == 6

    # Passing 1+2-3 to safe_eval, it should

# Generated at 2022-06-23 13:30:46.053109
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval with a variety of valid and invalid expressions
    '''

    # Test valid expressions
    # -----------------------
    # expected, expression, locals

    # int
    yield ('6', '6')
    # float
    yield ('1.1', '1.1')
    # string
    yield ('foo', '"foo"')
    # dict
    yield ({'foo': 'bar'}, '{ "foo" : "bar" }')
    # list
    yield (['foo', 'bar', 'baz'], '["foo", "bar", "baz"]')
    # tuple
    yield (('foo', 'bar', 'baz'), '("foo", "bar", "baz")')
    # set

# Generated at 2022-06-23 13:30:56.277124
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:06.725168
# Unit test for function safe_eval
def test_safe_eval():
    # Test whether builtins are blacked out
    if sys.version_info[0] > 2:
        # Python 3
        func_safe = ['bytearray', 'bytes', 'list', 'dict', 'set']
        str_safe = ['True', 'False', 'None']
    else:
        # Python 2
        func_safe = ['bytearray', 'bytes', 'list', 'dict', 'set', 'unicode']
        str_safe = ['True', 'False']

    # Ensure that known safe methods are not whitelisted by CleansingNodeVisitor
    assert set(func_safe) - set(C.SAFE_BUILTINS) == set()

    # Ensure that known safe attributes of the builtin 'str' class are not whitelisted by CleansingNodeVisitor
    assert set(str_safe)

# Generated at 2022-06-23 13:31:17.932201
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:27.850905
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases in format:
    # input, expected result, expected exception

    # Strings
    test_cases = [
        ('a', 'a'),
        ('""', ''),
        ('"a"', 'a'),
        ('"a" "b"', 'ab'),
        ("'a'", 'a'),
        ("'a' 'b'", 'ab')
    ]

    # Numerics

# Generated at 2022-06-23 13:31:39.386262
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    # Successful evals
    assert safe_eval("1 + 3") == 4
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    # Unsuccessful evals
    assert safe_eval("__import__('sys').version", include_exceptions=True)[0] == "__import__('sys').version"
    assert safe_eval("__import__('sys').version", include_exceptions=True)[1] is not None
    assert safe_eval("['foo', 'bar'][0]()", include_exceptions=True)[0] == "['foo', 'bar'][0]()"

# Generated at 2022-06-23 13:31:47.795792
# Unit test for function safe_eval
def test_safe_eval():

    # this should work
    expr = "{{ 1 + 1 }}"
    (res, err) = safe_eval(expr, {}, include_exceptions=True)
    assert res == 2
    assert err is None

    # this should fail
    expr = "{{ foo.bar() }}"
    (res, err) = safe_eval(expr, {}, include_exceptions=True)
    assert res == expr
    assert err is not None

    if not sys.version_info >= (3, 0):
        # this should work
        expr = "[x for x in range(10) if x % 2 == 0]"
        (res, err) = safe_eval(expr, {}, include_exceptions=True)
        assert res == [0, 2, 4, 6, 8]
        assert err is None

    # this should also work


# Generated at 2022-06-23 13:31:59.029456
# Unit test for function safe_eval
def test_safe_eval():
    # if the caller prefers not to handle exceptions we just return the value
    # in this case the expected result is "foo"
    assert safe_eval("foo") == "foo"
    # strings in quotes are ok
    assert safe_eval("'foo'") == "foo"
    # nested quotes are ok too
    assert safe_eval("'\"'") == "\""
    # nested quotes are ok too
    assert safe_eval("\"'\"") == "'"
    # unicode is allowed
    assert safe_eval("'üöäß'") == "üöäß"
    # mathematical operations are ok
    assert safe_eval("1 + 1") == 2
    # only addition and subtraction operations are ok
    assert safe_eval("1 / 1") == "1 / 1"
    # assignments are not allowed

# Generated at 2022-06-23 13:32:09.879694
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval("True or False") is True
    assert safe_eval("True and False") is False
    assert safe_eval("1 and 'a'") == 'a'
    assert safe_eval("[] or 'a'") == 'a'
    assert safe_eval("[] or 1") == 1
    assert safe_eval("{} or 1") == 1
    assert safe_eval("[] or {}") == {}
    assert safe_eval("{} or []") == []
    assert safe_eval("{} or {}") == {}
    assert safe_eval("[] and 1") == []
    assert safe_eval("1 and []") == []
    assert safe_eval("[] and {}") == []
    assert safe_eval("{} and []") == []
    assert safe_eval

# Generated at 2022-06-23 13:32:21.156469
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.my_arg_spec as arg_spec

    # if cmp(sys.version_info, (2, 7)) < 0:
    #     raise SkipTest("Templates do not work with Python < 2.7")

    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo }}", dict(foo='bar')) == "bar"
    assert safe_eval("{{ foo.bar }}", dict(foo=dict(bar='baz'))) == "baz"
    assert safe_eval("{{ foo['bar'] }}", dict(foo=dict(bar='baz'))) == "baz"
    assert safe_eval("{{ foo.bar }}", dict(foo=arg_spec.AnsibleDict(bar='baz'))) == "baz"
   

# Generated at 2022-06-23 13:32:31.628354
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:42.630240
# Unit test for function safe_eval
def test_safe_eval():
    """
    Tests for safe_eval function
    """
    original_display_skipped_hosts = C.DISPLAY_SKIPPED_HOSTS
    C.DISPLAY_SKIPPED_HOSTS = True
    string = 'test'
    integer = 1
    list = [1, 2, 'a']
    dict = {'test': 'ok', 'test2': ['a', 'b']}
    complex_dict = {'test': {'test2': {'test3': 'ok'}}}

# Generated at 2022-06-23 13:32:50.004862
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for raw boolean constants
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('yes') is None
    assert safe_eval('no') is None

    # Test for string constants
    assert safe_eval('"true"') == 'true'
    assert safe_eval("'false'") == 'false'
    assert safe_eval("'no'") == 'no'
    assert safe_eval('"yes"') == 'yes'

    # Test for raw numeric constants
    assert safe_eval('42') == 42

    # Test for raw dicts
    assert safe_eval('{}') == {}
    assert safe_eval('{"key":"value"}') == {"key":"value"}

    # Test for raw lists
    assert safe_eval('[]') == []
    assert safe_

# Generated at 2022-06-23 13:32:59.353993
# Unit test for function safe_eval
def test_safe_eval():
    if len(sys.argv) > 1 and sys.argv[1] == "safe_eval_test":
        print(safe_eval('false'))
        print(safe_eval('true'))
        print(safe_eval('null'))
        print(safe_eval('[1,2,3]'))
        print(safe_eval('{"a":1}'))
        print(safe_eval('1 + 2'))
        print(safe_eval('1 - 2'))
        print(safe_eval('1 * 2'))
        print(safe_eval('1 / 2'))
        print(safe_eval('1 // 2'))
        print(safe_eval('1 % 2'))
        print(safe_eval('1 ** 2'))
        print(safe_eval('- 1'))