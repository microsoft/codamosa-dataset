

# Generated at 2022-06-23 13:23:05.519322
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:13.941463
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    if sys.version_info < (2, 7):
        return  # FIXME: Python 2.6 not currently supported

    # enable certain function calls via CALL_ENABLED
    safe_eval(to_bytes('CALL_ENABLED.append("enumerate")'), locals={'CALL_ENABLED': CALL_ENABLED})

    # basic sanity check
    assert safe_eval(to_bytes("1 + 1"), locals={}) == 2

    # check that exceptions are raised for invalid expressions
    exception = safe_eval(to_bytes("1 +1"), locals={}, include_exceptions=True)[1]
    assert isinstance(exception, SyntaxError)

    # check that we can call enumerate on a list
   

# Generated at 2022-06-23 13:23:20.630446
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:31.280057
# Unit test for function safe_eval
def test_safe_eval():

    def _check(inp, expected, exc=False, inplace=False):
        if inplace:
            locals_dict = {'hostvars': {'localhost': {}}}
        else:
            locals_dict = {}
        (result, exception) = safe_eval(inp, locals_dict, include_exceptions=True)
        if exc:
            assert exception is not None
            assert result == inp
        else:
            assert exception is None
            assert result == expected

    # test variables
    _check('5',5)
    _check('"foo"', 'foo')
    _check('foo', 'foo')
    _check('foo().bar', 'foo().bar')
    _check('foo().bar.baz()', 'foo().bar.baz()')

# Generated at 2022-06-23 13:23:42.224098
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:51.390835
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("1 + 1") == 2
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("'a string'") == 'a string'
    assert safe_eval("['a', 'list']") == ['a', 'list']
    assert safe_eval("{'a': 'dict'}") == {'a': 'dict'}
    assert safe_eval("-1") == -1
    assert safe_eval("-1", include_exceptions=True)[0] == -1
    assert safe_eval("1 + 1 == 2") is True
    assert safe_eval("'a' in 'ab'") is True
    assert safe_eval("{'a': 'dict'}['a']") == 'dict'


# Generated at 2022-06-23 13:23:59.773917
# Unit test for function safe_eval
def test_safe_eval():
    a = safe_eval('[1,2,3]')
    assert a == [1,2,3]

    try:
        b = safe_eval('__import__("sys").modules')
    except:
        pass
    assert b == None

    try:
        c = safe_eval('True and False')
    except:
        pass
    assert c == None

    try:
        d = safe_eval('True and 2==2')
    except:
        pass
    assert d == True

    try:
        e = safe_eval('False or "truth"')
    except:
        pass
    assert e == 'truth'

    try:
        f = safe_eval('1 + 2')
    except:
        pass
    assert f == 3


# Generated at 2022-06-23 13:24:10.888846
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Very basic unit test to ensure safe_eval() works as expected.
    '''


# Generated at 2022-06-23 13:24:20.611687
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval() via Python's unit testing framework
    '''
    import unittest

    class TestSafeEval(unittest.TestCase):
        '''
        Test case for safe_eval()
        '''
        def test_safe_eval(self):
            '''
            Test safe_eval()
            '''
            # Test for successful evaluation
            test_string = "my_list = ['foo', 'bar', 'baz']"
            correct_result = ['foo', 'bar', 'baz']
            result = safe_eval(test_string)
            self.assertEqual(result, correct_result)

            # Test for basic python expressions
            test_string = "1 + 1"
            correct_result = 2
            result = safe_eval(test_string)
            self.assertE

# Generated at 2022-06-23 13:24:26.620220
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the complex expressions, simple expressions and special syntax.
    '''

    # complex expressions
    expr = "1 * 2 * (1 + 4)"
    assert safe_eval(expr) == 10
    expr = "1 * (1 + 4) * 2"
    assert safe_eval(expr) == 10
    expr = "[1, 2, 3][(-1 * 2 * 3 / 2) - 1]"
    assert safe_eval(expr) == 2
    expr = "[1, 2, 3][(-1 * (2 * 3) / 2) - 1]"
    assert safe_eval(expr) == 2

    # simple expressions
    expr = "1 + 4"
    assert safe_eval(expr) == 5
    expr = "1 - 4"
    assert safe_eval(expr) == -3

# Generated at 2022-06-23 13:24:32.905778
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic eval
    assert safe_eval("a == 1") is False
    assert safe_eval("a == 1", {"a": 1}) is True
    assert safe_eval("a == 1", {"a": 2}) is False
    assert safe_eval("a == 1", {"a": 1.0}) is True
    assert safe_eval("a == 1", {"a": 1.1}) is False

    # Test nested lists
    assert safe_eval("a == [1]", {"a": [1]}) is True
    assert safe_eval("a == [1]", {"a": [2]}) is False
    assert safe_eval("a == [[1]]", {"a": [[1]]}) is True
    assert safe_eval("a == [[1]]", {"a": [[2]]}) is False

    # Test nested dicts
    assert safe

# Generated at 2022-06-23 13:24:41.983872
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("a+b", locals=dict(a=1, b=2)) == 3
    assert safe_eval("{1:2,3:4}") == {1: 2, 3: 4}
    assert safe_eval("[1,2,3][0:2]") == [1, 2]
    assert safe_eval("a", locals=dict(a=True))

    assert safe_eval("a == b", locals=dict(a=True, b=False)) is False

    # make sure we don't allow executable code
    assert safe_eval("__import__('sys').exit(1)") == "__import__('sys').exit(1)"


# Generated at 2022-06-23 13:24:50.582733
# Unit test for function safe_eval
def test_safe_eval():
    # JSON types
    assert False is safe_eval('false')
    assert None is safe_eval('null')
    assert True is safe_eval('true')
    assert False is safe_eval('False')
    assert None is safe_eval('None')
    assert True is safe_eval('True')
    assert 42 is safe_eval('2*21')
    assert 42 == safe_eval('21*2')
    assert isinstance(safe_eval('range(21)'), builtins.range)

    # Disallowed subset of call()
    assert 0 is safe_eval('int("0")')
    assert 0 == safe_eval('int("0", 10)')
    assert 0 is safe_eval('len(["0"])')
    assert 0 == safe_eval('len(["0", "0"])', include_exceptions=True)[0]

# Generated at 2022-06-23 13:25:00.406404
# Unit test for function safe_eval
def test_safe_eval():
    test_data = [
        ('[1, 2, 3, 4]', [1, 2, 3, 4]),
        ('{"a": "foo", "b": "bar", "c": "baz"}', {"a": "foo", "b": "bar", "c": "baz"}),
        ('true', True),
        ('false', False),
        ('null', None),
        ('1 + 1', 2),
        ('a and b', 'a and b'),
        ('a.b', 'a.b'),
        ('a.b()', 'a.b()'),
    ]

    failed = 0
    for expr, expected in test_data:
        result = safe_eval(expr)

# Generated at 2022-06-23 13:25:12.159323
# Unit test for function safe_eval
def test_safe_eval():
    import copy
    import os
    import json

    TESTDIR = os.path.dirname(os.path.abspath(__file__))
    TESTFILE = os.path.join(TESTDIR, '..', '..', 'test', 'sanity', 'validate-modules')
    modules_dir = os.path.join(TESTDIR, '..', '..', 'lib', 'ansible', 'modules')
    if os.path.exists(modules_dir):
        test_files = [os.path.join(TESTFILE, f) for f in os.listdir(TESTFILE) if os.path.isfile(os.path.join(TESTFILE, f))]
    else:
        test_files = []
    results = {}
    exceptions = []

# Generated at 2022-06-23 13:25:19.795229
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:30.075361
# Unit test for function safe_eval
def test_safe_eval():
    # SyntaxError exception is handled properly
    assert safe_eval('abc()') == 'abc()'

    # No exception raised when callable is included in locals
    assert safe_eval('def x(host): pass') == 'def x(host): pass'

    # No exception raised when callable is in CALL_ENABLED
    old_call_enabled = CALL_ENABLED[:]
    CALL_ENABLED.append('abs')
    assert safe_eval('abs(-1)') == -1
    CALL_ENABLED = old_call_enabled[:]

    # Exception raised for any expressions with invalid function names
    assert safe_eval('abc(-1)') == 'abc(-1)'

    # No exception raised when whitespace is used
    assert safe_eval('1') == 1

    # No exception raised when boolean is used
    assert safe

# Generated at 2022-06-23 13:25:36.978247
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable") == "a_list_variable"
    assert safe_eval("a_list_variable.0") == "a_list_variable.0"
    assert safe_eval("a_list_variable[0]") == "a_list_variable[0]"
    assert safe_eval("a_list_variable[0].something") == "a_list_variable[0].something"
    assert safe_eval("{{ a_list_variable[0] }}") == "{{ a_list_variable[0] }}"
    assert safe_eval("{{ a_list_variable[0].something }}") == "{{ a_list_variable[0].something }}"
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"

# Generated at 2022-06-23 13:25:45.181575
# Unit test for function safe_eval
def test_safe_eval():
    # Pass
    for expr in (
        "2 + 2",
        "4 - 2",
        "4 * 2",
        "4 / 2",
        "4 ** 2",
        "True",
        "False",
        "None",
        "true",
        "false",
        "null",
        "[1,2,3]",
        "{1:2,3:4}",
        "var",
        "var_name",
    ):
        assert expr == safe_eval(expr)

    # Fail

# Generated at 2022-06-23 13:25:51.617466
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:04.012087
# Unit test for function safe_eval
def test_safe_eval():
    '''
    test method safe_eval
    '''
    from ansible.module_utils.basic import AnsibleModule

    def do(test_tuple):
        expr, ctx, output, changed, error = test_tuple
        m_args = dict(
            expr=str(expr),
            failed=False,
            changed=False,
            _ansible_no_log=False,
        )
        if ctx:
            m_args['ansible_facts'] = ctx
        m = AnsibleModule(
            argument_spec=dict(
                expr=dict(),
            ),
            supports_check_mode=False,
        )
        m_args['_ansible_no_log'] = False
        m.params = m_args

# Generated at 2022-06-23 13:26:13.625284
# Unit test for function safe_eval
def test_safe_eval():
    # we define a custom exception here
    # as we need it for the test
    class MyException(Exception):
        pass

    locals_ = {"a":"###","b":"ansible"}
    expr_ok = "a+b"
    expr_not_ok = "a+b; __import__('os').system('date')"

    result, exception = safe_eval(expr_ok, locals=locals_, include_exceptions=True)
    assert result == "###ansible"
    assert exception is None

    result, exception = safe_eval(expr_not_ok, locals=locals_, include_exceptions=True)
    # we don't care which exception is raised
    # as long as it is some kind of exception
    assert isinstance(exception, Exception)

    # test the check for json types
    expr_ok

# Generated at 2022-06-23 13:26:20.601360
# Unit test for function safe_eval
def test_safe_eval():
    # good expression
    expr = "1 + 1"
    t = safe_eval(expr)
    assert t == 2

    # could be good expression, but we don't allow calls, and raise
    # exception since we can't validate the func call
    expr = "foo(1, 2, 3)"
    t = safe_eval(expr)
    assert t == expr

    # good expression, but we don't allow function call, and raise
    # exception since we can't validate the func call
    expr = "1 + foo(1, 2, 3)"
    t = safe_eval(expr)
    assert t == expr

    # this will cause a syntax error since we are not parsing it as
    # an eval string, but returning it as-is
    expr = "a_list_variable"
    t = safe_eval(expr)

# Generated at 2022-06-23 13:26:32.759136
# Unit test for function safe_eval
def test_safe_eval():
    def test_eval(expr, expected, msg):
        result, exc = safe_eval(expr, include_exceptions=True)
        if exc is not None:
            raise Exception("test failed: %s" % msg)
        assert result == expected, msg

    def test_eval_exc(expr, expected, msg):
        result, exc = safe_eval(expr, include_exceptions=True)
        assert type(exc) == expected, msg

    # ensure list subscript works
    test_eval('a_list[0]', 'cheese', 'list item access failed')

    # ensure dict subscript works
    test_eval('a_dict["cheese"]', 'asdf', 'dict item access failed')

    # ensure basic math works
    test_eval('1 + 1', 2, 'basic math failed')

    # ensure support for boole

# Generated at 2022-06-23 13:26:44.765346
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # Numeric types
    assert safe_eval('42') == 42
    assert safe_eval('-42') == -42
    assert safe_eval('2.0') == 2.0
    assert safe_eval('-2.0') == -2.0
    assert safe_eval('1e2000') == float('inf')
    assert safe_eval('-1e2000') == float('-inf')
    assert safe_eval('inf') == float('inf')
    assert safe_eval('-inf') == float('-inf')

# Generated at 2022-06-23 13:26:53.589977
# Unit test for function safe_eval
def test_safe_eval():
    import warnings
    import json
    # set up some test values
    TEST_VALUES = {
        'true': True,
        'false': False,
        'null': None,
        'empty_string': '',
        'string': 'foobar',
        'unicode_string': u'unicode_string',
        'number': 42,
        'list': [1, 2, 3],
        'tuple': (1, 2, 3),
        'dict': {'a': 1, 'b': 2},
        'dict_with_list': {'a': [1, 2]},
        'nested_dict': {'a': {'b': {'c': {'d': 1}}}}
    }

# Generated at 2022-06-23 13:27:04.378953
# Unit test for function safe_eval
def test_safe_eval():
    try:
        print(safe_eval('foobar'))
    except:
        print("failed: foobar")
        sys.exit(1)
    try:
        print(safe_eval('foo["bar"]'))
    except:
        print("failed: foo[bar]")
        sys.exit(1)
    try:
        print(safe_eval('foo.bar'))
    except:
        print("failed: foo.bar")
        sys.exit(1)
    try:
        print(safe_eval('foo["bar"]["baz"]'))
    except:
        print("failed: foo[bar][baz]")
        sys.exit(1)

# Generated at 2022-06-23 13:27:14.514007
# Unit test for function safe_eval
def test_safe_eval():
    # Custom function calls are not allowed (unless enabled below)
    assert safe_eval("abs(1)") == "abs(1)"
    # We don't allow setting local variables via expr
    assert safe_eval("x = 1") == "x = 1"
    # Disabled builtin functions are not allowed
    assert safe_eval("sorted(1)") == "sorted(1)"
    # We support very simple expressions, like adding two numbers
    assert safe_eval("4 + 1") == 5
    # We can also have strings, which must be quoted appropriately
    assert safe_eval("'foo'") == "foo"
    # We do not allow unquoted Python keywords
    assert safe_eval("True") == "True"
    # We can perform simple comparisons
    assert safe_eval("a < b") == "a < b"
    # We

# Generated at 2022-06-23 13:27:24.352413
# Unit test for function safe_eval
def test_safe_eval():

    # test when expr is an expression
    ret, err = safe_eval("a", {'a': 'a'}, include_exceptions=True)
    assert ret == 'a'
    assert err is None

    # test when expr is templated to a datastructure
    ret, err = safe_eval({'a': 'a'}, {'a': 'a'}, include_exceptions=True)
    assert ret == {'a': 'a'}
    assert err is None

    # test syntax error
    ret, err = safe_eval('a>b', include_exceptions=True)
    assert ret == 'a>b'
    assert err is None

    # test safe_eval is not called when expr is an expression

# Generated at 2022-06-23 13:27:28.962925
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 + 3', include_exceptions=True)[0] == 5
    assert safe_eval({'a': 1}) == {'a': 1}
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('false', include_exceptions=True)[0] is False
    assert safe_eval('null', include_exceptions=True)[0] is None
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('{"a": "{{b}}", "c": "d"}', dict(b='ohnoes'), include_exceptions=True)[0]

# Generated at 2022-06-23 13:27:37.855144
# Unit test for function safe_eval
def test_safe_eval():
    data = [
        # Should pass through unchanged
        ('False', False),
        ('False', False),
        ('{}', {}),
        ('[]', []),
        ('{"foo": "bar"}', {'foo': 'bar'}),
        ('getattr(foo, "bar")', 'getattr(foo, "bar")'),

        # These need calls to builtins enabled
        ('datetime.datetime.utcnow()', 'datetime.datetime.utcnow()'),
        ('datetime.datetime.utcnow()'),

        # Boolean values
        ('false', False),
        ('true', True),
        ('False', False),
    ]
    for test, expected_result in data:
        result = safe_eval(test)
        if expected_result:
            assert result == expected_result


# Generated at 2022-06-23 13:27:47.612186
# Unit test for function safe_eval
def test_safe_eval():
    # some valid expressions
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('{"a": 1, "b": false}') == {"a": 1, "b": False}
    assert safe_eval('False') == False
    assert safe_eval('-True') == -1
    assert safe_eval('-1') == -1
    assert safe_eval('1+1') == 2
    assert safe_eval('"a" + "b"') == "ab"
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('(1, [2])') == (1, [2])
    assert safe_eval('x', dict(x=[1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 13:27:59.450552
# Unit test for function safe_eval
def test_safe_eval():
    # simple test that safe_eval works with a dictionary
    expr = '{"sku": "GeForce-GTX-660-2GB", "upc": "9387699987432"}'
    result = safe_eval(expr)
    assert(result == {'sku': 'GeForce-GTX-660-2GB', 'upc': '9387699987432'})

    # simple test that safe_eval works with a list
    expr = '["sku", "upc"]'
    result = safe_eval(expr)
    assert(result == ['sku', 'upc'])

    # simple test that safe_eval works with builtins
    CALL_ENABLED.append('str')
    expr = 'str(2)'
    result = safe_eval(expr)
    assert(result == '2')

# Generated at 2022-06-23 13:28:08.270899
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    # this shouldn't work
    try:
        safe_eval('__import__("os").getcwd()')
        raise Exception("safe_eval() failed to raise an exception")
    except Exception:
        pass

    # this should
    safe_eval('true')

    # this shouldn't, because we haven't whitelisted the 'foo' module
    try:
        safe_eval('foo.bar()')
        raise Exception("safe_eval() failed to raise an exception")
    except Exception:
        pass

    # also shouldn't work because we haven't whitelisted the call-use
    # of foo.bar

# Generated at 2022-06-23 13:28:13.867132
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:21.764253
# Unit test for function safe_eval
def test_safe_eval():
    # simple scalar values
    assert safe_eval("foo", locals=dict(foo="bar")) == "bar"
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", include_exceptions=True) == ("foo", None)
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", locals=dict(foo=5)) == 5
    assert safe_eval("foo", include_exceptions=True) == (5, None)
    assert safe_eval("foo", locals=dict(foo=None)) is None
    assert safe_eval("foo", include_exceptions=True) == (None, None)
    assert safe_eval("foo", locals=dict(foo=True)) is True
    assert safe_eval("foo", include_exceptions=True) == (True, None)


# Generated at 2022-06-23 13:28:31.881255
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("8 - 2") == 6
    assert safe_eval("4 * 3") == 12
    assert safe_eval("10 / 5") == 2

    assert safe_eval("not False")
    assert not safe_eval("not True")

    assert safe_eval("True or True")
    assert not safe_eval("False or False")
    assert not safe_eval("False or False or False")

    assert safe_eval("True and True")
    assert not safe_eval("True and False")
    assert not safe_eval("True and False and False")
    assert not safe_eval("False and False and False")

    assert safe_eval("-1") == -1
    assert safe_eval("-1 * -1") == 1


# Generated at 2022-06-23 13:28:42.759431
# Unit test for function safe_eval
def test_safe_eval():
    # Basic sanity check
    test_expr = "1 + 1"
    res = safe_eval(test_expr)
    assert res == 2

    test_expr = "[1, 2, 3]"
    res = safe_eval(test_expr)
    assert res == [1, 2, 3]

    test_expr = "a_list_variable"
    a_list_variable = [1, 2, 3]
    res = safe_eval(test_expr, dict(a_list_variable=a_list_variable))
    assert res == [1, 2, 3]

    test_expr = "a_list_variable[0]"
    res = safe_eval(test_expr, dict(a_list_variable=a_list_variable))
    assert res == 1

    # Malicious test for raising a SyntaxError exception
   

# Generated at 2022-06-23 13:28:53.514334
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:00.690100
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Ansible safe_eval test
    '''
    # Expression under test, hostvars and results

# Generated at 2022-06-23 13:29:08.580817
# Unit test for function safe_eval
def test_safe_eval():
    builtins_orig = builtins.int
    builtins.int = None

    test_expr = "{{ a_list_variable | min }}"
    # This will fail to compile
    result, exception = safe_eval(test_expr, include_exceptions=True)
    assert result == test_expr
    assert hasattr(exception, 'msg')

    builtins.int = builtins_orig

    test_expr = "{{ a_list_variable | min }}"
    # This will return an expression string
    result = safe_eval(test_expr)
    assert result == test_expr

    test_expr = "{{ a_list_variable | min() }}"
    # This will return an expression string
    result = safe_eval(test_expr)
    assert result == test_expr


# Generated at 2022-06-23 13:29:21.659949
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Define a test function that can be used by unit tests.
    '''
    from ansible.module_utils._text import to_text

    expr = 'foo.bar("%s")' % to_text(C.DEFAULT_SUDO_PASS)
    result = safe_eval(expr)
    assert result == 'foo.bar("%s")' % C.DEFAULT_SUDO_PASS

    expr = C.DEFAULT_SUDO_PASS
    result = safe_eval(expr)
    assert result == C.DEFAULT_SUDO_PASS

    expr = '{{ foo.bar() }}'
    result = safe_eval(expr)
    assert result == expr

    expr = 'True'
    result = safe_eval(expr)
    assert result is True

    expr = 'False'


# Generated at 2022-06-23 13:29:29.404430
# Unit test for function safe_eval
def test_safe_eval():
    '''
    assert that safe_eval works as expected.
    '''
    assert safe_eval(1) == 1
    assert safe_eval(1+1) == 2
    assert safe_eval(1+1+1) == 3
    assert safe_eval(1*3) == 3
    assert safe_eval(2+1*3) == 5
    assert safe_eval((2+1)*3) == 9
    assert safe_eval(1+1, include_exceptions=True) == (2, None)
    assert safe_eval('2+1', include_exceptions=True) == (3, None)
    assert safe_eval('(2+1)*3', include_exceptions=True) == (9, None)

# Generated at 2022-06-23 13:29:39.317476
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:49.129156
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate a literal value
    result, ex = safe_eval('3 + 5', include_exceptions=True)
    assert result == 8
    assert ex is None

    result, ex = safe_eval('a + b', {'a': 3, 'b': 5}, include_exceptions=True)
    assert result == 8
    assert ex is None

    result, ex = safe_eval('[1,2] + [3,4]', include_exceptions=True)
    assert result == [1, 2, 3, 4]
    assert ex is None

    result, ex = safe_eval('[1,2] + [3,4]', {'a': 3, 'b': 5}, include_exceptions=True)
    assert result == [1, 2, 3, 4]
    assert ex is None


# Generated at 2022-06-23 13:29:58.777592
# Unit test for function safe_eval
def test_safe_eval():
    '''Fail if the function safe_eval() doesn't work'''
    assert safe_eval("1+1") == 2
    assert safe_eval("2*2") == 4
    assert safe_eval("a*b", dict(a=6, b=7)) == 42
    assert safe_eval("foo['bar']", dict(foo=dict(bar='baz'))) == 'baz'
    assert safe_eval("None") is None
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("1==1") is True
    assert safe_eval("1!=1") is False
    assert safe_eval("1==2") is False
    assert safe_eval("1!=2") is True

# Generated at 2022-06-23 13:30:03.381985
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple numerical addition
    assert safe_eval("1+1", [], []) == 2

    # Test late evaluation
    assert safe_eval("from ansible import __version__", [], []) == "from ansible import __version__"

    # Test nested calls
    assert safe_eval("len([1,2,3,4,5])", [], []) == 5

    # Test variables and calls which is late evaluation
    assert safe_eval("ansible_version", {"ansible_version": "1.2.4"}, []) == "1.2.4"
    assert safe_eval("ansible_version", [], []) == "ansible_version"

    # Test nested calls with late evaluation
    assert safe_eval("len(ansible_version)", {"ansible_version": "1.2.4"}, []) == len

# Generated at 2022-06-23 13:30:12.073298
# Unit test for function safe_eval
def test_safe_eval():
    # This function tests that safe_eval behaves in the same way as eval,
    # except for the things that are intentionally excluded.

    # exclude short-circuit evaluations
    assert safe_eval("1 or 2") == 1
    assert safe_eval("0 and 2") == 0

    # exclude operator precedence
    assert safe_eval("1 + 2 * 3") == 7
    assert safe_eval("(1 + 2) * 3") == 9

    # exclude comparison operators
    assert safe_eval("1 < 2") is True
    assert safe_eval("1 <= 2") is True
    assert safe_eval("2 > 1") is True
    assert safe_eval("2 >= 1") is True
    assert safe_eval("1 == 2") is False

    # allow simple math
    assert safe_eval("1") == 1

# Generated at 2022-06-23 13:30:21.547469
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:33.945965
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run a simple test of safe_eval

    This includes checking that a simple name expression evaluates to the
    object in the local namespace and catching exceptions on invalid
    expressions.
    '''
    import pytest

    my_list = [1, 2, 3]

    # these should all be safe
    assert(safe_eval('my_list') == my_list)
    assert(safe_eval('my_list[0]') == 1)
    assert(safe_eval('my_list[1:]') == my_list[1:])
    assert(safe_eval('True') == True)
    assert(safe_eval('False') == False)
    assert(safe_eval('None') == None)
    assert(safe_eval('True and False') == False)
    assert(safe_eval('True or False') == True)

# Generated at 2022-06-23 13:30:41.062069
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:52.201754
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('1') == 1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1==2') == True
    assert safe_eval('foo') == 'foo'  # variable not defined
    assert safe_eval('type') == 'type'  # builtin not enabled
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('a_list_variable', dict(a_list_variable=[1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 13:31:03.911195
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('[ 1, 2, 3 ]') == [ 1, 2, 3 ]
    assert safe_eval('[ 1, 2, 3 ] + [ 4, 5, 6 ]') == [ 1, 2, 3, 4, 5, 6 ]
    assert safe_eval('1 + [ 1, 2, 3 ]') == [ 2, 3, 4 ]
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('{}') == {}

# Generated at 2022-06-23 13:31:10.468145
# Unit test for function safe_eval
def test_safe_eval():
    # test basic operations and types
    assert safe_eval("True")
    assert safe_eval("True or False")
    assert safe_eval("1 or 2")
    assert safe_eval("1 + 2 * 3") == 7
    assert safe_eval("1 + (2 * 3)") == 7
    assert safe_eval("2 * 3") == 6
    assert safe_eval("-2 * 3") == -6
    assert safe_eval("True and False") == False
    assert safe_eval("True and False") == False
    assert safe_eval("1 == 1")
    assert safe_eval("1 != 0")
    assert safe_eval("1 != 2") == True
    assert safe_eval("1.0 == 1")
    assert safe_eval("1.1 == 1.1")

# Generated at 2022-06-23 13:31:22.678127
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable", dict(a_list_variable=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval("a_dict_variable", dict(a_dict_variable=dict(b=2, a=1))) == dict(b=2, a=1)
    assert safe_eval("a_string", dict(a_string="foo")) == "foo"
    assert safe_eval("a_int", dict(a_int=42)) == 42
    assert safe_eval("a_float", dict(a_float=4.2)) == 4.2
    assert safe_eval("a_bool", dict(a_bool=False)) is False
    assert safe_eval("false") is False
    assert safe_eval("null") is None

# Generated at 2022-06-23 13:31:33.906365
# Unit test for function safe_eval
def test_safe_eval():
    module = AnsibleModule(argument_spec={})
    # test that syntax errors are caught
    test_expression = "{{{{ foo | capitalize }}}}"
    result, exception = safe_eval(test_expression, include_exceptions=True)
    module.fail_json(
        msg='safe_eval should not evaluate syntax errors',
        target_expression=test_expression,
        result=result,
        exception=exception
    )

    # test that evaling a string is prevented ... whitelist does not
    # include ast.Call
    test_expression = "\"foo bar baz\".split(' ')"
    result, exception = safe_eval(test_expression, include_exceptions=True)

# Generated at 2022-06-23 13:31:42.140194
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe parsing of simple statements
    assert(safe_eval('1') == 1)
    assert(safe_eval('-42') == -42)
    assert(safe_eval('1.0') == 1.0)
    assert(safe_eval('-42.0') == -42.0)
    assert(safe_eval('foo') == 'foo')
    assert(safe_eval('foo.bar()') == 'foo.bar()')
    assert(safe_eval('True') == True)
    assert(safe_eval('"true"') == "true")
    assert(safe_eval('["foo", "bar", "baz"]') == ["foo", "bar", "baz"])
    assert(safe_eval('{"foo": "bar"}') == {"foo": "bar"})

    # Test safe parsing of complex statements


# Generated at 2022-06-23 13:31:49.243157
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Verify that safe_eval is doing what we expect
    '''

    # Create a string that contains a valid Python expression
    # that will eval() to something, but is not a string containing JSON
    # Because the expression contains newlines, we cannot use single quotes
    # to delimit our string
    expr = """
        {
            'a_key': 'a_value',
            'a_nested_key': {
                'another_key': ['a', 'list']
            },
            "another_nested_key":
                b'The quick brown fox jumped over the lazy dog'
        }
    """
    expr = container_to_text(expr)

    # Evaluate our expression using safe_eval
    result1 = safe_eval(expr)

    # Evaluate the expression using safe_eval, but ask for exceptions


# Generated at 2022-06-23 13:31:59.683149
# Unit test for function safe_eval
def test_safe_eval():
    # no exception should be raised
    safe_eval("1 + 1")
    safe_eval("None")
    # the following call should raise an exception because
    # the python eval() function is a whitelisted function
    # and is not allowed by the custom visitor in our ast tree
    with open("/dev/null", "wb") as f:
        sys.stderr = f
        safe_eval("__import__('os').system('ls')")

# This code taken from yaml/__init__.py (PyYAML)
#
# Copyright (c) 2006 Kirill Simonov
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify,

# Generated at 2022-06-23 13:32:10.259851
# Unit test for function safe_eval
def test_safe_eval():
    def test_case(expr, expected):
        try:
            result = safe_eval(expr)
            if result != expected:
                print("Error processing: %s" % expr)
                print("Expected: %s" % expected)
                print("Got: %s" % result)
                sys.exit(1)
            else:
                print("OK: %s" % result)
        except Exception as e:
            print("Error processing: %s" % expr)
            print("Expected: %s" % expected)
            print("Error: %s" % e)
            sys.exit(1)

    # Simple tests
    test_case("null", None)
    test_case("true", True)
    test_case("false", False)
    test_case("1+1", 2)

# Generated at 2022-06-23 13:32:21.326861
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:31.769233
# Unit test for function safe_eval
def test_safe_eval():
    # Add test cases for all the different AST types
    # Each test case should include both a valid expression and invalid expression for the AST type

    # Add test cases for AST type: ast.Add
    # Valid expression
    assert safe_eval("1+1") == 2
    # Invalid expression
    assert safe_eval("1+'hi'") == "'hi'"

    # Add test cases for AST type: ast.BinOp
    # Valid expression
    assert safe_eval("'hi'+'there'") == "hithere"
    # Invalid expression
    assert safe_eval("'hi' + 1") == 1

    # Add test cases for AST type: ast.Call
    # Valid expression
    assert safe_eval("str(1)") == "1"
    # Invalid expression

# Generated at 2022-06-23 13:32:42.741251
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:48.906681
# Unit test for function safe_eval
def test_safe_eval():

    globals = {
        '__builtins__': {},  # avoid global builtins as per eval docs
        'false': False,
        'null': None,
        'true': True,
        # also add back some builtins we do need
        'True': True,
        'False': False,
        'None': None
    }

    # test 1, simple valid eval
    expr = '3 + 4'
    result = safe_eval(expr, globals)
    assert result == 7

    # test 2, simple invalid eval
    expr = 'a + b'
    try:
        result = safe_eval(expr, globals)
        assert False
    except:
        pass

    # test 3, simple invalid eval
    expr = '__builtins__.open("/etc/passwd")'

# Generated at 2022-06-23 13:32:58.561854
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from ansible.compat.tests import unittest
    except ImportError:
        # don't want to require unit test package just to run the test,
        # so skip it if it is not installed.
        return

    class TestEval(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_basic(self):

            # test simple expressions
            self.assertEquals(safe_eval('1+1'), 2)
            self.assertEquals(safe_eval('a', dict(a=1)), 1)

            # test list/dict literals
            self.assertEquals(safe_eval('[1, 2, 3]'), [1, 2, 3])