

# Generated at 2022-06-23 13:23:04.153198
# Unit test for function safe_eval
def test_safe_eval():

    # safe
    assert safe_eval('2 + 3') == 5
    assert safe_eval('[1, 2] + [3, 5]') == [1, 2, 3, 5]

    # safe if using builtins
    assert safe_eval('dict(a=1)') == {'a': 1}
    assert safe_eval('[[1], [2]]') == [[1], [2]]

    # unsafe, would allow arbitrary code execution
    assert safe_eval('__import__("os").system("rm -rf /")') == '__import__("os").system("rm -rf /")'

    # unsafe if using builtins
    assert safe_eval('__import__("sys").modules') == '__import__("sys").modules'



# Generated at 2022-06-23 13:23:12.821740
# Unit test for function safe_eval
def test_safe_eval():
    import nose

    # these are only used to show the right line numbers during the test
    def test_simple(expr):
        res, excep = safe_eval(expr, include_exceptions=True)
        assert excep is None, excep
        assert res == expr, res

    def test_fail(expr):
        res, excep = safe_eval(expr, include_exceptions=True)
        assert res is expr, res
        if isinstance(excep, AssertionError):
            raise excep
        assert excep is not None, excep

    # test various types of simple expressions
    test_simple("True")
    test_simple("1+1")
    test_simple("1")
    test_simple("'foo'")
    test_simple("['foo', 'bar']")

# Generated at 2022-06-23 13:23:22.586856
# Unit test for function safe_eval
def test_safe_eval():
    import os
    import time

    class Obj(object):
        OBJ_ATTR = 'hello'
        obj_dict = {
            'obj_key1': 1,
            'obj_key2': 2,
            'obj_key3': 3
        }

        def __init__(self):
            pass

    def obj_func():
        return 20


# Generated at 2022-06-23 13:23:31.619559
# Unit test for function safe_eval
def test_safe_eval():
    play_context = dict()
    play_context['vars'] = dict()

    # Test string concatenation
    expr = repr('a') + ' + ' + repr('b')
    assert safe_eval(expr, play_context['vars']) == 'ab'

    # Test boolean true and false
    expr = repr('a') + ' and ' + repr('b')
    assert safe_eval(expr, play_context['vars'])

    expr = repr('a') + ' and ' + repr('b') + ' and ' + repr('c')
    assert safe_eval(expr, play_context['vars'])

    expr = repr('a') + ' and ' + repr('false')
    assert not safe_eval(expr, play_context['vars'])

    expr = repr('a') + ' and ' + repr

# Generated at 2022-06-23 13:23:42.321435
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = {
        # simple cases
        "1+1": 2,
        "true": True,
        "null": None,
        "[1,2,3]": [1, 2, 3],
        "[1+1,2+2,3+3]": [2, 4, 6],
        "{'foo':'bar'}": {"foo": "bar"},
        # python built-ins are excluded, but boolean constants are allowed
        "min(1,2)": "min(1,2)",
        "foo in [1,2]": "foo in [1,2]",
        # TODO: ansible variables are excluded
        #"foo.bar": "foo.bar",
    }
    for test_str, result in test_cases.items():
        print("Testing: %s" % test_str)

# Generated at 2022-06-23 13:23:51.462341
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:01.923464
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:12.695976
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:21.889556
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from nose.tools import assert_equal, assert_false, assert_raises, assert_true
    except ImportError:
        raise ImportError('nose package is required to run tests')

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    assert_equal(safe_eval(1), 1)
    assert_equal(safe_eval('1'), 1)
    assert_equal(safe_eval('1 + 1'), 2)
    assert_equal(safe_eval('1 + 1 * 3'), 4)
    assert_equal(safe_eval('1 / 1'), 1)
    assert_equal(safe_eval('1 + -1'), 0)
    assert_equal(safe_eval('1 + -2 * 3'), -5)

# Generated at 2022-06-23 13:24:32.869612
# Unit test for function safe_eval
def test_safe_eval():

    def _test(input, valid_input, expected, expected_exception=None):
        output = safe_eval(input)
        if valid_input:
            assert output == expected
        else:
            assert output == input
        # Test exception handling
        if expected_exception is None:
            assert safe_eval(input, include_exceptions=True) == (expected, None)
        else:
            assert safe_eval(input, include_exceptions=True) == (input, expected_exception)

    # Test if the safe_eval function returns the expected value for input strings
    # Input string, valid input, expected output, expected exception
    _test("False", True, False)
    _test("true", True, True)
    _test("null", True, None)

# Generated at 2022-06-23 13:24:41.953401
# Unit test for function safe_eval
def test_safe_eval():
    begin_msg = "Testing evaluation of "
    end_msg = " ...OK"

    # This is a stupid test, we should try and fail on every one.
    # For now, just try passing different types we'd see in YAML
    # Note: python 2.6 doesn't have assertRaises(..)
    # TODO: Add a method decorator for testing, so we can do
    # more systematic testing.

    # TODO: Use the @unittest.skip decorator in newer versions
    # of python2.6 to skip some tests when we don't support them.
    if sys.version_info[:2] <= (2, 6):
        sys.stderr.write("Skipping some tests due to python version < 2.6\n")

    # a bool:

# Generated at 2022-06-23 13:24:50.561729
# Unit test for function safe_eval
def test_safe_eval():
    tests = dict()
    tests["[1, 2, 3]"] = [1, 2, 3]
    tests["2 + 3"] = 5
    tests["true and false"] = False
    tests["true or false"] = True
    tests["C.FOO"] = "FOO"

    for test_input, desirable in tests.items():
        # first test with no constraint
        result = safe_eval(test_input)
        assert result == desirable
        # then test with constraints
        result_constraints = safe_eval(test_input, locals={'C': C})
        assert result_constraints == desirable

    bad_expressions = ['import os', '__import__("os").system("ls -al")']

# Generated at 2022-06-23 13:24:59.524481
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:06.407084
# Unit test for function safe_eval
def test_safe_eval():

    def _assert_safe(expr, locals=None):
        result = safe_eval(expr, locals, include_exceptions=True)
        assert result[1] is None

    # Ensure that safe_eval returns the same output as regular eval()
    # when the input is constant, rather than a string.
    assert safe_eval(3) == 3
    assert safe_eval(3.0) == 3.0
    assert safe_eval(3) == eval(3)
    assert safe_eval(3.0) == eval(3.0)
    _assert_safe(3)
    _assert_safe(3.0)

    # test basic arithmetic
    _assert_safe('1 + 2')
    _assert_safe('1 + (1 + 1)')
    _assert_safe('1 + 1 + 1')
    _assert_

# Generated at 2022-06-23 13:25:12.936620
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:21.071063
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.split()') == "foo.split()"
    assert safe_eval('foo[:3]') == 'foo[:3]'
    assert safe_eval('1 + 1', dict(foo=2, bar=1)) == 2
    assert safe_eval('foo', dict(foo=2, bar=1)) == 2
    assert safe_eval('foo[:3]', dict(foo='foobar', bar=1)) == 'foo'
    assert safe_eval('bar + 1', dict(foo=2, bar=1)) == 2
    assert safe_eval('foo + 1', dict(foo=True, bar=1)) == 'True1'

# Generated at 2022-06-23 13:25:31.412463
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function to ensure safe_eval works as expected

    Run by using the command:
    python -m test.units.module_utils.safe_eval.test_safe_eval

    '''
    # Calls to builtin functions that we need, such as 'min'
    safe_builtins = ['min', 'max', 'abs', 'complex']
    for func in safe_builtins:
        assert safe_eval('%s(1)' % func) == eval(func)(1)

    # Operator precedence
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('1 + (2 * 3)') == 7

    # Arithmetic
    assert safe_eval('1 + 2') == 3

# Generated at 2022-06-23 13:25:40.829824
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:51.177253
# Unit test for function safe_eval
def test_safe_eval():
    try:
        from nose import SkipTest
    except ImportError:
        raise SkipTest("can't run safe_eval tests without nose installed")
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeVarsModule(object):
        def __init__(self, unsafe_proxy):
            self.__dict__['unsafe_proxy'] = UnsafeProxy(unsafe_proxy)

        def __getattr__(self, name):
            return getattr(self.__dict__['unsafe_proxy'], name)

        def __getitem__(self, name):
            return self.__dict__['unsafe_proxy'][name]



# Generated at 2022-06-23 13:26:03.282126
# Unit test for function safe_eval
def test_safe_eval():

    # List of expressions with the expected result
    tests = [
        (dict(expr='2+2', expected=4), ),
        (dict(expr='2+2 == 4', expected=True), ),
        (dict(expr='a_list_variable', expected='a_list_variable'), ),
        (dict(expr='a_list_variable', expected='a_list_variable', include_exceptions=True), ),
        (dict(expr='some_string', expected='some_string'), ),
        (dict(expr='a_list_variable', expected='a_list_variable', locals=dict(a_list_variable='foo')), ),
        (dict(expr='{"a": 1}', expected=dict(a=1)), ),
    ]


# Generated at 2022-06-23 13:26:11.438152
# Unit test for function safe_eval
def test_safe_eval():
    import random
    import sys
    import re
    global_list = [random.randint(1, 99) for r in range(10)]
    global_map = {'a': random.randint(1, 99), 'b': random.randint(1, 99)}
    for i in range(1000):
        expr = random.choice(global_list)
        success, exception = safe_eval(expr, include_exceptions=True)
        if exception is not None:
            sys.exit("safe_eval('%s') failed: %s" % (expr, exception))
        elif success != expr:
            sys.exit("safe_eval('%s') failed: %s != %s" % (expr, success, expr))
        # Test AnsibleVault
        expr = '"VARIABLE:%s"' % expr


# Generated at 2022-06-23 13:26:23.041579
# Unit test for function safe_eval
def test_safe_eval():
    import copy
    import re

    def test(expr, expected, locals=None, enable_call=False):
        if enable_call:
            CALL_ENABLED.append(enable_call)
        output = safe_eval(expr, dict(locals))
        if enable_call:
            CALL_ENABLED.pop()
        if output != expected:
            print("Error: %s != %s for %s" % (output, expected, expr))

    test('42', 42)
    test('[1,2,3]', [1, 2, 3])
    test('{"a": 1}', {"a": 1})
    test('foo', 'foo')
    test('foo.bar', 'foo.bar')
    test('foo.get("bar")', 'foo.get("bar")')

    # builtins
   

# Generated at 2022-06-23 13:26:30.016559
# Unit test for function safe_eval
def test_safe_eval():
    # Simple variable
    assert safe_eval('i_am_an_int', dict(i_am_an_int=1)) == 1
    assert safe_eval('i_am_a_bool', dict(i_am_a_bool=True))

    # All supported literals
    literals = (
        1,
        1.1,
        'string',
        True,
        False,
        None,
        [1, 2, 3],
        (1, 2, 3),
        {'one': 1}
    )
    for lit in literals:
        assert safe_eval(str(lit)) == lit

    # All supported operators
    # Addition
    assert safe_eval('1+2') == 3
    # Multiplication
    assert safe_eval('5*5') == 25
    # Subtraction

# Generated at 2022-06-23 13:26:38.944466
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval('1 + 2', include_exceptions=True)[0] == 3)
    assert(safe_eval('6*7', include_exceptions=True)[0] == 42)
    assert(safe_eval('a', {'a': 10}, include_exceptions=True)[0] == 10)
    assert(safe_eval('a["foo"]', {'a': {u'foo': u'bar'}}, include_exceptions=True)[0] == 'bar')
    assert(safe_eval('a[1]', {'a': [u'foo', u'bar']}, include_exceptions=True)[0] == 'bar')
    assert(safe_eval('"foo"', include_exceptions=True)[0] == 'foo')

# Generated at 2022-06-23 13:26:50.250243
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six import string_types
    MY_THINGS = [
        {'color': 'blue', 'type': 'truck', 'value': 'big'},
        {'color': 'green', 'type': 'truck', 'value': 'small'},
        {'color': 'purple', 'type': 'car', 'value': 'fast'},
        {'color': 'purple', 'type': 'dog', 'value': 'slow'},
        ]
    MY_THING = { 'color': 'pink', 'type': 'monkey', 'value': 'curious' }

    assert safe_eval('a == 1', dict(a=1)) == True
    assert safe_eval('a == 1', dict(a=2)) == False

# Generated at 2022-06-23 13:27:01.900488
# Unit test for function safe_eval
def test_safe_eval():
    # Test that safe_eval properly evaluates valid python
    assert safe_eval("a + b", dict(a=1, b=2)) == 3

    # Test that safe_eval returns the expression when provided with invalid python
    assert safe_eval("a)") == "a)"

    # Test that safe_eval properly evaluates valid boolean expressions
    assert safe_eval("a and b", dict(a=True, b=False)) == False

    # Test that safe_eval properly evaluates valid boolean expressions
    assert safe_eval("a or b", dict(a=True, b=False)) == True

    # Test that safe_eval properly evaluates valid comparison expressions
    assert safe_eval("a > 1", dict(a=1)) == False

    # Test that safe_eval properly evaluates valid comparison expressions

# Generated at 2022-06-23 13:27:12.793906
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval.
    '''

    # We want to do the following tests:
    # 1) Test for an invalid expression.
    # 2) Test for an invalid function call.
    # 3) Test for a valid expression.
    # 4) Test for a valid expression.
    # 5) Test for a valid expression with nested calls.
    # 6) Test for a valid expression with a call to a function with valid arguments
    # 7) Test for a valid expression with a call to a function with invalid arguments.
    # 8) Test for a valid expression with a call to a function with kwarg arguments.
    # 9) Test for a valid expression with a call to a function with kwarg arguments.
    # 10) Test for a valid expression with a call to a function with required arguments.


# Generated at 2022-06-23 13:27:23.068735
# Unit test for function safe_eval
def test_safe_eval():
    # Should pass, basic types
    assert safe_eval('42') == 42
    assert safe_eval('4.2') == 4.2
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    assert safe_eval('[1, "foo", true, false]') == [1, "foo", True, False]
    assert safe_eval('{"foo": "bar", "baz": 1}') == {"foo": "bar", "baz": 1}

    # Should pass, advanced math
    assert safe_eval('2 + 3 * 4') == 14
    assert safe_eval('(2 + 3) * 4') == 20

    # Should raise an exception, invalid type

# Generated at 2022-06-23 13:27:35.156518
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test for function safe_eval
    """
    # Set values to function variables to use in the function.
    expr = 'a_list_variable'
    locals = {'a_list_variable': ['item1', 'item2']}

    # Call the method under test
    result = safe_eval(expr, locals)

    # Test that the resulting value of the function is as expected
    assert result == ['item1', 'item2']

    # Set values to function variables to use in the function.
    expr = 'a_list_variable'
    locals = {'a_list_variable': ['item1', 'item2']}

    # Call the method under test
    result, exception = safe_eval(expr, locals, include_exceptions=True)

    # Test that the resulting value of the function is as expected

# Generated at 2022-06-23 13:27:40.271212
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:48.746578
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:56.094192
# Unit test for function safe_eval
def test_safe_eval():
    import os

    def test_call_good(f):
        global CALL_ENABLED
        old = CALL_ENABLED
        CALL_ENABLED = [f.__name__]
        r = safe_eval('%s()' % (f.__name__, ))
        assert r is not None
        CALL_ENABLED = old

    def test_call_bad(f):
        global CALL_ENABLED
        old = CALL_ENABLED
        CALL_ENABLED = []
        r, e = safe_eval('%s()' % (f.__name__, ), include_exceptions=True)
        assert r == '%s()' % (f.__name__, )
        assert e is not None
        CALL_ENABLED = old

    def test_expr_good(expr):
        r

# Generated at 2022-06-23 13:28:04.643870
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:16.836262
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('dict()') == {}
    assert safe_eval('dict(a=1,b=2)') == {'a': 1, 'b': 2}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[dict(a=1,b=2),dict(c=3,d=4)]') == [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    assert safe_eval('[1, 2, 3]', locals={}) == [1, 2, 3]
    assert safe_eval('[1, 2, 3]', locals={'looks_like_list': [1, 2, 3]}) == [1, 2, 3]

# Generated at 2022-06-23 13:28:30.095969
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestSafeEval(unittest.TestCase):
        '''Unit test for function safe_eval'''

        def _get_expr(self, value):
            """
            Makes an expression string from a value.
            """
            return container_to_text(value, quote=True)

        def _check_value(self, value):
            """
            Checks that safe_eval works with a value.
            """
            expr = self._get_expr(value)
            self.assertEqual(safe_eval(expr), value)

        def _check_expr(self, expr, value):
            """
            Checks that safe_eval works with an expression.
            """

# Generated at 2022-06-23 13:28:41.829308
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''

    def _test(expr, expected, locals=None, include_exceptions=False):
        result = safe_eval(expr, locals, include_exceptions)
        assert result == expected

        if locals is None:
            locals = {}

        if include_exceptions:
            expr, err = safe_eval(expr, locals, include_exceptions)
        else:
            expr = safe_eval(expr, locals, include_exceptions)

        if include_exceptions:
            assert err is None

        assert expr == expected

    # normal evaluation of expressions
    _test('1', 1)
    _test('True', True)
    _test('Hello', 'Hello')
    _test('{"a": 1}', dict(a=1))

# Generated at 2022-06-23 13:28:53.374877
# Unit test for function safe_eval
def test_safe_eval():
    # This demonstrates how to invoke this function, and
    # how it is intended to work.
    import textwrap

# Generated at 2022-06-23 13:29:00.622131
# Unit test for function safe_eval
def test_safe_eval():
    def fake_config(key, value=None, value_type=None, parse_default=False, do_reload=False):
        if key == 'DEFAULT_JINJA2_NATIVE':
            return False
        else:
            return value

    def fake_display(msg):
        pass

    assert safe_eval('test') == 'test'
    assert safe_eval('"test"') == 'test'
    assert safe_eval('"test" == "test"') is True
    assert safe_eval('[]') == []
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('{"test": "test"}') == {"test": "test"}
    assert safe_eval('{"test": "test"}.items()') == [('test', 'test')]
    assert safe_

# Generated at 2022-06-23 13:29:08.522717
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-argument
    def f(x):
        return x

    # A constant
    assert safe_eval("1 + 1") == 2
    assert safe_eval("dummy_var + 1") == "dummy_var + 1"
    assert safe_eval("f('hello')") == "f('hello')"

    # Safe builtins that we explicitly allowed
    assert safe_eval("None") is None
    assert safe_eval("True") is True
    assert safe_eval("False") is False

    # Safe operations
    assert safe_eval("True or False") is True

    # Safe containers
    assert safe_eval("[]") == []
    assert safe_eval("()") == ()
    assert safe_eval("{}") == {}

# Generated at 2022-06-23 13:29:21.567363
# Unit test for function safe_eval
def test_safe_eval():
    # simple expressions
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a', dict(a=1)) == 1
    assert safe_eval('a.b', dict(a=dict(b=2))) == 2
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert safe_eval('{"a": [1, 2, 3]}') == {'a': [1, 2, 3]}

    # These are all invalid and should raise

# Generated at 2022-06-23 13:29:29.347906
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_bytes

    # test simple expressions
    assert safe_eval("foo") == "foo"
    assert safe_eval("1") == 1
    assert safe_eval("1") != '1'
    assert safe_eval("None") is None
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("(1,2,3)") == (1, 2, 3)
    assert safe_eval("{1:2,3:4}") == {1: 2, 3: 4}
    assert safe_eval("foo", {"foo": "bar"}) == "bar"

# Generated at 2022-06-23 13:29:39.004693
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('[2, 3]') == [2, 3]
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('["a", "b"]') == ['a', 'b']
    assert safe_eval('[1, 2, 3] + [4, 5, 6]') == [1, 2, 3, 4, 5, 6]
    assert safe_eval('[1, 2, 3] + ["a", "b", "c"]') == [1, 2, 3, 'a', 'b', 'c']
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

# Generated at 2022-06-23 13:29:48.498628
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:58.438607
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('dict(one=1,two=2)') == dict(one=1, two=2)
    assert safe_eval('True') is True
    assert safe_eval('True and False') is False
    assert safe_eval('True or False') is True
    assert safe_eval('False or False') is False
    assert safe_eval('False and False') is False
    assert safe_eval('False and True') is False
    assert safe_eval('True and True') is True
    assert safe_eval('True or True') is True
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('1 + (2 * 3)') == 7


# Generated at 2022-06-23 13:30:09.663531
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo + bar") == "foo + bar"
    assert safe_eval("foo+bar") == "foo+bar"
    assert safe_eval("foo, bar") == "foo, bar"
    assert safe_eval("['foo','bar']") == ['foo','bar']
    assert safe_eval("1==1, 'foo'=='foo'") == (True, True)
    assert safe_eval("1==1, ['foo']==['foo']") == (True, False)
    assert safe_eval("1==1, ['foo']") == (True, ['foo'])
    assert safe_eval("1==1, ['foo'], 'bar'") == (True, ['foo'], 'bar')

# Generated at 2022-06-23 13:30:20.925836
# Unit test for function safe_eval
def test_safe_eval():
    # Safe
    assert(safe_eval("a['test']") == "a['test']")
    assert(safe_eval("a[1]") == "a[1]")
    assert(safe_eval("a[1:10]") == "a[1:10]")
    assert(safe_eval("a[1]['test']") == "a[1]['test']")
    assert(safe_eval("len(a)") == "len(a)")
    assert(safe_eval("a or b") == "a or b")
    assert(safe_eval("a and b") == "a and b")
    assert(safe_eval("a not in b") == "a not in b")
    assert(safe_eval("a in b") == "a in b")

# Generated at 2022-06-23 13:30:33.528019
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    if sys.version_info < (2, 7):
        raise SkipTest()
    else:
        assert safe_eval('True') is True
        assert safe_eval('False') is False
        assert safe_eval('None') is None
        assert safe_eval('true') is True
        assert safe_eval('false') is False
        assert safe_eval('null') is None
        assert safe_eval('1.0') == 1.0
        assert safe_eval('1+1') == 2
        assert safe_eval('[1]') == [1]
        assert safe_eval('(1, 1)') == (1, 1)
        assert safe_eval('{}') == {}
        assert safe_eval('{"one": 1}') == {"one": 1}

# Generated at 2022-06-23 13:30:40.743087
# Unit test for function safe_eval
def test_safe_eval():
    # verify that the safe_eval function works as expected

    assert safe_eval('1') == 1
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo.bar(1)') == 'foo.bar(1)'
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('foo == "bar"') == 'foo == "bar"'
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']

# Generated at 2022-06-23 13:30:51.866760
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('1==1') is True
    assert safe_eval('1==True') is True
    assert safe_eval('false==False') is True
    assert safe_eval('null') is None
    assert safe_eval('1+1') == 2
    assert safe_eval('1-1') == 0
    assert safe_eval('1+2-3') == 0
    assert safe_eval('(1+2)-3') == 0
    assert safe_eval('1+2+3') == 6
    assert safe_eval('(1+2)+3') == 6
    assert safe_eval('1+(2-3)') == 0
    assert safe_eval('(1+2)-3') == 0

# Generated at 2022-06-23 13:31:03.585315
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    try:
        from nose import tools
        from ansible.module_utils.common.text.converters import to_text
    except ImportError:
        print("Failed to import nose for safe_eval test")
        return

    # test a valid expression
    test_expression = 'a + b == c'
    tools.eq_(safe_eval(test_expression, dict(a=8, b=2, c=10)), True)

    # test an invalid expression
    # Note: eval raises a SyntaxError while safe_eval raises an Exception
    # Exception: invalid expression (a + b == c && 1)
    with tools.assert_raises(Exception) as context:
        safe_eval('a + b == c && 1', dict(a=8, b=2, c=10))

# Generated at 2022-06-23 13:31:10.399442
# Unit test for function safe_eval
def test_safe_eval():
    # test that with_items: { { foo: 1 } | combine(theme='json') } works as expected
    safe_eval("[{'foo': 1}]")
    try:
        safe_eval("[{'foo': 1}] | combine(theme='json')")
        assert False, "Expected an exception"
    except SyntaxError as e:
        assert "unexpected EOF" in to_native(e)
    except Exception as e:
        assert False, "Expected a syntax error, not %s" % to_native(e)


# Generated at 2022-06-23 13:31:22.674033
# Unit test for function safe_eval
def test_safe_eval():
    # These expressions should evaluate to True.
    true_exprs = [
        '1 == 1',
        'true',
        'false',
        'null',
        'false or true',
        '1 < 2',
        '1 + 2',
        '1 - 2',
        '1 * 2',
        '1 / 2',
        '-(1)',
        '-1',
        '["a", "b"]',
        '{"a": 1, "b": 2}',
        '{"b": 2, "a": 1}',
        '(1, 2)',
        '(1,)'
    ]

    # These expressions should evaluate to False.

# Generated at 2022-06-23 13:31:27.929443
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:39.428945
# Unit test for function safe_eval
def test_safe_eval():

    LOCAL_VARS = {
        'nested_data': {
            'key': 'value'
        },
        'template_data': '{{ nested_data.key }}'
    }

    FUNCTION_NAMES = [
        'repr', 'int', 'float', 'datetime', 'json', 'min', 'max', 'bool',
        'set'
    ]

    # Enable calls to builtins that are vetted as safe
    for fname in FUNCTION_NAMES:
        CALL_ENABLED.append(fname)

    # Test safe_eval with data that should work
    assert safe_eval('template_data') == 'value'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-23 13:31:47.825389
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:59.065937
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'Hello World'") == 'Hello World'
    assert safe_eval('[True, False]') == [True, False]
    assert safe_eval('{"hello": "world", "foo": "bar"}') == {"hello": "world", "foo": "bar"}
    assert safe_eval('["first", "second"]') == ['first', 'second']
    assert safe_eval('None') is None
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('7.1') == 7.1
    assert safe_eval('(7 + 1)') == (7 + 1)
    assert safe_eval('(-7 - 1)') == (-7 - 1)
    assert safe_eval('(-7 - 1)') == (-7 - 1)
    assert safe_

# Generated at 2022-06-23 13:32:09.882172
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:21.103436
# Unit test for function safe_eval
def test_safe_eval():
    old_display = C.ANSIBLE_DISPLAY_FAILED_STDERR


# Generated at 2022-06-23 13:32:31.591326
# Unit test for function safe_eval
def test_safe_eval():
    # test functions
    def test_func_allowed(*args, **kwargs):
        pass

    def test_func_disallowed(*args, **kwargs):
        pass

    # test variables
    test_var_allowed = "test_var_allowed"
    test_var_disallowed = "test_var_disallowed"

    # test dicts
    test_dict_allowed = {'a': 1, 'b': 2, 'c': 3}
    test_dict_disallowed = {'exec': True, 'print': True, 'eval': True}

    # make a variable mapping for safe_eval

# Generated at 2022-06-23 13:32:42.590565
# Unit test for function safe_eval
def test_safe_eval():
    globals = {}
    locals = {'foo': 'bar'}
    # Run syntax errors in python2 and python3 mode
    # as the module_utils tests are run in both modes
    # FIXME: remove the if when python2 support is dropped
    if sys.version_info[0] >= 3:
        exc = None
    else:
        exc = SyntaxError

    # The following unit tests are designed to test the correct behavior of
    # safe_eval.  The code to test is some valid python code that can be
    # evaluated.  We use the safe_eval function to evaluate it and the result
    # should be equal to the expected value.  If the safe_eval returns an
    # exception, we assert False.
    # The second of tuple is used to access the value in tests
    # It is used for booleans when evaluated outside

# Generated at 2022-06-23 13:32:49.976217
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six.moves import builtins
    class TestException(Exception):
        pass

    class MockOs(object):
        def __init__(self):
            self.pid = 42

        def open(self, *args):
            raise TestException('Attempt to open file %s' % args)

        def read(self, *args):
            raise TestException('Attempt to read file %s' % args)

        def close(self, *args):
            raise TestException('Attempt to close file %s' % args)

    old_os = sys.modules['os']


# Generated at 2022-06-23 13:32:59.297516
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Used for unit testing of safe_eval()
    '''

    # test cases for each AST node type