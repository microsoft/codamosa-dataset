

# Generated at 2022-06-23 13:23:06.385708
# Unit test for function safe_eval
def test_safe_eval():
    CALL_ENABLED.append('foo')
    splat = ['blue', 'red', 'green']
    result, _ = safe_eval("'.txt'.join(foo('%s'))" % splat, dict(foo=container_to_text), include_exceptions=True)
    assert result == 'blue.txtred.txtgreen'
    result, _ = safe_eval("''.join(foo('%s'))" % splat, dict(foo=container_to_text), include_exceptions=True)
    assert result == 'blueredgreen'
    result, _ = safe_eval("'.txt'.join(foo('%s'))" % splat, dict(foo=container_to_text), include_exceptions=True)
    assert result == 'blue.txtred.txtgreen'
    result, _ = safe_eval

# Generated at 2022-06-23 13:23:14.454550
# Unit test for function safe_eval
def test_safe_eval():
    # Passing tests
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("{'a': [1, 2, 3], 'b': 2}") == {'a': [1, 2, 3], 'b': 2}
    assert safe_eval("['a', 'b', 'c'] + ['d']") == ['a', 'b', 'c', 'd']
    assert safe_eval("['a', 'b', 'c'] * 2") == ['a', 'b', 'c', 'a', 'b', 'c']

# Generated at 2022-06-23 13:23:21.010213
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run unit tests to validate the safe_eval function.
    '''
    # import module snippets
    from ansible.module_utils.common._collections_compat import Mapping

    def fail_eval(expression):
        '''
        Evaluate an expression and fail if we don't get what we expect.
        '''
        expected = expression
        result = safe_eval(expression)
        assert result == expected, 'failed: %s != %s' % (result, expected)

    def fail_eval_exception(expression, exception):
        '''
        Evaluate an expression and fail if we don't get what we expect (with exception).
        '''
        expected = expression
        result, e = safe_eval(expression, include_exceptions=True)

# Generated at 2022-06-23 13:23:30.569093
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:36.791477
# Unit test for function safe_eval
def test_safe_eval():
    assert 2 == safe_eval("1+1")
    assert 1 == safe_eval("--- 1")
    assert 4 == safe_eval("2*2")
    assert True == safe_eval("1==1")
    assert False == safe_eval("1==0")
    assert False == safe_eval("true == 0")
    assert True == safe_eval("1 == 1")
    assert True == safe_eval("'foo' == 'foo'")
    assert True == safe_eval("foo in ['foo', 'bar']")
    assert True == safe_eval("foo not in []")
    assert True == safe_eval("foo not in ['baz']")
    assert False == safe_eval("foo in ['baz']")
    assert True == safe_eval("foo.split('.')[0] == 'foo'")
    assert 2 == safe

# Generated at 2022-06-23 13:23:48.918480
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is the list of assert results I had when validating the safe_eval function
    against all the items of the test_vars dictionary.
    """
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"1"') == "1"
    assert safe_eval('1 == 1') == True
    assert safe_eval('1 != 2') == True
    assert safe_eval('"foo" == "foo"') == True
    assert safe_eval('True == True') == True
    assert safe_eval('False == False') == True
    assert safe_eval('1 < 2') == True
    assert safe_eval('1 <= 1') == True
    assert safe_eval('2 > 1') == True

# Generated at 2022-06-23 13:23:58.197720
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:08.801191
# Unit test for function safe_eval
def test_safe_eval():
    # Test that a single argument is returned unchanged
    assert safe_eval("foo") == "foo"

    # Test that internal quotes are escaped
    assert safe_eval("'") == "'"
    assert safe_eval("'foo'") == "'foo'"

    # Test that a single argument is returned unchanged
    assert safe_eval("foo") == "foo"

    # Test that a single argument with quotes is also unchanged
    assert safe_eval("'foo'") == "'foo'"

    # Test that a single argument with escaped quotes is
    # correctly transformed to a string
    assert safe_eval("'foo\\'") == "foo\\'"

    # Test that a list is correctly transformed
    assert safe_eval("['foo']") == ['foo']

    # Test that a list of strings is correctly transformed
    assert safe_eval("['foo', 'bar']")

# Generated at 2022-06-23 13:24:16.227242
# Unit test for function safe_eval
def test_safe_eval():
    # test simple string
    test = "1"
    expected = 1
    result = safe_eval(test)
    assert expected == result

    # test simple eval
    test = "1 + 2"
    expected = 3
    result = safe_eval(test)
    assert expected == result

    # test builtin functions
    test = "len('foo')"
    expected = 3
    result = safe_eval(test)
    assert expected == result
    test = "foo"
    expected = "foo"
    result, exception = safe_eval(test, include_exceptions=True)
    assert expected == result
    assert exception is not None

    # test list lookups
    test = "foo[0]"
    expected = "foo"

# Generated at 2022-06-23 13:24:26.895634
# Unit test for function safe_eval
def test_safe_eval():
    def assert_eval(arg, value, e=None):
        if not e:
            assert value == safe_eval(arg)
        else:
            assert value == safe_eval(arg)[0]
            assert e == safe_eval(arg)[1]
    assert_eval("2", 2)
    assert_eval("2 + 2", 2 + 2)
    assert_eval("2 + 2 + 2", 2 + 2 + 2)
    assert_eval("var_a", "var_a")
    assert_eval("var_a.lower()")
    assert_eval("var_a.lower", "var_a.lower")
    assert_eval("'var_a'.lower()")
    assert_eval("'var_a'.lower")
    assert_eval("var_a.lower()", "var_a.lower()")


# Generated at 2022-06-23 13:24:33.190891
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as converters
    container_to_text = converters.container_to_text
    to_native = converters.to_native

    def test_when(a, b, c, d, e, f, g, h, i, j, k, l, expected, expected_exception):
        expr = '''\
{a} {b} {c} {d} {e} {f} {g} {h} {i} {j} {k} {l}'''.format(**locals())
        actual, exception = safe_eval(expr, include_exceptions=True)
        if expected_exception is not None:
            if not exception:
                print("parsed: %s" % expr)

# Generated at 2022-06-23 13:24:42.158209
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('[ 4, 6 ]') == [ 4, 6 ]
    assert safe_eval('[ 1, 2 ] + [3, 4]') == [ 1, 2, 3, 4 ]
    assert safe_eval('{ "a": 1, "b": "foo" }') == { 'a': 1, 'b': 'foo' }
    assert safe_eval('{ "a": 1, "b": "foo" }.keys()') == [ 'a', 'b' ]
    assert safe_eval('[1] * 2') == [ 1, 1 ]
    assert safe_eval('"c".upper()') == 'C'

# Generated at 2022-06-23 13:24:52.578261
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    assert safe_eval("foo") == "foo"
    assert safe_eval(42) == 42
    assert safe_eval(42, dict(locals=dict(foo=True))) == 42
    assert safe_eval(u"foo") == u"foo"
    assert safe_eval(u"foo\u1234") == u"foo\u1234"
    assert safe_eval(u"foo\u1234", dict(locals=dict(foo=True))) == u"foo\u1234"

    # Verify the function rejects unsafe code
    res = safe_eval("__import__('os').popen('ls').read()", dict(locals=dict(foo=True)))
    assert res == "__import__('os').popen('ls').read()"
   

# Generated at 2022-06-23 13:25:00.551188
# Unit test for function safe_eval
def test_safe_eval():
    # Verify that a string evaluating to an int works without raising an exception
    expr = "42"
    result, err = safe_eval(expr, include_exceptions=True)
    assert result == 42
    assert err is None

    # Verify that a string evaluating to a list works without raising an exception
    expr = "[42, 43]"
    result, err = safe_eval(expr, include_exceptions=True)
    assert result == [42, 43]
    assert err is None

    # Verify that a string evaluatint to a dict works without raising an exception
    expr = "{'foo': 42}"
    result, err = safe_eval(expr, include_exceptions=True)
    assert result == {'foo': 42}
    assert err is None

    # Verify that a string evaluating to a tuple works without raising an exception

# Generated at 2022-06-23 13:25:07.208337
# Unit test for function safe_eval
def test_safe_eval():
    '''
    >>> test_safe_eval()
    No Syntax Error raised
    '''
    expr = "[item for item in range(1, 5)]"
    safe_expr = safe_eval(expr)
    assert safe_expr == [1, 2, 3, 4]
    print("No Syntax Error raised")
    return True


if __name__ == "__main__":
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 13:25:17.695021
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:28.769583
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 2 == 4')
    assert not safe_eval('2 + 2 == 5')
    assert safe_eval('f()', {'f': lambda: True})
    # invalid syntax
    assert safe_eval('2 + 2 = 4') == '2 + 2 = 4'
    # invalid node type (call)
    assert safe_eval('a and b()', {'a': True}) == 'a and b()'
    # invalid node type (call) with invalid syntax
    assert safe_eval('a and b())', {'a': True}) == 'a and b())'
    # invalid node type (name)
    assert safe_eval('a.b', {'a': True}) == 'a.b'
    # invalid node type (name) with invalid syntax

# Generated at 2022-06-23 13:25:38.721687
# Unit test for function safe_eval
def test_safe_eval():

    # evaluation of basic types
    s = safe_eval('3')
    assert (type(s) is int) and (s == 3)
    s = safe_eval('"abc"')
    assert (type(s) is str) and (s == 'abc')
    s = safe_eval('True')
    assert (type(s) is bool) and (s is True)

    # evaluation of arithmetic expressions
    s = safe_eval('3 + 4')
    assert (type(s) is int) and (s == 7)
    s = safe_eval('3 + 4 * 2')
    assert (type(s) is int) and (s == 11)
    s = safe_eval('(3 + 4) * 2')
    assert (type(s) is int) and (s == 14)

# Generated at 2022-06-23 13:25:46.457216
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:54.592946
# Unit test for function safe_eval
def test_safe_eval():
    # test the basic case, make sure we can evaluate simple expressions
    assert safe_eval('a + 1 > 2') is False
    assert safe_eval('a == 1') is True
    assert safe_eval('"foo" + "bar"') == "foobar"

    # Test that exception is raised for invalid expressions
    try:
        safe_eval('foo()')
        assert False, "expected a safe eval exception"
    except Exception:
        pass

    # Test that it is safe to call the json module directly.  Because
    # we don't specifically allow this in the ast node filter, it should
    # not be possible to import json.
    try:
        safe_eval('json.dumps(foo)')
        assert False, "did not expect json to be importable"
    except Exception:
        pass

    # Test safe eval with exception

# Generated at 2022-06-23 13:26:07.026624
# Unit test for function safe_eval
def test_safe_eval():
    def _test(x, y, z):
        assert(safe_eval(x, locals=locals()) == y)
        assert(safe_eval('A %s B' % x, locals=locals()) == 'A %s B' % y)
        if z:
            assert(safe_eval(x, include_exceptions=True)[0] == y)
            assert(safe_eval('A %s B' % x, include_exceptions=True)[0] == 'A %s B' % y)
        else:
            assert(safe_eval(x, include_exceptions=True) == (x, None))
            assert(safe_eval('A %s B' % x, include_exceptions=True) == ('A %s B' % x, None))


# Generated at 2022-06-23 13:26:18.784816
# Unit test for function safe_eval
def test_safe_eval():
    # valid expressions
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('1+2 == 3')
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 in [1,2,3]')
    assert safe_eval('"foobar"') == 'foobar'
    assert safe_eval('"foo"+"bar"') == 'foobar'
    assert safe_eval('"foo" in "foobar"')
    # invalid expressions

# Generated at 2022-06-23 13:26:30.867060
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0:2] not in [(2, 7), (3, 5)]:
        raise Exception("safe_eval unit test requires Python 2.7 or 3.5 or newer, not %s." % sys.version)

    # success cases
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('dict()') == dict()
    assert safe_eval('dict(a=1,b=2)') == dict(a=1, b=2)
    assert safe_eval('[1,2,3,{{ 4 + 5 }},6]') == [1, 2, 3, 9, 6]

# Generated at 2022-06-23 13:26:39.412215
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''

    def do_test(expr, expected_result):
        '''
        Function to test function safe_eval
        '''
        result, _ = safe_eval(expr, include_exceptions=True)
        assert result == expected_result

    # Test basic math operations
    do_test("2 + 3", 5)
    do_test("6 - 2", 4)
    do_test("6 * 2", 12)
    do_test("6 / 2", 3)
    do_test("2 ** 3", 8)

    # Test variable names
    do_test("foo", 'foo')
    do_test("foo_bar_baz_99", 'foo_bar_baz_99')

    # Test boolean literals
    do_test("False", False)

# Generated at 2022-06-23 13:26:50.662426
# Unit test for function safe_eval
def test_safe_eval():
    C.HOST_KEY_CHECKING = False
    _ansible_constants_update_cache()

    some_vars = dict(
        a_list_variable = [1, 2, 3],
        a_dict_variable = dict(foo='bar', bar='baz'),
        a_numeric_variable = 99
    )

    # the following should pass
    assert safe_eval("a_list_variable", some_vars) == [1, 2, 3]
    assert safe_eval("a_dict_variable.foo", some_vars) == 'bar'
    assert safe_eval("a_dict_variable.keys()", some_vars) == ['foo', 'bar']
    assert safe_eval("a_dict_variable.values()", some_vars) == ['bar', 'baz']
    assert safe

# Generated at 2022-06-23 13:27:02.341436
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended to test safe_eval by defining a bunch of tests
    that check that safe_eval works as expected, and then run all of
    those tests.  The structure is inspired by Ansible test_utils
    and test_runner, but is done here in-line for simplicity.
    '''

    def assert_eval(evalstr, expected, locals=None):
        '''
        Takes an eval string, expected result, and optional locals.  If
        locals are not provided, then locals are empty.  If an exception
        is expected, then expected is a tuple of length 2, the first
        element is the exception object, and the second element is the
        string representation of the exception.
        '''

        if locals is None:
            locals = {}

        if sys.version_info >= (3, 0):
            locals['true']

# Generated at 2022-06-23 13:27:13.197796
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:23.443375
# Unit test for function safe_eval
def test_safe_eval():

    try:
        from nose.tools import assert_equals
    except:
        print("skipped: safe_eval unit tests require nose")
        return True

    print("testing safe_eval")
    assert_equals(safe_eval("1+1"), 2)
    assert_equals(safe_eval("'a'+'b'"), 'ab')
    assert_equals(safe_eval("('a','b','c')"), ('a','b','c'))
    assert_equals(safe_eval("[1,2,3]"), [1,2,3])
    assert_equals(safe_eval("dict(a=1,b=2,c=3)"), dict(a=1,b=2,c=3))


# Generated at 2022-06-23 13:27:35.397343
# Unit test for function safe_eval
def test_safe_eval():

    safe_eval('foo')
    safe_eval('True')
    safe_eval('foo or True')
    safe_eval('True and False')
    safe_eval('"foo" and "bar"')

    safe_eval('foo[bar]', {'foo': {'bar': 'baz'}})
    safe_eval('foo[bar][biz]', {'foo': {'bar': {'biz': 'baz'}}})

    safe_eval('foo+bar')
    safe_eval('foo+1')
    safe_eval('1+foo')

    safe_eval('(foo or True)+1')
    safe_eval('foo or (True+1)')

    safe_eval('foo and False+"bar"')
    safe_eval('foo+"bar" and False')


# Generated at 2022-06-23 13:27:43.889735
# Unit test for function safe_eval
def test_safe_eval():

    # dictionary with all test cases
    tests = dict()

    # boolean tests
    tests["true"] = True
    tests["True"] = True
    tests["false"] = False
    tests["False"] = False

    # string tests
    tests["test"] = "test"
    tests['test"test'] = "test\"test"
    tests[r'test\'test'] = "test'test"
    tests[r'test\\test'] = "test\\test"
    tests['test\ntest'] = "test\ntest"
    tests['test\r\ntest'] = "test\r\ntest"
    tests[r'test\\\r\ntest'] = "test\\\r\ntest"
    tests[r'test\x1b[0mtest'] = "test\x1b[0mtest"

# Generated at 2022-06-23 13:27:46.868527
# Unit test for function safe_eval
def test_safe_eval():
    # Known Good
    expr = "1+1"
    result = safe_eval(expr)
    assert result == 2

    # Known Bad
    bad_expr = "__import__('os').system('echo hello')"
    result = safe_eval(bad_expr)
    assert result == bad_expr

# Generated at 2022-06-23 13:27:58.696234
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:07.794258
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("dict(a=1, b=2)") == dict(a=1, b=2)
    assert safe_eval("('a', 'b', 'c')") == ('a', 'b', 'c')
    assert safe_eval("set(('a', 'b', 'c'))") == set(['a', 'b', 'c'])
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1 - 2") == -1


# Generated at 2022-06-23 13:28:14.568850
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:22.405970
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:32.095022
# Unit test for function safe_eval
def test_safe_eval():
    symbols_to_test = ['foo', 'foo-bar', 'bar_baz', 'bar.foo', 'foo0', '_bar', 'bar;', '\x00-bar']

    # Test const
    safe_exp = C.DEFAULT_INTERNAL_HASH_SUMMARY_INTERVAL
    result, exception = safe_eval(safe_exp, include_exceptions=True)
    if result is None or result != C.DEFAULT_INTERNAL_HASH_SUMMARY_INTERVAL or exception:
        sys.exit("Failed to evaluate and parse expression \"{0}\"".format(safe_exp))

    # Test safe expression with full path
    safe_exp = 'foo.bar0.baz[0].qux[1].foo-bar'

# Generated at 2022-06-23 13:28:42.922023
# Unit test for function safe_eval
def test_safe_eval():
    # yaml.safe_load only parses into the following types
    # so any expression should be reduced to types of those

    # Python3 does not have long
    if sys.version_info[0] == 2:
        python_types = (int, long, float, string_types, list, set, tuple, dict)
    else:
        python_types = (int, float, string_types, list, set, tuple, dict)


# Generated at 2022-06-23 13:28:53.590048
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:05.612639
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('false') is False
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval('false', include_exceptions=True) == (False, None)

# Generated at 2022-06-23 13:29:16.532950
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:26.769646
# Unit test for function safe_eval
def test_safe_eval():
    test_value = '[1,2,3]'

    # test with safe node and ensure proper evaluation
    evaluated = safe_eval(test_value)
    assert evaluated == [1, 2, 3]
    assert evaluated[0] == 1

    # test with unsafe node and ensure exception
    test_value = '__import__("os").system("ls")'
    try:
        safe_eval(test_value)
        assert False
    except Exception as e:
        assert "invalid expression" in str(e)

    # test with valid call that can be resolved
    test_value = "str(len('a'))"
    evaluated = safe_eval(test_value)
    assert evaluated == '1'

    # test with valid call that can be resolved but not allowed (should raise an exception)

# Generated at 2022-06-23 13:29:37.203715
# Unit test for function safe_eval
def test_safe_eval():
    imports = {
        'sys': {
            'version': sys.version,
        },
    }
    # these expressions should all succeed

# Generated at 2022-06-23 13:29:46.246018
# Unit test for function safe_eval
def test_safe_eval():
    class MockVars(object):
        test_dict = {'a': 'b'}
        test_list = [1, 2, 3]
        test_tuple = (4, 5, 6)

    func = safe_eval

    def assert_result(expr, expected):
        vars = MockVars()
        assert func(expr, vars) == expected
        assert func('[%s]' % expr, vars) == [expected]
        assert func('%s[0]' % expr, vars) == expected

    def assert_no_evaluation(expr):
        vars = MockVars()
        assert func(expr, vars) == expr

    def assert_syntax_error(expr):
        vars = MockVars()

# Generated at 2022-06-23 13:29:57.498025
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval on success cases
    assert safe_eval("2+2") == 4
    assert safe_eval("1 < 2") is True
    assert safe_eval("3 != 2") is True
    assert safe_eval("2 == 2") is True
    assert safe_eval("2 >= 3") is False
    assert safe_eval("3 <= 2") is False
    assert safe_eval("7.0") == 7.0
    assert safe_eval("'7.0'") == '7.0'
    assert safe_eval("2.0+2.0") == 4.0
    assert safe_eval("1.0 < 2.0") is True
    assert safe_eval("3.0 != 2.0") is True
    assert safe_eval("2.0 == 2.0") is True

# Generated at 2022-06-23 13:30:09.446220
# Unit test for function safe_eval
def test_safe_eval():

    def test_variable(x, result, err_msg=None):
        res, e = safe_eval(x, {}, include_exceptions=True)
        assert res == result, '%s != %s (%s): %s' % (res, result, x, err_msg)

    # Test a few valid expressions
    test_variable('foo', 'foo')
    test_variable('foo + foo', 'foofoo')
    test_variable('foo + foo or bar', 'foofoo')
    test_variable('foo + bar', 'foobar')
    test_variable('["foo", "bar"]', ['foo', 'bar'])
    test_variable('{"foo": "bar"}', {'foo': 'bar'})

# Generated at 2022-06-23 13:30:18.508568
# Unit test for function safe_eval
def test_safe_eval():
    # Proper Python syntax and safe function
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 + 3') != 6
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('dict(a="foo", b="bar")') == {'a': 'foo', 'b': 'bar'}
    assert safe_eval('list(a=1, b=2)') == [{'a': 1, 'b': 2}]
    assert safe_eval('(1, 2)') == (1, 2)

# Generated at 2022-06-23 13:30:25.899729
# Unit test for function safe_eval
def test_safe_eval():

    def assert_eval(expr, result):
        r = safe_eval(expr)
        assert r == result, "%s != %s" % (r, result)

    assert_eval('1', 1)
    assert_eval('1+2', 3)
    assert_eval('[1, 2, 3]', [1, 2, 3])
    assert_eval('{"foo": "bar"}', {"foo": "bar"})
    assert_eval('{"foo": [1, 2, 3]}', {"foo": [1, 2, 3]})
    assert_eval('{"foo": {"bar": "baz"}}', {"foo": {"bar": "baz"}})
    assert_eval('foo', "foo")

    assert_eval('1', 1)
    assert_eval('1+2', 3)

# Generated at 2022-06-23 13:30:35.312728
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Taken from:
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''

    # simple test to ensure the above code works.
    # Note: we want to ensure that only valid AST nodes
    #       are allowed, which is why this is somewhat
    #       complicated.
    class _TestNodeVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            raise Exception("invalid ast node: %s" % node.__class__.__name__)


# Generated at 2022-06-23 13:30:45.981954
# Unit test for function safe_eval
def test_safe_eval():
    # The following lines test the safe_eval function.
    if (safe_eval('2 + 3') != 5):
        raise Exception('safe_eval test 1 failed')
    if (safe_eval('x', {'x': 5}) != 5):
        raise Exception('safe_eval test 2 failed')
    if (safe_eval('x', {'x': 5}) != 5):
        raise Exception('safe_eval test 3 failed')
    try:
        safe_eval('__import__("os").listdir("/")')
        raise Exception('safe_eval test 4 failed')
    except:
        pass
    try:
        safe_eval('2 +')
        raise Exception('safe_eval test 5 failed')
    except:
        pass

# Generated at 2022-06-23 13:30:54.386473
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure safe_eval allows simple python constants
    assert safe_eval('42') == 42
    assert safe_eval('-42') == -42
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('["foo"]') == ["foo"]

    # Make sure safe_eval allows simple python expressions
    assert safe_eval('42 + 42') == 84
    assert safe_eval('42 - 42') == 0
    assert safe_eval('"foo" + "bar"') == "foobar"
    assert safe_eval('["foo"] + ["bar"]') == ["foo", "bar"]

    # Make sure safe_eval does not allow invalid keywords
    assert safe_eval('null') == None
    assert safe_eval('true') == True
    assert safe_eval('false') == False

    # Make sure safe_eval

# Generated at 2022-06-23 13:31:05.526368
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:15.971331
# Unit test for function safe_eval
def test_safe_eval():
    tests = []
    tests.append("2+2")
    tests.append("'hello'")
    tests.append("")
    tests.append("True")
    tests.append("['a', 'b', 'c']")
    tests.append("['a', [1, 'b', 'c'], 'c']")
    tests.append("'hello' + 'world'")
    tests.append("'hello' * 3")
    tests.append("None")
    tests.append("{'a': 'b', 'c': 'd'}")
    tests.append("{'a': [1, 'b', 'c'], 'c': {'1': 2, '2': 3}}")
    tests.append("[a for a in [1, 2, 3]]")
    tests.append("-1")
    tests

# Generated at 2022-06-23 13:31:26.757837
# Unit test for function safe_eval
def test_safe_eval():
    # tests based on http://docs.python.org/2/library/ast.html
    # Build a list comprehension
    node = ast.parse(
        '[' + ','.join(['x*x', 'x*x*x']) + ' for x in range(5)]',
        mode='eval'
    )
    assert safe_eval(node) == [0, 1, 4, 9, 16, 0, 1, 8, 27, 64]
    # Build a dict comprehension
    node = ast.parse(
        '{' + ','.join(
            ['%s:%s*%s' % (i, i, i) for i in range(5)]
        ) + '}',
        mode='eval'
    )

# Generated at 2022-06-23 13:31:38.254983
# Unit test for function safe_eval
def test_safe_eval():
    # Success cases
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'a' in 'abc'") is True
    assert safe_eval("'a' not in 'abc'") is False
    assert safe_eval("a in b", {"a": "x", "b": ["x", "y", "z"]}) is True
    assert safe_eval("a not in b", {"a": "x", "b": ["x", "y", "z"]}) is False

    # Error cases
    try:
        safe_eval("__import__('os').system('/bin/sh')")
        assert False, "safe_eval allowed __import__"
    except Exception:
        pass


# Generated at 2022-06-23 13:31:47.066189
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('false') is False
    assert safe_eval('a + b', {'a': 1, 'b': 2}) == 3
    assert safe_eval('a + b', {'a': 1, 'b': 2}, include_exceptions=True) == (3, None)
    assert safe_eval('["a","b"]') == ['a', 'b']
    assert safe_eval('a + b', {'a': 1, 'b': 2}) == 3
    assert safe_eval('a + b', {'a': 1, 'b': 2}, include_exceptions=True) == (3, None)


# Generated at 2022-06-23 13:31:58.956840
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe_eval on known string types, valid and invalid
    assert safe_eval('False') == False
    assert safe_eval('False and False') == False
    assert safe_eval('True and False') == False
    assert safe_eval('True and True') == True
    assert safe_eval('True or False') == True
    assert safe_eval('False or False') == False
    # Test multiple expressions
    assert safe_eval('False and False') == False
    assert safe_eval('x', {'x': False}) == False
    assert safe_eval('x or False', {'x': False}) == False
    assert safe_eval('x or False', {'x': True}) == True
    assert safe_eval('y', {'y': False}) == False
    assert safe_eval('z', {'z': False}) == False


# Generated at 2022-06-23 13:32:04.732029
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 + 3') == 6
    assert safe_eval('(True, False)') == (True, False)
    assert safe_eval('[True, False]') == [True, False]
    assert safe_eval('{"k1": "v1"}') == {"k1": "v1"}
    assert safe_eval('{"k1": {"k2": "v2"}}') == {"k1": {"k2": "v2"}}
    assert safe_eval('1 + True') == 2
    assert safe_eval('1 + None') is None
    assert safe_eval('"string"') == "string"
    assert safe_eval('"string with None %s" % None') == "string with None None"

# Generated at 2022-06-23 13:32:12.500699
# Unit test for function safe_eval
def test_safe_eval():
    # simple test to check that safe_eval operates safely
    result, err = safe_eval('a*3', {'a': 5}, include_exceptions=True)
    assert (result == 15) and (err is None)
    # unsafe test to check that safe_eval operates safely
    result, err = safe_eval('open("/etc/passwd", "r")', {}, include_exceptions=True)
    assert (result == 'open("/etc/passwd", "r")') and (err is not None)
    # simple test to check that safe_eval operates safely
    result, err = safe_eval('a*3', {'a': 5})
    assert result == 15



# Generated at 2022-06-23 13:32:22.674349
# Unit test for function safe_eval
def test_safe_eval():
    class NullStream(object):
        def write(self, x): pass
    sys.stderr = NullStream()
    mock_module = dict(
        a_list_variable=[1, 2],
        a_dict_variable=dict(a=1, b=2),
    )

    # test a basic datastructure
    test_ds = "[1, 2, 3]"
    v = safe_eval(test_ds, include_exceptions=True)
    assert v[0] == ast.literal_eval(test_ds)
    assert v[1] is None

    # test an expression
    test_expr = "[v for v in range(3)]"
    v = safe_eval(test_expr, dict(range=range), include_exceptions=True)
    assert v[0] == ast.literal_eval

# Generated at 2022-06-23 13:32:32.601483
# Unit test for function safe_eval
def test_safe_eval():
    import random
    import string

    random_numbers = [random.randint(0, 1000) for i in range(0, 20)]
    random_numbers_str = ','.join([str(x) for x in random_numbers])

    # generate a random list of strings
    random_strings = [''.join(random.choice(string.ascii_letters) for i in range(0, 20)) for i in range(0, 10)]
    random_strings_str = ','.join([x for x in random_strings])

    # generate a random list of dictionaries

# Generated at 2022-06-23 13:32:42.818046
# Unit test for function safe_eval
def test_safe_eval():
    def assert_success(expr, expected_value, locals=None):
        '''
        Evaluates expr, determines if the result matches expected_value.
        If not, an exception is raised.
        '''
        result = safe_eval(expr, locals=locals)
        assert result == expected_value, "Expected result %r, got %r" % (expected_value, result)

    def assert_failure(expr):
        '''
        Evaluates expr, determines if an exception was raised.
        If not, an exception is raised.
        '''
        result = safe_eval(expr)
        assert result == expr, "Expected an exception to be raised, but instead got %r" % result

    assert_success("1+1", 2)
    assert_success("True", True)

# Generated at 2022-06-23 13:32:50.142822
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval(...)
    # empty string
    assert safe_eval('') == ''

    # valid expressions
    assert safe_eval('0') == 0
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 * 2') == 3
    assert safe_eval('1 + (2 * 3)') == 7
    assert safe_eval('-1 + -2 * -3') == -7

    # invalid expressions
    assert safe_eval('__import__("os").getcwd()') == '__import__("os").getcwd()'
    assert safe_eval('1/0') == '1/0'

    # test safe_eval for data types

# Generated at 2022-06-23 13:32:59.403909
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import wrap_var

    # A few safe expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('(1 + 1, 3)') == (2, 3)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[a, b]', dict(a=1, b=2)) == [1, 2]
    assert safe_eval('[a, b]', dict(a=1, b=2, c=3)) == [1, 2]
    assert safe_eval('(1, {a: b})', dict(a=1, b=2)) == (1, {1: 2})
    assert safe_eval('a', dict(a=1, b=2)) == 1
   