

# Generated at 2022-06-23 13:23:04.660780
# Unit test for function safe_eval
def test_safe_eval():
    eval_str = "{{ foo }}+{{ bar }}"
    result = safe_eval(eval_str, dict(foo=1, bar=3))
    assert result == 4

    # Test that no exception is raised when we input unicode literals
    safe_eval("u'\u2665'")
    safe_eval("b'\u2665'")
    safe_eval("'\u2665'")
    safe_eval("'%c' % -6")

    # Test that unsafe syntax raises an error
    try:
        safe_eval("__import__('os').system('echo HACKED!')")
    except Exception as e:
        pass
    else:
        assert False, "safe_eval did not raise an exception"

    # Test that a safe call to a function raises an exception

# Generated at 2022-06-23 13:23:13.436320
# Unit test for function safe_eval
def test_safe_eval():

    def test_this(expr, expected):
        """
        Tests that expression expr evaluates to expected.
        """
        result = safe_eval(expr)
        if result != expected:
            raise AssertionError("%s should have been %s but was %s" %
                (expr, expected, result))

    # Test valid expressions
    test_this("True", True)
    test_this("False", False)
    test_this("None", None)
    test_this("true", True)
    test_this("null", None)
    test_this("'x'", 'x')
    test_this("1", 1)
    test_this("-1", -1)
    test_this("1+2", 3)
    test_this("1-2", -1)

# Generated at 2022-06-23 13:23:23.575372
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-23 13:23:31.683350
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import string_types

    def assert_result_type(result, result_type):
        assert isinstance(result, result_type), "Expected result of '%s' as %s but recieved %s" % (expr, result_type, type(result))

    def assert_res_and_type(expr, result_type, locals=None):
        result, ex = safe_eval(expr, locals=locals, include_exceptions=True)
        assert isinstance(result, result_type), "Expected result of '%s' as %s but recieved %s" % (expr, result_type, type(result))
        assert ex

# Generated at 2022-06-23 13:23:42.321538
# Unit test for function safe_eval
def test_safe_eval():
    assert C.DEFAULT_KEEP_REMOTE_FILES is not None
    assert safe_eval('3 + 3') == 6
    assert safe_eval('3 + 3') == 6
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('True == False') is False
    assert safe_eval('True and False') is False
    assert safe_eval('True or False') is True
    assert safe_eval('result = True') is True
    assert safe_eval('result = [1,2,3,4]') == [1,2,3,4]
    assert safe_eval('result = [1,2,3,4]', dict(result=None)) == [1,2,3,4]

# Generated at 2022-06-23 13:23:54.162455
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import ast
    except ImportError:
        sys.exit("SKIP: python 2.6 is required for the safe_eval unit test")

    # example provided by user on SO
    assert safe_eval("dict(zip(('a', 'b', 'c', 'd', 'e'), ('1', '2', '3', '4', '5')))") == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}

    # example provided by user on SO
    assert safe_eval("['abcd'[i] for i in range(4)]") == ['a', 'b', 'c', 'd']

    # test expressions that should be allowed

# Generated at 2022-06-23 13:24:01.332940
# Unit test for function safe_eval
def test_safe_eval():
    # Test for a boolean
    evaluated = safe_eval('True')
    assert evaluated == True

    # Test for a string
    evaluated = safe_eval('"test_string"')
    assert evaluated == "test_string"

    # Test for a dict
    evaluated = safe_eval('{"foo":"bar", "baz":"quux"}')
    assert evaluated == {"foo":"bar", "baz":"quux"}

    # Test for a list
    evaluated = safe_eval('[1, 2, "test_string"]')
    assert evaluated == [1, 2, "test_string"]

    # Test for a tuple
    evaluated = safe_eval('(1, 2, "test_string")')
    assert evaluated == (1, 2, "test_string")

    # Test for an integer
    evaluated = safe_eval('42')
   

# Generated at 2022-06-23 13:24:12.040580
# Unit test for function safe_eval
def test_safe_eval():
    # Boolean tests
    assert safe_eval('true')  == True
    assert safe_eval('false') == False

    # String tests
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" * 2') == 'foofoo'

    # Numeric tests
    assert safe_eval('2 + 3') == 5
    assert safe_eval('(2 * 3) + 1') == 7
    assert safe_eval('(2 * 3) + (1 * 5)') == 11

    # Tests of the syntax
    assert safe_eval('[True, True, False]') == [True, True, False]
    assert safe_eval('False and (True or False)') == False
    assert safe_eval('False and True or False') == False

# Generated at 2022-06-23 13:24:21.590607
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    assert safe_eval(to_native("1+1")) == 2
    assert safe_eval(to_native("2*2")) == 4
    assert safe_eval(to_native("[1,2]")) == [1, 2]
    assert safe_eval(to_native("{1:2}")) == {1: 2}
    assert safe_eval(to_native("{'a':'b'}")) == {'a': 'b'}
    assert safe_eval(to_native("True")) is True
    assert safe_eval(to_native("False")) is False
    assert safe_eval(to_native("None")) is None
    assert safe_eval(to_native("None"), include_exceptions=True) == (None, None)

# Generated at 2022-06-23 13:24:32.507503
# Unit test for function safe_eval
def test_safe_eval():

    # normal cases
    assert isinstance(safe_eval("['a', 'b', 'c']"), list)
    assert isinstance(safe_eval("{'a': 'b', 'c': 'd'}"), dict)
    assert isinstance(safe_eval("'a string'"), string_types)
    assert isinstance(safe_eval("True"), bool)
    assert isinstance(safe_eval("False"), bool)
    assert isinstance(safe_eval("null"), type(None))
    assert safe_eval("[item for item in foo]") == "[item for item in foo]"

    # with_items
    assert safe_eval("[ item | regex_search('a.*b')]") == "[ item | regex_search('a.*b')]"

    # invalid expressions

# Generated at 2022-06-23 13:24:41.668328
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases for safe_eval function
    # valid expression
    safe_eval("1 + 2 + 3")
    safe_eval("true")
    safe_eval("True")
    safe_eval("false")
    safe_eval("False")
    safe_eval("null")
    safe_eval("None")
    safe_eval("True or False")
    safe_eval("1 + 2 > 3")
    safe_eval("1 + 2 > 3 and 4 + 5 < 6")
    safe_eval("1 + 2 > 3 and 4 + 5 - 6 > 7")
    safe_eval("1 + 2 > 3 and 4 + 5 - 6 > 7 or 8 + 9 - 10 == 11")

# Generated at 2022-06-23 13:24:50.414086
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:53.576970
# Unit test for function safe_eval
def test_safe_eval():
    # Test a positive case
    ret = safe_eval("3 + 2")
    assert ret == 5

    # Test a negative case
    ret = safe_eval("__import__('sys').exit()")
    assert ret == "__import__('sys').exit()"

    # Test a positive use-case:
    ret = safe_eval("a_list_variable", dict(a_list_variable=[1,2,3]))
    assert ret == [1,2,3]

    # Test a negative use-case:
    ret = safe_eval("__import__('sys').exit()", dict(a_list_variable=[1,2,3]))
    assert ret == "__import__('sys').exit()"



# Generated at 2022-06-23 13:25:02.678530
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    # test safe_eval
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo + "bar"', {'foo': 'a'}) == 'abar'
    assert safe_eval('foo + "bar"', {'foo': 'a', 'bar': 'b'}) == 'abar'
    assert safe_eval('foo + "bar"', {'foo': 'a', 'bar': ['b']}) == 'abar'
    assert safe_eval('foo + "bar"', {'foo': 'a', 'bar': ['b'], 'baz': 'c'}) == 'abar'

# Generated at 2022-06-23 13:25:14.232868
# Unit test for function safe_eval
def test_safe_eval():
    # make sure we can evaluate stuff
    assert safe_eval('[a, b]') == ['a', 'b']
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('{"a": [1, 2, 3]}') == {'a': [1, 2, 3]}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 - 1') == 0
    assert safe_eval('1 * 5') == 5
    assert safe_eval('{{ VAR }}') == '{{ VAR }}'
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)

    # make sure we can safely evaluate stuff

# Generated at 2022-06-23 13:25:21.713850
# Unit test for function safe_eval
def test_safe_eval():

    FAILED = "failed!"

    def t_safe_eval(expr, expected, name=None):
        try:
            actual = safe_eval(expr)
            if actual != expected:
                print("%s: %r => %r (expected %r)" % (FAILED, expr, actual, expected))
            else:
                print("ok: %r" % expr)
        except Exception as e:
            print("%s: %r raised %r" % (FAILED, expr, e))

    t_safe_eval("1 + 1", 2)
    t_safe_eval("[1, 2] * 2", [1, 2, 1, 2])
    t_safe_eval("len([1, 2, 3])", 3)

# Generated at 2022-06-23 13:25:28.883223
# Unit test for function safe_eval
def test_safe_eval():
    # make sure it returns what it should
    assert safe_eval('True') is True

    # make sure it fails when it should
    try:
        safe_eval('__import__("sys").exit()')
    except Exception:
        pass
    else:
        assert False

    # make sure it fails when it should for unknown literals
    try:
        safe_eval('f')
    except Exception:
        pass
    else:
        assert False

if __name__ == '__main__':
    sys.exit(1)

# Generated at 2022-06-23 13:25:38.855455
# Unit test for function safe_eval
def test_safe_eval():
    def check(a, b=None):
        # Check to see if a and b are equal, print a message if they are
        # not.
        if a != b:
            print("%r != %r" % (a, b))

    check(safe_eval("1 + 1"), 2)
    check(safe_eval("1 + 1"), 3)

    # Check to see if we are raising an exception correctly
    check(safe_eval("int('hi')"), "int('hi')")
    check(safe_eval("1 + a", {"a": 1}), 2)
    check(safe_eval("1 + a", {"a": 1}), 3)

# Generated at 2022-06-23 13:25:46.550031
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable") == "a_list_variable"

    # for passing lists, the code must be templated to a python list
    # the important thing here is the double brackets, because Jinja2
    # otherwise treats this as a string representation of a list
    assert safe_eval("{{ [1,2,3] }}") == [1, 2, 3]

    # for booleans, these must also be passed as python bool literals
    assert safe_eval("{{ true }}") is True
    assert safe_eval("{{ false }}") is False

    # string literals are still supported
    assert safe_eval("{{ \"foo\" }}") == "foo"
    assert safe_eval("{{ \'foo\' }}") == "foo"

    # string literals are also still supported with more complex expressions
    assert safe_eval

# Generated at 2022-06-23 13:25:50.449222
# Unit test for function safe_eval
def test_safe_eval():
    # Shortcut for running tests if we import this as a module
    import os
    import sys
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..', 'plugins'))
    import test.utils as utils
    utils.run_module('test/safe_eval_test.py')

# Generated at 2022-06-23 13:26:01.056326
# Unit test for function safe_eval
def test_safe_eval():
    # No exception should be thrown for valid expressions
    for expr in ('1 + 1', '1 + 1 == 2'):
        assert safe_eval(expr) is True

    # Invalid expressions should raise an exception
    for invalid_expr in ('1 +', '1 + 1 = 2'):
        try:
            safe_eval(invalid_expr)
            # should not reach here
            assert False
        except Exception as e:
            pass

if __name__ == "__main__":
    if len(sys.argv) == 2:
        print(safe_eval(sys.argv[1]))
    else:
        print("Usage: safe_eval.py '<ansible vars>'")
        sys.exit(1)

# Generated at 2022-06-23 13:26:10.601340
# Unit test for function safe_eval
def test_safe_eval():
    CONSTANT_TESTS = (
        ('1 + 1', 2),
        ('1 - 1', 0),
        ('2 * 3', 6),
        ('10 / 5', 2),
        ('2 ** 8', 256),
        ('1 + 1 == 2', True),
        ('1 + 1 != 2', False),
        ('(1 + 1) in [1, 2]', True),
        ('1 in [1, 2]', True),
        ('[1, 2, 3]', [1, 2, 3]),
        ('1 in [1, 2, 3]', True),
        ('2 in [1, 2, 3]', True),
        ('4 in [1, 2, 3]', False),
    )

    #CONSTANT_TESTS_FAIL = (
    #    '(1 + 1) in [

# Generated at 2022-06-23 13:26:21.217338
# Unit test for function safe_eval
def test_safe_eval():
    # simple constants
    assert safe_eval("5") == 5
    assert safe_eval("'5'") == '5'
    assert safe_eval("5 * 3") == 15
    # lists
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("[1,2,[3,4]]") == [1, 2, [3, 4]]
    # dicts
    assert safe_eval("{'a': 'b', 'c': 1}") == {'a': 'b', 'c': 1}

    # these are not expressions, and so should raise an exception
    # (then, a fallback is used that returns the same expression, as a string)
    assert safe_eval("if True: print('Hello')") == "if True: print('Hello')"

# Generated at 2022-06-23 13:26:30.147058
# Unit test for function safe_eval
def test_safe_eval():

    # Evaluate this string to verify that safe_eval doesn't
    # change the result.  Do not modify this string unless
    # you really really really mean to.
    expr = "['a', 'b', 'c', 1, 2, 3, true, false, null]"

    # Test with no callables.  Locals is a dictionary that
    # symbolically represents what should be available to
    # templates when they are evaluated.
    l = safe_eval(expr, locals={})

    if l != ast.literal_eval(expr):
        sys.exit(1)



# Generated at 2022-06-23 13:26:39.049315
# Unit test for function safe_eval
def test_safe_eval():
    def test_safe(expr, value):
        assert safe_eval(expr) == value
        assert safe_eval(expr, include_exceptions=True)[0] == value

    def test_unsafe(expr):
        assert safe_eval(expr, include_exceptions=True)[0] == expr

    test_safe("1+1", 2)
    test_safe("'True'", "True")
    test_safe("True", True)
    test_safe("False", False)
    test_safe("None", None)
    test_safe("null", None)
    test_safe("[1, 2, 3]", [1, 2, 3])
    test_safe('{"a": "b"}', {"a": "b"})

# Generated at 2022-06-23 13:26:50.379318
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:02.074479
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:12.955633
# Unit test for function safe_eval
def test_safe_eval():
    def assert_syntax_error(expr):
        if sys.version_info >= (3, 0):
            assert isinstance(expr, SyntaxError)
        else:
            # In python 2.x SyntaxError is a subclass of StandardError
            assert isinstance(expr, Exception)

    # Test cases to verify that function safe_eval behaves as expected
    # Each test case includes:
    # - a description of the test case
    # - a dict containing input variables that are used in the test
    # - a dict containing the expected result of the test

# Generated at 2022-06-23 13:27:23.196990
# Unit test for function safe_eval
def test_safe_eval():
    # For more test cases, see module_utils/functions.py
    # That function also has more elaborate test cases,
    # but it does not return exceptions.
    # We don't need all of them here, we just want a few,
    # in order to test whether this function returns exceptions.

    # A few invalid expressions
    invalid_exprs = [
        "ansible.builtin.succeed",
        "int('1')",
        "abs(-1)",
        "2*3",
        "ansible.builtin.succeed('foo')",
        "#!/usr/bin/python",
    ]
    for expr in invalid_exprs:
        actual = safe_eval(expr, include_exceptions=True)
        assert isinstance(actual, tuple)
        assert isinstance(actual[1], Exception)
       

# Generated at 2022-06-23 13:27:35.197844
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    test_module = '''
        def test(var=None):
            return var
    '''
    # Test with a valid expression
    result = safe_eval('{"a": [1,2,3]}')
    assert isinstance(result, dict) and result == {"a": [1,2,3]}
    # Test with an invalid expression
    result = safe_eval('Test expression')
    assert isinstance(result, string_types) and result == 'Test expression'
    # Test with an invalid expression containing a builtin
    result = safe_eval('sum([1,2,3])')
    assert isinstance(result, string_types) and result == 'sum([1,2,3])'
    # Test with a valid expression containing a builtin
    CALL_ENABLED.append('sum')

# Generated at 2022-06-23 13:27:43.645169
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:52.580794
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Just to make sure we're not changing the function's logic too much,
    a simple unit test:
    '''

# Generated at 2022-06-23 13:28:02.854987
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:15.463585
# Unit test for function safe_eval
def test_safe_eval():
    with open("./test/safe_eval.py", 'r') as test_data:
        test_cases = ast.literal_eval(test_data.read())
        for case in test_cases:
            ev = safe_eval(case[0], include_exceptions=True)
            if ev[0] != case[1]:
                print("Input: %s" % to_native(case))
                print("Got %s" % to_native(ev[0]))
                print("Expected: %s" % to_native(case[1]))
            assert ev[0] == case[1], "Got %s, Expected: %s" % (to_native(ev[0]), to_native(case[1]))
            assert ev[1] is None, "Expected no exception, got %s" % to

# Generated at 2022-06-23 13:28:28.933571
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test to exercise safe_eval
    """
    # simple numerical expressions
    expr = '1 + 1'
    assert safe_eval(expr) == 2

    # a dictionary must be created via dict()
    expr = "{'a': 1}"
    assert safe_eval(expr, include_exceptions=True)[0] == expr

    expr = "dict(a=1)"
    assert safe_eval(expr) == dict(a=1)

    # a list must be created via []
    expr = "[1, 1]"
    assert safe_eval(expr) == [1, 1]

    # we can use len but not any other builtin that takes args
    expr = "len([])"
    assert safe_eval(expr) == 0

    expr = "len({})"
    assert safe_eval(expr) == 0



# Generated at 2022-06-23 13:28:40.563171
# Unit test for function safe_eval
def test_safe_eval():
    # simple scalars
    assert safe_eval('test') == 'test'
    assert safe_eval('{"test"}') == {"test"}
    assert safe_eval('test', include_exceptions=True) == ('test', None)
    assert safe_eval('{"test"}', include_exceptions=True) == ({"test"}, None)

    # JSON booleans
    assert safe_eval('True') is True
    assert safe_eval('false') is False

    # comparison operators
    assert safe_eval('1 == 1') is True
    assert safe_eval('1 == 2') is False
    assert safe_eval('1 != 2') is True
    assert safe_eval('1 != 1') is False
    assert safe_eval('1 > 2') is False
    assert safe_eval('2 > 1') is True

# Generated at 2022-06-23 13:28:52.304724
# Unit test for function safe_eval
def test_safe_eval():
    '''Test function safe_eval'''
    SIMPLE_EXPRESSIONS = [
        "2+2",
        "(2+2)/2",
        "1+1",
        "true",
        "false",
        "null",
        "'A random string'",
        "['a list', 'of expressions']",
        "{'a':'dictionary', 'of':'expressions'}",
        "'#octal-value: 0o777'",
    ]

    COMPLEX_EXPRESSIONS = [
        "{{ 'complex' }}",
        "{{ complex }}",
        "{{ 'complex expression' }}",
        "{{ complex expression }}",
        "{{ 'complex expression' | foo }}",
        "{{ complex expression | foo }}",
    ]


# Generated at 2022-06-23 13:29:02.542236
# Unit test for function safe_eval
def test_safe_eval():
    '''
    library/safe_eval.py
    '''

    r = safe_eval('[1,2]')
    assert isinstance(r, list)
    assert r == [1, 2]
    r = safe_eval('{"a": 2}')
    assert isinstance(r, dict)
    assert r == {"a": 2}
    r = safe_eval('"a string"')
    assert isinstance(r, string_types)
    assert r == "a string"
    r = safe_eval('true')
    assert isinstance(r, bool)
    assert r
    r = safe_eval('false')
    assert isinstance(r, bool)
    assert r == False
    r = safe_eval('null')
    assert r is None
    r = safe_eval('1 + 1')

# Generated at 2022-06-23 13:29:14.668400
# Unit test for function safe_eval
def test_safe_eval():
    # Basic sanity check
    assert safe_eval("2 + 3") == 5
    assert safe_eval("a_list_variable") == "a_list_variable"
    assert safe_eval("a_list_variable[3]") == "a_list_variable[3]"

    # Check that exceptions are raised as expected
    # Function calls should be disallowed unless whitelisted
    assert safe_eval("abs(-1)") == "abs(-1)"
    assert safe_eval("[1, 2, 3].index(2)") == "[1, 2, 3].index(2)"
    CALL_ENABLED.append('abs')
    assert safe_eval("abs(-1)") == 1
    CALL_ENABLED.append('index')
    assert safe_eval("[1, 2, 3].index(2)") == 1

    #

# Generated at 2022-06-23 13:29:26.037687
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:37.034139
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3

    safe_eval('1 + 1')
    safe_eval('[1,2,3]')
    safe_eval('{"foo": "bar"}')
    safe_eval('[1, 2, 3].append(7)')
    safe_eval('a_list', {'a_list': [1, 2, 3]})
    safe_eval('a_list["foo"]', {'a_list': {"foo": "bar", "baz": "wat"}})
    try:
        safe_eval('a_list["foo"]', {'a_list': "foo"})
        assert False, "Expected safe eval to fail for invalid list access"
    except Exception:
        pass

   

# Generated at 2022-06-23 13:29:46.153039
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:57.497985
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:09.315004
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo | default(bar) }}") == "{{ foo | default(bar) }}"
    assert safe_eval("{{ foo | default('bar') }}") == "{{ foo | default('bar') }}"
    assert safe_eval("{{ foo | default(5) }}") == "{{ foo | default(5) }}"
    assert safe_eval("{{ foo | default(omg) }}") == "{{ foo | default(omg) }}"
    assert safe_eval("{{ foo | default(5*5) }}") == "{{ foo | default(5*5) }}"
    assert safe_eval("{{ foo | default(5/0) }}") == "{{ foo | default(5/0) }}"

# Generated at 2022-06-23 13:30:20.754266
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:33.418516
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:40.621522
# Unit test for function safe_eval
def test_safe_eval():

    # Some expressions which should evaluate to true
    assert safe_eval('2 + 3 + 5') == 10
    assert safe_eval('abc or def') == 'abc'
    assert safe_eval('fjdskl or "a"') == 'fjdskl'
    assert safe_eval('fjdskl and "a"') == 'a'
    assert safe_eval('a or b or c') == 'a'
    assert safe_eval('a and b and c') == 'c'
    assert safe_eval('a and b or c') == 'b'
    assert safe_eval('a or b and c') == 'a'
    assert safe_eval('False or a') == 'a'
    assert safe_eval('False and a') == False
    assert safe_eval('True or a') == True
    assert safe_

# Generated at 2022-06-23 13:30:51.714732
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info < (2, 7):
        print("Skipping safe_eval unit tests for python 2.6")
        return
    assert safe_eval("42") == 42
    assert safe_eval("42.0") == 42.0
    assert safe_eval("42.42") == 42.42
    assert safe_eval("42.42 + 42.42") == 84.84
    assert safe_eval("42.0 + 42.42") == 84.42
    assert safe_eval("42.42 - 42.42") == 0.0
    assert safe_eval("42.42 - 42") == 0.42
    assert safe_eval("42.42 * 42") == 1764
    assert safe_eval("42.42 * 42.42") == 1764.84

# Generated at 2022-06-23 13:31:03.586249
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:12.302284
# Unit test for function safe_eval
def test_safe_eval():
    def test(value, expected_result=None, expected_exception=None):
        result, exception = safe_eval(value, include_exceptions=True)
        if expected_result is not None:
            assert result == expected_result
        if expected_exception is not None:
            assert isinstance(exception, expected_exception)

    # FIXME: write better tests
    test("True")
    test("False")
    test("None")
    test("True and False")
    test("True and False or True")
    test("True and (False or True)")
    test("True and (False or 1 + 1) == 2")
    test("False or 1 + 1")
    test("True and False", expected_exception=Exception)
    test("1 + 1", 2)
    test("1 + 1 == 2")

# Generated at 2022-06-23 13:31:17.256736
# Unit test for function safe_eval
def test_safe_eval():
    # This is more of a test of container_to_text() than safe_eval(),
    # since safe_eval() was borrowed from lib/ansible/module_utils/parsing
    # in Ansible 2.8.
    orig_fallback = C.DEFAULT_UNDEFINED_VAR_BEHAVIOR

# Generated at 2022-06-23 13:31:27.451554
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:39.044591
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{"foo": "bar"}'
    assert safe_eval(expr) == {"foo": "bar"}, "safe_eval Failed for " + expr

    expr = '{"foo": "bar"} + 1'
    assert safe_eval(expr) == 1, "safe_eval Failed for " + expr

    expr = '{"foo": "bar"} + -1'
    assert safe_eval(expr) == -1, "safe_eval Failed for " + expr

    expr = '{"foo": "bar"} + 1 + 2 + 3'
    assert safe_eval(expr) == 6, "safe_eval Failed for " + expr

    expr = '{"foo": "bar"} + "+" + "{" + "foo" + "}"}'
    assert safe_eval(expr) == '+{"foo}', "safe_eval Failed for " + expr



# Generated at 2022-06-23 13:31:47.282836
# Unit test for function safe_eval
def test_safe_eval():
    failed = False

# Generated at 2022-06-23 13:31:58.993904
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    import datetime as dt

    exprs = [(1, 1), ('a_string', 'a_string'), ('a_bool', True)]
    if sys.version_info[0] >= 3:
        exprs += [('a_bytes', b'a_bytes')]
    exprs += [(True, True), (dt.datetime.now(), dt.datetime.now())]

    test_vars = {
        'a_string': 'a_string',
        'a_bool': True
    }
    if sys.version_info[0] >= 3:
        test_vars.update({'a_bytes': b'a_bytes'})


# Generated at 2022-06-23 13:32:04.755658
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:13.560939
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    try:
        from nose.tools import assert_true, assert_false, assert_equal, assert_regexp_matches, assert_raises
    except ImportError:
        print("skipping evaluation tests, nose not available")
        return True

    # conditionals


# Generated at 2022-06-23 13:32:22.889780
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Evaluate all the expressions in list, returning a tuple of the
    result and an exception instance
    '''
    result, exception = safe_eval('1')
    assert result == 1

    result, exception = safe_eval('"foo"')
    assert result == 'foo'

    result, exception = safe_eval("'foo'")
    assert result == 'foo'

    result, exception = safe_eval("['foo', 'bar']")
    assert result == ['foo', 'bar']

    result, exception = safe_eval("{'foo': 1, 'bar': 2}")
    assert result == {'foo': 1, 'bar': 2}

    result, exception = safe_eval("len(['foo', 'bar'])")
    assert isinstance(exception, Exception)


# Generated at 2022-06-23 13:32:32.713674
# Unit test for function safe_eval
def test_safe_eval():
    failed = False

    print("Testing that simple expression can be evaluated")
    eval = safe_eval('foo + bar')
    if eval is True or eval is False or eval is None:
        print("safe_eval returned primitive type, expected expression")
        failed = True

    print("Testing that basic lists can be evaluated")
    valid_list = "['foo', 'bar']"
    invalid_list = "['foo', 'bar', (1,2,3)]"

    eval = safe_eval(valid_list)
    if eval != ['foo', 'bar']:
        print("safe_eval returned incorrect answer, expected [\"foo\", \"bar\"] got %s" % to_native(eval))
        failed = True


# Generated at 2022-06-23 13:32:39.797809
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:50.519235
# Unit test for function safe_eval
def test_safe_eval():
    import ast

    # This function tests the safe_eval function.
    # It enforces the following constraints:
    #   - The safe_eval function is a true drop-in replacement for ast.literal_eval
    #   - The safe_eval function will reject any expression that is accepted by ast.literal_eval, but that could
    #     potentially be dangerous.

    # The following example is taken from http://nedbatchelder.com/blog/201206/eval_really_is_dangerous.html.
    # It shows a case where ast.literal_eval will fail, but safe_eval will succeed.
    # This is because safe_eval is a true drop-in replacement for json.loads()
    complex_expr = "([c + 'and' + d for c in 'ABC' for d in 'XYZ'])"
    json_loads

# Generated at 2022-06-23 13:32:59.601583
# Unit test for function safe_eval
def test_safe_eval():
    # Valid expressions
    testvals = (
        ('[1,2,3]', [1, 2, 3]),
        ('{"foo": "bar"}', {"foo": "bar"}),
        ('{"foo": [1, 2]}', {"foo": [1, 2]}),
    )

    for s, e in testvals:
        v = safe_eval(s)
        assert (v == e)

    # Invalid expressions
    testvals2 = (
        'foo',
        '[1,2,3',
        '{"foo": "bar"',
        '{"foo": "bar", }',
    )

    for s in testvals2:
        try:
            safe_eval(s)
        except Exception as e:
            assert True
            continue