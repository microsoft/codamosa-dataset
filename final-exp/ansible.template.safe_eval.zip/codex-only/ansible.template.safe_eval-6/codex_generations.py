

# Generated at 2022-06-23 13:23:06.385828
# Unit test for function safe_eval
def test_safe_eval():
    # This function just triggers safe_eval() and collects the result
    def _safe_eval(expression, expression_str, locals_dict=None, include_exceptions=False):
        if locals_dict is None:
            locals_dict = {}
        try:
            if isinstance(expression, string_types):
                expression = ast.parse(expression, mode='eval')
            result = safe_eval(expression, locals=locals_dict, include_exceptions=include_exceptions)
            if include_exceptions:
                value, error = result
            else:
                value = result
        except SyntaxError as e:
            # special handling for syntax errors, we just return
            # the expression string back as-is to support late evaluation
            if include_exceptions:
                value, error = (expression_str, None)

# Generated at 2022-06-23 13:23:14.454724
# Unit test for function safe_eval
def test_safe_eval():
    expr = "1 + 2"
    expr_res = safe_eval(expr)
    if expr_res != 3:
        print("[!] test_safe_eval failed: expected 3, got: %s" % expr_res)
        sys.exit(1)

    expr = "1 + 2 < 5"
    expr_res = safe_eval(expr)
    if expr_res != True:
        print("[!] test_safe_eval failed: expected True, got: %s" % expr_res)
        sys.exit(1)

    expr = "a_list_variable | join(', ')"
    expr_res = safe_eval(expr, locals={'a_list_variable': ['a', 'b', 'c']})

# Generated at 2022-06-23 13:23:21.010776
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('foo', dict(foo=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval('foo', dict(foo={'bar': 'baz'})) == dict(bar='baz')
    assert safe_eval('foo', dict(foo=1)) == 1
    assert safe_eval('foo', dict(foo=100)) == 100
    assert safe_eval('foo', dict(foo=100.1)) == 100.1
    assert safe_eval('foo', dict(foo=True)) is True
    assert safe_eval('foo', dict(foo=False)) is False
    assert safe_eval('foo', dict(foo=None)) is None

# Generated at 2022-06-23 13:23:30.567577
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:38.258105
# Unit test for function safe_eval
def test_safe_eval():
    success = True

# Generated at 2022-06-23 13:23:42.766729
# Unit test for function safe_eval
def test_safe_eval():
    # simple expressions
    expr1 = "1 + 2"
    assert safe_eval(expr1) == 3

    # names used in expression must be defined as local variables
    foobar = "first_value"
    expr2 = "foobar"
    assert safe_eval(expr2) == "first_value"

    # reference to undefined name results in exception
    undefined_name = "test"
    try:
        safe_eval("undefined_name")
        raise AssertionError("should have raised exception")
    except:
        pass

    # This will fail because import is disallowed
    try:
        safe_eval("__import__('os').system('ls')")
        raise AssertionError("should have raised exception")
    except:
        pass

    # Use of dictionaries

# Generated at 2022-06-23 13:23:54.295689
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval("a+b", dict(a=1, b=2)) == 3
    assert safe_eval("foo", dict(foo=True)) is True
    assert safe_eval("foo", dict(foo=False)) is False
    assert safe_eval("foo", dict(foo=None)) is None
    assert safe_eval("foo", dict(foo=[])) == []
    assert safe_eval("foo", dict(foo=[1,2,3])) == [1,2,3]
    assert safe_eval("foo", dict(foo=dict(a=1, b=2))) == dict(a=1, b=2)

# Generated at 2022-06-23 13:24:03.645951
# Unit test for function safe_eval
def test_safe_eval():
    '''Unit test for function safe_eval'''
    def is_exception(expr):
        '''Helper function to test if an expression results in an exception'''
        e = safe_eval(expr, include_exceptions=True)
        return isinstance(e[1], Exception)

    # Some tests to ensure we handle various valid expressions properly
    assert safe_eval("1") == 1
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("[1,2]") == [1,2]
    assert safe_eval("{1:2}") == {1:2}
    assert safe_eval("(1,2)") == (1,2)
    assert safe_eval("len([1])") == 1

# Generated at 2022-06-23 13:24:11.915526
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('[1,2,3]')[0] == 1
    assert safe_eval('[1,2,3]')[1] == 2
    assert safe_eval('[1,2,3]')[2] == 3
    assert safe_eval('{ "a": 1, "b": 2 }')['a'] == 1
    assert safe_eval('{ "a": 1, "b": 2 }')['b'] == 2
    assert safe_eval('{"a": {"b": ["c","d"] }, "e": false}')['a']['b'][1] == "d"
    assert safe_eval('[1]*2') == [1, 1]

# Generated at 2022-06-23 13:24:21.588976
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test function safe_eval
    """

    # Dummy class for test
    class Dummy(object):
        def __init__(self):
            self.dummy = "dummy"

    # Test safe_eval()
    # First, define several expressions to eval

# Generated at 2022-06-23 13:24:30.080684
# Unit test for function safe_eval
def test_safe_eval():
    """This test function is not really a unit test, instead it
    is used to exercise safe_eval() in a fashion that allows
    visual inspection of the results.
    """
    print("\nExamples of safe things:")
    print("-----------------------")
    print("safe_eval('1') ==> ", safe_eval('1'))
    print("safe_eval('1 + 2') ==> ", safe_eval('1 + 2'))
    print("safe_eval('1*2') ==> ", safe_eval('1*2'))
    print("safe_eval('a_variable') ==> ", safe_eval('a_variable', {'a_variable': 1}))
    print("safe_eval('a_variable + 1') ==> ", safe_eval('a_variable + 1', {'a_variable': 1}))

# Generated at 2022-06-23 13:24:39.705006
# Unit test for function safe_eval
def test_safe_eval():
    module = None
    test_passed = True
    msg = ''

    # These expressions are safe and should pass

# Generated at 2022-06-23 13:24:49.332703
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3

    # test helper function for testing if a function is a builtin function
    def is_builtin_function(function):
        return function in vars(builtins).values()

    # add list of 'safe functions' to CALL_ENABLED
    for name in ('bool', 'dict', 'int', 'list', 'str', 'unicode'):
        CALL_ENABLED.append(name)

    # add list of 'safe classes' to CALL_ENABLED
    for name in ('bool', 'dict', 'int', 'list', 'str', 'unicode'):
        CALL_ENABLED.append(name)

    # Now run some unit tests against the safe_eval function.
    # Included are

# Generated at 2022-06-23 13:24:59.298722
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:06.314428
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+4") == 5
    assert safe_eval("a_list", {"a_list": [1, 2]}) == [1, 2]
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("abc_123") == "abc_123"
    assert safe_eval("null") is None
    assert safe_eval("a_list", {"a_list": [1, 2]}) == [1, 2]
    assert safe_eval("a_list.pop()", {"a_list": [1, 2]}) == 2
    assert safe_eval("a_list", {"a_list": "abcd"}) == "abcd"

# Generated at 2022-06-23 13:25:17.158811
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys

    if sys.version_info < (2,7):
        assert safe_eval("{{ foo }} or True") == "{{ foo }} or True"
        assert safe_eval("{{ foo }}") == "{{ foo }}"
        assert safe_eval("{{ foo }} | bar") == "{{ foo }} | bar"
        assert safe_eval("range(0,10)") == "range(0,10)"
        assert safe_eval("{{ 1 + range(0,10) }}") == "{{ 1 + range(0,10) }}"
        assert safe_eval("{{ a['b'] }}") == "{{ a['b'] }}"
        assert safe_eval("{{ a.b }}") == "{{ a.b }}"

# Generated at 2022-06-23 13:25:28.373226
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:38.675839
# Unit test for function safe_eval
def test_safe_eval():

    def test_safe_eval_one(expr, expected_result):
        # try without and without exception reporting
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result == expected_result
        assert exception is None

        result = safe_eval(expr)
        assert result == expected_result

    # Test list.
    test_safe_eval_one(expr='[1,2,3]', expected_result=[1, 2, 3])

    # Test dict.
    test_safe_eval_one(expr='{"a":1, "b":2, "c":3}', expected_result={'a': 1, 'b': 2, 'c': 3})

    # Test set.

# Generated at 2022-06-23 13:25:42.350412
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('true') is True
    try:
        safe_eval('ls')
        raise Exception("should have thrown exception")
    except:
        pass



# Generated at 2022-06-23 13:25:52.669180
# Unit test for function safe_eval
def test_safe_eval():
    expr = "a > 0"
    expected_result = True
    failure_msg = "Unsafe expression `%s` evaluated to %s instead of %s " % (expr, safe_eval(expr), expected_result)
    assert safe_eval(expr) == expected_result, failure_msg

    expr = "a > 1"
    expected_result = False
    failure_msg = "Unsafe expression `%s` evaluated to %s instead of %s " % (expr, safe_eval(expr), expected_result)
    assert safe_eval(expr) == expected_result, failure_msg

    expr = "2 ** 8"
    expected_result = 256
    failure_msg = "Unsafe expression `%s` evaluated to %s instead of %s " % (expr, safe_eval(expr), expected_result)

# Generated at 2022-06-23 13:26:05.370531
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval, which should return the same thing as eval() when
    given simple expressions, but raise an exception if given more
    complex expressions.
    '''

# Generated at 2022-06-23 13:26:13.218827
# Unit test for function safe_eval
def test_safe_eval():
    #include_exceptions = True or False
    include_exceptions = False
    res, error = safe_eval('True', include_exceptions=include_exceptions)
    assert res is True

    # basic test for `include_exceptions=True`
    res, error = safe_eval('[1,2,3]', include_exceptions=True)
    assert error is None

    try:
        res, error = safe_eval('1 + 1', include_exceptions=include_exceptions)
        assert res == 2
    except Exception as e:
        raise AssertionError(res)

    try:
        res, error = safe_eval('"1"', include_exceptions=include_exceptions)
        assert res == '1'
    except Exception as e:
        raise AssertionError(res)


# Generated at 2022-06-23 13:26:19.038939
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('[1,2,foo]') == "foo"
    assert safe_eval('{1:"foo",2:"bar"}') == {1: "foo", 2: "bar"}
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 - 3') == 0
    assert safe_eval('6 / 2') == 3
    assert safe_eval('3 * 4') == 12
    assert safe_eval('-3') == -3
    assert safe_eval('("foo", "bar")') == ("foo", "bar")

# Generated at 2022-06-23 13:26:27.757160
# Unit test for function safe_eval
def test_safe_eval():
    expr_ok = 'foo'
    expr_invalid = '__import__("os").system("echo hacked")'
    expr_invalid2 = 'import os;os.system("echo hacked")'

    safe_eval(expr_ok)

    try:
        safe_eval(expr_invalid)
        assert False, 'should not be able to execute random code'
    except:
        pass

    try:
        safe_eval(expr_invalid2)
        assert False, 'should not be able to execute random code'
    except:
        pass

# Generated at 2022-06-23 13:26:37.209909
# Unit test for function safe_eval
def test_safe_eval():
    foo = '''
    #!/usr/bin/python
    import os
    os.system('touch /tmp/success')
    '''

    # Test call to function not in whitelist
    try:
        safe_eval('os.system()')
        print("Expected exception for calling 'os', did not get one")
    except Exception:
        pass

    # Test calling to a function in whitelist
    safe_eval('open("/tmp/foo", "w")')
    safe_eval('dict().keys()')

    # Test calling to a function in whitelist
    safe_eval('__import__("os")')

    # Test calling not to a function in whitelist

# Generated at 2022-06-23 13:26:48.486240
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:59.367884
# Unit test for function safe_eval
def test_safe_eval():
    # Test that all of these should be True
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("None") == None
    assert safe_eval("obj == True") == True
    assert safe_eval("true") == True
    assert safe_eval("null") == None
    assert safe_eval("false") == False
    assert safe_eval("5+5") == 10
    assert safe_eval("20+20") == 40
    assert safe_eval("5+5-5") == 5
    assert safe_eval("5+5*5") == 30
    assert safe_eval("50/10") == 5
    assert safe_eval("50/10*10") == 50
    assert safe_eval("150/10/3") == 5

# Generated at 2022-06-23 13:27:10.587832
# Unit test for function safe_eval
def test_safe_eval():
    # The callable setting here allows the following code to work.
    # The 'bool' function is not generally allowed by safe_eval
    # But is allowed here.

    CALL_ENABLED = [
        'bool'
    ]

    # Scalars
    assert safe_eval('10') == 10
    assert safe_eval('"hello"') == 'hello'

    # Lists - with commas or not
    assert safe_eval('10,20,30') == [10, 20, 30]
    assert safe_eval('10 20 30') == [10, 20, 30]

    # Dictionaries - with commas or not
    assert safe_eval('{1: 2, 3: 4}') == {1: 2, 3: 4}

# Generated at 2022-06-23 13:27:20.186330
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'foo': 1}") == {'foo': 1}
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval('''"a"''') == 'a'
    assert safe_eval("10") == 10
    assert safe_eval("1+1") == 2
    assert safe_eval("2-1") == 1
    assert safe_eval("False") == False
    # this should return a string, as the syntax 'foo' is not a valid python expression
    assert safe_eval('foo') == 'foo'
    # this should return a string, as the syntax 'foo+bar'

# Generated at 2022-06-23 13:27:33.404978
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:42.929791
# Unit test for function safe_eval
def test_safe_eval():
    '''Unit tests for function safe_eval

    With this function we test several different inputs, and make sure that:
    * the input is evaluated to the expected result.
    * or that the expression passed in was not eval'd, and we simply returned
      the expression itself.

    We also test for errors, such as syntax errors or type errors, or calls
    to unsafe functions (builtin functions allowed in the AST).
    '''

    # These inputs should be properly executed

# Generated at 2022-06-23 13:27:51.757294
# Unit test for function safe_eval
def test_safe_eval():
    # Test a function call, which should not work
    try:
        if safe_eval('abs(1)') == 1:
            print("Failed to detect invalid function call")
            sys.exit(100)
    except Exception:
        pass

    # Importing a module, which should not work
    try:
        if safe_eval('import sys') is not None:
            print("Failed to detect module import")
            sys.exit(100)
    except Exception:
        pass

    # Arithmetic
    if safe_eval('1 + 2') != 3:
        print("Failed basic arithmetic")
        sys.exit(100)
    if safe_eval('1.0 + 2.0') != 3.0:
        print("Failed basic arithmetic with floats")
        sys.exit(100)

# Generated at 2022-06-23 13:28:02.479240
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('1') == 1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": 1}') == {"foo": 1}
    assert safe_eval('1.0') == 1.0
    assert safe_eval('foo') == "foo"
    assert safe_eval('foo.bar') == "foo.bar"

    assert safe_eval('foo, bar') == "foo, bar"
    assert safe_eval('foo.bar') == "foo.bar"

    assert safe_eval('foo and bar') == "foo and bar"

# Generated at 2022-06-23 13:28:15.267975
# Unit test for function safe_eval
def test_safe_eval():
    # Test that safe_eval raises an exception when trying to evaluate an
    # expression with an unknown type (for example, a JSON boolean)
    try:
        # Note: JSON booleans are unknown to python eval()
        safe_eval('true')
        assert False
    except Exception:
        assert True

    # Test that safe_eval can properly deal with a valid expression
    assert safe_eval('1 + 1') == 2

    # Test that safe_eval can properly deal with __builtins__
    assert safe_eval('hash("abc")') == hash('abc')

    # Test that safe_eval can properly deal with a variable
    assert safe_eval('foo', {'foo': 3}) == 3

    # Test that safe_eval can properly deal with __builtins__.get()

# Generated at 2022-06-23 13:28:28.789873
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic arithmetic operations
    assert safe_eval('1+1') == 2
    assert safe_eval('1+2*3') == 7
    assert safe_eval('(1+2)*3') == 9
    # Test booleans
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('true and false') == False
    assert safe_eval('true or false') == True
    # Test None
    assert safe_eval('null') == None
    assert safe_eval('null is null') == True
    # Test includes
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1, "b":2}') == {"a":1, "b":2}

# Generated at 2022-06-23 13:28:40.418853
# Unit test for function safe_eval
def test_safe_eval():
    # Test expressions that should pass
    test_pair('True', True)
    test_pair('1', 1)
    test_pair('a_list_variable', ['a', 'b', 'c'])
    test_pair('a_dict_variable', {'k': 'v'})
    test_pair('a_dict_variable["k"]', 'v')
    test_pair('a_dict_variable.k', 'v')
    test_pair('a_list_variable[1]', 'b')
    test_pair('1 + 1', 2)
    test_pair('1 + 1 == 2', True)
    test_pair('2 * 5', 10)
    test_pair('2 * (1 + 1)', 4)
    test_pair('"abc"', 'abc')

# Generated at 2022-06-23 13:28:48.127381
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=invalid-name

    # Make sure python won't exit on error
    C.DEFAULT_NO_TARGET_SYSLOG = False

    def assert_result(result, expected, expr=None):
        if expr is None:
            expr = repr(expected)
        if result != expected:
            raise AssertionError("Incorrect result for %s: %s != %s" % (repr(expr), repr(result), repr(expected)))

    def assert_exception(result, params):
        if result is not None:
            raise Ass

# Generated at 2022-06-23 13:28:57.728550
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1+1') == 2
    assert safe_eval('l.append(1)') is None
    assert safe_eval('l.append(1)', dict(l=[])) == [1]
    assert safe_eval('a') is None
    assert safe_eval('a', dict(a=3)) == 3
    assert safe_eval('a', include_exceptions=True) == ('a', None)
    assert safe_eval('1+-1') == 0
    assert safe

# Generated at 2022-06-23 13:29:09.504557
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.plugins.loader import find_plugin

    def _assert_safe_eval(x, y, z=None):
        if z is None:
            z = {}
        z['fail'] = True
        val, e = safe_eval(x, z, include_exceptions=True)
        z['fail'] = False
        if not (val == y and e is None):
            print("safe_eval(%s) = %s, exc = %s" % (x, val, e))
            assert (val == y and e is None)

    def _assert_safe_eval_error(x, z=None):
        if z is None:
            z = {}
        val, e = safe_eval(x, z, include_exceptions=True)

# Generated at 2022-06-23 13:29:18.688003
# Unit test for function safe_eval
def test_safe_eval():
    def test_safe_eval_helper(expr, locals=None, result=None):
        # To be able to handle functions, we need to define them
        # in the global scope.
        global dict_update, dict_update2
        def dict_update(d, u):
            d.update(u)
            return d
        def dict_update2(d, u):
            d.update(u)
            return d
        dict_locals = {'dict_update': dict_update}
        dict_locals.update(locals)
        assert safe_eval(expr, dict_locals) == result

    locals = {'a': 1, 'b': 2, 'c': 3, 'd': {'x': 1, 'y': 2, 'z': 3}}


# Generated at 2022-06-23 13:29:27.467502
# Unit test for function safe_eval
def test_safe_eval():
    f = safe_eval
    # good expressions
    assert f("['a','b','c']") == ['a', 'b', 'c']
    assert f("[]") == []
    assert (
        f("['a','b',['c','d']]") ==
        ['a', 'b', ['c', 'd']]
    )
    assert f("[1, 2, 5]") == [1, 2, 5]
    assert f("[0]") == [0]
    assert f("[]") == []
    assert f("['a','b',['c','d']]") == ['a', 'b', ['c', 'd']]

# Generated at 2022-06-23 13:29:37.741275
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2

    # These tests are marked with START_PROMPT in order to allow
    # the human developer to interactively enter the example on the
    # command line to demonstrate why these safe_eval examples
    # should return the expected results.

# Generated at 2022-06-23 13:29:46.398864
# Unit test for function safe_eval
def test_safe_eval():
    def assert_raises(expected_exception, func, args):
        try:
            func(*args)
        except expected_exception:
            pass
        else:
            pytest.fail("%s(%s) did not raise %s" % (func, args, expected_exception))

    old_ansible_stdout = sys.stdout
    # shut up test output
    sys.stdout = open(os.devnull, 'w')

    # Test cases
    # Syntax error
    assert(safe_eval('{"{') == '{"{')
    # Invalid node type
    assert_raises(Exception, safe_eval, '[]()')
    # Disallowed builtin function
    assert_raises(Exception, safe_eval, '__import__()')
    # Allowed builtin function

# Generated at 2022-06-23 13:29:57.498745
# Unit test for function safe_eval
def test_safe_eval():
    # test constants
    x = safe_eval('0')
    assert 0 == x, "Expected 0, got:" + str(x)
    x = safe_eval('1')
    assert 1 == x, "Expected 1, got:" + str(x)
    x = safe_eval('true')
    assert True == x, "Expected True, got:" + str(x)
    x = safe_eval('false')
    assert False == x, "Expected False, got:" + str(x)
    x = safe_eval('null')
    assert None == x, "Expected None, got:" + str(x)
    x = safe_eval('[]')
    assert [] == x, "Expected [], got:" + str(x)
    x = safe_eval('{}')

# Generated at 2022-06-23 13:30:09.314996
# Unit test for function safe_eval
def test_safe_eval():
    expr = '2 ** 3 - 1'
    result = safe_eval(expr)
    assert result == 7
    assert isinstance(result, int)

    expr = '[ 1, 2, 3 ]'
    result = safe_eval(expr)
    assert result == [1, 2, 3]
    assert isinstance(result, list)

    expr = '{ "a": 1, "b": 2 }'
    result = safe_eval(expr)
    assert result == { u"a": 1, u"b": 2 }
    assert isinstance(result, dict)

    expr = '{"a": 1, "b": {"c": 3}}'
    result = safe_eval(expr)
    assert result == { u"a": 1, u"b": { u"c": 3 } }
    assert isinstance(result, dict)



# Generated at 2022-06-23 13:30:20.705186
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:33.417610
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("{'a':True}") == {'a': True}
    assert safe_eval("5") == 5
    assert safe_eval("-5") == -5
    assert safe_eval("5.5") == 5.5
    assert safe_eval("-5.5") == -5.5
    assert safe_eval("5.5+10") == 15.5
    assert safe_eval("5.5+10.1") == 15.6
    assert safe_eval("5.5-10") == -4.5
    assert safe_eval("5.5-10.1") == -4.6
    assert safe_eval("5.5*10") == 55

# Generated at 2022-06-23 13:30:43.943811
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Function to test the function safe_eval by providing test cases
    '''

# Generated at 2022-06-23 13:30:53.780638
# Unit test for function safe_eval
def test_safe_eval():

    sys.stdout.write("Testing safe_eval")  # noqa

    # Simple test with no Jinja2 templating
    result = safe_eval("foo + 'bar'")
    if result != "foobar":
        raise AssertionError("Test failed: (%s) != (%s)" % (result, "foobar"))

    # Test with Jinja2 templating
    result = safe_eval("{{ foo }}bar")
    if result != "foobar":
        raise AssertionError("Test failed: (%s) != (%s)" % (result, "foobar"))

    # Test with Jinja2 template that contains syntax error
    result = safe_eval("{{ foo + }bar")

# Generated at 2022-06-23 13:31:05.172775
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that valid expressions evaluate as expected
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo + bar') == 'foo + bar'
    assert safe_eval('foo - bar') == 'foo - bar'
    assert safe_eval('foo * bar') == 'foo * bar'
    assert safe_eval('foo / 2') == 'foo / 2'
    assert safe_eval('foo.bar.bamf') == 'foo.bar.bamf'
    assert safe_eval('foo.bar().bamf') == 'foo.bar().bamf'
    assert safe_eval('foo[bar]') == 'foo[bar]'

# Generated at 2022-06-23 13:31:15.222577
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval() with a variety of expressions.
    We test for the correct evaluation of the expression and also
    for the exception that should be raised to reject unsafe expressions.
    '''
    # Test enabling a builtin function
    safe_eval('min([2, 3])', include_exceptions=True,
              locals={'min': min})
    # Test disallowing calling a builtin function
    try:
        safe_eval('min([2, 3])', include_exceptions=True)
        raise Exception("should have raised exception")
    except Exception:
        pass
    # Test enabling a call to a builtin function
    safe_eval("min([2, 3])", include_exceptions=True,
              locals={'min': min, '__builtins__': {}})
    # Test enabling a call to a built

# Generated at 2022-06-23 13:31:26.417433
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test cases for safe_eval
    Based on http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''

# Generated at 2022-06-23 13:31:27.122428
# Unit test for function safe_eval
def test_safe_eval():
    pass


# Generated at 2022-06-23 13:31:38.598176
# Unit test for function safe_eval
def test_safe_eval():
    TEST_PASSED = 0
    TEST_FAILED = 1
    TEST_SKIPPED = 2
    test_results = []

    if sys.version_info[0] == 2:
        TEST_PASSED = "PASSED"
        TEST_FAILED = "FAILED"
        TEST_SKIPPED = "SKIPPED"

    def test(results, safe_eval_function, good_expressions, bad_expressions):
        '''
        Run a test case and save results in a list
        '''
        def run_test(results, expr, expected_result, expr_type, is_safe_eval):
            '''
            Run a test with the good or bad expressions and save the results
            '''
            if is_safe_eval:
                result = safe_eval_function(expr)

# Generated at 2022-06-23 13:31:47.061349
# Unit test for function safe_eval
def test_safe_eval():
    # TEST BUILTIN
    constant_strings = [
        "1",
        "true",
        "True",
        "TRUE",
        "false",
        "False",
        "FALSE",
        "none",
        "None",
        "Null",
        "'string'",
        '"string"',
        "''",
        '""',
        "'1'",
        '"1"',
        "'true'",
        '"true"'
    ]
    builtin_calls = [
        ("len('abc')", 3),
        ("bool('abc')", True),
        ("str(1)", '1'),
        ("str(1, 'utf-8')", '1')
    ]

    for expr in constant_strings:
        assert expr == safe_eval(expr)


# Generated at 2022-06-23 13:31:58.970717
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This simple test suite covers the basic functionality of safe_eval.
    Obviously, there is a lot more to check, but we'll just cover some
    basic things.
    '''

    # First, we'll check that we can safely evaluate some simple expressions.
    assert safe_eval(1) == 1
    assert safe_eval('1') == 1
    assert safe_eval(True) is True
    assert safe_eval('True') is True
    assert safe_eval(True) is True
    assert safe_eval('True') is True
    assert safe_eval('a_string') == 'a_string'
    assert safe_eval('1 == 1') is True
    assert safe_eval('a_string == "a_string"') is True
    assert safe_eval('a_string != "a_string"') is False

# Generated at 2022-06-23 13:32:09.843052
# Unit test for function safe_eval
def test_safe_eval():
    def _assert_eval_success(expr, expected_result):
        result = safe_eval(expr)
        assert result == expected_result

    def _assert_eval_failure(expr):
        engine_exc = None
        try:
            result = safe_eval(expr)
            assert result is None
        except Exception as exc:
            engine_exc = exc
        assert engine_exc is not None

    call_expr_enabled = """
        (1, 2, 3)
        """
    _assert_eval_success(call_expr_enabled, (1, 2, 3))

    # check for calls to a disallowed builtin and non-identifiers
    _assert_eval_failure("abs(1)")
    _assert_eval_failure("'{0}'.format(1)")
    _assert_eval_fail

# Generated at 2022-06-23 13:32:16.633478
# Unit test for function safe_eval
def test_safe_eval():
    def assert_exception(expr, msg):
        result, exception = safe_eval(expr, include_exceptions=True)
        assert exception is not None
        assert expr == result
        assert msg in to_native(exception)

    # test simple literals
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'key1': 'value2'}") == {'key1': 'value2'}
    assert safe_eval("1 + 2") == 3
    assert safe_eval("a_var") == "a_var"
    assert safe_eval("1.5 / 1") == 1.5

    # test that we forbid function calls
    assert_exception("dir()", "function: dir")

# Generated at 2022-06-23 13:32:28.775240
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:41.123804
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import sympy
    except ImportError:
        return

    # Note that since sympy is not whitelisted in our
    # safe_eval function, we do not expect it to work
    # with this function, but should be fine with the
    # regular eval() function

# Generated at 2022-06-23 13:32:53.258374
# Unit test for function safe_eval
def test_safe_eval():

    def evaluate(expr):
        return safe_eval(expr)

    # Should return True
    assert evaluate('true') is True
    assert evaluate('false') is False
    assert evaluate('null') is None
    assert evaluate('True') is True
    assert evaluate('False') is False
    assert evaluate('None') is None

    # Should return 'somestring'
    assert evaluate('"somestring"') == 'somestring'
    assert evaluate('\'somestring\'') == 'somestring'

    # Should return an empty list
    assert evaluate('[]') == []

    # Should return an empty dict
    assert evaluate('{}') == {}

    # Should return 42
    assert evaluate('1 + 1 + 40') == 42
    assert evaluate(' 42 ') == 42

# Generated at 2022-06-23 13:33:00.538860
# Unit test for function safe_eval
def test_safe_eval():
    # use this to test exceptions
    include_exceptions = True

    # Simple test with a valid expression
    expr = "1 + 2"
    result, exception = safe_eval(expr, include_exceptions=include_exceptions)
    assert result == 3
    assert exception is None
    assert expr == "1 + 2"

    # Test with an invalid expression
    expr = "1 + 2 foo"
    result, exception = safe_eval(expr, include_exceptions=include_exceptions)
    assert result == expr
    assert exception is not None
    assert expr == "1 + 2 foo"

    # Test with a valid expression and an additional local variable
    expr = "1 + y"
    y = 2