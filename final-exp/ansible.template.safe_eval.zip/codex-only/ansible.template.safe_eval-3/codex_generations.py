

# Generated at 2022-06-23 13:22:56.768583
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:08.730082
# Unit test for function safe_eval
def test_safe_eval():

    def _fuq(msg):  # convenience function for formatting test messages
        return "failed: %s: %s" % (to_native(msg), to_native(repr(ans)))

    def _fae(msg):  # convenience function for formatting test messages
        return "failed: %s: %s" % (to_native(msg), to_native(e))

    print("testing safe_eval (this may take a moment)")

    for s in ['true', 'false', 'null']:
        print("... testing %s" % s)
        ans = safe_eval(s)
        if not isinstance(ans, (bool, type(None))):
            sys.exit(_fuq("%s result should be a bool" % s))

    # test literals

# Generated at 2022-06-23 13:23:18.993107
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 + 2", include_exceptions=True) == (3, None)
    assert safe_eval("1 + 2", locals={"one": 1}) == 3
    assert safe_eval("one + 2", locals={"one": 1}) == 3
    assert safe_eval("1 + 2", locals={"one": 1}, include_exceptions=True) == (3, None)
    assert safe_eval("one + 2", locals={"one": 1}, include_exceptions=True) == (3, None)
    assert safe_eval("1 + 2", locals={"one": 1, "two": 2}) == 3
    assert safe_eval("1 + two", locals={"one": 1, "two": 2}) == 3

# Generated at 2022-06-23 13:23:29.599572
# Unit test for function safe_eval
def test_safe_eval():

    # Simple expression
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('dict(a=1, b=2)') == {'a': 1, 'b': 2}
    assert safe_eval('a[1]') == 'b'
    assert safe_eval('dict(1=a, 2=b)') == {1: 'a', 2: 'b'}
    assert safe_eval('dict(1=a, 2=b)', {'a': 1, 'b': 2}) == {1: 1, 2: 2}
    assert safe_eval('1.01') == 1.01
    assert safe_eval('True') is True
    assert safe_eval

# Generated at 2022-06-23 13:23:37.640446
# Unit test for function safe_eval
def test_safe_eval():
    # assert all the valid expressions evaluate to the expected value
    assert safe_eval("10") == 10
    assert safe_eval("-10") == -10
    assert safe_eval("10.5") == 10.5
    assert safe_eval("-10.5") == -10.5
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("[1,2,3,4]") == [1,2,3,4]
    assert safe_eval("[1,2,3,4,]") == [1,2,3,4]
    assert safe_eval("[]") == []
    assert safe_eval("{1: foo, 2: bar}") == {1: 'foo', 2: 'bar'}
   

# Generated at 2022-06-23 13:23:48.959521
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:59.189167
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:10.299592
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:20.037995
# Unit test for function safe_eval
def test_safe_eval():

    # A short test suite for safe_eval.

    C.ANSIBLE_TEST_FORCE_EVAL = True

    def __eval(s, l=None, i=False, expected=None, exception=None):
        if l is None:
            l = {}
        if exception is not None:
            out = safe_eval(s, l, i)
            assert isinstance(out, tuple)
            assert out[0] == expected
            assert isinstance(out[1], exception)
        else:
            out = safe_eval(s, l, i)
            assert isinstance(out, tuple)
            assert out[0] == expected
            assert out[1] is None

    # Test bare numbers
    __eval("1", expected=1)
    __eval("-1", expected=-1)

# Generated at 2022-06-23 13:24:30.621371
# Unit test for function safe_eval
def test_safe_eval():
    # this needs to be a valid python expression
    assert safe_eval('2+2') == 4

    # this is a valid syntax but invalid python expression,
    # since we are not supporting mutations of data types
    assert safe_eval('"ab"+"cd"') == 'abcd'

    # this should throw an exception because of invalid syntax
    try:
        safe_eval('4+')
    except Exception as e:
        if sys.version_info >= (3, 0):
            assert "cannot concatenate" in to_native(e)
        else:
            assert "invalid syntax" in to_native(e)

    # this should throw an exception since we are not supporting mutations

# Generated at 2022-06-23 13:24:40.186687
# Unit test for function safe_eval
def test_safe_eval():

    # This is a very simple test of safe evaluation.
    # We just try a few different types of values,
    # and compare the result to what eval would normally return
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({'a': 1, 'b': 2}, None)
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}

# Generated at 2022-06-23 13:24:49.344843
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:59.298590
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as c
    from ansible.module_utils.six.moves import builtins as __builtin__

    assert safe_eval('1+1') == 2
    assert safe_eval('1|2') == 1|2
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('["foo","bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('None') is None
    assert safe_eval('true') == True
    assert safe_eval('true and false') == False
    assert safe_eval('true and not false') == True
    assert safe_eval('true or false') == True
    assert safe_eval('false or true') == True

# Generated at 2022-06-23 13:25:09.800638
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('foo') is None
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('{"a": "foo"}') == {'a': 'foo'}
    assert safe_eval('1 in [1,2,3]') is True
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('(1 if true else 0)') == 1
    assert safe_eval('(1 if false else 0)') == 0

# Generated at 2022-06-23 13:25:19.502602
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:29.845539
# Unit test for function safe_eval
def test_safe_eval():
    # Tuple of (test case, expected result)
    test_cases = [
        ('[1,2,3,4]', [1, 2, 3, 4]),
        ('{"a": "foo", "b": "bar"}', {"a": "foo", "b": "bar"}),
        ("((1 + 2) * 4) / 2", 6),  # math
        ("true", True),
        ("false", False),
        ("null", None),
    ]

    for (test_case, expected_result) in test_cases:
        result = safe_eval(test_case)
        assert result == expected_result

        result, exception = safe_eval(test_case, include_exceptions=True)
        assert result == expected_result
        assert exception is None

    # Bad cases, with no errors
    assert safe_

# Generated at 2022-06-23 13:25:39.540423
# Unit test for function safe_eval
def test_safe_eval():
    def _run_safe_eval(expr, expected, locals={}, include_exceptions=False):
        if include_exceptions:
            tmp = safe_eval(expr, locals=locals, include_exceptions=True)
            result, exception = tmp[0], tmp[1]
        else:
            result = safe_eval(expr, locals=locals, include_exceptions=False)
            exception = None

        if expected == result:
            return True
        elif expected == exception and expected is not None:
            return True
        elif isinstance(expected, BaseException) and isinstance(exception, expected):
            return True
        else:
            return False

    # safe_eval with locals
    assert _run_safe_eval("a", "a", locals={})

# Generated at 2022-06-23 13:25:46.986944
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Make sure safe_eval works as expected
    '''
    # add some mock locals
    locals = dict(a=1, b=2)

    # simple add
    expr = 'a + b'
    assert safe_eval(expr, locals) == 3

    # some basic arithmetic operations
    expr = 'a - (-1) * b / 2'
    assert safe_eval(expr, locals) == 3

    # call expression is forbidden by CleansingNodeVisitor
    expr = 'c()'
    assert safe_eval(expr, locals) == expr

    # builtin functions are forbidden (unless explicitly included in CALL_ENABLED)
    expr = 'any([a, b])'
    assert safe_eval(expr, locals) == expr
    expr = 'len("a")'

# Generated at 2022-06-23 13:25:56.771810
# Unit test for function safe_eval
def test_safe_eval():
    result, error = safe_eval('{"a": 1, "b": 2}', include_exceptions=True)
    assert result == {'a': 1, 'b': 2}
    result, error = safe_eval('[1,2,3,4]', include_exceptions=True)
    assert result == [1, 2, 3, 4]
    result, error = safe_eval('sort([1,2,3,4])', include_exceptions=True)
    assert result == 'sort([1,2,3,4])'
    result, error = safe_eval('(1 == 1)', include_exceptions=True)
    assert result == True
    result, error = safe_eval('(1 == 2)', include_exceptions=True)
    assert result == False

# Generated at 2022-06-23 13:26:08.094159
# Unit test for function safe_eval
def test_safe_eval():
    locals = {
        'a': [1, 2, 3],
        'b': [{
            'c': 'd'
        }]
    }


# Generated at 2022-06-23 13:26:19.334318
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a simple unit test for the function safe_eval.
    '''

# Generated at 2022-06-23 13:26:31.679207
# Unit test for function safe_eval
def test_safe_eval():

    # simple test
    assert safe_eval("my_var") == "my_var"

    # simple arithmetic
    assert safe_eval("1 + 2") == 3
    assert safe_eval("6 - 2") == 4

    # dict
    assert safe_eval("dict(a=5, b=6)") == dict(a=5, b=6)

    # list
    assert safe_eval("[1,2,3]") == [1,2,3]

    # tuple
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)

    # unary operations
    assert safe_eval("-1") == -1
    assert safe_eval("not True") == False
    assert safe_eval("not False") == True

    # boolean combinations

# Generated at 2022-06-23 13:26:42.788066
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:52.660236
# Unit test for function safe_eval
def test_safe_eval():
    # eval should fail as list not allowed
    expr = "[1,2,3]"
    (result, exception) = safe_eval(expr, include_exceptions=True)

    assert exception is not None

    # eval should succeed as list is allowed now
    expr = "[1,2,3]"
    result = safe_eval(expr)
    expected = [1, 2, 3]

    assert result == expected

    # eval should succeed as dict is allowed now
    expr = "{'a': 1, 'b': 2}"
    result = safe_eval(expr)
    expected = {'a': 1, 'b': 2}

    assert result == expected

    # eval should succeed as None is allowed now
    expr = "None"
    result = safe_eval(expr)
    expected = None

    assert result == expected

    # eval should succeed

# Generated at 2022-06-23 13:27:03.678454
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:14.238652
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:24.279142
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('["foo","bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo":1,"bar":false}') == {'foo': 1, 'bar': False}
    assert safe_eval('{"foo": {"bar":1} }') == {'foo': {'bar': 1}}
    assert safe_eval('[foo,bar]', {'foo': 'test', 'bar': 'test2'}) == ['test', 'test2']
    assert safe_eval('[]', {'foo': 'test', 'bar': 'test2'}) == []
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1

# Generated at 2022-06-23 13:27:30.706260
# Unit test for function safe_eval
def test_safe_eval():

    # normal allowed things
    assert safe_eval("a_list_variable", {'a_list_variable': ['foo', 'bar']}) == ['foo', 'bar']
    assert safe_eval("a_list_variable", {'a_list_variable': None}) is None
    assert safe_eval("a_list_variable", {'a_list_variable': 'foo'}) == 'foo'
    assert safe_eval("a_list_variable", {'a_list_variable': {'foo': 'bar'}}) == {'foo': 'bar'}

    # syntax error, should return the string
    assert safe_eval("a_list_variable", {'a_list_variable': "['foo', 'bar'"}) == "['foo', 'bar'"

    # non-valid variable name

# Generated at 2022-06-23 13:27:38.374467
# Unit test for function safe_eval
def test_safe_eval():
    def test_one(expr, expected):
        msg = "Expected %s to eval to %s, but got %s instead" % (expr, expected, eval(expr))
        assert safe_eval(expr) == expected, msg

    test_one('1', 1)
    test_one('1 + 1', 2)
    test_one('1 + 1 == 2', True)
    test_one('1 + 1 == 3', False)
    test_one('"foo"', u'foo')
    test_one('"foo" + "bar"', u'foobar')
    test_one('["foo", "bar"]', [u'foo', u'bar'])
    test_one('["foo", "bar"] + ["baz"]', [u'foo', u'bar', u'baz'])

# Generated at 2022-06-23 13:27:41.126094
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    import os
    import tempfile


# Generated at 2022-06-23 13:27:50.144740
# Unit test for function safe_eval
def test_safe_eval():
    class FailingNodeVisitor(ast.NodeVisitor):
        def visit_Name(self, node):
            raise Exception("invalid name (%s)" % node.id)
    failing_nv = FailingNodeVisitor()

    # Each test should either pass or raise an exception.  If it
    # passes, it can return a value.  If it raises an exception,
    # the exception message should match the one in parens after
    # the ->.

    # {'a': 'b'} is a literal dict, 'b' is a literal string,
    # and 'a' is a Name.  It doesn't matter what locals() is set
    # to since we never try to resolve any names.
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}

    # Same here, only now

# Generated at 2022-06-23 13:28:01.061641
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple expressions
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 - 1") == 0
    assert safe_eval("1 / 2") == 0.5
    assert safe_eval("1 * 1") == 1
    assert safe_eval("1 % 2") == 1
    assert safe_eval("1 > 2") is False
    assert safe_eval("1 < 2") is True
    assert safe_eval("1 == 1") is True
    assert safe_eval("1 != 2") is True
    assert safe_eval("1 <= 1") is True
    assert safe_eval("1 <= 2") is True
    assert safe_eval("1 >= 1") is True
    assert safe_eval("2 >= 1") is True

# Generated at 2022-06-23 13:28:09.203113
# Unit test for function safe_eval
def test_safe_eval():
    import yaml

# Generated at 2022-06-23 13:28:19.306763
# Unit test for function safe_eval
def test_safe_eval():
    test_vars = dict(
        foo=2,
        boo="blah",
        far=[1, 2, 3],
    )

    # Test simple list
    assert safe_eval('[1, 2, 3]', test_vars) == [1, 2, 3]
    # Test simple dict
    assert safe_eval('{"a": 1, "b": "c"}', test_vars) == {"a": 1, "b": "c"}
    # Test simple string
    assert safe_eval('foo', test_vars) == 2
    # Test simple string
    assert safe_eval('boo', test_vars) == 'blah'

    # Test simple math
    assert safe_eval('foo + 1', test_vars) == 3

# Generated at 2022-06-23 13:28:30.781420
# Unit test for function safe_eval
def test_safe_eval():
    # successful expressions
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("1.0/2.0*3.0") == 1.5
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert isinstance(safe_eval("{'k': 'v'}"), dict)
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("False and True") is False

# Generated at 2022-06-23 13:28:42.349936
# Unit test for function safe_eval
def test_safe_eval():
    # All of these should pass
    safe_eval("2 + 3")
    safe_eval("['a', 'b'][0]")
    safe_eval("dict(a=1)")
    safe_eval("{'a': 1}")
    safe_eval("['a', {'b': 'c'}][1]")
    safe_eval("false and true")
    safe_eval("true or false")
    safe_eval("false or true")
    safe_eval("true and true")
    safe_eval("(true and true) or (false and true) and false")
    safe_eval("(true and true) or (true and false) or true")
    safe_eval("(true and true) or (true and false) or false")

# Generated at 2022-06-23 13:28:49.179876
# Unit test for function safe_eval
def test_safe_eval():
    test_var = "{{ ansible_hostname }}"
    expr, exp = safe_eval(test_var, include_exceptions=True)
    assert(expr == test_var)
    assert(exp is None)

    test_var = "{{ 'a' * 2  }}"
    expr, exp = safe_eval(test_var, include_exceptions=True)
    assert(expr == test_var)
    assert(exp is None)

    test_var = "{{  }}"
    expr, exp = safe_eval(test_var, include_exceptions=True)
    assert(expr == test_var)
    assert(exp is None)

    test_var = "{{ ansible_hostname }}"
    expr, exp = safe_eval(test_var, include_exceptions=True)

# Generated at 2022-06-23 13:28:58.644261
# Unit test for function safe_eval
def test_safe_eval():
    # asserts to backport to unit test
    assert ast.parse("{'foo': 'bar'}")
    assert ast.parse("{foo: 'bar'}")
    assert ast.parse("['foo', 'bar', 'baz']")
    assert ast.parse("['foo', 'bar', {'a': 'b'}]")
    assert ast.parse("(1, 2, 3)")
    assert ast.parse("(1, 2, 3, (4, 5))")
    assert ast.parse("1 + 2")
    assert ast.parse("1 - 2")
    assert ast.parse("1 * 2")
    assert ast.parse("1 / 2")
    assert ast.parse("1 ** 2")
    assert ast.parse("[item for item in (1, 2, 3)]")

# Generated at 2022-06-23 13:29:10.444322
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo }}", locals=dict(foo="bar")) == "bar"
    assert safe_eval("{{ foo.bar }}", locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("{{ foo.bar }}", locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("{{ foo['bar'] }}", locals=dict(foo=dict(bar="baz"))) == "baz"
    assert safe_eval("{{ foo[bar] }}", locals=dict(foo=dict(bar="baz"), bar="bar")) == "baz"
    assert safe_eval("{{ bar }}", locals=dict(bar="zeitgeist")) == "zeitgeist"

# Generated at 2022-06-23 13:29:22.479470
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert type(safe_eval('1')) == int
    assert safe_eval('"auto_update" in image.tags') == False
    assert type(safe_eval('"auto_update" in image.tags')) == bool
    assert safe_eval('a_list_variable') == None  # None is a valid string
    assert type(safe_eval('a_list_variable')) == str
    assert safe_eval('image') == None
    assert type(safe_eval('image')) == str
    assert safe_eval('{ "a": 1, "b": 2 }') == { "a": 1, "b": 2 }
    assert safe_eval('[ 1, 2, 3 ]') == [ 1, 2, 3 ]

    expr = "a['b']"
    result, ex

# Generated at 2022-06-23 13:29:31.941790
# Unit test for function safe_eval
def test_safe_eval():
    # These are situations where safe_eval should not pass
    # because they are unsafe to execute.  This is done by
    # ensuring that the syntax error exception is raised.
    bad_exprs = [
        # no assignment
        'a = 5',
        '1 = 1',
        # regex
        're.compile()',
        # overrides
        '__builtins__ = 1',
        # function call
        'open()',
        'os.path',
    ]
    for expr in bad_exprs:
        try:
            safe_eval(expr)
        except SyntaxError:
            pass
        except:
            print("Unexpected exception from expr %s" % expr)
    # These are situations where a known exception should be raised

# Generated at 2022-06-23 13:29:42.452301
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:55.317745
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure that safe_eval() is working, and at least some Python builtins are blocked
    expr = "len('12345')"
    builtin_len = len
    assert builtin_len('12345') == 5
    try:
        result = safe_eval(expr)
        assert False
    except Exception as e:
        pass
    # Ensure that the literal expression is returned when there is a syntax error
    expr = "len (12345)"
    assert safe_eval(expr) == expr
    # The following test ensures that Python builtins can be invoked if explicitly whitelisted
    expr = "len('12345')"
    result = safe_eval(expr, include_exceptions=True)
    assert result[0] == 5
    assert isinstance(result[1], Exception)

    # test advanced python builtins

# Generated at 2022-06-23 13:30:00.794439
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''

    # These are all valid expressions

# Generated at 2022-06-23 13:30:11.153633
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function
    '''

    # test with a valid expression
    assert safe_eval('1 + 1') == 2

    # test with a invalid expression
    assert safe_eval('some_method()', include_exceptions=True)[1] is not None

    # test with a valid expression containing a dict
    expr = '{"ansible_os_family": "RedHat", "ansible_distribution": "Fedora"}'
    result = safe_eval(expr)
    assert isinstance(result, dict)
    assert result.get('ansible_os_family') == 'RedHat'

    # test with a broken dict expression
    expr = '{"ansible_os_family": "RedHat", ansible_distribution": "Fedora"}'
    result = safe_eval(expr)

# Generated at 2022-06-23 13:30:21.785393
# Unit test for function safe_eval
def test_safe_eval():
    # various cases to test eval() succeeds
    assert safe_eval("ansible_version.full") == C.__version__
    assert safe_eval("ansible_version.full == '2.9.6'") is False
    assert safe_eval("ansible_version.full == '2.9.6'", dict(ansible_version=dict(full='2.9.6')))
    assert safe_eval("a.keys() | list", dict(a=dict(a=1,b=2))) == ['a', 'b']
    assert safe_eval("a.keys() | list", dict(a=dict(a=1,b=2,))) == ['a', 'b']

# Generated at 2022-06-23 13:30:34.082690
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval("1+1")
    # safe_eval("get_user(my_var)")
    safe_eval("get_user()")
    safe_eval("[1,2,3]")
    safe_eval("{'a':1,'b':2}")
    safe_eval("{}")
    safe_eval("1")
    safe_eval("'a'")
    safe_eval("True")
    safe_eval("null")
    safe_eval("1.0")
    safe_eval("1.0/2")
    safe_eval("1+2*3")
    safe_eval("1.1+2*3")
    safe_eval("1/2*3")
    safe_eval("1/2/3")
    safe_eval("(1+2)*3")
    safe_

# Generated at 2022-06-23 13:30:41.161070
# Unit test for function safe_eval
def test_safe_eval():

    # test that the list 'example' is evaluated
    expr = "{{ example }}"
    expr_result = safe_eval(expr, dict(example=['foo', 'bar']))
    assert expr_result == ['foo', 'bar']

    # test that the string 'example' is left alone
    expr = "{{ example }}"
    expr_result = safe_eval(expr, dict(example="example"))
    assert expr_result == 'example'

    # test that the string 'example' is interpolated if the string contains a variable
    expr = "{{ example }}"
    expr_result = safe_eval(expr, dict(example="foo{{bar}}", bar='bar'))
    assert expr_result == 'foobar'

    # test that the integer literal is evaluated
    expr = "{{ example }}"
    expr_result = safe_eval

# Generated at 2022-06-23 13:30:52.640172
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Returns: a tuple of (success(True/False), message)
    '''
    # enable all builtin functions calls in safe_eval()
    CALL_ENABLED.extend(dir(builtins))
    CALL_ENABLED.append('_')
    CALL_ENABLED.append('ansible_host')  # python-2.6 version of gethostname()

    # test for true expression
    for expr in ['1 + (4 * 5)', '_()', '_("foo")', "ansible_host"]:
        result, exception = safe_eval(expr, include_exceptions=True)
        if result != eval(expr) or exception:
            return (False, "safe_eval('%s') failed with result '%s', exception '%s'" % (expr, result, exception))

    #

# Generated at 2022-06-23 13:31:02.969153
# Unit test for function safe_eval
def test_safe_eval():

    # Ensure no exception is raised
    assert safe_eval('5 > 3')

    try:
        # Ensure exception is raised
        assert safe_eval('foo')
    except:
        assert True

    try:
        # Ensure exception is raised
        assert safe_eval('__import__("os").system("/bin/sh")')
    except:
        assert True

    # Ensure no exception is raised
    assert safe_eval('["foo", "bar"]')

    # Ensure no exception is raised
    assert safe_eval('{"a": "b", "c": "d"}')

    # Ensure no exception is raised
    assert safe_eval('5 | 2')


# Generated at 2022-06-23 13:31:09.889341
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.basic
    import ansible.module_utils.common.text.converters as text_converters

    # Tests for set_type function

# Generated at 2022-06-23 13:31:21.872724
# Unit test for function safe_eval
def test_safe_eval():
    # Test Objects
    class testClass(object):
        def test_fn(self):
            return 2
    testObject = testClass()

    # Test Strings
    string = "1 == 1"
    array_string = "['one', 'two', 'three']"
    dict_string = "{'one': 1, 'two': 2, 'three': 3}"
    # Test Data

# Generated at 2022-06-23 13:31:29.752308
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Ensure safe_eval() works as expected.
    '''
    from ansible.module_utils.six import text_type

    # Test that it returns an error instead of raising one.
    # Test some illegal expressions.

# Generated at 2022-06-23 13:31:40.281485
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("[1,2,3] + [1,2]") == [1, 2, 3, 1, 2]
    assert safe_eval("{'a': [1,2,3]}") == {'a': [1, 2, 3]}
    assert safe_eval("{'a': [1,2,3]}['a']") == [1, 2, 3]
    assert safe_eval("{'a': [1,2,3]}['a'] + [1,2]") == [1, 2, 3, 1, 2]
    assert safe_eval("{'a': [1,2,3]}['a'][0]") == 1
    assert safe_eval("-1") == -1

# Generated at 2022-06-23 13:31:48.427050
# Unit test for function safe_eval
def test_safe_eval():
    # Python 2.6 and 3.2 both have bugs in ast.parse, the following tests
    # do not work with those interpreter versions
    if sys.version_info < (2, 7) or (3, 0) <= sys.version_info < (3, 3):
        return

    # for Python 2.6 or 3.2, use ast.literal_eval as a
    # reference implementation
    import ast

# Generated at 2022-06-23 13:31:59.326895
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic test to make sure we don't get exceptions and we end up with
    the answer we expect.
    '''

# Generated at 2022-06-23 13:32:09.992881
# Unit test for function safe_eval
def test_safe_eval():
    """
    Run all safe_eval unit tests defined in docstring of the function.
    """

    def perform_test(test):
        """
        Perform one test of safe_eval().

        Return True if the test passed, and False if it failed.
        """
        success = False
        try:
            result = safe_eval(test['expression'])
        except Exception as e:
            result = str(e)
        if result != test['expected_result']:
            success = False
        else:
            success = True
        if not success:
            print('FAILED: %(expression)s : %(expected_result)s != %(result)s' %
                  {'expression': test['expression'],
                   'expected_result': test['expected_result'],
                   'result': result})
        return success

    #

# Generated at 2022-06-23 13:32:21.178832
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info < (2, 7):
        return dict(skipped=True, msg="python version < 2.7")


# Generated at 2022-06-23 13:32:31.666034
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:42.668472
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_eval("foo = 'bar'", include_exceptions=True)[0] == 'bar'
    assert safe_eval("{'foo':'bar'}") == {'foo':'bar'}
    assert safe_eval("{'foo':'bar'}", include_exceptions=True)[0] == {'foo':'bar'}
    assert safe_eval("['foo','bar']") == ['foo','bar']
    assert safe_eval("['foo', 'bar']", include_exceptions=True)[0] == ['foo', 'bar']

# Generated at 2022-06-23 13:32:50.064041
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a very minimal unit test of function safe_eval.
    It is based on the test case provided by user Semmel in
    the following StackOverflow thread:

    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe

    '''
    expr = "__import__('os').system('/bin/sh')"
    try:
        result = safe_eval(expr)
    except:
        result = None
    if result == None:
        t1 = True
    else:
        t1 = False

    expr = "__import__('os').system('ls')"
    try:
        result = safe_eval(expr)
    except:
        result = None
    if result == None:
        t