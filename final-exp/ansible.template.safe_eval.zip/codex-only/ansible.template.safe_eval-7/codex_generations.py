

# Generated at 2022-06-23 13:23:03.266130
# Unit test for function safe_eval
def test_safe_eval():
    def _test_eval(line, result, locals=None, exception=None):
        locals = {} if locals is None else locals
        if exception is None:
            assert safe_eval(line, locals=locals) == result
        else:
            actual_result, actual_exception = safe_eval(line, locals=locals, include_exceptions=True)
            assert actual_result == result
            assert isinstance(actual_exception, exception)

    # Some tests from the original unit test implementation
    _test_eval('1 + 1', 2)
    _test_eval('foo', 'foo')
    _test_eval('[1, 2, 3]', [1, 2, 3])
    _test_eval('{"foo": "bar", "bar": "foo"}', {'foo': 'bar', 'bar': 'foo'})

# Generated at 2022-06-23 13:23:12.280223
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"one"') == 'one'
    assert safe_eval("'one'") == 'one'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == {'a': 1}

    # Truth tests
    assert safe_eval('True or False') == True
    assert safe_eval('False or True') == True
    assert safe_eval('True and False') == False
    assert safe_eval('False and True') == False
    assert safe_eval

# Generated at 2022-06-23 13:23:18.280215
# Unit test for function safe_eval
def test_safe_eval():
    # Simple test for function safe_eval
    assert safe_eval('1 + 2') == 3
    assert safe_eval('3*4') == 12
    # Test for unsafe functions
    assert safe_eval('__import__("time").sleep(10)') == "__import__(\"time\").sleep(10)"
    # Test for safelist of AST nodes
    assert safe_eval('"a" * 3') == "aaa"


# Generated at 2022-06-23 13:23:28.854213
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:37.104407
# Unit test for function safe_eval
def test_safe_eval():
    failures = []


# Generated at 2022-06-23 13:23:48.958894
# Unit test for function safe_eval
def test_safe_eval():
    # Boolean expressions
    assert safe_eval("True or False") == True
    assert safe_eval("1 < 2") == True
    assert safe_eval("1 > 2") == False
    assert safe_eval("1 == 2") == False
    assert safe_eval("1 != 2") == True
    assert safe_eval("1 != '1'") == False
    assert safe_eval("'foo' < 'goo'") == True

    # Arithmetic expressions
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 - 2") == -1
    assert safe_eval("1 * 2") == 2
    assert safe_eval("1 / 2.0") == 0.5
    assert safe_eval("2**2") == 4

    # List and dictionary expressions

# Generated at 2022-06-23 13:23:58.229394
# Unit test for function safe_eval
def test_safe_eval():
    # assert container_to_text(safe_eval("[1, 2, 3, ]")) == [1, 2, 3]
    assert container_to_text(safe_eval("{'a': 1, 'b': 2}")) == '{"a": 1, "b": 2}'
    assert container_to_text(safe_eval("['a', 'b', 'c']")) == '["a", "b", "c"]'
    assert container_to_text(safe_eval("['a', 'b', '{{ B }}', 'c']", dict(B='b'))) == '["a", "b", "b", "c"]'

# Generated at 2022-06-23 13:24:08.899852
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import wrap_var

    # We test only syntax errors and invalid expressions because we can't
    # test for eval's runtime errors (divide by 0, accessing undefined
    # variable, etc.) in a unit test.  If we could, we would have to mock
    # the thing that caused the error.  In this case, a good plan would be:
    # * Create a function that creates a variable that doesn't exist when
    #   called.  We will call this function in safe_eval
    # * Create a class that raises when certain methods are called
    # * Create an instance of the class and substitute it for the variable
    #   that doesn't exist in the eval's globals/locals
    # * Call the function in safe_eval and check that the exception
    #   is caught and that the result is the expression being

# Generated at 2022-06-23 13:24:15.976113
# Unit test for function safe_eval
def test_safe_eval():
    tests = [
        ('template_hostvars.update_password({ encrypted_password: "test" })', 'callable'),
        ('template_hostvars.update_password({ encrypted_password: "test" })', 'callable'),
        ('template_hostvars.update_password()', 'callable')
    ]

    for (expr, expect) in tests:
        if expect == 'callable':
            assert hasattr(safe_eval(expr), '__call__')
        else:
            assert safe_eval(expr) == expect



# Generated at 2022-06-23 13:24:26.893936
# Unit test for function safe_eval
def test_safe_eval():
    def run_test(expr, expected, expected_exception=None, exception_pattern=None):
        result = safe_eval(expr)
        if exception_pattern:
            assert expected_exception
            assert isinstance(result, Exception)
            assert exception_pattern in to_native(result)
        else:
            if expected_exception:
                raise AssertionError("test should not have thrown an exception")
            assert expected == result

    # Test safe_eval
    run_test('1+1', 2)
    run_test('true', True)
    run_test('false', False)
    run_test('null', None)
    run_test('(1,2,3)', (1,2,3))
    run_test('[1,2,3]', [1,2,3])
    run_

# Generated at 2022-06-23 13:24:37.107063
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for safe_eval()
    # If your test fails, make sure to run flake8 on the file
    # since it will probably have been linted -- <3 flake8
    assert safe_eval('2 + 2', {}, False) == 4
    #
    # The following variables are unused, but are necessary to pass arguments
    # to the function. It's needed for the 'locals' variable when running the
    # function in the module.
    #
    # pylint: disable=unused-argument,unused-variable
    #
    # Test that we can't use a variable we haven't specified
    # (Closest thing I could find to a variable we don't want to use)
    assert '__import__' in str(safe_eval('__import__', {}, False))
    # Make sure we can't use

# Generated at 2022-06-23 13:24:44.956249
# Unit test for function safe_eval
def test_safe_eval():
    call_enabled = ['set', 'dict']
    for call in call_enabled:
        CALL_ENABLED.append(call)
        assert safe_eval('%s()' % call) == eval('%s()' % call)
        assert safe_eval('%s()' % call) == eval('%s()' % call)
        assert safe_eval('a %s b' % call, dict(a=1, b=1)) == eval('a %s b' % call, dict(a=1, b=1))
        assert safe_eval('a %s b' % call, dict(a=1, b=1)) == eval('a %s b' % call, dict(a=1, b=1))

# Generated at 2022-06-23 13:24:55.748413
# Unit test for function safe_eval
def test_safe_eval():
    # Tests for valid python expressions that do not contain any
    # of the restricted keywords
    tests = [
        ('1 + 1', 2),
        ('[1, 2, 3]', [1, 2, 3]),
        ('{"a": 42}', {"a": 42}),
        ('a or b', [])
    ]

    # Create a dummy function to try and call
    def test_func():
        pass

    # Add it to locals
    locals = {'test_func': test_func}

    for (expr, expected) in tests:
        result = safe_eval(expr, locals=locals)
        assert expected == result, "Eval of '%s' failed." % expr

if __name__ == "__main__":
    # Run test of function safe_eval
    test_safe_eval()

# Generated at 2022-06-23 13:25:05.679769
# Unit test for function safe_eval
def test_safe_eval():
    def evaluate_expression(expression, expression_type=None, include_exceptions=False):
        # convert expression to string, if necessary
        expression = container_to_text(expression)

        # ensure that the expression_type is always upper case
        if expression_type is not None:
            expression_type = expression_type.upper()

        # perform the safe_eval()
        result, exception = safe_eval(expression, include_exceptions=include_exceptions)

        # return the result
        if include_exceptions:
            return result, exception
        else:
            return result

    def check(expression, expression_type=None, expected_result=None, expected_exception=None, raise_exception=True):
        result, exception = evaluate_expression(expression, expression_type=expression_type, include_exceptions=True)
       

# Generated at 2022-06-23 13:25:16.804861
# Unit test for function safe_eval
def test_safe_eval():

    if sys.version_info[0] == 2:
        assert(safe_eval("[u'homebrew']", include_exceptions=True)[0] == ['homebrew'])
    else:
        assert(safe_eval("['homebrew']", include_exceptions=True)[0] == ['homebrew'])
    assert(safe_eval("not_a_list", include_exceptions=True)[1] != None)

    safe_eval("1 + 1", include_exceptions=True)
    safe_eval("1 + '1'", include_exceptions=True)
    safe_eval("'a' + 'b'", include_exceptions=True)
    safe_eval("a", include_exceptions=True)
    safe_eval("'1'", include_exceptions=True)

# Generated at 2022-06-23 13:25:28.352947
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval()...")

    def test_expr(expr, should_be_passed):
        print("test_expr: %s" % expr)
        try:
            res = safe_eval(expr)
            if should_be_passed and isinstance(res, string_types):
                raise AssertionError("safe_eval has failed for expression '%s'" % expr)
            elif not should_be_passed and not isinstance(res, string_types):
                raise AssertionError("safe_eval has failed for expression '%s'" % expr)
        except Exception as e:
            if should_be_passed:
                raise AssertionError("safe_eval has failed for expression '%s'" % expr)

    # Test allowed expressions
    test_expr("1", True)
    test_expr

# Generated at 2022-06-23 13:25:38.675825
# Unit test for function safe_eval
def test_safe_eval():

    def fail_if_raise(func, *args, **kwargs):
        ''' there is no Python 2.4 friendly way to check for exception '''
        try:
            func(*args, **kwargs)
        except:
            assert(False)
        else:
            assert(True)

    safe_eval('1')
    safe_eval('True')
    safe_eval('{"foo": "bar"}')
    safe_eval('[1, 2, foo]', dict(foo=None))

    fail_if_raise(safe_eval, 'while')
    fail_if_raise(safe_eval, 'foo(1)')
    fail_if_raise(safe_eval, '{foo:bar}')

    # TODO: Need to add Python 3.x test case.
    # TODO: Need to add safe_eval

# Generated at 2022-06-23 13:25:46.424868
# Unit test for function safe_eval
def test_safe_eval():
    def test_safe_eval_assert_raises(expr, locals=None, exception=None):
        (result, exc) = safe_eval(expr, locals=locals, include_exceptions=True)
        assert expr == result
        assert isinstance(exc, exception)

    test_safe_eval_assert_raises('1*1', locals={'foo': 4}, exception=Exception)
    test_safe_eval_assert_raises('foo + 1', locals={'foo': 4}, exception=Exception)
    test_safe_eval_assert_raises('foo + 1', locals={'foo': '4'}, exception=Exception)
    test_safe_eval_assert_raises('1 + 1', locals={}, exception=Exception)
    test_safe_eval_assert_raises('1 + 1', exception=Exception)
    test

# Generated at 2022-06-23 13:25:54.569223
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:07.027039
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:18.808171
# Unit test for function safe_eval
def test_safe_eval():
    """See example in docstring of safe_eval()"""
    if sys.version_info[0] == 2:
        from ansible.module_utils.pycompat24 import to_unicode
        key = 'unicode'
    else:
        key = 'str'

    # tests that should work
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.strip()", dict(foo=' asdf ')) == ' asdf '
    assert safe_eval("[]") == []
    assert safe_eval("[].append", dict(a=[])) == []
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2] + [3, 4]") == [1, 2, 3, 4]

# Generated at 2022-06-23 13:26:30.866371
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("False") is False
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("[1,2,3] + [4, 5, 6]") == [1, 2, 3, 4, 5, 6]
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("'''a'''") == 'a'
    assert safe_eval("'''1 + 1'''") == '1 + 1'

# Generated at 2022-06-23 13:26:41.543997
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 2") == 3
    assert safe_eval("(1 + 2) * 8") == 24
    assert safe_eval("[1 + 2] * 3") == [3, 3, 3]
    assert safe_eval("{'a': 1 + 2}") == {'a': 3}
    assert safe_eval("1 + 2", include_exceptions=True)[0] == 3
    assert safe_eval("1 / 0", include_exceptions=True)[0] == "1 / 0"
    assert safe_eval("{'a': 1 / 0}", include_exceptions=True)[0] == "{'a': 1 / 0}"
    assert safe_eval("true") is True
    assert safe_eval("{'a': true}") == {'a': True}

# Generated at 2022-06-23 13:26:51.726538
# Unit test for function safe_eval
def test_safe_eval():
    # Test container types
    for expr in ('{}', '[]', '()'):
        assert safe_eval(expr) == eval(expr)
    # Test literal types
    for expr in ('True', 'False', '42', '3.14', '"foo"', '"bar"'):
        assert safe_eval(expr) == eval(expr)
    # Test dictionary
    expected = {'foo': 'bar', 'baz': 42}
    assert safe_eval('dict(foo="bar", baz=42)') == expected
    # Test list
    expected = ['foo', 'bar', 42]
    assert safe_eval('["foo", "bar", 42]') == expected
    # Test tuple
    expected = ('foo', 'bar', 42)
    assert safe_eval('("foo", "bar", 42)') == expected
   

# Generated at 2022-06-23 13:27:03.136565
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This code unit tests the safe_eval function
    '''

    results = []

    results.append(safe_eval('True'))
    results.append(safe_eval('False'))
    results.append(safe_eval('None'))
    results.append(safe_eval('1'))
    results.append(safe_eval('1.0'))
    results.append(safe_eval('"abc"'))
    results.append(safe_eval("['a', 1, True]"))
    results.append(safe_eval("{'a': 1}"))
    results.append(safe_eval("1 + 1"))
    results.append(safe_eval("1.0 + 1"))
    results.append(safe_eval("1 - 1"))
    results.append(safe_eval("1 - 1.0"))

# Generated at 2022-06-23 13:27:13.876006
# Unit test for function safe_eval
def test_safe_eval():
    '''
    We just build a dictionary of inputs and outputs,
    and assert they match.
    '''


# Generated at 2022-06-23 13:27:24.055382
# Unit test for function safe_eval
def test_safe_eval():
    # use a copy of the context for each test
    my_context = dict(aa='red', bb='green', cc='blue')
    my_context.update(builtins.__dict__)
    my_context.update({'__builtins__': None})

    # NOTE: expression, expected, message

# Generated at 2022-06-23 13:27:35.473265
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_native

    # Include exception does not raise on error
    safe_eval_include_exceptions = lambda x: safe_eval(x, include_exceptions=True)
    safe_eval_no_exceptions = lambda x: safe_eval(x, include_exceptions=False)

    # Standard tests
    assert safe_eval_include_exceptions('2+2') == (4, None)
    assert safe_eval_include_exceptions('[1,2,3]') == ([1, 2, 3], None)
    assert safe_eval_include_exceptions('[1,2,3]') == ([1, 2, 3], None)

# Generated at 2022-06-23 13:27:43.938674
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + a', dict(a=1)) == 2
    assert safe_eval('1 + a["b"]', dict(a=dict(b=1))) == 2
    assert safe_eval('a["b"]["c"]', dict(a=dict(b=dict(c='foo')))) == 'foo'
    assert safe_eval('a["b"]["c"]["d"]', dict(a=dict(b=dict(c=dict(d='foo'))))) == 'foo'
    assert safe_eval('a[b]["c"]["d"]', dict(a=dict(hello=dict(c=dict(d='foo'))), b='hello')) == 'foo'
    assert safe

# Generated at 2022-06-23 13:27:52.735083
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval against several tests
    '''

    def check_safe_eval(expr, value, exception=None):
        '''
        Pass a test expression, the result and an optional exception to check
        '''
        result = safe_eval(expr, include_exceptions=True)
        if isinstance(result, tuple):
            result, exception_raised = result
        else:
            result, exception_raised = result, None

        assert result == value, 'unexpected result for (%s) : %s != %s' % (expr, result, value)

        if exception is not None:
            assert exception_raised is not None, 'Missing expected exception'
            assert isinstance(exception_raised, exception), 'Incorrect exception type: %s != %s' % (type(exception_raised), exception)

# Generated at 2022-06-23 13:28:02.916405
# Unit test for function safe_eval
def test_safe_eval():
    results = dict()
    # Test syntax errors
    assert safe_eval('a') == 'a'
    assert safe_eval('=') == '='
    assert safe_eval('{{') == '{{'
    # Test unsupported nodes
    assert safe_eval('import os') == 'import os'
    assert safe_eval('os.system("/sbin/reboot")') == 'os.system("/sbin/reboot")'
    assert safe_eval('send_messages()') == 'send_messages()'
    assert safe_eval('open("/etc/shadow", "r")') == 'open("/etc/shadow", "r")'
    assert safe_eval('__import__("os").system("/sbin/reboot")') == '__import__("os").system("/sbin/reboot")'
    #

# Generated at 2022-06-23 13:28:15.508656
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:28.982120
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info < (2, 7, 0):
        raise AssertionError("safe_eval unit test needs Python 2.7 or higher")

    class TestEval(unittest.TestCase):
        def test_positive(self):
            def test(expr, value):
                self.assertEqual(safe_eval(expr), value)

            test('[]', [])
            test('(1,2)', (1,2))
            test('[1,2,3]', [1,2,3])
            test('{"user":"johndoe"}', {'user': 'johndoe'})
            test('True', True)
            test('True for x in (1,2,3)', True)
            test('True if True else False', True)

# Generated at 2022-06-23 13:28:40.612373
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:52.304477
# Unit test for function safe_eval
def test_safe_eval():
    def _eval(expr):
        return safe_eval(expr)

    assert _eval("2 + 3") == 5
    assert _eval("true") is True
    assert _eval("5 < 3") is False
    assert _eval("5 == 4 + 1") is True
    assert _eval("(5,)") == (5,)
    assert _eval("[5, 'a']") == [5, 'a']
    assert _eval("{'a': 5}") == {'a': 5}

    assert safe_eval("[1, 2] + [3, 4]") == [1, 2, 3, 4]
    assert safe_eval("{'a': 1} == {'a': 1}") is True
    assert safe_eval("{'a': 1} != {'a': 1}") is False
    assert safe_eval

# Generated at 2022-06-23 13:28:59.300395
# Unit test for function safe_eval
def test_safe_eval():
    expr = '"ansible-test" in name'
    result = safe_eval(expr)
    assert result is True

    expr = '"ansible-test" not in name'
    result = safe_eval(expr)
    assert result is True

    expr = '"ansible-test" in name and state == "present"'
    result = safe_eval(expr)
    assert result is True

    expr = '"ansible-test" not in name and state == "present"'
    result = safe_eval(expr)
    assert result is True

    expr = '"ansible-test" in name or state == "absent"'
    result = safe_eval(expr)
    assert result is True

    expr = '"ansible-test" not in name or state == "absent"'
    result = safe_eval(expr)


# Generated at 2022-06-23 13:29:11.728834
# Unit test for function safe_eval
def test_safe_eval():
    import copy
    import datetime

    # this is the whitelist of AST nodes we are going to
    # allow in the evaluation. Any node type other than
    # those listed here will raise an exception in our custom
    # visitor class defined below.

# Generated at 2022-06-23 13:29:19.545211
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:27.818444
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEFAULT_DEBUG:
        return

    assert safe_eval('1') == 1
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('"hello"') == "hello"
    assert safe_eval('"hello %s" % "world"') == "hello world"
    assert safe_valu('a+b', dict(a=1,b=2)) == 3
    assert safe_eval('a+b', dict(a="a",b="b")) == "ab"
    assert safe_eval('a+b', dict(a=1,b="b")) == "1b"

    # container_to_text returns json string for non-ascii unicode

# Generated at 2022-06-23 13:29:38.056890
# Unit test for function safe_eval
def test_safe_eval():
    # test that functions are not allowed
    test_string = 'len(["a", "b"])'
    test_result = len(["a", "b"])
    res = safe_eval(test_string)
    assert res == test_result

    # test that modules are not allowed
    test_string = 'sys.modules.keys()'
    test_result = sys.modules.keys()
    res = safe_eval(test_string)
    assert res == test_result

    # test that custom vars are not allowed
    test_string = 'test_var'
    locals = dict(test_var=42)
    test_result = 42
    res = safe_eval(test_string, locals)
    assert res == test_result

    # test that builtin functions are allowed

# Generated at 2022-06-23 13:29:41.593826
# Unit test for function safe_eval
def test_safe_eval():
    test_bool_true = safe_eval("true")
    assert test_bool_true is True

    test_bool_false = safe_eval("false")
    assert test_bool_false is False

    test_number = safe_eval("1 + 2")
    assert test_number == 3

    test_string = safe_eval("'a string'")
    assert test_string == 'a string'

    test_list = safe_eval("[ 1, 2, 3 ]")
    assert test_list == [1, 2, 3]

    test_dict = safe_eval("{ 'a': 1, 'b': 2 }")
    assert test_dict == {'a': 1, 'b': 2}

    # this is *not* valid JSON
    test_tuple = safe_eval("(1, 2, 3)")

# Generated at 2022-06-23 13:29:47.823143
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic functionality
    assert safe_eval('1 + 2') == 3
    assert safe_eval('True or False') == True
    assert safe_eval('[x for x in range(10)]') == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert safe_eval('{"a": 1}') == {"a": 1}

    # Test that the custom Visitor disallows certain AST nodes
    if sys.version_info < (3, 0):
        assert safe_eval('[x for x in range(1) if x]') == ['0']
    else:
        # Python 3 returns an iterator, not a list
        assert list(safe_eval('[x for x in range(1) if x]')) == [0]
    assert safe_eval('foo') == "foo"

# Generated at 2022-06-23 13:29:58.109425
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a') == 'a'
    assert safe_eval('a or b') == 'a or b'
    assert safe_eval('a and b') == 'a and b'
    assert safe_eval('a in b') == 'a in b'
    assert safe_eval('a not in b') == 'a not in b'
    assert safe_eval('a.b') == 'a.b'
    assert safe_eval('a.b.c') == 'a.b.c'
    assert safe_eval('a.b.c.d') == 'a.b.c.d'
    assert safe_eval('a.b.c.d.e') == 'a.b.c.d.e'
    assert safe_eval('a[1]') == 'a[1]'

# Generated at 2022-06-23 13:30:09.486248
# Unit test for function safe_eval
def test_safe_eval():
    if len(sys.argv) == 1:
        print(safe_eval("a + b + 10"))
        print(safe_eval("a+b+10", locals={'a':1, 'b':2}))
        print(safe_eval("a+b+10", locals={'a':1, 'b':2}, include_exceptions=True))
        print(safe_eval("a+b+10", locals={'a':1, 'b':2, 'c':3}, include_exceptions=True))
        print(safe_eval("a+b+10", locals={'a':1, 'b':2, 'c':3}))
        print(safe_eval("a+b+10", locals={'a':1, 'b':2, 'c':3}, include_exceptions=True))

# Generated at 2022-06-23 13:30:20.817071
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar", "baz": [1, 2]}') == {"foo": "bar", "baz": [1, 2]}
    assert safe_eval('1 < 2') == True
    assert safe_eval('["foo", "bar"] < ["foo", "bar"]') == False
    assert safe_eval('["foo", "bar"] < ["foo", "baz"]') == True
    assert safe_eval('["foo", "bar"] < ["foo", "bar", "more"]') == True
    assert safe_eval('1+2') == 3

# Generated at 2022-06-23 13:30:33.453733
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic

    loader = basic.AnsibleModule(argument_spec={})
    def check(expr, expected, include_exceptions=False):
        actual = safe_eval(expr, include_exceptions=include_exceptions)
        if include_exceptions:
            (actual, e) = actual
        if actual != expected:
            raise AssertionError("expected %s, got %s" % (expected, actual))
        # make sure that the value we got back can be rendered as a string
        # without throwing any exceptions
        container_to_text(actual, fail_on_undefined=True)

    def fail(expr):
        try:
            check(expr, None)
        except Exception as e:
            return
        raise AssertionError("expected failure")


# Generated at 2022-06-23 13:30:40.683033
# Unit test for function safe_eval
def test_safe_eval():

    # fails
    assert safe_eval("__import__('sys').path") == "__import__('sys').path"
    assert safe_eval("__import__('os').path") == "__import__('os').path"
    assert safe_eval("_system('ls')") == "_system('ls')"
    assert safe_eval("__builtins__.system('ls')") == "__builtins__.system('ls')"
    assert safe_eval('dict(Dev=sda1, Ops=sdb1)') == 'dict(Dev=sda1, Ops=sdb1)'
    assert safe_eval('{"Dev": "sda1", "Ops": "sdb1"}') == '{"Dev": "sda1", "Ops": "sdb1"}'

# Generated at 2022-06-23 13:30:51.790446
# Unit test for function safe_eval
def test_safe_eval():
    '''
    safe_eval: return None on syntax error (undefined variable)
    '''
    # Syntax error (undefined variable)
    # Python 2: NameError
    # Python 3: NameError
    assert safe_eval('bar', dict(foo='ansible')) is None

    # Syntax error (invalid syntax for boolean KW)
    # Python 2: NameError
    # Python 3: SyntaxError
    if sys.version_info.major == 2:
        assert safe_eval('foo', dict(foo='ansible')) is None
    else:
        assert safe_eval('foo', dict(foo='ansible')) is None

    # None is safe
    assert safe_eval('None', dict(foo='ansible')) is None

    # Boolean True is safe

# Generated at 2022-06-23 13:31:03.592474
# Unit test for function safe_eval
def test_safe_eval():
    # test some type conversion
    assert safe_eval('foo') == 'foo'
    assert isinstance(safe_eval('foo1'), int)
    assert safe_eval('foo1', locals={'foo1': 'bar1'}) == 'bar1'
    assert isinstance(safe_eval('True'), bool)
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('None') is None
    assert safe_eval('foo3', locals={'foo3': '["bar3"]'}) == ['bar3']
    assert safe_eval('foo4', locals={'foo4': '["bar4"]'}) == ['bar4']

# Generated at 2022-06-23 13:31:12.302222
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is not really a unit test but more a quick check that things
    are working as they should.
    '''

    def test_call_enabled():
        CALL_ENABLED.append('foo')
        expr = 'foo("bar")'
        assert safe_eval(expr) == 'bar'

    # simple string/number test
    expr = '"#abc"'
    assert safe_eval(expr) == '#abc'
    expr = '1'
    assert safe_eval(expr) == 1

    # simple expressions
    expr = '1 + 1'
    assert safe_eval(expr) == 2
    expr = '1 - 1'
    assert safe_eval(expr) == 0
    expr = '2 * 2'
    assert safe_eval(expr) == 4
    expr = '1 / 2'


# Generated at 2022-06-23 13:31:17.256219
# Unit test for function safe_eval
def test_safe_eval():
    # normal evals
    assert safe_eval("1") == 1
    assert safe_eval("'foobar'") == 'foobar'
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 + 2 * 6") == 13
    assert safe_eval("1 + (2 * 6)") == 13

    # list and dict evals
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}

    # callables should fail
    assert safe_eval("str") == "str"
    assert safe_eval("str(1)") != "1"

    # computed dict keys should fail
    assert safe_eval("{1: 2}") == "{1: 2}"
    assert safe_eval

# Generated at 2022-06-23 13:31:22.586242
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure we catch invalid functions in a call
    try:
        safe_eval('os.getpid()')
        assert False, "safe_eval() should not allow calling arbitrary functions"
    except:
        pass

    # Ensure we catch syntax errors
    try:
        safe_eval('{')
        assert False, "safe_eval() should not allow syntax errors"
    except:
        pass

    # Ensure we can support simple JSON types
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # Ensure we can use numeric types
    assert safe_eval('1') == 1
    assert type(safe_eval('1')) is int
    assert safe_eval('1.1') == 1.1
    assert type(safe_eval('1')) is float

# Generated at 2022-06-23 13:31:30.001907
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval() function
    # this is not a complete set of tests, but it does test some key areas
    # (primarily the AST whitelisting)
    # plus, the test suite for this function itself should be quick enough
    # to run that we can do it with every invocation of ansible, if needed

    assert safe_eval("foo == 'bar'") is False
    assert safe_eval("foo == 'foo'") is True
    assert safe_eval("foo != 'foo'") is False
    assert safe_eval("foo != 'bar'") is True

    assert safe_eval("0 == False") is True
    assert safe_eval("0 == 'False'") is True
    assert safe_eval("0 is False") is False
    assert safe_eval("0 is 'False'") is False

# Generated at 2022-06-23 13:31:40.469649
# Unit test for function safe_eval
def test_safe_eval():
    # Test success cases
    assert safe_eval('1 + 1') == 2
    assert safe_eval('true')
    assert safe_eval('false') is False
    assert safe_eval('true and false') is False
    assert safe_eval('false and true') is False
    assert safe_eval('') == ''
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('["foo", "bar", "baz"]') == ['foo', 'bar', 'baz']
    assert safe_eval('{1: "a", 2: "b", 3: "c"}') == {1: 'a', 2: 'b', 3: 'c'}

# Generated at 2022-06-23 13:31:48.564655
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:59.361548
# Unit test for function safe_eval
def test_safe_eval():
    # Variables used in testing
    a_string = 'a_string'
    a_dict = {'a_key': 'a_value'}
    a_list = ['a_list', a_dict]
    test_dict = {'a_key': 'a_value'}
    test_dict.update(builtins.__dict__)

    # Test that safe_eval is returning the expected value for safe expressions
    assert safe_eval('a_string') == 'a_string'
    assert safe_eval('a_list') == ['a_list', {'a_key': 'a_value'}]
    assert safe_eval('a_list', test_dict) == ['a_list', {'a_key': 'a_value'}]

# Generated at 2022-06-23 13:32:10.030591
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'item in test_list'
    result = safe_eval(expr, dict(test_list=[1,2,3,4]))
    assert(result == 'item in test_list')

    expr = 'item in [1,2,3,4]'
    result = safe_eval(expr, dict(test_list=[1,2,3,4]))
    assert(result == 'item in [1,2,3,4]')

    expr = 'item in test_list'
    result, exception = safe_eval(expr, dict(test_list=[1,2,3,4]), include_exceptions=True)
    assert(result == 'item in test_list')
    assert(exception is None)

    expr = 'item in [1,2,3,4]'
    result, exception = safe_eval

# Generated at 2022-06-23 13:32:21.179318
# Unit test for function safe_eval
def test_safe_eval():
    '''
    basic test of safe_eval function above
    '''

    # test normal operations
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == dict(a='b')
    assert safe_eval('0xff') == 255
    assert safe_eval('0777') == 0o777
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1 + 2, 3 + 4]') == [3, 7]
    assert safe_eval('["foo", "bar"][0]') == 'foo'

# Generated at 2022-06-23 13:32:31.666670
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:42.667715
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{foo: bar}', {'bar': 'foo'}) == {'foo': 'foo'}
    assert safe_eval(
        '{foo: bar()}',
        {'bar': lambda: 'foo'}
    ) == '{foo: bar()}'
    assert safe_eval('{foo: bar}', include_exceptions=True) == ('{foo: bar}', None)
    assert safe_eval(
        '{foo: bar()}',
        {'bar': lambda: 'foo'},
        include_exceptions=True
    ) == ('{foo: bar()}', None)
    assert safe_eval(
        '{foo: bar()}',
        include_exceptions=True
    ) == ('{foo: bar()}', None)

# Generated at 2022-06-23 13:32:50.064881
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:59.354128
# Unit test for function safe_eval