

# Generated at 2022-06-23 13:22:58.203444
# Unit test for function safe_eval
def test_safe_eval():

    # Test with both Python 2 and 3
    if sys.version_info[0] < 3:
        builtins_module_name = '__builtin__'
    else:
        builtins_module_name = 'builtins'
    test_file = 'ansible/utils/unsafe_proxy.py'

    # Call valid values
    assert safe_eval('1 + 1', locals=dict(__builtins__=__import__(builtins_module_name))) == 2
    assert safe_eval('1 + 1') == 2
    assert safe_eval('True', locals=dict(__builtins__=__import__(builtins_module_name))) is True
    assert safe_eval('True') is True
    assert safe_eval('False', locals=dict(__builtins__=__import__(builtins_module_name))) is False

# Generated at 2022-06-23 13:23:09.745466
# Unit test for function safe_eval
def test_safe_eval():
    # Test function that evaluates a list of arguments and verifies
    # that the provided eval_function returns the expected result
    def eval_test(test_cases, eval_function, msg, include_exceptions=False):
        for test in test_cases:
            if include_exceptions:
                result, exception = eval_function(test, include_exceptions=True)
                assert exception is None, \
                    "Failed %s eval on expression '%s' (exception: %s)" % (msg, test, exception)
            else:
                result = eval_function(test)
            assert result == test_cases[test], \
                "Failed %s eval on expression '%s' (expected:%s)." % (msg, test, test_cases[test])

    # Test expressions that should succeed

# Generated at 2022-06-23 13:23:19.639278
# Unit test for function safe_eval
def test_safe_eval():
    cases = [
        # Check the safe list of AST nodes
        "1 + 1",
        "[1,2,3]",
        "[1,'two',3]",
        "dict(foo='bar')",
        "1 if True else 2",
        "-1",
    ]

    for case in cases:
        assert safe_eval(case) == eval(case)

    # invalid function
    invalid_cases = [
        "__import__('os').system('/bin/echo gotcha')",
        "exec open('gotcha.py').read()",
        "__import__('sys').exit(1)"
    ]

    for case in invalid_cases:
        try:
            safe_eval(case)
            raise Exception("failed to reject: " + case)
        except Exception as e:
            pass

    # invalid syntax

# Generated at 2022-06-23 13:23:30.278642
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 1
    expr = "output['msg']"
    value = safe_eval(expr)
    assert value == expr, "failed to return expr when invalid syntax"

    # Test case 2
    expr = "{{{ 'msg': 'hello' }}}"
    value = safe_eval(expr)
    assert value == expr, "failed to return expr when invalid syntax"

    # Test case 3
    expr = "[1, 2]"
    value = safe_eval(expr)
    assert value == [1, 2], "failed to return [1, 2]"

    # Test case 4
    expr = "{'msg': 'hi'}"
    value = safe_eval(expr)
    assert value == {'msg': 'hi'}, "failed to return {'msg': 'hi'}"

    # Test case 5

# Generated at 2022-06-23 13:23:38.084521
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:42.734136
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:54.298475
# Unit test for function safe_eval
def test_safe_eval():
    # should return a string
    assert isinstance(safe_eval("lookup('foo')"), str)

    # should return a list
    assert isinstance(safe_eval("[1,2]"), list)

    # should return a dict
    assert isinstance(safe_eval("{'a':'b'}"), dict)

    # should return an integer
    assert isinstance(safe_eval("4"), int)

    # should return a long
    assert isinstance(safe_eval("4l"), long)

    # should return a float
    assert isinstance(safe_eval("4.0"), float)

    # should return a complex number
    assert isinstance(safe_eval("4.0+4.1j"), complex)

    # should allow simple arithmetic expression
    assert safe_eval("4 + 2 - 3 * 4") == -4



# Generated at 2022-06-23 13:24:03.645518
# Unit test for function safe_eval
def test_safe_eval():
    # Add methods to the CALL_ENABLED whitelist to enable their execution
    CALL_ENABLED.extend(['len'])

    # Test if the base functionality of safe_eval is valid
    # Note that this will only work if the system's native Python
    # has the same version as the bundled Python of the Ansible instance
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('7') == 7
    assert safe_eval('7.5') == 7.5

    # Test if the whitelisting of nodes works
    # The node 'Str' is whitelisted, the node 'Repr' is not whitelisted
    # If a whitelisted node is encountered then no exception is raised and
    # the result of 'eval()'

# Generated at 2022-06-23 13:24:13.782616
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:26.582734
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1*1', {}, True) == (1, None)
    assert safe_eval('1*1') == 1
    assert safe_eval('1', {}, True) == (1, None)
    assert safe_eval('1') == 1
    assert safe_eval('1.1', {}, True) == (1.1, None)
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.1*1.1', {}, True) == (1.21, None)
    assert safe_eval('1.1*1.1') == 1.21
    assert safe_eval('True', {}, True) == (True, None)
    assert safe_eval('True') == True
    assert safe_eval('False', {}, True) == (False, None)

# Generated at 2022-06-23 13:24:32.846251
# Unit test for function safe_eval
def test_safe_eval():
    # Test dictionary of variables with a list
    variables = {
        'my_var': "{{ ['the', 'quick', 'brown', 'fox'] }}",
        'my_var2': '{{ [ "the", "quick", "brown", "fox" ] }}'
    }

    # Convert the variables dictionary to text so Jinja2 processes
    # the variables
    variables_text = container_to_text(variables)

    # With_items must be a list or a string
    assert isinstance(safe_eval(variables_text['my_var']), list)
    assert isinstance(safe_eval(variables_text['my_var2']), list)

    # Test dictionary of variables with a string

# Generated at 2022-06-23 13:24:41.918529
# Unit test for function safe_eval
def test_safe_eval():
    '''
    >>> test_safe_eval()
    0
    '''

    # call the function with the test expressions
    # from the module documentation

# Generated at 2022-06-23 13:24:50.561586
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:00.369042
# Unit test for function safe_eval
def test_safe_eval():
    # test the literal cases we added to the test
    for l in [None, True, False]:
        assert l == safe_eval(str(l))

    # test the string literal case
    assert "testing" == safe_eval("'testing'")

    # test the string variable lookup case
    assert safe_eval("foo", dict(foo="bar")) == "bar"

    # test the basic math cases
    assert safe_eval("1 + 2") == 3
    assert safe_eval("2 * 3") == 6
    assert safe_eval("2 + 3 * 4") == 14
    assert safe_eval("(2 + 3) * 4") == 20
    assert safe_eval("2 + 3 - 4") == 1

    # test comparisons
    # NOTE: this is probably not what you would expect
    assert safe_eval("'2' == 2")

# Generated at 2022-06-23 13:25:12.114447
# Unit test for function safe_eval
def test_safe_eval():
    print("=== testing safe_eval ===")
    print(safe_eval("2+3"))
    print(safe_eval("dict(a=1, b=2)"))
    print(safe_eval("[]"))
    print(safe_eval("tuple()"))
    print(safe_eval("[].append(7)"))
    print(safe_eval("(1,2) + (3,4)"))
    print(safe_eval("(1,2) + (3,4)", include_exceptions=True))
    print(safe_eval("[].append(7)", include_exceptions=True))
    print(safe_eval("2+3", include_exceptions=True))
    print(safe_eval("dict(a=1, b=2)", include_exceptions=True))

# Generated at 2022-06-23 13:25:20.593595
# Unit test for function safe_eval
def test_safe_eval():

    try:
        import __builtin__ as builtins_mod
    except ImportError:
        import builtins as builtins_mod

    def test_call_ok(expr, globals_=None, locals_=None, args=None, kwargs=None):
        ''' Test that call is allowed for this expression '''
        if globals_ is None:
            globals_ = {}

        if locals_ is None:
            locals_ = {}

        if args is None:
            args = ()

        if kwargs is None:
            kwargs = {}

        safe = safe_eval(expr)
        assert callable(safe)
        builtin = getattr(builtins_mod, expr)
        safe(*args, **kwargs)
        builtin(*args, **kwargs)

        # Test that safe_eval actually returns

# Generated at 2022-06-23 13:25:30.997998
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure safe_eval returns exception when it should
    bad_result = safe_eval("/bin/ls")
    assert bad_result is not None, "safe_eval did not return an exception"
    assert isinstance(bad_result, string_types), "safe_eval did not return an exception"

    # Make sure safe_eval returns normal value when it should
    good_result = safe_eval("ansible_facts['distribution']")
    assert good_result is not None, "safe_eval did not return a value"
    assert isinstance(good_result, string_types), "safe_eval did not return a string"

    # Make sure safe_eval returns an exception when it should
    bad_result2, err = safe_eval("/bin/ls", include_exceptions=True)

# Generated at 2022-06-23 13:25:37.356934
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:47.429849
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases where we expect no error
    assert safe_eval("[]") == []
    assert safe_eval("()") == ()
    assert safe_eval("{}") == {}
    assert safe_eval("1") == 1
    assert safe_eval("'a'") == 'a'
    assert safe_eval("1.0") == 1.0
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'a' + 'b'") == 'ab'
    assert safe_eval("'a' + 'b' + 'c'") == 'abc'
    assert safe_eval("'a' * 3") == 'aaa'
    assert safe_eval("[1]") == [1]
    assert safe_eval("(1,)") == (1,)

# Generated at 2022-06-23 13:25:57.389080
# Unit test for function safe_eval
def test_safe_eval():
    # these should be safe
    safe_eval('foo')
    safe_eval('foo.bar()')
    safe_eval('foo["bar"]')
    safe_eval('foo + bar')
    safe_eval('foo.bar + bar.foo')
    safe_eval('foo*10')
    safe_eval('foo % 10')
    safe_eval('10 % foo')
    safe_eval('foo[1]')
    safe_eval('foo[:1]')
    safe_eval('zip(foo, bar)')
    safe_eval('{1: "a"}')
    safe_eval('{1: "b", 2: "c"}')
    safe_eval('[1, 2, {"a": 3}]')
    safe_eval('(1, 2, {"a": 3})')

# Generated at 2022-06-23 13:26:08.562637
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:19.371884
# Unit test for function safe_eval
def test_safe_eval():
    # test that safe_eval only allows for
    # safe expression to be parsed
    MY_GLOBALS = {'test': 'foo'}

    # simple addition expression
    EXPR = '1 + 1'
    assert safe_eval(EXPR) == 2

    # this expression is not allowed by default.  but if
    # we add the call node to the list of allowed nodes,
    # it will be allowed
    if C.DEFAULT_CALLABLE_WHITELIST:
        EXPR = "int('0x0a', 16)"
        assert safe_eval(EXPR) == 10

        # test with custom locals
        EXPR = "'%s' %% test" % '%s'
        assert safe_eval(EXPR, MY_GLOBALS) == 'foo'

    # this expression is not allowed by default, and there

# Generated at 2022-06-23 13:26:31.723621
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:39.688054
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("5+5") == 10
    assert safe_eval("'hello'") == "hello"
    assert safe_eval("['a', 'list','of','strings']") == ['a','list','of','strings']
    assert safe_eval("{'a': 'dict', 'of': 'strings'}") == {'a': 'dict', 'of': 'strings'}
    assert safe_eval("7 - 3") == 4
    assert safe_eval("2 * 3") == 6
    assert safe_eval("-2") == -2
    assert safe_eval("+2") == 2
    assert safe_eval("2 + 3 == 5") == True
    assert safe_eval("2 + 3 != 5") == False
    assert safe_eval("1 < 2") == True
    assert safe_eval("2 < 1") == False

# Generated at 2022-06-23 13:26:50.863334
# Unit test for function safe_eval
def test_safe_eval():
    C.SHOW_CUSTOM_STDERR = False
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", include_exceptions=True) == ('foo', None)
    assert safe_eval("foo", locals=dict(foo=False)) is False
    assert safe_eval("foo", locals=dict(foo=False), include_exceptions=True) == (False, None)
    assert safe_eval("foo == 'bar'", locals=dict(foo='bar')) is True
    assert safe_eval("foo == 'bar'", locals=dict(foo='bar'), include_exceptions=True) == (True, None)
    assert safe_eval("foo == 'bar'", locals=dict(foo='baz')) is False

# Generated at 2022-06-23 13:26:59.018163
# Unit test for function safe_eval
def test_safe_eval():
    simple_items = [1, 2, 3]
    complex_items = [1, 'some string', True, None, [1,2], {'a': 1}]

    for items in [simple_items, complex_items]:
        for i in items:
            assert safe_eval(str(i)) == i

    for items in [simple_items, complex_items]:
        cur_list = container_to_text(items)
        assert safe_eval(cur_list) == items



# Generated at 2022-06-23 13:27:07.074945
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:15.391230
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("'test'+'test2'*2") == "testtesttest"
    assert safe_eval('[item for item in range(10)]') == list(range(10))
    assert safe_eval("1234") == 1234
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("{1:2, 2:3}") == {1: 2, 2: 3}
    assert safe_eval("{'a': 1, 'b': 2}", include_exceptions=True) == ({'a': 1, 'b': 2}, None)

# Generated at 2022-06-23 13:27:24.685789
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a very basic unit test.
    '''

    def assert_safe_eval(x, y, msg=None):
        if not safe_eval(x) == y:
            raise AssertionError(msg or "safe_eval(%s) != %s" % (repr(x), repr(y)))

    assert_safe_eval('True', True)
    assert_safe_eval('False', False)
    assert_safe_eval('None', None)
    assert_safe_eval('true', True)
    assert_safe_eval('false', False)
    assert_safe_eval('null', None)
    assert_safe_eval('1+1', 2)
    assert_safe_eval('{}', {})
    assert_safe_eval('[]', [])

# Generated at 2022-06-23 13:27:35.724775
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended for allowing things like:
    with_items: a_list_variable

    Where Jinja2 would return a string but we do do not want to allow it to
    call functions (outside of Jinja2, where the env is constrained).

    Based on:
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''
    # define certain JSON types
    # eg. JSON booleans are unknown to python eval()

# Generated at 2022-06-23 13:27:46.985997
# Unit test for function safe_eval
def test_safe_eval():
    # This is a list of sample expressions to evaluate,
    # along with the expected result.
    test_expressions = [
        '',
        1,
        2,
        2 - 1,
        'foo',
        'foo-bar',
        'foo-bar-baz'
    ]
    test_results = [
        '',
        1,
        2,
        1,
        'foo',
        'foo-bar',
        'foo-bar-baz'
    ]

    failed = False

    for expr, result in zip(test_expressions, test_results):
        val = safe_eval(expr)
        if val != result:
            failed = True
            print("Failed to evaluate expression '%s', expected: %s got: %s" % (expr, result, val))


# Generated at 2022-06-23 13:27:58.849562
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    if len(sys.argv) > 1:
        for expr in sys.argv[1:]:
            try:
                result = safe_eval(to_text(expr))
                print("%s => %s" % (expr, result))
            except Exception as e:
                print("%s => Exception: %s" % (expr, to_text(e)))


# Generated at 2022-06-23 13:28:07.835342
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{"a":1}', include_exceptions=True) == ({'a': 1}, None)
    assert safe_eval('a', {'a': 5}, include_exceptions=True) == (5, None)
    assert safe_eval('false', include_exceptions=True)[0] is False
    assert safe_eval('true', include_exceptions=True)[0] is True
    assert safe_eval('null', include_exceptions=True)[0] is None
    assert safe_eval('42 + 1', include_exceptions=True) == (43, None)
    assert safe

# Generated at 2022-06-23 13:28:18.513383
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:30.306456
# Unit test for function safe_eval
def test_safe_eval():
    # Test eval of python constants
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("0") == 0
    assert safe_eval("-123") == -123
    assert safe_eval("1.23") == 1.23
    assert safe_eval("-1.23") == -1.23
    assert safe_eval("0.0") == 0.0
    assert safe_eval("0.456") == 0.456
    assert safe_eval("-0.456") == -0.456
    assert safe_eval("0.456e3") == 0.456e3
    assert safe_eval("3.1E-2") == 3.1E-2
    assert safe_eval("3.1e-2") == 3.1e-2
    # Test

# Generated at 2022-06-23 13:28:42.043771
# Unit test for function safe_eval
def test_safe_eval():
    # tests
    # this regular str should be fine
    safe_expr = "foo"
    assert safe_eval(safe_expr) == safe_expr

    # this one is not okay with just a dict
    bad_expr = 'foo.bar.faz'
    try:
        safe_eval(bad_expr)
    except Exception:
        pass
    else:
        raise AssertionError('safe_eval() should have failed, but didn\'t')

    # but it's fine if we add a dict to locals
    bad_expr = 'foo.bar.faz'
    assert safe_eval(bad_expr, locals={'foo': {'bar': {'faz': 'boz'}}}) == 'boz'

    # or if we add a dict to globals
    bad_expr = 'foo.bar.faz'

# Generated at 2022-06-23 13:28:49.158399
# Unit test for function safe_eval
def test_safe_eval():
    # we allow loading and using of these builtins
    CALL_ENABLED.append('len')

    # Test cases

# Generated at 2022-06-23 13:28:58.609990
# Unit test for function safe_eval
def test_safe_eval():
    #Tests safe_eval function
    #Test safe_eval with dictionary (with non-ascii values)
    #Set C.DEFAULT_SUDO_USER to a non-ascii value for this test
    C.DEFAULT_SUDO_USER = 'testuser'

    #Testing for dictionary value
    dictionary_value = u'{\u6d4b\u8bd5: "unicode-test"}'
    success, failure = safe_eval(dictionary_value, include_exceptions=True)
    assert success == {u'\u6d4b\u8bd5': 'unicode-test'}

# AnsibleError is only used by plugins/action/__init__.py and deprecated.
# We can't just not import it because of backwards compatibility.
# pylint: disable=unused-import

# Generated at 2022-06-23 13:29:10.396806
# Unit test for function safe_eval
def test_safe_eval():

    def _test_safe_eval(expr, result, locals=None):
        returned_result, returned_exception = safe_eval(expr, locals=locals, include_exceptions=True)
        assert (returned_result, returned_exception) == (result, None)

    _test_safe_eval('1', 1)
    _test_safe_eval('False', False)

    _test_safe_eval('[1,2,3]', [1,2,3])
    _test_safe_eval('{"a":1}', {"a":1})
    _test_safe_eval('1 + 2', 3)
    _test_safe_eval('dict(a=1)', {"a": 1})
    _test_safe_eval('list([1,2,3])', [1,2,3])

   

# Generated at 2022-06-23 13:29:22.439503
# Unit test for function safe_eval
def test_safe_eval():

    def t(expr, expected):
        r, e = safe_eval(expr, include_exceptions=True)
        if e:
            raise e

        assert r == expected, "'%s' != '%s'" % (r, expected)
        assert r == safe_eval(expr), "'%s' != '%s'" % (r, safe_eval(expr))

    # basic
    t("1+1==2", True)
    t("-1+1", 0)
    t("-1+1+1", 1)
    t("-1+1+1-1", 0)

    # dict
    t("dict(a=1)", dict(a=1))
    t("dict(a=[])", dict(a=[]))
    t("dict(a=[1])", dict(a=[1]))
   

# Generated at 2022-06-23 13:29:29.754538
# Unit test for function safe_eval
def test_safe_eval():

    # Evaluating a simple expression
    x = 5
    result, exception = safe_eval('1 + x', dict(x=x), include_exceptions=True)
    assert result == 6
    assert exception is None

    # Evaluating a forbidden expression
    result, exception = safe_eval('__import__("os").system("ls")', include_exceptions=True)
    assert result == '__import__("os").system("ls")'
    assert isinstance(exception, Exception)

    # Evaluating a complex data structure
    x = 'hey'
    y = ['a', 1, {'b': 'c'}]
    d = dict(
        x=x,
        y=y,
    )

# Generated at 2022-06-23 13:29:39.281100
# Unit test for function safe_eval
def test_safe_eval():
    # These are all numbers
    assert safe_eval("1") == 1
    assert safe_eval("122") == 122

    # These are all strings
    assert safe_eval("'1'") == '1'
    assert safe_eval("\"122\"") == '122'

    # This is a string
    assert safe_eval("'string_one'") == 'string_one'
    assert safe_eval("\"string_one\"") == 'string_one'

    # These should be a list or tuple of strings
    assert safe_eval("['string_one']") == ['string_one']
    assert safe_eval("('string_one',)") == ('string_one',)

    # This should be a dictionary, string keys and string values

# Generated at 2022-06-23 13:29:49.080516
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 5
    assert safe_eval('some_dict[some_key]', dict(some_dict={'some_key': 'some_value'})) == 'some_value'
    assert safe_eval('some_dict["some_key"]', dict(some_dict={'some_key': 'some_value'})) == 'some_value'
    assert safe_eval('some_list[1]', dict(some_list=['a', 'b', 'c'])) == 'b'
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        # We expect an exception for these on Python 2.6
        assert isinstance(safe_eval('{"a":1, "b":2}'), basestring)

# Generated at 2022-06-23 13:29:58.774631
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:09.860124
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:19.174398
# Unit test for function safe_eval
def test_safe_eval():

    def check_eval(expr, assert_type, assert_value):
        value, exception = safe_eval(expr, include_exceptions=True)
        if exception is not None:
            raise Exception("eval failed for (%s) with exception: %s" % (expr, to_native(exception)))

        if not isinstance(value, assert_type):
            raise Exception("eval failed for (%s) and did not return the correct type: %s" % (expr, to_native(value)))

        if value != assert_value:
            raise Exception("eval failed for (%s) and did not return the correct value: %s" % (expr, to_native(value)))

    # string literals
    check_eval('"a string"', str, "a string")
    check_eval("'another string'", str, "another string")

   

# Generated at 2022-06-23 13:30:26.324300
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test examples from
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''
    def test(e, result=None):
        '''
        Run a single test case and compare the result to the expected value
        '''
        err = None
        try:
            re = safe_eval(e)
        except Exception as e:
            re = None
            err = e
        if re != result:
            print("FAIL: safe_eval('%s')=%s (expected %s)" % (e, re, result))
            print("      exception=%s" % err)
        else:
            print("OK:   safe_eval('%s')=%s" % (e, re))

# Generated at 2022-06-23 13:30:35.485652
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is intended for allowing things like:
    with_items: a_list_variable

    Where Jinja2 would return a string but we do not want to allow it to
    call functions (outside of Jinja2, where the env is constrained).

    Based on:
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    """

    # define certain JSON types
    # eg. JSON booleans are unknown to python eval()

# Generated at 2022-06-23 13:30:46.052996
# Unit test for function safe_eval
def test_safe_eval():
    x = safe_eval('6+5')
    assert (x == 11)
    x = safe_eval('6+5', dict(ansible=True))
    assert (x == 11)

    # allow call to import if import is allowed in configuration
    if C.DEFAULT_ALLOW_CALLABLE_IMPORTS:
        x = safe_eval('"abc" in vars', dict(vars=["abc", "def"]))
        assert (x)

    # basic invalid expression
    x = safe_eval('vars()')
    assert (x == 'vars()')
    # basic invalid expression with a dict given
    x = safe_eval('vars()', dict(ansible=True))
    assert (x == 'vars()')
    # invalid function in expression

# Generated at 2022-06-23 13:30:56.276776
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a") == "a"
    assert safe_eval("a.b") == "a.b"
    assert safe_eval("1") == 1
    assert safe_eval("1 + 1") == 2
    assert safe_eval("3 - 2") == 1
    assert safe_eval("3 - 3 - 3") == -3
    assert safe_eval("a_list_variable") == "a_list_variable"
    assert safe_eval("{{ a_var }}") == "{{ a_var }}"
    assert safe_eval("a_var") == "a_var"
    assert safe_eval("1 + {{ a_var }}") == "1 + {{ a_var }}"
    assert safe_eval("a_var + 1") == "a_var + 1"

# Generated at 2022-06-23 13:31:06.763027
# Unit test for function safe_eval
def test_safe_eval():
    # Check that we can safely evaluate string
    test_string = '{"foo": [1, 2, 3]}'
    result = safe_eval(test_string, include_exceptions=True)
    assert result[0] == ast.literal_eval(test_string)
    assert result[1] is None

    # Check that we can safely evaluate integer
    test_string = "1"
    result = safe_eval(test_string, include_exceptions=True)
    assert result[0] == ast.literal_eval(test_string)
    assert result[1] is None

    # Check that we can safely evaluate boolean
    test_string = "True"
    result = safe_eval(test_string, include_exceptions=True)
    assert result[0] == ast.literal_eval(test_string)
   

# Generated at 2022-06-23 13:31:14.575930
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:25.900036
# Unit test for function safe_eval
def test_safe_eval():

    # This test should not raise an exception.
    safe_eval("5 + 2")
    safe_eval("dictionary['valid_dict_key']")
    safe_eval("dictionary.valid_dict_key")
    safe_eval("'string_literal'")
    safe_eval("false or false")
    safe_eval("true and true")
    safe_eval("not false")
    safe_eval("2 * 3")
    safe_eval("4 / 2")
    safe_eval("-5")
    safe_eval("[]")
    safe_eval("{}")
    safe_eval("()")

    # This test should raise an exception.
    try:
        safe_eval("exec('ls')")
    except Exception as e:
        print(e)

# Generated at 2022-06-23 13:31:37.948612
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[]") == []
    assert safe_eval("['a',1,'b',2]") == ['a', 1, 'b', 2]
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 < 2") is True
    assert safe_eval("1 < 1") is False
    assert safe_eval("2 in [1,2]") is True
    assert safe_eval("3 in [1,2]") is False
    assert safe_eval("len([1,2,3])") == 3
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None

# Generated at 2022-06-23 13:31:46.861711
# Unit test for function safe_eval
def test_safe_eval():
    # test list
    tested = safe_eval("[ 1, 2, 3 ]")
    assert isinstance(tested, list)
    assert tested == [1, 2, 3]

    # test dict
    tested = safe_eval('{"a": 1, "b":2}')
    assert isinstance(tested, dict)
    assert tested == {"a": 1, "b": 2}

    # test dict
    tested = safe_eval('{"a": 1, "b": [1,2]}')
    assert isinstance(tested, dict)
    assert tested == {"a": 1, "b": [1, 2]}

    # test dict
    tested = safe_eval('{"a": 1, "b": {"c": "d"}}')
    assert isinstance(tested, dict)

# Generated at 2022-06-23 13:31:58.955715
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEVELOPMENT:
        return

    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    # basic syntax and type checking
    def check(expr, expected, locals=None):
        ret, err = safe_eval(expr, locals=locals, include_exceptions=True)
        if err is not None:
            raise AssertionError('failed to evaluate expression %s: %s' % (expr, err))
        if expected != ret:
            raise AssertionError('expression %s evaluated to %s when %s was expected' % (expr, ret, expected))

    check('a', 'a')
    check('["a"]', ['a'])

# Generated at 2022-06-23 13:32:09.803189
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:19.110185
# Unit test for function safe_eval
def test_safe_eval():
    tests = [
        ("'abc'", "'abc'"),
        ("['a', 'b', 'c']", ['a', 'b', 'c']),
        ("{'a': 'a', 'b': 'b'}", {'a': 'a', 'b': 'b'}),
        ("1", 1),
        ("1+1", 2),
        ("1.2+2.3", 3.5),
        ("'a' + 'b'", "'ab'")
    ]

    for test in tests:
        assert(safe_eval(test[0]) == test[1])



# Generated at 2022-06-23 13:32:30.263289
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases: Unsafe expressions
    # Unsafe JSON types
    assert not safe_eval("__builtin__")
    assert not safe_eval("__builtins__")
    assert not safe_eval("abs")
    assert not safe_eval("all")
    assert not safe_eval("any")
    assert not safe_eval("basestring")
    assert not safe_eval("bool")
    assert not safe_eval("bytearray")
    assert not safe_eval("bytes")
    assert not safe_eval("chr")
    assert not safe_eval("classmethod")
    assert not safe_eval("cmp")
    assert not safe_eval("compile")
    assert not safe_eval("complex")
    assert not safe_eval("delattr")
    assert not safe_eval("dict")

# Generated at 2022-06-23 13:32:41.665639
# Unit test for function safe_eval
def test_safe_eval():
    expr = "a_list_variable if True else None"
    local_vars = {'a_list_variable': [1, 2, 3]}
    result = safe_eval(expr, local_vars, include_exceptions=False)
    assert isinstance(result, list)
    assert [1, 2, 3] == result

    expr = "a_dict_variable if True else None"
    local_vars = {'a_dict_variable': {'a': 1, 'b': 2}}
    result = safe_eval(expr, local_vars, include_exceptions=False)
    assert isinstance(result, dict)
    assert local_vars['a_dict_variable'] == result

    expr = "a_dict_variable[x] if True else None"

# Generated at 2022-06-23 13:32:53.894101
# Unit test for function safe_eval