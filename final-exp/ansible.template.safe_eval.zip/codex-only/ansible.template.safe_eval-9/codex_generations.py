

# Generated at 2022-06-23 13:23:06.290206
# Unit test for function safe_eval
def test_safe_eval():
    # basic types
    assert safe_eval('True') is True
    assert safe_eval(True) is True
    assert safe_eval('true') is True
    assert safe_eval(True) is True
    assert safe_eval('"false"') == 'false'
    assert safe_eval('[true, false]') == [True, False]

    # comparison operators
    assert safe_eval('1 == 1') is True
    assert safe_eval('true == false') is False
    assert safe_eval('1.0 == 1') is True
    assert safe_eval('1.1 == 1') is False
    assert safe_eval('"abc" == "abc"') is True
    assert safe_eval('"abc" == "def"') is False

    # boolean operators
    assert safe_eval('true or false') is True
    assert safe

# Generated at 2022-06-23 13:23:14.347061
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'foo["bar"]'
    expected_result = expr
    result = safe_eval(expr)
    assert(result == expected_result)

    expr = 'foo["bar"] * 5'
    expected_result = expr
    result = safe_eval(expr)
    assert(result == expected_result)

    expr = 'foo["bar"] ** 5'
    expected_result = expr
    result = safe_eval(expr)
    assert(result == expected_result)

    expr = '{}'
    expected_result = {}
    result = safe_eval(expr)
    assert(result == expected_result)

    expr = 'foo[0]'
    expected_result = expr
    result = safe_eval(expr)
    assert(result == expected_result)

    expr = 'foo[0] * 5'
   

# Generated at 2022-06-23 13:23:24.411975
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import json
    import sys

    def test(expr, error=False):
        try:
            result = safe_eval(expr)
        except TypeError:
            pass
        except Exception as e:
            # Special handling for syntax errors
            if isinstance(e, ast.SyntaxError):
                result = expr
            else:
                raise e
        if error:
            assert result == expr, 'Got: ' + to_native(result)
        else:
            json_result = json.loads(json.dumps(result))
            # Outputs are being truncated. Setting output length to 0 for now
            assert json_result == json.loads(json.dumps(eval(expr))), 'Got: ' + to_native(result)

    # test coverage for all valid types.
    test('0')
    test

# Generated at 2022-06-23 13:23:34.185725
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:45.785276
# Unit test for function safe_eval
def test_safe_eval():
    # Test expressions that should be safe
    safe_expr = [
        'a_list_variable',
        'a_string',
        'a_string[0]',
        'a_string[a:b]',
        '"a" + "b"',
        '1 + 1',
        '1 / 2',
        '-a',
        '-1',
        'not a',
        'a and b',
        'a is b',
        '(a or b) == False',
        'True',
        'False',
        'None',
        'false',
        'null',
        'true'
    ]
    for expr in safe_expr:
        safe_eval(expr)

    # Test expressions that should not be safe

# Generated at 2022-06-23 13:23:56.022122
# Unit test for function safe_eval
def test_safe_eval():
    # Test some common use cases
    assert safe_eval('a') == 'a'
    assert safe_eval('a == b') == 'a == b'

    # Test some cases which should not work
    assert safe_eval('__import__("os").system("ls")') == '__import__("os").system("ls")'
    assert safe_eval('__import__("os").system("ls")', include_exceptions=True)[0] == '__import__("os").system("ls")'
    assert safe_eval('__import__("os").system("ls")', include_exceptions=True)[1] is not None
    assert safe_eval('__import__("os")') == '__import__("os")'
    # SyntaxError is thrown by python instead of an exception

# Generated at 2022-06-23 13:24:02.302382
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid expressions
    assert safe_eval("a_list_variable", dict(a_list_variable=[1,2,3])) == [1,2,3]
    assert safe_eval("a_variable", dict(a_variable=1)) == 1
    assert safe_eval("a_variable + 5", dict(a_variable=1)) == 6
    assert safe_eval("a_variable * 5", dict(a_variable=1)) == 5
    assert safe_eval("a_variable + 5", dict(a_variable=1)) == 6
    assert safe_eval("a_variable - 5", dict(a_variable=1)) == -4
    assert safe_eval("5 - a_variable", dict(a_variable=1)) == 4

    # Test exceptions

# Generated at 2022-06-23 13:24:10.591156
# Unit test for function safe_eval
def test_safe_eval():
    # Test the various literals, and some basic operators
    literals = (
        'null',
        'false',
        'true',
        '0',
        '-1',
        '[]',
        '{}',
        '["foo", "bar", "baz"]',
        '{"foo": "bar", "baz": "qux"}',
    )
    for literal in literals:
        exprs = (
            literal,
            '-%s' % literal,
            '+%s' % literal,
            '(%s)' % literal,
        )
        for expr in exprs:
            result = safe_eval(expr)
            assert result == ast.literal_eval(expr)

    # Test some more complex examples

# Generated at 2022-06-23 13:24:20.221889
# Unit test for function safe_eval
def test_safe_eval():
    # Test with invalid AST nodes
    try:
        safe_eval('__import__("json").loads("{}")')
    except Exception as e:
        assert isinstance(e, Exception)

    assert safe_eval('1 + 1 == 2')
    assert not safe_eval('1 + 1 == 3')
    assert safe_eval('a == a', {'a': 'a'})
    assert not safe_eval('a == b', {'a': 'a'})
    assert safe_eval('{1:2, 3:4} == {3:4, 1:2}')
    assert safe_eval('{"a":[1,2,3], "b":[4,5,6]} == {"b":[4,5,6], "a":[1,2,3]}')
    assert safe_eval("True")
    assert not safe_

# Generated at 2022-06-23 13:24:29.379899
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('2.5') == 2.5
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None
    assert safe_eval('a') == 'a'
    assert safe_eval('a+1') == 'a+1'
    assert safe_eval('2+4') == 6
    assert safe_eval('2 * 3') == 6
    assert safe_eval('7 - 8') == -1
    assert safe_eval('3 / 2') == 1.5
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('-a')

# Generated at 2022-06-23 13:24:39.137055
# Unit test for function safe_eval
def test_safe_eval():
    # test eval exceptions
    assert safe_eval("x.x") == "x.x"
    assert safe_eval("[x,y]") == "[x,y]"
    assert safe_eval("{x:y}") == "{x:y}"

    # test basic types
    assert safe_eval("-1") == -1
    assert safe_eval("1") == 1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("null") == None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("'foo'") == "foo"

# Generated at 2022-06-23 13:24:48.801300
# Unit test for function safe_eval
def test_safe_eval():
    expr = "True"
    result = safe_eval(expr)
    assert result is True

    expr = "True"
    result = safe_eval(expr)
    assert result is True

    expr = "True and False"
    result = safe_eval(expr)
    assert result is False

    expr = "foo"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == "foo"
    assert exception == None

    expr = "True and foo"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == "True and foo"
    assert exception is not None

    expr = "foo"
    foo = 1
    result = safe_eval(expr, {"foo": foo})
    assert result == 1

    expr = "foo"

# Generated at 2022-06-23 13:24:58.858158
# Unit test for function safe_eval
def test_safe_eval():
    # These expressions should evaluate without raising an exception
    true_pass = [
        'foo',
        'True',
        'false',
        'null',
        'true',
        '1',
        '[]',
        '{}',
        '{"foo": "bar"}',
        '["foo", "bar"]',
        '1+2',
        '2*3',
        # "__import__('sys').modules",  # can't do this because it removes the global __builtins__
        'dict()',
        'list()',
        'int()',
        'set()',
    ]
    for expr in true_pass:
        res, err = safe_eval(expr, {}, include_exceptions=True)
        assert err is None

    # These expressions should raise an exception

# Generated at 2022-06-23 13:25:06.110045
# Unit test for function safe_eval
def test_safe_eval():
    v1 = safe_eval('a + b')
    assert v1 == "a + b", "did not return a string"
    v1 = safe_eval('a + b', dict(a=1, b=2))
    assert v1 == 3, "did not calculate expression"
    v1 = safe_eval('a and b')
    assert v1 == "a and b", "did not return a string"
    v1 = safe_eval('a and b', dict(a=True, b=False))
    assert v1 == False, "did not calculate expression"
    try:
        v1 = safe_eval('import os; os.system("echo ' + C.DEFAULT_VAULT_PASSWORD_FILE + '")')
        assert False, "did not raise exception"
    except Exception:
        pass

# Generated at 2022-06-23 13:25:17.040848
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    # Test AST node types

# Generated at 2022-06-23 13:25:28.206181
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:38.627154
# Unit test for function safe_eval
def test_safe_eval():
    # type check for safe_eval
    assert isinstance(safe_eval(1), int)

    # equality check for safe_eval
    assert safe_eval('<') == '<', "safe_eval failed"

    # list check for safe_eval
    assert safe_eval('[]') == [], "safe_eval failed"

    # dict check for safe_eval
    assert safe_eval('{}') == {}, "safe_eval failed"

    # syntax error check for safe_eval
    assert safe_eval('{{') == '{{', "safe_eval failed"

    # unicode check for safe_eval
    assert safe_eval(u'\u2713') == u'\u2713', "safe_eval failed"

    # bool check for safe_eval
    assert safe_eval('false') is False and safe_eval('true')

# Generated at 2022-06-23 13:25:46.392743
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:54.543621
# Unit test for function safe_eval
def test_safe_eval():
    '''
    The following lines test the safe_eval function
    '''
    assert safe_eval('True')
    assert safe_eval('False')
    assert not safe_eval('False', {})
    assert safe_eval('True or False')
    assert not safe_eval('True or False', {})
    assert safe_eval('True and False')
    assert not safe_eval('True and False', {})
    assert safe_eval('a and b', dict(a=1, b=1))
    assert safe_eval('a or b', dict(a=False, b=False))
    assert safe_eval('a or b', dict(a=True, b=False))
    assert safe_eval('a or b', dict(a=False, b=True))

# Generated at 2022-06-23 13:26:07.027073
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:18.767798
# Unit test for function safe_eval
def test_safe_eval():
    # Test for AnsibleModule
    # TODO: add some unit test

    # Test for safe_eval
    if sys.version_info >= (3, 0):
        # Can't use 'in' as part of safe_eval()
        v1 = safe_eval('[{"a": "b"}, {"c": "d"}]')
        assert isinstance(v1, list)

        # Can parse json
        v1 = safe_eval('{"a": "b"}')
        assert isinstance(v1, dict)

        # Can not use builtin
        with C.DEFAULT_MODULE_UTILS_PATH:
            v1, e = safe_eval('open', include_exceptions=True)
            assert isinstance(v1, str)
            assert isinstance(e, Exception)


# Generated at 2022-06-23 13:26:30.663858
# Unit test for function safe_eval
def test_safe_eval():
    # Test no evals
    assert safe_eval("5") == 5
    assert safe_eval("test") == "test"
    assert safe_eval("'test'") == "test"
    assert safe_eval("['test']") == ["test"]
    assert safe_eval("{'test': 'test2'}") == {'test': 'test2'}
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("None") is None
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("-'-5'") == 5
    assert safe_eval("-5") == -5

    # Test with evals

# Generated at 2022-06-23 13:26:39.294975
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:50.581621
# Unit test for function safe_eval
def test_safe_eval():
    ''' test safe_eval'''
    assert safe_eval('[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval('{"one": 1, "two": 2}') == {'one': 1, 'two': 2}
    assert safe_eval('{"a": [1,2,3], "b": 4}') == {'a': [1, 2, 3], 'b': 4}
    assert safe_eval('{"a": [1,2,3], "b": [{"foo": "bar"}]}') == {'a': [1, 2, 3], 'b': [{'foo': 'bar'}]}

# Generated at 2022-06-23 13:27:02.294483
# Unit test for function safe_eval
def test_safe_eval():
    # This is a test template which should evaluate successfully
    test_template_1 = '{{ ansible_eth0.ipv4.address }}'
    # This is another test template which needs to be rendered before evaluation
    test_template_2 = "{{ lookup('file', '/etc/resolv.conf').split()[1] }}"
    # This should not be safe to eval
    test_template_3 = '{{ lookup("pipe","wget http://www.google.com/ -q -O - | grep title | sed -e "s/<[^>]*>//g") }}'
    # This is a safe one for eval
    test_template_4 = '{{ stdout_lines[0].split()[1] }}'
    # This should be safe for eval

# Generated at 2022-06-23 13:27:13.158450
# Unit test for function safe_eval
def test_safe_eval():
    # validate 1 + 2 eq 3 and 2 * 3 eq 6
    expr = '1 + 2'
    result, exception = safe_eval(expr, {}, include_exceptions=True)
    assert result == 3
    assert exception is None

    expr = '2 * 3'
    result, exception = safe_eval(expr, {}, include_exceptions=True)
    assert result == 6
    assert exception is None

    # try 1 + 2 == 3 and 2 * 3 == 6
    expr = '1 + 2 == 3'
    result, exception = safe_eval(expr, {}, include_exceptions=True)
    assert result is True
    assert exception is None

    expr = '2 * 3 == 6'
    result, exception = safe_eval(expr, {}, include_exceptions=True)
    assert result is True
    assert exception

# Generated at 2022-06-23 13:27:23.403239
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text

    raw = u'[1,2,3]'
    b_raw = to_text(raw, encoding=None, errors='surrogate_or_strict')

    # make sure that both unicode and bytes are handled equally
    assert raw == b_raw

    # basic sanity test
    assert safe_eval(raw) == ast.literal_eval(raw)
    assert safe_eval(b_raw) == ast.literal_eval(b_raw)

    # test if error is propagated
    assert safe_eval(u'[1,2,3') == u'[1,2,3'

    # test with a variable

# Generated at 2022-06-23 13:27:35.356536
# Unit test for function safe_eval
def test_safe_eval():
    # builtins that can be enabled
    CALL_ENABLED.insert(0, 'int')

    assert safe_eval('1') == 1
    assert safe_eval('"1"') == '1'
    assert safe_eval('[1]') == [1]
    assert safe_eval('{1: 1}') == {1: 1}
    assert safe_eval('g', dict(g=[1])) == [1]
    assert safe_eval('[1, 2] + [3, 4]') == [1, 2, 3, 4]
    assert safe_eval('[1, 2] * 2') == [1, 2, 1, 2]
    assert safe_eval('a', dict(a='string')) == 'string'
    assert safe_eval('a', dict(a=1)) == 1
    assert safe_

# Generated at 2022-06-23 13:27:43.769584
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run the safe_eval function on a list of expressions of the form:
    '[expr, expected_return_value]'
    '''

# Generated at 2022-06-23 13:27:52.635188
# Unit test for function safe_eval
def test_safe_eval():
    def _test_safe_eval(expr, successful=True):
        # run eval on both raw expression and converted to string
        if isinstance(expr, string_types):
            res, msg = safe_eval(expr, include_exceptions=True)
            if successful:
                assert msg is None, "safe_eval of \"%s\" raised unexpected exception: %s" % (expr, msg)
                assert res == eval(expr)
            else:
                assert msg is not None, "safe_eval of \"%s\" should have raised an exception" % (expr)
                assert res == expr

            res = safe_eval(expr)
            if successful:
                assert res == eval(expr)
            else:
                assert res == expr

# Generated at 2022-06-23 13:28:02.886069
# Unit test for function safe_eval
def test_safe_eval():

    # false alerts in pyflakes
    # pylint: disable=undefined-variable

    # simple expressions
    assert safe_eval('a == "b"') is False
    assert safe_eval('a != "b"') is True
    assert safe_eval('a and b') is None
    assert safe_eval('a or b') is 'a'
    assert safe_eval('not a') is True
    assert safe_eval('count(a)') == len(a)
    assert safe_eval('count(a, True)') == len(a)
    assert safe_eval('count(a, False)') == len(a)
    assert safe_eval('first(a)') == a[0]
    assert safe_eval('last(a)') == a[-1]

# Generated at 2022-06-23 13:28:09.238722
# Unit test for function safe_eval
def test_safe_eval():
    class KnownException(Exception):
        pass

    test = dict()
    test[0] = dict(
        expr='1',
        success=True,
        result=1,
    )
    test[1] = dict(
        expr='1 or 2',
        success=True,
        result=1,
    )

# Generated at 2022-06-23 13:28:19.305483
# Unit test for function safe_eval
def test_safe_eval():
    simple_expr = '2 + 3'
    assert 5 == safe_eval(simple_expr)

    # using the with_items syntax
    with_items_expr = "['a','b','c']"
    assert ['a', 'b', 'c'] == safe_eval(with_items_expr)

    # the same expression, but with a comment
    with_comment = "['a','b','c']  # comment here"
    assert ['a', 'b', 'c'] == safe_eval(with_comment)

    # string concatenation
    string_concat = "'ans' + 'ible'"
    assert 'ansible' == safe_eval(string_concat)

    # addition of strings
    string_add = "'ans' 'ible'"
    assert 'ansible' == safe_eval(string_add)

    # calling

# Generated at 2022-06-23 13:28:30.781831
# Unit test for function safe_eval
def test_safe_eval():
    def run_test(expr, expected_result):
        result, exception = safe_eval(expr, include_exceptions=True)
        if result != expected_result:
            print("%s evaled to %s, expected %s" % (expr, result, expected_result))
            sys.exit(1)
        if exception:
            print("%s threw an exception: %s" % (expr, exception))
            sys.exit(1)

    # some basic tests of the safe_eval function
    if safe_eval("[1,2,3]") != [1,2,3]:
        print("safe_eval 1 failed")
        sys.exit(1)

# Generated at 2022-06-23 13:28:42.405121
# Unit test for function safe_eval
def test_safe_eval():
    # code to run a test
    assert safe_eval("4+4") == 8
    assert safe_eval("4+4", include_exceptions=True) == (8, None)

    assert safe_eval("4 + 4") == 8
    assert safe_eval("4 + 4", include_exceptions=True) == (8, None)

    assert safe_eval("foo42") == "foo42"
    assert safe_eval("foo42", include_exceptions=True) == ("foo42", None)

    assert safe_eval("A + B", dict(A=1, B=2)) == 3
    assert safe_eval("A + B", dict(A=1, B=2), include_exceptions=True) == (3, None)

    assert safe_eval("'a' + 'b'") == "ab"

# Generated at 2022-06-23 13:28:49.414132
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function safe_eval

    Returns:
        Test result
    '''

    # Test 1: simple expression
    safe_eval_string = '1 + 1'
    safe_eval_expected_result = 2
    safe_eval_observed_result = safe_eval(safe_eval_string)

    if safe_eval_observed_result != safe_eval_expected_result:
        sys.exit("Unit test for safe_eval failed: test 1")

    # Test 2: dict expression
    safe_eval_string = "{'a': 'b'}"
    safe_eval_expected_result = {'a': 'b'}
    safe_eval_observed_result = safe_eval(safe_eval_string)


# Generated at 2022-06-23 13:28:58.766927
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended for output from the ansible-doc script,
    so that we can use the test framework properly.
    '''

    global CALL_ENABLED
    CALL_ENABLED.append('version')
    CALL_ENABLED.append('foo')


# Generated at 2022-06-23 13:29:10.632427
# Unit test for function safe_eval
def test_safe_eval():
    # these tests were stolen from test_jinja2.py and modified
    # to run in this context

    # simple cases
    assert safe_eval('foo') == 'foo'
    assert safe_eval('1 + 1') == 2

    # eval() would allow us to call builtins
    assert 'open' not in safe_eval('__builtins__.keys()')

    # some python syntax not allowed
    assert 'while' not in safe_eval('__builtins__.keys()')

    # no function calls!
    assert safe_eval('foo(1)') == 'foo(1)'

    # because we don't allow '.', these are all just strings
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar()') == 'foo.bar()'

# Generated at 2022-06-23 13:29:15.033077
# Unit test for function safe_eval
def test_safe_eval():
    # Test a typical invocation
    assert safe_eval('4 + 5') == 9

    # Test for undefined variables
    try:
        safe_eval('foo * 5')
        assert False, "safe_eval() didn't detect an undefined variable"
    except:
        pass

    # Test for security violations
    try:
        safe_eval('__import__("os").popen("ls").read()')
        assert False, "safe_eval() is not safe!"
    except:
        pass

    # Test callable
    assert safe_eval('min([1,2,3,4])') == 1

    # Test weird expressions
    assert safe_eval('{{ foo }}') == '{{ foo }}'
    assert safe_eval(4) == 4

    # Test for syntax error
    assert safe_eval('{{ foo') == '{{ foo'



# Generated at 2022-06-23 13:29:26.137134
# Unit test for function safe_eval
def test_safe_eval():
    # base test
    result = safe_eval('2 + 3')
    assert result == (5, None)

    # test with a value that would normally be treated as a string
    result = safe_eval('"a" + "b"')
    assert result == ("ab", None), result

    # test with a call expression
    result = safe_eval('len("abc")')
    assert result == (3, None), result

    # test with a call expression including a variable
    result = safe_eval('len("abc" + "def")', dict(abc="abc"))
    assert result == (6, None), result

    # test with an invalid expression
    result = safe_eval('len("abc" + "def" + vars())', dict(abc="abc"))

# Generated at 2022-06-23 13:29:37.034025
# Unit test for function safe_eval
def test_safe_eval():

    # test safe_eval
    class TestEval:
        def __init__(self, value):
            self.value = value

        def simple(self):
            return self.value

        def args(self, num):
            return self.value + num

        def kwargs(self, num=100):
            return self.value + num

        def varargs(self, *args):
            return self.value + len(args)

        def varkwargs(self, **kwargs):
            return self.value + len(kwargs)

        def varargs_and_varkwargs(self, *args, **kwargs):
            return self.value + len(args) + len(kwargs)

    # simple use - no args, no wonkiness
    test_obj = TestEval(42)
    eval_str

# Generated at 2022-06-23 13:29:46.110435
# Unit test for function safe_eval
def test_safe_eval():
    # helper function to test safe_eval
    def test_eval(expr, failed=False, **kwargs):
        cur_expr = expr
        if kwargs:
            cur_expr = cur_expr % kwargs
        passed = False
        try:
            result = safe_eval(cur_expr)
            passed = True
        finally:
            if failed:
                assert not passed, "safe_eval unexpectedly passed for expression: %s = %s" % (cur_expr, result)
            else:
                assert passed, "safe_eval unexpectedly failed for expression: %s" % cur_expr

    # Test expressions that passed safe_eval
    test_eval('1')
    test_eval('1+1')
    test_eval('1+1==2')
    test_eval('false or true')

# Generated at 2022-06-23 13:29:57.498311
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:09.316682
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:20.706315
# Unit test for function safe_eval
def test_safe_eval():
    def test(name, expr, expected):
        result, exc = None, None
        try:
            if isinstance(expected, type):
                result, exc = safe_eval(expr, include_exceptions=True)
            else:
                result = safe_eval(expr, include_exceptions=True)
        except Exception as e:
            exc = e
        success = (result == expected and (exc is None or isinstance(exc, expected)))
        if not success:
            print(name, success, result, exc, to_native(expr))

    # basic arithmetic
    test('Add', '1 + 2', 3)
    test('Subtract', '1 - 1', 0)
    test('Multiply', '2 * 3', 6)
    test('Divide', '2 / 2', 1)

# Generated at 2022-06-23 13:30:33.418371
# Unit test for function safe_eval
def test_safe_eval():
    # Sanity
    assert safe_eval('{0}') == {}

    # Test basic functionality
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 3') == 4
    assert safe_eval('true and true')
    assert safe_eval('false and true', include_exceptions=True) == (False, None)
    assert safe_eval('true and false', include_exceptions=True) == (False, None)
    assert safe_eval('false and false', include_exceptions=True) == (False, None)
    assert safe_eval('true or true')
    assert safe_eval('false or true')
    assert safe_eval('true or false')
    assert safe_eval('false or false', include_exceptions=True) == (False, None)

# Generated at 2022-06-23 13:30:40.652407
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This unit test is designed to test safe_eval.

    NOTE: This test is not exhaustive, it is just a starting point to exercise the
    code.  It is not intended to be used as an input validation or secure coding practice.
    '''

    # Show the safe_eval function output given the input expression
    def _test_eval(expr):

        result = safe_eval(expr)
        print("%s => %s" % (expr, result))

    # Test various ways of returning a string
    _test_eval('"a string"')
    _test_eval("'single quotes'")
    _test_eval('"a test of \'single quotes\' inside double quotes"')
    _test_eval('"a test of \"double quotes\" inside double quotes"')

# Generated at 2022-06-23 13:30:50.510065
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: This is not an extensive test.
    # val, exc = safe_eval('"foo" in bar', {'bar': [1,2,3]}, include_exceptions=True)
    # assert val == False
    # assert exc is None

    val, exc = safe_eval('bar[0]', {'bar': [1,2,3]}, include_exceptions=True)
    assert val == 1
    assert exc is None

    # val, exc = safe_eval('"foo" in bar', {'bar': [1,2,3]}, include_exceptions=True)
    # assert val is None
    # assert exc is not None

    return True

# Generated at 2022-06-23 13:31:02.511107
# Unit test for function safe_eval
def test_safe_eval():
    success = True

    # Test the CleansingNodeVisitor class with various expressions

# Generated at 2022-06-23 13:31:09.677621
# Unit test for function safe_eval
def test_safe_eval():
    one = 1
    two = 2
    three = 3
    six = 6
    seven = 7
    true = True
    false = False

    # test basic functionality
    assert safe_eval('one * two * three') == six
    assert safe_eval('one + two + three') == six
    assert safe_eval('seven - two - one') == four
    assert safe_eval('seven - two - three') == two
    assert safe_eval('(three - two) * (one + two)') == three
    assert safe_eval('true and false') is False
    assert safe_eval('true or false') is True
    assert safe_eval('true or true and false') is True
    assert safe_eval('false or true and false') is False

    # test that the string representation is returned when syntax errors occur

# Generated at 2022-06-23 13:31:21.726828
# Unit test for function safe_eval
def test_safe_eval():
    current_module = sys.modules[__name__]
    safe_eval_result = safe_eval('foobar', vars(current_module))
    assert safe_eval_result == 'foobar'
    safe_eval_result = safe_eval('True', vars(current_module))
    assert safe_eval_result
    safe_eval_result = safe_eval('False', vars(current_module))
    assert not safe_eval_result
    safe_eval_result = safe_eval('1 + 2', vars(current_module))
    assert safe_eval_result == 3
    safe_eval_result = safe_eval('1 <= 2', vars(current_module))
    assert safe_eval_result
    safe_eval_result = safe_eval('1 < 2', vars(current_module))
    assert safe_

# Generated at 2022-06-23 13:31:29.673509
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run unit tests on function safe_eval
    '''
    class TestEval:
        def a(self):
            return 'a'


# Generated at 2022-06-23 13:31:40.204390
# Unit test for function safe_eval
def test_safe_eval():
    class SafeDict(dict):
        """Wrapper for dict to prevent calling functions."""
        def __getitem__(self, key):
            val = super(SafeDict, self).__getitem__(key)
            if isinstance(val, dict):
                return SafeDict(val)
            return val

        def get(self, key, default=None):
            val = super(SafeDict, self).get(key, default)
            if isinstance(val, dict):
                return SafeDict(val)
            return val

    # check all kinds of strings to avoid type check in safe_eval

# Generated at 2022-06-23 13:31:48.341312
# Unit test for function safe_eval
def test_safe_eval():
    # Try a hardcoded list
    result = safe_eval("[1,2,3]")
    assert result == [1, 2, 3]

    # Try a hardcoded dict
    result = safe_eval("{'a':1, 'b':{'c':2}}")
    assert result == {'a': 1, 'b': {'c': 2}}

    # Try a reference to a variable
    result = safe_eval("{{a_var}}", dict(a_var=5))
    assert result == 5

    # Try a reference to a known function
    result = safe_eval("len([1,2,3])")
    assert result == 3

    # Try a reference to an unknown function

# Generated at 2022-06-23 13:31:59.327120
# Unit test for function safe_eval
def test_safe_eval():

    def _assert_exception(expr, should_error, error_message):
        result = safe_eval(expr)
        if should_error:
            assert result == expr, "%s should have returned %s" % (error_message, expr)
        else:
            assert result != expr, "%s should have returned something else than %s" % (error_message, expr)

    # Test basic lists and dicts
    _assert_exception("[3, 4, 5]", False, "list construction")
    _assert_exception("{'a': 2, 'b': 4}", False, "dict construction")
    _assert_exception("[3, {'a': 2}]", False, "complex list construction")
    _assert_exception("[x for x in range(10)]", False, "list comprehension")
    # Test

# Generated at 2022-06-23 13:32:09.993208
# Unit test for function safe_eval
def test_safe_eval():
    # Test a simple addition
    assert safe_eval("2 + 2") == 4

    # Test a dict
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

    # Test a list
    assert safe_eval("[1, [2, 3], 4]") == [1, [2, 3], 4]

    # Test a comparison
    assert safe_eval("2 > 3") == False

    # Test null
    assert safe_eval("None") is None

    # Test true
    assert safe_eval("True") is True

    # Test false
    assert safe_eval("False") is False

    # Test empty string
    assert safe_eval("''") == ''

    # Test string
    assert safe_eval("'a'") == 'a'

    # Test

# Generated at 2022-06-23 13:32:21.177982
# Unit test for function safe_eval
def test_safe_eval():
    # Check for Jinja2 templating
    test_var = '{{ foo }}'
    assert safe_eval(test_var) == test_var

    # Check for Python string templating
    test_var = '{foo}'
    assert safe_eval(test_var) == test_var

    # Check for Python datetime templating
    test_var = '{{ 2011-06-01 }}'
    assert safe_eval(test_var) == '{{ 2011-06-01 }}'

    # Boolean test
    test_var = 'True'
    assert safe_eval(test_var)

    # Integer test
    test_var = '50'
    assert safe_eval(test_var) == 50

    # Float test
    test_var = '50.0'

# Generated at 2022-06-23 13:32:31.667714
# Unit test for function safe_eval
def test_safe_eval():

    # Tests for functions
    # These tests should fail with exceptions.
    assert safe_eval("__import__('os').system('/usr/bin/id')") == "__import__('os').system('/usr/bin/id')"
    assert safe_eval('len("123456789")') == 'len("123456789")'
    assert safe_eval('{"a": 1, "b": 2}') == '{"a": 1, "b": 2}'
    assert safe_eval('["a", "b", "c"]') == '["a", "b", "c"]'
    assert safe_eval('(1, 2, 3, 4)') == '(1, 2, 3, 4)'
    assert safe_eval('set([1, 2, 3, 4])') == 'set([1, 2, 3, 4])'

# Generated at 2022-06-23 13:32:42.668146
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:47.162388
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: this unit test is incomplete and needs to be finished for rescue mode
    success_exprs = ['1', '1+1', '1 + 1', '1 + 1 - 2', '/etc/myfile']
    for expr in success_exprs:
        try:
            safe_eval(expr)
        except Exception as e:
            print("safe_eval('%s') could not be evaluated: %s" % (expr, to_native(e)))
            sys.exit(1)


# Generated at 2022-06-23 13:32:57.273219
# Unit test for function safe_eval