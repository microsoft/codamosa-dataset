

# Generated at 2022-06-23 13:23:06.337711
# Unit test for function safe_eval
def test_safe_eval():
    # test 1
    # Note: Passing a non string expr (dict) to safe_eval should return it
    #       unchanged
    non_str_expr = {'lbl': 'hello'}
    assert safe_eval(non_str_expr, locals=dict(lbl='hello')) == non_str_expr

    # test 2
    # Note: passing a string expr to safe_eval will return
    #       the evaluated result of the expression
    str_expr = 'lbl'
    assert safe_eval(str_expr, locals=dict(lbl='hello')) == 'hello'

    # test 3 (with fail=True)
    # Note: if fail=True, safe_eval should return the original string
    #       (and not evaluate it)
    str_expr_with_fail = 'lbl'
    assert safe_eval

# Generated at 2022-06-23 13:23:14.424337
# Unit test for function safe_eval
def test_safe_eval():
    # this is intended for allowing things like:
    # with_items: a_list_variable
    # Where Jinja2 would return a string but we do not want to allow it to call functions (outside of Jinja2, where the env is constrained).
    # Based on:
    # http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe

    # Some rule definitions that can be used by the tests below
    rule1 = {'with_items': 'some_list_variable'}
    rule2 = {'with_items': 'some_list_variable | some_filter'}
    rule3 = {'with_items': ['a', 2]}
    rule4 = {'with_items': ['a', 2, 'some_var']}
   

# Generated at 2022-06-23 13:23:20.986706
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info >= (3,):
        return

    local_vars = {
        "test_data": frozenset(['A', 'B', 'C']),
        "test_data2": [1, 2, 3],
        "test_dict_a": {
            "key1": "value1",
            "key2": "value2",
        },
        "test_dict_b": {
            "key3": "value3",
            "key4": "value4",
        },
    }
    def _test_eval(test_case_data):
        """
        Perform unit test for function safe_eval.
        """
        for case_data in test_case_data:
            expr = case_data[0]
            expected = case_data[1]

            ans = safe_eval

# Generated at 2022-06-23 13:23:31.646860
# Unit test for function safe_eval
def test_safe_eval():

    # helper function to test with custom locals
    def test(expr, expected, locals=None):
        locals = {} if locals is None else locals
        result = safe_eval(expr, locals, include_exceptions=False)
        if isinstance(expected, type) and issubclass(expected, Exception):
            assert isinstance(result, expected)
        else:
            if result != expected:
                print('%r != %r' % (result, expected))
                raise Exception('Unexpected expression result')

    # test the basics
    test('"foo"', 'foo')
    test('foo', NameError)
    test('[1,2,3]', [1, 2, 3])
    test('{"foo": "bar"}', dict(foo='bar'))

# Generated at 2022-06-23 13:23:42.321239
# Unit test for function safe_eval
def test_safe_eval():
    # Test where expr is a string
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("['a', 'b', 3, True]") == ['a', 'b', 3, True]
    assert safe_eval("{'foo': 'bar', 'fuz': True}") == {'foo': 'bar', 'fuz': True}
    assert safe_eval("[1,2,3]", include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval("['a', 'b', 3, True]", include_exceptions=True) == (['a', 'b', 3, True], None)

# Generated at 2022-06-23 13:23:51.462971
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] == 2:
        try:
            exec("eval('__import__(\"os\").system(\"echo " + C.DEFAULT_MODULE_COMPAT_SKIP + "\")')")
            raising_syntax_error = True
        except SyntaxError:
            raising_syntax_error = False
    else:
        raising_syntax_error = True

    assert safe_eval("{{ ansible_os_family }} == 'RedHat'", dict(ansible_os_family='RedHat')) is True
    assert safe_eval("{{ ansible_os_family }} == 'RedHat'", dict(ansible_os_family='Debian')) is False

# Generated at 2022-06-23 13:24:01.922765
# Unit test for function safe_eval
def test_safe_eval():
    # Most tests are in template_module_utils, which tests the return values
    # of the templating engine against known safe inputs
    data = [
        ["1+2", 3],
        ["true", True],
        ["[1, 2, 3]", [1, 2, 3]],
        ["{'a': 2}", {'a': 2}],
        ["null", None],
        ["True", True],
        ["False", False],
        ["None", None],
        ["callme()", "callme()"],
        ["bad", "bad"],
        ["0o123", 0o123],
    ]
    for expr, known_result in data:
        eval_result, exception = safe_eval(expr, include_exceptions=True)

# Generated at 2022-06-23 13:24:12.696166
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:20.370028
# Unit test for function safe_eval
def test_safe_eval():
    '''
    >>> safe_eval('1 + 1')
    2
    >>> try: safe_eval('__import__("os").system("rm -rf ~")')
    ... except Exception as e: print(e)
    {1, 6, 7, 8, 11, 12, 13, 14, 15, 17, 19, 20, 21, 23, 24, 25, 26, 27, 31, 32, 33}

    '''
    pass



# Generated at 2022-06-23 13:24:29.456048
# Unit test for function safe_eval
def test_safe_eval():
    expr1 = "True"
    expected_result1 = True

    expr2 = "False"
    expected_result2 = False

    expr3 = "'ansible'"
    expected_result3 = "ansible"

    expr4 = "\"ansible\""
    expected_result4 = "ansible"

    expr5 = "'ansible' if True else 'not_ansible'"
    expected_result5 = "ansible"

    expr6 = "{'ansible': 'awesome'}"
    expected_result6 = {'ansible': 'awesome'}

    expr7 = "{'ansible': 'awesome', 'other': 'other'}"
    expected_result7 = {'ansible': 'awesome', 'other': 'other'}

    expr8 = "['ansible', 'awesome']"
    expected_result8

# Generated at 2022-06-23 13:24:35.377941
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:47.121754
# Unit test for function safe_eval
def test_safe_eval():
    """
    This function is called when this module is run as a script from
    the command line.

    It first creates the unit test cases, then runs them.
    """

    from ansible.module_utils._text import to_native

    # (expr, locals, result)

# Generated at 2022-06-23 13:24:57.800121
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    # this raises an exception when called with a string as the first arg
    boolean('yes')


# Generated at 2022-06-23 13:25:07.899397
# Unit test for function safe_eval
def test_safe_eval():
    results = []

    # Test simple
    tests = [
        # a, b     A, B      expected
        ("1", "1", True),
        ("1", "2", False),
        ("2", "2", True),
    ]
    for (a, b, expected) in tests:
        result = safe_eval("%s == %s" % (a, b))
        results.append(result == expected)

    # Test short circuiting
    #
    # Safe eval should not allow short circuiting like python.  This is a
    # potential security issue if, for example, someone passes in:
    #    "stuff" if 1==2 else "else"
    # or:
    #    "stuff" and debug()

# Generated at 2022-06-23 13:25:14.272342
# Unit test for function safe_eval
def test_safe_eval():
    if not C.DEFAULT_KEEP_REMOTE_FILES:
        return
    global CALL_ENABLED


# Generated at 2022-06-23 13:25:21.740045
# Unit test for function safe_eval
def test_safe_eval():
    # define some variables for the test
    test_error_msg = "invalid expression (%s)"
    a, b, c = 'string', 10, 20.5

    # define whitelist of safe callables
    # CALL_ENABLED.append('list')
    CALL_ENABLED.append('dict')
    CALL_ENABLED.append('tuple')
    CALL_ENABLED.append('len')
    CALL_ENABLED.append('str')
    CALL_ENABLED.append('int')
    CALL_ENABLED.append('float')
    CALL_ENABLED.append('bool')

    # list of tests and expected results

# Generated at 2022-06-23 13:25:32.052708
# Unit test for function safe_eval
def test_safe_eval():
    # TODO: add more tests
    assert safe_eval('{fake_key: fake_value}') == {'fake_key': 'fake_value'}
    assert safe_eval('true') is True
    assert safe_eval('[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval('1 + 1') == 2

    if sys.version_info[0] < 3:
        exceptions = (SyntaxError, NameError)
    else:
        exceptions = (NameError,)


# Generated at 2022-06-23 13:25:41.833666
# Unit test for function safe_eval
def test_safe_eval():
    # some valid use cases
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('1') == 1
    assert safe_eval('foo') == "foo"
    assert safe_eval('1 + foo') == "1 + foo"
    assert safe_eval('foo_bar') == "foo_bar"
    assert safe_eval('foo_bar + 1') == "foo_bar + 1"
    assert safe_eval('1 + foo_bar') == "1 + foo_bar"
    assert safe_eval('foo_bar + foo') == "foo_bar + foo"
    assert safe_eval('foo + foo_bar') == "foo + foo_bar"
    assert safe_eval('foo + 1 + foo_bar') == "foo + 1 + foo_bar"

# Generated at 2022-06-23 13:25:52.335386
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid Python expression
    expr = "1 + 2"
    result = safe_eval(expr)
    assert result == 3

    # Test invalid Python expression
    expr = "1 +"
    try:
        safe_eval(expr)
        success = False
    except Exception:
        success = True
    assert success
    expr = "__import__('sys').exit(0)"
    try:
        safe_eval(expr)
        success = False
    except Exception:
        success = True
    assert success

    expr = "1 + 2"
    result, err = safe_eval(expr, include_exceptions=True)
    assert result == 3
    assert err is None

    # Test invalid Python expression
    expr = "1 +"
    result, err = safe_eval(expr, include_exceptions=True)
   

# Generated at 2022-06-23 13:26:04.950571
# Unit test for function safe_eval
def test_safe_eval():
    # normal cases
    assert safe_eval("1") == 1
    assert safe_eval("[1,2]") == [1, 2]
    assert safe_eval("1 in [1,2]") is True
    assert safe_eval("1 not in [1,2]") is False
    assert safe_eval("True") is True
    assert safe_eval("false") is False
    assert safe_eval("1 in [1]") is True
    assert safe_eval("1 not in [1]") is False
    assert safe_eval("1 in range(2)") is True
    assert safe_eval("1 not in range(2)") is False
    assert safe_eval("1 in range(2)") is True
    assert safe_eval("1 not in range(2)") is False
    assert safe_eval("True") is True

# Generated at 2022-06-23 13:26:12.630519
# Unit test for function safe_eval
def test_safe_eval():

    # Test errors
    result = safe_eval("{{ None }}")
    assert result == "{{ None }}"
    result = safe_eval("{{ foo.bar }}")
    assert result == "{{ foo.bar }}"
    result = safe_eval("{{ 1 + }}")
    assert result == "{{ 1 + }}"
    result = safe_eval("{{ foo() }}")
    assert result == "{{ foo() }}"
    result = safe_eval("{{ foo is bar }}")
    assert result == "{{ foo is bar }}"
    result = safe_eval("{{ foo.bar is baz }}")
    assert result == "{{ foo.bar is baz }}"


# Generated at 2022-06-23 13:26:19.994884
# Unit test for function safe_eval
def test_safe_eval():
    # default, empty environment
    assert safe_eval('foo_bar') == 'foo_bar'
    assert safe_eval('foo_bar', {'foo_bar': False, 'foo': 'bar'}) is False
    assert safe_eval(True) is True
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('1 + 2') == 3
    assert safe_eval('2 - 1') == 1
    assert safe_eval('2 * 2') == 4
    assert safe_eval('2 / 2') == 1
    assert safe_eval('foo') == 'foo'
    assert safe_eval

# Generated at 2022-06-23 13:26:32.249084
# Unit test for function safe_eval
def test_safe_eval():
    tests = (
        ('1', 1),
        ('1 + 1', 2),
        ('True', True),
        ('False', False),
        ('None', None),
        ('1.1 + 1', 2.1),
        ('1.0 + 1', 2.0),
    )

    def _test_safe_eval(expr, expected):
        actual = safe_eval(expr)
        if actual != expected:
            print("safe_eval did not work for '%s', expected=%s, actual=%s" % (expr, expected, actual))

    for test in tests:
        _test_safe_eval(test[0], test[1])
        _test_safe_eval("(%s)" % test[0], test[1])

    failed = False
    # We expect failures for these expressions

# Generated at 2022-06-23 13:26:44.118567
# Unit test for function safe_eval
def test_safe_eval():
    # Test expressions that should be parsed
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a_list[0]', dict(a_list=['first'])) == 'first'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{ "a": 1 }') == {'a': 1}
    assert safe_eval('myvar', dict(myvar=True)) == True
    assert safe_eval('myvar', dict(myvar=False)) == False
    assert safe_eval('myvar', dict(myvar=None)) is None

    # Test expressions that should not be parsed
    assert safe_eval('open') == 'open'
    assert safe_eval('open("foo")') == 'open("foo")'

# Generated at 2022-06-23 13:26:53.203389
# Unit test for function safe_eval
def test_safe_eval():
    results = safe_eval("{{ test }}")
    assert results == "{{ test }}"

    results = safe_eval("{{ test }}", dict(test="foo"))
    assert results == "foo"

    # Verify that ast.Call is properly disallowed
    results = safe_eval("{{ test() }}", dict(test="foo"))
    assert results == "{{ test() }}"

    # Verify that safe_eval pass if function call is allowed
    CALL_ENABLED.append('foo')
    results = safe_eval("{{ test() }}", dict(test="foo"))
    assert results == "foo()"

    # Verify that safe_eval fail if some ast is not permitted
    results = safe_eval("1 + 1")
    assert results == "1 + 1"

    # Verify that safe_eval returns the expression when exception if found
    # and

# Generated at 2022-06-23 13:27:04.249395
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:14.433064
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:24.350469
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:28.963027
# Unit test for function safe_eval
def test_safe_eval():
    # This test is intended to be run with pytest.

    # Passing tests
    # tests based on the syntax whitelist defined in the body of safe_eval
    assert safe_eval("True")
    assert not safe_eval("False")
    assert safe_eval("a['b']['c']")
    assert safe_eval("True and False")
    assert safe_eval("True or False")
    assert safe_eval("a and b")
    assert safe_eval("a or b")
    assert safe_eval("a == b")
    assert safe_eval("a != b")
    assert safe_eval("a <= b")
    assert safe_eval("a >= b")
    assert safe_eval("a < b")
    assert safe_eval("a > b")
    assert safe_eval("a in b")

# Generated at 2022-06-23 13:27:34.025827
# Unit test for function safe_eval
def test_safe_eval():
    # test a simple expression
    assert safe_eval('2 + 3') == 5

    # test local variables
    one = 1
    assert safe_eval('one + one') == 2
    # clean up local variables
    del one

    # test locals dict
    two = 2
    assert safe_eval('a + b', dict(a=1, b=2)) == 3
    # clean up local variables
    del two

    # test invalid expressions
    assert safe_eval('__import__("os").system("echo boom")') == '__import__("os").system("echo boom")'

    # test enabling callables
    safe_eval('max(foo)', dict(foo=[2, 3]), CALL_ENABLED=['max']) == 3

# Generated at 2022-06-23 13:27:43.138823
# Unit test for function safe_eval
def test_safe_eval():
    pass_true = ('"foo"', "'foo'", "12", "12.22", "true", "false", "null", "[1,2,3]", "(1,2,3)", "{1:2,3:4}")
    pass_false = ('a_string_variable', 'a_string_variable.keys()', 'a_string_variable[0]',
                  'a_string_variable[0:3]', 'env.host_specific_var', '{{ a_string_variable }}',
                  '{{ [1,2,3] }}', '{{ {1:2, 3:4} }}')

# Generated at 2022-06-23 13:27:51.917713
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:02.626189
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests of the safe_eval function
    # use this to test if the exceptions are handled properly
    if sys.version_info >= (3, 0):
        evaled = safe_eval("__import__('os').system('/bin/date')")
    else:
        evaled = safe_eval('''__import__('os').system('/bin/date')''')

    assert evaled is None

    evaled = safe_eval("1+1")
    assert evaled == 2

    evaled = safe_eval("1+1", include_exceptions=True)
    assert evaled == (2, None)

    evaled = safe_eval("__import__('os').system('/bin/date')", include_exceptions=True)
    assert evaled == (None, None)


# Generated at 2022-06-23 13:28:15.418253
# Unit test for function safe_eval
def test_safe_eval():
    def _test_basic(expr, output):
        actual = safe_eval(expr)
        assert actual == output, "Expected %s, got %s" % (output, actual)

    def _test_exception(expr):
        try:
            # Just calling safe_eval should not raise an exception
            # when an exception is expected
            actual = safe_eval(expr)
        except Exception as e:
            assert False, "Exception raised even though it wasn't expected.  Not failing, but " \
                          "just letting you know: %s" % (to_native(e),)
        else:
            assert False, "Expected exception, but got '%s' instead" % (actual,)

    # Basic tests
    _test_basic("[1, 2, 3]", [1, 2, 3])
    _test_basic

# Generated at 2022-06-23 13:28:28.884631
# Unit test for function safe_eval
def test_safe_eval():
    # Do some basic tests
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('string') == 'string'
    assert safe_eval('string', include_exceptions=True) == ('string', None)

    # Invalid expressions
    assert safe_eval('__import__("os").system("ls")') == "__import__('os').system('ls')"
    assert safe_eval('open("/etc/passwd")', include_exceptions=True)[0] == 'open("/etc/passwd")'

    # Try a valid/invalid expression in the same string
    assert safe_eval('open("/etc/passwd"); 1 + 1') == 2

# Generated at 2022-06-23 13:28:34.975271
# Unit test for function safe_eval
def test_safe_eval():
    # If any of these tests fail, it should cause the test to error and stop
    # All tests that should succeed are grouped together with a "True" result
    # All tests that should fail are grouped together with a "False" result
    #
    # A comment before each grouping describes what should happen

    # Test single value expressions

    # Test list expressions

    # Test tuple expressions

    # Test set expressions

    # Test dict expressions

    # Test string expressions

    # Test unicode expressions

    # All tests that should fail
    # The following tests are all expected to fail, and we want the test to pass when they do
    # All tests that should fail are grouped together with a "False" result
    failed_tests = [
        # Test invalid python expressions

        # Test function calls

        # Test unsafe functions

        # Test unsafe builtins
    ]


# Generated at 2022-06-23 13:28:44.546525
# Unit test for function safe_eval
def test_safe_eval():
    # Test some safe expressions
    assert(safe_eval('2 + 3') == 5)
    assert(safe_eval('value_to_test in [1, 2, 3]') == True)
    assert(safe_eval('value_to_test not in [4, 5, 6]') == True)
    assert(safe_eval('value_to_test == 7') == False)
    assert(safe_eval('value_to_test == value_to_test_2') == True)
    assert(safe_eval('value_to_test is defined') == True)
    assert(safe_eval('value_to_test is not defined') == False)
    assert(safe_eval('value_to_test is None') == False)
    assert(safe_eval('value_to_test is not None') == True)

# Generated at 2022-06-23 13:28:50.174679
# Unit test for function safe_eval
def test_safe_eval():
    # jinja2 expressions
    results = safe_eval('foo.bar')
    assert results == 'foo.bar', 'failed to leave a string alone'

    # list operators
    results = safe_eval('foo[0]')
    assert results == 'foo[0]', 'failed to leave a string alone'

    # basic literals
    results = safe_eval('2 + 3')
    assert results == 5, 'failed to evaluate a basic expression'

    # basic lists
    results = safe_eval('[1, 2, 3]')
    assert results == [1, 2, 3], 'failed to evaluate a basic list'

    # list comprehension
    results = safe_eval('[x+1 for x in [1, 2, 3]]')
    assert results == [2, 3, 4], 'failed to evaluate a list comprehension'


# Generated at 2022-06-23 13:28:59.200350
# Unit test for function safe_eval
def test_safe_eval():
    # successfull evaluation
    result, exception = safe_eval("[1,2,3]", include_exceptions=True)
    assert result == [1, 2, 3]
    assert exception is None

    result, exception = safe_eval("[1,2,3]", {}, include_exceptions=True)
    assert result == [1, 2, 3]
    assert exception is None

    result, exception = safe_eval("'foo'", include_exceptions=True)
    assert result == 'foo'
    assert exception is None

    result, exception = safe_eval("'foo'", {}, include_exceptions=True)
    assert result == 'foo'
    assert exception is None

    # failed evaluation

    # 1. unsupported AST node type

# Generated at 2022-06-23 13:29:11.639597
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1,"b":2}') == dict(a=1, b=2)
    assert safe_eval('4 + 5') == 9
    assert safe_eval('4 + 5', include_exceptions=True) == (9, None)

    assert safe_eval('[1,2,3] + [4,5,6]') == [1, 2, 3, 4, 5, 6]
    assert safe_eval('{"a":1,"b":2} + {"c":3,"d":4}') == dict(a=1, b=2, c=3, d=4)
    assert safe_eval('5 * 5') == 25

    assert safe_eval('-5 * 5') == -25


# Generated at 2022-06-23 13:29:19.502910
# Unit test for function safe_eval
def test_safe_eval():
    print("=== Testing safe_eval ===")
    assert not safe_eval("{{", include_exceptions=True)[1]
    assert not safe_eval("{{", include_exceptions=True)[1]
    assert not safe_eval("{{")[1]
    assert not safe_eval("{{")[1]
    assert safe_eval("[1,2,3]", include_exceptions=True)[1] is None
    assert safe_eval("[1,2,3]", include_exceptions=True)[1] is None
    assert safe_eval("[1,2,3]") is not None
    assert safe_eval("[1,2,3]") is not None
    assert safe_eval("['a','b']", include_exceptions=True)[1] is None

# Generated at 2022-06-23 13:29:27.796489
# Unit test for function safe_eval
def test_safe_eval():
    # Test literal values
    assert safe_eval("1") == 1
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']

    # Test operators
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 - 1") == 0
    assert safe_eval("1 * 2") == 2
    assert safe_eval("1 / 2") == 0.5
    assert safe_eval("-1") == -1

    # Test booleans
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("foo and bar") == False

# Generated at 2022-06-23 13:29:38.018808
# Unit test for function safe_eval
def test_safe_eval():
    # Multiple expressions should still work
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1') == 2

    # Containers should still work
    assert safe_eval('[1,2,3]', include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # Strings should still work
    assert safe_eval("'1 + 1'", include_exceptions=True)[0] == '1 + 1'
    assert safe_eval("'1 + 1'") == '1 + 1'

    # Expression with quotes and unicode should still work

# Generated at 2022-06-23 13:29:44.153300
# Unit test for function safe_eval
def test_safe_eval():
    from io import StringIO
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    # Create a mock ansible env for tests
    ansible_env = {}
    for key in ['ANSIBLE_NOCOLOR', 'ANSIBLE_FORCE_COLOR']:
        if key in os.environ:
            ansible_env[key] = os.environ[key]

    # Save some state
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    # Create a new sys.stdout and replace it while running tests
    sys.stdout = StringIO()
    sys.stderr = StringIO()

    # Initialize a fake ansible module
    am = AnsibleModule(
        argument_spec={},
    )

   

# Generated at 2022-06-23 13:29:56.118885
# Unit test for function safe_eval
def test_safe_eval():
    # Test list elements
    assert safe_eval("[ [ 1, 2 ], [ 3, 4 ] ]") == [[1, 2], [3, 4]]
    assert safe_eval("[ 1, 2, 3, 4 ]") == [1, 2, 3, 4]

    # Test dict elements
    assert safe_eval("{ 'a': 1, 'b': 2 }") == {'a': 1, 'b': 2}

    # Test list element slicing
    assert safe_eval('"12345"[0:3]') == "123"
    assert safe_eval('"12345"[1:-1]') == "234"
    assert safe_eval('"12345"[1:]') == "2345"
    assert safe_eval('"12345"[:3]') == "123"

# Generated at 2022-06-23 13:30:08.798246
# Unit test for function safe_eval
def test_safe_eval():
    # Empty string
    assert safe_eval('') == ''

    # int
    assert safe_eval('5') == 5
    assert safe_eval('-5') == -5
    assert safe_eval('-10') == -10
    assert safe_eval('-5') == -5

    # float
    assert safe_eval('5.0') == 5.0
    assert safe_eval('-5.0') == -5.0
    assert safe_eval('-10.0') == -10.0
    assert safe_eval('-5.0') == -5.0

    # hex
    assert safe_eval('0x10') == 0x10

    # string
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("'foo'") == "foo"

# Generated at 2022-06-23 13:30:14.252919
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test module for safe_eval
    '''
    expressions = {
        'a and b': "invalid expression",
        '1 + 1': 2,
        'a_list[0]': "invalid expression",
        'a_list.1': "invalid expression",
        'a_dict[key]': "invalid expression",
        'array_var[item]': "invalid expression",
        'dict_var[item]': "invalid expression",
        'array_var[0]': "invalid expression",
        'dict_var["key"]': "invalid expression",
        'null': None,
    }


# Generated at 2022-06-23 13:30:22.892776
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 5
    assert safe_eval('[2 + 3]') == [5]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": ["bar", "baz"]}') == {'foo': ['bar', 'baz']}
    assert safe_eval('{"foo": {"bar": "baz"}}') == {'foo': {'bar': 'baz'}}
    assert safe_eval(
        '{"foo": {"bar": "baz"}, "ping": "pong"}') == {'foo': {'bar': 'baz'}, 'ping': 'pong'}
    assert safe_eval('2 + 3', include_exceptions=True) == (5, None)

# Generated at 2022-06-23 13:30:34.322161
# Unit test for function safe_eval
def test_safe_eval():
    _test_safe_eval({"a": "foo"}, "_a_foo_")
    _test_safe_eval({"a": "foo"}, "{% for a in b %}_{{ a }}_{%endfor%}", {"b": ["1", "2"]})
    _test_safe_eval({"a": "foo"}, "{{ ''.join(a) }}", {"a": ["_", "foo", "_"]})
    _test_safe_eval({"a": "foo"}, "{% for a in b %}_{{ a }}_{%endfor%}", {"b": ("1", "2")})
    _test_safe_eval({"a": "foo"}, "{{ ''.join(a) }}", {"a": ("_", "foo", "_")})

# Generated at 2022-06-23 13:30:45.116750
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval should not accept a call to a built-in function
    test_result = safe_eval('abs(-1)')
    assert test_result == 'abs(-1)'

    # safe_eval should accept a call to a native Python function
    test_result = safe_eval('int(1)')
    assert test_result == 1

    # safe_eval should accept a call to a safe built-in function
    test_result = safe_eval('bool(1)')
    assert test_result == True

    # safe_eval should not accept a call to a built-in function
    # that is not in the safe list
    test_result = safe_eval('bin(-1)')
    assert test_result == 'bin(-1)'

    # safe_eval should not accept invalid syntax

# Generated at 2022-06-23 13:30:55.166347
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('10') == 10
    assert safe_eval('10 * 2') == 20
    assert safe_eval('-10 * 2') == -20
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('None') is None

    assert safe_eval('10 * 2 - 4') == 16
    assert safe_eval('10 * (2 - 4)') == -20

    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo') == 'foo'

    # This should fail

# Generated at 2022-06-23 13:31:06.078782
# Unit test for function safe_eval
def test_safe_eval():
    def assert_eval(expr, expected, locals=None):
        assert expected == safe_eval(expr, locals=locals)

    # test error handling
    assert_eval('1 + 1', '1 + 1')
    assert_eval('az = "foo"', 'az = "foo"')
    assert_eval('a.bcd()', 'a.bcd()')
    assert_eval('[1,2,3,4]', [1, 2, 3, 4])
    assert_eval('{"a": "b"}', {u'a': u'b'})
    assert_eval('True', True)
    assert_eval('False', False)
    assert_eval('None', None)
    assert_eval('1 + 1', 2)
    assert_eval('1 + 1', 2)

# Generated at 2022-06-23 13:31:09.728528
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval by calling it with various input and checking the
    output and exceptions.
    """
    # TODO: implement more tests
    assert safe_eval('[1,2,3]') == [1, 2, 3]



# Generated at 2022-06-23 13:31:21.726247
# Unit test for function safe_eval
def test_safe_eval():
    # test constants
    assert safe_eval("false") == False
    assert safe_eval("none") == None
    assert safe_eval("null") == None
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("null") == None
    assert safe_eval("true") == True

    # test numbers
    assert safe_eval("5") == 5
    assert safe_eval("-5") == -5
    assert safe_eval("5.0") == 5.0
    assert safe_eval("5.5") == 5.5
    assert safe_eval("-5.5") == -5.5

    # test strings
    assert safe_eval("''") == ''
    assert safe_eval(r"'test'") == 'test'

# Generated at 2022-06-23 13:31:27.293032
# Unit test for function safe_eval
def test_safe_eval():

    def _evaluate(expr):
        return safe_eval(expr)

    # basic math, should return an int
    assert _evaluate('1 + 1') == 2

    # this should return a string
    assert _evaluate('1 + 1') == 2 and isinstance(_evaluate('"foo"'), string_types)

    if sys.version_info >= (3, 0):
        # unicode string literal
        assert _evaluate('u"foo"') == 'foo'

    # list of ints
    assert _evaluate('[1, 2, 3]') == [1, 2, 3]

    # list of strings
    assert _evaluate('["foo", "bar", "baz"]') == ['foo', 'bar', 'baz']

    # simple dict

# Generated at 2022-06-23 13:31:38.707878
# Unit test for function safe_eval
def test_safe_eval():

    def raise_exception(msg):
        raise Exception(msg)


# Generated at 2022-06-23 13:31:47.114299
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a") == safe_eval("a")
    assert safe_eval("a") == "a"
    assert safe_eval("a = 1") == "a = 1"
    assert safe_eval("a.b") == "a.b"
    assert safe_eval("[1,2,3,4]") == [1,2,3,4]
    assert safe_eval("[1,2,3,4]", include_exceptions=True)[1] is None
    assert safe_eval("{'a': 1, 'b': 2}", include_exceptions=True)[1] is None
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

# Generated at 2022-06-23 13:31:58.993435
# Unit test for function safe_eval
def test_safe_eval():
    # strings
    assert safe_eval("None") is None
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("0") == 0
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("('foo', 'bar')") == ('foo', 'bar')
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("0+1", include_exceptions=True)[0] == 1
    assert safe_eval("-1+1", include_exceptions=True)[0] == 0

    # Invalid expressions

# Generated at 2022-06-23 13:32:04.754943
# Unit test for function safe_eval
def test_safe_eval():
    # Success cases
    assert safe_eval('1')
    assert safe_eval('1 + 1')
    assert safe_eval('[ 1, 2, 3 ]')
    assert safe_eval('true')
    assert safe_eval('false')
    assert safe_eval('null')
    assert safe_eval('[ 1, 2, 3 ] if true else [ 0 ]')
    assert safe_eval('list(range(3))')
    assert safe_eval('set([1, 2, 3])')
    assert safe_eval('{1, 2, 3}')
    assert safe_eval('(1, 2, 3)')
    assert safe_eval('-1')
    assert safe_eval('-1 * 3')
    assert safe_eval('-1 * -3')
    assert safe_eval('1 * -3')
    assert safe_

# Generated at 2022-06-23 13:32:13.552928
# Unit test for function safe_eval
def test_safe_eval():
    # Unsafe builtins which will be disallowed by the CleansingNodeVisitor
    UNSAFE_BUILTINS = [
        'open', 'file', 'compile', 'execfile', 'reload', '__import__', 'eval'
    ]

    # set of eval() tests we expect to pass

# Generated at 2022-06-23 13:32:22.889593
# Unit test for function safe_eval
def test_safe_eval():
    # Verify with_items is able to be evaluated safely
    with_items_expr = "'foo' in [ 'foo', 'bar' ]"
    with_items_result = safe_eval(with_items_expr, dict())
    assert with_items_result is True

    # Verify {{ 1 == 1 }} is able to be evaluated safely
    basic_expr = "1 == 1"
    basic_result = safe_eval(basic_expr, dict())
    assert basic_result is True

    # Verify {{ 1 == 1 }} is able to be evaluated safely
    basic_expr = "1 == 1"
    basic_result = safe_eval(basic_expr, dict())
    assert basic_result is True

    # Verify {{ 1 == 1 }} is able to be evaluated safely
    basic_expr = "1 == 1"

# Generated at 2022-06-23 13:32:32.714347
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:39.743696
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validate normal behavior for safe_eval function.
    '''

# Generated at 2022-06-23 13:32:47.821349
# Unit test for function safe_eval
def test_safe_eval():
    # fixed bugs
    assert safe_eval('') is None
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []

    assert safe_eval('1 + 3') == 4
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('foo') == 'foo'

    # ensure none of these throw an exception
    safe_eval('_')
    safe_eval('foo.bar')
    safe_eval('1 + 2 * 3')
    safe_eval('(1 + 2) * 3')
    safe_eval('2**3')
    safe_eval('(foo == 1) or (bar == 2)')
    safe_eval('foo.bar == "baz"')
    safe_eval

# Generated at 2022-06-23 13:32:57.652240
# Unit test for function safe_eval
def test_safe_eval():
    '''
    unit test for safe_eval()
    '''
