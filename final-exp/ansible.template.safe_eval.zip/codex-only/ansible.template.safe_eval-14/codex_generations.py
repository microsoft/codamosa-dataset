

# Generated at 2022-06-23 13:23:05.354356
# Unit test for function safe_eval
def test_safe_eval():

    eval_expr = 'a_list_variable'
    expect_result = 'a_list_variable'
    expect_error = None

    result, error = safe_eval(eval_expr, include_exceptions=True)
    assert result == expect_result, "%s != %s" % (result, expect_result)
    assert error == expect_error, "%s != %s" % (error, expect_error)

    # inside_call

    eval_expr = 'my_func()'
    expect_result = 'my_func()'
    expect_error = None

    result, error = safe_eval(eval_expr, include_exceptions=True)
    assert result == expect_result, "%s != %s" % (result, expect_result)

# Generated at 2022-06-23 13:23:13.764208
# Unit test for function safe_eval
def test_safe_eval():
    data_true = [
        "1", "[1]", "{'foo': 'bar'}",
        "1 + 2 + 3", "[1, 2, 3]", "{'foo': 'bar', 'bam': 'boom'}",
    ]
    for expr in data_true:
        result, exc = safe_eval(expr, include_exceptions=True)
        if exc is not None:
            raise Exception("%s: %s" % (expr, exc))
        assert result is not None

    data_false = [
        "__import__", "pwd.getpwall()",
        "__import__('os').popen('ls /').read()",
        "__import__('os').system('ls /')",
    ]
    # all of these calls should raise exceptions

# Generated at 2022-06-23 13:23:23.871879
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This test suite serves as a regression test suite for the function safe_eval().
    It is a mixture of positive and negative tests, and is not intended to be
    comprehensive.

    The tests are organized as a list of 2-tuples, where each tuple consists of
    the expression to be evaluated, and the expected result of evaluating that
    expression.  True and False are represented as actual True and False values.

    The list is ordered to be a mixture of positive and negative tests.
    '''


# Generated at 2022-06-23 13:23:31.838567
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval...")
    my_dict = dict()
    my_dict['name'] = "billy"
    my_dict['age'] = 9
    my_dict['hometown'] = "boston"
    local_vars = dict()
    local_vars['my_dict'] = my_dict
    local_vars['result'] = True

    # test dict lookups

# Generated at 2022-06-23 13:23:42.413329
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    :return: no return value
    '''
    # Ensure that we can evaluate simple expressions
    assert safe_eval('2 + 3') is 5
    assert safe_eval('5 - 2') is 3
    assert safe_eval('12 * 12') is 144
    assert safe_eval('36 / 6') is 6

    # Ensure that we can evaluate expressions involving variables
    assert safe_eval('foo + bar', dict(foo=2, bar=3)) is 5
    assert safe_eval('foo * bar', dict(foo=2, bar=3)) is 6

    # Ensure that we can evaluate simple logical expressions
    assert safe_eval('foo and bar', dict(foo=True, bar=True)) is True

# Generated at 2022-06-23 13:23:54.251409
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('foo') == 'foo'
    assert safe_eval('[1,2,3]') == [1,2,3]

    if sys.version_info[:2] >= (3, 4):
        assert safe_eval('{ "a": 1, "b": 2 }') == { "a": 1, "b": 2 }

    assert safe_eval('False') is False
    assert safe_eval('True') is True

    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None

    assert safe_eval('1==1') is True

    # confirm safe_eval is protecting against arbitrary code execution

# Generated at 2022-06-23 13:24:03.611108
# Unit test for function safe_eval
def test_safe_eval():

    def construct_test(expr, expected_value, expected_exception):
        def do_test(self):
            (value, exception) = safe_eval(expr, include_exceptions=True)
            assert value == expected_value
            assert exception is expected_exception
        return do_test

    # We would normally only let you reference variables in the "locals" namespace
    locals().update(vars(sys.modules[__name__]))
    test_vars = {'test_bool': True,
                 'test_list': ['a', 'b'],
                 'test_dict': {'a': 'b'}}

# Generated at 2022-06-23 13:24:11.874315
# Unit test for function safe_eval
def test_safe_eval():
    # test invalid Jinja2 syntax
    test_str = "{{ foo | bar"
    try:
        safe_eval(test_str)
    except Exception as e:
        result = to_native(e)
    assert 'invalid expression' in result

    # test disallowed function
    test_str = "{{ foo | bool }}"
    try:
        safe_eval(test_str)
    except Exception as e:
        result = to_native(e)
    assert 'invalid function' in result

    # test valid Jinja2 syntax
    test_str = "{{ foo | to_json }}"
    assert safe_eval(test_str, dict(foo=['a', 'b'])) == '["a", "b"]'

    # test valid non-Jinja2 syntax
    test_str = "foo"


# Generated at 2022-06-23 13:24:21.511548
# Unit test for function safe_eval
def test_safe_eval():
    # test for None
    test_none = safe_eval("null")
    assert test_none is None

    # Test for boolean (True)
    test_bool_true = safe_eval("true")
    assert test_bool_true is True

    # Test for boolean (False)
    test_bool_false = safe_eval("false")
    assert test_bool_false is False

    # Test for numbers: int
    test_int = safe_eval("1")
    assert test_int == 1

    # Test for numbers: float
    test_float = safe_eval("1.23")
    assert test_float == 1.23

    # Test for strings
    test_string = safe_eval("'foo'")
    assert test_string == "foo"

    # Test for lists

# Generated at 2022-06-23 13:24:32.375228
# Unit test for function safe_eval
def test_safe_eval():
    # define a whitelist of AST nodes we are going to
    # allow in the evaluation. Any node type other than
    # those listed here will raise an exception in our custom
    # visitor class defined below.
    SAFE_NODES = set(
        (
            ast.Add,
            ast.BinOp,
            ast.Call,
            ast.Compare,
            ast.Constant,
            ast.Dict,
            ast.Div,
            ast.Expression,
            ast.List,
            ast.Load,
            ast.Mult,
            ast.Num,
            ast.Str,
            ast.Sub,
            ast.USub,
            ast.Tuple,
            ast.UnaryOp,
        )
    )


# Generated at 2022-06-23 13:24:41.553532
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:50.387939
# Unit test for function safe_eval

# Generated at 2022-06-23 13:25:00.252881
# Unit test for function safe_eval
def test_safe_eval():
    print("TEST: safe_eval")


# Generated at 2022-06-23 13:25:11.917714
# Unit test for function safe_eval
def test_safe_eval():
    assert 'foo' == safe_eval('"foo"')
    assert 'foo' == safe_eval('foo')
    assert "'foo'" == safe_eval("'foo'")
    assert [1,2,3] == safe_eval("[1,2,3]")
    assert (1,2,3) == safe_eval("(1,2,3)")
    assert 1 == safe_eval("1")
    assert 1.5 == safe_eval("1.5")
    assert 2 == safe_eval("1+1")
    assert 0 == safe_eval("1-1")
    assert 2 == safe_eval("1*2")
    assert 1 == safe_eval("2/2")
    assert False == safe_eval("False")
    assert True == safe_eval("True")
    assert False == safe_eval("false")

# Generated at 2022-06-23 13:25:20.468571
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("123") == 123
    assert safe_eval("1.4") == 1.4
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 * 2') == 2
    assert safe_eval('False') == False
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('a', {'a': 42}) == 42
    #assert safe_eval('add(1, 2

# Generated at 2022-06-23 13:25:30.865943
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended to be used with the nosetests command
    as follows:

    nosetests ansible/utils/unsafe_proxy.py:test_safe_eval

    Do not add other unit tests here.
    '''

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-23 13:25:40.347238
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval
    '''

    expression = '1+1'
    try:
        result = safe_eval(expression)
    except Exception:
        result = None

    assert result == 2, "safe_eval"

    expression = "my_list[item]"
    my_list = [1, 2, 3]
    item = 1
    try:
        result = safe_eval(expression, locals(), include_exceptions=True)
    except Exception:
        result = None

    assert result == (2, None)

    expression = "asd"
    try:
        result = safe_eval(expression, locals(), include_exceptions=True)
    except Exception:
        result = None

    assert result == ('asd', None)

    expression = "asd.keys()"

# Generated at 2022-06-23 13:25:50.718537
# Unit test for function safe_eval
def test_safe_eval():
    # Tests taken from original Stackoverflow link
    assert safe_eval('1 + 3') == 4
    assert safe_eval('1 + 3 * 2') == 7
    assert safe_eval('len("abcd")') == 4
    assert safe_eval('2 ** 3') == 8

    try:
        safe_eval('__import__("os").getcwd()') != C.DEFAULT_LOCAL_TMP
    except Exception:
        pass

    # Additional tests:
    # valid JSON
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    #

# Generated at 2022-06-23 13:26:00.750972
# Unit test for function safe_eval
def test_safe_eval():

    def contains(haystack, needle):
        return needle in haystack

    safe_eval('1+1')
    safe_eval('"foo"')
    safe_eval('[2,3,4]')
    safe_eval('{"a":3}')
    safe_eval('{"a":3}["a"]')
    safe_eval('2 in [2,3,4]')

    # Contains is not safe to run
    try:
        safe_eval('contains("foo", "o")')
        assert False
    except Exception as e:
        pass

    # Use the locals parameter to add contains to the locals
    assert safe_eval('contains("foo", "o")', locals={'contains': contains})

# Generated at 2022-06-23 13:26:10.405198
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure we don't allow any of the things we don't want.
    def assertInvalid(x):
        try:
            safe_eval(x)
            assert False
        except Exception:
            pass

    assertInvalid("__import__('sys').modules")
    assertInvalid("__import__('os').system('ls')")
    assertInvalid("__import__('time').sleep(30)")
    assertInvalid("__import__('subprocess').check_output('ls')")
    assertInvalid("__import__('requests').get('http://www.example.com')")

    # Check that things we do want work.
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
   

# Generated at 2022-06-23 13:26:21.015426
# Unit test for function safe_eval
def test_safe_eval():
    our_test_dict = {'key1': 'val1', 'key2': 'val2'}
    # List of tuples where first item is the code to parse and second item
    # is the expected result

# Generated at 2022-06-23 13:26:33.120960
# Unit test for function safe_eval
def test_safe_eval():
    def assert_eval(expr, result):
        assert safe_eval(expr) == result

    def assert_not_eval(expr):
        try:
            safe_eval(expr)
        except Exception:
            pass  # So long as an exception was thrown, it is good
        else:
            assert False, "Eval allowed an unsafe expression"

    assert_eval("{{ foo }}", "{{ foo }}")
    assert_eval("[1,2,3]", [1,2,3])
    assert_eval("{'foo': 'bar'}", {'foo':'bar'})
    assert_eval("(1,2,3)", (1,2,3))
    assert_eval("7", 7)
    assert_eval("-7", -7)
    assert_eval("1+7", 8)
    assert_

# Generated at 2022-06-23 13:26:40.432388
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval")

# Generated at 2022-06-23 13:26:51.131361
# Unit test for function safe_eval
def test_safe_eval():
    expr = '2 + 3'
    r = safe_eval(expr)
    assert r == 5, 'expresion "%s" yielded %s, expected 5' % (expr, r)

    expr = '{ "a": 1, "b": 2 }'
    r = safe_eval(expr)
    assert r == { 'a': 1, 'b': 2 }, 'expression "%s" yielded %s, expected { "a": 1, "b": 2 }' % (expr, r)

    expr = '1 or 2'
    r = safe_eval(expr)
    assert r == 1, 'expresion "%s" yielded %s, expected 1' % (expr, r)

    expr = 'false'
    r = safe_eval(expr)

# Generated at 2022-06-23 13:27:02.648323
# Unit test for function safe_eval
def test_safe_eval():
    def test(expression, expect, success=True, debug=False):
        global CALL_ENABLED

        # Enable calls to some builtins for this test
        CALL_ENABLED = ['match']

        result, err = safe_eval(expression, include_exceptions=True)
        if result != expect or (success and err is not None):
            if debug:
                print("safe_eval(%s) got %s instead of %s" % (expression, repr(result), repr(expect)))
                print("Got exception: %s" % repr(err))
                #raise
            return False
        return True

    # basic tests
    assert test('1 + 1', 2)
    assert test('1 + 1', 22, success=False)
    assert test('1 + 1', '1 + 1', success=False)

# Generated at 2022-06-23 13:27:13.471006
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic types
    assert(safe_eval('1') == 1)
    assert(safe_eval('"foo"') == "foo")
    assert(safe_eval('[1,2]') == [1, 2])
    assert(safe_eval('{"foo": "bar"}') == {"foo": "bar"})

    # Test safe functions
    assert(safe_eval("min([1,2])") == 1)
    assert(safe_eval("max([1,2])") == 2)
    assert(safe_eval("[1,2][1]") == 2)

    # Test safe math
    assert(safe_eval("1+2") == 3)
    assert(safe_eval("1-2") == -1)
    assert(safe_eval("-1-2") == -3)

# Generated at 2022-06-23 13:27:23.715616
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, locals, should_fail=False):
        result, exc = safe_eval(expr, locals, include_exceptions=True)
        if should_fail:
            assert result == expr
            assert exc is not None
        else:
            assert result == locals['a'] * locals['b']
            assert exc is None
    _test('a * b', {'a': 1, 'b': 2})
    _test('a * b', {'a': 1, 'b': 2, 'c': 3})
    _test('a * b * c', {'a': 1, 'b': 2, 'c': 3}, should_fail=True)
    _test('a * b', {'a': 'hi ', 'b': "there"}, should_fail=True)

# Generated at 2022-06-23 13:27:30.311394
# Unit test for function safe_eval
def test_safe_eval():

    # Boolean, string and int
    assert safe_eval('true') is True
    assert safe_eval('True') is True
    assert safe_eval('false') is False
    assert safe_eval('False') is False
    assert safe_eval('null') is None
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('12345') == 12345
    assert safe_eval('1') == 1

    # Supported punctuation
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

    # Nested list
    assert safe_eval('[[1], [1, 2]]') == [[1], [1, 2]]

    # N

# Generated at 2022-06-23 13:27:39.378033
# Unit test for function safe_eval
def test_safe_eval():

    def pp(result):
        print("*" * 40)
        print("expr: %s" % result[0])
        if result[1] is None:
            print("result: %s" % container_to_text(result[2]))
        else:
            print("exc: %s" % result[1])
        print("*" * 40)

    def test(expr):
        result = safe_eval(expr, include_exceptions=True)
        pp(result)
        return result[0]

    # ALL THESE EXPRESSIONS SHOULD FAIL
    #
    print("\nAll these should fail")

    # expr is None
    assert test("None") == "None"

    # expr is empty string
    assert test("") == ""

    # expr is a simple integer constant

# Generated at 2022-06-23 13:27:47.962430
# Unit test for function safe_eval
def test_safe_eval():
    import datetime

    def _test(expr, expected, locals=None, container_conversion=False):
        result, exception = safe_eval(expr, locals, include_exceptions=True)
        if exception:
            pytest.fail("Failed to evaluate expression")
        if container_conversion:
            result = container_to_text(result)
        assert result == expected

    # basic constants
    _test('1', '1')
    _test('1.1', '1.1')
    _test('True', 'True')
    _test('False', 'False')
    _test('None', '')
    _test('null', '')
    _test('foo', 'foo')

    # binary operations
    _test('1 + 1', '2')
    _test('1 - 1', '0')
    _

# Generated at 2022-06-23 13:27:55.582654
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2]') == [1,2]
    assert safe_eval('[1,"foo",["bar", "baz"]]') == [1,"foo",["bar", "baz"]]
    assert safe_eval('[foo,bar]', dict(foo=1,bar=[2,3])) == [1,[2,3]]
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', dict(foo=42)) == 42
    assert safe_eval('foo.bar', dict(foo=dict(bar=42))) == 42
    assert safe_eval('test', dict(test=[1,2])) == [1,2]
    assert safe_eval('test', dict(test=[1,2])) == [1,2]

# Generated at 2022-06-23 13:28:04.382575
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:16.633511
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr, result, allowed_expr=False):
        if allowed_expr:
            assert safe_eval(expr) == result
        else:
            assert safe_eval(expr) == expr
        if C.DEFAULT_DEBUG and result != expr:
            print('TEST SUCCESS: %s == %s' % (expr, result))

    test('1+2', 3)
    test('[1,2]', [1, 2])
    test('{"a":1}', {'a': 1})
    test('a', 'a')
    test('a', 'a', allowed_expr=True)
    test('a+1', 'a+1')
    test('a*3', 'a*3')
    test('len(a)', 'len(a)')

# Generated at 2022-06-23 13:28:29.839236
# Unit test for function safe_eval
def test_safe_eval():
    def assert_evaluates(expr, value):
        ''' Helper to make a test look cleaner by just passing
            a string and the expression you expect back '''
        result, error = safe_eval(expr, include_exceptions=True)
        if error:
            raise error
        assert result == value

    assert_evaluates("1", 1)
    assert_evaluates("-1", -1)
    assert_evaluates("null", None)
    assert_evaluates("false", False)
    assert_evaluates("true", True)
    assert_evaluates("[]", [])
    assert_evaluates("['a','b','c']", ['a', 'b', 'c'])
    assert_evaluates("[1,2,3]", [1, 2, 3])

# Generated at 2022-06-23 13:28:41.617634
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval()

    Note that this test does not test the blacklisting of potentially
    dangerous functions (eg. popen()).  This could easily be added
    with more tests.

    Also, this test does not test the blacklisting of builtins,
    because exceptions for them are thrown directly from
    CleansingNodeVisitor.
    '''
    # all of these should evaluate to the same thing, three different
    # ways of writing the same data structure with varying levels of
    # nesting and quoting.

# Generated at 2022-06-23 13:28:47.006746
# Unit test for function safe_eval
def test_safe_eval():
    expr = "uname == 'Linux'"
    locals = dict(uname="Linux")
    try:
        value = safe_eval(expr, locals)
        assert value
    except Exception as e:
        sys.exit("safe_eval test failed, exception: %s" % e)


# Generated at 2022-06-23 13:28:56.835113
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True')
    assert safe_eval('true')
    assert not safe_eval('False')
    assert not safe_eval('false')
    assert len(safe_eval('["foo", "bar", "baz"]')) == 3

    # Javascript boolean literals are available
    assert safe_eval('true')
    assert not safe_eval('false')

    # The following should raise an exception, but not with safe_eval()
    assert safe_eval('int(1, 2)')
    assert safe_eval('__import__("sys").exit(1)')
    assert safe_eval('range(1, 2)')
    assert not safe_eval('func()')
    assert safe_eval('True and False')
    assert safe_eval('True or False')
    assert safe_eval('True and False')
    assert safe

# Generated at 2022-06-23 13:29:08.925398
# Unit test for function safe_eval
def test_safe_eval():

    # Only a few callable functions in the whitelist
    # "print" and "len" are excluded.

    # This pass:
    # should_pass = ['1', '1+1', '[1,2,3]', 'a_list_variable', '{"a": 3, "b": 4}', '1 == 1', 'len(a_list_variable)']
    should_pass = ['1', '1+1', '[1,2,3]', 'a_list_variable', '1 == 1']
    for i in should_pass:
        result = safe_eval(i, dict(a_list_variable=[1, 2, 3]))
        print(i, result)
        assert result == eval(i, dict(__builtins__={}, a_list_variable=[1, 2, 3]))

    # This fail

# Generated at 2022-06-23 13:29:21.747287
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit tests for function safe_eval
    """
    assert safe_eval("42+42") == 84
    assert safe_eval("1+2+3+4+5") == 15
    assert safe_eval("3*3") == 9
    assert safe_eval("(1+1)*8") == 16
    assert safe_eval("(foo+foo)*8", { 'foo': 2 }) == 32
    assert safe_eval("2**20") == 1048576
    assert safe_eval("48/2/2") == 6
    assert safe_eval("48//2//2") == 6
    assert safe_eval("[1,'two',3,4]") == [1, 'two', 3, 4]

# Generated at 2022-06-23 13:29:29.483505
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:39.110989
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:48.688145
# Unit test for function safe_eval
def test_safe_eval():
    """
    Retrieve various expressions and test them.
    This is same test as in jinja2, with the exception of
    the {% set %} which is a jinja2 specific construct and
    thus not required here.

    Note: json.loads is used for validation. It is not a
    complete solution as it does not support regex, but
    this is not needed for the eval in question here.

    from jinja2/_compat.py
    """
    from ansible.module_utils.common.text.converters import to_text
    import json

    def test_item(test):
        result, exception = safe_eval(test[0], include_exceptions=True)
        assert(result == json.loads(test[1]))
        assert(exception is None)


# Generated at 2022-06-23 13:29:58.554163
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:09.738001
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test that things that should pass the safe_eval test do, and
    things that should fail do fail.

    :return: True if the test passes
    :raises: AssertionError if the test fails
    '''

    # this should succeed
    eval_result, error = safe_eval('[1,2,3]', include_exceptions=True)
    assert eval_result, '[1,2,3]'
    assert error is None

    # this should fail (SyntaxError)
    eval_result, error = safe_eval('[1,2,3', include_exceptions=True)
    assert error is not None
    assert isinstance(error, SyntaxError), type(error)

    # this should fail (invalid expression)

# Generated at 2022-06-23 13:30:19.173856
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    if sys.version_info < (2, 7):
        assert safe_eval('1+1') == '1+1'
        assert safe_eval('{{ foo }}') == '{{ foo }}'
        assert safe_eval('{{ foo }}', include_exceptions=True) == ('{{ foo }}', None)
        assert safe_eval(['a', 'b', 'c']) == ['a', 'b', 'c']
        assert safe_eval(('a', 'b', 'c')) == ('a', 'b', 'c')
        assert safe_eval('a/b') == 'a/b'
        assert safe_eval('a//b') == 'a//b'
        assert safe_eval('a/**/b') == 'a/**/b'

# Generated at 2022-06-23 13:30:24.724217
# Unit test for function safe_eval
def test_safe_eval():
    # test whether non-string input is passed through
    assert 1 == safe_eval(1)
    # test whether string input is passed through on syntax errors
    assert 'foo-bar' == safe_eval('foo-bar')
    assert 'foo bar' == safe_eval('foo bar')
    # test whether string input is properly evaluated for valid expressions
    assert 1 == safe_eval('1')
    assert 1.25 == safe_eval('1.25')
    assert 'hello' == safe_eval('"hello"')
    assert 'hello world' == safe_eval('"hello" + " " + "world"')
    assert [1, 2, 3] == safe_eval('[1, 2, 3]')
    assert (1, 2, 3) == safe_eval('(1, 2, 3)')

# Generated at 2022-06-23 13:30:35.079204
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1 -- A string with a variable in it
    expr = "{{ foo }}"
    locals = {'foo':'bar'}
    result = safe_eval(expr, locals)
    if result != 'bar':
        raise Exception("Eval 1 failed: %s != 'bar'" % result)

    # Test 2 -- A string with variables in it
    expr = "hello, {{ foo }} is good at {{ bar }}"
    locals = {'foo':'sam', 'bar':'maths'}
    result = safe_eval(expr, locals)
    if result != 'hello, sam is good at maths':
        raise Exception("Eval 2 failed: %s != 'hello, sam is good at maths'" % result)

    # Test 3 -- A list of strings - must be converted to a list

# Generated at 2022-06-23 13:30:45.796919
# Unit test for function safe_eval
def test_safe_eval():
    # enable a few builtin calls
    CALL_ENABLED.append('len')
    CALL_ENABLED.append('true')
    assert safe_eval("len(['a','b','c'])") == 3
    assert safe_eval("true('a','b','c')") == True
    assert safe_eval("-1") == -1
    assert safe_eval("len(['a','b','c'])", include_exceptions=True) == (3, None)
    assert safe_eval("true('a','b','c')", include_exceptions=True) == (True, None)
    assert safe_eval("-1", include_exceptions=True) == (-1, None)

    # disable a builtin we want to explicitly test here
    CALL_ENABLED.remove('len')

# Generated at 2022-06-23 13:30:54.311272
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=too-many-boolean-expressions,invalid-name
    locals = {'foo': 'FOO', 'bar': 3, 'baz': [1, 2, 3], 'quux': {'foo': 'FOO', 'bar': 3}}
    def check(expr, expected):
        ''' helper function to compare expected with actual results '''
        actual = safe_eval(expr, locals=locals)
        if actual != expected:
            print("safe_eval('%s', %s)" % (expr, locals))
            print("  expected: %s" % expected)
            print("  actual  : %s" % actual)

    # test with_items:
    # this is an item from the list, which should get expanded by our safe_eval

# Generated at 2022-06-23 13:31:05.449733
# Unit test for function safe_eval
def test_safe_eval():
    # valid cases
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'foo': 'bar', 'blah': null}") == {'foo': 'bar', 'blah': None}
    assert safe_eval("foo.bar.baz()") == "foo.bar.baz()"
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("3 > 2") is True
    assert safe_eval("3 < 2") is False
    assert safe_eval("3 >= 2") is True
    assert safe_eval("3 != 2") is True
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 - 2") == -1

# Generated at 2022-06-23 13:31:15.922184
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:26.720732
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:38.217953
# Unit test for function safe_eval
def test_safe_eval():
    # basic testing
    assert safe_eval('1 + 1', {}, True) == (2, None)
    assert safe_eval('foo', {'foo': 10}, True) == (10, None)
    assert safe_eval('foo', {'foo': 'bar'}, True) == ('bar', None)
    assert safe_eval('foo + foo', {'foo': 'bar'}, True) == ('barbar', None)

    # containers
    assert safe_eval('foo + foo', {'foo': ['bar', 'baz']}, True) == (['bar', 'baz', 'bar', 'baz'], None)
    assert safe_eval('foo', {'foo': ('bar', 'baz')}, True) == ('bar', None)

# Generated at 2022-06-23 13:31:47.006012
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    variables = {'val1': 0, 'val2': [0, 1, 2], 'val3': True}
    extra_test_cases_syntax_error = ['[1,2,3]', '{"a":1,"b":2,"c":3}', '{"a":1,"b":2,"c":3}', '1==2', '1 < 2', '1 > 2']


# Generated at 2022-06-23 13:31:58.957182
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Safe evaluation test.
    '''

# Generated at 2022-06-23 13:32:09.803110
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo }}", dict(foo=5)) == 5
    assert safe_eval("{{ foo }}", dict(foo="bar")) == "bar"
    assert safe_eval("{{ foo }}", dict(foo=[1, 2, 3])) == [1, 2, 3]
    assert safe_eval("{{ foo }}", dict(foo={"a": 1, "b": 2})) == {"a": 1, "b": 2}
    assert safe_eval("{{ foo }}", dict(foo=True)) == True
    assert safe_eval("{{ foo }}", dict(foo=False)) == False
    assert safe_eval("{{ foo }}", dict(foo=0)) == 0
    assert safe_eval("{{ foo }}", dict(foo=1)) == 1

# Generated at 2022-06-23 13:32:21.066123
# Unit test for function safe_eval
def test_safe_eval():
    # If a string, assume it is an expression and evaluate it
    # If not, return the value unchanged, assume it is already templated
    test_vals = {
        '1,2,3': [1, 2, 3],
        'a_list_variable': 'a_list_variable',
        'False': False,
        'True': True,
        '{{foo}}': '{{foo}}',
        'True and False': False,
        '1 < 2': True,
        '[1,2,3]': [1, 2, 3],
        '{"foo": "bar"}': {"foo": "bar"},
        '"foo"': "foo"
    }
    call_enabled = ['str']


# Generated at 2022-06-23 13:32:31.552801
# Unit test for function safe_eval
def test_safe_eval():
    # all tests are assertTrue, since the purpose of this method
    # is to accept valid expressions and raise an exception
    # on invalid ones

    def _test_good_expr(expr, expected):
        """ helper function to test a valid expression """
        result, exception = safe_eval(expr, include_exceptions=True)
        assert exception is None
        assert result == expected

    def _test_bad_expr(expr, expected_exception=None):
        """ helper function to test an invalid expression """
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result is None
        if expected_exception:
            assert isinstance(exception, expected_exception)

    # type conversions should be in place
    _test_good_expr('1 + 2', 3)

    # test with and without builtins


# Generated at 2022-06-23 13:32:42.550884
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:54.755436
# Unit test for function safe_eval
def test_safe_eval():
    # safe
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 - 1") == 1
    assert safe_eval("6 * 7") == 42
    assert safe_eval("42 / 7") == 6
    assert safe_eval("1 + [1]") == [1, 1]
    assert safe_eval("{'a': 'b'}") == {u'a': u'b'}
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("foo.strip()") == 'foo.strip()'
    assert safe_eval("[1, 2, '3']") == [1, 2, u'3']
    assert safe_eval("'a,b'.split(',')") == [u'a', u'b']