

# Generated at 2022-06-23 13:23:04.409954
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('7') == 7
    assert safe_eval('3 + 5') == 8
    assert safe_eval('7 * 3') == 21
    assert safe_eval('max(3, 5)') == 5
    assert safe_eval('"%s"' % str(u"foo")) == u"foo"
    assert safe_eval('"%s"' % str(u"b\xe9ar")) == u"b\xe9ar"
    assert safe_eval('"%s"' % str(u"b\xe9ar")) == u"b\xe9ar"
    assert safe_eval('"%s"' % str(u"b\xe9ar").encode('utf-8')) == u"b\xe9ar"
    assert safe_eval('False') is False
    assert safe_eval('True') is True


# Generated at 2022-06-23 13:23:13.365951
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import ast
    except ImportError:
        print("SKIP: no ast module")
        sys.exit(0)

    assert safe_eval('True')
    assert not safe_eval('False')
    assert safe_eval('None') is None
    assert safe_eval('False and True') is False
    assert safe_eval('True and True') is True
    assert safe_eval('True or False') is True
    assert safe_eval('False or False') is False
    assert safe_eval('False or True') is True
    assert safe_eval('True or False or True') is True
    assert safe_eval('True and False') is False
    assert safe_eval('True and False and False') is False
    assert safe_eval('False and False') is False
    assert safe_eval('1') == 1
    assert safe_

# Generated at 2022-06-23 13:23:23.533298
# Unit test for function safe_eval
def test_safe_eval():
    PASSED = 0
    FAILED = 0


# Generated at 2022-06-23 13:23:31.652315
# Unit test for function safe_eval
def test_safe_eval():
    # These examples are ok
    assert safe_eval("a_list_variable") == dict(a_list_variable=None)
    assert safe_eval("a_list_variable", dict(a_list_variable=[])) == dict(a_list_variable=[])
    assert safe_eval("a_list_variable", dict(a_list_variable=['foo', 'bar'])) == dict(a_list_variable=['foo', 'bar'])
    assert safe_eval("a_list_variable", dict(a_list_variable=('foo', 'bar'))) == dict(a_list_variable=('foo', 'bar'))
    assert safe_eval("a_list_variable", dict(a_list_variable=set(['foo', 'bar']))) == dict(a_list_variable=set(['foo', 'bar']))

# Generated at 2022-06-23 13:23:42.324000
# Unit test for function safe_eval
def test_safe_eval():

    # this is the whitelist of AST nodes we are going to
    # allow in the evaluation. Any node type other than
    # those listed here will raise an exception in our custom
    # visitor class defined below.
    SAFE_NODES = set(
        (
            ast.Add,
            ast.BinOp,
            # ast.Call,
            ast.Compare,
            ast.Constant,
            ast.Dict,
            ast.Div,
            ast.Expression,
            ast.List,
            ast.Load,
            ast.Mult,
            ast.Num,
            ast.Name,
            ast.Set,
            ast.Str,
            ast.Sub,
            ast.USub,
            ast.Tuple,
            ast.UnaryOp,
        )
    )

    CALL_ENABLED

# Generated at 2022-06-23 13:23:46.689201
# Unit test for function safe_eval
def test_safe_eval():
    # first, basic checks for a few simple expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 5') == 10
    assert safe_eval('"foo" in ["foo", "bar"]') is True
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('dict(foo=1)') == {'foo': 1}

    # now check that all these fail because their AST node type is not in SAFE_NODES

# Generated at 2022-06-23 13:23:50.594158
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, locals=None, include_exceptions=False):
        result =  safe_eval(expr, locals, include_exceptions)
        if include_exceptions:
            (result, exception) = result

# Generated at 2022-06-23 13:23:59.364323
# Unit test for function safe_eval
def test_safe_eval():

    # test with exceptions = None
    # Simple test
    eval_result = safe_eval("[1,2,3]", include_exceptions=True)
    if eval_result[0] == [1,2,3] and eval_result[1] == None:
        print("Simple test passed")
    else:
        print("Simple test failed")

    # Syntax error test
    eval_result = safe_eval("[1,2,3", include_exceptions=True)
    if eval_result[0] == "[1,2,3" and eval_result[1] == None:
        print("Syntax error test passed")
    else:
        print("Syntax error test failed")

    # Test with simple exception

# Generated at 2022-06-23 13:24:10.454440
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar.zing") == "foo.bar.zing"
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1 + foo") == "1 + 1 + foo"
    assert safe_eval("foo.bar + 1") == "foo.bar + 1"

    assert safe_eval("false or true") is True
    assert safe_eval("none or true") is True
    assert safe_eval("false or true or foo") == "false or true or foo"
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-23 13:24:20.111444
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('"foobar"') == "foobar"
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('max(1, 2, 3)') == 3
    assert safe_eval('min(1, 2, 3)') == 1
    assert safe_eval('1 - 2') == -1
    assert safe_eval('1 - - 2') == 3

    # Test invalid exprs
    # assert safe_eval('1 + 2 +') == ast.parse('1 + 2 +',

# Generated at 2022-06-23 13:24:30.711491
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("3 + 4") == 7
    assert safe_eval("foo") == 'foo'
    assert safe_eval("! foo") == '! foo'

    assert safe_eval("{'a': '1'}") == {'a': '1'}
    assert safe_eval("['a', '1']") == ['a', '1']
    assert safe_eval("('a', '1')") == ('a', '1')
    assert safe_eval("{'a': '1'}") == {'a': '1'}
    assert safe_eval("['a', '1']") == ['a', '1']
    assert safe_eval("('a', '1')") == ('a', '1')


# Generated at 2022-06-23 13:24:40.266657
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    if sys.version_info < (2, 7):
        raise Exception("Python 2.6 does not have a working safe_eval function for our needs, so this is not a safe test")

    # empty list
    assert safe_eval('[]') == []
    # one item list
    assert safe_eval('[1]') == [1]
    # multiple item list
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    # simple dictionary
    assert safe_eval('{"a": 1}') == {"a": 1}
    # two item dictionary
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    # multiple item dictionary

# Generated at 2022-06-23 13:24:49.430956
# Unit test for function safe_eval
def test_safe_eval():
    # Calls to name/id that aren't builtin functions, should work.
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo["bar"]') == 'foo["bar"]'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo["bar"]()') == 'foo["bar"]()'
    safe_eval('foo()') == 'foo()'

    # Simple operations, should work
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"a string"') == "a string"
    assert safe_eval('[1,2]') == [1, 2]

# Generated at 2022-06-23 13:24:59.568060
# Unit test for function safe_eval
def test_safe_eval():

    # NOTE: These tests could be written in a more generic way, but this would
    # be more difficult to read.
    # NOTE: These tests can be run with `python -m ansible.module_utils.common.text.evaluate test_safe_eval`

    # Test a safe expression.
    expr = "first_item if a and b or c"
    result, exception = safe_eval(expr, locals={'a': True, 'b': True, 'c': False, 'first_item': 1, 'second_item': 2}, include_exceptions=True)
    assert 1 == result
    assert exception is None

    # Test an unsafe expression.
    expr = "first_item if a and b or __import__('os')"

# Generated at 2022-06-23 13:25:10.506085
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure that safe_eval is working
    def _test_safe_eval(expr, expected_result):
        result, exception = safe_eval(expr, include_exceptions=True)
        if exception:
            raise Exception("error evaluating safe expression '%s': %s" % (expr, exception))
        if result != expected_result:
            raise AssertionError("safe_eval error for '%s': expected '%s' got '%s'" % (expr, expected_result, result))

    # simple expressions
    _test_safe_eval("1 + 2", 3)
    _test_safe_eval("'abcd'", 'abcd')
    _test_safe_eval("['a', 'b', 'c']", ['a', 'b', 'c'])

# Generated at 2022-06-23 13:25:19.848222
# Unit test for function safe_eval
def test_safe_eval():
    # Test that basic functionality works
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('a + b', locals=dict(a=1, b=2)) == 3
    # Test that invalid code raises an exception
    try:
        safe_eval('[1, 2, __import__("os").system("echo HACKED")]')
    except Exception:
        pass
    else:
        assert False, "__import__() should not be allowed!"
    # Test that invalid code raises an exception
    try:
        safe_eval('abs(__import__("os").system("echo HACKED"))')
    except Exception:
        pass

# Generated at 2022-06-23 13:25:30.073772
# Unit test for function safe_eval
def test_safe_eval():
    # Substitution in conditional expressions
    assert safe_eval('foo') == 'foo'

    # Numeric expressions
    assert safe_eval('2 * 3') == 6
    assert safe_eval('7 - 9') == -2
    assert safe_eval('-5 - -1') == -4
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('6 / 2') == 3

    # String expressions
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('"foo"*3') == 'foofoofoo'

    # Lists
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[1, "a", "foo"]')

# Generated at 2022-06-23 13:25:39.775957
# Unit test for function safe_eval
def test_safe_eval():

    #########
    # add: 2 + 2 == 4
    #########
    test_expr = '2 + 2'
    print("Testing: %s" % test_expr)
    result = safe_eval(test_expr)
    if result != 4:
        print("ERROR: %s failed!" % test_expr)
        sys.exit(1)

    #########
    # subtract: 2 - 3 == -1
    #########
    test_expr = '2 - 3'
    print("Testing: %s" % test_expr)
    result = safe_eval(test_expr)
    if result != -1:
        print("ERROR: %s failed!" % test_expr)
        sys.exit(1)

    #########
    # multiply: 2 * 2 == 4
    #########

# Generated at 2022-06-23 13:25:50.135106
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("0") == 0
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'a string'") == 'a string'
    assert safe_eval("1 + 1 + 'string'", include_exceptions=True)[1] is not None


# Utility function for returning a string for printingable data structure
# for use in AnsibleModule argument_spec
#
# This will return the data structured in the format:
# repr(type(data_structure_variable))
#
# This is needed so that the formatting of dictionaries and lists are retained
# when passing the default argument_spec to AnsibleModule

# Generated at 2022-06-23 13:26:02.368398
# Unit test for function safe_eval
def test_safe_eval():
    # Creating an error for a condition within safe_eval
    # This testcase is for condition: expression is not a string
    try:
        expr, e = safe_eval(1, include_exceptions=True)
    except Exception as e:
        pass
    assert expr is None
    assert isinstance(e, TypeError)

    # Negative testcase:
    # expression contains invalid function
    try:
        expr, e = safe_eval("a", include_exceptions=True)
    except Exception as e:
        pass
    assert expr is None
    assert isinstance(e, Exception)

    # Negative testcase:
    # expression contains invalid operator
    try:
        expr, e = safe_eval("c | d", include_exceptions=True)
    except Exception as e:
        pass
    assert expr is None

# Generated at 2022-06-23 13:26:11.088570
# Unit test for function safe_eval
def test_safe_eval():

    # Success
    assert safe_eval("1+1") == 2
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo['bar']") == "foo['bar']"
    assert safe_eval("foo['bar'][0]") == "foo['bar'][0]"
    assert safe_eval("foo['bar'][0].baz") == "foo['bar'][0].baz"
    assert safe_eval("foo.bar[0]") == "foo.bar[0]"
    assert safe_eval("foo.bar['baz']") == "foo.bar['baz']"
    assert safe_eval("foo.bar.baz") == "foo.bar.baz"
    # Failure
    assert safe_eval("foo.bar()") == "foo.bar()"


# Generated at 2022-06-23 13:26:21.758273
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe strings in safe_eval
    assert safe_eval("name0") == "name0"
    assert safe_eval("name0 + name1") == "name0 + name1"
    assert safe_eval("name0 * 3") == "name0 * 3"
    assert safe_eval("name0 and name1") == "name0 and name1"
    assert safe_eval("name0 or name1") == "name0 or name1"
    assert safe_eval("name0 in name1") == "name0 in name1"
    assert safe_eval("'name0' in 'name1'") == "'name0' in 'name1'"
    assert safe_eval("name0[name1]") == "name0[name1]"
    assert safe_eval("name0[:3]") == "name0[:3]"


# Generated at 2022-06-23 13:26:33.766786
# Unit test for function safe_eval
def test_safe_eval():
    # use the builtin 'max' function to validate that regular calls work
    safe_eval('max(1, 2)')
    safe_eval('max(a, b)', {'a': 1, 'b': 2})

    # test our whitelisted python expressions against safe_eval
    safe_eval('1 + 1')
    safe_eval('0123')
    safe_eval('[1, 2, 3]')
    safe_eval('{"k1": "v1", "k2": "v2"}')
    safe_eval('(1, 2, 3)')
    safe_eval('-1')
    safe_eval('[]')
    safe_eval('{}')
    safe_eval('()')
    safe_eval('1')
    safe_eval('True')
    safe_eval('False')
    safe_

# Generated at 2022-06-23 13:26:46.159397
# Unit test for function safe_eval
def test_safe_eval():
    """Trivial test of safe_eval"""
    test_eval_correct = {
        '0': 0,
        '1': 1,
        '1 + 1': 2,
        'a_variable + 1': None,
        '[1, 2]': [1, 2],
        '(1, 2)': (1, 2),
        '{a: 1, b: 2}': {'a': 1, 'b': 2},
        'a_list_variable': None,
        'a_dict_variable': None,
    }

    test_eval_error = {
        'a_variable + a_dict_variable': "invalid expression",
        'a_variable + a_dict_variable': "invalid expression (a_variable + a_dict_variable)",
    }


# Generated at 2022-06-23 13:26:54.274123
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 and 2') == 2
    assert safe_eval('"a" and "b"') == 'b'
    assert safe_eval('"a" or "b"') == 'a'
    assert safe_eval('1 or 0') == 1
    assert safe_eval('1 or 2') == 1
    assert safe_eval('not 1') == False
    assert safe_eval('not None') == True
    assert safe_eval('not 0') == True
    assert safe_eval('not "a"') == False
    assert safe_eval('"b" or not ""') == 'b'
    assert safe_eval('"a" in "abc"') == True
    assert safe_eval('"d" in "abc"') == False

# Generated at 2022-06-23 13:27:02.991008
# Unit test for function safe_eval
def test_safe_eval():

    # requires Python 2.6+
    if sys.version_info[:2] < (2, 6):
        print("SKIPPING safe_eval unit test, which requires Python 2.6+")
        return

    def expect_pass(expr):
        try:
            result = safe_eval(expr)
            if not isinstance(expr, string_types):
                assert result == expr
            else:
                assert result is not None
        except Exception as e:
            print("Exception in expect_pass for %s: %s" % (expr, to_native(e)))
            raise


# Generated at 2022-06-23 13:27:11.254998
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval with CALL_ENABLED")
    # Test with CALL_ENABLED
    CALL_ENABLED.append("object")
    CALL_ENABLED.append("str")
    expected = "abc"
    e = safe_eval("str('abc')")
    if e != expected:
        print("safe_eval str failed: %s != %s" % (e, expected))
        sys.exit(1)

    expected = False
    e = safe_eval("isinstance(str('abc'), object)")
    if e != expected:
        print("safe_eval isinstance failed: %s != %s" % (e, expected))
        sys.exit(1)

    CALL_ENABLED.remove("object")
    CALL_ENABLED.remove("str")


# Generated at 2022-06-23 13:27:18.365536
# Unit test for function safe_eval
def test_safe_eval():

    expr = "{{ a + b }}"
    expr_result = safe_eval(expr, dict(a=1, b=2), include_exceptions=True)
    # expr_result should be (3, None)
    assert expr_result[0] == 3
    assert expr_result[1] is None

    expr = "{% raw %}{{ a + b }}{% endraw %}"
    expr_result = safe_eval(expr, dict(a=1, b=2), include_exceptions=True)
    # expr_result should be ('{{ a + b }}', None)
    assert expr_result[0] == '{{ a + b }}'
    assert expr_result[1] is None

    expr = "{% raw %}{{ a + b }}{% endraw %}{{ a + b }}"
    expr_result

# Generated at 2022-06-23 13:27:26.471016
# Unit test for function safe_eval

# Generated at 2022-06-23 13:27:36.571573
# Unit test for function safe_eval
def test_safe_eval():
    # test list
    expr = "[1,2,3]"
    assert safe_eval(expr) == [1, 2, 3]

    # test dict
    expr = "{a: 1, b: 2}"
    assert safe_eval(expr) == {'a': 1, 'b': 2}

    # test string
    expr = "\"hello\""
    assert safe_eval(expr) == "hello"

    # test int
    expr = "2"
    assert safe_eval(expr) == 2

    # basic py evaluation
    expr = "3 * 4"
    assert safe_eval(expr) == 12

    # test with_items type
    expr = "[1,2,3]"
    assert safe_eval(expr) == [1, 2, 3]

    # hmmm
    expr = "vars"

# Generated at 2022-06-23 13:27:47.272459
# Unit test for function safe_eval
def test_safe_eval():
    def run_test(expr, result):
        res, err = safe_eval(expr, include_exceptions=True)
        if err:
            raise AssertionError('Error evaluating expression: %s' % expr)
        assert res == result, "Expected: %s, got %s for expression '%s'" % (result, res, expr)
        # ensure that the non-include_exceptions version works
        assert safe_eval(expr) == result, "Expected: %s, got %s for expression '%s'" % (result, res, expr)

    # test known good things

# Generated at 2022-06-23 13:27:59.099636
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:08.007536
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('"foo" in [ "fizz", "buzz" ]') is False
    assert safe_eval('"foo" in [ "fizz", "buzz", "foo" ]') is True
    assert safe_eval('"foo" in mylist', dict(mylist=[ "fizz", "buzz", "foo" ])) is True
    assert safe_eval('"foo" in mylist', dict(mylist=None)) is False
    assert safe_eval('"foo" in mylist', dict(mylist=1)) is False
    assert safe_eval('"foo" in mylist', dict(mylist=[])) is False
    assert safe_eval('"foo" in mylist', dict(mylist=["foo"])) is True

# Generated at 2022-06-23 13:28:14.602345
# Unit test for function safe_eval

# Generated at 2022-06-23 13:28:19.096755
# Unit test for function safe_eval
def test_safe_eval():
    my_dict = {'a': 1, 'b': 2, 'c': 3}
    my_list = [1, 2, 3]
    my_tuple = (2, 3, 4)
    my_str = "foo"
    my_int = 15
    my_float = 15.5
    my_foo_str = "'foobar'"
    my_true_str = "'true'"
    my_false_str = "'false'"
    my_none_str = "'null'"
    my_eq = "a == b"
    my_ge = "a >= b"
    my_le = "a <= b"
    my_lt = "a < b"
    my_gt = "a > b"
    my_ne = "a != b"
    my_in = "a in b"
    my_

# Generated at 2022-06-23 13:28:30.743147
# Unit test for function safe_eval
def test_safe_eval():
    # Test with no exceptions
    assert safe_eval('{{ foo }}') == '{{ foo }}'
    assert safe_eval('"{{ foo }}"') == '{{ foo }}'
    assert safe_eval('[ [ foo, bar ], baz ]') == [['foo', 'bar'], 'baz']
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo[bar]') == 'foo[bar]'
    assert safe_eval('foo[1:2]') == 'foo[1:2]'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('"{{ foo }}".split()') == '{{ foo }}.split()'
    assert safe_eval('foo == bar') == 'foo == bar'

# Generated at 2022-06-23 13:28:42.308898
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import string_to_bool

    def validate_type(result, expected_type):
        if isinstance(result, expected_type):
            return True
        else:
            raise AssertionError("test_safe_eval: Value of type %s, expected %s." % (type(result), expected_type))

    def validate(result, expected):
        if isinstance(result, dict):
            if isinstance(expected, dict):
                assert result == expected
                return True
        elif isinstance(result, list):
            if isinstance(expected, list):
                assert result == expected
                return True

# Generated at 2022-06-23 13:28:53.419417
# Unit test for function safe_eval
def test_safe_eval():
    '''
    load a bunch of expressions in the "safe" whitelist and make sure they
    execute fine.

    Also load some non-safe expressions and make sure they result in an
    exception
    '''
    # safe expressions

# Generated at 2022-06-23 13:29:00.645582
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test function safe_eval
    """
    assert safe_eval('"foobar"') == "foobar"
    assert safe_eval('1+2') == 3
    assert safe_eval('true and false') == False
    assert safe_eval('true or false') == True
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('foo') == 'foo'
    assert safe_eval('5.5') == 5.5
    assert safe_eval('5.5+5.5') == 11.0

    try:
        safe_eval('__import__("os").getcwd()')
        print("shoud not get here")
        assert False
    except Exception as e:
        # Expected to fail, as we disabled importing modules
        pass


# Generated at 2022-06-23 13:29:08.591255
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar.baz") == "foo.bar.baz"
    assert safe_eval("foo.bar.baz()") == "foo.bar.baz()"

    assert isinstance(safe_eval('[1,2,3]'), list)
    assert isinstance(safe_eval('{"foo":"bar"}'), dict)

    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo":"bar"}') == {'foo': 'bar'}

    assert safe_eval('[1,2,3]') == safe_eval('[1,2,3]')
    assert safe_eval('{"foo":"bar"}') == safe_eval('{"foo":"bar"}')

# Generated at 2022-06-23 13:29:21.660735
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'ansible_distribution_version.split(".")'
    result = safe_eval(expr)
    assert callable(result)

    expr = '"string with spaces"'
    result = safe_eval(expr)
    assert result == 'string with spaces'

    expr = 'dict(some_list)'
    result = safe_eval(expr)
    assert callable(result)

    # Test with safe_eval disabled
    C.DEFAULT_SAFE_EVAL_DISABLED = True
    result = safe_eval(expr)
    assert result == expr

    expr = 'ansible_distribution_version.split(".")'
    result = safe_eval(expr)
    assert result == expr

    # Test with safe_eval enabled
    C.DEFAULT_SAFE_EVAL_DISABLED = False
    result

# Generated at 2022-06-23 13:29:29.404441
# Unit test for function safe_eval
def test_safe_eval():
    # Success
    assert safe_eval("foo") == "foo"
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("a", dict(a='bar')) == 'bar'
    assert safe_eval("len", dict(len=len)) == len

    # If a user defines a function 'len' should they be allowed to use it?
    # assert safe_eval("len(foo)", dict(foo='bar', len=len)) == 3

    # Should work with kwargs too
    assert safe_eval("foo", dict(foo='bar'), include_exceptions=True)[0] == "bar"

    # Should not allow calling functions that have not been vetted.
    # assert safe_eval("str(foo)",

# Generated at 2022-06-23 13:29:39.039710
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:48.547920
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:58.468264
# Unit test for function safe_eval
def test_safe_eval():
    # An innocuous expression to start with
    result, e = safe_eval("a_list_variable", {'a_list_variable': [1, 2, 3]}, True)
    assert isinstance(result, list)
    assert e is None

    # fail if safe_eval encounters a dangerous callable
    result, e = safe_eval("__import__('os').system('echo hi there')", locals={}, include_exceptions=True)
    assert isinstance(result, str)
    assert e is not None

    # Strings should be returned as-is to support late evaluation
    result, e = safe_eval('something', {}, True)
    assert isinstance(result, str)
    assert e is None

    # Already templated to a datastructure, perhaps?

# Generated at 2022-06-23 13:30:09.710673
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:20.959526
# Unit test for function safe_eval
def test_safe_eval():
    foo = "foo"
    bar = "bar"
    baz = "baz"

# Generated at 2022-06-23 13:30:33.563170
# Unit test for function safe_eval
def test_safe_eval():
    def assert_raise_invalid_expr(expr, locals=None):
        try:
            safe_eval(expr, locals=locals)
            assert False, 'invalid expression (%s) did not raise exception' % expr
        except Exception:
            pass

    def assert_safe_eval(expr, expected_result, locals=None):
        result, e = safe_eval(expr, locals=locals, include_exceptions=True)
        assert e is None, 'unexpected exception for expression (%s): %s' % (expr, e)
        assert result == expected_result, 'expected (%s) != result (%s)' % (expected_result, result)

    assert_raise_invalid_expr('[1] + 2')
    assert_raise_invalid_expr('[1] + [2]')
    assert_raise_in

# Generated at 2022-06-23 13:30:40.771252
# Unit test for function safe_eval
def test_safe_eval():
    # if we get a string back, it wasn't able to parse it
    if safe_eval("[1,2]") == "[1,2]":
        raise Exception("failed")
    if safe_eval("{'a': 'b'}") == "{'a': 'b'}":
        raise Exception("failed")
    if safe_eval("[1,2]", include_exceptions=True)[0] != [1, 2]:
        raise Exception("failed")
    if safe_eval("[1,2]", include_exceptions=True)[1]:
        raise Exception("failed")
    if safe_eval("[1,2,3+4]", include_exceptions=True)[0] != [1, 2, 7]:
        raise Exception("failed")

# Generated at 2022-06-23 13:30:51.904059
# Unit test for function safe_eval
def test_safe_eval():
    def _test_assert_exception(result, value):
        if isinstance(result, tuple):
            assert result[0] == value
            assert isinstance(result[1], Exception)
            assert not isinstance(result[1], SyntaxError)
        else:
            assert result == value

    _test_assert_exception(safe_eval("[1,2,3,{{ a_list_variable }},5]",
                                     dict(a_list_variable=[4]),
                                     include_exceptions=True), [1, 2, 3, 4, 5])

# Generated at 2022-06-23 13:31:03.625787
# Unit test for function safe_eval
def test_safe_eval():
    # Test good input
    test_inputs = [
        ('1+1', 2),
        ('1+1', 2),
       ('(1,2,3)', (1, 2, 3)),
        ('[1, "two", 3]', [1, "two", 3]),
        ('{1: "one", "2": 3}', {1: "one", "2": 3}),
        ('{"a": "b"}', {"a": "b"})
    ]
    for expr, expected in test_inputs:
        assert(safe_eval(expr) == expected)
    # Test bad input

# Generated at 2022-06-23 13:31:12.332477
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import common
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text.converters import to_text

    def _test_safe_eval(expr, result=None, exception=None):
        (res, ex) = safe_eval(to_text(expr), include_exceptions=True)
        if result is not None:
            assert (res == result)
        if exception is not None:
            assert (ex is not None)
            assert (to_native(ex.args[0]).endswith(to_native(exception)))
        else:
            assert (ex is None)

    # Test expressions that should work

# Generated at 2022-06-23 13:31:17.273296
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval.
    '''

# Generated at 2022-06-23 13:31:22.586242
# Unit test for function safe_eval
def test_safe_eval():
    test_dict = {'foo': 'bar', 'a_list': ['item1', 'item2'], 'an_integer': 1, 'a_float': 2.0}

    assert safe_eval('foo', test_dict) == 'bar'
    assert safe_eval('a_list', test_dict) == ['item1', 'item2']
    assert safe_eval('an_integer', test_dict) == 1
    assert safe_eval('a_float', test_dict) == 2.0

    # dicts with non-string keys are not valid
    # this should return the original expression
    assert safe_eval('a_dict', test_dict) == 'a_dict'

    if sys.version_info >= (2, 7, 9):
        # dicts with non-string keys would be valid in Python 3
        assert safe_

# Generated at 2022-06-23 13:31:27.887088
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.errors import AnsibleError

    class TestVarsModule:
        def __init__(self):
            self.params = {
                'hostvars': {
                    'host1': {
                        'name': 'host1',
                        'var1': {
                            'key': 'value'
                            },
                        'var2': 'value'
                        },
                    'host2': {
                        'name': 'host2',
                        'var1': {
                            'key': 'value'
                            },
                        'var2': 'value'
                        }
                    }
                }

    module = TestVarsModule()

    evald_val = safe_eval("hostvars.host2.var1.key")
    assert evald_val == 'value'

    # Verify that boolean values are parsed properly
   

# Generated at 2022-06-23 13:31:39.387859
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:47.795731
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    import sys
    import types
    import textwrap
    from ansible.module_utils.common.text.converters import container_to_text, to_native

    def _create_code(code_string):
        # Provides a way to get the compiled version of a code object
        # so we can see what AST node types are actually being used.
        return compile(textwrap.dedent(code_string), '<string>', 'exec')

    def _get_ast_dict(code_object):
        # Returns a dictionary of the AST nodes and their types
        # (as strings) in the specified code object.
        ast_dict = {}
        ast.node_classes = {} # Necessary to avoid a warning in 2.6.5.

# Generated at 2022-06-23 13:31:59.028446
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure that legitimate expressions are allowed
    assert safe_eval(u"1 + 1") == 2
    assert safe_eval(u"2 * 3") == 6
    assert safe_eval(u"'abc'") == 'abc'
    assert safe_eval(u"len([1, 2, 3])") == 3
    assert safe_eval(u"[1, 2, 3]") == [1, 2, 3]
    assert safe_eval(u"{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

    # Ensure that dangerous built-in functions are not allowed

# Generated at 2022-06-23 13:32:09.880353
# Unit test for function safe_eval
def test_safe_eval():
    # Smoke test
    safe_eval('1+1')
    # Verify that only allowed AST nodes are allowed
    safe_eval('[1,2,3,4]')
    safe_eval('{"foo":42}')
    safe_eval('abs(-1)')
    # Verify that calls to builtins are safe
    safe_eval("len([1,2,3])")
    # Verify that only certain builtins are safe
    safe_eval("eval('1+1')", include_exceptions=True)[1]
    # Verify that only certain builtins are safe
    safe_eval("__import__('os').system('echo hi')", include_exceptions=True)[1]
    # Verify that only certain builtins are safe
    safe_eval("__import__('os').remove('/tmp/foo')")

# Generated at 2022-06-23 13:32:21.102753
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run unit tests against function safe_eval, using the eval-tests.yml test
    cases which are embedded in the source code.
    '''
    import os
    import pprint
    import yaml
    from ansible.module_utils import basic

    filename = os.path.join(os.path.dirname(__file__), 'eval-tests.yml')
    with open(filename) as f:
        data = yaml.safe_load(f.read())
    try:
        import json
        json.dumps(data, indent=4)
    except:
        sys.exit("Failed to parse %s: %s" % (filename, data))

    for test in data:
        if not test.get('enabled', True):
            continue

# Generated at 2022-06-23 13:32:31.592728
# Unit test for function safe_eval
def test_safe_eval():

    # if the call to safe_eval raises an exception, this will fail
    safe_eval('dict()')
    safe_eval('list()')
    safe_eval('tuple()')
    safe_eval('set()')
    safe_eval('{"foo": "bar"}')
    safe_eval('["bar", "baz"]')
    safe_eval('("bar", "baz")')
    safe_eval('{"name": "john", "last": "doe"}')
    safe_eval('["name", "john", "last", "doe"]')
    safe_eval('("name", "john", "last", "doe")')
    safe_eval('dict(name="john", last="doe")')
    safe_eval('list(name="john", last="doe")')

# Generated at 2022-06-23 13:32:42.590759
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:49.976133
# Unit test for function safe_eval
def test_safe_eval():
    # Test constants
    assert safe_eval('true') is True
    assert safe_eval('True') is True
    assert safe_eval('false') is False
    assert safe_eval('False') is False
    assert safe_eval('null') is None
    assert safe_eval('null') is None

    # Test strings
    assert safe_eval('"test"') == 'test'
    assert safe_eval('"{0}"'.format('test')) == 'test'
    assert safe_eval('"test {0}"'.format('string')) == 'test string'
    assert safe_eval('u"test"') == u'test'
    assert safe_eval('u"{0}"'.format('test')) == u'test'
    assert safe_eval('u"test {0}"'.format('string')) == u'test string'

# Generated at 2022-06-23 13:32:59.326475
# Unit test for function safe_eval
def test_safe_eval():
    # Check that a single string is passed through unmodified
    assert safe_eval("foo") == 'foo'
    # Empty string should be passed through
    assert safe_eval("") == ''
    # Check that integers are passed through
    assert safe_eval(42) == 42
    # Check that a list is passed through
    assert safe_eval([1,2,3]) == [1,2,3]

    # Check that a dict is passed through
    assert safe_eval({'a':1, 'b':2}) == {'a':1, 'b':2}
    # Check that an expression is evaluated
    assert safe_eval("1 + 2") == 3
    # Check that a dict with an expression is evaluated