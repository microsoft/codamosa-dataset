

# Generated at 2022-06-23 13:22:56.876242
# Unit test for function safe_eval
def test_safe_eval():
    failed = False
    # Ensure we can handle an empty string
    if safe_eval('') != '':
        failed = True
        print("safe_eval() test failed on empty string")
    # Ensure we can handle a list comprehension
    if safe_eval('[x for x in foo]') != '[x for x in foo]':
        failed = True
        print("safe_eval() test failed on list comprehension")
    # Test with a number
    if safe_eval('5') != 5:
        failed = True
        print("safe_eval() test failed on number")
    # Test with a bool
    if safe_eval('False') != False:
        failed = True
        print("safe_eval() test failed on number")
    # Test with a null
    if safe_eval('null') != None:
        failed = True
        print

# Generated at 2022-06-23 13:23:08.808333
# Unit test for function safe_eval
def test_safe_eval():
    # Test for safe_eval
    from ansible.module_utils.common.text.converters import to_unicode

    ret = None

# Generated at 2022-06-23 13:23:19.070557
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:29.692511
# Unit test for function safe_eval
def test_safe_eval():
    # 1. Test basic arithmetic, boolean and comparison operations
    expr = "1 + 2 * 3 - (4 / 3) * 4 + 5 * sqrt(9) * ((9) and True)"
    assert safe_eval(expr) == eval(expr)
    expr = "1 + 2 * 3 - (4 / 3) * 4 + 5 * pow(3, 2) * ((9) and True)"
    assert safe_eval(expr) == eval(expr)
    expr = "1 + 2 * 3 - (4 / 3) * 4 + 5 * 3 ** 2 * ((9) and True)"
    assert safe_eval(expr) == eval(expr)
    expr = "1 + 2 * 3 - (4 / 3) * 4 + 5 * 3 ** 2 * ((9) and True) == 42"

# Generated at 2022-06-23 13:23:37.702133
# Unit test for function safe_eval

# Generated at 2022-06-23 13:23:42.540266
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'true'
    assert safe_eval(expr) is True

    expr = 'null'
    assert safe_eval(expr) is None

    expr = 'false'
    assert safe_eval(expr) is False

    expr = 'test'
    assert safe_eval(expr) == 'test'

    expr = 'false or true'
    assert safe_eval(expr) is True

    expr = '1 == 1 and true'
    assert safe_eval(expr) is True

    expr = '(1 == 1) and (1 == 2)'
    assert safe_eval(expr) is False

    expr = '1 + 1'
    assert safe_eval(expr) == 2

    expr = '2 * 3'
    assert safe_eval(expr) == 6

    expr = '(1, 2)'
    assert safe_eval(expr)

# Generated at 2022-06-23 13:23:54.252171
# Unit test for function safe_eval
def test_safe_eval():
    """ Unit test for safe_eval """
    CLEAN_TESTS = dict(
        empty_list=[],
        some_strings=[],
        some_ints=[],
        empty_dict={},
        empty_dict_with_spaces={},
        dict_with_some_vars={},
        dict_with_some_vars_and_functions={},
        dict_with_nested_dict_and_list={},
    )


# Generated at 2022-06-23 13:24:01.388795
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test cases for method safe_eval
    '''
    from ansible.module_utils.common._collections_compat import Mapping

    # Test safe_eval with different types
    assert safe_eval('foo') == 'foo'
    assert safe_eval(u'foo') == u'foo'
    assert safe_eval(u'foo', include_exceptions=True) == (u'foo', None)
    assert safe_eval('42') == 42
    assert safe_eval('42', include_exceptions=True) == (42, None)
    assert safe_eval('True') is True
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('False') is False

# Generated at 2022-06-23 13:24:12.073455
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("[1,2]") == [1, 2]
    assert safe_eval("1 + {'a': 'b', 'c': 'd'}", include_exceptions=True)[0] == \
        (2, {'a': 'b', 'c': 'd'})
    assert safe_eval("{'a': 'b', 'c': 'd'} + 1", include_exceptions=True)[0] == \
        ({'a': 'b', 'c': 'd'}, 1)

# Generated at 2022-06-23 13:24:18.406612
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ 1 }}") == "{{ 1 }}"
    assert safe_eval("{{ 'foo' }}") == "{{ 'foo' }}"
    assert safe_eval("{{ 'foo' }}", include_exceptions=True)[0] == "{{ 'foo' }}"
    assert safe_eval("{{ foo }}", include_exceptions=True)[0] == "{{ foo }}"
    assert safe_eval("{{ [1, 2, 3] }}") == "{{ [1, 2, 3] }}"
    assert safe_eval("{{ {'x': 42, 'y': 43} }}") == "{{ {'x': 42, 'y': 43} }}"
    assert safe_eval("{{ (1, 2, 3) }}") == "{{ (1, 2, 3) }}"

# Generated at 2022-06-23 13:24:28.396987
# Unit test for function safe_eval
def test_safe_eval():
    # basic sanity checks
    expr = '1'
    assert safe_eval(expr) == 1
    expr = 'true'
    assert safe_eval(expr) is True
    expr = 'false'
    assert safe_eval(expr) is False
    expr = 'null'
    assert safe_eval(expr) is None
    expr = 'dict(a=1, b=2)'
    assert safe_eval(expr) == dict(a=1, b=2)
    expr = 'list(a=1, b=2)'
    assert safe_eval(expr) == list(a=1, b=2)
    expr = '[1, 2, 3]'
    assert safe_eval(expr) == [1, 2, 3]
    expr = '[1, 2, 3]'

# Generated at 2022-06-23 13:24:38.516239
# Unit test for function safe_eval

# Generated at 2022-06-23 13:24:44.809179
# Unit test for function safe_eval
def test_safe_eval():
    # Test valid expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 2') == 4
    assert safe_eval('1 + 1 == 2')
    assert safe_eval('1 + 1 == 2 and (1 + 1) * 2 == 6')
    assert safe_eval('"foo" in ["foo", "bar", "baz"]')
    assert safe_eval('not ("quux" in "quux")')
    assert safe_eval('1 != 2')
    assert safe_eval('1 < 2')
    assert safe_eval('2 > 1')
    assert safe_eval('1 <= 1')
    assert safe_eval('1 <= 2')
    assert safe_eval('1 >= 1')
    assert safe_eval('2 >= 1')
    assert safe_eval('2 ** 3')
    assert safe

# Generated at 2022-06-23 13:24:55.428123
# Unit test for function safe_eval
def test_safe_eval():
    failed = False

# Generated at 2022-06-23 13:25:04.005964
# Unit test for function safe_eval
def test_safe_eval():

    # assert exceptions
    # Note: Not checking the exception message, because the message
    # generated by different versions of Python are different.

    expr = "1 if 2 else 5"
    try:
        val = safe_eval(expr)
    except Exception as e:
        assert True
    else:
        assert False

    expr = "1 or 2"
    try:
        val = safe_eval(expr)
    except Exception as e:
        assert True
    else:
        assert False

    expr = "1 and 2"
    try:
        val = safe_eval(expr)
    except Exception as e:
        assert True
    else:
        assert False

    expr = "1 in 2"
    try:
        val = safe_eval(expr)
    except Exception as e:
        assert True

# Generated at 2022-06-23 13:25:15.137660
# Unit test for function safe_eval
def test_safe_eval():
    def check(result, exception, **kwargs):
        _result, _exception = safe_eval(result, **kwargs)
        if exception is not None:
            assert isinstance(_exception, exception)
        elif _exception is not None:
            raise AssertionError("_exception should be None, got: %s" % _exception)
        return _result

    # Base Types
    check(1, None, include_exceptions=True)
    check(1.5, None, include_exceptions=True)
    check('abc', None, include_exceptions=True)
    check('1 + 1', None, include_exceptions=True)
    check({'a': 1}, None, include_exceptions=True)
    check([1], None, include_exceptions=True)

# Generated at 2022-06-23 13:25:20.275877
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval returns a value, while unsafe_eval returns a string
    assert safe_eval("2 + 3") == 5
    assert safe_eval("{{ 2+3 }}") == "{{ 2+3 }}"

    # make sure we don't run arbitrary python code.
    assert safe_eval("__import__('os').system('rm -rf')") == "__import__('os').system('rm -rf')"
    # but also allow list creation
    safe_eval("[1,2,3,4]") == [1,2,3,4]

    # make sure we don't allow attribute access
    assert safe_eval("a_list = [1,2,3,4]; a_list.pop()") == "a_list = [1,2,3,4]; a_list.pop()"

# Generated at 2022-06-23 13:25:21.253737
# Unit test for function safe_eval
def test_safe_eval():
    raise NotImplementedError()
    pass

# Generated at 2022-06-23 13:25:31.453386
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended to be run from the command line
    via: python -c 'import ansible.utils.unsafe_proxy; ansible.utils.unsafe_proxy.test_safe_eval()'
    '''

    # test cases, where the tuple is:
    #  - input string to be tested
    #  - string to be printed if test fails
    #  - expected output value

# Generated at 2022-06-23 13:25:40.869084
# Unit test for function safe_eval
def test_safe_eval():
    # Data
    GOOD_DATA = 'test_string'
    GOOD_EXPR = 'test_string'
    BAD_EXPR = 'test_string_with_bad_function()'
    BAD_EXPR_WITH_MULTIPLE_FUNCTIONS = '[os.path.dirname(test_string_with_bad_function()),os.path.dirname(test_string_with_bad_function())]'
    EXPECTED_ERROR = 'invalid function: test_string_with_bad_function'
    EXPECTED_ERROR_WITH_MULTIPLE_FUNCTIONS = "invalid expression ([os.path.dirname(test_string_with_bad_function()),os.path.dirname(test_string_with_bad_function())])"

    # Test good include
    result = safe_

# Generated at 2022-06-23 13:25:51.215732
# Unit test for function safe_eval
def test_safe_eval():
    # Test literal dicts and lists
    result = safe_eval('{"key": "val"}')
    assert result == {'key': 'val'}
    result = safe_eval('["val"]')
    assert result == ['val']

    # Test disallowed things
    try:
        safe_eval('[x for x in [1,2,3]]')
        assert False
    except Exception as e:
        assert True

    # Test allowed things with Call
    result = safe_eval('{"key": list(range(2))}')
    assert result == {'key': [0, 1]}

    # Test safe functions in Call
    result = safe_eval('len([1,2,3])')
    assert result == 3

# Generated at 2022-06-23 13:26:03.331994
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval function
    assert safe_eval('my_list[0]', {'my_list': [42]}) == 42
    assert safe_eval('my_list[0]', {'my_list': [42]}, include_exceptions=True) == (42, None)
    assert safe_eval('my_list[0]', {'my_list': 42}) == 'my_list[0]'
    assert safe_eval('my_list[0]', {'my_list': 42}, include_exceptions=True) == ('my_list[0]', None)
    assert safe_eval('my_list[0]', {'my_list': range(10)}) == 0
    assert safe_eval('my_list[0]', {'my_list': range(10)}, include_exceptions=True)

# Generated at 2022-06-23 13:26:07.691158
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure safe_eval passes back syntax errors
    # Note:  Syntax errors could be propagated back
    # in Python 3.x and later with a try/catch/raise
    # but Python 2.x has different exceptions for
    # compile() and eval()
    syntax_error = '{a:2,b:3'
    result = safe_eval(syntax_error)
    assert(result == syntax_error)

    # Examples that should be allowed that were
    # failing previously
    result = safe_eval('mydict["a"]', dict(mydict=dict(a=2,b=3)))
    assert(result == 2)
    result = safe_eval('result.get("a")', dict(result=dict(a=2,b=3)))
    assert(result == 2)

    # Example of a disallowed function

# Generated at 2022-06-23 13:26:19.256667
# Unit test for function safe_eval
def test_safe_eval():

    # Tests with invalid expressions
    failed = 0
    failed += not safe_eval("a + 1", {'a': 1}, include_exceptions=True) == (2, None)
    failed += not safe_eval("foo(1) + 1", {'a': 1}, include_exceptions=True) == ('foo(1) + 1', None)
    failed += not safe_eval("foo(1)", {'foo': lambda x: 1}, include_exceptions=True) == (1, None)
    failed += not safe_eval("foo(1)", {'foo': lambda x: 1, '__builtins__': {'bar': 0}}, include_exceptions=True) == (1, None)

# Generated at 2022-06-23 13:26:25.229520
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:35.524406
# Unit test for function safe_eval
def test_safe_eval():
    # normal
    assert safe_eval("{{ foo }}") == '{{ foo }}'
    assert safe_eval("{{ foo + bar }}") == '{{ foo + bar }}'
    assert safe_eval("{{ foo.bar }}") == '{{ foo.bar }}'
    assert safe_eval("{{ foo | mand }}") == '{{ foo | mand }}'
    assert safe_eval("{{ foo.bar | mand }}") == '{{ foo.bar | mand }}'
    assert safe_eval("newvalue") == 'newvalue'
    assert safe_eval(123) == 123
    assert safe_eval(3.14) == 3.14
    assert safe_eval(True) is True
    assert safe_eval(False) is False
    assert safe_eval([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 13:26:48.066691
# Unit test for function safe_eval

# Generated at 2022-06-23 13:26:58.674437
# Unit test for function safe_eval
def test_safe_eval():
    (compare_result, errors) = safe_eval("a + b", dict(a=1, b=2), True)
    assert compare_result == 3
    assert errors is None

    (compare_result, errors) = safe_eval("a + b", dict(a=1, b=2, c=3), True)
    assert compare_result == 3
    assert errors is None

    (compare_result, errors) = safe_eval("a + int('1')", dict(a=1, b=2, c=3), True)
    assert compare_result == 2
    assert errors is None

    (compare_result, errors) = safe_eval("a + d", dict(a=1, b=2, c=3), True)
    assert compare_result == 'a + d'

# Generated at 2022-06-23 13:27:06.982776
# Unit test for function safe_eval
def test_safe_eval():
    expr = u"1 + 2 + 3 + 4"
    result = safe_eval(expr)
    assert result == 10

    expr = u"1 + frob() + 3 + 4"
    try:
        safe_eval(expr)
        assert False, "should have raised an exception"
    except Exception as e:
        pass

    expr = u"1 + 2 + 3 + 4"
    result = safe_eval(expr, include_exceptions=True)
    assert result == (10, None)

    expr = u"1 + frob() + 3 + 4"
    result = safe_eval(expr, include_exceptions=True)
    assert result[0] == expr
    assert result[1] != None

    expr = u"null"
    result = safe_eval(expr)
    assert result == None


# Generated at 2022-06-23 13:27:16.132172
# Unit test for function safe_eval
def test_safe_eval():

    # test that unsafe things raise exceptions
    expr = '__import__("os").popen("touch pwned").read()'
    try:
        safe_eval(expr)
        assert False, '"%s" should not be safe' % expr
    except Exception:
        pass

    # test that safe things are allowed
    expr = '1+2'
    assert safe_eval(expr) == 3

    expr = '1+2'
    assert safe_eval(expr) == 3

    expr = '-1'
    assert safe_eval(expr) == -1

    expr = '"-1"'
    assert safe_eval(expr) == "-1"

    expr = '"foo"'
    assert safe_eval(expr) == "foo"

    expr = '1,2,3'

# Generated at 2022-06-23 13:27:25.071083
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test that safe_eval() runs without errors on valid Python expressions
    """
    # We can convert this to a single expression once #15206 is done
    expr_template = u'''
        {%% if result | default(True) -%}
          {{ result_str }}
        {%% else -%}
          {{ expr }}
        {%% endif -%}
    '''

    def run_test(expr, additional_globals=None):
        e = Exception('oops')
        result_str = container_to_text(safe_eval(expr), python_multiline=True)

        # first, ensure that when the evaluation failed, we got back the
        # original expression
        result, err = safe_eval(expr, include_exceptions=True)
        assert result == expr
        assert err is not None

        #

# Generated at 2022-06-23 13:27:35.889380
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == 'foo'

    assert safe_eval("foo.bar()") == 'foo.bar()'

    assert safe_eval("foo.bar") == 'foo.bar'

    assert safe_eval("foo['bar']") == "foo['bar']"

    assert safe_eval("foo['bar']",
                     dict(foo={'bar': 'baz'})) == "baz"

    assert safe_eval("foo['bar'].baz()",
                     dict(foo={'bar': 'baz'})) == "foo['bar'].baz()"

    assert safe_eval("foo.bar.baz()",
                     dict(foo={'bar': 'baz'})) == "foo.bar.baz()"


# Generated at 2022-06-23 13:27:47.071319
# Unit test for function safe_eval
def test_safe_eval():
    # Dictionary should be fine
    assert safe_eval("{'a': 'b'}") == {"a": "b"}

    # List should be fine
    assert safe_eval("['a', 'b']") == ["a", "b"]

    # Numeric expression
    assert safe_eval("1+1") == 2

    # Simple boolean expression
    assert safe_eval("1==1") is True

    # Call to bool() should fail
    assert safe_eval("bool(1)") is None

    # Call to print() should fail
    assert safe_eval("print(1)") is None

    # Expression should fail
    assert safe_eval("1+foo") is None

    # Nested expression should fail
    assert safe_eval("1+1==2") is None

    # Call to bool() should pass with CALL_ENABLED set

# Generated at 2022-06-23 13:27:58.951749
# Unit test for function safe_eval
def test_safe_eval():
    tests = [
        (1, '1'),
        (1.1, '1.1'),
        ('foo', "'foo'"),
        ([1, 2], '[1, 2]'),
        (['a', 1, ['b', 'c']], "['a', 1, ['b', 'c']]"),
        (None, 'null'),
        (False, 'false'),
        ('[]', '[]'),
        ('[1,2,3]', '[1,2,3]'),
        ('{"foo": "bar"}', '{"foo": "bar"}'),
        ('[foo]', '[foo]'),
    ]

    allowed_functions = call_whitelist()

    for allowed in allowed_functions:
        tests.append((allowed.__name__, '%s()' % allowed.__name__))

   

# Generated at 2022-06-23 13:28:05.709147
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"
    assert safe_eval("{{ foo.bar.baz }}") == "{{ foo.bar.baz }}"
    assert safe_eval("42") == 42
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("(foo.bar)", dict(foo={'bar': 42})) == 42
    assert safe_eval("(foo.bar)", dict(foo={'bar': 42.5})) == 42.5
    assert safe_eval("foo.bar", dict(foo={'bar': 'baz'})) == "baz"
    assert safe_eval("foo.bar", dict(foo={'bar': [1, 2, 3]}))

# Generated at 2022-06-23 13:28:17.648159
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2, 'safe_eval("1+1") failed'
    assert safe_eval("1+1", include_exceptions=True) == (2, None), 'safe_eval("1+1") with include_exceptions failed'
    assert safe_eval("1+1", {'one': 1}) == 2, 'safe_eval("1+1", {one: 1}) failed'
    assert safe_eval("1+one", {'one': 1}) == 2, 'safe_eval("1+one", {one: 1}) failed'
    assert safe_eval("1+one", {'one': 1}, include_exceptions=True) == (2, None), 'safe_eval("1+one", {one: 1}, include_exceptions) failed'

# Generated at 2022-06-23 13:28:30.224256
# Unit test for function safe_eval
def test_safe_eval():
    def assert_raises(expr):
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result == expr
        assert type(exception) == Exception

    # Test basic Python expressions
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2

    # Test string expression containing quote
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'foo'") == 'foo'

    # Test boolean expressions
    assert safe_eval('1 == 1')
    assert not safe_eval('1 > 1')

    # Test lists, dicts and tuples
    assert safe_eval('[1, 2]') == [1, 2]

# Generated at 2022-06-23 13:28:41.959627
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is intended for allowing things like:
    with_items: a_list_variable

    Where Jinja2 would return a string but we do not want to allow it to
    call functions (outside of Jinja2, where the env is constrained).

    Based on:
    http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe
    '''


# Generated at 2022-06-23 13:28:49.100784
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable") == "a_list_variable"
    assert safe_eval("'a_list_variable'") == "a_list_variable"
    assert safe_eval("a_list_variable|d(omain='example.com')") == "a_list_variable|d(omain='example.com')"
    assert safe_eval("{'k1': 'v1'}") == dict(k1='v1')
    assert safe_eval("[]") == []
    assert safe_eval("'v1'") == "v1"
    assert safe_eval("v1") == "v1"
    assert safe_eval("['v1']") == ["v1"]

# Generated at 2022-06-23 13:28:58.575052
# Unit test for function safe_eval

# Generated at 2022-06-23 13:29:10.353743
# Unit test for function safe_eval
def test_safe_eval():

    def _test(expr, expected, locals=None):
        ''' compare the result of safe_eval with the expected result '''
        rc, err = safe_eval(expr, locals=locals, include_exceptions=True)
        if err is not None:
            print("invalid expr: %s [error: %s]" % (expr, err))
            sys.exit(1)
        if rc != expected:
            print("invalid expr: %s [expected: %s, got: %s]" % (expr, expected, rc))
            sys.exit(1)
        print("good expr: %s" % expr)

    vars = dict(
        toto="hello",
        titi=False,
        tata=[1, 2, 3],
        tete={'a': 'b'}
    )

    #

# Generated at 2022-06-23 13:29:22.401582
# Unit test for function safe_eval
def test_safe_eval():
    d = {}
    assert safe_eval('a', {'a': True}) is True
    assert safe_eval('a', {'a': 1}) == 1
    assert safe_eval('"hello"') == u"hello"
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {u"foo": u"bar"}
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('[a for a in range(5)]', {'range': range}) == [0, 1, 2, 3, 4]
    assert safe_eval('foo(a)', {'a': 5, 'foo': lambda x: x * 2}) == 10

# Generated at 2022-06-23 13:29:29.745814
# Unit test for function safe_eval
def test_safe_eval():

    # This is a list of a list of a list
    lll = safe_eval("[ [ 'foo', 'bar' ], [ 'baz' ] ]")
    assert lll[1][0] == 'baz'

    # This is a list of a tuple of a list of a string
    lotl = safe_eval("[ ( 'foo', ['bar' ] ), 'this is a string' ]")
    assert lotl[0][1] == ['bar']

    # This is a tuple
    t = safe_eval("('foo',)")
    assert t == ('foo',)

    # This is a list
    lll = safe_eval("['foo', 'bar']")
    assert lll == ['foo', 'bar']

    # This is a dictionary
    d = safe_eval("{'foo': 'bar'}")


# Generated at 2022-06-23 13:29:39.317729
# Unit test for function safe_eval
def test_safe_eval():

    def _run_test(args, result, exception=None):
        if exception:
            res, ex = safe_eval(args, include_exceptions=True)
            if res != result or not isinstance(ex, exception):
                raise AssertionError(
                    "Evaluation of '{}' failed!\nResult is '{}' instead of '{}'!\nException is '{}' instead of '{}'!".format(
                        args, res, result, ex, exception
                    )
                )
        else:
            res = safe_eval(args, include_exceptions=True)

# Generated at 2022-06-23 13:29:49.128433
# Unit test for function safe_eval
def test_safe_eval():
    def fail(expr):
        try:
            safe_eval(expr)
            raise Exception("safe_eval passed: %s" % expr)
        except Exception as e:
            print("%s: %s" % (type(e), expr))


# Generated at 2022-06-23 13:29:58.774172
# Unit test for function safe_eval
def test_safe_eval():

    # check for dangerous calls and unsafe strings
    def check_unsafe_string(expr, locals=None):
        result, exception = safe_eval(expr, locals=locals, include_exceptions=True)
        assert result == expr
        assert type(exception) == Exception

    check_unsafe_string('open("/etc/passwd")')
    check_unsafe_string('os.system("/etc/passwd")')
    check_unsafe_string('__import__("subprocess").call("/etc/passwd")')
    check_unsafe_string('__import__("subprocess").call(["/etc/passwd"])')
    check_unsafe_string('subprocess.call(["/etc/passwd"])')
    check_unsafe_string('subprocess.call("/etc/passwd")')

# Generated at 2022-06-23 13:30:09.849194
# Unit test for function safe_eval
def test_safe_eval():
    # include this for python 2.6 which does not support the with_items
    # syntax in ansible directly (to be removed in 2.0)
    locals = {
        'a_list': [2, 3, 4],
        'a_string': "I'm a string",
        'a_dict': {
            'foo': 1,
            'bar': 2,
            'baz': [3, 4],
            'qux': {'quux': 5, 'quuz': 6},
        },
        'a_number': 123,
    }

    assert safe_eval('a_list', locals=locals) == [2, 3, 4] # with_items
    assert safe_eval('a_string', locals=locals) == locals['a_string']

# Generated at 2022-06-23 13:30:19.176094
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('list(range(2))') == [0, 1]
    assert safe_eval('"a" or "b"') == "a"
    assert safe_eval('True') is True
    assert safe_eval("False") is False
    assert safe_eval("null") is None
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("a", dict(a=1)) == 1
    assert safe_eval("a", dict(a="b")) == "b"
    assert safe_eval("a", dict(a=None)) is None
    assert safe_eval("a", dict(a=True)) is True

# Generated at 2022-06-23 13:30:26.324438
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This test function can be run from the command line
    to perform a quick unit test on the safe_eval function.
    '''


# Generated at 2022-06-23 13:30:35.485637
# Unit test for function safe_eval
def test_safe_eval():
    # Test to make sure safe_eval works as expected, in normal situations

    # Test safe_eval, passing in a string which is python code
    result = safe_eval("True")
    assert result is True

    # Test enclosing the string literal with quotes
    result = safe_eval("'True'")
    assert result == 'True'

    # Test an Expression
    result = safe_eval("2+2")
    assert result == 4

    # Test an Expression using more complicated variables
    test_variable_dict = {'a': 1, 'b': 2}
    result = safe_eval("a+b", dict(test_variable_dict))
    assert result == 3

    # Test an Expression using more complicated variables
    test_variable_dict = {'a': '2', 'b': '2'}

# Generated at 2022-06-23 13:30:46.054655
# Unit test for function safe_eval

# Generated at 2022-06-23 13:30:52.572010
# Unit test for function safe_eval
def test_safe_eval():
    good_expr = 'a_list | map("int") | list'
    bad_expr = 'a_list | map("int") | not_any_function'

    # List and string comparison with assertEqual doesn't work
    # for some reason, so use the good old assert
    assert safe_eval(good_expr) == [1, 2, 3]
    # bad_expr raises an exception, but our function should just
    # return it so we can handle it elsewhere as a string
    assert safe_eval(bad_expr) == bad_expr



# Generated at 2022-06-23 13:31:04.354352
# Unit test for function safe_eval

# Generated at 2022-06-23 13:31:10.564003
# Unit test for function safe_eval
def test_safe_eval():
    good_expressions = (
        None,
        0,
        1,
        '',
        'string',
        '{{ foo }}',
        '[]',
        '{}',
        'foo',
        'True',
        'False',
        'None',
        'foo.bar',
        'foo.bar()',
        'foo()',
        '[i for i in foo]',
        '{i: j for i, j in foo.items()}',
    )

# Generated at 2022-06-23 13:31:22.679884
# Unit test for function safe_eval
def test_safe_eval():

    def _test(expr, locals_=None, exception_=None, result_=None):
        if locals_ is None:
            locals_ = {}
        expected = (result_, exception_)
        actual = safe_eval(expr, locals_, include_exceptions=True)
        assert expected == actual

    # default case
    _test('abc')
    _test('abc', result_='abc')
    _test('abc', {'abc':'def'}, result_='def')

    # Literals
    _test('123', result_=123)
    _test('"string"', result_='string')
    _test('"yay {}".format(1+1)', result_='yay 2')
    _test('[1,2]', result_=[1,2])

# Generated at 2022-06-23 13:31:33.906181
# Unit test for function safe_eval
def test_safe_eval():
    # Test the failure modes
    eval_failure = [
        "__import__('sys').modules",
        "__builtins__.open('/etc/passwd').read()",
        "[x for x in range(0,3)][os.getpid()]",
        "__builtins__.max([1,2,3], key=lambda x: __import__('sys').modules)",
    ]

    for expr in eval_failure:
        assert safe_eval(expr) == expr

    # Test that we can still use the literal types we allow

# Generated at 2022-06-23 13:31:38.665545
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is not a complete test, as unsafe_eval is subject
    to change and there is nothing to stop a built-in or an
    imported module being added to the whitelist in future.
    '''
    # This checks we can't call anything in the builtins
    # that we haven't specifically allowed.
    assert safe_eval(u"divmod(5,6)") == u"divmod(5,6)"
    CALL_ENABLED.append(u'divmod')
    assert safe_eval(u"divmod(5,6)") == (5, 6)

    # This checks against running arbitrary code

# Generated at 2022-06-23 13:31:47.090554
# Unit test for function safe_eval
def test_safe_eval():
    assert str(safe_eval("'1'+'1'")) == "11"
    assert safe_eval("__") == "__"
    assert safe_eval("__", include_exceptions=True) == ('__', None)
    assert safe_eval("__import__('sys')") == "__import__('sys')"
    assert safe_eval("__import__('sys')", include_exceptions=True) == ("__import__('sys')", None)
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert dict(safe_eval("(1:1, 2:2)")) == {1: 1, 2: 2}
    assert safe_eval("[__") == "[__"
    assert safe_eval("[1,__") == "[1,__"
    assert safe_

# Generated at 2022-06-23 13:31:58.958171
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2") == 2
    assert safe_eval("2 + 2") == 4
    assert safe_eval("2 * 3") == 6
    assert safe_eval("6 / 2") == 3
    assert safe_eval("6 // 2") == 3
    assert safe_eval("7 // 2") == 3
    assert safe_eval("10 % 4") == 2
    assert safe_eval("'foo' == 'foo'") is True
    assert safe_eval("'foo' + 'bar'") == "foobar"
    assert safe_eval("'foo' + u'bar'") == "foobar"
    assert safe_eval("'foo' + 'bar' + 'baz'") == "foobarbaz"
    assert safe_eval("2 and 3") == 3
    assert safe_eval("2 or 3") == 2

# Generated at 2022-06-23 13:32:04.731940
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval.
    '''
    from ansible.module_utils.common import json

    # Boolean
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("true and false") is False
    assert safe_eval("true or false") is True
    assert safe_eval("true and true") is True
    assert safe_eval("true or true") is True

    # Number
    assert safe_eval("0") == 0
    assert safe_eval("1.0") == 1.0
    assert safe_eval("1 + 2") == 3
    assert safe_eval("1 * 2 + 3 * 4") == 14
    assert safe_eval("0.1 + 0.2") == 0.3
    assert safe_eval("42") == 42



# Generated at 2022-06-23 13:32:13.521808
# Unit test for function safe_eval
def test_safe_eval():
    # raise exception with invalid expression
    try:
        safe_eval('_func()')
        assert False
    except Exception:
        assert True

    # raise exception with invalid function call
    try:
        safe_eval('__import__("sys").exit(0)')
    except Exception:
        assert True

    # return expression string when convert to data structure failed
    assert safe_eval('{a}') == '{a}'

    # convert a valid expression to data structure
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a_list":[1,2,3], "a_dict": {"b": 1, "c": 2}}') == {"a_list": [1, 2, 3], "a_dict": {"b": 1, "c": 2}}
   

# Generated at 2022-06-23 13:32:22.859571
# Unit test for function safe_eval
def test_safe_eval():
    expr1 = 'item_1'
    expr2 = 'item_1 and item_2'
    expr3 = 'item_1 and not item_2'
    expr4 = 'item_1 or item_2'
    expr5 = '"string"'
    expr6 = 'item_1 in item_2'
    expr7 = 'item_1 + item_2'
    expr8 = 'item_1 - item_2'
    expr9 = 'item_1 * item_2'
    expr10 = 'item_1 / item_2'
    expr11 = 'item_1.item_2'
    expr12 = 'item_1[item_2]'
    expr13 = 'item_1.item_2.item_3'
    expr14 = 'item_1[item_2][item_3]'
    expr15

# Generated at 2022-06-23 13:32:32.686785
# Unit test for function safe_eval

# Generated at 2022-06-23 13:32:42.858893
# Unit test for function safe_eval
def test_safe_eval():

    safe_dict = { "a": 1, "b": 2, "c": 3 }

    def valid_case(expr, expected):

        value = safe_eval(expr, locals=safe_dict)
        if value != expected:
            raise AssertionError('Expression: %s; expected: %s; got: %s' % (expr, expected, value))

        result, exception = safe_eval(expr, locals=safe_dict, include_exceptions=True)
        if result != expected:
            raise AssertionError('Expression: %s; expected: %s; got: %s' % (expr, expected, result))
        if exception is not None:
            raise AssertionError('Expression: %s; expected: %s; got: %s' % (expr, expected, exception))


# Generated at 2022-06-23 13:32:53.758005
# Unit test for function safe_eval
def test_safe_eval():
    pass_tests = ['True', 'False', 'None', 'True or False']

    for test in pass_tests:
        assert safe_eval(test) == eval(test)

    fail_tests = [
        'import os',
        '__import__("os")',
        "__import__('os')",
        'import os; os.listdir(".")',
        '__import__("os").listdir(".")',
        'assert False',
        'assert(False)',
    ]

    for test in fail_tests:
        try:
            safe_eval(test)
        except Exception:
            pass
        else:
            raise AssertionError('safe_eval() passed on invalid literal %s' % test)
