

# Generated at 2022-06-21 07:51:04.515690
# Unit test for function safe_eval
def test_safe_eval():
    '''Test the safe_eval method'''
    from ansible.module_utils.basic import AnsibleModule

    # We need a module to call exitjson()
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # This is a safe expression
    test_string = 'foo is bar'
    (result, exc) = safe_eval(test_string, include_exceptions=True)
    if exc is not None:
        module.exit_json(failed=True, msg='Expression "%s" is not safe: %s' % (test_string, to_native(exc)))

# Generated at 2022-06-21 07:51:15.956338
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:27.349828
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    results = []

# Generated at 2022-06-21 07:51:39.863353
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:40.929891
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure the error handling is valid and working
    safe_eval('1 == 1 and not this_is_an_error', {})



# Generated at 2022-06-21 07:51:52.886587
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:05.066816
# Unit test for function safe_eval
def test_safe_eval():
    def assert_eval(expr, locals=None):
        locals = {} if locals is None else locals
        parsed = safe_eval(expr, locals=locals, include_exceptions=True)

        if not isinstance(parsed, tuple):
            parsed = (parsed, None)

        if parsed[1] is not None:
            raise parsed[1]
        else:
            return parsed[0]

    assert_eval('{}')
    assert_eval('[]')
    assert_eval('[1, 2, 3]')
    assert_eval('["foo", "bar"]')
    assert_eval('[1, 2, [3, 4]]')
    assert_eval('{"foo": "bar"}')
    assert_eval('{"foo": "bar", "bar": "foo"}')

# Generated at 2022-06-21 07:52:16.633466
# Unit test for function safe_eval
def test_safe_eval():
    # from ansible.constants import empty_val

    # None is a valid expression
    result, exception = safe_eval(None, {}, include_exceptions=True)
    assert result is None
    assert exception is None

    # Test safe_eval
    result, exception = safe_eval('"test" in x', {'x': "Testing"}, include_exceptions=True)
    assert result is True
    assert exception is None

    result, exception = safe_eval('"test" in x', {'x': "foo"}, include_exceptions=True)
    assert result is False
    assert exception is None

    result, exception = safe_eval('x in y', {'x': "Testing", 'y': "foo"}, include_exceptions=True)
    assert result is False
    assert exception is None

    result, exception = safe_eval

# Generated at 2022-06-21 07:52:23.905252
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 * 3") == 6
    assert safe_eval("1 + 2 + 3") == 6
    assert safe_eval("'a' + 'b'") == 'ab'
    assert safe_eval("'a' + 'b' + 'c'") == 'abc'
    assert safe_eval("1 + 1 == 2") is True
    assert safe_eval("2 * 3 == 5") is False
    assert safe_eval("2 * 3 < 5") is True
    assert safe_eval("'a' + 'b' == 'ab'") is True
    assert safe_eval("'a' + 'b' == 'ac'") is False
    assert safe_eval("2 * 3 in [3, 4, 5]") is False

# Generated at 2022-06-21 07:52:34.406470
# Unit test for function safe_eval
def test_safe_eval():
    # Tests the AST filter
    expr = "[1,2,3]"
    assert safe_eval(expr) == [1, 2, 3]

    # Tests the error handling
    expr = "__import__('os').listdir('.')"
    eval = safe_eval(expr)
    assert(eval == expr)
    # Make sure the evaluated value is still a string
    assert isinstance(eval, str)

    # Make sure that safe_eval(None) returns None
    assert safe_eval(None) == None

    # Make sure that safe_eval(True) returns True
    assert safe_eval(True) is True

    # Make sure that safe_eval(1) returns 1
    assert safe_eval(1) == 1

    # Make sure that safe_eval(1.0) returns 1.0

# Generated at 2022-06-21 07:52:48.725373
# Unit test for function safe_eval
def test_safe_eval():
    # Python 2.6 does not have ast.Call and ast.Name so we need to stub them
    # out to prevent an exception

    class Call():
        pass

    class Name():
        pass

    ast.Call = Call
    ast.Name = Name

    # Test some safe expressions

# Generated at 2022-06-21 07:52:59.092292
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    # Test the basics
    pytest.raises(Exception, safe_eval, 'invalid expression')
    pytest.raises(Exception, safe_eval, 'invalid_function()')
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('[1, (2, 3), 4]') == [1, (2, 3), 4]
    assert safe_eval('{"foo": "bar"}') == {u"foo": u"bar"}
    assert safe_eval('None') == None
    assert safe_eval('1 == 1') is True
    assert safe_eval('false') is False
   

# Generated at 2022-06-21 07:53:09.786547
# Unit test for function safe_eval
def test_safe_eval():
    # invalid syntax error
    try:
        safe_eval('(){}')
    except Exception:
        pass
    else:
        assert False, "Invalid syntax should raise an exception"

    # should have no exceptions
    safe_eval('1')
    safe_eval('1+1')
    safe_eval('1+1', dict(a=1))
    safe_eval('1+1', dict(a=1, b=2))
    safe_eval('a', dict(a=1))
    safe_eval("'%s'" % 'a')
    safe_eval("[1,2,3]")
    safe_eval("(1,2,3)")
    safe_eval("{'a': 1, 'b':2}")
    safe_eval("[1,2,3][1]")
    safe_eval

# Generated at 2022-06-21 07:53:22.128918
# Unit test for function safe_eval
def test_safe_eval():
    # old style module tests function
    try:
        from ansible.module_utils import basic
        from ansible.module_utils._text import to_text
    except Exception:
        from __main__ import basic
        from __main__ import to_text
    if not isinstance(basic, object):
        raise Exception("__main__.basic is no longer an object!")
    if not hasattr(basic, 'AnsibleModule'):
        raise Exception("__main__.basic is no longer a class!")

    # we can't directly use sys.modules because this test script
    # will import and execute setup.py which will import ansible
    # resulting in a loaded module, but not the one we want, so
    # we look it up in sys.modules

# Generated at 2022-06-21 07:53:33.744796
# Unit test for function safe_eval
def test_safe_eval():
    # no exception should be thrown
    safe_eval("2+2")
    safe_eval("dict(a=1, b=2)")
    safe_eval("[1, 2]")
    safe_eval("[x for x in range(10)]")
    safe_eval("(1, 2)")
    safe_eval("{1, 2}")
    safe_eval("{1: 2, 3: 4}")
    safe_eval("1 + 2 * 3 / 4")
    safe_eval("(1 + 2) * 3 / 4")
    safe_eval("1 ** 2 + 2 ** 3")
    safe_eval("-1")
    safe_eval("-1 ** 2")
    safe_eval("not True")
    safe_eval("True and False")
    safe_eval("True and False or True")

   

# Generated at 2022-06-21 07:53:44.846952
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins  # pylint: disable=no-name-in-module,import-error

    # evil_func is now in the CALL_ENABLED list, so it will be allowed to be called.
    # If you want to call it, you will have to import it from the os module.
    original_os_system = builtins.__dict__['system']
    builtins.__dict__['system'] = builtins.__dict__['evil_func']

    expr = "ansible_facts['distribution_release'] == 'el7' or ansible_facts['distribution_release'] == '7'"
    safe_eval(expr)

    # this expression should raise a ValueError like regular python does
    expr = "'12' + 7"
   

# Generated at 2022-06-21 07:53:52.933495
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as conv

    for item in ["{{ foo }}", "{{ foo.bar }}", "['fizz', 'buzz']", "{'fizz': 'buzz'}"]:
       assert(safe_eval(item) == conv.template(item))
    try:
        safe_eval("foo()")
        assert False
    except:
        pass

    try:
        safe_eval("[1,2,3,4][foo]")
        assert False
    except:
        pass

    try:
        safe_eval("eval('foo')")
        assert False
    except:
        pass

    try:
        safe_eval("{1:2,3:4,5:6}['foo']")
        assert False
    except:
        pass


# Generated at 2022-06-21 07:54:03.259459
# Unit test for function safe_eval
def test_safe_eval():
    s = """
    # Test that the stringified version of a dict is still a dict
    foo_dict = dict(a='b', b='c')
    foo_str = "%s" % foo_dict
    """
    locals = {}
    safe_eval(s, locals)
    assert locals['foo_dict']['a'] == 'b'
    assert locals['foo_str']['a'] == 'b'

    # Test that a dict, when templated by the string module, converts to a dict
    s = "{{ foo_dict }}"
    locals = dict(foo_dict=dict(a='b', b='c'))
    assert isinstance(safe_eval(s, locals), dict)
    assert locals['foo_dict']['a'] == 'b'

    # Test that a list, when templated

# Generated at 2022-06-21 07:54:13.351863
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval"""
    assert C.DEFAULT_DEBUG == safe_eval('True or False')
    assert 3 == safe_eval('1 + 3 - 1')
    assert 16 == safe_eval('2 ** 4')
    assert [1, 2, 4] == safe_eval('[1, 2, 2 ** 2]')
    assert (1, 3, 9) == safe_eval('(1, 3, 3 ** 2)')
    assert {'a': 'b', 'c': 42} == safe_eval('{"a": "b", "c": 6 * 7}')
    assert 'foo' == safe_eval('"fo" + "o"')
    assert 'globals' in safe_eval('globals()')

# Generated at 2022-06-21 07:54:22.366535
# Unit test for function safe_eval
def test_safe_eval():

    # we expect this call to succeed
    test = safe_eval("1 + 1")
    assert test == 2, test

    # we expect this call to fail
    test = safe_eval("import fcntl")
    assert test == "import fcntl", test

    # we expect this call to fail
    test = safe_eval("a_list_variable")
    assert test == "a_list_variable", test

    # we expect this call to fail
    test = safe_eval("[a_list_variable]")
    assert test == "[a_list_variable]", test

    # we expect this call to succeed
    test = safe_eval("len([range(10)])")
    assert test == 1, test

    # we expect this call to fail
    test = safe_eval("[range(10)]")
    assert test

# Generated at 2022-06-21 07:54:35.019821
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval
    '''
    passed = False
    # test 1,2 - primitive literals
    # integer
    if safe_eval("1") != 1:
        print("safe_eval() failed to parse 1 as an integer")
        return False
    # float
    if safe_eval("1.1") != 1.1:
        print("safe_eval() failed to parse 1.1 as a float")
        return False
    # boolean
    if safe_eval("True") != True:
        print("safe_eval() failed to parse True as a boolean")
        return False
    # null
    if safe_eval("null") != None:
        print("safe_eval() failed to parse null as None")
        return False
    # string

# Generated at 2022-06-21 07:54:43.319621
# Unit test for function safe_eval
def test_safe_eval():
    """
    Minimal unit tests for safe_eval
    """
    # Simple allowed expressions
    assert safe_eval("1+1") == 2
    assert safe_eval("a_list_variable", locals=dict(a_list_variable=['foo', 'bar'])) == ['foo', 'bar']

    # Simple disallowed expressions
    assert safe_eval('__import__("os")') == "__import__(\"os\")"

    # JSON types
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None
    if sys.version_info[0] == 2:
        # Python 2 eval() does not allow unicode literals
        # The safe_eval() wrapper should convert them to str
        assert safe_eval(u"u'foo'") == u

# Generated at 2022-06-21 07:54:55.624535
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:07.713247
# Unit test for function safe_eval
def test_safe_eval():
    # python 2.6
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    # python 2.7+
    else:
        import unittest

    # define our expected exceptions
    class TestException(Exception):
        pass

    class TestException2(Exception):
        pass


# Generated at 2022-06-21 07:55:19.147215
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr, exp_result):
        # Test without variables
        result = safe_eval(expr)
        assert result == exp_result, "Error evaluating '%s': expected %s, got %s" % (expr, exp_result, result)

        # Now test with variables
        locals = {'foo' : 'bar', 'bar' : 'foo'}
        result = safe_eval(expr, locals=locals)
        assert result == exp_result, "Error evaluating '%s': expected %s, got %s" % (expr, exp_result, result)
    def test_fail(expr, exp_exception):
        try:
            result = safe_eval(expr)
        except Exception as e:
            assert str(e) == exp_exception, "Error evaluating '%s': expected %s, got %s"

# Generated at 2022-06-21 07:55:26.731311
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    from collections import namedtuple
    test_set = namedtuple('test_set', ['input_string', 'expected_output'])
    # Runs test_sets, ensures that all of them evaluate to True
    # If some of them fail, prints the failing test_set and the error
    # message
    def run_tests(test_sets):
        for test_set in test_sets:
            try:
                result = safe_eval(test_set.input_string)
                assert result == test_set.expected_output
            except AssertionError as e:
                print("FAILED test_set", test_set)
                print("exception:", e)
                return False
        return True

    # Only the foll. items are permitted in

# Generated at 2022-06-21 07:55:38.851536
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:47.478942
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:00.271353
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('"a string"')
    assert result == "a string"
    result = safe_eval('42')
    assert result == 42
    result = safe_eval('6 * 7')
    assert result == 42

    result = safe_eval('a_dictionary["a_key"]')
    assert result == "a_string"
    result = safe_eval('a_dictionary["a_key"] + " plus some more"')
    assert result == "a_string plus some more"

    unsuccessful = False
    try:
        result = safe_eval('open("/tmp/foo")')
    except:
        unsuccessful = True
    assert unsuccessful == True

    unsuccessful = False
    try:
        result = safe_eval('"a_string"[3:4]')
    except:
        unsuccessful = True

# Generated at 2022-06-21 07:56:07.090829
# Unit test for function safe_eval
def test_safe_eval():

    def assert_exception(expr):
        x, e = safe_eval(expr, include_exceptions=True)
        assert e is not None

    def assert_success(expr, expected):
        x = safe_eval(expr)
        assert x == expected

    # basic types
    assert_success("True", True)
    assert_success("1", 1)
    assert_success("'junk'", "junk")
    assert_success("[1,2,3]", [1,2,3])
    assert_success("{1:'foo',2:'bar'}", {1:'foo',2:'bar'})

    # disallow functions
    assert_exception("list()")
    assert_exception("dict()")
    assert_exception("__import__('os').path")

    # allow list comprehensions


# Generated at 2022-06-21 07:56:15.068949
# Unit test for function safe_eval
def test_safe_eval():
    # Test (positive) value checks
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('1+2+3') == 6
    assert safe_eval('1-2') == -1
    assert safe_eval('1-2-3') == -4
    assert safe_eval('10/2') == 5
    assert safe_eval('1*2') == 2
    assert safe_eval('1*2*3') == 6
    assert safe_eval('1*2*3*4') == 24
    assert safe_eval('5*5') == 25

    assert safe_eval('true') is True
    assert safe_eval('TRUE') is True
    assert safe_eval('True') is True

    assert safe_eval('false') is False
    assert safe_eval

# Generated at 2022-06-21 07:56:25.096526
# Unit test for function safe_eval
def test_safe_eval():
    # test the safe_eval function without calling builtins
    expr = "my_list.pop()"
    #parse the expression into a tree
    t = ast.parse(expr, mode="eval")
    #compile the tree
    c = compile(t, "<string>", "exec")
    #eval the tree
    eval(c)

    # test the safe_eval function with calling builtins
    expr = "True"
    #parse the expression into a tree
    t = ast.parse(expr, mode="eval")
    #compile the tree
    c = compile(t, "<string>", "exec")
    #eval the tree
    eval(c)

# Unit tests for function safe_eval_lstrip

# Generated at 2022-06-21 07:56:33.308252
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2+2', include_exceptions=True) == (4, None)
    assert safe_eval('"foo" + "bar"', include_exceptions=True) == ('foobar', None)
    assert safe_eval('2*5', include_exceptions=True) == (10, None)
    assert safe_eval('abs(-99)', include_exceptions=True) == (99, None)
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('(1,2,3)', include_exceptions=True) == ((1, 2, 3), None)
    assert safe_eval('{"a": "b"}', include_exceptions=True) == ({'a': 'b'}, None)
   

# Generated at 2022-06-21 07:56:45.852622
# Unit test for function safe_eval
def test_safe_eval():

    class TestModule(object):
        def __init__(self, module_args, fail=False, fail2=False):
            self.params = module_args
            self.fail = fail
            self.fail2 = fail2

        def fail_json(self, msg):
            self.fail = True
            self.fail2 = True

    # first test the function that is being called, so that we know
    # that we can safely compare the results later

    # test non string types
    assert safe_eval(True)
    assert safe_eval(False)
    assert safe_eval(None)
    assert safe_eval(0)
    assert safe_eval(1)
    assert safe_eval(-1)
    assert safe_eval(-1.0)
    assert safe_eval(-1.0)

# Generated at 2022-06-21 07:56:55.360641
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:07.994812
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic functionality
    assert safe_eval('1+1') == 2
    # Test that adding a string to a number is invalid
    try:
        safe_eval('1+"a"')
        raise AssertionError
    except:
        pass
    # Test that we can safely lookup a value in a passed-in dictionary
    assert safe_eval('value', {'value': 2}) == 2
    # Test that we cannot break out of the safe_eval sandbox
    try:
        safe_eval('__builtins__["__import__"]("sys").modules["sys"].exit(0)')
        raise AssertionError
    except:
        pass
    # Test that we can add one string to another
    assert safe_eval('"a"+"b"') == 'ab'
    # Test that we can implicitly convert a string to

# Generated at 2022-06-21 07:57:17.330259
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:29.946171
# Unit test for function safe_eval
def test_safe_eval():
    # good test cases
    assert safe_eval("2 + 3 == 5") == True
    assert safe_eval("'a thing'") == 'a thing'
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("false") == False
    assert safe_eval("true") == True
    assert safe_eval("null") == None

# Generated at 2022-06-21 07:57:38.573825
# Unit test for function safe_eval
def test_safe_eval():

    # Make sure that we can perform basic calculations
    assert safe_eval('2+2') == 4
    assert safe_eval('2 + 2') == 4
    assert safe_eval('50 - 5*6') == 20
    assert safe_eval('(50 - 5*6) / 4') == 5.0
    assert safe_eval('8 / 5') == 1.6
    assert safe_eval('17 / 3') == 5.666666666666667
    assert safe_eval('17 % 3') == 2
    assert safe_eval('5 * 3 + 2') == 17

    # Make sure that we can use boolean operators
    assert safe_eval('True and False') is False
    assert safe_eval('True or False') is True
    assert safe_eval('not False') is True

    # Make sure that we can compare numbers

# Generated at 2022-06-21 07:57:50.411035
# Unit test for function safe_eval
def test_safe_eval():
    class TestObj(object):
        def __init__(self, a=0, b=0):
            self.a = a
            self.b = b

        def __add__(self, other):
            return TestObj(self.a + other.a, self.b + other.b)

        def __sub__(self, other):
            return TestObj(self.a - other.a, self.b - other.b)

    o = TestObj

# Generated at 2022-06-21 07:58:07.512423
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    sys.path.append("/tmp")
    try:
        import mock
    except ImportError:
        import unittest.mock as mock

    class TestSafeEval(object):
        '''
        The unit test class for safe_eval.
        '''

        # use this string literal to test safe_eval with a file that may not be present on
        # the target system, like a remote system with a different file system layout.
        TEST_FILE = '/tmp/test_safe_eval'

        def test_simple_expression(self):
            '''
            Test the most basic arithmetic expressions
            '''
            assert safe_eval("0+1") == 1
            assert safe_eval("0+1-1") == 0
            assert safe_eval("0+1*1") == 1

# Generated at 2022-06-21 07:58:18.394011
# Unit test for function safe_eval
def test_safe_eval():
    # originally used to just test template strings but now
    # used to also test complex literal strings
    assert safe_eval('{{ "abcd" }}') == 'abcd'
    assert safe_eval('{{ "abcd" }}', include_exceptions=True) == ('abcd', None)
    assert safe_eval('{{ 1 + 2 + 3 }}') == 6
    assert safe_eval('{{ "abcd" + "def" }}') == 'abcddef'
    assert safe_eval('{{ ansible_default_ipv4.address }}') == '10.0.2.15'
    assert safe_eval('{{ foo }}') == 'bar'
    assert safe_eval('{{ ansible_check_mode }}') == False

    # should not raise exception, even though we are using a variable named
    # 'list' below
    assert safe

# Generated at 2022-06-21 07:58:24.948449
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:37.000253
# Unit test for function safe_eval
def test_safe_eval():
    # Test with invalid expressions
    test_exprs = [
        "{{ foo }}",
        "{{ foo }} + {{ bar }}",
        "{% for x in y %} {{ foo }} {% endfor %}",
        "{{ foo.bar }}",
        "{{ foo.bar() }}",
        "{{ foo.bar.foo() }}"
    ]

    for expr in test_exprs:
        res, exc = safe_eval(expr, None, True)
        if res != expr or exc is None:
            print("Unexpected output for expr '%s': res='%s' exc=%s" % (expr, res, exc))
            sys.exit(1)

    # Test with valid expressions

# Generated at 2022-06-21 07:58:45.894285
# Unit test for function safe_eval
def test_safe_eval():

    # eval doesn't know about JSON types (case insensitive)

    assert safe_eval("False") is False
    assert safe_eval("true") is True
    assert safe_eval("null") is None

    # eval doesn't know about JSON types (as python constants)
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("None") is None

    # eval does know about Python types
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("None") is None
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("'foo'.upper()") == 'FOO'
    assert safe_eval("2 + 2") == 4

    # eval does know about lists

# Generated at 2022-06-21 07:58:57.460594
# Unit test for function safe_eval
def test_safe_eval():  # noqa
    '''
    Unit test for function safe_eval.
    '''

# Generated at 2022-06-21 07:59:08.184251
# Unit test for function safe_eval
def test_safe_eval():
    # Tests that the function safe_eval works as expected
    # Test 1: safe_eval: simple expressions
    if safe_eval('1+1') != 2:
        raise AssertionError("safe_eval: simple expressions: FAIL")
    if safe_eval('5-5') != 0:
        raise AssertionError("safe_eval: simple expressions: FAIL")
    if safe_eval('3*3') != 9:
        raise AssertionError("safe_eval: simple expressions: FAIL")
    if safe_eval('6/2') != 3:
        raise AssertionError("safe_eval: simple expressions: FAIL")
    if safe_eval('6//2') != 3:
        raise AssertionError("safe_eval: simple expressions: FAIL")

# Generated at 2022-06-21 07:59:17.446428
# Unit test for function safe_eval
def test_safe_eval():
    # success cases (no exception):
    safe_eval('a')
    safe_eval('a + b')
    safe_eval('[1,2]')
    safe_eval('"a"')
    safe_eval("''")
    safe_eval("'a'")
    safe_eval("'a' + ''")
    safe_eval("{}")
    safe_eval("[]")
    safe_eval("()")
    safe_eval("1")
    safe_eval("-1")
    safe_eval("1 + 1")
    safe_eval("1 - 1")
    safe_eval("1 * 1")
    safe_eval("1 / 1")
    safe_eval("1 - -1")

    # failure cases (exception):

# Generated at 2022-06-21 07:59:28.778640
# Unit test for function safe_eval
def test_safe_eval():
    # Test a basic expression
    result = safe_eval("{{ var1 + var2 }}", dict(var1=1, var2=2), True)
    if result != 3:
        raise AssertionError("eval() of var1 + var2 should be 3 but was %s" % result)

    # Test a boolean expression
    result = safe_eval("{{ True and False }}", dict(), True)
    if result != False:
        raise AssertionError("eval() of True and False should be False but was %s" % result)

    # Test a comparison
    result = safe_eval("{{ 1 == 1 }}", dict(), True)
    if result != True:
        raise AssertionError("eval() of 1 == 1 should be True but was %s" % result)

    # Test a call to the builtin any() function
    result

# Generated at 2022-06-21 07:59:37.239379
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("0") == 0
    assert safe_eval("\"str\"") == "str"
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("null") is None
    assert safe_eval("None") is None
    assert safe_eval("1+1") == 2
    assert safe_eval("2*2") == 4
    assert safe_eval("['one', 'two']") == ['one', 'two']
    assert safe_eval("['two', 'one']") == ['two', 'one']
    assert safe_eval("{'one':1, 'two':2}") == {'one': 1, 'two': 2}

# Generated at 2022-06-21 07:59:56.953030
# Unit test for function safe_eval
def test_safe_eval():
    # This is to prove that syntax errors will still be returned as strings
    # even though we are using the literal_eval() method above to parse them
    # This is to prevent jinja2 from returning a string that is then treated
    # as a python data structure (ie, a dictionary)
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    # This is to ensure that python data structures are returned as
    # native datastructures, and not strings
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    # This is to ensure that python data structures are returned as
    # native datastructures, and not strings
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    # This is to ensure that python data structures are returned as
   

# Generated at 2022-06-21 08:00:09.576547
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("'hi'") == 'hi'
    assert safe_eval("1+1") == 2
    assert safe_eval("1<2") == True
    assert safe_eval("1<2 and 1>2") == False
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("null") == None
    assert safe_eval("None") == None
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

# Generated at 2022-06-21 08:00:21.667320
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test for function safe_eval
    """
    def _test_safe_eval(expr, expected):
        """
        helper function for unit test
        :param expr: expression being tested
        :param expected: expected value after execution
        """
        if expected[0] is not None:
            assert safe_eval(expr) == expected[0]
        if expected[1] is not None:
            assert safe_eval(expr, include_exceptions=True) == expected

    # Test numeric values
    _test_safe_eval('1', (1, None))
    _test_safe_eval('1 + 1', (2, None))
    _test_safe_eval('1 - 1', (0, None))
    _test_safe_eval('1 * 1', (1, None))

# Generated at 2022-06-21 08:00:30.041069
# Unit test for function safe_eval
def test_safe_eval():
    # make sure a simple expression works
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar", dict(foo={'bar': 'baz'})) == "baz"

    # make sure expression evaluation works
    assert safe_eval("1+1") == 2
    assert safe_eval("2*3") == 6
    assert safe_eval("42") == 42
    assert safe_eval("[1,2,3]") == "[1,2,3]"
    assert safe_eval("[1,2,3]", dict(foo='[1,2,3]')) == [1,2,3]
    assert safe_eval("{'a': 'b'}") == "{'a': 'b'}"

# Generated at 2022-06-21 08:00:41.737322
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the safe_eval function
    '''
    # Test data

# Generated at 2022-06-21 08:00:51.904469
# Unit test for function safe_eval
def test_safe_eval():
    failures = []
