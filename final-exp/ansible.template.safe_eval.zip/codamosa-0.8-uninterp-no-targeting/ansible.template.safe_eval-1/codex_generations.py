

# Generated at 2022-06-21 07:51:09.470952
# Unit test for function safe_eval
def test_safe_eval():

    def test_data(res, passed, err):
        if passed:
            print("   PASSED: %s" % res)
        else:
            print(" ** FAILED: %s (%s)" % (res, err))

    # white-list conversion
    test_cases = [
        (1 + 3, 4),
        ("1 + 3", "1 + 3"),
        ("1 == 3", "1 == 3"),
        ("1 + 'foo'", "1 + 'foo'"),
        ("1.1 + 2.2", 3.3),
        ("'foo' is 'foo'", "'foo' is 'foo'"),
        ("'foo' not in ['bar', 'baz']", "'foo' not in ['bar', 'baz']")
    ]

# Generated at 2022-06-21 07:51:18.360826
# Unit test for function safe_eval
def test_safe_eval():
    locals = {}
    expr = '10 + 1'
    assert safe_eval(expr, locals=locals) == 11
    expr = '10 + 1.0'
    assert safe_eval(expr, locals=locals) == 11.0
    expr = '10 + true'
    assert safe_eval(expr, locals=locals) == 11
    expr = 'false'
    assert not safe_eval(expr, locals=locals)
    expr = 'null'
    assert None is safe_eval(expr, locals=locals)
    expr = '(10, 20, 30)'
    assert (10, 20, 30) == safe_eval(expr, locals=locals)
    expr = '["one", "two", "three"]'

# Generated at 2022-06-21 07:51:25.846833
# Unit test for function safe_eval
def test_safe_eval():
    # test Python SyntaxError
    # expr = '\n'
    # result, error = safe_eval(expr, include_exceptions=True)
    # assert error is not None  # TODO: This test fails in Python 3.6
    # assert result == "\n"

    # test Python Exception
    expr = 'import os'
    result, error = safe_eval(expr, include_exceptions=True)
    assert error is not None
    assert result == expr

    # test JSON SyntaxError
    expr = '{a}'
    result, error = safe_eval(expr, include_exceptions=True)
    assert error is not None
    assert result == expr

    # test safe
    expr = '{a: 1}'
    result, error = safe_eval(expr, include_exceptions=True)

# Generated at 2022-06-21 07:51:38.448933
# Unit test for function safe_eval
def test_safe_eval():

    def re(expr, expected):
        if expected is not None:
            expected = to_native(expected)
        try:
            tval = "to" + "text"  # avoid pyflakes warning
            actual = eval(expr)
        except Exception as e:
            actual = "EXCEPTION"
        try:
            tval = "to" + "text"  # avoid pyflakes warning
            safe = safe_eval(expr, include_exceptions=True)
            if safe[1] is not None:
                raise safe[1]
            else:
                safe = safe[0]
        except Exception as e:
            safe = "EXCEPTION"


# Generated at 2022-06-21 07:51:47.200763
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('3 + 5') == 8
    assert safe_eval('3 - 5') == -2
    assert safe_eval('3 * 5') == 15
    assert safe_eval('25 / 5') == 5
    assert safe_eval('-25') == -25
    assert safe_eval('2 ** 7') == 128
    assert safe_eval('1 < 5') is True
    assert safe_eval('6 > 2') is True
    assert safe_eval('2 == 2') is True
    assert safe_eval('1 <= 5') is True
    assert safe_eval('6 >= 2') is True
    assert safe_eval('2 != 2') is False
    assert safe_eval('1 and 4') == 4
    assert safe_eval('0 and 4') == 0
    assert safe_eval('0 or 4') == 4
    assert safe

# Generated at 2022-06-21 07:51:58.592057
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Spot check some samples - could be fleshed out to cover more cases
    '''
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 < 1') == False
    assert safe_eval('1 < 2') == True
    assert safe_eval('2 < 1') == False
    assert safe_eval('1 <= 1') == True
    assert safe_eval('1 <= 2') == True
    assert safe_eval('2 <= 1') == False
    assert safe_eval

# Generated at 2022-06-21 07:52:11.645286
# Unit test for function safe_eval
def test_safe_eval():
    #print("CALL_ENABLED: %s" % CALL_ENABLED)
    expr = "string"
    val = safe_eval(expr)
    assert val == expr
    expr = "str(string)"
    val = safe_eval(expr)
    assert val == expr
    expr = "True"
    val = safe_eval(expr)
    assert val is True
    expr = "1 > 1"
    val = safe_eval(expr)
    assert val is False
    # note: python2.6 does not have assertRaisesRegexp
    try:
        val = safe_eval('1 + [1, 2]')
        assert False, "should have thrown an exception"
    except Exception:
        pass

# Generated at 2022-06-21 07:52:20.968452
# Unit test for function safe_eval
def test_safe_eval():
    # can convert strings to native types
    assert("string" == safe_eval("string"))

    # can convert ints to native types
    assert(1 == safe_eval("1"))

    # can convert floats to native types
    assert(2.2 == safe_eval("2.2"))

    # can convert booleans to python booleans
    assert(True is safe_eval("True"))

    # can convert null to python None types
    assert(None is safe_eval("null"))

    # simple addition is ok
    assert(2 == safe_eval("1 + 1"))

    # simple subtraction is ok
    assert(1 == safe_eval("2 - 1"))

    # simple multiplication is ok
    assert(5 == safe_eval("5 * 1"))

    # simple division is ok

# Generated at 2022-06-21 07:52:32.165222
# Unit test for function safe_eval
def test_safe_eval():
    # pylint: disable=unused-variable,too-many-branches, too-many-statements, protected-access, invalid-name
    from ast import Num, Name, UnaryOp, USub, Expression, Dict, Str, Load, Add
    from ansible.module_utils.common.text.converters import to_native

    # setup Call node type to allow easy construction of AST tree
    try:
        # Call node exists in python3
        from ast import Call
        call_enabled = True
    except:
        # fake version of Call node (for python2)
        import builtins
        print("WARNING: Call node not available, so safe_eval() unit test may be incomplete")
        class _Call(object):
            pass
        Call = _Call

    # setup module globals used by safe_eval
    global CALL_

# Generated at 2022-06-21 07:52:39.958616
# Unit test for function safe_eval
def test_safe_eval():
    # They should work
    assert 1 == safe_eval("1")
    assert True is safe_eval("True")
    assert False is safe_eval("False")
    assert 1 == safe_eval("True+False")
    assert 1 == safe_eval("True+0")
    assert 1 == safe_eval("True*1")
    assert -1 == safe_eval("-True*1")
    assert 0 == safe_eval("0*True")
    assert False is safe_eval("(True is not True)")
    assert 0 == safe_eval("True*0")
    assert -1 == safe_eval("-True*1")
    assert 0 == safe_eval("0*True")
    assert True is safe_eval("(True is True)")
    assert False is safe_eval("(True is False)")
    assert False is safe_

# Generated at 2022-06-21 07:52:55.537079
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:03.178938
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:15.711330
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, result):
        got = safe_eval(expr)
        if got != result:
            raise AssertionError("%s => %s != %s" % (expr, got, result))
        # now make sure that indentation is ignored
        got = safe_eval(expr + "    ")
        if got != result:
            raise AssertionError("%s => %s != %s" % (expr + "    ", got, result))
        # now make sure that trailing whitespace is ignored
        got = safe_eval(expr + " ")
        if got != result:
            raise AssertionError("%s => %s != %s" % (expr + " ", got, result))

    _test('1', 1)
    _test('-1', -1)

# Generated at 2022-06-21 07:53:25.864824
# Unit test for function safe_eval
def test_safe_eval():

    # invalid expression
    expr = "a + b - c"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr
    assert exception is not None

    # list
    expr = "[1, 2, 3]"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == [1, 2, 3]
    assert exception is None

    # list using int
    expr = "[int(item_num) for item_num in range(1, 4)]"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == [1, 2, 3]
    assert exception is None

    # list using int function imported from __builtins__

# Generated at 2022-06-21 07:53:38.381121
# Unit test for function safe_eval
def test_safe_eval():
    # Test for safe_eval function
    # https://github.com/ansible/ansible/pull/14947
    value = {"key": "value"}
    assert safe_eval('value'), "safe_eval('value') True"
    assert safe_eval('False'), "safe_eval('False') True"
    assert safe_eval('None'), "safe_eval('None') True"
    assert safe_eval('(True, False, None)'), "safe_eval('(True, False, None)') True"
    assert safe_eval("value['key']"), "safe_eval(\"value['key']\") True"
    assert safe_eval("value['key'] and True"), "safe_eval(\"value['key'] and True\") True"
    assert safe_eval("{}"), "safe_eval(\"{}\") True"


# Generated at 2022-06-21 07:53:48.301714
# Unit test for function safe_eval
def test_safe_eval():
    our_locals = {
        'a_list_variable': [1, 2, 3],
        'a_string': 'string',
        'another_list': ['apple', 'banana', 'cherry'],
        'a_int': 15,
        'a_float': 14.75,
        'a_dict': {'a': 1, 'b': 2, 'c': 3, 'd': 4},
        'a_dict2': {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]},
        'null_val': None,
        'a_set': set(['a', 'b', 'c', 'd']),
        'complex_var': None
    }


# Generated at 2022-06-21 07:53:58.855660
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:09.759229
# Unit test for function safe_eval
def test_safe_eval():
    # These should fail
    assert safe_eval('True = False') == 'True = False'
    assert safe_eval('__import__("sys").exit(1)') == '__import__("sys").exit(1)'
    assert safe_eval('abs') == 'abs'
    assert safe_eval('abs()') == 'abs()'
    assert safe_eval('abs(a=0)') == 'abs(a=0)'
    assert safe_eval('1()') == '1()'

    # These should pass
    assert safe_eval('abs(1)') == 1
    assert safe_eval('abs(-1)') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a_string') == 'a_string'

# Generated at 2022-06-21 07:54:17.594063
# Unit test for function safe_eval
def test_safe_eval():
    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

    def test_pass(result, except_str):
        assert result
        assert except_str is None

    def test_fail(result, except_str):
        assert result is None
        assert except_str

    # test integer
    result, except_str = safe_eval("1234567890", include_exceptions=True)
    test_pass(result, except_str)
    assert isinstance(result, int)

    # test float
    result, except_str = safe_eval("1.0", include_exceptions=True)
    test_pass(result, except_str)

# Generated at 2022-06-21 07:54:28.173253
# Unit test for function safe_eval
def test_safe_eval():
    test_ok = True
    if 'pytest' in sys.modules:
        test_ok = False
        import pytest
        if hasattr(pytest, 'mark'):
            test_ok = True

    if test_ok:
        def test_ok_expr(expr, value, locals=None):
            our_locals = locals.copy() if locals else {}
            our_locals['include_exceptions'] = True
            result, exc = safe_eval(expr, our_locals)
            if exc:
                pytest.fail("Error running safe_eval on '%s': %s" %
                            (expr, to_native(exc)))
            assert value == result

        def test_fail_expr(expr):
            result, exc = safe_eval(expr, {'include_exceptions': True})

# Generated at 2022-06-21 07:54:53.425167
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestSafeEval(unittest.TestCase):
        def setUp(self):
            # enable all builtins for testing
            global CALL_ENABLED
            CALL_ENABLED = dir(builtins)


# Generated at 2022-06-21 07:55:00.873122
# Unit test for function safe_eval
def test_safe_eval():
    fails = 0
    if len(sys.argv) > 1 and sys.argv[1] == '-v':
        verbose = True
    else:
        verbose = False
    # Test data to pass to safe_eval
    # tuple of inputs, expected result, exception flag

# Generated at 2022-06-21 07:55:13.229748
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:23.624890
# Unit test for function safe_eval
def test_safe_eval():
    # Test with 'CALL_ENABLED'
    CALL_ENABLED.append('len')
    # simple expressions
    assert safe_eval('5') == 5
    assert safe_eval('5 + 5') == 10
    assert safe_eval('10 - 5') == 5
    assert safe_eval('-10') == -10
    assert safe_eval('(5 + 10) * 2') == 30
    assert safe_eval('10 / 2') == 5
    assert safe_eval('10 // 2') == 5
    assert safe_eval('2 * 10 // 4') == 5
    # constants
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    # types
    assert safe_eval('bool(10)') is True

# Generated at 2022-06-21 07:55:35.176216
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is not a real unit test: just run it in the interpreter
    and make sure it doesn't throw any exceptions.
    '''

    # when we're testing, we want it to raise exceptions
    include_exceptions = True
    syntax_error = False

    def test(expression, expected, locals=None):
        locals = {} if locals is None else locals
        print()
        print("Evaluating: %s" % to_native(expression))
        result, exception = safe_eval(expression, locals=locals, include_exceptions=include_exceptions)
        print("Evaluated: %s" % container_to_text(result))
        print("Expected: %s" % to_native(expected))
        print("Exception: %s" % to_native(exception))
        assert result == expected

   

# Generated at 2022-06-21 07:55:45.508511
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("['a', 'b'] + ['c', 'd']")
    assert result == ['a', 'b', 'c', 'd']

    result = safe_eval("a_list_variable")
    assert result == 'a_list_variable'

    result = safe_eval("a_list_variable", dict(a_list_variable=['a', 'b']))
    assert result == ['a', 'b']

    result = safe_eval("['a', 'b'] if True else ['c', 'd']")
    assert result == ['a', 'b']

    result = safe_eval("['a', 'b'] if False else ['c', 'd']")
    assert result == ['c', 'd']

    result = safe_eval("['a', 'b'] if True")

# Generated at 2022-06-21 07:55:58.319752
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    # test simple values
    assert safe_eval('1', {}, True)[0] == 1
    assert safe_eval('2.0', {}, True)[0] == 2.0
    assert safe_eval('3.14', {}, True)[0] == 3.14
    assert safe_eval('"hello"', {}, True)[0] == 'hello'
    assert safe_eval('"hello" + " " + "world"', {}, True)[0] == 'hello world'
    assert safe_eval('["a", "b"]', {}, True)[0] == ['a', 'b']

# Generated at 2022-06-21 07:56:06.333683
# Unit test for function safe_eval
def test_safe_eval():

    def test_failure(expr):
        try:
            safe_eval(expr)
        except Exception as e:
            if C.DEFAULT_DEBUG:
                print("successfully caught Illegal expression: %s\n" % e)
            return True
        raise Exception("UNEXPECTED EXCEPTION: %s" % expr)

    # test for invalid expressions

# Generated at 2022-06-21 07:56:18.475724
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:28.668138
# Unit test for function safe_eval
def test_safe_eval():
    # enable builtin functions call
    global CALL_ENABLED
    CALL_ENABLED = [
        'bool', 'dict', 'enumerate', 'float', 'int', 'len', 'list', 'max',
        'min', 'range', 'reversed', 'set', 'sorted', 'tuple', 'zip'
    ]

    # good expressions

# Generated at 2022-06-21 07:56:47.265895
# Unit test for function safe_eval
def test_safe_eval():
    expr = '1 + 2 + [3,4]'
    expr_result = safe_eval(expr)
    assert expr_result == '1 + 2 + [3,4]'

    expr = '1 + 2 + (3 * 4)'
    expr_result = safe_eval(expr)
    assert expr_result == 11



# Generated at 2022-06-21 07:56:52.947034
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, expected, locals=None):
        result = safe_eval(expr, locals=locals)
        assert result == expected

    _test("'one' + 'two'", 'onetwo')
    _test("['one', 'two', 'three'][2]", 'three')
    _test("{'foo':'bar', 'baz':'quux'}", {'foo': 'bar', 'baz': 'quux'})
    _test("['one', 'two', 'three'][2]", 'three')
    _test("{'name': 'foo', 'data': True}", {'name': 'foo', 'data': True})
    _test("['one', 'two', 'three'][2]", 'three')

# Generated at 2022-06-21 07:57:03.884498
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:13.601418
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate a Python expression of the input string
    # Test safe_eval() where expression is a Python string
    (result, exception) = safe_eval('mydict.get("localhost", "127.0.0.1")',
                                    {"mydict": {"localhost": "::1"}},
                                    True)
    assert result == "::1"
    assert exception == None

    # Test safe_eval() where expression is a non-string
    (result, exception) = safe_eval(['foo', 'bar'], {}, True)
    assert result == ['foo', 'bar']
    assert exception == None

    # Test safe_eval where expression is a syntax error
    (result, exception) = safe_eval('my_missing_variable', {}, True)
    assert result == 'my_missing_variable'

# Generated at 2022-06-21 07:57:26.293062
# Unit test for function safe_eval
def test_safe_eval():
    '''
    safe_eval function unit test
    :return:
    '''

    # simple test that checks the expected generated ast tree
    def test_ast(input_string, expected_tree):
        # Remove any leading whitespace from input_string to avoid
        # confusing the parser
        input_string = input_string.lstrip()
        parsed_tree = ast.parse(input_string, mode='eval')
        assert parsed_tree == expected_tree

    test_ast(
        '1 + 1',
        ast.Expression(
            ast.BinOp(
                ast.Num(1),
                ast.Add(),
                ast.Num(1)
            )
        )
    )


# Generated at 2022-06-21 07:57:36.680687
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_native

    # Test function calls
    assert safe_eval('to_native("foo")') == 'foo'
    assert safe_eval('to_native("foo", encoding="ascii")') == 'foo'
    assert safe_eval('to_native("foo", errors="strict")') == 'foo'
    assert safe_eval('to_native("foo", nonstring="simplerepr")') == 'foo'
    assert safe_eval('to_native("foo", nonstring="empty")') == 'foo'
    assert safe_eval('to_native("foo", nonstring="passthru")') == 'foo'

    assert safe_eval('container_to_text("foo")') == 'foo'

# Generated at 2022-06-21 07:57:49.399159
# Unit test for function safe_eval
def test_safe_eval():
    expr = '{"foo": "bar", "baz": "qux"}'
    res, err = safe_eval(expr, include_exceptions=True)
    assert res == {"foo": "bar", "baz": "qux"}
    assert err is None

    expr = '{"foo": "bar", "baz": "qux"}'
    res = safe_eval(expr)
    assert res == {"foo": "bar", "baz": "qux"}

    expr = '["foo", "bar", "baz"]'
    res = safe_eval(expr)
    assert res == ["foo", "bar", "baz"]

    expr = '1 + 2 + 5'
    res = safe_eval(expr)
    assert res == 8

    expr = '1 + 2 + foo'

# Generated at 2022-06-21 07:57:57.516973
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This function tests safe_eval using assert_equals
    '''
    # Try and load the test function
    try:
        from nose.tools import assert_equals
    except ImportError as e:
        # If the import fails, it just means we're not running the tests
        return

    # This is some data that we'll use in our tests.

# Generated at 2022-06-21 07:58:09.555289
# Unit test for function safe_eval
def test_safe_eval():
    global CALL_ENABLED

    CALL_ENABLED.append('str')
    CALL_ENABLED.append('int')

    # test cases of expressions we expect to succeed
    assert safe_eval("1 + 1") == 1 + 1
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 1 + 1
    assert safe_eval("2 * 3") == 2 * 3
    assert safe_eval("3 / 2") == 3 / 2
    assert safe_eval("-5") == -5
    assert safe_eval("5 + -5") == 5 + -5
    assert safe_eval("1 + 1 == 2") == 1 + 1 == 2
    assert safe_eval("(1 + 1)", include_exceptions=True)[0] == (1 + 1)
    assert safe_eval("str('hello')")

# Generated at 2022-06-21 07:58:19.366064
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:58.231399
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("'foo'+'bar'") == 'foobar'
    assert safe_eval("dict(foo='bar')") == {'foo': 'bar'}

    assert safe_eval("[1,2,3,4]", include_exceptions=True)[0] == [1, 2, 3, 4]
    assert safe_eval("'foo'+'bar'", include_exceptions=True)[0] == 'foobar'
    assert safe_eval("dict(foo='bar')", include_exceptions=True)[0] == {'foo': 'bar'}

    assert safe_eval("[1,2,3]", include_exceptions=True)[1] is None

# Generated at 2022-06-21 07:59:01.775484
# Unit test for function safe_eval
def test_safe_eval():
    # no exception, so ok
    v = safe_eval('[1,2,3]')
    assert v == [1, 2, 3], v
    v = safe_eval('{ "a": 1, "b": 2 }')
    assert v == { "a": 1, "b": 2 }, v
    v = safe_eval('["a", "b"] + ["c", "d"]')
    assert v == ["a", "b", "c", "d"], v
    # jinja2 allows non-ascii in variable expressions, so we do, too
    if sys.version_info < (3, 0):
        v = safe_eval(u'["\u20ac"]')
        assert v == [u"\u20ac"], v

    # exceptions

# Generated at 2022-06-21 07:59:10.664948
# Unit test for function safe_eval
def test_safe_eval():
    def _test_safe_eval(expression, expected_result=None, expected_failure=False):
        if expected_failure:
            result, exception = safe_eval(expression, include_exceptions=True)
            if exception is None:
                raise AssertionError("Expected failure, but no exception was raised")
        else:
            result = safe_eval(expression)
            exception = None

        if result != expected_result:
            raise AssertionError("Expected result to be %s but got %s" % (expected_result, result))

    # A bunch of expressions that do not pass our test

# Generated at 2022-06-21 07:59:20.986159
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validate safe_eval behavior
    '''
    # Test valid input
    results = safe_eval('[1, 2, 3]')
    assert isinstance(results, list)
    assert results == [1, 2, 3]

    results = safe_eval('{"a": 1, "b": 2, "c": 3}')
    assert isinstance(results, dict)
    assert results == {"a": 1, "b": 2, "c": 3}

    results = safe_eval('a == 1 or b == 2 or c == 3 or d == 4',
                        locals={"a": 1, "b": 2, "c": 3, "d": 4})
    assert isinstance(results, bool)
    assert results


# Generated at 2022-06-21 07:59:32.164622
# Unit test for function safe_eval
def test_safe_eval():
    # Test with valid expressions, then test with invalid expressions
    valid_expressions = (
        "['foo', 'bar']",
        "'foo'",
        "dict(foo='bar')",
        "1.0",
        "1",
        "1+2",
        "len(['foo'])",
        "['foo', 'bar'][0]",
    )

    invalid_expressions = (
        "open(file)",
        "import os",
        "locals()",
        "__import__('os').getcwd()",
        "__import__('subprocess').Popen(['echo', 'hi'])",
        "a['foo']",
        "dict['foo']",
        "set['foo']",
        "a['foo'][0]["
    )



# Generated at 2022-06-21 07:59:39.006383
# Unit test for function safe_eval
def test_safe_eval():
    test_hash = '{ "a": 1, "b": 2 }'
    test_list = '[1,2,3,4]'
    test_stripped_hash = '{{{ "a": 1, "b": 2 }}}'
    test_stripped_list = '[{{1}},2,{{3}},4]'
    test_stripped_string = "the string"
    test_string = "the string"

    h = safe_eval(test_hash)
    assert isinstance(h, dict)
    assert h['a'] == 1

    l = safe_eval(test_list)
    assert isinstance(l, list)
    assert l[0] == 1

    h = safe_eval(test_stripped_hash)
    assert isinstance(h, dict)
    assert h['a'] == 1



# Generated at 2022-06-21 07:59:51.154375
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:59.143316
# Unit test for function safe_eval
def test_safe_eval():
    # Can parse a tuple
    test_str = '("foo","bar")'
    test_eval = safe_eval(test_str)
    assert isinstance(test_eval, tuple)
    assert len(test_eval) == 2

    # Can parse a list
    test_str = "['foo','bar']"
    test_eval = safe_eval(test_str)
    assert isinstance(test_eval, list)
    assert len(test_eval) == 2

    # Can parse a dict
    test_str = "{'foo':'bar'}"
    test_eval = safe_eval(test_str)
    assert isinstance(test_eval, dict)
    assert len(test_eval) == 1

    # Can parse a dict
    test_str = "dict(foo='bar')"
    test_eval = safe

# Generated at 2022-06-21 08:00:10.695675
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('string') == 'string'
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('{"foo": "bar", "dog": "cat"}') == {"foo": "bar", "dog": "cat"}
    assert safe_eval('{"foo": {"cat": "dog", "horse": "cow"}}') == {"foo": {"cat": "dog", "horse": "cow"}}
    assert safe_eval('null') == None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('["foo", "{{ bar }}"]') == ["foo", "{{ bar }}"]

# Generated at 2022-06-21 08:00:23.143127
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:49.538051
# Unit test for function safe_eval
def test_safe_eval():
    # Expression with all allowed AST nodes
    expr = '''
    a = [1, 2, 3]
    b = {'a': 1, 'b': 2, 'c': 3}
    c = ('x', 'y', 'z')
    d = True
    e = False
    f = 'foobar'
    g = 1
    h = -1
    i = 1.1
    j = -1.1
    k = 1 + 2
    l = 1 * 2
    m = 1 - 2
    n = 1 / 2
    o = 1 // 2
    p = 1 % 2
    q = 1 ** 2
    r = 1 << 2
    s = 1 >> 2
    t = 1 & 2
    u = 1 | 2
    v = 1 ^ 2
    '''
    safe_eval(expr)



# Generated at 2022-06-21 08:00:58.818124
# Unit test for function safe_eval
def test_safe_eval():
    tests = dict(
        test_pass='true',
        test_fail='__import__("sys").exit(1)',
        test_pass_dict='{"foo": "bar"}',
        test_pass_jinja='items | map("extract", hostvars[inventory_hostname]) | list | sum',
        test_pass_underscore='my_list | sum(attribute="value")',
        test_fail_function='my_list | nonexistent(attribute="value")',
    )

    for test in tests:
        result, exception = safe_eval(tests[test], {'my_list': [{'value': 2}, {'value': 4}]}, True)
        if exception:
            raise exception

