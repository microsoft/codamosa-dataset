

# Generated at 2022-06-21 07:51:03.807618
# Unit test for function safe_eval
def test_safe_eval():
    assert (safe_eval('a_list_variable', dict(
        a_list_variable=['foo', 'bar'],
        a_string="cheese",
        a_bool=False,
        a_none=None,
        a_num=1,
        a_dict={'foo': 'bar'},
    )) == ['foo', 'bar'])

    # should also work for dicts
    assert safe_eval('a_dict', dict(
        a_dict={'foo': 'bar'},
    )) == {'foo': 'bar'}

    # just a string is ok
    assert safe_eval('a_string', dict(
        a_dict={'foo': 'bar'},
        a_string="cheese",
    )) == "cheese"

    # the number 1 is ok
    assert safe_eval

# Generated at 2022-06-21 07:51:15.406165
# Unit test for function safe_eval
def test_safe_eval():
    """
    For each test case, the dict contains:
        'input' : the input to test
        'output' : the expected output
        'raises' : the exception (if any) that the input should raise
    """

# Generated at 2022-06-21 07:51:27.130459
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:39.813743
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:47.988424
# Unit test for function safe_eval
def test_safe_eval():

    # all of these should pass
    expressions = [
        "1",
        "1 + 1",
        "1 * 2 + 3 * 4",
        "1 * ( 2 + 3 ) * 4",
        "1 * 2 ** 3 * 4",
        "[1,2,'3']",
        "[1,2,['3']]",
        "dict(a=1)",
        "{'a': '123', 'b': 456}",
    ]
    for expr in expressions:
        assert safe_eval(expr, include_exceptions=True) == (safe_eval(expr), None)

    # all of these should fail

# Generated at 2022-06-21 07:51:59.219838
# Unit test for function safe_eval
def test_safe_eval():
    # functions we want to enable calling
    FUNCS = {
        'range': range,
        'len': len
    }

# Generated at 2022-06-21 07:52:12.223488
# Unit test for function safe_eval
def test_safe_eval():
    # Note: these tests rely on the behaviour of safe_eval() as it is
    # currently implemented.  If it changes, that is not necessarily bad,
    # but these tests may need to be updated.
    assert 'foo' == safe_eval('foo')
    assert 'abcd' == safe_eval('a + b + c + d', dict(a='a', b='b', c='c', d='d'))
    assert 'abcdefgh' == safe_eval('a + b + c + d + e + f + g + h',
                                   dict(a='a', b='b', c='c', d='d', e='e', f='f', g='g', h='h'))

# Generated at 2022-06-21 07:52:18.208124
# Unit test for function safe_eval
def test_safe_eval():

    # test safe_eval for good expressions
    assert safe_eval('"string"') == 'string'
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None

    # test safe_eval for bad expressions
    if C.DEFAULT_DEBUG:
        try:
            safe_eval('import os; os.system("echo hello")')
            assert False
        except Exception as e:
            if not isinstance(e, SyntaxError):
                assert True

    try:
        safe_eval('"string')
        assert False
    except Exception as e:
        assert isinstance(e, SyntaxError) or isinstance(e, ValueError)


# Generated at 2022-06-21 07:52:28.777898
# Unit test for function safe_eval
def test_safe_eval():
    '''
    There should be an exception, as this is an invalid expression
    '''
    invalid_expr_1 = "a + b + 'c'"
    invalid_expr_2 = "a + (b - c)"
    invalid_expr_3 = "os.path.join('abc', 'def')"
    invalid_expr_4 = "1 + true"
    invalid_expr_5 = "a + [1,2,3]"

    valid_expr_1 = "1 + 2"
    valid_expr_2 = "a + b"
    valid_expr_3 = "a + b + 'c'"
    valid_expr_4 = "a + (b + 'c')"
    valid_expr_5 = "a + [1,2,3]"

    assert safe_eval(valid_expr_1) == 3


# Generated at 2022-06-21 07:52:38.399518
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:52.683058
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, expect, locals=None, include_exceptions=False):
        result = safe_eval(expr, locals, include_exceptions)
        print("TESTING: %s => %s" % (expr, expect))
        if isinstance(expect, Exception):
            assert isinstance(result, tuple)
            assert isinstance(result[1], expect.__class__)
        else:
            assert result == expect

    _test('foo', 'foo')
    _test('foo[0]', 'foo[0]')
    _test('{{ foo }}', '{{ foo }}')
    _test('[1, 2]', [1, 2])
    _test('[1, 2, 3] | count', 3)
    _test('1 + 1', 2)
    _test('1 + 1', 2)

# Generated at 2022-06-21 07:53:01.781845
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test of safe_eval.

    :return:
    """
    # Allowed
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1", include_exceptions=True)[0] == 2
    assert safe_eval("dict(changed=True)") == dict(changed=True)
    assert safe_eval("1+1", locals=dict(a=1)) == 2
    assert safe_eval("a+1", locals=dict(a=1)) == 2
    assert safe_eval("a.append(1)", locals=dict(a=[])) == None
    assert safe_eval("a.append(1)", locals=dict(a=[]), include_exceptions=True)[0] == None
    assert safe_eval("'foo' in a", locals=dict(a=['foo']))

# Generated at 2022-06-21 07:53:14.118517
# Unit test for function safe_eval
def test_safe_eval():

    # test with a JSON-style data structure
    expr = '{ foo: "bar", baz: null, true: false, false: true, null: false, none: false }'
    result = safe_eval(expr)
    assert isinstance(result, dict)
    assert result == {'foo': 'bar', 'baz': None, 'true': False, 'false': True, 'null': False, 'none': False}

    # test with a simple arithmetic expression
    expr = '0.5 + 0.5'
    result = safe_eval(expr)
    assert isinstance(result, float)
    assert result == 1.0

    # test with expression calling a math function
    expr = 'math.factorial(10)'
    result = safe_eval(expr)
    assert isinstance(result, int)
    assert result == 36

# Generated at 2022-06-21 07:53:25.164295
# Unit test for function safe_eval
def test_safe_eval():
    # Basic functionality
    assert safe_eval("1 + 1") == 2

    # Variable substitution
    assert safe_eval("a + 1", locals={'a': 2}) == 3

    # Variable substitution with complex variable
    assert safe_eval("d['foo']", locals={'d': {'foo': 'bar'}}) == 'bar'

    assert safe_eval("a[0]", locals={'a': [1, 2, 3]}) == 1

    # Valid tuples
    assert safe_eval("(1, 2)") == (1, 2)

    # A few basic compares
    assert safe_eval("a == 2", locals={'a': 2})

    assert safe_eval("a <= 2", locals={'a': 2})

    assert safe_eval("a < 2", locals={'a': 1})

    assert safe_eval

# Generated at 2022-06-21 07:53:37.690407
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:47.697434
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{ foo }}"
    result = safe_eval(expr)
    assert expr == result

    expr = "{{ foo | default(1) }}"
    result = safe_eval(expr)
    assert expr == result

    expr = "['a', 'b']"
    result = safe_eval(expr)
    assert result == ['a', 'b']

    expr = "{'a': 1, 'b': 2}"
    result = safe_eval(expr)
    assert result == {'a': 1, 'b': 2}

    expr = "[1, 2]"
    result = safe_eval(expr)
    assert result == [1, 2]

    expr = "{1: 1, 2: 2}"
    result = safe_eval(expr)
    assert result == {1: 1, 2: 2}


# Generated at 2022-06-21 07:53:57.916539
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    failed = False

    # Since this is a unit test and we are running in the same python
    # process as the code being tested, this test must run after
    # CleansingNodeVisitor is defined, since it uses it as a class in
    # its ast.NodeVisitor subclass
    if sys.version_info[0] < 3:
        # Python 2.x requires the following:
        safe_eval('u"foo"')
        safe_eval('u"foo"') == u'foo'
        safe_eval('b"foo"')
        safe_eval('b"foo"') == 'foo'
        safe_eval('bytes([99, 111, 110, 115, 116])') == 'const'

# Generated at 2022-06-21 07:54:09.014039
# Unit test for function safe_eval
def test_safe_eval():
    # These asserts test the safe_eval() function
    # only for functionality that is actually used within Ansible.
    #
    # The tests are not comprehensive; see the referenced link for
    # a comprehensive test suite.

    # References:
    #   https://github.com/asottile/safe_eval/blob/master/tests/test_safe_eval.py
    #   https://github.com/asottile/safe_eval

    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    assert safe_eval('2 + 3') == 5
    assert safe_eval('10 - 2') == 8

# Generated at 2022-06-21 07:54:17.108921
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:27.293274
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test that invalid syntax and expressions raise an exception
    '''
    # Syntax errors are not caught
    assert safe_eval('{{', {}) == '{{'
    assert safe_eval('{%', {}) == '{%'
    assert safe_eval('foo', {}) == 'foo'
    assert safe_eval('foo', {}, include_exceptions=True) == ('foo', None)
    assert safe_eval('"a string" + 2', {}) == '"a string" + 2'
    assert safe_eval('"a string" + 2', {}, include_exceptions=True) == ('"a string" + 2', None)

    # All nodes in SAFE_NODES should be allowed

# Generated at 2022-06-21 07:54:42.281722
# Unit test for function safe_eval
def test_safe_eval():
    bad_expr = "foo(bar)"
    good_expr = "foo('bar')"
    bad_expr_tree = ast.parse(bad_expr, mode='eval')
    good_expr_tree = ast.parse(good_expr, mode='eval')
    builtins.foo = lambda x: "foo({0})".format(x)

    # make sure good_expr is allowed in safe_eval()
    assert safe_eval(good_expr, include_exceptions=True)[0] == "foo('bar')"

    # confirm that bad_expr_tree is invalid and raises an exception
    assert good_expr_tree is not None
    try:
        CleansingNodeVisitor().visit(bad_expr_tree)
        assert False, "did not raise an exception"
    except Exception as e:
        pass

    # confirm

# Generated at 2022-06-21 07:54:54.621823
# Unit test for function safe_eval
def test_safe_eval():
    # Test safe
    test_tree = safe_eval("['hello', 'world']")
    if isinstance(test_tree, list) and len(test_tree) == 2 and test_tree[0] == 'hello':
        print("Success")
    # Test safe
    test_tree = safe_eval("{'foo': 'bar'}")
    if isinstance(test_tree, dict) and len(test_tree) == 1 and list(test_tree.keys())[0] == 'foo':
        print("Success")
    # Test unsafe
    test_tree = safe_eval("__import__('sys').exit(1)")
    if test_tree == "__import__('sys').exit(1)":
        print("Success")
    else:
        print("Fail")
    # Test with_items
    test_tree

# Generated at 2022-06-21 07:55:05.826302
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    # valid syntax, safe for eval
    expr = "foo == 'bar' or foo == 'baz'"
    assert safe_eval(expr) == expr

    # syntax error, ignored, but not safe
    expr = "foo == bar baz"
    assert safe_eval(expr) == expr

    # not valid python, not safe
    expr = "foo(bar='baz')"
    assert safe_eval(expr) == expr

    # valid python, but not safe as using a non-whitelisted identifier
    expr = "foo.upper()"
    assert safe_eval(expr) == expr

    # valid python, but not safe as calling an in-built function
    expr = "hasattr(foo, 'upper')"

# Generated at 2022-06-21 07:55:17.880174
# Unit test for function safe_eval
def test_safe_eval():
    # Basic literals and operators
    expr = "1"
    assert safe_eval(expr) == 1
    expr = "1+2"
    assert safe_eval(expr) == 3
    expr = "1+2*3"
    assert safe_eval(expr) == 7
    expr = "[1, 2, 3]"
    assert safe_eval(expr) == [1, 2, 3]
    expr = "[1, 2, 3] + [4, 5]"
    assert safe_eval(expr) == [1, 2, 3, 4, 5]
    # Simple variable lookup
    expr = "foo"
    assert safe_eval(expr, {'foo': 1}) == 1
    expr = "foo['a']"
    assert safe_eval(expr, {'foo': {'a': 1}}) == 1
    # 

# Generated at 2022-06-21 07:55:26.231016
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:38.301195
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 + 3', locals={'foo': 'bar'}) == 5
    assert safe_eval('foo', locals={'foo': 'bar'}) == 'bar'
    assert safe_eval('foo.lower()', locals={'foo': 'bar'}) == 'bar'
    assert safe_eval('foo.lower()', locals={'foo': 'bar', 'lower': 7}) == 7
    assert safe_eval('foo', locals={'foo': None}) is None

    assert safe_eval('defined', locals={'defined': 'bar'}) == 'bar'
    assert safe_eval('defined', locals={}) == 'defined'

    assert safe_eval('foo.lower()', locals={'foo': 'bar', 'lower': to_text}) == 'bar'

    # based

# Generated at 2022-06-21 07:55:47.227703
# Unit test for function safe_eval
def test_safe_eval():
    # Test for valid expressions
    for expr in ['2', '2+2', '2 + 2 * 4']:
        result = safe_eval(expr)
        assert type(result) == int and result == eval(expr)

    # Test for invalid expressions that should raise an exception
    for expr in ['__import__("os").system("rm -rf")', '2 + __import__("os").system("rm -rf")']:
        try:
            result = safe_eval(expr)
            assert False
        except Exception:
            pass

    # Test for invalid expressions that should return the original expression
    for expr in ['__import__("os").system("rm -rf")', '2 + __import__("os").system("rm -rf")']:
        result = safe_eval(expr, include_exceptions=True)[0]
        assert type

# Generated at 2022-06-21 07:55:54.872136
# Unit test for function safe_eval
def test_safe_eval():
    # This should fail because it contains a '@'
    assert safe_eval("ansible_memtotal_mb @ 1024") == "ansible_memtotal_mb @ 1024"
    # This should fail because it contains a function call
    assert safe_eval("foo(bar)") == "foo(bar)"
    # This should pass
    assert safe_eval("ansible_memtotal_mb * 1024") == "ansible_memtotal_mb * 1024"

# Generated at 2022-06-21 07:56:04.650746
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:17.132954
# Unit test for function safe_eval
def test_safe_eval():
    # define a custom function for the test
    # function returns nothing and also does not take anything
    def my_func():
        pass

    # define the list of expressions and expected results
    # we will pass the list of expressions to safe_eval
    # and check if the results returned match the expected results

# Generated at 2022-06-21 07:56:31.223840
# Unit test for function safe_eval
def test_safe_eval():
    data = [
        ('1 + 2', 3),
        ('1 + 2 + 3', 6),
        ('1 + 2 * 3', 7),
        ('1 + (2 * 3)', 7),
        ('(1 + 2) * 3', 9),
        ('1 == 2', False),
        ('1 == 1', True),
        ('1 == 1 and 2 == 2', True),
        ('1 == 1 or 2 == 3', True),
        ('1 != 1', False),
        ('1 < 2', True),
        ('1 > 2', False),
        ('1 < 1', False),
        ('1 >= 1', True),
    ]

    for expr, expected in data:
        result, exception = safe_eval(expr, None, include_exceptions=True)

# Generated at 2022-06-21 07:56:43.921781
# Unit test for function safe_eval
def test_safe_eval():
    # All of the following should evaluate to true
    test_cases = [
        "123",
        "[1, 2, 3, 4]",
        "{'a': 'b', 'c': 'd'}",
        "(1 + 1)",
        "1 + 1 == 2",
        "1 + 1",
        "null",
        "true",
        "false",
        "`a_string`",
        "[a_var for a_var in [1,2,3]]",
        "",
    ]

    for a_case in test_cases:
        print(a_case)
        result, exception = safe_eval(a_case, locals={'a_var': 1}, include_exceptions=True)

# Generated at 2022-06-21 07:56:53.951559
# Unit test for function safe_eval
def test_safe_eval():
    # test eval a variable
    assert safe_eval(dict(a=3, b=dict(c=4))) == dict(a=3, b=dict(c=4))

    # test eval an arithmetic expression
    assert safe_eval('1 + 1 * 2') == 3
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('(1 + 2) * (0 + 3)') == 9

    # test eval a list
    assert safe_eval('["item1", "item2"]') == ["item1", "item2"]
    assert safe_eval('["key1", "key2"]') == ["key1", "key2"]

    # test eval a dict

# Generated at 2022-06-21 07:57:06.030839
# Unit test for function safe_eval
def test_safe_eval():
    # Simple expressions
    assert safe_eval('1') == 1
    assert safe_eval('2 * 3') == 6
    assert safe_eval('1.5') == 1.5
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('2 ** 3') == 8
    assert safe_eval('(1 + 2) * 3') == 9
    assert safe_eval('2 + 3 == 5') is True
    assert safe_eval('(1 == 2) == False') is True

    # Literal data structures
    assert safe_eval('[1, 2, "foo"]') == [1, 2, "foo"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-21 07:57:14.578711
# Unit test for function safe_eval
def test_safe_eval():
    def _test_expr(expr, expected_result, expected_error=None,
                   test_locals=None):
        actual_result, actual_error = safe_eval(expr,
                                                test_locals,
                                                include_exceptions=True)
        assert actual_result == expected_result
        if expected_error:
            assert isinstance(actual_error, expected_error)
        else:
            assert actual_error is None

    # test invalid expression
    _test_expr("{", None, SyntaxError)
    _test_expr("1 + [1, 2] + 3", None, TypeError)
    _test_expr("a_dict['a_key']", None, KeyError)
    _test_expr("'my_string'.upper()", None, AttributeError)

    # test valid expression


# Generated at 2022-06-21 07:57:27.242921
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:37.370775
# Unit test for function safe_eval
def test_safe_eval():
    # Test that the safe eval function works per the following examples:

    # Test 1: eval should be able to return a list
    expr = "[1, 2, 3]"
    assert safe_eval(expr).sort() == [1, 2, 3].sort()

    # Test 2: eval should be able to return a dict
    expr = '{"foo": "bar"}'
    assert safe_eval(expr) == {"foo": "bar"}

    # Test 3: eval should be able to return a string
    expr = '"foo"'
    assert safe_eval(expr) == "foo"

    # Test 4: eval should be able to parse math operations
    expr = "1 + 2 * 3"
    assert safe_eval(expr) == 7

    # Test 5: eval should be able to parse boolean expressions
    expr = 'false or true'

# Generated at 2022-06-21 07:57:50.081174
# Unit test for function safe_eval
def test_safe_eval():

    # test that literal value gets returned unchanged
    assert safe_eval('foo', dict(foo='bar')) == 'bar'
    assert safe_eval('true', dict(foo='bar')) is True
    assert safe_eval('false', dict(foo='bar')) is False
    assert safe_eval('null', dict(foo='bar')) is None
    assert safe_eval('{"a": 1, "b": 2}', dict(foo='bar')) == dict(a=1, b=2)
    assert safe_eval('{"a": true}', dict(foo='bar')) == dict(a=True)
    assert safe_eval('{"a": false}', dict(foo='bar')) == dict(a=False)

# Generated at 2022-06-21 07:57:57.914280
# Unit test for function safe_eval
def test_safe_eval():
    expr = "'$my_list'.join(a_list_variable)"
    try:
        # pylint: disable=eval-used
        eval(expr)
        assert False, "should have thrown an exception"
    except NameError:
        pass

    locals = dict(a_list_variable=['a', 'b', 'c'])
    result = safe_eval(expr, locals)
    assert result == 'a$my_listb$my_listc'

    expr = 'a.get("b")'
    assert safe_eval(expr) is None

    expr = 'a.get("b", "fake")'
    assert safe_eval(expr) == "fake"

    expr = '"a".startswith("b")'
    assert not safe_eval(expr)


# Generated at 2022-06-21 07:58:10.038898
# Unit test for function safe_eval
def test_safe_eval():
    # test basic usage
    assert safe_eval("a_list_variable") == "a_list_variable"
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo123") == "foo123"

    # test that function calls are rejected
    assert safe_eval("func(a)") == "func(a)"
    assert safe_eval("func(a, b)") == "func(a, b)"
    assert safe_eval("func()") == "func()"

    # test that dict entries are properly parsed
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("a") == "a"

    # test that dict entries with vars are properly parsed

# Generated at 2022-06-21 07:58:27.919058
# Unit test for function safe_eval
def test_safe_eval():
    def test_eval(expr, expected, **kwargs):
        result = safe_eval(expr, **kwargs)
        if isinstance(expected, Exception):
            assert isinstance(result, Exception)
            assert result.__class__ == expected.__class__
        else:
            assert result == expected

    # Basic tests
    test_eval("1", 1)
    test_eval("str(42)", "42")
    test_eval("[]", [])
    test_eval("()", ())
    test_eval("{}", {})

    # Test all nodes
    # ast.Add,
    test_eval("1+1", 2)
    # ast.BinOp,
    test_eval("1+2*3", 7)
    # ast.Call,
    test_eval("min(1, 2)", 1)

# Generated at 2022-06-21 07:58:39.835639
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # test safe_eval(RHS) == LHS

# Generated at 2022-06-21 07:58:50.767221
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('value')
    assert result == 'value'

    result = safe_eval('value', include_exceptions=True)
    assert result == ('value', None)

    result = safe_eval('foo + 10')
    assert result == 'foo + 10'

    result = safe_eval('foo + 10', locals={'foo':20})
    assert result == 30

    result = safe_eval('foo + 10', locals={'foo':'string'})
    assert result == 'string + 10'

    result = safe_eval('foo + 10', locals={'foo':['a', 'b', 'c']})
    assert result == 'a + 10'

    result = safe_eval("""
        [ 'a',
          'b',
          c + 10]
        """, locals={'c':20})

# Generated at 2022-06-21 07:59:02.662208
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:11.261873
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:23.919073
# Unit test for function safe_eval
def test_safe_eval():

    # Ensure we can eval something simple
    simple_eval = safe_eval("5+5", include_exceptions=True)
    assert simple_eval[0] == 10
    assert simple_eval[1] is None

    # Disallow calling eval
    eval_call = safe_eval("eval('1+1')", include_exceptions=True)
    assert eval_call[0] == "eval('1+1')"
    assert isinstance(eval_call[1], Exception)

    # Disallow calling any builtin function
    list_call = safe_eval("list()", include_exceptions=True)
    assert list_call[0] == "list()"
    assert isinstance(list_call[1], Exception)

    # Disallow calling None
    none_call = safe_eval("None()", include_exceptions=True)

# Generated at 2022-06-21 07:59:34.273246
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a basic unit test for the function safe_eval. There are a number of
    cases that are tested here. Please add new test cases if you find that safe_
    eval is not doing the correct thing.

    Note: The tests defined here will assume that the CALL_ENABLED list is empty.
    This is because we want to test that calls to any builtin will raise an
    exception. If CALL_ENABLED is non-empty, then the user can call any of the
    builtin functions that are defined in the list.

    '''

# Generated at 2022-06-21 07:59:45.908294
# Unit test for function safe_eval
def test_safe_eval():
    # Verify that a syntax error will not be caught
    (result, e) = safe_eval("{{ 3 + 2 }", include_exceptions=True)
    assert result == "{{ 3 + 2 }"
    assert e is None
    # Check boolean handling
    (result, e) = safe_eval("{{ True and False }}", include_exceptions=True)
    assert result == False
    assert e is None
    # Check integer handling
    (result, e) = safe_eval("{{ 3 + 2 }}", include_exceptions=True)
    assert result == 5
    assert e is None
    # Check dictionary handling
    (result, e) = safe_eval("{{ dict(a=1, b=2) }}", include_exceptions=True)
    assert result == dict(a=1, b=2)
    assert e is None

# Generated at 2022-06-21 07:59:56.406078
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:08.518986
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test to test the function safe_eval.  The following cases are covered:
    1. Safe Eval of constants
    2. Safe Eval of variables (using locals)
    3. Safe eval of expressions (using BinOps and UnaryOps)
    4. Inclusion of additional globals
    5. Handling of invalid AST nodes (things like Call, or Subscript)
    6. Handling of invalid builtins
    """

    # Test case #1: Safe Eval of constants
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2

    # Test case #2: Safe Eval of variables (using locals)
    assert safe_eval('a', {'a': 'test'}) == 'test'

# Generated at 2022-06-21 08:00:34.740674
# Unit test for function safe_eval
def test_safe_eval():
    safe_globals = {
        '__builtins__': {},
        'false': False,
        'null': None,
        'true': True,
        'True': True,
        'False': False,
        'None': None
    }
    add_docs = "Add two values together."
    sub_docs = "Subtract two values."
    my_builtins = {
        'add': lambda a, b: a + b,
        'sub': lambda a, b: a - b,
    }
    my_globals = {
        '__builtins__': my_builtins,
        'false': False,
        'null': None,
        'true': True,
        'True': True,
        'False': False,
        'None': None
    }


# Generated at 2022-06-21 08:00:45.367720
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:56.173725
# Unit test for function safe_eval
def test_safe_eval():
    test_results = [
        ('1+1', 2),
        ('(True and "foo") or "bar"', 'foo'),
        ('("foo" in ["foo", "bar"])', True),
        ('not True', False),
        ('1+"foo"', "invalid expression (1+\"foo\")"),
        ('foo and "bar"', "invalid expression (foo and \"bar\")"),
    ]

    for expr, result in test_results:
        real_result = safe_eval(expr)
        if isinstance(result, Exception):
            result = type(result)
        if isinstance(real_result, Exception):
            real_result = type(real_result)
        assert real_result == result
