

# Generated at 2022-06-21 07:51:10.691549
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:18.773508
# Unit test for function safe_eval
def test_safe_eval():
    # Test booleans
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    # Test None
    assert safe_eval("null") is None
    # Test integers
    assert safe_eval("1") == 1
    # Test floating point
    assert safe_eval("30.123") == 30.123
    # Test nested containers
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("[1, 2, [3, 4]]") == [1, 2, [3, 4]]
    assert safe_eval("[1, 2, {'foo': 3}]") == [1, 2, {'foo': 3}]

# Generated at 2022-06-21 07:51:26.415597
# Unit test for function safe_eval
def test_safe_eval():
    # Simple cases that should pass
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2] + [4]") == [1, 2, 4]

    # Should pass since there is no call to any builtin function
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}

    # Should fail because of a builtin call
    assert safe_eval("datetime.datetime.now()") == "datetime.datetime.now()"

    # Should fail because of an invalid operator
    assert safe_eval("1 // 2") == "1 // 2"

    # Should fail because of an invalid type

# Generated at 2022-06-21 07:51:39.227007
# Unit test for function safe_eval
def test_safe_eval():
    # Test case 1: list literals
    assert(safe_eval('[1, 2, 3, 4]') == [1, 2, 3, 4])

    # Test case 2: nested list literals
    assert(safe_eval('[1, [2, 3, 4], 5, [6, 7]]') == [1, [2, 3, 4], 5, [6, 7]])

    # Test case 3: dict literals
    assert(safe_eval('{"key1": "value1", "key2": "value2"}') == {'key1': 'value1', 'key2': 'value2'})

    # Test case 4: nested dict literals

# Generated at 2022-06-21 07:51:47.727873
# Unit test for function safe_eval
def test_safe_eval():
    # Expected to pass
    assert safe_eval("a") == "a"
    assert safe_eval("'a'") == "a"
    assert safe_eval('"a"') == "a"
    assert safe_eval("'a b'") == "a b"
    assert safe_eval("1") == 1
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("[a]") == "[a]"
    assert safe_eval("{'a':1}") == {'a':1}
    assert safe_eval("{'a':[1,2,3]}") == {'a':[1,2,3]}

# Generated at 2022-06-21 07:51:58.997376
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:12.020586
# Unit test for function safe_eval
def test_safe_eval():

    def do_test(exp, expected):
        result, e = safe_eval(exp, include_exceptions=True)
        if expected[0] is None and e is not None:
            raise Exception('Expected no exception but got %s' % to_native(e))
        if expected[0] is not None and e is None:
            raise Exception('Expected exception %s but got no exceptions' % to_native(expected[0]))
        if expected[0] is not None and e is not None:
            if str(expected[0]) not in str(e):
                raise Exception('Expected exception %s but got %s' % (to_native(expected[0]), to_native(e)))

# Generated at 2022-06-21 07:52:21.231773
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:32.568661
# Unit test for function safe_eval
def test_safe_eval():
    '''Test code for safe_eval'''
    from ansible.module_utils.common.text.converters import to_text

    # test standard cases
    assert safe_eval('1', include_exceptions=True) == (1, None)
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('true', include_exceptions=True) == (True, None)
    assert safe_eval('False', include_exceptions=True) == (False, None)
    assert safe_eval('false', include_exceptions=True) == (False, None)
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_

# Generated at 2022-06-21 07:52:40.200596
# Unit test for function safe_eval
def test_safe_eval():
    # Test that good expressions work
    assert safe_eval('1') == 1
    assert safe_eval('[1, "two"]') == [1, "two"]
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('dict(a=1)') == {'a': 1}

    # Test that bad expressions don't work
    try:
        safe_eval('__import__("os").system("rm -rf")')
    except Exception as e:
        pass
    else:
        print(safe_eval('__import__("os").system("rm -rf")'))
        raise Exception("safe_eval() with the 'os' module allowed!")
    try:
        safe_eval('len([])')
    except Exception as e:
        pass

# Generated at 2022-06-21 07:52:55.546528
# Unit test for function safe_eval
def test_safe_eval():
    # Don't worry about python2.6 compatibility here,
    # we don't support it anyway.
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1 - 2') == 0
    assert safe_eval('1+1-2') == 0
    assert safe_eval('10 * 10') == 100
    assert safe_eval('-10') == -10
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('foo + "bar"') == 'foobar'
    assert safe_eval('2 == 2') is True
    assert safe_eval('2 != 2') is False
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-21 07:53:03.178544
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:15.711887
# Unit test for function safe_eval
def test_safe_eval():
    def test_case(description, expr, expected):
        print("Testing: %s" % description)
        result = safe_eval(expr)
        if type(expected) == type(result):
            if isinstance(expected, (dict, list)):
                if len(expected) != len(result):
                    print("FAILED: %s != %s" % (to_native(expected), to_native(result)))
                    sys.exit(1)
                for (k1, v1), (k2, v2) in zip(expected.items(), result.items()):
                    if k1 != k2 or v1 != v2:
                        print("FAILED: %s != %s" % (to_native(expected), to_native(result)))
                        sys.exit(1)

# Generated at 2022-06-21 07:53:25.865434
# Unit test for function safe_eval
def test_safe_eval():
    # This is a list of test expressions and the expected result when evaluated.
    # The actual result is compared against the expected result.
    test_cases = {
        '1 + 1': 2,
        'ansible': 'ansible',
        '(1, 2)': (1, 2),
        '{1: 2}': {1: 2},
        'a_list_var[1]': 'foo',
        'a_list_var[-1]': 'foo',
        'a_dict_var["key"]': 'foo',
    }
    # This is a list of test expressions and the expected exception when evaluated.
    # The actual exception is compared against the expected exception.

# Generated at 2022-06-21 07:53:38.390289
# Unit test for function safe_eval
def test_safe_eval():
    """ Example usage for function safe_eval() """
    # start with a list
    print(safe_eval("['a','b','c']"))
    # can we use a variable?
    print(safe_eval("a_list", {'a_list':['a','b','c']}))
    # what happens when we try to call something?
    print(safe_eval("len(['a','b','c'])"))
    # what about a dictionary?
    print(safe_eval("{'a':1,'b':2,'c':3}"))
    # what if we have a valid expression that needs to be evaluated?
    print(safe_eval("['a','b','c'][0]"))
    # what happens if we call a function we haven't explicitly enabled?
    print(safe_eval("sys.exit()"))
    print

# Generated at 2022-06-21 07:53:48.301433
# Unit test for function safe_eval
def test_safe_eval():

    # Parse a simple datastructure and a simple expression
    expr = '{"a": "b", "c": [1, 2, 3], "d": {"x": "y"}, "e": "e1", "f": "f1", "g": "g1"}'
    compiled = safe_eval(expr)
    if not isinstance(compiled, dict):
        sys.exit('test_safe_eval: dict() compile failed')

    # Parse a dict with a dict inside it and an expression
    expr = '{"a": {"b": "c"}}'
    compiled = safe_eval(expr)
    if not isinstance(compiled, dict):
        sys.exit('test_safe_eval: dict(dict()) compile failed')

    # Parse a simple expression
    expr = '1 + 1'
    compiled = safe_

# Generated at 2022-06-21 07:53:58.855529
# Unit test for function safe_eval
def test_safe_eval():
    # Variables for asserts
    global_vars = {'from_file': False}
    local_vars = {'from_file': True}

    # Test without any function calls
    assert safe_eval('10 + 2') == (10 + 2)
    assert safe_eval('"10" + "2"') == '102'
    assert safe_eval('"10" * 2') == '1010'
    assert safe_eval('"10" * "2"') == '10'
    assert safe_eval('10 / 2') == 5.0

    # Test with global variable calls
    assert safe_eval('from_file') == global_vars['from_file']

    # Test with local variable calls
    assert safe_eval('from_file', local_vars) == local_vars['from_file']

    # Test

# Generated at 2022-06-21 07:54:09.758699
# Unit test for function safe_eval
def test_safe_eval():
    # test simple types
    assert safe_eval("foo", locals={"foo": "bar"}) == "bar"
    assert safe_eval("foo.bar", locals={"foo": {"bar": "baz"}}) == "baz"
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    if sys.version_info > (3,):
        assert safe_eval("{'foo':'bar'}") == {'foo': 'bar'}
    else:
        assert safe_eval("{'foo':'bar'}") == {u'foo': u'bar'}

    # test complex types

# Generated at 2022-06-21 07:54:17.593027
# Unit test for function safe_eval
def test_safe_eval():
    # simple eval
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # simple eval with namespace
    assert safe_eval('[1,2,3]', {'foo': 'bar'}) == [1, 2, 3]

    # multi-level deep eval
    assert safe_eval('bar[item]', {'bar': {'item': 'value'}}) == 'value'

    # multi-level deep eval with a filter
    assert safe_eval('bar[item].split()[0]', {'bar': {'item': 'value'}}) == 'value'

    # simple jinja2 eval
    assert safe_eval('{{foo}}', {'foo': 'value'}) == 'value'

    # simple jinja2 eval with pipe

# Generated at 2022-06-21 07:54:28.170923
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:42.958273
# Unit test for function safe_eval
def test_safe_eval():
    # Basic test
    assert safe_eval('42') == 42

    # JSON test
    assert safe_eval('["test", "est", "st", "t", 1, 3, 4, 5]') == ["test", "est", "st", "t", 1, 3, 4, 5]

    # Boolean test
    assert safe_eval('false') == False

    # Tuple test
    assert safe_eval('(1,2,3)') == (1, 2, 3)

    # Dict test
    assert safe_eval('{"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7}') == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}

    # Try to run

# Generated at 2022-06-21 07:54:55.311852
# Unit test for function safe_eval
def test_safe_eval():
    # Build a small module with some locally defined functions
    def test_func(x):
        return x

    def test_abs(x):
        return abs(x)

    def test_isinstance(x, t):
        return isinstance(x, t)

    # And a callable object
    class TestClass(object):

        def __init__(self, x):
            self.x = x

        def __call__(self, y):
            return self.x + y

    test_func.test_isinstance = test_isinstance
    module = sys.modules[__name__]
    module.test_abs = test_abs
    module.test_func = test_func
    module.TestClass = TestClass

    # Test the usage above
    #
    # Disabled:
    #   - ast.Call
    #

# Generated at 2022-06-21 07:55:07.204270
# Unit test for function safe_eval
def test_safe_eval():
    # test if safe_eval() returns the same result as eval()
    assert safe_eval('') == eval('')
    assert safe_eval('2') == eval('2')
    assert safe_eval('-1') == eval('-1')
    assert safe_eval('1+1') == eval('1+1')
    assert safe_eval('2-1') == eval('2-1')
    assert safe_eval('2*2') == eval('2*2')
    assert safe_eval('4/2') == eval('4/2')
    assert safe_eval('2**2') == eval('2**2')
    assert safe_eval('True') == eval('True')
    assert safe_eval('False') == eval('False')
    assert safe_eval('None') == eval('None')

# Generated at 2022-06-21 07:55:11.052823
# Unit test for function safe_eval
def test_safe_eval():
    set_trace = False
    test_inputs = [
        '"not_a_var"',
        '"not_a_var" + "neither_is_this"',
        '"3" + str(not_a_var)',
        '"un" + "safe_" + "eval"',
        'tuple()',
        'list()',
        'dict()',
        'bool(True)',
        'set()',
        'True',
        'False',
        'None',
        'True and False',
    ]
    print("Testing safe_eval function with %d test inputs" % len(test_inputs))
    for test_expr in test_inputs:
        print("Testing safe_eval(%s)" % test_expr)
        if set_trace:
            import ipdb

# Generated at 2022-06-21 07:55:22.252740
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"one" in foo') == "'one' in foo"
    assert safe_eval('foo in bar') == 'foo in bar'
    assert safe_eval('foo not in bar') == 'foo not in bar'
    assert safe_eval('foo and bar') == 'foo and bar'
    assert safe_eval('foo or bar') == 'foo or bar'
    assert safe_eval('not foo') == 'not foo'
    assert safe_eval('foo is None') == 'foo is None'
    assert safe_eval('foo is not None') == 'foo is not None'
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo[0]') == 'foo[0]'

# Generated at 2022-06-21 07:55:34.483949
# Unit test for function safe_eval
def test_safe_eval():
    # case 1:
    # a basic list
    s = "[1, 2, 3]"
    js = safe_eval(s)
    assert js == [1, 2, 3]

    # case 2:
    # a list with a string
    s = "[1, 2, \"3\"]"
    js = safe_eval(s)
    assert js == [1, 2, "3"]

    # case 3:
    # a list with a string with a simple jinja2 expression
    s = "[1, 2, \"{{ 3 }}\"]"
    js = safe_eval(s)
    assert js == [1, 2, "{{ 3 }}"]

    # case 4:
    # a list with a string with a simple jinja2 expression
    s = "[1, 2, \"{{ 3 }}\"]"
    js = safe_

# Generated at 2022-06-21 07:55:44.973997
# Unit test for function safe_eval
def test_safe_eval():
    def safe_eval_test(q, locals=None, include_exceptions=False):
        ok, err = safe_eval(q, locals=locals, include_exceptions=include_exceptions)
        if err:
            raise Exception("Error in %r: %s: %s" % (q, type(err).__name__, err))
        else:
            return ok

    # constants
    safe_eval_test("1")
    safe_eval_test("'foo'")
    # simple math
    safe_eval_test("1+2")
    # list
    safe_eval_test("[ 1, 2, 3 ]")
    # tuple
    safe_eval_test("( 1, 2, 3 )")
    # list+variable

# Generated at 2022-06-21 07:55:57.514253
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval"""
    # pylint: disable=redefined-outer-name

    def check_eval(expr, expected, locals=None):
        # pylint: disable=redefined-outer-name
        try:
            actual, err = safe_eval(expr, locals, include_exceptions=True)
        except Exception as e:
            actual, err = None, e

        assert actual == expected, "safe_eval('%s', %s) returned '%s' != '%s'" % (expr, locals, actual, expected)
        assert err is None, "safe_eval('%s', %s) raised error: %s" % (expr, locals, err)


# Generated at 2022-06-21 07:56:05.905648
# Unit test for function safe_eval
def test_safe_eval():
    # define certain JSON types
    # eg. JSON booleans are unknown to python eval()
    OUR_GLOBALS = {
        '__builtins__': {},  # avoid global builtins as per eval docs
        'false': False,
        'null': None,
        'true': True,
        # also add back some builtins we do need
        'True': True,
        'False': False,
        'None': None
    }

    # this is the whitelist of AST nodes we are going to
    # allow in the evaluation. Any node type other than
    # those listed here will raise an exception in our custom
    # visitor class defined below.

# Generated at 2022-06-21 07:56:18.200329
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic 'safe' eval expressions
    assert safe_eval('1+1') == 2
    assert safe_eval('(1+1)') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert safe_eval('-1') == -1
    assert safe_eval('null') is None
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('true and true') is True
    assert safe_eval('true and false') is False
    assert safe_eval('false or true') is True
    assert safe_eval('false or false') is False
   

# Generated at 2022-06-21 07:56:44.024458
# Unit test for function safe_eval
def test_safe_eval():
    # A safe expression
    expr = '1 + 1'
    locals = {}
    expected = 2
    actual = safe_eval(expr, locals)
    assert expected == actual, '%s == %s' % (expected, actual)

    # An unsafe expression
    expr = "__import__('os').system('rm -rf /')"
    locals = {}
    expected = expr
    actual = safe_eval(expr, locals)
    assert expected == actual, '%s == %s' % (expected, actual)

    # An unsafe expression with a portion that is marked safe
    expr = "foo + __import__('os').system('rm -rf /')"
    locals = {'foo': 1}
    expected = expr
    actual = safe_eval(expr, locals)

# Generated at 2022-06-21 07:56:54.033366
# Unit test for function safe_eval
def test_safe_eval():
    # default safe_eval should return strings for anything it can't evaluate
    assert safe_eval('{{ foo }}') == '{{ foo }}'
    assert safe_eval('{{ foo[1] }}') == '{{ foo[1] }}'
    # tests for known jinja2 expressions
    assert safe_eval('foo + 2') == 'foo + 2'
    assert safe_eval('foo + 2', dict(foo=1)) == 'foo + 2'
    assert safe_eval('foo + 2', dict(foo=1), True)[0] == 3
    assert safe_eval('foo + 2', dict(foo='1')) == 'foo + 2'
    assert safe_eval('foo + 2', dict(foo='1'), True)[0] == '1'
    assert safe_eval('foo | int + 2', dict(foo=1)) == 3

# Generated at 2022-06-21 07:57:06.185832
# Unit test for function safe_eval
def test_safe_eval():

    print("Testing safe_eval...")

    # simple
    result = safe_eval("2+3")
    assert(result == 5)
    result = safe_eval("set((1,2,3))")
    assert(result == set([1,2,3]))

    # check blacklisting of certain functions
    try:
        result = safe_eval("chr(10)")
        assert False, "expected exception"
    except Exception:
        assert True

    # check blacklisting of certain functions
    try:
        result = safe_eval("list('abcd')")
        assert False, "expected exception"
    except Exception:
        assert True

    # check blacklisting of certain functions
    # ast.Call is not in the SAFE_NODES list

# Generated at 2022-06-21 07:57:14.657694
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:27.289577
# Unit test for function safe_eval
def test_safe_eval():
    '''
    unit test to verify correct handling of safe_eval
    '''
    if sys.version_info < (2, 6):
        raise AssertionError("safe_eval requires python 2.6 at a minimum")

    # ast.Call requires python >= 2.6

# Generated at 2022-06-21 07:57:37.406422
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:50.132317
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Testcase for safe_eval
    '''

    def test_one(expr, value):
        ro = safe_eval(expr)
        assert ro == value, "safe_eval('%s') returned error %s, expected %s" % (expr, ro, value)

    def test_two(expr, value, var):
        ro = safe_eval(expr, dict(var=var))
        assert ro == value, "safe_eval('%s') returned error %s, expected %s" % (expr, ro, value)

    def test_three(expr, value, var, locals):
        ro = safe_eval(expr, dict(var=var, **locals))
        assert ro == value, "safe_eval('%s') returned error %s, expected %s" % (expr, ro, value)

    test

# Generated at 2022-06-21 07:58:02.700378
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2 }") == {'a': 1, 'b': 2}
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1-1") == 1
    assert safe_eval("1+1-1+1") == 2
    assert safe_eval("1-1+1") == 1
    assert safe_eval("1-1+1-1") == 0
    assert safe_eval("1+1+1-1") == 3
    assert safe_eval("1+1+1+1-1") == 4

# Generated at 2022-06-21 07:58:07.936678
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:18.629403
# Unit test for function safe_eval
def test_safe_eval():
    # Enable all builtins for testing purposes
    for function in dir(builtins):
        CALL_ENABLED.append(function)

    # Test valid expressions
    my_result, exception = safe_eval('{"foo": "bar"}', include_exceptions=True)
    assert my_result == {'foo': 'bar'}
    assert exception is None

    my_result, exception = safe_eval('["foo", "bar"]', include_exceptions=True)
    assert my_result == ['foo', 'bar']
    assert exception is None

    my_result, exception = safe_eval('my_list', include_exceptions=True, locals={'my_list': ['foo', 'bar']})
    assert my_result == ['foo', 'bar']
    assert exception is None


# Generated at 2022-06-21 07:58:44.472814
# Unit test for function safe_eval
def test_safe_eval():
    # test things we should allow
    assert safe_eval('0', {}) == 0
    assert safe_eval('0') == 0
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1+1') == 3
    assert safe_eval('1+1-1') == 1
    assert safe_eval('1+1-1+1') == 2
    assert safe_eval('1+1-1+1-1') == 1
    assert safe_eval('-1-1-1-1') == -4
    assert safe_eval('-1-1-1+1') == -2
    assert safe_eval('-1-1-1+1+1') == -1
    assert safe_eval

# Generated at 2022-06-21 07:58:55.898126
# Unit test for function safe_eval
def test_safe_eval():
    print('Testing ansible.utils.unsafe_proxy')

    def fail(x):
        raise Exception('%s: %s' % (type(x), to_native(x)))

    # use the built-in function 'min' as a sentinal to verify
    # that the function was actually called

# Generated at 2022-06-21 07:59:06.934472
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') is None
    assert safe_eval('result') == 'result'
    assert safe_eval('result', dict(result=True)) == True
    assert safe_eval('a == 1 and b == 2', dict(a=1, b=2)) == True
    assert safe_eval('a == 1 and b == 1', dict(a=1, b=2)) == False
    assert not safe_eval('[0, 1, 2]')
    assert not safe_eval('[0, 1, 2]', include_exceptions=True)[0]
    assert safe_eval('[0, 1, 2]', dict(a=[0, 1, 2])) == [0, 1, 2]

# Generated at 2022-06-21 07:59:13.420663
# Unit test for function safe_eval
def test_safe_eval():
    "Test safe_eval function"

    # Validation: We should be able to evaluate these

# Generated at 2022-06-21 07:59:24.334843
# Unit test for function safe_eval
def test_safe_eval():
    class Test:
        a = 'string'
        b = 1
        c = [1,2,3]
        d = {'a':1,'b':2}
        e = True     # JSON booleans are unknown to python eval()
        f = '{{foo}}'

        def bar(self):
            return 'bar'

    d = Test()
    assert safe_eval("a",dict(a=d.a)) == d.a
    assert safe_eval("b",dict(b=d.b)) == d.b
    assert safe_eval("c",dict(c=d.c)) == d.c
    assert safe_eval("d",dict(d=d.d)) == d.d
    assert safe_eval("e",dict(e=d.e)) == d.e

# Generated at 2022-06-21 07:59:34.577221
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Returns a dict of the test results (True for pass, False for fail).

    This does not test all possible cases as that would require a full python
    eval implementation.  Rather, we are testing that our whitelist works as
    expected, and that whitelisted code is properly evaluated.
    '''
    results = {}

    # test our whitelist
    val_fail = ast.BoolOp()
    val_pass = ast.BinOp()
    cnv = CleansingNodeVisitor()
    cnv.generic_visit(val_fail)
    try:
        cnv.generic_visit(val_pass)
        results['whitelist'] = True
    except Exception:
        results['whitelist'] = False

    # test that our code eval works

# Generated at 2022-06-21 07:59:46.248198
# Unit test for function safe_eval
def test_safe_eval():
    # Variables and values
    v_s = 'one'
    v_i = 1
    v_f = 1.0
    v_t = True
    v_l = [1]
    v_d = {'a': 1}

    # Test that basic values and math expressions work
    assert safe_eval(v_s) == v_s
    assert safe_eval(v_i) == v_i
    assert safe_eval(v_f) == v_f
    assert safe_eval(v_t) == v_t
    assert safe_eval(v_l) == v_l
    assert safe_eval(v_d) == v_d
    assert safe_eval('1 + 1') == 2

    # Test that it returns the underlying Python object
    assert safe_eval(v_l) is v_l

# Generated at 2022-06-21 07:59:56.644714
# Unit test for function safe_eval
def test_safe_eval():
    # String that will be evaluated but should fail
    test_string = "ansible.constants.DEFAULT_DEBUG"

    # Get the globals, locals, and builtins of ansible.utils.unsafe_eval
    g = safe_eval.func_globals
    l = safe_eval.func_globals['locals']()
    b = safe_eval.func_globals['builtins']

    # Run the string through eval to ensure it works and is properly sandboxed
    try:
        exec_string = compile(test_string, '<string>', 'single')
        result = eval(exec_string, g, l)
    except Exception as e:
        result = e

    # Check that the result is True, indicating that the string was properly sandboxed
    assert result, "safe_eval is not sandboxed"



# Generated at 2022-06-21 08:00:08.877835
# Unit test for function safe_eval
def test_safe_eval():
    class MyException(Exception):
        pass

    def my_import(name, globals=None, locals=None, fromlist=None):
        raise MyException("simulated exception")

    old_import, sys.modules['__builtin__'].__import__ = sys.modules['__builtin__'].__import__, my_import

# Generated at 2022-06-21 08:00:21.170881
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: Test the safe_eval function and ensure that it returns the
    # expected value.
    test_expr = "1 + 2 + 3"
    expected = 6
    result = safe_eval(test_expr)
    assert result == expected

    # Test 2: Test a more complex expression.  This expression is also
    # more likely to be specified by a user and hence needs to be tested.
    test_expr = "1 + (3 * (5 + (6 * 8)))"
    expected = 129
    result = safe_eval(test_expr)
    assert result == expected

    # Test 3: Test a more complex expression that includes the use of
    # variables in the expression.
    # Set a variable 'a' with a specific value.  We'll then use this
    # variable in the expression
    test_var = 'a'
