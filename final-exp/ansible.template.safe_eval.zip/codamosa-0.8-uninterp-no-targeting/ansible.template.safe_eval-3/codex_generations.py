

# Generated at 2022-06-21 07:51:02.870709
# Unit test for function safe_eval
def test_safe_eval():
    # Basic unit tests
    assert safe_eval("foobar") == "foobar"
    assert safe_eval("'foobar'") == "foobar"
    assert safe_eval("['foo', 'bar']") == ["foo", "bar"]
    assert safe_eval("['foo', 'bar', true]") == ["foo", "bar", True]
    assert safe_eval("{'foo': 'bar', 'bar': 'foo'}") == {"foo": "bar", "bar": "foo"}
    assert safe_eval("{'foo': 'bar', 'bar': true}") == {"foo": "bar", "bar": True}
    assert safe_eval("foobar", dict(foobar=42)) == 42

# Generated at 2022-06-21 07:51:14.730526
# Unit test for function safe_eval
def test_safe_eval():
    # Tests that safe_eval correctly returns what you pass it
    def test_returns(expression):
        assert safe_eval(expression) == expression

    # Tests that safe_eval doesn't call anything it shouldn't
    def test_no_call(expression):
        try:
            safe_eval(expression)
            assert False
        except Exception as e:
            assert "calling function" in to_native(e)

    test_returns("foo")
    test_returns("bar")
    test_returns("foo.bar")
    test_returns("foo['bar']")
    test_returns("foo.bar.baz")
    test_returns(123)

    # Tests that allowed functions are run correctly

# Generated at 2022-06-21 07:51:26.789983
# Unit test for function safe_eval
def test_safe_eval():
    class Test():
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10

        def __getitem__(self, key):
            return getattr(self, key)

        def integer(self):
            return 99

    t = Test()
    tdict = dict(
        a=1,
        b=2,
        d=4,
        f=6,
        h=8,
        j=10,
    )


# Generated at 2022-06-21 07:51:39.514439
# Unit test for function safe_eval
def test_safe_eval():

    (result, err) = safe_eval("{{ foo }}{{ bar }}", dict(foo='one', bar='two'), include_exceptions=True)
    assert result == 'onetwo'
    assert err is None

    (result, err) = safe_eval("{{ foo }}{{ bar }}", dict(foo='one', bar='two', baz=None), include_exceptions=True)
    assert result == 'onetwo'
    assert err is None

    (result, err) = safe_eval("{{ foo }}{{ bar }}{{ baz }}", dict(foo='one', bar='two', baz=None), include_exceptions=True)
    assert result == 'onetwoNone'
    assert err is None


# Generated at 2022-06-21 07:51:47.849510
# Unit test for function safe_eval
def test_safe_eval():
    failed_tests = []

# Generated at 2022-06-21 07:51:54.270922
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function for basic eval function logic.
    '''
    # initialize the error list to empty
    eval_errors = []

    # test the basic functionality of safe_eval
    assert safe_eval('1 + 1') == 2, "1 + 1 should be 2"
    assert safe_eval('"a" + "b"') == 'ab', "'a' + 'b' should be 'ab'"
    assert safe_eval('[1, 2, 3]') == [1, 2, 3], "[1, 2, 3] should be [1, 2, 3]"
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}, "{'a': 1, 'b': 2} should be {'a': 1, 'b': 2}"

    # test safe_eval with a local

# Generated at 2022-06-21 07:52:06.553023
# Unit test for function safe_eval
def test_safe_eval():
    def do_test(d, e, v, msg):
        try:
            r = safe_eval(d)
            if (r != v):
                print(('%s: %s != %s (%s)' % (msg, r, v, d)))
        except Exception as err:
            r = 'ERROR'
            if (e != 'ERROR'):
                print(('%s: %s != %s (%s)' % (msg, r, v, d)))


# Generated at 2022-06-21 07:52:17.839059
# Unit test for function safe_eval
def test_safe_eval():
    # success cases
    if C.DEFAULT_DEBUG:
        assert safe_eval('[1, "a", {}]') == [1, "a", {}]
        assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

        assert safe_eval('[1, "a", {}]', include_exceptions=True) == ([1, "a", {}], None)
        assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({"a": 1, "b": 2}, None)

        assert safe_eval('2+2') == 4
        assert safe_eval('2+2', include_exceptions=True) == (4, None)


# Generated at 2022-06-21 07:52:21.090175
# Unit test for function safe_eval
def test_safe_eval():
    # safe eval of constant vars and adding of new variables
    assert safe_eval('3 + 4') == 7
    assert safe_eval('ansible_facts') is None
    assert safe_eval('ansible_facts') is None
    # TODO: Add more tests



# Generated at 2022-06-21 07:52:32.317812
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: ensure that we can safely parse a single string with constant
    # values and basic operators
    expr = '3 + 5'
    value, exception = safe_eval(expr, include_exceptions=True)
    assert value == 8 and exception is None

    # Test 2: ensure that we can safely parse a single string with constant
    # values, basic operators, and function calls
    expr = '"%s" % "hello world"'
    value, exception = safe_eval(expr, include_exceptions=True)
    assert value == 'hello world' and exception is None

    # Test 3: ensure that we cannot parse a string with a SyntaxError
    expr = 'foo ='
    value, exception = safe_eval(expr, include_exceptions=True)
    assert value == expr and isinstance(exception, SyntaxError)

   

# Generated at 2022-06-21 07:52:45.068336
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"
    assert safe_eval("42") == 42
    assert safe_eval("42.0") == 42.0
    assert safe_eval("42.", include_exceptions=True)[1] is not None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("['foo', 'bar']") == ["foo", "bar"]
    assert safe_eval("{'foo' : 'bar'}") == {"foo": "bar"}
    assert safe_eval("foo") is None
    assert safe_eval("42 + 42")

# Generated at 2022-06-21 07:52:56.297065
# Unit test for function safe_eval
def test_safe_eval():
    # should be safe
    safe_eval("container_to_text([], indent=0)")
    safe_eval("a and b")
    safe_eval("a or b")
    safe_eval("a in b")
    safe_eval("a not in b")
    safe_eval("None and b")
    safe_eval("None or b")
    safe_eval("None in b")
    safe_eval("None not in b")
    safe_eval("a == b")
    safe_eval("a != b")
    safe_eval("a < b")
    safe_eval("a <= b")
    safe_eval("a > b")
    safe_eval("a >= b")
    safe_eval("0")
    safe_eval("1")
    safe_eval("0.0")

# Generated at 2022-06-21 07:53:03.558380
# Unit test for function safe_eval
def test_safe_eval():
    def inner_test(expr, expected):
        result = safe_eval(expr)
        if result != expected:
            raise AssertionError("Error in safe_eval: %s != %s (type=%s)" % (result, expected, type(result)))
    inner_test("{'a': 1 , 'b':2}", {'a':1,'b':2})
    inner_test("[1,2,3]", [1,2,3])
    inner_test("[{'a':1}, {'b':2}]", [{'a':1}, {'b':2}])
    inner_test("3", 3)
    inner_test("-3", -3)
    inner_test("3 + 2", 5)
    inner_test("'foo' in ['foo', 'bar']", True)

# Generated at 2022-06-21 07:53:16.128403
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate an expression containing string, boolean, number and variable references
    # using the safe_eval function.
    expr = "'I am a string' == 'I am a string' and 1 == 1 and true == true and the_var == 'the_value'"

    # Define the variable used in the expression
    variables = {'the_var': 'the_value'}

    # Evaluate the expression using safe_eval()
    (result, exception) = safe_eval(expr, variables, include_exceptions=True)

    if exception is not None:
        # If an exception occurred, print its error message
        print('Exception occurred: %s' % to_native(exception), file=sys.stderr)
        exitResult = 1

# Generated at 2022-06-21 07:53:26.076609
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:38.597036
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('1') == 1
    assert safe_eval('1 or 2') == 1
    assert safe_eval('1 and 2') == 2

    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('6 / 2') == 3
    assert safe_eval('3 - 1') == 2
    assert safe_eval('1 - 3') == -2

    assert safe_eval('2 == 2')

    assert safe_eval('[1, 2]') == [1, 2]

# Generated at 2022-06-21 07:53:48.488856
# Unit test for function safe_eval
def test_safe_eval():
    # Simple integer tests
    assert safe_eval('1', {}, include_exceptions=True)[0] == 1
    assert safe_eval('1 + 2', {}, include_exceptions=True)[0] == 3
    assert safe_eval('1 + 2 * 4', {}, include_exceptions=True)[0] == 9
    assert safe_eval('1 + (2 * 4)', {}, include_exceptions=True)[0] == 9

    # Simple string tests
    assert safe_eval('"foo"', {}, include_exceptions=True)[0] == "foo"
    assert safe_eval('"foo" + "bar"', {}, include_exceptions=True)[0] == "foobar"

    # Boolean tests
    assert safe_eval('false', {}, include_exceptions=True)[0] == False
    assert safe

# Generated at 2022-06-21 07:53:59.113749
# Unit test for function safe_eval
def test_safe_eval():
    # known good expressions
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1') == 1
    assert safe_eval('2.2') == 2.2
    assert safe_eval('1+1') == 2
    assert safe_eval('1*1') == 1
    assert safe_eval('2**2') == 4
    assert safe_eval('2 + 2 * 2') == 6
    assert safe_eval('(2 + 2) * 2') == 8
    assert safe_eval('1 < 2') is True
    assert safe_eval('2 < 1') is False
    assert safe_eval('2 == 2') is True
    assert safe_eval('2 != 2') is False

# Generated at 2022-06-21 07:54:10.017708
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval function
    :returns: pass or fail
    """

    my_var = 'foo'

# Generated at 2022-06-21 07:54:17.042860
# Unit test for function safe_eval
def test_safe_eval():
    # Basic case
    result = safe_eval('2 + 3')
    if result != 5:
        raise AssertionError("safe_eval failed")
    # Make sure that it respects context
    result = safe_eval('test + 4', dict(test=3))
    if result != 7:
        raise AssertionError("safe_eval failed")
    # Try the include exceptions option
    result, exception = safe_eval('__builtins__.max()', include_exceptions=True)
    if isinstance(exception, Exception):
        if not isinstance(exception, SyntaxError):
            raise AssertionError("safe_eval failed")
    else:
        raise AssertionError("safe_eval failed")



# Generated at 2022-06-21 07:54:32.669039
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:41.649734
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:54.055999
# Unit test for function safe_eval
def test_safe_eval():
    # Some examples from the spec - http://json.org/
    assert safe_eval(""" [1, 2, 3] """) == [1, 2, 3]
    assert safe_eval(""" {"a": "b"} """) == {'a': 'b'}
    assert safe_eval(""" "abc" """) == 'abc'
    assert safe_eval(""" 1 """) == 1
    assert safe_eval(""" true """) is True
    assert safe_eval(""" false """) is False
    assert safe_eval(""" null """) == None
    # From the spec, these are not valid JSON
    # Because it is not a subset of JS value syntax.
    # assert safe_eval(""" 1, """)   == (1,)
    # assert safe_eval(""" 1 2 """)  == (1, 2)
   

# Generated at 2022-06-21 07:55:05.231876
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:17.225470
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:25.918927
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:37.899583
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval("[1,2,3,]")
    except Exception as e:
        sys.stderr.write(str(e))
        raise Exception("safe_eval should not fail for [1,2,3,]")
    try:
        safe_eval("[1,2,3")
    except Exception as e:
        sys.stderr.write(str(e))
        raise Exception("safe_eval should not fail for [1,2,3")
    try:
        safe_eval("{'foo': 'bar'}")
    except Exception as e:
        sys.stderr.write(str(e))
        raise Exception("safe_eval should not fail for {'foo': 'bar'}")

# Generated at 2022-06-21 07:55:46.993635
# Unit test for function safe_eval
def test_safe_eval():
    if 'ansible.debug' in sys.modules:
        raise Exception('test_safe_eval() not allowed when ansible.debug is in use')

    # Define some test variables
    test_dict = {
        'foo': True,
        'bar': False,
        'baz': {
            'qux': None
        }
    }
    test_list = ['foo', 'bar', 'baz']

    # Test a trivial example that should pass
    test_expr = 'foo'
    result = safe_eval(test_expr, dict(foo=True))
    assert result is True

    # Test a trivial example that should fail
    test_expr = 'foo'
    result = safe_eval(test_expr, dict(foo=True))
    assert result is True

    # Test a complex example that should pass
    test

# Generated at 2022-06-21 07:56:00.013788
# Unit test for function safe_eval
def test_safe_eval():
    import ast


# Generated at 2022-06-21 07:56:11.899186
# Unit test for function safe_eval
def test_safe_eval():
    C.DEFAULT_DEBUG = False
    # test the safe_eval function
    def test(expr, expected, locals=None):
        result = safe_eval(expr, locals=locals, include_exceptions=True)
        if result[0] != expected:
            raise AssertionError("%s != %s" % (result[0], expected))

    # safe_eval should return the expression parameter unmodified
    # if an exception is raised during the evaluation.
    test("{{ foo[bar] }}", "{{ foo[bar] }}")

    # normal python expressions should be fine
    test("2 + 3", 5, {})
    test("test(1, 2)", "test(1, 2)")

    # dictionary and list expressions are fine
    test("{2: 3}[2]", 3, {})

# Generated at 2022-06-21 07:56:32.673106
# Unit test for function safe_eval
def test_safe_eval():
    # Boolean true/false
    assert safe_eval('true') == True
    assert safe_eval('false') == False

    # None is a special case, because Jinja2 does not recognize None as a literal.
    # Therefore safe_eval('null') would be syntactically incorrect.
    assert safe_eval('None') == None
    assert safe_eval(None) == None

    # String
    assert safe_eval('"foobar"') == 'foobar'

    # Integer
    assert safe_eval('42') == 42

    # Dictionary
    assert safe_eval('{"a": 1, "b": "c"}') == {"a": 1, "b": "c"}

    # List
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

    # Tuple

# Generated at 2022-06-21 07:56:45.256839
# Unit test for function safe_eval
def test_safe_eval():
    # test basic syntax error
    (a, b) = safe_eval("{{", include_exceptions=True)
    assert isinstance(b, SyntaxError), b

    # test normal happy path
    a = safe_eval("{{ foo }}")
    assert isinstance(a, string_types), a

    # test error with exception
    (a, b) = safe_eval("{{ invalid_function() }}", include_exceptions=True)
    assert isinstance(b, NameError)

    # test already-evaluated expression
    a = safe_eval(['foo', 'bar'])
    assert isinstance(a, list)
    assert a == ['foo', 'bar']

    # test already-evaluated expression with include_exceptions

# Generated at 2022-06-21 07:56:54.925981
# Unit test for function safe_eval
def test_safe_eval():
    # Note: the test doesn't verify the exact error message but it
    # does verify that errors are detected.

    # This test just uses the string repr() of the exception so we
    # can do string contains in the test and not worry about the
    # details of the exception type
    def error_str(s):
        try:
            safe_eval(s)
        except Exception as e:
            return repr(e)

    assert error_str("[1,2][__import__('os').system('echo hi')]") is not None
    assert error_str("__import__('os').system('echo hi')") is not None
    assert error_str("a+unknown_variable") is not None
    assert error_str("a+unknown_variable") is not None
    assert error_str("a + 1 + 2") is None

# Generated at 2022-06-21 07:57:07.185665
# Unit test for function safe_eval
def test_safe_eval():
    import sys

    # Valid types
    assert safe_eval('123') == 123
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('"string"') == "string"
    assert safe_eval('None') is None
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('{"a": "b"}') == {"a": "b"}

    # Some basic arithmetics and comparisons
    assert safe_eval('2 + 3') == 5
    assert safe_eval('2 + -3') == -1
    assert safe_eval('2 + 4 - 3') == 3
    assert safe_eval('2 * 3 + 2') == 8
    assert safe_eval('2 * (3 + 2)') == 10

# Generated at 2022-06-21 07:57:15.162434
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:27.335073
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:38.469815
# Unit test for function safe_eval
def test_safe_eval():
    # should not raise an exception
    safe_eval("{ 'answer': True }")

    # should raise an exception
    try:
        safe_eval("[ a + 5 for a in range(10) ]")
        raise Exception("Failed to detect invalid AST expression")
    except Exception:
        pass

    # should not raise an exception
    safe_eval("[ a + 5 for a in range(10) if a > 7 ]")

    # should not raise an exception
    safe_eval("True and False")

    # should raise an exception
    try:
        safe_eval("__import__('sys').exit(1)")
        raise Exception("Failed to detect invalid AST expression")
    except Exception:
        pass

    # should raise an exception

# Generated at 2022-06-21 07:57:50.360678
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo.bar()") == "foo.bar()"

    # basic tests
    assert safe_eval("1+2") == 3
    assert safe_eval("'a'") == 'a'
    assert safe_eval("'a'+'b'") == 'ab'
    assert safe_eval("'a'+'b'+'c'") == 'abc'
    assert safe_eval("'a'*2") == 'aa'
    assert safe_eval("['a','b','c']") == ['a','b','c']
    assert safe_eval("('a','b','c')") == ('a','b','c')

# Generated at 2022-06-21 07:57:58.045300
# Unit test for function safe_eval
def test_safe_eval():
    values = {'foo': 42, 'bar': '42'}

# Generated at 2022-06-21 07:58:10.197657
# Unit test for function safe_eval
def test_safe_eval():
    # Test ascii string to be converted to boolean
    assert safe_eval('true') is True
    assert safe_eval('TRUE') is True
    assert safe_eval('false') is False
    assert safe_eval('FALSE') is False

    # Test unicode string to be converted to boolean
    assert safe_eval(u'true') is True
    assert safe_eval(u'TRUE') is True
    assert safe_eval(u'false') is False
    assert safe_eval(u'FALSE') is False

    # Test ascii string to be converted to None
    assert safe_eval('null') is None
    assert safe_eval('NULL') is None

    # Test unicode string to be converted to None
    assert safe_eval(u'null') is None
    assert safe_eval(u'NULL') is None

   

# Generated at 2022-06-21 07:58:38.559395
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.six.moves import builtins

    def test_safe_eval_run(expr, exc):
        if exc:
            with pytest.raises(exc):
                safe_eval(expr)
        else:
            safe_eval(expr)

    # test safe evals
    test_safe_eval_run('', None)
    test_safe_eval_run('1', None)
    test_safe_eval_run('not False', None)
    test_safe_eval_run('True or False', None)
    test_safe_eval_run('1 == 1', None)
    test_safe_eval_run('1 == 1 and False', None)
    test_safe_eval_run('1 == 1 and not False', None)
    test_safe_eval_run

# Generated at 2022-06-21 07:58:46.624792
# Unit test for function safe_eval
def test_safe_eval():
    # Do nothing if not invoked from CLI.
    if not sys.argv[0].endswith("py.test"):
        return

    # Basic true and false
    assert safe_eval("True")
    assert not safe_eval("False")

    # Literals: Integers, longs, floats, strings, tuples and lists
    assert safe_eval("1") == 1
    assert safe_eval("1L") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'hello world'") == 'hello world'
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("[1, 2]") == [1, 2]

    # Operators
    assert safe_eval("1 + 1") == 2

# Generated at 2022-06-21 07:58:58.433052
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('"foo" in bar') == 'foo' in 'bar'
    assert safe_eval('"foo" not in bar') is False
    # This could be true but we don't support keywords in safe_eval
    assert safe_eval('not true') is False
    assert safe_eval('null') is None
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

# Generated at 2022-06-21 07:59:09.027292
# Unit test for function safe_eval
def test_safe_eval():
    # test that valid expressions work
    assert safe_eval("1 == 1")
    assert safe_eval("a or b", {"a": False, "b": True})
    assert safe_eval("a", {"a": [1, 2, 3]})
    assert safe_eval('"string"')
    assert safe_eval("var", {"var": "a"})
    assert safe_eval("a or (b and c)", {"a": False, "b": True, "c": False})
    assert safe_eval("{'a': 1, 'b': 2}")
    assert safe_eval("[1, 2, 3, 4]")
    assert safe_eval("len([1, 2, 3, 4])")
    assert safe_eval("{}")
    assert safe_eval("()")

# Generated at 2022-06-21 07:59:18.488560
# Unit test for function safe_eval
def test_safe_eval():
    seq = ('1+1', '1+true', '1+false', '1+null', '1+1.0', '1+1j',
           '1+x', '1++1', '1+-1', '1+"a"', 'dict(a=2, b=3)', '-1+1',
           '[]', '()', '{}', '1 if 1 else 2', 'set([1,2])')
    raises = ('1+x', '1++1', '1+-1', '1+"a"', 'set([1,2])')
    for expr in seq:
        print(expr)
        result = safe_eval(expr)
        print(result)
        assert isinstance(result, (int, float, complex))

# Generated at 2022-06-21 07:59:29.966261
# Unit test for function safe_eval
def test_safe_eval():
    # Basic smoke test
    result = safe_eval("1 + 1")
    assert result == 2

    # Test returning the original expression along with the exception
    # where a syntax error occurs
    result, exc = safe_eval("1 + 1 +", include_exceptions=True)
    assert result == "1 + 1 +"
    assert isinstance(exc, SyntaxError)

    # Test a safe expression
    result = safe_eval("1 + 2 + 3")
    assert result == 6

    # Test an unsafe expression
    result = safe_eval("__import__('os').remove('/tmp/file')")
    if C.DEFAULT_KEEP_REMOTE_FILES:
        assert result == "__import__('os').remove('/tmp/file')"
    else:
        assert result == None

    # Test that we reject expressions

# Generated at 2022-06-21 07:59:37.887390
# Unit test for function safe_eval
def test_safe_eval():
    # test a simple expression
    expr = "foo == 'bar'"
    result = safe_eval(expr, dict(foo='bar'))
    assert(result is True)
    # test a simple expression w/o expected value
    expr = """foo"""
    result = safe_eval(expr, dict(foo='bar'))
    assert(result == 'bar')
    # test a simple expression w/o expected value
    expr = """foo"""
    result = safe_eval(expr, dict(foo=['bar']))
    assert(result == ['bar'])
    # test a simple expression w/o expected value
    expr = """foo"""
    result = safe_eval(expr, dict(foo=('bar', 'baz')))
    assert(result == ('bar', 'baz'))
    # test a simple expression w/o expected

# Generated at 2022-06-21 07:59:50.008863
# Unit test for function safe_eval
def test_safe_eval():
    # test good input
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('"foo"', include_exceptions=True)[0] == 'foo'
    assert safe_eval('[1, 2, 3]', include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval('{"foo": "bar", "biz": "baz"}', include_exceptions=True)[0] == {'foo': 'bar', 'biz': 'baz'}
    assert safe_eval('[1, 2, 3] + [4, 5, 6]', include_exceptions=True)[0] == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 07:59:58.647141
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('a.b.c.d') == 'a.b.c.d'
    try:
        safe_eval('__import__("os").system("ls")')
        assert False
    except Exception:
        assert True
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"k1": "v1"}') == {"k1": "v1"}
    assert safe_eval('[1,2,3,]') == [1, 2, 3]
    assert safe_eval('["one", "two", "three"]') == ['one', 'two', 'three']
    assert safe_eval('[1, 2, 3] == [1, 2, 3]') is True
    assert safe

# Generated at 2022-06-21 08:00:10.551997
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    # Test that it returns the correct value when given a safe expression
    assert safe_eval('1 + 1') == 2
    assert safe_eval('foobar') == 'foobar'
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('(1 + 1) * 2') == 4
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    # Test that it raises an exception when given an unsafe expression
    with pytest.raises(Exception):
        safe_eval('__import__("os").system("/bin/ls")')

    with pytest.raises(Exception):
        safe_eval('hasattr(__builtins__, "__import__")')


# Generated at 2022-06-21 08:00:52.655093
# Unit test for function safe_eval
def test_safe_eval():
    # Basic tests
    builtin = ('__import__',)
    not_builtin = ('foo',)

    # Check basic functionality and basic safety