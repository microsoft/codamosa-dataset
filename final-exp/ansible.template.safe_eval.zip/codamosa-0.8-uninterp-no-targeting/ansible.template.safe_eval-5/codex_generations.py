

# Generated at 2022-06-21 07:50:55.888864
# Unit test for function safe_eval
def test_safe_eval():
    pass



# Generated at 2022-06-21 07:51:02.783913
# Unit test for function safe_eval
def test_safe_eval():
    print("testing safe_eval")
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)

    assert safe_eval("foo") == 'foo'
    assert safe_eval("foo", include_exceptions=True) == ('foo', None)

    assert safe_eval("1 + 1", dict(foo='bar')) == 2
    assert safe_eval("1 + 1", dict(foo='bar'), include_exceptions=True) == (2, None)

    assert safe_eval("1 + 1", dict(foo='bar'), include_exceptions=True)[0] == 2
    assert safe_eval("1 + 1", dict(foo='bar'), include_exceptions=True)[1] is None


# Generated at 2022-06-21 07:51:14.652889
# Unit test for function safe_eval
def test_safe_eval():
    try:
        safe_eval("")
        raise AssertionError("emptry string should fail safe_eval")
    except Exception:
        pass

    try:
        safe_eval("{'a': 'b'")
        raise AssertionError("bad dict should fail safe_eval")
    except Exception:
        pass

    try:
        safe_eval("{'a': 'b',}")
        raise AssertionError("bad dict should fail safe_eval")
    except Exception:
        pass

    try:
        safe_eval("[]")
        raise AssertionError("empty list should fail safe_eval")
    except Exception:
        pass

    assert safe_eval("{'a': 'b'}") == {'a': 'b'}

# Generated at 2022-06-21 07:51:26.711513
# Unit test for function safe_eval
def test_safe_eval():
    # basic testing to ensure that safe eval works as intended
    # for most common cases

    def _eval(expr, locals=None):
        return safe_eval(expr, locals, include_exceptions=True)

    # re-enable these functions as a test
    CALL_ENABLED.extend(['sorted', 'set', 'dict'])

    assert _eval('1 + 1') == (2, None)
    assert _eval('dict(foo=1, bar=2)') == ({'foo': 1, 'bar': 2}, None)
    assert _eval("""{% if testvar is defined %}
    {{ testvar }}
{% else %}
    default
{% endif %}""", dict(testvar="foo")) == ('foo', None)

    # make sure that literal_eval still works
    assert ast.literal

# Generated at 2022-06-21 07:51:39.515067
# Unit test for function safe_eval
def test_safe_eval():
    # All of the following lines should return True
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 == 1')
    assert safe_eval('1 != 2')
    assert safe_eval('1 < 2')
    assert safe_eval('1 > 2')
    assert safe_eval('1 <= 1')
    assert safe_eval('1 >= 1')
    assert safe_eval('true and true') == True
    assert safe_eval('false and true') == False
    assert safe_eval('true and false') == False
    assert safe_eval('false and false') == False
    assert safe_eval('true or false') == True

# Generated at 2022-06-21 07:51:47.588825
# Unit test for function safe_eval
def test_safe_eval():
    expr = "'this is a string'"
    actual = safe_eval(expr)
    assert actual == expr

    expr = "true and false"
    actual = safe_eval(expr)
    assert actual is False

    expr = "1 == 1"
    actual = safe_eval(expr)
    assert actual is True

    # This example tries to call json.loads, which is not allowed
    expr = "json.loads('[1,2,3]')"
    actual = safe_eval(expr)
    assert actual == expr

    # This example is allowed
    expr = "[1,2,3]"
    actual = safe_eval(expr)
    assert actual == [1, 2, 3]

# unit test helper to detect if we are in a unit test (no __main__)

# Generated at 2022-06-21 07:51:58.835475
# Unit test for function safe_eval
def test_safe_eval():
    # Test that literal values pass
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('42') == 42
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 2 - 3') == 0
    assert safe_eval('1 + 2 - 3 * 4 / 5') == 0.6
    assert safe_eval('"foo" in ["foo", "bar"]') is True

# Generated at 2022-06-21 07:52:11.866620
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("0") == 0
    assert safe_eval("1") == 1
    assert safe_eval("False") == False
    assert safe_eval("True") == True
    assert safe_eval("27") == 27
    assert safe_eval("True or False") == True
    assert safe_eval("True and False") == False
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("dict([('key', 'value')])") == {'key': 'value'}
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}
    assert safe_eval("True and None") is None
    assert safe_eval("False or None") is False
    assert safe_eval("True or False or None") is True
    assert safe

# Generated at 2022-06-21 07:52:21.119487
# Unit test for function safe_eval
def test_safe_eval():

    # Test that None and True are not interpreted as strings
    expr = 'v1 == None or v1 == True'
    var = {'v1': "None"}
    result = safe_eval(expr, var)
    assert result is True
    var = {'v1': "True"}
    result = safe_eval(expr, var)
    assert result is True

    # Test that types are preserved
    expr = 'v1 is True'
    var = {'v1': True}
    result = safe_eval(expr, var)
    assert result is True
    expr = 'v1 is False'
    var = {'v1': False}
    result = safe_eval(expr, var)
    assert result is True
    expr = 'v1 is None'
    var = {'v1': None}
    result = safe

# Generated at 2022-06-21 07:52:32.427570
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: Normal python defines
    s = "a = 10"
    r = safe_eval(s)
    if s == r:
        sys.exit("FAIL: Test 1 (Normal python defines)")
    else:
        print("Success: Test 1 (Normal python defines)")

    # Test 2: Simple assignment
    s = "a = 1+2"
    r = safe_eval(s)
    if s == r:
        sys.exit("FAIL: Test 2 (Simple Assignment)")
    else:
        print("Success: Test 2 (Simple Assignment)")

    # Test 3: Multi line python expression
    s = "a = 1+2\nb = 2+3"
    r = safe_eval(s)

# Generated at 2022-06-21 07:52:45.556946
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:56.731821
# Unit test for function safe_eval
def test_safe_eval():
    true = None
    false = None

    # Test basic python eval() features
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('0') == 0
    assert safe_eval('1') == 1
    assert safe_eval('3.14') == 3.14
    assert safe_eval('"a"') == "a"
    assert safe_eval('True or False') is True
    assert safe_eval('False or True') is True
    assert safe_eval('False or False') is False
    assert safe_eval('True and False') is False
    assert safe_eval('True and True') is True
    assert safe_eval('False and True') is False
    assert safe_eval('0 == 1') is False
    assert safe_

# Generated at 2022-06-21 07:53:07.396223
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval with different kind of data

    - Role var
    - Host var
    - Jinja2 expression
    - Python expression

    All of above should return the right type with right content
    """
    test_module = '{{ foo }}'
    test_group_var = '{{ hostvars["example.com"]["foo"] }}'
    test_host_var = '{{ ansible_hostname }}'
    test_jinja2 = '{{ [1, 2] }}'
    # Test string is the same as test_jinja2, but it shouldn't be evaluated,
    # since it's not a valid python expression.
    test_python_string = '{{ [1, 2] }}'
    test_python_exp = '[1, 2]'

    # Test values

# Generated at 2022-06-21 07:53:19.759563
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic functionality
    assert safe_eval('2 + 3') == 2 + 3
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 2, "b": 3}') == {"a": 2, "b": 3}
    assert safe_eval('2 + 3', include_exceptions=True) == (2 + 3, None)
    assert safe_eval('z + 3') == "z + 3"
    assert safe_eval('z + 3', include_exceptions=True) == ('z + 3', None)

    # Test specific exceptions

# Generated at 2022-06-21 07:53:27.709766
# Unit test for function safe_eval
def test_safe_eval():
    # First test the built-in constant folding for the simple case
    assert safe_eval('100 + 1') == 101
    assert safe_eval('100 - 1') == 99
    assert safe_eval('100 / 2') == 50
    assert safe_eval('100 * 2') == 200
    assert safe_eval('100 * (2 + 2) + 1') == 401
    assert safe_eval('100 * (2 + 2) + (1 - 1)') == 400
    assert safe_eval('(100 + 100) * 2 + 1') == 401
    assert safe_eval('(100 + 100) * 2 + (1 - 1)') == 400
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('1 + 2 * 3 + 4') == 11
    assert safe_eval('(1 + 2) * 3 + 4')

# Generated at 2022-06-21 07:53:39.979301
# Unit test for function safe_eval
def test_safe_eval():
    # load jinja2 env
    from ansible import context
    from ansible.template import Templar

    context._init_global_context(None)
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)

    # Test basic expressions
    ansible_1 = templar.template('{{ 1 + 4 }}', convert_bare=True)
    assert safe_eval(ansible_1) == 5
    ansible_4 = templar.template('{{ 1 + 4.01 }}', convert_bare=True)
    assert safe_eval(ansible_4) == 5.01
    ansible_5 = templar.template('{{ [1] + [4, 5] }}', convert_bare=True)
    assert safe_eval(ansible_5) == [1, 4, 5]


# Generated at 2022-06-21 07:53:49.408325
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('1 | 2') == 1 | 2
    assert safe_eval('1 & 2') == 1 & 2
    assert safe_eval('1 == 2') == 1 == 2
    assert safe_eval('1 != 2') == 1 != 2
    assert safe_eval('1 < 2') == 1 < 2
    assert safe_eval('1 > 2') == 1 > 2
    assert safe_eval('1 <= 2') == 1 <= 2
    assert safe_eval('1 >= 2') == 1 >= 2
    assert safe_eval('1 + 2') == 1 + 2
    assert safe_eval('1 - 2') == 1 - 2
    assert safe_eval

# Generated at 2022-06-21 07:54:00.033190
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:10.711447
# Unit test for function safe_eval
def test_safe_eval():
    # supported syntax
    assert safe_eval('1 + 2') == 3
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('(1, 2)') == (1, 2)
    assert safe_eval('["a", "b"]') == ["a", "b"]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('ansible_system') == "ansible_system"

    if sys.version_info >= (3, 0):
        assert safe_eval('1 > 2') is False
        assert safe_eval('1 < 2') is True
        assert safe_eval('1 == 1') is True

# Generated at 2022-06-21 07:54:18.162722
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:32.872040
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for safe_eval

    tests expect to run with the following env variables set:
    ANSIBLE_KEEP_REMOTE_FILES=1
    ANSIBLE_REMOTE_TEMP=/tmp

    :return: None
    '''
    # Test for bad string being evaluated
    assert safe_eval('os.system("ls -al")') == 'os.system("ls -al")'

    # Test for good string being evaluated (all string ops are allowed)
    assert safe_eval('a'*10) == 'aaaaaaaaaa'
    assert safe_eval('"hello " + "world!"') == 'hello world!'
    assert safe_eval('"hello "*2') == 'hello hello '
    assert safe_eval('"hello "*2 + "world"') == 'hello hello world'

    # Test for good

# Generated at 2022-06-21 07:54:41.831805
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:54.166348
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:05.279592
# Unit test for function safe_eval
def test_safe_eval():
    import os
    import sys

    class ReturnException(Exception):
        pass

    class Return(object):
        '''Decorator to return after a function runs'''
        def __init__(self, expr):
            self.expr = expr

        def __call__(self, func):
            def wrapped(*args, **kwargs):
                try:
                    func(*args, **kwargs)
                except ReturnException:
                    pass
                return self.expr
            return wrapped

    class TestException(Exception):
        '''Exception raised on failed unit test'''
        def __init__(self, value):
            Exception.__init__(self)
            self.value = value

        def __str__(self):
            return repr(self.value)


# Generated at 2022-06-21 07:55:17.301228
# Unit test for function safe_eval
def test_safe_eval():
    # verifying that common python expressions evaluate correctly
    assert safe_eval('2 + 3') == 5
    assert safe_eval('answers[0]', {'answers': [42]}) == 42
    assert safe_eval('false or true') is True
    assert safe_eval('false and true') is False
    assert safe_eval('foo[1]', {'foo': (1, 2, 3)}) == 2
    assert safe_eval('foo.bar', {'foo': {'bar': 'test'}}) == 'test'
    assert safe_eval('isinstance(1, int)') is True
    assert safe_eval('isinstance(1, dict)') is False

    # verifying that certain malformed expressions do not evaluate
    assert safe_eval('__import__("os")') == '__import__("os")'
   

# Generated at 2022-06-21 07:55:23.997389
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{foo}}") == u"{{foo}}"
    assert safe_eval("foo") == u"foo"
    assert safe_eval("true") == True
    assert safe_eval("false") == False
    assert safe_eval("{{ True }}") == True
    assert safe_eval("{{ False }}") == False

    assert safe_eval("{{foo}}", {'foo': 1}) == 1
    assert safe_eval("{{foo}}", {'foo': 1 + 3}) == 4
    assert safe_eval("{{foo}}", {'foo': 1 + 3}, include_exceptions=True)[0] == 4
    assert safe_eval("{{foo}}", {'foo': 1 + 3}, include_exceptions=True)[1] is None


# Generated at 2022-06-21 07:55:35.513605
# Unit test for function safe_eval
def test_safe_eval():
    # shouldn't throw an exception
    safe_eval('1 + 1')

    # shouldn't throw an exception
    safe_eval('true')

    # shouldn't throw an exception
    safe_eval('false')

    # shouldn't throw an exception
    safe_eval('null')

    # shouldn't throw an exception
    safe_eval('"foobar"')

    # shouldn't throw an exception
    safe_eval('1 + 1 < 10')

    # shouldn't throw an exception
    safe_eval('"a" in foo')

    # should throw an exception as __import__ is not whitelisted
    try:
        safe_eval('__import__')
    except Exception as e:
        pass
    else:
        sys.exit(1)

    # should throw an exception as foo() is not whitelisted

# Generated at 2022-06-21 07:55:45.776781
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(None) is None
    assert safe_eval(1) == 1
    assert safe_eval(1.1) == 1.1
    assert safe_eval('testing') == 'testing'
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1') == -1
    assert safe_eval('-1.1') == -1.1
    assert safe_eval('testing') == 'testing'
    assert safe_eval('"testing"') == 'testing'
    assert safe_eval(True) is True
    assert safe_eval('True') is True
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None
    assert safe_eval('None') is None

# Generated at 2022-06-21 07:55:58.679883
# Unit test for function safe_eval
def test_safe_eval():
    BADEXPR = "__import__('os').system('ls')"
    EVAL_FAIL = "dictionary['key']"
    assert safe_eval("hello") == "hello"
    assert safe_eval("1+1") == "1+1"
    assert safe_eval("{{ hi }}") == "{{ hi }}"
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("()") == ()
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("()") == ()
    assert safe_eval("(1,2,3)") == (1, 2, 3)

# Generated at 2022-06-21 07:56:06.507491
# Unit test for function safe_eval
def test_safe_eval():
    """
    There are many tests for safe_eval, in the test/sanity directory.
    These tests are for the special cases that are not covered there.

    >>> test_safe_eval()
    True
    """
    from ansible.module_utils.six import PY3

    # Test variables that are always allowed
    assert safe_eval("True")
    assert safe_eval("False")
    assert safe_eval("None")
    assert safe_eval("null")
    assert safe_eval("true")
    assert safe_eval("false")

    # Test string constants are allowed in Python 3
    if PY3:
        assert safe_eval("'abc'")

    # Test empty tuples are allowed
    assert safe_eval("()")
    assert safe_eval("[]")
    assert safe_eval("{}")
    assert safe

# Generated at 2022-06-21 07:56:25.662560
# Unit test for function safe_eval
def test_safe_eval():
    # basic test
    result = safe_eval("foo")
    assert result == "foo", result

    # simple test with constants/builtins
    result = safe_eval("foo == 'foo'")
    assert result

    # simple test with unusual unquoted string
    result = safe_eval("foo == foo")
    assert result

    # simple test with unusual unquoted string
    result = safe_eval("foo == True")
    assert result

    # simple test with unusual unquoted string
    result = safe_eval("foo == None")
    assert result

    # test with quoted dict
    result = safe_eval('{"foo": "bar"}')
    assert result == {"foo": "bar"}, result

    # test with quoted list
    result = safe_eval('["foo", "bar"]')

# Generated at 2022-06-21 07:56:33.582534
# Unit test for function safe_eval
def test_safe_eval():
    success = ('True', 'False', 'None', '1', '1.5',
               '"string"', "'string'", "'1.3'", '[]', '{}',
               '[1, 2, [3, 4]]', '{"a": "b"}',
               #'{1: 3, 4: 5}',  # fails because of the int keys
               '{"moo": "cow"}',
              )
    for expr in success:
        result, exception = safe_eval(expr, include_exceptions=True)
        assert result == ast.literal_eval(expr), "Expected %s == %s" % (result, ast.literal_eval(expr))
        assert exception == None, "Expected no exception in %s" % (expr)


# Generated at 2022-06-21 07:56:46.166941
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:55.567259
# Unit test for function safe_eval
def test_safe_eval():
    # Tests whitelisted calls

    # Comparison operators
    assert safe_eval('42 < 23') is True
    assert safe_eval('42 > 23') is False
    assert safe_eval('42 == 42') is True
    assert safe_eval('42 != 42') is False
    assert safe_eval('42 == 42 and not 42 == 23') is True
    assert safe_eval('42 in [42, 23]') is True
    assert safe_eval('42 not in [42, 23]') is False

    # Arithmetic operators
    assert safe_eval('42 + 23') == 65
    assert safe_eval('42 - 23') == 19
    assert safe_eval('42 * 23') == 966
    assert safe_eval('42 / 2') == 21
    assert safe_eval('42 // 2') == 21

# Generated at 2022-06-21 07:57:08.294517
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:17.978460
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('-1.0') == -1.0
    assert safe_eval('()') == ()
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('[1]') == [1]
    assert safe_eval('[1, 2]') == [1, 2]

# Generated at 2022-06-21 07:57:30.570146
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:38.926699
# Unit test for function safe_eval
def test_safe_eval():
    # test that safe_eval can parse JSON and return a datastructure
    json_string = '{"a": [1,2,3], "b": [{"c": true}, {"d": [1, 2, 5]}]}'

    # import json module that we can use to validate our result against
    if sys.version_info[0] == 3:
        import importlib
        import_module = importlib.import_module
    else:
        import __builtin__ as builtins

    json = import_module('json')
    expected = json.loads(json_string, strict=False)
    actual = safe_eval(json_string)
    assert expected == actual

    # test that non-JSON expressions are returned as-is
    non_json = 'variable_name'
    actual = safe_eval(non_json)
    assert non

# Generated at 2022-06-21 07:57:50.758038
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit tests for safe_eval()
    '''

    def validate_expr(expr, result):
        '''
        validate the result of expr passed through the safe_eval function
        '''
        assert safe_eval(expr) == result
        assert safe_eval(expr, include_exceptions=True)[0] == result

    def validate_expr_exception(expr, exception):
        '''
        validate that expr passed through the safe_eval function
        raises the appropriate exception
        '''
        try:
            safe_eval(expr)
            assert False, "%s did not raise exception %s" % (expr, exception)
        except exception:
            pass


# Generated at 2022-06-21 07:58:03.362586
# Unit test for function safe_eval
def test_safe_eval():
    # Simple expressions
    assert safe_eval("1") == 1
    assert safe_eval("1+2") == 3
    assert safe_eval("~1") == -2
    assert safe_eval("not True") is False
    assert safe_eval("True or False") is True
    assert safe_eval("True and False") is False
    assert safe_eval("a_dict_var", locals=dict(a_dict_var=dict(a=1))) == dict(a=1)
    assert safe_eval("an_int_var", locals=dict(an_int_var=1)) == 1
    assert safe_eval("a_list_var", locals=dict(a_list_var=[1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-21 07:58:27.084818
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a+b', dict(a=1, b=2), include_exceptions=True) == (3, None)
    assert safe_eval('a+b', dict(a=1, b=2)) == 3
    assert safe_eval('a+b') == 'a+b'
    assert safe_eval('a+b', dict(a=1, b=2), include_exceptions=True)[1].args[0] == 'invalid expression (a+b)'
    assert safe_eval('import os', dict(a=1, b=2), include_exceptions=True)[1].args[0] == "invalid expression (import os)"



# Generated at 2022-06-21 07:58:39.190047
# Unit test for function safe_eval
def test_safe_eval():
    BACKUP_CALL_ENABLED = CALL_ENABLED[:]

    # test with valid expr
    CALL_ENABLED.extend(['sqrt', 'abs'])
    assert safe_eval("2 * 3") == 6
    assert safe_eval("sqrt(9)") == 3
    assert safe_eval("abs(9)") == 9
    assert safe_eval("2 * 3 + 1") == 7
    assert safe_eval("2 * (3 + 1)") == 8
    assert safe_eval("2 * -3") == -6
    assert safe_eval("-2 * 3") == -6
    assert safe_eval("2 * 3 - 1") == 5
    assert safe_eval("1-2") == -1
    assert safe_eval("0.5") == 0.5

# Generated at 2022-06-21 07:58:46.922092
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:58.680579
# Unit test for function safe_eval
def test_safe_eval():
    C.CALLABLE_WHITELIST = ['int', 'str', 'reversed', 'zip', 'equal']

    assert safe_eval("[2, 3]") == [2, 3]
    assert safe_eval("[2, 3]") == [2, 3]
    assert safe_eval("[2, 3]") == [2, 3]
    assert safe_eval("[2, 3]") == [2, 3]
    assert safe_eval("str(2)") == '2'
    assert safe_eval("int('2')") == 2
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)

# Generated at 2022-06-21 07:59:09.921705
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:20.175792
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text

    # Test cases that should not raise an exception, and the expected result

# Generated at 2022-06-21 07:59:31.444295
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval(u"{ 'foo': 'bar' }")
    assert type(result) == dict
    assert result == {u'foo': u'bar'}

    result = safe_eval(u"{ 'foo': 'bar' }", {}, True)
    assert type(result) == tuple
    assert type(result[0]) == dict
    assert result[0] == {u'foo': u'bar'}
    assert result[1] == None

    result = safe_eval(u"{ 'foo': 'bar', 'baz': 1 }", {}, True)
    assert type(result) == tuple
    assert type(result[0]) == dict
    assert result[0] == {u'foo': u'bar', u'baz': 1}
    assert result[1] == None

    result = safe_

# Generated at 2022-06-21 07:59:39.494399
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    my_builtin = '__builtins__'
    my_name = 'test'
    my_function = '__import__'

    # call safe_eval() to test cases

# Generated at 2022-06-21 07:59:51.637401
# Unit test for function safe_eval
def test_safe_eval():
    """
    Unit test for function safe_eval
    """
    pass_tuples = [
        ('item in foo_list', None),
        ('item in [1, 2, 3, 4]', None),
        ('item > 3', None),
        ('item < 3', None),
        ('item == 3', None),
        ('item != 3', None),
        ('item is not defined', None),
        ('item is defined', None),
    ]

    for s, exp_exc in pass_tuples:
        try:
            res = safe_eval(s)
            assert exp_exc is None
            assert res == eval(s)
        except Exception as x:
            assert exp_exc == type(x)


# Generated at 2022-06-21 07:59:59.086612
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-21 08:00:43.061724
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # a very simple expression, evaluate to True
    expr = 'a == 5'
    result = safe_eval(expr, dict(a=5))
    assert result is True

    # a simple example of a JSON-like data structure
    expr = '''
    {
        "authors": [
            "Elliot"},
            "Jasper"
        ]
    }
    '''.strip()
    result = safe_eval(expr)
    assert result['authors'] == ['Elliot', 'Jasper']

    # a string representation of a list
    expr = "[ 1, 2, 3 ]"
    result = safe_eval(expr)
    assert result == [1, 2, 3]

    # an empty list
    expr = "[]"
    result = safe_eval(expr)
    assert result == []

    # simple

# Generated at 2022-06-21 08:00:54.744749
# Unit test for function safe_eval