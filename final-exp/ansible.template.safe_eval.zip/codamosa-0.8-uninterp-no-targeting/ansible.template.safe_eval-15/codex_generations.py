

# Generated at 2022-06-21 07:51:02.419910
# Unit test for function safe_eval
def test_safe_eval():
    ''' test safe_eval '''

    # expression list to be tested.

# Generated at 2022-06-21 07:51:14.341616
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("['a', 'b']") == ['a', 'b']
    assert safe_eval("['a', 'b', 1]") == ['a', 'b', 1]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': None, 'b': 2}") == {'a': None, 'b': 2}
    assert safe_eval("{'a': False, 'b': 2}") == {'a': False, 'b': 2}
    assert safe_eval("{'a': True, 'b': 2}") == {'a': True, 'b': 2}

# Generated at 2022-06-21 07:51:26.435912
# Unit test for function safe_eval
def test_safe_eval():
    # Disable the linters, these are needed for the function to work.
    # pylint: disable=undefined-variable,unused-variable
    global SAFE_NODES, CALL_ENABLED

    # First test without allowing any calls
    SAFE_NODES = set((ast.Load, ast.Name, ast.Constant))

    expr = 'a'
    result = safe_eval(expr)
    assert result == 'a'

    expr = 'a.upper()'
    result = safe_eval(expr, dict(a='a'))
    assert result == 'a'

    # permit calls to certain functions
    SAFE_NODES = set((ast.Load, ast.Name, ast.Constant, ast.Call))
    CALL_ENABLED = set(('upper',))


# Generated at 2022-06-21 07:51:39.324507
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ var }}") == "{{ var }}"

    assert safe_eval("some string") == "some string"

    assert safe_eval("1 + 1") == 2

    # Strings (including multiline)
    assert safe_eval("this is a string") == "this is a string"
    assert safe_eval("'this' 'is' 'a' 'string'") == "this is a string"
    assert safe_eval('"""this is a \n multiline string"""') == "this is a \n multiline string"

    # Lists, tuples, and sets
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-21 07:51:47.793377
# Unit test for function safe_eval
def test_safe_eval():
    # Just a few tests for the safe_eval function

    assert safe_eval('False') is False
    assert safe_eval('False and True') is False
    assert safe_eval('True or False') is True

    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('"foo" + "bar" + "baz"') == 'foobarbaz'
    assert safe_eval('("foo", "bar")') == ('foo', 'bar')
    assert safe_eval('("foo", "bar", "baz")') == ('foo', 'bar', 'baz')

    assert safe_eval('{"foo": "bar", "baz": "blam"}') == {"foo": "bar", "baz": "blam"}



# Generated at 2022-06-21 07:51:59.105656
# Unit test for function safe_eval
def test_safe_eval():

    # test empty string
    assert safe_eval("")

    # test a literal string
    assert safe_eval("hello world")

    # test a simple expression
    assert safe_eval("5") == 5

    # test a simple mathematical expression
    assert safe_eval("5*5") == 25

    # test the addition of variables
    assert safe_eval("x + y", {'x':1, 'y':2}) == 3

    # test that actions are not allowed
    try:
        safe_eval("print hello")
    except Exception as e:
        assert 'invalid expression' in str(e)
    else:
        assert False, "expected an exception"

    # test that unallowed functions are not allowed

# Generated at 2022-06-21 07:52:12.122259
# Unit test for function safe_eval
def test_safe_eval():

    set_locals = False
    set_globals = False

    # we want to test the effect of setting locals and globals
    locals_dict = {'z': 10, 't': 'test'}
    globals_dict = {'a': 'foo', 'b': 2}

    if set_locals:
        if not set_globals:
            raise Exception("When setting locals, must also set globals")
    elif set_globals:
        raise Exception("When setting globals, must also set locals")

    # Test various data types

# Generated at 2022-06-21 07:52:21.313477
# Unit test for function safe_eval
def test_safe_eval():
    print("testing safe_eval")

# Generated at 2022-06-21 07:52:32.626509
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is a unit test for the module_utils/safe_eval function
    """
    def set_conversion(val):
        """
        This function is used to ensure that sets are converted back to the
        original set format, ie: set([1, 2]) should be converted to {1, 2}
        """
        if isinstance(val, set):
            return "{{{}}}".format(', '.join([str(x) for x in val]))
        return str(val)
    # Build up a dictionary of expression, expected result
    # This is used as the basis of testing

# Generated at 2022-06-21 07:52:40.226340
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[:2] < (2, 7):
        return

    assert safe_eval(None) == None
    assert safe_eval(True)
    assert safe_eval('True')
    assert safe_eval('False') == False
    assert safe_eval('5') == 5
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('()') == ()
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('{}') == {}
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('{"a": 1}') == {"a": 1}

# Generated at 2022-06-21 07:52:54.611591
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:02.795630
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:15.136082
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ foo.bar }}") == "{{ foo.bar }}"
    assert safe_eval("{{ foo['bar'] }}") == "{{ foo['bar'] }}"
    assert safe_eval("{{ foo.bar | map(attribute='bam') }}") == "{{ foo.bar | map(attribute='bam') }}"
    assert safe_eval("'{{ foo }}'") == "'{{ foo }}'"
    assert safe_eval("'{{ foo.bar }}'") == "'{{ foo.bar }}'"
    assert safe_eval("'{{ foo['bar'] }}'") == "'{{ foo['bar'] }}'"

# Generated at 2022-06-21 07:53:25.622067
# Unit test for function safe_eval
def test_safe_eval():
    # Custom exceptions
    class SyntaxError2(Exception):
        pass

    class ImportError2(Exception):
        pass

    class ValueError2(Exception):
        pass

    def keywords_allowed(expr):
        # Check if keywords are allowed
        try:
            safe_eval(expr)
        except SyntaxError2:
            return False
        return True

    def true_functions_allowed(expr):
        # Check if functions with a 'true' return value are allowed
        try:
            return safe_eval(expr)
        except ValueError2:
            return False
        return True

    def false_functions_allowed(expr):
        # Check if functions with a 'false' return value are allowed
        try:
            return safe_eval(expr)
        except ImportError2:
            return False
        return True


# Generated at 2022-06-21 07:53:38.156559
# Unit test for function safe_eval
def test_safe_eval():
    ast_name_test_cases = {
        'true': True,
        'false': False,
        'null': None,
        C.DEFAULT_UNDEFINED_VAR_BEHAVIOR: None,
        'foo': 'foo',
        '"foo"': 'foo',
        '"foo" + 1': 'foo1',
        'False and True or "foo"': 'foo',
        '"foo" + (1 - 1)': 'foo0',
        '1' + '1': '11',
    }


# Generated at 2022-06-21 07:53:42.593226
# Unit test for function safe_eval
def test_safe_eval():
    """
    simple test to make sure the safe_eval() method works
    """
    test_pass = 0
    test_fail = 0

    print("Running safe_eval() test")
    print("=======================")


# Generated at 2022-06-21 07:53:50.782433
# Unit test for function safe_eval
def test_safe_eval():

    # setup
    FAIL_MSG = "safe_eval: '{0}' should have failed with {1}"
    PASS_MSG = "safe_eval: '{0}' passed as expected"

    def pass_test(test_string, locals=None, exception_expected=None):
        if exception_expected is not None:
            msg = FAIL_MSG.format(test_string, exception_expected)
            assert False, msg
        else:
            msg = PASS_MSG.format(test_string)
            print(msg)

    def fail_test(test_string, locals=None, exception_expected=None):
        (result, exception) = safe_eval(test_string, locals, include_exceptions=True)

# Generated at 2022-06-21 07:54:01.463941
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:12.070745
# Unit test for function safe_eval
def test_safe_eval():
    # Test normal case
    expr = "output.stdout.find('value') > 0"
    result = safe_eval(expr)
    assert result == expr
    assert type(result) == str

    # Test JSON formatting
    expr = "[{'ansible_facts': {'distribution': 'Ubuntu'}}]"
    result = safe_eval(expr)
    text = container_to_text(result)
    assert text == expr
    assert type(result) == list
    assert type(result[0]) == dict

    # Test JSON styling
    expr = "[{'ansible_facts': {'distribution': 'Ubuntu'}}]"
    expr2 = "[{'ansible_facts':{'distribution':'Ubuntu'}}]"
    result = safe_eval(expr)
    result2 = safe_eval(expr2)

# Generated at 2022-06-21 07:54:18.827502
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:31.916674
# Unit test for function safe_eval
def test_safe_eval():
    failed = 0

# Generated at 2022-06-21 07:54:41.202759
# Unit test for function safe_eval
def test_safe_eval():
    # avoid logging error messages during testing
    C.DEFAULT_LOG_PATH = '/dev/null'

    # test with list
    test_result = safe_eval(["a", "b"])
    assert test_result == ["a", "b"]

    # test with dict
    test_result = safe_eval({"a": 1, "b": 2})
    assert test_result == {"a": 1, "b": 2}

    # test with string
    test_result = safe_eval("a")
    assert test_result == "a"

    # test with unicode string
    test_result = safe_eval(u"a")
    assert test_result == "a"

    # test with integer
    test_result = safe_eval(1)
    assert test_result == 1

    # test with float
    test_

# Generated at 2022-06-21 07:54:53.690727
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'a + b'
    locals_ = {'a':1, 'b': 2}
    res = safe_eval(expr, locals_)
    assert res == 3

    expr = 'a + b'
    locals_ = {'a':1, 'b': 2}
    res, exc = safe_eval(expr, locals_, include_exceptions=True)
    assert res == 3
    assert exc is None

    expr = 'a + b'
    locals_ = {'a':1, 'b': 2, 'open': True}
    res, exc = safe_eval(expr, locals_, include_exceptions=True)
    assert res == 3
    assert exc is None

    expr = 'a + b'
    locals_ = {'a':1, 'b': 2, 'open': True}
    exc

# Generated at 2022-06-21 07:55:00.987539
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    test_input_vars = {
        'a_string': 'value',
        'a_list': [1, 2, 3],
        'a_dict': {'name': 'Joe', 'age': 30}
    }

    # valid expression
    assert safe_eval('a_string', test_input_vars) == 'value'
    assert safe_eval('a_list', test_input_vars) == [1, 2, 3]
    assert safe_eval('a_dict', test_input_vars) == {'name': 'Joe', 'age': 30}

    # not a valid expression
    try:
        safe_eval('a_dict()', test_input_vars)
    except Exception as e:
        pass

# Generated at 2022-06-21 07:55:13.381376
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2 * 3 * 4") == 24
    assert safe_eval("dict(a=1)") == dict(a=1)
    assert safe_eval("[]") == []
    assert safe_eval("()") == ()
    assert safe_eval("True")
    assert safe_eval("False") is None
    assert safe_eval("False or True")
    assert not safe_eval("False or False")
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{1:'one',2:'two',3:'three'}") == {1:'one',2:'two',3:'three'}
    assert safe_eval("(1,2,3)") == (1,2,3)

# Generated at 2022-06-21 07:55:23.768655
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.import_module import import_module

    add_all_plugin_dirs()
    import_module('lib.ansible.modules.commands.command')
    import_module('lib.ansible.modules.files.stat')
    import_module('lib.ansible.modules.files.file')

    def check_expr(expr, expected, locals=None, include_exceptions=False):
        # Check that safe_eval() applied to `expr` returns `expected`
        # when given the context defined by locals
        locals = {} if locals is None else locals
        if include_exceptions:
            result, exception = safe_eval(expr, locals,
                                          include_exceptions=True)

# Generated at 2022-06-21 07:55:35.286612
# Unit test for function safe_eval
def test_safe_eval():
    # All of these should succeed
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 * 2") == 4
    assert safe_eval("1 > 0") == True
    assert safe_eval("1 < 0") == False
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("{'a':1, 'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("2**2") == 4

# Generated at 2022-06-21 07:55:45.584390
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('42', dict()) == 42
    assert safe_eval('[42]', dict()) == [42]
    assert safe_eval('True', dict()) is True
    assert safe_eval('False', dict()) is False
    assert safe_eval('None', dict()) is None
    assert safe_eval('False and None', dict()) is False
    assert safe_eval('123 + 321', dict()) == 444
    assert isinstance(safe_eval('"test"', dict()), str)

    # We do want to allow expressions:
    assert safe_eval('"test" + "ing"', dict()) == "testing"

    # For now, we do not want to allow functions:
    assert '__builtins__' not in safe_eval('__builtins__', dict())

# Generated at 2022-06-21 07:55:58.423999
# Unit test for function safe_eval
def test_safe_eval():
    '''
    test_safe_eval: Test safe_eval with various inputs

    Parameters:
    - None

    Output:
    - None

    Exceptions:
    - None
    '''

# Generated at 2022-06-21 07:56:07.027448
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:23.432592
# Unit test for function safe_eval
def test_safe_eval():
    # With default set of allowed nodes
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("1 + 1") == 2
    assert safe_eval("[ x * 2 for x in range(3) ]") == [0, 2, 4]
    assert safe_eval("{ x: 'foo' for x in range(3) }") == {0: 'foo', 1: 'foo', 2: 'foo'}
    assert safe_eval("1 + foo") == "1 + foo"
    assert safe_eval("{'foo': foo}") == "{'foo': foo}"
    assert safe_eval("{'foo': len(foo)}") == "{'foo': len(foo)}"

# Generated at 2022-06-21 07:56:32.177843
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:44.910625
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_KEEP_REMOTE_FILES:
        sys.stderr.write("Unable to execute unit tests while ansible is configured to keep remote files.\n")
        sys.exit(2)

    def mock_print(msg):
        print(msg)
        sys.stdout.flush()

    def run_test(name, test_to_run, expected_results):
        passed = True
        print("TEST CASE: %s" % name)

        for test in test_to_run:
            result = safe_eval(test[0], test[1])
            if result != test[2]:
                mock_print("FAIL: %s" % container_to_text(test))
                mock_print("     Expected: %s" % container_to_text(test[2]))
               

# Generated at 2022-06-21 07:56:49.456060
# Unit test for function safe_eval
def test_safe_eval():

    # Check if safe_eval whitelist is configured correctly
    # with all known builtins disallowed
    try:
        safe_eval('str(\'foo\')')
    except Exception:
        pass
    else:
        if sys.version_info[0] == 2 and sys.version_info[1] < 7:
            raise AssertionError("str() should not be included in safe_eval whitelist")
        elif sys.version_info[0] >= 3:
            raise AssertionError("str() should not be included in safe_eval whitelist")

    # Check if safe_eval whitelist is configured correctly
    # with safe builtins allowed
    assert safe_eval('[1, 2]') == [1, 2]

    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2') != 4

# Generated at 2022-06-21 07:56:56.646416
# Unit test for function safe_eval
def test_safe_eval():
    CALL_ENABLED = ['foo']

    # Cases where safe_eval should return string
    strings = [
        "'helloworld'",
        "helloworld",
        "helloworld|string",
        "helloworld[0]",
        "helloworld.split(',')",
        "helloworld.split(',')[0]",
        "helloworld.split(',')[0].strip()",
        "helloworld[0].strip()"
    ]

    for string in strings:
        result, exception = safe_eval(string, include_exceptions=True)
        if exception is not None:
            print("safe_eval test failed for expression: %s" % string)
            sys.exit(1)

# Generated at 2022-06-21 07:57:09.306617
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval('3 + 4') == 7
    safe_eval('x + y + z', {'x': 1, 'y': 2, 'z': 3}) == 6
    safe_eval('x + y + z', {'v': 1, 'w': 2, 'x': 3}) == 6
    # safe_eval('six.moves.xrange(3)') == range(3)
    safe_eval('True and False or False') == False
    safe_eval('"fail" in dir(six)') == False

    expression = '''
---
a: 1
b:
  - 1
  - 2
  - 3
'''
    result = {
        'a': 1,
        'b': [1, 2, 3],
    }

    assert safe_eval(expression) == result
    assert safe_eval

# Generated at 2022-06-21 07:57:19.633748
# Unit test for function safe_eval
def test_safe_eval():
    # add builtins whose calls we want to allow
    CALL_ENABLED.append('len')

    # basic string check
    safe_eval("'hello'")
    assert safe_eval("len('hello')") == 5
    assert safe_eval("len('hello')") == 5
    safe_eval("boolean_string = 'True'")
    safe_eval("boolean_string = 'False'")
    safe_eval("boolean_string = 'None'")

    # check if non-python types are allowed
    safe_eval("boolean_string = true")
    safe_eval("boolean_string = null")
    safe_eval("boolean_string = false")

    # check if exception is thrown on invalid type
    safe_eval("len(fail)")
    safe_eval("range(10)")

    # check

# Generated at 2022-06-21 07:57:31.793787
# Unit test for function safe_eval
def test_safe_eval():
    # Function must raise Exception if there are undefined variables in expr
    if safe_eval("{{ foo }}") != "{{ foo }}":
        print("safe_eval could not handle Jinja2 variable")
        sys.exit(1)

    if safe_eval("{{ foo['bar'] }}") != "{{ foo['bar'] }}":
        print("safe_eval could not handle Jinja2 variable")
        sys.exit(1)

    if safe_eval("{{ foo.bar }}") != "{{ foo.bar }}":
        print("safe_eval could not handle Jinja2 variable")
        sys.exit(1)

    if safe_eval("{{ foo['bar'] + foo.baz }}") != "{{ foo['bar'] + foo.baz }}":
        print("safe_eval could not handle Jinja2 variable")
        sys.exit(1)

# Generated at 2022-06-21 07:57:39.401371
# Unit test for function safe_eval
def test_safe_eval():

    def safe_eval_test(expr):
        ret, err = safe_eval(expr, include_exceptions=True)
        print("    '%s' ==> '%s' (error: %s)" % (expr, ret, err))


# Generated at 2022-06-21 07:57:51.212291
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic
    import ansible.constants as C

    basic._ANSIBLE_ARGS = basic.AnsibleArgs({'no_log': True})


# Generated at 2022-06-21 07:58:06.949383
# Unit test for function safe_eval
def test_safe_eval():

    def is_exception(obj):
        if isinstance(obj, tuple):
            if len(obj) == 2:
                return True
        return False


# Generated at 2022-06-21 07:58:18.273652
# Unit test for function safe_eval
def test_safe_eval():

    # --- test that safe_eval works as a drop-in replacement for eval
    assert safe_eval('') == eval('')
    assert safe_eval('1') == eval('1')
    assert safe_eval('None') == eval('None')
    assert safe_eval('True') == eval('True')
    assert safe_eval('False') == eval('False')
    assert safe_eval('"foo"') == eval('"foo"')
    assert safe_eval('["foo", "bar", "baz"]') == eval('["foo", "bar", "baz"]')
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == eval('{"foo": "bar", "baz": "qux"}')

# Generated at 2022-06-21 07:58:24.948905
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]

    assert safe_eval("a", dict(a=1)) == 1
    assert safe_eval("a.split()", dict(a='1 2 3')) == ['1', '2', '3']
    assert safe_eval("'_'.join(a)", dict(a=['1', '2', '3'])) == '1_2_3'

    assert safe_eval("a", dict(a='1.2')) == '1.2'
    assert safe_eval("float(a)", dict(a='1.2')) == 1.2
    assert safe_eval("str(a)", dict(a=1.2)) == '1.2'

# Generated at 2022-06-21 07:58:37.004665
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-21 07:58:45.894594
# Unit test for function safe_eval
def test_safe_eval():
    # Create test structure
    test_dict = dict(
        single_num=1,
        double_num=2,
        dict_num=dict(
            num=99,
        ),
        list_num = [
            1, 2, 3, 4, 5,
        ],
        nested_list = [
            [
                1, 2, 3, 4, 5,
            ],
            [
                6, 7, 8, 9, 10,
            ],
        ],
        nested_dict = dict(
            dict1=dict(
                a=1,
                b=2,
                c=3,
            ),
            dict2=dict(
                d=4,
                e=5,
                f=6,
            ),
        ),
    )

    # Add some test data to the locals()
    test_

# Generated at 2022-06-21 07:58:57.461353
# Unit test for function safe_eval
def test_safe_eval():
    # check that None evaluates to None
    result = safe_eval('None')
    assert result is None

    # check that boolean values work
    result = safe_eval('true')
    assert result is True
    result = safe_eval('false')
    assert result is False

    # check that string values are passed through
    result = safe_eval('')
    assert result == ''
    result = safe_eval('"foobar"')
    assert result == 'foobar'

    # check that integers work
    result = safe_eval('42')
    assert result == 42

    # check that we are able to add integers
    result = safe_eval('1 + 1')
    assert result == 2

    # check that we are able to subtract integers
    result = safe_eval('2 - 1')
    assert result == 1

    # check that we

# Generated at 2022-06-21 07:59:08.184809
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    if sys.version_info[0] > 2:
        from ast import Constant
        from ansible.module_utils.common.text.extras.dummy_compat import StringIO
    else:
        from ansible.module_utils.common.text.extras.dummy_compat import StringIO, Constant

    def _check_eval(expr, expected=None):
        # for convenience a basic equal test
        if expected is not None:
            assert safe_eval(expr) == expected
        # also test the exceptions version
        result, exception = safe_eval(expr, include_exceptions=True)
        if expected is not None:
            assert result == expected, "expected %s to equal %s" % (result, expected)

# Generated at 2022-06-21 07:59:17.445404
# Unit test for function safe_eval
def test_safe_eval():
    # Test various inputs to safe_eval to make sure that the legal ones
    # evaluate to the expected output, and that the illegal ones raise an
    # exception.

    # test that exceptions preserve the original input in the msg
    try:
        safe_eval("{{ bad_var }}")
    except Exception as e:
        assert "bad_var" in to_native(e)

    assert safe_eval("{{ foo }}") == '{{ foo }}'
    assert safe_eval("{{ foo }}", dict(foo='bar')) == "bar"

    try:
        safe_eval("{{ foo }}", dict(foo='bar'), True)
    except Exception as e:
        assert "foo" not in to_native(e)

    assert safe_eval("1 + 1") == 2

# Generated at 2022-06-21 07:59:25.042379
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']
    assert safe_eval("{'a':'foo', 'b':'bar', 'c':'baz'}") == {'a':'foo', 'b':'bar', 'c':'baz'}
    try:
        safe_eval("__import__('os').getcwd()")
    except Exception:
        pass
    else:
        assert False, "safe_eval allowed __import__('os')"



# Generated at 2022-06-21 07:59:35.020149
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''
    #  Safe

# Generated at 2022-06-21 07:59:54.433521
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple functions
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1 + 2") == 3
    assert safe_eval("'this is a string'") == 'this is a string'
    assert safe_eval("(1, 2)") == (1, 2)
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{1: 'a'}") == {1: 'a'}

    # Test variable input
    var1 = "a variable"
    var2 = [1, 2]
    assert safe_eval("var1") == "a variable"
    assert safe_eval("var2") == [1, 2]

    # Test failing functions

# Generated at 2022-06-21 08:00:05.680367
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_DEBUG:
        assert safe_eval('{"a":2}') == {"a":2}
        assert safe_eval('2+2') == 4
        assert safe_eval('2+3') == 5
        assert safe_eval('2+3', locals={'a':5, 'b':6}) == 5
        assert safe_eval('a+b', locals={'a':5, 'b':6}) == 11
        assert safe_eval('a+b', locals={'a':5, 'b':6, '__builtins__':{'foo':'bar'}}) == 11
        assert safe_eval('1 + 2', locals={'__builtins__':{}}, include_exceptions=True) == (3, None)

# Generated at 2022-06-21 08:00:13.964557
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    # define test cases
    # for each test case, we are providing an input and expected output
    # in some cases, we expect an exception

# Generated at 2022-06-21 08:00:25.668698
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe_eval function

    :return: None
    """
    # Test simple expressions
    val = safe_eval(u'{{list_var}}', dict(list_var=[1,2,3]))
    assert val == [1, 2, 3]
    val = safe_eval('{{list_var}}', dict(list_var=[1,2,3]))
    assert val == [1, 2, 3]

    # Test exceptions
    val, exception = safe_eval('{{list_var}}', dict(list_var=[1,2,3]), include_exceptions=True)
    assert exception is not None
    assert val == '{{list_var}}'

    # Test errors

# Generated at 2022-06-21 08:00:38.177691
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for function safe_eval()
    '''
    # success cases
    # NOTE: the first two cases require special handling for SyntaxErrors to
    # support deferred evaluation of with_items type vars.
    assert safe_eval('a') == 'a'

    # the following is a template which should parse as a dict literal
    # which is a valid expression when evaluated.
    assert safe_eval('{ "a": 1 }') == {u'a': 1}

    # same as above, but without quotes around the dict key.
    assert safe_eval('{ a: 1 }') == {u'a': 1}

    # dict with more than one key.
    assert safe_eval('{ a: 1, b: 2 }') == {u'a': 1, u'b': 2}

    # dict where key has quotes

# Generated at 2022-06-21 08:00:47.085287
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Make sure that safe_eval only evaluates safe code.
    '''

    # Good cases
    safe_eval('1')
    safe_eval('None')
    safe_eval('false')
    safe_eval('true')
    safe_eval('1 < 2')
    safe_eval('1 <= 2')
    safe_eval('1 == 2')
    safe_eval('1 != 2')
    safe_eval('1 >= 2')
    safe_eval('1 > 2')
    safe_eval('"a"')
    safe_eval('"a" in "abc"')
    safe_eval('"a" not in "abc"')
    safe_eval('"a" is None')
    safe_eval('"a" is not None')
    safe_eval('1 and 2')

# Generated at 2022-06-21 08:00:58.519270
# Unit test for function safe_eval