

# Generated at 2022-06-21 07:51:06.405688
# Unit test for function safe_eval
def test_safe_eval():
    # enable call function test with 'input'
    builtins.input = input

    result, exception = safe_eval('1 - 2', include_exceptions=True)
    assert result == -1
    assert exception is None
    result, exception = safe_eval('a_complex_var.get("key", "default")',
                                  locals={'a_complex_var': {'key': 'value'}}, include_exceptions=True)
    assert result == 'value'
    assert exception is None
    result, exception = safe_eval('a_complex_var.get("key", "default")',
                                  locals={'a_complex_var': 'hi'}, include_exceptions=True)
    assert result == 'hi'
    assert exception is None

# Generated at 2022-06-21 07:51:16.630345
# Unit test for function safe_eval
def test_safe_eval():
    ''' Unit test for function safe_eval.
    This test might need to be expanded in the future
    if there is a change in Jinja2 and the future
    behavior of the function.
    '''
    # test to make sure it evaluates things properly
    assert safe_eval("1 + 1") == 2
    assert safe_eval("'foo'.upper()") == "FOO"
    assert safe_eval("'foo' + 'bar'") == "foobar"
    assert safe_eval("dict((('key', 'value'),))") == {"key": "value"}
    assert safe_eval("list({1,3,3,3})") == [1,3]

    # test to make sure it evaluates things correctly when there is a variable
    assert safe_eval("a_var", {"a_var": 2}) == 2
    assert safe_

# Generated at 2022-06-21 07:51:27.790904
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:40.130429
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('my list') == 'my list'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"x": "y"}') == {"x": "y"}
    assert safe_eval('"foo" in bar') == '"foo" in bar'
    assert safe_eval('"foo" in ["foo", "bar"]')
    assert safe_eval('"foo" in bar', {'bar': ['foo', 'bar']})
    assert safe_eval('57') == 57
    assert safe_eval('56+1') == 57
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', {'ansible_check_mode': True}) == 2

# Generated at 2022-06-21 07:51:51.115879
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] < 3:
        # assertRaises only works correctly in python 3
        return

    import pytest
    # All expressions in this list should evaluate successfully
    # The result is the first element in the tuple followed by the expression

# Generated at 2022-06-21 07:52:02.183041
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validates the safe_eval function.
    '''
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2

    # Test if an exception is raised for non-strings

# Generated at 2022-06-21 07:52:14.875948
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:22.955478
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('True') == True
    assert safe_eval('True or False', include_exceptions=True) == (True, None)
    assert safe_eval('True or False') == True
    assert safe_eval('True and False', include_exceptions=True) == (False, None)
    assert safe_eval('True and False') == False
    assert safe_eval('1 < 2', include_exceptions=True) == (True, None)
    assert safe_eval('1 < 2') == True

# Generated at 2022-06-21 07:52:33.800666
# Unit test for function safe_eval
def test_safe_eval():
    # Change the following test cases to try other expressions
    # Call to eval is safe
    test_expr = "eval('0+0')"
    # List Comprehension
    # test_expr = '[0 for i in range(10)]'
    # List Comprehension with if
    # test_expr = '[0 for i in range(10) if i > 5]'
    # Tuple
    # test_expr = '(0 for i in range(10))'
    # Dict
    # test_expr = "{0:'localhost'}"
    # Arbitrary expressions
    # test_expr = "(0+0) > 5"
    # test_expr = "0+0 > 5"
    # test_expr = "(0+0) < 5"
    # test_expr = "(0+0) == 5"
    # test_expr =

# Generated at 2022-06-21 07:52:43.094281
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:56.905328
# Unit test for function safe_eval
def test_safe_eval():
    # test_safe_eval: normal list evaluation
    test_value = "test_string"
    test_expression = "[1,2,3,4,5,6,7,8,%s]" % test_value
    test_result = safe_eval(test_expression, dict())
    assert type(test_result) == list
    assert len(test_result) == 9
    assert test_result[8] == test_value
    # test_safe_eval: list evaluation with more complex content
    test_value = "test_string"
    test_expression = "[1,2,3,4,5,6,7,8,'%s']" % test_value
    test_result = safe_eval(test_expression, dict())
    assert type(test_result) == list
    assert len(test_result) == 9


# Generated at 2022-06-21 07:53:07.448569
# Unit test for function safe_eval
def test_safe_eval():
    # eval() already has a test suite.  We just need to test that the
    # safe_eval customizations are working.
    def assert_safe_eval(x, y, ns=None):
        ns = {} if ns is None else ns
        assert safe_eval(x, ns) == y

    # basic math
    assert_safe_eval("2 + 3", 5)
    assert_safe_eval("2 - 3", -1)
    assert_safe_eval("2 * 3", 6)
    assert_safe_eval("6 / 2", 3)
    assert_safe_eval("2**3", 8)
    assert_safe_eval("2 * 3 * 5 * 7 * 11 * 13 * 17 * 19 * 23 * 29 * 31 * 37",
                     2147483648)  # 2**31

# Generated at 2022-06-21 07:53:18.949082
# Unit test for function safe_eval
def test_safe_eval():
    # Test assertions for exception handling
    cases = [['"foobar"', 'foobar'],
             ['123', 123],
             ['false', False],
             ['true', True],
             ['null', None],
             ['[1, 2]', [1, 2]],
             ['foo', 'foo'],
             ['123 + 456', 579]]
    for expr, expected in cases:
        assert expected == safe_eval(expr), expr

    # Test assertions for exception handling
    badcases = ['__import__("os").system("ls")',
                '__import__("time").sleep(5)',
                '__import__("sys").exit()']
    for expr in badcases:
        assert expr == safe_eval(expr), expr



# Generated at 2022-06-21 07:53:27.356799
# Unit test for function safe_eval
def test_safe_eval():

    ###
    # Test safe_eval with a dictionary of expected result.
    # Each key will be used in a call to safe_eval and the value
    # is used to compare the result.
    # If the value is a tuple, the second element of the tuple is
    # expected to be an exception, if any.
    ###
    def test_safe_eval_with_dict(test_data):

        for expr, expect in test_data.iteritems():
            if isinstance(expect, tuple):
                result, exception = safe_eval(expr, include_exceptions=True)
                assert result == expect[0]
                assert exception == expect[1]
            else:
                result = safe_eval(expr)
                assert result == expect

    # Value for 'a' is a string

# Generated at 2022-06-21 07:53:39.707846
# Unit test for function safe_eval
def test_safe_eval():
    # A number of variables defined by Jinja2 but not supported in safe_eval
    unsupported_vars = [
        'range',
        'True',
        'False',
        'loop',
        'config',
        'vars',
        'hostvars',
        'groups',
        'omit',
        'True',
        'False',
        'None',
    ]
    # A number of functions defined by Jinja2 but not supported in safe_eval

# Generated at 2022-06-21 07:53:49.199260
# Unit test for function safe_eval
def test_safe_eval():
    # Use the 'js' format to parse the string, since that is what we are
    # trying to emulate with safe_eval
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

# Generated at 2022-06-21 07:53:59.946709
# Unit test for function safe_eval
def test_safe_eval():

    def test_file(filename):
        test_data = []
        result = True
        with open(filename) as f:
            for line in f.readlines():

                # Ignore comment lines
                line = line.strip()
                if line == "" or line.startswith("#"):
                    continue

                # Split line into parts and validate that there are exactly two
                parts = line.split(":", 1)

                if len(parts) < 2 or len(parts) > 3:
                    print("Invalid input line: %s" % line)
                    result = False
                    break

                if len(parts) == 3:
                    (type, string, result) = parts
                else:
                    (type, string) = parts
                    result = None


# Generated at 2022-06-21 07:54:10.626591
# Unit test for function safe_eval
def test_safe_eval():
    variables = {
        'name': 'Bob',
        'age': 10,
        'a_list': ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],
        'a_dict': {'a':'b', 'b':10, 'c':None},
        'null': None,
        'true': True,
        'false': False,
        'jid': 'abcde1234567890',
        'inventory_hostname': 'example.com',
    }


# Generated at 2022-06-21 07:54:18.113922
# Unit test for function safe_eval
def test_safe_eval():
    '''
    These tests are for safe_eval, which is intended for allowing things like:
    with_items: a_list_variable

    It should also allow for safe usage of:
    string: "{{ some_variable }}"

    Where Jinja2 would return a string but we do not want to allow it to
    call functions (outside of Jinja2, where the env is constrained).
    '''

    # setup a list and a string
    a_var = [1, 2, 3]
    a_string = "hello world"

    # test a literal list
    assert safe_eval('[1,2,3]') == [1, 2, 3]

    # test a list var with a string pointer
    assert safe_eval('a_var', dict(a_var=a_var)) == a_var

    # test a list var

# Generated at 2022-06-21 07:54:28.759015
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2+2') == 4
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('None') == None
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar", "blam": "blaz"}') == {"foo": "bar", "blam": "blaz"}
    assert safe_eval('2+(2*2)') == 6
    assert safe_eval('2 + 2') == 4
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]

# Generated at 2022-06-21 07:54:38.393127
# Unit test for function safe_eval
def test_safe_eval():
    # This test is placed outside of the class below to give easier test setup
    # and results to the user.

    import doctest
    total_failures, total_tests = doctest.testmod(optionflags=doctest.ELLIPSIS,
                                                  raise_on_error=True,
                                                  verbose=False,
                                                  report=False)
    if total_failures:
        raise Exception("There were %s failures under %s tests in safe_eval." %
                        (total_failures, total_tests))

# This is a placeholder for a docstring test, it can be ignored.

# Generated at 2022-06-21 07:54:49.951153
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:59.421371
# Unit test for function safe_eval
def test_safe_eval():
    local_vars = {'a':1, 'b':2, 'c':[1,2,3]}

    # Check basic arithmetic operations
    s = "a + b"
    e = safe_eval(s)
    assert e == 3
    s = "a - b"
    e = safe_eval(s)
    assert e == -1
    s = "a * b"
    e = safe_eval(s)
    assert e == 2
    s = "b / a"
    e = safe_eval(s)
    assert e == 2
    s = "a**b"
    e = safe_eval(s)
    assert e == 1
    s = "a//b"
    e = safe_eval(s)
    assert e == 0

    # Check boolean operators

# Generated at 2022-06-21 07:55:11.560663
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info >= (3, 0):
        assert safe_eval("1 + 2") == 3, "Should be 3"
        assert safe_eval("null") is None, "Should be None"
        assert safe_eval("'a' + 'b'") == 'ab', "Should be ab"
        assert safe_eval("1 == 1 and 2 == 2") is True, "Should be True"
        assert safe_eval("1 == 1 or 2 == 3") is True, "Should be True"
        assert safe_eval("1 == 2") is False, "Should be False"
        assert safe_eval("true") is True, "Should be True"
        assert safe_eval("false") is False, "Should be False"
        assert safe_eval("[1, 2]") == [1, 2], "Should be [1,2]"

# Generated at 2022-06-21 07:55:22.702630
# Unit test for function safe_eval
def test_safe_eval():
    '''Unit tests for safe_eval'''
    env = {
        "var1": "bar",
        "var2": "myhost.example.org",
        "var3": "ok",
        "var4": "yes",
        "var5": '"log file"',
        "var6": """/etc/my\nmultiline\nstring""",
        "var7": '"/etc/my\nmultiline\nstring"',
        "var8": [1, 2, 3],
        "var9": "{'foo': 1, 'bar': 2 }",

        # just some invalid values
        "var10": b'\xc3',
        "var11": u'\u0394',
        "var12": Container(hello=True),
        "var13": Container(),
    }



# Generated at 2022-06-21 07:55:35.070774
# Unit test for function safe_eval
def test_safe_eval():
    rc, errors = safe_eval("a['b'].c(d, e, f=g).h()", include_exceptions=True)
    assert rc is "a['b'].c(d, e, f=g).h()" and errors is None
    rc, errors = safe_eval("a['b'].c(d, e, f=g).h()", include_exceptions=True)
    assert rc is "a['b'].c(d, e, f=g).h()" and errors is None

    rc, errors = safe_eval("a['b'].c(d, e, f=g).h()['j'].k()", include_exceptions=True)

# Generated at 2022-06-21 07:55:45.427003
# Unit test for function safe_eval
def test_safe_eval():
    # setup
    builtin_dir_backup = dir(builtins)
    CALL_ENABLED.append('abs')
    CALL_ENABLED.append('test_true')

    def test_true():
        return True

    OUR_GLOBALS = {
        '__builtins__': {},
        'false': False,
        'null': None,
        'true': True,
        'abs': abs,
        'test_true': test_true,
    }
    expr = 'test_true() and true'
    expected = True
    parsed_tree = ast.parse(expr, mode='eval')
    compiled = compile(parsed_tree, '<expr %s>' % to_native(expr), 'eval')
    # eval()

# Generated at 2022-06-21 07:55:58.158829
# Unit test for function safe_eval
def test_safe_eval():
    # the following expression should evaluate to the
    # number 6
    expr = "4 + 2"
    result = safe_eval(expr)
    assert result == 6

    # the following expression should evaluate to the
    # string 'datastructure'
    expr = "'datastructure'"
    result = safe_eval(expr)
    assert result == 'datastructure'

    # the following expression should evaluate to the
    # datastructure [ 'a', 'b', 'c' ]
    expr = "[ 'a', 'b', 'c' ]"
    result = safe_eval(expr)
    assert result == [ 'a', 'b', 'c' ]

    # the following expression should evaluate to the
    # datastructure { 'a': 1, 'b': 2, 'c': 3 }

# Generated at 2022-06-21 07:56:06.277579
# Unit test for function safe_eval
def test_safe_eval():
    # Allow calling builtin functions that we have deemed safe
    safe_builtins = set(
        (
            'abs',
            'all',
            'any',
            'bool',
            'complex',
            'dict',
            'enumerate',
            'float',
            'format',
            'hasattr',
            'hash',
            'isinstance',
            'iter',
            'list',
            'max',
            'min',
            'range',
            'repr',
            'set',
            'slice',
            'str',
            'tuple',
            'zip'
        )
    )
    CALL_ENABLED.extend(safe_builtins)

    # Test for invalid expressions and for safe expressions

# Generated at 2022-06-21 07:56:18.417130
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('6') == 6
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('[1, 2, a_var]', {'a_var': 3}) == [1, 2, 3]
    assert safe_eval('a_var + 3', {'a_var': 3}, True) == (6, None)
    assert safe_eval('[1, 2, a_var]', {'a_var': '3'}, True) == ('[1, 2, a_var]', None)

# Generated at 2022-06-21 07:56:30.066627
# Unit test for function safe_eval
def test_safe_eval():
    import ast
    from ansible.errors import AnsibleFilterError
    from ansible.module_utils.six.moves import builtins

    # list of python expressions to test
    # format of tuple is (expression,expected_result,error_expected)

# Generated at 2022-06-21 07:56:42.360003
# Unit test for function safe_eval
def test_safe_eval():

    # test various valid expressions
    assert safe_eval("foo=='bar'")
    assert safe_eval("foo")
    assert not safe_eval("false")
    assert safe_eval("foo.bar")
    assert safe_eval("true")
    assert safe_eval("foo.bar")
    assert safe_eval("foo > 1")
    assert safe_eval("dict(a=1)")
    assert safe_eval("[1,2,3]")
    assert safe_eval("(1,2,3)")
    assert safe_eval("1 in foo")
    assert safe_eval("1 not in foo")
    assert safe_eval("foo.bar in {'a':1}")

    # invalid expressions
    assert safe_eval("__import__('os').system('rm -rf /')") is False
    assert safe_eval

# Generated at 2022-06-21 07:56:52.870578
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:03.668333
# Unit test for function safe_eval
def test_safe_eval():
    def standard_test(expr, result, expect_exception=False, locals=None):
        if locals is None:
            locals = {}
        try:
            evaled = safe_eval(expr)
        except Exception as e:
            assert expect_exception is True
            return True
        assert not expect_exception
        assert evaled == result, 'expr: %s, expected: %s, got: %s' % (repr(expr), repr(result), repr(evaled))

    def builtin_test(func, args=None, kwargs=None, exceptions=True):
        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}

# Generated at 2022-06-21 07:57:13.477876
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure that we catch an unquoted string
    try:
        safe_eval("mydict['foo']")
    except Exception:
        pass
    else:
        assert False, "Did not catch unquoted string"

    # Ensure that we catch function calls in the argument
    try:
        safe_eval("dict(foo='bar', lst=[hash(x) for x in range(10)], other=map(int, range(10)))")
    except Exception:
        pass
    else:
        assert False, "Did not catch function call in argument"

    # Ensure that we catch function calls in the key
    try:
        safe_eval("{dict(foo='bar', lst=[hash(x) for x in range(10)]): 1}")
    except Exception:
        pass

# Generated at 2022-06-21 07:57:26.190875
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a unit test for function safe_eval.

    This function makes several checks, including that safe_eval
    returns the expected result, and also it includes several
    checks for safety, based on the contents of the SAFE_NODES
    list.  If you change SAFE_NODES or safe_eval in any way,
    you should run this test to make sure no security holes
    are introduced.
    '''

    # run a set of test cases to make sure safe_eval is working

# Generated at 2022-06-21 07:57:36.603295
# Unit test for function safe_eval
def test_safe_eval():
    # These should evaluate ok
    assert safe_eval("None") is None
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("'foo' + 'bar'") == 'foobar'
    assert safe_eval("1 + 1") == 2
    # These should fail to evaluate
    assert safe_eval("a_list_variable") == 'a_list_variable'
    assert safe_eval("foo") == 'foo'
    assert safe_eval("open('/tmp/foo').read()") == "open('/tmp/foo').read()"
    assert safe_eval("a_list_variable") == 'a_list_variable'
    assert safe_eval("a_list_variable", vars(builtins)) == 'a_list_variable'
    assert safe_eval("int") == 'int'



# Generated at 2022-06-21 07:57:49.304440
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:57.459636
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:09.488223
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:22.086825
# Unit test for function safe_eval
def test_safe_eval():
    # Adding callable to the whitelist enables calling it
    def f(a, b):
        return a + b
    CALL_ENABLED.append('f')

    # This should work, since we are only doing basic math
    expr = '1 + 2'
    result = safe_eval(expr)
    assert result == 3

    # This should fail, since we are not allowing calls
    expr = 'f(1, 2)'
    try:
        result = safe_eval(expr)
        assert False, 'Expected exception, but got %s' % result
    except Exception:
        pass

    # This should work now that we have added f to the call whitelist
    expr = 'f(1, 2)'
    result = safe_eval(expr)
    assert result == 3


# Generated at 2022-06-21 07:58:33.203106
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
        return

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import integer_types as numbers


# Generated at 2022-06-21 07:58:43.704456
# Unit test for function safe_eval
def test_safe_eval():
    def test_safe_eval(expr, expected, should_fail=False, include_exceptions=False):
        print("testing: %s" % expr)
        try:
            result = safe_eval(expr, include_exceptions=include_exceptions)
            if include_exceptions:
                result, exception = result
            if should_fail:
                raise AssertionError("%s: expected exception, got %s" % (expr, result))
            else:
                if C.DEFAULT_UNDEFINED_VAR_BEHAVIOR == 'warn':
                    expected = expr
                assert result == expected, '%s != %s (type %s %s)' \
                    % (result, expected, type(result), type(expected))
        except Exception as e:
            if not should_fail:
                raise

# Generated at 2022-06-21 07:58:54.563015
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:05.865949
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:12.939503
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[True, False]') == [True, False]
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('"foo" in ["foo", "bar"]') is True
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('"foo" in {"foo": "bar"}') is True
    assert safe_eval('["foo", "bar"][0]') == "foo"
    assert safe_eval('("foo", "bar")[0]') == "foo"
    assert safe_eval('foo in ["foo", "bar"]') is None
    assert safe_eval('foo in ["foo", "bar"]', dict(foo="foo")) is True

# Generated at 2022-06-21 07:59:23.779579
# Unit test for function safe_eval
def test_safe_eval():
    # Using a constant
    assert safe_eval("42", include_exceptions=True) == (42, None)
    assert safe_eval("42") == 42

    # Using a variable
    local_value = "foo"
    assert safe_eval("value", {'value': local_value}) == "foo"

    # Using an object
    local_list = [42, 23]
    assert safe_eval("list", {'list': local_list}) == local_list

    # Using an object method
    assert safe_eval("list.__getitem__(0)", {'list': local_list}) == 42

    # Using an object attribute
    assert safe_eval("list.count", {'list': local_list}) == local_list.count

    # Using operands
    assert safe_eval("1 + 2") == 3

    #

# Generated at 2022-06-21 07:59:34.118378
# Unit test for function safe_eval
def test_safe_eval():
    # All should pass
    assert safe_eval("{{ foo }}") == "{{ foo }}"
    assert safe_eval("{{ 'foo' }}") == "{{ 'foo' }}"
    assert safe_eval("{{ foo | bar }}") == "{{ foo | bar }}"
    assert safe_eval("{{ 'foo' | bar }}") == "{{ 'foo' | bar }}"
    assert safe_eval("{{ foo | bar | baz }}") == "{{ foo | bar | baz }}"
    assert safe_eval("{{ 'foo' | bar | baz }}") == "{{ 'foo' | bar | baz }}"
    assert safe_eval("{{ ( foo | bar | baz ) }}") == "{{ ( foo | bar | baz ) }}"

# Generated at 2022-06-21 07:59:45.908970
# Unit test for function safe_eval
def test_safe_eval():
    # We can do basic math
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('6 / 2') == 3
    assert safe_eval('3 - 1') == 2
    assert safe_eval('2 ** 3') == 8
    # We can compare values
    assert safe_eval('1 + 1 == 2') is True
    assert safe_eval('1 + 1 != 2') is False
    assert safe_eval('1 + 1 < 2') is False
    assert safe_eval('1 + 1 <= 2') is True
    assert safe_eval('2 > 1') is True
    assert safe_eval('2 >= 2') is True
    # We can combine comparisons and math
    assert safe_eval('2 * 3 > 4 + 1') is True

# Generated at 2022-06-21 07:59:50.425388
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:10.311130
# Unit test for function safe_eval
def test_safe_eval():
    """
    test_safe_eval: Evaluate some test expressions using safe_eval()
    """
    # Actual expressions to test

# Generated at 2022-06-21 08:00:19.311056
# Unit test for function safe_eval
def test_safe_eval():
    # Load module to get access to json_dict
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    # Test evaluation of dicts
    assert m.safe_eval("{'key1': 'value1', 'key2': 'value2'}") == {'key1': 'value1', 'key2': 'value2'}

    # Test evaluation of lists
    assert m.safe_eval("['element1', 'element2']") == ['element1', 'element2']


# Generated at 2022-06-21 08:00:27.449924
# Unit test for function safe_eval
def test_safe_eval():
    eval_examples = [
        "{{ val1 + val2 }}",
        "[1,2,3,4]",
        "{'foo': 'bar'}",
        "{% if True %}True{% else %}False{% endif %}",
        # Below tests are commented out as the
        # value of the expression cannot be determined
        #"func()",
        #"True in ('true')",
        #"True in ('false')",
     ]
    for expr in eval_examples:
        result, ret = safe_eval(expr, include_exceptions=True)
        assert ret is None, "Error evaluating: %s" % expr

# Generated at 2022-06-21 08:00:39.051180
# Unit test for function safe_eval
def test_safe_eval():
    failures = {}

# Generated at 2022-06-21 08:00:47.626112
# Unit test for function safe_eval
def test_safe_eval():
    # Test that an exception is thrown on Python syntax error
    try:
        test = safe_eval("[[]]", include_exceptions=True)
        assert False
    except SyntaxError:
        assert True

    # Test that an exception is thrown on Python syntax error
    try:
        test = safe_eval("[]()", include_exceptions=True)
        assert False
    except Exception:
        assert True

    # Test that a valid expression is evaluated correctly
    test = safe_eval("[1][0]", include_exceptions=True)
    assert test[0] == 1
    assert test[1] is None

    # Test that an invalid expression is evaluated correctly
    test = safe_eval("[]()", include_exceptions=True)
    assert test[0] == "[]()"

# Generated at 2022-06-21 08:00:58.710511
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit test for function safe_eval
    '''

    # can't test this directly as it will throw a SyntaxError
    # _ = safe_eval('1 + 3(2)')

    simple_expression = safe_eval('1+3')
    assert simple_expression == 4

    simple_float_expression = safe_eval('1.0+3.0')
    assert simple_float_expression == 4.0

    simple_float_expression = safe_eval('1.0+3')
    assert simple_float_expression == 4.0

    simple_float_expression = safe_eval('1+3.0')
    assert simple_float_expression == 4.0

    simple_string_expression = safe_eval("'ansible'+' rocks'")
    assert simple_string_expression == 'ansible rocks'

   