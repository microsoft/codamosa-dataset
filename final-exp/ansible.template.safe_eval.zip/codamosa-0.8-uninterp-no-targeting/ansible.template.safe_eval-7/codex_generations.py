

# Generated at 2022-06-21 07:51:02.419402
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a test for the safe_eval() function.
    '''
    # SyntaxError test
    expr = 'None) + 3'
    res = safe_eval(expr)
    assert res == expr

    # Invalid expression test
    expr = '__import__("os").system("ls")'
    res = safe_eval(expr)
    assert res == expr

    # Valid expression test
    expr = 'False or True and False'
    res = safe_eval(expr)
    assert res is False

    # Function call test
    expr = 'len([1,2,3,4])'
    res = safe_eval(expr)
    assert res == 4

    # JSON test
    expr = '[true, false, null]'
    res = safe_eval(expr)

# Generated at 2022-06-21 07:51:14.342007
# Unit test for function safe_eval
def test_safe_eval():
    # E1: None
    e = safe_eval("None")
    assert e is None

    # E2: False
    e = safe_eval("False")
    assert e is False

    # E3: True
    e = safe_eval("True")
    assert e is True

    # E4: ""
    e = safe_eval("''")
    assert e == ""

    # E5: "some string"
    e = safe_eval("'some string'")
    assert e == "some string"

    # E6: 6
    e = safe_eval("6")
    assert e == 6

    # E7: 3+5
    e = safe_eval("3+5")
    assert e == 8

    # E8: ['a', 'b', 'c']

# Generated at 2022-06-21 07:51:26.473495
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:39.374786
# Unit test for function safe_eval
def test_safe_eval():
    # tests for cases where safe_eval() does not raise an exception
    test_cases = [
        ('1'),
        ('1 + 1'),
        ('[1, 2]'),
        ('{"a": "b"}'),
        ('null'),
        ('false'),
        ('true'),
        ('a_list_variable'),
        ('a_list_variable[0]["some_key"]'),
        ('a_list_variable[0]'),
    ]
    for expr in test_cases:
        result = safe_eval(expr)
        if isinstance(result, Exception):
            raise result

# Generated at 2022-06-21 07:51:47.821461
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:59.105036
# Unit test for function safe_eval
def test_safe_eval():
    # This tests if a string can be passed through safely
    expr = '["foo", "bar"]'
    assert safe_eval(expr) == ast.literal_eval(expr)
    # This tests if a list can be passed through safely
    expr = ['a', 'b']
    assert safe_eval(expr) == ast.literal_eval(str(expr))
    # This tests if a string with a function call can not be passed through
    expr = '["foo", "bar", len(my_list)]'
    try:
        safe_eval(expr)
    except Exception as e:
        assert 'invalid function: len' in to_native(e)
    # This tests if a string with a function call can not be passed through
    expr = '["foo", "bar", len(my_list), foo()]'

# Generated at 2022-06-21 07:52:12.121338
# Unit test for function safe_eval
def test_safe_eval():
    # Test all valid expressions
    test_bool_true = safe_eval("True")
    try:
        assert test_bool_true == True
    except:
        raise

    test_bool_false = safe_eval("False")
    try:
        assert test_bool_false == False
    except:
        raise

    test_null = safe_eval("null")
    try:
        assert test_null is None
    except:
        raise

    test_empty_string = safe_eval("''")
    try:
        assert test_empty_string == ""
    except:
        raise

    test_string = safe_eval('"ansible"')
    try:
        assert test_string == "ansible"
    except:
        raise

    test_int = safe_eval("1")

# Generated at 2022-06-21 07:52:17.952507
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("1+1") == 2
    assert safe_eval("'hello' + 'world'") == 'helloworld'
    assert safe_eval("1 if 1 == 1 else 2") == 1

    # These should raise exceptions, but we catch them so the unit test doesn't
    # mind.
    try:
        safe_eval("__import__('os').getcwd()")
        assert(False)
    except:
        pass

# Generated at 2022-06-21 07:52:28.514674
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3, 4]+[1, 'two']") == [1, 2, 3, 4, 1, 'two']
    assert safe_eval("{1, 2, 3, 4}+{1, 'two'}") == {1, 2, 3, 4, 'two'}
    assert safe_eval("1 in [1, 2, 3, 4]") is True
    assert safe_eval("true", include_exceptions=True) == (True, None)
    assert safe_eval("false", include_exceptions=True) == (False, None)
    assert safe_eval("null", include_exceptions=True) == (None, None)

# Generated at 2022-06-21 07:52:33.192113
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:47.412764
# Unit test for function safe_eval
def test_safe_eval():
    def fail_eval(expr):
        return (expr, None) == safe_eval(expr, include_exceptions=True)

    assert fail_eval("import os; os.system('rm -rf *')")
    assert fail_eval("[x for x in range(0, os.getuid() + 1)]")
    assert fail_eval("__import__('os').system('rm -rf *')")
    assert fail_eval("__builtins__.__import__('os').system('rm -rf *')")
    assert fail_eval("__builtins__['__import__']('os').system('rm -rf *')")
    assert fail_eval("[x for x in range(0, __import__('os').getuid() + 1)]")

# Generated at 2022-06-21 07:52:58.217179
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:08.519097
# Unit test for function safe_eval
def test_safe_eval():
    import types

    # check some basic expressions
    assert safe_eval('1') == 1
    assert safe_eval('2 + 2') == 4
    assert safe_eval('4 - 2') == 2
    assert safe_eval('4 - - 2') == 6
    assert safe_eval('4 - -2') == 6
    assert safe_eval('4 - + 2') == 2
    assert safe_eval('4.5') == 4.5
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('none') is None

# Generated at 2022-06-21 07:53:21.042431
# Unit test for function safe_eval
def test_safe_eval():
    def test_it(expr, expected, **kwargs):
        actual = safe_eval(expr, **kwargs)
        if actual != expected:
            print("%s  =>  %s" % (expr, actual))
            print("expected:", expected)
            sys.exit(1)

    test_it("2+2", 4)
    test_it('"foo"', "foo")
    test_it("foo", "foo")

    # builtins are disallowed now
    try:
        test_it("int('1')", 1)
        print("failed to identify invalid builtin")
        sys.exit(1)
    except Exception:
        pass

    test_it('{foo:1, bar:2}', {"foo": 1, "bar": 2})

# Generated at 2022-06-21 07:53:24.957751
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:38.158007
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    assert safe_eval("2+2") == 4
    assert safe_eval("2+2") != 5
    assert safe_eval("(2,3,4)") == (2,3,4)
    assert safe_eval("{'a': 10}") == {'a': 10}
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("a", {'a': '10'}) == '10'

    # test safe_eval with jinja2 variables
    assert safe_eval("{{ 2 + 2 }}") == "{{ 2 + 2 }}"
   

# Generated at 2022-06-21 07:53:42.593830
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:50.782447
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:01.464644
# Unit test for function safe_eval
def test_safe_eval():

    # success cases
    assert safe_eval('42') == 42
    assert safe_eval('-42') == -42
    assert safe_eval('4**2') == (4**2)
    assert safe_eval('1==1') == (1==1)
    assert safe_eval('None') == None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('["foo"]') == ["foo"]
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('"a" * 2') == "aa"
    assert safe_eval('["a"] * 2') == ["a", "a"]

# Generated at 2022-06-21 07:54:12.071861
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:25.093266
# Unit test for function safe_eval
def test_safe_eval():
    import os
    import shutil
    import tempfile
    import traceback

    tmpdir = tempfile.mkdtemp()
    os.chmod(tmpdir, 0o700)

    def test(expr, should_fail=False, should_warn=False, **kwargs):
        try:
            result, warn = safe_eval(expr, **kwargs)
        except Exception:
            # pass to test suite
            if not should_fail:
                raise

        else:
            # pass to test suite
            if should_fail:
                raise AssertionError('%s should have raised an exception' % expr)
            if should_warn:
                raise AssertionError('should have generated a warning')

    # test clean evals
    test('2+2')
    test('2+2', include_exceptions=True)


# Generated at 2022-06-21 07:54:35.066271
# Unit test for function safe_eval
def test_safe_eval():
    def runsafe(expression, expected_result):
        ''' Test a safe expression that is expected to run and return the expected result '''
        C.DEFAULT_DEBUG = True
        val, err = safe_eval(expression, include_exceptions=True)
        assert err is None
        assert val == expected_result
        val = safe_eval(expression)
        assert val == expected_result
        C.DEFAULT_DEBUG = False
        val, err = safe_eval(expression, include_exceptions=True)
        assert err is None
        assert val == expected_result
        val = safe_eval(expression)
        assert val == expected_result

    def runfails(expression):
        ''' Test an expression that is expected to fail '''
        C.DEFAULT_DEBUG = True

# Generated at 2022-06-21 07:54:43.344285
# Unit test for function safe_eval
def test_safe_eval():
    # Simple eval test
    assert safe_eval('1') == 1

    # Keywords are not allowed
    try:
        safe_eval('false')
        assert False
    except Exception:
        pass

    # UnaryOp is valid
    assert safe_eval('-1') == -1

    # BinOp is valid
    assert safe_eval('2 + 3') == 5

    # Compare is valid
    assert safe_eval('1 < 2') is True
    assert safe_eval('1 > 2') is False

    # List is valid
    assert safe_eval('[1, 2]') == [1, 2]

    # Dict is valid
    assert safe_eval('{"a": 1, "b": true}') == {"a": 1, "b": True}

    # Multiple statements are not allowed

# Generated at 2022-06-21 07:54:53.165945
# Unit test for function safe_eval
def test_safe_eval():
    ''' Test whether safe_eval fails as expected on various invalid expressions
    '''
    bad_exprs = [
        '1 + [1, 2, 3]',
        '__import__("os").getcwd()',
        '__import__("sys").exit(1)',
        'True = False',
        '1.__add__(1)',
    ]

    for expr in bad_exprs:
        print('Testing: %s' % to_native(expr))
        if safe_eval(expr) != expr:
            raise Exception('%s evaluated unexpectedly (%s)' % (expr, safe_eval(expr)))

# Generated at 2022-06-21 07:55:00.777546
# Unit test for function safe_eval
def test_safe_eval():
    """
    This tests a few of the cases for safe_eval.  A few more cases are tested
    in the 'when' clause of ansible/playbooks/meta.yml in the 'gather_facts' tag.
    """

    def test_eval(expr, expected_result, locals=None):
        '''Test if safe_eval(expr, locals) == expected_result'''
        locals = {} if locals is None else locals
        assert isinstance(expected_result, string_types)
        actual_result = safe_eval(expr, locals=locals)
        assert isinstance(actual_result, string_types)
        assert actual_result == expected_result

    # Test that we eval strings that look like dicts and lists to dicts and lists

# Generated at 2022-06-21 07:55:13.191041
# Unit test for function safe_eval
def test_safe_eval():
    program = '''
    with_items:
    - "{{ lookup('template', 'foo.j2') }}"
    - "{{ lookup('template', 'bar.j2') }}"

    with_items:
      - "{{ lookup('template', 'foo.j2') }}"
      - "{{ lookup('template', 'bar.j2') }}"

    with_items:
      - "{{ lookup('template', 'foo.j2') }}"
      - "{{ lookup('template', 'bar.j2') }}"
    '''

# Generated at 2022-06-21 07:55:23.625471
# Unit test for function safe_eval
def test_safe_eval():
    # dummy function for testing
    def dummy_func():
        return 10
    # valid expressions
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1") == 1
    assert safe_eval("-5") == -5
    assert safe_eval("5") == 5
    assert safe_eval("-5.5") == -5.5
    assert safe_eval('"1"') == "1"
    assert safe_eval("'1'")

# Generated at 2022-06-21 07:55:35.175537
# Unit test for function safe_eval
def test_safe_eval():

    # this should be allowed
    expr = "foo == 'bar'"
    locals = { 'foo' : 'bar' }
    if safe_eval(expr, locals) != True:
        raise Exception("safe_eval failed to allow '%s'" % expr)

    # this should not be allowed
    expr = "foo.bar()"
    try:
        safe_eval(expr, locals)
    except:
        pass
    else:
        raise Exception("safe_eval failed to restrict '%s'" % expr)

    # this should be allowed
    expr = "foo == 'foo'"
    locals = { 'foo' : 'foo' }
    if safe_eval(expr, locals) != True:
        raise Exception("safe_eval failed to allow '%s'" % expr)

    # this should not be allowed

# Generated at 2022-06-21 07:55:45.507320
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"ansible": true}') == {"ansible": True}
    # ensure that our blacklist of dangerous functions and
    # classes is complete and accurate
    with open(C.DEFAULT_FILTER_PLUGIN_CONFIG, 'r') as f:
        # this is a yaml document, so we know that each line will be a
        # complete entry, we could have just loaded the whole thing
        # but this allows the plugin to be more fully commented
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # these are defined in the yaml.  they are either found in
           

# Generated at 2022-06-21 07:55:58.320216
# Unit test for function safe_eval
def test_safe_eval():
    # The following call to safe_eval should succeed without exceptions
    safe_eval("10 + 5")

    # The following call to safe_eval should fail because it uses a python function
    # that is not in our whitelist.
    try:
        safe_eval("locals()")
    except:
        print("safe_eval() successfully detected use of invalid function")
    else:
        print("safe_eval() failed to detect use of invalid function")
        sys.exit(1)

    # The following call to safe_eval should succeed because it does not
    # use any functions.
    safe_eval("[1,2,3]")

    # The following call to safe_eval should fail because it uses an
    # invalid token

# Generated at 2022-06-21 07:56:13.032113
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("6 + 4") == 10

    result = safe_eval("a_python_var", dict(a_python_var=5))
    assert result == 5

    result = safe_eval("a_python_var", dict(a_python_var="hello"))
    assert result == "hello"

    result = safe_eval("a_python_var", dict(a_python_var=5.5))
    assert result == 5.5

    result = safe_eval("a_python_var", dict(a_python_var="5"))
    assert result == 5

    result = safe_eval("a_python_var", dict(a_python_var="5.5"))
    assert result == 5.5


# Generated at 2022-06-21 07:56:24.319021
# Unit test for function safe_eval
def test_safe_eval():
    # test cases
    TEST_DATA = [
        ('7', 7),
        ('3 + 4', 7),
        ('7 - 2', 5),
        ('7 * 2', 14),
        ('7 / 2', 3.5),
        ('2 + 3 * 4', 14),
        ('(2 + 3) * 4', 20),
        ('2 + 3 * 4 - 6 / 3 - 2', 7),
        ('1 - 2 - 3 - 4', -8),
        ('1 - (2 - (3 - 4))', 2),
        ('3 + 4 - 2', 5),
        ('8 * (1 - 2)', -8)
    ]

    TEST_EVAL_EXPR_FAILURE = [
        '(2 + 3',
        '2 + 3)'
    ]

    TEST_EVAL_EXPR_FAIL

# Generated at 2022-06-21 07:56:30.631875
# Unit test for function safe_eval
def test_safe_eval():
    test_cases = [
        ("{{ ' '.join(['a', 'b']) }}", ['a', 'b']),
        ("{{ ' '.join(results.stdout_lines) }}", "foo"),
    ]
    for item in test_cases:
        print("Testing: {0}".format(item[0]))
        result, err = safe_eval(item[0], dict(results={'stdout_lines': ['f', 'o', 'o']}), True)
        assert result == item[1]
        assert err is None


# Generated at 2022-06-21 07:56:43.065235
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic Python syntax with safe_eval
    assert safe_eval("'{0}{1}'.format('a', 'b')") == 'ab'

    # Test basic syntax errors with safe_eval
    assert safe_eval("'{0}{1'.format('a', 'b')") == "'{0}{1'.format('a', 'b')"

    # Test invalid Python syntax with safe_eval
    assert safe_eval("__import__('os').system('echo got root')") == "__import__('os').system('echo got root')"


# Generated at 2022-06-21 07:56:47.084731
# Unit test for function safe_eval
def test_safe_eval():
    import sys


# Generated at 2022-06-21 07:56:56.142895
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:08.799023
# Unit test for function safe_eval
def test_safe_eval():
    # Test successful eval
    assert safe_eval('True') is True
    assert safe_eval('10') == 10
    assert safe_eval('10.0') == 10.0
    assert safe_eval('-12') == -12
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{}') == {}
    assert safe_eval('[1,2,3]*3') == [1,2,3,1,2,3,1,2,3]
    assert safe_eval('(1,2,3,4)') == (1,2,3,4)
    assert safe_eval('not False') is True
    assert safe_eval('10 < 20') is True

# Generated at 2022-06-21 07:57:15.771176
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run tests with:
    ANSIBLE_CONFIG=test/ansible.cfg python -m ansible.utils.unsafe_proxy ansible.utils.unsafe_proxy
    '''
    import os
    import pytest
    from ansible.module_utils.six.moves import builtins

    # mock __import__ to be a noop
    old_import = builtins.__import__
    builtins.__import__ = lambda name, *args, **kwargs: None

    # test vars

# Generated at 2022-06-21 07:57:28.435437
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:37.777429
# Unit test for function safe_eval
def test_safe_eval():

    if sys.version_info < (2, 7):
        print('Unit tests require python 2.7 or newer')
        sys.exit(1)

    global CALL_ENABLED
    CALL_ENABLED.extend(['lambda', 'list'])

    # test a set of expression that are good
    # and should return the same result
    # as the normal python eval()

# Generated at 2022-06-21 07:57:51.685135
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the safe_eval function
    '''

    # Basic tests
    assert safe_eval('1') == 1
    assert safe_eval('True') is True
    assert safe_eval('True') is not True
    assert safe_eval('True or False') is True
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('-1') == -1
    assert safe_eval('-1') == -1
    assert safe_eval('-1 * 2') == -2

# Generated at 2022-06-21 07:58:03.726560
# Unit test for function safe_eval
def test_safe_eval():
    """
    tests for function safe_eval
    """

    # based on http://stackoverflow.com/questions/12523516/using-ast-and-whitelists-to-make-pythons-eval-safe

# Generated at 2022-06-21 07:58:15.533668
# Unit test for function safe_eval
def test_safe_eval():
    # Known good inputs
    assert safe_eval('1', {}) == 1
    assert safe_eval('1 + 1', {}) == 2
    assert safe_eval('1 + 1 == 2', {}) == True

    # Known bad inputs
    assert safe_eval('__import__("os").system("ls")', {}) == "__import__(\"os\").system(\"ls\")", \
           "Failed to detect unsafe usage of __import__"
    assert safe_eval('True + True', {}) == "True + True", \
           "Failed to detect non-constant expression"
    assert safe_eval('[] + []', {}) == "[] + []", \
           "Failed to detect non-constant expression"

    # The following should not raise an exception

# Generated at 2022-06-21 07:58:23.194103
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure that a constant evaluates to itself, whatever it is
    for test_expr in (None, True, False, 0, 1, 1.0, 1j, 'hello', b'hello',
                      [], (), {}):
        assert safe_eval(repr(test_expr)) is test_expr

    # Expressions that should pass unchanged
    def assert_safe_passthrough(exp):
        assert safe_eval(exp) == exp

    # Single elements that should work, as well as their repr()
    for el in (None, True, False, 0, 1, 'hello', b'hello', [], (), {}):
        assert_safe_passthrough(repr(el))
        assert_safe_passthrough(el)

    # Test safe_eval() on a variety of AST nodes

# Generated at 2022-06-21 07:58:33.009056
# Unit test for function safe_eval
def test_safe_eval():

    # this is expected to succeed
    expr = "({# foo #} - 1) * 2"
    result = safe_eval(expr)
    assert result == 0

    # the following should all throw an exception
    bad_exprs = [
        "foo.bar()",
        "__import__('os').system('/bin/echo got root?')",
        "map(__import__('os').system, [ '/bin/echo got root?' ])",
    ]
    for expr in bad_exprs:
        try:
            result = safe_eval(expr)
            assert False, "safe_eval failed to reject the expression: %s" % expr
        except:
            pass

# Generated at 2022-06-21 07:58:43.545857
# Unit test for function safe_eval
def test_safe_eval():
    output = safe_eval('1 + 2')
    assert output == 3, "safe_eval('1 + 2') returned %s" % output

    output = safe_eval('1 + 2', include_exceptions=True)
    assert output == (3, None), "safe_eval('1 + 2') returned %s" % output

    output = safe_eval('1 + a', locals={'a': 2}, include_exceptions=True)
    assert output == (3, None), "safe_eval('1 + a') returned %s" % output

    output = safe_eval('false or true', include_exceptions=True)
    assert output == (True, None), "safe_eval('false or true') returned %s" % output

    output = safe_eval('false or true', locals={'true': False}, include_exceptions=True)


# Generated at 2022-06-21 07:58:54.157377
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic values
    assert safe_eval('42') == 42
    assert safe_eval('-42') == -42
    assert safe_eval('1.0') == 1.0
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"hello"') == 'hello'
    assert safe_eval("'hello'") == 'hello'
    assert safe_eval("True") == True
    assert safe_eval("False") == False

    # Test tuples
    assert safe_eval("(True, False)") == (True, False)
    assert safe_eval("(1.0, 'a')") == (1.0, 'a')
    assert safe_eval("(42, 42, 42)") == (42, 42, 42)

    # Test lists

# Generated at 2022-06-21 07:59:05.641338
# Unit test for function safe_eval
def test_safe_eval():
    """
    These test cases are commented out since safe_eval is now used
    by a private callback plugin.
    """
    # The following list of strings are taken from
    # https://github.com/SecWiki/linux-kernel-exploits/tree/master/2014/CVE-2014-4699
    # description of the exploit in the commit message
    # https://github.com/SecWiki/linux-kernel-exploits/commit/9c8b2f51977d
    # The values have been made safe by adding quotes around them.
    #
    # Note that CVE-2014-4699 was fixed by commit 087d927b3c8b56dfc6eabe7fbcf3b6c64b6a63a6,
    # so these should not work against an unpatched kernel.

# Generated at 2022-06-21 07:59:12.831108
# Unit test for function safe_eval
def test_safe_eval():
    # Successes
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('(1 + 1, 2 + 2)') == (2, 4)
    assert safe_eval('(1 + 1, 2 + 2)', include_exceptions=True) == ((2, 4), None)
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}', include_exceptions=True) == ({"a": 1}, None)
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)

# Generated at 2022-06-21 07:59:23.682072
# Unit test for function safe_eval
def test_safe_eval():
    print('running test_safe_eval')
    for expr in ['2 + 2', '"4"', "'4'"]:
        print('testing basic expr: %s' % expr)
        assert safe_eval(expr) == ast.literal_eval(expr)

    test_failures = [
        '__import__("os").system("rm -rf /")',  # Code injection (disable builtins)
        '__import__("os")',                     # Code injection (disable builtins)
        'abs(1)',                               # abs() not allowed
        'True',                                 # True is a builtin
    ]

    for expr in test_failures:
        print('testing fail expr: %s' % expr)
        result, err = safe_eval(expr, include_exceptions=True)
        assert result == expr

# Generated at 2022-06-21 07:59:36.926658
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    try:
        import astor
    except ImportError:
        print('Unable to load astor, skipping test of safe_eval')
        return
    stdout = sys.stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-21 07:59:49.290171
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases for safe_eval
    import sys

    # This is the test module that we will mask from the test cases
    from ansible.compat.tests.mock import MagicMock

    # This is a module that should not be masked
    import json

    # Test Cases

# Generated at 2022-06-21 07:59:58.359058
# Unit test for function safe_eval
def test_safe_eval():
    # eval our list back into a Python list (which is safe)
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    # raise error for unallowed Python builtin functions
    try:
        safe_eval("len([1,2,3])")
        assert False
    except Exception as e:
        assert "invalid function" in to_native(e)
    # raise error for unallowed Python expressions
    try:
        safe_eval("[x for x in range(5)]")
        assert False
    except Exception as e:
        assert "invalid expression" in to_native(e)
    # allow calling os.getcwd() since it's a safe function
    safe_eval("import os; os.getcwd()", include_exceptions=True)
    # allow calling os.get

# Generated at 2022-06-21 08:00:10.351311
# Unit test for function safe_eval
def test_safe_eval():
    def test_exception(expr, msg):
        try:
            result = safe_eval(expr)
        except Exception as e:
            if str(e) != msg:
                print("expected %s, got %s" % (msg, e))
            return

        print("expected exception, got %s" % (result))


    def test_expression(expr, value):
        result = safe_eval(expr)
        if result != value:
            print('expected %s, got %s' % (value, result))

    test_expression("','.join(['a', 'b', 'c'])", 'a,b,c')
    test_expression('True', True)
    test_expression('False', False)
    test_expression('True and False', False)
    test_expression('True or True', True)
   

# Generated at 2022-06-21 08:00:23.005791
# Unit test for function safe_eval
def test_safe_eval():
    expr_list = [
        ('[True, False, null]', [True, False, None]),
        ('{"a": "alpha", "b": "bravo"}', {'a': 'alpha', 'b': 'bravo'}),
        ('(2, 3, 5, 7, 11)', (2, 3, 5, 7, 11))
    ]

    for expr, expected in expr_list:
        result, err = safe_eval(expr, include_exceptions=True)
        if not err:
            assert result == expected, ('Failed to safely eval expression: %s'
                                        % expr)
            if C.DEFAULT_DEBUG:
                print('Safely evaluated:', expr)
        else:
            raise Exception('Failed to safely eval expression: %s (%s)' %
                            (expr, err))

# Generated at 2022-06-21 08:00:30.216558
# Unit test for function safe_eval
def test_safe_eval():
    local_vars = dict(
        ansible_lsb=dict(
            codename='jessie',
        ),
    )


# Generated at 2022-06-21 08:00:41.904103
# Unit test for function safe_eval
def test_safe_eval():

    # Test that different variable types can be evaluated
    expected_result_types = [
        int,
        float,
        list,
        dict,
        set,
        tuple,
        bool,
    ]

    # This is a list of python expressions that should evaluate to
    # the expected result type.
    ok_to_eval_list = [
        "123",
        "123.123",
        "[1,2,3]",
        "{'foo':'bar'}",
        "set([1,2,3])",
        "(1,2,3)",
        "True",
    ]

    for expected_type, expr in zip(expected_result_types, ok_to_eval_list):
        result = safe_eval(expr)

# Generated at 2022-06-21 08:00:53.683456
# Unit test for function safe_eval