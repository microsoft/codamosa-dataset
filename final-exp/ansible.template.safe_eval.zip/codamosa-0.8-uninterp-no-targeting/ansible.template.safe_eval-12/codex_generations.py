

# Generated at 2022-06-21 07:51:07.600154
# Unit test for function safe_eval
def test_safe_eval():
    def test_expr(expr, expect_result, expect_error=False, locals=None):
        if any((
            constants.DISPLAY_SKIPPED_HOSTS and C.DISPLAY_SKIPPED_HOSTS,
            constants.DEFAULT_UNDEFINED_VAR_BEHAVIOR and C.DEFAULT_UNDEFINED_VAR_BEHAVIOR
        )):
            return

        print("testing: %s" % expr)

        if locals is None:
            locals = {}

        (result, err) = safe_eval(expr, locals, include_exceptions=True)
        if expect_error:
            assert err is not None, "Expected an error for expr: %s" % expr
            #print("%s -> %s (expecting error)" % (expr, result))

# Generated at 2022-06-21 07:51:17.421772
# Unit test for function safe_eval
def test_safe_eval():
    # Use a dict for locals because dicts are non-order dependent
    locals = dict(
        x = "a",
        y = "b",
        z = "c",
        d = {'l1': 'val1'},
        l = ['a', 'b', 'c'],
        t = ('a', 'b', 'c')
    )

    # List of tuples of (expression, expected result)

# Generated at 2022-06-21 07:51:28.228041
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:40.328659
# Unit test for function safe_eval
def test_safe_eval():
    # Test functions
    assert safe_eval('int("1")') == 1
    assert safe_eval('str(1)') == "1"
    assert safe_eval('dict({1:2})') == {1: 2}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('1 + 2*3') == 7
    assert safe_eval('1 + 2*True') == 3
    assert safe_eval('1 + 2*False') == 1
    assert safe_eval('1 + 2*None') == 1

    # Test invalid syntax
    assert safe_eval('this is invalid syntax') == 'this is invalid syntax'

    # Test invalid expressions
    assert safe_eval('__import__("os").system("echo")') == '__import__("os").system("echo")'

# Generated at 2022-06-21 07:51:48.259209
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic 'safe' operations
    # Note: We could test all the safe_nodes above, but that would
    #       get quite long
    test_data = {}

# Generated at 2022-06-21 07:51:59.488582
# Unit test for function safe_eval
def test_safe_eval():
    fake_fact = {'a_list_variable': [1, 2, 3]}
    fake_vars = {'b_list_variable': [4, 5, 6]}
    # Basic tests
    assert 1 == safe_eval('1')
    assert 1 == safe_eval('1 + 1 - 1')
    assert 1 == safe_eval('a_list_variable[0]', fake_fact)
    assert 1 == safe_eval('b_list_variable[0]', fake_vars)
    assert 1 == safe_eval('1 or 2')
    assert 1 == safe_eval('1 and 2')
    assert 2 == safe_eval('2 or 1')
    assert 2 == safe_eval('2 and 1')
    assert 2 == safe_eval('2 if 2 else 1')
    # Basic Types
    assert '1' == safe_

# Generated at 2022-06-21 07:52:12.469519
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ myvar }}") == "{{ myvar }}"
    assert safe_eval("{{ myvar | d() }}") == "{{ myvar | d() }}"
    assert safe_eval("{{ myvar | d(1, 2) }}") == "{{ myvar | d(1, 2) }}"
    assert safe_eval("{{ myvar | d('true') }}") == "{{ myvar | d('true') }}"
    assert safe_eval("{{ myvar | d(true) }}") == "{{ myvar | d(true) }}"
    assert safe_eval("{{ myvar | d(false) }}") == "{{ myvar | d(false) }}"
    assert safe_eval("{{ myvar | d(True) }}") == "{{ myvar | d(True) }}"

# Generated at 2022-06-21 07:52:21.596412
# Unit test for function safe_eval
def test_safe_eval():

    # simple eval of an expression
    assert safe_eval('2+2') == 4

    # define a function
    def square(x):
        return x*x

    # add function to locals()
    l = locals()
    l['square'] = square

    # function call should be allowed
    assert safe_eval('square(10)', l) == 100

    # nested calls should be allowed
    assert safe_eval('square(square(5))', l) == 625

    # nested calls with spaces should be allowed
    assert safe_eval('square ( square ( 5 ) )', l) == 625

    # function call with string
    assert safe_eval('square("foo")', l) == 'foofoo'

    # function call with nested list
    assert safe_eval('square([10,2])', l) == [100, 4]

   

# Generated at 2022-06-21 07:52:32.711207
# Unit test for function safe_eval
def test_safe_eval():
    # the following will all be True
    expr = True
    assert safe_eval(expr) == expr

    expr = '1 == 1'
    assert safe_eval(expr) == expr

    expr = dict(a=1, b=2, c=3)
    assert safe_eval(expr) == expr

    CALL_ENABLED.append('dict')
    expr = 'dict(a=1, b=2, c=3)'
    assert safe_eval(expr) == expr

    # but these will not be
    expr = '__import__("subprocess").check_output("echo hello", shell=True)'
    assert 'invalid expression' in str(safe_eval(expr, include_exceptions=True)[1])

    expr = sys.modules['os'].system

# Generated at 2022-06-21 07:52:40.276490
# Unit test for function safe_eval
def test_safe_eval():
    '''
    We define a "safe" AnsibleModule class so that we can test
    some of the plugins which require this.
    '''
    from ansible.module_utils.basic import AnsibleModule

    class SafeAnsibleModule(AnsibleModule):
        ''' wrapped AnsibleModule class to provide a safer dict '''

# Generated at 2022-06-21 07:52:54.983537
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for the safe_eval function
    '''

# Generated at 2022-06-21 07:52:58.546674
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic sanity testing for the safe_eval function
    '''
    assert safe_eval('3 + 1') == 4
    assert safe_eval('a + 1', dict(a=5)) == 6
    assert safe_eval('a + b', dict(a=5, b=10)) == 15
    assert safe_eval('a + b + c + d', dict(a=5, b=10, c=20, d=15)) == 50
    assert safe_eval('a + b + c + d', dict(a=1, b=2, c=3, d=4)) == 10
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-21 07:53:09.261928
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:21.493080
# Unit test for function safe_eval
def test_safe_eval():
    # Basic usage tests
    expr = "a and b"
    locals = dict(a=True, b=True)
    result = safe_eval(expr, locals)
    assert result is True

    expr = "a and b"
    locals = dict(a=True, b=False)
    result = safe_eval(expr, locals)
    assert result is False

    expr = "a and (b or c)"
    locals = dict(a=True, b=False, c=True)
    result = safe_eval(expr, locals)
    assert result is True

    # Test the forbidden operators, functions and types
    expr = "1 / 0"
    result = safe_eval(expr)
    assert result == expr

    expr = "1 // 0"
    result = safe_eval(expr)
    assert result == expr

    expr

# Generated at 2022-06-21 07:53:33.690523
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Currently only tests for safe eval, not for the AST node visitor
    '''
    assert safe_eval('(True)') == True
    assert safe_eval('(False)') == False
    assert safe_eval('(None)') == None
    assert safe_eval('(4 + 4)') == 8
    assert safe_eval('(4 + 4 - 6)') == 2
    assert safe_eval('(4 - 6 + 4)') == 2
    assert safe_eval('(4 - 6 - 4)') == -6
    assert safe_eval('(4 * 6 * 4)') == 96
    assert safe_eval('(4 * 6 / 2)') == 12
    assert safe_eval('(2 / 4 * 6)') == 3
    assert safe_eval('(4 * (6 + 2))') == 32
   

# Generated at 2022-06-21 07:53:44.802980
# Unit test for function safe_eval
def test_safe_eval():

    # Happy paths - these expressions are legit
    expressions = [
        '1 + 1',
        '1 + 1 == 2',
        '1 + 1 == 2 and True',
        '1 + 1 == 2 and True or False',
        "'foo' in ['foo', 'bar']",
        "4 in [1,2,4]",
        '1 + 2 + 3',
        '2 * 3',
        '1 - 2',
        '1 / 2',
        '-1',
        '{}',
        '{"a": 1, "b": 2}',
        '[]',
        '["a", "b"]',
        '[1,2,3,4]',
        '{"a": 1, "b": 2 + 3}',
        'foo'
        ]

# Generated at 2022-06-21 07:53:51.843600
# Unit test for function safe_eval
def test_safe_eval():
    # should pass
    assert safe_eval('foo <= bar') is True
    assert safe_eval('foo <= bar is False') is False
    assert safe_eval('foo <= bar is True') is True
    # should pass but with warning, since the items are actually strings
    #assert safe_eval('foo <= bar is baz') is True
    # should fail
    #assert safe_eval('__import__("os").system("echo Hello")') is True
    #assert safe_eval('__import__("os").system("echo Hello") is True') is True
    # this should fail with syntax error since None is not a valid expression
    assert safe_eval('None') == 'None'
    #assert safe_eval('None is True') is False
    # the following should fail with a syntax error even though they are
    # syntactically correct because they have a

# Generated at 2022-06-21 07:54:02.055127
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('1') == 1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1: 2, 3: 4}') == {1: 2, 3: 4}
    assert safe_eval('2 + 2') == 4
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

    # Test with include_exceptions=True
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('[1, 2, 3]]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{1: 2, 3: 4}', include_exceptions=True) == ({1: 2, 3: 4}, None)

# Generated at 2022-06-21 07:54:12.604287
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:19.089465
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Tests for function safe_eval
    '''

    # Test expressions that should pass

# Generated at 2022-06-21 07:54:32.821577
# Unit test for function safe_eval
def test_safe_eval():

    # Simple test
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 - 2') == -1
    assert safe_eval('3 * 2') == 6
    assert safe_eval('6 / 2') == 3
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"k1": "v1", "k2": "v2"}') == {"k1": "v1", "k2": "v2"}

# Generated at 2022-06-21 07:54:41.795006
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:54.113413
# Unit test for function safe_eval
def test_safe_eval():
    test_exprs = [
        ("a or b", [('a', True), ('b', False)], True),
        ("a or b", [('a', False), ('b', False)], False),
    ]

    for e in test_exprs:
        expr = e[0]
        locals = e[1]
        expected = e[2]
        result = safe_eval(expr, locals)
        # we can't just check for the value being the same because we're
        # testing against a Python object (True), which is not the same as
        # the string literal version of that object ("True"), which is what
        # we're passing in some of the cases above.

# Generated at 2022-06-21 07:55:05.230229
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('1==1') is True
    assert safe_eval('1!=1') is False
    assert safe_eval('1+1==2') is True
    assert safe_eval('1+1!=2') is False

# Generated at 2022-06-21 07:55:17.300827
# Unit test for function safe_eval
def test_safe_eval():
    # Only attempt unit test if this function is the main one being run.
    # If someone is running a unittest that specifically calls this, we
    # want to run it.  To do not interfere with normal unittest operation,
    # only run if this module is the main one being run.
    if sys.modules['__main__'].__file__.endswith('utils.py'):
        # We want to raise on invalid expressions
        def check_eval(expr):
            try:
                safe_eval(expr)
            except Exception as e:
                if expr.startswith('_'):
                    pass
                else:
                    raise

        # Strings
        assert safe_eval('hello') == 'hello'
        assert safe_eval('ansible') == 'ansible'

# Generated at 2022-06-21 07:55:25.945564
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:37.954932
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:47.047943
# Unit test for function safe_eval
def test_safe_eval():
    # Primarily this tests that the function doesn't throw fatal exceptions
    cases = [
        # These should all fail
        ('import os', None),
        ('__import__("os")', None),
        ('__import__("__builtins__")', None),
        ('[x for x in range(10)]', None),
        ('__builtins__', None),
        ('False == False', True),
        ('True == True', True),
        ('None == None', True),
        ('False or False', False),
        ('True or True', True),
        ('True and not False', True),
        ('foo', None),
        ('False if True else False', False),
    ]
    for expr, expected in cases:
        got = safe_eval(expr)
        if expected is not None:
            if expected != got:
                print

# Generated at 2022-06-21 07:56:00.013356
# Unit test for function safe_eval
def test_safe_eval():
    CALL_ENABLED.extend(C.DEFAULT_CALLABLE_WHITELIST)
    if sys.version_info >= (3, 5):
        CALL_ENABLED.extend(C.DEFAULT_CALLABLE_WHITELIST_NEW)
    try:
        import pkg_resources  # python2
    except ImportError:
        # no setuptools support in python3.x
        import setuptools as pkg_resources
    CALL_ENABLED.extend([
        'resource_string',
    ])
    CALL_ENABLED.extend(
        ['%s' % p for p in pkg_resources.get_entry_map('ansible.plugins.connection', 'network.common').keys()]
    )

    # Simple sanity check

# Generated at 2022-06-21 07:56:11.899221
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Runs tests for this module
    '''
    assert(isinstance(safe_eval("'foo'", include_exceptions=True), tuple))
    assert(isinstance(safe_eval("'foo'"), string_types))
    assert(safe_eval("'foo'") == 'foo')
    assert(safe_eval('a + 1', dict(a=5)) == 6)
    assert(safe_eval("a['foo']", dict(a=dict(foo=5))) == 5)
    assert(safe_eval("a['foo'][1]", dict(a=['bar', 'ignore', 'baz'])) == 'i')
    assert(safe_eval("a[1]", dict(a=['bar', 'ignore', 'baz'])) == 'ignore')

# Generated at 2022-06-21 07:56:21.008259
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval with no error
    assert safe_eval("1 + 1") == 2
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("test_list", locals=dict(test_list=[1,2,3])) == [1,2,3]
    assert safe_eval("test_dict", locals=dict(test_dict=dict(test='test'))) == dict(test='test')

    # safe_eval with error
    assert safe_eval("__import__") == '__import__'
    assert safe_eval("import os") == 'import os'
    assert safe_eval("import os", include_exceptions=True)[1].__class__.__name__ == 'NameError'

# Generated at 2022-06-21 07:56:30.425271
# Unit test for function safe_eval
def test_safe_eval():
    """To run this test, you must install the astroid module."""
    from astroid import parse
    from astroid.nodes import Call, Name

    # Check that syntax errors are returned as-is
    for code in [ 'a b', 'a=', 'lambda' ]:
        result, exception = safe_eval(code, include_exceptions=True)
        if str(result) != code:
            raise Exception("%s was not returned" % code)
        if exception:
            raise Exception("%s should not have an exception (%s)" % (code, exception))
    # Check that ok code is returned
    for code in [ 'a', 'a+b', 'lambda x: x' ]:
        result, exception = safe_eval(code, include_exceptions=True)

# Generated at 2022-06-21 07:56:42.777524
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:53.215327
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:04.695055
# Unit test for function safe_eval
def test_safe_eval():
    # Sanity check
    # Use 'eval' to make sure that the expr being tested against
    # is a valid Python expression
    test_expr = "foo == 'bar'"
    try:
        eval(test_expr)
    except:
        print("expression %s is invalid" % test_expr)
        sys.exit(1)

    # First run should return the evaluated result
    result = safe_eval(test_expr)
    assert result == True

    # Now confirm that the safe_eval returns the expr string back
    # if passed an invalid expression
    invalid_expr = "foo = bar"
    result = safe_eval(invalid_expr)
    assert not result

    # Now pass a tuple to be sure we're safely unpacking it
    test_tuple = "('foo', 'bar')"

# Generated at 2022-06-21 07:57:13.897928
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:26.396721
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == 'foo'
    assert safe_eval("foo.bar") == 'foo.bar'
    assert safe_eval("foo in bar") == 'foo in bar'
    assert safe_eval("foo + bar") == 'foo + bar'
    assert safe_eval("foo.bar + 2") == 'foo.bar + 2'
    assert safe_eval("(foo.bar + 2) / 3") == '(foo.bar + 2) / 3'
    assert safe_eval("foo.bar + (2 / 3)") == 'foo.bar + (2 / 3)'
    assert safe_eval("foo.bar(x=1, y=2) + (2 / 3)") == 'foo.bar(x=1, y=2) + (2 / 3)'

# Generated at 2022-06-21 07:57:36.753606
# Unit test for function safe_eval
def test_safe_eval():
    # This is where I put the unit test for this function
    for safe in ["true", "false", "null", "3", "3.0", "3 + 3", "(3 * 'un' + 'ium')", "{'a_dict': true}", "[3, 4, null]", "!true"]:
        try:
            res = safe_eval(safe)
            print(res)
        except Exception as e:
            print(e)
    for unsafe in ["__import__('os').system('/bin/ls')", "__import__('subprocess').Popen(['/bin/ls'])"]:
        try:
            res = safe_eval(unsafe)
            print(res)
        except Exception as e:
            print(e)


if __name__ == '__main__':
    test_safe_eval

# Generated at 2022-06-21 07:57:49.494764
# Unit test for function safe_eval
def test_safe_eval():

    # invalid expression
    # note the invalid use of a bare variable name in a list
    expr = "['foo', bar, 'baz']"
    assert not safe_eval(expr)

    # valid expression
    expr = "['foo', 'bar', 'baz']"
    assert safe_eval(expr) == ['foo', 'bar', 'baz']

    # usage with a variable
    expr = "['foo', '%s', 'baz']" % 'bar'
    assert safe_eval(expr) == ['foo', 'bar', 'baz']

    # usage with a variable
    expr = "('foo', '%s', 'baz')" % 'bar'
    assert safe_eval(expr) == ('foo', 'bar', 'baz')

    # usage with a variable

# Generated at 2022-06-21 07:57:57.575400
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as converters
    # These should always pass
    safe_eval("1 + 1")
    safe_eval("[1] or [2]")
    safe_eval("[1] and [2]")
    safe_eval("{'a': 'b', 'c': ('d',)}")
    safe_eval("True")
    safe_eval("False")
    safe_eval("None")
    safe_eval("1")
    safe_eval("0")
    safe_eval("1.0")
    safe_eval("0.0")
    safe_eval("1.0")
    safe_eval("0.0")
    safe_eval("'hello'")
    safe_eval('"hello"')
    safe_eval('b"hello"')
    safe

# Generated at 2022-06-21 07:58:19.054529
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:28.384372
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:40.303228
# Unit test for function safe_eval
def test_safe_eval():
    as_bool = lambda s: bool(safe_eval(s))
    as_str = lambda s: safe_eval(s)
    as_num = lambda s: safe_eval(s)
    as_type = lambda s: type(safe_eval(s))
    as_nonce = lambda s: safe_eval(s)

    def test_type(item, correct_type):
        """
        Give the test item, and the python type it should evaluate to.
        Then test through safe_eval to confirm it is that type.
        """
        result = safe_eval(item)
        assert type(result) is correct_type


# Generated at 2022-06-21 07:58:47.445863
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:59.311976
# Unit test for function safe_eval
def test_safe_eval():
    x = {'y': 5, 'z': 6}
    x_str = to_native(x)
    # These are the expressions we want to evaluate.
    # The list is a list of tuples. The first value in
    # each tuple is the expression itself. The second
    # value is the expected result when you evaluate the
    # expression.

# Generated at 2022-06-21 07:59:09.398422
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple strings
    eval_string = "foo"
    assert eval_string == safe_eval(eval_string)

    # Test a python function call
    eval_string = "len('foo')"
    assert 3 == safe_eval(eval_string)

    # Test a python variable
    eval_string = "foo"
    assert "bar" == safe_eval(eval_string, {'foo': 'bar'})

    # Test a python variable
    eval_string = "foo"
    assert [1, 2, 3, 4] == safe_eval(eval_string, {'foo': [1, 2, 3, 4]})

    # Test a python datastructure
    eval_string = "['foo', 'bar']"
    assert ['foo', 'bar'] == safe_eval(eval_string)

    # Test a python

# Generated at 2022-06-21 07:59:18.955981
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": "value"}') == {"a": "value"}
    assert safe_eval('(1,2,3)') == (1,2,3)
    assert safe_eval('{"a": "value"}', {'a': 'not_value'}) == {"a": "value"}
    assert safe_eval('a', {'a': 'value'}) == 'value'
    assert safe_eval('a', {'a': 'value'}) == 'value'

    try:
        # The following should fail, due to ast.Call
        safe_eval('a == "value"')
        raise Exception("Failed to raise exception")
    except:
        pass


# Generated at 2022-06-21 07:59:30.571454
# Unit test for function safe_eval
def test_safe_eval():

    # test expression evaluation
    expr_result, exception = safe_eval('1 + 3', {}, include_exceptions=True)
    assert expr_result == 4 and exception is None

    # test non-variable expression with error
    expr_result, exception = safe_eval('1 + "a"', {}, include_exceptions=True)
    assert expr_result == '1 + "a"' and isinstance(exception, SyntaxError)

    # test variable
    expr_result, exception = safe_eval('a_variable', {'a_variable': 'test_string'}, include_exceptions=True)
    assert expr_result == 'test_string' and exception is None

    # test variable expression

# Generated at 2022-06-21 07:59:38.310694
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:50.394794
# Unit test for function safe_eval
def test_safe_eval():

    def test(expr, expected_result, locals=None):
        locals = {} if locals is None else locals
        result, exception = safe_eval(expr, locals=locals, include_exceptions=True)
        assert result == expected_result, "exp='%s' res='%s' expected='%s' exception='%s'" % (expr, result, expected_result, exception)

    test('1 + 1', 2)
    test('1 + 1', 2, {'a': 'b'})
    test('1 + variable', '1 + variable')
    test('1 + variable', '1 + variable', {'variable': 'value'})
    test("{'a': '1'}", {'a': '1'})

# Generated at 2022-06-21 08:00:12.328197
# Unit test for function safe_eval
def test_safe_eval():
    def my_func(x):
        return x

    # Ensure that the function raises the exception
    expr = 'my_func(x)'
    try:
        safe_eval(expr)
        assert False, "Failed to raise exception for %s" % expr
    except Exception as e:
        assert "invalid function" in str(e), "Unexpected exception: %s" % str(e)

    # Ensure that the function works now that it has been whitelisted
    CALL_ENABLED.append('my_func')
    expr = 'my_func(x)'
    result = safe_eval(expr, locals={'x':3})
    assert result == 3, "Unexpected result: %s" % result

    # Ensure that the expression is passed through when non-string
    expr = 3

# Generated at 2022-06-21 08:00:24.430472
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:34.363247
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    # set type is not available in safe_eval
    assert safe_eval("{1,2,3}") == "{1,2,3}"
    assert safe_eval("1+2") == 3
    assert safe_eval("1-2") == -1
    # Need to be able to look up variable
    assert safe_eval("x + 1", locals={'x': 5}) == 6
    assert isinstance(safe_eval("[1,2,3]"), list)
    assert isinstance(safe_eval("(1,2,3)"), tuple)
    assert isinstance(safe_eval("{'a':1, 'b':2}"), dict)

    assert safe_eval("[] + []") == []

# Generated at 2022-06-21 08:00:45.062448
# Unit test for function safe_eval
def test_safe_eval():
    '''
    basic usage for safe_eval should be of the form:

    result, err = safe_eval(template_expression, dict(variables), include_exceptions=True)
    if err:
       raise Exception(err)
    '''

    # add a new method to dict to allow for checking for unexpected side effects
    class MyDict(dict):
        def __init__(self, *args, **kwargs):
            dict.__init__(self, *args, **kwargs)
            self.items = dict.items

    class MyStruct(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    # simple test template strings

# Generated at 2022-06-21 08:00:56.705805
# Unit test for function safe_eval
def test_safe_eval():
    # Test error handling
    assert safe_eval('invalid()') == 'invalid()'
    assert safe_eval([1, 2, 3]) == [1, 2, 3]
    assert safe_eval({'key': 'value'}) == {'key': 'value'}
    assert safe_eval(10) == 10

    # Test numeric expressions
    assert safe_eval('10') == 10
    assert safe_eval('-10') == -10
    assert safe_eval('--10') == 10
    assert safe_eval('10 + -10') == 0
    assert safe_eval('10 + 10') == 20
    assert safe_eval('10 + 10 + 10') == 30
    assert safe_eval('10 - 10') == 0
    assert safe_eval('10 - 10 - 10') == -10