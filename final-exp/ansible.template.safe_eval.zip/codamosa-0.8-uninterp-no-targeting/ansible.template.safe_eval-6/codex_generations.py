

# Generated at 2022-06-21 07:51:01.511368
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:13.641740
# Unit test for function safe_eval
def test_safe_eval():
    PASS_EXPRS = [
        "a or b",
        "a and b",
        "not a",
        "a or b and c or d and e or f",
        "a + b",
        "a - b",
        "a * b",
        "a / b",
        "a [b]",
        "a [b] [c]",
        "a [b : c]",
        "{'a': 1, 'b': 2}",
        "['a', 'b', 'c']",
        "(1, 2, 3, 4, 5)",
        "a.b.c.d",
        "a.b.c.d.e",
    ]


# Generated at 2022-06-21 07:51:26.148056
# Unit test for function safe_eval
def test_safe_eval():
    # Correct input
    good_inputs = ['true', 'false', 'null', '1', '1.0', '[]', '{}',
                   '1+2', '1-2', '3*4', '6/2', '1.0+2.0', '1.0-2.0', '3.0*4.0', '6.0/2.0', '1+2*3',
                   '[1,2]', '{1: 2, 3: 4}', '(1,2)', '1 in (1,2)', '"a" in ("a","b")',
                   '"a".upper()', 'None', 'True', 'False']

    # Error-ed inputs

# Generated at 2022-06-21 07:51:38.889731
# Unit test for function safe_eval
def test_safe_eval():
    tests = {}
    tests['basic-resource'] = (None, "'httpd'")
    tests['basic-resource-dict'] = (None, "{'name': 'httpd','service':'httpd','enabled':True}")
    tests['basic-resource-dict-var'] = (None, "{'name': 'httpd','service':'httpd','enabled':{{named_var}}}")
    tests['basic-resource-list'] = (None, "['httpd']")
    tests['basic-resource-list-var'] = (None, "['httpd',{{named_var}}]")
    tests['basic-resource-list-var-list'] = (None, "['httpd',{{named_var.split(\",\")}}]")

# Generated at 2022-06-21 07:51:47.518099
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:58.727954
# Unit test for function safe_eval
def test_safe_eval():
    data = {
        'value': 1,
        'string': "a" * 1000,
        'list': [1, 2, 3],
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'tuple': (1, 2, 3),
        'good_function': lambda x: x,
        'bad_function': sys.exit,
        'True': True,
        'False': False,
        'None': None
    }
    bad_functions = [
        'sys.exit',
        '__import__',
        'os.system',
    ]


# Generated at 2022-06-21 07:52:11.761365
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # Simple test to see if we can evaluate a set of expressions
    # using our safe_eval function.

# Generated at 2022-06-21 07:52:21.044106
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:32.266053
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:40.013382
# Unit test for function safe_eval
def test_safe_eval():
    # Test simple expressions
    assert safe_eval('True') is True
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{1:2,3:4}') == {1: 2, 3: 4}
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('1 < 2') is True
    assert safe_eval('1 in [0, 1, 2]') is True

    # Test raise exception
    assert safe_eval('__import__("os").remove("/tmp/file")') == '__import__("os").remove("/tmp/file")'
    assert safe_eval('str(1337)') == 'str(1337)'

    # Test exceptions with include_exceptions=True

# Generated at 2022-06-21 07:52:54.022277
# Unit test for function safe_eval
def test_safe_eval():
    # skip the unit test if Python < 2.6
    if sys.version_info < (2, 6):
        return

    # test a few evaluations
    assert safe_eval("1") == 1
    assert safe_eval("'1'") == '1'
    assert safe_eval("0.1") == 0.1
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("true") is True
    assert safe_eval("let_me_call_things()") == "let_me_call_things()"

    # test some evaluations that should fail
    assert "__import__" in safe_eval("__import__('os').system('echo IM IN UR BASE')")
    assert "__import__" in safe_eval("__import__('os')")

    # test arithmetic

# Generated at 2022-06-21 07:53:02.436957
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:14.369457
# Unit test for function safe_eval
def test_safe_eval():

    # Test literals
    assert safe_eval("1") == 1
    assert safe_eval("True") is True
    assert safe_eval("False") is False

    # Test comparisons
    assert safe_eval("1 == 1") is True
    assert safe_eval("1 != 1") is False
    assert safe_eval("True == False") is False
    assert safe_eval("None == None") is True
    assert safe_eval("1 < 2") is True
    assert safe_eval("1 > 2") is False
    assert safe_eval("1 <= 2") is True
    assert safe_eval("1 >= 2") is False
    assert safe_eval("1 < 1") is False
    assert safe_eval("1 > 1") is False
    assert safe_eval("1 <= 1") is True
    assert safe_eval("1 >= 1") is True

# Generated at 2022-06-21 07:53:25.348076
# Unit test for function safe_eval
def test_safe_eval():
    if C.DEFAULT_DEBUG:
        # run unit tests when --debug is enabled as part of `make test`
        from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-21 07:53:38.157909
# Unit test for function safe_eval
def test_safe_eval():
    from json import loads


# Generated at 2022-06-21 07:53:42.593117
# Unit test for function safe_eval
def test_safe_eval():
    expr = "[1+2, 3+4]"
    result = safe_eval(expr)
    assert result == [3, 7]

    expr = "{'a':1,'b':2}"
    result = safe_eval(expr)
    assert result == {'a': 1, 'b': 2}

    expr = "1+2"
    result = safe_eval(expr)
    assert result == 3

    expr = "a_string"
    result = safe_eval(expr, dict(a_string='hello world'))
    assert result == 'hello world'

    expr = "~1"
    result = safe_eval(expr)
    assert result == -2

    expr = "!1"
    result = safe_eval(expr)
    assert result is False


# Generated at 2022-06-21 07:53:45.717028
# Unit test for function safe_eval
def test_safe_eval():
    # Test function is called
    globals()['safe_eval']('my_func()')
    # Test function is not called
    globals()['safe_eval']('my_func')
    try:
        # Test unbounded builtin call is not allowed
        globals()['safe_eval']('open()')
    except:
        pass
    # Test a bounded builtin call is allowed
    globals()['safe_eval']('len("foo")')
    # Test a name that is both a bounded builtin call and not is appropriately
    # handled
    globals()['safe_eval']('len')



# Generated at 2022-06-21 07:53:52.319352
# Unit test for function safe_eval
def test_safe_eval():
    ok = False
    try:
        ok = safe_eval('{foo:bar}') == {'foo': 'bar'}
    except Exception:
        pass
    assert ok

    ok = False
    try:
        ok = safe_eval('[foo, bar]') == ['foo', 'bar']
    except Exception:
        pass
    assert ok

    ok = False
    try:
        ok = safe_eval('foo*3') == 'foofoofoo'
    except Exception:
        pass
    assert ok

    ok = False
    try:
        ok = safe_eval('1+1') == 2
    except Exception:
        pass
    assert ok

    ok = False
    try:
        ok = safe_eval('1+1') != 1
    except Exception:
        pass
    assert ok


# Generated at 2022-06-21 07:54:02.692058
# Unit test for function safe_eval
def test_safe_eval():
    def assert_success(s, expected):
        if isinstance(s, string_types):
            # Try to add more info to error messages
            tokens = s.split()
            if len(tokens) < 10:
                s = repr(s)
            else:
                s = repr("{} ... {}".format(" ".join(tokens[:10]), " ".join(tokens[-10:])))
            msg = "safe_eval({}) == {}".format(s, repr(expected))
        else:
            # No need for repr with non-string value
            msg = "safe_eval({}) == {}".format(s, expected)
        try:
            actual = safe_eval(s)
        except Exception as e:
            actual = e
        assert actual == expected, msg

    # test_eval_expressions

# Generated at 2022-06-21 07:54:12.876785
# Unit test for function safe_eval
def test_safe_eval():
    # Needed to test when variable has a value of False
    false = False
    true = True
    none = None

# Generated at 2022-06-21 07:54:24.904116
# Unit test for function safe_eval
def test_safe_eval():
    # Test list syntax
    assert safe_eval("['config', 'group_vars']") == ['config', 'group_vars']

    # Test tuple syntax
    assert safe_eval("('config', 'group_vars')") == ('config', 'group_vars')

    # Test dict syntax
    assert safe_eval("{'config': 'group_vars'}") == {'config': 'group_vars'}

    # Test bare string
    assert safe_eval("this string is just a string") == "this string is just a string"

    # Test int
    assert safe_eval("0") == 0

    # Test int
    assert safe_eval("0xffff") == 0xffff
    assert safe_eval("0o666") == 0o666

    # Test negative int

# Generated at 2022-06-21 07:54:34.851539
# Unit test for function safe_eval
def test_safe_eval():
    def check(expr, expected):
        actual = safe_eval(expr)
        if C.DEFAULT_DEBUG:
            print('expr: %s, actual: %s, expected: %s' % (expr, actual, expected))
        assert actual == expected

    # We do not want Jinja2 to try the following.
    # strings are passed to Jinja2, which will first use str.format or str.__mod__
    # before calling eval.
    #
    # This means that something like:
    #    test: '{{ "MIXED".join(["case", "string"]) }}'
    #
    # Passing through the Jinja filter is no different than:
    #    "MIXED".join(["case", "string"])
    #
    # Unfortunately, the above will error out because 'MIXED'.join is

# Generated at 2022-06-21 07:54:43.215406
# Unit test for function safe_eval
def test_safe_eval():
    r1 = safe_eval("a_list_variable", {"a_list_variable": [1, 2, 3]})
    assert r1 == [1, 2, 3]
    r2 = safe_eval("a_list_variable")
    assert r2 == "a_list_variable"
    r3 = safe_eval("a_list_variable", include_exceptions=True)
    assert r3 == ("a_list_variable", None)
    r4 = safe_eval("not_a_list_variable", include_exceptions=True)
    assert r4 == ("not_a_list_variable", None)
    r5 = safe_eval("'1' if (1 == 2 and 3 == 3) else ''")
    assert r5 == ''

# Generated at 2022-06-21 07:54:55.536521
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("a_list_variable", dict(a_list_variable=[1,2])) == [1, 2]
    assert safe_eval("a_string_variable", dict(a_string_variable="hello")) == "hello"
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("1 + 1") == 2
    assert safe_eval("a_list_variable[0] + 1", dict(a_list_variable=[1,2])) == 2
    assert safe_eval("dict(a=1, b=2)", dict(a_list_variable=[1,2])) == dict(a=1, b=2)

# Generated at 2022-06-21 07:55:04.401479
# Unit test for function safe_eval
def test_safe_eval():
    # simple checks
    assert safe_eval("1+1") == 2
    assert safe_eval("1.1+1.1") == 2.2
    assert safe_eval("True") == True
    assert safe_eval("None") is None
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("('foo', 'bar')") == ('foo', 'bar')
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}



# Generated at 2022-06-21 07:55:16.342753
# Unit test for function safe_eval
def test_safe_eval():
    # Evaluate None
    assert safe_eval('None') is None

    # Evaluate a string
    assert safe_eval('"foobar"') == "foobar"

    # Evaluate a unicode string
    assert safe_eval('u"foobar"') == "foobar"

    # Evaluate a string with spaces
    assert safe_eval('"foo bar"') == "foo bar"

    # Evaluate an integer
    assert safe_eval('42') == 42

    # Evaluate a floating point number
    assert safe_eval('3.1415') == 3.1415

    # Evaluate true
    assert safe_eval('true') is True

    # Evaluate false
    assert safe_eval('false') is False

    # Evaluate zero-length list
    assert safe_eval('[]') == []

    # Evaluate zero-length

# Generated at 2022-06-21 07:55:25.469760
# Unit test for function safe_eval
def test_safe_eval():
    # Simple examples
    assert safe_eval("4 + 5") == 9, "'4 + 5' should be 9"
    assert safe_eval("4 + 5", locals={'foo': 'bar'}) == 9, "'4 + 5' should be 9. Locals is ignored"
    assert safe_eval("4 + 5", locals={'foo': 'bar'}, include_exceptions=True)[0] == 9, "'4 + 5' should be 9. Locals is ignored"

    # More complicated example
    assert safe_eval("dict(a=1, b=2, c=3)") == {'a': 1, 'b': 2, 'c': 3}, \
        "'dict(a=1, b=2, c=3)' should be {'a': 1, 'b': 2, 'c': 3}"

    # Example with embedded quotes


# Generated at 2022-06-21 07:55:37.542730
# Unit test for function safe_eval
def test_safe_eval():
    try:
        result = safe_eval("foo")
    except Exception:
        assert False, 'should not have raised an exception'

    try:
        result = safe_eval('foo', dict(foo="bar"))
    except Exception:
        assert False, 'should not have raised an exception'

    try:
        result = safe_eval("foo|baR")
        assert False, 'should have raised an exception'
    except Exception:
        pass

    try:
        result = safe_eval("{{ foo }}")
        assert False, 'should have raised an exception'
    except Exception:
        pass

    try:
        result = safe_eval("[1,foo,3]")
    except Exception:
        assert False, 'should not have raised an exception'


# Generated at 2022-06-21 07:55:46.819201
# Unit test for function safe_eval
def test_safe_eval():
    def python_version_major():
        return sys.version_info[0]

    def python_version_minor():
        return sys.version_info[1]

    def python_version_patch():
        return sys.version_info[2]

    # test data from
    # http://www.json.org/json-en.html

# Generated at 2022-06-21 07:55:59.854810
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("") is None
    assert safe_eval("null") is None
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("[]") == []
    assert safe_eval("[1,2,3]", include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval("[[]]") == [[]]
    assert safe_eval("[1,2,3]", include_exceptions=True)[0] == [1, 2, 3]
    assert safe_eval("[1,2,3]", include_exceptions=True)[0] == [1, 2, 3]

# Generated at 2022-06-21 07:56:13.666419
# Unit test for function safe_eval
def test_safe_eval():
    if sys.version_info[0] == 2:
        assert safe_eval("True") is True
        assert safe_eval("False") is False
        assert safe_eval("None") is None

        assert safe_eval("'True'") == "True"
        assert safe_eval("'aeiou'") == "aeiou"
        assert safe_eval("123") == 123
        assert safe_eval("[1,2,3]") == [1, 2, 3]
        assert safe_eval("{1:'foo', 2:'bar'}") == {1: 'foo', 2: 'bar'}
        assert safe_eval("{'str': [1,2,3]}") == {'str': [1, 2, 3]}
        assert safe_eval("(1, 2)") == (1, 2)
        assert safe

# Generated at 2022-06-21 07:56:24.794610
# Unit test for function safe_eval
def test_safe_eval():
    # Basic sanity checking
    assert safe_eval('1') == 1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    # Make sure we don't allow function calls
    try:
        assert safe_eval('abs(-42)')
    except Exception as e:
        assert 'invalid expression' in str(e)
    # Make sure we don't allow attribute access
    try:
        assert safe_eval('[].')
    except Exception as e:
        assert 'invalid expression' in str(e)

# Generated at 2022-06-21 07:56:33.210488
# Unit test for function safe_eval
def test_safe_eval():
    # test helper function
    def _test_eval(eval_str, expect_result, expect_exception,
                   locals=None, include_exceptions=False):
        result, exception = safe_eval(eval_str, locals=locals,
                                      include_exceptions=include_exceptions)
        if exception:
            if expect_exception:
                if sys.version_info >= (3, 0):
                    if not isinstance(exception, expect_exception):
                        raise AssertionError("exception %s not equal to expected exception %s" % (exception, expect_exception))
                else:
                    if not isinstance(exception[0], expect_exception):
                        raise AssertionError("exception %s not equal to expected exception %s" % (exception, expect_exception))

# Generated at 2022-06-21 07:56:45.751306
# Unit test for function safe_eval
def test_safe_eval():

    # most basic test
    expr = '1 + 1'
    expected = 2
    assert safe_eval(expr) == expected

    # test the obvious case, where we raise an exception
    # for invalid syntax
    expr = '1 + * 1'
    expected = expr
    assert safe_eval(expr) == expected

    # test the obvious case, where we raise an exception
    # for invalid syntax
    expr = 'open("/etc/passwd").readlines()'
    expected = expr
    assert safe_eval(expr) == expected

    # test the obvious case, where we raise an exception
    # for invalid syntax
    expr = 'os.system("echo hello")'
    expected = expr
    assert safe_eval(expr) == expected

    # test the obvious case, where we raise an exception
    # for invalid syntax

# Generated at 2022-06-21 07:56:50.929896
# Unit test for function safe_eval
def test_safe_eval():

    def check_eval(expr, expected=None, include_exceptions=False, locals=None):
        if expected is None:
            expected = expr
        locals = {} if locals is None else locals
        if include_exceptions:
            res, err = safe_eval(expr, locals, include_exceptions=True)
        else:
            res = safe_eval(expr, locals, include_exceptions=False)
        assert res == expected, "Expression %s evaluated to %s (expected %s)" % (expr, res, expected)

    check_eval('foo')
    check_eval('bar', locals={'bar': 'baz'})
    check_eval('[1, 2, 3]')
    check_eval('{"a": 1, "b": 2}')
    check_eval('1+2*3')
    check

# Generated at 2022-06-21 07:56:58.051963
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 + 2', include_exceptions=True) == (3, None)

    expr = '1 + 2'
    assert safe_eval(expr) == 3
    assert safe_eval(expr, include_exceptions=True) == (3, None)

    expr = '"a string literal"'
    assert safe_eval(expr) == "a string literal"
    assert safe_eval(expr, include_exceptions=True) == ("a string literal", None)

    expr = "a string literal"
    assert safe_eval(expr) == "a string literal"
    assert safe_eval(expr, include_exceptions=True) == ("a string literal", None)

    expr = "a string literal"
    assert safe_eval(expr) == "a string literal"

# Generated at 2022-06-21 07:57:10.303463
# Unit test for function safe_eval
def test_safe_eval():
    # unittest setup
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestSafeEval(unittest.TestCase):

        # FIXME: Add more test cases
        # FIXME: Test the correct handling of SyntaxError

        def test_python_version(self):
            # Just checking that Python version is >= 2.6
            self.assertGreaterEqual(sys.version_info[0], 2)
            self.assertGreaterEqual(sys.version_info[1], 6)
            self.assertEqual(3, safe_eval('1+2'))


# Generated at 2022-06-21 07:57:21.076923
# Unit test for function safe_eval
def test_safe_eval():
    def check_exc(expr, exc_str):
        try:
            safe_eval(expr)
        except Exception as e:
            assert str(e).startswith(exc_str)
        else:
            raise Exception("Should have thrown an exception")

    # Ensure safe_eval allows basic expressions
    test_expr = 'foo.bar'
    result = safe_eval(test_expr)
    assert result == test_expr

    # Ensure safe_eval allows simple math expressions
    test_expr = '5 * 4 + 10 / 10'
    result = safe_eval(test_expr)
    assert result == 20

    # Ensure safe_eval allows dicts, lists, tuples and more complex expressions

# Generated at 2022-06-21 07:57:32.932068
# Unit test for function safe_eval
def test_safe_eval():
    # set up a fake load
    # load = dict(
    #     hosts=['fake_host']
    # )

    # Set up some variables
    local_vars = dict(
        my_var1='foo',
        my_var2='bar'
    )

    # Set up some mappings
    my_dict = dict(
        my_key1='my_value1',
        my_key2='my_value2',
    )

    # Set up some lists
    my_list = [
        'my_list_value1',
        'my_list_value2',
        'my_list_value3',
    ]

    # set up some tests

# Generated at 2022-06-21 07:57:35.432522
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Run doctests on safe_eval
    '''
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-21 07:57:51.307325
# Unit test for function safe_eval
def test_safe_eval():
    # TEST FOR SAFE_NODES
    expr_str = '''
        [
            True,
            False,
            (1 * 1),
            (0 - 9),
            (9 + 9),
            (0 / 1),
            (1 / 0),
            (2 / 2),
            2,
            2.0,
            "hello",
            [],
            (),
            {},
            {'a':'b'},
            'a' in ['b','c','d'],
            ('a' == 'b'),
            ('a' != 'b'),
            ('not' == 'a'),
            ('not' != 'a')
        ]
    '''
    results = safe_eval(expr_str)

# Generated at 2022-06-21 07:58:03.638522
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo", {"foo": "bar"}, include_exceptions=True) == ('bar', None)
    assert safe_eval("foo", {"foo": "bar"}) == 'bar'
    assert safe_eval("foo(bar)", {}) == "foo(bar)"
    assert safe_eval("foo(bar)", {"foo": "bar"}, include_exceptions=True) == ("foo(bar)", None)
    assert safe_eval("foo(bar)",
                     {"foo": "bar", "bar": "foo"},
                     include_exceptions=True) == ("foo(bar)", None)
    assert safe_eval("foo(bar)", {"foo": "bar", "bar": "foo"}) == "foo(bar)"
    assert safe_eval("foo", {"foo": "bar"}) == 'bar'

# Generated at 2022-06-21 07:58:15.433091
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # Make sure key ansible_ variables are defined for this test.
    sys.modules['__main__'].ansible_version = '999.99.99'
    sys.modules['__main__'].ansible_module_version = '999.99.99'
    sys.modules['__main__'].ansible_python_version = (3, 8, 5)

    # Verify safe evaluation of valid expressions.
    assert safe_eval(
        'ansible_version', locals=locals()
    ) == '999.99.99'
    assert safe_eval(
        'ansible_module_version', locals=locals()
    ) == '999.99.99'

# Generated at 2022-06-21 07:58:23.137631
# Unit test for function safe_eval
def test_safe_eval():
    # Test invalid expressions
    assert safe_eval("{{ this }}") == "{{ this }}"
    assert safe_eval("{{ this }}", include_exceptions=True)[1] is None
    assert safe_eval(2 + 3) == 5
    assert safe_eval((2 + 3), include_exceptions=True)[1] is None
    assert safe_eval("") == ""
    assert safe_eval("", include_exceptions=True)[1] is None
    assert safe_eval(None) is None
    assert safe_eval(None, include_exceptions=True)[1] is None
    assert safe_eval(set([])) == set([])
    assert safe_eval(set([]), include_exceptions=True)[1] is None
    assert safe_eval(dict([])) == {}

# Generated at 2022-06-21 07:58:34.707603
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:44.730419
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:56.290010
# Unit test for function safe_eval
def test_safe_eval():
    # always enable these calls in the unit tests
    CALL_ENABLED.extend(['test_call', 'test_call2'])

    def test_call(arg1, arg2):
        return arg1 + arg2

    def test_call2(arg1, arg2=None):
        return arg1 + arg2

    def test_call3(arg1, arg2=None):
        return arg1 + arg2

    assert 42 == safe_eval('42')
    assert 42 == safe_eval(42)
    assert 42 == safe_eval(ast.Num(42))
    assert 42 == safe_eval(ast.Expression(ast.Num(42)))

    assert 'Hello' == safe_eval("'Hello'")
    assert 'Hello' == safe_eval(ast.Constant('Hello'))
    assert 'Hello'

# Generated at 2022-06-21 07:59:08.126376
# Unit test for function safe_eval
def test_safe_eval():
    # testing constants
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None

    assert safe_eval('true and true') is True
    assert safe_eval('true and false') is False
    assert safe_eval('true or false') is True
    assert safe_eval('false or false') is False

    assert safe_eval('true or false and true') is True
    assert safe_eval('true and false or true') is True
    assert safe_eval('false and true or true') is True

    assert safe_eval('1 == 1') is True
    assert safe_eval('2 == 1') is False
    assert safe_eval('1 != 1') is False

# Generated at 2022-06-21 07:59:17.225252
# Unit test for function safe_eval
def test_safe_eval():
    print("Testing safe_eval...")
    # Test variable substitution in base cases
    assert safe_eval("{{ test }}") == "{{ test }}"
    assert safe_eval("{{ test }}", dict(test="THIS TEST PASSED")) == "THIS TEST PASSED"
    assert safe_eval(u"{{ test }}", dict(test=u"THIS TEST PASSED")) == u"THIS TEST PASSED"

    # Test native int and string literals
    assert safe_eval(u"1") == 1
    assert safe_eval(u"[1, 2, 3, 4]") == [1, 2, 3, 4]
    assert safe_eval(u"True") == True
    assert safe_eval(u"False") == False
    assert safe_eval(u"None") == None

# Generated at 2022-06-21 07:59:28.391199
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval()
    '''

    # test cases, each of which is a triple of args and a result

# Generated at 2022-06-21 07:59:39.493558
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:51.634873
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval by looking for exceptions
    '''
    # test input
    STR_TRUE = "'True'"
    STR_FALSE = "'False'"
    STR_ZERO = '0'
    STR_ONE = '1'
    STR_EMPTY_STRING = "''"
    STR_NONEMPTY_STRING = "'a string'"
    STR_EMPTY_LIST = '[]'
    STR_NONEMPTY_LIST = '["one", "two", 3]'
    STR_EMPTY_DICT = '{}'
    STR_NONEMPTY_DICT = '{"key1": "value1", "key2": "value2"}'
    STR_PAREN_STRING = "'one (1)'"
    STR_ADD_ONE_TWO = '1 + 2'


# Generated at 2022-06-21 07:59:59.391107
# Unit test for function safe_eval
def test_safe_eval():

    def check(expr, expected=None, **kwargs):
        # This helper function updates the global vars we use for safe_eval
        # and executes it.  The global vars (safe_eval_locals and
        # safe_eval_include_exceptions) are set to the values passed
        # to this function.  If a non-default value is not specified for these
        # globals, then the default is used.
        global safe_eval_locals
        global safe_eval_include_exceptions

        if safe_eval_locals is None:
            safe_eval_locals = locals()

        if kwargs is not None:
            for key, value in kwargs.items():
                if key in safe_eval_locals.keys():
                    safe_eval_locals[key] = value


# Generated at 2022-06-21 08:00:04.895075
# Unit test for function safe_eval
def test_safe_eval():
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            print(safe_eval(arg))
            print(safe_eval(arg, include_exceptions=True))
    else:
        raise Exception("missing arguments")

if __name__ == '__main__':
    test_safe_eval()

# Generated at 2022-06-21 08:00:13.634559
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1:
    b = dict(element1 = 5, element_2 = "bar", element_3 = dict(element4 = "foo"))
    for test in [
        ('element1', 5),
        ('element_2', 'bar'),
        ('element3', u'***unsupported expression type***'),
        ('element_3', {u'element4': u'foo'}),
        ('element_3.element4', 'foo'),
    ]:
        test_value = safe_eval(test[0], dict(a=b), True)
        assert test_value[0] == test[1], \
            "Unexpected result in value: %s, expected: %s" % (test_value[0], test[1])

    # Test 2:

# Generated at 2022-06-21 08:00:25.417815
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function safe_eval
    '''

# Generated at 2022-06-21 08:00:35.742950
# Unit test for function safe_eval
def test_safe_eval():
    # CleansingNodeVisitor intentionally disallows function calls.  But, we can
    # work around this by enabling a specific, known safe function 'int'.
    our_globals = {'__builtins__':{}, 'int':int}

    # Test basic comparison operations
    assert safe_eval('10', our_globals) == 10
    assert safe_eval('5+5', our_globals) == 10
    assert safe_eval('5-10', our_globals) == -5
    assert safe_eval('100/10', our_globals) == 10
    assert safe_eval('10*10', our_globals) == 100
    assert safe_eval('10*(10+10)', our_globals) == 200

# Generated at 2022-06-21 08:00:46.113032
# Unit test for function safe_eval
def test_safe_eval():
    # Enable safe_eval to call specific builtin functions
    CALL_ENABLED.extend([
        'len',
        'min',
        'max',
    ])

    # Test safe_eval without call support
    try:
        assert safe_eval('len([1,2])') == 2
    except Exception:
        # This is a valid expression, so it should not throw an exception
        assert False

    # Test safe_eval WITH call support
    assert safe_eval('len([1,2])') == 2

    # Test safe_eval WITH call support
    try:
        safe_eval('open("/tmp/foo")')
        # This is an invalid expression, so it should throw an exception
        assert False
    except Exception:
        pass

    # Test safe_eval with a more complex expression.

# Generated at 2022-06-21 08:00:57.668254
# Unit test for function safe_eval