

# Generated at 2022-06-21 07:51:12.525228
# Unit test for function safe_eval
def test_safe_eval():
    # Test with simple string data
    expr = '{ "FOO": "BAR" }'
    data = safe_eval(expr)
    assert data == {'FOO': 'BAR'}

    # Test with more complex string data
    expr = '{"dest": "{{ backup_dir }}/{{ inventory_hostname_short }}", "options": "-i {{ id_rsa_path }} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"}'
    data = safe_eval(expr)
    assert data == {'dest': '{{ backup_dir }}/{{ inventory_hostname_short }}', 'options': '-i {{ id_rsa_path }} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'}

    # Test with data already evaluated
   

# Generated at 2022-06-21 07:51:25.218338
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:38.003344
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:46.867545
# Unit test for function safe_eval
def test_safe_eval():

    # Basic test: ensure that safe_eval can handle simple computations
    e = '2 + 2'
    result, err = safe_eval(e, include_exceptions=True)
    assert result == 4
    assert err is None
    if sys.version_info < (3, 0):
        assert type(result) is int

    # Ensure that safe_eval can handle file references
    e2 = '{{ playbook_dir }}/foo.yml'
    result2, err2 = safe_eval(e2, include_exceptions=True)
    assert result2 == e2
    assert err2 is None

    # Ensure that safe_eval raises an exception when called with an invalid expression
    e3 = 'foo.bar()'
    result3, err3 = safe_eval(e3, include_exceptions=True)
    assert result3

# Generated at 2022-06-21 07:51:58.221442
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:11.299512
# Unit test for function safe_eval
def test_safe_eval():
    # Simple success case
    expr = "1 + 2"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == 3 and not exception

    # Result should be a string
    expr = "'a string'"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == "a string" and not exception

    # Syntax error should leave the expression
    expr = "[1,2,3]]"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr and not exception

    # Error should leave the expression
    expr = "5/0"
    result, exception = safe_eval(expr, include_exceptions=True)
    assert result == expr and not exception

    # FIXME: CNV should raise an exception, but for

# Generated at 2022-06-21 07:52:20.740528
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Validates the safe_eval function
    '''

    # Test list of tests and expected outcome

# Generated at 2022-06-21 07:52:31.864165
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2 + 2", include_exceptions=True) == (4, None)
    assert safe_eval("2 + 2") == 4
    assert safe_eval("2 + 2", {"two": 2}) == 4
    assert safe_eval("2 + 2") == 4
    assert safe_eval("len(['a', 'b', 'c'])") == 3
    assert safe_eval("[1, 2, 3, 4][0]") == 1
    assert safe_eval("2 + 3 * 4", include_exceptions=True) == (14, None)
    assert safe_eval("2 * -1", include_exceptions=True) == (-2, None)
    assert safe_eval("2 + 2 == 4") == True
    assert safe_eval("2 + 2 == 5") == False

# Generated at 2022-06-21 07:52:39.788568
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2
    if PY2:
        #TODO: change the testcase to string type
        try:
            safe_eval(u"{'name': 'value'}")
        except:
            pass
        else:
            raise AssertionError("Safe eval should not accept unicode as input on Python 2")

    # Following should all pass
    safe_eval("[]")
    safe_eval("{}")
    safe_eval("1")
    safe_eval("a or b")
    safe_eval("a and b")
    safe_eval("a in b")
    safe_eval("a not in b")
    safe_eval("a is b")

# Generated at 2022-06-21 07:52:50.938116
# Unit test for function safe_eval
def test_safe_eval():
    # Single number
    assert safe_eval("1") == 1

    # Multiple numbers
    assert safe_eval("1 + 2 - 3") == 0
    assert safe_eval("3 * 4 / 2") == 6

    # Numbers and variable
    assert safe_eval("1 + foo") == 4
    assert safe_eval("foo - 2", dict(foo=5)) == 3
    assert safe_eval("foo - bar", dict(foo=5, bar=2)) == 3

    # Brackets
    assert safe_eval("(1 + 2) * 3") == 9
    assert safe_eval("(foo + 2) * 3", dict(foo=3)) == 15
    assert safe_eval("(foo - 2) * bar", dict(foo=5, bar=3)) == 9

    # Not allowed:
    # - Calling functions
    # -

# Generated at 2022-06-21 07:53:02.579232
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic eval
    assert safe_eval('1') == 1
    assert safe_eval('2 + 3') == 5
    assert safe_eval('4 - 1') == 3
    assert safe_eval('4 * 5') == 20
    assert safe_eval('12 / 2') == 6
    assert safe_eval('12 / 3') == 4
    assert safe_eval('13 / 3') == 4
    assert safe_eval('-12') == -12
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('true') is True
    assert safe_eval('foo') == 'foo'


# Generated at 2022-06-21 07:53:14.759335
# Unit test for function safe_eval
def test_safe_eval():
    old_debug = C.DEFAULT_DEBUG
    old_log_path = C.DEFAULT_LOG_PATH
    C.DEFAULT_DEBUG = True
    C.DEFAULT_LOG_PATH = '/dev/null'

# Generated at 2022-06-21 07:53:25.454610
# Unit test for function safe_eval
def test_safe_eval():
    # Call the function safe_eval with different type of arguments,
    # and make sure the correct return value is returned

    # Test case 1: expr is a simple string type
    result1 = safe_eval("1 + 1")
    assert result1 == 2

    # Test case 2: expr is a dict type
    result2 = safe_eval("{'a': 1}")
    assert result2 == {'a': 1}

    # Test case 3: expr is a list type
    result3 = safe_eval("[1, 2, 3]")
    assert result3 == [1, 2, 3]

    # Test case 4: expr is a dict type
    result4 = safe_eval("1 and True or False")
    assert result4 == True

    # Test case 5: expr is an empty string
    # Return an empty string if expr is empty


# Generated at 2022-06-21 07:53:38.027287
# Unit test for function safe_eval
def test_safe_eval():

    # get test data
    eval_test_data = C.YAML_ANSIBLESAFEEVAL

    # evaluate JSON types
    # Note: 'safe_eval' return the evaluated data structure or the original expression
    #       in case of an error. The test will fail if 'safe_eval' returns the original
    #       expression when it should have evaluated it.
    # Set "trusted_hosts" to a known string which will be evaluated to a list.
    # We need to set 'trusted_hosts' because we can't use a list as an 'allowed_host'
    # value.
    for test in eval_test_data:
        assert test[0] == safe_eval(test[0])                       # no-op
        if test[1] is not None: assert test[1] == safe_eval(test[0])

# Generated at 2022-06-21 07:53:48.031316
# Unit test for function safe_eval
def test_safe_eval():
    # Test basic variable replacement
    test_list = {
        'var': 'foo',
        'dict': {'bar': 'baz'},
        'list': ['bar'],
        'truthy': 'true',
        'falsy': 'false',
        'none': 'null',
    }
    for expr, expected in (
        ('var', 'foo'),
        ('dict.bar', 'baz'),
        ('list[0]', 'bar'),
        ('truthy', True),
        ('falsy', False),
        ('none', None),
    ):
        result, err = safe_eval(expr, test_list, include_exceptions=True)
        assert result == expected, "%s failed, got %r, expected %r" % (expr, result, expected)

# Generated at 2022-06-21 07:53:58.324933
# Unit test for function safe_eval
def test_safe_eval():
    def test(expr, success=True):
        (result, error) = safe_eval(expr, include_exceptions=True)
        if success:
            assert result == eval(expr)
        else:
            assert error is not None

    test("1+1")
    test("1+1", success=True)
    test("1+1==2", success=True)
    test("1+1==3", success=False)
    test("__import__('os').getcwd()", success=False)
    test("__import__('os').getcwd", success=False)
    test("__builtins__['__import__']('os').getcwd()", success=False)
    test("1 + 1")
    test("'%s'" % C.DEFAULT_HASH_BEHAVIOUR)
    test

# Generated at 2022-06-21 07:54:09.912644
# Unit test for function safe_eval
def test_safe_eval():
    # the following should all evaluate successfully
    assert safe_eval("2+2") == 4
    assert safe_eval("True")
    assert safe_eval("false") is False
    assert safe_eval("null") is None
    assert safe_eval("true")
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("(1,2,3)") == (1,2,3)
    assert safe_eval("{'a':1, 'b':2}") == {'a':1, 'b':2}

    # the following should all raise exceptions during safe_eval
    #assert safe_eval("__import__")
    assert safe_eval("open")

    # this should raise an exception if safe_eval is not called with include_exceptions

# Generated at 2022-06-21 07:54:17.701796
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(1) == 1
    assert safe_eval('1') == 1
    assert safe_eval('a') == 'a'
    assert safe_eval('a.b.c') == 'a.b.c'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None
    assert safe_eval('a==3') == 'a==3'
    assert safe_eval('[1]') == [1]
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('[1,2,a]') == [1, 2, 'a']

# Generated at 2022-06-21 07:54:28.268060
# Unit test for function safe_eval
def test_safe_eval():
    """
    This function is not called when running the code normally, only when the
    module is run as its own program.  It is used to compare the output of
    safe_eval with the output from the built-in eval.  The built-in eval is
    considered the gold standard in what it can do, and we are trying to do
    the same.
    """
    # Here are the calls we want to test, look at the output of
    # python -m ansible.module_utils.facts safe_eval
    # to see the results.

# Generated at 2022-06-21 07:54:37.928327
# Unit test for function safe_eval
def test_safe_eval():

    # Test whitelisted conditions
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1 or True') is 1
    assert safe_eval('if 1: True') is True
    assert safe_eval('if 1: True else False') is True
    assert safe_eval('if 0: True else False') is False
    assert safe_eval('if 0: True else 1') == 1
    assert safe_eval('if 0: True else 1+1') == 2
    assert safe_eval('if 1: True else False') is True
    assert safe_eval('if 1: True else False') is True

# Generated at 2022-06-21 07:54:53.856895
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:01.049884
# Unit test for function safe_eval
def test_safe_eval():
    '''safe_eval() unit test'''

    # How to add a test:
    # f = lambda x: x['foo']
    # tests = [
    #     ('foo', 'foo'),
    #     (1, 1),
    #     (1|2, 3),
    #     (f({'foo': 1, 'bar': 2}), 1),
    #     (f(dict(foo=1,bar=2)), 1),
    #     (['foo', 'bar'][0], 'foo'),
    #     (dict(foo=1,bar=2)['foo'], 1),
    #     (True and True, True),
    #     (True or False, True),
    #     (True if (1==1) else False, True),
    # ]

    # test valid expressions

# Generated at 2022-06-21 07:55:13.379026
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:23.732965
# Unit test for function safe_eval
def test_safe_eval():
    def run_test(expr, expected_result):
        try:
            result, exception = safe_eval(expr, include_exceptions=True)
            if exception:
                return False

            if result == expected_result:
                return True
            return False

        except:
            return False

    #####################################
    # Start tests
    #####################################
    # Test case 1: invalid expression
    test_case = 1
    result = run_test("'str(1)'", None)
    print("test #%d: %s" % (test_case, 'OK' if result else 'Failed'))
    sys.stdout.flush()
    test_case += 1

    # Test case 2: invalid expression
    result = run_test('true', None)

# Generated at 2022-06-21 07:55:35.226255
# Unit test for function safe_eval
def test_safe_eval():
    # This method is intended to just be invoked by py.test while you
    # are developing the code in this file.
    #

    def run_test(expr, expected_value=None, expected_exception=None):
        obj = safe_eval(expr)
        if expected_value != None:
            assert obj == expected_value
        if expected_exception != None:
            assert type(obj) == expected_exception

    # Valid expressions
    run_test("[1,2,3,4,5]")
    run_test("(1,2,3,4,5)")
    run_test("{'a': 1, 'b':2, 'c':3, 'd':4, 'e':5}")
    run_test("{1,2,3,4,5}")

# Generated at 2022-06-21 07:55:45.546932
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("{'boo': true}") == {'boo': True}
    assert safe_eval("{'foo': 1 + 3}") == {'foo': 4}
    assert safe_eval("1 + 4") == 5
    assert safe_eval("1 + None") == 1
    assert safe_eval("1 + null") == 1
    # the following test should fail, but does not. that's a bug...
    if sys.version_info[0] == 3:
        assert safe_eval("1 + True") == 2
    else:
        assert safe_eval("1 + True") == 2

# Generated at 2022-06-21 07:55:58.371849
# Unit test for function safe_eval
def test_safe_eval():
    # Test that the test methods pass
    assert(safe_eval('foo') == 'foo')
    assert(safe_eval('1 + 1') == 2)
    assert(safe_eval('foo in bar') == 'foo in bar')
    # Test a truncated AstCall node to make sure we don't allow it
    try:
        assert(safe_eval('__import__("os").system("echo hello")'))
    except Exception as e:
        assert(str(e) == 'invalid expression (__import__("os").system("echo hello"))')
    # Test a truncated AstName node to make sure we don't allow it

# Generated at 2022-06-21 07:56:06.359612
# Unit test for function safe_eval
def test_safe_eval():

    def test_scenario(scenario, result):
        print("Scenario : %s" % scenario)
        if isinstance(result, tuple):
            func_result, exception = result
        else:
            func_result = result
            exception = None
        assert safe_eval(scenario) == func_result
        assert safe_eval(scenario, include_exceptions=True)[0] == func_result
        if exception:
            assert isinstance(safe_eval(scenario, include_exceptions=True)[1], exception)
        print('=' * 30)

    # Test scenarios

# Generated at 2022-06-21 07:56:18.470995
# Unit test for function safe_eval
def test_safe_eval():

    # these all work
    assert safe_eval("[]") == []
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{'a':1}") == {'a': 1}
    assert safe_eval("'foo'") == 'foo'

    # this raises an exception because json doesn't know about python dicts
    try:
        safe_eval("{1:2}")
        assert False
    except Exception:
        pass

    # this is not valid YAML
    try:
        safe_eval("1:2")
        assert False
    except SyntaxError:
        pass

    # we allow simple math
    assert safe_eval("3+4") == 7

    # we allow simple math with variables

# Generated at 2022-06-21 07:56:28.667661
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1
    # ensure safe_eval works the same as regular eval
    res = safe_eval('[1, 2, 3]')
    assert res == [1,2,3]

    # Test 2
    # ensure safe_eval works the same as regular eval
    res = safe_eval('{"a": "b"}')
    assert res == {'a': 'b'}

    # Test 3
    # ensure strings can be converted to ints
    res = safe_eval('1')
    assert res == 1

    # Test 4
    # ensure strings can be converted to floats
    res = safe_eval('1.1')
    assert res == 1.1

    # Test 5
    # ensure strings can be converted to booleans
    res = safe_eval('true')
    assert res == True

    # Test 6
    #

# Generated at 2022-06-21 07:56:44.811963
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test safe eval and make sure it raises an assertion error
    """
    import pytest

    # Test invalid expressions
    expr = "'now' | strftime(a_variable)"
    with pytest.raises(Exception):
        safe_eval(expr)

    expr = 'a_variable | regex_replace("(foo)", "\\1")'
    with pytest.raises(Exception):
        safe_eval(expr)

    expr = '{{ a_variable }}'
    with pytest.raises(Exception):
        safe_eval(expr)

    expr = '(a_variable'
    with pytest.raises(Exception):
        safe_eval(expr)

    expr = ")a_variable"
    with pytest.raises(Exception):
        safe_eval(expr)


# Generated at 2022-06-21 07:56:54.587887
# Unit test for function safe_eval
def test_safe_eval():
    # test when callable is allowed
    assert safe_eval('set([1,2,3])', dict(set=set), include_exceptions=True) == (set([1, 2, 3]), None)
    assert safe_eval('set([1,2,3])', dict(set=set)) == set([1, 2, 3])
    assert safe_eval('5 + 3', dict(set=set), include_exceptions=True) == (8, None)
    assert safe_eval('5 + 3', dict(set=set)) == 8

    # test when callable is not allowed
    assert safe_eval('set([1,2,3])', dict()) == 'set([1,2,3])'

# Generated at 2022-06-21 07:57:06.735865
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:14.924367
# Unit test for function safe_eval
def test_safe_eval():

    # test general syntax errors
    assert safe_eval("{{ foo") == "{{ foo", "failed to return original string on syntax error"
    assert safe_eval("{% foo") == "{% foo", "failed to return original string on syntax error"
    assert safe_eval("% foo") == "% foo", "failed to return original string on syntax error"
    assert safe_eval("- foo") == "- foo", "failed to return original string on syntax error"
    assert safe_eval("* foo") == "* foo", "failed to return original string on syntax error"
    assert safe_eval("/ 1, 0") == "/ 1, 0", "failed to return original string on syntax error"

    # test not allowed identifier
    assert safe_eval("foo.__dict__") == "foo.__dict__", "failed to return original string on invalid identifier"

    #

# Generated at 2022-06-21 07:57:27.290220
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2 ,3]') == [1, 2, 3]
    assert safe_eval('{"a": [1,2] , "b": true }') == {"a": [1, 2], "b": True}
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo|bar") == "foo|bar"
    assert safe_eval("foo") == "foo"

    (result, err) = safe_eval("foo.bar", include_exceptions=True)
    assert err is not None
    assert result == "foo.bar"


# Generated at 2022-06-21 07:57:37.407243
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:50.127797
# Unit test for function safe_eval
def test_safe_eval():
    # Test the safe_eval function.
    def assert_eval(expr, result, locals=None):
        if locals:
            actual = safe_eval(expr, locals=locals)
        else:
            actual = safe_eval(expr)

        if type(actual) != type(result):
            print(type(actual))
            print(type(result))
            raise AssertionError("%s: results do not match type" % expr)
        if actual != result:
            raise AssertionError("%s: results do not match value %s != %s" % (expr, actual, result))

    assert_eval("not True", False)
    assert_eval("True and False", False)
    assert_eval("True or False", True)
    assert_eval("True or False and True or False", True)
    assert_eval

# Generated at 2022-06-21 07:57:57.937924
# Unit test for function safe_eval
def test_safe_eval():

    def assert_type(inp, out_t, **kwargs):
        r, e = safe_eval(inp, include_exceptions=True, **kwargs)
        assert isinstance(r, out_t) or r is out_t, "%s is not an %s" % (r, out_t)
        if e:
            raise e

    a = 10
    var_a = 10
    var_b = 100
    assert_type("'%s'" % a, str)
    assert_type("%s" % var_a, int)
    assert_type("%s + %s" % (a, var_b), int)
    assert_type("'%s' + '%s'" % (a, var_b), str)

# Generated at 2022-06-21 07:58:10.096634
# Unit test for function safe_eval
def test_safe_eval():
    expr = 'foo[4]'
    var = dict(foo=[1,2,3,4,5])

    safe_result, safe_err = safe_eval(expr, dict(var), include_exceptions=True)

    if safe_result != var['foo'][4]:
        print("Eval test 1: failed eval with safe_eval")

    if safe_err is not None:
        print("Eval test 2: safe_eval raised an exception: %s" % (safe_err))

    try:
        full_result = eval(expr, dict(var))
    except Exception as e:
        print("Eval test 3: eval failed without an exception")

    if full_result != var['foo'][4]:
        print("Eval test 4: failed eval w/o safe_eval")



# Generated at 2022-06-21 07:58:16.056111
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function safe_eval
    basic syntax checks
    '''
    assert safe_eval('True')

    assert safe_eval('true')

    assert safe_eval('null is None')

    assert safe_eval('1 + 2')

    assert safe_eval('{"a": [1, 2, 3], "b": "c"}')

    assert safe_eval('["a", "b", "c"]')



# Generated at 2022-06-21 07:58:29.214711
# Unit test for function safe_eval
def test_safe_eval():
    # try a few things to make sure we get what we expect
    assert safe_eval('foo.lower()') == 'foo.lower()'
    assert safe_eval('foo.lower()', locals={'foo': 'BAR'}) == 'BAR'.lower()
    assert safe_eval('foo.lower()', locals={'foo': 'BAR'}) != 'foo.lower()'

    # make sure we can do some simple math
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 - 1') == 0
    assert safe_eval('1 * 1') == 1
    assert safe_eval('1 / 1') == 1

    # dicts
    assert safe_eval('{"a": "foo", "b": "bar"}') == {'a': 'foo', 'b': 'bar'}
    assert safe_

# Generated at 2022-06-21 07:58:41.044165
# Unit test for function safe_eval
def test_safe_eval():

    # simple test for a bad syntax
    expr = "{foo: bar}"
    (res, err) = safe_eval(expr, include_exceptions=True)
    assert expr == res
    assert isinstance(err, SyntaxError)

    # simple test for bad syntax in a dict
    expr = "var1: 'foo' bar: value"
    (res, err) = safe_eval(expr, include_exceptions=True)
    assert expr == res
    assert isinstance(err, SyntaxError)

    # dict with a dict
    expr = "{x: 'foo', 'y': {'bar':'baz'}}"
    (res, err) = safe_eval(expr, include_exceptions=True)
    assert expr == container_to_text(res)
    assert err is None

# Generated at 2022-06-21 07:58:50.965133
# Unit test for function safe_eval
def test_safe_eval():
    def _test(expr, locals, expected_result, include_exceptions):
        if include_exceptions:
            result, exception = safe_eval(expr, locals, include_exceptions)
        else:
            result = safe_eval(expr, locals, include_exceptions)

        if include_exceptions:
            if result == expected_result and exception is None:
                return True
        elif result == expected_result:
            return True

        print("Failed to evaluate '%s' properly with locals %s.  Result was '%s', expected '%s'" % (expr, locals, result, expected_result))
        return False

    # test standard expression
    good = _test("2 + 3", {}, 5, False)
    assert good

    # test syntax error

# Generated at 2022-06-21 07:59:02.852558
# Unit test for function safe_eval
def test_safe_eval():
    # This tests code that is around the safe_eval code.
    assert isinstance(safe_eval('{{ ansible_distribution }}'), string_types)

    # These tests are based on the documentation
    assert safe_eval('1 + 2 + 3') == 6
    assert safe_eval('(True and not False) and not True') == False
    assert safe_eval('len(["a", "b", "c"])') in [3, u'3']
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None

    # And to prove the tests above are not trivially passing
    assert safe_eval('1 + 2 + 3') != 5
    assert safe_eval('(True and not False) and not True') != True

# Generated at 2022-06-21 07:59:11.379512
# Unit test for function safe_eval
def test_safe_eval():
    assert 'foo' == safe_eval('foo')
    assert [1,2,3] == safe_eval('[1,2,3]')
    assert (1,2,3) == safe_eval('(1,2,3)')
    assert {"a": 1, "b": 2} == safe_eval('{"a": 1, "b": 2}')
    assert {"a": 1, "b": 2} == safe_eval('{"a": 1, "b": 2}')
    assert True == safe_eval('true')
    assert False == safe_eval('false')
    assert None == safe_eval('null')
    assert 2 == safe_eval('1+1')
    assert 2.5 == safe_eval('1+1.5')
    assert 3 == safe_eval('1+1+1')

# Generated at 2022-06-21 07:59:21.724282
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic tests for safe_eval
    '''
    # test None / empty string
    ret = safe_eval('', {})
    assert ret is None

    ret = safe_eval(None, {})
    assert ret is None

    # test simple values as expressions
    ret = safe_eval('0', {})
    assert ret == 0

    ret = safe_eval('string', {})
    assert ret == 'string'

    # test dictionaries and lists in expressions, implicitly via
    # their string representation
    # eg. '{}' == {}
    ret = safe_eval('{}', {})
    assert ret == {}

    ret = safe_eval('[]', {})
    assert ret == []

    ret = safe_eval('{1: 2}', {})
    assert ret == {1: 2}

   

# Generated at 2022-06-21 07:59:32.775253
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    def test_eval(expr, result, locals=None):
        assert safe_eval(expr, locals=locals) == result

    # Simple things
    test_eval("1+2", 3)
    test_eval("1+2*3", 7)

    # Constants and variables
    test_eval("True", True)
    test_eval("False", False)
    test_eval("None", None)
    test_eval("'a'", 'a')
    test_eval('"a"', 'a')
    test_eval("[1, 'a', [2, 3.0]]", [1, 'a', [2, 3.0]])
    test_eval("(1, 'a')", (1, 'a'))

# Generated at 2022-06-21 07:59:39.310267
# Unit test for function safe_eval
def test_safe_eval():
    # First a test that's supposed to work
    test_str = "['hello', 'world']"
    # Try to safely eval test_str
    test_eval = safe_eval(test_str)
    # Fail if eval didn't work
    if not isinstance(test_eval, list):
        raise AssertionError('safe eval failed to return a list')
    # Fail if eval didn't return expected list
    if test_eval != ['hello', 'world']:
        raise AssertionError('safe eval did not return expected list')

    # Next a test that's supposed to fail
    test_str = "__import__('os').system('rm -rf /')"
    # Try to safely eval test_str
    test_eval = safe_eval(test_str)
    # Fail if eval didn't work

# Generated at 2022-06-21 07:59:51.445941
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('True') is True
    assert safe_eval('true') is True
    assert safe_eval('False') is False
    assert safe_eval('false') is False
    assert 'True' == safe_eval('"True"')
    assert 'True' == safe_eval("'True'")
    assert 'true' == safe_eval("'true'")
    assert 'tRUE' == safe_eval("'tRUE'")
    assert 'true ' == safe_eval("'true '")
    assert 'true' == safe_eval("'true'")
    assert 'false' == safe_eval("'false'")
    assert [1,2,3] == safe_eval("[1,2,3]")

# Generated at 2022-06-21 07:59:59.296752
# Unit test for function safe_eval
def test_safe_eval():
    """Does a series of tests to verify that safe_eval works
    as expected."""
    try:  # in 2.6, reloading modules is broken.  Work around it.
        reload(sys.modules['ansible.utils.unsafe_proxy'])
    except NameError:
        pass  # python3

    import ansible.utils.unsafe_proxy as unsafe_proxy

    assert not C.DEFAULT_DEBUG
    assert not hasattr(unsafe_proxy.AnsibleUnsafeText, '_ansible_unsafe_proxy_wrap')

    # First a safe example
    test_str = 'true'
    wrapped_str = unsafe_proxy.AnsibleUnsafeText(test_str)
    assert wrapped_str._ansible_unsafe_proxy_text == test_str
    assert wrapped_str._ansible_uns

# Generated at 2022-06-21 08:00:14.081461
# Unit test for function safe_eval
def test_safe_eval():
    # Test various valid expressions
    assert safe_eval('1/2') == 0.5
    assert safe_eval('1/2 + 1/2') == 1.0
    assert safe_eval('1.0/2 + 1.0/2') == 1.0
    assert safe_eval('1/2 + 1/2 + 1/2') == 1.5
    assert safe_eval('1/2 + 1/2 + 1/2 + 1/2') == 2.0
    assert safe_eval('1/2 + 1/2 + 1/2 + 1/2 + 1/2') == 2.5
    # Test negative
    assert safe_eval('-1*1') == -1
    assert safe_eval('0-1') == -1
    assert safe_eval('-(1)') == -1

# Generated at 2022-06-21 08:00:25.747841
# Unit test for function safe_eval
def test_safe_eval():
    expr = "a_list_variable.strip()"
    locals = {'a_list_variable': ' foo '}
    result = safe_eval(expr, locals)
    if result != 'foo':
        print("test_safe_eval did not return the expected value, got: %s" % result)
        sys.exit(-1)

    expr = "a_list_variable.strip()"
    locals = {'a_list_variable': ' foo '}
    result, exception = safe_eval(expr, locals, include_exceptions=True)
    if result != 'foo':
        print("test_safe_eval did not return the expected value, got: %s" % result)
        sys.exit(-1)

# Generated at 2022-06-21 08:00:38.177444
# Unit test for function safe_eval
def test_safe_eval():
    '''
    simple unit test to make sure safe_eval works as expected.
    '''
    MY_VARS = {
        'firstvar': '1st',
        'secondvar': '2nd',
        'thirdvar': True,
        'fourthvar': False,
        'fifthvar': None
    }

    # True statements
    assert safe_eval('firstvar', MY_VARS) == '1st'
    assert safe_eval('secondvar', MY_VARS) == '2nd'
    assert safe_eval('thirdvar', MY_VARS) is True
    assert safe_eval('fifthvar', MY_VARS) is None

    # Fails for simple evaluation
    try:
        assert safe_eval('None.foo', MY_VARS)
        assert False
    except:
        assert True

    # Test

# Generated at 2022-06-21 08:00:47.085063
# Unit test for function safe_eval
def test_safe_eval():
    # does not raise exception
    expr = "2 + 2"
    assert safe_eval(expr) == 4
    expr = "foo.split(':')[0]"
    assert safe_eval(expr, dict(foo='bar:baz')) == 'bar'
    expr = "len(['a', 'b', 'c'])"
    assert safe_eval(expr) == 3
    expr = "False if False else 'x'"
    assert safe_eval(expr) == 'x'

    # raises an exception
    expr = "eval('__import__(\"os\").system(\"echo hello\")')"
    exc = None
    try:
        safe_eval(expr)
    except Exception as e:
        exc = e
    assert exc is not None

    expr = "foo.split(';')[0]"
   

# Generated at 2022-06-21 08:00:58.519459
# Unit test for function safe_eval
def test_safe_eval():
    # success cases
    assert safe_eval('1 + 1') == 2
    assert safe_eval('3 - 2') == 1
    assert safe_eval('3 * 2') == 6
    assert safe_eval('3 / 2') == 1.5
    assert safe_eval('3 ** 2') == 9
    assert safe_eval('3 / 2 + 1 - 5 * 2 + 10') == -6.0
    assert safe_eval('[1,2,3] + [4,5]') == [1,2,3,4,5]
    assert safe_eval('(1, 2, 3) + (4, 5)') == (1, 2, 3, 4, 5)
    assert safe_eval('[1,2,3] * 3') == [1,2,3,1,2,3,1,2,3]
