

# Generated at 2022-06-21 07:51:02.394070
# Unit test for function safe_eval
def test_safe_eval():
    # setup required for local variables
    var1 = 'hello'
    var2 = ['one', 'two']
    var3 = {'a': 'b', 'c': 'd'}

    # test safe strings
    test_strings = {
        'var1': var1,
        'var2': var2,
        'var3': var3,
        'var1 + var1': var1 + var1,
        "'literal'": 'literal',
        '1 + 1': 1 + 1,
        '10 / 2': 5,
        '[]': [],
        '{}': {},
        'False': False,
        'True': True,
        'None': None
    }

    for test_string, expected in test_strings.items():
        actual = safe_eval(test_string, locals())


# Generated at 2022-06-21 07:51:14.342010
# Unit test for function safe_eval
def test_safe_eval():
    original_bool = C.DEFAULT_KEEP_REMOTE_FILES
    original_string = C.DEFAULT_REMOTE_TMP

# Generated at 2022-06-21 07:51:26.436007
# Unit test for function safe_eval
def test_safe_eval():
    class TestCtx:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def d(self):
            return 555
        def e(self):
            return 'eee'

    # first test basic variable stuff
    ctx = dict(
        foo='foo',
        c=TestCtx(1, 2),
        d=TestCtx(3, 4),
    )
    assert(safe_eval('foo', ctx) == 'foo')
    assert(safe_eval('c.a', ctx) == 1)
    assert(safe_eval('d.b', ctx) == 4)

    # then test operators
    assert(safe_eval('c.a + d.b', ctx) == 5)

# Generated at 2022-06-21 07:51:39.324416
# Unit test for function safe_eval
def test_safe_eval():
    '''
      Runs a test to see if the safe_eval function properly protects against
      malicious code.
    '''
    try:
        safe_eval("__import__('os').system('ls')")
        sys.exit("Failed safe_eval() test.  Expected exception, got none.")
    except Exception as e:
        pass
    else:
        sys.exit("Failed safe_eval() test.  Expected exception, got none.")

    # Quick sanity check against syntax errors
    assert safe_eval('{foo: 1}', include_exceptions=True)[0] == '{foo: 1}'

    # Test that function calls are disabled by default, even for builtins
    assert safe_eval(
        'str(x)', {'x': 123},
        include_exceptions=True
    )[1] != None

# Generated at 2022-06-21 07:51:47.794825
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None

    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"string"') == 'string'

# Generated at 2022-06-21 07:51:59.107139
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:12.123891
# Unit test for function safe_eval
def test_safe_eval():

    # Test == and !=
    assert safe_eval('3 == 3')
    assert safe_eval('3 != 4')

    # Test unary not and negation
    assert safe_eval('not 0')
    assert safe_eval('not 1')
    assert safe_eval('-0')
    assert safe_eval('-1')

    # Test comparisons
    assert safe_eval('1 >= 1')
    assert safe_eval('1 <= 1')
    assert safe_eval('1 > 0')
    assert safe_eval('1 < 2')
    assert safe_eval('1 < 2 > 0')
    assert safe_eval('1 < 2 > 3 < 4')

    # Test boolean operators
    assert safe_eval('1 and 1')
    assert safe_eval('0 and 1')
    assert safe_eval('1 and 0')
    assert safe_

# Generated at 2022-06-21 07:52:17.995185
# Unit test for function safe_eval
def test_safe_eval():
    expr = "var1 + ' ' + var2"

    # Safe when vars are defined
    vars = dict(var1='a', var2='b', var3='a+b')
    result = safe_eval(expr, vars)
    assert result == 'a b'

    # Also check that we do not leak vars
    result = safe_eval('var3', vars)
    assert result == 'a+b'

    # And that we do not allow dangerous function calls
    result = safe_eval('int("42")', vars)
    assert result == "int('42')"

    # Check that we allow explicitly allowed calls
    expr = "int('42')"
    safe_eval(expr, vars, include_exceptions=(True,))

# Generated at 2022-06-21 07:52:28.570084
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:37.682337
# Unit test for function safe_eval
def test_safe_eval():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__

   # Test nodes that should pass

# Generated at 2022-06-21 07:52:51.029246
# Unit test for function safe_eval
def test_safe_eval():
    # get exceptions for syntax errors
    for expr in [ '1 + * 2', 'foo(bar=baz)', 'foo = 1; bar = 2; foo + bar = baz', 'foo = [1, 2, 3' ]:
        (result, exception) = safe_eval(expr, include_exceptions=True)
        assert result == expr, "%s did not return the original expression '%s' but %s" % (expr, expr, result)
        assert exception is not None, "No exception was raised when trying to parse '%s'" % expr

    # get exceptions for invalid nodes

# Generated at 2022-06-21 07:53:00.605628
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:12.415567
# Unit test for function safe_eval
def test_safe_eval():
    # Test a series of expressions that should evaluate to True
    assert safe_eval('3 in [1,2,3]') is True

    # Test short-circuiting of boolean expression
    assert safe_eval('3 in [1,2,3] and false') is False

    # Test unicode literals
    assert safe_eval('u"\u00a1Hola!"') == u"\u00a1Hola!"
    assert safe_eval('u"A\xac\u1234\u20ac\U00008000"') == u"A\xac\u1234\u20ac\U00008000"

    # Test a series of expressions that should evaluate to False
    assert safe_eval('3 in [1,2,3] and false') is False

    # Test a series of expressions that should throw an exception
    # Type

# Generated at 2022-06-21 07:53:25.494717
# Unit test for function safe_eval
def test_safe_eval():
    locale = {'marks': [3, 5, 7]}
    success, exception = safe_eval('marks[0]', locale, True)
    assert success == 3
    assert exception == None

    success, exception = safe_eval('marks[4]', locale, True)
    assert success == 'marks[4]'
    assert exception != None

    success, exception = safe_eval('marks[4] + 1', locale, True)
    assert success == 'marks[4] + 1'
    assert exception != None

    # Check that valid calls are okay
    locale = {'callable': sys.version_info}
    success, exception = safe_eval('callable.major', locale, True)
    assert success == sys.version_info.major
    assert exception == None

    # Check that invalid calls are not okay
    success, exception = safe_

# Generated at 2022-06-21 07:53:38.073492
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function
    '''

    # hostvars
    # DEFAULT_SUDO_USER = 'root'
    # DEFAULT_SUDO_PASS = None
    # DEFAULT_REMOTE_USER = None #use connection plugin's default username
    # DEFAULT_REMOTE_PASS = None #use connection plugin's default password
    # DEFAULT_SU = False #do not use su by default
    # DEFAULT_SU_PASS = None #use su connection plugin's default password by default
    # DEFAULT_SU_USER = 'root'
    # DEFAULT_ASK_SU_PASS = False
    # DEFAULT_ASK_SUDO_PASS = False
    # DEFAULT_ASK_PASS = False
    # DEFAULT_BECOME = False
    # DEFAULT_BECOME_

# Generated at 2022-06-21 07:53:48.072684
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Verify that safe_eval fails when it should, and works when it should
    '''
    # basic examples of valid types
    assert safe_eval("'test'") == 'test'
    assert safe_eval('"test"') == 'test'
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("(1,2,3)") == (1, 2, 3)
    assert safe_eval("{'foo':'bar'}") == {'foo': 'bar'}

    # basic examples of invalid types
    try:
        safe_eval("foo()")
    except Exception as e:
        assert 'invalid expression (foo())' in str(e)
    else:
        raise AssertionError("Expected Exception was not raised")


# Generated at 2022-06-21 07:53:58.412001
# Unit test for function safe_eval
def test_safe_eval():
    # simple literals
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("{'k1': 'v1', 'k2': 'v2'}") == {'k1': 'v1', 'k2': 'v2'}
    assert safe_eval("['v1', 'v2']") == ['v1', 'v2']
    assert safe_eval("('v1', 'v2')") == ('v1', 'v2')
    assert safe_eval("true") is True
    assert safe_eval("false") is False

    # mathematical operators
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1 / 2") == 1.5

# Generated at 2022-06-21 07:54:09.379835
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('1') == 1
    assert safe_eval('a') == 'a'
    assert safe_eval('a.b.c') == 'a.b.c'
    assert safe_eval('False') is False
    assert safe_eval('true') is True
    assert safe_eval('true', dict(true=True)) is True
    assert safe_eval('a == 1') == 'a == 1'
    assert safe_eval('a is b') == 'a is b'
    if sys.version_info >= (3, 0):
        assert safe_eval('0 + 1') == 1
    else:
        assert safe_eval('0 + 1') == '0 + 1'
    assert safe_eval('a + 1') == 'a + 1'
    assert safe_eval

# Generated at 2022-06-21 07:54:17.339533
# Unit test for function safe_eval
def test_safe_eval():
    module_name = 'test'

    assert safe_eval("1") == 1
    assert safe_eval("1 + 1") == 2
    assert safe_eval("foo") == 'foo'
    assert safe_eval("foo + foo") == 'foofoo'
    assert safe_eval("foo * 4") == 'foofoofoofoo'
    assert safe_eval("hello.world") == 'hello.world'
    assert safe_eval("foo|bar") == 'foo|bar'

    # Python3 (and probably Python2) add a leading space to the repr
    # of a list, set or dict.  This test makes sure that we don't care
    # about the leading space or the trailing space.
    assert safe_eval("[1, 2, 3 ]") == [1, 2, 3]

# Generated at 2022-06-21 07:54:27.933799
# Unit test for function safe_eval
def test_safe_eval():
    # List of simple strings for testing
    test_strings = [
        "'abc'",
        '"def"',
        "'a', 'b', 'c'",
        "u'unicode'",
        "1",
        "1.1",
        "True",
        "False",
        "None",
        "[1, 2, 3]",
        "{'a': 1}",
        "{'a': 'b'}",
        "dict(a=1)",
        "dict(a='b')",
    ]

    # Run tests
    for expr in test_strings:
        result = safe_eval(expr)
        assert result == eval(expr)

    # List of test expressions (including invalid ones)

# Generated at 2022-06-21 07:54:41.201846
# Unit test for function safe_eval
def test_safe_eval():
    # Test whether expressions evaluate correctly
    # Test simple expressions
    assert safe_eval("{}") == {}
    assert safe_eval("[]") == []
    assert safe_eval("()") == ()
    assert safe_eval("set()") == set()
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("5") == 5
    assert safe_eval("-5") == -5
    assert safe_eval("5-10") == -5
    assert safe_eval("5+10") == 15
    assert safe_eval("5*10") == 50
    assert safe_eval("10/5") == 2
    assert safe_eval("-5/7") == -5.0/7
    assert safe_eval("5/10") == 0.5
    assert safe_eval

# Generated at 2022-06-21 07:54:53.691298
# Unit test for function safe_eval
def test_safe_eval():
    # Test literal
    assert safe_eval('{foo: "bar"}') == {'foo': 'bar'}
    assert safe_eval('"bar"') == 'bar'
    assert safe_eval('10') == 10
    assert safe_eval('10.0') == 10.0
    assert safe_eval('10.0') == 10.0
    assert safe_eval('True')
    assert safe_eval('False') is False
    assert safe_eval('null') is None

    # Test expressions
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]
    assert safe_eval('1 + 2') == 3
    assert safe_eval('3 * 4') == 12
    assert safe_eval('10 - 8') == 2
    assert safe_eval('10 / 5') == 2.

# Generated at 2022-06-21 07:55:04.749423
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:16.731695
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    class TestSafeEval(unittest.TestCase):
        '''
        Note: there are no tests for the following:
        - syntax errors beyond invalid strings, as we catch them and
        return the original text back to jinja
        - builtin functions (eg. 'range') as we explicitly disallow them
        for safety. Safe functions can be added to the call_whitelist.
        '''
        def setUp(self):
            # by default, we don't allow calls to anything
            global CALL_ENABLED
            CALL_ENABLED = []

        def test_allowed_toplevel(self):
            # top-level constructs (not as part of a call)
            # that we should allow
            self.assertEquals(safe_eval('1'), 1)

# Generated at 2022-06-21 07:55:25.708425
# Unit test for function safe_eval
def test_safe_eval():
    # default: return original expression string
    expr = u"foo * [1,2,3]"
    assert safe_eval(expr) == expr
    # accept builtin functions
    expr = u"sum([1,2,3]) + max([1,2,3])"
    assert safe_eval(expr) == 9
    # allow integer and string literals
    expr = u"1 + 2 * 3"
    assert safe_eval(expr) == 7
    expr = u"'foo' + 'bar'"
    assert safe_eval(expr) == u'foobar'
    # allow [], (), {}
    expr = u"[1,2,3] + (4,5,6) + {'foo':'bar'}"

# Generated at 2022-06-21 07:55:37.645174
# Unit test for function safe_eval
def test_safe_eval():

    # function call is not allowed
    assert safe_eval("max(1, 2, 3)") == "max(1, 2, 3)"
    assert safe_eval("max(1, 2, 3)", include_exceptions=True)[0] == "max(1, 2, 3)"

    # list is allowed
    assert safe_eval("['a', ['b'], [1, 2, 3]]") == ['a', ['b'], [1, 2, 3]]

    # dictionary is allowed
    assert safe_eval("{'a': 'b', 'c': {'d': 'e'}}") == {'a': 'b', 'c': {'d': 'e'}}

    # expression is allowed
    assert safe_eval("(1 + 2) / 3 * 2") == 2

    # name is allowed

# Generated at 2022-06-21 07:55:46.850767
# Unit test for function safe_eval
def test_safe_eval():
    # test that we don't allow unsafe constructs
    assert safe_eval('__import__("os").system("id")') == '__import__("os").system("id")'
    assert safe_eval('__import__("os").system("id")', include_exceptions=True) == ('__import__("os").system("id")', None)
    assert safe_eval('__import__("os").system("id")', include_exceptions=True)[1] is None

    # test that we don't allow unsafe constructs
    assert safe_eval('assert 1==1') == 'assert 1==1'
    assert safe_eval('assert 1==1', include_exceptions=True) == ('assert 1==1', None)
    assert safe_eval('assert 1==1', include_exceptions=True)[1] is None

    # test that we allow construct

# Generated at 2022-06-21 07:55:59.907938
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert safe_eval("'a'.upper()") == 'A'
    assert safe_eval("'$'") == '$'
    assert safe_eval("'\$'") == '\$'
    assert safe_eval("'%'") == '%'
    assert safe_eval("'%%'") == '%%'
    assert safe_eval("'\%'") == '\%'
    assert safe_eval("'%(a)'") == '%(a)'
    assert safe_eval("'%(a)%(b)%(c)'") == '%(a)%(b)%(c)'

# Generated at 2022-06-21 07:56:11.643011
# Unit test for function safe_eval
def test_safe_eval():

    def _eval_and_check(params_dict, result_value, exception=None):
        result_dict, err = safe_eval(params_dict, include_exceptions=True)
        # verify result_dict has the value
        assert result_dict == result_value
        # verify exception, if any, is the same as expected
        if exception:
            assert type(err) == type(exception)
            assert err.args == exception.args
        else:
            assert err is None

    assert safe_eval(123) == 123
    assert safe_eval('foo') == 'foo'
    assert safe_eval('"foo bar"') == 'foo bar'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-21 07:56:23.140592
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:42.960847
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2') == 2
    assert safe_eval('2.2') == 2.2
    assert safe_eval('-2') == -2
    assert safe_eval('-2.2') == -2.2
    assert safe_eval('2*2') == 4
    assert safe_eval('-2*2') == -4
    assert safe_eval('2*2*2') == 8
    assert safe_eval('-2*2*2') == -8
    assert safe_eval('2*-2*2') == -8
    assert safe_eval('-2*-2*2') == 8
    assert safe_eval('2*2*2*2') == 16
    assert safe_eval('2*2*2*2*2') == 32

# Generated at 2022-06-21 07:56:47.002079
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Basic testing function that attempts to eval strings known to generate security warnings
    and not string that should not generate warnings.  If we get to the last print and
    no exceptions were generated, we can assume the tests passed.

    Particularly we want to avoid expressions that would call into builtin functions
    like open() and __import__() since we do not want to be vulnerable to code execution
    attacks.
    '''

    # Test cases
    # For each list value turn on the security check specified by the list key
    # The first item in each test tuple is the expression to test, and the second
    # item is the expected result.


# Generated at 2022-06-21 07:56:53.442324
# Unit test for function safe_eval
def test_safe_eval():
    # Test a simple use case for safe_eval
    assert safe_eval('foo') == 'foo'

    # Test safe_eval detecting an unsafe call
    try:
        safe_eval('__import__("os").remove("/tmp/danger")')
    except Exception as e:
        pass
    else:
        assert False

    # Test safe_eval works with functions enabled
    CALL_ENABLED.append('len')
    assert safe_eval('len([1,2,3])') == 3



# Generated at 2022-06-21 07:57:05.077702
# Unit test for function safe_eval
def test_safe_eval():
    # Add support for boolean operators
    SAFE_NODES = (
        ast.And,
        ast.Or,
        ast.Not,
    )

    # modify the SAFE_NODES set
    SAFE_NODES = SAFE_NODES + CleansingNodeVisitor.SAFE_NODES
    CleansingNodeVisitor.SAFE_NODES = set(SAFE_NODES)

    expr = 'myvar'
    locals = dict(myvar='hello')
    assert safe_eval(expr, locals) == 'hello'

    expr = '10'
    locals = {}
    assert safe_eval(expr, locals) == 10

    expr = '10'
    assert safe_eval(expr) == 10

    expr = '10 + 20'
    assert safe_eval(expr)

# Generated at 2022-06-21 07:57:11.730087
# Unit test for function safe_eval
def test_safe_eval():
    # Disabled to address potential issues with secure defaults
    # in the future
    # https://github.com/ansible/ansible/issues/27618
    return

    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("-1.1") == -1.1
    assert safe_eval("True")
    assert safe_eval("False")
    assert safe_eval("None")
    assert safe_eval("true")
    assert safe_eval("false")
    assert safe_eval("null")

# Generated at 2022-06-21 07:57:23.501776
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:34.888494
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:46.883272
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"foo":"bar"}') == {'foo': 'bar'}
    assert safe_eval('[1,2,3,4]') == [1, 2, 3, 4]
    assert safe_eval('["foo","bar"]') == ['foo', 'bar']
    assert safe_eval('[1,2,3,[4,5,6]]') == [1, 2, 3, [4, 5, 6]]
    assert safe_eval('{"foo": "bar", "baz": "bam"}') == {'foo': 'bar', 'baz': 'bam'}
    assert safe_eval('["foo", "bar", "baz", "bam"]') == ['foo', 'bar', 'baz', 'bam']

    # verify we are allowing the use of true, false, and null in expressions


# Generated at 2022-06-21 07:57:55.927988
# Unit test for function safe_eval
def test_safe_eval():
    # skip test on Python3 because prevent_unsafe_lookups is True by default there
    if sys.version_info[0] >= 3:
        return

    # allow call:
    # - to builtin functions which accept no arguments and return
    #   a constant type
    # - to builtin functions which accept a single constant
    #   and return a constant type
    # - to builtin functions which accept a single constant
    #   and return a constant type
    CALL_ENABLED.extend((
        'None',
        'True',
        'False',
        'int',
        'bool',
        'float',
        'complex',
        'list',
        'dict',
        'tuple',
        'set',
    ))

    # Simple expression
    assert safe_eval(expr='a') is None

# Generated at 2022-06-21 07:58:07.636387
# Unit test for function safe_eval
def test_safe_eval():
    expr = "dict(changed=True,ansible_facts=dict(a='1'))"
    result = safe_eval(expr)
    assert result == {"changed": True, "ansible_facts": {"a": "1"}}, \
        "safe_eval should evaluate dictionary with string key value"

    expr = "dict(changed='{{ changed }}')"
    result = safe_eval(expr)
    assert result == {"changed": "{{ changed }}"}, \
        "safe_eval should handle expressions in key values"

    expr = "dict(ansible_facts=dict(a='1'))"
    result = safe_eval(expr)
    assert result == {"ansible_facts": {"a": "1"}}, \
        "safe_eval should handle nested dictionary"


# Generated at 2022-06-21 07:58:35.608005
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:45.263505
# Unit test for function safe_eval
def test_safe_eval():
    # simple test cases
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('false') is False
    assert safe_eval('true') is True
    assert safe_eval('null') is None

    # python 2.6 requires quotes around None, True and False,
    # this handles that as well
    assert safe_eval('"None"') is None
    assert safe_eval('"True"') is True
    assert safe_eval('"False"') is False

    # the following should all raise exceptions
    try:
        safe_eval('__import__("os").system("echo TEST")')
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-21 07:58:56.885169
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit testing for function safe_eval
    '''
    functions = [
        "abs",
        "ceil",
        "cumsum",
        "divmod",
        "filter",
        "float",
        "int",
        "isinstance",
        "len",
        "map",
        "max",
        "min",
        "pow",
        "round",
        "sorted",
        "sum",
        "zip",
    ]
    functions = dict.fromkeys(functions, True)

# Generated at 2022-06-21 07:59:07.740073
# Unit test for function safe_eval
def test_safe_eval():
    # Check basic evaluation, trivial
    assert safe_eval("1") == 1
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}

    # Check for syntax error, expr should be returned as-is
    assert safe_eval("a[0]") == "a[0]"

    # Make sure certain things are prohibited
    try:
        safe_eval("__import__('os').system('rm /')")
        # if we got here, we are sad
        assert False
    except Exception:
        pass

    # Allowed operations, these should not raise any errors
    def test_it(a):
        safe_eval(a)

    test_it("1+1")
    test_it("10/5")
    test_it("False")

# Generated at 2022-06-21 07:59:16.447358
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:27.709482
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('True') is True
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('foo') == 'foo'

    # this is accepted by python but not safe_eval. we will only give the real
    # traceback if ANSIBLE_DEBUG is set
    if C.DEFAULT_DEBUG:
        assert safe_eval('__import__("os").system("echo foo")') == '__import__("os").system("echo foo")'
    else:
        assert safe_eval('__import__("os").system("echo foo")') == '__import__("os").system("echo foo")'

    assert safe

# Generated at 2022-06-21 07:59:36.618075
# Unit test for function safe_eval
def test_safe_eval():
    # Ensure list elements, dict keys, and dict values all support safe_eval()
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('["foo" in bar, "baz" not in bar]', dict(bar=["baz", "foo"])) == [True, False]
    assert safe_eval('{"foo": "bar", "baz": "bim"}') == {"foo": "bar", "baz": "bim"}

    # Disallow any callables in safe_eval
    assert safe_eval('["foo", "bar"].pop()') == '["foo", "bar"].pop()'
    assert safe_eval('["foo", "bar"].pop', dict(bar=["baz", "foo"])) == '["foo", "bar"].pop'
    #

# Generated at 2022-06-21 07:59:49.193066
# Unit test for function safe_eval
def test_safe_eval():
    the_list = ['item1', 'item2', 'item3']
    the_dict = dict(key1='value1', key2='value2', key3='value3')

    # this is a safe eval
    result = safe_eval('["a", "b", "c"]')
    assert result == ['a', 'b', 'c']

    result2 = safe_eval('{a: "b", c: "d"}')
    assert result2 == {'a': 'b', 'c': 'd'}

    result3 = safe_eval('a_list[1:]')
    assert result3 == ['item2', 'item3']

    result4 = safe_eval('a_dict.get("key2")')
    assert result4 == 'value2'


# Generated at 2022-06-21 07:59:58.300324
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:10.311678
# Unit test for function safe_eval
def test_safe_eval():
    # call a python builtin
    assert safe_eval("len([1,2,3])") == 3

    # simple math expression
    assert safe_eval("2+2") == 4

    # simple comparison
    assert safe_eval("2+2 == 4") == True

    # and, or, not expressions
    assert safe_eval("(2+2 == 4 or 2*2 == 3) and not 2*2 == 3") == True

    # list
    assert safe_eval("[1,2,3]") == [1, 2, 3]

    # dict
    assert safe_eval("{1:2,3:4}") == {1: 2, 3: 4}

    # dict with list
    assert safe_eval("{1:2,3:[4,5]}") == {1: 2, 3: [4, 5]}

# Generated at 2022-06-21 08:00:50.600335
# Unit test for function safe_eval
def test_safe_eval():

    # A simple evaluation
    assert safe_eval("1 + 2") == 3
    # This one fails, because it's not a valid python expression
    assert safe_eval("1 + ") == "1 + "
    # This one fails with a proper exception
    assert safe_eval("1 + * 2") == "1 + * 2"
    # This one fails, because of an invalid syntax
    assert safe_eval("1 + (2") == "1 + (2"
    # This one fails, because we're not allowing calls
    assert safe_eval("__import__('os').system('echo oh no')") == "__import__('os').system('echo oh no')"

    # Enable some builtins
    C.CALL_ENABLED.append('str')
    C.CALL_ENABLED.append('int')
    assert safe_