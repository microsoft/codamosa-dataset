

# Generated at 2022-06-21 07:51:04.002778
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:15.588590
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:27.241349
# Unit test for function safe_eval
def test_safe_eval():
    # simple cases
    assert safe_eval("True") == True
    assert safe_eval("1+1") == 2
    assert safe_eval("'abc'") == 'abc'

    # some valid python expressions but invalid ansible expressions
    assert safe_eval("def foo(): return 1") == "def foo(): return 1"

    # input is an ansible expression, but eval will throw an exception
    assert safe_eval("[1,2]()") == "[1,2]()"

    # input is a json expression
    assert safe_eval("{'key': 'value'}") == {'key': 'value'}
    assert safe_eval("{'key': 'value', 'value': {}, 'k': 'v'}") == {'key': 'value', 'value': {}, 'k': 'v'}

    # lists


# Generated at 2022-06-21 07:51:39.814694
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    import os
    import tempfile

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from test.lib import remove_tmp_path
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    tmpdir = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP)
    tmpdir = to_native(tmpdir, errors='surrogate_or_strict')


# Generated at 2022-06-21 07:51:50.413441
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure our safelist of AST nodes is complete
    safelist = set(
        (
            ast.Add,
            ast.BinOp,
            ast.Call,
            ast.Compare,
            ast.Constant,
            ast.Dict,
            ast.Div,
            ast.Expression,
            ast.List,
            ast.Load,
            ast.Mult,
            ast.Num,
            ast.Name,
            ast.Set,
            ast.Str,
            ast.Sub,
            ast.USub,
            ast.Tuple,
            ast.UnaryOp,
        )
    )
    tree = ast.parse('1+1', mode='eval')
    for node in ast.walk(tree):
        assert type(node) in safelist

    # Test actual functionality of safe_eval


# Generated at 2022-06-21 07:52:01.484568
# Unit test for function safe_eval
def test_safe_eval():
    # from ansible.playbook import PlaybookInclude
    expected_result = [1, 2, 3]

    # This should work
    result = safe_eval("[1,2,3]")
    assert result == expected_result

    # These should cause an exception
    if C.DEFAULT_UNSAFE_EVAL:
        print("WARNING: DEFAULT_UNSAFE_EVAL is set to True. This test will fail.")
    else:
        exception_raised = False
        try:
            result = safe_eval("__import__('os').system('ls')")
        except:
            exception_raised = True
        assert exception_raised

        exception_raised = False
        try:
            result = safe_eval("__builtins__.open('/tmp/foo', 'w')")
        except:
            exception_raised

# Generated at 2022-06-21 07:52:14.050636
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # Test ast.Constant, ast.Num

# Generated at 2022-06-21 07:52:22.551347
# Unit test for function safe_eval
def test_safe_eval():

    # disable printing exceptions for test
    C.DEFAULT_DEBUG = False

    # basic datastructures
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval("{'a': 1}", include_exceptions=True) == ({'a': 1}, None)

    # dicts, lists, sets, tuples
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval("(1,2,3)") == (1,2,3)
    assert safe_eval("{1,2,3}") == {1,2,3}

# Generated at 2022-06-21 07:52:33.616631
# Unit test for function safe_eval
def test_safe_eval():
    # Try a simple expression
    assert safe_eval('2 + 3') == 5

    # Try a comparison
    assert safe_eval('2 > 1') == True

    # Try a builtin function
    assert safe_eval('len("abc")') == 3

    # Try a list
    assert safe_eval('[1, 2.0, 3, "foo", "bar", len("abc")]') == [1, 2.0, 3, "foo", "bar", 3]

    # Try a dictionary
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

    # Try a complex expression
    assert safe_eval('"foo" in ["foo", "bar"]') == True

    # Try a simple syntax error

# Generated at 2022-06-21 07:52:40.733072
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:56.514499
# Unit test for function safe_eval
def test_safe_eval():
    print('===TESTING SAFE EVAL===')

    # A list of tuples of form (test_input, test_output)
    # This is a partial list, based on tests that passed or failed,
    # please add more tests!

# Generated at 2022-06-21 07:53:03.672324
# Unit test for function safe_eval
def test_safe_eval():
    # Basic test. Safe to eval
    expr = 'false'
    result, ex = safe_eval(expr, include_exceptions=True)
    assert ex is None
    assert result is False

    # Some basic math.
    expr = '1 + 2 * 5'
    result, ex = safe_eval(expr, include_exceptions=True)
    assert ex is None
    assert result == 11

    # Lists / dicts / sets
    expr = '["a", "b", "c"]'
    result, ex = safe_eval(expr, include_exceptions=True)
    assert ex is None
    assert result == ['a', 'b', 'c']

    expr = '{"a": 1, "b": 2, "c": 3}'
    result, ex = safe_eval(expr, include_exceptions=True)


# Generated at 2022-06-21 07:53:16.228658
# Unit test for function safe_eval
def test_safe_eval():
    def test_case(expression, result):
        # sample_dict  = {'a': 1}
        # sample_list  = [1]
        # sample_tuple = (1, )
        # sample_str   = 'string'
        # sample_bool  = True
        # sample_int   = 1
        locals_ = {
            'sample_dict': {'a': 1},
            'sample_list': [1],
            'sample_tuple': (1, ),
            'sample_str': 'string',
            'sample_bool': True,
            'sample_int': 1
        }
        return safe_eval(expression, locals_) == result

    # empty string
    assert test_case('', None)
    # invalid string
    assert test_case('a', 'a')
    # valid string


# Generated at 2022-06-21 07:53:26.166678
# Unit test for function safe_eval
def test_safe_eval():
    # literal values
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('42') == 42
    assert safe_eval('42.7') == 42.7
    assert safe_eval('4.2e7') == 4.2e7
    assert safe_eval('"string"') == "string"

    assert ast.literal_eval(safe_eval('["an", "array"]')) == ["an", "array"]
    assert ast.literal_eval(safe_eval('{"a": "dict"}')) == {"a": "dict"}

    # basic math
    assert safe_eval('3 + 5') == 8
    assert safe_eval('3 - 5') == -2

# Generated at 2022-06-21 07:53:38.700620
# Unit test for function safe_eval
def test_safe_eval():

    # simply test that if we pass something other than a string,
    # we return the input
    def test_non_string_inputs(input):
        if isinstance(input, string_types):
            return
        assert safe_eval(input) is input

    float_values = [
        1.0,  # basic float
        12e34, # float with exponent
        float('1.5'), # float cast from string
        float(14), # basic float with int constructor
        float('15e-1'), # float constructor with exponent
    ]


# Generated at 2022-06-21 07:53:48.564002
# Unit test for function safe_eval
def test_safe_eval():
    def _test_assert(expr, expected_value, expected_exception=None, **kwargs):
        if not isinstance(expected_value, Exception):
            # only apply kwargs if expected result is not an exception
            # otherwise variables are ignored
            evaluated, exception = safe_eval(expr, include_exceptions=True, **kwargs)
        else:
            evaluated, exception = safe_eval(expr, include_exceptions=True)

        if isinstance(expected_exception, Exception):
            assert exception is not None
            assert isinstance(exception, expected_exception.__class__)
            assert str(exception) == str(expected_exception)
        else:
            assert exception is None

        assert evaluated == expected_value

        return True

    # Test raising an exception

# Generated at 2022-06-21 07:53:59.202043
# Unit test for function safe_eval
def test_safe_eval():
    # We are not testing all possible Python combinations, but testing
    # basic comparisons and simple arithmetic versus the Jinja2
    # results. Any change in Jinja2 evaluation will be caught by
    # integration testing.
    assert safe_eval("3 + 2 == 5")
    assert safe_eval("3 * 2 == 6")
    assert safe_eval("var1 == 'teststring'")
    assert safe_eval("var2 == 'teststring2'")
    assert not safe_eval("3 + 2 == 4")
    assert not safe_eval("3 * 2 == 5")
    assert safe_eval("var3 == [ 'item1', 'item2' ]")
    assert safe_eval("var4 == { 'key1': 'value1', 'key2': 'value2' }")

# Generated at 2022-06-21 07:54:10.104400
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{foo}}", locals={'foo': 42}) == 42
    assert safe_eval("{{foo}}", locals={'foo': 'bar'}) == "bar"
    assert safe_eval("{{foo}}", locals={'foo': ['a', 42, 'c']}) == ['a', 42, 'c']
    assert safe_eval("{{foo}}", locals={'foo': ('a', 42, 'c')}) == ('a', 42, 'c')
    assert safe_eval("{{foo}}", locals={'foo': ('a', 42, 'c')}) == ('a', 42, 'c')
    assert safe_eval("{{foo}}", locals={'foo': {'a': 42, 'b': 'c'}}) == {'a': 42, 'b': 'c'}

# Generated at 2022-06-21 07:54:17.808201
# Unit test for function safe_eval
def test_safe_eval():
    # valid expressions
    assert isinstance(safe_eval("{'a': 1}"), dict)
    assert isinstance(safe_eval("[1,2,3]"), list)
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("a", dict(a=1)) == 1
    assert safe_eval("a", dict(a=[1, 2])) == [1, 2]
    assert safe_eval("a", dict(a={'a': 1})) == {'a': 1}
    assert safe_eval("a", dict(a=True)) is True

# Generated at 2022-06-21 07:54:28.398798
# Unit test for function safe_eval
def test_safe_eval():
    # Expected to pass
    safe_eval('a')
    safe_eval('a + b')
    safe_eval('a and b or c')
    safe_eval('a and b or c and d or e')
    safe_eval('a + b and c + d or e + f')
    safe_eval('a + b.foo')
    safe_eval('a + b[foo]')
    safe_eval('a + b(foo)')
    safe_eval('a + b(foo=bar)')
    safe_eval('a + b(**c)')
    safe_eval('a + b(kwarg=c)')
    safe_eval('a + b(kwarg=c, bar=foo)')
    safe_eval('a + b(kwarg=c, *d)')

# Generated at 2022-06-21 07:54:44.340071
# Unit test for function safe_eval
def test_safe_eval():
    # This should raise an exception
    try:
        safe_eval('foo')
    except:
        pass
    else:
        print("safe_eval failed (1)")
        sys.exit(1)

    # This should raise an exception
    try:
        safe_eval('import os')
    except:
        pass
    else:
        print("safe_eval failed (2)")
        sys.exit(1)

    # This should raise an exception
    try:
        safe_eval('{1,2,3')
    except:
        pass
    else:
        print("safe_eval failed (3)")
        sys.exit(1)

    # This should raise an exception
    try:
        safe_eval('foo()')
    except:
        pass

# Generated at 2022-06-21 07:54:56.425066
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit tests for the safe_eval function.
    '''
    from ansible.module_utils._text import to_text

    def assert_raises(expr, msg):
        '''
        Asserts that the string in expr raises the exception with the given
        message.
        '''
        try:
            safe_eval(expr)
            assert False, "Failed to raise exception"
        except Exception as e:
            assert to_text(e) == msg

    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2]') == [1, 2]

# Generated at 2022-06-21 07:55:09.521008
# Unit test for function safe_eval
def test_safe_eval():
    # First, basic usage cases
    assert safe_eval('a * 10') == 'a * 10'
    int_exprs = ['10', '10 + 2', '(10 + 2) * 2', '10|2', '10 ^ 2']
    for expr in int_exprs:
        assert safe_eval(expr) == eval(expr)
    str_exprs = ['10 * "a"', '"abc" + "def"']
    for expr in str_exprs:
        assert safe_eval(expr) == eval(expr)
    dict_exprs = ['{"a": 1, "b": 2}', "[1, 2, 3]"]
    for expr in dict_exprs:
        assert safe_eval(expr) == eval(expr)
    assert safe_eval('false') == False
    assert safe_eval('True')

# Generated at 2022-06-21 07:55:20.695354
# Unit test for function safe_eval
def test_safe_eval():
    # these simple expressions should work
    assert safe_eval('1 + 2') == 3
    assert safe_eval('foo', {'foo': 42}) == 42
    assert safe_eval('foo["bar"]', {'foo': {'bar': 'baz'}}) == 'baz'
    assert safe_eval('foo.bar', {'foo': {'bar': 'baz'}}) == 'baz'
    assert safe_eval('foo(bar)', {'foo': lambda x: x, 'bar': 'baz'}) == 'baz'
    assert safe_eval('foo[0]', {'foo': ['bar']}) == 'bar'

    # these fail, we want to make sure the evaluator is trying to
    # prevent this from running
    eval_error = None

# Generated at 2022-06-21 07:55:27.337966
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:39.383883
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('0') == 0
    assert safe_eval('1+1') == 2
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo[bar]') == 'foo[bar]'
    assert safe_eval('foo(bar)') == 'foo(bar)'

    # make sure the following are not valid
    try:
        safe_eval('["foo", "bar"][1]')
        raise Exception("evaluated a list as an expression")
    except:
        pass

    try:
        safe_eval('__builtins__')
        raise Exception("evaluated __builtins__")
    except:
        pass


# Generated at 2022-06-21 07:55:47.765801
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:00.509259
# Unit test for function safe_eval
def test_safe_eval():
    base = "safe_eval('abc' + 'def')"
    result = safe_eval(base)
    assert result == 'abcdef'

    base = "safe_eval('abc' + 'def', include_exceptions=True)"
    result = safe_eval(base)
    assert result == ('abcdef', None)

    base = "safe_eval('2+2')"
    result = safe_eval(base)
    assert result == 4

    base = "safe_eval('foo.bar()', include_exceptions=True)"
    result = safe_eval(base)
    assert result == ('foo.bar()', None)

    base = "safe_eval('2**4')"
    result = safe_eval(base)
    assert result == 16


# Generated at 2022-06-21 07:56:12.523638
# Unit test for function safe_eval
def test_safe_eval():
    import collections

    # safe_eval('1 + 1')
    assert safe_eval('1 + 1') is 2

    # safe_eval('1 + 1', include_exceptions=True)
    expr, exc = safe_eval('1 + 1', include_exceptions=True)
    assert expr is 2
    assert exc is None

    # safe_eval('1 + 1', {}, include_exceptions=True)
    expr, exc = safe_eval('1 + 1', {}, include_exceptions=True)
    assert expr is 2
    assert exc is None

    # safe_eval('1 + 1', {'foo': 123}, include_exceptions=True)
    expr, exc = safe_eval('1 + 1', {'foo': 123}, include_exceptions=True)
    assert expr is 2
    assert exc is None

    #

# Generated at 2022-06-21 07:56:23.903296
# Unit test for function safe_eval
def test_safe_eval():
    # valid expressions
    assert safe_eval("1 + 1") == 2
    assert safe_eval("2 * 3") == 6
    assert safe_eval("foo.bar.baz()") == 'baz'
    assert safe_eval("{1: 'a', 3: 'c' }") == {1: 'a', 3: 'c'}
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("(1, 3)") == (1, 3)
    assert safe_eval("var_test_a + var_test_b") == 4

    # invalid expressions
    assert safe_eval("{'foo': 'bar'}['foo']") == "{'foo': 'bar'}['foo']"

# Generated at 2022-06-21 07:56:53.709905
# Unit test for function safe_eval
def test_safe_eval():
    import ansible.module_utils.common.text.converters as converters

    # boolean-style comparisons
    expr = "not true"
    assert safe_eval(expr) is False, "Failed to evaluate expression: %s" % expr
    expr = "false == false"
    assert safe_eval(expr) is True, "Failed to evaluate expression: %s" % expr

    # integer operations
    expr = "10 - 10"
    assert safe_eval(expr) == 0, "Failed to evaluate expression: %s" % expr
    expr = "10 + 10"
    assert safe_eval(expr) == 20, "Failed to evaluate expression: %s" % expr
    expr = "10 * 2"
    assert safe_eval(expr) == 20, "Failed to evaluate expression: %s" % expr

# Generated at 2022-06-21 07:57:05.618299
# Unit test for function safe_eval
def test_safe_eval():
    assertion_type_error = "AssertionError: '%s' should be %s"
    assertion_equal = "AssertionError: '%s' != '%s'"
    # A test to pass
    expr1 = '{"name": "example", "value": [1,2,3,4]}'
    safe_result1, safe_exception1 = safe_eval(expr1, include_exceptions=True)
    assert isinstance(safe_result1, dict), assertion_type_error % (expr1, 'dict')
    assert safe_result1.get('name') == 'example', assertion_equal % ('name', 'example')
    assert safe_result1.get('value') == [1, 2, 3, 4], assertion_equal % ('value', '[1, 2, 3, 4]')
    assert not safe_

# Generated at 2022-06-21 07:57:14.386459
# Unit test for function safe_eval
def test_safe_eval():

    # all of the below should return None, as the string
    # is not a valid expression
    for expr in [
        # python operators
        ">>>",  # bitwise shift right
        "<<<",
        "+="   # assignment operator
    ]:
        assert safe_eval(expr) is None

    # make sure we pass the correct type back
    assert safe_eval('[{"a": 1}, {"b": 2}]') == [{"a": 1}, {"b": 2}]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

# Generated at 2022-06-21 07:57:26.986815
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:37.175456
# Unit test for function safe_eval
def test_safe_eval():
    class Person():
        age = 6
        height = 12
        name = 'Joe'
        married = True
        cars = ['BMW', 'Volvo']
        employee_hierarchy = {'boss': 'Jane', 'assistant': 'Mary'}

        def get_status(self):
            return "All systems go"

    p = Person()
    locals = dict(p=p)


# Generated at 2022-06-21 07:57:49.994764
# Unit test for function safe_eval

# Generated at 2022-06-21 07:58:02.554664
# Unit test for function safe_eval
def test_safe_eval():
    def test_eval(expr, expected, msg=None, locals=None, include_exceptions=False):
        actual = safe_eval(expr, locals=locals, include_exceptions=include_exceptions)
        if include_exceptions:
            actual_expr, actual_exception = actual
            if expected is not None and expected != actual_expr:
                print("%s: Got %s, expected %s (exception was %s)" % (msg, actual_expr, expected, actual_exception))
        else:
            if expected is not None and expected != actual:
                print("%s: Got %s, expected %s" % (msg, actual, expected))

    if len(sys.argv) > 1:
        c = sys.argv[1]

# Generated at 2022-06-21 07:58:14.346022
# Unit test for function safe_eval
def test_safe_eval():
    # sanities
    assert safe_eval("1 + 1") == 2
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("dict(a=1, b=2)") == dict(a=1, b=2)
    assert safe_eval("'hello'") == 'hello'
    assert safe_eval("true") is True
    assert safe_eval("false") is False
    assert safe_eval("null") is None

    # FIXME: partially broken until we correctly populate __builtins__
    # assert safe_eval("len()") == 0
    assert safe_eval("len([1,2])") == 2

    # broken
    assert safe_eval("[1,2,3]") == [1, 2, 3]

# Generated at 2022-06-21 07:58:22.594167
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Unit testing for function safe_eval
    '''
    # No exception raised if call is successful
    expr = '{"a": 1, "b": 2, "c": 3}'
    safe_eval(expr)
    expr = '{"a": [1, 2], "b": 2, "c": 3}'
    safe_eval(expr)

    # Exception raised for invalid expression
    expr = '{a: 1, "b": 2, "c": 3}'
    try:
        safe_eval(expr)
        assert False
    except Exception as e:
        pass

    # Exception raised for invalid function calls
    expr = 'open("/etc/passwd")'
    try:
        safe_eval(expr)
        assert False
    except Exception as e:
        pass

    # Exception raised for invalid built

# Generated at 2022-06-21 07:58:33.996202
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'string_value'") == 'string_value'
    assert safe_eval("5") == 5
    assert safe_eval("'5'") == '5'
    assert safe_eval("5.5") == 5.5
    # assert safe_eval("5.5+5") == 10.5
    # assert safe_eval("5.5-5") == 0.5
    # assert safe_eval("5.5*5") == 27.5
    # assert safe_eval("5.5/5") == 1.1
    assert safe_eval("'5'+'5'") == '55'
    assert safe_eval("'5'-'5'") == '5-5'
    assert safe_eval("'foo' in ['bar', 'baz', 'foo']") is True
    assert safe_

# Generated at 2022-06-21 07:59:13.922905
# Unit test for function safe_eval
def test_safe_eval():
    def _test_eval(expr, success, expected, verify_exception=False, locals=None):
        success = bool(success)
        try:
            evaluated = safe_eval(expr, locals=locals)
        except Exception as e:
            if success:
                raise
            if not verify_exception:
                return
            if expected != e.__class__.__name__:
                raise Exception("safe_eval() failed with unexpected exception (%s)" % e)
            return
        if not success:
            raise Exception("safe_eval() succeeded unexpectedly")
        if expected is None:
            return
        if evaluated != expected:
            raise Exception("safe_eval() failed, expected %s but got %s" % (expected, evaluated))

    _test_eval('1 + 1', True, 2)

# Generated at 2022-06-21 07:59:24.942862
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:34.948985
# Unit test for function safe_eval
def test_safe_eval():
   code = """
{% set myvar = ({
     'my_dict': {
       'key1': 'value1',
       'key2': 'value2',
       'key3': 'value3',
     },
   }) %}

{{ myvar|from_json|map(attribute='my_dict')|list }}
"""

   locals = {
       'from_json': ast.literal_eval,
       'map': map,
       'attribute': ast.Attribute,
       'list': list,
   }

   (result, retval) = safe_eval(code, locals, True)
   print(result, retval)


# Generated at 2022-06-21 07:59:46.766175
# Unit test for function safe_eval
def test_safe_eval():
    expr = "sample_list.0.key1"
    expr2 = "sample_str.upper()" # invalid syntax, not safe
    expr3 = "dict(a=1, b=2)"     # invalid syntax, not safe
    expr4 = "sample_dict['a']"
    expr5 = "sample_dict['b']"
    expr6 = "sample_list"

    assert(safe_eval(expr) == 'val1')
    assert(safe_eval(expr2) == expr2) # unchanged as invalid syntax
    assert(safe_eval(expr3) == expr3) # unchanged as invalid syntax
    assert(safe_eval(expr4) == 1)
    assert(safe_eval(expr5) == 2)
    assert(safe_eval(expr6) == '[1, 2, 3]')

    complex_expr

# Generated at 2022-06-21 07:59:57.028846
# Unit test for function safe_eval
def test_safe_eval():
    # The next line SHOULD FAIL, since we are trying to invoke an unsafe
    # builtin (open) from within safe_eval, but the failure is expected,
    # so we don't want to fail the unit test here.
    #safe_eval("open('/etc/passwd', 'r')")
    assert safe_eval("a_list_variable", dict(a_list_variable=[1,2])) == [1,2]
    try:
        assert safe_eval("a_list_variable", dict(a_list_variable=[1,2]), True) == [1,2]
    except TypeError:
        # assert tries to do == comparison or raise AssertionError
        # but Python3 raises TypeError on comparing a tuple to a list
        pass
    assert safe_eval(None) is None

# Generated at 2022-06-21 08:00:09.233782
# Unit test for function safe_eval
def test_safe_eval():
    failed = False
    test_results = {
        "expr": "expr",
        "eval_result": "eval_result",
        "success": "success"
    }

# Generated at 2022-06-21 08:00:21.409788
# Unit test for function safe_eval
def test_safe_eval():
    f = lambda: None
    builtins.foo = f
    assert eval('foo') == f
    assert safe_eval('foo') == 'foo'
    assert eval('1') == safe_eval('1')
    assert eval('"hello"') == safe_eval('"hello"')
    assert eval('[1,2,3]') == safe_eval('[1,2,3]')
    assert eval({'a':'b'}) == safe_eval({'a':'b'})
    assert eval('True') == safe_eval('True')
    assert eval('False') == safe_eval('False')
    assert eval('None') == safe_eval('None')
    assert eval('{"a": "b"}') == safe_eval('{"a": "b"}')
    # Note: calling ast_parse with mode='eval' causes

# Generated at 2022-06-21 08:00:29.921235
# Unit test for function safe_eval
def test_safe_eval():
    import unittest

    class TestSafeEval(unittest.TestCase):
        """ Test cases for safe_eval function
        """

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_safe_eval_01(self):
            """ Test safe_eval
                1- Test the evaluation of the default variable
            """
            variable = dict()

            variable['item'] = '1234'
            variable['item1'] = {'a': '2', 'b': '3'}
            result = safe_eval('item', variable)
            self.assertEqual(result, '1234')

        def test_safe_eval_02(self):
            """ Test safe_eval
                2- Test the evaluation of a string concatenation
            """
            variable = dict()

            variable

# Generated at 2022-06-21 08:00:41.614664
# Unit test for function safe_eval
def test_safe_eval():
    instance = safe_eval
    # Simple tests
    assert instance('[1, 2, 3]') == [1, 2, 3]
    assert instance('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert instance('foobar') == 'foobar'
    assert instance('1 + 2') == 3
    assert instance('1 + 2 * 3') == 7
    assert instance('(1 + 2) * 3') == 9
    # Dunder (magic) method tests
    assert instance('__import__') == __import__
    assert instance('__import__("os").path.exists') == __import__('os').path.exists
    # Test for calls
    assert instance('__import__("os").path.exists("/tmp")')
    # Test for calls with invalid arguments

# Generated at 2022-06-21 08:00:48.819535
# Unit test for function safe_eval