

# Generated at 2022-06-21 07:51:08.522982
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:17.929423
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:28.404817
# Unit test for function safe_eval
def test_safe_eval():
    # These expressions should pass safe_eval
    safe_tests = [
        # Simple expressions
        "a",
        "a + b",
        "a - b",
        "a * b",
        "a / b",
        "a[1]",
        "{'a': 1, 'b': 2}",
        "[1, 2, 3]",
        "(1, 2, 3)",
        # Tests for validity
        "True",
        "True and False",
        # Tests for invalidity
        "@with_items",
        "1 +",
        "foo()",
    ]

    print("Running tests for safe_eval()")

# Generated at 2022-06-21 07:51:40.464315
# Unit test for function safe_eval
def test_safe_eval():
    # simple examples
    assert safe_eval("3") == 3
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("dict(a=1,b=2)") == {u'a': 1, u'b': 2}
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("set([1,2,3])") == set([1, 2, 3])
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {u'a': 1, u'b': 2}
    # Test that this evaluates to the original string.
    # This protects against code execution.
    assert safe

# Generated at 2022-06-21 07:51:48.325750
# Unit test for function safe_eval
def test_safe_eval():
    # possible future tests:
    # 1. tests for json booleans (true, false)
    # 2. tests for json null
    # 3. tests for json numerical types
    # 4. tests for json dictionaries
    # 5. tests for json arrays
    # 6. tests for strings that are not valid json yet would be valid python

    module = sys.modules[__name__]


# Generated at 2022-06-21 07:51:59.547492
# Unit test for function safe_eval
def test_safe_eval():
    test_type = type(container_to_text('test'))
    test_eval = lambda x, y=None: safe_eval(x, locals=y, include_exceptions=True)
    print('Testing safe_eval')
    # ensure safe_eval treats a non string input as a JSON type
    assert test_eval(3) == (3, None)
    assert type(test_eval(3)) == tuple
    assert type(test_eval(3)[0]) == int
    assert test_eval(3)[1] is None
    assert test_eval(True) == (True, None)
    assert type(test_eval(True)) == tuple
    assert type(test_eval(True)[0]) == bool
    assert test_eval(True)[1] is None
    assert test_eval(None) == (None, None)


# Generated at 2022-06-21 07:52:12.515705
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a') == 'a'
    assert safe_eval('a+b') == 'a+b'
    assert safe_eval('a+1') == 'a+1'
    assert safe_eval('a+True') == 'a+True'
    assert safe_eval('a==1') == 'a==1'
    assert safe_eval('1') == 1
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval('[1, "a"]') == [1, 'a']
    assert safe_eval('foo.bar(1, 2)') == 'foo.bar(1, 2)'
    assert safe_eval('foo.bar') == 'foo.bar'

# Generated at 2022-06-21 07:52:21.631388
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 * 3') == 6
    assert safe_eval('6 / 3') == 2
    assert safe_eval('6 / 4') == 1
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('"hello " + "world"') == "hello world"
    assert safe_eval('"hello " * 3') == "hello hello hello "
    assert safe_eval('["foo", "bar"] + ["baz"]') == ["foo", "bar", "baz"]
    assert safe_eval('["foo"] * 2') == ["foo", "foo"]
    assert safe_eval('["foo", "bar"] * 2') == ["foo", "bar", "foo", "bar"]

# Generated at 2022-06-21 07:52:32.762117
# Unit test for function safe_eval
def test_safe_eval():
    stdout = sys.stdout
    sys.stdout = None


# Generated at 2022-06-21 07:52:40.829710
# Unit test for function safe_eval
def test_safe_eval():
    def _test(args, expected_result, expected_exception=None):
        locals = {}
        try:
            result = safe_eval(args, locals=locals) if not expected_exception else None
            exception = None
        except Exception as e:
            result = None
            exception = e
        if exception:
            exception = str(exception)
        if exception == expected_exception:
            if not exception:
                assert result == expected_result
        else:
            raise Exception("test %s expected result %s, got %s" % (args, expected_result, result))

    _test("[x for x in range(10) if x % 2]", [1, 3, 5, 7, 9])

# Generated at 2022-06-21 07:52:56.989446
# Unit test for function safe_eval
def test_safe_eval():
    module_name = sys._getframe().f_code.co_name

    # test safe_eval()
    assert safe_eval("1+1") == 2
    assert safe_eval("1+1", {}) == 2
    assert safe_eval("1+1", {}, include_exceptions=True) == (2, None)
    assert safe_eval("1+1", include_exceptions=True) == (2, None)
    assert safe_eval("True") is True
    assert safe_eval("True", include_exceptions=True) == (True, None)
    assert safe_eval("False or True") is True
    assert safe_eval("False or True", include_exceptions=True) == (True, None)
    assert safe_eval("false") is False

# Generated at 2022-06-21 07:53:07.496717
# Unit test for function safe_eval
def test_safe_eval():
    expr = '5 if true else 3'
    result = safe_eval(expr)
    assert result == 5

    expr = '5 + 3'
    result = safe_eval(expr)
    assert result == 8

    # evaluation should not work because we
    # are using an undefined variable
    expr = '1+foo'

    try:
        safe_eval(expr)
        assert False
    except:
        assert True

    expr = 'foo is undefined'
    result = safe_eval(expr)
    assert result == 'foo is undefined'

    expr = 'foo is undefined'
    result, e = safe_eval(expr, include_exceptions=True)
    assert result == 'foo is undefined'

    # test for a specific bad value
    expr = 'foo|bar'

# Generated at 2022-06-21 07:53:19.915167
# Unit test for function safe_eval
def test_safe_eval():

    # Testing basic stuff that should work
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1+1') == 2
    assert safe_eval('2*3+4') == 10
    assert safe_eval('1*-1') == -1
    assert safe_eval('True or False') is True
    assert safe_eval('True and False') is False
    assert safe_eval('[]') == []
    assert safe_eval('()') == ()
    assert safe_eval('{}') == {}
    assert safe_eval('[1,2,3]') == [1,2,3]

# Generated at 2022-06-21 07:53:27.813444
# Unit test for function safe_eval
def test_safe_eval():
    # these should raise exceptions:
    broken_exprs = [
        '__import__("os").system("echo hi")',
        '__builtins__.__import__("os").system("echo hi")',
        '__import__("os").some_func()',
        'some_func()',
        'some_func',
        'open("/etc/passwd")',
    ]
    for expr in broken_exprs:
        f = lambda: safe_eval(expr)
        if sys.version_info < (2, 7, 0):
            if f() != expr:
                print("safe_eval failed to return input string when called with expr '%s'" % expr)

# Generated at 2022-06-21 07:53:40.022386
# Unit test for function safe_eval
def test_safe_eval():
    # Test a valid expression with no variables
    expression = "2+2"
    expected_result = 4
    assert safe_eval(expression) == expected_result, \
        "Expected result of {0}, got {1}".format(expected_result, safe_eval(expression))

    # Test a valid expression with a variable
    expression = "2+x"
    expected_result = 4
    assert safe_eval(expression, locals=dict(x=2)) == expected_result, \
        "Expected result of {0}, got {1}".format(expected_result, safe_eval(expression))

    # Test an expression with a call to a builtin function which we have explicitly allowed
    expression = "round(3.3)"
    expected_result = 3
    assert safe_eval(expression, CALL_ENABLED=['round'])

# Generated at 2022-06-21 07:53:49.441982
# Unit test for function safe_eval
def test_safe_eval():

    # Tests for safe_eval
    assert safe_eval("1 + 2 == 3") is True
    assert safe_eval("1 + 3 == 3") is False
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo['bar']") == "foo['bar']"
    assert safe_eval("foo in bar") == "foo in bar"
    assert safe_eval("foo {0} bar".format("==")) == "foo == bar"
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("None") is None
    assert safe_eval("true") is True
    assert safe_

# Generated at 2022-06-21 07:54:00.033083
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:10.712096
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1, simple success case
    assert safe_eval("1 + 2") == 3

    # Test 2, a big failure
    try:
        safe_eval("1 + [3, 3]")
    except:
        assert sys.exc_info() is not None

    # Test 3, success case, allowing a call to a builtin safe_function
    assert safe_eval("foo.split(',')", dict(foo='a,b,c'), CALL_ENABLED=['split']) == ['a', 'b', 'c']

    # Test 4, failure case, trying to call a builtin that is not allowed
    try:
        safe_eval("foo.split(',')", dict(foo='a,b,c'), CALL_ENABLED=['join'])
    except:
        assert sys.exc_info() is not None

# Generated at 2022-06-21 07:54:18.162236
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils._text import to_bytes

    def my_test(t, e, v=None, tb=None, p=None):
        if tb is None:
            tb = (v is None)
        try:
            r = safe_eval(t, dict(v=v), include_exceptions=True)
            if r[1] is None:
                ok = True
            else:
                ok = False
        except Exception as x:
            r = (t, x)
            ok = False

        if ok != e:
            print("ERROR: expected %s but got %s" % (e, ok))
            if tb:
                print("Traceback:")
                import traceback
                traceback.print_exc()
            if p:
                print("Python error:")
               

# Generated at 2022-06-21 07:54:28.790016
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.errors import AnsibleError
    from ansible.playbook.role.definition import RoleDefinition

    def safe_eval_with_exceptions(test_expression):
        """
        Evaluate the given expression safely and return the result along with any exceptions encountered
        """
        # Traverse all registered plugins and call the safe_eval filter on each
        # so that any filters defined on the plugins are also evaluated safely.
        # We use the PlayContext object to pass to the filter as it has builtin
        # filters as well as mappings for hosts, port and vars
        fake_pc = RoleDefinition()
        fake_pc.CLIARGS = dict()

        # safe_eval(test_expression, include_exceptions=True) is the filter
        # we want to call. But the plugins may also define other filters that
        # we do not want

# Generated at 2022-06-21 07:54:41.391077
# Unit test for function safe_eval

# Generated at 2022-06-21 07:54:53.849154
# Unit test for function safe_eval
def test_safe_eval():
    # basic types
    assert safe_eval('test') == 'test'
    assert isinstance(safe_eval('test'), string_types)
    assert safe_eval('123') == 123
    assert isinstance(safe_eval('123'), int)
    assert safe_eval('123.456') == 123.456
    assert isinstance(safe_eval('123.456'), float)
    assert safe_eval('True') is True
    assert isinstance(safe_eval('True'), bool)
    assert safe_eval('False') is False
    assert isinstance(safe_eval('False'), bool)
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert isinstance(safe_eval('[1,2,3]'), list)
    assert safe_eval

# Generated at 2022-06-21 07:55:01.049690
# Unit test for function safe_eval
def test_safe_eval():
    # ----------------------------------------------------------------
    # Check the dicts
    # ----------------------------------------------------------------
    test_dict = dict(a=1, b="foo", c=[1, 2, 3])
    result = safe_eval(test_dict, include_exceptions=True)
    assert result == (test_dict, None)

    # ----------------------------------------------------------------
    # Check the list
    # ----------------------------------------------------------------
    test_list = [1, "foo", [1, 2, 3]]
    result = safe_eval(test_list, include_exceptions=True)
    assert result == (test_list, None)

    # ----------------------------------------------------------------
    # Check simple expression
    # ----------------------------------------------------------------
    result = safe_eval('a + 1', dict(a=10), include_exceptions=True)
    assert result == (11, None)

    # ----------------------------------------------------------------
    # Check simple expression that is not safe
    #

# Generated at 2022-06-21 07:55:13.378908
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:23.732948
# Unit test for function safe_eval
def test_safe_eval():
    # Good
    assert safe_eval("[1, 2, [3, 4], (5, 6)]") == [1, 2, [3, 4], (5, 6)]
    assert safe_eval("{1:2, 3:4}") == {1:2, 3:4}
    assert safe_eval("(1, 2, (3, 4))") == (1, 2, (3, 4))
    assert safe_eval("[1, 2, [3, 4], (5, 6)][0]") == 1
    assert safe_eval("(1, 2, (3, 4))[0]") == 1
    assert safe_eval("{1:2, 3:4}[3]") == 4
    assert safe_eval("0 - 2") == -2

# Generated at 2022-06-21 07:55:35.226863
# Unit test for function safe_eval
def test_safe_eval():
    # Test for Python 3.4 and earlier
    if sys.version_info[0:2] == (3, 4):
        safe_eval('None', include_exceptions=False)
        try:
            safe_eval('[x for x in range(10)]', include_exceptions=False)
        except:
            pass
        else:
            raise AssertionError('Should not have been allowed')

    safe_eval('True', include_exceptions=False)
    safe_eval('False', include_exceptions=False)
    safe_eval('None', include_exceptions=False)
    safe_eval('[]', include_exceptions=False)
    safe_eval('{}', include_exceptions=False)

# Generated at 2022-06-21 07:55:45.545772
# Unit test for function safe_eval
def test_safe_eval():

    test_globals = {
        'v': 'global',
        'global_func': lambda: 'global_func'
    }

    test_data = [
        ('v', 'global'),
        ('global_func()', 'global_func')
    ]

    for t, r in test_data:
        result = safe_eval(t, test_globals)
        assert result == r, 'safe_eval() failed on %s: got %s but expected %s' % (t, result, r)

    # Test that bad input throws an exception

# Generated at 2022-06-21 07:55:58.370899
# Unit test for function safe_eval
def test_safe_eval():
    # Simple string
    assert safe_eval('"a simple string"') == 'a simple string'

    # Simple number
    assert safe_eval('1') == 1

    # Simple number with leading zero
    assert safe_eval('01') == 1

    # Non-zero octal number
    assert safe_eval('0777') == 777

    # Zero octal number
    assert safe_eval('00') == 0

    # Simple list
    assert safe_eval('["a simple list"]') == ['a simple list']

    # Simple dict
    assert safe_eval('{"a simple dict": "a simple string"}') == {'a simple dict': 'a simple string'}

    # Simple tuple
    assert safe_eval('("a simple tuple")') == ('a simple tuple',)

    # Combination of list and string

# Generated at 2022-06-21 07:56:06.395174
# Unit test for function safe_eval
def test_safe_eval():
    assert 0 == safe_eval('0')
    assert 1 == safe_eval('-1 + 2')
    assert 'ab' == safe_eval('"a" + "b"')
    assert [0, 1, 2] == safe_eval('[0,1,2]')
    assert (0, 1, 2) == safe_eval('(0,1,2)')
    assert {'a': 1, 'b': 2} == safe_eval('{"a": 1, "b": 2}')
    assert {'a': 1, 'b': 2} == safe_eval('dict(a=1, b=2)')
    assert sorted({'a': 1, 'b': 2}) == safe_eval('[{"a": 1, "b": 2}]')


# Generated at 2022-06-21 07:56:18.531370
# Unit test for function safe_eval
def test_safe_eval():
    # PASS: these tests should not raise an exception
    safe_eval('[]')
    safe_eval(r"[1,2,3, '{{ myvar }}']")
    safe_eval('True')
    safe_eval('"OK"')
    safe_eval(r"'{{ myvar }}'")
    safe_eval(r"'{{ myvar | quote }}'")
    safe_eval('1.1')
    safe_eval('1337')
    safe_eval('1 + 2')
    safe_eval('1 + 1 == 2')
    safe_eval('1 + 1')
    safe_eval('1 + 1')
    safe_eval('1 - 1')
    safe_eval('1 * 1')
    safe_eval('4 / 2')
    safe_eval('1')
    safe_eval('-1')
    safe

# Generated at 2022-06-21 07:56:33.281793
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("2+3") == 5
    assert safe_eval("2+3", include_exceptions=True) == (5, None)
    assert safe_eval("2+3", include_exceptions=True)[0] == 5

    assert safe_eval("a", include_exceptions=True)[0] == 'a'
    assert safe_eval("a", include_exceptions=True)[1] is None
    assert safe_eval("a") == 'a'

    assert safe_eval("math.pow(2, 5)") == 32
    assert safe_eval("math.pow(2, 5)", include_exceptions=True) == ('math.pow(2, 5)', None)

# Generated at 2022-06-21 07:56:45.853089
# Unit test for function safe_eval
def test_safe_eval():

    def check_eval(expr, results={}, globals={}, should_pass=True):
        res, e = safe_eval(expr, locals=results, include_exceptions=True)
        if should_pass:
            if e is not None:
                print (expr, "failed, should have passed but got exception", e)
                exit(1)
        else:
            if e is None:
                print (expr, "passed, should have failed")
                exit(1)

    # simple expr
    check_eval('mytest', results={'mytest': 'hello'}, should_pass=True)

    # simple expr
    check_eval('mytest=="hello"', results={'mytest': 'hello'}, should_pass=True)

    # invalid expr

# Generated at 2022-06-21 07:56:55.361201
# Unit test for function safe_eval
def test_safe_eval():

    def assert_safe_eval(name, expr, expected, locals=None):
        locals = {} if locals is None else locals
        actual, e = safe_eval(expr, locals, include_exceptions=True)
        assert actual == expected, "Expected %s to be %s but got %s (error was %s)" % (name, expected, actual, e)

    assert_safe_eval('boolean', 'true', True)
    assert_safe_eval('empty list', '[]', [])
    assert_safe_eval('empty dict', '{}', {})
    assert_safe_eval('empty tuple', '()', ())
    assert_safe_eval('tuple', '("a",1)', ("a",1))

# Generated at 2022-06-21 07:57:07.995586
# Unit test for function safe_eval
def test_safe_eval():
    # determine if we are python 2.x or python 3.x
    # this allows the module to deal with unicode properly
    is_py2 = sys.version[0] == '2'

    def patch_python_2():
        '''
        This is needed to make the code compatible with python 2.x
        '''
        if is_py2:
            # python 2 vs python 3
            from itertools import izip_longest as zip_longest
            from itertools import izip as zip

        # make True and False builtin keywords
        # this is so that jinja2 templates don't break
        # when we try to use them in expressions
        import __builtin__

# Generated at 2022-06-21 07:57:17.329496
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Ensure the input expression is preserved if it cannot be processed.
    '''

    # Make sure the simplest case returns the correct value
    result = safe_eval('{"a": [1, 2, 3]}')
    assert result == {"a": [1, 2, 3]}

    result = safe_eval('{"a": {"b": 5}}')
    assert result == {"a": {"b": 5}}

    result = safe_eval('{"a": {"b": {"c": None}}}')
    assert result == {"a": {"b": {"c": None}}}

    result = safe_eval('{"a": {"b": {"c": "hello world"}}}')
    assert result == {"a": {"b": {"c": "hello world"}}}

    result = safe_eval('{"a": {"b": {"c": False}}}')
    assert result

# Generated at 2022-06-21 07:57:29.950164
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test safe_eval function returns the same as eval
    '''
    assert safe_eval("1 + 2 + 3") == eval("1 + 2 + 3")
    assert safe_eval("[1, 2, 3]") == eval("[1, 2, 3]")
    assert safe_eval("{'a': 1, 'b': 2}") == eval("{'a': 1, 'b': 2}")
    assert safe_eval("'a' in {'a': 1, 'b': 2}") == eval("'a' in {'a': 1, 'b': 2}")

    if sys.version_info[0] == 3:
        assert safe_eval("ord('a')") == eval("ord('a')")

# Generated at 2022-06-21 07:57:33.504546
# Unit test for function safe_eval
def test_safe_eval():
    expr = "{{ foo }}"
    expr2 = "[1,2,3,4]"
    expr3 = "[1,2,{{foo}},4]"
    expr4 = "1+1"
    expr5 = "5+5"
    expr6 = "foo"
    expr7 = "1+1"
    expr8 = "foo.lower()"
    expr9 = "foo.lower"
    expr10 = "foo.lower().strip()"
    expr11 = "foo.lower().stript()"
    expr12 = "foo.lower().strip().upper().strip()"
    expr13 = "foo.lower().stript().upper().strip()"
    expr14 = "foo.lower().strip()+'bar'"
    expr15 = "foo.lower().stript()+'bar'"

# Generated at 2022-06-21 07:57:44.229187
# Unit test for function safe_eval
def test_safe_eval():
    def test(string, result):
        try:
            res = safe_eval(string)
            if res == result:
                print("ok: '{0}' -> '{1}'".format(string, result))
            else:
                print("FAIL: '{0}' -> '{1}' != '{2}'".format(string, res, result))
        except Exception as e:
            print("FAIL: '{0}' -> Exception: {1}".format(string, e))

    def test_fail(string):
        print("FAIL: '{0}' -> did not fail".format(string))

    CALL_ENABLED.append('dict')
    test("dict(a=1, b=2)", dict(a=1, b=2))

# Generated at 2022-06-21 07:57:54.123623
# Unit test for function safe_eval
def test_safe_eval():
    # test for CID 8723: AST injection through safe_eval()
    assert safe_eval(ast.__version__) == ast.__version__
    assert safe_eval('__import__("sys").version > "2.6"') == True
    assert safe_eval('__import__("sys").version > "2.6"', include_exceptions=True)[0] == False
    assert safe_eval('__import__("sys").version_info > (2, 6)') == True
    assert safe_eval('__import__("sys").version_info > (2, 6)', include_exceptions=True)[0] == False
    assert safe_eval('[__import__("sys").version_info > (2, 6)]') == [True]

# Generated at 2022-06-21 07:58:05.525666
# Unit test for function safe_eval
def test_safe_eval():
    # Passing test cases
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('42') == 42
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)

    intlist = [1, 2, 3]
    assert safe_eval('x + y', {'x': 5, 'y': 10}) == 15
    assert safe_eval('[x+1 for x in intlist]', {'intlist': [1, 2, 3]}) == [2, 3, 4]

# Generated at 2022-06-21 07:58:28.638808
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Return True on success or False and an error message on failure
    '''
    # This function tests safe_eval

    # a dict to hold our results
    test_results = dict(failures=[], successes=[])

    # test data, we need a list of things to test, the expected result and a description
    # of the test

# Generated at 2022-06-21 07:58:40.589981
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1*2') == 2
    assert safe_eval('2*2') == 4
    assert safe_eval('a_list_variable', dict(a_list_variable=[1, 2])) == [1, 2]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('foo(1)', {'foo': lambda x: x+1}) == 2
    assert safe_eval('a == b', {'a': 1, 'b': 1})
    assert safe_eval('a[2] == "something"', {'a': [1, 2, "something"]})
    assert safe_eval("a or b", {'a': 0, 'b': 'something'}) == 'something'

    # Test invalid expressions

# Generated at 2022-06-21 07:58:47.571073
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    # This is a list of expressions to evaluate and the expected result
    TEST_EXPRESSIONS = [
        ('1 + 1', 2),
        ('2 + 3', 5),
        ('[1,2,3]', [1,2,3]),
        ('True', True),
        ('False', False),
        ('None', None),
        ('(1, 2, 3)', (1, 2, 3)),
        ('{1:2, 3:4}', {1:2, 3:4}),
        ('-1', -1),
        ('-1 + -1', -2),
        ('1 + -1', 0),
    ]

    # Ensure all expressions in the list evaluate as expected
    for expr, expected in TEST_EXPRESSIONS:
        assert safe_eval(expr) == expected

    IN

# Generated at 2022-06-21 07:58:59.639479
# Unit test for function safe_eval
def test_safe_eval():
    boolean_expressions = {
        "true": True,
        "1 == 1": True,
        "false": False,
        "1 == 0": False,
    }
    integer_expressions = {
        "1": 1,
        "2*2": 4,
        "(1 + 5)*3": 18,
        "1 >= 0": True,
        "5 != 4": True,
        "5 % 3": 2,
        "5**2": 25,
    }
    string_expressions = {
        '"foo"': "foo",
        '"foo" + "bar"': "foobar",
    }

# Generated at 2022-06-21 07:59:09.472520
# Unit test for function safe_eval
def test_safe_eval():
    C.DEFAULT_DEBUG = False
    # make sure safe_eval parses only certain AST node types
    assert_raises(Exception, safe_eval, "__import__('sys').exit(1)")
    assert_raises(Exception, safe_eval, "__import__('os').system('echo hi')")
    assert_raises(Exception, safe_eval, "[x for x in range(5)]")
    assert_raises(Exception, safe_eval, "{x:x for x in range(5)}")
    # these should all parse fine
    safe_eval("[x for x in range(10) if x % 2 == 0]")
    safe_eval("{x:x for x in range(10) if x % 2 == 0}")
    # test that names are restricted to builtin functions

# Generated at 2022-06-21 07:59:19.081971
# Unit test for function safe_eval
def test_safe_eval():
    (result, exception) = safe_eval('[1, 2, 3]', include_exceptions=True)
    assert exception is None, 'result: %s exception: %s' % (repr(result), repr(exception))
    assert result == [1, 2, 3], 'result: %s exception: %s' % (repr(result), repr(exception))

    (result, exception) = safe_eval('{"foo":"bar"}', include_exceptions=True)
    assert exception is None, 'result: %s exception: %s' % (repr(result), repr(exception))
    assert result == {"foo": "bar"}, 'result: %s exception: %s' % (repr(result), repr(exception))

    (result, exception) = safe_eval('30', include_exceptions=True)
   

# Generated at 2022-06-21 07:59:30.562604
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure the right things evaluate
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo.bar") == "foo.bar"
    assert safe_eval("foo[bar]") == "foo[bar]"
    assert safe_eval("foo.bar[baz]") == "foo.bar[baz]"

    # This is actually valid python, but we don't allow it
    # because the python eval() function would interpret
    # it as a non-string.
    assert safe_eval("'foo' 'bar'") == "'foo' 'bar'"

    # None of these should evaluate

# Generated at 2022-06-21 07:59:38.179579
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure we can handle all the JSON types, arrays, empty dict/array
    testcases = [
        [ 'null', None],
        [ 'false', False],
        [ 'true', True],
        [ 'null', None],
        [ '[]', []],
        [ '{}', {}],
        [ '{"a": [1, "yes", null], "b": {"key": false}}',
                                          {'a': [1, 'yes', None], 'b': {'key': False}}],
    ]
    for testcase in testcases:
        orig = testcase[0]
        expected = testcase[1]
        actual = safe_eval(orig)
        assert actual == expected, "%s: %s != %s" % (orig, actual, expected)


# Generated at 2022-06-21 07:59:50.254344
# Unit test for function safe_eval
def test_safe_eval():
    # enable all callable builtins
    from ansible.module_utils.six.moves.builtins import __dict__ as bi
    CALL_ENABLED.extend([func_name for func_name in dir(bi) if callable(getattr(bi, func_name))])

    assert safe_eval('True') is True
    assert safe_eval('false') is False
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('[1.9,2.0,3.1]') == [1.9,2,3.1]

# Generated at 2022-06-21 07:59:58.803391
# Unit test for function safe_eval

# Generated at 2022-06-21 08:00:30.064992
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # These tests need to be updated to account for the changes to allow
    # all operators, and any builtin functions, because we can now
    # constrain the globals and locals.

# Generated at 2022-06-21 08:00:41.738011
# Unit test for function safe_eval
def test_safe_eval():
    include_exceptions = True
    raise Exception("TODO: unit tests")
    assert safe_eval("8", include_exceptions=include_exceptions) == 8
    assert safe_eval("9", include_exceptions=include_exceptions) == 9
    assert safe_eval("8 + 9", include_exceptions=include_exceptions) == 17
    assert safe_eval("({'a':'b'})", include_exceptions=include_exceptions) == {'a': 'b'}
    assert safe_eval("({'a':'b'})", include_exceptions=include_exceptions) == {'a': 'b'}
    assert safe_eval("'foo'", include_exceptions=include_exceptions) == 'foo'

# Generated at 2022-06-21 08:00:53.683588
# Unit test for function safe_eval
def test_safe_eval():
    import unittest2 as unittest
    class TestSafeEval(unittest.TestCase):
        ''' tests the safe_eval function '''
        def test_safe_eval(self):
            # expected: pass
            self.assertEquals(safe_eval("10"), 10)
            self.assertEquals(safe_eval("10 + 10"), 20)
            self.assertEquals(safe_eval("10-10"), 0)
            self.assertEquals(safe_eval("true"), True)
            self.assertEquals(safe_eval("'hello'"), 'hello')
            self.assertEquals(safe_eval("'hello' + 'world'"), 'helloworld')
            self.assertEquals(safe_eval("['hello', true]"), ['hello', True])