

# Generated at 2022-06-21 07:51:07.651048
# Unit test for function safe_eval
def test_safe_eval():
    '''
    The function safe_eval is used to "evaluate" untrusted expressions
    for use by with_items, when and other modules.
    It is intended that these expressions can only contain literals and
    simple operators such as + and -
    This test is a collection of expressions that should be True when
    evaluated by python's built-in eval() function, and should also be
    True when evaluated by safe_eval.
    These tests are thus grouped together and will pass if both built-in
    eval and safe_eval are behaving as intended.
    '''
    # Imports used by tests below
    from datetime import date, datetime

    # Gather a list of expresssions to be evaluated
    exprs = []
    # Literals

# Generated at 2022-06-21 07:51:17.454568
# Unit test for function safe_eval

# Generated at 2022-06-21 07:51:28.227955
# Unit test for function safe_eval
def test_safe_eval():
    """Run safe_eval through a series of tests.

    Call safe_eval on various expressions, to see whether it does the right
    thing:

    - Return the same thing for expressions that evaluate without exceptions
    - Return the expression for a string that isn't valid Python
    - Return the expression for a string that has a SyntaxError in it
    - Assert in various ways for expressions that have invalid nodes in them
    """


# Generated at 2022-06-21 07:51:40.328559
# Unit test for function safe_eval
def test_safe_eval():
    """
    If a syntax error is encountered, the expression string is returned as-is
    to support late evaluation.
    """

    # Simple examples.
    assert safe_eval("None") == None
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("[]") == []
    assert safe_eval("{}") == {}
    assert safe_eval("{'k1': 'v1'}") == {'k1': 'v1'}
    assert safe_eval("'str'") == 'str'
    assert safe_eval(u"'str'") == u'str'

# Generated at 2022-06-21 07:51:51.587444
# Unit test for function safe_eval
def test_safe_eval():
    from copy import copy
    from ansible.module_utils.common.text.converters import to_unicode
    # test a string literal
    s = "[1,2,3]"
    assert to_unicode(s) == safe_eval(to_unicode(s))
    # test a string variable
    s = 'var'
    locals = {}
    locals['var'] = "[1,2,3]"
    assert locals['var'] == safe_eval(to_unicode(s), locals)
    # test a string arithmetic expression
    s = '1 + 2'
    assert '3' == safe_eval(to_unicode(s))
    # test a string literal
    s = 'var == "[1,2,3]"'
    locals = {}
    locals['var'] = "[1,2,3]"
   

# Generated at 2022-06-21 07:52:03.362038
# Unit test for function safe_eval
def test_safe_eval():
    # safe
    assert safe_eval('1 + 2') == 3
    assert safe_eval('(a and b) or (c and d)') == ('(a and b) or (c and d)', None)
    assert safe_eval('a, b', dict(a=1, b=2)) == (1, 2)
    assert safe_eval('dict(a=1, b=2)') == dict(a=1, b=2)

    # unsafe
    assert safe_eval('__import__("os").system("echo hi")') == "__import__(\"os\").system(\"echo hi\")"
    assert safe_eval('open("/etc/passwd", "r").read()') == "open(\"/etc/passwd\", \"r\").read()"

# Generated at 2022-06-21 07:52:04.702879
# Unit test for function safe_eval
def test_safe_eval():
    # test safe_eval
    pass

# Generated at 2022-06-21 07:52:16.346337
# Unit test for function safe_eval

# Generated at 2022-06-21 07:52:25.397906
# Unit test for function safe_eval
def test_safe_eval():
    # Expression that should cause an exception
    expr = 'foo'
    result = safe_eval(expr)
    assert result == expr

    assert safe_eval('foo') == 'foo'
    assert safe_eval(1) == 1
    assert safe_eval(1.3) == 1.3

    # Test that we can parse some basic JSON types
    assert safe_eval('true') == True
    assert safe_eval('false') == False
    assert safe_eval('null') == None

    assert safe_eval('[]') == []
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{}') == {}
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}

    # Basic math operations

# Generated at 2022-06-21 07:52:35.569566
# Unit test for function safe_eval
def test_safe_eval():
    # basic tests
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3
    assert safe_eval('true') == True
    assert safe_eval('null') == None
    assert safe_eval('"abcd"') == "abcd"
    assert safe_eval("'abcd'") == "abcd"
    assert safe_eval("['a','b']") == ['a','b']
    assert safe_eval("{ 'a':'b' }") == { 'a':'b' }

    # test the inclusion of some builtin functions
    assert safe_eval("len('abcd')") == 4
    assert safe_eval("len('abcd')", {}, True)[0] == 4

    # test the handling of a syntax error

# Generated at 2022-06-21 07:52:49.163850
# Unit test for function safe_eval
def test_safe_eval():
    # Convert second argument in Python 2/3
    if sys.version_info < (3,):
        safeeval = safe_eval(to_native("\"foo\""), {'bar': {'zip': 'zap'}})
        assert safeeval == "foo"
        safeeval = safe_eval(to_native("[1,2,'foo', '{zip: zap}']"), {'bar': {'zip': 'zap'}})
        assert safeeval == [1, 2, 'foo', '{zip: zap}']
        safeeval = safe_eval(to_native("['foo', '{zip: zap}']"), {'bar': {'zip': 'zap'}})
        assert safeeval == ['foo', '{zip: zap}']
        safeeval = safe_eval

# Generated at 2022-06-21 07:52:59.363942
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('a + b', dict(a=1, b=2)) == 3
    assert safe_eval('a * b', dict(a=4, b=5)) == 20
    assert safe_eval('a - b', dict(a=4, b=5)) == -1
    assert safe_eval('a / b', dict(a=16, b=2)) == 8
    assert safe_eval('a / b', dict(a=16.0, b=2)) == 8.0
    # not supported by safe_eval
    # assert safe_eval('a / b', dict(a=16, b

# Generated at 2022-06-21 07:53:10.430104
# Unit test for function safe_eval
def test_safe_eval():
    # Test python 3 style print
    expr = "print('Hello World!', file=sys.stderr)"
    if sys.version_info[0] < 3:
        expr = "print 'Hello World!'"
    print('\n## Test %s ...' % expr)
    value = safe_eval(expr)
    print(value)
    assert value == expr

    # Test valid Python data structures
    expr = '{"a": "b"}'
    print('\n## Test %s ...' % expr)
    value = safe_eval(expr)
    print(container_to_text(value))
    assert value == {'a': 'b'}

    expr = '["a", "b"]'
    print('\n## Test %s ...' % expr)
    value = safe_eval(expr)

# Generated at 2022-06-21 07:53:22.440804
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[]') == []
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('foo') == 'foo'
    assert safe_eval('["foo", "bar", 1, 2, True, False]') == ['foo', 'bar', 1, 2, True, False]
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('1 + 2') == 3
    assert safe_eval('6 / 2') == 3
    assert safe_eval('-1') == -1

# Generated at 2022-06-21 07:53:33.746349
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:44.847155
# Unit test for function safe_eval

# Generated at 2022-06-21 07:53:51.868478
# Unit test for function safe_eval
def test_safe_eval():
    ret, _ = safe_eval('{{ foo }}')
    assert ret == '{{ foo }}'

    ret, _ = safe_eval('{{ foo }}', {'foo': 'bar'})
    assert ret == '{{ foo }}'

    ret, _ = safe_eval('[ [ 2, 3, 4 ], [ 4, 5 ] ]')
    assert ret == [[2, 3, 4], [4, 5]]

    ret, _ = safe_eval('[ [ 2, 3, 4 ], [ 4, 5 ] ]', include_exceptions=True)
    assert ret == [[2, 3, 4], [4, 5]]

    ret, err = safe_eval('[{{ foo }}]')
    assert ret == '[{{ foo }}]'

    ret, err = safe_eval('[{{ foo }}]', {'foo': 'bar'})

# Generated at 2022-06-21 07:54:02.055617
# Unit test for function safe_eval
def test_safe_eval():

    try:
        import yaml  # Importing yaml here so as to not bring in unnecessary dependencies
    except ImportError:
        print("skipping safe_eval unit tests due to yaml missing")
        return

    class TestCase(object):
        data = None
        expected = None
        should_fail = False
        name = ''

    # NOTE: Expected behavior may change in the future when we move toward YAML 2.0
    # The current behavior here is to unescape a literal string, so this test will
    # likely need to be updated when that change occurs
    # Test 1: Simple list of strings (eval should simply pass through)
    TestCase.name = 'Test 1: simple list of strings'
    TestCase.data = """
        - 'hello'
        - 'world'
    """

# Generated at 2022-06-21 07:54:12.604475
# Unit test for function safe_eval
def test_safe_eval():
    # Check that basic Jinja2 syntax works
    eval1 = safe_eval('{{ var }}')
    assert eval1 == '{{ var }}'

    # Check that basic multiplication works
    eval2 = safe_eval('3 * 4')
    assert eval2 == 12

    # Check that basic addition works
    eval3 = safe_eval('3 + 4')
    assert eval3 == 7

    # Check that basic subtraction works
    eval4 = safe_eval('3 - 4')
    assert eval4 == -1

    # Check that basic division works
    eval5 = safe_eval('3 / 4')
    assert eval5 == 0.75

    # Check that lists work
    eval6 = safe_eval('[1, 2, 3] * 3')

# Generated at 2022-06-21 07:54:19.071193
# Unit test for function safe_eval
def test_safe_eval():
    unsafe_str_1 = "{% if x > 0 %}y{{ y }}z{% else %}q{{ q }}{% endif %}"
    unsafe_str_2 = "{{ z }}"
    unsafe_str_3 = "{% if x > 0 and y > 0 %}y{{ y }}z{% else %}q{{ q }}{% endif %}"
    safe_str_1 = "{{ z }}"
    safe_str_2 = "x"
    safe_str_3 = "1 + 1"
    safe_str_4 = "complex(3, 4)"
    safe_str_5 = "(3,4)"
    safe_str_6 = "[3,4]"
    safe_str_7 = "5.5"
    safe_str_8 = "'simple string'"

# Generated at 2022-06-21 07:54:34.585009
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test function for function safe_eval
    '''
    # Simple test to see if we get the same value back

# Generated at 2022-06-21 07:54:43.075872
# Unit test for function safe_eval
def test_safe_eval():
    # Test empty expression, should return an empty expression
    test_expr = ''
    val = safe_eval(test_expr)
    assert val == test_expr, 'Failed to safely evaluate an empty expression'

    # Test an expression with a builtin method, should fail
    test_expr = 'len([1, 2])'
    val = safe_eval(test_expr)
    assert val == test_expr, 'Failed to safely evaluate an expression including a builtin method'

    # Test an expression with JSON, should pass
    test_expr = '[1, 2]'
    val = safe_eval(test_expr)
    assert val == [1, 2], 'Failed to safely evaluate an expression including JSON'

    # Test a call to a non-builtin method, should pass

# Generated at 2022-06-21 07:54:52.658518
# Unit test for function safe_eval
def test_safe_eval():
    """
    Test to ensure that safe_eval works correctly.
    """
    tests = {
        "1 + 1": 2,
        "[1, 2, 3][0]": 1,
        "foo": "foo",
        "None": None,
        "{'foo': 'bar', 'snuh': 'nuh'}": {'foo': 'bar', 'snuh': 'nuh'},
        "[item for item in [1, 2, 3]]": [1, 2, 3]
    }

    for test, test_result in tests.items():
        assert test_result == safe_eval(test)


# Generated at 2022-06-21 07:55:00.678632
# Unit test for function safe_eval
def test_safe_eval():

    def check_safe_eval(expr, result):
        assert safe_eval(expr) == result

    check_safe_eval('1 + 2', 3)
    check_safe_eval('"abc"', "abc")
    check_safe_eval('[1, 2, 3]', [1, 2, 3])
    check_safe_eval('{"a": "b", "c": "d"}', {'a': 'b', 'c': 'd'})

    def check_safe_eval_exception(expr):
        try:
            safe_eval(expr)
        except:
            return True
        else:
            return False

    # eval() does not allow statements
    assert check_safe_eval_exception('a = 1')

    # only identifiers are allowed at global scope

# Generated at 2022-06-21 07:55:13.182790
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("42") == 42
    assert safe_eval("42 + 42") == 84
    assert safe_eval("a", {"a": 1}) == 1
    assert safe_eval("a_list + [1]", {"a_list": [1]}) == [1, 1]
    assert safe_eval("a_list + [1, 2, 3]", {"a_list": [1, 2]}) == [1, 2, 1, 2, 3]
    assert safe_eval("a_list + [1] + b_list", {"a_list": [1], "b_list": [2, 3]}) == [1, 1, 2, 3]

# Generated at 2022-06-21 07:55:23.625046
# Unit test for function safe_eval
def test_safe_eval():

    # Test for constants
    assert safe_eval('true')
    assert not safe_eval('false')
    assert safe_eval('null') is None
    assert safe_eval('true and false') is False

    # Test for operators
    assert safe_eval('1 + 2') == 3
    assert safe_eval('1 - 2') == -1
    assert safe_eval('1 * 2') == 2
    assert safe_eval('1 / 2') == 0.5
    assert safe_eval('1 + 1 + 1') == 3
    assert safe_eval('1 - 1 - 1') == -1
    assert safe_eval('1 * 1 * 1') == 1
    assert safe_eval('1 / 1 / 1') == 1

    # Test for comparison operators
    assert safe_eval('1 == 1')
    assert safe_eval('1 != 1')

# Generated at 2022-06-21 07:55:35.177881
# Unit test for function safe_eval

# Generated at 2022-06-21 07:55:45.506815
# Unit test for function safe_eval
def test_safe_eval():

    # Verify that it can evaluate simple expressions
    assert safe_eval("a + b") == 'a + b'
    assert safe_eval("a + b", dict(a=1, b=2)) == 3

    # Verify that it detects unsafe calls
    assert safe_eval("__import__('os').walk") == "__import__('os').walk"
    assert safe_eval("abs(1)") == 1

    # Verify that it detects unsafe module-level attributes
    assert safe_eval("ansible.__version__") == "ansible.__version__"
    assert safe_eval("ansible.__file__") == "ansible.__file__"

    # Verify that it allows safe module-level attributes
    CALL_ENABLED.append('__version__')
    CALL_ENABLED.append('__file__')
    assert safe

# Generated at 2022-06-21 07:55:58.319184
# Unit test for function safe_eval
def test_safe_eval():
    def run_eval_result(val):
        if isinstance(val, tuple):
            return val[0]
        return val

    # valid eval calls
    assert run_eval_result(safe_eval("foo", dict(foo="bar"))) == "bar"
    assert run_eval_result(safe_eval("foo", dict(foo=None))) is None
    assert run_eval_result(safe_eval("foo + 1", dict(foo=1))) == 2
    assert run_eval_result(safe_eval("foo.upper()", dict(foo="bar"))) == "BAR"
    assert run_eval_result(safe_eval("'{}'.format(foo)", dict(foo="bar"))) == "bar"

# Generated at 2022-06-21 07:56:06.435559
# Unit test for function safe_eval
def test_safe_eval():
    # This should work
    s = '{"json_key": "json_value"}'
    assert safe_eval(s) == {'json_key': 'json_value'}

    # This should raise an exception, since we want to restrict callables
    s = 'json.dumps({"json_key": "json_value"})'
    assert safe_eval(s) == s

    # This should work
    s = '{"json_key": "json_value"}'
    assert safe_eval(s) == {'json_key': 'json_value'}

    # This should raise an exception, since we want to restrict callables
    s = 'json.dumps({"json_key": "json_value"})'
    assert safe_eval(s) == s

    # This should raise an exception, since we want to restrict callables

# Generated at 2022-06-21 07:56:27.772618
# Unit test for function safe_eval
def test_safe_eval():
    # Test good eval
    assert safe_eval("1 + 2") == 3
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("{'foo': 1, 'bar': 2}") == {'foo': 1, 'bar': 2}
    assert safe_eval("1 + 2", include_exceptions=True) == (3, None)
    assert safe_eval("['foo', 'bar']", include_exceptions=True) == (['foo', 'bar'], None)
    assert safe_eval("{'foo': 1, 'bar': 2}", include_exceptions=True) == ({'foo': 1, 'bar': 2}, None)
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None

# Generated at 2022-06-21 07:56:39.112200
# Unit test for function safe_eval

# Generated at 2022-06-21 07:56:50.497375
# Unit test for function safe_eval
def test_safe_eval():
    expr = "foo == 1 and bar == 2"
    locals = dict(foo=1, bar=2, baz=3)

    assert safe_eval(expr, locals) is True
    assert safe_eval(expr, locals, include_exceptions=True)[0] is True

    expr = "foo == 1 and baz == 3"
    assert safe_eval(expr, locals) is False
    assert safe_eval(expr, locals, include_exceptions=True)[0] is False

    expr = "foo in [1,2,3]"
    assert safe_eval(expr, locals) is True
    assert safe_eval(expr, locals, include_exceptions=True)[0] is True

    expr = "foo not in [1,2,3]"
    assert safe_eval(expr, locals) is False

# Generated at 2022-06-21 07:56:57.841045
# Unit test for function safe_eval
def test_safe_eval():
    # Good things
    # -----------
    # Constant values
    for value in ['1', '1.2', '-1', '-1.2', '"string_constant"', '"string_constant"', 'True', 'False', 'None',
                  '[1, 2, 3]', '{"a": 1, "b": 2}']:
        assert safe_eval(value) == ast.literal_eval(value)

    # Simple calculations
    assert safe_eval('1+1') == 2
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1-1') == 0
    assert safe_eval('1 * 2') == 2
    assert safe_eval('1 / 2') == 0.5

    # Complex expressions
    assert safe_eval('(1+2)*(2+3)')

# Generated at 2022-06-21 07:57:10.260971
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This comment is a unit test
    '''

    # test constants
    TRUE_VALUE = True
    FALSE_VALUE = False
    NONE_VALUE = None
    EMPTY_DICT = {}
    EMPTY_LIST = []
    EMPTY_STRING = ''

    INT_VALUE = 1
    LONG_VALUE = 2**32
    NEG_VALUE = -3
    ZERO_VALUE = 0
    FLOAT_VALUE = 4.5
    DOUBLE_VALUE = 8.5

    UNICODE_STRING = u'\u2713'
    STRING_VALUE = 'value'
    STRING_VALUE_ONE = '1'
    STRING_VALUE_ONE_INT = 1
    DOUBLE_STRING = "5.5"
    DOUBLE_STRING_VALUE = 5

# Generated at 2022-06-21 07:57:21.022359
# Unit test for function safe_eval
def test_safe_eval():
    res = safe_eval('1')
    assert res == 1
    res = safe_eval('1 + 3')
    assert res == 4
    res = safe_eval('["a", "b", "c"]')
    assert res == ["a", "b", "c"]
    res = safe_eval('{"a": 1, "b": 2}')
    assert res == {"a": 1, "b": 2}
    res = safe_eval('a_dict["a"]')
    assert res == "a"
    res = safe_eval('a_list[0]')
    assert res == "a"
    res = safe_eval('a_list[1] + a_list[2]')
    assert res == "bc"
    res = safe_eval('a_list[0] + a_list[-1]')


# Generated at 2022-06-21 07:57:32.887338
# Unit test for function safe_eval
def test_safe_eval():
    # this compile should work
    assert safe_eval("a='b'")
    assert safe_eval("a='b'", include_exceptions=True)[0] == "a='b'"

    # this compile should fail
    if sys.version_info < (3, 0):
        assert safe_eval("a='b'", include_exceptions=True)[0] == "a='b'"
        assert "invalid syntax" in safe_eval("a='b'", include_exceptions=True)[1].message
    else:
        assert safe_eval("a='b'", include_exceptions=True)[0] == "'b'"
        assert "invalid syntax" in safe_eval("a='b'", include_exceptions=True)[1].msg

    # these are just tests to make sure we cover all types

# Generated at 2022-06-21 07:57:39.882098
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:44.546046
# Unit test for function safe_eval

# Generated at 2022-06-21 07:57:54.383459
# Unit test for function safe_eval
def test_safe_eval():
    '''
    This is a test suite for the safe_eval function.
    '''

    def test(expr, expected_result):
        '''
        Executes the tests.
        :arg expr: An expression
        :arg expected_result: The expected result
        '''
        result = safe_eval(expr)
        if result != expected_result:
            s = "expr: %s, expected_result: %s, result: %s" % (expr, expected_result, result)
            raise AssertionError(s)

    test('[1,2,3]', [1,2,3])
    test('{"a":1,"b":2}', {"a":1, "b":2})
    test('(1,1,1)', (1,1,1))

# Generated at 2022-06-21 07:58:34.752476
# Unit test for function safe_eval
def test_safe_eval():
    # test 1: eval basic literals
    result = safe_eval('false')
    assert result == False
    result = safe_eval('true')
    assert result == True
    result = safe_eval('null')
    assert result is None
    result = safe_eval('5')
    assert result == 5
    result = safe_eval('5.5')
    assert result == 5.5
    result = safe_eval('[]')
    assert result == []
    result = safe_eval('"hello"')
    assert result == "hello"
    result = safe_eval('"hello world"')
    assert result == "hello world"
    result = safe_eval('{"a":5}')
    assert result == {"a":5}
    result = safe_eval('{"a":[1,2,3]}')

# Generated at 2022-06-21 07:58:44.766128
# Unit test for function safe_eval
def test_safe_eval():
    # test simple strings
    assert safe_eval('foo') == 'foo'
    assert safe_eval('{foo}') == '{foo}'
    assert safe_eval('{{foo}}') == '{{foo}}'
    # test atomic constants
    assert safe_eval('null') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('100') == 100
    assert safe_eval('1.5') == 1.5
    assert safe_eval('1.0e8') == 1.0e8
    # test math expressions
    assert safe_eval('2 + 2') == 4
    assert safe_eval('2 * 2') == 4
    assert safe_eval('4 - 2') == 2
    assert safe_eval('4 / 2') == 2.0 # float division

# Generated at 2022-06-21 07:58:56.333380
# Unit test for function safe_eval
def test_safe_eval():
    '''
    test safe_eval
    '''
    # test basic functionality
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    # test call disallowed if not enabled in globals
    assert safe_eval('max(1, 5)') == 'max(1, 5)'
    # test call allowed if enabled in globals
    assert safe_eval('max(1, 5)', {'max': max}) == 5
    # test safe_eval allows late evaluation [1].  note:
    # this should return 'max(1, 4)', not the evaluated result.
    assert safe_eval('max(1, 4)') == 'max(1, 4)'
    # test safe_eval allows late evaluation [2]

# Generated at 2022-06-21 07:59:07.320922
# Unit test for function safe_eval

# Generated at 2022-06-21 07:59:13.587071
# Unit test for function safe_eval
def test_safe_eval():
    locals = {'a_list_variable': [1,2,3]}

    assert safe_eval('a_list_variable', locals) == [1,2,3]
    assert safe_eval('a_list_variable') == 'a_list_variable'
    assert safe_eval('a_list_variable', {}, include_exceptions=True) == ('a_list_variable', None)
    assert safe_eval('{{a_list_variable}}', {}, include_exceptions=True) == ('{{a_list_variable}}', None)
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('["a", 2, 3]') == ['a', 2, 3]

# Generated at 2022-06-21 07:59:24.534152
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: test that valid expressions are evaluated correctly
    assert safe_eval("3 + 4") == 7
    assert safe_eval("3+4") == 7
    assert safe_eval("3 + 4 * 5") == 23
    assert safe_eval("(3 + 4) * 5") == 35
    assert safe_eval("5 - (3 + 4)") == -2
    assert safe_eval("12 / (3 + 4)") == 2
    assert safe_eval("-12/(3+4)") == -2
    assert safe_eval("3.5*2") == 7.0
    assert safe_eval("(3.5 + 4) * 2") == 14.0
    assert safe_eval("3.5 + 4 * 2") == 11.5

# Generated at 2022-06-21 07:59:34.726085
# Unit test for function safe_eval
def test_safe_eval():
    expr = '2+2'
    locals = {}
    expected = 4
    result = safe_eval(expr, locals)
    assert result == expected

    expr = '1+1'
    locals = {}
    expected = 2
    result = safe_eval(expr, locals)
    assert result == expected

    expr = "dict(a=[1,2,3], b=[1,2])"
    locals = {}
    expected = {'a': [1, 2, 3], 'b': [1, 2]}
    result = safe_eval(expr, locals)
    assert result == expected

    expr = "dict(a=dict(b=[1,2,3]),c=[1,2])"
    locals = {}

# Generated at 2022-06-21 07:59:46.458331
# Unit test for function safe_eval
def test_safe_eval():
    # simple list and dictionary should work
    assert safe_eval('([1,2], {"a":1})') == ([1, 2], {'a': 1})
    # simple math
    assert safe_eval('2*2') == 4
    # builtin functions are unavailable
    try:
        safe_eval('len([1,2])')
        raise Exception('should not have gotten here')
    except Exception as e:
        pass
    # we allow ``None`` and ``True`` and ``False``
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    # boolean operations are allowed
    assert safe_eval('((1 == 1) or (2 == 2))') is True

# Generated at 2022-06-21 07:59:56.801709
# Unit test for function safe_eval
def test_safe_eval():
    data = [
        # simple cases which should just work
        ("1", 1),
        ("-1", -1),
        ("~1", -2),
        ("[1, 2, 3]", [1, 2, 3]),
        ("{'foo': 'bar'}", {'foo': 'bar'}),
        ("null", None),
        ("false", False),
        ("true", True),
        ("True", True),
        ("False", False),
        ("None", None),
        ("[foo]", ['foo']),

        # a couple of bad cases
        ("True == False", "True == False"),
        ("null.foo()", "null.foo()"),
    ]

    for expr, expected_result in data:
        result = safe_eval(expr)

# Generated at 2022-06-21 08:00:09.576459
# Unit test for function safe_eval
def test_safe_eval():

    # Prefix with "e_" to distinguish expressions from results.
    #
    # These are invalid Python, but we should get the string back anyway.
    e_in_bad_python = [
        'foo-bar',
        '1 + 2 +',
        '1 + * 3',
        '()',
        '[] + ()',
    ]
    # These are valid Python, but not valid YAML.
    e_in_valid_python = [
        '{}',
        '[]',
        '[1, 2, 3]',
        '{"a": "b"}',
        '1 + 2',
        '1.0 / 2',
    ]
    # These are valid Python and valid YAML, but should not be evaluated.

# Generated at 2022-06-21 08:00:52.908924
# Unit test for function safe_eval