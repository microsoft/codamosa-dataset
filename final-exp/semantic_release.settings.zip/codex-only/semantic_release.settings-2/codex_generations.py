

# Generated at 2022-06-24 01:55:43.518358
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import changelog_components, changelog_components_v2

    config["changelog_components"] = "semantic_release.changelog.changelog_components"

    assert current_changelog_components() == changelog_components

    config["changelog_components"] = "semantic_release.changelog.changelog_components_v2"

    assert current_changelog_components() == changelog_components_v2

# Generated at 2022-06-24 01:55:47.802050
# Unit test for function overload_configuration
def test_overload_configuration():
    # define a dummy function
    def config_test():
        return config

    # let's change the configuration
    config_test_decorated = overload_configuration(config_test)
    config["test"] = 0
    assert config["test"] == 0
    config_test_decorated(define=["test=1"])
    assert config["test"] == 1

# Generated at 2022-06-24 01:55:51.750980
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components
    current_commits = current_changelog_components()

    assert len(current_commits) == len(
        semantic_release.changelog_components.changelog_components
    )



# Generated at 2022-06-24 01:55:52.902723
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []



# Generated at 2022-06-24 01:55:59.831350
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import format_changelog_components
    from semantic_release.utils import current_changelog_components

    config['changelog_components'] = 'semantic_release.changelog.changelog_components'
    assert current_changelog_components() == format_changelog_components

    config['changelog_components'] = 'semantic_release.changelog.changelog_components,semantic_release.changelog.changelog_components'
    assert current_changelog_components() == format_changelog_components+format_changelog_components


# Generated at 2022-06-24 01:56:05.712117
# Unit test for function overload_configuration
def test_overload_configuration():
    config["new-key"] = "old-value"

    @overload_configuration
    def overload_configuration_function(new_key):
        return new_key

    new_key = overload_configuration_function(new_key="new-value", define=["new-key=new-value"])
    assert new_key == config["new-key"] == "new-value"



# Generated at 2022-06-24 01:56:11.464846
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def _test_changelog_components_default():
        expected = ["semantic_release.changelog.components.removed",
                    "semantic_release.changelog.components.enhancement",
                    "semantic_release.changelog.components.bugfix",
                    "semantic_release.changelog.components.security",
                    "semantic_release.changelog.components.deprecated",
                    "semantic_release.changelog.components.documentation"]
        components = current_changelog_components()
        assert len(components) == 6
        for i in range(len(components)):
            assert components[i].__name__ == expected[i].split(".")[-1]


# Generated at 2022-06-24 01:56:12.879430
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])


# Generated at 2022-06-24 01:56:25.890679
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog

    def fake_parse_commit(commit: str) -> semantic_release.changelog.Commit:
        return semantic_release.changelog.Commit(commit, "fake")

    def fake_get_versioned_changelog(commits: List[str]) -> List[str]:
        return ["fake changelog"]

    def fake_get_unversioned_changelog(commits: List[str]) -> List[str]:
        return ["fake changelog"]

    def fake_get_versioned_commit_list(commits: List[str]) -> List[str]:
        return ["fake commits"]

    fake_parser = "test_helpers.fake_parse_commit"

# Generated at 2022-06-24 01:56:29.627639
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(*args, **kwargs):
        return kwargs

    assert len(foo(define=["foo=bar"])) == 1

# Generated at 2022-06-24 01:56:36.776473
# Unit test for function overload_configuration
def test_overload_configuration():
    # Tested function
    @overload_configuration
    def function_to_test(param1, param2=None):
        return param1, param2

    # Test 1: No parameter
    assert function_to_test("param") == ("param", None)
    # Test 2: One parameter in define
    assert function_to_test(
        "param", define=["before=after"]
    ) == ("param", None)
    assert config["before"] == "after"
    # Test 3: Two parameters in define
    assert function_to_test(
        "param", define=["before=after", "second=third"]
    ) == ("param", None)
    assert config["before"] == "after"
    assert config["second"] == "third"
    # Test 4: Second part with no =
    assert function_to_

# Generated at 2022-06-24 01:56:38.373892
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) > 0

# Generated at 2022-06-24 01:56:45.203449
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog

    # Test if the default changelog components are returned by default
    default_components = [
        changelog.components.commit_log,
        changelog.components.pr_template,
    ]
    assert current_changelog_components() == default_components

    # Test if a valid list of components are returned when requested
    components = [
        changelog.components.commit_log,
        changelog.components.issue_template,
    ]
    config["changelog_components"] = "semantic_release.changelog.components.commit_log,semantic_release.changelog.components.issue_template"
    assert current_changelog_components() == components

    # Test if the default changelog components are returned when the configuration

# Generated at 2022-06-24 01:56:46.948423
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass
    else:
        assert False



# Generated at 2022-06-24 01:56:49.542062
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Verifies that the default parser is returned when a parser is not configured
    """
    config.clear()
    from semantic_release.history import parse_commits

    assert current_commit_parser() == parse_commits


# Generated at 2022-06-24 01:56:53.073417
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli as cli

    @overload_configuration
    def test_func(**kwargs):
        return kwargs

    kwargs = {"define": ["foo=bar"]}
    assert config.get("foo") == "bar"
    kwargs = {"define": ["foo=foo"]}
    assert config.get("foo") == "foo"
    assert test_func(**kwargs) == kwargs

# Generated at 2022-06-24 01:56:56.493825
# Unit test for function current_changelog_components
def test_current_changelog_components():
    test_config = UserDict({'changelog_components': 'path.to.changelog_components'})
    assert current_changelog_components(config = test_config) == ['path.to.changelog_components']


# Generated at 2022-06-24 01:56:58.783366
# Unit test for function current_changelog_components
def test_current_changelog_components():
    changelog_components_list = current_changelog_components()
    assert changelog_components_list[0] == pre_release_body

# Generated at 2022-06-24 01:57:03.170654
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components
    changelog_components = current_changelog_components()

    assert len(changelog_components) == 1
    assert isinstance(changelog_components[0], Callable)
    assert changelog_components[0].__name__ ==\
        semantic_release.changelog_components.tag_names.__name__


# Generated at 2022-06-24 01:57:08.179323
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the config object is correctly modified by the decorator."""
    load = overload_configuration(lambda x: x)
    load(define=["variable=value"])
    assert config["variable"] == "value"

# Generated at 2022-06-24 01:57:12.589548
# Unit test for function overload_configuration
def test_overload_configuration():
    config["version.suffix"] = "dev"
    @overload_configuration
    def myfunc(define):
        print(config["version.suffix"])
        return define

    assert myfunc(define=["version.suffix=test"]) == ["version.suffix=test"]
    assert config["version.suffix"] == "test"

# Generated at 2022-06-24 01:57:13.712456
# Unit test for function current_commit_parser
def test_current_commit_parser():  # pragma: no cover
    print(current_commit_parser())



# Generated at 2022-06-24 01:57:25.010810
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import write_changelog
    from .commit_parser import parse_commits
    from .components import IssueUrl, UserUrl
    from .components.title import Title
    from .components.body import Body
    from .components.footer import Footer

    assert current_changelog_components() == [
        Title(),
        IssueUrl(),
        UserUrl(),
        Body(),
        Footer(),
    ]

    changelog_components = "semantic_release.components.title.Title"

    config["changelog_components"] = changelog_components
    assert current_changelog_components() == [Title()]

    changelog_components = "semantic_release.components.title.Title,semantic_release.components.body.Body"

# Generated at 2022-06-24 01:57:34.496369
# Unit test for function overload_configuration
def test_overload_configuration():
    def wrapped_function(arg1, arg2, define=None):
        return arg1 + arg2

    wrapped_function = overload_configuration(wrapped_function)

    # Check that no changes occur when no define is given
    assert wrapped_function(1, 2) == 3
    assert wrapped_function(1, 2, []) == 3
    assert wrapped_function(1, 2, ["key=value"]) == 3

    # Check the changes when a define is given
    assert wrapped_function(1, 2, ["foo=bar"]) == 3
    assert config["foo"] == "bar"
    assert wrapped_function(1, 2, ["foo=bar", "baz=qux"]) == 3
    assert config["foo"] == "bar"
    assert config["baz"] == "qux"

# Generated at 2022-06-24 01:57:38.623053
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(define):
        return config["version"]

    func = overload_configuration(func)
    config["version"] = "0.0.0"
    assert func(define="version=0.0.1") == "0.0.1"

# Generated at 2022-06-24 01:57:48.017948
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli as cli
    cli.config["check_build_status"] = False
    cli.config["upload_to_pypi"] = False
    cli.config["upload_to_release"] = False
    cli.config["remove_dist"] = False
    cli.config["patch_without_tag"] = False
    cli.config["commits_output_path"] = "commits.csv"
    cli.config["changelog_output_path"] = "CHANGELOG.md"

# Generated at 2022-06-24 01:57:49.538450
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_parser

    assert default_parser == current_commit_parser()

# Generated at 2022-06-24 01:57:55.727123
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config["major_on_zero"] == True

    @overload_configuration
    def test_method(define="major_on_zero=False"):
        assert config["major_on_zero"] == False

    @overload_configuration
    def test_method2(define=["major_on_zero=False"]):
        assert config["major_on_zero"] == False

    test_method()
    test_method2()

# Generated at 2022-06-24 01:58:02.595668
# Unit test for function overload_configuration
def test_overload_configuration():
    result_config = _config()
    assert config == result_config
    current_value = config["version_variable"]
    new_value = "this_is_a_new_value"
    assert new_value != current_value

    @overload_configuration
    def test_function(*, define):
        pass

    # Test overload with a new key/value
    test_function(define=["new_key=new_value"])
    result_config["new_key"] = "new_value"
    assert config == result_config

    # Test overload with an existing key/value
    test_function(define=[f"version_variable={new_value}"])
    result_config["version_variable"] = new_value
    assert config == result_config

# Generated at 2022-06-24 01:58:07.065522
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser().__name__ == "default_parser"


# Generated at 2022-06-24 01:58:13.051912
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # GIVEN
    # dummy changelog components
    config['changelog_components'] = "tests.test_config.dummy_changelog_component"

    # WHEN
    components = current_changelog_components()

    # THEN
    assert len(components) == 1
    assert components[0] == dummy_changelog_component



# Generated at 2022-06-24 01:58:18.139797
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(one, two, three, *args, **kwargs):
        return (one, two, three, args, kwargs)
    assert test_func(1, 2, 3) == (1, 2, 3, (), {})
    assert test_func(1, 2, 3, define=["a=b"]) == (1, 2, 3, (), {"define": ["a=b"]})
    assert config["a"] == "b"

    assert test_func(1, 2, 3, define=["a=c"]) == (1, 2, 3, (), {"define": ["a=c"]})
    assert config["a"] == "c"

# Generated at 2022-06-24 01:58:19.794196
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None



# Generated at 2022-06-24 01:58:23.155381
# Unit test for function current_commit_parser
def test_current_commit_parser():
    _config.get = lambda *args, **kwargs: {"commit_parser": "semantic_release.commit_parser.parse"}
    parser = current_commit_parser()
    assert repr(parser) == repr(parse)


# Generated at 2022-06-24 01:58:27.927990
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.BreakingChanges"
    assert isinstance(current_changelog_components()[0](), Callable)



# Generated at 2022-06-24 01:58:32.449616
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # This function does not raise any error when the configuration is correct
    assert current_changelog_components()
    # This function raise an error when the configuration is incorrect
    config["changelog_components"] = "toto.tata"
    try:
        current_changelog_components()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 01:58:36.783687
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        current_changelog_components()
        == [
            'semantic_release.changelog.components._append_summary',
            'semantic_release.changelog.components._append_issues',
        ]
    )

# Generated at 2022-06-24 01:58:39.372338
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.changelog_components.changelog_sections"
    components = current_changelog_components()
    assert components[0].__name__ == "changelog_sections"



# Generated at 2022-06-24 01:58:41.952078
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 01:58:43.010799
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import changelog_components
    assert current_changelog_components() == changelog_components()

# Generated at 2022-06-24 01:58:48.160962
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_generator.before_deploy.Header"
    assert len(current_changelog_components()) == 1

    config["changelog_components"] = "semantic_release.changelog_generator.before_deploy.Header,semantic_release.changelog_generator.before_deploy.Changelog"
    assert len(current_changelog_components()) == 2

    config["changelog_components"] = ""
    assert len(current_changelog_components()) == 0



# Generated at 2022-06-24 01:58:56.364935
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # default configuration
    assert current_changelog_components() == [
        'semantic_release.changelog.components.ChangelogBody',
        'semantic_release.changelog.components.ChangelogCommitHash',
        'semantic_release.changelog.components.ChangelogCommitMessage',
        'semantic_release.changelog.components.ChangelogHeader',
    ]

    # custom configuration
    prev_config = config['changelog_components']
    config['changelog_components'] = 'a.b.c.d,e.f.g.h,i.j.k.l'

# Generated at 2022-06-24 01:58:58.397043
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert config.get('changelog_components') is not None

    current_changelog_components()



# Generated at 2022-06-24 01:59:01.242464
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.default"
    assert current_commit_parser()(
        "feat(module): this is a commit message", "semantic_release"
    ) == (
        "Semantic Release config file was not found. Using default."
        " Please create a 'setup.cfg' file in the root of your project"
        " and use the default config file available in this package as template."
    )

# Generated at 2022-06-24 01:59:09.231722
# Unit test for function overload_configuration
def test_overload_configuration():
    def a_function(a, b=3, define=["a=42", "b=True"]):
        assert a == 42, "should be 42"
        assert b is True, "should be True"

    a_function = overload_configuration(a_function)

    test_conf = {"a": 1, "b": False}
    a_function.__globals__["config"] = test_conf
    a_function(2)

    assert test_conf["a"] == 42, "should be 42"
    assert test_conf["b"] is True, "should be True"

# Generated at 2022-06-24 01:59:13.190099
# Unit test for function current_changelog_components
def test_current_changelog_components():
    test_config_ini = """
[tool.semantic_release]
changelog_components=semantic_release.changelog.components.breaking_change,
                      semantic_release.changelog.components.feature,
                      semantic_release.changelog.components.fixes
"""
    parser = configparser.ConfigParser()
    parser.read_string(test_config_ini)
    assert current_changelog_components(parser) == [
        semantic_release.changelog.components.breaking_change,
        semantic_release.changelog.components.feature,
        semantic_release.changelog.components.fixes,
    ]

# Generated at 2022-06-24 01:59:20.615997
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser()
        == importlib.import_module("semantic_release.commit_parser").parse
    )
    # Configure a different parser
    config["commit_parser"] = "semantic_release.commit_parser.parse"
    assert (
        current_commit_parser()
        == importlib.import_module("semantic_release.commit_parser").parse
    )

# Generated at 2022-06-24 01:59:27.095278
# Unit test for function overload_configuration
def test_overload_configuration():
    def check_config(define):
        if key in config:
            return config[key] == value
        return False

    key = "MASTER_BRANCH"
    value = "dev"
    overload_configuration(lambda: 0)(define=[f"{key}={value}"])

    assert check_config(define=[f"{key}={value}"]), "Configuration must be overloaded"

# Generated at 2022-06-24 01:59:36.489498
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from pathlib import Path
    from .changelog_components import GitModel, Version

    test_path = Path(os.path.dirname(__file__)) / "pyproject.toml"
    with open(test_path, "r") as f:
        test_pyproject = tomlkit.loads(f.read())
    # Check the user define a changelog_components list
    test_pyproject["tool"]["semantic_release"]["changelog_components"] = (
        "semantic_release.changelog_components.Version,semantic_release.changelog_components.GitModel"
    )
    with open(test_path, "w") as f:
        f.write(tomlkit.dumps(test_pyproject))

    assert current_changelog

# Generated at 2022-06-24 01:59:41.879240
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = {
        "changelog_components": "changelog_components.comp1,changelog_components.comp2",
        "commit_parser": "commit_parser.parser",
        "changelog_parser": "changelog_parser.parser",
    }

    @overload_configuration
    def method(define):
        return config

    assert method(define=["changelog_components=changelog_components.comp3"]) == {
        "changelog_components": "changelog_components.comp3",
        "commit_parser": "commit_parser.parser",
        "changelog_parser": "changelog_parser.parser",
    }

# Generated at 2022-06-24 01:59:50.823383
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.components import (
        CommitMessageParser,
        IssueCommitMessageParser,
        PullRequestCommitMessageParser,
    )

    config["changelog_components"] = ",".join(
        [
            "semantic_release.components.CommitMessageParser",
            "semantic_release.components.IssueCommitMessageParser",
            "semantic_release.components.PullRequestCommitMessageParser",
        ]
    )

    assert current_changelog_components() == [
        CommitMessageParser,
        IssueCommitMessageParser,
        PullRequestCommitMessageParser,
    ]

# Generated at 2022-06-24 01:59:56.111161
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def ret():
        return config

    assert ret()["dry_run"] == False
    assert ret(define=["dry_run"])["dry_run"] == True
    assert ret(define=["dry_run="])["dry_run"] == ""
    assert ret(define=["dry_run=False"])["dry_run"] == "False"
    assert ret(define=["dry_run=False", "commit_parser=test"])[
              "commit_parser"] == "test"

# Generated at 2022-06-24 01:59:59.804078
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test that current_commit_parser() is returning the correct component."""
    current_commit_parser()

# Generated at 2022-06-24 02:00:08.227866
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the decorator by simulating an environment in which "define" is passed
    as an argument.
    """
    @overload_configuration
    def say_my_name(define):
        return config["name"]

    say_my_name(define=["name=John"])
    assert config["name"] == "John"
    say_my_name(define=["name=Paul"])
    assert config["name"] == "Paul"

# Generated at 2022-06-24 02:00:13.745851
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = {"a": 1, "b": 2}
    assert config["a"] == 1
    assert config["b"] == 2

    @overload_configuration
    def f(**kwargs):
        pass

    f(define=["a=2"])
    assert config["a"] == "2"
    assert config["b"] == 2

# Generated at 2022-06-24 02:00:18.023743
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test with error raise
    config["changelog_components"] = "InvalidInput"
    with pytest.raises(ImproperConfigurationError):
        current_changelog_components()

    # Test with a valid input
    config["changelog_components"] = "semantic_release.changelog_components.get_commits_data"
    assert current_changelog_components()[0] == get_commits_data

# Generated at 2022-06-24 02:00:20.022480
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .current_changelog_components import fake_changelog_component

    fake_content = "fake content"

    return fake_content

# Generated at 2022-06-24 02:00:30.498574
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration"""

    def overload_configuration_no_args():
        return config

    def overload_configuration_with_args(define):
        return config

    # overwrite overcommit_version
    overloaded_config = overload_configuration(overload_configuration_no_args)()
    assert overloaded_config["overcommit_version"] == "0.42.0"
    assert overloaded_config["overcommit_hooks"] == "true"

    # overwrite overcommit_version and overcommit_hooks
    overloaded_config = overload_configuration(
        overload_configuration_with_args
    )(define=["overcommit_version=0.43.0", "overcommit_hooks=true"])
    assert overloaded_config["overcommit_version"] == "0.43.0"
    assert overloaded_config

# Generated at 2022-06-24 02:00:33.233099
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # If a configuration error happens, the function should raise
    # ImproperConfigurationError
    assert current_changelog_components() == [
        semantic_release.changelog.components.base.components
    ]



# Generated at 2022-06-24 02:00:37.889442
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    """
    config.get = lambda key: "test"
    @overload_configuration
    def test_function():
        assert config["test_key"] == "test_value"
        assert config["test_key_2"] == "test_value_2"

    test_function(define=["test_key=test_value", "test_key_2=test_value_2"])

# Generated at 2022-06-24 02:00:45.917565
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release
    import pkg_resources
    dist = pkg_resources.get_distribution(semantic_release.__name__)
    semantic_release_path = os.path.dirname(dist.location)
    # Change folder to the semantic_release folder
    os.chdir(semantic_release_path)

    changelog_components = current_changelog_components()

    for changelog_component in changelog_components:
        assert hasattr(changelog_component, "__call__")



# Generated at 2022-06-24 02:00:55.688906
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # define a fake component
    def component(): 
        pass
    
    # config file
    setup_cfg_path = "setup.cfg"

    # save actual setup.cfg
    with open(setup_cfg_path, "r") as fo:
        setup_cfg_content = fo.read()
 
    # write a fake config
    fake_config = """[semantic_release]
changelog_components=path.component"""
    with open(setup_cfg_path, "w") as fo:
        fo.write(fake_config)

    # define component in the config
    config = _config()
    components = current_changelog_components()
    assert "component" == components[0].__name__
    
    # remove the fake config

# Generated at 2022-06-24 02:01:01.444358
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This function tests the overload_configuration function.
    """
    @overload_configuration
    def add(a, b):
        """
        Simple function adding two values.
        """
        return a + b

    assert add(2, 3) == 5
    assert add(2, b=3) == 5
    assert add(a=2, b=3) == 5
    assert add(2, 3, define=["a=1", "b=2"]) == 3
    assert add(2, 3, define=["a=4", "b=5"]) == 9

# Generated at 2022-06-24 02:01:05.423141
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelogs.components.changes
    import semantic_release.changelogs.components.contributors

    assert current_changelog_components() == [
        semantic_release.changelogs.components.contributors.contributors,
        semantic_release.changelogs.components.changes.changes,
    ]

# Generated at 2022-06-24 02:01:08.851026
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commits

    assert current_commit_parser() is parse_commits



# Generated at 2022-06-24 02:01:19.740005
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test with a good example
    config["changelog_components"] = "semantic_release.changelog.components.issue_component, semantic_release.changelog.components.scope_component"
    assert len(current_changelog_components()) == 2

    # Test with an inexistant module
    config["changelog_components"] = "semantic_release.changelog.components.bad_module"
    try:
        current_changelog_components()
        assert False
    except:
        assert True

    # Test with an inexistant function
    config["changelog_components"] = "semantic_release.changelog.components.issue_component, semantic_release.changelog.components.bad_component"

# Generated at 2022-06-24 02:01:23.137994
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(define):
        return define

    assert test_func(["a=b"]) == ["a=b"]

    wrapped_func = overload_configuration(test_func)
    assert wrapped_func(["a=b"]) == ["a=b"]
    assert config["a"] == "b"

# Generated at 2022-06-24 02:01:28.565091
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_entry"] = "test_value"
    @overload_configuration
    def func(define=None):
        if define:
            print(config["test_entry"])
        else:
            raise Exception()
    try:
        func()
    except Exception:
        print("Correct Exception")
    else:
        raise Exception()
    print(config["test_entry"])
    func(define=["test_entry=overloaded_value"])
    print(config["test_entry"])

# Generated at 2022-06-24 02:01:33.301443
# Unit test for function overload_configuration
def test_overload_configuration():
    config_to_test = _config()

    @overload_configuration
    def test_func(define=None):
        test_func.__globals__["config"]["new_variable"] = "new_value"

    # Test with no arguments
    test_func()
    assert config_to_test.get("new_variable") == "new_value"

    # Test with arguments
    test_func(define=["define_this=value_with_space", "define_that=value_no_space"])
    assert config_to_test.get("define_this") == "value_with_space"
    assert config_to_test.get("define_that") == "value_no_space"

# Generated at 2022-06-24 02:01:37.420918
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components as cc  # noqa
    import semantic_release.plugins.changelog_components.title as title  # noqa

    components = current_changelog_components()
    assert components == [cc.title]

# Generated at 2022-06-24 02:01:39.818359
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(define):
        return define

    define = ["backend=silly"]
    assert foo(define=define) == define

# Generated at 2022-06-24 02:01:41.919848
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser is not None
    assert callable(parser)



# Generated at 2022-06-24 02:01:43.880321
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.versions import find_next_version
    # We want to override the value of changelog_filename
    config["changelog_filename"] = "test_file"
    assert find_next_version(patch_without_tag=True, define=["changelog_filename=new_file"]) == "new_file"

# Generated at 2022-06-24 02:01:51.036891
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("commit_parser") == "semantic_release.commit_parser"

    @overload_configuration
    def test_function(define):
        pass

    # The function has side effects and modifies the global config
    test_function(define=["commit_parser=mock_parser"])
    assert config.get("commit_parser") == "mock_parser"

# Generated at 2022-06-24 02:01:55.824642
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        current_changelog_components()
        == [
            semantic_release.changelog.changelog.change_type,
            semantic_release.changelog.changelog.commit_title,
            semantic_release.changelog.changelog.issues_closed,
            semantic_release.changelog.changelog.merge_requests_merged,
            semantic_release.changelog.changelog.impact_label,
            semantic_release.changelog.changelog.commit_hash,
            semantic_release.changelog.changelog.commit_author,
            semantic_release.changelog.changelog.commit_date,
        ]
    )

# Generated at 2022-06-24 02:02:03.143506
# Unit test for function overload_configuration
def test_overload_configuration():  # pragma: no cover
    from semantic_release.cli import parse_args

    def func(a, b=2):
        return a + b

    @overload_configuration
    def func_wrapped(a, b=2):
        return a + b

    args = parse_args(["--define", "a=5", "--define", "b=10", "1", "2", "3"])
    assert func_wrapped(*args.args, **args.kwargs) == 15

# Generated at 2022-06-24 02:02:07.797115
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert components == [], "the list must be empty"

# Generated at 2022-06-24 02:02:14.493720
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test that the current_changelog_components function return a list of
    changelog components"""
    from semantic_release.changelog import changelog_components  # noqa
    from semantic_release.changes import get_changes  # noqa

    # Check that the function return a list of changelog components
    assert current_changelog_components() == [
        changelog_components.check_build_status,
        changelog_components.get_issues,
        changelog_components.get_releases,
        get_changes,
    ]

# Generated at 2022-06-24 02:02:20.620060
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(bar):
        return bar

    assert config["commit_parser"] == "semantic_release.commit_parser"
    assert config["changelog_components"] == (
        "semantic_release.changelog.components.components"
    )

    foo("spam", define=["commit_parser=foo.bar", "changelog_components=foo.components"])
    assert config["commit_parser"] == "foo.bar"
    assert config["changelog_components"] == "foo.components"

# Generated at 2022-06-24 02:02:31.749187
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration in util.py."""
    # Initial state
    assert config.get("changelog_filename") == "CHANGELOG.rst"
    assert config.get("changelog_components") == "release.components.changelog_components"
    assert config.get("commit_parser") == "semantic_release.commit_parser.parse"
    assert config.get("pre_tag_hook") == "semantic_release.hooks.pre_tag_hook"
    assert config.get("post_tag_hook") == "semantic_release.hooks.post_tag_hook"
    assert config.get("post_version_hook") == "semantic_release.hooks.post_version_hook"

    # Set up for empty test

# Generated at 2022-06-24 02:02:35.071635
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import UnreleasedComponent, CommitNotesComponent
    assert current_changelog_components() == [UnreleasedComponent,
                                              CommitNotesComponent]

# Generated at 2022-06-24 02:02:37.600576
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return 0

    test_function(define=["my_key=my_value"])
    assert config["my_key"] == "my_value"

# Generated at 2022-06-24 02:02:39.391072
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import version_from_commit

    assert current_commit_parser() == version_from_commit



# Generated at 2022-06-24 02:02:40.863136
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commits

    assert current_commit_parser() == parse_commits

# Generated at 2022-06-24 02:02:47.956368
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Without error
    current_commit_parser()

    # With error
    config["commit_parser"] = "semantic_release.commit_parser.not_a_parser"
    try:
        current_commit_parser()
    except ImproperConfigurationError as e:
        assert e.args[0] == 'Unable to import parser "No module named "\'semantic_release.commit_parser.not_a_parser\'"'

# Generated at 2022-06-24 02:02:51.196894
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    assert config["check_build_status"]

    @overload_configuration
    def wrapper(define):
        pass

    wrapper(define=["check_build_status=false"])
    assert not con

# Generated at 2022-06-24 02:02:53.335291
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser.__name__ == "default_parser"



# Generated at 2022-06-24 02:02:59.956317
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert "changelog_components" not in config, "changelog_components should not be in config"
    assert current_changelog_components() == [], 'default current_changelog_components should be an empty list'
    config["changelog_components"] = "semantic_release.changelog.components.parse_issues"
    assert current_changelog_components()[0] == "semantic_release.changelog.components.parse_issues"

# Generated at 2022-06-24 02:03:04.518094
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Function tests that current_changelog_components returns a list of functions
    """
    components = current_changelog_components()
    assert isinstance(components, list)
    functions = [callable(x) for x in components]
    assert all(functions)

# Generated at 2022-06-24 02:03:07.156006
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # We simulate a semantic_release set in setup.cfg
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"

    assert current_commit_parser() == parse_commit

# Generated at 2022-06-24 02:03:09.442907
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser:parse"
    parser = current_commit_parser()
    assert parser.__name__ == "parse"



# Generated at 2022-06-24 02:03:13.129824
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_message
    from semantic_release.config import config
    config["commit_parser"] = "semantic_release.commit_parser.parse_message"
    assert current_commit_parser() == parse_message



# Generated at 2022-06-24 02:03:19.367405
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.get_current_version,
        semantic_release.changelog.components.get_commits,
        semantic_release.changelog.components.build_header,
        semantic_release.changelog.components.commitize,
    ]

# Generated at 2022-06-24 02:03:23.514835
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """ Test of the function current_changelog_components
    """
    from .component import changelog_components
    _config()["changelog_components"] = (
        "semantic_release.changelog_components.components.default"
    )
    res = current_changelog_components()
    assert res == changelog_components()



# Generated at 2022-06-24 02:03:29.804559
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_edit_config(*args, **kwargs):
        return "config" in kwargs, kwargs

    config["test_1"] = "test_value_1"
    assert test_edit_config(define=["test_1=new_value_1"]) == (False, {})
    assert config["test_1"] == "new_value_1"

    assert test_edit_config(define=["test_2=new_value_2"]) == (False, {})
    assert config["test_2"] == "new_value_2"

    config["test_3"] = "test_value_3"
    assert test_edit_config(config=config, define=["test_3=new_value_3"]) == (True, config)

# Generated at 2022-06-24 02:03:32.149553
# Unit test for function current_changelog_components
def test_current_changelog_components():
    pass

# Generated at 2022-06-24 02:03:38.163687
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.commit_author,semantic_release.changelog.components.commit_summary"
    components = current_changelog_components()
    assert components[0]({"author": "John Doe"}) == "John Doe"
    assert components[1]({"summary": "Hello World!"}) == "Hello World!"

# Generated at 2022-06-24 02:03:42.633534
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Unit test for function current_commit_parser
    """
    import semantic_release  # For release_type
    import tests.parser  # For commit_parser

    result = current_commit_parser()
    assert result == tests.parser.commit_parser
    assert semantic_release.release_type() == "patch"


# Generated at 2022-06-24 02:03:46.308770
# Unit test for function current_commit_parser
def test_current_commit_parser():
    call = current_commit_parser()
    assert call is not None
    assert call == config.get("commit_parser")


# Generated at 2022-06-24 02:03:52.329114
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Arrange
    import semantic_release.commit_parser
    from semantic_release.commands.command import BaseCommand
    from semantic_release.hvcs import git
    from semantic_release.changelog import changelog
    from semantic_release.settings import init_config

    # Act
    hvcs_service_mock = git.GitService(config)
    init_config(override={
        'changelog_parser': False,
        'changelog_generator': False,
        'commit_parser': 'semantic_release.commit_parser.parse_commits'
    })
    commit_parser = current_commit_parser()
    cl_components = current_changelog_components()

# Generated at 2022-06-24 02:03:55.924554
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    >>> @overload_configuration
    ... def _(define=[]):
    ...     pass
    >>> _(define=['foo=bar'])
    >>> config['foo']
    'bar'
    """

# Generated at 2022-06-24 02:04:03.400956
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def test_component_one():
        pass

    def test_component_two():
        pass

    @overload_configuration
    def test_function(define):
        pass

    test_function(define=["changelog_components=tests.unit.test_helpers.test_component_one,tests.unit.test_helpers.test_component_two"])
    assert test_function == current_changelog_components()[0]
    assert test_function == current_changelog_components()[1]

# Generated at 2022-06-24 02:04:06.497308
# Unit test for function current_commit_parser
def test_current_commit_parser():
    expected_parser = config.get("commit_parser")
    assert expected_parser == current_commit_parser()

# Generated at 2022-06-24 02:04:08.754826
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_version

    @overload_configuration
    def get_version():
        return semantic_version.Version.coerce(config["version"])

    try:
        version = get_version(define=["version=3.0.0-alpha.1"])
        assert version.major == 3
    except ImproperConfigurationError:
        assert False, "Unable to get the version"

# Generated at 2022-06-24 02:04:15.640938
# Unit test for function overload_configuration
def test_overload_configuration():
    """This is a "classic" test to ensure that the decorator overload_configuration
    works as expected.
    """

    global config

    # Manually override the configuration
    config["commit_parser"] = "semantic_release.commit_parser.my_parser"

    @overload_configuration
    def function(param):
        global config
        return config.get(param)

    assert function("commit_parser") == "semantic_release.commit_parser.my_parser"

    # Change the configuration with the decorator
    assert function("commit_parser", define=["commit_parser=parser.parse"]) == "parser.parse"
    assert config.get("commit_parser") == "parser.parse"

# Generated at 2022-06-24 02:04:20.395991
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()

    @overload_configuration
    def update_dict(define: list):
        pass

    update_dict(define=["key1=value1"])
    assert config["key1"] == "value1"

    update_dict(define=["key1=value1", "key2=value2"])
    assert config["key2"] == "value2"

# Generated at 2022-06-24 02:04:27.296385
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import get_changelog_components

    # We can't directly modify the config dictionary, so let's temporarily
    # overwrite its .get() method to return a value different from the
    # configuration file
    config.get = lambda _: "semantic_release.changelog.get_current_changelog"

    # current_changelog_components() must return the same result as
    # get_changelog_components()
    assert current_changelog_components() == get_changelog_components()



# Generated at 2022-06-24 02:04:29.196427
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components

    assert current_changelog_components() == changelog_components

# Generated at 2022-06-24 02:04:37.246111
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

    @overload_configuration
    def test(define=[]):
        pass

    config["my_key"] = "my_value"
    test("my_key=my_other_value")
    assert config["my_key"] == "my_other_value"
    test("my_new_key=my_new_value")
    assert config["my_new_key"] == "my_new_value"

# Generated at 2022-06-24 02:04:39.341256
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:04:42.878493
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def overload_configuration_func(define=None):
        return None
    conf = config.copy()
    conf["a"] = "b"
    conf["c"] = "d"
    overload_configuration_func(define=["a=b", "c=d"])
    assert config == conf

# Generated at 2022-06-24 02:04:45.857849
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.update({'changelog_components': 'semantic_release.changelog.components.breaking_change, semantic_release.changelog.components.feature'})
    from semantic_release.changelog import components
    assert current_changelog_components() == [components.breaking_change, components.feature]


# Generated at 2022-06-24 02:04:54.374115
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=[]):
        pass

    # set configuration to default value
    config["name"] = "my project"

    # test
    test_function(define=["name=my other project"])
    assert config["name"] == "my other project"

    # test
    test_function(define=["name=my other project", "version=1.0.0"])
    assert config["name"] == "my other project"
    assert config["version"] == "1.0.0"

    # test
    test_function(define=["name"])
    assert config["name"] == "my other project"

# Generated at 2022-06-24 02:05:03.329973
# Unit test for function current_changelog_components
def test_current_changelog_components():

    # Test when the config["changelog_components"] is empty
    config["changelog_components"] = ""
    assert [] == current_changelog_components()

    # Test when the config["changelog_components"] has only one value
    config["changelog_components"] = "semantic_release.changelog.pre_release_notes_component"
    assert len(current_changelog_components()) == 1
    assert (
        current_changelog_components()[0]
        == semantic_release.changelog.pre_release_notes_component
    )

    # Test when the config["changelog_components"] has two values

# Generated at 2022-06-24 02:05:08.954278
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the current_commit_parser function when it finds the correct
    function and when it doesn't find the function.
    """
    assert callable(current_commit_parser())

    config["commit_parser"] = "wrong.function"
    try:
        current_commit_parser()
        assert False
    except ImproperConfigurationError:
        assert True



# Generated at 2022-06-24 02:05:11.165097
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commits

    assert current_commit_parser() == parse_commits



# Generated at 2022-06-24 02:05:18.395374
# Unit test for function overload_configuration
def test_overload_configuration():
    # Defining a function to test
    @overload_configuration
    def function(a, b, **kwargs):
        return a + b

    function(1, 2)
    assert config["define"] == []
    function(1, 2, define=["a"])
    assert config["define"] == []
    function(1, 2, define=["new=setting"])
    assert config["new"] == "setting"



# Generated at 2022-06-24 02:05:22.430063
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        changelog.section_type,
        changelog.breaking_changes,
        changelog.features,
        changelog.bug_fixes,
        changelog.misc,
    ]

# Generated at 2022-06-24 02:05:24.685990
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 3

# Generated at 2022-06-24 02:05:26.426395
# Unit test for function overload_configuration
def test_overload_configuration():
    from .fixtures.overload_configuration import test_config
    assert test_config["test"] == "config"

# Generated at 2022-06-24 02:05:32.684939
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.tests.changelog_components import Header, Footer
    config['changelog_components'] = "semantic_release.tests.changelog_components.Header,semantic_release.tests.changelog_components.Footer"
    components = current_changelog_components()

    assert components[0] == Header
    assert components[1] == Footer


# Generated at 2022-06-24 02:05:42.480348
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.hooks

    # Test when changelog_components is not set
    assert current_changelog_components() == []

    config["changelog_components"] = "semantic_release.hooks.changelog_components_template"

    # Test when changelog_components is set to a non existing class
    config["changelog_components"] = "does.not.exist"
    try:
        current_changelog_components()
    except ImproperConfigurationError:
        pass
    except Exception:
        assert False, "Should have raised 'ImproperConfigurationError'"

    # Test when changelog_components is set
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == semantic_release.hooks