

# Generated at 2022-06-24 01:55:53.473180
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog

    # Test failure
    with pytest.raises(ImproperConfigurationError):
        config["changelog_components"] = "does.not.exist"
        current_changelog_components()

    # Test success
    config["changelog_components"] = "semantic_release.changelog.components.format_release"
    assert current_changelog_components() == [changelog.format_release]
    # Test success
    config["changelog_components"] = "semantic_release.changelog.components.format_release,semantic_release.changelog.components.substitute_dashes"

# Generated at 2022-06-24 01:55:55.966694
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser

    with overload_configuration:
        commit_parser = current_commit_parser()

    assert commit_parser == semantic_release.commit_parser.parse_message

# Generated at 2022-06-24 01:56:00.180003
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def print_config(**kwargs):
        return config

    assert {"key": "value"} == print_config(define=["key=value"])

# Generated at 2022-06-24 01:56:08.110551
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Simple case
    assert "commits_parser" == current_commit_parser().__name__
    # Overload case
    current_commit_parser = overload_configuration(current_commit_parser)
    config["commit_parser"] = "semantic_release.test_commit.test_parser"
    assert test_parser == current_commit_parser(define=["commit_parser=test"])()


# Overload "config" for tests
config["commit_parser"] = "semantic_release.test_commit.test_parser"
config["changelog_components"] = "semantic_release.test_commit.test_component"



# Generated at 2022-06-24 01:56:12.464730
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """It should get the current parser based on config"""
    fake_parser = lambda *args, **kwargs: None
    config['commit_parser'] = 'tests.helpers.test_helpers.fake_parser'

    assert current_commit_parser() == fake_parser

# Generated at 2022-06-24 01:56:15.882238
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        current_changelog_components()
        == [
            "semantic_release.changelog.components.get_git_authors",
            "semantic_release.changelog.components.get_git_commits",
        ]
    )



# Generated at 2022-06-24 01:56:19.955790
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test for current_commit_parser function

    :raises AssertionError: if the function raised an exception or the returned value is not correct
    """
    try:
        assert current_commit_parser() is not None
    except ImproperConfigurationError:
        assert False

# Generated at 2022-06-24 01:56:26.717730
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelogs import default
    from semantic_release.changelogs.bitbucket import bitbucket_pr
    from semantic_release.changelogs.github import github_pr
    from semantic_release.changelogs.gitlab import gitlab_mr

    components = current_changelog_components()
    assert len(components) == 4
    assert default in components
    assert bitbucket_pr in components
    assert github_pr in components
    assert gitlab_mr in components

# Generated at 2022-06-24 01:56:28.224570
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert "commit_parser" in config
    assert callable(current_commit_parser())

# Generated at 2022-06-24 01:56:38.574129
# Unit test for function overload_configuration
def test_overload_configuration():
    # Define a mock function to apply the decorator on
    @overload_configuration
    def mock_function(a, b, define=[]):
        return a, b, config
    
    # Test with one pair of key/value
    config["foo"] = "bar"
    assert mock_function(a=1, b=2, define=["foo=spam"]) == (1, 2, {"foo": "spam"})
    assert config["foo"] == "bar"  # It should not be changed in config
    
    # Reset config
    config.data = {}
    
    # Test with multiple pairs of key/value
    config["foo"] = "bar"

# Generated at 2022-06-24 01:56:47.248118
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components function

    Given
    - A setup.cfg file with a non-default changelog_components value

    When
    - The function current_changelog_components is called

    Then
    - The function returns a list of functions corresponding to the value
    """
    from .commit_parsers import header_parser
    from .changelog_writers import simplify_entry

    components = current_changelog_components()
    assert len(components) == 3
    assert components[0] is header_parser
    assert components[1] == simplify_entry
    assert components[2] == simplify_entry


# Generated at 2022-06-24 01:56:49.831742
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.components.changelog"

    assert (
        current_changelog_components() == [
            semantic_release.components.changelog.component
        ]
    )

# Generated at 2022-06-24 01:56:57.746683
# Unit test for function current_commit_parser
def test_current_commit_parser():
    with open('pyproject.toml', 'w') as fp:
        fp.write("""[tool.semantic_release]
                    commit_parser = semantic_release.commit_parser.default_commits_parser\n""")
    from semantic_release.commit_parser import default_commits_parser
    assert current_commit_parser() == default_commits_parser
    # Remove the file after test
    os.remove('pyproject.toml')


# Generated at 2022-06-24 01:57:00.862502
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function():
        return config["overload_configuration_test"]

    tst = overload_configuration(test_function)
    tst(define=["overload_configuration_test=success"])

    assert config["overload_configuration_test"] == "success"

# Generated at 2022-06-24 01:57:05.805291
# Unit test for function overload_configuration
def test_overload_configuration():
    config["name"] = None
    @overload_configuration
    def test(*args, **kwargs):
        pass
    test(define=["name=3"])
    assert config["name"] == "3"

# Generated at 2022-06-24 01:57:11.984802
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def overload_test_func():
        return config["changelog_components"]

    overload_test_func(define=["changelog_components=1,2,3,4", "commit_parser=5"])
    assert config["changelog_components"] == "1,2,3,4"
    assert config["commit_parser"] == "5"

# Generated at 2022-06-24 01:57:14.668798
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def update_config(define):
        config.update(define)
    update_config(define=["name=value", "test=test"])
    assert "name" in config and config["name"] == "value"
    assert "test" in config and config["test"] == "test"

# Generated at 2022-06-24 01:57:16.678562
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history import git

    current_commit_parser()
    assert current_commit_parser() == git.parse_commits

# Generated at 2022-06-24 01:57:23.585564
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    import semantic_release.changelog_components

    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == semantic_release.changelog.change_summary
    assert components[1] == semantic_release.changelog_components.issues
    assert components[0] != semantic_release.changelog.issues

# Generated at 2022-06-24 01:57:34.179259
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()
    config["a_string"] = "string1"
    config["an_int"] = "4"

    @overload_configuration
    def funct_without_overload(a_string, an_int):
        return a_string, an_int

    assert funct_without_overload(a_string="string1", an_int="4") == ("string1", "4")

    @overload_configuration
    def funct_with_overload(a_string, an_int):
        return a_string, an_int

    assert funct_with_overload(
        a_string="string1", an_int="4", define=["a_string=string2"]
    ) == ("string2", "4")

# Generated at 2022-06-24 01:57:36.868571
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser"""
    parser = current_commit_parser()
    assert parser.__name__ == "parse_commits"



# Generated at 2022-06-24 01:57:43.062150
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def get_config(key):
        return config[key]

    assert len(config) == 0
    assert get_config("key") == "key"
    assert "key" in config
    assert get_config("key2", define=["key2=value2"]) == "value2"
    assert "key2" in config

# Generated at 2022-06-24 01:57:44.275797
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())


# Generated at 2022-06-24 01:57:52.125138
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that overload_configuration decorator works as expected"""

    # This function should be decorated
    @overload_configuration
    def function_to_decorate(one_param, define=None):
        """A function that takes one parameter, as expected"""

        # We should test that the definition has been correctly updated
        assert config["token"] == "aaa"
        assert config["url"] == "bbb"
        return one_param

    # This function should not be decorated
    def function_not_to_decorate(one_param, define=None):
        """A function that takes one parameter, as expected"""

        # We should test that the definition has been correctly updated
        try:
            assert config["token"] == "aaa"
            assert False
        except KeyError:
            pass

# Generated at 2022-06-24 01:57:57.889554
# Unit test for function overload_configuration
def test_overload_configuration():
    config = dict()

    @overload_configuration
    def with_define(define=None):
        if define is not None:
            for defined_param in define:
                pair = defined_param.split("=", maxsplit=1)
                if len(pair) == 2:
                    config[str(pair[0])] = pair[1]

    @overload_configuration
    def without_define():
        pass

    with_define(define=["key=value", "key2=value2"])
    assert config == {'key': 'value', 'key2': 'value2'}

    config = dict()
    without_define()
    assert config == dict()

# Generated at 2022-06-24 01:58:03.894524
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog_components
    assert current_changelog_components() == [
        changelog_components.commit_range,
        changelog_components.unreleased,
        changelog_components.branch,
        changelog_components.issues,
        changelog_components.compare,
    ]

# Generated at 2022-06-24 01:58:10.008114
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.released_features"
    assert len(current_changelog_components()) == 1

    config["changelog_components"] = "semantic_release.changelog.components.released_features, semantic_release.changelog.components.breaking_changes"
    assert len(current_changelog_components()) == 2

# Generated at 2022-06-24 01:58:15.340618
# Unit test for function current_changelog_components
def test_current_changelog_components():
    with open('pyproject.toml', 'r') as f:
        pyproject = f.read()
    pyproject = pyproject.replace("changelog_components = 'semantic_release.changelog.FileChangelogComponent'",
                                  "changelog_components = 'semantic_release.changelog.FileCha'")
    with open('pyproject.toml', 'w') as f:
        f.write(pyproject)
    assert current_changelog_components() == []

# Generated at 2022-06-24 01:58:19.212902
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    We test that the decorator works
    """
    @overload_configuration
    def func(define):
        return define

    test = func(define=["define=me"])
    assert test == ["define=me"]
    assert config.get("define") == "me"


# Generated at 2022-06-24 01:58:20.110355
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 01:58:23.456493
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        config.get("commit_parser")
        == "semantic_release.commit_parser.CommitMessageParser"
    )
    assert current_commit_parser().__name__ == "CommitMessageParser"



# Generated at 2022-06-24 01:58:30.856894
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {"hello": "world"}
    overloaded_config = {}

    def function(define, **kwargs):
        global overloaded_config
        overloaded_config = kwargs

    function = overload_configuration(function)

    function(define=["hello=world 2"], **config)
    assert overloaded_config == {"hello": "world 2"}

    function(define=["hello=world 3"], **config)
    assert overloaded_config == {"hello": "world 3"}

# Generated at 2022-06-24 01:58:34.642881
# Unit test for function overload_configuration
def test_overload_configuration():
    config["key1"] = "value1"
    config["key2"] = "value2"

    # Test overloading existing value
    @overload_configuration
    def func(define):
        return config["key1"]

    assert func(define="key1=new_value") == "new_value"

    # Test overloading new value
    @overload_configuration
    def func(define):
        return config["new_key"]

    assert func(define="new_key=new_value") == "new_value"

# Generated at 2022-06-24 01:58:36.398857
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import default_components
    config['changelog_components'] = 'semantic_release.changelog.default_components'
    components = current_changelog_components()
    assert components == default_components

# Generated at 2022-06-24 01:58:39.789287
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .changelog import changelog_parser

    # Test with the default parser
    assert current_commit_parser() == changelog_parser
    # Test with a function
    config["commit_parser"] = "semantic_release.commit_parser.changelog_parser"
    assert current_commit_parser() == changelog_parser

# Generated at 2022-06-24 01:58:45.259846
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test function current_changelog_components"""
    list_func = current_changelog_components()
    assert list_func[0] == 'semantic_release.changelog.get_commit_log'
    assert list_func[1] == 'semantic_release.changelog.validate_issue_tracker'



# Generated at 2022-06-24 01:58:46.089231
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components()

# Generated at 2022-06-24 01:58:51.540211
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser.parse'
    parser = current_commit_parser()
    assert callable(parser)



# Generated at 2022-06-24 01:59:00.416761
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config["commit_parser"] == "semantic_release.commit_parser"

    def dummy_func(dummy_param, define=None, **kwargs):
        return True

    dummy_func = overload_configuration(dummy_func)
    assert dummy_func(None) == True
    assert config["commit_parser"] == "semantic_release.commit_parser"

    dummy_func(None, define=["commit_parser=semantic_release.tests.dummy_parser"])
    assert config["commit_parser"] == "semantic_release.tests.dummy_parser"

# Generated at 2022-06-24 01:59:10.872366
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import ChangelogException
    from semantic_release.changelog import format_changelog_section

    @overload_configuration
    def test_function():
        from semantic_release.changelog import Changelog
        from semantic_release.changelog import format_changelog_section

        components = current_changelog_components()
        assert len(components) == 2

        for component in components:
            assert component == format_changelog_section

    test_function(define=["changelog_components=semantic_release.changelog.format_changelog_section"])


# Generated at 2022-06-24 01:59:12.545638
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()
    assert current_changelog_components()[0]([]) == []

# Generated at 2022-06-24 01:59:19.564173
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli as cli
    # We need to add this option to the parser so that it's available in the
    # function signature.
    cli.parser.add_argument("--define", nargs="+")

    # Decorate the function, so that it takes all other parameters from the
    # parser.
    decorator = overload_configuration(cli.main)

    # Define an arbitrary parameter in the argv array.
    # The first two arguments are the 'path' to the module and the
    # '--define' string. The other items are arbitrary.
    cli.sys.argv = ["", "--define", "foo=bar", "--dry-run"]

    decorator()
    assert config["foo"] == "bar"

    # Cleanup.
    cli.sys.argv = cli.sys

# Generated at 2022-06-24 01:59:24.358768
# Unit test for function current_commit_parser
def test_current_commit_parser():  # noqa: D103
    from semantic_release import parser_functions

    assert current_commit_parser() == parser_functions.parser

# Generated at 2022-06-24 01:59:27.016540
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "python_semantic_release.commit_parser.parse"
    assert "parse" == current_commit_parser().__name__


# Generated at 2022-06-24 01:59:31.449595
# Unit test for function current_commit_parser
def test_current_commit_parser():

    # Default commit message parser
    assert current_commit_parser().__name__ == "parse_message"

    # Custom commit message parser
    # Mock the get method of the config dict
    config.get = lambda x: "tests.test_config.test_parser"
    assert current_commit_parser().__name__ == "test_parser"


# Generated at 2022-06-24 01:59:34.078722
# Unit test for function current_changelog_components
def test_current_changelog_components():

    import semantic_release.changelog

    assert current_changelog_components() == [
        semantic_release.changelog.get_changelog_sections
    ]

# Generated at 2022-06-24 01:59:41.412668
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import Body, Footer, FooterMethod, Header

    components = current_changelog_components()
    assert len(components) == 2
    assert components == [Body.get_changelog_component, Header.get_changelog_component]
    assert 'Footer' in config['changelog_components']
    assert 'FooterMethod' not in config['changelog_components']

# Generated at 2022-06-24 01:59:45.523515
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "parse"


# Generated at 2022-06-24 01:59:49.223559
# Unit test for function overload_configuration
def test_overload_configuration():
    config.get = lambda _: ""

    @overload_configuration
    def foo(x):
        return config.get(x)

    assert foo(define=["baz=bar", "foo=bar"], x="foo") == "bar"

# Generated at 2022-06-24 01:59:53.199886
# Unit test for function current_changelog_components
def test_current_changelog_components():
    class FakeModule:
        @staticmethod
        def fake_component():
            pass

    importlib.import_module = lambda module: FakeModule
    config["changelog_components"] = "semantic_release.tests.test_configuration.fake_component"
    res = current_changelog_components()
    assert callable(res[0])

# Generated at 2022-06-24 02:00:01.138097
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import (
        breaking_changes,
        commits,
        features_and_fixes,
    )

    assert current_changelog_components() == [
        breaking_changes,
        commits,
        features_and_fixes,
    ]

    config["changelog_components"] = "semantic_release.changelog_components.breaking_changes"
    assert current_changelog_components() == [breaking_changes]
    config["changelog_components"] = "semantic_release.changelog_components"
    assert current_changelog_components() == [
        breaking_changes,
        commits,
        features_and_fixes,
    ]

# Generated at 2022-06-24 02:00:04.112620
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser.default_parser"


# Generated at 2022-06-24 02:00:06.514808
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 02:00:16.109956
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        config['changelog_components'] = 'semantic_release.changelog_components.changelog_components'
        components = current_changelog_components()
        assert components is not None
    except (ImportError, AttributeError):
        assert False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    for k, v in config.items():
        parser.add_argument(f"--{k}", default=v, help=k)
    args = parser.parse_args()

    for k, v in args.__dict__.items():
        config[k] = v
    print(config)

# Generated at 2022-06-24 02:00:20.325192
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Test custom commit parser
    config["commit_parser"] = "semantic_release.commit_parser.custom_commit_parser"
    from .commit_parser import custom_commit_parser
    assert current_commit_parser() == custom_commit_parser

    # Test default commit parser
    config["commit_parser"] = "semantic_release.commit_parser"
    assert current_commit_parser() == custom_commit_parser

# Generated at 2022-06-24 02:00:23.188610
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert type(current_changelog_components()) == list

# Generated at 2022-06-24 02:00:25.578012
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.make_components"
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-24 02:00:29.554247
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()



# Generated at 2022-06-24 02:00:30.531260
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:00:31.193124
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()


# Generated at 2022-06-24 02:00:36.155685
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    test_overload_configuration.func_called = False
    @overload_configuration
    def test_func(arg1, arg2, define=None):
        test_overload_configuration.func_called = True
        assert config["test_key"] == "new_value"
        assert arg1 == "arg1"
        assert arg2 == "arg2"

    test_func("arg1", "arg2", define=["test_key=new_value"])
    assert test_overload_configuration.func_called is True

# Generated at 2022-06-24 02:00:40.809466
# Unit test for function current_changelog_components
def test_current_changelog_components():
    expected_components = [
        semantic_release.changelog_components.body,
        semantic_release.changelog_components.compare_link,
        semantic_release.changelog_components.title,
    ]
    assert current_changelog_components() == expected_components

# Generated at 2022-06-24 02:00:49.969075
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This unit test checks if the configuration can be overloaded.
    """
    def mocked_func(**kwargs):
        return kwargs

    mocked_func = overload_configuration(mocked_func)
    assert mocked_func(define=["python_interpreter=something", "version_variable=new_version"]) == {
        "python_interpreter": "something",
        "version_variable": "new_version"
    }
    assert mocked_func(define=["python_interpreter=something", "version_variable=new_version"], another_var=True) == {
        "python_interpreter": "something",
        "version_variable": "new_version",
        "another_var": True
    }

# Generated at 2022-06-24 02:00:53.293002
# Unit test for function current_commit_parser
def test_current_commit_parser():
    print(current_commit_parser())



# Generated at 2022-06-24 02:00:54.926552
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release import parser

    assert current_commit_parser() == parser.parse_commit_message

# Generated at 2022-06-24 02:00:59.167239
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(lambda x: x)

    @overload_configuration
    def wrapper(x):
        return x

    assert func(define=["foo=bla"]) is None
    assert config["foo"] == "bla"
    assert wrapper(define=["foo=bla"]) is None
    assert config["foo"] == "bla"

# Generated at 2022-06-24 02:01:00.541482
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parser import default_commit_parser

    assert current_commit_parser() == default_commit_parser



# Generated at 2022-06-24 02:01:04.886788
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def get_config(key):
        assert config['fail'] == 'foo'
        assert config['true']
        assert not config['false']
        return config['fail']

    config['fail'] = 'bar'
    config['true'] = False
    config['false'] = True
    get_config('fail', define=['fail=foo', 'true=true', 'false=false'])

# Generated at 2022-06-24 02:01:12.827987
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components
    from semantic_release.utils import define_changelog_components

    @define_changelog_components("semantic_release.tests.test_changelog_components_1")
    def test_function_1():
        return get_changelog_components()

    @define_changelog_components("semantic_release.tests.test_changelog_components_1")
    def test_function_2():
        return get_changelog_components()


# Generated at 2022-06-24 02:01:13.394185
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-24 02:01:24.126560
# Unit test for function overload_configuration
def test_overload_configuration():
    import click

    # Define a dummy click command
    @click.command()
    @click.help_option("-h", "--help")
    @click.option("--define", "-d", multiple=True)
    @overload_configuration
    def dummy_click_command(define):
        click.echo("Hello World")

    # Call the dummy with a single pair of key/value
    dummy_click_command("-d", "dummy_test_key=test_value")
    assert config["dummy_test_key"] == "test_value"

    # Call the dummy with two pairs of key/value
    dummy_click_command("-d", "dummy_test_key=test_value", "-d", "hello=world")
    assert config["dummy_test_key"] == "test_value"
   

# Generated at 2022-06-24 02:01:27.427621
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config["changelog_components"] == "changelog.components.changelog"
    assert config["commit_parser"] == "semantic_release.commit_parser.default_parser"


if __name__ == "__main__":
    test_overload_configuration()

# Generated at 2022-06-24 02:01:32.313789
# Unit test for function overload_configuration
def test_overload_configuration():
    os.environ["SEMANTIC_RELEASE_DEFINE"] = "home=asd"

    # config.get() is mocked
    config.get = lambda key: None

    def no_overload(define=None):
        return not config.get(define.split("=")[0]) is None

    no_overload = overload_configuration(no_overload)
    assert no_overload(define=os.getenv("SEMANTIC_RELEASE_DEFINE"))
    # Clean up config.
    del config[os.getenv("SEMANTIC_RELEASE_DEFINE").split("=")[0]]

# Generated at 2022-06-24 02:01:40.327622
# Unit test for function overload_configuration
def test_overload_configuration():
    pre_config = config.copy()
    # empty case
    define_key_values = [""]
    overload_configuration("")(define=define_key_values)
    assert pre_config == config
    # case without "="
    define_key_values = ["key"]
    overload_configuration("")(define=define_key_values)
    assert pre_config == config
    # case with several "="
    define_key_values = ["key=value=value2"]
    overload_configuration("")(define=define_key_values)
    assert pre_config == config
    # case with one key/value
    define_key_values = ["overload_key=overload_value"]
    overload_configuration("")(define=define_key_values)

# Generated at 2022-06-24 02:01:47.275872
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_parse(message):
        return {
            "type": "feat",
            "scope": "chore",
            "subject": "test",
            "body": "test body",
            "issues": ["1", "2"],
        }

    config["commit_parser"] = ".".join([__name__, "test_parse"])
    assert current_commit_parser() == test_parse
    # Should raise error when not having a good "commit_parser" in config
    config["commit_parser"] = "this.will.fail"
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-24 02:01:54.019303
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.scripts import changelog_maker

    components = current_changelog_components()

    assert components[0] == changelog_maker.get_fixed_issues
    assert components[1] == changelog_maker.get_new_features
    assert components[2] == changelog_maker.get_other_changes



# Generated at 2022-06-24 02:02:00.257357
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """ Test function current_commit_parser()
    """

    # Test the right import
    assert current_commit_parser.__name__ == "current_commit_parser"

    # Test the expected behaviour
    # Test the correct behaviour if config is set
    for test in ["package_name", "user_name", "password", "release_branch"]:
        assert config.get(test)
    # Test the correct behaviour if config is not set
    for test in ["release_branch", "user_name", "password"]:
        assert config.get(test) is None
    # Test the correct behaviour if config is set but empty
    assert config.get("package_name") == ""
    # Test error message if ImportError is raised

# Generated at 2022-06-24 02:02:04.774732
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.simple"
    assert importlib.import_module("semantic_release.commit_parser.simple").simple
    config["commit_parser"] = "semantic_release.commit_parser.angular"
    assert importlib.import_module("semantic_release.commit_parser.angular").angular


# Generated at 2022-06-24 02:02:15.062702
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        import semantic_release.tests.changelog_components as changelog_components
        from semantic_release.tests.tests_changelog_components import (
            semantic_release_changelog_components_function,
            semantic_release_changelog_components_class,
        )
    except ImportError:  # pragma: no cover
        return
    except ModuleNotFoundError:  # pragma: no cover
        return
    config["changelog_components"] = "semantic_release.tests.changelog_components.semantic_release_changelog_components_function"
    assert current_changelog_components() == [
        semantic_release_changelog_components_function
    ]

# Generated at 2022-06-24 02:02:15.951523
# Unit test for function current_commit_parser
def test_current_commit_parser():
    print(current_commit_parser())

# Generated at 2022-06-24 02:02:27.259290
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import os
    import tempfile
    from textwrap import dedent

    from .errors import ImproperConfigurationError

    cwd = os.getcwd()
    config_file_contents = dedent(
        """
        [tool.semantic_release]
        changelog_components = semantic_release.tests.test_config.incorrect_component_path,  # noqa: E501
                               semantic_release.tests.test_config.test_component
    """
    )

    temp_dir = tempfile.gettempdir()
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    os.chdir(temp_dir)


# Generated at 2022-06-24 02:02:31.074840
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.extract_release_notes,
        semantic_release.changelog.changelog_commit_parser,
        semantic_release.changelog.changelog_format,
        semantic_release.changelog.changelog_write,
    ]

# Generated at 2022-06-24 02:02:34.466422
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # The function current_changelog_components is well tested by the
    # unit tests of the respective components
    pass

# Generated at 2022-06-24 02:02:44.579374
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import (
        IssuesClosed,
        IssueLink,
        IssueReference,
        CommitReferences,
        CommitLink,
        CommitReference,
    )

    component_paths = config.get("changelog_components")
    component_paths = component_paths.replace(
        ",", "").replace(
            "semantic_release.changelog_components.", "").split()
    components = list()

    for path in component_paths:
        try:
            components.append(getattr(importlib.import_module(
                "semantic_release.changelog_components"), path))
        except (ImportError, AttributeError) as error:
            raise ImproperConfigurationError(
                f'Unable to import changelog component "{path}"')

# Generated at 2022-06-24 02:02:54.730553
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .validate_changelog import changelog_commit_type

    for key in config.keys():
        if key.startswith("changelog_components"):
            config.pop(key)
    config["changelog_components"] = "semantic_release.changelog.changelog_commit_type"
    assert current_changelog_components() == [changelog_commit_type]
    config["changelog_components"] = "semantic_release.changelog.changelog_commit_type,semantic_release.changelog.changelog_scope"
    assert current_changelog_components() == [changelog_commit_type, changelog_scope]

# Generated at 2022-06-24 02:03:05.799722
# Unit test for function overload_configuration
def test_overload_configuration():
    """ This function does a test for overload_configuration decorator """

    # This class is used for the test of overload_configuration decorator.
    # It permits to know if the function has been called.
    class TestFuncExec():
        def __init__(self):
            self.executed = False

        def check_execution(self):
            self.executed = True

    def f_test(define=None):
        test_function.check_execution()

    test_function = TestFuncExec()
    f_overload = overload_configuration(f_test)

    # Test with no define parameters
    f_overload()
    assert test_function.executed is True

    test_function = TestFuncExec()
    # Test with one define parameter
    f_overload(define=["foo=bar"])

# Generated at 2022-06-24 02:03:06.672927
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert isinstance(current_commit_parser(), Callable)

# Generated at 2022-06-24 02:03:12.945791
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli
    import semantic_release.hvcs

    def dummy_func(a):
        return a

    semantic_release.cli.command = overload_configuration(semantic_release.cli.command)
    semantic_release.hvcs.get_vcs = overload_configuration(
        semantic_release.hvcs.get_vcs
    )

    semantic_release.cli.command("hi")
    assert config.get("dry_run") is False
    semantic_release.cli.command("hi", define=["dry_run"])
    assert config.get("dry_run") is True
    semantic_release.cli.command("hi", define=["dry_run=False"])
    assert config.get("dry_run") is False


# Generated at 2022-06-24 02:03:18.893923
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"

    assert (
        current_commit_parser().__module__
        == "semantic_release.commit_parser"
    )
    assert current_commit_parser().__name__ == "parse_commit"



# Generated at 2022-06-24 02:03:21.245531
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = {}
    @overload_configuration
    def foo(arg):
        return arg

    foo(arg="bar", define=["test=value"])
    assert config["test"] == "value"

# Generated at 2022-06-24 02:03:21.968781
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-24 02:03:24.780518
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["major_on_zero=False"])
    assert config["major_on_zero"] == "False"

# Generated at 2022-06-24 02:03:26.727507
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(*args, **kwargs):
        return config

    old_value = config["define"]
    config["define"] = "test"
    assert test_function()["define"] == "test"
    config["define"] = old_value

# Generated at 2022-06-24 02:03:27.644287
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert config.get("commit_parser") == "semantic_release.commit_parser"

# Generated at 2022-06-24 02:03:37.326889
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # pylint: disable=protected-access
    config["changelog_components"] = "semantic_release.changelog.components.unreleased_commits"
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == "unreleased_commits"
    assert components[0].__module__ == "semantic_release.changelog.components"

    config["changelog_components"] = "semantic_release.changelog.components.unreleased_commits,invalid"
    with pytest.raises(ImproperConfigurationError):
        components = current_changelog_components()



# Generated at 2022-06-24 02:03:43.525490
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy(foo, bar, zoo=None, define=None):
        return foo, bar, zoo, define

    assert dummy("foo", "bar") == ("foo", "bar", None, None)
    assert dummy("foo", "bar", zoo="zoo") == ("foo", "bar", "zoo", None)
    assert dummy("foo", "bar", zoo="zoo", define="a=a") == ("foo", "bar", "zoo", "a=a")
    assert dummy("foo", "bar", zoo="zoo", define=["a=a", "b=b"]) == ("foo", "bar", "zoo", ["a=a", "b=b"])
    assert config == {"a": "a", "b": "b"}

# Generated at 2022-06-24 02:03:47.486037
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())


# Generated at 2022-06-24 02:03:51.840560
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test that a function with the name of the component is called"""
    assert current_changelog_components() == [changelog_parsing.pre_release]

# Generated at 2022-06-24 02:03:58.029741
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.tests.test_changelog_components'
    components = current_changelog_components()
    assert len(components) == 1

    config['changelog_components'] = 'semantic_release.tests.test_changelog_components,semantic_release.tests.test_changelog_components.submodule'
    components = current_changelog_components()
    assert len(components) == 2

# Generated at 2022-06-24 02:04:02.408431
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser.parser'
    assert(current_commit_parser().__name__ == 'parser')


# Generated at 2022-06-24 02:04:10.574368
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test defines a configurator with the key "test" to "test_value"
    and checks that the value of "config["test"]" is changed.
    """
    define = ["test=test_value"]

    @overload_configuration
    def add_value(define):
        config["test"] = "not_test"
        return 0

    assert config["test"] == "not_test"
    add_value(define)
    assert config["test"] == "test_value"

# Generated at 2022-06-24 02:04:18.405702
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import textwrap
    from semantic_release.tests.changelog_components import bugfix, feature
    from semantic_release import changelog

    @changelog.changelog_component
    def example_components(config):
        yield from feature(config)
        yield from bugfix(config)

    config["changelog_components"] = "semantic_release.tests.changelog_components.example_components"
    changelog_components = current_changelog_components()
    assert changelog_components[0]().__name__ == feature.__name__
    assert changelog_components[1]().__name__ == bugfix.__name__



# Generated at 2022-06-24 02:04:19.739240
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 02:04:28.833458
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Case no component specified
    config["changelog_components"] = ""
    assert current_changelog_components() == []

    # Case only a component specified
    config["changelog_components"] = "get_current_version_number"
    assert (
        current_changelog_components()
        == [importlib.import_module("semantic_release.changelog").get_current_version_number]
    )

    # Case several components specified
    config["changelog_components"] = "get_current_version_number,get_title_from_changelog"

# Generated at 2022-06-24 02:04:36.830932
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # reset config
    config = _config()
    assert callable(current_commit_parser())
    config['commit_parser'] = "semantic_release.commit_parser.parse_commits"
    assert callable(current_commit_parser())
    # test if ImproperConfigurationError is raised
    config['commit_parser'] = "semantic_release.commit_parser.no_parse_commits"
    from semantic_release.errors import ImproperConfigurationError
    from semantic_release import main
    assert main.main(['major']) == ImproperConfigurationError
    # test if ImproperConfigurationError is raised
    config['commit_parser'] = "semantic_release.commit_parse.no_parse_commits"
    assert main.main(['major']) == ImproperConfigurationError
    # test if ImproperConfigurationError is raised
   

# Generated at 2022-06-24 02:04:40.376764
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(test):
        return test

    test(test="test")

# Generated at 2022-06-24 02:04:51.221181
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def do_something(value):
        return value

    # Overloading key/value
    do_something(value="test", define=["key=value", "key2=value2"])
    assert config["key"] == "value"
    assert config["key2"] == "value2"
    # Overloading key only
    do_something(value="test", define=["key"])
    assert config["key"] == ""
    # Overloading key,value with spaces
    do_something(value="test", define=["key = value2"])
    assert config["key"] == "value2"
    # Overloading with only one '='
    do_something(value="test", define=["key=value2=value3"])
    assert config["key"] == "value2=value3"

# Generated at 2022-06-24 02:04:52.723286
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == 'semantic_release.commit_parser.default'



# Generated at 2022-06-24 02:04:54.235507
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.history

    assert current_commit_parser() == semantic_release.history.compare_commits

# Generated at 2022-06-24 02:04:55.364989
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:04:59.511278
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_config(msg):
        return config

    test_config(define=["new_config_value=new_value"], msg="Hello")
    assert config.get('new_config_value') == 'new_value'

# Generated at 2022-06-24 02:05:03.507475
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 3

# Generated at 2022-06-24 02:05:09.166632
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components return value"""
    # monkey patch
    config["changelog_components"] = "semantic_release.changelog_components.default"
    # return string
    assert isinstance(current_changelog_components()[0], str)
    # return function
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-24 02:05:11.679553
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parsers import issue_number_only_parser as parser

    assert current_commit_parser() == parser



# Generated at 2022-06-24 02:05:20.653447
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def overload(foo,bar,baz,define=None):
        print(foo,bar,baz,define)
        return define

    overload("a","b","c")
    assert config["package_name"] == "foomodule"
    assert config.get("version_variable") == "__version__"
    assert config.get("version_source_path") == "foomodule/__init__.py"
    assert config.get("version_format") == "%(version)s"
    assert config.get("upload_to_pypi") == "True"
    assert config.get("upload_to_pypi_repository") == ""
    assert config.get("upload_to_pypi_repository_url") == ""

# Generated at 2022-06-24 02:05:26.677179
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "world"

    @overload_configuration
    def foo(define, test):
        return test

    assert foo(define=["test=foo"], test="bar") == "bar"
    assert foo(define=["test=foo"]) == "foo"
    assert config["test"] == "world"

# Generated at 2022-06-24 02:05:30.352507
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import parser

    parser.parse_args(["--define", "remove_dist=True"])
    assert config["remove_dist"] == "True"

# Generated at 2022-06-24 02:05:34.417694
# Unit test for function current_commit_parser
def test_current_commit_parser():
    class_name = current_commit_parser()
    assert class_name.__name__ == 'parse_message'

# Generated at 2022-06-24 02:05:37.704832
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert config.get("changelog_components").split(",") != None

# Generated at 2022-06-24 02:05:45.966263
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(x, define):
        return x

    assert config["changelog_components"] == "semantic_release.changelog.changelog_components.changelog"
    assert config["major_on_zero"] == True

    assert test_func(1, ["changelog_components=foo", "major_on_zero=false"]) == 1

    assert config["changelog_components"] == "foo"
    assert config["major_on_zero"] == False

    assert test_func(2, ["changelog_components=foo,bar"]) == 2
    
    assert config["changelog_components"] == "foo,bar"