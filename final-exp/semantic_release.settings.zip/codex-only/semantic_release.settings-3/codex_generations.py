

# Generated at 2022-06-24 01:55:41.429599
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser() == 'semantic_release.commit_parser.default_parser'


# Generated at 2022-06-24 01:55:47.166842
# Unit test for function overload_configuration
def test_overload_configuration():
    result_configuration = config.copy()
    result_configuration["before_deploy"] = "do.that,do.that,do.that"
    result_configuration["after_deploy"] = "do.that,do.that,do.that"

    @overload_configuration
    def test_function(define):
        pass

    test_function(define=["before_deploy=do.that", "after_deploy=do.that,do.that"])

    assert config == result_configuration

# Generated at 2022-06-24 01:55:54.613735
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog_components
    from .changelog_components import (
        link_references,
        format_changelog_message,
        release_date,
    )

    COMPONENTS = [link_references, format_changelog_message, release_date]

    config["changelog_components"] = ",".join(
        "{}.{}".format(changelog_components.__name__, x.__name__)
        for x in COMPONENTS
    )

    assert current_changelog_components() == COMPONENTS

# Generated at 2022-06-24 01:56:03.660722
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Return the default parser if there is no commit_parser entry in config
    config = UserDict()
    from .parser import ChangelogParser

    assert current_commit_parser() == ChangelogParser

    # Return the parser if there is a commit_parser entry in config
    from .tests.fixtures import DummyCommitParser

    config = UserDict(commit_parser="semantic_release.tests.fixtures.DummyCommitParser")
    assert current_commit_parser() == DummyCommitParser

    # Fail if the parser is not found
    config = UserDict(commit_parser="cfg_parser")
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-24 01:56:06.635386
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.hvcs import parse_commit
    from semantic_release.hvcs.git import parse_commit as git_parse_commit

    try:
        parser = current_commit_parser()
    except ImproperConfigurationError:
        parser = git_parse_commit

    assert parser == parse_commit

# Generated at 2022-06-24 01:56:18.893705
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def foo():
        pass

    def bar(components):
        return [foo()]

    components = current_changelog_components()
    assert not components

    config["changelog_components"] = "semantic_release.changelog.utils.foo"
    components = current_changelog_components()
    assert components == [foo]

    config["changelog_components"] = "semantic_release.changelog.utils.bar"
    components = current_changelog_components()
    assert components == [bar]

    config["changelog_components"] = (
        "semantic_release.changelog.utils.foo,semantic_release.changelog.utils.bar"
    )
    components = current_changelog_components()

# Generated at 2022-06-24 01:56:22.113379
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert type(current_changelog_components()) == list
    assert len(current_changelog_components()) > 0
    assert config.get("changelog_components") is not None
    assert config.get("changelog_components") != ""


# Generated at 2022-06-24 01:56:25.287340
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parsers.all import parse_all_commits

    assert current_commit_parser() == parse_all_commits
    assert current_commit_parser.__name__ == "current_commit_parser"


# Generated at 2022-06-24 01:56:36.602722
# Unit test for function overload_configuration
def test_overload_configuration():
    # Function to be tested is a function without arguments with a defined function
    def test_func():
        pass

    # Function without arguments with a defined variables "define"
    @overload_configuration
    def test_func_without_define():
        pass

    # Function with arguments with a defined variables "define"
    @overload_configuration
    def test_func_with_define(define):
        pass

    # Function without arguments with a defined variables "define"
    @overload_configuration
    def test_func_with_args(arg):
        return arg

    # Function without arguments with a defined variables "define"
    @overload_configuration
    def test_func_with_kwargs(**kwargs):
        return kwargs

    # Function with arguments with a defined variables "define"

# Generated at 2022-06-24 01:56:40.512475
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test exists to provide coverage for the overload_configuration
    function.
    """

    @overload_configuration
    def foo():
        pass

    @overload_configuration
    def bar(i, **kwargs):
        return i

    foo()
    bar(1, define=["foo=bar"])

# Generated at 2022-06-24 01:56:48.558454
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test verifies that the content of
    the "define" array is injected into the "config"
    dictionary.
    """
    @overload_configuration
    def main(define):
        pass
    main(["version-file=pyproject.toml", "file=path", "file2=path2"])
    assert config["version-file"] == "pyproject.toml"
    assert config["file"] == "path"
    assert config["file2"] == "path2"

# Generated at 2022-06-24 01:56:53.411548
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import Changelog
    from .changelog import get_changelog
    from .changelog import write_changelog

    components = current_changelog_components()

    assert get_changelog in components
    assert write_changelog in components

    assert isinstance(Changelog, type(components[0]))

# Generated at 2022-06-24 01:56:57.885705
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import version_components, date_components

    config = {
        "changelog_components": "semantic_release.changelog.version_components,semantic_release.changelog.date_components"
    }
    assert current_changelog_components(config) == [version_components, date_components]

# Generated at 2022-06-24 01:57:01.674172
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import setup_utils

    # Policy is to overwrite any previous value,
    # and remove any key that does not have a value.
    class FakeConfig:
        @overload_configuration
        def fake_func(self, key, define=None):
            return setup_utils.config[key]

    fake_func = FakeConfig().fake_func

    assert fake_func("changelog_components") != "issue"
    assert fake_func("changelog_components", define="changelog_components=issue") == "issue"
    assert "changelog_components" in setup_utils.config

    assert fake_func("changelog_components", define="commit_parser=") == ""
    assert "commit_parser" not in setup_utils.config

    # The decorator does not accept an empty

# Generated at 2022-06-24 01:57:10.107719
# Unit test for function overload_configuration
def test_overload_configuration():
    # Example function
    @overload_configuration
    def test_func(define):
        return config.get("foo")

    # Return 'bar' when key 'foo' is present in config
    assert test_func(define=["foo=bar"]) == "bar"

    # Return No value when key 'foo' is not present in config
    assert test_func(define=["foo="]) is None

# Generated at 2022-06-24 01:57:16.259299
# Unit test for function overload_configuration
def test_overload_configuration():
    from .bump import bump_version
    @overload_configuration
    def fn():
        pass
    fn()
    assert config['changelog_components'] == 'semantic_release.changelog.changelog_components.docs_section'
    fn(define=["changelog_components=semantic_release.changelog.changelog_components.changes_section"])
    assert config['changelog_components'] == 'semantic_release.changelog.changelog_components.changes_section'
    fn()
    assert config['changelog_components'] == 'semantic_release.changelog.changelog_components.docs_section'
    config.clear()

# Generated at 2022-06-24 01:57:21.929566
# Unit test for function overload_configuration
def test_overload_configuration():

    def unit_test(parameter):
        return config[parameter]

    unit_test = overload_configuration(unit_test)

    assert config["trigger_release"] == "master"
    unit_test(define=["trigger_release=develop"])
    assert config["trigger_release"] == "develop"

# Generated at 2022-06-24 01:57:25.092465
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components = current_changelog_components()
    assert current_changelog_components[0] == correct_component1
    assert current_changelog_components[1] == correct_component2


# Generated at 2022-06-24 01:57:30.152437
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""

    from . import changelog_components
    assert current_changelog_components() == [
        changelog_components.log_level,
        changelog_components.releases,
    ]

# Generated at 2022-06-24 01:57:33.763014
# Unit test for function current_commit_parser
def test_current_commit_parser():
    class Defaults:
        commit_parser = "semantic_release.commit_parser"

    import semantic_release.commit_parser

    assert current_commit_parser() == semantic_release.commit_parser.parser



# Generated at 2022-06-24 01:57:44.760572
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .utils import changelog_components
    from .utils import CONVENTIONAL_COMPONENTS

    config["changelog_components"] = "semantic_release.utils.changelog_components"
    components = current_changelog_components()
    assert components[0] == changelog_components

    config["changelog_components"] = (
        "semantic_release.utils.changelog_components,"
        "semantic_release.utils.CONVENTIONAL_COMPONENTS"
    )
    components = current_changelog_components()
    assert components[0] == changelog_components
    assert components[1] == CONVENTIONAL_COMPONENTS


# Generated at 2022-06-24 01:57:47.175287
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()
    assert current_commit_parser.__name__ == 'current_commit_parser'


# Generated at 2022-06-24 01:57:51.185528
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    func1 = overload_configuration(lambda x: x)
    func1("test")

    if config["test"] != "test":
        raise Exception("test_overload_configuration failed")

    func2 = overload_configuration(lambda x, define: x)
    func2("test", define=["test=test2"])

    if config["test"] != "test2":
        raise Exception("test_overload_configuration failed")

# Generated at 2022-06-24 01:57:56.925280
# Unit test for function current_changelog_components

# Generated at 2022-06-24 01:58:00.206673
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-24 01:58:08.622017
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # sample from setup.cfg
    component_paths = 'autohooks.semantic_release.changelog_components.DefaultComponent,autohooks.semantic_release.changelog_components.IssuesClosedComponent'
    components = []

    # check if components imported correctly
    components.append(
        getattr(
            importlib.import_module("autohooks.semantic_release.changelog_components"),
            "DefaultComponent",
        )
    )
    components.append(
        getattr(
            importlib.import_module("autohooks.semantic_release.changelog_components"),
            "IssuesClosedComponent",
        )
    )
    # check if components equal to imported components
    assert current_changelog_components() == components

# Generated at 2022-06-24 01:58:14.726262
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.parse_commits,semantic_release.changelog.check_changelog_file"
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == "parse_commits"
    assert components[1].__name__ == "check_changelog_file"

# Generated at 2022-06-24 01:58:18.177488
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        pass

    test(define=["a=b", "c=d", "e=f"])

    assert config["a"] == "b"
    assert config["c"] == "d"
    assert config["e"] == "f"

# Generated at 2022-06-24 01:58:21.680370
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"

    @overload_configuration
    def fake_function_to_test_decorator(**kwargs):
        return config

    new_config = fake_function_to_test_decorator(define=["test=test2"], extra="extra")

    assert new_config["test"] == "test2"

# Generated at 2022-06-24 01:58:25.367414
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components =  current_changelog_components()
    assert len(components) > 0

# Generated at 2022-06-24 01:58:28.463979
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components() == [
        semantic_release.changelog.components.summary,
        semantic_release.changelog.components.subtasks,
        semantic_release.changelog.components.breaking_changes,
        semantic_release.changelog.components.issue_references,
    ]

# Generated at 2022-06-24 01:58:36.078712
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(config=None):
        return config

    assert func() is None
    assert func(define=["version=test"]) == "test"
    assert func(config="test") == "test"
    assert func(config="test", define=["version=test2"]) == "test2"

# Generated at 2022-06-24 01:58:41.472553
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components as components
    assert current_changelog_components() == [
        components.create_changelog_header,
        components.hashes_to_end,
        components.add_footer,
    ]



# Generated at 2022-06-24 01:58:45.840514
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Test current_changelog_components()
    """
    import semantic_release.changelog as changelog

    config['changelog_components'] = 'semantic_release.changelog.issue_components'

    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == changelog.issue_components


# Generated at 2022-06-24 01:58:50.033520
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-24 01:59:00.084690
# Unit test for function overload_configuration
def test_overload_configuration():
    def function():
        return "function"

    # Empty definition
    assert overload_configuration(function)() == "function"

    # Overriding the value
    assert overload_configuration(function)(define=["changelog_components=my_component"]) == "function"
    assert config["changelog_components"] == "my_component"

    # Overriding the value and keeping the original
    assert overload_configuration(function)(define=["changelog_components=my_component", "commit_parser=parse_function"]) == "function"
    assert config["changelog_components"] == "my_component"
    assert config["commit_parser"] == "parse_function"

# Generated at 2022-06-24 01:59:10.469109
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(define=None):
        # Create a copy of the original config values
        old_config = dict(config)
        if not isinstance(define, list):
            define = list()
        overload_configuration(test_func)(define=define)
        # restore the original config values
        config.update(old_config)
        return config

    test_config = test_func()
    test_config_1 = test_func(['user.name=Toto', 'user.email=toto@example.com'])
    assert test_config == config
    assert test_config_1 != config
    assert test_config_1.get("user.name") == "Toto"
    assert test_config_1.get("user.email") == "toto@example.com"

# Generated at 2022-06-24 01:59:12.141416
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        components = current_changelog_components()
        assert len(components) == 5
    except:
        assert True

# Generated at 2022-06-24 01:59:12.897924
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert components

# Generated at 2022-06-24 01:59:23.276122
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test if a parameter is correctly passed to the configuration dictionary
    """
    config["test1"] = "config1"
    config["test2"] = "config2"
    config["test3"] = "config3"

    @overload_configuration
    def func(define, test1, test2, test3):
        assert test1 == "config1"
        assert test2 == "config2"
        assert test3 == "config3"

    func(define=["test2=define2", "test3=define3"])
    assert config["test1"] == "config1"
    assert config["test2"] == "define2"
    assert config["test3"] == "define3"

    config.clear()

# Generated at 2022-06-24 01:59:25.190212
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == load_changelog_section



# Generated at 2022-06-24 01:59:29.469769
# Unit test for function overload_configuration
def test_overload_configuration():
    config["overload_configuration"] = "before"

    @overload_configuration
    def mock_function(x):
        pass

    mock_function(define=["overload_configuration=after"])

    assert config["overload_configuration"] == "after"

# Generated at 2022-06-24 01:59:30.372622
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-24 01:59:33.742805
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.get_messages"
    assert current_commit_parser() == importlib.import_module(
        "semantic_release.commit_parser"
    ).get_messages

# Generated at 2022-06-24 01:59:36.223294
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.unreleased_changes"
    assert current_changelog_components() is not None

# Generated at 2022-06-24 01:59:39.474717
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history import CommitParser

    assert current_commit_parser() == CommitParser



# Generated at 2022-06-24 01:59:44.172673
# Unit test for function current_changelog_components
def test_current_changelog_components():
    result = current_changelog_components()
    assert result, "result should not be empty"
    assert callable(result[0]), "result should be a callable"

# Generated at 2022-06-24 01:59:45.013160
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-24 01:59:46.505585
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == importlib.import_module("semantic_release.commit_parser").default

# Generated at 2022-06-24 01:59:49.242348
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == "breaking_change_component"
    assert components[1].__name__ == "feature_component"

# Generated at 2022-06-24 01:59:58.747497
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the function current_changelog_components to make sure it
    returns the currently-configured changelog components"""
    # most basic test case
    input_changelog_components = "src.components.major_change, src.components.minor_change"
    expected_output = [
        src.components.major_change,
        src.components.minor_change,
    ]
    config["changelog_components"] = input_changelog_components
    assert current_changelog_components() == expected_output
    # test even if changelog_components is empty
    input_changelog_components = ""
    expected_output = []
    config["changelog_components"] = input_changelog_components
    assert current_changelog_

# Generated at 2022-06-24 02:00:03.331208
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Check if a changelog_components is defined in the local setup.cfg
    try:
        assert current_changelog_components()[0] == config.get("changelog_components").split(",")[0]
    except ImproperConfigurationError:
        # If the function raises a configuration error, changelog_components
        # is not defined in the local setup.cfg
        assert False

# Generated at 2022-06-24 02:00:09.052940
# Unit test for function current_changelog_components
def test_current_changelog_components():
    og_components = config.get("changelog_components")
    config["changelog_components"] = (
        "semantic_release.changelog_components.get_git_commits"
    )
    try:
        assert len(current_changelog_components()) == 1
    except ImproperConfigurationError:
        assert False
    finally:
        config["changelog_components"] = og_components

# Generated at 2022-06-24 02:00:11.608599
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release import commit_parser

    assert current_commit_parser() == commit_parser.default



# Generated at 2022-06-24 02:00:16.079903
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser.__name__ == "current_commit_parser"
    assert current_commit_parser.__doc__ == "Get the currently-configured commit parser"
    assert getattr(current_commit_parser(), "__name__") == "parse"

# Generated at 2022-06-24 02:00:26.999334
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser.__init__ import parse

    def my_parser(message):
        return {"version": "1.2.3", "type": "minor", "subject": message}

    # Normal configuration
    assert current_commit_parser() == parse
    # Redefine configuration
    config["commit_parser"] = "semantic_release.tests.test_setup_cfg.my_parser"
    assert current_commit_parser() == my_parser
    # Missing function
    config["commit_parser"] = (
        "semantic_release.tests.test_setup_cfg.absent_function"
    )
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-24 02:00:30.873384
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        import git.cmd

        current_changelog_components()
    except ImproperConfigurationError:
        assert False, "This env should be properly configured"

# Generated at 2022-06-24 02:00:33.982664
# Unit test for function overload_configuration
def test_overload_configuration():
    # This function is used to test the function overload_configuration
    @overload_configuration
    def test_function(define: list = None):
        return define

    define_list = ["package_name=test_package"]
    assert define_list == test_function(define=define_list)
    assert config["package_name"] == "test_package"

# Generated at 2022-06-24 02:00:38.058206
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_overload_configuration(message, define=None):
        print(message)
        return message

    test_overload_configuration("initial", define=["token=12345678"])
    assert config["token"] == "12345678"
    config.clear()

# Generated at 2022-06-24 02:00:41.460072
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import CommitNote, ReleaseNote

    components = current_changelog_components()
    assert ReleaseNote in components
    assert CommitNote in components

# Generated at 2022-06-24 02:00:45.917901
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release
    import copy
    # The function to be decorated
    def func(config):
        return semantic_release.__version__

    func = overload_configuration(func)
    # Define a custom configuration
    config_local = copy.deepcopy(config)
    func(define=['hello=world'])
    assert config_local != config

# Generated at 2022-06-24 02:00:48.536322
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config.get = lambda key: "semantic_release.commit_parser.parse_commits"
    assert current_commit_parser().__name__ == "parse_commits"



# Generated at 2022-06-24 02:00:54.813007
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.BreakingChange, semantic_release.changelog.Deprecation'

    expected = [
        semantic_release.changelog.BreakingChange, 
        semantic_release.changelog.Deprecation
    ]

    assert current_changelog_components() == expected

# Generated at 2022-06-24 02:00:59.666678
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def funct(*args, **kwargs):
        return kwargs

    assert funct(*["a", "b"], **{"define": ["hello=world", "version=1.0.1"]}) == {
        "define": ["hello=world", "version=1.0.1"]
    }
    assert config["hello"] == "world"
    assert config["version"] == "1.0.1"

# Generated at 2022-06-24 02:01:00.730433
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:01:02.512270
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser.__name__ == "current_commit_parser"
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:01:03.671632
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == config.get("commit_parser")

# Generated at 2022-06-24 02:01:08.317862
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def testfunc(bar):
        assert bar == "bar_blah"
    testfunc(bar="bar_blah", define=["foo=blah", "bar=bar_blah"])



# Generated at 2022-06-24 02:01:13.449078
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """ current_commit_parser() should return the same value as in configuration file """
    expected = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser() == expected

# Generated at 2022-06-24 02:01:15.782959
# Unit test for function current_commit_parser
def test_current_commit_parser():
    path = config["commit_parser"]

    assert current_commit_parser() is not None and path.split(".")[-1] == "parser"



# Generated at 2022-06-24 02:01:19.840377
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """current_commit_parser returns the semrelparser.parser module if
    config['commit_parser'] = semrelparser.parser
    """
    import semantic_release.hvcs  # pylint: disable=import-outside-toplevel
    config["commit_parser"] = "semantic_release.hvcs.parser"
    assert current_commit_parser() == semantic_release.hvcs.parser

# Generated at 2022-06-24 02:01:22.257197
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) > 0
    assert len(config.get("changelog_components").split(",")) == len(current_changelog_components())



# Generated at 2022-06-24 02:01:26.617772
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.format_summary,
        semantic_release.changelog.components.format_pull_requests,
        semantic_release.changelog.components.format_issues,
        semantic_release.changelog.components.format_commits,
    ]

# Generated at 2022-06-24 02:01:34.111076
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    :param current_changelog_components:
    :return:
    """

    # unit test 1
    config["changelog_components"] = "semantic_release.changelog.components.compute_commits"
    components = current_changelog_components()  # call test function
    assert components[0].__name__ == "compute_commits"
    # assert components[0] == semantic_release.changelog.components.compute_commits

    # unit test 2
    config["changelog_components"] = "semantic_release.changelog.components.compute_commits,semantic_release.changelog.components.compute_version"
    components = current_changelog_components()

# Generated at 2022-06-24 02:01:44.234558
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def overload_config(define=None):
        if define is not None:
            for param in define:
                pair = param.split("=", maxsplit=1)
                if len(pair) == 2:
                    config[str(pair[0])] = pair[1]

    assert config.get("changelog_components") == "OursChangelogComponent"
    assert config.get("changelog_capitalize") == "True"
    assert config.get("changelog_scope") == "True"
    assert config.get("check_build_status") == "True"
    assert config.get("commit_parser") == "semantic_release.commit_parser.get_default_commit_parser"
    assert config.get("major_on_zero") == "False"

# Generated at 2022-06-24 02:01:52.978105
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def _test_func(config):
        return config["test_key"]

    # Set configuration variables as type str
    config["test_key"] = "test_value"

    # Set configuration variables as type int
    config["test_key2"] = 1

    # Check if values of the configuration variables have been changed
    assert _test_func(define=["test_key=overloaded_test_key"]) == "overloaded_test_key"
    assert _test_func(define=["test_key2=2"]) == "2"

# Generated at 2022-06-24 02:01:56.755915
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert type(current_changelog_components()) == list

# Generated at 2022-06-24 02:02:03.267162
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog
    from . import changelog_components_2
    config["changelog_components"] = "semantic_release.changelog.create,semantic_release.changelog_components_2.create_2"
    result = current_changelog_components()
    assert result == [changelog.create, changelog_components_2.create_2]

# Generated at 2022-06-24 02:02:06.186938
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import CommitParser
    from semantic_release.parser import parse

    commit_parser = current_commit_parser()
    assert isinstance(commit_parser, CommitParser)
    assert commit_parser.parser == parse

# Generated at 2022-06-24 02:02:11.098221
# Unit test for function current_changelog_components
def test_current_changelog_components():
    class MockConfig:
        def __init__(self,changelog_components):
            self.changelog_components = changelog_components

    config = MockConfig("semantic_release.changelog.components.feature.add_change")
    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "add_change"

# Generated at 2022-06-24 02:02:16.553189
# Unit test for function current_commit_parser
def test_current_commit_parser():
    with open("setup.cfg", "w") as f:
        f.write("""[semantic_release]
                    commit_parser = semantic_release.commit_parser.simple_parser
                """)
    assert current_commit_parser() == importlib.import_module(
        "semantic_release.commit_parser"
    ).simple_parser



# Generated at 2022-06-24 02:02:24.160358
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Test that current_changelog_components returns the proper function
    """
    import semantic_release.changelog.component as component
    components = current_changelog_components()
    assert components[0] == component.changelog_references
    assert components[1] == component.changelog_author
    assert components[2] == component.changelog_date
    assert components[3] == component.changelog_tasks
    assert components[4] == component.changelog_contributors

# Generated at 2022-06-24 02:02:32.137730
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Test default parser
    default_parser = current_commit_parser()
    assert default_parser.__name__ == 'parser'

    # Test custom parser
    config["commit_parser"] = "semantic_release.utils.custom_parser"
    custom_parser = current_commit_parser()
    assert custom_parser.__name__ == 'custom_parser'

    # Test default parser if "commit_parser" is not defined in config
    del config["commit_parser"]
    default_parser = current_commit_parser()
    assert default_parser.__name__ == 'parser'



# Generated at 2022-06-24 02:02:37.475492
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test checks if the content of the "define" array will be added to
    the global "config" variable.
    """
    config_before = config.copy()
    my_function(define=["test=test1", "test2=test3"])
    assert config != config_before
    assert config["test"] == "test1"
    assert config["test2"] == "test3"



# Generated at 2022-06-24 02:02:38.633937
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert isinstance(current_changelog_components(), list)

# Generated at 2022-06-24 02:02:40.788621
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog.components
    assert current_changelog_components() == [
        semantic_release.changelog.components.categories
    ]

# Generated at 2022-06-24 02:02:49.028252
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = 0

    @overload_configuration
    def test(define):
        return "test"

    for i, test_data in enumerate([(0, "0"), (1, "1"), ("a", "a")]):
        assert config["test"] == test_data[0]
        assert test(define=["test=" + str(test_data[1])]) == "test"
        assert config["test"] == test_data[1]

# Generated at 2022-06-24 02:02:49.947881
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:02:52.192987
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config_from_file = _config()
    components = current_changelog_components()
    assert len(config_from_file) == len(components)

# Generated at 2022-06-24 02:02:58.812186
# Unit test for function overload_configuration
def test_overload_configuration():
    import inspect
    import sys
    import os

    # Get the old list of command line arguments
    old_argv = sys.argv

    def func():
        pass

    wrapped_func = overload_configuration(func)

    @overload_configuration
    def func_with_deco():
        pass

    # Test function
    sys.argv = ["sr", "--define", "foo=bar", "--define", "bar=foo"]
    func_with_deco()
    assert config.get("foo") == "bar"
    assert config.get("bar") == "foo"

    # Test wrapper
    sys.argv = ["sr", "--define", "foo=baz", "--define", "bar=var"]
    wrapped_func()
    assert config.get("foo") == "baz"
   

# Generated at 2022-06-24 02:03:06.631738
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Given a configuration file with
    # changelog_components = ["semantic_release.changelog.components.breaking_changes", "semantic_release.changelog.components.fixes"]
    # when import the first changelog component
    module = "semantic_release.changelog.components.breaking_changes"
    components = [getattr(importlib.import_module(module), "breaking_changes")]
    # then the result should be equal to current_changelog_components()
    assert current_changelog_components() == components

# Generated at 2022-06-24 02:03:10.365964
# Unit test for function overload_configuration
def test_overload_configuration():
    config['test_key'] = 'old_value'
    @overload_configuration
    def test_func(define):
        return config['test_key']
    assert test_func(define=['test_key=new_value']) == 'new_value'
    assert test_func() == 'old_value'
    assert test_func(define=['test_key=new_value']) == 'new_value'

# Generated at 2022-06-24 02:03:13.971555
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == 'get_merge_commits'
    assert components[1].__name__ == 'get_version_bump_commits'

# Generated at 2022-06-24 02:03:18.700920
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelogs.changelog_writer,
        semantic_release.changelogs.commit_writer,
    ]

# Generated at 2022-06-24 02:03:20.450239
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history.parsers import parse_commit

    assert current_commit_parser() == parse_commit



# Generated at 2022-06-24 02:03:21.878429
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config.get = lambda x, y: "semantic_release.commit_parser.standard_parser"
    assert current_commit_parser()


# Generated at 2022-06-24 02:03:26.242150
# Unit test for function overload_configuration
def test_overload_configuration():
    config["key"] = "value"
    config["another_key"] = "another_value"

    @overload_configuration
    def function_to_wrap(define=[]):
        assert config["key"] == "value"
        assert config["another_key"] == "another_value"

    function_to_wrap(define=["key=new_value"])
    assert config["key"] == "new_value"
    assert config["another_key"] == "another_value"

    assert function_to_wrap.__name__ == "function_to_wrap"
    assert function_to_wrap.__doc__ is None

# Generated at 2022-06-24 02:03:28.355421
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.get_commit_message"
    assert(current_commit_parser() == semantic_release.commit_parser.get_commit_message)
    

# Generated at 2022-06-24 02:03:32.746389
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test current_commit_parser

    :returns: None
    """
    os.environ["PYTHONPATH"] = f"{os.getcwd()}/tests/resources/config"
    parser = current_commit_parser()
    assert parser() == "test"



# Generated at 2022-06-24 02:03:42.144092
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog as main_pckg

    @config.overload_configuration
    def test(define=None):
        components = current_changelog_components()
        assert len(components) == 4
        assert all(callable(c) for c in components)
        assert components[0] is main_pckg.commit_parser_component
        assert components[1] is main_pckg.issue_component
        assert components[2] is main_pckg.pr_component
        assert components[3] is main_pckg.other_component

    test()

    @config.overload_configuration
    def test(define=None):
        components = current_changelog_components()
        assert len(components) == 4

# Generated at 2022-06-24 02:03:51.615084
# Unit test for function overload_configuration
def test_overload_configuration():
    config["plugin_config.key1"] = "value1"
    config["plugin_config.key2"] = "value2"

    @overload_configuration
    def test_function(key1, key2):
        return "test_function", key1, key2

    result_function, result_key1, result_key2 = test_function(
        key1 = "value1",
        key2 = "value2",
        define = ["plugin_config.key2=modified_value2"],
    )
    assert result_function == "test_function"
    assert result_key1 == "value1"
    assert result_key2 == "modified_value2"

# Generated at 2022-06-24 02:03:55.640613
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_initial_value"

    @overload_configuration
    def funct(define):
        return config["test_key"]

    assert funct(define="test_key=test_value") == "test_value"

# Generated at 2022-06-24 02:03:56.570021
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "parser"

# Generated at 2022-06-24 02:03:58.949332
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = getattr(importlib.import_module("semantic_release.commit_parser.default"),
                            "commit_parser")
    from semantic_release.config import current_commit_parser
    assert current_commit_parser() == commit_parser

# Generated at 2022-06-24 02:04:01.987535
# Unit test for function overload_configuration
def test_overload_configuration():
    overload_configuration(lambda x: x)(define=["foo=bar"])
    assert config.get("foo") == "bar"

    overload_configuration(lambda x: x)(define=["foo=baz"])
    assert config.get("foo") == "baz"

    overload_configuration(lambda x: x)(define=["foo=baz", "bar=baz"])
    assert config.get("foo") == "baz"
    assert config.get("bar") == "baz"


# Unit tests for function get_current_commit_parser

# Generated at 2022-06-24 02:04:06.496776
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog

    result = current_changelog_components()
    assert result == [get_changelog]

# Generated at 2022-06-24 02:04:07.345629
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert True == callable(components[0])

# Generated at 2022-06-24 02:04:15.502962
# Unit test for function overload_configuration
def test_overload_configuration():
    # Define a configuration that we use in our test
    class Config(UserDict):
        def __init__(self):
            self["version_variable_name"] = "__version__"

    # Define an object containing the content of the "define" argument
    defined_args = ["define=version_variable_name=__version__;user=you", "verbose"]

    # Define the function we are going to use
    def foo(verbose):
        return config["user"]

    # Wrap it
    wrapped_foo = overload_configuration(foo)

    # Assign the test configuration to the config variable
    config = Config()

    # Call the wrapped function
    assert wrapped_foo(*defined_args) == "you"

    # Assert that the new key-value has been correctly set
    assert "user" in config.data

# Generated at 2022-06-24 02:04:20.703402
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser

    def parse(*args, **kwargs):
        pass

    assert parse == current_commit_parser()

    # This parser is not defined
    config["commit_parser"] = "foo.bar"

    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-24 02:04:22.072898
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == config.get("commit_parser")

# Generated at 2022-06-24 02:04:26.038309
# Unit test for function overload_configuration
def test_overload_configuration():
    conf = {**{}, **config}
    @overload_configuration
    def fn(define=None):
        pass
    fn(define=["foo=bar"])

    assert config["foo"] == "bar"
    config.clear()
    config.update(conf)

# Generated at 2022-06-24 02:04:32.026965
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"
    assert current_commit_parser(
        ":hammer: feat: a new feature\n\ndescription\nCloses #123"
    ) == {
        "type": "feat",
        "scope": "",
        "subject": "a new feature\n\ndescription",
        "body": "",
        "issues": [],
    }



# Generated at 2022-06-24 02:04:33.067224
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None


# Generated at 2022-06-24 02:04:36.812611
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # This method returns the current list of changelog components
    # The default config is configured to return the "Unreleased"
    # component
    assert current_changelog_components()[0].__name__ == "unreleased"

# Generated at 2022-06-24 02:04:47.407154
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.docker_images,semantic_release.changelog_components.issue_tracker"
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == semantic_release.changelog_components.docker_images
    assert components[1] == semantic_release.changelog_components.issue_tracker

    # test with a wrong import path
    config["changelog_components"] = "semantic_release.changelog_components.docker_images,semantic_release.changelog_components.wrong_import_path"

# Generated at 2022-06-24 02:04:50.973040
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changes import link_changes_to_commits, issue_and_pr_references

    assert current_changelog_components() == [
        link_changes_to_commits,
        issue_and_pr_references,
    ]

# Generated at 2022-06-24 02:05:01.340534
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def no_op_func(*args, **kwargs):
        pass
    from .defaults import default_changelog_components
    from .changelog_components import ISSUE_RE

    components = current_changelog_components()
    assert [ISSUE_RE, no_op_func] == [c for c in components]

    config["changelog_components"] = "semantic_release.changelog_components.ISSUE_RE"
    components = current_changelog_components()
    assert [ISSUE_RE] == components

    components = current_changelog_components()
    assert [ISSUE_RE] == components

    config["changelog_components"] = ""
    components = current_changelog_components()

# Generated at 2022-06-24 02:05:07.809362
# Unit test for function overload_configuration
def test_overload_configuration():
    # Here we use the fact that we can mock the get() method for testing
    def function(a):
        return a

    function_overloaded = overload_configuration(function)

    config.get = lambda x : None
    assert function_overloaded(a="b") == "b"
    assert config == {}
    assert function_overloaded(a="b",define=["c=d"]) == "b"
    assert config["c"] == "d"
    assert function_overloaded(a="b",define=["c=d","e=f"]) == "b"
    assert config["c"] == "d"
    assert config["e"] == "f"
    assert function_overloaded(a="b",define=["c=d","e","f=g=h"]) == "b"

# Generated at 2022-06-24 02:05:08.368605
# Unit test for function overload_configuration
def test_overload_configuration():
    assert overload_configuration

# Generated at 2022-06-24 02:05:10.865233
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser:parser"
    assert current_commit_parser() is parser


# Generated at 2022-06-24 02:05:14.824255
# Unit test for function current_commit_parser
def test_current_commit_parser():
    get_parser = current_commit_parser()
    assert "parse" in get_parser.__name__

# Generated at 2022-06-24 02:05:17.163303
# Unit test for function current_commit_parser
def test_current_commit_parser():
    importlib.import_module("semantic_release.hvcs")
    assert current_commit_parser() is not None


# Generated at 2022-06-24 02:05:23.735632
# Unit test for function overload_configuration
def test_overload_configuration():
    # Change the config dictionary to have a pair to be changed
    config["test_new_key"] = "test_value"

    @overload_configuration
    def function(define):
        print(config["test_new_key"])

    function(define=["test_new_key=test_new_value"])

    # The new value should be the one provided in the decorator's arguments
    assert config["test_new_key"] == "test_new_value"



# Generated at 2022-06-24 02:05:25.340547
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:05:33.867906
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test config setting
    config2 = config.copy()
    @overload_configuration
    def test(define):
        pass
    test(define=["a=3"])
    assert config["a"] == "3"
    assert config2["a"] is None
    test(define=["a=3","b=4"])
    assert config["a"] == "3"
    assert config["b"] == "4"
    config = config2
    assert config["a"] is None
    assert config["b"] is None
    # Test config function

# Generated at 2022-06-24 02:05:39.788483
# Unit test for function current_commit_parser
def test_current_commit_parser():
    semantic_release.config.config.commit_parser = "semantic_release.commit_parser.parse_commit"
    assert semantic_release.config.current_commit_parser() == semantic_release.commit_parser.parse_commit