

# Generated at 2022-06-24 01:55:45.503546
# Unit test for function overload_configuration
def test_overload_configuration():
    config["first"] = "old value"
    
    @overload_configuration
    def test_function(first):
        return config[first]

    assert test_function(first="first", define=["first=new value"]) == "new value"

# Generated at 2022-06-24 01:55:50.926040
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(my_param: str = None):
        return my_param

    assert test_func(define=["my_param=value"]) == "value"

# Generated at 2022-06-24 01:55:55.600004
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(lambda x, define: define)
    assert func(None, define=["a=b"]) == ["a=b"]
    assert func(None, define=["a=b", "b=c"]) == ["a=b", "b=c"]
    assert func(None, define=["a=b", "b=c", "c"]) == ["a=b", "b=c", "c"]

# Generated at 2022-06-24 01:55:58.277936
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration.
    """
    from semantic_release.cli import get_version

    assert get_version.__name__ == "get_version"
    assert get_version(define=["version_variable=version"]).__name__ == "wrap"

# Generated at 2022-06-24 01:56:04.460773
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def changelog_comp(context):
        print("oi")

    changelog_comp_mock = "semantic_release.tests.commands.conftest.changelog_comp"
    config["changelog_components"] = changelog_comp_mock

    components = current_changelog_components()
    assert components[0] == changelog_comp



# Generated at 2022-06-24 01:56:05.261915
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    # check if the parser is a Callable :
    assert callable(parser)

# Generated at 2022-06-24 01:56:10.987691
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Ensure the correct callable is returned"""
    from semantic_release.changelog import get_latest_version

    assert current_changelog_components() == get_latest_version



# Generated at 2022-06-24 01:56:20.725301
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Example of external component.

    To use it, add to your `pyproject.toml`:

        [tool.semantic_release]
        changelog_components = "tests.test_settings.example_changelog_component"

    """
    def example_changelog_component(
        changelog: str, commits: List, release_version: str, previous_version: str
    ) -> str:
        changelog = "\n".join([changelog, "```diff"])
        for commit in commits:
            changelog = "\n".join([changelog, f"- {commit.message}"])
        changelog = "\n".join([changelog, "```"])
        return changelog

    return example_changelog_component



# Generated at 2022-06-24 01:56:23.091709
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = current_commit_parser()
    assert callable(commit_parser)



# Generated at 2022-06-24 01:56:27.051068
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for function overload_configuration"""
    config["define"] = "define"

    @overload_configuration
    def test(define):
        return config

    assert len(test.__doc__) > 0
    assert test(define=["define=defined"])["define"] == "defined"

# Generated at 2022-06-24 01:56:31.587999
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        pass

    test_func(define=["a=b", "c=d"])
    assert ("a" in config)
    assert (config["a"] == "b")
    assert ("c" in config)
    assert (config["c"] == "d")
    test_func()

# Generated at 2022-06-24 01:56:38.149291
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import main

    old_parse_args = main._parse_args

    def mock_parse_args():
        return {"define": ["token=123", "commit_parser=noop"]}

    main._parse_args = mock_parse_args
    main()

    assert config["token"] == "123"
    assert config["commit_parser"] == "noop"

    main._parse_args = old_parse_args

# Generated at 2022-06-24 01:56:42.597627
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(a=3, define=["b=2"]):
        return {a: config["b"]}

    assert overload_configuration(func)() == {3: "2"}

# Generated at 2022-06-24 01:56:47.518158
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function(arg1, define):
        return config[arg1], define

    decorated_function = overload_configuration(test_function)

    assert decorated_function("arg1", "new_description=mydescription") == ("mydescription", "new_description=mydescription")

# Generated at 2022-06-24 01:56:48.333264
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components()

# Generated at 2022-06-24 01:56:48.870300
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 01:56:51.017510
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """ Assert that the configuration variable 'changelog_components' can be retrieved """
    components = current_changelog_components()
    assert len(components) > 0


# Generated at 2022-06-24 01:56:56.235072
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test to ensure proper funcitonality of the `.current_commit_parser` function"""
    import semantic_release.hvcs.vcs.commit_parser

    commit_parser = current_commit_parser()

    assert commit_parser == semantic_release.hvcs.vcs.commit_parser.default

# Generated at 2022-06-24 01:57:04.011710
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Check if the changelog components are loaded properly"""
    # not executable by default
    assert current_changelog_components() == [
        from_changelog,
        from_commits,
        from_commits_summary_section,
    ]

    # executable
    changelog_components = "semantic_release.changelog_components.from_changelog," \
                           "semantic_release.changelog_components.from_commits," \
                           "semantic_release.changelog_components.from_commits_summary_section"
    config["changelog_components"] = changelog_components

# Generated at 2022-06-24 01:57:11.373872
# Unit test for function overload_configuration
def test_overload_configuration():
    config["user_agent"] = "old_agent"
    @overload_configuration
    def test_func(a, b=1, define=[]):
        assert a == 1
        assert b == 2
        assert config["user_agent"] == "new_agent"

    test_func(1, 2, define="user_agent=new_agent")
    assert config["user_agent"] == "old_agent"

# Generated at 2022-06-24 01:57:12.197965
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

# Generated at 2022-06-24 01:57:16.044348
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main

    assert main.__name__ == "main"

    @overload_configuration
    def main_overloaded(**kwargs):
        return main(**kwargs)

    assert main_overloaded.__wrapped__ == main

    # Call main_overloaded with define "define=foo" and test that config
    # has been updated.
    main_overloaded(define=["define=foo"])
    assert config["define"] == "foo"

# Generated at 2022-06-24 01:57:19.310376
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser()
        == current_commit_parser
    ), "The current configured comit parser is the default one"

# Generated at 2022-06-24 01:57:30.359022
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # We expect an error, because there is no function "not_existing" in module semantic_release.changelog_components
    with pytest.raises(ImproperConfigurationError) as exc_info:
        config['changelog_components'] = 'semantic_release.changelog_components.bug_id, semantic_release.changelog_components.not_existing'
        assert 'changelog_components' in config
        assert 'changelog_components' in config.keys()
        assert current_changelog_components() == [semantic_release.changelog_components.bug_id, semantic_release.changelog_components.not_existing]

    # first component does not exist

# Generated at 2022-06-24 01:57:32.852794
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser

    assert current_commit_parser() == semantic_release.commit_parser.parse_commits

# Generated at 2022-06-24 01:57:41.808863
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release
    import semantic_release.changelog
    expected_output = [
        semantic_release.changelog.append_changes,
        semantic_release.changelog.prepend_changes,
    ]
    semantic_release.config["changelog_components"] = ",".join(
        ["semantic_release.changelog.append_changes","semantic_release.changelog.prepend_changes"]
    )
    assert current_changelog_components() == expected_output
    semantic_release.config["changelog_components"] = ""


# Generated at 2022-06-24 01:57:46.585319
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert(
        current_commit_parser()
        == "semantic_release.commit_parser.default_commit_parser"
    )



# Generated at 2022-06-24 01:57:51.328765
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog

    assert current_changelog_components() == Changelog.component_list

# Generated at 2022-06-24 01:57:57.857350
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components == [
        semantic_release.changelog.components.render_breaking_change,
        semantic_release.changelog.components.render_issues,
        semantic_release.changelog.components.render_features,
        semantic_release.changelog.components.render_fixes,
    ]

# Generated at 2022-06-24 01:58:06.931972
# Unit test for function overload_configuration
def test_overload_configuration():
    config["a"] = 1
    config["b"] = {"a": 0, "b": 1}
    config["c"] = [1, 2, 3]

    @overload_configuration
    def test_func(define, kwargs):
        return kwargs

    result = test_func(define=["a=2", "b={'a': 1, 'b': 2}", "c=[]"], kwargs=config)
    assert result["a"] == 2
    assert result["b"] == {"a": 1, "b": 2}
    assert result["c"] == []

# Generated at 2022-06-24 01:58:13.238188
# Unit test for function overload_configuration
def test_overload_configuration():
    def mocked_func(a):
        return a

    mocked_func = overload_configuration(mocked_func)

    # An additional key named "custom_key" is added into the config dict
    mocked_func(define=["custom_key=foo"])
    assert config["custom_key"] == "foo"

    # The config remains unchanged
    assert config["custom_key"] == "foo"

# Generated at 2022-06-24 01:58:15.778043
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.utils import validate_parser

    parser = current_commit_parser()
    validate_parser(parser)

# Generated at 2022-06-24 01:58:22.609812
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the decorator "overload_configuration" by setting 2 values in config and
    testing if they can then be used as parameters
    """
    assert "name" not in config
    assert "email" not in config

    # This function is decorated by overload_configuration
    @overload_configuration
    def test(define):
        # Check if the value is set in config
        assert config["name"] == "fake"
        assert config["email"] == "fake@mail.com"

    test(define=["name=fake", "email=fake@mail.com"])

# Generated at 2022-06-24 01:58:23.999190
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test function current_commit_parser"""
    assert current_commit_parser()



# Generated at 2022-06-24 01:58:28.147553
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the addition of arguments in the config file
    """

    def test_function(define):
        return config["define"]

    result = test_function(define='define=value')
    assert result == 'value'

# Generated at 2022-06-24 01:58:29.534749
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import Changelog  # noqa

    assert Changelog in current_changelog_components()

# Generated at 2022-06-24 01:58:40.522845
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert os.environ.get("COMMIT_PARSER") != "semantic_release.hvcs.github_commit_parser"
    assert "commit_parser" not in config
    try:
        parser = current_commit_parser()
        assert parser.__name__ == "github_commit_parser"
    except ImproperConfigurationError:
        pass
    os.environ["COMMIT_PARSER"] = "semantic_release.hvcs.github_commit_parser"
    assert os.environ.get("COMMIT_PARSER") == "semantic_release.hvcs.github_commit_parser"
    parser = current_commit_parser()
    assert parser.__name__ == "github_commit_parser"
    # Remove the environment variable
    del os.environ["COMMIT_PARSER"]

# Generated at 2022-06-24 01:58:41.754130
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()("foo") == ("", "foo")


# Generated at 2022-06-24 01:58:48.196504
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Semantic release import current parser in its setup with:
    # --commit-parser semantic_release.commit_parser.default_parser
    # so we need to create a fake setup.cfg with:
    # [semantic_release]
    # commit_parser = semantic_release.commit_parser.default_parser
    # Where semantic_release.commit_parser.default_parser is the function to import
    # Then we import config of semantic_release, and we should have the parser
    # previously imported

    # We assert that current_commit_parser returns the default_parser one
    assert current_commit_parser.__name__ == "default_parser"

# Generated at 2022-06-24 01:58:49.934638
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    output = ["changelog_version_component", "changelog_body_component"]
    for i in range(len(components)):
        assert components[i].__name__ == output[i]

# Generated at 2022-06-24 01:58:54.048046
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function():
        return None

    test_function()
    assert config == _config()

    test_function(define=["foo=bar"])
    assert config["foo"] == "bar"

    config["foo"] = "baz"
    test_function()
    assert config["foo"] == "baz"



# Generated at 2022-06-24 01:58:57.155818
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import issue_component, title_component, body_component

    assert current_changelog_components() == [issue_component, title_component, body_component]



# Generated at 2022-06-24 01:58:59.863974
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_parser

    config["commit_parser"] = "semantic_release.commit_parser:default_parser"
    assert current_commit_parser() == default_parser



# Generated at 2022-06-24 01:59:02.156383
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define: List[str]) -> None:
        pass

    test_func(define=["a=b"])
    assert config["a"] == "b"

# Generated at 2022-06-24 01:59:07.242899
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Check that we are selecting the correct commit parser

    This test may be fragile, depending on how the semantic release packages
    are installed, but we should make every effort to pass.
    """
    from semantic_release.commit_parser import parser as expected

    assert current_commit_parser() == expected



# Generated at 2022-06-24 01:59:10.392720
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 2
    assert (
        "semantic_release.changelog.changelog_component_update_tasks"
        in repr(current_changelog_components()[1])
    )

# Generated at 2022-06-24 01:59:12.070139
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current = current_changelog_components()
    assert len(current) == 1
    assert callable(current[0])

# Generated at 2022-06-24 01:59:15.703050
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main

    main(["--help"], define=["config.option1=value1", "config.option2=value2"])
    assert config["option1"] == "value1"
    assert config["option2"] == "value2"
    assert config["option2"] != "value1"

# Generated at 2022-06-24 01:59:20.627620
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components() returns the correct component functions"""
    import semantic_release.plugins


# Generated at 2022-06-24 01:59:24.847612
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "default_commit_parser"



# Generated at 2022-06-24 01:59:34.886599
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # define empty, exception will be raised in current_changelog_components function
    config["changelog_components"] = ""
    try:
        current_changelog_components()
    except ImproperConfigurationError as e:
        assert str(e) == "Unable to import changelog component ''"

    # define with a valid function name
    config["changelog_components"] = "semantic_release.changelog_components.issue_component"
    assert current_changelog_components()[0] == importlib.import_module(
        "semantic_release.changelog_components"
    ).issue_component

    # define with a valid function name
    config["changelog_components"] = "changelog_components.issue_component"

# Generated at 2022-06-24 01:59:43.766360
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}
    @overload_configuration
    def test(*args, **kwargs):
        pass

    test(define=["my_var=my_value"])
    assert config == {"my_var": "my_value"}

    config = {}
    test(define=["my_var=my_value", "my_var2=my_value2"])
    assert config == {"my_var": "my_value", "my_var2": "my_value2"}

    config = {}
    test(define=["my_var="])
    assert config == {"my_var": ""}

    config = {}
    test(define=["my_var"])
    assert config == {}


# Generated at 2022-06-24 01:59:46.207839
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This function is supposed to be called by
    test_overload_configuration decorator
    """
    pass


if __name__ == "__main__":
    print(config)

# Generated at 2022-06-24 01:59:53.639176
# Unit test for function overload_configuration
def test_overload_configuration():
    from tests.unit.helpers import get_config

    get_config_overloaded = overload_configuration(get_config)

    # Missing key
    assert get_config_overloaded(define=["release_commit_message=message"]) == get_config()

    # Valid key
    assert (
        get_config_overloaded(define=["changelog_capitalize=True"])
        == dict(get_config(), changelog_capitalize=True)
    )

    # Wrong usage
    assert (
        get_config_overloaded(define=["changelog_capitalize", "False"])
        == dict(get_config(), changelog_capitalize=None)
    )

# Generated at 2022-06-24 01:59:58.048623
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test if overload_configuration edit the content of config according to
    the define array"""
    @overload_configuration
    def sample_function(define):
        config["pip_args"] = define["pip_args"]
        return sample_function(define={"pip_args": "--path"})
    assert config["pip_args"] == "--path"

# Generated at 2022-06-24 02:00:00.554215
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        return
    raise AssertionError('ImproperConfigurationError not raised')

# Generated at 2022-06-24 02:00:07.335553
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.UnreleasedSectionComponent,semantic_release.changelog_components.ChangelogEntryComponent,semantic_release.changelog_components.VersionSectionComponent"
    assert len(current_changelog_components()) == 3

# Generated at 2022-06-24 02:00:14.931942
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key1"] = "test_value1"
    config["test_key2"] = "test_value2"

    @overload_configuration
    def overloaded_function(define=None, *args, **kwargs):
        return None

    overloaded_function(define=["test_key1=new_value1", "test_key2=new_value2"])

    assert config["test_key1"] == "new_value1"
    assert config["test_key2"] == "new_value2"

# Generated at 2022-06-24 02:00:19.778901
# Unit test for function overload_configuration
def test_overload_configuration():
    from .actions import main as main_action
    from .actions import upload_to_pypi as upload_to_pypi_action

    assert config["next_version"] == "0.0.1"

    main_action(define=["next_version=0.0.2"])

    assert config["next_version"] == "0.0.2"

    upload_to_pypi_action(define=["next_version=0.0.3"])

    assert config["next_version"] == "0.0.3"

# Generated at 2022-06-24 02:00:30.000924
# Unit test for function overload_configuration
def test_overload_configuration():
    def suite(define):
        print(config["dry_run"])
        print(config["define"])
        print(config["token"])
    suite = overload_configuration(suite)
    assert "define" not in config
    assert config["dry_run"] == "False"
    suite(define="define=test")
    assert "define" in config
    assert config["define"] == "test"
    assert config["dry_run"] == "True"
    assert "token" in config
    suite(define=["dry_run=False", "token=new_token"])
    assert "define" in config
    assert config["define"] == "test"
    assert config["dry_run"] == "False"
    assert config["token"] == "new_token"

# Generated at 2022-06-24 02:00:36.256223
# Unit test for function overload_configuration
def test_overload_configuration():
    from .tools import semantic_release
    from .utils import define
    import configparser
    import os

    # Overload configuration
    semantic_release.main(command="prepare", define=["tag_name=test", "tag=True"])

    # Check config
    cwd = os.getcwd()
    parser = configparser.ConfigParser()
    parser.read(os.path.join(cwd, 'setup.cfg'))
    assert parser['semantic_release']['tag_name'] == 'test'
    assert parser['semantic_release']['tag'] == 'True'

    # Restore configuration
    catch_release_commands(["prepare", define("tag_name="), define("tag=")])



# Generated at 2022-06-24 02:00:45.526723
# Unit test for function overload_configuration
def test_overload_configuration():
    init_config = _config()
    # This test function has to be at the same level of the function
    # overload_configuration
    @overload_configuration
    def edit_config(define=None):
        """Test function for overload_configuration"""

    edit_config(define=["test=ok"])
    # The value of config is modified
    assert config["test"] == "ok"
    config.clear()
    config.update(init_config)

    edit_config(define=["test=ok", "test2=test2"])
    assert config["test"] == "ok"
    assert config["test2"] == "test2"

    # Test when the argument "define" is missing
    edit_config()

# Generated at 2022-06-24 02:00:46.659842
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:00:52.790094
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = {"first_key": "original", "second_key": "original"}

    @overload_configuration
    def _overload_configuration(define):
        return config

    first_config = _overload_configuration(define=["first_key=new"])
    assert first_config["first_key"] == "new"
    assert first_config["second_key"] == "original"

    second_config = _overload_configuration(define=["second_key=new"])
    assert second_config["first_key"] == "new"
    assert second_config["second_key"] == "new"

# Generated at 2022-06-24 02:00:55.299932
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commits"
    assert current_commit_parser().__name__ == "parse_commits"



# Generated at 2022-06-24 02:01:01.888775
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """This test checks if the function current_changelog_components() is working properly using
    mock.

    The function get_changelog_components() is mock in order to return this string:
    "semantic_release.changelog.components.KarmaComponent,semantic_release.changelog.components.CodebaseComponent".

    The function importlib.import_module is also mock in order to return a module object.

    The function getattr is also mock in order to return a function object.

    Current function return a list with the 2 function objects.
    """
    importlib.import_module = {}

# Generated at 2022-06-24 02:01:05.772171
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.unreleased_notes,semantic_release.changelog.components.issue_references,semantic_release.changelog.components.commit_messages"
    assert len(current_changelog_components()) == 3

# Generated at 2022-06-24 02:01:10.554576
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test1"] = "orig1"
    config["test2"] = "orig2"

    @overload_configuration
    def function_to_test(define=[]):
        pass

    function_to_test(define=["test1=new1", "test2=new2"])

    assert config["test1"] == "new1"
    assert config["test2"] == "new2"

# Generated at 2022-06-24 02:01:16.747605
# Unit test for function overload_configuration
def test_overload_configuration():
    def dummy_func(define):
        assert config["verbose"] == "1"
        assert config["branch"] == "test_branch_name"
        assert config["ambient"] == "1"
    wrapped_func = overload_configuration(dummy_func)
    wrapped_func(define=["verbose", "1", "branch=test_branch_name", "ambient=1"])

# Generated at 2022-06-24 02:01:24.397907
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog

    components = current_changelog_components()
    assert changeset.get_commits in components
    assert changeset.get_changes_in_commit in components
    assert changelog.git_describe in components
    assert changelog.get_message_body in components
    assert changelog.get_message_summary in components
    assert changelog.get_message_type in components
    assert changelog.is_version_tag in components
    assert changelog.tag_version in components
    assert changelog.write_changelog in components
    assert changelog.git_describe in components



# Generated at 2022-06-24 02:01:25.402427
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-24 02:01:26.254600
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:01:30.193982
# Unit test for function overload_configuration
def test_overload_configuration():
    config["first"] = "initial"
    config["second"] = "initial"

    @overload_configuration
    def func(define):
        return config

    assert func(define=["first=changed"])["first"] == "changed"
    assert func(define=["second=changed"])["second"] == "changed"
    assert func(define=["third=changed"])["third"] is None

# Generated at 2022-06-24 02:01:34.897344
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = {"key": "value"}

    @overload_configuration
    def func(define):
        pass

    func(define="test=test")
    assert config["test"] == "test"
    func(define=["test=test"])
    assert config["test"] == "test"
    func(define=["key=new_value"])
    assert config["key"] == "new_value"
    func(define=["test=test"])
    assert len(config.keys()) == 3
    test_config["key"] = "value"
    assert config["key"] == "value"
    assert config["test"] == "test"

# Generated at 2022-06-24 02:01:42.770993
# Unit test for function overload_configuration
def test_overload_configuration():
    config_backup = config.copy()
    def test_func(a, b, define=None):
        return a, b

    decorated_func = overload_configuration(test_func)
    assert decorated_func('a', 'b') == ('a', 'b')
    assert config == config_backup
    assert decorated_func(1, 2, define=["foo=bar", "bar=baz"]) == (1, 2)
    assert config["foo"] == "bar"
    assert config["bar"] == "baz"
    assert config != config_backup

# Generated at 2022-06-24 02:01:49.967330
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(foo):
        return config[foo]

    assert f("name") == "semantic_release"
    assert f("define", foo="name=something", define=["bar=baz"]) == "something"
    assert config["bar"] == "baz"
    assert f("bar") == "baz"



# Generated at 2022-06-24 02:01:53.414284
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # check that current_commit_parser return parser
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:01:56.491210
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-24 02:02:04.210145
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    assert config.get("changelog_components") == "changelog.components"

    config["changelog_components"] = "changelog2.components"
    assert config.get("changelog_components") == "changelog2.components"

    @overload_configuration
    def function(define):
        pass

    function(define=["changelog_components=changelog.newcomponents"])
    assert config.get("changelog_components") == "changelog.newcomponents"

# Generated at 2022-06-24 02:02:08.904509
# Unit test for function current_changelog_components
def test_current_changelog_components():
    _config_from_pyproject = current_changelog_components()
    assert len(_config_from_pyproject) > 0
    assert type(_config_from_pyproject[0]) == Callable


# Generated at 2022-06-24 02:02:20.520959
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test that function current_commit_parser correctly reads the
    commit_parser path in setup.cfg or pyproject.toml
    """

    # If no commit parser is specified, it should work with the default one
    assert current_commit_parser().__name__ == "parse_commits"

    # If a custom commit parser is specified, it should work as expected
    config["commit_parser"] = "semantic_release.tests.test_configuration.parse_commits"
    assert current_commit_parser().__name__ == "parse_commits"

    # If something goes wrong, the function should raise an error
    with pytest.raises(ImproperConfigurationError):
        config["commit_parser"] = "semantic_release.tests.test_configuration.no_parse_commits"
        current_commit_parser()




# Generated at 2022-06-24 02:02:31.003761
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {"test": "foo"}
    def fake_function(define):
        return config['test']

    test_overload_configuration.fakefunc = fake_function
    test_overload_configuration.fakefunc = overload_configuration(
        test_overload_configuration.fakefunc
    )

    assert test_overload_configuration.fakefunc(define=['test=bar']) == 'bar'
    assert test_overload_configuration.fakefunc(define=['foo=bar']) == 'foo'
    assert test_overload_configuration.fakefunc(define=['foo=bar', 'test=baz']) == 'baz'

# Generated at 2022-06-24 02:02:34.777771
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(define):
        return config["message"]

    assert foo(define=["message=bar"]) == "bar"

# Generated at 2022-06-24 02:02:38.634585
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        changelog_components.start_version,
        changelog_components.genre_change,
        changelog_components.end_version,
    ]

# Generated at 2022-06-24 02:02:44.182660
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import features
    from semantic_release.changelog_components import breaking_changes
    from semantic_release.changelog_components import deprecations
    from semantic_release.changelog_components import bugs
    from semantic_release.changelog_components import enhancements
    from semantic_release.changelog_components import miscellaneous
    assert current_changelog_components() == [
        features,
        breaking_changes,
        deprecations,
        bugs,
        enhancements,
        miscellaneous,
    ]

# Generated at 2022-06-24 02:02:55.151490
# Unit test for function current_commit_parser
def test_current_commit_parser():
    test_parser_defined_in_file = "semantic_release.commit_parser.commit_parser"
    test_parser_defined_in_setup_cfg = "semantic_release.commit_parser.commit_parser"
    test_parser_defined_in_cli = "semantic_release.commit_parser.commit_parser"
    assert (
        current_commit_parser()
        == importlib.import_module(test_parser_defined_in_file).commit_parser
    )
    assert (
        current_commit_parser()
        == importlib.import_module(test_parser_defined_in_setup_cfg).commit_parser
    )
    assert (
        current_commit_parser()
        == importlib.import_module(test_parser_defined_in_cli).commit_parser
    )

# Generated at 2022-06-24 02:02:56.136112
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

# Generated at 2022-06-24 02:02:59.869022
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.issue_components,semantic_release.changelog.components.fix_components"
    current_changelog_components()
    

# Generated at 2022-06-24 02:03:01.337205
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_commit_parser():
        pass

    config["commit_parser"] = "test_release.test_config.test_commit_parser"

    assert current_commit_parser() == test_commit_parser

# Generated at 2022-06-24 02:03:02.593963
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_components

    assert get_components() == current_changelog_components()

# Generated at 2022-06-24 02:03:05.588112
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.commit_parser, semantic_release.changelog_components.github_release"
    current_changelog_components()

# Generated at 2022-06-24 02:03:08.453602
# Unit test for function current_commit_parser
def test_current_commit_parser():
    @current_commit_parser()
    def parse_commit(commit_message: str) -> dict:
        return {"commits": commit_message}

    assert parse_commit("Hello world!") == {"commits": "Hello world!"}

# Generated at 2022-06-24 02:03:09.925105
# Unit test for function current_commit_parser
def test_current_commit_parser():
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()

# Generated at 2022-06-24 02:03:18.611159
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test that the current_changelog_components() function returns a
    list of functions as expected.
    """
    def func1():
        pass

    def func2():
        pass

    def func3():
        pass

    expected_changelog_list = [func1, func2, func3]

    config["changelog_components"] = "tests.commontest.func1,tests.commontest.func2,tests.commontest.func3"
    changelog_components_list = current_changelog_components()
    for i, item in enumerate(changelog_components_list):
        assert (
            expected_changelog_list[i].__name__ == changelog_components_list[i].__name__
        )



# Generated at 2022-06-24 02:03:20.372792
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    """
    from semantic_release.hvcs.git import parse_commits
    assert current_commit_parser() == parse_commits

# Generated at 2022-06-24 02:03:21.770312
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import default_commit_parser

    assert current_commit_parser() == default_commit_parser

# Generated at 2022-06-24 02:03:29.774126
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import BreakingChange
    from semantic_release.changelog import Deprecation
    from semantic_release.changelog import Feature
    from semantic_release.changelog import Fix
    from semantic_release.changelog import Security

    try:
        components = current_changelog_components()
        assert all(
            [
                isinstance(component, type)
                and issubclass(component, Fix)
                for component in components
            ]
        )
    except ImproperConfigurationError:
        pass



# Generated at 2022-06-24 02:03:40.804943
# Unit test for function overload_configuration
def test_overload_configuration():
    """The test doesn't modify the global config.
    """
    config_copy = config.copy()

    @overload_configuration
    def foo(config):
        return config

    assert config_copy == foo(config)

    @overload_configuration
    def bar(define, config):
        return config

    assert config_copy == bar(define={}, config=config)

    @overload_configuration
    def baz(define, *args, config, **kwargs):
        return config

    assert baz(define={}, *{}, config={}, **{}) == {}
    assert config_copy == baz(define={"hello=world"}, *{}, config=config, **{})
    assert config_copy == baz(define={"hello="}, *{}, config=config, **{})

# Generated at 2022-06-24 02:03:49.513653
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""
    # pylint: disable=import-outside-toplevel, wrong-import-position
    from semantic_release.changelog_components import (
        breaking_change_component,
        build_metadata_component,
        closes_issues_component,
        expand_commit_type,
        owner_component,
        links_component,
    )
    # pylint: enable=import-outside-toplevel, wrong-import-position

    expected = [
        breaking_change_component,
        expand_commit_type,
        links_component,
        owner_component,
        closes_issues_component,
        build_metadata_component,
    ]
    result = current_changelog_components()
    assert expected == result

# Generated at 2022-06-24 02:03:50.657428
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser"""
    current_commit_parser()

# Generated at 2022-06-24 02:03:52.245699
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commithooks import parse_commits

    assert current_commit_parser() == parse_commits

# Generated at 2022-06-24 02:03:57.287128
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release
    import semantic_release.cli
    temp_config = {"key": "value"}
    semantic_release.cli.config = temp_config
    @overload_configuration
    def function(defined):
        return defined

    assert function(defined="key=newvalue") == "key=newvalue"
    assert temp_config == {"key": "newvalue"}

# Generated at 2022-06-24 02:04:04.236752
# Unit test for function overload_configuration
def test_overload_configuration():
    config["a"] = 0
    config["b"] = 0

    @overload_configuration
    def test():
        return

    test(define=["a=b"])
    assert config["a"] == "b"

    test(define=["c=d"])
    assert config["c"] == "d"

    test(define=["a=1", "b=2"])
    assert config["a"] == "1"
    assert config["b"] == "2"

# Generated at 2022-06-24 02:04:07.645219
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.hooks

    assert current_commit_parser() is semantic_release.hooks.default_commit_parser



# Generated at 2022-06-24 02:04:09.092263
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None


# Generated at 2022-06-24 02:04:18.643625
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for the overload_configuration.

    The purpose of this unit test is to verify that the decorator overload_configuration()
    can actually overload the value of a configuration parameter, as requested in #103.

    The test also verifies that the value of a configuration parameter is not changed
    if a wrong syntax is used.
    """

    @overload_configuration
    def test_function(define=[]):
        return

    # Case where everything is OK
    test_function(define=["token_auth=my-token"])
    assert config.get("token_auth") == "my-token"

    # Case where a wrong syntax is used
    test_function(define=["token_auth"])
    assert config.get("token_auth") == "my-token"

# Generated at 2022-06-24 02:04:21.594532
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.data["changelog_components"] = "semantic_release.changelog.components.new_release_configuration_name"
    assert current_changelog_components()



# Generated at 2022-06-24 02:04:30.039205
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(bar, define=None):
        return config[bar]

    from .settings import config as settings_config
    old_config = settings_config.copy()

# Generated at 2022-06-24 02:04:41.405628
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main
    config["commit_parser"] = "semantic_release.hvcs.commit_parser.default"
    assert main(["version"]) is None
    config["commit_parser"] = "semantic_release.hvcs.commit_parser.default"
    assert main(["version", "--define", "commit_parser=semantic_release.hvcs.commit_parser.comment"]) is None
    config["commit_parser"] = "semantic_release.hvcs.commit_parser.default"
    assert main(["version"]) is None
    config["commit_parser"] = "semantic_release.hvcs.commit_parser.default"
    assert main(["version", "--define", "commit_parser=semantic_release.hvcs.commit_parser.comment"])

# Generated at 2022-06-24 02:04:45.857081
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"
    current_commit_parser()



# Generated at 2022-06-24 02:04:55.090345
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This decorator                                            overload_configuration
    gets the content of the "define" array and edits          \
    the "config" dictionary according to the key/value pairs. -
    """


# Generated at 2022-06-24 02:04:56.233415
# Unit test for function current_commit_parser
def test_current_commit_parser():
    with current_commit_parser() as parser:
        assert parser()

# Generated at 2022-06-24 02:04:59.315778
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f():
        pass
    f(define=['name=value'])
    assert config['name'] == 'value'

# Generated at 2022-06-24 02:05:08.960001
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogEntry

    class Config:
        def __init__(self, changelog_components):
            self.changelog_components = changelog_components

    class FakeEntry(ChangelogEntry):
        def __init__(self, title, body, footer):
            self.title = title
            self.body = body
            self.footer = footer

        def get_formatted_string(self):
            return f"{self.title}\n{self.body}\n{self.footer}"

    class FakeChangelog(Changelog):
        def __init__(self, entries):
            self.entries = entries

        def get_unreleased_entries(self):
            return self

# Generated at 2022-06-24 02:05:14.224336
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.unreleased_changes, semantic_release.changelog.components.breaking_changes, semantic_release.changelog.components.features, semantic_release.changelog.components.bugs, semantic_release.changelog.components.deprecations'
    assert type(current_changelog_components()[0]) == Callable


# Generated at 2022-06-24 02:05:19.607049
# Unit test for function current_changelog_components
def test_current_changelog_components():
    tests = [
        (("1"), ["1"]),
        (("1,2"), ["1", "2"]),
        (("1,2,3"), ["1", "2", "3"]),
        (("1,2,3,"), ["1", "2", "3"]),
        ((","), []),
    ]
    # Run unit tests
    for param, expected in tests:
        config["changelog_components"] = param
        result = current_changelog_components()
        assert result == expected

# Generated at 2022-06-24 02:05:23.707792
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import next_version
    from semantic_release.changelog_components import previous_version
    config["changelog_components"] = "semantic_release.changelog_components.next_version,semantic_release.changelog_components.previous_version"
    assert current_changelog_components() == [next_version, previous_version]

# Generated at 2022-06-24 02:05:30.511979
# Unit test for function overload_configuration
def test_overload_configuration():
    config.update(test_configuration={"test_key": "test_value"})
    @overload_configuration
    def foo(define=None):
        if define is not None:
            config["test_configuration"].update({
                "foo_key": "foo_value"
            })
        return config

    assert config["test_configuration"] == {"test_key": "test_value"}

    foo(define=["test_configuration.foo_key=foo_value"])

    assert config["test_configuration"] == {
        "test_key": "test_value",
        "foo_key": "foo_value",
    }

# Generated at 2022-06-24 02:05:33.706456
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import SemanticReleaseChangeLog, ChangedComponent, BreakingChangeComponent
    assert current_changelog_components() == [SemanticReleaseChangeLog.format_header, ChangedComponent.rewrite, SemanticReleaseChangeLog.rewrite_links, BreakingChangeComponent.rewrite]

# Generated at 2022-06-24 02:05:36.040638
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "changelog.components.body,changelog.components.footer"

    assert current_changelog_components() == [body, footer]

# Generated at 2022-06-24 02:05:39.345077
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import commit_autogen
    assert current_changelog_components() == [commit_autogen]

# Generated at 2022-06-24 02:05:48.930197
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .readme import parse_readme_sections
    from .changelog import parse_changelog_sections

    changelog_components_test = config["changelog_components"]
    config["changelog_components"] = (
        "semantic_release.readme.parse_readme_sections"
    )

    assert current_changelog_components() == [parse_readme_sections]

    config["changelog_components"] = (
        "semantic_release.readme.parse_readme_sections,"
        "semantic_release.changelog.parse_changelog_sections"
    )
    assert current_changelog_components() == [
        parse_readme_sections,
        parse_changelog_sections,
    ]
