

# Generated at 2022-06-24 01:55:45.426911
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [], "the list should be empty"
    config["changelog_components"] = "semantic_release.changelog_components.components"
    components = current_changelog_components()
    assert len(components) == 3, "the length of the list should be 3"
    for f in components:
        assert f(None, None) == None, "each function should return None"

# Generated at 2022-06-24 01:55:49.578478
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert(current_commit_parser() == current_commit_parser())



# Generated at 2022-06-24 01:55:53.940166
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_components

    config.update(
        {
            "changelog_components": (
                "semantic_release.changelog.SummaryComponent, "
                "semantic_release.changelog.CommitsComponent"
            )
        }
    )

    components = current_changelog_components()
    assert components == get_components()

# Generated at 2022-06-24 01:55:56.085338
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_commit_parser

    assert current_commit_parser() == default_commit_parser
    assert not current_commit_parser() is default_commit_parser

# Generated at 2022-06-24 01:56:03.206200
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(branch_name, define):
        return branch_name

    assert test_function("master", define=None) == "master"

    # use of a definition
    assert test_function("master", define=["key=toto"]) == "master"
    assert config["key"] == "toto"

# Generated at 2022-06-24 01:56:05.372844
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser as commit_parser
    assert config["commit_parser"] == "semantic_release.commit_parser.parse"
    assert current_commit_parser() == commit_parser.parse



# Generated at 2022-06-24 01:56:08.550242
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests if the configuration is set properly."""

    @overload_configuration
    def test_func(func_arg, define):
        return func_arg, config.get("test_key")

    assert test_func("test_arg", define=["test_key=test_value"]) == ("test_arg", "test_value")

# Generated at 2022-06-24 01:56:11.072422
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .utils import parse_commit_message

    assert current_commit_parser() == parse_commit_message

# Generated at 2022-06-24 01:56:20.831334
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import main
    from .plugins import version_check
    import argparse
    import sys

    class MockArgs:
        def __init__(self):
            self.define = ['test=test']

    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers()
    subparsers.required = True
    subparsers.choices = {"version_check": "", "publish": ""}

    main_parser = subparsers.add_parser(
        "version_check", parents=[version_check.make_parser()]
    )
    main_parser.set_defaults(func=main)

    # Set the sys.argv to include our test arguments
    sys.argv = [sys.argv[0], "version_check"]

    # Parse the arguments


# Generated at 2022-06-24 01:56:26.421571
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test that current_commit_parser loads the expected value from setup.cfg.
    """
    from .commit_parser import default_commit_parser

    # MyPy does not allow mocking get() for a dict...
    _config = config
    _config.get = lambda *args, **kwargs: "semantic_release.default_commit_parser"
    assert current_commit_parser() == default_commit_parser


# Generated at 2022-06-24 01:56:30.074164
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(lambda x: config["foo"])
    assert func("bar", define=["foo=foobar"]) == "foobar"
    assert func("bar", define=["foo=foobar", "yep=1"]) == "foobar"

# Generated at 2022-06-24 01:56:32.920250
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import parse_date, parse_commits, parse_version

    assert (
        current_changelog_components() == [parse_date, parse_commits, parse_version]
    )

# Generated at 2022-06-24 01:56:35.501477
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test that "overload_configuration" function works as expected
    """
    @overload_configuration
    def test_config():
        assert config.get("test_param") == "test_value"

    test_config(define=["test_param=test_value"])

# Generated at 2022-06-24 01:56:41.838172
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test whether current_commit_parser function works correctly.
    """
    from semantic_release.commit_parser import default_parser

    config["commit_parser"] = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser() == default_parser
    config["commit_parser"] = (
        "semantic_release.commit_parser.default_parser.default_parser"
    )
    assert current_commit_parser() == default_parser

# Generated at 2022-06-24 01:56:47.687312
# Unit test for function overload_configuration
def test_overload_configuration():
    # pylint: disable=protected-access
    def test_func(define=None):
        pass

    test_func = overload_configuration(test_func)

    # The only way to verify that the config is updated is to test the private
    # attribute, as it cannot be reached in any other way
    test_func(define=["plugin_config.key=value"])
    assert config.data["plugin_config.key"] == "value"

    test_func(define=["plugin_config.key=value2"])
    assert config.data["plugin_config.key"] == "value2"

# Generated at 2022-06-24 01:56:48.821167
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 01:56:50.730214
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components
    assert get_changelog_components() == current_changelog_components()

# Generated at 2022-06-24 01:56:55.469245
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test with a wrong changelog_components path
    config["changelog_components"] = "wrong/path"
    with pytest.raises(ImproperConfigurationError):
        current_changelog_components()

# Generated at 2022-06-24 01:56:56.704575
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-24 01:56:58.660413
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser.__name__
        == "parse_commit_message_with_footer"
    )

# Generated at 2022-06-24 01:57:07.572346
# Unit test for function overload_configuration
def test_overload_configuration():
    # Patching the configuration dictionary
    config.get = lambda x: ""

    @overload_configuration
    def my_func(*args, **kwargs):
        pass

    # You can't overload this value, it's hardcoded in config.py
    assert config.get("upload_to_pypi") == ""

    # Let's overload it
    my_func(define=["upload_to_pypi=True"])
    assert config.get("upload_to_pypi") == "True"

# Generated at 2022-06-24 01:57:14.342002
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Test default values
    assert config.get("commit_parser") == "semantic_release.commit_parser"
    assert current_commit_parser()

    # Test explicit values
    config["commit_parser"] = "semantic_release.tests.test_config.DummyParser"
    assert current_commit_parser()

    # Test ImportError
    config["commit_parser"] = "semantic_release.tests.dummy_parser"
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass



# Generated at 2022-06-24 01:57:25.479953
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(foo, bar, define=[]):
        pass

    # Ensure that the function works with no parameters
    test_function(foo="baz", bar="qux")

    # Ensure that we can pass a single key=value pair
    test_function(foo="baz", bar="qux", define=["spam=eggs"])
    assert config["spam"] == "eggs"

    # Ensure that the dictionary is reset after each test
    test_function(foo="baz", bar="qux")
    assert not config.get("spam")

    # Ensure that the dictionary is reset after each test
    test_function(foo="baz", bar="qux", define=["spam=eggs", "hello=world"])

# Generated at 2022-06-24 01:57:33.810313
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(**kwargs):
        return [kwargs.get(arg) for arg in ["arg1", "arg2", "arg3"]]

    assert test_function(define=["arg1=foo", "arg2=bar", "arg3=baz"]) == [
        "foo",
        "bar",
        "baz",
    ]
    assert test_function(define=["arg1=foo", "arg2=bar"]) == ["foo", "bar", None]
    assert test_function(define=["arg1=foo"]) == ["foo", None, None]
    assert test_function(define=[]) == [None, None, None]

# Generated at 2022-06-24 01:57:35.122246
# Unit test for function overload_configuration

# Generated at 2022-06-24 01:57:40.155676
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import default_commit_parser

    # test default value
    assert current_commit_parser() == default_commit_parser
    # test overrided value
    config["commit_parser"] = "semantic_release.custom_parser.parser"
    assert current_commit_parser() != default_commit_parser

# Generated at 2022-06-24 01:57:47.141514
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config_data = """
[tool.semantic_release]
changelog_components = changelog.components.author,changelog.components.issue
    """
    parser = configparser.ConfigParser()
    parser.read_string(config_data)
    config.get = parser.get

# Generated at 2022-06-24 01:57:53.225082
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()("Merge pull request #24\n\nCR: Adding pre-release script to docs") == [
        {
            "message": "Merge pull request #24",
            "pr_number": "24",
            "type": "other",
            "issues": [],
            "references": ["#24"],
        }
    ]

# Generated at 2022-06-24 01:58:00.641213
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Test that the current_changelog_components function returns the expected
    result.
    """
    # Given
    changelog_components = config.get("changelog_components")

# Generated at 2022-06-24 01:58:09.345634
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import generate_changelog

    config["changelog_components"] = "semantic_release.changelog.generate_changelog"
    components = current_changelog_components()

    assert isinstance(components, list)
    assert len(components) == 1
    assert components[0] == generate_changelog

# Generated at 2022-06-24 01:58:10.627472
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "default"
    from . import commit_parser

    assert current_commit_parser() == commit_parser.default_commit_parser


# Generated at 2022-06-24 01:58:16.498238
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def overloaded_func(a, b, define):
        return a + b, define

    assert overloaded_func(1, 2, define=["define=foo"]) == (3, "foo")
    assert overloaded_func(1, 2, define=["define=bar"]) == (3, "bar")
    assert overloaded_func(1, 2, define=["other=bar"]) == (3, "other=bar")
    assert overloaded_func(1, 2, define=["define=foo"]) == (3, "foo")
    assert overloaded_func(1, 2, define=["define=bar"]) == (3, "bar")

# Generated at 2022-06-24 01:58:20.864647
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components
    get_components = current_changelog_components()
    components = [
        get_components,
        semantic_release.changelog_components.get_current_version,
    ]
    assert components == get_components
# Test ends here

# Generated at 2022-06-24 01:58:27.510351
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.get.return_value = "semantic_release.changelog_components.current_version"
    assert current_changelog_components()[0] == current_version
    config.get.return_value = "semantic_release.changelog_components.tiny_version_change"
    assert current_changelog_components()[0] == tiny_version_change
    config.get.return_value = "semantic_release.changelog_components.github_changelog"
    assert current_changelog_components()[0] == github_changelog

# Generated at 2022-06-24 01:58:29.021267
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        current_changelog_components()[0].__name__
        == "changelog_components_features"
    )

# Generated at 2022-06-24 01:58:35.181741
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # pylint: disable=redefined-outer-name
    from semantic_release.history import default_commit_parser

    assert current_commit_parser() == default_commit_parser



# Generated at 2022-06-24 01:58:45.563246
# Unit test for function current_changelog_components
def test_current_changelog_components():
    _config_from_pyproject = _config_from_pyproject
    _config = config
    
    # "unittest" is a proper component
    _config_from_pyproject = lambda path: {"tool": {"semantic_release": {"changelog_components": "semantic_release.changelog.unittest.Unittest"}}}
    _config = _config()
    assert("semantic_release.changelog.unittest.Unittest" in _config.get("changelog_components"))
    components = current_changelog_components()
    assert(len(components) == 1)
    assert(components[0].__name__ == "Unittest")
    assert(components[0].__module__ == "semantic_release.changelog.unittest")

   

# Generated at 2022-06-24 01:58:50.973028
# Unit test for function overload_configuration
def test_overload_configuration():
    config["commit_parser"] = "semantic_release.commit_parser.standard"
    config["changelog_components"] = "semantic_release.changelog.components.commit_summary"

    @overload_configuration
    def test_func(*args, **kwargs):
        assert config["commit_parser"] == "semantic_release.commit_parser.standard"
        assert config["changelog_components"] == "semantic_release.changelog.components.commit_summary"

    test_func(define=["commit_parser=semantic_release.commit_parser.standard_with_prefix"])
    assert config["commit_parser"] == "semantic_release.commit_parser.standard_with_prefix"

# Generated at 2022-06-24 01:58:52.889040
# Unit test for function current_commit_parser
def test_current_commit_parser():
    settings = current_commit_parser()
    assert callable(settings)



# Generated at 2022-06-24 01:58:56.532329
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.history.components.default"
    assert current_changelog_components() == [default]

# Generated at 2022-06-24 01:58:58.863801
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the function current_commit_parser()."""
    parser = current_commit_parser()
    # Assert the type of the parser
    assert callable(parser)

# Generated at 2022-06-24 01:59:01.523817
# Unit test for function overload_configuration
def test_overload_configuration():
    config['hello'] = 'so long'
    @overload_configuration
    def my_func(define):
        assert config['hello'] == 'world'

    my_func(define=['hello=world'])



# Generated at 2022-06-24 01:59:03.918940
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"

    @overload_configuration
    def func(define):
        return

    func(define=["test=value"])
    assert config["test"] == "value"

# Generated at 2022-06-24 01:59:09.224694
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components
    """
    # Test when there is a list of components
    def change_log_components():
        print('Test')

    components = [change_log_components]
    assert current_changelog_components() == components


# Generated at 2022-06-24 01:59:15.634643
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def changelog_components1():
        return []

    def changelog_components2():
        return []

    config["changelog_components"] = "semantic_release.changelog_components.changelog_components1, " \
                                     "semantic_release.changelog_components.changelog_components2"

    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == changelog_components1
    assert components[1] == changelog_components2

# Generated at 2022-06-24 01:59:16.574638
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 01:59:21.673969
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Function current_changelog_components should return a list of functions """
    from . import changelog

    config["changelog_components"] = "semantic_release.changelog:get_changelog_sections"
    cl_components = current_changelog_components()
    assert len(cl_components) == 1
    assert cl_components[0] == changelog.get_changelog_sections

# Generated at 2022-06-24 01:59:24.918612
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history import parse_commits

    assert current_commit_parser() == parse_commits

# Generated at 2022-06-24 01:59:28.343239
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_content, changelog_diff
    assert current_changelog_components() == [changelog_content, changelog_diff]

# Generated at 2022-06-24 01:59:37.313841
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(a, b, define=[]):
        return a, b, config["c"]

    @overload_configuration
    def func_overload(a, b, define=[]):
        return a, b, config["c"]

    # Config is empty by default
    config.clear()
    assert func(1, 2) == (1, 2, None)
    assert func_overload(1, 2) == (1, 2, None)

    # The overload shouldn't work with an empty list
    config["c"] = "d"
    assert func(1, 2) == (1, 2, "d")
    assert func_overload(1, 2) == (1, 2, "d")

    # Add a key 'a' with the value 'b'
    config.clear()

# Generated at 2022-06-24 01:59:42.305339
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None, var1=None):
        pass

    test_function(var1="my variable")
    assert config["var1"] != "value"

    test_function(var1="value")
    assert config["var1"] == "value"

# Generated at 2022-06-24 01:59:49.509559
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        parse_commit_headers,
        parse_commit_body,
    )

    # can add new value to config
    config["changelog_components"] = "semantic_release.changelog.parse_commit_headers"
    assert current_changelog_components() == [parse_commit_headers]
    
    # can return multiple values
    config["changelog_components"] = "semantic_release.changelog.parse_commit_headers,semantic_release.changelog.parse_commit_body"
    assert current_changelog_components() == [parse_commit_headers, parse_commit_body]

# Generated at 2022-06-24 01:59:50.148113
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-24 01:59:53.817209
# Unit test for function current_commit_parser
def test_current_commit_parser():
    func = current_commit_parser()
    commit = func('feat(demo): add new feature')
    assert commit['type'] == 'feat'
    assert commit['scope'] == 'demo'
    assert commit['subject'] == 'add new feature'
    assert commit['body'] == ''



# Generated at 2022-06-24 01:59:56.667028
# Unit test for function current_changelog_components
def test_current_changelog_components():
    path = "semantic_release.components"
    module = ".".join(path.split(".")[:-1])
    components = getattr(importlib.import_module(module), path.split(".")[-1])
    components = current_changelog_components()
    assert components

# Generated at 2022-06-24 01:59:58.985951
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()


# Generated at 2022-06-24 02:00:06.509689
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def test_component():
        return ["A", "B"]

    def test_component():
        return ["C", "D"]

    config["changelog_components"] = f"{__name__}.test_component"

    components = current_changelog_components()

    assert len(components) == 1
    assert components[0]() == ["A", "B"]

    config["changelog_components"] = f"{__name__}.test_component,{__name__}.test_component2"

    components = current_changelog_components()

    assert len(components) == 2
    assert components[0]() == ["A", "B"]
    assert components[1]() == ["C", "D"]

# Generated at 2022-06-24 02:00:12.742577
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changes as changes
    assert isinstance(current_changelog_components(), list)
    assert len(current_changelog_components()) > 0
    assert isinstance(current_changelog_components()[0], type(changes.get_default))



# Generated at 2022-06-24 02:00:18.505254
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_param"] = "0"

    @overload_configuration
    def test_overload(param1, param2, define=None):
        return param1, param2, config["test_param"]

    param1 = "1"
    param2 = "2"
    assert test_overload(param1, param2) == (param1, param2, "0")

    define = ["test_param=2"]
    assert test_overload(param1, param2, define=define) == (param1, param2, "2")

# Generated at 2022-06-24 02:00:29.289650
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogSection
    from semantic_release.changelog import ChangelogCommit
    from semantic_release.changelog import ChangelogRelease
    from semantic_release.changelog import ChangelogPreClassification
    from semantic_release.changelog import ChangelogPostClassification
    from semantic_release.changelog import ChangelogFooter
    from semantic_release.output import Output
    from semantic_release.output import CustomOutput
    from semantic_release.output import ConsoleOutput


# Generated at 2022-06-24 02:00:32.190624
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """This method checks if the current_commit_parser returns the parser
    defined in the setup.cfg"""

    from semantic_release.commit_parser import parser_for_standard_commits
    assert current_commit_parser() == parser_for_standard_commits



# Generated at 2022-06-24 02:00:35.676126
# Unit test for function current_commit_parser
def test_current_commit_parser():
    module = "semantic_release.commit_parser"
    name = "DefaultCommitParser"
    config["commit_parser"] = module + "." + name
    assert current_commit_parser().__name__ == name
    config["commit_parser"] = "invalid"
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass


# Generated at 2022-06-24 02:00:36.604767
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:00:47.029685
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test config value must be correct
    config["changelog_components"] = "semantic_release.changelog.components.custom_comp1,semantic_release.changelog.components.custom_comp2"

    # Test a good config value
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == "custom_comp1"
    assert components[1].__name__ == "custom_comp2"

    # Test empty attribute
    config["changelog_components"] = ""
    assert len(current_changelog_components()) == 0

    # Test wrong config value
    config["changelog_components"] = "fake.path"

# Generated at 2022-06-24 02:00:52.328933
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.components as components

    config.update({"changelog_components": "components.changelog_entry"})
    assert current_changelog_components() == [components.changelog_entry]

    config.update(
        {"changelog_components": "components.changelog_entry,components.issue_reference"}
    )
    assert current_changelog_components() == [
        components.changelog_entry,
        components.issue_reference,
    ]

# Generated at 2022-06-24 02:00:58.155820
# Unit test for function overload_configuration
def test_overload_configuration():
    # We need a new config for each test
    config_ = _config()

    def func(define):
        return config_['version_variable']

    decorate = overload_configuration(func)

    # Overload with a good value
    config_['version_variable'] = 'version_1'
    decorate(define=['version_variable=version_2'])
    assert func(define=['version_variable=version_2']) == 'version_2'

    # Overload with a bad value
    config_['version_variable'] = 'version_2'
    decorate(define=['version_variable='])
    assert func(define=['version_variable=']) == 'version_2'

    # Overload with a not existing parameter
    config_['version_variable'] = 'version_3'

# Generated at 2022-06-24 02:01:01.361961
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_function(message: str) -> str:
        return "Test"

    config["commit_parser"] = "semantic_release.test.test_configuration.test_function"

    assert current_commit_parser()("Not important") == "Test"



# Generated at 2022-06-24 02:01:06.630848
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commit

    orig_parser = config["commit_parser"]
    try:
        config["commit_parser"] = "semantic_release.commit_parser.parse_commit"
        assert current_commit_parser() is parse_commit
    finally:
        # Restore the original value
        config["commit_parser"] = orig_parser

# Generated at 2022-06-24 02:01:08.932693
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commit

    assert current_commit_parser() == parse_commit

# Generated at 2022-06-24 02:01:17.502913
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test :func:`semantic_release.settings.current_changelog_components`."""
    assert current_changelog_components() == [
        semantic_release.changelog.components.bug,
        semantic_release.changelog.components.breaking,
        semantic_release.changelog.components.enhancement,
        semantic_release.changelog.components.feature,
        semantic_release.changelog.components.other,
        semantic_release.changelog.components.security,
    ]

# Generated at 2022-06-24 02:01:25.701492
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(a, b=2, *args, c=3, d=4, **kwargs):
        return a, b, c, d

    func = overload_configuration(test_func)

    config["b"] = 5
    config["c"] = 6
    config["d"] = 7
    assert func(1) == (1, 5, 6, 7)

    config["b"] = 2
    config["c"] = 3
    config["d"] = 4
    assert func(1, 2, 3, c=6, d=7) == (1, 2, 6, 7)

    config["b"] = 2
    config["c"] = 3
    config["d"] = 4

# Generated at 2022-06-24 02:01:33.474574
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Simple test: Create list, modify config, test function
    parts = "changelog_components"
    values = ["tests.utils.parser.components.test_component_1", "tests.utils.parser.components.test_component_2"]
    config[parts] = values[0]
    assert len(current_changelog_components()) == 1
    config[parts] = values[1]
    assert len(current_changelog_components()) == 1
    config[parts] = ", ".join(values)
    assert len(current_changelog_components()) == 2

    # Now let's provoke an exception:
    config[parts] = "some.strange.module"

# Generated at 2022-06-24 02:01:41.829439
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test the function current_commit_parser
    """
    commit_parser_config = "semantic_release.commit_parser.default_commit_parser"

    # Test that the function return a function
    result = current_commit_parser()
    assert callable(result)

    # Test that the function use the default configuration
    assert config.get("commit_parser") == commit_parser_config

    # Test if an error is raised
    config.get.return_value = "wrong.import.Error"
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass


# Generated at 2022-06-24 02:01:46.230683
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def dummy_function(a, b, c=None, d=None):
        return (a, b, c, d)

    config = _config()
    config["changelog_components"] = "semantic_release.tests.test_config_helpers.dummy_function"
    assert current_changelog_components() == [dummy_function]

# Generated at 2022-06-24 02:01:52.143546
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(lambda a, b: print(f"{a} {b}"))
    args = [1, 2]
    func(*args) == None
    func(*args, define=["b=3", "a=4"]) == None
    kwargs = {"b": 3}
    func(**kwargs) == None
    func(**kwargs, define=["b=4", "a=1"]) == None

# Generated at 2022-06-24 02:01:54.934437
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert config.get("commit_parser") == "semantic_release.commit_parser:parse_semver"
    assert callable(current_commit_parser())


# Generated at 2022-06-24 02:02:01.804184
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    assert config["foo"] == "bar"

    @overload_configuration
    def test_overload_configuration_decorator(define):
        pass

    test_overload_configuration_decorator(define=["foo=fooz"])
    assert config["foo"] == "fooz"

# Generated at 2022-06-24 02:02:03.550283
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import default_components

    assert len(current_changelog_components()) == len(default_components)

# Generated at 2022-06-24 02:02:07.839759
# Unit test for function current_commit_parser
def test_current_commit_parser():
    fn = current_commit_parser()
    assert fn.__name__ == "_parse_commit"


# Generated at 2022-06-24 02:02:18.213400
# Unit test for function current_changelog_components

# Generated at 2022-06-24 02:02:24.188102
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.fixes:get_fixes"
    result = current_changelog_components()
    assert result[0].__name__ == "get_fixes"



# Generated at 2022-06-24 02:02:27.692641
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the function current_commit_parser
    """
    # test if the parser defined in the setup.cfg file is parsed correctly
    config["commit_parser"] = "semantic_release.commit_parser.standard_parser"
    parser = current_commit_parser()
    assert parser.__name__ == "standard_parser"

# Generated at 2022-06-24 02:02:31.353565
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        assert current_commit_parser()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-24 02:02:36.297251
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import main

    old_config = config.get("major_on_zero")
    main(["--define", "major_on_zero=False"], standalone_mode=False)
    assert config.get("major_on_zero") == "False"
    config["major_on_zero"] = old_config

# Generated at 2022-06-24 02:02:43.639534
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def print_config(**kwargs):
        print(kwargs)

    print_config(define=[])
    print("==========")
    print_config(define=["key1=val1", "key2=val2"])
    print("==========")
    print_config(define=["key1=val1", "key2=val2"], test="test")
    print("==========")
    print_config(define=["key1=val1", "key2=val2"], key1="val1bis")
    print("==========")
    print_config(define=["key1=val1", "key2=val2"], key1="val1bis", test="test")
    print("==========")

# Generated at 2022-06-24 02:02:46.870645
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()


# Generated at 2022-06-24 02:02:52.893150
# Unit test for function current_commit_parser
def test_current_commit_parser():
    fake_parser = lambda x: "fake_parser"

    # Test with default commit parser
    assert current_commit_parser()(None) == "changelog_entry"

    # Test with a custom commit parser
    default = config.get
    try:
        config.get = lambda _: "tests.test_config.fake_parser"
        assert current_commit_parser()(None) == "fake_parser"
    finally:
        config.get = default

# Generated at 2022-06-24 02:02:54.257196
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert type(current_changelog_components()[0]) == Callable



# Generated at 2022-06-24 02:02:58.417487
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Tests for current_commit_parser function."""
    import semantic_release.hvcs
    import semantic_release.commit_parser

    parser = current_commit_parser()
    assert parser == semantic_release.hvcs.parse_commit



# Generated at 2022-06-24 02:03:05.608202
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test checks that the configuration is correctly overloaded from CLI
    when the function "overload_configuration" is used as decorator.
    """
    @overload_configuration
    def test_func(define):
        pass

    assert "changelog_components" not in config

    test_func(define=['changelog_components=semantic_release.changelog'])

    assert config["changelog_components"] == 'semantic_release.changelog'

# Generated at 2022-06-24 02:03:16.578024
# Unit test for function overload_configuration
def test_overload_configuration():
    # Mock config for testing
    config = UserDict({"abc": "def"})

    # Empty define
    @overload_configuration
    def test_func_empty(**kwargs):
        return kwargs

    assert test_func_empty(define=[]) == {}

    # Correct define
    @overload_configuration
    def test_func_correct(**kwargs):
        return kwargs

    assert test_func_correct(define=["abc=123"]) == {}

    # Wrong define
    @overload_configuration
    def test_func_wrong(**kwargs):
        return kwargs

    assert test_func_wrong(define=["abc"]) == {"define": ["abc"]}

    # Multiple define

# Generated at 2022-06-24 02:03:21.881422
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main  # pylint: disable=unused-variable

    # "config" has no key "test"
    assert not (("test" in config) and (config["test"] == "ploum"))

    # Try to add key/value in "config" dict
    main(["--define", "test=ploum"])

    # Check if key/value have been added
    assert ("test" in config) and (config["test"] == "ploum")

# Generated at 2022-06-24 02:03:24.184425
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_function():
        assert config.get("commit_parser") == "semantic_release.commit_parser.parse"
        assert callable(current_commit_parser())



# Generated at 2022-06-24 02:03:24.842287
# Unit test for function current_commit_parser
def test_current_commit_parser(): 
    print(current_commit_parser)

# Generated at 2022-06-24 02:03:28.705826
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def _test_overload_configuration(define):
        assert config["foo"] == "bar"
        assert config["hello"] == "world"
        assert config["python"] == "3.7"
        return True

    args = {"define": ["foo=bar", "hello=world", "python=3.7"]}
    assert _test_overload_configuration(**args)

# Generated at 2022-06-24 02:03:32.355927
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-24 02:03:36.474110
# Unit test for function overload_configuration
def test_overload_configuration():
    from types import MethodType

    def foobar(define=None):
        return define

    overload_configuration(foobar)

    assert foobar(define=["foo=bar"]) == ["foo=bar"]

# Generated at 2022-06-24 02:03:47.110845
# Unit test for function overload_configuration
def test_overload_configuration():
    # Not real unit test, only functional test for coverage
    # Test simple overload
    @overload_configuration
    def my_func(define):
        pass
    my_func(define=["setting_1=value_1"])
    assert config["setting_1"] == "value_1"

    # Test multiple overload
    @overload_configuration
    def my_func2(define):
        pass
    my_func2(define=["setting_2=value_2", "setting_3=value_3"])
    assert config["setting_2"] == "value_2"
    assert config["setting_3"] == "value_3"

    # Test overload without value
    @overload_configuration
    def my_func3(define):
        pass
    my_func3(define=["setting_4"])

# Generated at 2022-06-24 02:03:53.821457
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()
    config["test"] = "test1"

    def test(test=None, define=None):
        return test

    test_with_overload = overload_configuration(test)

    assert test_with_overload(test="test2") == "test2"
    assert config["test"] == "test1"

    assert test_with_overload(define=["test=test3"]) == "test3"
    assert config["test"] == "test3"

    assert test_with_overload(define=["test=test4"]) == "test4"
    assert config["test"] == "test4"

# Generated at 2022-06-24 02:03:59.178231
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.hvcs.git import _get_git_commits_between_versions
    from semantic_release.hvcs.hg import _get_mercurial_commits_between_versions

    assert current_changelog_components()



# Generated at 2022-06-24 02:04:01.524492
# Unit test for function overload_configuration
def test_overload_configuration():
    expected_config = config.copy()
    expected_config["foo"] = "bar"

    @overload_configuration
    def func(define):
        pass

    func(define=["foo=bar"])
    assert config == expected_config



# Generated at 2022-06-24 02:04:08.494418
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    assert "test" in config.data

    @overload_configuration
    def dummy_call(define=None):
        return True

    assert "test" in config.data
    dummy_call(define="test=test2")
    assert "test2" == config["test"]

# Generated at 2022-06-24 02:04:14.847822
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test for module has function
    changelog_components = config.get("changelog_components").split(",")
    component_paths = changelog_components[0].split(".")
    module = ".".join(component_paths[:-1])
    component_function = component_paths[-1]
    m = importlib.import_module(module)
    assert hasattr(m, component_function)
    # Test for current_changelog_function_length
    component_length = current_changelog_components()
    assert len(component_length) == 2

# Generated at 2022-06-24 02:04:19.738812
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # [0]: make sure it returns a list
    # [1]: make sure the content is correct
    assert type(current_changelog_components()) == list
    assert current_changelog_components() == [changelog_preamble]


# Generated at 2022-06-24 02:04:24.979014
# Unit test for function current_changelog_components
def test_current_changelog_components():

    from .changelog_components import body, type, scope, breaking, issues

    components = [
        body,
        type,
        scope,
        breaking,
        issues,
    ]

    config["changelog_components"] = ",".join([str(component) for component in components])

    try:
        assert current_changelog_components() == components
    finally:
        config["changelog_components"] = "semantic_release.changelog_components.body,semantic_release.changelog_components.type,semantic_release.changelog_components.scope,semantic_release.changelog_components.breaking,semantic_release.changelog_components.issues"



# Generated at 2022-06-24 02:04:28.222571
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-24 02:04:33.898198
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release
    import semantic_release.cli

    @overload_configuration
    def test_func(define):
        pass

    def check_value(*key):
        assert config.get(*key)

    def check_type(*key):
        assert isinstance(config.get(*key), type(key[-1]))

    semantic_release.cli.overload_configuration = overload_configuration
    config.clear()

    # Test with list of 'define' parameters
    test_func(define=["key1=value1", "key2=value2", "key3=value3", "key4=value4"])

    check_value("key1", "value1")
    check_value("key2", "value2")
    check_value("key3", "value3")

# Generated at 2022-06-24 02:04:37.053558
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog

    components = current_changelog_components()

    assert len(components) == 2
    assert components[0] is changelog.common
    assert components[1] is changelog.fixes

# Generated at 2022-06-24 02:04:44.193720
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.components import Issues, Commits, ChangelogEntry
    from semantic_release.history import CommitNote
    assert current_changelog_components() == [Issues, Commits, ChangelogEntry]
    assert current_changelog_components() == [Issues, Commits, ChangelogEntry]
    assert current_commit_parser()(CommitNote, b"test") == CommitNote(
        header="test", body="", footer="", scope="", commit=""
    )

# Generated at 2022-06-24 02:04:47.322986
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test1"] = "initial_value"

    @overload_configuration
    def test_function(define):
        assert config["test1"] == "new_value"

    test_function(["test1=new_value"])

# Generated at 2022-06-24 02:04:55.298879
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"

    @overload_configuration
    def echo(foo):
        return foo

    assert echo(foo="foo") == "foo"
    assert config["foo"] == "foo"

    config["bar"] = "baz"

    @overload_configuration
    def echo(bar, define=[]):
        return bar

    assert echo(bar="foobar") == "foobar"
    assert config["bar"] == "foobar"

    @overload_configuration
    def echo(bar, define=[]):
        return bar

    assert echo(bar="foobar", define=["foo=bar"]) == "foobar"
    assert config["foo"] == "bar"

# Generated at 2022-06-24 02:05:01.140513
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = (
        "semantic_release.changelog_components.features," "semantic_release.changelog_components.breaking_changes," "semantic_release.changelog_components.bugs"
    )
    components = current_changelog_components()
    assert len(components) == 3
    assert components[1].__name__ == "breaking_changes"

# Generated at 2022-06-24 02:05:02.164540
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) > 1

# Generated at 2022-06-24 02:05:07.808668
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        from semantic_release.changelog_components.markdown import (
            changelog_version_heading,
            changelog_summary,
        )
        config["changelog_components"] = "semantic_release.changelog_components.markdown.changelog_version_heading,"\
                                         "semantic_release.changelog_components.markdown.changelog_summary"
        components = current_changelog_components()
        assert len(components) == 2
        assert components[0] == changelog_version_heading
        assert components[1] == changelog_summary
    except ImportError:
        pass



# Generated at 2022-06-24 02:05:14.627057
# Unit test for function overload_configuration
def test_overload_configuration():
    # Setup
    @overload_configuration
    def overloaded_function(define):
        return config

    old_value = config["changelog_components"]
    new_value = "other_value"
    define = "changelog_components={}".format(new_value)

    # Excercise
    result = overloaded_function(define=define)

    # Verify
    assert result["changelog_components"] != old_value
    assert result["changelog_components"] == new_value

    # Cleanup
    config["changelog_components"] = old_value

# Generated at 2022-06-24 02:05:24.530887
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"
    assert current_commit_parser() is not None
    config["commit_parser"] = "semantic_release.utils.parse_commit"
    assert current_commit_parser() is not None
    config["commit_parser"] = "semantic_release.utils.no_parse_commit"
    try:
        current_commit_parser()
    except ImproperConfigurationError as ex:
        assert str(ex) == 'Unable to import parser "No module named \'semantic_release.utils\'"'
    config["commit_parser"] = "semantic_release.commit_parser.no_parse_commit"

# Generated at 2022-06-24 02:05:29.281795
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(arg):
        return arg

    # Assign value to a parameter
    assert not config
    config["foo"] = "bar"
    foo("foo", define=("foo=baz"))
    assert config["foo"] == "baz"

    # Assign value to a new parameter
    foo("foo", define=("new=baz"))
    assert config["new"] == "baz"

# Generated at 2022-06-24 02:05:37.034178
# Unit test for function overload_configuration
def test_overload_configuration():
    def fake_func(define):
        # Assuming the key "name" was not defined
        assert config["name"] == "fake_func"
        # Assuming the key "count" was not defined
        assert config["count"] == "12"

    overload_configuration(fake_func)(define=["name=fake_func", "count=12"])
    assert config["name"] == "fake_func"
    assert config["count"] == "12"

# Generated at 2022-06-24 02:05:41.248405
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from mock import patch

    with patch.object(config, "get", return_value="semantic_release.changelog.default_components.title_upgrade,semantic_release.changelog.default_components.package_upgrade"):
        assert len(current_changelog_components()) == 2