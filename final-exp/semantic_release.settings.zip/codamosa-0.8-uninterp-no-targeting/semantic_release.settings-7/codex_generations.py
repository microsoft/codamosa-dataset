

# Generated at 2022-06-21 21:00:12.526829
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    components_names = [c.__name__ for c in components]
    assert "render_components" in components_names
    assert "render_issue" in components_names
    assert "render_pull_request" in components_names
    assert "render_breaking_change" in components_names
    assert "render_commit" in components_names

# Generated at 2022-06-21 21:00:14.314781
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.hvcs

    assert current_commit_parser() == semantic_release.hvcs.parse_commit

# Generated at 2022-06-21 21:00:19.994217
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def f():
        return config.get("overloaded")

    assert f() == "1"

    assert config.get("overloaded") is None

    assert f(define=["overloaded=1"]) == "1"
    assert f(define=["overloaded=2"]) == "2"
    assert f(define=["overloaded=3"]) == "3"
    assert f(define=["overloaded"]) == None

# Generated at 2022-06-21 21:00:21.092344
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser is not None

# Generated at 2022-06-21 21:00:26.783580
# Unit test for function overload_configuration
def test_overload_configuration():
    original_major_on_zero = config["major_on_zero"]

    @overload_configuration
    def test(*args, **kwargs):
        assert config["major_on_zero"] != original_major_on_zero
        return "success"

    assert test(*["one", "two"], define=["major_on_zero=False"]) == "success"
    assert test("one", "two") == "success"
    assert config["major_on_zero"] == original_major_on_zero

# Generated at 2022-06-21 21:00:29.931677
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return

    test_function(define=["foo=bar"])

    assert config["foo"] == "bar"

# Generated at 2022-06-21 21:00:34.940766
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        repo.changelog_components.changelog_sections,
        repo.changelog_components.changelog_notes,
        repo.changelog_components.changelog_compare_link,
    ]

# Generated at 2022-06-21 21:00:44.154662
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = UserDict()
    test_config['changelog_scope'] = 'scope'
    test_config['check_build_status'] = True
    test_config['commit_version_number'] = True
    test_config['major_on_zero'] = True

    @overload_configuration
    def test_func(define=None):
        return config

    assert (
        test_func() == test_config
    ), "Return the 'config' variable if there is no arguments"

    test_config['changelog_scope'] = 'test1'
    assert (
        test_func(define=['changelog_scope=test1'])
        == test_config
    ), "Update the 'config' variable if there is a " "'changelog_scope=test1' argument"


# Generated at 2022-06-21 21:00:46.793927
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the callable current_commit_parser
    """
    try:
        current_commit_parser()
        assert True
    except ImproperConfigurationError:
        assert False



# Generated at 2022-06-21 21:00:50.939027
# Unit test for function current_commit_parser
def test_current_commit_parser():
    path_to_plugin = "readme"
    config["commit_parser"] = path_to_plugin
    from .plugins.readme import parse as expected_result
    assert current_commit_parser() is expected_result



# Generated at 2022-06-21 21:01:00.501197
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config = UserDict({"commit_parser": "semantic_release.commit_parser"})
    assert current_commit_parser()



# Generated at 2022-06-21 21:01:02.689228
# Unit test for function current_changelog_components
def test_current_changelog_components():
    changelog_components = current_changelog_components()
    assert callable(changelog_components[0])

# Generated at 2022-06-21 21:01:07.933176
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test for function current_commit_parser
    """
    importlib.reload(config)
    config.set("commit_parser", "semantic_release.vcs.git.parse_git_commits")
    assert current_commit_parser().__name__ == "parse_git_commits"



# Generated at 2022-06-21 21:01:16.384421
# Unit test for function overload_configuration
def test_overload_configuration():
    os.environ["SEMANTIC_RELEASE_SOME_KEY"] = "SEMANTIC_RELEASE_SOME_VALUE"

    config["some_key"] = "some_value"
    assert config["some_key"] == "some_value"

    @overload_configuration
    def func_to_be_decorated(define, another_arg):
        assert another_arg is not None

    func_to_be_decorated(define=["some_key=some_value2"], another_arg="value")
    assert config["some_key"] == "some_value2"

    with pytest.raises(ImproperConfigurationError):
        func_to_be_decorated(define=["some_key="], another_arg="value")


# Generated at 2022-06-21 21:01:25.751038
# Unit test for function overload_configuration
def test_overload_configuration():
    """We check that a basic call to the decorator actually works and that a
    complex call to the decorator actually works.

    :raises ValueError: if the basic call fails or if the complex call fails
    """
    from semantic_release import log
    from . import errors

    @overload_configuration
    def test_func(a, b, c):
        return a, b, c

    @overload_configuration
    def test_func_define(a, b, define=["my_param_1=my_plugin"]):
        return a, b, config["my_param_1"]

    # Basic call to overload_configuration
    if test_func(1, 2, 3) != (1, 2, 3):
        raise ValueError("Basic call to overload_configuration failed.")

    # Complex call to overload_configuration

# Generated at 2022-06-21 21:01:30.154838
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = "semantic_release.tests.test_helpers.changelog_component"
    assert current_changelog_components() == [changelog_component]


# Generated at 2022-06-21 21:01:31.306430
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser != None


# Generated at 2022-06-21 21:01:33.522362
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import format_changelog_text

    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == format_changelog_text



# Generated at 2022-06-21 21:01:36.367383
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def add_number(number1, number2):
        return number1 + number2

    add_number(5, 10, define=["number1=6"])
    assert config["number1"] == "6"

# Generated at 2022-06-21 21:01:44.109538
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(parameter, define):
        return (parameter, config["parameter"])

    test_func = overload_configuration(test_func)

    config["parameter"] = "old_value"
    parameter, config_parameter = test_func("value", define=[])
    assert config_parameter == "old_value"
    assert parameter == "value"

    parameter, config_parameter = test_func("new_value", define=["parameter=test"])
    assert config_parameter == "test"
    assert parameter == "new_value"



# Generated at 2022-06-21 21:02:02.217719
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # We should be able to parse a full commit message
    commit_parser = current_commit_parser()
    commit_message = commit_parser("fix: foo bar")
    assert commit_message["message"].endswith("foo bar")

    # We should be able to handle a message with more than one commit
    # message
    commit_message = commit_parser(
        "feat: add first commit\n\nfix: add second commit\n\nrefactor: add third commit"
    )
    assert commit_message["message"].endswith("add third commit")

    # We should be able to handle multi-line commit messages

# Generated at 2022-06-21 21:02:06.038988
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Tests that the function overload_configuration actually overloads the
    configuration variable expected.
    """
    config["overload_configuration"] = "before"

    @overload_configuration
    def change_config(define: List[str]):
        pass

    change_config(define=["overload_configuration=after"])

    assert config["overload_configuration"] == "after"

# Generated at 2022-06-21 21:02:11.885151
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import BreakingChange
    from .changelog import EnhancementsChange
    from .changelog import BugFixesChange
    changelog_components = current_changelog_components()
    assert changelog_components == [
        BreakingChange,
        EnhancementsChange,
        BugFixesChange,
    ]


# Generated at 2022-06-21 21:02:21.709555
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}
    traceback = []

    @overload_configuration
    def overload(a, b, c):
        config["a"] = a
        return config

    config = overload(1, 2, 3, define=["a=4", "b=5"])
    assert config == {"a": "4"}
    config = overload(1, 2, 3, define=["a=4"])
    assert config == {"a": "4"}
    config = overload(1, 2, 3, define=["b=4"])
    assert config == {}
    config = overload(1, 2, 3, define=["b=4", "c.d.e=5"])
    assert config == {}

# Generated at 2022-06-21 21:02:27.632413
# Unit test for function overload_configuration
def test_overload_configuration():
    # The configuration will be overloaded
    @overload_configuration
    def test_func(define):
        return config

    assert test_func(define=["token=new-token"])["token"] == "new-token"

    # The configuration will not be overloaded
    @overload_configuration
    def test_func():
        return config

    assert test_func()["token"] == "your-token"

# Generated at 2022-06-21 21:02:29.314107
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser:detect_message_tag"

# Generated at 2022-06-21 21:02:32.703860
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = (
        "semantic_release.changelog.components.break_change,"
        "semantic_release.changelog.components.features"
    )

    current_changelog_components()



# Generated at 2022-06-21 21:02:38.117611
# Unit test for function overload_configuration
def test_overload_configuration():
    config["define_test"] = "toto"

    @overload_configuration
    def foo(define: str=None):
        return define

    assert foo(define=["define_test=titi"]) == "titi"
    assert config["define_test"] == "titi"
    assert foo() == "titi"


test_overload_configuration()

# Generated at 2022-06-21 21:02:40.946596
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def my_parser():
        pass

    config = UserDict()

    assert current_commit_parser() is None


# Generated at 2022-06-21 21:02:44.321779
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(define):
        return define

    decorated = overload_configuration(test_func)
    assert decorated('define="major_on_zero=True"') == 'define="major_on_zero=True"'

# Generated at 2022-06-21 21:02:52.970741
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-21 21:03:02.845680
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import (  # noqa
        removed,
        changed,
        bugfix,
        security,
        feat,
        BREAKING_CHANGE,
        DEPRECATED,
        enhancements,
        breaking_changes,
        version_header,
    )

    components = current_changelog_components()

    assert removed in components
    assert changed in components
    assert bugfix in components
    assert security in components
    assert feat in components
    assert BREAKING_CHANGE in components
    assert DEPRECATED in components
    assert enhancements in components
    assert breaking_changes in components
    assert version_header in components

# Generated at 2022-06-21 21:03:04.024866
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:03:13.170141
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(a, b, define=None):
        return a + b
    assert f(2, 3) == 5
    assert config["define"] == []
    assert f(2, 3, define=["define=a"]) == 5
    assert config["define"] == ["a"]
    assert f(2, 3, define=["define=a,define=b"]) == 5
    assert config["define"] == ["a", "b"]
    assert f(2, 3, define=["define=a,define=b", "define=c"]) == 5
    assert config["define"] == ["a", "b", "c"]
    assert f(2, 3, define=["define=a,define=b,define=c"]) == 5

# Generated at 2022-06-21 21:03:24.871618
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.settings as s
    # Test that the "config" variable is empty before overriding it
    assert s.config == {}
    # Test that the "config" variable is not empty after overriding it
    @s.overload_configuration
    def define_overload_configuration():
        pass
    assert s.config == {}
    # Test that one variable can be defined
    define_overload_configuration(
        define=["PREFERRED_VERSION_SCHEME=calver", "changelog_scope=version"]
    )
    assert s.config == {
        "PREFERRED_VERSION_SCHEME": "calver",
        "changelog_scope": "version",
    }
    # Test that the variable override is maintained across function calls

# Generated at 2022-06-21 21:03:27.337522
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        components = current_changelog_components()
        assert(components == [])
    except ImproperConfigurationError:
        assert(True)


# Generated at 2022-06-21 21:03:30.410172
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("extends") == ""

    @overload_configuration
    def dummy(define):
        pass

    dummy(define=["extends=test"])
    assert config.get("extends") == "test"

# Generated at 2022-06-21 21:03:33.233208
# Unit test for function overload_configuration
def test_overload_configuration():
    result = dict()

    @overload_configuration
    def func(result):
        result.update(config)

    func(result=result, define=["a=b", "c=d"])
    assert dict(result) == dict(a="b", c="d")

# Generated at 2022-06-21 21:03:40.360826
# Unit test for function overload_configuration
def test_overload_configuration():
    from .commands.release import release

    @overload_configuration
    def identity(define, **kwargs):
        return kwargs

    # When the 'define' key is not in the kwargs, nothing changes
    assert identity(dry_run=True) == {"dry_run": True}

    # When the 'define' key is in the kwargs and has no value, nothing changes
    assert identity(dry_run=True, define=None) == {"dry_run": True, "define": None}

    # When the 'define' key is in the kwargs and has a value,
    # the config is updated
    assert identity(dry_run=True, define=["version_variable_name=ver"]) == {
        "dry_run": True,
        "version_variable_name": "ver",
    }



# Generated at 2022-06-21 21:03:46.239397
# Unit test for function overload_configuration
def test_overload_configuration():
    from . import __version__

    @overload_configuration
    def test(param: str):
        return config[param]

    assert test("version") == __version__
    assert test("version", define=["version=0.0.0"]) == "0.0.0"

# Generated at 2022-06-21 21:04:02.476030
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=[]):
        if define:
            assert config["name"] == "new_name"
            assert config["hello"] == "world"
        else:
            assert config["name"] == "project_name"
            assert not "hello" in config

    config["name"] = "project_name"

    test_func()
    test_func(define=["name=new_name", "hello=world"])
    # remove defines
    del config["hello"]

# Generated at 2022-06-21 21:04:07.133186
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the overload_configuration decorator"""
    @overload_configuration
    def my_function(param1, define=[]):
        return param1

    assert my_function("test") == "test"
    assert my_function("test", define=["test=test"]) == "test"
    assert config["test"] == "test"

# Generated at 2022-06-21 21:04:12.012441
# Unit test for function overload_configuration
def test_overload_configuration():
    # Setup
    @overload_configuration
    def test(define=[]):
        pass

    # Execute
    test(define=["test1=1", "test2=2"])

    # Assert
    assert config["test1"] == "1"
    assert config["test2"] == "2"

# Generated at 2022-06-21 21:04:15.437643
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 3
    assert components[1].__name__ == "issue_reference_component"


# Unit tests for function current_commit_parser

# Generated at 2022-06-21 21:04:19.855380
# Unit test for function overload_configuration
def test_overload_configuration():
    def my_function(test=None):
        return config.get(test)

    my_function_overload = overload_configuration(my_function)
    assert my_function_overload(test='user_name', define=['user_name=test']) == 'test'

# Generated at 2022-06-21 21:04:22.425446
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .example.plugin import changelog_components

    components = current_changelog_components()
    assert changelog_components in components



# Generated at 2022-06-21 21:04:27.742722
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert config.get("changelog_components") == "semantic_release.changelog_components.feat,semantic_release.changelog_components.fix"
    assert len(current_changelog_components()) == 2
    assert current_changelog_components()[0] == semantic_release.changelog_components.feat
    assert current_changelog_components()[1] == semantic_release.changelog_components.fix


# Generated at 2022-06-21 21:04:29.459509
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(foo):
        assert foo == "bar"
    test(foo="foo", define=["foo=bar"])



# Generated at 2022-06-21 21:04:32.219543
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.hvcs import git
    from semantic_release.changelog import simple
    assert current_changelog_components() == [git, simple]

# Generated at 2022-06-21 21:04:36.594795
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog_components as c

    components = current_changelog_components()
    assert components == [c.append_changelog]

# Generated at 2022-06-21 21:04:52.359045
# Unit test for function overload_configuration
def test_overload_configuration():
    test_subj = {
        "plugin_name": "myplugin",
        "define": ["foo=bar", "hello=world"]
    }

    def test_func(plugin_name, **kwargs):
        assert plugin_name == "myplugin"
        # change 'config' to a local var so the test can't mess with the global 'config'
        config = dict()
        return config

    result = overload_configuration(test_func)(**test_subj)
    assert result["foo"] == "bar"
    assert result["hello"] == "world"

# Generated at 2022-06-21 21:04:57.524618
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def parser(message: str) -> str:
        return "Example"

    config["commit_parser"] = "tests.example.parser"
    assert current_commit_parser() == parser



# Generated at 2022-06-21 21:05:01.713959
# Unit test for function overload_configuration
def test_overload_configuration():
    with overload_configuration:
        print(config["commit_parser"])
        overload_configuration(define=["commit_parser=slpp.py"])
        print(config["commit_parser"])

# Generated at 2022-06-21 21:05:06.013103
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .parse_commits import parse_commits
    from .changelog import generate_changelog
    config["changelog_components"] = "semantic_release.changelog.generate_changelog"
    assert current_changelog_components() == [generate_changelog]

# Generated at 2022-06-21 21:05:07.850881
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser:parse'
    assert current_commit_parser() == parse

# Generated at 2022-06-21 21:05:12.715022
# Unit test for function overload_configuration
def test_overload_configuration():
    func = lambda: None
    wrapped_func = overload_configuration(func)
    assert wrapped_func.__name__ == "func"
    assert wrapped_func.__doc__ == "Unit test for function overload_configuration"
    assert (
        wrapped_func.__wrapped__.__name__ == "func"
    )  # See: https://www.python.org/dev/peps/pep-0343/
    assert (
        wrapped_func.__wrapped__.__doc__ == "Unit test for function overload_configuration"
    )

# Generated at 2022-06-21 21:05:24.512684
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.format_pull_requests"
    assert (
        current_changelog_components() == [
            "semantic_release.changelog.format_pull_requests"
        ]
    )
    config["changelog_components"] = "semantic_release.changelog.format_pull_requests,semantic_release.changelog.format_issue_urls"
    assert (
        current_changelog_components()
        == [
            "semantic_release.changelog.format_pull_requests",
            "semantic_release.changelog.format_issue_urls",
        ]
    )

# Generated at 2022-06-21 21:05:29.669491
# Unit test for function overload_configuration
def test_overload_configuration():
    """The "set" command line argument allows to overload the defines."""
    config = _config()
    define_array = ["foo=b", "bar=value"]
    overload_configuration(lambda x: None)(define=define_array)
    assert config["foo"] == "b"
    assert config["bar"] == "value"

# Generated at 2022-06-21 21:05:36.947818
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components
    """

    try:
        config["changelog_components"] = "semantic_release.changelog_components.link_references,semantic_release.changelog_components.remove_empty_sections"
        current_changelog_components()
    except ImproperConfigurationError as error:
        assert False, error

# Generated at 2022-06-21 21:05:42.063012
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parsers import get_commit_parser

    # Checking if the current parser is the same
    assert get_commit_parser() == current_commit_parser()
    # Checking if current parser can be used properly
    assert current_commit_parser()('chore: blabla') == ('chore', 'blabla')



# Generated at 2022-06-21 21:05:57.881428
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def config_func(conf, define=None):
        return conf

    conf = config_func("test_value", define=["conf=overloaded", "conf2=overloaded_2"])
    # check that the config was correctly overloaded
    assert conf == "overloaded"
    # check that 2 defined variables were correctly added to the config
    assert config["conf2"] == "overloaded_2"
    # check that the config was correctly restored
    assert config["conf"] == "default_value"

# Generated at 2022-06-21 21:06:03.732920
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release import parser

    assert current_commit_parser() == parser.parse_commits
    # Change parser configuration
    try:
        config["commit_parser"] = "semantic_release.commit_parser.parse_commits"
    except ImproperConfigurationError:
        pass
    else:
        assert current_commit_parser() == parser.parse_commits



# Generated at 2022-06-21 21:06:10.769113
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def foo(a, b=10, define=[]):
        return a + b

    assert foo(10) == 20
    assert foo(10, define=["b=20"]) == 30
    assert foo(10, define=["b=20", "c=30"]) == 30

    assert config["b"] == "20"
    assert config["c"] == "30"



# Generated at 2022-06-21 21:06:13.309120
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Since the package "semantic_release" is always installed,
    # setting a normal module should be found
    config["commit_parser"] = "semantic_release.commit_parser"
    current_commit_parser()

# Generated at 2022-06-21 21:06:24.286400
# Unit test for function overload_configuration
def test_overload_configuration():
    import json

    @overload_configuration
    def function(**kwargs):
        return kwargs

    assert function(define=["a=1"]) == {"define": ["a=1"], "a": "1"}
    assert function(define=["a=1", "b=1"], c="1") == {
        "define": ["a=1", "b=1"],
        "a": "1",
        "b": "1",
        "c": "1",
    }
    assert (
        json.dumps(function(define=["a=2", "a=1"], b="1"))
        == json.dumps({"define": ["a=2", "a=1"], "a": "1", "b": "1"})
    )

# Generated at 2022-06-21 21:06:27.379932
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test():
        return config["foo"]

    config["foo"] = "bar"
    assert test() == "bar"

    new_value = "new configuration"
    assert test(define=["foo=" + new_value]) == new_value

    assert test() == new_value

# Generated at 2022-06-21 21:06:29.207226
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()


# Generated at 2022-06-21 21:06:31.273090
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:06:38.244341
# Unit test for function overload_configuration
def test_overload_configuration():
    class DummyPlugin:
        @overload_configuration
        def call(self, define=None):
            pass

    dummy = DummyPlugin()
    global config
    config = {}
    dummy.call()
    assert config == {}
    dummy.call(define=["key=value"])
    assert config == {"key": "value"}
    config = {}
    dummy.call(define=["key=value", "spam=egg"])
    assert config == {"key": "value", "spam": "egg"}



# Generated at 2022-06-21 21:06:40.514743
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__module__ == "semantic_release.commit_parser"
    assert current_commit_parser().__name__ == "parse"

# Generated at 2022-06-21 21:06:52.585754
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Replace config for the time of the test
    _config.__code__ = _config_from_ini.__code__

    assert current_commit_parser() is not None

    # Restore config
    _config.__code__ = _config.__globals__["_config"].__code__

# Generated at 2022-06-21 21:06:59.477484
# Unit test for function overload_configuration
def test_overload_configuration():
    # Define a function for testing
    @overload_configuration
    def function(param1, param2, param3):
        return "Import error"
    # Call the function with short syntax
    function("value1", "value2", "value3")
    assert "Import error"
    # Call the function with long syntax
    function("value1", "value2", "value3", define=["param1=value1"])
    assert "value1" == config["param1"]

# Generated at 2022-06-21 21:07:02.834957
# Unit test for function current_changelog_components
def test_current_changelog_components():

    current_commit_parser = current_commit_parser()
    assert current_commit_parser is not None

    current_changelog_components = current_changelog_components()
    assert current_changelog_components is not None

# Generated at 2022-06-21 21:07:05.670493
# Unit test for function current_commit_parser
def test_current_commit_parser():
    test_path = "semantic_release_test.test_current_commit_parser.test_function"
    config["commit_parser"] = test_path
    parser = current_commit_parser()
    assert parser == test_function


# Function used for the previous test

# Generated at 2022-06-21 21:07:06.599977
# Unit test for function current_changelog_components
def test_current_changelog_components():
    pass


# Generated at 2022-06-21 21:07:19.695523
# Unit test for function overload_configuration
def test_overload_configuration():
    import tempfile
    from .git import get_repo_info
    from semantic_release import _cli

    tmp_dir = tempfile.TemporaryDirectory()

    _cli.main(["--no-verify", "--no-confirm", "patch", "--dry-run", f"--repo={tmp_dir.name}"])
    assert get_repo_info("0.1.1", "master") is not None
    _cli.main(["--no-verify", "--no-confirm", "patch", "--dry-run", f"--repo={tmp_dir.name}", "--define", "commit_parser=semantic_release.vcs_helpers.get_commit_info"])
    assert get_repo_info("0.1.2", "master") is None
    _cli

# Generated at 2022-06-21 21:07:22.253163
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components.type_of_changes import type_of_changes
    assert current_changelog_components() == [type_of_changes]

# Generated at 2022-06-21 21:07:25.747602
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Overload the configuration to test that the decorator works
    @overload_configuration
    def overload(x = "foo", define=["bar=baz"]):
        """Overload the configuration"""
        return x

    overload()
    assert config['bar'] == 'baz'

# Generated at 2022-06-21 21:07:26.884783
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

# Generated at 2022-06-21 21:07:28.661468
# Unit test for function overload_configuration
def test_overload_configuration():
    """tests if the values of the config are correctly replace
     by the ones given by the user"""



# Generated at 2022-06-21 21:07:39.008860
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser.__name__ == "parser"

# Generated at 2022-06-21 21:07:44.012826
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog
    from semantic_release.changelog import changelog as changelog_module

    components = current_changelog_components()
    assert components == [
        changelog.changelog_header,
        changelog.changelog_unreleased,
        changelog.changelog_release,
        changelog_module.changelog_footer,
    ]

# Generated at 2022-06-21 21:07:46.025961
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())


# Generated at 2022-06-21 21:07:49.137070
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test"""
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == "get_commits_between_tags"



# Generated at 2022-06-21 21:08:00.433104
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test overload_configuration decorator
    """

    @overload_configuration
    def foo(define: list = None) -> dict:
        """Func to test the decorator overload_configuration
        """
        return config

    assert foo()["commit_parser"] == "semantic_release.hacks.noop_commit_parser"
    assert foo(define=["commit_parser=semantic_release.hacks.noop_commit_parser"])[
        "commit_parser"
    ] == "semantic_release.hacks.noop_commit_parser"
    assert foo(define=["commit_parser=semantic_release.hacks.noop_commit_parser,other_key=foo"])[
        "commit_parser"
    ] == "semantic_release.hacks.noop_commit_parser"


# Generated at 2022-06-21 21:08:07.322493
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import default_changelog_components

    # Loading of correct changelog component function
    config.data["changelog_components"] = "semantic_release.changelog.default_changelog_components"
    assert current_changelog_components() == default_changelog_components()
    # Loading of incorrect changelog component function
    config.data["changelog_components"] = "semantic_release.changelog.invalid_component"
    with pytest.raises(ImproperConfigurationError) as excinfo:
        current_changelog_components()
    assert str(excinfo.value) == 'Unable to import changelog component "semantic_release.changelog.invalid_component"'

# Generated at 2022-06-21 21:08:16.858020
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser("fix(scope): blah blah blah") == ("fix", "scope", "blah blah blah")
    assert parser("feat(scope): blah blah blah") == ("feat", "scope", "blah blah blah")
    assert parser("perf(scope): blah blah blah") == ("perf", "scope", "blah blah blah")
    assert parser("BREAKING CHANGE: blah blah blah") == (
        "BREAKING CHANGE",
        None,
        "blah blah blah",
    )
    assert parser("blah blah blah") == (None, None, "blah blah blah")

# Generated at 2022-06-21 21:08:21.196451
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test to make sure the decorator overload_configuration performs as expected.
    """

    @overload_configuration
    def test_func(define):
        return config["test"]

    config["test"] = "test_value"
    assert test_func(define="test=replacing_value") == "replacing_value"

# Generated at 2022-06-21 21:08:24.386272
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_parser
    assert current_commit_parser() == default_parser
    config['commit_parser'] = 'semantic_release.commit_parser:parser'


# Generated at 2022-06-21 21:08:26.168375
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.hvcs.commit_parser import parse

    assert parse == current_commit_parser()

# Generated at 2022-06-21 21:08:42.379865
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.feature,semantic_release.changelog.components.fix'
    assert current_changelog_components() == [
        semantic_release.changelog.components.feature,
        semantic_release.changelog.components.fix,
    ]



# Generated at 2022-06-21 21:08:50.824324
# Unit test for function overload_configuration
def test_overload_configuration():
    # Create a dummy function
    def dummy(arg):
        return arg

    # Decorator
    config_overload = overload_configuration(dummy)

    # Check config is empty
    assert not config.get("dummy_key")
    assert config_overload("test") == "test"

    # Check the config overload
    assert config.get("dummy_key") == "dummy_value"
    assert config_overload("test", define=["dummy_key=dummy_value"]) == "test"

# Generated at 2022-06-21 21:08:58.163834
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy_function(*args, **kwargs):
        pass
    # Check we can overload parameters
    dummy_function(define=["GITHUB_TOKEN=1234567890"])
    assert config["GITHUB_TOKEN"] == "1234567890"
    # Check bad parameters are skipped
    dummy_function(define=["GITHUB_TOKEN=1234567890", "PEP440_VIRTUAL_SUFFIX=1.0+abc", "invalid=value"])
    assert config["GITHUB_TOKEN"] == "1234567890"
    assert config["PEP440_VIRTUAL_SUFFIX"] == "1.0+abc"
    assert "invalid" not in config

# Generated at 2022-06-21 21:09:03.109238
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog_components  # noqa: F401

    assert config.get("changelog_components")
    assert current_changelog_components()
    assert len(current_changelog_components()) > 0

# Generated at 2022-06-21 21:09:07.776979
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser
    assert current_commit_parser() == semantic_release.commit_parser.default
    config["commit_parser"] = "semantic_release.commit_parser.default"
    assert current_commit_parser() == semantic_release.commit_parser.default
    assert (
        config["commit_parser"]
        == "semantic_release.commit_parser.default"
    )

# Generated at 2022-06-21 21:09:09.731181
# Unit test for function overload_configuration
def test_overload_configuration():
    def foo(x):
        return config

    result = overload_configuration(foo)(define=["a=b"])
    assert result["a"] == "b"

# Generated at 2022-06-21 21:09:10.815009
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()



# Generated at 2022-06-21 21:09:11.607126
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:09:20.182188
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "old_value"

    @overload_configuration
    def function(arg1, arg2, define=None):
        print(arg1)
        print(arg2)
        print(config["foo"])
        print(config["bar"])

    function("arg1", "arg2", define=["foo=new_value", "bar=baz"])
    assert "foo" in config
    assert config["foo"] == "new_value"
    assert "bar" in config
    assert config["bar"] == "baz"

# Generated at 2022-06-21 21:09:28.123264
# Unit test for function overload_configuration
def test_overload_configuration():
    config["a"] = "b"
    config["c"] = "d"

    @overload_configuration
    def test_func(**kwargs):
        return [kwargs[key] for key in ["a", "b", "c"]]

    assert test_func() == ["b", None, "d"]
    assert test_func(define=["c=d"]) == ["b", None, "d"]
    assert test_func(define=["a=e"]) == ["e", None, "d"]
    assert test_func(define=["a=e,b=f"]) == ["e", "f", "d"]

# Generated at 2022-06-21 21:09:44.001421
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """This function tests that function current_changelog_components
    import the correct changelog components.
    """

    # Overload the configuration of changelog_components to test the function
    config["changelog_components"] = "semantic_release.changelog.components.issue:issue_titles,semantic_release.changelog.components.scope:scope_extractor"

    # Unit test the function by comparing the list of imported components
    # with the list of components written in the config file
    assert current_changelog_components() == [
        semantic_release.changelog.components.issue.issue_titles,
        semantic_release.changelog.components.scope.scope_extractor,
    ]



# Generated at 2022-06-21 21:09:47.565282
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """It returns the current parser.
    """
    assert current_commit_parser() is not None, "Parser can't be None."

# Generated at 2022-06-21 21:09:49.692428
# Unit test for function current_changelog_components
def test_current_changelog_components():
    changelog_components = current_changelog_components()
    assert len(changelog_components) == 4

# Generated at 2022-06-21 21:09:52.273169
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import first_alpha_version, update_changelog_geonetwork
    assert current_changelog_components() == [first_alpha_version, update_changelog_geonetwork]

# Generated at 2022-06-21 21:09:53.931101
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None



# Generated at 2022-06-21 21:10:03.702588
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        pass
    # Standard call, no error
    test(define=[])
    # Value is defined, no error
    test(define=["hello=world"])
    # Error, the param is not in key=value format
    try:
        test(define=["hello"])
    except ValueError as error:
        assert "not enough values to unpack" in str(error)
    # Value is defined, no error
    test(define=["hello=world", "foo=bar"])
    assert config["hello"] == "world"
    assert config["foo"] == "bar"