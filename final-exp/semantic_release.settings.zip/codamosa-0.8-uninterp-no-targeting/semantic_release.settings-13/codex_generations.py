

# Generated at 2022-06-21 21:00:16.972643
# Unit test for function overload_configuration
def test_overload_configuration():
    assert callable(overload_configuration)
    from .cli import pre_release
    from .triggers import release_triggered
    from .settings import release_triggers
    @overload_configuration
    def test_func():
        assert True
    test_func()
    with_release_triggered = pre_release(release_triggered)
    with_release_triggered({"define": ["release_triggers=[]"]})
    assert release_triggers == []
    with_release_triggered({"define": ["release_triggers=['foo', 'bar']"]})
    assert release_triggers == ["foo", "bar"]

# Generated at 2022-06-21 21:00:21.688851
# Unit test for function overload_configuration
def test_overload_configuration():
    config['commit_parser'] = 'a'
    config['changelog_components'] = 'a,b,c'
    config['define'] = 'commit_parser=b'
    assert overload_configuration(lambda: config['changelog_components'])() == 'a,b,c'
    assert overload_configuration(lambda: config['commit_parser'])() == 'b'

# Generated at 2022-06-21 21:00:30.721549
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test for the overload_configuration function"""

    def original_function(define=None):
        assert "custom_key" in config and config["custom_key"] == "custom_value"
        assert config["custom_key_2"] == "custom_value_2"

    decorated_original_function = overload_configuration(original_function)

    # Check that the configuration is not altered
    assert "custom_key" not in config
    assert "custom_key_2" not in config

    # Call the wrapped function
    decorated_original_function(define=["custom_key=custom_value", "custom_key_2=custom_value_2"])

    # Rerun the test but with "define=None"
    original_function()

# Generated at 2022-06-21 21:00:31.650592
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:00:34.933858
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def echo(config):
        return config

    new_config = echo(config, define=["key=value", "foo=bar"])
    assert new_config["key"] == "value"
    assert new_config["foo"] == "bar"

# Generated at 2022-06-21 21:00:39.160071
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_merge_commit

    assert current_commit_parser() == parse_merge_commit

# Generated at 2022-06-21 21:00:42.129977
# Unit test for function current_changelog_components
def test_current_changelog_components():
    commit_parser = current_changelog_components()
    assert len(commit_parser) == 2
    assert callable(commit_parser[0])
    assert callable(commit_parser[1])



# Generated at 2022-06-21 21:00:48.232016
# Unit test for function current_changelog_components
def test_current_changelog_components():

    @overload_configuration
    def test_function(define=None):
        return current_changelog_components()

    functions = test_function(
        define=[
            "changelog_components=semantic_release.changelog.components.summary",
            "changelog_components=semantic_release.changelog.components.body",
        ]
    )
    assert len(functions) == 2
    assert functions[0].__name__ == "summary"
    assert functions[1].__name__ == "body"

# Generated at 2022-06-21 21:00:50.508923
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert "parse_commit" == config.get("commit_parser")
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:00:55.217655
# Unit test for function overload_configuration
def test_overload_configuration():
    from .env import configure_logging
    configure_logging()

    @overload_configuration
    def overload_configuration_with_define_array(define):
        pass
    assert config.get("release_branch") == "master"
    overload_configuration_with_define_array(define=["release_branch=develop"])
    assert config.get("release_branch") == "develop"

# Generated at 2022-06-21 21:01:13.218191
# Unit test for function overload_configuration
def test_overload_configuration():
    assert overload_configuration(lambda x: x)(1) == 1

    def test(a, b, c, define=None):
        return (a, b, c)

    assert overload_configuration(test)(1, 2, 3) == (1, 2, 3)
    assert overload_configuration(test)(1, 2, 3, define=["x=y"]) == (1, 2, 3)
    assert overload_configuration(test)(1, 2, 3, define=["a=y"]) == (1, 2, 3)
    assert overload_configuration(test)(1, 2, 3, define=["x=y", "a=b"]) == (1, 2, 3)

# Generated at 2022-06-21 21:01:24.877379
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the class decorator for the arguments "define" in the command line.
    """
    # Fixture
    class Test:
        @overload_configuration
        def __init__(self, define=None):
            assert config["plugin_config"] == "test"

        @property
        def plugin_config(self):
            return config["plugin_config"]

    class Test2:
        @overload_configuration
        def __init__(self, define=None):
            assert config["plugin_config"] == "test2"

        @property
        def plugin_config(self):
            return config["plugin_config"]

    class Test3:
        @overload_configuration
        def __init__(self, define=None):
            assert config["plugin_config"] == "test2"


# Generated at 2022-06-21 21:01:37.709803
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from tests.components import test_component as test_component_module
    from semantic_release.changelog_components import (
        entry_filter,
        pr_title,
        issue_title,
        pr_link,
        issue_link,
        type_emoji,
    )
    import pkg_resources


# Generated at 2022-06-21 21:01:41.093549
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define):
        return define

    assert func(["hello_world=hello"]) == ["hello_world=hello"]
    assert config == {"hello_world": "hello"}

# Generated at 2022-06-21 21:01:43.986533
# Unit test for function current_changelog_components
def test_current_changelog_components():
    parser = current_changelog_components()
    assert type(parser) is list
    assert len(parser) == 1
    assert parser[0].__name__ == "parse_commit"



# Generated at 2022-06-21 21:01:47.352547
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_components

    config["changelog_components"] = (
        "semantic_release.changelog.HeaderComponent"
        ",semantic_release.changelog.CommitSpecifierComponent"
    )
    assert current_changelog_components() == get_components()

# Generated at 2022-06-21 21:01:51.619496
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def sample_function(argument1, argument2=None):
        pass
    sample_function(argument1='test', define=["argument2=test2"])
    assert config["argument1"] == "test"
    assert config["argument2"] == "test2"

# Generated at 2022-06-21 21:01:53.036859
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components == current_changelog_components()

# Generated at 2022-06-21 21:01:55.931935
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define=None):
        return config["test"]

    assert func(define=["test=test success"]) == "test success"

# Generated at 2022-06-21 21:01:58.176800
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parsers.parse_commit"
    current_commit_parser()

# Generated at 2022-06-21 21:02:08.309500
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    This function tests the function current_commit_parser for import error.
    """
    expected = 'Unable to import parser "No module named \'commit_parser\'"'
    actual = current_commit_parser()
    assert actual == expected

# Generated at 2022-06-21 21:02:11.779214
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import GitLog, ConventionalChangelog
    components = current_changelog_components()
    assert components[0] is GitLog
    assert components[1] is ConventionalChangelog

# Generated at 2022-06-21 21:02:22.540603
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import sys
    import os
    from contextlib import contextmanager

    from unittest import TestCase

    from semantic_release.errors import ImproperConfigurationError

    @contextmanager
    def setenv(key, value):
        origin = os.environ.get(key)
        os.environ[key] = value
        try:
            yield
        finally:
            if origin is not None:
                os.environ[key] = origin
            else:
                os.environ.pop(key)

    class TestCase(TestCase):
        def setUp(self):
            self.orig_environ = os.environ.copy()

        def tearDown(self):
            os.environ = self.orig_environ

        def test_success(self):
            from semantic_release.hvcs import git

# Generated at 2022-06-21 21:02:32.535219
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import (
        changelog_components,
        get_changelog_content,
        get_changelog_sections,
        get_changelog_title,
    )

    config["changelog_components"] = "semantic_release.changelog.get_changelog_title"
    assert current_changelog_components() == [get_changelog_title]

    config["changelog_components"] = (
        "semantic_release.changelog.get_changelog_title,"
        "semantic_release.changelog.get_changelog_sections"
    )
    assert current_changelog_components() == [get_changelog_title, get_changelog_sections]

    config["changelog_components"]

# Generated at 2022-06-21 21:02:35.472022
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 1
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-21 21:02:44.046584
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.CommitsComponent,tests.test_changelog.CustomChangeLogComponent"
    assert isinstance(current_changelog_components(), list)
    assert isinstance(current_changelog_components()[0], Callable)
    assert current_changelog_components()[0].__name__ == "CommitsComponent"
    assert current_changelog_components()[1].__name__ == "CustomChangeLogComponent"



# Generated at 2022-06-21 21:02:52.768005
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(a, b, c, define=[]):
        return a + b + c

    assert f(1, 2, 3) == 6
    assert f(1, 2, 3, define=["a=4"]) == 4
    assert f(1, 2, 3, define=["a=4", "b=5"]) == 9
    assert f(1, 2, 3, define=["a=4", "b=5", "c=6"]) == 15
    assert f(1, 2, 3, define=["a=4", "b=5", "c=6", "define=[]"]) == 15
    assert f(1, 2, 3, define=["a=4", "b=5", "c=6", "define=[d=7]"]) == 15

# Generated at 2022-06-21 21:02:54.927784
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        assert current_commit_parser() is not None
    except ImproperConfigurationError:
        pass



# Generated at 2022-06-21 21:02:57.409714
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert isinstance(current_commit_parser(), Callable)



# Generated at 2022-06-21 21:03:04.371264
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def set_config_value(key, value):
        config[key] = value

    # test when no key/value pairs are specified
    set_config_value(key="foo", value="bar")
    assert config["foo"] == "bar"

    # test with key/value pairs
    set_config_value(key="foo", value="bar1", define=["foo=bar2"])
    assert config["foo"] == "bar2"

# Generated at 2022-06-21 21:03:17.704913
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.hooks.changelog_components.components_pr,
        semantic_release.hooks.changelog_components.components_issues,
        semantic_release.hooks.changelog_components.components_commits,
    ]

# Generated at 2022-06-21 21:03:22.777423
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.various_changes,semantic_release.changelog.components.features,semantic_release.changelog.components.bug_fixes,semantic_release.changelog.components.breaking_changes'
    assert len(current_changelog_components()) == 4

# Generated at 2022-06-21 21:03:25.423547
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        config.get("changelog_components") == "semantic_release.changelog.git"
    )
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-21 21:03:27.520482
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) > 0
    assert callable(components[0])


# Generated at 2022-06-21 21:03:29.898922
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = config.get("changelog_components").split(",")
    used_component = current_changelog_components()
    assert components == used_component

# Generated at 2022-06-21 21:03:30.729748
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:03:34.032444
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser()
        == current_commit_parser.__module__.split(".")[-1] + "." + current_commit_parser.__name__
    )

# Generated at 2022-06-21 21:03:38.155280
# Unit test for function overload_configuration
def test_overload_configuration():
    config["key1"] = "value1"
    config["key2"] = "value2"

    @overload_configuration
    def test_function(define, key1, key2):
        assert key1 == "overload1"
        assert key2 == "overload2"

    test_function(define=["key1=overload1", "key2=overload2"])



# Generated at 2022-06-21 21:03:39.705950
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == 'semantic_release.commit_parser:CommitParser'


# Generated at 2022-06-21 21:03:42.654440
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define, local_config):
        local_config['name'] = 'value'
        return local_config

    assert {'name': 'value', 'key': 'value'} == test(define=['key=value'], local_config={})

# Generated at 2022-06-21 21:04:03.832391
# Unit test for function overload_configuration
def test_overload_configuration():
    # Mock config to test overload_configuration
    config.clear()
    config["tag_prefix"] = "v"

    def test_func():
        pass

    wrapped = overload_configuration(test_func)

    assert wrapped.__name__ == "test_func"
    wrapped(define=["tag_prefix=test_prefix"])
    assert config["tag_prefix"] == "test_prefix"

# Generated at 2022-06-21 21:04:10.067554
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        pass

    pairs = [
        "key1=value1",
        "key2=value2",
    ]
    test(define=pairs)
    assert config["key1"] == "value1"
    assert config["key2"] == "value2"
    assert "key3" not in config

    pairs = ["key1=new_value1", "key3=value3"]
    test(define=pairs)
    assert config["key1"] == "new_value1"
    assert "key2" not in config
    assert config["key3"] == "value3"

# Generated at 2022-06-21 21:04:15.736155
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog
    from semantic_release.components import Issue, Merge

    assert current_changelog_components() == [Issue, Merge]

    os.environ["GITHUB_TOKEN"] = "ffff"
    assert changelog.current_changelog_components() == [Merge, Issue]

# Generated at 2022-06-21 21:04:24.585997
# Unit test for function overload_configuration
def test_overload_configuration():
    from .release_manager import get_release_manager
    from .errors import ImproperConfigurationError

    def test_func_or_method(*args, **kwargs):
        assert config["test_configuration_overload"] == "test"

    overload_configuration(test_func_or_method)(define=["test_configuration_overload=test"])

    # Overload with both release manager as class and as a string
    overload_configuration(get_release_manager)(
        "test_package_name",
        "1.2.3",
        None,
        define=[
            "project_name=test_package_name",
            "release_manager=semantic_release.release_manager.ReleaseManager",
        ],
    )


# Generated at 2022-06-21 21:04:26.070016
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commits
    assert current_commit_parser() == parse_commits



# Generated at 2022-06-21 21:04:31.203412
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration"""
    assert len(config) == 0

    @overload_configuration
    def add(define):
        """Add a new key value pair in config."""
        pass

    add(define=["key=value"])
    assert len(config) == 1
    assert config["key"] == "value"

# Generated at 2022-06-21 21:04:37.111752
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Tests current_changelog_components() function"""
    import semantic_release.changelog

    components = current_changelog_components()
    assert callable(components[1])

    for component in components:
        assert component.__module__.startswith("semantic_release.changelog")

# Generated at 2022-06-21 21:04:38.902855
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import default_components
    assert current_changelog_components() == default_components

# Generated at 2022-06-21 21:04:43.823327
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(define=[]):
        return config["commit_parser"]

    overloaded_func = overload_configuration(test_func)

    assert overloaded_func() == config["commit_parser"]

    overloaded_func(define=["commit_parser=module.other_module.parse_func"])

    assert overloaded_func() == "module.other_module.parse_func"

# Generated at 2022-06-21 21:04:49.145302
# Unit test for function current_commit_parser
def test_current_commit_parser():
    default_commit_parser = "semantic_release.commit_parser:parse_commit"
    config["commit_parser"] = default_commit_parser

    current_commit_parser()
    config["commit_parser"] = "semantic_release.commit_parser"
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()

# Generated at 2022-06-21 21:05:08.502936
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test if the current_commit_parser returns the right function when it's imported
    """

    from semantic_release.commit_parser import default_parser

    assert default_parser == current_commit_parser()

# Generated at 2022-06-21 21:05:11.618845
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test current_commit_parser returns the same function as
    semantic_release.hacking.parse_commit
    """
    parser = current_commit_parser()
    assert parser("feat: Add foo") == current_commit_parser()("feat: Add foo")

# Generated at 2022-06-21 21:05:20.622878
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test that current_changelog_components returns a list of component functions"""
    config["changelog_components"] = "semantic_release.changelog.changelog.get_changes"
    component_list = current_changelog_components()
    assert type(component_list) is list
    assert component_list[0] is semantic_release.changelog.changelog.get_changes


# Generated at 2022-06-21 21:05:28.152144
# Unit test for function current_changelog_components
def test_current_changelog_components():
    with open("pyproject.toml", "w") as fileout:
        fileout.write(
            '''
            [tool.semantic_release]
            changelog_components=semantic_release_test.test_current_changelog_components.component1,semantic_release_test.test_current_changelog_components.component2
            '''
        )
    result = current_changelog_components()
    assert component1 in result
    assert component2 in result



# Generated at 2022-06-21 21:05:35.064888
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import re
    import semantic_release
    import semantic_release.hvcs
    import semantic_release.changelog

    changelog_components = current_changelog_components()
    assert len(changelog_components) == 3
    assert {
        x.__name__
        for x in changelog_components
    } == {
        "get_changelog_components",
        "get_last_releases",
        "generate_changelog",
    }

    # Check that the changelog components has been imported from the proper
    # module
    for component in changelog_components:
        assert component.__module__.startswith(
            "semantic_release.changelog"
        )

    # Check that the other components have been imported from the proper module


# Generated at 2022-06-21 21:05:38.309081
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test initialization of CommitParser class."""
    from .commit_parser import CommitParser

    try:
        assert current_commit_parser() == CommitParser
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-21 21:05:40.269078
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser.__name__ == 'parse_commits'


# Generated at 2022-06-21 21:05:43.106212
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test for the function current_commit_parser()
    """
    from .commit_parser import parse_message

    assert current_commit_parser() == parse_message



# Generated at 2022-06-21 21:05:45.270341
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert config.get("commit_parser") == "semantic_release.commit_parser"
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:05:47.827403
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import tests.common.changelog_components as changelog_components
    assert(current_changelog_components() == [changelog_components.tag_component])

# Generated at 2022-06-21 21:06:10.206119
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Make sure that current_changelog_components() returns a list of functions"""
    components = current_changelog_components()
    assert len(components) > 0
    for component in components:
        assert callable(component)

# Generated at 2022-06-21 21:06:12.116895
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['components'] = ''
    assert current_changelog_components() == []

# Generated at 2022-06-21 21:06:14.980043
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_commits
    assert current_commit_parser() == parse_commits
    # Set commit_parser to another value
    config["commit_parser"] = "semantic_release.commit_parser.parse_commits"
    assert current_commit_parser() == parse_commits

# Generated at 2022-06-21 21:06:21.501775
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator. The new values must be added
    to config.
    """
    @overload_configuration
    def test_function(**kwargs):
        pass

    test_function(define=["set_config=ok", "set_config_too=ok"])
    assert config["set_config"] == "ok"
    assert config["set_config_too"] == "ok"

# Generated at 2022-06-21 21:06:23.881086
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = 'semantic_release.changelog_components.Issue'
    assert len(current_changelog_components()) > 0

# Generated at 2022-06-21 21:06:26.175848
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        # No commit_parser specified
        pass
    except Exception:
        assert False, "An error happened"



# Generated at 2022-06-21 21:06:27.450134
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser.parse_commits"

# Generated at 2022-06-21 21:06:38.634739
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # If a component is not imported, it should rise an error
    config["changelog_components"] = "tests.modules.invalid_component"
    from .modules import invalid_component

    error = "Unable to import changelog component"
    try:
        current_changelog_components()
    except ImproperConfigurationError as err:
        assert error in str(err)

    # If a component is imported, but not in the right format, it should rise an
    # error
    config["changelog_components"] = "tests.modules.invalid_form_component"
    from .modules import invalid_form_component

    error = "changelog component"
    try:
        current_changelog_components()
    except ImproperConfigurationError as err:
        assert error in str(err)

    #

# Generated at 2022-06-21 21:06:43.090295
# Unit test for function overload_configuration
def test_overload_configuration():
    class Tested:
        @overload_configuration
        def test(self):
            return True

    assert Tested().test() == True

    class Tested:
        @overload_configuration
        def test(self, define=[]):
            return True

    assert Tested().test(define=[]) == True

    class Tested:
        @overload_configuration
        def test(self, define=[]):
            return False

    assert Tested().test(define=["hello=world"]) == False
    assert config.get("hello") == "world"

# Generated at 2022-06-21 21:06:50.236387
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Test if default commit_parser is returned when no configuration is present
    del config.data["commit_parser"]
    import semantic_release.commit_parser.parser

    assert current_commit_parser() == \
        semantic_release.commit_parser.parser.parser

    # Test if custom commit parser is returned when configuration is present
    config.data["commit_parser"] = "semantic_release.commit_parser.parser.parser"
    assert current_commit_parser() == \
        semantic_release.commit_parser.parser.parser

# Generated at 2022-06-21 21:07:12.307659
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Mocking the config for test
    config["changelog_components"] = "semantic_release.changelog.default_components"
    assert current_changelog_components() == [semantic_release.changelog.default_components]


# Generated at 2022-06-21 21:07:15.353433
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == ["semantic_release.changelog.components.body",
                                              "semantic_release.changelog.components.breaking_changes",
                                              "semantic_release.changelog.components.developers",
                                              "semantic_release.changelog.components.date",
                                              "semantic_release.changelog.components.tag"]

# Generated at 2022-06-21 21:07:22.115381
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(arg):
        return arg

    new_func = overload_configuration(func)
    assert new_func(10) == 10

    new_func = overload_configuration(func)
    assert new_func(10, define=["foo=bar"]) == 10
    assert config["foo"] == "bar"

    new_func = overload_configuration(func)
    assert new_func(10, define=["foo=baz"]) == 10
    assert config["foo"] == "baz"

# Generated at 2022-06-21 21:07:26.560514
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components as changelog_components
    assert current_changelog_components() == [
        changelog_components.add_header,
        changelog_components.include_changes_from_dependencies,
        changelog_components.add_footer,
    ]

# Generated at 2022-06-21 21:07:37.089145
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert callable(parser)
    assert parser.__name__ == "main"

try:
    # Try to import the non-default parser
    import semantic_release.test_parser as test_parser
    from semantic_release.test_parser import main as test_main
except ImportError as e:
    raise ImportError(
        f"semantic_release.test_parser is not installed. "
        f"Run the following command to install it: "
        f"$ pip install semantic-release[test-parser]"
    ) from e
else:
    # Set the non-default parser as the configuration entry
    config["commit_parser"] = "semantic_release.test_parser.main"

    # Then test it
    def test_current_commit_parser_with_override():
        parser

# Generated at 2022-06-21 21:07:40.694504
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parser import CommitMessageParser
    from . import parser

    assert current_commit_parser() == CommitMessageParser
    assert current_commit_parser() == parser.CommitMessageParser
    assert current_commit_parser() == parser.CommitMessageParser.parse



# Generated at 2022-06-21 21:07:47.337845
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.hooks.components import (
        commit_msg,
        changelog,
        changelog_entry_title,
        changelog_entry_body,
        changelog_entry_body_without_issue,
        changelog_entry_body_with_issue,
    )
    class_config = _config()

# Generated at 2022-06-21 21:07:58.704129
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Using tempfile.NamedTemporaryFile for a temporary file with a true path
    import tempfile
    from io import StringIO

    # Writing the content
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        f.write(
            """
[tool.semantic_release]
commit_parser = semantic_release.commit_parser:parse_commit
changelog_components = semantic_release.changelog_components:IssueComponent
"""
        )

    # Reading the content
    with open(f.name, "r") as f:
        conf = _config_from_pyproject(f.name)

    # Asserting
    assert conf["commit_parser"] == "semantic_release.commit_parser:parse_commit"

# Generated at 2022-06-21 21:08:05.004630
# Unit test for function overload_configuration
def test_overload_configuration():
    config["project_name"] = "foo"
    args = {}

    def function():
        pass

    function = overload_configuration(function)

    # the key "project_name" is not in the arguments in args.
    args = {}
    assert function(**args) == None
    assert config["project_name"] == "foo"

    # the key "project_name" is passed in args.
    args = {
        "define": ["project_name=bar"]
    }
    assert function(**args) == None
    assert config["project_name"] == "bar"

# Generated at 2022-06-21 21:08:09.060644
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Testing if current_commit_parser is working correctly
    :return:
    """
    from semantic_release.commit_parser import default_commit_parser

    assert current_commit_parser() is default_commit_parser

# Generated at 2022-06-21 21:08:33.941539
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test for function overload_configuration
    """

    def test_func(foo=None, bar=None, define=None):
        params = {"foo": foo, "bar": bar}

        return params

    updated_test_func = overload_configuration(test_func)
    params = updated_test_func(f"foo=foo", f"bar=bar", define=[f"foo=changed_foo"])

    assert params["foo"] == "changed_foo"
    assert params["bar"] == "bar"

# Generated at 2022-06-21 21:08:36.422155
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_param"] = "test_config"
    assert(config["test_param"] == "test_config")

    @overload_configuration
    def test_function(define):
        assert(config["test_param"] == "overload")

    test_function(define="test_param=overload")

# Generated at 2022-06-21 21:08:46.117538
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""
    # These should all succeed
    test_strings = [
        "semantic_release.changelog.changelog_components.header",
        "semantic_release.changelog.changelog_components.unreleased",
        "semantic_release.changelog.changelog_components.released",
    ]
    for test_string in test_strings:
        config["changelog_components"] = test_string
        current_changelog_components()



# Generated at 2022-06-21 21:08:56.279293
# Unit test for function overload_configuration
def test_overload_configuration():
    # Assert function overload_configuration does not crash
    @overload_configuration
    def config_overload_test(define=None):
        pass

    config_overload_test()

    # Assert function overload_configuration does not crash and does not change "config"
    @overload_configuration
    def config_overload_test_no_define(define=None):
        pass

    # Function config_overload_test_no_define does not have a parameter "define"
    config_overload_test_no_define()
    assert "push_to" in config
    assert "release_branch" in config

    # Assert function overload_configuration does not crash and do not change "config"
    # as there is a space before the first "="

# Generated at 2022-06-21 21:09:03.510371
# Unit test for function overload_configuration
def test_overload_configuration():
    """Tests that function overload_configuration decorator sets the variables
    in config.
    """
    # Change variable "check_build_status" to "False"
    @overload_configuration
    def func(a, b):
        return a + b

    assert config["check_build_status"] == True
    func(1, 2, define=["check_build_status=False"])
    assert config["check_build_status"] == False

# Generated at 2022-06-21 21:09:06.093730
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = False

    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["test=True"])
    assert config["test"] == "True"

# Generated at 2022-06-21 21:09:07.002034
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:09:08.505585
# Unit test for function current_commit_parser
def test_current_commit_parser():
    generate = current_commit_parser()
    assert callable(generate)



# Generated at 2022-06-21 21:09:11.752612
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    This function perform a unit test on the function current_commit_parser,
    that returns the path of the parser function currently used.
    """
    config["commit_parser"] = "package.module.commit_parser"
    commit_parser = current_commit_parser()
    assert commit_parser == "package.module.commit_parser"


# Generated at 2022-06-21 21:09:13.311480
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """A simple unit test for the current_changelog_components"""
    current_changelog_components()
    return

# Generated at 2022-06-21 21:09:41.081185
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        assert config['commit_parser'] == 'semantic_release.commit_parser.parse_commit_message'
        assert config['changelog_components'] == 'semantic_release.components.issues,semantic_release.components.merge_requests'
        assert config['git_author_name'] == 'Unittest'
        assert config['git_author_email'] == 'unittest@example.com'

    test(define=["commit_parser=my_commit_parser",
                 "changelog_components=my_commit_parser",
                 "git_author_name=Unittest",
                 "git_author_email=unittest@example.com"])

# Generated at 2022-06-21 21:09:52.155883
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog
    back_up = config.get("changelog_components")
    config.data["changelog_components"] = "semantic_release.changelog.release_summary"
    assert current_changelog_components() == [changelog.release_summary]
    config.data["changelog_components"] = "semantic_release.changelog.changelog_title"
    assert current_changelog_components() == [changelog.changelog_title]
    config.data["changelog_components"] = "semantic_release.changelog.commit_summary"
    assert current_changelog_components() == [changelog.commit_summary]

# Generated at 2022-06-21 21:09:54.405576
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = current_commit_parser()
    assert callable(commit_parser)

# Generated at 2022-06-21 21:09:59.002078
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import public_repo_changes
    from semantic_release.changelog import private_repo_changes
    assert current_changelog_components() == [
        public_repo_changes,
        private_repo_changes,
    ]

# Generated at 2022-06-21 21:10:02.179366
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define):
        return config["commit_parser"]

    func(define=["commit_parser=parser.func"])
    assert config["commit_parser"] == "parser.func"