

# Generated at 2022-06-21 21:00:08.178510
# Unit test for function overload_configuration
def test_overload_configuration():
    # Monkey patch
    setattr(config, "get", lambda x: None)

    @overload_configuration
    def foo():
        pass

    foo(define=("test=test"))
    assert config["test"] == "test"

# Generated at 2022-06-21 21:00:18.899320
# Unit test for function current_changelog_components
def test_current_changelog_components():
    class MockModule:
        @classmethod
        def mock_component_one(cls):
            return "mocked_component1"

        @classmethod
        def mock_component_two(cls):
            return "mocked_component2"

    mock_path = "semanticrelease.cli.overload_configuration"

    with importlib.mock.patch(
        mock_path + ".current_changelog_components"
    ) as mock_current_changelog_components:
        mock_current_changelog_components.return_value = [
            MockModule.mock_component_one,
            MockModule.mock_component_two,
        ]
        components = current_changelog_components()

        assert MockModule.mock_component_one == components[0]
        assert Mock

# Generated at 2022-06-21 21:00:21.495023
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert os.path.exists(current_commit_parser)

# Generated at 2022-06-21 21:00:23.267633
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-21 21:00:27.165463
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        len(current_changelog_components()) == 2
    ), "current_changelog_components returns a list of 2 elements"

# Generated at 2022-06-21 21:00:32.419226
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Fake the config module to return the correct parser module."""
    with config.override(commit_parser="semantic_release.commit_parser:default_type_mapping"):
        parser = current_commit_parser()
        assert parser.__module__ == "semantic_release.commit_parser"
        assert parser.__name__ == "default_type_mapping"


# Generated at 2022-06-21 21:00:42.941194
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

    @overload_configuration
    def foo(argument, define=[], bar="bar"):
        return config["argument"], config["define"], config["bar"]

    # assert functions well with no overload
    assert foo("foo") == ("foo", [], "bar")

    # assert function overloads argument
    assert foo("foo", define=["bar=foo"]) == ("foo", ["bar=foo"], "bar")

    # assert function can overload both argument and argument
    assert foo("foo", define=["bar=foo", "argument=foo"]) == ("foo", ["bar=foo", "argument=foo"], "bar")

    # assert function overloads define with a string
    assert foo("foo", define="argument=foo") == ("foo", [], "bar")

    # assert function overloads define with a list

# Generated at 2022-06-21 21:00:48.856780
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog.components import fix_component, feat_component
    from .changelog.components import doc_component, style_component, perf_component
    from .changelog.components import revert_component, build_component
    from .changelog.components import test_component, chore_component, refactor_component
    # assert current_changelog_components() == [
    # fix_component, feat_component, doc_component, style_component, perf_component, revert_component, build_component, test_component, chore_component, refactor_component
    # ]

# Generated at 2022-06-21 21:00:53.953498
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()[0]("") == "", "Default changelog test"
    assert (
        current_changelog_components()[1]("")
        == "",
        "Default commit changelog test",
    )
    assert (
        current_changelog_components()[2]("")
        == "",
        "Default issue changelog test",
    )

# Generated at 2022-06-21 21:00:58.138877
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Test with a valid parser
    assert current_commit_parser().__name__ == "compute_parser"

    # Test with an invalid parser
    config["commit_parser"] = "non-existing.commit_parser"

    try:
        current_commit_parser()
    except ImproperConfigurationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 21:01:08.774380
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import standard

    assert config.get("commit_parser") == "semantic_release.commit_parser:standard"
    assert current_commit_parser() == standard

# Generated at 2022-06-21 21:01:14.261926
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Mock the content that is normally generated from setup.cfg
    config.get = lambda x: "semantic_release.commit_parser.custom_parser"
    parser = current_commit_parser()
    # The function imported from the custom_parser file looks like
    # this one:
    #
    # def custom_parser(commits: List[Commit]) -> Optional[str]:
    #     return "1.0.0"
    assert parser([]) == "1.0.0"

# Generated at 2022-06-21 21:01:24.837996
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Should return an ImproperConfigurationError if no 'commit_parser' property is set
    Should return commit_parser function from module semantic_release.commit_parser
    """

    # Arrange
    cli_args = ['pysetup', 'release', 'patch']
    expected = 'semantic_release.commit_parser.default'

    # Act
    del config['commit_parser']
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()
    config['commit_parser'] = expected
    result = current_commit_parser()

    # Assert
    assert isinstance(result, Callable)
    assert result.__module__ == 'semantic_release.commit_parser'
    assert result.__name__ == 'default'


# Generated at 2022-06-21 21:01:35.456101
# Unit test for function overload_configuration
def test_overload_configuration():
    test_args = {"define": ["test.path=test_path", "version.suffix=test_suffix"]}
    expected_config = {"test.path": "test_path", "version.suffix": "test_suffix"}
    test_func_called = False
    test_config_before = config.copy()

    @overload_configuration
    def test_func(args):
        nonlocal test_func_called
        assert args is test_args
        assert config == expected_config
        test_func_called = True

    test_func(test_args)
    assert test_func_called
    assert config == test_config_before

# Generated at 2022-06-21 21:01:37.505152
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser.parse_commits"


# Generated at 2022-06-21 21:01:40.508776
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser'
    assert current_commit_parser().__name__ == 'parse'



# Generated at 2022-06-21 21:01:42.270238
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history.default_parser import parse

    assert current_commit_parser() == parse



# Generated at 2022-06-21 21:01:47.914963
# Unit test for function overload_configuration
def test_overload_configuration():
    # We assume that config["package_files"] haven't been overloaded previously
    current_config = config.get("package_files")

    @overload_configuration
    def overload(**kwargs):
        return config.get("package_files")

    # Now that we call overload with the parameter "package_files=test.py"
    # we assume that config["package_files"] should be equal to ["test.py"]
    overloaded_config = overload(define=["package_files=test.py"])
    assert overloaded_config == ["test.py"]

    # Reset the previous configuration for unit tests
    config["package_files"] = current_config

# Generated at 2022-06-21 21:01:50.760007
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog.components import commits, issues, tasks

    assert current_changelog_components() == [commits, issues, tasks]

# Generated at 2022-06-21 21:01:53.955415
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.tests.test_config.test_function'
    assert current_changelog_components()[0] == test_function



# Generated at 2022-06-21 21:02:03.128822
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser == parser



# Generated at 2022-06-21 21:02:08.921444
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.Body,
        semantic_release.changelog.components.IssuesClosed,
        semantic_release.changelog.components.PkgReference,
    ]

# Generated at 2022-06-21 21:02:10.583696
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert type(current_changelog_components()[0]) == Callable

# Generated at 2022-06-21 21:02:13.371990
# Unit test for function current_commit_parser
def test_current_commit_parser():
    @current_commit_parser()
    def commit_parser_func():
        return None

    assert commit_parser_func is not None

# Generated at 2022-06-21 21:02:22.210621
# Unit test for function overload_configuration
def test_overload_configuration():
    # Semantic release should always default to True
    assert config["changelog_capitalize"] is False
    assert config["changelog_scope"] is False

    # Overload the configuration
    @overload_configuration
    def test(**kwargs):
        return kwargs

    kwargs = test(define=["changelog_capitalize=True"])
    assert config["changelog_capitalize"] is True
    assert config["changelog_scope"] is False

    kwargs = test(define=["changelog_scope=True"])
    assert config["changelog_capitalize"] is False
    assert config["changelog_scope"] is True

# Generated at 2022-06-21 21:02:24.720704
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import ChangelogParser

    assert current_changelog_components() == ChangelogParser._components

# Generated at 2022-06-21 21:02:28.098488
# Unit test for function overload_configuration
def test_overload_configuration():
    # given
    @overload_configuration
    def test_func(define):
        pass

    # when
    test_func(define=["test=hello"])

    # then
    assert config['test'] == 'hello'

# Generated at 2022-06-21 21:02:31.380008
# Unit test for function overload_configuration
def test_overload_configuration():
    def fake_function(*args, **kwargs):
        return

    fake_wrapper = overload_configuration(fake_function)
    fake_wrapper("param1", define=["package_name=test"])
    assert config["package_name"] == "test"

# Generated at 2022-06-21 21:02:35.772361
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test that the define option is correctly taken into account
    """
    # given
    @overload_configuration
    def func():
        return config["foo"]

    # when
    result = func(define=["foo=bar"])

    # then
    assert result == "bar"

# Generated at 2022-06-21 21:02:37.883354
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # No exception raised
    current_changelog_components()

# Generated at 2022-06-21 21:02:48.640077
# Unit test for function current_commit_parser
def test_current_commit_parser():
    module = "semantic_release.commit_parser"
    assert config.get("commit_parser") == module + ":parse_commit"
    assert current_commit_parser() == importlib.import_module(module).parse_commit



# Generated at 2022-06-21 21:02:49.701561
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changes import Changelog

    assert current_changelog_components() == [Changelog]

# Generated at 2022-06-21 21:02:56.039617
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import Changelog

    @overload_configuration
    def changelog_semver(define=None):
        """Get the currently-configured changelog components

        :raises ImproperConfigurationError: if ImportError or AttributeError is raised
        :returns: List of component functions
        """

        components = current_changelog_components()
        # Component functions
        return Changelog(components)

    # We need to mock config.get because the test run outside the context of
    # semantic-release and this could raise an error
    with mock.patch("semantic_release.settings.config.get") as mock_get:
        mock_get.return_value = "semantic_release.changelog.components.scope"

# Generated at 2022-06-21 21:03:03.360320
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test for the overload_configuration decorator"""
    config["test_key"] = "test_value"

    @overload_configuration
    def get_config(key):
        return config[key]

    result = get_config("test_key")
    assert result == "test_value"

    result = get_config("test_key", define=["test_key=new_test_value"])
    assert result == "new_test_value"

# Generated at 2022-06-21 21:03:12.759700
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration"""

    def function_to_test(define=[]):
        pass

    function_to_test_overloaded = overload_configuration(function_to_test)

    assert config.get('tag_format') == 'v${version}'
    function_to_test_overloaded(define=["tag_format=foo"])
    assert config.get('tag_format') == 'foo'
    function_to_test_overloaded(define=[])
    assert config.get('tag_format') == 'foo'
    function_to_test_overloaded()
    assert config.get('tag_format') == 'foo'

    function_to_test_overloaded(define=["tag_format=v${version}"])
    assert config.get('tag_format') == 'v${version}'

# Generated at 2022-06-21 21:03:14.430786
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser.parse_commits'
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:03:22.743310
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo():
        pass

    @overload_configuration
    def bar(define: List[str]):
        pass

    try:
        foo(define=["pre_release_name=alpha"])
        foo()
        foo(define=["unknown=foo"])
        foo(define=["unknown=foo", "other=bar"])
    except Exception:
        assert False

    try:
        bar(define=[])
        bar(define=["pre_release_name=alpha"])
    except Exception:
        assert False

# Generated at 2022-06-21 21:03:28.279826
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # init config with invalid path
    config.__setitem__('commit_parser', 'bad.module')
    # function should raise exception
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()
    # init config with valid path
    config.__setitem__('commit_parser', 'semantic_release.commit_parser.parser')
    assert current_commit_parser()



# Generated at 2022-06-21 21:03:33.157836
# Unit test for function current_changelog_components
def test_current_changelog_components():
    ret = current_changelog_components()
    assert len(ret) == 2
    assert callable(ret[0])
    assert callable(ret[1])
    # The following line will raise an error if the function is not called
    from semantic_release.changelog import parse_changelog_to_summary_string

    assert ret[0] == parse_changelog_to_summary_string

# Generated at 2022-06-21 21:03:38.656672
# Unit test for function overload_configuration
def test_overload_configuration():
    # Call the function with a value of define equivalent to --define
    # "upload_to_pypi=False" on the command line.
    # This part was adapted from
    # https://github.com/relekang/rstcheck/blob/master/rstcheck/tests/test_main.py
    @overload_configuration
    def foo():
        pass

    foo(define=["upload_to_pypi=False"])

    # Here, we test if the variable has really been modified
    assert config.get("upload_to_pypi") == "False"

# Generated at 2022-06-21 21:03:48.283673
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "components"

# Generated at 2022-06-21 21:03:50.710645
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import guess_version

    assert current_changelog_components() == [guess_version]



# Generated at 2022-06-21 21:03:54.695239
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import BreakingChangeComponent

    config["changelog_components"] = "semantic_release.changelog.BreakingChangeComponent"

    assert current_changelog_components() == [BreakingChangeComponent]



# Generated at 2022-06-21 21:03:57.562376
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser()
        == "semantic_release.commit_parser.default_commit_parser"
    )



# Generated at 2022-06-21 21:04:07.023027
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()("feat: add feature") == (
        "feat",
        "add feature",
        None,
    )
    assert current_commit_parser()("fix: add feature") == (
        "fix",
        "add feature",
        None,
    )
    assert current_commit_parser()("feat: add feature!(scope)") == (
        "feat",
        "add feature",
        "scope",
    )
    assert current_commit_parser()("feat: add feature(scope)") == (
        "feat",
        "add feature",
        "scope",
    )
    assert current_commit_parser()("feat: add feature (scope)") == (
        "feat",
        "add feature",
        "scope",
    )

# Generated at 2022-06-21 21:04:08.071855
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() is not None

# Generated at 2022-06-21 21:04:09.353026
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:04:17.580222
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 4
    assert callable(components[0])
    assert callable(components[1])
    assert callable(components[2])
    assert callable(components[3])
    assert components[0].__name__ == "get_issue_url"
    assert components[1].__name__ == "get_commits"
    assert components[2].__name__ == "format_commit"
    assert components[3].__name__ == "get_author_name"


# Generated at 2022-06-21 21:04:22.426265
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Load the parser and make sure it's the default
    default = current_commit_parser()
    from semantic_release.history import parse

    assert default == parse

    # Overload it with a new function
    config["commit_parser"] = "tests.test_commands.load_parser"

    loaded = current_commit_parser()

    assert loaded == load_parser



# Generated at 2022-06-21 21:04:25.094098
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Function exists, have correct name and be callable
    from semantic_release.parser import parse

    assert callable(current_commit_parser())
    assert current_commit_parser() == parse



# Generated at 2022-06-21 21:04:37.063125
# Unit test for function current_commit_parser
def test_current_commit_parser():

    # Test if function works without parser in [semantic_release]
    config.pop("commit_parser", None)
    assert not config.get("commit_parser")

    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError(
            'Function current_commit_parser should raise ImproperConfigurationError'
        )

    # Test if function works with parser in [semantic_release]
    config["commit_parser"] = "semantic_release.commit_parser:parse_commits"
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:04:47.344533
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """current_changelog_components

    :raises ImproperConfigurationError: if ImportError or AttributeError is raised
    :returns: List of component functions
    """
    component_paths = 'semantic_release.changelog_generator.get_commits,semantic_release.changelog_generator.create_header,semantic_release.changelog_generator.create_footer'
    components = list()


# Generated at 2022-06-21 21:04:48.699005
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config.get = lambda x: "pyupgrade.upgrade_file_contents"

    commit_parser = current_commit_parser()
    assert callable(commit_parser)
    assert commit_parser.__name__ == "upgrade_file_contents"



# Generated at 2022-06-21 21:04:51.874044
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    This method tests the function current_commit_parser.
    """
    from .commit_parser import get_all_commits

    assert current_commit_parser() == get_all_commits



# Generated at 2022-06-21 21:04:59.765404
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_parser(data):
        return data

    config = {"commit_parser": "semantic_release.tests.test_config.test_parser"}
    assert current_commit_parser()(data="test") == "test"

    with raises(ImproperConfigurationError):
        config = {"commit_parser": "3"}
        assert current_commit_parser()



# Generated at 2022-06-21 21:05:09.465040
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the function current_changelog_components"""
    from .changelog import generate_changelog_components
    from .changelog import custom_componennt

    components = current_changelog_components()
    config["changelog_components"] = "semantic_release.changelog.generate_changelog_components"
    assert current_changelog_components()[0] == generate_changelog_components
    config["changelog_components"] = "semantic_release.changelog.generate_changelog_components, " \
        "semantic_release.changelog.custom_componennt"
    assert current_changelog_components()[0] == generate_changelog_components
    assert current_changelog_components

# Generated at 2022-06-21 21:05:16.756647
# Unit test for function overload_configuration
def test_overload_configuration():
    from .__main__ import main

    assert config.get("define") is None

    # overload_configuration should set config[python_files] value to "tests/*.py"
    assert config.get("python_files") == "**/*.py"

    main(["check", "--define", "python_files=tests/*.py"])

    assert config.get("python_files") == "tests/*.py"

# Generated at 2022-06-21 21:05:17.413762
# Unit test for function overload_configuration
def test_overload_configuration():
    pass

# Generated at 2022-06-21 21:05:18.834144
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:05:25.959944
# Unit test for function overload_configuration
def test_overload_configuration():
    from .utils import override_argv

    # Overload "upload_to_pypi"
    with override_argv("--define", "upload_to_pypi=True"):
        @overload_configuration
        def foo():
            assert config.getboolean("upload_to_pypi") is True

        foo()

    # Overload "upload_to_release"
    with override_argv("--define", "upload_to_release=false"):
        @overload_configuration
        def foo():
            assert config.getboolean("upload_to_release") is False

        foo()

# Generated at 2022-06-21 21:05:36.591265
# Unit test for function overload_configuration
def test_overload_configuration():
    import sys
    from semantic_release import main

    sys.argv = [
        sys.argv[0], "major",
        "--define", "dry-run=True",
        "--define", "build_status=False",
    ]
    main()
    assert config["dry_run"] == "True"
    assert config["build_status"] == "False"

# Generated at 2022-06-21 21:05:43.353796
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_overload_configuration"] = None

    @overload_configuration
    def test_overload_configuration_function(a, b, c, define=None):
        return a + b + c

    c = test_overload_configuration_function(1, 2, 3, define=["test_overload_configuration=4"])
    assert c == 6
    assert config["test_overload_configuration"] == "4"

# Generated at 2022-06-21 21:05:50.629154
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    assert overload_configuration is working.
    """
    global config
    config = _config()
    config_before = config["changelog_components"]
    @overload_configuration
    def update_config(define):
        return define

    update_config(define=["changelog_components=new_components"])
    assert config.get("changelog_components") == "new_components"
    config["changelog_components"] = config_before

# Generated at 2022-06-21 21:05:54.474481
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def builder(a, b, c, define=None):
        print(config)
        return a + b + c

    builder(3, 4, 5, define=["a=1"])
    assert config["a"] == "1"

# Generated at 2022-06-21 21:05:55.086217
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components()

# Generated at 2022-06-21 21:05:59.915628
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # When the function is called the first time, config is empty.
    # Then, the function is called with a config.
    config["commit_parser"] = "semantic_release.commit_parser.standard"
    assert current_commit_parser() == "standard"
    config["commit_parser"] = "semantic_release.commit_parser.angr"
    assert current_commit_parser() == "angr"
    config["commit_parser"] = None
    assert current_commit_parser() == "standard"

# Generated at 2022-06-21 21:06:06.028401
# Unit test for function current_changelog_components
def test_current_changelog_components():
    test_components = [
        "semantic_release.changelog.default_components.header",
        "semantic_release.changelog.default_components.body",
        "semantic_release.changelog.default_components.footer",
    ]
    assert current_changelog_components() == list(
        map(current_commit_parser, test_components)
    )

# Generated at 2022-06-21 21:06:14.182248
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # trigger the ImportError exception
    config["commit_parser"] = "example.parser"

    # set the parser to the default one
    config["commit_parser"] = "semantic_release.commit_parser.parser"

    # retrieve the parser
    parser = current_commit_parser()

    # test basic usage
    parser("test phrase #semver: major")
    assert parser("test phrase #semver: major") == "major"

    # test multiple parser calls
    parser("test phrase #semver: patch")
    parser("test phrase #semver: patch")
    assert parser("test phrase #semver: patch") == "patch"

# Generated at 2022-06-21 21:06:18.604060
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import title_capitalization, scope_title_capitalization

    current_components = current_changelog_components()
    assert title_capitalization in current_components
    assert scope_title_capitalization in current_components

# Generated at 2022-06-21 21:06:21.718249
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(define=None):
        return define

    assert my_function(define=['first=1', 'second=2']) is not None



# Generated at 2022-06-21 21:06:33.782702
# Unit test for function current_changelog_components
def test_current_changelog_components():

    assert type(current_changelog_components()) == list
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-21 21:06:37.209427
# Unit test for function overload_configuration
def test_overload_configuration():
    config["fake_key"] = "old_value"

    @overload_configuration
    def test_function(*args, **kwargs):
        assert config["fake_key"] == "new_value"

    test_function(define=["fake_key=new_value"])

# Generated at 2022-06-21 21:06:38.709618
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parsers import parse_commits as default_parser

    assert current_commit_parser() == default_parser

# Generated at 2022-06-21 21:06:45.308480
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(args):
        return config[args]

    initial_value = config["tag_pattern"]
    new_value = "new value"

    assert func("tag_pattern") == initial_value
    func("define=tag_pattern={}".format(new_value))
    assert func("tag_pattern") == new_value
    func("define=tag_pattern={}".format(initial_value))
    assert func("tag_pattern") == initial_value

# Generated at 2022-06-21 21:06:46.313460
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:06:49.698657
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import BreakingChange, Feature, Bugfix, MiscChange
    components = current_changelog_components()
    assert components == [BreakingChange, Feature, Bugfix, MiscChange]

# Generated at 2022-06-21 21:06:52.710119
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser"""
    config["commit_parser"] = "semantic_release.commit_parser.default_parser"
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:06:53.739653
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:06:58.232329
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import bug_fix  # NOQA

    config["changelog_components"] = "semantic_release.changelog_components.bug_fix"
    assert current_changelog_components() == [bug_fix]

# Generated at 2022-06-21 21:07:06.694005
# Unit test for function overload_configuration
def test_overload_configuration():

    # Simple case when we use decorator overload_configuration
    @overload_configuration
    def test_config(a, b=None, c=None, d=None, define=[]):
        return a, b, c, d

    # Simple case when we don't use decorator overload_configuration
    def test_config2(a, b=None, c=None, d=None, define=[]):
        return a, b, c, d

    # Run test cases

# Generated at 2022-06-21 21:07:25.258682
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test for the function current_changelog_components.

    This function checks that if the configuration of the changelog components
    is correct in the setup.cfg, then the function returns the correct list of
    components.
    """
    from semantic_release.changelog import create_component_description

    config_parser = configparser.ConfigParser()
    config_parser.read("setup.cfg")

    # Test for the components without specified module
    config_parser.set("semantic_release", "changelog_components", "first,second")
    with open("setup.cfg", "w") as setup_config_file:
        config_parser.write(setup_config_file)

    result = current_changelog_components()

# Generated at 2022-06-21 21:07:27.719754
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def config_wrapper(define):
        pass

    config_wrapper(define=["test=true"])
    assert config["test"] == "true"

# Generated at 2022-06-21 21:07:30.466753
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parser"
    assert current_commit_parser().__module__ == "semantic_release.commit_parser"

# Generated at 2022-06-21 21:07:34.079478
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "tests.commands.test_semantic_release.fixtures.commit_parser.parser"
    assert current_commit_parser()("") == "foo"



# Generated at 2022-06-21 21:07:38.293822
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test_value"
    assert config["test"] == "test_value"
    @overload_configuration
    def dummy_func(define):
        pass
    dummy_func(define=["test=new_value"])
    assert config["test"] == "new_value"

# Generated at 2022-06-21 21:07:46.121873
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import test_compatibility, test_changelog, main

    def overload_compatibility(func):
        return func

    def overload_changelog(func):
        return func

    test_compatibility = overload_configuration(test_compatibility)
    test_changelog = overload_configuration(test_changelog)
    main = overload_configuration(main)
    test_compatibility = overload_compatibility(test_compatibility)
    test_changelog = overload_compatibility(test_changelog)
    main = overload_compatibility(main)

    test_compatibility(define=["changelog_components=changelog_components_1",
                               "changelog_components=changelog_components_2"])


# Generated at 2022-06-21 21:07:57.672212
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import sys
    import tempfile
    import pathlib
    import pytest

    cwd = pathlib.Path(tempfile.mkdtemp())

    (cwd / "changelog_components.py").touch()

    # Create a pyproject.toml file with the following content
    config_file = (
        "[tool.semantic_release]\n"
        f"changelog_components=changelog_components.component1,{cwd}/other_component.component2\n"
    )
    with open(cwd / "pyproject.toml", "w") as f:
        f.write(config_file)
    sys.path.append(cwd)

    def component1():
        pass

    def component2():
        pass


# Generated at 2022-06-21 21:07:59.865133
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["critical"]
    assert test_func(define=["critical=10"]) == "10"

# Generated at 2022-06-21 21:08:01.646587
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser() == importlib.import_module("semantic_release.commit_parser").parse
    )



# Generated at 2022-06-21 21:08:04.525998
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """An test for the current_changelog_components function
    """

    # The list of the changelog components is not empty
    components = current_changelog_components()
    assert len(components) > 0

# Generated at 2022-06-21 21:08:18.094801
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import components

    assert current_changelog_components() == [
        components.note_release,
        components.breaking_change,
        components.feature,
        components.fix,
        components.ci_enhancement,
        components.docs,
    ]

# Generated at 2022-06-21 21:08:24.138080
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test for "overload_configuration" using a simple function.
    """

    # Simple function to test the decorator
    def foo(a):
        assert config["foo"] == "bar"
        assert config["bar"] == "foo"
        return a

    assert foo(0) == 0

    # Overload "config"
    foo = overload_configuration(foo)

    assert foo(0, define=["foo=bar", "bar=foo"]) == 0

# Generated at 2022-06-21 21:08:32.336149
# Unit test for function overload_configuration
def test_overload_configuration():
    import deepdiff

    @overload_configuration
    def _test_function(define):
        return config

    # Call a function with the overload
    config["overloaded"] = False
    config["new_value"] = False
    config["overloaded_bool"] = False
    config["overloaded_string"] = ""
    config["overloaded_int"] = 0

    output_1 = _test_function(define=["new_value=True"])
    output_2 = _test_function(
        define=["overloaded=True", "overloaded_bool=True", "overloaded_string=string", "overloaded_int=1"]
    )

    # Check that the function overload the "config" dict
    comparison = {"dictionary_item_added": {"root['new_value']": True}}
    assert deepdiff.DeepDiff

# Generated at 2022-06-21 21:08:39.649840
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Function to test the current_commit_parser, mocking _config"""
    # Mocking _config with a return of a parser function
    _config_backup = _config
    val = {'commit_parser': 'semantic_release.commit_parser.parse_commits'}
    _config = lambda: val

    # Test if the current_commit_parser returns the parse_commits function
    parser = current_commit_parser()
    assert parser == parse_commits

    # Reset the value of _config
    _config = _config_backup


# Unit Test for function current_changelog_components

# Generated at 2022-06-21 21:08:45.436899
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.documentation_update,semantic_release.changelog.components.breaking_change"
    assert len(current_changelog_components()) == 2

# Generated at 2022-06-21 21:08:47.663789
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import body_components
    assert current_changelog_components() == [body_components]

# Generated at 2022-06-21 21:08:57.063822
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # test with valid value
    data = {'changelog_components': 'semantic_release.changelog.ReleaseChangelogComponent,semantic_release.changelog.BreakingChangesChangelogComponent'}
    config.data = data
    result = current_changelog_components()
    assert result[0].__name__ == 'ReleaseChangelogComponent'
    assert result[1].__name__ == 'BreakingChangesChangelogComponent'

    # test with invalid value
    data = {'changelog_components': 'semantic_release.invalid'}
    config.data = data
    try:
        result = current_changelog_components()
        assert False, 'Should raise ImproperConfigurationError'
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:09:01.554373
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """This function tests if the current_commit_parser is returning the expected
    value.

    :returns: None
    """
    assert (
        current_commit_parser() == "semantic_release.commit_parser:CommitMessage"
    )

# Generated at 2022-06-21 21:09:03.592499
# Unit test for function current_changelog_components
def test_current_changelog_components():
    res = current_changelog_components()
    assert len(res) == 2

# Generated at 2022-06-21 21:09:09.786651
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    """

    @overload_configuration
    def add_1(value, define=[]):
        return int(value) + 1

    @overload_configuration
    def add_2(value, define=[]):
        return int(value) + 2

    @overload_configuration
    def add_semantic_release_version(value, define=[]):
        """returns the value + the version of this library
        """
        from .__version__ import __version__

        return value + __version__

    assert add_1(1, define=["other=False"]) == 2
    assert add_2(1, define=["other=False"]) == 3
    assert config["other"] == "False"


# Generated at 2022-06-21 21:09:25.976630
# Unit test for function overload_configuration
def test_overload_configuration():
    """Check if overload_configuration decorator is applied correctly."""

    @overload_configuration
    def function(define):
        return config["package_name"]

    # no define
    assert function() == "semantic_release"

    # define with wrong format
    assert function(define="wrong_format") == "semantic_release"

    # define with correct format
    assert function(define="package_name=overloaded") == "overloaded"

# Generated at 2022-06-21 21:09:30.091477
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def mock_function(*args, **kwargs):
        return True
    mock_function(define=["a=b", "c=d"])
    assert config.get("a") == "b"
    assert config.get("c") == "d"

# Generated at 2022-06-21 21:09:32.903127
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test function current_commit_parser"""
    config['commit_parser'] = "semantic_release.commit_parser.parse_message"
    result = current_commit_parser()


# Generated at 2022-06-21 21:09:35.350150
# Unit test for function overload_configuration
def test_overload_configuration():
    def old_func(define):
        assert define == ["a=b", "c=d"]
        return "test"

    @overload_configuration
    def new_func(define):
        assert define == ["a=b", "c=d"]
        return "test"

    assert old_func(["a=b", "c=d"]) == "test"
    assert new_func(["a=b", "c=d"]) == "test"

# Generated at 2022-06-21 21:09:43.009837
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []
    os.environ["SEMANTIC_RELEASE_CHANGELOG_COMPONENTS"] = \
        "semantic_release.changelog.components.issue_template.get_issue_template"

    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "get_issue_template"

    config["changelog_components"] = "semantic_release.changelog.components.issue_template.get_issue_template"
    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "get_issue_template"


# Generated at 2022-06-21 21:09:48.128367
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import (
        issues_closed,
        commits_since_last_release,
    )
    assert (
        current_changelog_components()
        == [issues_closed, commits_since_last_release]
    )

# Generated at 2022-06-21 21:09:49.510467
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-21 21:09:56.106521
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_version import Version

    # Function that uses the decorator
    @overload_configuration
    def foo(version):
        return version

    config["current_version"] = "2.2.2"

    # The first case does not use the "define" argument,
    # so therefore the configuration is not changed
    version = foo(Version("3.3.3"))
    assert(version == Version("3.3.3"))
    assert(config["current_version"] == "2.2.2")

    # The second case uses the "define" argument and
    # therefore the configuration changes
    version = foo(Version("4.4.4"), define=["current_version=4.4.4"])
    assert(version == Version("4.4.4"))

# Generated at 2022-06-21 21:09:57.506857
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()