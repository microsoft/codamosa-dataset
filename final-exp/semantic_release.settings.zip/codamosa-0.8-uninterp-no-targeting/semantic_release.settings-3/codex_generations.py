

# Generated at 2022-06-21 21:00:06.224327
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser"
    current_commit_parser()



# Generated at 2022-06-21 21:00:07.915986
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None


# Generated at 2022-06-21 21:00:17.235326
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the decorator overload_configuration"""
    @overload_configuration
    def func(define):
        return

    assert config.get("commit_message_footer") == "Closes Issue #<number>"
    func(define=["define=value", "commit_message_footer=Closes #<number>"])
    assert config.get("commit_message_footer") == "Closes #<number>"
    func(define=["commit_message_footer=<number>"])
    assert config.get("commit_message_footer") == "<number>"


__all__ = ["current_commit_parser", "current_changelog_components"]

# Generated at 2022-06-21 21:00:18.555885
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 2


# Generated at 2022-06-21 21:00:25.223782
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse

    assert current_commit_parser() == parse
    assert config.get("commit_parser") == "semantic_release.commit_parser.parse"

    config["commit_parser"] = "tests.test_settings.test_current_commit_parser"

    assert current_commit_parser() == test_current_commit_parser
    assert config.get("commit_parser") == "tests.test_settings.test_current_commit_parser"

# Generated at 2022-06-21 21:00:26.888245
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test current_commit_parser function
    """
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:00:30.807948
# Unit test for function overload_configuration
def test_overload_configuration():
    config["key"] = "old_value"

    @overload_configuration
    def func(define):
        pass

    func(define=["key=new_value"])
    assert config["key"] == "new_value"

# Generated at 2022-06-21 21:00:34.818515
# Unit test for function current_commit_parser
def test_current_commit_parser():
    @overload_configuration
    def test_helper(define):
        parser_module = current_commit_parser()
        name = parser_module.__name__
        return parser_module, name

    assert test_helper(define=["commit_parser=semantic_release.vcs.git.parser"])[1] == "git_parser"

# Generated at 2022-06-21 21:00:41.076903
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(**kwargs):
        return kwargs

    assert "define" not in test_function()
    assert "b" not in config
    assert "a" not in config
    test_function(define=["b=1", "a=2"])
    assert config["b"] == "1"
    assert config["a"] == "2"

# Generated at 2022-06-21 21:00:42.345838
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:00:55.031934
# Unit test for function overload_configuration
def test_overload_configuration():
    try:
        current_value = config.get("changelog_components")
        assert (
            overloade_configuration(
                current_value,
                define=["changelog_components=new_value_1,new_value_2"],
            )
            == current_value
        )
    except ImproperConfigurationError as e:
        assert False
    finally:
        config["changelog_components"] = current_value


if __name__ == "__main__":
    test_overload_configuration()

# Generated at 2022-06-21 21:00:59.198898
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert config.get("commit_parser") == "semantic_release.commit_parser.default"
    assert current_commit_parser().__name__ == "default"
    with open("setup.cfg", "w") as f:
        f.write('[semantic_release]\ncommit_parser = semantic_release.commit_parser.default\n')



# Generated at 2022-06-21 21:01:02.008757
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        pass

    assert config["commit_parser"] == "semantic_release.commit_parser"
    test(define=["commit_parser=test"])
    assert config["commit_parser"] == "test"

# Generated at 2022-06-21 21:01:03.704980
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def parser():
        pass

    assert current_commit_parser() == parser

# Generated at 2022-06-21 21:01:11.913285
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(a, b, c=0, d=None, define=[]):
        return {
            "a": a,
            "b": b,
            "c": c,
            "d": d,
            "define": define,
        }

    decorated_func = overload_configuration(func)
    assert decorated_func(1, 2, define=["c=5"]) == {
        "a": 1,
        "b": 2,
        "c": 5,
        "d": None,
        "define": ["c=5"],
    }

# Generated at 2022-06-21 21:01:15.746667
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()(b"a") == b"a"



# Generated at 2022-06-21 21:01:18.802648
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test case for function current_commit_parser.
    """

    from semantic_release.parser import commit_parser as parser

    assert current_commit_parser() == parser



# Generated at 2022-06-21 21:01:21.096475
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        assert callable(current_commit_parser()) is True
    except ImproperConfigurationError as error:
        print(error)
        assert False

# Generated at 2022-06-21 21:01:23.250531
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the current_commit_parser function"""

    set_option('commit_parser', 'semantic_release.commit_parser')
    assert current_commit_parser() is not None
    assert current_commit_parser() == commit_parser



# Generated at 2022-06-21 21:01:28.010780
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history import semantic_release_history

    # Test simple case
    config["commit_parser"] = "semantic_release.history.semantic_release_history"
    assert current_commit_parser() == semantic_release_history

    # Test more complex case
    config["commit_parser"] = "semantic_release.history.semantic_release_history.parse"
    assert current_commit_parser() == semantic_release_history.parse

    # Test with empty parser
    del config["commit_parser"]
    assert current_commit_parser() == semantic_release_history.parse

# Generated at 2022-06-21 21:01:40.466715
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def fake_func(a, b=1, c=2):
        return a, b, c

    assert fake_func(3, define=["b=5"]) == (3, 5, 2)

# Generated at 2022-06-21 21:01:44.106359
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.get = lambda item: "local.component_test"
    components = current_changelog_components()
    assert len(components) == 1
    assert type(components[0]) == type(test_current_changelog_components)



# Generated at 2022-06-21 21:01:49.234495
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import tests.changelog_components as tests_changelog_components

    components = current_changelog_components()
    assert tests_changelog_components.example_component == components[0]
    # testing that 2nd component is not in the list
    index = components.index(tests_changelog_components.example_component2)
    assert index == -1
    # testing that 3rd component is not in the list
    index = components.index(tests_changelog_components.example_component3)
    assert index == -1



# Generated at 2022-06-21 21:01:50.848752
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser



# Generated at 2022-06-21 21:01:54.912839
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import (
        breaking_change_version,
        breaking_change_component,
        detail_changes_version,
        detail_changes_component,
        release_notes_component,
    )

    current_changelog_components()

# Generated at 2022-06-21 21:02:03.277271
# Unit test for function overload_configuration
def test_overload_configuration():
    # Arrange
    config['changelog_components'] = 'local_pkg.local_func1,local_pkg.local_func2'
    config['commit_parser'] = 'local_pkg.local_func3'
    # Act
    @overload_configuration
    def test(**kwargs):
        print('test')
    test(define=["changelog_components=local_pkg.local_func4", "commit_parser=local_pkg.local_func5"])
    # Assert
    assert config['changelog_components'] == 'local_pkg.local_func4'
    assert config['commit_parser'] == 'local_pkg.local_func5'

# Generated at 2022-06-21 21:02:12.267374
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.hvcs import bitbucket, github, gitlab
    assert current_commit_parser() == bitbucket.get_commits
    config['commit_parser'] = 'semantic_release.hvcs.gitlab.get_commits'
    assert current_commit_parser() == gitlab.get_commits
    config['commit_parser'] = 'semantic_release.hvcs.github.get_commits'
    assert current_commit_parser() == github.get_commits

# Generated at 2022-06-21 21:02:17.030030
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.feature,
        semantic_release.changelog.components.breaking_change,
        semantic_release.changelog.components.fix,
        semantic_release.changelog.components.misc,
    ]

# Generated at 2022-06-21 21:02:18.840452
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) > 0

# Generated at 2022-06-21 21:02:29.504073
# Unit test for function overload_configuration
def test_overload_configuration():
    from .overload_configuration import config, overload_configuration

    @overload_configuration
    def test_function(define):
        for defined_param in define:
            pair = defined_param.split("=", maxsplit=1)
            if len(pair) == 2:
                config[str(pair[0])] = pair[1]

    _config = config.copy()

    assert config["package_name"] == "new-package"
    test_function(define=["package_name=test"])
    assert config["package_name"] == "test"
    config.clear()
    config.update(_config)
    assert config["package_name"] == "new-package"

    assert "package_version" not in config
    test_function(define=["package_version=test"])

# Generated at 2022-06-21 21:02:44.183971
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import changelog_components
    from semantic_release.changelog import changelog_components as default_components
    assert current_changelog_components() == default_components
    config['changelog_components'] = "semantic_release.changelog.components"
    assert current_changelog_components() == changelog_components

# Generated at 2022-06-21 21:02:51.139389
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test if current_changelog_components correctly returns the list
    of changelog components under its "changelog_components" key
    """
    from .changelog_components import PreviousVersion, Summary

    config["changelog_components"] = "semantic_release.changelog_components.PreviousVersion,semantic_release.changelog_components.Summary"
    components = current_changelog_components()

    assert isinstance(components, list)
    assert len(components) == 2
    assert components[0] == PreviousVersion
    assert components[1] == Summary



# Generated at 2022-06-21 21:02:52.772679
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser:parse_commits"


# Generated at 2022-06-21 21:02:54.546917
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog

    current_changelog_components() == [changelog.diff_component]

# Generated at 2022-06-21 21:03:02.493859
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        from semantic_release.commit_parser import parse_commits
        assert current_commit_parser() == parse_commits
    except ImportError:
        pass
    try:
        from semantic_release.commit_parser import default_commit_parser
        config['commit_parser'] = 'semantic_release.commit_parser:default_commit_parser'
        assert current_commit_parser() == default_commit_parser
    except ImportError:
        pass



# Generated at 2022-06-21 21:03:08.530700
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator effectively overloads the config.
    """
    # init config
    test_config = config
    assert test_config.get("upload_to_pypi")

    # override config
    class MockArgs:
        def __init__(self):
            self.define = ["upload_to_pypi=False"]

    @overload_configuration
    def mock_func(args):
        config["upload_to_pypi"] = args.upload_to_pypi

    mock_func(MockArgs())
    assert not test_config.get("upload_to_pypi")

    # restore config
    test_config["upload_to_pypi"] = True
    assert test_config.get("upload_to_pypi")



# Generated at 2022-06-21 21:03:09.841026
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == type(lambda:0)



# Generated at 2022-06-21 21:03:13.250123
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "tests.test_changelog_components.component1"
    component1 = importlib.import_module("tests.test_changelog_components").component1
    assert component1 == current_changelog_components()[0]

# Generated at 2022-06-21 21:03:17.642127
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=[]):
        return define

    assert test_function(define=["hello=world"]) == ["hello=world"]
    config["hello"] == "world"

# Generated at 2022-06-21 21:03:26.503722
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.tests.test_helpers.test_current_changelog_components_1,semantic_release.tests.test_helpers.test_current_changelog_components_2,semantic_release.tests.test_helpers.test_current_changelog_components_3'
    components = current_changelog_components()
    assert len(components) == 3
    assert components[0]() == 1
    assert components[1]() == 2
    assert components[2]() == 3
    config['changelog_components'] = 'semantic_release.tests.test_helpers.test_current_changelog_components_1'
    components = current_changelog_components()
    assert len(components)

# Generated at 2022-06-21 21:03:37.474254
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config.get = lambda x: "semantic_release.commit_parser.default"
    commit_parser = current_commit_parser()
    assert commit_parser.__name__ == 'default'


# Generated at 2022-06-21 21:03:38.363711
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None


# Generated at 2022-06-21 21:03:40.251496
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.changelog_body
    ]

# Generated at 2022-06-21 21:03:47.218423
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Sanity test for function current_changelog_components
    """
    config.get.return_value = "semantic_release.changelog.components.header"
    assert current_changelog_components() == [
        semantic_release.changelog.components.header
    ]

    config.get.return_value = "semantic_release.changelog.components.header,semantic_release.changelog.components.footer"
    assert current_changelog_components() == [
        semantic_release.changelog.components.header,
        semantic_release.changelog.components.footer,
    ]


# Generated at 2022-06-21 21:03:48.708760
# Unit test for function current_commit_parser
def test_current_commit_parser():
    result = current_commit_parser()
    assert result is not None


# Generated at 2022-06-21 21:03:54.427160
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import (
        breaking_change_section,
        issue_section,
        issue_references,
        bullet_item,
    )
    components = current_changelog_components()
    assert components == [
        breaking_change_section,
        issue_section,
        issue_references,
        bullet_item,
    ]

# Generated at 2022-06-21 21:04:02.862265
# Unit test for function overload_configuration
def test_overload_configuration():
    # Mock the method get() in UserDict
    def get_mock(self, key):
        return config.get(key)

    UserDict.get = get_mock

    assert config.get("python_package") == "git+git://github.com/relekang/python-semantic-release.git#egg=python-semantic-release"

    @overload_configuration
    def my_function(kwargs):
        return config.get("python_package")

    assert my_function(define=["python_package=test"]) == "test"

# Generated at 2022-06-21 21:04:10.608491
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # get commit parser
    commit_parser = current_commit_parser()
    assert callable(commit_parser)

    # test parser function
    commit_message = (
        "feat(scope): broadcast $destroy event on scope destruction\n\nCloses #8"
    )
    changelog_entry = commit_parser(commit_message)
    assert isinstance(changelog_entry, dict)
    assert changelog_entry == {
        "type": "feature",
        "scope": "scope",
        "subject": "broadcast $destroy event on scope destruction",
        "body": "",
        "issues": [],
        "breaking": False,
        "commits": [],
    }

    # test parser with a license change
    commit_message = "license(mit): add mit license"
    changelog_

# Generated at 2022-06-21 21:04:21.854791
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Test if current_changelog_components function returns a
    list of functions

    :return: True if the function returns a list of functions
    """
    from semantic_release.changelog import version_change_type_filter
    from semantic_release.changelog import title_from_issue_filter
    from semantic_release.changelog import title_case_filter

    config["changelog_components"] = "semantic_release.changelog.version_change_type_filter,semantic_release.changelog.title_from_issue_filter,semantic_release.changelog.title_case_filter"

    assert current_changelog_components() == [
        version_change_type_filter,
        title_from_issue_filter,
        title_case_filter,
    ]

# Generated at 2022-06-21 21:04:22.797054
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-21 21:04:40.484463
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    Test if current_changelog_components() returns the expected result
    """
    from mock import MagicMock
    from semantic_release import config

    # mock function "Component" to make sure it's called
    test_component = MagicMock()
    config.config["changelog_components"] = "semantic_release.tests.test_config.test_component"
    components = config.current_changelog_components()

    assert len(components) == 1
    assert components[0] == test_component

# Generated at 2022-06-21 21:04:41.369322
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:04:47.150421
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    try:
        config["hello"]
    except KeyError:
        pass
    else:
        raise AssertionError("assertion error")

    @overload_configuration
    def dummy_function(define):
        pass

    dummy_function(define=["hello=world"])
    assert config["hello"] == "world"

# Generated at 2022-06-21 21:04:49.841650
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .parser import parse_commits

    assert current_commit_parser() == parse_commits


# Unit tests for function current_changelog_components

# Generated at 2022-06-21 21:04:54.745222
# Unit test for function overload_configuration
def test_overload_configuration():
    """This unit test tests that
    the function overload_configuration works as expected.
    """

    @overload_configuration
    def func1(arg1, arg2):
        print(arg1, arg2)

    assert config["release_commit_message_style"] == "pep440"

    func1("arg1", "arg2", define=["release_commit_message_style=keep_current"])
    assert config["release_commit_message_style"] == "keep_current"



# Generated at 2022-06-21 21:04:55.926615
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components()

# Generated at 2022-06-21 21:04:59.284987
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test if the current_commit_parser function is functioning correctly."""
    from semantic_release import commit_parser

    assert current_commit_parser() == commit_parser

# Generated at 2022-06-21 21:05:02.737176
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == 'semantic_release.changelog.components.release'

# Generated at 2022-06-21 21:05:04.478077
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.history import release_note

    assert current_changelog_components() == [release_note]

# Generated at 2022-06-21 21:05:10.639075
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""
    import semantic_release.components.changelog_components as changelog_components
    config['changelog_components'] = 'semantic_release.components.changelog_components.changelog_component_1, semantic_release.components.changelog_components.changelog_component_2'
    components = current_changelog_components()
    assert changelog_components.changelog_component_1 in components
    assert changelog_components.changelog_component_2 in components

# Generated at 2022-06-21 21:05:21.677083
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def fake():
        pass
    fake(define=["foo=bar"])
    assert config.get("foo") == "bar"

# Generated at 2022-06-21 21:05:32.217304
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import (
        Types,
        cmp_commits,
        cmp_scope,
        cmp_description,
        cmp_body,
        cmp_body_nginx,
    )

    # Get the list of component functions
    components = current_changelog_components()

    # Check if the necessary component functions are present
    assert cmp_commits in components
    assert cmp_scope in components
    assert cmp_description in components
    assert cmp_body in components

    # Check if the changelog components are in the correct order
    # cmp_commits should come last
    assert components[-1] == cmp_commits

    # Check if the changelog components are in the correct order
    # cmp_scope should come first
    assert components[0] == cmp

# Generated at 2022-06-21 21:05:35.334136
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Should get the parser specified in the default.cfg
    assert current_commit_parser() == parse_commit_message


# Generated at 2022-06-21 21:05:36.468957
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components()

# Generated at 2022-06-21 21:05:41.074642
# Unit test for function overload_configuration
def test_overload_configuration():
    config["new_value"] = "pre_test"

    @overload_configuration
    def func(define=None):
        print(config["new_value"])

    func(define=["new_value=post_test"])
    assert config["new_value"] == "post_test"

# Generated at 2022-06-21 21:05:47.887698
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test 1: define a new value that doen not exist in module
    @overload_configuration
    def test_func(define):
        assert config["hello"] == "world"

    test_func(define=["hello=world"])

    # Test 2: define an already existing value in module
    @overload_configuration
    def test_func(define):
        assert config["major_on_zero"] == "False"

    test_func(define=["major_on_zero=False"])

    # Test 3: define a new value and an already existing value in module
    @overload_configuration
    def test_func(define):
        assert config["hello"] == "world"
        assert config["major_on_zero"] == "True"


# Generated at 2022-06-21 21:05:50.345194
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_commit"



# Generated at 2022-06-21 21:05:51.602460
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()() == "changelog"



# Generated at 2022-06-21 21:05:57.205758
# Unit test for function overload_configuration
def test_overload_configuration():
    config_copy = config.copy()
    assert config_copy != {}

    @overload_configuration
    def test():
        pass

    test(define=["user_name=Gregory", "email=gregory.poirer@polyconseil.fr"])

    assert config["user_name"] == "Gregory"
    assert config["email"] == "gregory.poirer@polyconseil.fr"



# Generated at 2022-06-21 21:05:59.771241
# Unit test for function overload_configuration
def test_overload_configuration():
    config["my_param"] = "my_value"

    @overload_configuration
    def my_function(define):
        assert config.get("my_param") == "new_value"

    my_function(define=["my_param=new_value"])

# Generated at 2022-06-21 21:06:11.644440
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import components
    assert current_changelog_components() == [components.title, components.body]

# Generated at 2022-06-21 21:06:12.796875
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:06:24.206929
# Unit test for function current_changelog_components
def test_current_changelog_components():
    function_name: str = "current_changelog_components"
    # default package
    assert len(current_changelog_components()) == 2
    assert len(current_changelog_components()) == 2
    # custom package
    config["changelog_components"] = "semantic_release.changelog_component.merges,semantic_release.changelog_component.commits"
    assert len(current_changelog_components()) == 2
    config["changelog_components"] = ""
    assert len(current_changelog_components()) == 1
    # error "ImportError"
    config["changelog_components"] = "semantic_release.changelog_component.not_exists_module"

# Generated at 2022-06-21 21:06:28.346540
# Unit test for function current_commit_parser
def test_current_commit_parser():

    # Configure commit_parser 
    config.data["commit_parser"] = "semantic_release.commit_parser.angular_style_commit_parser"

    # Should run successfully
    current_commit_parser()

    # Test with improper configuration
    config.data.pop("commit_parser")

    # Should throw ImproperConfigurationError
    with raises(ImproperConfigurationError):
        current_commit_parser()


# Generated at 2022-06-21 21:06:31.750647
# Unit test for function current_commit_parser
def test_current_commit_parser():
    if current_commit_parser() == "semantic_release.hvcs_parsers.standard":
        pass

# Generated at 2022-06-21 21:06:34.779985
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse_from_file"
    assert current_commit_parser()(None) == {}



# Generated at 2022-06-21 21:06:37.743154
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) > 0
    for component in components:
        assert callable(component)


if __name__ == "__main__":
    current_changelog_components()

# Generated at 2022-06-21 21:06:41.316046
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser:CommitParser'
    assert current_commit_parser() == importlib.import_module('.commit_parser', 'semantic_release').CommitParser



# Generated at 2022-06-21 21:06:50.611207
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test is structured like a unit test but it's a functional one. It
    will trigger the stdout of the functions.
    You can use it if you want but you will probably pollute your console with
    prints.
    """
    # pylint: disable=unused-variable

    @overload_configuration
    def main(arg1, arg2, define=[]):
        """
        This function is just here to test the decorator.
        """
        print(config)
        print("You gave me: ", arg1, arg2)

    main("aaa", "bbb", define=["commit_parser=aaa.bbb.ccc"])

# Generated at 2022-06-21 21:06:57.659538
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import setup_cfg as sc

    sc.config["parser"] = "old_parser"

    @overload_configuration
    def test_function(define):
        print(sc.config["parser"])

    test_function(define=["parser=new_parser"])
    # Assert that function overload_configuration works, config["parser"]
    # should be the value passed with the parameter "define"
    assert sc.config["parser"] == "new_parser"

# Generated at 2022-06-21 21:07:09.961210
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.changelog import parse_commit

    assert current_commit_parser() == parse_commit



# Generated at 2022-06-21 21:07:11.217618
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-21 21:07:15.477549
# Unit test for function overload_configuration
def test_overload_configuration():
    config["define"] = False

    @overload_configuration
    def overload_config_func(define):
        return config["define"]

    assert overload_config_func(define="define=True")
    assert not overload_config_func(define="define=False")

# Generated at 2022-06-21 21:07:18.613195
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def dummy_parse(commit_message):
        return commit_message

    config['commit_parser'] = '.'.join(
        [dummy_parse.__module__, dummy_parse.__name__])

    from .commit_parser import default_parse as default_parse
    # default_parse is a wrapper around the default_parse_function
    assert current_commit_parser() != default_parse
    assert current_commit_parser() == dummy_parse
    config.pop('commit_parser')

# Generated at 2022-06-21 21:07:20.359300
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_func():
        pass
    config["commit_parser"] = ".".join([test_func.__module__, test_func.__name__])
    assert current_commit_parser() == test_func



# Generated at 2022-06-21 21:07:30.118060
# Unit test for function overload_configuration
def test_overload_configuration():
    #  Set up a config dict
    config = dict(
        token_url='https://gitlab.com/oauth/token',
        redirect_url='https://gitlab.com/oauth/token',
        client_id='client',
        client_secret='secret'
    )

    #  Set up a function with a "define" parameter
    def func(a, *args, define):
        pass

    #  Set up some parameters to define in the "define" parameter
    defines = [
        'token_url=https://gitlab.com/api/v4/oauth/token',
        'client_id=my_client',
        'client_secret=my_secret'
    ]

    #  We call the original function with some parameters
    #  One of them is the "define" parameter.
    new_func

# Generated at 2022-06-21 21:07:32.051140
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import default_commit_parser
    assert current_commit_parser() == default_commit_parser



# Generated at 2022-06-21 21:07:33.565417
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == list()

# Generated at 2022-06-21 21:07:41.331323
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This test case is used to check if our overload_configuration function works
    as expected.
    """
    @overload_configuration
    def func(define=None):
        if define:
            for defined_param in define:
                pair = defined_param.split("=", maxsplit=1)
                if len(pair) == 2:
                    config[str(pair[0])] = pair[1]
        # cut the first letter of the value
        return config["non-existent-key"][1:]

    func(define=["non-existent-key=value"])
    assert func() == "alue", "value was not properly set"

# Generated at 2022-06-21 21:07:43.944114
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define, a, b):
        return a, b

    assert test(define=["build_command=echo", "b=2"], a=1) == (1, 2)

# Generated at 2022-06-21 21:07:56.696867
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog_components.InlineChangeEntry'
    assert current_changelog_components() == [InlineChangeEntry]

# Generated at 2022-06-21 21:07:58.666291
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"]='semantic_release.commit_parser.default_commit_parser'
    assert current_commit_parser()==default_commit_parser

# Generated at 2022-06-21 21:08:03.443766
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog as changelog_module
    assert list(map(lambda x: changelog_module.ChangelogComponents.FUNCTION_NAME, current_changelog_components())) == [
        "check_tag",
        "get_current_version",
        "get_commits_since_last_release",
        "get_section_items"
    ]


# Generated at 2022-06-21 21:08:04.561466
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "parse"


# Generated at 2022-06-21 21:08:05.927825
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:08:13.597071
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import tests

    try:
        # We test the function with function tests.changelog_components
        config["changelog_components"] = 'semantic_release.components.tests.changelog_components'
        current_components = current_changelog_components()
        assert current_components == tests.changelog_components
    except Exception:
        # The test fails
        return False
    # The test success
    return True

# Generated at 2022-06-21 21:08:15.816542
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser:CommitParser"

# Generated at 2022-06-21 21:08:21.437958
# Unit test for function overload_configuration
def test_overload_configuration():
    def my_function(a, b, c, define=None):
        assert config["a"] == "1"
        assert config["b"] == "2"
        assert config["c"] == "3"
        assert config["e"] == "4"
    wrapped_function = overload_configuration(my_function)
    wrapped_function(0, 0, 0, define=["a=1", "b=2", "c=3", "d", "e=4"])

# Generated at 2022-06-21 21:08:25.470805
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def just_a_function(a=10, define=None):
        if a == 10 and config.get("foo") == "bar":
            return True
        return False

    assert just_a_function(define=["foo=bar"]) == True

# Generated at 2022-06-21 21:08:30.924067
# Unit test for function overload_configuration
def test_overload_configuration():
    from .commands.release import release

    @overload_configuration
    def test_overload_conf(parse):
        pass

    # NOTE: importlib.import_module('commands.release') imports the release module
    test_overload_conf(
        importlib.import_module("semantic_release.commands.release").release,
        define=["commit_parser=semantic_release.utils.tests.parser_test"],
    )

    assert current_commit_parser() is release

# Generated at 2022-06-21 21:08:46.606837
# Unit test for function overload_configuration
def test_overload_configuration():
    function_to_test = overload_configuration(lambda define: define)
    assert function_to_test(define=["key=value"]) == ["key=value"]

# Generated at 2022-06-21 21:08:56.608824
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def get_config(self, *args):
        return config

    assert get_config()

    config["foo"] = "bar"

    assert get_config().get("foo") == "bar"

    config["foo"] = "baz"

    assert get_config().get("foo") == "baz"

    assert "foo" in config

    assert get_config().get("foo") == "baz"

    config["foo"] = "foo"

    assert get_config().get("foo") == "foo"

    config["foo"] = "bar"
    config["bar"] = "foo"

    assert get_config().get("foo") == "bar"
    assert get_config().get("bar") == "foo"

    assert "foo" in get_config()

# Generated at 2022-06-21 21:09:07.534393
# Unit test for function overload_configuration
def test_overload_configuration():
    from .config import _config
    from .cli import _run_main

    config = _config()
    assert "changelog_components" in config
    assert "commit_parser" in config
    assert "tag_format" in config

    assert config["changelog_components"] == "semantic_release.changelog.components.issues_closed"
    assert config["commit_parser"] == "semantic_release.commit_parser.parse"
    assert config["tag_format"] == "{tag_name}"

    _run_main(["run", "--define", "changelog_components=semantic_release.changelog.components.issues"])
    assert config["changelog_components"] == "semantic_release.changelog.components.issues"

# Generated at 2022-06-21 21:09:15.511428
# Unit test for function overload_configuration
def test_overload_configuration():
    # Arrange
    @overload_configuration
    def get_config(key):
        return config[key]

    # Act/Assert
    assert get_config("remote_repo") == "origin"

    # Arrange
    assert get_config("remote_repo") == "origin"

    # Act
    get_config("remote_repo", define=["remote_repo=a_new_origin"])

    # Assert
    assert get_config("remote_repo") == "a_new_origin"

    # Arrange
    get_config("remote_repo", define=["remote_repo=a_new_origin"])
    assert get_config("remote_repo") == "a_new_origin"

    # Act

# Generated at 2022-06-21 21:09:20.712004
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .utils import parse_commit

    assert parse_commit == current_commit_parser()
    config["commit_parser"] = "semantic_release.utils.parse_commit"
    assert parse_commit == current_commit_parser()

# Generated at 2022-06-21 21:09:23.894606
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog_components.changelogComponent,
        semantic_release.changelog_components.double_dash,
    ]

# Generated at 2022-06-21 21:09:25.657052
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert(current_commit_parser() == "releasebot.commit_parser.parse")


# Generated at 2022-06-21 21:09:29.474996
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_generator import GenerateChangelog

    changelog_components = current_changelog_components()
    assert changelog_components == [GenerateChangelog]

# Generated at 2022-06-21 21:09:39.074535
# Unit test for function overload_configuration
def test_overload_configuration():
    """ Test the @overload_configuration function
    """
    # Test overload_configuration decorator
    @overload_configuration
    def print_config(**kwargs):
        """ Print a configuration value of semantic_release
        """
        print(config.get(kwargs.get("key"), ""))

    # Call print_config with a key
    print_config(key="version_variable", define=["version_variable=__version__"])
    # Call print_config with a key and a value
    print_config(
        key="version_variable",
        define=[
            "version_variable=__version__",
            "version_source=src/directory/test_overload_configuration.py",
        ],
    )
    # Call print_config with a key and a non-existing value

# Generated at 2022-06-21 21:09:40.742413
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser.__name__ == "current_commit_parser"
    assert callable(current_commit_parser())


# Generated at 2022-06-21 21:09:57.860386
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    import semantic_release.changelog.components

    assert (
        current_changelog_components()
        == [
            semantic_release.changelog.components.changes,
            semantic_release.changelog.components.security,
            semantic_release.changelog.components.deprecations,
            semantic_release.changelog.components.other,
        ]
    )