

# Generated at 2022-06-21 21:00:02.427873
# Unit test for function overload_configuration
def test_overload_configuration():
    # Given
    @overload_configuration
    def test_method_with_defined_params(define=None):
        # Then
        assert "push_to" in config and config["push_to"] == "github"

    # When
    test_method_with_defined_params(define=["push_to=github"])

# Generated at 2022-06-21 21:00:07.320810
# Unit test for function overload_configuration
def test_overload_configuration():
    # decorate a test function
    @overload_configuration
    def test_func(keys, **kwargs):
        return keys, config.get("foo"), kwargs.get("bar"), config.get("bar")

    # call the test function
    keys, foo, bar, bar_after = test_func(
        keys=["foo", "bar"], define=["foo=42", "bar=john doe"]
    )

    assert foo == "42"
    assert bar == "john doe"
    assert bar_after is None

# Generated at 2022-06-21 21:00:08.373966
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:00:13.922270
# Unit test for function current_changelog_components
def test_current_changelog_components():
    del config["changelog_components"]

    # Should raise ImproperConfigurationError
    raised = False
    try:
        current_changelog_components()
    except ImproperConfigurationError as e:
        assert str(e) == "Unable to import changelog component ''"
        raised = True
    assert raised



# Generated at 2022-06-21 21:00:19.954181
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test_func(*args):
        pass

    try:
        old_parser = config["commit_parser"]
        new_parser = "tests.test_config.test_func"
        config["commit_parser"] = new_parser
        assert current_commit_parser() == test_func

        # clean up
        config["commit_parser"] = old_parser
    except ImproperConfigurationError:
        raise AssertionError(
            "Test function couldn't be imported as commit parser"
        )



# Generated at 2022-06-21 21:00:21.092913
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:00:22.351953
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == config["commit_parser"]

# Generated at 2022-06-21 21:00:25.377778
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])
    assert callable(current_changelog_components()[1])
    assert callable(current_changelog_components()[2])

# Generated at 2022-06-21 21:00:31.900594
# Unit test for function overload_configuration
def test_overload_configuration():
    config["aaa"] = 1
    config["bbb"] = 1

    @overload_configuration
    def test_overload_config(define: tuple) -> None:
        assert config["aaa"] == 1
        assert config["bbb"] == 1

    test_overload_config(define=["aaa=3", "bbb=4"])
    assert config["aaa"] == 3
    assert config["bbb"] == 4



# Generated at 2022-06-21 21:00:38.465811
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Config version
    assert config.get("commit_parser") == "semantic_release.commit_parser"
    assert current_commit_parser.__module__ == "semantic_release.commit_parser"

    # Override version
    parser_module = "my_module"
    parser_func = "my_parser"
    config["commit_parser"] = parser_module + "." + parser_func
    assert current_commit_parser.__module__ == parser_module

# Generated at 2022-06-21 21:00:48.740435
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Validate that the commit_parser is an available function."""
    assert current_commit_parser() is not None



# Generated at 2022-06-21 21:00:51.727060
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass
    except:
        assert False, "current_commit_parser raised Unexpected error"



# Generated at 2022-06-21 21:00:52.656704
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:00:55.767570
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.parse"
    assert current_commit_parser() == parse

    config["commit_parser"] = "other_package.commit_parser.parse"
    assert current_commit_parser() == parse



# Generated at 2022-06-21 21:00:57.852534
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])
    assert callable(current_changelog_components()[1])


# Generated at 2022-06-21 21:01:02.907705
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog_components.BodyComponent,semantic_release.changelog_components.FooterComponent,semantic_release.changelog_components.HeaderComponent'
    assert len(current_changelog_components()) == 3

# Generated at 2022-06-21 21:01:10.326118
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy_function(define):
        return config.get("test_key")

    # Pair of key and value: the key can be any type of object, the value must be a string
    assert dummy_function(define=["test_key=test_value"]) == "test_value"
    assert dummy_function(define=["1=test_value"]) == "test_value"
    assert dummy_function(define=["2"]) is None

# Generated at 2022-06-21 21:01:14.842497
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser:CommitParser"
    assert callable(current_commit_parser())

    # Test raises exception
    config["commit_parser"] = "semantic_release.commit_parser:test"
    try:
        current_commit_parser()
        assert False, "Should not be here"
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:01:15.792434
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release import commit_parser

    assert current_commit_parser() == commit_parser

# Generated at 2022-06-21 21:01:18.327073
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function(*args, **kwargs):
        return kwargs

    assert function(define=["test=test"]) == {"define": ["test=test"]}
    assert config["test"] == "test"

    assert function(define=["test=test2"]) == {"define": ["test=test2"]}
    assert config["test"] == "test2"
    del config["test"]

# Generated at 2022-06-21 21:01:27.826427
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(bar):
        return config.get("foo") + bar

    assert foo(bar="bar") == "foo bar"



# Generated at 2022-06-21 21:01:40.848554
# Unit test for function current_changelog_components
def test_current_changelog_components():

    # Test if the changelog components are properly imported
    config['changelog_components'] = 'semantic_release.changelog.generate.initial_component, \
    semantic_release.changelog.generate.fixes_component, semantic_release.changelog.generate.features_component'
    changelog_components = current_changelog_components()
    assert len(changelog_components) == 3
    assert callable(changelog_components[0])
    assert callable(changelog_components[1])
    assert callable(changelog_components[2])

    # Test if the proper error is raised if ImportError or AttributeError is raised

# Generated at 2022-06-21 21:01:43.409606
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert (
        current_changelog_components()[0]
        == "semantic_release.changelog.utils.commit_summary"
    )
    pass

# Generated at 2022-06-21 21:01:51.998295
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # The decorator function needs a function to decorate
    def dummy_function(): pass

    # The decorator is first applied to the dummy function
    dummy_function = overload_configuration(dummy_function)

    # Checking if pyproject.toml is considered when no option is added
    assert len(current_changelog_components()) == 3

    # Checking if pyproject.toml is considered if option is set without value
    dummy_function(define="changelog_components=")
    assert len(current_changelog_components()) == 3

    # Checking if pyproject.toml is considered if option is set with a value
    dummy_function(define="changelog_components=dev-dependencies")
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-21 21:01:55.298065
# Unit test for function current_changelog_components
def test_current_changelog_components():
    path = 'semantic_release.changelog.components.issue_components'
    current_changelog_components()
    assert config.get('changelog_components') == path

# Generated at 2022-06-21 21:01:56.686376
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert hasattr(current_commit_parser(), "__call__")



# Generated at 2022-06-21 21:02:05.342812
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components
    """
    # Define a changelog_components parameter, that contains one function
    config['changelog_components'] = "semantic_release.changelog.components.release"
    # Check that the function is returned
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == 'release'
    # Define a changelog_components parameter, that contains two functions
    config['changelog_components'] = "semantic_release.changelog.components.release,semantic_release.changelog.components.differences"
    # Check that the functions are returned
    components = current_changelog_components()

# Generated at 2022-06-21 21:02:12.376521
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_parser

    with overload_configuration(current_commit_parser):
        assert current_commit_parser()() == default_parser()

    with overload_configuration(current_commit_parser):
        assert (
            current_commit_parser(
                define=["commit_parser=semantic_release.commit_parser.default_parser"]
            )()
            == default_parser()
        )



# Generated at 2022-06-21 21:02:19.580304
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test overload_configuration decorator"""
    from .cli._get_version import _get_version
    from .core.version import Version

    new_config = {'__build__': 0, '__version__': '0.0.0'}
    _get_version(define=list(new_config.keys()))
    assert config == new_config
    assert Version.version() == Version.from_string(new_config['__version__'])

# Generated at 2022-06-21 21:02:27.296811
# Unit test for function overload_configuration
def test_overload_configuration():
    old_value = config.get("non_existing_key", None)
    assert old_value is None

    # test with one valid definition
    @overload_configuration
    def overload(define="non_existing_key=value"):
        assert config["non_existing_key"] == "value"

    overload()

    # test with 3 valid definitions
    @overload_configuration
    def overload(define=["non_existing_key=value", "key=value", "key=value2"]):
        assert config["non_existing_key"] == "value"
        assert config["key"] == "value2"

    overload()

    assert config["non_existing_key"] == "value"
    assert config["key"] == "value2"

    # test with invalid definitions

# Generated at 2022-06-21 21:02:36.128030
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser is not None

# Generated at 2022-06-21 21:02:42.206986
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test1 : In case of empty path in changelog_components
    assert current_changelog_components() == []
    # Test2 : In case of wrong path in changelog_components
    config["changelog_components"] = ".wrong.module"
    try:
        current_changelog_components()
    except ImproperConfigurationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 21:02:44.365655
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import default_commit_parser
    assert current_commit_parser() == default_commit_parser

# Generated at 2022-06-21 21:02:53.005446
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration"""

    @overload_configuration
    def function1(test_key, define=[]):
        """Function with overload"""
        return config.get(test_key)

    assert function1("test_key1") == None
    assert function1("test_key2", define=["test_key1=test_value1"]) == None
    assert function1("test_key1", define=["test_key1=test_value1"]) == "test_value1"
    assert function1("test_key2", define=["test_key1=test_value1"]) == None
    assert function1("test_key1", define=["test_key1=test_value2"]) == "test_value2"
    assert function1("test_key1") == "test_value2"

# Generated at 2022-06-21 21:03:01.413735
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test if the config was overloaded with the new value
    @overload_configuration
    def test_config(define):
        return config["define"]

    test_config(define=["define=new_value"])
    assert config["define"] == "new_value"

    # Test if the config was overloaded with an empty string
    @overload_configuration
    def test_config(define):
        return config["define"]

    test_config(define=["define="])
    assert config["define"] == ""

# Generated at 2022-06-21 21:03:03.112417
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # testing to see if this works
    assert current_commit_parser()
    assert current_commit_parser()

# Generated at 2022-06-21 21:03:05.421622
# Unit test for function overload_configuration
def test_overload_configuration():
    from .commands.release import release

    release(define=["test=value"])
    assert config["test"] == "value"

# Generated at 2022-06-21 21:03:12.803982
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Change current commit parser from the default to a custom class
    config["commit_parser"] = "pkg.custom_parser.Parser"
    # Import custom class
    from .pkg.custom_parser import Parser
    assert current_commit_parser() == Parser.parse
    # Change current commit parser to a custom class which does not exist
    config["commit_parser"] = "pkg.faulty_custom_parser.Parser"
    # Assert an ImproperConfigurationError exception is raised
    import pytest
    with pytest.raises(ImproperConfigurationError, match="Unable to import parser"):
        current_commit_parser()
    assert True


# Generated at 2022-06-21 21:03:21.079045
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def display(**kwargs):
        print("DEBUG:", config["changelog_scope"])
        print("DEBUG:", config["hooks"])

    display(define=["changelog_scope=False", "hooks=['*']"])
    assert config["changelog_scope"] == "False"
    assert config["hooks"] == "['*']"
    print("overload_configuration - OK")



# Generated at 2022-06-21 21:03:26.577889
# Unit test for function overload_configuration
def test_overload_configuration():
    fake_func = lambda *args, define: define[0].split("=")[1]

    func = overload_configuration(fake_func)
    assert func(define=["foo=bar"]) == "bar"

    config["foo"] = "alpha"
    assert func(define=["foo=beta"]) == "beta"

# Generated at 2022-06-21 21:03:34.154209
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:03:34.756559
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:03:37.474002
# Unit test for function current_commit_parser
def test_current_commit_parser():
    class current_commit_parserTestCase(unittest.TestCase):
        def test_case(self):
            self.assertIsNotNone(current_commit_parser())
    return current_commit_parserTestCase



# Generated at 2022-06-21 21:03:41.600596
# Unit test for function overload_configuration
def test_overload_configuration():
    def my_test_with_define(define):
        print(config["test"])

    overload_configuration(my_test_with_define)(define=["test=1"])
    assert config["test"] == "1"
    overload_configuration(my_test_with_define)(define=["test=2"])
    assert config["test"] == "2"

# Generated at 2022-06-21 21:03:46.769181
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test for function overload_configuration"""
    config_copy = dict(config)
    overload_configuration(lambda: False)(define=["a=b"])
    assert config["a"] == "b"
    assert config_copy["a"] is None

# Generated at 2022-06-21 21:03:49.544772
# Unit test for function current_changelog_components
def test_current_changelog_components():
    result = current_changelog_components()
    assert len(result) == 4
    assert callable(result[0])
    assert callable(result[1])
    assert callable(result[2])
    assert callable(result[3])



# Generated at 2022-06-21 21:03:59.343215
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = {
        "test1": "test1",
        "test2": "test2",
    }
    mutable_dict = UserDict(test_config)

    @overload_configuration
    def mock_func(overloaded_dict):
        assert overloaded_dict == mutable_dict

    mock_func(define=["test1=test1_overloaded", "test3=test3"], **mutable_dict)
    assert mutable_dict == {
        "test1": "test1_overloaded",
        "test2": "test2",
        "test3": "test3",
    }

# Generated at 2022-06-21 21:04:05.294277
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = {"name": "value"}
    test_define = ["define=value", "define2=value", "define3=value"]

    @overload_configuration
    def test_func(define=None):
        return define

    assert test_func(define=test_define) == test_define
    assert test_config["define"] == "value"
    assert test_config["define2"] == "value"
    assert test_config["define3"] == "value"

# Generated at 2022-06-21 21:04:08.356218
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog.components as changelog_components
    assert current_changelog_components() == [
        changelog_components.title, changelog_components.body, changelog_components.footer,
    ]

# Generated at 2022-06-21 21:04:13.109213
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog

    components = current_changelog_components()
    assert len(components) == 2
    assert isinstance(components[0], Callable)
    assert isinstance(components[1], Callable)

    changelog.get_changelog_components = lambda: current_changelog_components()
    changelog.write_changelog(*changelog.generate_changelog())

    changelog.get_changelog_components = lambda: current_changelog_components()
    changelog.write_changelog(*changelog.generate_changelog())

# Generated at 2022-06-21 21:04:22.053963
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse

    assert parse is current_commit_parser()

# Generated at 2022-06-21 21:04:27.974119
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(*args, **kwargs):
        print(kwargs.get("define"))
        return True

    func_with_overload = overload_configuration(func)

    assert func_with_overload() == True
    assert func_with_overload(define=["a=b", "c=d"]) == True
    assert func_with_overload(define=["x=y"]) == True
    assert func_with_overload(define=["a=b", "name=value"]) == True
    assert isinstance(config.get("name"), str)

# Generated at 2022-06-21 21:04:31.203329
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import default_changelog_components
    output = current_changelog_components()
    assert output == default_changelog_components

# Generated at 2022-06-21 21:04:37.110762
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli

    semantic_release.cli.config = {}

    @overload_configuration
    def run(test=None):
        pass

    run("bla", define=["test_key=test_value"])
    assert semantic_release.cli.config["test_key"] == "test_value"

# Generated at 2022-06-21 21:04:38.464285
# Unit test for function current_commit_parser
def test_current_commit_parser():
    pass
    # assert current_commit_parser() == config["commit_parser"]

# Generated at 2022-06-21 21:04:39.775796
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parse_commits
    assert current_commit_parser() == parse_commits

# Generated at 2022-06-21 21:04:44.894234
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This function test that the overload_configuration decorator
    will update the config object as expected
    """
    @overload_configuration
    def test_func(define=None):
        return

    test_func(define=['first=hello', 'second=world'])
    assert config['first'] == 'hello'
    assert config['second'] == 'world'

# Generated at 2022-06-21 21:04:45.924108
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:04:51.103604
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define):
        if not define:
            return config["define"]

    config["define"] = "initial value"
    assert func(define=None) == "initial value"

    # Edit the configuration
    func(define=["define=new value"])
    assert config["define"] == "new value"

# Generated at 2022-06-21 21:04:56.705901
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config = _config()
    config["changelog_components"] = "semantic_release.changelog_components.components"
    assert current_changelog_components() == [components]

# Generated at 2022-06-21 21:05:07.226527
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()("feat: add commit parser") == {
        "type": "feat",
        "scope": None,
        "subject": "add commit parser",
        "body": None,
        "issues": [],
    }



# Generated at 2022-06-21 21:05:09.884483
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(arg, define=["test=test"]):
        return config

    assert foo(None) == {"test": "test"}


# Unit tests for functions _config_from_ini and current_commit_parser

# Generated at 2022-06-21 21:05:15.977507
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        'semantic_release.changelog.npm_component',
        'semantic_release.changelog.pypi_component',
        'semantic_release.changelog.gitlab_component'
    ]


# Generated at 2022-06-21 21:05:21.393161
# Unit test for function current_commit_parser
def test_current_commit_parser():
    class TestCommitParser:
        def parse(self, content):
            return "v2.0.0"

    assert current_commit_parser()("v1.0.0") == "v1.0.0"
    assert current_commit_parser(TestCommitParser())("v1.0.0") == "v2.0.0"

# Generated at 2022-06-21 21:05:22.514973
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])


# Generated at 2022-06-21 21:05:30.902123
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_overload(define):
        pass

    test_overload(define=["test=test"])
    assert(config["test"] == "test")

    test_overload(define=["test=test2"])
    assert(config["test"] == "test2")

    test_overload(define=["test=test", "test2=test2"])
    assert(config["test"] == "test")
    assert(config["test2"] == "test2")

# Generated at 2022-06-21 21:05:38.153582
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test method current_changelog_components"""
    expected = [
        semantic_release.changelog.components.BugsClosedComponent,
        semantic_release.changelog.components.FeaturesAddedComponent,
        semantic_release.changelog.components.BreakingChangesComponent,
    ]
    actual = semantic_release.config.current_changelog_components()
    assert actual == expected

# Generated at 2022-06-21 21:05:41.576276
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def do_something(*args, **kwargs):
        pass

    do_something(define=["a=b"])

    assert config.get("a") == "b"

# Generated at 2022-06-21 21:05:46.739156
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(release_type, **kwargs):
        return release_type, config["project_url"]

    func_with_overload = overload_configuration(func)

    func_with_overload(release_type="major", define=["project_url=my_new_url"])
    assert config["project_url"] == "my_new_url"

    func_with_overload(release_type="minor", define=["project_url=another_one"])
    assert config["project_url"] == "another_one"

# Generated at 2022-06-21 21:05:52.140387
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """ If a changelog_component is defined in setup.cfg then this function
    should return the parser function specified by that path
    """
    config["changelog_components"] = "semantic_release.changelog_components.get_message"
    return_func = current_changelog_components()
    assert len(return_func) == 1


# Generated at 2022-06-21 21:06:03.358784
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()



# Generated at 2022-06-21 21:06:07.710782
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(*args, **kwargs):
        return config["key"]

    assert test(define="key=value") == "value"
    assert test(define="key=value2") == "value2"
    assert config["key"] == "value2"

# Generated at 2022-06-21 21:06:15.894281
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release

    def mocked_function(define=None):
        if define:
            for defined_param in define:
                pair = defined_param.split("=", maxsplit=1)
                if len(pair) == 2:
                    config[str(pair[0])] = pair[1]
        return config

    # Overload parameters
    assert not overload_configuration(mocked_function)(None)
    assert (
        overload_configuration(mocked_function)(define="level=1")["level"] == "1"
    )
    assert (
        overload_configuration(mocked_function)(
            define=["level=1", "other=2"]
        )["level"]
        == "1"
    )

# Generated at 2022-06-21 21:06:16.460779
# Unit test for function current_changelog_components
def test_current_changelog_components():
    pass

# Generated at 2022-06-21 21:06:21.633149
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()("feat(semver): introduce semantic versioning") == {
        "scope": "semver",
        "subject": "introduce semantic versioning",
        "body": None,
        "type": "major",
    }



# Generated at 2022-06-21 21:06:26.397029
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == list()
    config["changelog_components"] = "semantic_release.changelog_components" + \
        ".parse_issue_refs,semantic_release.changelog_components" + \
        ".parse_commits"
    assert current_changelog_components() == [parse_issue_refs, parse_commits]



# Generated at 2022-06-21 21:06:32.440628
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def test_function():
        pass

    old_value = config["changelog_components"]
    config["changelog_components"] = "semantic_release.tests.test_config.test_function"
    result = current_changelog_components()
    config["changelog_components"] = old_value

    assert result[0] == test_function

# Generated at 2022-06-21 21:06:34.068852
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:06:41.808310
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import pytest
    from semantic_release.changelog_components import get_components

    with pytest.raises(ImproperConfigurationError):
        config["changelog_components"] = "this_does_not_exist.foo"
        current_changelog_components()

    with pytest.raises(ImproperConfigurationError):
        config["changelog_components"] = "semantic_release.this_does_not_exist"
        current_changelog_components()

    config["changelog_components"] = ""
    changelog_components = current_changelog_components()

    assert changelog_components == []

    config["changelog_components"] = ",".join(get_components().keys())
    changelog_components = current_ch

# Generated at 2022-06-21 21:06:44.246769
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser.__name__ == "current_commit_parser"



# Generated at 2022-06-21 21:06:54.927844
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_message

    assert isinstance(current_commit_parser(), Callable)
    assert current_commit_parser() == parse_message



# Generated at 2022-06-21 21:07:04.808947
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_components import (
        get_next_version,
        get_current_version,
        changelog,
        changelog_header,
        changelog_body,
    )
    expected_configuration = [
        get_next_version,
        get_current_version,
        changelog,
        changelog_header,
        changelog_body,
    ]

# Generated at 2022-06-21 21:07:05.833231
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-21 21:07:11.062247
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test that the current_commit_parser function returns the correct CommitParser."""
    from semantic_release.history.default import CommitParser

    parser = current_commit_parser()
    assert parser == CommitParser

# Generated at 2022-06-21 21:07:15.329307
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import changelog as changelog_component
    from .changelog import link_issues as link_issues_component
    assert current_changelog_components() == \
        [link_issues_component, changelog_component]


# Generated at 2022-06-21 21:07:18.866457
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import get_version_and_update_changelog

    @overload_configuration
    def my_function(param):
        return param

    try:
        get_version_and_update_changelog(["semantic-release", "--help"])
        assert config["remove_dist"] == "true"
    except (ImportError,  ImproperConfigurationError):
        pass
    assert my_function("hello", define=["world=good"]) == "hello"
    assert config["world"] == "good"

# Generated at 2022-06-21 21:07:21.466585
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import generate_changelog_components

    components = current_changelog_components()
    assert len(components) == 5



# Generated at 2022-06-21 21:07:22.445420
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:07:25.869570
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.full_title'
    result = current_changelog_components()
    assert len(result) == 1
    assert result[0] == full_title


# Generated at 2022-06-21 21:07:29.697732
# Unit test for function current_changelog_components

# Generated at 2022-06-21 21:07:38.913733
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())


# Generated at 2022-06-21 21:07:42.394643
# Unit test for function current_commit_parser
def test_current_commit_parser():
    test_parser = "semantic_release.commit_parser.get_commits"
    config["commit_parser"] = test_parser
    parser = current_commit_parser()
    assert parser.__module__.startswith("semantic_release.commit_parser")

# Generated at 2022-06-21 21:07:46.598248
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests if the overload_configuration function is working
    properly.
    """
    @overload_configuration
    def return_config(define):
        return config

    config["foo"] = "bar"
    assert return_config(define=["foo=baz"]) == {"foo": "baz"}
    assert return_config(define=["new=def"]) == {"foo": "baz", "new": "def"}
    assert return_config() == {"foo": "baz", "new": "def"}

# Generated at 2022-06-21 21:07:53.778272
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = (
        "semantic_release.changelog.components.body:BodyComponent,"
        "semantic_release.changelog.components.footer:FooterComponent"
    )
    changelog_components = current_changelog_components()
    assert changelog_components[0] == BodyComponent
    assert changelog_components[1] == FooterComponent

# Generated at 2022-06-21 21:07:58.171749
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the overload_configuration method"""
    @overload_configuration
    def mocked_function(**kwargs):
        """This function is mocked to test the overload_configuration method.
        """
        return kwargs

    assert mocked_function(define=["foo=bar"])["define"] == ["foo=bar"]

# Generated at 2022-06-21 21:08:06.304183
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from . import __version__

    class MockSemanticRelease(object):
        tools = {'semantic_release': {'commit_parser': 'semantic_release.commit_parser.parser'}}

    # We need a tmp pyproject.toml file and to set the current working directory to the
    # top of the module
    cwd = os.getcwd()
    os.chdir(os.path.dirname(__file__))

    with open("pyproject.toml", "w") as f:
        f.write(tomlkit.dumps(MockSemanticRelease))
    assert current_commit_parser.__name__ == 'parser'
    # Clean up the file and reset the cwd
    os.chdir(cwd)
    os.unlink("pyproject.toml")

# Generated at 2022-06-21 21:08:12.415472
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests that the function overload_configuration works.
    """
    from .main import semantic_release

    @overload_configuration
    def foo(bar):
        return bar

    semantic_release.main(["bugfix", "--dry-run", "--define=bar=baz"])
    assert config.get("bar") == "baz"

# Generated at 2022-06-21 21:08:22.401416
# Unit test for function overload_configuration
def test_overload_configuration():
    from .context import set_default_context
    from . import activate_set_release_plugins

    set_default_context()
    activate_set_release_plugins()

    @overload_configuration
    def main(**kwargs):
        return kwargs

    assert main(release=True) == {"release": True}
    assert main(release=True, define=["version_sources=my_branch"]) == {
        "release": True
    }
    assert config["version_sources"] == "my_branch"
    assert main(release=True, define=["version_sources=my_other_branch"]) == {
        "release": True
    }
    assert config["version_sources"] == "my_other_branch"

# Generated at 2022-06-21 21:08:30.181106
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def add_var(a, b):
        return a + b

    assert add_var(1, 2) == 3
    assert add_var(1, 2, define=["test=test"]) == 3
    assert add_var(1, 2, define=["test=test", "test2=test2"]) == 3
    assert add_var(1, 2, define=["test=test", "test2=test2", "a=9"]) == 11
    assert add_var(1, 2, define=["test=test", "test2=test2", "a=9", "b=3"]) == 12



# Generated at 2022-06-21 21:08:35.196688
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}

    @overload_configuration
    def function_without_define(**kwargs):
        config.update(kwargs)

    function_without_define()

    assert config == {}

    @overload_configuration
    def function_with_define(define, **kwargs):
        assert define == ["key1=value1", "keÿ2= value2"]
        config.update(kwargs)

    function_with_define(define=["key1=value1", "keÿ2= value2"])

    assert config == {"key1": "value1", "keÿ2": " value2"}



# Generated at 2022-06-21 21:08:53.643634
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Invalid config
    config["changelog_components"] = "foo"
    try:
        current_changelog_components()
        assert False
    except ImproperConfigurationError:
        assert True

    # Valid config
    config["changelog_components"] = "semantic_release.changelog_components.compare_link"
    current_changelog_components()

    # Config is a comma-separated list
    config["changelog_components"] = "semantic_release.changelog_components.compare_link,semantic_release.changelog_components.issue_link"
    current_changelog_components()

# Generated at 2022-06-21 21:08:59.791410
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the current_commit_parser function"""
    from .commit_parser import no_pypi_releases_parser
    from .errors import ImproperConfigurationError

    # Test case 1: no config["commit_parser"]
    assert current_commit_parser() == no_pypi_releases_parser

    # Test case 2: config["commit_parser"] is a bad string
    config["commit_parser"] = "no_such_module.no_such_function"
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()

    # Test case 3: config["commit_parser"] is a good string
    config["commit_parser"] = "semantic_release.commit_parser.no_pypi_releases_parser"
    assert current_commit_parser() == no_pypi_releases

# Generated at 2022-06-21 21:09:03.748869
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    parser = current_changelog_components()
    import pprint
    pprint.pprint(parser)
    assert parser[0] == semantic_release.changelog.log_commit



# Generated at 2022-06-21 21:09:10.334076
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    from .changelog import issue_numbers
    from .changelog import breaking_change_message

    from semantic_release.changelog import components
    expected_components = components + [issue_numbers, breaking_change_message]

    config["changelog_components"] = (
        "semantic_release.changelog.components,"
        "semantic_release.changelog.issue_numbers,"
        "semantic_release.changelog.breaking_change_message"
    )
    assert set(current_changelog_components()) == set(expected_components)

# Generated at 2022-06-21 21:09:13.832065
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components as changelog_components

    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == changelog_components.get_commits_list
    assert components[1] == changelog_components.get_compare_url

# Generated at 2022-06-21 21:09:15.912095
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "parse_commits"


# Unit tests for function current_changelog_components

# Generated at 2022-06-21 21:09:22.431030
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import commit_link, commit_message, commit_author

    assert callable(current_changelog_components()[0])
    assert current_changelog_components() == [
        commit_link,
        commit_message,
        commit_author,
    ]



# Generated at 2022-06-21 21:09:25.103419
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.ChangelogEntry"
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-21 21:09:35.417491
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Case 1: proper components are specified
    config["changelog_components"] = "date,latest_tag,changelog_entry,body"
    assert current_changelog_components() == [
        date,
        latest_tag,
        changelog_entry,
        body,
    ]

    # Case 2: proper components are specified with whitespace
    config["changelog_components"] = "date, latest_tag,changelog_entry, body"
    assert current_changelog_components() == [
        date,
        latest_tag,
        changelog_entry,
        body,
    ]

    # Case 3: no components are specified
    config["changelog_components"] = ""
    assert current_changelog_components() == []

    # Case 4: one component

# Generated at 2022-06-21 21:09:38.297653
# Unit test for function overload_configuration
def test_overload_configuration():
    def get_config():
        return config["custom_key"]

    new_get_config = overload_configuration(get_config)

    new_get_config(version="1.2.3", define=["custom_key=custom_value"])
    assert config["custom_key"] == "custom_value"
    assert get_config() == "custom_value"
    assert new_get_config() == "custom_value"

# Generated at 2022-06-21 21:09:48.475573
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:09:55.635501
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This test unit verifies that "overload_configuration" function retrieves
    the content of "define" and assigns the values defined in it to the
    module config.
    """

    import unittest
    import tempfile

    from semantic_release.cli import main as cli
    from semantic_release.settings import config

    class ConfigTest(unittest.TestCase):
        def test_overload_configuration(self):
            with config.unlocked:
                access_token = "abcdefghijklmnopqrstuvwxyz1234567890"
                config["access_token"] = access_token  # Set the config

            # To execute the command, create a temporary file containing
            # the "message", save it and pass its path as a parameter