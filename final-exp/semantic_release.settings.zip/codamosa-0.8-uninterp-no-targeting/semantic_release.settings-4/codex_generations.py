

# Generated at 2022-06-21 21:00:16.311283
# Unit test for function current_commit_parser
def test_current_commit_parser():

    # Check both cases when the parser is not set and when it is
    config["commit_parser"] = None

    # Import the default parser
    from semantic_release.commit_parser import default

    assert current_commit_parser() == default
    assert current_commit_parser() != None

    # Import a different parser and check that it's in charge
    from semantic_release.commit_parser.example import parser

    config["commit_parser"] = "semantic_release.commit_parser.example.parser"

    assert current_commit_parser() == parser
    assert current_commit_parser() != default

# Generated at 2022-06-21 21:00:21.315483
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def example_function(*args, **kwargs):
        return kwargs

    # Example where "define" is not set
    assert example_function() == {}

    # Example where "define" is set
    assert example_function(define=["a=b", "c=d"]) == {
        "define": ["a=b", "c=d"]}

# Generated at 2022-06-21 21:00:23.603591
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        assert config["test"] == "test"
    test_func(define=["test=test"])



# Generated at 2022-06-21 21:00:33.280848
# Unit test for function overload_configuration
def test_overload_configuration():
    original_config = config.copy()
    result = {
        "changelog_capitalize": True,
        "changelog_scope": True,
        "check_build_status": True,
        "commit_version_number": True,
        "patch_without_tag": True,
        "major_on_zero": True,
        "remove_dist": True,
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert overload_configuration(config.update)(define=result.keys())
    assert config == {**original_config, **result}

# Generated at 2022-06-21 21:00:40.547408
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = current_commit_parser()
    assert callable(commit_parser)

    # This is the default parser in case of absence of this value in setup.cfg
    assert commit_parser.__name__ == "parse_commits"

# Generated at 2022-06-21 21:00:43.902051
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.hooks import build_commit_message

    config["commit_parser"] = "semantic_release.commit_parser.build_commit_message"
    assert current_commit_parser() == build_commit_message



# Generated at 2022-06-21 21:00:45.480886
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse

    assert current_commit_parser() == parse



# Generated at 2022-06-21 21:00:46.386556
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:00:47.772128
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:00:48.555040
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:00:59.341671
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(url=None):
        return url

    assert test_func() is None
    assert test_func(url="test.com") == "test.com"
    assert test_func(define=["url=test.org"]) == "test.org"

# Generated at 2022-06-21 21:01:01.270384
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def foo(bar, define=None):
        return config[bar]

    assert foo("hello", define=["hello=world"]) == "world"

# Generated at 2022-06-21 21:01:06.117616
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import ChangelogGenerator, SectionGenerator

    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == ChangelogGenerator
    assert components[1] == SectionGenerator

# Generated at 2022-06-21 21:01:11.871630
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_entry_hook as default_changelog_entry_hook
    from semantic_release.changelog import changelog_section_hook as default_changelog_section_hook

    assert (
        current_changelog_components()
        == [default_changelog_entry_hook, default_changelog_section_hook]
    )

# Generated at 2022-06-21 21:01:12.745112
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """

    """
    assert current_commit_parser()

# Generated at 2022-06-21 21:01:19.960574
# Unit test for function overload_configuration
def test_overload_configuration():
    config["define"] = "DUMMY_VARIABLE=DUMMY_VALUE"

    @overload_configuration
    def dummy_function(param1, define=[]):
        return param1

    assert dummy_function(param1="value", define=["example_var=example_value"]) == "value"
    assert config["example_var"] == "example_value"

# Generated at 2022-06-21 21:01:21.854253
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components()[0]() == 'This release contains the following changes:'

# Generated at 2022-06-21 21:01:24.313369
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components
    assert current_changelog_components() == get_changelog_components()
    assert current_changelog_components() != [str]

# Generated at 2022-06-21 21:01:30.039461
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import get_config

    config_old = dict(config)
    get_config(args=["--define", "ci_build=1"])
    assert config_old != dict(config)
    assert config["ci_build"] == "1"
    config.update(config_old)

# Generated at 2022-06-21 21:01:33.438509
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.test.test_utils.test_component"

    assert current_changelog_components()[0] == test_component



# Generated at 2022-06-21 21:01:45.499369
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "testvalue"
    assert config["test"] == "testvalue"
    @overload_configuration
    def test(**define):
        return True
    test(define=["test=testvalueoverloaded"])
    assert config["test"] == "testvalueoverloaded"

# Generated at 2022-06-21 21:01:48.903424
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.component1,semantic_release.changelog_components.component2"
    assert len(current_changelog_components()) == 2

    config["changelog_components"] = ""
    assert len(current_changelog_components()) == 0

# Generated at 2022-06-21 21:01:58.129964
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def test1():
        pass

    def test2():
        pass
    
    def test3():
        pass

    config['commit_parser'] = "tests.tests.test1"
    assert current_commit_parser() == test1
    config['commit_parser'] = "tests.tests.test2"
    assert current_commit_parser() == test2
    config['commit_parser'] = "tests.tests.test3"
    assert current_commit_parser() == test3
    config['commit_parser'] = "tests.tests.test4"
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-21 21:01:59.492749
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:02:04.916999
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Write sample config file
    with open("setup.cfg", "w") as f:
        f.write("[semantic_release]\n")
        f.write("commit_parser = semantic_release.parse_commits.today_parser\n")
    from semantic_release.parse_commits import today_parser

    def today_parser():
        return None, None

    commit_parser = current_commit_parser()
    assert commit_parser == today_parser

    # Remove setup.cfg file
    os.remove("setup.cfg")


# Generated at 2022-06-21 21:02:07.788812
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""
    components = current_changelog_components()
    assert len(components) == 2

# Generated at 2022-06-21 21:02:14.672615
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components

    test_components = ["semantic_release.changelog.fixed_issues_component"]
    config["changelog_components"] = test_components
    assert len(changelog_components) == len(test_components), "Expected same length"
    assert changelog_components[0].__name__ == "fixed_issues_component"

# Generated at 2022-06-21 21:02:22.506252
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def echo_configuration_value(key):
        return config[key]

    # Just to make sure the config is not clobbered by the tests
    assert echo_configuration_value("remote_repo")

    assert "test" == echo_configuration_value("test", define=["test=test"])
    assert "test" == echo_configuration_value("test")
    assert None is echo_configuration_value("test", define=["test"])
    assert "test" == echo_configuration_value("test", define=["test=test", "test"])



# Generated at 2022-06-21 21:02:27.376780
# Unit test for function overload_configuration
def test_overload_configuration():
    """
        >>> @overload_configuration
        ... def test(x):
        ...     print(x)
        ...
        >>> test("this is a test", define=['git_commit_sha=abcd'])
        this is a test
        >>> config['git_commit_sha']
        'abcd'
        >>>
    """

# Generated at 2022-06-21 21:02:33.956194
# Unit test for function overload_configuration
def test_overload_configuration():
    from unittest.mock import patch

    @overload_configuration
    def fake_function(result, define=None):
        return result

    with patch("semantic_release.settings.config") as config_mock:
        for key, value in {"key1": "value1", "key2": "value2"}.items():
            fake_function("unit_test", define=[f"{key}={value}"])
            config_mock.__setitem__.assert_called_with(
                key, value,
            )

    assert fake_function("unit_test") == "unit_test"

# Generated at 2022-06-21 21:02:47.328633
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    assert config["foo"] == "bar"
    assert config.get("bar") is None

    @overload_configuration
    def set_config(define=None, **kwargs):
        pass

    set_config(define=["foo=baz", "bar=taz"])

    assert config["foo"] == "baz"
    assert config["bar"] == "taz"



# Generated at 2022-06-21 21:02:52.658249
# Unit test for function current_commit_parser
def test_current_commit_parser():
    def assert_current_commit_parser_returns_fixture_parser(tmpdir):
        # given
        setup_cfg = """[semantic_release]
commit_parser=semantic_release.tests.fixtures.commit_parser"""
        setup_cfg_file = tmpdir.join("setup.cfg")
        setup_cfg_file.write(setup_cfg)
        # when
        parser = current_commit_parser()
        # then
        assert parser.__name__ == "commit_parser"



# Generated at 2022-06-21 21:02:55.164131
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test if the current commit parser is being correctly imported"""
    from .commit_parser import parse_commit_message

    assert current_commit_parser() == parse_commit_message


# Generated at 2022-06-21 21:03:06.146614
# Unit test for function overload_configuration
def test_overload_configuration():
    class Dummy:
        @overload_configuration
        def __init__(self, a=1):
            self.a = a
    d = Dummy()
    assert d.a == 1
    d = Dummy(define=["a=2"])
    assert d.a == 2
    # Defining a=1 again should not change anything
    d = Dummy(define=["a=1"])
    assert d.a == 2
    # Defining a=2 again should not change anything
    d = Dummy(define=["a=2"])
    assert d.a == 2
    # Defining b=3 should raise a KeyError
    try:
        Dummy(define=["b=3"])
    except KeyError:
        pass

# Generated at 2022-06-21 21:03:06.725439
# Unit test for function current_commit_parser
def test_current_commit_parser():
    return

# Generated at 2022-06-21 21:03:11.228230
# Unit test for function overload_configuration
def test_overload_configuration():
    def get_config(value: str) -> str:
        return config.get(value)

    get_config_overloaded = overload_configuration(get_config)
    assert get_config_overloaded("python_version") == "3.5"
    assert get_config_overloaded("python_version", define=["python_version=7"]) == "7"



# Generated at 2022-06-21 21:03:14.095662
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = "semantic_release.changelog.format_changelog"
    components = current_changelog_components()
    assert components[0].__name__ == "format_changelog"

# Generated at 2022-06-21 21:03:19.449996
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.settings import config as sut_config
    from semantic_release.settings import current_changelog_components as sut

    config = {
        "changelog_components": "semantic_release.changelog_components.title,semantic_release.changelog_components.body"
    }
    sut_config.update(config)

    assert len(sut()) == 2

    sut_config.clear()

# Generated at 2022-06-21 21:03:24.836550
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test if correct changelog_components are being used
    parser = current_changelog_components()
    assert parser[0].__name__ == "changelog_version"
    assert parser[1].__name__ == "changelog_summary"
    assert parser[2].__name__ == "changelog_body"
    assert parser[3].__name__ == "changelog_footer"



# Generated at 2022-06-21 21:03:29.808197
# Unit test for function current_changelog_components
def test_current_changelog_components():
    def component_func():
        pass

    def component_func2():
        pass

    expected_components = [component_func, component_func2]

    component_paths = "tests.fixtures.component_func,tests.fixtures.component_func2"
    assert (
        current_changelog_components() == expected_components
    ), "current_changelog_components failed"

# Generated at 2022-06-21 21:03:43.326389
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components
    """
    from .changelog import (
        CommitsListProcessor,
        IssueReferencesExtractor,
        IssueReferencesLinker,
        MergeReferencesExtractor,
        MergeReferencesLinker,
        WriteChangelogEntry,
    )

    components = current_changelog_components()
    assert components == [
        CommitsListProcessor,
        IssueReferencesExtractor,
        IssueReferencesLinker,
        MergeReferencesExtractor,
        MergeReferencesLinker,
        WriteChangelogEntry,
    ]

# Generated at 2022-06-21 21:03:45.009817
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None


# Generated at 2022-06-21 21:03:52.662932
# Unit test for function overload_configuration
def test_overload_configuration():
    from .main import release
    import click

    @click.command()
    @click.argument("define", type=str, nargs=-1)  # pylint: disable=unused-argument
    @overload_configuration
    def function(define):
        """Function to test overload_configuration"""

        @click.command()
        @click.option("--option", default=config.get("option"), show_default=True)
        def test(option):
            """Test function with option that uses config.get()"""
            click.echo(option)

    # Old value
    assert config.get("option") == "False"
    # Test with new value
    function(define=["option=True"])
    assert config.get("option") == "True"

    # Test output with new value

# Generated at 2022-06-21 21:03:54.796334
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser
    assert current_commit_parser() == semantic_release.commit_parser.parse_message

# Generated at 2022-06-21 21:04:04.229323
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the overload_configuration decorator.
    """

    @overload_configuration
    def test_func(define=None):
        return True

    test_func()
    assert config == _config()

    test_func(define=["foo=bar"])
    assert config.get("foo") == "bar"

    test_func(define=["foo"])
    assert config.get("foo") == "bar"

    test_func(define=["foo="])
    assert config.get("foo") == ""

    test_func(define=["foo", "bar"])
    assert config.get("foo") == ""
    assert config.get("bar") is None

# Generated at 2022-06-21 21:04:11.416043
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

    @overload_configuration
    def dummy_function(a, c, b, define = None):
        pass

    assert dummy_function(1, 2, 3, None) is None
    assert config == {"changelog_components": "",
                      "changelog_capitalize": True,
                      "changelog_scope": True,
                      "commit_parser": "semantic_release.commit_parser:CommitParser",
                      "check_build_status": True,
                      "commit_version_number": True,
                      "patch_without_tag": True,
                      "major_on_zero": True,
                      "remove_dist": False,
                      "upload_to_pypi": True,
                      "upload_to_release": True,
                      }


# Generated at 2022-06-21 21:04:15.342289
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(define):
        return define
    assert foo(define=["key=value"]) == ["key=value"]
    assert "key" in config
    assert config["key"] == "value"

# Generated at 2022-06-21 21:04:18.147049
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commits import parse_commit_message

    assert current_commit_parser() == parse_commit_message

# Generated at 2022-06-21 21:04:21.066568
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import parse_components

    changelog_components = current_changelog_components()

    for c in changelog_components:
        assert c in parse_components

# Generated at 2022-06-21 21:04:23.169122
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser:Mock"
    assert current_commit_parser() == "Mock"

# Generated at 2022-06-21 21:04:49.704328
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the behavior of the overload_configuration decorator.

    This decorator is used to set a configuration value with a custom value
    provided by the user. In that way, the user can overwrite the value read
    in setup.cfg (or pyproject.toml).
    """
    global config

    @overload_configuration
    def f(define):
        return config


# Generated at 2022-06-21 21:04:55.061825
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog_components as semantic_release_changelog_components
    config["changelog_components"] = (
        "semantic_release.changelog_components.changelog_body,"
        "semantic_release.changelog_components.assignee"
    )
    assert (
        current_changelog_components()
        == [
            semantic_release_changelog_components.changelog_body,
            semantic_release_changelog_components.assignee,
        ]
    )

# Generated at 2022-06-21 21:04:56.649456
# Unit test for function current_commit_parser
def test_current_commit_parser():
    result = current_commit_parser()
    assert result is not None

# Generated at 2022-06-21 21:05:00.469438
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == "changelog_render"

# Unit tests for function current_commit_parser

# Generated at 2022-06-21 21:05:09.849374
# Unit test for function overload_configuration
def test_overload_configuration():
    from .environment import get_project_name
    from .version import get_next_version

    name = get_project_name()

    assert name == "semantic_release"

    release_types = {
        "major": {"name": "semantic_release"},
        "minor": {"name": "semantic-release"},
        "patch": {"name": "semantic_release", "version": "0.0.1"},
    }

    for release_type, params in release_types.items():
        assert get_next_version(release_type, **params) == "0.0.1"

    @overload_configuration
    def test_overload(release_type, **kwargs):
        return get_next_version(release_type, **kwargs)


# Generated at 2022-06-21 21:05:15.978008
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Return the currently-configured changelog components
    """
    parts = config.get("changelog_components").split(",")
    module = ".".join(parts[:-1])
    components = getattr(importlib.import_module(module), parts[-1])
    print(components)

# Generated at 2022-06-21 21:05:17.078905
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:05:18.264196
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:05:20.573773
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        _ = current_commit_parser()
    except ImproperConfigurationError:
        return True
    return False

# Generated at 2022-06-21 21:05:22.618472
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test if current_commit_parser returns expected value."""
    from semantic_release.commit_parser import parse
    assert current_commit_parser() == parse


# Generated at 2022-06-21 21:05:41.673399
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Import the current commit parser
    commit_parser = current_commit_parser()
    assert callable(commit_parser)
    assert commit_parser



# Generated at 2022-06-21 21:05:48.715502
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Unit test for function current_changelog_components
    # GIVEN a changelog_components option set to a single value that is a valid configuration
    config["changelog_components"] = "semantic_release.changelog_components.get_unreleased_changes"
    # WHEN current_changelog_components is called
    # THEN the current changelog_components is the expected one
    assert len(current_changelog_components()) == 1
    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "get_unreleased_changes"



# Generated at 2022-06-21 21:05:56.177303
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    config["test_key"] = "test_before"
    assert test_func(define=["test_key=test_after"]) == "test_after"
    assert config["test_key"] == "test_after"
    assert test_func(define=["test_key=test_after"]) == "test_after"
    assert config["test_key"] == "test_after"

    config.pop("test_key")

# Generated at 2022-06-21 21:05:59.714497
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "old value"
    @overload_configuration
    def myFunction(**kwargs):
        return config["test"]

    result = myFunction()
    assert result == "old value"
    result = myFunction(define=["test=new value"])
    assert result == "new value"
    result = myFunction()
    assert result == "new value"

# Generated at 2022-06-21 21:06:11.644794
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.shell import main as cli_main

    @overload_configuration
    def main(**kwargs):
        return config

    new_config = main(define=["tag_format=v{version}"])
    assert new_config["tag_format"] == "v{version}"

    new_config = main(define=["changelog_components=semantic_release.git_changelog.get_changelog", "tag_format=v{version}"])
    assert new_config["changelog_components"] == "semantic_release.git_changelog.get_changelog"
    assert new_config["tag_format"] == "v{version}"

    new_config = cli_main(["--define", "tag_format=v{version}"])
    assert new

# Generated at 2022-06-21 21:06:15.864095
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define=None):
        pass
    test_function(define=["test_key=value_overloaded"])
    assert config["test_key"] == "value_overloaded"

# Generated at 2022-06-21 21:06:20.224475
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    The default commit_parser should be semantic_release.hvcs.git.
    """
    assert current_commit_parser().__name__ == "parse_commits"



# Generated at 2022-06-21 21:06:26.683813
# Unit test for function overload_configuration
def test_overload_configuration():
    os.environ["TEST_OVERLOAD_CONFIGURATION"] = "hello"
    config["hello"] = "world"

    @overload_configuration
    def printconfig(conf):
        return config[conf]

    assert printconfig(conf="hello") == "world"
    assert printconfig(define=["hello=overload"]) == "overload"
    assert printconfig(conf="hello") == "overload"
    assert printconfig(define=["hello=${TEST_OVERLOAD_CONFIGURATION}"]) == "hello"
    assert printconfig(conf="hello") == "hello"

# Generated at 2022-06-21 21:06:32.490402
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from . import changelog

    component_paths = config.get("changelog_components").split(",")
    components = current_changelog_components()

    assert len(component_paths) == len(components)
    assert component_paths == [component.__module__ + "." + component.__name__ for component in components]

# Generated at 2022-06-21 21:06:34.505026
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.parser import parse_message

    assert current_commit_parser() == parse_message


# Generated at 2022-06-21 21:06:52.994849
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import always_semantic

    assert current_commit_parser() == always_semantic

# Generated at 2022-06-21 21:07:03.639219
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test1"] = "original value"
    config["test2"] = "original value"
    config["test3"] = "original value"
    config["test4"] = "original value"
    config["test5"] = "original value"
    config["test6"] = "original value"
    tmp_config = config.copy()

    def no_overload(*args, **kwargs):
        return True

    @overload_configuration
    def standard_overload(*args, **kwargs):
        return True

    standard_overload()
    assert tmp_config == config, "config should not be edited in no overload function"

    overload1 = standard_overload(define=["test1=new value"])
    assert config["test1"] == "new value", "config should be edited by overload function"


# Generated at 2022-06-21 21:07:06.513396
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert callable(parser)
    assert "parser" in vars(parser)



# Generated at 2022-06-21 21:07:16.625257
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Should throw an exception since the parser doesn't exist
    error = False
    try:
        config['changelog_components'] = 'asdf.asdf'
        current_changelog_components()
    except ImproperConfigurationError as e:
        error = True
    assert error

    # Should work
    config['changelog_components'] = 'semantic_release.changelog_components.Changelog'
    assert current_changelog_components() == [semantic_release.changelog_components.Changelog]


# Generated at 2022-06-21 21:07:26.804576
# Unit test for function overload_configuration
def test_overload_configuration():
    os.environ["SR_SOME_PARAM"] = "some_value"
    os.environ["SR_SOME_OTHER_PARAM"] = "some_other_value"
    config["some_param"] = "default_value"
    config["some_other_param"] = "default_other_value"

    @overload_configuration
    def my_function(define):
        pass

    my_function(define=["some_param=new_value"])
    my_function(define=["some_param=${SR_SOME_PARAM}"])
    my_function(define=["some_other_param=new_other_value"])
    my_function(define=["some_other_param=${SR_SOME_OTHER_PARAM}"])


# Generated at 2022-06-21 21:07:31.805822
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "TEST"
    @overload_configuration
    def _test_overload_configuration(define=None):
        assert config["test"] == "TEST-CHANGED"
    _test_overload_configuration(define=["test=TEST-CHANGED"])
    _test_overload_configuration()

# Generated at 2022-06-21 21:07:33.672325
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None



# Generated at 2022-06-21 21:07:35.867625
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components"""
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-21 21:07:42.779562
# Unit test for function overload_configuration
def test_overload_configuration():
    # pylint: disable=unused-variable
    @overload_configuration
    def test_function(define=None):
        pass

    test_function(define=["next_version=2.0", "new_line=bla"])

    # Check if the keys are creted
    assert "next_version" in config.data
    assert "new_line" in config.data

    # Check if the pair is correctly set
    assert config.data["next_version"] == "2.0"
    assert config.data["new_line"] == "bla"



# Generated at 2022-06-21 21:07:45.360604
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config.get("foo")

    assert test_function() is None

    assert test_function(define=["foo=bar"]) == "bar"

    assert test_function() == "bar"

# Generated at 2022-06-21 21:08:06.694719
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.filters.__init__.FileLoader"
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] is not None



# Generated at 2022-06-21 21:08:09.058376
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-21 21:08:11.109897
# Unit test for function current_changelog_components
def test_current_changelog_components():
    try:
        current_changelog_components()
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-21 21:08:21.401021
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test different use cases
    # Define changelog_components in configuration file
    config["changelog_components"] = "semantic_release.changelog.components.issues,semantic_release.changelog.components.diff"
    # Import the component component
    component = "semantic_release.changelog.components.issues"
    component2 = "semantic_release.changelog.components.diff"
    c_list = current_changelog_components()
    component = component.split('.')
    component2 = component2.split('.')
    component = component[-1]
    component2 = component2[-1]
    # Check if component is found in the component list
    assert component in c_list
    assert component2 in c_list
    # Define chang

# Generated at 2022-06-21 21:08:25.130054
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test current_commit_parser"""
    commit_parser: Callable = current_commit_parser()
    # if config.get('commit_parser') is not defined
    assert commit_parser.__name__ == "default_commit_parser"

# Generated at 2022-06-21 21:08:27.109624
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import conventional_commit_parser
    parser = current_commit_parser()
    assert parser == conventional_commit_parser


# Generated at 2022-06-21 21:08:29.650410
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.commit_message_component'
    assert current_changelog_components()[0] == commit_message_component

# Generated at 2022-06-21 21:08:33.772943
# Unit test for function overload_configuration
def test_overload_configuration():
    args = ["test.py"]
    kwargs = {"define": ["key1=value1", "key2=value2"]}
    assert os.path.join(os.path.dirname(__file__), "defaults.cfg") == config["commit_parser"]
    test_funct(*args, **kwargs)
    assert "value1" == config["key1"]
    assert "value2" == config["key2"]



# Generated at 2022-06-21 21:08:36.086482
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import pytest

    with pytest.raises(ImproperConfigurationError):
        current_changelog_components()

# Generated at 2022-06-21 21:08:48.456821
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator works as expected
    """

# Generated at 2022-06-21 21:09:11.132063
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    The function will import and return the function on the configuration
    """
    config["commit_parser"] = "semantic_release.commit_parser.CommitMessage.parse_message"
    assert current_commit_parser() is not None



# Generated at 2022-06-21 21:09:15.511281
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test that current_changelog_components returns a list of component
    functions from the setup.cfg file.
    """
    from semantic_release.changelog import components

    config["changelog_components"] = "semantic_release.changelog.components"
    assert current_changelog_components() == components

# Generated at 2022-06-21 21:09:24.044604
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the function current_changelog_components

    :raises AssertionError: if function current_changelog_components returns an unexpected list
    """
    config["changelog_components"] = (
        "semantic_release.changelog_components.ConventionalCommitComponent"
    )
    changelog_components = current_changelog_components()
    from .changelog import ConventionalCommitComponent

    assert changelog_components == [ConventionalCommitComponent]

# Generated at 2022-06-21 21:09:28.163040
# Unit test for function current_changelog_components
def test_current_changelog_components():

    def test_component():
        return "Test"

    current_commit_parser.__globals__["config"] = {
        "changelog_components": "tests.test_helpers.test_current_changelog_components.test_component"
    }

    assert current_changelog_components() == [test_component]

# Generated at 2022-06-21 21:09:31.673742
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = current_commit_parser()
    commit_message = commit_parser("""feat(parser): Add parser
feat: Add parser
feat(parser) Add parser
feat: Add parser""")
    assert commit_message == "Add parser"


# Generated at 2022-06-21 21:09:35.340926
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == "parse_commit"
    assert components[1].__name__ == "render_components"



# Generated at 2022-06-21 21:09:42.172527
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import (
        changelog_entry,
        changelog_header,
        changelog_message,
        changelog_scope,
        changelog_summary,
        changelog_unreleased_header,
        changelog_version,
    )

    components = current_changelog_components()

    assert len(components) == 7

    assert changelog_entry in components
    assert changelog_header in components
    assert changelog_message in components
    assert changelog_scope in components
    assert changelog_summary in components
    assert changelog_unreleased_header in components
    assert changelog_version in components

# Generated at 2022-06-21 21:09:43.880479
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import parser
    assert current_commit_parser() is parser


# Generated at 2022-06-21 21:09:53.976739
# Unit test for function overload_configuration
def test_overload_configuration():
    """Function to check the overload_configuration decorator"""

    @overload_configuration
    def f(**kwargs):
        """Function to be decorated"""
        return kwargs

    def test_config_not_empty():
        """Check that the configuration is not empty"""
        assert config
        assert f()

    def test_config_overloading():
        """Check the overload of the configuration"""
        config_before = config.copy()
        f(define=["test_config_overloading_1=1", "test_config_overloading_2=2"])
        assert config_before["test_config_overloading_1"] != 1
        assert config_before["test_config_overloading_2"] != 2
        assert config["test_config_overloading_1"] == 1

# Generated at 2022-06-21 21:10:01.163470
# Unit test for function overload_configuration
def test_overload_configuration():
    results = []

    @overload_configuration
    def function(param1, param2, param3):
        results.append(config["param1"])
        results.append(config["param2"])
        results.append(config.get("param3"))

    function(param1="dummy", param2="dummy2", param3="dummy3", define=["param1=dummy"])
    assert results == ["dummy", "dummy2", "dummy3"]