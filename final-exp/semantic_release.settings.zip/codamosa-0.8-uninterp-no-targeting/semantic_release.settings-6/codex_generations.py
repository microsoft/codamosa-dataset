

# Generated at 2022-06-21 21:00:10.362880
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define: list):
        return define

    assert test(["foo=bar"]) == ["foo=bar"]
    assert config["foo"] == "bar"

# Generated at 2022-06-21 21:00:13.543339
# Unit test for function overload_configuration
def test_overload_configuration():
    def test(define=None):
        return config["package_name"]
    decorated = overload_configuration(test)
    assert decorated(define=["package_name=foo"]) == "foo"



# Generated at 2022-06-21 21:00:19.334485
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # GIVEN
    expected = "semantic_release.commit_parser.select_commits"
    config["commit_parser"] = expected

    # WHEN
    commit_parser = current_commit_parser()

    # THEN
    assert (
        commit_parser.__name__ == expected.split(".")[-1]
    ), f"The name of the commit parser `{commit_parser.__name__}` is not the one defined in the configuration `{expected}`"

# Generated at 2022-06-21 21:00:25.859370
# Unit test for function current_commit_parser
def test_current_commit_parser():
    os.environ["SEMANTIC_RELEASE_MOCK_CONFIG_COMMIT_PARSER"] = "semantic_release.commit_parser.default"
    config = _config()
    assert current_commit_parser() == importlib.import_module("semantic_release.commit_parser.default").default
    del os.environ["SEMANTIC_RELEASE_MOCK_CONFIG_COMMIT_PARSER"]


# Generated at 2022-06-21 21:00:34.389818
# Unit test for function current_changelog_components
def test_current_changelog_components():
    #: Add new functions in current_changelog_component() to this array
    current_changelog_component = ["changelog_components"]
    #: Add new functions in current_changelog_components() to this array
    current_changelog_components = ["current_changelog_components"]

    # Test that all functions current_changelog_component() are in current_changelog_components()
    for function_name in current_changelog_component:
        assert function_name in current_changelog_components, \
            "Function {}() is only in current_changelog_component()".format(function_name)

# Generated at 2022-06-21 21:00:38.242846
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    components = current_changelog_components()
    assert len(components) == 3
    expected = [
        semantic_release.changelog.title,
        semantic_release.changelog.description,
        semantic_release.changelog.tag,
    ]
    assert components == expected

# Generated at 2022-06-21 21:00:40.937767
# Unit test for function current_changelog_components
def test_current_changelog_components():
    for function in current_changelog_components():
        assert function.__name__ in ("release_date", "release_author", "release_message")

# Generated at 2022-06-21 21:00:44.644139
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    @overload_configuration
    def foo(bar, define=None):
        """ Do nothing
        """
        return config["foo"]

    res = foo("bar", define=["foo=baz"])
    assert res == "baz"

# Generated at 2022-06-21 21:00:49.088922
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(*args, **kwargs):
        """
        Overload configuration
        :return:
        """

    assert func(define=["foo=bar"]) is None
    assert config["foo"] == "bar"

    config.clear()
    assert func() is None
    assert len(config.keys()) == 0

# Generated at 2022-06-21 21:00:51.339883
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser"""
    test_parser = current_commit_parser()
    assert callable(test_parser)

# Generated at 2022-06-21 21:01:04.149717
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog
    import semantic_release.hooks
    from time import time

    # we need to run this from the root of semantic_release
    os.chdir(os.path.dirname(os.path.dirname(semantic_release.__file__)))

    changelog_components_str = "semantic_release.changelog.IssueChangelog,semantic_release.changelog.CommitChangelog,semantic_release.changelog.TagChangelog"
    config["changelog_components"] = changelog_components_str
    components = current_changelog_components()
    assert isinstance(components, list)

    changelog = get_changelog(components, time())

# Generated at 2022-06-21 21:01:10.048032
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator
    """

    @overload_configuration
    def test_func(define=["name=Yoann"]):
        return define

    assert test_func() == ["name=Yoann"]
    assert config["name"] == "Yoann"
    assert config["commit_parser"] == "semantic_release.commit_parser"

# Generated at 2022-06-21 21:01:14.559264
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release

    config["changelog_components"] = "semantic_release.changelog_components.body,semantic_release.changelog_components.footer"  # noqa: E501
    assert current_changelog_components() == [
        semantic_release.changelog_components.body,
        semantic_release.changelog_components.footer,
    ]

# Generated at 2022-06-21 21:01:22.822951
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.clear()
    config["changelog_components"] = "semantic_release.changelog_components.BreakingChange"
    components = current_changelog_components()
    assert components == [semantic_release.changelog_components.BreakingChange]

    config.clear()
    components = current_changelog_components()
    assert components == [semantic_release.changelog_components.BreakingChange]

    components = current_changelog_components()
    assert components == [semantic_release.changelog_components.BreakingChange]

# Generated at 2022-06-21 21:01:27.182716
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config_components = ['semantic_release.components.commit_parser',
                         'semantic_release.components.changelog']
    config['changelog_components'] = ','.join(config_components)
    components = current_changelog_components()
    assert len(components) == len(config_components)
    for i, component in enumerate(components):
        assert component.__name__ == config_components[i].split(".")[-1]



# Generated at 2022-06-21 21:01:31.306293
# Unit test for function current_changelog_components
def test_current_changelog_components():
    _config()['changelog_components'] = 'semantic_release.changelog_generator.components.unreleased'
    current_changelog_components()

# Generated at 2022-06-21 21:01:42.950251
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

    config["changelog_components"] = (
        "semantic_release.changelog.changelog_components.unreleased_changes"
    )
    result = current_changelog_components()
    assert len(result) == 1
    assert result[0] == unused
    config["changelog_components"] = ""

    config["changelog_components"] = (
        "semantic_release.changelog.changelog_components.unreleased_changes,"
        "semantic_release.changelog.changelog_components.released_changes"
    )
    result = current_changelog_components()
    assert len(result) == 2
    assert result[0] == unused

# Generated at 2022-06-21 21:01:48.008165
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = {"hello": "world"}
    test_args = {}
    test_kwargs = {
        "hello": "second world",
        "define": ["hello=third world", "define=", "define="]
    }
    def test_function(**kwargs):
        return kwargs["hello"]

    test_function = overload_configuration(test_function)

    assert test_function(**test_args) == "world"
    assert test_function(**test_kwargs) == "third world"

# Generated at 2022-06-21 21:01:49.305403
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import CommitMessageChangelog
    assert current_changelog_components() == [CommitMessageChangelog]

# Generated at 2022-06-21 21:01:52.377588
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Get the currently-configured commit parser test
    """
    assert current_commit_parser() == "semantic_release.hvcs.get_default_commit_message"


# Generated at 2022-06-21 21:02:05.551185
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the current changelog components"""
    expected = ("semantic_release.changelog.components.author",
                "semantic_release.changelog.components.title",
                "semantic_release.changelog.components.date",
                "semantic_release.changelog.components.breaking",
                "semantic_release.changelog.components.scope",
                "semantic_release.changelog.components.body")

    for ex, current in zip(expected, current_changelog_components()):
        assert ex == current.__module__+"."+current.__qualname__


# Generated at 2022-06-21 21:02:12.157944
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def get_defined(*args, **kwargs):
        return kwargs

    kwargs = get_defined(define=["test_param=test_value", "test_param2=test_value2"])
    assert(kwargs["test_param"] == "test_value")
    assert(kwargs["test_param2"] == "test_value2")

# Generated at 2022-06-21 21:02:17.484421
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(arg, define=None):
        return config[arg]

    with pytest.raises(ImproperConfigurationError):
        func("commit_parser")

    assert func("commit_parser", ["commit_parser=python_semantic_release.commit_parser:parse_commits"]) == parse_commits

# Generated at 2022-06-21 21:02:22.056565
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function():
        return config.get("test")

    config["test"] = "old_value"
    assert test_function() == config.get("test")
    test_function(define=['test="new_value"'])
    assert config.get("test") == "new_value"

# Generated at 2022-06-21 21:02:32.323362
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from .commit_parser import default_commit_parser

    # default_commit_parser should be returned if no commit parser is
    # configured in the config file
    config.pop("commit_parser")
    assert current_commit_parser() == default_commit_parser

    # Properly configured parser should be returned
    config["commit_parser"] = "semantic_release.commit_parser.my_commit_parser"
    assert current_commit_parser() == my_commit_parser

    # Raise an error if the configured parser is not found or if
    # the configured parser do not have a `parse` method
    config["commit_parser"] = "semantic_release.commit_parser.does_not_exist"

# Generated at 2022-06-21 21:02:37.345198
# Unit test for function current_changelog_components
def test_current_changelog_components():

    from . import changelog
    from . import changelog_common

    components = current_changelog_components()

    assert changelog.changelog_unreleased_section in components
    assert changelog.changelog_released_section in components
    assert changelog.changelog_compare_link in components
    assert changelog.changelog_pull_requests in components
    assert changelog.changelog_compare_link_title in components
    assert changelog.changelog_released_version in components
    assert changelog.changelog_unreleased_version in components
    assert changelog.changelog_unreleased_pull_requests in components
    assert changelog.changelog_released_pull_requests in components
    assert changelog.changelog_

# Generated at 2022-06-21 21:02:37.990039
# Unit test for function current_commit_parser
def test_current_commit_parser():
    pass



# Generated at 2022-06-21 21:02:45.883392
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """ Test the current_commit_parser function.
    It should work when a valid commit parser function is specified in
    setup.cfg and raise a ImproperConfigurationError when an invalid one is.
    """
    from semantic_release.commit_parser.default import parse

    assert current_commit_parser() == parse

    try:
        config["commit_parser"] = "semantic_release.commit_parser.wrong"
        current_commit_parser()
    except ImproperConfigurationError:
        pass
    else:
        raise AssertionError("ImproperConfigurationError was not raised.")



# Generated at 2022-06-21 21:02:47.251733
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert isinstance(current_changelog_components(), list)

# Generated at 2022-06-21 21:02:54.407743
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for the overload_configuration decorator"""
    config_init = config.copy()

    @overload_configuration
    def call_test(a, b, define=None):  # pylint: disable=unused-argument
        return

    # test with define:
    call_test(1, 2, define=["a=1", "b=2"])
    assert config.get("a") == "1"
    assert config.get("b") == "2"

    # test without define:
    config = config_init.copy()

    call_test(1, 2)
    assert config.get("a") == config_init.get("a")
    assert config.get("b") == config_init.get("b")

# Generated at 2022-06-21 21:03:02.078004
# Unit test for function current_changelog_components
def test_current_changelog_components():
    current_changelog_components() == list()

# Generated at 2022-06-21 21:03:07.160758
# Unit test for function current_changelog_components
def test_current_changelog_components():
    old_path = config.get("changelog_components")
    config["changelog_components"] = "semantic_release.changelog_components.extract_ticket_id"
    components = current_changelog_components()
    assert components[0].__name__ == "extract_ticket_id"
    config["changelog_components"] = old_path

# Generated at 2022-06-21 21:03:14.563275
# Unit test for function overload_configuration
def test_overload_configuration():
    # Initialize the config dict
    config["test_param"] = "exemple"

    # fun is the function returned by the decorator overload_configuration
    # that overloads the config dict
    @overload_configuration
    def fun(define):
        return config["test_param"]

    # The dict is still the same
    assert config["test_param"] == "exemple"

    # The define argument has replaced the value of the "test_param" key
    assert fun(define=["test_param=test"]) == "test"

    # The dict has been changed in the function
    assert config["test_param"] == "test"


# Generated at 2022-06-21 21:03:18.349098
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "baz"
    config["bar"] = "baz"

    @overload_configuration
    def f(define=[]):
        return config

    assert f(define=["foo=fooz"]) == {"foo": "fooz", "bar": "baz"}

# Generated at 2022-06-21 21:03:21.270463
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test function current_commit_parser"""
    import semantic_release.commit_parser
    assert current_commit_parser() == semantic_release.commit_parser.parser

# Generated at 2022-06-21 21:03:25.697335
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import components
    c = current_changelog_components()
    assert components.body == c[0]
    assert components.footer == c[1]

# Generated at 2022-06-21 21:03:29.943196
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_overloade_configuration():
        return config

    config["test"] = "initial_value"
    result = test_overloade_configuration(define=["test=overload_value"])
    assert "test" in result
    assert result["test"] == "overload_value"

# Generated at 2022-06-21 21:03:32.860662
# Unit test for function current_commit_parser
def test_current_commit_parser():
    old_parser = config.get("commit_parser")
    config["commit_parser"] = "semantic_release.commit_parser.default"
    try:
        assert callable(current_commit_parser())
    finally:
        config["commit_parser"] = old_parser



# Generated at 2022-06-21 21:03:37.326364
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the current_commit_parser function"""
    from semantic_release.commit_parser import get_message_parser

    assert current_commit_parser() == get_message_parser
    # If commit_parser isn't set in the config, it should return the default
    config["commit_parser"] = ""
    assert current_commit_parser() == get_message_parser



# Generated at 2022-06-21 21:03:42.620624
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def configure(*args, **kwargs):
        return kwargs.get("define")

    assert configure() is None
    assert configure(define=["define"]) == ["define"]
    assert configure(define=["define", "define"]) == ["define", "define"]
    assert configure(define=["one=two"]) == ["one=two"]
    assert configure(define=["one=two", "three=four"]) == ["one=two", "three=four"]

# Generated at 2022-06-21 21:03:52.354785
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """check the validity of this function"""
    components = current_changelog_components()
    assert len(components) == 1
    assert callable(components[0])

# Generated at 2022-06-21 21:03:53.512963
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-21 21:04:03.634424
# Unit test for function current_changelog_components
def test_current_changelog_components():
    overrides = UserDict({"changelog_components": "semantic_release.changelog.components.body"})
    comp = current_changelog_components(overrides)
    assert comp == [
        semantic_release.changelog.components.body
    ]
    overrides["changelog_components"] = "semantic_release.changelog.components.body,semantic_release.changelog.components.footer"
    comp = current_changelog_components(overrides)
    assert comp == [
        semantic_release.changelog.components.body,
        semantic_release.changelog.components.footer
    ]

# Generated at 2022-06-21 21:04:10.026917
# Unit test for function overload_configuration
def test_overload_configuration():
    def overloaded(a, b, c, d, define=None):
        return a, b, c, d, config.get("changelog_scope")

    new_func = overload_configuration(overloaded)
    config.setdefault("changelog_scope", "none")

    assert new_func(1, 2, 3, 4, define=["changelog_scope=minor"]) == (
        1,
        2,
        3,
        4,
        "minor",
    )

# Generated at 2022-06-21 21:04:12.877068
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo_key"] = "initial value"
    assert config["foo_key"] == "initial value"

    @overload_configuration
    def test_function(define):
        pass

    test_function(define=["foo_key=new value", "baz_key=value"])

    assert config["foo_key"] == "new value"
    assert config["baz_key"] == "value"

# Generated at 2022-06-21 21:04:14.030953
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == list()

# Generated at 2022-06-21 21:04:17.684468
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.hvcs.github import parse_commits
    assert current_commit_parser() == parse_commits

# Generated at 2022-06-21 21:04:24.222398
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Given
    config["changelog_components"] = "semantic_release.changelog_components.HISTORY_SECTION,semantic_release.changelog_components.FORWARD_PORT_SECTION"
    # When
    changelog_components = current_changelog_components()
    # Then
    assert len(changelog_components) == 2
    assert changelog_components[0].__name__ == "HISTORY_SECTION"
    assert changelog_components[1].__name__ == "FORWARD_PORT_SECTION"

# Generated at 2022-06-21 21:04:27.874470
# Unit test for function current_commit_parser
def test_current_commit_parser():
    original_config = _config()
    try:
        config["commit_parser"] = 'my.custom_module.my_function'
        assert current_commit_parser() is my_function
    finally:
        config.clear()
        config.update(original_config)



# Generated at 2022-06-21 21:04:35.785179
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    :param define: list of pairs of key/value to edit the "config" dictionary
        with.
    """
    config["key1"] = "value1"

    @overload_configuration
    def test_overload():
        return None

    test_overload(define=["key2=value2"])

    assert config["key1"] == "value1"
    assert config["key2"] == "value2"

# Generated at 2022-06-21 21:04:45.921053
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import VersionGroupingChangelogComponent

    assert type(current_changelog_components()[0]) == VersionGroupingChangelogComponent



# Generated at 2022-06-21 21:04:51.410416
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.hvcs
    import semantic_release.changelog

    changelog_components = current_changelog_components()

    assert changelog_components[0] == semantic_release.hvcs.get_commits
    assert changelog_components[1] == semantic_release.changelog.get_changes



# Generated at 2022-06-21 21:04:55.928016
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert (
        current_commit_parser()
        == "semantic_release.commit_parser.parse_commit_message"
    )

# Generated at 2022-06-21 21:04:57.259015
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-21 21:04:59.044627
# Unit test for function current_commit_parser
def test_current_commit_parser():
    commit_parser = current_commit_parser()
    assert callable(commit_parser)

# Generated at 2022-06-21 21:05:01.055069
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test function current_commit_parser"""
    from semantic_release import get_parser

    get_parser()

# Generated at 2022-06-21 21:05:03.928841
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test function current_commit_parser"""
    assert config["commit_parser"]==current_commit_parser()


# Generated at 2022-06-21 21:05:05.317480
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """We use a different config file that doesn't contain the
    "changelog_components" key.
    """
    global config
    config = {"changelog_components": "tests.config_tests"}

# Generated at 2022-06-21 21:05:09.344044
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components:current_version,components:other"

    # Check that the function is found
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == current_version
    assert components[1] == other



# Generated at 2022-06-21 21:05:16.143024
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # TODO: This test is bad.  The only possible implementation of 
    # current_commit_parser is a method on the config object.  We can't
    # mock the config object if it is created in the global scope.
    config.get = lambda *args: "semantic_release.commit_parser.default"
    parsed = current_commit_parser()

    assert parsed



# Generated at 2022-06-21 21:05:27.839368
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        "semantic_release.changelogs.bitbucket.components:Commit",
        "semantic_release.changelogs.bitbucket.components:Merge",
    ]

# Generated at 2022-06-21 21:05:33.781181
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        current_tag_name,
        next_version,
        previous_tag_name,
    )
    config["changelog_components"] = (
        "semantic_release.changelog.current_tag_name, "
        "semantic_release.changelog.previous_tag_name, "
        "semantic_release.changelog.next_version"
    )

    assert current_changelog_components() == [
        current_tag_name,
        previous_tag_name,
        next_version,
    ]


# Generated at 2022-06-21 21:05:40.414010
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser as parser

    # When the config is correct
    config["commit_parser"] = "semantic_release.commit_parser:parse_commit"
    assert current_commit_parser() == parser.parse_commit

    # When the config is wrong
    config["commit_parser"] = "foo.bar"
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        pass



# Generated at 2022-06-21 21:05:43.976231
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def call(*args, **kwargs):
        return kwargs

    assert call(define=["key=value"]) == {'define': ['key=value']}
    assert config["key"] == "value"

# Generated at 2022-06-21 21:05:50.186695
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def mytest_func(arg1, arg2, define=None):
        return (arg1, arg2, config)

    mytest_func("a", "b", define=["a=b"])
    assert config["a"] == "b"

    mytest_func("a", "b", define=["a=b", "c=d"])
    assert config["c"] == "d"

# Generated at 2022-06-21 21:05:53.031133
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.pull_requests,
        semantic_release.changelog.components.rewrite
    ]

# Generated at 2022-06-21 21:05:57.358780
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def call(param, define=None):
        return config[param]

    # applying definings
    call("foo", define=["foo=bar"])
    assert config["foo"] == "bar"

    # disabling definings
    call("foo", define=None)
    assert config["foo"] == "bar"

# Generated at 2022-06-21 21:06:01.722477
# Unit test for function overload_configuration
def test_overload_configuration():
    """This tests the overload_configuration decorator."""

    config["define"] = None
    assert config["define"] is not None

    @overload_configuration
    def overload():
        return config["define"]

    assert overload(define=["foo=bar"]) == "bar"

# Generated at 2022-06-21 21:06:05.404412
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog_generator import (
        changelog_components,
    )
    assert current_changelog_components() == changelog_components

# Generated at 2022-06-21 21:06:07.603727
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert "parse" in parser.__name__



# Generated at 2022-06-21 21:06:21.326360
# Unit test for function overload_configuration
def test_overload_configuration():
    config["token"] = "token"
    @overload_configuration
    def test_func(**kwargs):
        assert config["token"] == "token"

    test_func(define=["token=TOKEN"])
    assert config["token"] == "TOKEN"

# Generated at 2022-06-21 21:06:26.184648
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define=None, *args, **kwargs):
        pass
    os.environ["GITHUB_TOKEN"] = "token"
    func(define=["github_token=env"])
    assert config.get("github_token") == "token"
    func(define=["github_token=newToken"])
    assert config.get("github_token") == "newToken"

# Generated at 2022-06-21 21:06:26.895259
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:06:29.300028
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.utils.commit_parser"
    assert callable(current_commit_parser())

# Generated at 2022-06-21 21:06:33.638830
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.title,
        semantic_release.changelog.pull_request,
        semantic_release.changelog.issues,
    ]

# Generated at 2022-06-21 21:06:35.004121
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert hasattr(current_changelog_components(), "__len__")

# Generated at 2022-06-21 21:06:41.252853
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test will take the input argument "-D version_level=major"
    and will edit the "config" global var to replace the value of
    "version_level" by "major".
    """
    global config
    config = {}
    config["version_level"] = "patch"
    assert config["version_level"] == "patch"

    @overload_configuration
    def function(*args, **kwargs):
        return

    function(define=["version_level=major"])
    assert config["version_level"] == "major"


if __name__ == "__main__":
    test_overload_configuration()

# Generated at 2022-06-21 21:06:52.667685
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test for function current_changelog_components"""
    from semantic_release import _components as default_components
    from semantic_release.changelog import changelog_components
    from semantic_release.changelog import UnreleasedNotes
    from tests.components import TestComponent

    # Default config
    current_components = current_changelog_components()

    assert len(current_components) == len(default_components)
    assert current_components == changelog_components

    # Custom config

# Generated at 2022-06-21 21:06:58.793506
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Overwrite config
    config['commit_parser'] = "semantic_release.commit_parser.RegexCommitParser"
    parser = current_commit_parser()
    assert parser.__name__ == "RegexCommitParser"
    # Re-instantiate config
    config.clear()
    for k in _config():
        config[k] = _config()[k]


# Generated at 2022-06-21 21:07:01.030918
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.get = lambda key: "changelog.changelog_components"
    assert current_changelog_components()


# Generated at 2022-06-21 21:07:18.599064
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function_overloaded(x, y, define=None):
        return x + y

    config["test_key"] = "test_value"
    assert "test_key" in config
    assert config["test_key"] == "test_value"

    assert function_overloaded(2, 3) == 5
    assert function_overloaded(2, 3, define=["test_key=overloaded_value"]) == 5
    assert "test_key" in config
    assert config["test_key"] == "overloaded_value"
    assert function_overloaded(2, 3) == 5

# Generated at 2022-06-21 21:07:22.747081
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()
    assert callable(current_commit_parser())
    # Test wrong config
    config["commit_parser"] = "some.wrong.config"
    # Should raise a exception
    try:
        current_commit_parser()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-21 21:07:24.105057
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) >= 0

# Generated at 2022-06-21 21:07:25.009567
# Unit test for function current_commit_parser
def test_current_commit_parser():
    current_commit_parser()

# Generated at 2022-06-21 21:07:35.738076
# Unit test for function overload_configuration
def test_overload_configuration():
    return

    # test with invalid option
    @overload_configuration
    def fake_function(**kwargs):
        return kwargs["define"]

    fake_function(define=["test1=val1", "invalid_option", "test2=val2"])
    assert config["test1"] == "val1"
    assert config["test2"] == "val2"

    # test with valid option
    del config["test1"]
    del config["test2"]

    @overload_configuration
    def fake_function(**kwargs):
        return kwargs["define"]

    fake_function(define=["test1=val1", "test2=val2"])
    assert config["test1"] == "val1"
    assert config["test2"] == "val2"

# Generated at 2022-06-21 21:07:37.978117
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release import get_commit_parser
    assert current_commit_parser() == get_commit_parser()



# Generated at 2022-06-21 21:07:44.593640
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    This method test the current_changelog_components from configuration.py
    """
    from .changelog import current_changelog_components

    assert "utils.changelog.changelog_trivial" in config.get(
        "changelog_components"
    ), "changelog_component not in config"

    assert (
        "utils.changelog.changelog_trivial"
        in str(current_changelog_components())
    ), "changelog_component not in changelog_components"



# Generated at 2022-06-21 21:07:56.443362
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser as commit_parser

    config["commit_parser"] = "semantic_release.commit_parser"
    parser = current_commit_parser()
    assert parser == commit_parser.parse_message
    assert parser.__name__ == "parse_message"

    config["commit_parser"] = "semantic_release.commit_parser:parse_message"
    parser = current_commit_parser()
    assert parser == commit_parser.parse_message
    assert parser.__name__ == "parse_message"

    config["commit_parser"] = "semantic_release.commit_parser:parse_message"
    parser = current_commit_parser()
    assert parser == commit_parser.parse_message
    assert parser.__name__ == "parse_message"


# Generated at 2022-06-21 21:07:59.340798
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import create_header

    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == "create_header"



# Generated at 2022-06-21 21:08:02.403521
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """
    Test function current_commit_parser
    """
    from semantic_release.commit_parser import parse

    config["commit_parser"] = "semantic_release.commit_parser.parse"
    assert current_commit_parser() == parse

# Generated at 2022-06-21 21:08:12.320282
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-21 21:08:15.093221
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == 'components'

# Generated at 2022-06-21 21:08:25.089151
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test that the current_commit_parser function returns the correct parser.
    """
    import semantic_release.commit_parser

    # current_commit_parser is by default the default commit parser
    default_parser = current_commit_parser()
    assert default_parser == semantic_release.commit_parser.default

    # current_commit_parser is the custom commit parser if set in config
    custom_parser_str = "semantic_release.custom_parser.my_cool_custom_parser"

    with overload_configuration():
        config["commit_parser"] = custom_parser_str
        custom_parser = current_commit_parser()
    importlib.reload(semantic_release.custom_parser)
    from semantic_release.custom_parser import my_cool_custom_parser

    assert custom_parser == my_cool_custom_parser


# Generated at 2022-06-21 21:08:31.906920
# Unit test for function overload_configuration
def test_overload_configuration():
    config['config_value'] = 1
    config['other_config_value'] = 2

    def func_to_wrap(define=None):
        return config['config_value'] + config['other_config_value']

    wrapped_function = overload_configuration(func_to_wrap)

    # Check if the values are correctly set in config
    # and that the value of "func_to_wrap" is correctly set
    assert wrapped_function() == 3
    assert config['config_value'] == 1
    assert config['other_config_value'] == 2

    # Check that the function returns the value defined in the array
    wrapped_function(define=['config_value=10', 'other_config_value=20'])
    assert config['config_value'] == 10
    assert config['other_config_value'] == 20

    # Check

# Generated at 2022-06-21 21:08:34.081477
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test `current_commit_parser` function with a custom parser.

    :return: None
    """

    assert current_commit_parser() is current_commit_parser()
    assert current_commit_parser().__name__ == "parser"



# Generated at 2022-06-21 21:08:38.529147
# Unit test for function overload_configuration
def test_overload_configuration():
    """ Test the decorator overload_configuration with 2 differents scenerios.
    First, the config is supposed to be correct. The keys in "define" have to
    have a pair, and the values are supposed to be correct.
    Second, the config is supposed to be wrong, one of the key in "define" does
    not have a pair. The function raise an error.
    """

    @overload_configuration
    def func(a, define):
        return a * 2

    assert func(1, ["test=foo"]) == 2
    try:
        func(1, ["test"])
    except ImproperConfigurationError as error:
        assert error.args[0] == "Missing argument '='"
    else:
        raise AssertionError("The argument 'test' should be an error.")

# Generated at 2022-06-21 21:08:48.133618
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.history import parse_commit
    from semantic_release.changelog import get_changelog_components
    correct_component_paths = "semantic_release.changelog.parse_commit,"
    correct_component_paths += "semantic_release.changelog.get_changelog_components"
    config["changelog_components"] = correct_component_paths

    components = current_changelog_components()

    # Check if the right functions have been imported
    assert parse_commit in components
    assert get_changelog_components in components

# Generated at 2022-06-21 21:08:53.107493
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the configuration change of changelog components"""
    config["changelog_components"] = "semantic_release.changelog_components.unreleased, semantic_release.tests.test_configuration.fake_function"
    components = current_changelog_components()
    assert len(components) == 2



# Generated at 2022-06-21 21:08:53.692570
# Unit test for function current_changelog_components
def test_current_changelog_components():
    pass

# Generated at 2022-06-21 21:08:57.926388
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Set the configured components
    config['changelog_components'] = 'tests.changelog_components.first_component,tests.changelog_components.second_component'

    components = current_changelog_components()

    # Verify that the correct components are returned
    assert len(components) == 2
    assert components[0].__name__ == 'first_component'
    assert components[1].__name__ == 'second_component'

# Generated at 2022-06-21 21:09:14.711307
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components"""
    import semantic_release.changelog

    paths = [
        f"{module_path}.{component_name}"
        for module_path, component_name in [
            ("semantic_release.changelog", "changelog_link_to_commits"),
            ("semantic_release.changelog", "changelog_link_to_issue"),
        ]
    ]
    config["changelog_components"] = ",".join(paths)
    components = current_changelog_components()
    assert components == [
        semantic_release.changelog.changelog_link_to_commits,
        semantic_release.changelog.changelog_link_to_issue,
    ]

# Generated at 2022-06-21 21:09:20.607628
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.hacking:parse_commit"
    assert current_commit_parser() == parse_commit

    config["commit_parser"] = "invalid"
    with pytest.raises(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-21 21:09:27.766159
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def just_return_config_as_is():
        return config

    assert just_return_config_as_is() == config
    assert just_return_config_as_is(define=["foo=bar"]) == {"foo": "bar"}
    assert just_return_config_as_is(define=[]) == config
    assert just_return_config_as_is(define=["foo=bar", "toto=titi"]) == {
        "foo": "bar",
        "toto": "titi",
    }

# Generated at 2022-06-21 21:09:31.948282
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    config["bar"] = "foo"

    @overload_configuration
    def test(define=None):
        pass

    test(define=["foo=baz", "bar=baz"])

    assert config["foo"] == "baz" and config["bar"] == "baz"

# Generated at 2022-06-21 21:09:37.108886
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests if the content of "config" is changed or not
    """
    decorated_fnc = overload_configuration(_config)
    decorated_fnc(define=["commit_parser=semantic_release.hacks.default_commit_parser"])
    assert config["commit_parser"] == "semantic_release.hacks.default_commit_parser"

# Generated at 2022-06-21 21:09:43.872279
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.settings import current_changelog_components, config

    # Test with a list of two components
    config["changelog_components"] = "semantic_release.changelogs.commits,semantic_release.changelogs.pypi"
    components = current_changelog_components()
    assert len(components) == 2
    assert components[0].__name__ == "commits"
    assert components[1].__name__ == "pypi"

    # Test with one component
    config["changelog_components"] = "semantic_release.changelogs.commits"
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0].__name__ == "commits"

    # Test with an empty list


# Generated at 2022-06-21 21:09:46.391086
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-21 21:09:50.294820
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config.get = Mock(return_value="tests.parser_mock.parse")
    assert current_commit_parser() is not None
    config.get = Mock(return_value="nonexistent.parser_mock.parse")
    assert current_commit_parser() is None

# Generated at 2022-06-21 21:09:54.676266
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(define=None):
        return config.get("hello")

    assert my_function() == "world"
    assert my_function(define="hello=overload") == "overload"
    assert my_function(define="hello=overload other=branch") == "overload"
    assert my_function(define="hello=overload other=branch") == "overload"
    assert my_function() == "world"

# Generated at 2022-06-21 21:09:57.655817
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.noop_parser"
    assert "noop_parser" in str(current_commit_parser())