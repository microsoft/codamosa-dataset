

# Generated at 2022-06-18 03:31:32.999669
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config

    assert test_func(define=["key=value"])["key"] == "value"

# Generated at 2022-06-18 03:31:33.997669
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-18 03:31:38.423125
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.body,
        semantic_release.changelog.components.footer,
        semantic_release.changelog.components.header,
    ]

# Generated at 2022-06-18 03:31:39.489038
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-18 03:31:44.744731
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["test=test"]) == _config()
    assert test_func(define=["test=test"])["test"] == "test"

# Generated at 2022-06-18 03:31:53.466495
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main

    assert config.get("commit_parser") == "semantic_release.commit_parser.parse"
    assert config.get("changelog_components") == "semantic_release.changelog.components.BreakingChange,semantic_release.changelog.components.Feature,semantic_release.changelog.components.Bugfix,semantic_release.changelog.components.Deprecation,semantic_release.changelog.components.Removal,semantic_release.changelog.components.SecurityFix,semantic_release.changelog.components.Other"


# Generated at 2022-06-18 03:31:56.025810
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config

    config["test_key"] = "test_value"
    assert test_func(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:32:02.160846
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        pass
    test_function(define=["test_key=new_value"])
    assert config["test_key"] == "new_value"

# Generated at 2022-06-18 03:32:08.209909
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(a, b, c=None, define=None):
        return a, b, c

    assert test_func(1, 2, 3, define=["a=b"]) == (1, 2, 3)
    assert config["a"] == "b"

# Generated at 2022-06-18 03:32:16.783826
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == _config()
    assert test_function(define=["foo=bar", "foo=baz"]) == _config()
    assert test_function(define=["foo=bar", "foo=baz", "foo=baz"]) == _config()
    assert test_function(define=["foo=bar", "foo=baz", "foo=baz", "foo=baz"]) == _config()
    assert test_function(define=["foo=bar", "foo=baz", "foo=baz", "foo=baz", "foo=baz"]) == _config()

# Generated at 2022-06-18 03:32:29.157584
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == {"foo": "bar"}
    assert test_function(define=["foo=bar", "baz=qux"]) == {"foo": "bar", "baz": "qux"}

# Generated at 2022-06-18 03:32:32.254807
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_function() == "test_value"
    assert test_function(define=["test_key=test_value_overloaded"]) == "test_value_overloaded"

# Generated at 2022-06-18 03:32:36.350456
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator overload_configuration works as expected"""

    @overload_configuration
    def test_function(define=None):
        return config

    # Test that the decorator works as expected
    assert test_function(define=["foo=bar"])["foo"] == "bar"

# Generated at 2022-06-18 03:32:39.615150
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config.get("test_key")

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:32:48.080697
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function()["changelog_components"] == "semantic_release.changelog.components.issue"
    assert test_function(define=["changelog_components=semantic_release.changelog.components.issue,semantic_release.changelog.components.breaking_change"])["changelog_components"] == "semantic_release.changelog.components.issue,semantic_release.changelog.components.breaking_change"

# Generated at 2022-06-18 03:32:48.696418
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-18 03:32:53.421585
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    config["test_key"] = "test_value"
    assert test_function()["test_key"] == "test_value"
    assert test_function(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:32:57.704952
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"

    @overload_configuration
    def test_func(define):
        return config["test_key"]

    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:33:00.955704
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    config["test"] = "test"
    assert test_func()["test"] == "test"
    assert test_func(define=["test=test2"])["test"] == "test2"

# Generated at 2022-06-18 03:33:02.892389
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:33:16.458890
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the overload_configuration decorator works as expected"""
    @overload_configuration
    def test_function(define=None):
        return config

    # Test that the decorator works as expected
    assert test_function(define=["foo=bar"])["foo"] == "bar"
    assert test_function(define=["foo=bar", "bar=foo"])["bar"] == "foo"

# Generated at 2022-06-18 03:33:20.519912
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        Changelog,
        ChangelogEntry,
        ChangelogSection,
    )

    components = current_changelog_components()
    assert len(components) == 2
    assert components[0] == ChangelogEntry
    assert components[1] == ChangelogSection



# Generated at 2022-06-18 03:33:23.852447
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        return config["test_key"]
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:33:30.462200
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import main

    # Test with a simple key/value pair
    main(["--define", "key=value"])
    assert config["key"] == "value"

    # Test with a key/value pair containing an equal sign
    main(["--define", "key=value=value"])
    assert config["key"] == "value=value"

    # Test with a key/value pair containing an equal sign
    main(["--define", "key=value=value", "--define", "key2=value2"])
    assert config["key"] == "value=value"
    assert config["key2"] == "value2"

# Generated at 2022-06-18 03:33:36.518657
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        get_changelog_components,
        get_changelog_components_from_config,
    )

    config["changelog_components"] = "semantic_release.changelog.components.title"
    assert get_changelog_components() == get_changelog_components_from_config()

    config["changelog_components"] = "semantic_release.changelog.components.title,semantic_release.changelog.components.body"
    assert get_changelog_components() == get_changelog_components_from_config()


# Generated at 2022-06-18 03:33:38.869817
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test"]

    assert test_func(define=["test=value"]) == "value"

# Generated at 2022-06-18 03:33:41.884453
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:33:49.140230
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the overload_configuration decorator.
    """
    @overload_configuration
    def test_function(define):
        return config

    # Test with no define
    assert test_function(define=[]) == config

    # Test with one define
    assert test_function(define=["test=test"]) == config

    # Test with two defines
    assert test_function(define=["test=test", "test2=test2"]) == config

# Generated at 2022-06-18 03:33:53.516819
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == {**_config(), "foo": "bar"}
    assert test_function(define=["foo=bar", "baz=qux"]) == {**_config(), "foo": "bar", "baz": "qux"}

# Generated at 2022-06-18 03:33:54.895110
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser.parse_commits"



# Generated at 2022-06-18 03:34:07.108530
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    assert config["test"] == "test"

    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["test=test2"])
    assert config["test"] == "test2"

# Generated at 2022-06-18 03:34:15.207313
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    # Test with no define
    assert test_func() == config

    # Test with define
    assert test_func(define=["test=test"]) == {"test": "test"}

    # Test with multiple define
    assert test_func(define=["test=test", "test2=test2"]) == {
        "test": "test",
        "test2": "test2",
    }

    # Test with bad define
    assert test_func(define=["test"]) == config

# Generated at 2022-06-18 03:34:16.278670
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-18 03:34:23.574240
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config.get("test_key")

    config["test_key"] = "test_value"
    assert test_func() == "test_value"

    config["test_key"] = "test_value_2"
    assert test_func(define=["test_key=test_value_3"]) == "test_value_3"

    config["test_key"] = "test_value_4"
    assert test_func(define=["test_key_2=test_value_5"]) == "test_value_4"

# Generated at 2022-06-18 03:34:26.594737
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:34:30.432421
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:34:32.824439
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:34:35.076183
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components
    assert current_changelog_components() == changelog_components

# Generated at 2022-06-18 03:34:40.012007
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["foo=bar"]) == {**_config(), "foo": "bar"}
    assert test_func(define=["foo=bar", "spam=eggs"]) == {**_config(), "foo": "bar", "spam": "eggs"}

# Generated at 2022-06-18 03:34:42.424782
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components
    assert current_changelog_components() == get_changelog_components()

# Generated at 2022-06-18 03:34:55.050103
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def test_function(define):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=overloaded_value"]) == "overloaded_value"

# Generated at 2022-06-18 03:34:59.901547
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This function tests the overload_configuration decorator.
    """

    @overload_configuration
    def test_function(define=None):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_function() == "test_value"
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:35:02.396405
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:35:05.640576
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:35:09.051848
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"

    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:35:11.305460
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components

    assert current_changelog_components() == get_changelog_components()

# Generated at 2022-06-18 03:35:14.847200
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config.get("test_key")

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:35:16.476023
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config["define_test"]

    assert test_function(define=["define_test=test"]) == "test"

# Generated at 2022-06-18 03:35:20.240416
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"

    @overload_configuration
    def test_function(define):
        pass

    test_function(define=["test_key=new_value"])
    assert config["test_key"] == "new_value"

# Generated at 2022-06-18 03:35:30.573776
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogEntry
    from semantic_release.changelog import ChangelogEntryType
    from semantic_release.changelog import ChangelogEntryVersion
    from semantic_release.changelog import ChangelogEntryVersionType
    from semantic_release.changelog import ChangelogEntryVersionChange
    from semantic_release.changelog import ChangelogEntryVersionChangeType
    from semantic_release.changelog import ChangelogEntryVersionChangeChange
    from semantic_release.changelog import ChangelogEntryVersionChangeChangeType
    from semantic_release.changelog import ChangelogEntryVersionChangeChangeChange
    from semantic_release.changelog import ChangelogEntryVersionChangeChangeChangeType

# Generated at 2022-06-18 03:35:41.982139
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.commit_message,
        semantic_release.changelog.components.issue_references,
        semantic_release.changelog.components.pr_references,
    ]

# Generated at 2022-06-18 03:35:46.257967
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=overloaded_value"]) == "overloaded_value"

# Generated at 2022-06-18 03:35:50.667032
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_func() == "test_value"
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:35:57.913915
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the overload_configuration decorator.
    """

    @overload_configuration
    def test_function(define=None):
        return config

    # Test with no define
    assert test_function() == config

    # Test with one define
    assert test_function(define=["define_test=test"]) == {**config, "define_test": "test"}

    # Test with two defines
    assert test_function(define=["define_test=test", "define_test2=test2"]) == {
        **config,
        "define_test": "test",
        "define_test2": "test2",
    }

# Generated at 2022-06-18 03:35:58.631110
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-18 03:36:02.378961
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config["test_key"]

    assert test_function(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:36:04.553997
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test"]

    assert test_func(define=["test=test"]) == "test"

# Generated at 2022-06-18 03:36:07.847399
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser.parse_commits"

# Generated at 2022-06-18 03:36:13.135064
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["foo=bar"]) == {**_config(), "foo": "bar"}
    assert test_func(define=["foo=bar", "baz=qux"]) == {**_config(), "foo": "bar", "baz": "qux"}

# Generated at 2022-06-18 03:36:13.850603
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-18 03:36:24.828029
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config.get("test_key")

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:36:26.936385
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config.get("test_key")

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:36:29.693897
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        return config["test_key"]
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:36:34.071690
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_func() == "test_value"
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:36:36.057543
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    config["test"] = "test"
    assert test_function()["test"] == "test"
    assert test_function(define=["test=test2"])["test"] == "test2"

# Generated at 2022-06-18 03:36:39.799858
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define):
        return config["test_key"]
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:36:40.285205
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-18 03:36:43.102086
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    @overload_configuration
    def test_function(define):
        return config["test"]

    assert test_function(define=["test=test2"]) == "test2"

# Generated at 2022-06-18 03:36:46.987365
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:36:49.836450
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test"]

    assert test_func(define=["test=test"]) == "test"

# Generated at 2022-06-18 03:37:03.911187
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["foo=bar"]) == _config()
    assert test_func(define=["foo=bar", "bar=foo"]) == _config()
    assert test_func(define=["foo=bar", "bar=foo", "foo=foo"]) == _config()
    assert test_func(define=["foo=foo"]) == {**_config(), "foo": "foo"}
    assert test_func(define=["foo=foo", "bar=foo"]) == {**_config(), "foo": "foo", "bar": "foo"}

# Generated at 2022-06-18 03:37:05.799280
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-18 03:37:09.574780
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config.get("test_key")

    assert test_function() is None
    assert test_function(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:37:13.840256
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""
    config["test_key"] = "test_value"

    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:37:17.778516
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]
    assert test_func() == "test_value"
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:37:21.374975
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    @overload_configuration
    def test_function(define):
        return config["test"]

    assert test_function(define=["test=test2"]) == "test2"

# Generated at 2022-06-18 03:37:27.304157
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components function"""
    from semantic_release.changelog import get_changelog_components
    from semantic_release.changelog import get_changelog_components_from_config

    assert current_changelog_components() == get_changelog_components()
    assert current_changelog_components() == get_changelog_components_from_config()

# Generated at 2022-06-18 03:37:29.518670
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components

    assert current_changelog_components() == changelog_components

# Generated at 2022-06-18 03:37:33.379729
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def test_function(define):
        """Test function"""
        return define

    assert test_function(define=["a=b"]) == ["a=b"]
    assert config["a"] == "b"

# Generated at 2022-06-18 03:37:37.006323
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components
    assert current_changelog_components() == changelog_components

# Generated at 2022-06-18 03:37:51.256636
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    # Test if the decorator works
    assert test_func() == _config()

    # Test if the decorator overloads the configuration
    assert test_func(define=["test=1"]) == _config()
    assert test_func(define=["test=1"])["test"] == "1"

    # Test if the decorator overloads the configuration with multiple pairs
    assert test_func(define=["test=1", "test2=2"]) == _config()
    assert test_func(define=["test=1", "test2=2"])["test"] == "1"
    assert test_func(define=["test=1", "test2=2"])["test2"] == "2"

# Generated at 2022-06-18 03:37:53.710974
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components
    assert current_changelog_components() == changelog_components

# Generated at 2022-06-18 03:37:55.060146
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 1
    assert current_changelog_components()[0].__name__ == "changelog_section"

# Generated at 2022-06-18 03:38:00.305613
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_function(define=None):
        return config["test_key"]
    assert test_function() == "test_value"
    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:38:02.364004
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_commit

    assert current_commit_parser() == parse_commit

# Generated at 2022-06-18 03:38:06.906998
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    test_func(define=["test_key=test_value"])
    assert config["test_key"] == "test_value"

# Generated at 2022-06-18 03:38:08.264555
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-18 03:38:13.267514
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        BreakingChange,
        Changelog,
        Feature,
        Fix,
        Other,
    )
    from semantic_release.changelog import (
        BreakingChange,
        Changelog,
        Feature,
        Fix,
        Other,
    )
    assert current_changelog_components() == [
        BreakingChange,
        Feature,
        Fix,
        Other,
        Changelog,
    ]

# Generated at 2022-06-18 03:38:18.411187
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["test=test"]) == _config()
    assert test_func(define=["test=test"])["test"] == "test"

# Generated at 2022-06-18 03:38:20.825029
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import changelog_components

    assert current_changelog_components() == changelog_components

# Generated at 2022-06-18 03:38:32.225590
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == {"foo": "bar"}
    assert test_function(define=["foo=bar", "baz=qux"]) == {"foo": "bar", "baz": "qux"}

# Generated at 2022-06-18 03:38:33.787480
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == 'semantic_release.commit_parser.parse_commits'

# Generated at 2022-06-18 03:38:38.669167
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.body,
        semantic_release.changelog.components.footer,
        semantic_release.changelog.components.header,
    ]

# Generated at 2022-06-18 03:38:49.718128
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogEntry
    from semantic_release.changelog import ChangelogEntryType
    from semantic_release.changelog import ChangelogSection
    from semantic_release.changelog import ChangelogSectionType
    from semantic_release.changelog import ChangelogTitle
    from semantic_release.changelog import ChangelogTitleType
    from semantic_release.changelog import ChangelogType
    from semantic_release.changelog import ChangelogVersion
    from semantic_release.changelog import ChangelogVersionType

    components = current_changelog_components()
    assert len(components) == 3
    assert components[0] == Changelog
    assert components[1] == ChangelogEntry


# Generated at 2022-06-18 03:38:52.890794
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config.get("test_key")

    assert test_func(define="test_key=test_value") == "test_value"

# Generated at 2022-06-18 03:39:03.896995
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogEntry
    from semantic_release.changelog import ChangelogEntryType
    from semantic_release.changelog import ChangelogEntryVersion
    from semantic_release.changelog import ChangelogEntryVersionType
    from semantic_release.changelog import ChangelogSection
    from semantic_release.changelog import ChangelogSectionType
    from semantic_release.changelog import ChangelogSectionVersion
    from semantic_release.changelog import ChangelogSectionVersionType
    from semantic_release.changelog import ChangelogVersion
    from semantic_release.changelog import ChangelogVersionType
    from semantic_release.changelog import ChangelogVersionVersion

# Generated at 2022-06-18 03:39:06.835169
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == {**_config(), "foo": "bar"}
    assert test_function(define=["foo=bar", "bar=foo"]) == {**_config(), "foo": "bar", "bar": "foo"}

# Generated at 2022-06-18 03:39:08.044988
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() == "semantic_release.commit_parser:CommitParser"

# Generated at 2022-06-18 03:39:14.063850
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_func() == "test_value"
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:39:14.987587
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-18 03:39:27.516713
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:39:32.134156
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        return config["test"]

    assert test_function(define=["test=test"]) == "test"
    assert test_function(define=["test=test", "test2=test2"]) == "test"

# Generated at 2022-06-18 03:39:35.058680
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def test_function(define):
        """Test function"""
        return define

    assert test_function(define=["foo=bar"]) == ["foo=bar"]
    assert config["foo"] == "bar"

# Generated at 2022-06-18 03:39:39.239661
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.changelog_body,
        semantic_release.changelog.components.changelog_footer,
        semantic_release.changelog.components.changelog_header,
    ]

# Generated at 2022-06-18 03:39:44.145526
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:39:47.793415
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    assert test_func(define=["test_key=test_value"]) == "test_value"
    assert "test_key" not in config

# Generated at 2022-06-18 03:39:50.540509
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config.get("test_key")

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:39:53.182079
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the decorator overload_configuration"""

    @overload_configuration
    def test_function(define):
        return config

    config["test_key"] = "test_value"
    assert test_function(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:39:54.744842
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-18 03:39:58.265310
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"
    @overload_configuration
    def test_func(define):
        return config["test_key"]
    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:40:10.074728
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration decorator"""

    @overload_configuration
    def test_function(define):
        """Test function"""
        return define

    assert test_function(define=["foo=bar"]) == ["foo=bar"]
    assert config["foo"] == "bar"

# Generated at 2022-06-18 03:40:11.032832
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-18 03:40:13.671980
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config

    config["test"] = "test"
    assert test_func(define=["test=test2"])["test"] == "test2"

# Generated at 2022-06-18 03:40:21.807710
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()

    assert test_func(define=["foo=bar"]) == {**_config(), "foo": "bar"}

    assert test_func(define=["foo=bar", "baz=qux"]) == {
        **_config(),
        "foo": "bar",
        "baz": "qux",
    }

    assert test_func(define=["foo=bar", "baz=qux", "foo=quux"]) == {
        **_config(),
        "foo": "quux",
        "baz": "qux",
    }

# Generated at 2022-06-18 03:40:26.562017
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    config["test"] = "foo"
    assert test_func(define=["test=bar"])["test"] == "bar"

# Generated at 2022-06-18 03:40:28.711580
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator overload_configuration works as expected"""
    @overload_configuration
    def test_function(define=None):
        return config

    config["test_key"] = "test_value"
    assert test_function()["test_key"] == "test_value"
    assert test_function(define=["test_key=new_value"])["test_key"] == "new_value"

# Generated at 2022-06-18 03:40:30.814506
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components

    assert current_changelog_components() == get_changelog_components()

# Generated at 2022-06-18 03:40:40.952911
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Changelog
    from semantic_release.changelog import ChangelogEntry
    from semantic_release.changelog import ChangelogEntryType
    from semantic_release.changelog import ChangelogEntryVersion
    from semantic_release.changelog import ChangelogEntryVersionType
    from semantic_release.changelog import ChangelogEntryVersionChange
    from semantic_release.changelog import ChangelogEntryVersionChangeType
    from semantic_release.changelog import ChangelogEntryVersionChangeCommit
    from semantic_release.changelog import ChangelogEntryVersionChangeCommitType
    from semantic_release.changelog import ChangelogEntryVersionChangeCommitAuthor
    from semantic_release.changelog import ChangelogEntryVersionChangeCommitAuthorType

# Generated at 2022-06-18 03:40:44.834309
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the overload_configuration decorator.
    """

    @overload_configuration
    def test_function(define):
        return config

    assert test_function(define=["test=test"])["test"] == "test"

# Generated at 2022-06-18 03:40:51.818997
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(a, b, c, d, define=None):
        return a, b, c, d, define

    assert test_func(1, 2, 3, 4, define=["a=b", "c=d"]) == (1, 2, 3, 4, ["a=b", "c=d"])
    assert config["a"] == "b"
    assert config["c"] == "d"

# Generated at 2022-06-18 03:41:02.326999
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"

    @overload_configuration
    def test_func(define):
        return config["test_key"]

    assert test_func(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-18 03:41:03.591885
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

# Generated at 2022-06-18 03:41:07.277653
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import get_changelog_components

    assert current_changelog_components() == get_changelog_components()

# Generated at 2022-06-18 03:41:10.512987
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    assert test_func(define=["test_key=test_value"]) == "test_value"

# Generated at 2022-06-18 03:41:13.571289
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        return config

    assert test_function() == _config()
    assert test_function(define=["foo=bar"]) == {**_config(), "foo": "bar"}

# Generated at 2022-06-18 03:41:17.388184
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config["test_key"]

    config["test_key"] = "test_value"
    assert test_func(define=["test_key=test_value_overloaded"]) == "test_value_overloaded"

# Generated at 2022-06-18 03:41:20.696009
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test"
    @overload_configuration
    def test_function(define=None):
        return config["test"]
    assert test_function() == "test"
    assert test_function(define=["test=test2"]) == "test2"

# Generated at 2022-06-18 03:41:24.563112
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define=None):
        return config

    assert test_func() == _config()
    assert test_func(define=["foo=bar"]) == {**_config(), "foo": "bar"}
    assert test_func(define=["foo=bar", "bar=baz"]) == {**_config(), "foo": "bar", "bar": "baz"}