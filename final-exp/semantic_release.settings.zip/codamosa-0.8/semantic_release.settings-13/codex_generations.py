

# Generated at 2022-06-12 07:01:02.121809
# Unit test for function overload_configuration
def test_overload_configuration():
    # Given
    values = {"tag_template": "v{version}"}
    config.update(values)

    @overload_configuration
    def func(define):
        if isinstance(define, str):
            define = [define]
        return config

    # When
    result = func(define=["tag_template=v{version_on_eight_digits}"])

    # Then
    assert result["tag_template"] == "v{version_on_eight_digits}"

# Generated at 2022-06-12 07:01:07.658768
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def fake_func():
        return 'fake_func'

    assert config['develop_branch'] == 'master'
    assert fake_func() == 'fake_func'
    assert config['develop_branch'] == 'master'
    fake_func(define=['develop_branch=custom_branch'])
    assert config['develop_branch'] == 'custom_branch'

# Generated at 2022-06-12 07:01:17.735483
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Function test_current_commit_parser tests method current_commit_parser
    """

    # Configure the class for "semantic_release_parser"
    config["commit_parser"] = "semantic_release_parser"

    # Get the parser
    parser = current_commit_parser()

    # Check that the parser is the one from "semantic_release_parser"
    assert parser.__name__ == "semantic_release_parser"

    # Test an error case
    config["commit_parser"] = "unknow_parser"
    try:
        current_commit_parser()
        assert False
    except ImproperConfigurationError as e:
        assert "Unable to import parser" in str(e)



# Generated at 2022-06-12 07:01:37.297967
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import BadComponent, GoodComponent

    bad_components = [
        "semantic_release.changelog_components.BadComponent",
        "semantic_release.changelog_components.GoodComponent",
    ]
    config["changelog_components"] = ",".join(bad_components)
    assert current_changelog_components() == [BadComponent, GoodComponent]

    bad_components = [
        "semantic_release.changelog_components.BadComponent",
        "semantic_release.changelog_components.UnknownComponent",
        "semantic_release.changelog_components.GoodComponent",
    ]
    config["changelog_components"] = ",".join(bad_components)
    assert current_changelog

# Generated at 2022-06-12 07:01:46.150213
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the function current_commit_parser
    """
    from semantic_release.history import changelog

    config['commit_parser'] = 'semantic_release.history.changelog'
    assert current_commit_parser() == changelog

    config['commit_parser'] = 'semantic_release.history.changelog.changelog'
    assert current_commit_parser() == changelog

    config['commit_parser'] = 'semantic_release.history.changelog.bad'
    try:
        current_commit_parser()
        assert False
    except ImproperConfigurationError:
        assert True

# Generated at 2022-06-12 07:01:49.662227
# Unit test for function overload_configuration
def test_overload_configuration():
    config["new_option"] = "default_value"

    @overload_configuration
    def get_new_option():
        return config.get("new_option")

    assert get_new_option() == "default_value"
    assert get_new_option(define=["new_option=new_value"]) == "new_value"

# Generated at 2022-06-12 07:01:54.697743
# Unit test for function overload_configuration
def test_overload_configuration():
    config["some_key"] = "some_value"
    assert config["some_key"] == "some_value"

    @overload_configuration
    def config_overloading_test(define):
        pass

    config_overloading_test(define=["some_key=some_other_value"])
    assert config["some_key"] == "some_other_value"



# Generated at 2022-06-12 07:02:02.698899
# Unit test for function overload_configuration
def test_overload_configuration():
    """Check that the decorator overload_configuration works.

    This unit test is meant to be run directly.
    """
    config_original = config.copy()
    config["overload"] = "original"
    config["overload_wrong"] = "original"

    @overload_configuration
    def test_function(overload_wrong, define):
        new = config.copy()
        new.pop("overload_wrong")
        return new

    assert config == test_function(overload_wrong="new", define=["overload=new"])
    assert config_original == config


if __name__ == "__main__":
    # For testing purposes.
    test_overload_configuration()

# Generated at 2022-06-12 07:02:09.428513
# Unit test for function overload_configuration
def test_overload_configuration():
    from . import cli

    cli.config["testkey"] = 0
    assert cli.config.get("testkey", 1) == 0

    @overload_configuration
    def test_func():
        return cli.config.get("testkey", 2)

    test_func(define=["testkey=10"])
    assert cli.config.get("testkey", 3) == 10

    test_func()
    assert cli.config.get("testkey", 4) == 10

# Generated at 2022-06-12 07:02:15.492398
# Unit test for function overload_configuration
def test_overload_configuration():
    config["ci"] = "Travis"
    config[".."] = ".."

    @overload_configuration
    def test_function(define=None):
        return config["ci"]

    assert test_function() == "Travis"
    assert test_function(define=["ci=AppVeyor", "..=."]) == "AppVeyor"
    assert config[".."] == "."

# Generated at 2022-06-12 07:02:22.254658
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None



# Generated at 2022-06-12 07:02:27.715742
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.issue_tracker_section, semantic_release.changelog.components.note_section, semantic_release.changelog.components.breaking_change_section"
    assert current_changelog_components() != None, current_changelog_components()

# Generated at 2022-06-12 07:02:33.250809
# Unit test for function overload_configuration
def test_overload_configuration():
    """This tests overwrite a configuration parameter
    """

    def definition():
        """ This is the definition of a dummy function
        """
        pass

    # This must be the definition, with the key "test"
    assert overload_configuration(definition)()["test"] == None

    # We overwrite the configuration parameter
    config["test"] = "test value"
    # This must be the definition, with the key "test"
    assert overload_configuration(definition)()["test"] == "test value"

# Generated at 2022-06-12 07:02:37.223485
# Unit test for function current_commit_parser
def test_current_commit_parser():
    with open(os.path.join(os.path.dirname(__file__), "defaults.cfg"), "w") as f:
        f.write("[semantic_release]\n")
        f.write('commit_parser = semantic_release.commit_parser.parse')

    current_commit_parser()

# Generated at 2022-06-12 07:02:42.067984
# Unit test for function overload_configuration
def test_overload_configuration():
    new_config = {"foo": "bar"}
    old_config = {**config, **new_config}

    @overload_configuration
    def f(foo):
        print(f"This is {foo}")
        return foo

    assert config == old_config
    assert f(define=["foo=bar"]) == "bar"
    assert config == old_config

# Generated at 2022-06-12 07:02:44.135763
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-12 07:02:53.497361
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy_func(define=None):
        return config["changelog_components"]

    result1 = dummy_func()
    result2 = dummy_func(define=["changelog_components=semantic_release.changelog.changelog_components.create_issue"])

    assert result1 != result2  # Test that the function overloads config
    assert result1 != config["changelog_components"]  # Test that config is overload within the function
    assert result2 == config["changelog_components"]  # Test that the function overloads config

# Generated at 2022-06-12 07:02:56.721138
# Unit test for function overload_configuration
def test_overload_configuration():
    config["new_config_key"] = "original value"
    assert config["new_config_key"] == "original value"

    class Foo:
        @overload_configuration
        def overwrite_config(self, **kwargs):
            assert config["new_config_key"] == "new value"

    Foo().overwrite_config(define=["new_config_key=new value"])
    assert config["new_config_key"] == "new value"

# Generated at 2022-06-12 07:03:05.689913
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(define=None):
        return config

    # Case 0 : define is None
    assert foo() is config
    # Case 1 : define is a single key/value
    assert foo(define=["key=value"])["key"] == "value"
    # Case 2 : define is a single key without value
    assert "key" not in foo(define=["key"])
    # Case 3 : define is a list of key/value
    assert foo(define=["key1=value1", "key2=value2"])["key2"] == "value2"



# Generated at 2022-06-12 07:03:10.975159
# Unit test for function overload_configuration
def test_overload_configuration():
    """This is a unit test for the decorator overload_configuration.
    It checks that the content of "config" is correctly modified by the keys
    of the "define" arrays.
    """
    @overload_configuration
    def define_config(define):
        assert config

    define_config(define=["key=value"])
    assert config["key"] == "value"

# Generated at 2022-06-12 07:03:19.236357
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """ Tests the function current_commit_parser
    """
    assert callable(current_commit_parser())

# Generated at 2022-06-12 07:03:28.530988
# Unit test for function overload_configuration
def test_overload_configuration():
    config["project_name"] = "old-project-name"

    @overload_configuration
    def run(define):
        # define must be passed as a list of strings
        pass

    run(define=["project_name=new-project-name"])

    assert config["project_name"] == "new-project-name"

    # If define is not a string, the old value must be returned
    run(define=["project_name"])
    assert config["project_name"] == "new-project-name"
    assert config["project_name"] != "old-project-name"

    # If define has no value, the old value must be returned
    run(define=["project_name="])
    assert config["project_name"] == "new-project-name"

# Generated at 2022-06-12 07:03:31.098765
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog

    assert current_changelog_components() == [
        changelog.issue_numbers,
        changelog.unreleased,
        changelog.summary,
    ]

# Generated at 2022-06-12 07:03:38.280706
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(arg):
        return arg
    
    assert(test_func("Hello") == "Hello")
    assert(config.get("overloaded") == None)
    assert(test_func("Hello", define=["overloaded=true"]) == "Hello")
    assert(config.get("overloaded") == "true")
    assert(test_func("Hello", define=["non_existing_key=true"]) == "Hello")
    assert(config.get("non_existing_key") == None)

# Generated at 2022-06-12 07:03:46.580401
# Unit test for function overload_configuration
def test_overload_configuration():
    # a function without overload_configuration decorator
    def func_without_overload(a, b, c=5):
        return a * b * c

    # a function with overload_configuration decorator
    @overload_configuration
    def func_with_overload(a, b, c=5):
        return a * b * c

    def test_func_with_overload():
        assert func_with_overload(2, 3) == 30
        assert func_with_overload(2, 3, define=["c=10"]) == 60
        assert func_with_overload(2, 3, c=10, define=["c=100"]) == 600
        assert func_with_overload(2, 3, c=10) == 30

# Generated at 2022-06-12 07:03:48.883573
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.errors

    with semantic_release.errors.expected(ImproperConfigurationError):
        current_commit_parser()



# Generated at 2022-06-12 07:03:58.963667
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = {"previous_version": "1.0.0", "current_version": "1.0.1"}

    @overload_configuration
    def test_function(previous_version, current_version, define=None):
        return previous_version, current_version

    assert test_function("1.1.0", "1.1.1") == ("1.1.0", "1.1.1")

    assert (
        test_function("1.2.0", "1.2.1", define=["previous_version=1.0.0"])
        == ("1.0.0", "1.2.1")
    )


# Generated at 2022-06-12 07:04:03.814205
# Unit test for function overload_configuration
def test_overload_configuration():
    """Make sure that we can overload configuration file"""
    import sys
    import semantic_release.cli

    sys.argv = ["semantic-release", "--define=use_local_cache=True"]
    with overload_configuration(semantic_release.cli.cli):
        semantic_release.cli.cli()

    assert config["use_local_cache"] == "True"

# Generated at 2022-06-12 07:04:08.724842
# Unit test for function overload_configuration
def test_overload_configuration():
    config["release_type"] = "patch"

    @overload_configuration
    def set_type():
        return config["release_type"]

    assert set_type() == "patch"
    assert set_type(define=["release_type=minor"]) == "minor"
    assert set_type() == "patch"

# Generated at 2022-06-12 07:04:09.720880
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()


# Generated at 2022-06-12 07:04:24.877912
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the following:
    - the decorator can be used on any function
    - the decorator overrides the config
    """
    config["test"] = False

    @overload_configuration
    def function(define=None):
        # Here, the 'test' value of the config should be True
        return config

    # The decorator can be used on any function
    def function2(define=None):
        # Here, the 'test' value of the config should be True
        return config

    assert function(define=["test=True"])["test"]
    # The config is not overridden outside the decorated function
    assert not config["test"]

    # The decorator also works on other functions
    assert function2(define=["test=True"])["test"]
    # The config is not overridden outside the decorated function


# Generated at 2022-06-12 07:04:28.280852
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_configuration(define=None):
        return define

    assert test_configuration(define=['release_level=major']) == ['release_level=major']
    assert config.get('release_level') == 'major'

# Generated at 2022-06-12 07:04:35.398853
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(define, value=None):
        return define, value

    # Without define argument
    assert my_function(value=True) == (None, True)

    # With define argument
    assert my_function(define=["name=value", "empty", "dummy=1=2"], value=True) == (
        ["name=value", "empty", "dummy=1=2"],
        True,
    )
    assert config["name"] == "value"
    assert not config.get("empty")
    assert config["dummy"] == "1=2"

# Generated at 2022-06-12 07:04:40.624443
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog_components.title,
        semantic_release.changelog_components.issue,
        semantic_release.changelog_components.pr,
        semantic_release.changelog_components.body,
    ]

# Generated at 2022-06-12 07:04:45.953787
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test overrides two parameters of config and check if
    the content of the config dictionnary has changed
    """
    config["test_string"] = "This is a test string"
    config["test_integer"] = 1

    @overload_configuration
    def test_func(*args, **kwargs):
        return True

    test_func(define=["test_string=Other test string", "test_integer=2"])
    assert config["test_string"] == "Other test string"
    assert config["test_integer"] == "2"

# Generated at 2022-06-12 07:04:49.650913
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(a, b):
        return a + b

    # No overload
    assert f(1, 2) == 3

    # Overload
    assert f(1, 2, define=["a=3"]) == 5

# Generated at 2022-06-12 07:04:58.835313
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_overload_configuration_key"] = "test_overload_configuration_value"

    @overload_configuration
    def test_function(define):
        """ This function just returns the value of the config key
        "test_overload_configuration_key" and the string "value".
        """
        return config["test_overload_configuration_key"], "value"

    # Test if the "function" returns the original value of the config key
    assert test_function.__name__ == "test_function"
    assert test_function(define=None) == ("test_overload_configuration_value", "value")

    # Test if a config key is correctly changed
    test_function(define="test_overload_configuration_key=test_overload_configuration_new_value")
    assert config

# Generated at 2022-06-12 07:05:06.212798
# Unit test for function overload_configuration
def test_overload_configuration():
    class TestClass:

        @overload_configuration
        def overloaded_function(self, define=None):
            return

    test_class = TestClass()

    # Test no define
    assert test_class.overloaded_function() is None

    # Test define with one argument
    assert test_class.overloaded_function(define=["key=value"]) is None
    assert str(config["key"]) == "value"

    # Test define with two arguments
    assert test_class.overloaded_function(define=["key=value", "key2=value2"]) is None
    assert str(config["key2"]) == "value2"

# Generated at 2022-06-12 07:05:07.693845
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 2

# Generated at 2022-06-12 07:05:16.788400
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import get_version_and_release_message

    # Old value of config
    old_config = config.copy()

    # Define new values with overload_configuration
    # Normal case
    get_version_and_release_message(meta={"define": ["changelog_file=CHANGELOG.md"]})
    # Type error should be ignored
    get_version_and_release_message(meta={"define": ["changelog_file=CHANGELOG.md", "dry_run=true"]})
    # Bad format
    get_version_and_release_message(meta={"define": ["changelog_file"]})
    # Empty value
    get_version_and_release_message(meta={"define": ["=CHANGELOG.md"]})


# Generated at 2022-06-12 07:05:32.900140
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog
    from semantic_release.changelog import Changelog, ChangelogComponent
    from semantic_release.errors import ImproperConfigurationError
    from unittest.mock import Mock, patch

    import semantic_release as sr

    with patch("semantic_release.config.config", new=Mock()):
        sr.config.config["changelog_components"] = "commits,bug_fixes,invalid"
        components = current_changelog_components()
        assert components == [commits, bug_fixes]

        sr.config.config["changelog_components"] = "invalid"
        with pytest.raises(ImproperConfigurationError):
            current_changelog_components()



# Generated at 2022-06-12 07:05:37.136829
# Unit test for function overload_configuration
def test_overload_configuration():
    def dummy_func(define=None):
        return define

    dummy_func_overloaded = overload_configuration(dummy_func)
    assert dummy_func_overloaded(define=["newkey=newvalue"]) == ["newkey=newvalue"]
    assert config["newkey"] == "newvalue"



# Generated at 2022-06-12 07:05:41.403086
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config["long_description_content_type"] == "text/markdown"

    @overload_configuration
    def update_config(define: str):
        pass

    update_config(define="long_description_content_type=text/rst")

    assert config["long_description_content_type"] == "text/rst"

# Generated at 2022-06-12 07:05:48.199416
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(param):
        return config["test"]

    # No define parameter
    assert func("test") == "default_value"
    # Set test to 'value_one'
    assert func("test", define=["test=value_one"]) == "value_one"
    # Set test to 'value_two' (override to 'value_one')
    assert func("test", define=["test=value_two"]) == "value_two"

# Generated at 2022-06-12 07:05:54.136875
# Unit test for function overload_configuration
def test_overload_configuration():
    """This unit test tests the behavior of the "overload_configuration" function."""

    def test_func(**kwargs):
        """This is a simple function used to test the behavior of the
        "overload_configuration" function.
        """

        return kwargs

    assert overload_configuration(test_func)(define=["a=1"])["define"] == ["a=1"]
    assert overload_configuration(test_func)(define=["b=2"])["define"] == ["b=2"]

# Generated at 2022-06-12 07:05:57.521760
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Setup the "changelog_components" parameter
    config["changelog_components"] = "changelog.components.BreakingChange.from_commit"
    # Call the current_changelog_components function
    component = current_changelog_components()
    # Assert that the returned component is the expected one
    assert component[0] is changelog.components.BreakingChange.from_commit



# Generated at 2022-06-12 07:06:02.179717
# Unit test for function current_changelog_components
def test_current_changelog_components():
    real_config = config
    config['changelog_components'] = "semantic_release.vcs.changelog_components.BreakingChange"
    assert current_changelog_components() == [importlib.import_module('semantic_release.vcs.changelog_components').BreakingChange]
    config = real_config

# Generated at 2022-06-12 07:06:04.671666
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 2
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-12 07:06:10.996229
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_component.unreleased import unreleased_components
    from .changelog_component.with_issue import components_with_issue
    from .changelog_component.without_issue import components_without_issue
    components = current_changelog_components()
    assert len(components) == 3
    assert components == (unreleased_components, components_with_issue, components_without_issue)



# Generated at 2022-06-12 07:06:15.823125
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def get_configuration(define=None):
        return config

    config["test_1"] = "test_1"
    new_config = get_configuration(define=["test_1=other_test_1", "test_2=test_2"])
    assert new_config["test_1"] == "other_test_1"
    assert new_config["test_2"] == "test_2"

# Generated at 2022-06-12 07:06:27.784626
# Unit test for function overload_configuration
def test_overload_configuration():
    """Checks that the decorator overloads the config with the "define" param
    """
    # Overload a config value
    @overload_configuration
    def test_function(define=[]):
        return config['commit_parser'][:3]

    assert test_function(define=["commit_parser=semantic_release.commit_parser:SingleLineParser"]) == "sem"

# Generated at 2022-06-12 07:06:37.639568
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(*args, **kwargs):
        return kwargs

    assert "define" not in test_func(1, 2, 3)
    assert "define" in test_func(1, 2, 3, define=["token=token1"])["define"]
    assert "token=token1" in test_func(1, 2, 3, define=["token=token1"])["define"]
    assert "token=token1,token=token2" == test_func(
        1, 2, 3, define=["token=token1,token=token2"]
    )["define"][0]
    assert "token2" in test_func(
        1, 2, 3, define=["token=token1,token=token2"]
    )["define"][0]

    #

# Generated at 2022-06-12 07:06:45.126856
# Unit test for function overload_configuration
def test_overload_configuration():
    """Add a "define" key-value to kwargs and check that this key-value is
    also in config
    """

    def func(x, define=None):
        return x

    func = overload_configuration(func)
    kwargs = {"x": 0, "define": ["y=1"]}
    func(**kwargs)
    assert config["y"] == "1"

# Generated at 2022-06-12 07:06:49.027962
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog_components
    from semantic_release.changelog_components import BreakingChange, Changelog

    assert Changelog in current_changelog_components()
    assert BreakingChange in current_changelog_components()

# Generated at 2022-06-12 07:06:53.844046
# Unit test for function current_commit_parser
def test_current_commit_parser():
    class DummyParser:
        def parse_message(self, message):
            return {}

    class DummyParserModule:
        Commit = DummyParser

    assert current_commit_parser() == DummyParser().parse_message
    assert current_commit_parser() != None


# Generated at 2022-06-12 07:07:00.172906
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

    @overload_configuration
    def test(commit_parser=None, define=None):
        return config["commit_parser"]

    assert test(define=["commit_parser=semantic_release.commit_parser.noop"]) == "semantic_release.commit_parser.noop"

    # Save the initial configuration
    initial_config = config.copy()

    # Use a function that doesn't exist
    test(define=["commit_parser=semantic_release.commit_parser.noop.noop"])

    # Restore the initial configuration
    config = initial_config.copy()

# Generated at 2022-06-12 07:07:06.706096
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(param):
        assert param == "value_in_args"
        assert config["key_in_args"] == "value_in_args"
        assert "key_in_kwargs" in config and config["key_in_kwargs"] == "value_in_kwargs"

    my_function(param="value_in_args", define=["key_in_args=value_in_args", "key_in_kwargs=value_in_kwargs"])

# Generated at 2022-06-12 07:07:10.099198
# Unit test for function overload_configuration
def test_overload_configuration():
    import inspect

    def configurable(a, b, define=None):
        return a, b, define

    configurable = overload_configuration(configurable)

    assert inspect.getsource(configurable) == inspect.getsource(overload_configuration)

# Generated at 2022-06-12 07:07:15.456961
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "value1"

    @overload_configuration
    def test_function(define=None):
        return config.get("test")

    assert test_function() == "value1"
    assert test_function(define="test=value2") == "value2"

# Generated at 2022-06-12 07:07:23.698242
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}
    @overload_configuration
    def function_one(some_param, **options):
        return config

    function_one("test", define=["PARAM1=value1"])
    assert config["PARAM1"] == "value1"
    function_one("test", define=["PARAM2=value2"])
    assert config["PARAM1"] == "value1"
    assert config["PARAM2"] == "value2"

# Generated at 2022-06-12 07:07:38.520020
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test_ok"

    @overload_configuration
    def test_configuration(define):
        return config["test"]

    assert test_configuration(define=["test=test_fail"]) == "test_ok"
    assert test_configuration(define=["test=test_success"]) == "test_success"

# Generated at 2022-06-12 07:07:43.183551
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(a, b, c):
        return a, b, c

    # By using the decorator, the function returns the modified arguments
    assert func(a=1, b=2, c=3, define=['a=10']) == (10, 2, 3)

# Generated at 2022-06-12 07:07:49.461784
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "a"

    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["test=b"])
    assert config["test"] == "b"

    test_func(define=["test=c"])
    assert config["test"] == "c"

# Generated at 2022-06-12 07:07:53.514605
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy(foo, bar, define=None):
        return foo, bar

    assert dummy(foo="foo", bar="bar") == ("foo", "bar")
    assert dummy(foo="foo", bar="bar", define=["foo=bar"]) == ("bar", "bar")
    assert dummy(foo="foo", bar="bar", define=["foo=bar", "bar=foo"]) == ("bar", "foo")

# Generated at 2022-06-12 07:07:58.802030
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(key: str, value: str):
        config[key] = value

    test_func(key="key1", value="value1", define=["key2=value2"])
    assert config["key1"] == "value1"
    assert config["key2"] == "value2"

# Generated at 2022-06-12 07:08:05.076872
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(param1, param2, param3, define):
        pass

    wrap = overload_configuration(func)

    new_config = config.copy()
    new_config["param1"] = "value1"
    new_config["param2"] = "value2"

    wrap(param1="value1", param2="value2", param3="value3", define=["param1=value1", "param2=value2"])

    assert config == new_config

# Generated at 2022-06-12 07:08:07.443583
# Unit test for function current_commit_parser
def test_current_commit_parser():
    import semantic_release.commit_parser  # noqa

    assert current_commit_parser() == semantic_release.commit_parser.parse_message

# Generated at 2022-06-12 07:08:14.937322
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test function defined here
    # to avoid side effect on other tests
    @overload_configuration
    def dummy_func():
        return config["package_name"]

    # Construct a user defined package name
    config["package_name"] = "custom_package"
    # Test that the user defined package name is used
    assert dummy_func() == "custom_package"
    # Test that a new parametere is loaded
    custom_param = "custom_param"
    new_config = dummy_func(define=[f"defined={custom_param}"])
    assert new_config == custom_param

# Generated at 2022-06-12 07:08:18.656470
# Unit test for function current_commit_parser
def test_current_commit_parser():
    expected = "vermin.parser.parse"
    config["commit_parser"] = expected
    result = current_commit_parser()
    assert result is not None
    assert result.__name__ == expected.split(".")[-1]

# Generated at 2022-06-12 07:08:26.112532
# Unit test for function overload_configuration
def test_overload_configuration():
    # Scenario 1: Overload variables defined in config file
    @overload_configuration
    def overload1(config_str):
        if config_str == "True":
            return True
        return False

    assert overload1(config_str="False", define=["config_str=True"])

    # Scenario 2: Do not overload variables defined in config file
    @overload_configuration
    def overload2(config_str):
        if config_str == "True":
            return True
        return False

    assert not overload2(config_str="False")

# Generated at 2022-06-12 07:08:43.125253
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def check_overload(define=None):
        # We check the config in a separate function, so that if overload_configuration
        # is defined as a class decorator, the overload is not pre-triggered.
        assert "dry_run" in config
        assert "commit_parser" in config
        assert "changelog_components" in config
        assert "changelog_capitalize" in config
        assert "changelog_scope" in config
        assert "check_build_status" in config
        assert "commit_version_number" in config
        assert "patch_without_tag" in config
        assert "major_on_zero" in config
        assert "remove_dist" in config
        assert "upload_to_pypi" in config
        assert "upload_to_release"

# Generated at 2022-06-12 07:08:45.252644
# Unit test for function overload_configuration
def test_overload_configuration():
    from .main import Plugin

    plugin = Plugin()
    assert plugin.name == "Semantic Release"

# Generated at 2022-06-12 07:08:49.058627
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog_components.issues_closed,
        semantic_release.changelog_components.pull_requests_merged,
        semantic_release.changelog_components.changes_committed,
    ]

# Generated at 2022-06-12 07:08:55.270975
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import article, breaking

    setup_cfg = """
    [semantic_release]
    changelog_components = semantic_release.changelog_components.article,semantic_release.changelog_components.breaking

    """

    with open("setup.cfg", "w") as setup_file:
        setup_file.write(setup_cfg)

    assert current_changelog_components() == [article, breaking]

    os.remove("setup.cfg")

# Generated at 2022-06-12 07:09:01.506935
# Unit test for function overload_configuration
def test_overload_configuration():
    def dummy_fun(arg):
        return arg

    decorated_fun = overload_configuration(dummy_fun)
    assert decorated_fun(1) == 1
    assert decorated_fun(arg=2) == 2
    assert decorated_fun(arg=2, define=["key=value"]) == 2
    assert decorated_fun(arg=2, define=["key=value", "key1=value1"]) == 2
    assert config["key"] == "value"
    assert config["key1"] == "value1"

# Generated at 2022-06-12 07:09:07.277235
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the decorator overload_configuration
    """
    assert config["major_on_zero"] == True

    @overload_configuration
    def test_function(**kwargs):
        return config["major_on_zero"]

    assert test_function(define="major_on_zero=False") == False
    assert config["major_on_zero"] == True

# Generated at 2022-06-12 07:09:11.675697
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_func(define=["plugin={plugin_name}"]):
        return config

    config = my_func()
    assert config["plugin"] == "{plugin_name}"

# Generated at 2022-06-12 07:09:22.211020
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration
    """

    init_config = dict(config)

    @overload_configuration
    def func(define):
        pass

    # Test
    func(define=[])
    assert config == init_config

    # Test
    func(define=["foo=bar"])
    assert config["foo"] == "bar"
    assert config == {"foo": "bar"}

    # Test
    func(define=["foo=bar", "hello=world"])
    assert config["foo"] == "bar"
    assert config["hello"] == "world"
    assert config == {"foo": "bar", "hello": "world"}

    # Test
    func(define=["foo", "hello=world"])
    assert config["foo"] == "bar"
    assert config["hello"] == "world"
   

# Generated at 2022-06-12 07:09:27.287322
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.data['changelog_components'] = "semantic_release.components.format_changelog,semantic_release.components.docs_changelog"
    assert current_changelog_components()[0].__name__ == "format_changelog"
    assert current_changelog_components()[1].__name__ == "docs_changelog"

# Generated at 2022-06-12 07:09:32.774868
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test current_changelog_components()."""
    config["changelog_components"] = "semantic_release.history.components.Dependencies"
    assert len(current_changelog_components()) == 1
    config["changelog_components"] = "semantic_release.history.components.Dependencies,semantic_release.history.components.Changelog"
    assert len(current_changelog_components()) == 2

# Generated at 2022-06-12 07:09:42.419669
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_message

    assert current_commit_parser() == parse_message

# Generated at 2022-06-12 07:09:50.720396
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(x):
        print(config.get("skip_publish"))

    # Case 0: no overload
    test(x="x")
    assert config.get("skip_publish") is False

    # Case 1: defined key in config, no overload
    config["skip_publish"] = True
    test(x="x")
    assert config.get("skip_publish") is True

    # Case 2: defined key in config, overload
    test(x="x", define=["skip_publish=False"])
    assert config.get("skip_publish") is False

    # Case 3: not defined key in config, overload
    test(x="x", define=["a=b"])
    assert config.get("a") == "b"

# Generated at 2022-06-12 07:09:55.853384
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}

    @overload_configuration
    def function_to_be_tested(*args, **kwargs):
        # Here, we do nothing. This is a mock function.
        pass

    # We define two config parameters
    function_to_be_tested(define=["param1=value1", "param2=value2"])

    assert config["param1"] == "value1"

    assert config["param2"] == "value2"



# Generated at 2022-06-12 07:10:00.530329
# Unit test for function overload_configuration
def test_overload_configuration():
    def f(define):
        return True
    new_func = overload_configuration(f)

    # Test if it returns True as expected
    assert new_func(define=["commit_parser=new_parser"])

    # Test if it changes the configuration as expected
    assert config.get("commit_parser") == "new_parser"

# Generated at 2022-06-12 07:10:03.404145
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.tag,semantic_release.changelog_components.issue,semantic_release.changelog_components.note"
    funcs = current_changelog_components()
    assert len(funcs) == 3
    assert funcs[0].__name__ == "tag"
    assert funcs[1].__name__ == "issue"
    assert funcs[2].__name__ == "note"
    config.pop("changelog_components")



# Generated at 2022-06-12 07:10:05.361223
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser"""
    assert current_commit_parser()

# Generated at 2022-06-12 07:10:09.639869
# Unit test for function overload_configuration
def test_overload_configuration():
    config["defineTest"] = "InitialValue"

    @overload_configuration
    def test_function(define=None):
        return config.get("defineTest")

    assert test_function() == "InitialValue"
    assert test_function(define=["defineTest=ChangeValue"]) == "ChangeValue"

# Generated at 2022-06-12 07:10:15.557501
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def add_param(**kwargs):
        return kwargs

    assert add_param(a=1, b=2, define=["c=3"])["c"] == "3"
    assert config["c"] == "3"

# Generated at 2022-06-12 07:10:17.138272
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog
    components = current_changelog_components()
    assert components == [semantic_release.changelog.header, semantic_release.changelog.components]

# Generated at 2022-06-12 07:10:20.293926
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(test_param, define=None):
        pass
    test_function(1, define=["test=foo", "test2=bar"])
    assert "test" in config and "test2" in config

# Generated at 2022-06-12 07:10:38.257503
# Unit test for function overload_configuration
def test_overload_configuration():
    from .__main__ import main

    class Config(object):
        def get(self, _, __=None):
            return ""

        def __getitem__(self, key):
            return ""

    config.update(Config())


    @overload_configuration
    def func():
        pass

    # Without any config, everything should be ok
    func()

    # With some config, it should be ok
    func(define=["user_name=py1", "password=py2"])

    # With some invalid config, it should throw an exception
    try:
        func(define=["user name=py1", "password=py2"])
        assert False
    except SystemExit:
        pass

# Generated at 2022-06-12 07:10:47.262969
# Unit test for function overload_configuration
def test_overload_configuration():
    """This tests the overload_configuration decorator"""

    # We test the decorator on a simple mock function
    @overload_configuration
    def mock_function(define=None):
        return config

    # First we test without passing anything
    assert mock_function() == {}

    # Then we test with a single overload with a "=" sign
    assert mock_function(define=["foo=bar"]) == {"foo": "bar"}

    # Then we test with a multiple overloads with a "=" sign
    assert mock_function(define=["foo=bar", "bar=foo"]) == {"foo": "bar", "bar": "foo"}

    # Then we test with a single overload without a "=" sign
    assert mock_function(define=["foo"]) == {"foo": None}

    # Then we test with a multiple overloads without a

# Generated at 2022-06-12 07:10:47.777246
# Unit test for function current_changelog_components
def test_current_changelog_components():
    pass

# Generated at 2022-06-12 07:10:50.624821
# Unit test for function overload_configuration
def test_overload_configuration():
    def test(define=None):
        pass

    assert len(config.keys()) == 0
    test(define=["a=b", "c=d"])
    assert config["a"] == "b"
    assert config["c"] == "d"

