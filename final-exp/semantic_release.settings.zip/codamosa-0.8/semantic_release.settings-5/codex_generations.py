

# Generated at 2022-06-12 07:00:59.260101
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = 4
    @overload_configuration
    def test(define = None):
        return config["test"]
    assert test() == 4
    assert test(define=["test=42"]) == 42
    assert test(define=["test=\"my test\""]) == "my test"
    config.pop("test")



# Generated at 2022-06-12 07:01:05.626733
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def config_function(parameter):
        return config.get(parameter)

    assert config_function("release_branch_pattern") == "beta"
    assert config_function("release_branch_pattern", define=["release_branch_pattern=alpha"]) == "alpha"
    assert config_function("release_branch_pattern", define=["release_branch_pattern=alpha", "test=test"]) == "alpha"

# Generated at 2022-06-12 07:01:17.735369
# Unit test for function overload_configuration
def test_overload_configuration():
    import sys

    class FooClass:
        @overload_configuration
        def foo_dummy(self, define=None):
            return

    foo_obj = FooClass()
    foo_obj.foo_dummy(["hello=fred"])
    assert config.get("hello", "nope") == "fred"
    del foo_obj

    def foo_dummy(define=None):
        return

    foo_dummy(["goodbye=fred"])
    assert config.get("goodbye", "nope") == "fred"

    sys.modules[__name__].foo_dummy = foo_dummy
    foo_obj = FooClass()
    foo_obj.foo_dummy(["hello=fred"])
    assert config.get("hello", "nope") == "fred"
    del foo_obj



# Generated at 2022-06-12 07:01:29.409428
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert(current_changelog_components())

# Generated at 2022-06-12 07:01:30.968487
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        current_commit_parser()
    except ImproperConfigurationError:
        return False
    return True

# Generated at 2022-06-12 07:01:38.177123
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import run_cli
    from .config import current_commit_parser
    from .errors import ImproperConfigurationError
    from .utils import get_commit, is_prerelease, get_version

    def custom_commit_parser(commit):
        return "release" in commit["message"]

    def custom_version(old_version, prerelease):
        return "10.0"

    commit = get_commit()
    old_version = get_version()
    prerelease = is_prerelease()

    # Set default commit_parser
    config["commit_parser"] = "semantic_release.commit_parser.default_semantic_release_commits"

    # Check with default commit_parser
    assert (
        current_commit_parser()(commit) == False
    ), "Default commit parser do not detect the release message"

    #

# Generated at 2022-06-12 07:01:46.207004
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def get_config(config_key):
        return config[config_key]

    # No overload
    assert get_config("shall_be_unchanged") == config["shall_be_unchanged"]

    # First overload
    assert get_config("shall_be_overloaded", define=["shall_be_overloaded=toto"]) == "toto"

    # Second overload
    assert get_config("shall_be_overloaded", define=["shall_be_overloaded=tata"]) == "tata"

# Generated at 2022-06-12 07:01:49.157390
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that we can overload some configs
    """

    @overload_configuration
    def add(a, b):
        return a + config.get("myconfig", 0) + b

    assert add(1, 2, define=["myconfig=3"]) == 6

# Generated at 2022-06-12 07:01:52.395948
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for function current_commit_parser
    """
    print("test_current_commit_parser")
    assert callable(current_commit_parser())



# Generated at 2022-06-12 07:01:59.105155
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import create_parser
    import argparse
    parser = create_parser()
    argv = [
        "release",
        "major",
        "--define",
        "tag_name='%(version)s'",
        "--define",
        "tag_name='%(new_version)s'",
    ]
    parsed_args = parser.parse_args(argv)
    assert config["tag_name"] == "%(new_version)s"

# Generated at 2022-06-12 07:02:14.958816
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator overload_configuration behaves as expected
    """
    @overload_configuration
    def simple_function(define=None):
        return

    # The decorator should not edit the config dict
    simple_function()
    assert config is _config()

    # The decorator should not edit the config dict
    simple_function(define=["release_branch=next"])
    assert config is _config()

    # The decorator should edit the config dict
    simple_function(define=["fart=smell"])
    assert "fart" in config

# Generated at 2022-06-12 07:02:23.157100
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Overloaded value takes precedence over default value
    """
    default_value = "default"
    overloaded_value = "overloaded"
    config["overloaded"] = default_value


    @overload_configuration
    def get_value(value=config["overloaded"]):
        return value

    assert get_value(
        define=["overloaded=" + overloaded_value]
    ) == overloaded_value
    assert get_value() == default_value

# Generated at 2022-06-12 07:02:31.514063
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    - Check that the overload works for a boolean and an int
    """
    import collections

    @overload_configuration
    def test(param, define=None):
        return config

    assert test(param=True, define=["remove_dist=True"])["remove_dist"]

    assert test(param=True, define=["local_config.path=tests"])["local_config.path"] == "tests"

    assert (
        test(param=True, define=["plugins[0]=semantic_release.hvcs.git.git_push"])
        ["plugins[0]"]
        == "semantic_release.hvcs.git.git_push"
    )

# Generated at 2022-06-12 07:02:36.303631
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "hello"

    @overload_configuration
    def f(define):
        return config

    assert f(define="test=world")["test"] == "world"
    assert f(define="test2=world2")["test"] == "world"
    assert f(define="test2=world2")["test2"] == "world2"

# Generated at 2022-06-12 07:02:42.224649
# Unit test for function overload_configuration
def test_overload_configuration():
    import inspect

    # make sure decorator is not part of function definition
    assert "overload_configuration" not in inspect.getsource(overload_configuration)

    def func(param1, define=None):
        return param1

    func = overload_configuration(func)

    # make sure decorator was added
    assert "overload_configuration" in inspect.getsource(func)

    assert func(1, define=["key=value"]) == 1
    assert config["key"] == "value"

    # make sure function can still be called normally
    assert func(2) == 2

    # make sure undefined parameters don't cause problems
    assert func(3, define=["key1=value1", "key2=value2"]) == 3
    assert config["key"] == "value"

# Generated at 2022-06-12 07:02:43.819893
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-12 07:02:48.063546
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(*args, **kwargs):
        return config

    origin = config.copy()
    assert test() == origin
    assert test(define=["foo=bar"])["foo"] == "bar"
    assert test() == origin

# Generated at 2022-06-12 07:02:57.619870
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test overload_configuration decorator"""
    def a_function(param1, param2, param3):
        return param1, param2, param3
    assert a_function("1", "2", "3") == ("1", "2", "3")
    assert overload_configuration(a_function)("1", "2", "3") == ("1", "2", "3")
    assert overload_configuration(a_function)("1", "2", "3", define=None) == ("1", "2", "3")
    assert overload_configuration(a_function)("1", "2", "3", define=["use_release=False"]) == ("1", "2", "3")
    assert config["use_release"] == "False"

# Generated at 2022-06-12 07:03:02.679130
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(a):
        pass

    f(a=1)
    assert config["plugin_config"] == ""

    f(a=1, define=("a=2", "b=3"))
    assert config["a"] == "2"
    assert config["b"] == "3"

# Generated at 2022-06-12 07:03:04.213910
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())



# Generated at 2022-06-12 07:03:16.389844
# Unit test for function overload_configuration
def test_overload_configuration():
    '''Test "overload_configuration" decorator.'''
    import inspect
    import pytest
    from .utils import Config

    config = Config(CONFIG=dict(foo='foo', bar='bar', baz='baz'))
    config.foo = 'foo'
    config.bar = 'bar'
    config.baz = 'baz'

    @overload_configuration
    def function_to_test(config, *args, **kwargs):
        if "define" in kwargs:
            return kwargs["define"]

    # decorator with no overloads
    assert function_to_test(config, []) == []
    assert config.foo == "foo"
    assert config.bar == "bar"
    assert config.baz == "baz"

    # decorator with overloads

# Generated at 2022-06-12 07:03:19.631233
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import config
    from semantic_release.cli import get_arguments

    get_arguments([None, "--define", "custom_param=my_value"])
    assert config.get("custom_param") == "my_value"

# Generated at 2022-06-12 07:03:21.911339
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy_function(define=[]):
        return define

    assert dummy_function(define=["new_key=new_value"]) is not None

# Generated at 2022-06-12 07:03:31.100643
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test the current_changelog_components function.
    This is necessary because the user could configure an
    unknown or invalid changelog_components.
    """
    import semantic_release.utils
    from semantic_release.plugins import (
        IssuePlugin,
        PullRequestPlugin,
        PythonPlugin,
        RstChangeLogPlugin,
    )

    with semantic_release.utils.cd(
        os.path.dirname(os.path.dirname(__file__))
    ):

        # Get the default list of changelog_components
        components = current_changelog_components()
        assert IssuePlugin in components
        assert PullRequestPlugin in components
        assert PythonPlugin in components
        assert RstChangeLogPlugin in components

        # Configure an invalid changelog_components in setup.cfg

# Generated at 2022-06-12 07:03:37.141020
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import get_changelog_components

    # Overload some value for the unit testing
    config["changelog_components"] = "semantic_release.changelog.components.parse_pr_title"

    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == get_changelog_components()[0]



# Generated at 2022-06-12 07:03:41.172787
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(define=["a=b"]):
        return config.get("a")
    assert f() == "b"

    @overload_configuration
    def f(define=["c=d"]):
        return config.get("c")
    assert f() == "d"

# Generated at 2022-06-12 07:03:48.057617
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = _config()
    assert test_config.get("define") is None
    assert test_config.get("repository_type") == "git"

    @overload_configuration
    def func():
        assert test_config.get("define") is None
        assert test_config.get("repository_type") == "git"

    func()
    assert test_config.get("define") is None
    assert test_config.get("repository_type") == "git"

    @overload_configuration
    def func2(define=["repository_type=svn", "define=foo=bar"]):
        assert test_config.get("define") == "foo=bar"
        assert test_config.get("repository_type") == "svn"

    func2()
   

# Generated at 2022-06-12 07:03:53.924010
# Unit test for function overload_configuration
def test_overload_configuration():
    # The test overwrites the value of the "package_name" key
    @overload_configuration
    def test_function(define):
        pass

    test_function(define=["package_name=my_package_name"])

    assert config["package_name"] == "my_package_name", "The value of the " \
        "key 'package_name' should be overwritten."

# Generated at 2022-06-12 07:03:57.387994
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_overloading"] = "should edit"
    test_function = lambda define: None
    test_function = overload_configuration(test_function)
    test_function(define=["test_overloading=modified"])
    assert config["test_overloading"] == "modified"

# Generated at 2022-06-12 07:04:03.008105
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import tempfile
    import configparser
    from semantic_release.settings import current_changelog_components
    from semantic_release import generate_changelog

    try:
        with tempfile.NamedTemporaryFile(mode="w+") as handle:
            handle.write("[semantic_release]\nchangelog_components = tests.test_settings.test_component\n")
            handle.seek(0)
            configparser.ConfigParser().read_file(handle)
            assert current_changelog_components() == [generate_changelog.test_component]
    except ModuleNotFoundError:
        # We're not running from source, so there is no
        # semantic_release.generate_changelog
        pass

# Generated at 2022-06-12 07:04:16.029514
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def argument():
        return config

    # Test that the function returns the current config
    assert argument() == _config()
    # Test that the function overloads "config" correctly
    assert argument(define=["foo=bar"]) == {
        **_config(),
        "foo": "bar",
    }

# Generated at 2022-06-12 07:04:21.430868
# Unit test for function overload_configuration
def test_overload_configuration():
    """Tests if the decorator overloads the config correctly."""

    # A function to be decorated
    def f(foo: str) -> None:
        return foo

    # Assert initial value of config
    assert config["verbose"] is False

    # Test if the decorator works
    @overload_configuration
    def decorated_f(define: str, foo: str) -> None:
        return f(foo)

    decorated_f(define="verbose=True", foo="bar")
    assert config["verbose"] is True

# Generated at 2022-06-12 07:04:29.626910
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func_to_test(x, y, z, define=None):
        """Test function"""
        return x + y + z

    old_config = config.copy()

    assert func_to_test(1, 2, 3, define=[]) == 6
    assert config == old_config

    assert (
        func_to_test(1, 2, 3, define=["release.error_on_dirty_workspace=False"])
        == 6
    )
    assert config["release.error_on_dirty_workspace"] == "False"

    assert (
        func_to_test(1, 2, 3, define=["release.error_on_dirty_workspace=True"])
        == 6
    )

# Generated at 2022-06-12 07:04:32.170704
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.components.commit_parser"
    assert len(current_changelog_components()) == 1


# Unit test to check that the setting 'commit_parser'

# Generated at 2022-06-12 07:04:35.441701
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import main

    main(["config"], define=["a=toto", "b=titi"])
    assert config["a"] == "toto"
    assert config["b"] == "titi"

# Generated at 2022-06-12 07:04:44.160522
# Unit test for function overload_configuration
def test_overload_configuration():
    # If a config value was not defined, it will get a default value.
    assert config["version_variable"] == "__version__"

    # When a config value is defined in the cli, it will be overriden
    @overload_configuration
    def overload_test(define):
        return config["version_variable"]

    # If a value is passed in the standard style
    assert overload_test(define="version_variable=__new_version__") == "__new_version__"

    # If a value is passed with just the name (useful for booleans)
    assert overload_test(define="changelog_capitalize") == True

# Generated at 2022-06-12 07:04:45.090097
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()



# Generated at 2022-06-12 07:04:53.990943
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(*args, **kwargs):
        return kwargs

    config["old"] = "old"

    assert func() == {}
    assert config["old"] == "old"

    assert func(define=["new=new"]) == {}
    assert config["old"] == "old"
    assert config["new"] == "new"

    assert func(define=["new=this is new", "other=other", "other=overwritten"]) == {}
    assert config["old"] == "old"
    assert config["new"] == "this is new"
    assert config["other"] == "overwritten"

# Generated at 2022-06-12 07:04:58.276081
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import _get_current_version

    def get_current_version(*args, **kwargs):
        if "version" in config:
            return config["version"]
        return _get_current_version(*args, **kwargs)

    overload_configuration(get_current_version)(define=["version=0.0.0"])
    assert config["version"] == "0.0.0"

# Generated at 2022-06-12 07:05:02.692297
# Unit test for function overload_configuration
def test_overload_configuration():
    with overload_configuration(lambda x: x):
        config["version_variable"] = "current_version"
        config["new_version"] = "new_version"

    assert config["version_variable"] == "new_version"
    assert config["new_version"] == "new_version"

# Generated at 2022-06-12 07:05:17.973763
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(a, b):
        return a, b

    assert test_func(1, 2) == (1, 2)
    assert test_func(1, 2, define=["a=b"]) == (1, 2)
    assert test_func(1, 2, define=["a=b", "c=d"]) == (1, 2)
    assert test_func(1, 2, define=["a=b", "c=d", "d=e"]) == (1, 2)

# Generated at 2022-06-12 07:05:27.662936
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config["hello"] = "world"
    config["value"] = 1
    func = overload_configuration(lambda x, y, z=2, define=None: (x, y, z))
    assert func("A", "B") == ("A", "B", 2)
    assert func("A", "B", define=[]) == ("A", "B", 2)
    assert func("A", "B", define=["hello=mars"]) == ("A", "B", 2)
    assert config["hello"] == "mars"
    assert func("A", "B", define=["value=2", "hello=moon"]) == ("A", "B", 2)
    assert config["hello"] == "moon"
    assert config["value"] == 2
    # Invalid arguments are ignored

# Generated at 2022-06-12 07:05:33.987960
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    The function test_overload_configuration tests whether the decorator
    overload_configuration() works properly or not
    """
    @overload_configuration
    def some_function():
        """
        This function is mocked in order to test the decorator.
        """
        pass

    assert config.get("include_files") == ".*"

    some_function(define=["include_files=.*setup.py"])

    assert config.get("include_files") == ".*setup.py"

# Generated at 2022-06-12 07:05:37.099470
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert config["changelog_components"] == "semantic_release.changelog_components.components"
    assert current_changelog_components()[0].__name__ == "components"

# Generated at 2022-06-12 07:05:44.748451
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(lambda define: define)
    func(define=["test=test"])
    assert config["test"] == "test"
    func(define=["test=value"])
    assert config["test"] == "value"
    func(define=["test=test", "foo=bar"])
    assert config["test"] == "test"
    assert config["foo"] == "bar"
    func(define=["foo=bar", "test=test"])
    assert config["test"] == "test"
    assert config["foo"] == "bar"


# Generated at 2022-06-12 07:05:54.359620
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test the behavior of overload_configuration decorator

    # Create a mock of the config object to be used by overload_configuration
    test_config = {
        "string": "Value",
        "int": 123,
        "float": 1.23,
        "bool": True,
        "list": ["a", "b", "c"],
    }


    @overload_configuration
    def mock_function(define):
        """This function returns the mock config object.
        """
        return test_config


    # Verify that the initial values are left unchanged
    assert mock_function(define=["string=hello"])["string"] == "Value"
    assert mock_function(define=["int=0"])["int"] == 123
    assert mock_function(define=["float=0.00"])["float"] == 1

# Generated at 2022-06-12 07:05:58.632408
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(**kwargs):
        return config.get("test_key")

    assert test_function() == _config()["test_key"]
    assert test_function(define=["test_key=test_value"]) == "test_value"



# Generated at 2022-06-12 07:06:03.193229
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["name=default"])
    assert config["name"] == "default"
    test_func(define=["name=override"])
    assert config["name"] == "override"



# Generated at 2022-06-12 07:06:10.540118
# Unit test for function overload_configuration
def test_overload_configuration():
    assert len(config) > 0

    @overload_configuration
    def overloaded_function(name, define=None):
        return name

    # Overload configuration for current key
    for key in config:
        if key != "upload_to_releases":
            assert config[key] == overloaded_function(key, define=[key + "=toto"])[key]

    # Overload configuration for new key
    key = "new_config"
    assert overloaded_function(key, define=[key + "=toto"])[key] == "toto"

# Generated at 2022-06-12 07:06:17.981596
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test with a single pair of key/value
    @overload_configuration
    def test_function(define=None):
        return

    test_function(define=["author=my_author"])
    assert config["author"] == "my_author"

    # Test with multiple pairs of key/value
    @overload_configuration
    def test_function(define=None):
        return

    test_function(define=["author=my_author", "version=my_version"])
    assert config["author"] == "my_author"
    assert config["version"] == "my_version"

    # Test with no pairs of key/value
    @overload_configuration
    def test_function(define=None):
        return

    test_function()
    assert config["author"] == "my_author"

# Generated at 2022-06-12 07:06:35.713129
# Unit test for function overload_configuration
def test_overload_configuration():
    good_config_test = os.path.join(os.path.dirname(__file__), "test_config.cfg")
    bad_config_test = os.path.join(os.path.dirname(__file__), "test_bad_config.cfg")
    good_pyproject_test = os.path.join(os.path.dirname(__file__), "test_pyproject.toml")
    bad_pyproject_test = os.path.join(os.path.dirname(__file__), "test_bad_pyproject.toml")


# Generated at 2022-06-12 07:06:40.494878
# Unit test for function overload_configuration
def test_overload_configuration():
    no_configuration = config["changelog_components"]
    modified_configuration = "tests.config_for_tests.changelog_components"
    assert no_configuration != modified_configuration

    @overload_configuration
    def test_func(define):
        return config["changelog_components"]

    assert test_func(define=["changelog_components=" + modified_configuration]) is not None
    assert test_func(define=["changelog_components=" + modified_configuration]) == modified_configuration

# Generated at 2022-06-12 07:06:47.787461
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()
    config["foo"] = "bar"

    @overload_configuration
    def run(*args):
        return config

    assert run() == {"foo": "bar"}
    assert run(define=["foo=baz"]) == {"foo": "baz"}
    assert run(define=["foo=baz", "baz=bar"]) == {"foo": "baz", "baz": "bar"}



# Generated at 2022-06-12 07:06:58.012922
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Assert if the function current_changelog_components works in case
    the setup.cfg file is not empty.
    """

    path = os.path.join(os.path.dirname(__file__), "defaults.cfg")
    parser = configparser.ConfigParser()
    parser.read(path)

    component_paths = parser.get("semantic_release", "changelog_components").split(",")
    components = list()

    for path in component_paths:
        parts = path.split(".")
        module = ".".join(parts[:-1])
        components.append(getattr(__import__(module, fromlist=[parts[-1]]), parts[-1]))

    assert current_changelog_components() == components

# Generated at 2022-06-12 07:07:00.370384
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser().__name__ == "parse_commits"

# Generated at 2022-06-12 07:07:08.057057
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import main

    os.environ["SMEARGLE_USERNAME"] = "smeagol"
    os.environ["SMEARGLE_PASSWORD"] = "precious"

    main(["version"], define=["upload_to_pypi=true", "username=me"])
    assert config["username"] == "me"
    assert config["upload_to_pypi"] is True

    main(["version"], define=["password=yes"])
    assert config["username"] == "smeagol"
    assert config["password"] == "yes"

# Generated at 2022-06-12 07:07:14.702643
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config['commit_parser'] = 'semantic_release.commit_parser:parse_commits'
    parser = current_commit_parser()
    assert parser.__module__ == 'semantic_release.commit_parser'
    assert parser.__name__ == 'parse_commits'

# Generated at 2022-06-12 07:07:27.038919
# Unit test for function overload_configuration
def test_overload_configuration():
    """Ensure all works as expected"""

    original_changelog_components = config.get("changelog_components")
    original_changelog_capitalize = config.get("changelog_capitalize")

    def dummy_func():
        assert config.get("changelog_components") == "tests.test_changelog_components.test_component_1"
        assert config.get("changelog_capitalize") is False
        assert config.get("my_special_config") == "my_special_value"

    dummy_func = overload_configuration(dummy_func)

# Generated at 2022-06-12 07:07:29.818487
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog import has_bug_fix_component, has_breaking_change_component
    assert current_changelog_components() == [
        has_bug_fix_component,
        has_breaking_change_component,
    ]

# Generated at 2022-06-12 07:07:36.121828
# Unit test for function overload_configuration
def test_overload_configuration():
    config['commit_message_footer'] = "old_footer"
    @overload_configuration
    def test(define: List[str]):
        return config['commit_message_footer']

    assert test(define=None) == "old_footer"
    assert test(define=["commit_message_footer=new_footer"]) == "new_footer"

# Generated at 2022-06-12 07:07:51.094330
# Unit test for function overload_configuration
def test_overload_configuration():
    def foo(bar, define=None):
        if define == ["my_key=my_value"]:
            return {"bar": bar, "my_key": "my_value"}

    decorated = overload_configuration(foo)

    result = decorated("baz", define=["my_key=my_value"])

    assert result == {"bar": "baz", "my_key": "my_value"}

# Generated at 2022-06-12 07:07:59.325263
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog.render import (
        commit_changes,
        commit_types,
        create_bullet,
        create_release_title,
        render_body,
        render_head,
    )
    from semantic_release.changelog.update import update_changelog

    assert (
        current_changelog_components()
        == [
            commit_changes,
            commit_types,
            create_bullet,
            create_release_title,
            render_body,
            render_head,
            update_changelog,
        ]
    )

# Generated at 2022-06-12 07:08:07.322663
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def printed_configuration(output):
        for key, value in config.items():
            output.append(key + ": " + str(value))

    output = []
    config["test_key_1"] = 1
    config["test_key_2"] = "2"
    printed_configuration(output)
    assert len(output) == len(config)
    assert output[0] == "test_key_1: 1"
    assert output[1] == "test_key_2: 2"

    # Overload test_key_1.
    config["test_key_1"] = "1"
    printed_configuration(output, ["test_key_1=1"])
    assert len(output) == len(config)

# Generated at 2022-06-12 07:08:17.731405
# Unit test for function overload_configuration
def test_overload_configuration():
    """A simple unit test to check that the configuration is correct"""

    @overload_configuration
    def overloaded_function(value1, value2, define=[]):
        assert config["version_variable_name"] == "__version__"
        assert config["changelog_release_levels"] == "major,minor,patch"
        assert config["changelog_base_url"] == "https://my-website.com"
        assert config["changelog_capitalize"] is False
        assert config["changelog_scope"] is True
        assert config["changelog_commit_url"] == "https://my-website.com/commit/{sha}"
        assert config["check_build_status"] is True
        assert config["commit_parser"] == "semantic_release.commit_parsers.default_parser"
       

# Generated at 2022-06-12 07:08:25.163923
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(x, y, z):
        pass

    func(1, 2, 3)
    assert config["base_branch"] == "master"
    assert config["check_build_status"] is True
    assert config["commit_parser"].endswith("parse_message")
    func(x=1, y=2, z=3, define=["check_build_status=false", "base_branch=feature"])
    assert config["base_branch"] == "feature"
    assert config["check_build_status"] is False

# Generated at 2022-06-12 07:08:30.726433
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function(param1, param2=None, define=None):
        return param1, param2

    with overload_configuration(test_function):
        param1, param2 = test_function("a", "b", define=["a=b"])
    assert param1 == "a"
    assert param2 == "b"
    assert config["a"] == "b"

# Generated at 2022-06-12 07:08:35.673992
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test1"] = False
    config["test2"] = True
    config["test3"] = "foo"

    @overload_configuration
    def ret(define: List[str]):
        return config

    assert ret(define=["test1=True"])["test1"]
    assert not ret(define=["test2=False"])["test2"]
    assert ret(define=["test3=bar"])["test3"] == "bar"

# Generated at 2022-06-12 07:08:41.578795
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the overloaded configuration is correctly set"""

    @overload_configuration
    def dummy_func(a, b, c=None, **kwargs):
        return (a, b, c)

    assert dummy_func(1, 2) == (1, 2, None)
    assert dummy_func(1, 2, c=3) == (1, 2, 3)
    assert dummy_func(1, 2, define=["c=3"]) == (1, 2, "3")

# Generated at 2022-06-12 07:08:44.274901
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for function overload_configuration"""

    @overload_configuration
    def function():
        pass

    assert function(define=["name=value"]) is None
    assert isinstance(config["name"], str)
    assert config["name"] == "value"

# Generated at 2022-06-12 07:08:49.922149
# Unit test for function overload_configuration
def test_overload_configuration():
    class TestCls:
        @overload_configuration
        def test_func(self):
            print(config)

        @overload_configuration
        def test_func2(self, define):
            print(config)

    t = TestCls()
    t.test_func()
    config["test_overload"] = "false"
    t.test_func2(["test_overload=true"])
    assert config.get('test_overload') == 'true'

# Generated at 2022-06-12 07:09:05.108954
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()
    config["commit-parser"] = "semantic_release.commit_parser.default_parser"

    @overload_configuration
    def test(define=None):
        assert config["commit-parser"] == "semantic_release.commit_parser.default_parser"

    test(define=["commit-parser=test_commit_parser"])
    assert config["commit-parser"] == "test_commit_parser"
    config.clear()
    config["commit-parser"] = "semantic_release.commit_parser.default_parser"

    @overload_configuration
    def test(define=None):
        assert (
            config["commit-parser"]
            == "semantic_release.commit_parser.default_parser"
        )

    test()

# Generated at 2022-06-12 07:09:08.182219
# Unit test for function current_commit_parser
def test_current_commit_parser():
    parser = current_commit_parser()
    assert parser.__name__ == "parser"
    assert parser(
        "[0.1.2]\n* Minor change\n* Breaking change"
    ) == "Minor change\nBreaking change"

# Generated at 2022-06-12 07:09:12.105817
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function(hello):
        pass

    wrapper = overload_configuration(test_function)
    wrapper(hello="world", define=["test=test_value"])
    assert config["test"] == "test_value"

# Generated at 2022-06-12 07:09:18.413202
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []
    config["changelog_components"] = "semantic_release.commit_parser.parse"
    assert current_changelog_components() == [current_commit_parser()]
    config["changelog_components"] = "semantic_release.commit_parser.parse,spam,ham"
    assert current_changelog_components() == [current_commit_parser(), None, None]

# Generated at 2022-06-12 07:09:24.627554
# Unit test for function overload_configuration
def test_overload_configuration():
    import click

    @click.command()
    @click.argument("version")
    @click.option("--define", "-d", multiple=True)
    @overload_configuration
    def cli(version, define):
        print(version)

    runner = click.testing.CliRunner()
    result = runner.invoke(cli, ["--define", "test=test", "1.0"])
    assert result.exit_code == 0
    result = runner.invoke(cli, ["--define", "test=test", "1.0"])
    assert result.exit_code == 0
    assert result.output == "1.0\n"

# Generated at 2022-06-12 07:09:30.330375
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import (
        changelog_components,
        invalid_commit_message_component,
    )
    path = 'semantic_release.changelog.changelog_components'
    config.get('changelog_components') == path
    parser = current_changelog_components()
    assert parser == [changelog_components, invalid_commit_message_component]

# Generated at 2022-06-12 07:09:35.432850
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test if overload configuration is called properly when function
    is wrapped with @overload_configuration.
    """
    test_function = overload_configuration(lambda x: x)
    test_function(define = ["key1=value1", "key2=value2"])
    assert config.get("key1") == "value1"
    assert config.get("key2") == "value2"

# Generated at 2022-06-12 07:09:40.210547
# Unit test for function overload_configuration
def test_overload_configuration():
    config["commit_message"] = "Branch %(branch_name)s"

    # No change expected
    @overload_configuration
    def test_func(define):
        pass

    test_func(define=[])
    assert config["commit_message"] == "Branch %(branch_name)s"

    # Overload expected
    @overload_configuration
    def test_func2(define):
        pass

    test_func2(define=["commit_message=Branch %(branch)s"])
    assert config["commit_message"] == "Branch %(branch)s"

# Generated at 2022-06-12 07:09:41.061041
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-12 07:09:46.426561
# Unit test for function current_commit_parser
def test_current_commit_parser():
    try:
        assert current_commit_parser()
    except ImproperConfigurationError as error:
        """Ignore the error for tests because if the user doesn’t have the
        python-git package installed he won’t be able to set the commit_parser
        in his setup.cfg"""
        pass

# Generated at 2022-06-12 07:10:02.629398
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("repository_url") == "https://github.com/relekang/python-semantic-release-test"
    assert config.get("npm_publish") is False

    @overload_configuration
    def test_overload(define = None):
        if define is None:
            return
        for defined_param in define:
            pair = defined_param.split("=", maxsplit=1)
            assert config.get(pair[0]) == pair[1]

    test_overload(define=["repository_url=http://github.com/foo", "npm_publish=true"])

    assert config.get("repository_url") == "http://github.com/foo"
    assert config.get("npm_publish") is True



# Generated at 2022-06-12 07:10:09.447933
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.Summary,
        semantic_release.changelog.components.CommitList,
    ]

    config["changelog_components"] = "semantic_release.changelog.components.Summary"
    assert current_changelog_components() == [
        semantic_release.changelog.components.Summary,
    ]

# Generated at 2022-06-12 07:10:20.119697
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def retour():
        return config

    retour()

    assert len(config["plugins"]) == 0

    retour(define=["plugins=test1:test2"])
    assert config["plugins"] == "test1:test2"

    retour(define=["plugins=test3:test4"])
    assert config["plugins"] == "test3:test4"

    retour(define=["plugins=test5:test6", "define=test7:test8"])
    assert config["plugins"] == "test5:test6"

    retour(define=["plugins="])
    assert len(config["plugins"]) == 0

# Generated at 2022-06-12 07:10:30.134344
# Unit test for function overload_configuration
def test_overload_configuration():
    mock_config = {'name': 'semantic_release', 'version': '1.8.1'}

    @overload_configuration
    def func(config, param):
        return config

    param = "name=semantic_release"
    assert mock_config == func(config=mock_config, define=[param])

    param = "version=1.8.1"
    assert mock_config == func(config=mock_config, define=[param])

    param = "version=2.0.0"
    assert {**mock_config, **{'version': '2.0.0'}} == func(config=mock_config, define=[param])

    param = "version=2.0.0"
    param2 = "version=2.0.1"

# Generated at 2022-06-12 07:10:40.202219
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Middle line of this function simulates the environment variable
    # (os.environ) setting.
    os.environ["SEMANTIC_RELEASE_CHANGELOG_COMPONENTS"] = "semantic_release.changelog.components.Summary,path.to.component_1"
    # Import for the first time so that SEMANTIC_RELEASE_CHANGELOG_COMPONENTS is
    # considered for the first time.
    import semantic_release.settings
    semantic_release.settings.config = semantic_release.settings._config()
    assert len(semantic_release.settings.current_changelog_components()) == 2


# Generated at 2022-06-12 07:10:49.196062
# Unit test for function overload_configuration
def test_overload_configuration():
    test_config = {
        'first_key': 10,
        'second_key': 'a string'
    }

    def test_func(first_parameter, define=None):
        return first_parameter

    # test_func has not been decorated. test_config is not modified
    decorated_func = overload_configuration(test_func)
    assert decorated_func(test_config['first_key'], define=['second_key=22', 'third_key=3']) == test_config['first_key']
    assert test_config['first_key'] == 10
    assert test_config['second_key'] == 'a string'
    assert test_config.get("third_key") is None

    # test_func has been decorated. test_config is modified
    test_func = decorated_func
    test_func