

# Generated at 2022-06-12 07:00:57.986680
# Unit test for function overload_configuration
def test_overload_configuration():
    config["warning"] = "default"

    @overload_configuration
    def func(warning):
        return config["warning"]

    assert func(warning="overloaded") == "overloaded"
    assert func(warning="default") == "default"

# Generated at 2022-06-12 07:01:05.962773
# Unit test for function overload_configuration
def test_overload_configuration():

    def test_function(define=None):
        return config["token"], config["repository_url"]

    # It parses define attribute
    test_setting = [{"token": "github_token", "repository_url": "github_url"}]
    assert test_function(test_setting) == ("github_token", "github_url")

    # It parses define attribute when it is a list of string
    test_setting = ["token=github_token", "repository_url=github_url"]
    assert test_function(test_setting) == ("github_token", "github_url")

# Generated at 2022-06-12 07:01:18.123523
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("define") is None
    assert config.get("release_references_on_github") == "./github_references.py"

    @overload_configuration
    def config_overloaded(param, define=None):
        return config.get(param, None)

    assert config_overloaded("define") is None
    assert config_overloaded("release_references_on_github") == "./github_references.py"

    config_overloaded("define", define=["release_references_on_github=test_value"])
    assert config_overloaded("release_references_on_github") == "test_value"

    config_overloaded("define", define=["release_references_on_github=./github_references.py"])

# Generated at 2022-06-12 07:01:31.597344
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Test if it returns a list of callables"""
    config["changelog_components"] = "semantic_release.changelog.components.commit"
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-12 07:01:36.630430
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"

    @overload_configuration
    def dummy_print_config(test_config):
        print(test_config)

    dummy_print_config(test_config=config)
    assert config["foo"] == "bar"

    dummy_print_config(test_config=config, define=["foo=baz"])
    assert config["foo"] == "baz"

    dummy_print_config(test_config=config)
    assert config["foo"] == "baz"

# Generated at 2022-06-12 07:01:40.799909
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function():
        pass

    function(define=["foo=bar", "bar=baz"])
    assert config["foo"] == "bar"
    assert config["bar"] == "baz"

# Generated at 2022-06-12 07:01:47.233454
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for function overload_configuration.
    This decorator allows to overload the "config" configparser in order
    to overload any value.
    """
    @overload_configuration
    def overloaded_function(define=None):
        return config

    assert overloaded_function() == config
    assert overloaded_function(define=["key1=value1", "key2=value2"]) == {**config, **{"key1": "value1", "key2": "value2"}}

# Generated at 2022-06-12 07:01:50.006589
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from . import default_commit_parser

    assert current_commit_parser() is default_commit_parser
    config["commit_parser"] = "semantic_release.commit_parser.default_commit_parser"
    assert current_commit_parser() is default_commit_parser



# Generated at 2022-06-12 07:01:58.361041
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test function overload_configuration

    Expected : add two key/value in config dict
    """
    config["test1"] = "None"
    config["test2"] = "None"

    @overload_configuration
    def func(**kwargs):
        pass

    func(
        define=[
            "test1=value1",
            "test2=value2",
        ]
    )
    assert config["test1"] == "value1"
    assert config["test2"] == "value2"

# Generated at 2022-06-12 07:02:03.603431
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def overload_configuration_test_func(
        param, define=None
    ):  # pylint: disable=unused-argument
        my_other_config = config.copy()
        return my_other_config

    # testing without overload
    assert overload_configuration_test_func("any_param") == config

    # testing with overload
    assert overload_configuration_test_func("any_param", define=["foo=bar"]) == {
        **config,
        "foo": "bar",
    }

# Generated at 2022-06-12 07:02:15.969429
# Unit test for function overload_configuration
def test_overload_configuration():
    # Create function
    @overload_configuration
    def param(a):
        return a

    # Check default value
    assert param("toto") == "toto"

    # Check overload_configuration function
    assert param("toto", define=["a=1"]) == "toto"
    assert config['a'] == '1'

# Generated at 2022-06-12 07:02:23.565689
# Unit test for function overload_configuration
def test_overload_configuration():
    from unittest.mock import Mock

    @overload_configuration
    def test_func(*args, **kwargs):
        # type: (anything, anything) -> anything
        pass

    mock = Mock()
    mock.return_value = True
    test_func.return_value = mock

    test_func(define=["key=value"])

    assert config.get("key") == "value"
    assert mock.called



# Generated at 2022-06-12 07:02:30.296864
# Unit test for function overload_configuration
def test_overload_configuration():
    # temp patch. It initialize the config
    config["changelog_components"] = "semantic_release.history.History"

    # This function only update the dict config with new values
    @overload_configuration
    def run_test_func(define):
        final_config = config.copy()
        return final_config

    # run the function with new parameters
    test_new_config = run_test_func(define=["changelog_components=test"])

    # assert that the value has been changed
    assert test_new_config["changelog_components"] == "test"

# Generated at 2022-06-12 07:02:39.466644
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .components import changelog_commit_parser
    from .components import comp1, comp2
    from .components import comp3

    from . import get_changelog_components

    # test 1: get the list of components
    components = current_changelog_components()
    assert len(components) == 3

    # test 2: use the list of components
    tested_components = get_changelog_components(components)
    assert len(tested_components) == 3

    # test 3: run the changelog_components
    # get the components

# Generated at 2022-06-12 07:02:43.650665
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "before"
    config_overloaded = {"test": "after"}

    @overload_configuration
    def test_function(define):
        # Check if config has been overloaded
        assert config == config_overloaded

    test_function(define=["test=after"])

# Generated at 2022-06-12 07:02:55.102988
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import semantic_release.changelog

    # This can be empty because nothing is defined in the config
    assert current_changelog_components() == []

    # Define one component
    config["changelog_components"] = "semantic_release.changelog.title"
    assert current_changelog_components() == [semantic_release.changelog.title]

    # Define three components
    config["changelog_components"] = "semantic_release.changelog.title,semantic_release.changelog.issue_number,semantic_release.changelog.unreleased_label"

# Generated at 2022-06-12 07:02:55.933994
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-12 07:03:01.369777
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(param1, param2):
        pass

    foo(param1="foo", param2="bar", define=["baz=qux", "quux=quuz"])

    assert config.get("baz") == "qux"
    assert config.get("quux") == "quuz"

# Generated at 2022-06-12 07:03:11.460975
# Unit test for function overload_configuration
def test_overload_configuration():
    config_original = config.copy()

    @overload_configuration
    def test_func1(foo):
        assert config == config_original

    @overload_configuration
    def test_func2(foo, define=None):
        assert config == config_original

    @overload_configuration
    def test_func3(foo, define=[]):
        assert config == config_original

    @overload_configuration
    def test_func4(foo, define=["foo=bar"]):
        assert config["foo"] == "bar"
        assert config["bar"] == "baz"

    @overload_configuration
    def test_func5(foo, define=["foo=bar,bar=baz"]):
        assert config["foo"] == "bar"
        assert config["bar"] == "baz"



# Generated at 2022-06-12 07:03:14.036688
# Unit test for function current_changelog_components
def test_current_changelog_components():

    @overload_configuration
    def current_changelog_components():
        """Return changelog components."""
        return config["changelog_components"]

    def test_components():
        return ("tests.unit.test_settings.components_func1",
                "tests.unit.test_settings.components_func2")

    config["changelog_components"] = test_components()
    result = current_changelog_components()
    assert len(result) == 2



# Generated at 2022-06-12 07:03:30.709100
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Delete configuration
    config.clear()

    # Import the default parser
    assert current_commit_parser()

    # Import a custom parser
    config["commit_parser"] = "semantic_release.commit_parser.custom"
    assert current_commit_parser()

    # Import a custom parser not existing
    config["commit_parser"] = "custom"
    assert current_commit_parser()

    # Import a custom module with the config
    config["commit_parser"] = "semantic_release.tests.test_helpers.config_test"
    assert config["commit_parser"]

    # Module not existing
    config["commit_parser"] = "semantic_release.custom"
    assert config["commit_parser"]

    # Parser not existing

# Generated at 2022-06-12 07:03:40.729543
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the decorator overload_configuration.
    """
    global config

    # Testing with a config with no key "define"
    config = dict()
    assert config == {}
    overload_configuration(test_overload_configuration)()
    assert config == {}

    # Testing with a good define key
    config = {"define": ["version=1.0.0", "name=semantic-release"]}
    assert config == {"define": ["version=1.0.0", "name=semantic-release"]}
    overload_configuration(test_overload_configuration)()
    assert config == {"definition": ["version=1.0.0", "name=semantic-release"]}
    assert config["version"] == "1.0.0"
    assert config["name"] == "semantic-release"



# Generated at 2022-06-12 07:03:44.325616
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(name, define=None):
        return config[name]

    func("major_on_zero", define="major_on_zero=true")
    assert func("major_on_zero")

    # Check that default value is not changed
    assert not config['major_on_zero']

# Generated at 2022-06-12 07:03:52.007699
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def fake_function(first_param, second_param, define=None):
        return (first_param, second_param)

    # Test fake_function without overloaded parameters
    assert fake_function("first", "second") == ("first", "second")

    # Test fake_function with overloaded parameters
    assert fake_function("first", "second", define=["param1=value1", "param2=value2"]) == ("first", "second")
    assert config["param1"] == "value1"
    assert config["param2"] == "value2"

# Generated at 2022-06-12 07:03:58.590976
# Unit test for function overload_configuration
def test_overload_configuration():
    # Define a class to test
    class Test:
        def __init__(self):
            self.value = False

        def func(self):
            self.value = True

    # Create a test object
    test = Test()

    # Get the decorated function
    decorated = overload_configuration(Test.func)

    # Test that the decorator does not change the behavior
    decorated(test)
    assert test.value is True

    # Test that overload_configuration actually overloads the configuration
    decorated(test, define=["key=value"])
    assert config["key"] == "value"

# Generated at 2022-06-12 07:04:01.623792
# Unit test for function overload_configuration
def test_overload_configuration():
    config['test'] = 'test'
    @overload_configuration
    def test_func(a):
        return config['test']

    test_func(a='test')
    assert config['test'] == 'test'



# Generated at 2022-06-12 07:04:08.239691
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli as cli
    with overload_configuration(cli.main) as new_func:
        assert new_func.__name__ == "main"
    # config is unchanged
    assert config.get("check_build_status") is False
    # config is changed
    with overload_configuration(cli.main) as new_func:
        new_func(define=["check_build_status=True"])
    assert config.get("check_build_status") is True

# Generated at 2022-06-12 07:04:17.550706
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog
    import pytest

    def test_component(config, **kwargs):
        pass

    config["changelog_components"] = "test_component"
    assert current_changelog_components() == [test_component]

    config["changelog_components"] = (
        "semantic_release.changelog.BreakingChangeComponent,semantic_release."
        "changelog.FeatureComponent,semantic_release.changelog."
        "BugfixComponent,semantic_release.changelog.DocumentationComponent"
    )
    assert current_changelog_components() == [
        changelog.BreakingChangeComponent,
        changelog.FeatureComponent,
        changelog.BugfixComponent,
        changelog.DocumentationComponent,
    ]

   

# Generated at 2022-06-12 07:04:25.261606
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import pytest
    from semantic_release.errors import ImproperConfigurationError

    with pytest.raises(ImproperConfigurationError):
        current_changelog_components()

    config["changelog_components"] = "foo.bar,invalid"
    with pytest.raises(ImproperConfigurationError):
        current_changelog_components()

    from semantic_release.changelog import header, sections

    config["changelog_components"] = "semantic_release.changelog.header,invalid"
    assert current_changelog_components() == [header]

    config["changelog_components"] = "semantic_release.changelog.header"
    assert current_changelog_components() == [header]


# Generated at 2022-06-12 07:04:28.469294
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(arg):
        return config.get(arg)

    decorated_func = overload_configuration(func)

    # Always set the value of "config_test" to "default"
    assert decorated_func("config_test") == "default"

    # Now redefine the value of "config_test" as "overloaded"
    decorated_func(define=["config_test=overloaded"])
    assert decorated_func("config_test") == "overloaded"

# Generated at 2022-06-12 07:04:37.395696
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert 1 == len(current_changelog_components())

# Generated at 2022-06-12 07:04:46.500332
# Unit test for function overload_configuration
def test_overload_configuration():
    # To mock config
    class Config(UserDict):
        def __init__(self):
            super().__init__()
            self.data = {}

        def get(self, *args):
            return None

    config = Config()

    # The function to mock
    def mock_function(**kwargs):
        return "mocked function"

    # Overloading the real config
    mock_function = overload_configuration(mock_function)

    # *
    # * Test Case 1
    # * Respecting the patern key=value
    # *
    assert mock_function(define=["key=value", "key2=value2"]) == "mocked function"
    assert config["key"] == "value"
    assert config["key2"] == "value2"

    # *
    # * Test Case 2


# Generated at 2022-06-12 07:04:53.264212
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("commit_parser") == "semantic_release.hvcs.git.commit_parser"
    @overload_configuration
    def test_function(define=None):
        return
    test_function(define=["commit_parser=test_function"])
    assert config.get("commit_parser") == "test_function"


__all__ = ["config", "current_commit_parser", "current_changelog_components"]

# Generated at 2022-06-12 07:04:57.253857
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def _foo(foo, bar=3):
        return foo + bar + config.get('baz', 0)

    assert _foo(4, bar=5, define=('baz=1')) == 10

# Test only semantic-release.configuration.config
# Avoid to overload global config

# Generated at 2022-06-12 07:05:07.038163
# Unit test for function overload_configuration
def test_overload_configuration():
    from .logger import set_log_levels

    set_log_levels()

    # test that defined parameter are correctly added
    @overload_configuration
    def test_func(define=None):
        return True

    assert test_func(define=["a=b"]) is True
    assert config.get("a") == "b"

    # test that defined parameter are correctly added even if the key already exists
    @overload_configuration
    def test_func(define=None):
        return True

    config["a"] = "c"
    assert test_func(define=["a=b"]) is True
    assert config.get("a") == "b"

    # test that the value of defined parameter is not only one char
    @overload_configuration
    def test_func(define=None):
        return True

# Generated at 2022-06-12 07:05:12.173228
# Unit test for function overload_configuration
def test_overload_configuration():
    assert len(config) == 0
    config["a"] = "a"
    config["b"] = "b"
    config["c"] = "c"

    def test_func(*args, **kwargs):
        return kwargs["define"]

    overload = overload_configuration(test_func)
    overload(define=["a=aa", "b=bb", "c=cc"])

    assert config.get("a") == "aa"
    assert config.get("b") == "bb"
    assert config.get("c") == "cc"

# Generated at 2022-06-12 07:05:17.310668
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import main

    config.get = lambda x: "nono"
    assert main(["version"]) == 0

    config.get = lambda x: "aral"
    assert main(["version"]) == 1

    config.get = lambda x: "aral"
    assert main(["version", "--define", "token=toto"]) == 0



# Generated at 2022-06-12 07:05:21.689107
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Test when the changelog_components option is missing in setup.cfg or pyproject.toml
    assert len(current_changelog_components()) == 0

    # Test when the changelog_components option is set in setup.cfg
    config["changelog_components"] = "semantic_release.changelog_components.default_components"

    components = current_changelog_components()
    assert len(components) == 3
    assert components[0].__name__ == "changelog_header_for_release"
    assert components[1].__name__ == "get_changelog"
    assert components[2].__name__ == "changelog_footer"

    # Test when the changelog_components option is set in pyproject.toml

# Generated at 2022-06-12 07:05:26.506737
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(config):
        return config

    assert func(define=["first_pair=1", "second_pair=2"])["first_pair"] == "1"
    assert func(define=["first_pair=1", "second_pair=2"])["second_pair"] == "2"

# Generated at 2022-06-12 07:05:36.644823
# Unit test for function overload_configuration
def test_overload_configuration():
    import sys
    import pytest

    globals()["sys"] = pytest.importorskip("sys")
    config["python_requires"] = ">=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*"
    config["python_modules"] = "semantic_release"
    config["skip_tag"] = True
    config["upload_to_test"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True


# Generated at 2022-06-12 07:05:46.277062
# Unit test for function overload_configuration
def test_overload_configuration():
    """The function overload_configuration is tested by passing the value None
    to the decorator so that the function is not used.
    """
    return None

# Generated at 2022-06-12 07:05:50.354691
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_config_func(param1, param2, define=None):
        pass

    decorated_func = overload_configuration(test_config_func)
    decorated_func(0, 0, define=["project_name=test"])
    assert config["project_name"] == "test"

# Generated at 2022-06-12 07:05:56.141797
# Unit test for function overload_configuration
def test_overload_configuration():
    config_dict = {"a": "1", "b": "2"}
    original_config = config.copy()

    @overload_configuration
    def test_function(arg1, arg2, define=None):
        assert arg1 == "a"
        assert arg2 == "b"
        assert config["a"] == "1"
        assert config["b"] == "2"
        assert config == config_dict

    test_function("a", "b", define=["a=1", "b=2"])

    assert config == original_config



# Generated at 2022-06-12 07:05:59.288462
# Unit test for function current_changelog_components
def test_current_changelog_components():
    changelog_components = current_changelog_components()
    assert len(changelog_components) == 2
    assert changelog_components[0] is not None
    assert changelog_components[1] is not None

# Generated at 2022-06-12 07:06:04.195105
# Unit test for function overload_configuration
def test_overload_configuration():
    config["changelog_components"] = "a.c"
    @overload_configuration
    def set_default_values(*args, **kwargs):
        pass
    set_default_values(define=["changelog_components=b.d"])
    assert config["changelog_components"] == "b.d"

# Generated at 2022-06-12 07:06:13.838592
# Unit test for function overload_configuration
def test_overload_configuration():
    def function(a, b, c, d=0, e=1, f=2, g=None, define=[]):
        return a, b, c, d, e, f, g

    new_func = overload_configuration(function)

    assert new_func(1, 2, 3) == (1, 2, 3, 0, 1, 2, None)
    assert new_func(1, 2, 3, define=["d=4", "e=5"]) == (1, 2, 3, 4, 5, 2, None)
    assert new_func(1, 2, 3, define=["d=4", "h=6"]) == (1, 2, 3, 4, 1, 2, None)



# Generated at 2022-06-12 07:06:23.093317
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(a, b):
        return a, b

    assert func(1, 2) == (1, 2)
    assert func(a=1, define=["b=2"]) == (1, 2)
    assert func(a=1, b=2, define=["b=3"]) == (1, 3)

    assert "b" not in config
    assert func(a=1, define=["b=2", "c=3"]) == (1, 2)
    assert "b" in config
    assert func(a=1, b=2, define=["b=3", "c=4"]) == (1, 3)
    assert "c" not in config

# Generated at 2022-06-12 07:06:27.221851
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == "changelog.components.section"
    components = current_changelog_components()
    assert len(components) == 1
    assert components[0] == "changelog.components.section"

# Generated at 2022-06-12 07:06:37.109252
# Unit test for function overload_configuration
def test_overload_configuration():
    # Normal case
    internal_config_initial = config.copy()
    @overload_configuration
    def function_for_overload_configuration(s: str, define: list = None):
        return config[s]
    config_keys_length = len(config)
    test_value = "test_value"
    assert function_for_overload_configuration("test", define=["test=test_value"]) == test_value
    # Check the initial config has not changed
    assert config_keys_length == len(config)
    assert config == internal_config_initial
    # Check with multiple definitions
    assert function_for_overload_configuration("test2", define=["test2=test_value", "test=test_value"]) == test_value
    # Check with multiple definitions
    assert function_for_over

# Generated at 2022-06-12 07:06:49.234805
# Unit test for function overload_configuration
def test_overload_configuration():
    config["other"] = "y"
    assert config["other"] == "y"

    @overload_configuration
    def test_func(x, y, define=None):
        return (x, y, config["other"])

    x = "x"
    y = "y"
    # No define
    x1, y1, other1 = test_func(x, y)
    assert x1 == x
    assert y1 == y
    assert other1 == "y"
    # One define
    x2, y2, other2 = test_func(x, y, define=["other=z"])
    assert x2 == x
    assert y2 == y
    assert other2 == "z"
    # Here config["other"] is still "z"
    x3, y3, other3 = test_func

# Generated at 2022-06-12 07:07:00.139900
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from ...components import sections, changelog_commits

    assert current_changelog_components() == [sections, changelog_commits]

# Generated at 2022-06-12 07:07:04.633487
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(test_cfg):
        pass

    func = overload_configuration(func)
    assert isinstance(func, Callable)

    func(define=["test:1"])
    assert config["test"] == "1"

    func(define=["test:2"])
    assert config["test"] == "2"

# Generated at 2022-06-12 07:07:07.264718
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """ Test the default parser is returned if the commit parser is not specified """
    config.pop("commit_parser")
    assert str(current_commit_parser()) == "semantic_release.commit_parser.parse"

# Generated at 2022-06-12 07:07:15.863124
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_overload_configuration"] = "test_value"

    @overload_configuration
    def test_overload_configuration():
        return config["test_overload_configuration"]

    assert test_overload_configuration() == "test_value"
    assert test_overload_configuration(define=["test_overload_configuration=overloaded_value"]) == "overloaded_value"

# Generated at 2022-06-12 07:07:23.848794
# Unit test for function overload_configuration
def test_overload_configuration():
    # GIVEN some default configuration and a function to change it
    @overload_configuration
    def func(define=[], **kwargs):
        pass

    # WHEN execute the function with a defined parameter
    define = ["test=ok"]
    args = {}
    func(define=define, **args)

    # THEN the change is made and
    assert config["test"] == "ok"



# Generated at 2022-06-12 07:07:26.494147
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.vcs_helpers.CommitsWithDescription"
    assert len(current_changelog_components()) == 1

# Generated at 2022-06-12 07:07:32.066985
# Unit test for function overload_configuration
def test_overload_configuration():
    '''This method tests overload_configuration.'''
    # Test changes a key already present in the dictionary
    overload_configuration(config)(define=['helper_version=2'])
    assert config['helper_version'] == "2"

    # Test changes a key that is not already present in the dictionary
    overload_configuration(config)(define=['new_key=2'])
    assert config['new_key'] == "2"

    # Test that does not change the dictionary
    overload_configuration(config)()
    assert config['helper_version'] == "2"
    assert config['new_key'] == "2"

# Generated at 2022-06-12 07:07:39.136212
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.component.FormatBody,semantic_release.changelog.component.CapitalizeBody,semantic_release.changelog.component.ScopeBody,semantic_release.changelog.component.Title"
    assert len(current_changelog_components()) == 4


# Generated at 2022-06-12 07:07:45.755383
# Unit test for function overload_configuration

# Generated at 2022-06-12 07:07:47.963618
# Unit test for function overload_configuration

# Generated at 2022-06-12 07:08:05.765200
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator overloads the configuration
    with the define key/value pairs
    """

    @overload_configuration
    def get_dict():
        return config

    config_bkup = config.copy()
    # Test overwrite of a simple key
    config["key1"] = "value1"
    config["key2"] = "value2"
    get_dict(define=["key1=new_value1", "key2=new_value2"])
    assert config["key1"] == "new_value1"
    assert config["key2"] == "new_value2"
    config = config_bkup.copy()
    # Test overwrite of a complex key
    config["key1"] = {"key11": "value11", "key12": "value12"}

# Generated at 2022-06-12 07:08:14.336772
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the decorator overload_configuration"""

    # save the current value of a config param
    backup_config = config["pre_release_branch"]

    # function to overload
    @overload_configuration
    def test_function(a, define=None):
        """Test the decorator overload_configuration"""
        return a

    # change config param
    assert backup_config == config["pre_release_branch"]
    test_function("hello", define=["pre_release_branch=beta"])
    assert config["pre_release_branch"] != backup_config

    # restore config param
    config["pre_release_branch"] = backup_config

# Generated at 2022-06-12 07:08:19.502429
# Unit test for function overload_configuration
def test_overload_configuration():
    # Define configuration and configure the decorator
    def decorator(arg):
        return arg

    decorator = overload_configuration(decorator)

    # Test the decorator without command line
    assert decorator("test") == "test"
    # Test the decorator with command line arguments
    assert decorator("test", define=["content=test"]) == "test"

# Generated at 2022-06-12 07:08:25.924843
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.data['changelog_components'] = 'semantic_release.changelog.components'
    components = current_changelog_components()
    assert len(components) == 1

    config.data['changelog_components'] = 'semantic_release.changelog.components,semantic_release.changelog.components'
    components = current_changelog_components()
    assert len(components) == 2


# Generated at 2022-06-12 07:08:35.648573
# Unit test for function overload_configuration
def test_overload_configuration():
    os.environ["SR_CONFIG_CHANGELOG_COMPONENTS"] = "python"
    os.environ["SR_CONFIG_CHANGELOG_MAX_LENGTH"] = "200"
    os.environ["SR_CONFIG_COMMIT_MESSAGE_REGEX"] = ".*"
    os.environ["SR_CONFIG_COMMIT_MESSAGE_REGEX_RELEASE"] = ".*"
    os.environ["SR_CONFIG_COMMIT_MESSAGE_REGEX_DROP_RELEASE"] = ".*"
    os.environ["SR_CONFIG_COMMIT_MESSAGE_REGEX_SKIP_RELEASE"] = ".*"

# Generated at 2022-06-12 07:08:38.737265
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Checking if current_commit_parser gives the correct import path"""
    from .commit_parsers import parse_release_type

    assert current_commit_parser() == parse_release_type

# Generated at 2022-06-12 07:08:40.620234
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(define):
        return define

    values = ["foo=bar", "bar=baz"]
    assert my_function(define=values) == values
    assert config["foo"] == "bar"

# Generated at 2022-06-12 07:08:44.499427
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog_components.commit_message_component"
    assert current_changelog_components() == [
        semantic_release.changelog_components.commit_message_component
    ]
    config["changelog_components"] = ""
    assert current_changelog_components() == []



# Generated at 2022-06-12 07:08:53.686575
# Unit test for function overload_configuration
def test_overload_configuration():
    config["changelog_components"] = "components.component_a, components.component_b"
    config["changelog_capitalize"] = "true"
    config["changelog_scope"] = "true"

    @overload_configuration
    def change_config(define):
        pass

    change_config(
        define=[
            "changelog_components=components.component_c, components.component_d",
            "changelog_capitalize=false",
        ]
    )
    assert config["changelog_components"] == "components.component_c, components.component_d"

# Generated at 2022-06-12 07:08:58.885452
# Unit test for function overload_configuration
def test_overload_configuration():
    config["changelog_components"] = "semantic_release.vcs.git"
    called = False

    @overload_configuration
    def func(argument: str = "test", define=[]):
        nonlocal called
        called = True
        assert argument == "overload"

    func(define=["argument=overload"])
    assert called is True

# Generated at 2022-06-12 07:09:10.970649
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test if overload_configuration overloads the conf file with define parameters."""

    @overload_configuration
    def test(**kwargs):
        assert config["define"] == "key1=value1,key2=value2"
        assert config["key1"] == "value1"
        assert config["key2"] == "value2"

    test(define=["define=key1=value1,key2=value2"])

# Generated at 2022-06-12 07:09:20.346891
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function(param1, param2, define=None):
        print(param1, param2, config)
        return param1, param2

    wrapper = overload_configuration(test_function)

    wrapper(1, 2)
    assert config == {}

    wrapper(1, 2, define=["a=b", "c=d", "e=f"])
    assert config == {"a": "b", "c": "d", "e": "f"}

    wrapper(1, 2, define=["g=h", "i=j", "k=l"])
    assert config == {"a": "b", "c": "d", "e": "f", "g": "h", "i": "j", "k": "l"}

# Generated at 2022-06-12 07:09:24.501811
# Unit test for function overload_configuration
def test_overload_configuration():
    def f(**kwargs):
        pass

    f_overload = overload_configuration(f)

    f_overload(define=["plugin=plugin_name", "debug=true"])

    assert config["plugin"] == "plugin_name"
    assert config["debug"] == "true"

    f_overload(define=["plugin=other_name"])
    assert config["plugin"] == "other_name"

# Generated at 2022-06-12 07:09:25.638335
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}
    assert config == {}


# Generated at 2022-06-12 07:09:32.934620
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_components'] = 'semantic_release.changelog.components.body'
    assert current_changelog_components() == [semantic_release.changelog.components.body]

    config['changelog_components'] = 'semantic_release.changelog.components.body,semantic_release.changelog.components.issues'
    assert current_changelog_components() == [semantic_release.changelog.components.body, semantic_release.changelog.components.issues]

# Generated at 2022-06-12 07:09:36.442865
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = dict(a="b")
    @overload_configuration
    def foo(define=[]):
        return config
    assert foo() == dict(a="b")
    assert foo(define=["a=c"]) == dict(a="c")

# Generated at 2022-06-12 07:09:42.029444
# Unit test for function overload_configuration
def test_overload_configuration():
    config["overload"] = "original"
    config["overload_int"] = 2

    @overload_configuration
    def test_overload(*args, **kwargs):
        return kwargs["define"]

    assert test_overload(define=["overload=overloaded"]) == ["overload=overloaded"]
    assert config["overload"] == "overloaded"
    assert test_overload(define=["overload_int=1"]) == ["overload_int=1"]
    assert config["overload_int"] == "1"

# Generated at 2022-06-12 07:09:50.699517
# Unit test for function overload_configuration
def test_overload_configuration():
    # We define a config with only one setting in order to be able to check
    # that it is redefined by the decorator
    conf = configparser.ConfigParser()
    conf["semantic_release"] = {"plugin_repo": "my_plugin"}
    config_ini = {
        "changelog_capitalize": "False",
        "changelog_scope": "False",
        "check_build_status": "False",
        "commit_version_number": "False",
        "patch_without_tag": "False",
        "major_on_zero": "False",
        "remove_dist": "False",
        "upload_to_pypi": "False",
        "upload_to_release": "False",
        "plugin_repo": "my_plugin",
    }

    # Now, let's

# Generated at 2022-06-12 07:09:56.949758
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function is to be run from the main project folder.
    """
    config["foo"] = "setup.cfg"

    @overload_configuration
    def test_func(define=[]):
        return config["foo"]

    assert test_func() == "setup.cfg"
    assert test_func(define=["foo=pyproject.toml"]) == "pyproject.toml"
    assert test_func(define=["foo=about.rst"]) == "about.rst"
    assert test_func() == "about.rst"

# Generated at 2022-06-12 07:10:04.003943
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

# Generated at 2022-06-12 07:10:15.817195
# Unit test for function overload_configuration
def test_overload_configuration():
    def do_something(foo, bar):
        pass

    do_something = overload_configuration(do_something)

    do_something(foo=1, define=["bar=baz"])

    assert config["bar"] == "baz"

# Generated at 2022-06-12 07:10:26.274929
# Unit test for function overload_configuration
def test_overload_configuration():
    '''Unit test for overload_configuration decorator
    '''

    @overload_configuration
    def my_func(a, b, *args, **kwargs):
        return a, b, args, kwargs

    assert my_func("a", "b", define=["define1=value1"]) == ("a", "b", (), {})
    assert my_func("a", "b", define=["define1=value1", "define2=value2"]) == ("a", "b", (), {})
    assert my_func("a", "b", define=["define1=value1", "define2=value2"], c="c") == ("a", "b", (), {"c": "c"})

# Generated at 2022-06-12 07:10:28.404670
# Unit test for function current_changelog_components
def test_current_changelog_components():
    list_components = current_changelog_components()
    assert len(list_components) == 2

# Generated at 2022-06-12 07:10:32.226198
# Unit test for function overload_configuration
def test_overload_configuration():
    func = overload_configuration(config.get)
    func(define=["python_versions=toto"])
    assert config["python_versions"] == "toto"

# Generated at 2022-06-12 07:10:36.720118
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.config as config_module

    @config_module.overload_configuration
    def test_func(define=None):
        pass

    test_func(define=["test=test"])

    assert config["test"] == "test"

    test_func()

    assert "test" not in config

# Generated at 2022-06-12 07:10:45.366825
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def some_method(a, b, define=None):
        return None

    # Ready

    # Test for no override
    some_method(1, 2)
    assert config.get("old_configuration") == "old_value"

    # Test for define override an existing value
    some_method(1, 2, define=["old_configuration=new_value"])
    assert config.get("old_configuration") == "new_value"

    # Test for define override an non existing value
    some_method(1, 2, define=["this_key_is_not_in_config=new_value"])
    assert config.get("this_key_is_not_in_config") == "new_value"