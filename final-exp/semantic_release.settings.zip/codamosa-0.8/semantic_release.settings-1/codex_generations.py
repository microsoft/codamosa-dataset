

# Generated at 2022-06-12 07:01:00.797971
# Unit test for function overload_configuration
def test_overload_configuration():
    config_backup = config.copy()
    empty_function = overload_configuration(lambda: None)
    empty_function()
    assert config == config_backup

    config["foo"] = "bar"
    empty_function(define=["foo=baz"])
    assert config["foo"] == "baz"

    empty_function(define=["foo=baz", "foo=bak", "bar=baz"])
    assert config == {"foo": "bak", "bar": "baz"}

    assert empty_function.__name__ == "empty_function"

# Generated at 2022-06-12 07:01:08.058022
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test with one element in the array
    @overload_configuration
    def test_function(define=None):
        if define is None:
            return config["test_key"]
    test_function(define=["test_key=this_value"])
    assert config["test_key"] == "this_value"
    # Test with multiple elements in the array
    test_function(define=["test_key=new_value", "other_key=other_value"])
    assert config["test_key"] == "new_value"
    assert config["other_key"] == "other_value"
    # Test with invalid data
    test_function(define=["invalid_data"])
    assert config["test_key"] == "new_value"
    assert config["other_key"] == "other_value"

# Generated at 2022-06-12 07:01:19.112220
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 4
    assert components[0](github_repo_url='https://github.com/relekang/python-semantic-release') == \
        'https://github.com/relekang/python-semantic-release/compare/v0.10.0...HEAD'
    assert components[1](github_repo_url='https://github.com/relekang/python-semantic-release') == \
        'python-semantic-release: No new issues.\npython-semantic-release-cli: No new issues.\n'

# Generated at 2022-06-12 07:01:31.234880
# Unit test for function current_changelog_components
def test_current_changelog_components():

    from semantic_release import Changelog, parse_changelog

    changelog_components = current_changelog_components()
    assert changelog_components == [Changelog, parse_changelog]

# Generated at 2022-06-12 07:01:34.128360
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function(string, define=None):
        # some code
        pass
    function("", define=["pypi_token=my_token"])
    assert config["pypi_token"] == "my_token"

# Generated at 2022-06-12 07:01:41.892188
# Unit test for function overload_configuration
def test_overload_configuration():
    # Given
    config["option"] = "original"
    config["other"] = "another"

    @overload_configuration
    def test(define: List[str]):
        pass

    # When
    test(define=["option=overloaded"])

    # Then
    assert config["option"] == "overloaded", "The option should be overloaded"
    assert config["other"] == "another", "The option should not be overloaded"



# Generated at 2022-06-12 07:01:48.068156
# Unit test for function current_commit_parser
def test_current_commit_parser():
    # Assert that the default parser is the one provided by default
    assert current_commit_parser().__name__ == "parse_commits", "Wrong parser imported"
    # Assert that the parser can be changed in setup.cfg
    config["commit_parser"] = "semantic_release.commit_parser.parse_commits_test"
    assert current_commit_parser().__name__ == "parse_commits_test", "Wrong parser imported"



# Generated at 2022-06-12 07:01:51.642776
# Unit test for function overload_configuration
def test_overload_configuration():
    mock_config = {"repository_url": "git@github.com:relekang/example.git", "define": [
        "repository_url=git@github.com:relekang/new-example.git"]}
    @overload_configuration
    def func():
        return config

    assert func(**mock_config) == {"repository_url": "git@github.com:relekang/new-example.git"}

# Generated at 2022-06-12 07:01:54.506790
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(x, y, define=[]):
        return x + y

    func = overload_configuration(func)
    assert func(1, 2, define=["a=b"]) == 3
    assert config["a"] == "b"

# Generated at 2022-06-12 07:02:00.357233
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.update({"changelog_components": "semantic_release.changelog.components.scope,semantic_release.changelog.components.message"})
    assert len(current_changelog_components()) == 2
    assert current_changelog_components()[0].__name__ == "scope"
    assert current_changelog_components()[1].__name__ == "message"



# Generated at 2022-06-12 07:02:21.184628
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from .changelog_components import (
        Bugfix,
        CommitType,
        Feature,
        BreakingChange,
        NewComponent
    )

    assert current_changelog_components() == [
        Bugfix(),
        CommitType(),
        Feature(),
        BreakingChange(),
        NewComponent()
    ]

# Generated at 2022-06-12 07:02:30.771950
# Unit test for function current_changelog_components
def test_current_changelog_components():

    # Case 1: no error is raised
    changelog_components = [
        "semantic_release.changelog.components.changelog_summary",
        "semantic_release.changelog.components.changelog_commits",
    ]
    config["changelog_components"] = ",".join(changelog_components)
    assert current_changelog_components() is not None

    # Case 2: error is raised
    config["changelog_components"] = "ComponentDoesNotExist"
    with pytest.raises(ImproperConfigurationError) as error:
        current_changelog_components()
    assert (
        str(error.value) == 'Unable to import changelog component "ComponentDoesNotExist"'
    )

# Generated at 2022-06-12 07:02:39.593245
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def func(foo, bar, baz, **kwargs):
        return foo, bar, baz

    class Class:
        @staticmethod
        @overload_configuration
        def func(foo, bar, baz, **kwargs):
            return foo, bar, baz

    # Check that a command-line argument is correctly overwritten

    config["release_commit_message_filename"] = "RELEASE_COMMIT_MESSAGE_FILENAME"
    assert func("foo", "bar", "baz", define=["release_commit_message_filename=commit_message.txt"]) == ("foo", "bar", "baz")
    assert config["release_commit_message_filename"] == "commit_message.txt"

    # Check that an error is raised if an argument is not correctly define


# Generated at 2022-06-12 07:02:50.803669
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def empty(arg1):
        pass

    @overload_configuration
    def single(arg1, define=[]):
        pass

    @overload_configuration
    def multiple(arg1, define=[]):
        pass

    @overload_configuration
    def multi_with_arg(arg1, define=[]):
        pass

    test_default_value = "test"
    assert config["changelog_capitalize"] is False
    assert config["changelog_scope"] is False
    assert config["check_build_status"] is False
    assert config["commit_version_number"] is True
    assert config["patch_without_tag"] is False
    assert config["major_on_zero"] is False
    assert config["remove_dist"] is False

# Generated at 2022-06-12 07:02:57.703583
# Unit test for function overload_configuration
def test_overload_configuration():
    config['bob'] = 'john'
    config['alice'] = 'bob'
    config['james'] = 'jones'

    @overload_configuration
    def foo(bar, baz):
        return

    foo(bar=7, define=['bob=doe', 'james=bond'])
    assert config['bob'] == 'doe'
    assert config['alice'] == 'bob'
    assert config['james'] == 'bond'

if __name__ == "__main__":
    test_overload_configuration()

# Generated at 2022-06-12 07:03:04.071047
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(arg):
        assert config["define"] == "setup.cfg"
        assert config["changelog_components"] == "GitHub.issue"
        assert config["new_version"] == "minor"
        return

    test("test", define=["define=setup.cfg", "changelog_components=GitHub.issue", "new_version=minor"])

# Generated at 2022-06-12 07:03:06.980602
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(x):
        return x

    assert func(x=3, define=["old_value=new_value"]) == 3
    assert func(x=3) == 3

# Generated at 2022-06-12 07:03:10.128570
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config["check_build_status"] == True

    @overload_configuration
    def func(define):
        return config["check_build_status"] == True

    assert func(define=["check_build_status=False"]) == False

# Generated at 2022-06-12 07:03:17.706663
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test checks if the decorator overload_configuration
    works as intended"""
    from .base_command import BaseCommand
    from .components import Components
    from .main import get_version_from_git
    from .settings import config
    from .utils.exec import exec
    from .utils.git import Git
    from .utils.git import init_repo

    class TestOverloadConfiguration(BaseCommand):
        """TestOverloadConfiguration is used to test the decorator
        overload_configuration"""

        @overload_configuration
        def func(self, *args, **kwargs):
            print(config["changelog_components"])

    test_config = config.copy()
    test_config["changelog_components"] = "components.test_config"

# Generated at 2022-06-12 07:03:20.446270
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == [
        semantic_release.changelog.components.changelog,
        semantic_release.changelog.components.user_config,
    ]

# Generated at 2022-06-12 07:03:39.412683
# Unit test for function overload_configuration
def test_overload_configuration():
    def _test_function(item):
        return config.get(item)

    function = overload_configuration(_test_function)
    assert function("package_files") == "['**/*']"
    function("package_files", define=["package_files=['pyproject.toml']"])
    assert function("package_files") == "['pyproject.toml']"

# Generated at 2022-06-12 07:03:43.573958
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define, pull_request=None):
        return pull_request

    # test environment variable overload
    assert func(define=["PULL_REQUEST=1"]) == "1"

    # test that the overload only lives during one call of the function
    assert func(pull_request=None) == None



# Generated at 2022-06-12 07:03:51.479794
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

    config["changelog_components"] = "tests.components.first_component"
    assert current_changelog_components() == [first_component]

    config["changelog_components"] = (
        "tests.components.first_component,"
        "tests.components.second_component,"
        "tests.components.third_component,"
    )
    assert current_changelog_components() == [
        first_component,
        second_component,
        third_component,
    ]



# Generated at 2022-06-12 07:03:53.919523
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert len(current_changelog_components()) == 1
    components = list(current_changelog_components())
    assert components[0]([]) == []

# Generated at 2022-06-12 07:03:56.043915
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser"
    assert callable(current_commit_parser())


# Generated at 2022-06-12 07:03:58.089620
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from tests.lib.mock_components import mock_component_one, mock_component_two

    assert (
        current_changelog_components()
        == [mock_component_one, mock_component_two]
    )

# Generated at 2022-06-12 07:04:03.476577
# Unit test for function overload_configuration
def test_overload_configuration():
    parser = configparser.ConfigParser()
    parser.read(os.path.join(os.path.dirname(__file__), 'defaults.cfg'))

    # Create a function that uses the decorator
    @overload_configuration
    def test_func(define):
        pass

    print('config', config)
    print('parser', parser)

    # Check if "config" is the same as "parser"
    assert config == parser

    # Then check if the decorator works properly
    test_func(define=["check_build_status=False"])
    assert config["check_build_status"] == "False"

    test_func(define=["tag_format=v{new_version}"])
    assert config["tag_format"] == "v{new_version}"

# Generated at 2022-06-12 07:04:08.007099
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define):
        pass
    test_function(define=["foo=bar", "bar=foo", "empty="])
    assert config.get("foo") == "bar"
    assert config.get("bar") == "foo"
    assert config.get("empty") == ""

# Generated at 2022-06-12 07:04:17.358299
# Unit test for function overload_configuration
def test_overload_configuration():  # noqa: D103
    config = {"default_key": "default_val", "my_key": "my_value"}

    @overload_configuration
    def the_func(my_key):
        return config

    # should return dict with unchanged "my_key"
    assert the_func(my_key="my_key") == {"default_key": "default_val", "my_key": "my_value"}
    # should return dict with changed "my_key"
    assert the_func(define=["my_key=new_value"]) == {"default_key": "default_val", "my_key": "new_value"}
    # should return dict with changed "default_key" and "my_key"

# Generated at 2022-06-12 07:04:21.159823
# Unit test for function overload_configuration
def test_overload_configuration():
    # Make sure 'define' is not present in config, if it is, delete it.
    if 'define' in config:
        del config['define']

    @overload_configuration
    def test(define, kwargs):
        return kwargs

    assert test(define='project=test_config_overloaded', kwargs='true') == 'true'

# Generated at 2022-06-12 07:04:44.366948
# Unit test for function overload_configuration
def test_overload_configuration():
    config["key1"] = "test1"
    config["key2"] = "test2"

    @overload_configuration
    def f(key1, key2):
        return key1, key2

    assert f(define="key1=test1") == ("test1", "test2")
    assert f(define=["key1=test1"]) == ("test1", "test2")
    assert f(define=["key2=test2"]) == ("test1", "test2")
    assert f(define=["key1=overload", "key2=overload"]) == ("overload", "overload")

# Generated at 2022-06-12 07:04:55.177834
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get("changelog_components") == "semantic_release.components.changelog,semantic_release.components.compare_commits"
    assert config.get("prepare") == "semantic_release.prepare:prepare"

    @overload_configuration
    def foo(changelog_components, prepare):
        assert changelog_components == "bar"
        assert prepare == "baz"

    foo(define=["changelog_components=bar", "prepare=baz"])
    assert config.get("changelog_components") == "semantic_release.components.changelog,semantic_release.components.compare_commits"
    assert config.get("prepare") == "semantic_release.prepare:prepare"

   

# Generated at 2022-06-12 07:05:06.113938
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test if the overload_configuration correctly overloads the
    configuration
    """
    test_config = configparser.ConfigParser()
    test_config["semantic_release"] = {
        "remove_dist": "true",
        "upload_to_pypi": "false",
    }
    assert config["remove_dist"] is True
    assert config["upload_to_pypi"] is False

    # Overload the configuration with new parameters
    @overload_configuration
    def test_func(define):
        pass

    test_func(define=["remove_dist=false", "upload_to_pypi=true"])

    # Check that the configuration has been correctly edited
    assert config["remove_dist"] is False
    assert config["upload_to_pypi"] is True

# Generated at 2022-06-12 07:05:07.910023
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert "semantic_release.commit_parser.get_message" == current_commit_parser()

# Generated at 2022-06-12 07:05:09.057371
# Unit test for function current_changelog_components
def test_current_changelog_components():
	assert callable(current_changelog_components()[0])


# Generated at 2022-06-12 07:05:18.903603
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the `overload_configuration` decorator."""
    import unittest.mock as mock

    @overload_configuration
    def test_function_to_overload(define=[]):
        """This function is used to test the decorator overload_configuration."""
        assert config["define"] == "value"

    # call the function with a key/value pair in the "define" array
    config["define"] = ""
    test_function_to_overload(define=["define=value"])

    # call the function with two key/value pair in the "define" array
    config["define"] = ""
    test_function_to_overload(define=["define=value", "define=value"])

    # call the function with a wrong key/value pair in the "define" array
    config["define"]

# Generated at 2022-06-12 07:05:26.541860
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def test_config_func(configuration_key):
        return config[configuration_key]

    test_config_func("commit_parser", define=["commit_parser=foo"])
    assert config["commit_parser"] == "foo"
    assert test_config_func("commit_parser") == "foo"

    test_config_func("commit_parser", define=["commit_parser=bar"])
    assert config["commit_parser"] == "bar"
    assert test_config_func("commit_parser") == "bar"

# Generated at 2022-06-12 07:05:32.608014
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.history import parse_history_section
    from semantic_release.changelog import create_changelog


    test_str = config.get("changelog_components")
    assert test_str == 'semantic_release.history.parse_history_section, semantic_release.changelog.create_changelog'

    assert parse_history_section in current_changelog_components()
    assert create_changelog in current_changelog_components()

# Generated at 2022-06-12 07:05:39.146953
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(foo, define=[]):
        print(config.get('foo'))  # None
        print(config.get('bar'))  # None
        print(config.get('spam')) # None
        print(foo)                # None

    f(foo=None, define=["foo=bar", "spam=eggs"])

    assert config.get('foo') == 'bar'
    assert config.get('bar') == 'spam=eggs'
    assert config.get('spam') == 'eggs'

# Generated at 2022-06-12 07:05:43.763809
# Unit test for function overload_configuration
def test_overload_configuration():
    # Defines 2 entries, with 2 differents types
    @overload_configuration
    def test_func(define):
        return config

    assert test_func(define=["verbose=True", "command=test"]) == {
        "verbose": "True",
        "command": "test",
    }

# Generated at 2022-06-12 07:06:05.457264
# Unit test for function overload_configuration
def test_overload_configuration():
    def test(define):
        pass
    test.__wrapped__(define=["a=b"])
    assert config["a"] == "b"
    test.__wrapped__(define=["a=b", "c=d"])
    assert config["c"] == "d"
    test.__wrapped__(define=["c=e"])
    assert config["c"] == "e"
    test.__wrapped__()
    assert config["c"] == "e"

# Generated at 2022-06-12 07:06:07.298182
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert importlib.import_module("semantic_release.commit_parser")

# Generated at 2022-06-12 07:06:16.101144
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test the currently-configured commit parser"""
    from semantic_release.commit_parser import parse_commits

    config["commit_parser"] = "semantic_release.commit_parser.parse_commits"
    actual = current_commit_parser()
    assert actual == parse_commits

    config["commit_parser"] = "semantic_release.tests.notfound"
    try:
        current_commit_parser()
        assert False, "Should have raised ImproperConfigurationError"
    except ImproperConfigurationError:
        pass

    config["commit_parser"] = "semantic_release.commit_parser.fake_parser"
    try:
        current_commit_parser()
        assert False, "Should have raised ImproperConfigurationError"
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-12 07:06:20.486163
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function(a, b):
        return config.get("vara")
    config["vara"] = "first"
    assert function(1, 2) == "first"
    assert function(1, 2, define=["vara=second"]) == "second"

# Generated at 2022-06-12 07:06:27.502923
# Unit test for function overload_configuration
def test_overload_configuration():
    from . import config

    @overload_configuration
    def test_function(test_param):
        return config[test_param]

    assert test_function(test_param="test_key") == "test_value"
    assert test_function(define=["test_key=test_value_2"], test_param="test_key") == "test_value_2"
    assert test_function(define=["test_key="], test_param="test_key") == ""
    assert test_function(define=["test_key"], test_param="test_key") == "test_key"

# Generated at 2022-06-12 07:06:36.709746
# Unit test for function overload_configuration
def test_overload_configuration():

    # Empty config
    def func(define):
        pass

    func_empty = overload_configuration(func)

    func_empty(define=None)

    # Normal config
    func_normal = overload_configuration(func)

    config_list = ["foo=bar", "baz=qux"]
    config_dict = {"foo": "bar", "baz": "qux"}
    func_normal(define=config_list)
    assert config == config_dict

    # Wrong config
    func_wrong = overload_configuration(func)

    with pytest.raises(ValueError):
        config_list_wrong = ["foo", "baz=qux"]
        func_wrong(define=config_list_wrong)

# Generated at 2022-06-12 07:06:43.795790
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test the function overload_configuration
    """

    @overload_configuration
    def test(define):
        assert config.get("hello") == "world"

    test(define=["hello=world"])
    test(define=["hello=world", "key=value"])
    test(define=["hello=world", "key=value", "foo=bar"])



# Generated at 2022-06-12 07:06:48.134284
# Unit test for function overload_configuration
def test_overload_configuration():
    def func(arg, define=[]):
        assert config["key"] == "changedvalue"

    assert config["key"] == "value"
    wrapped_func = overload_configuration(func)
    wrapped_func("arg", define=["key=changedvalue"])

# Generated at 2022-06-12 07:06:56.486373
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_function(a, b):
        return config["a"], config["b"], a, b

    assert test_function(1, 2) == (None, None, 1, 2), "This function is not working"

    test_function = overload_configuration(test_function)
    assert test_function(1, 2) == (None, None, 1, 2), "This function is not working"
    assert test_function(1, 2, define=["a=a", "b=b"]) == ("a", "b", 1, 2), "This function is not working"

# Generated at 2022-06-12 07:07:05.509889
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function() -> None:
        pass

    # Nothing defined
    my_function()
    assert config
    assert "changelog_components" in config
    assert "commit_parser" in config

    # Define changelog_components
    my_function(define=["changelog_components=semantic_release.changelog.components.foo"])
    assert config
    assert config["changelog_components"] == "semantic_release.changelog.components.foo"

    # Define changelog_components and commit_parser
    my_function(
        define=["changelog_components=semantic_release.changelog.components.foo", "commit_parser=semantic_release.parser.bar"]
    )

# Generated at 2022-06-12 07:07:27.275619
# Unit test for function overload_configuration
def test_overload_configuration():
    test_value = "test"
    config["test_value"] = test_value
    test_value = "test2"

    @overload_configuration
    def test_func(define):
        return None

    define_arg = ["test_value=test2", "test_value2=test3"]
    test_func(define=define_arg)
    assert config["test_value"] == "test2"
    assert config["test_value2"] == "test3"



# Generated at 2022-06-12 07:07:31.296204
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(arg1, arg2, arg3, define=[]):
        return arg1, arg2, arg3

    assert foo(1, 2, 3, ["type=patch"]) == (1, 2, 3)
    assert config["type"] == "patch"
    assert foo(1, 2, 3, ["type=minor"]) == (1, 2, 3)
    assert config["type"] == "minor"

# Generated at 2022-06-12 07:07:39.417869
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(x):
        return config

    assert foo(10) == _config()
    assert foo(10, define=["major_on_zero=True"]) == _config()
    assert foo(10, define=["major_on_zero=False"]) != _config()
    assert foo(10, define=["major_on_zero=False"])["major_on_zero"] is False

# Generated at 2022-06-12 07:07:44.411890
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(arg1, arg2):
        return arg1 + arg2
    test_func = overload_configuration(test_func)

    result = test_func(arg1=1, arg2=2, define=["arg1=100"])
    assert result == 102

    result = test_func(arg1=1, arg2=2)
    assert result == 3

    result = test_func(define=["arg2=200"], arg1=1, arg2=2)
    assert result == 201

# Generated at 2022-06-12 07:07:48.127474
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.components.ChangelogGenerator"
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-12 07:07:53.537967
# Unit test for function overload_configuration
def test_overload_configuration():
    global config
    config = UserDict()
    @overload_configuration
    def overload_configuration_test_func(define=None):
        """This function is to test if a decorator can do the configuration.
        """
        return None

    config["foo"] = "bar"
    overload_configuration_test_func(define="foo=baz")
    assert config["foo"] == "baz"

# Generated at 2022-06-12 07:08:02.844776
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "old_value"

    @overload_configuration
    def test_func():
        return config["test_key"]

    assert test_func(define=["test_key=key_value_overload"]) == "key_value_overload"
    assert config["test_key"] == "key_value_overload"

    @overload_configuration
    def test_func():
        return config["test_key"]

    assert test_func() == "key_value_overload"
    assert config["test_key"] == "key_value_overload"

# Generated at 2022-06-12 07:08:08.581190
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def test_function(define=None):
        return define if define is not None else config["changelog_scope"]
    result = test_function(define=["changelog_scope=true", "another_var=my_value"])
    assert result == ["changelog_scope=true", "another_var=my_value"]
    assert config["changelog_scope"] == "true"
    assert config["another_var"] == "my_value"

# Generated at 2022-06-12 07:08:10.866275
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """Unit test for function current_changelog_components
    """
    assert type(current_changelog_components()) is list

# Generated at 2022-06-12 07:08:15.674736
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(*args, **kwargs):
        return config["foo"]

    config["foo"] = "bar"

    assert test(define=["foo=baz"]) == "baz"


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-12 07:08:33.287553
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func(*, define):
        return config.get("ignore", "")

    decorated_func = overload_configuration(test_func)
    decorated_func(define=["ignore=foo"])
    assert config.get("ignore", "") == "foo"

# Generated at 2022-06-12 07:08:34.994149
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.history import default_parser

    current_commit_parser() == default_parser

# Generated at 2022-06-12 07:08:41.178291
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(foo):
        return foo

    config["foo"] = "bar"

    assert test_function(define=[]) == "bar"
    assert test_function(define=["foo=overloaded"]) == "overloaded"
    assert test_function(define=["foo=overloaded", "zoo=zaz"]) == "overloaded"
    assert test_function(define=["zoo=zaz"]) == "bar"

# Generated at 2022-06-12 07:08:43.984343
# Unit test for function current_commit_parser
def test_current_commit_parser():
    config["commit_parser"] = "semantic_release.commit_parser.default"
    assert callable(current_commit_parser())

    config["commit_parser"] = "semantic_release.commit_parser"
    assert callable(current_commit_parser())



# Generated at 2022-06-12 07:08:48.017171
# Unit test for function overload_configuration
def test_overload_configuration():
    options = {'define': ['token=123', 'tag-format=%(version)s']}

    @overload_configuration
    def f(option):
        print(option)

    f(options)
    assert config['token'] == '123'
    assert config['tag-format'] == '%(version)s'

# Generated at 2022-06-12 07:08:49.010620
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser()

# Generated at 2022-06-12 07:08:53.200277
# Unit test for function current_changelog_components
def test_current_changelog_components():
    """
    The test case to check current_changelog_components function
    """
    config["changelog_components"] = "semantic_release.changelogs:components"
    components=current_changelog_components()
    for component in components:
        assert component.__name__ == "components"


# Generated at 2022-06-12 07:09:00.319191
# Unit test for function overload_configuration
def test_overload_configuration():
    def my_func(defined=[]):
        return defined

    attr = "foo"
    attr_value = "bar"
    my_func_overloaded = overload_configuration(my_func)
    assert my_func(defined=[f"{attr}={attr_value}"]) == [f"{attr}={attr_value}"]
    assert my_func_overloaded(defined=[f"{attr}={attr_value}"]) == [f"{attr}={attr_value}"]
    assert config[attr] == attr_value

# Generated at 2022-06-12 07:09:10.141553
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # Tests the default values
    test = ['semantic_release.changelog.components.python_version',
            'semantic_release.changelog.components.changelog_release_message',
            'semantic_release.changelog.components.changelog_commits',
            'semantic_release.changelog.components.changelog_contributors']
    assert (current_changelog_components() == test)
    # If a value is not correct an ImproperConfigurationError is raised
    with pytest.raises(ImproperConfigurationError):
        # Fake value
        config['changelog_components'] = 'semantic_release.changelog.components.python.version'
        current_changelog_components()

# Generated at 2022-06-12 07:09:18.965115
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "test_value"
    @overload_configuration
    def test_func(define):
        return

    # Test the update of config works
    test_func(define=["test=overloaded_value"])
    assert config["test"] == "overloaded_value"
    # Test that the config doesn't get overloaded if value is missing
    test_func(define=["test2="])
    assert "test2" not in config
    # Test that the config doesn't get overloaded if the format is wrong
    test_func(define=["test=overloaded_value=extra_value"])
    assert config["test"] == "overloaded_value"

# Generated at 2022-06-12 07:09:45.176515
# Unit test for function overload_configuration
def test_overload_configuration():
    config_copy = config.copy()
    config["release_branch"] = "master"
    config["major_on_zero"] = False
    config["patch_without_tag"] = False

    @overload_configuration
    def function(release_branch, major_on_zero, patch_without_tag):
        assert config["release_branch"] == release_branch
        assert config["major_on_zero"] == major_on_zero
        assert config["patch_without_tag"] == patch_without_tag

    function(define=["release_branch=dev", "major_on_zero=True", "patch_without_tag=True"])
    config.update(config_copy)

# Generated at 2022-06-12 07:09:50.030512
# Unit test for function overload_configuration
def test_overload_configuration():
    # Initialize config
    config["changelog_components"] = "changelog.changelog.get_changelog"

    def test_function(define=["changelog_components=tests.helpers.test_configuration.CurrentChangelogComponent"]):
        return current_changelog_components()

    @overload_configuration
    def test():
        return test_function()

    current_changelog = test()[0]()
    assert current_changelog == "CurrentChangelogComponent"

# Generated at 2022-06-12 07:09:53.710532
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from . import commit_parser

    assert config.get("commit_parser") == "semantic_release.commit_parser"
    result = current_commit_parser()
    assert result == commit_parser



# Generated at 2022-06-12 07:09:58.744928
# Unit test for function overload_configuration
def test_overload_configuration():
    # Overload config
    @overload_configuration
    def adder(a, b):
        return a + b

    assert adder(5, 8, define=["a=3", "b=5"]) == 8

    # No overload config
    @overload_configuration
    def adder2(a, b):
        return a + b

    assert adder2(5, 8) == 13

# Generated at 2022-06-12 07:10:03.527778
# Unit test for function overload_configuration
def test_overload_configuration():
    config["define"] = "some_key=some_value"
    def test_function():
        pass
    test_overload_configuration = overload_configuration(test_function)
    assert "some_value" == config["some_key"]
    config["some_key"] = "old_value"



# Generated at 2022-06-12 07:10:10.446191
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def foo(*args, **kwargs):
        return (args, kwargs)

    assert foo(1, 2, 3, a=4, b=5, define=["foo=bar", "hello=world"]) == (
        (1, 2, 3),
        {"a": 4, "b": 5, "define": ["foo=bar", "hello=world"]},
    )
    assert config["foo"] == "bar"
    assert config["hello"] == "world"

# Generated at 2022-06-12 07:10:16.532813
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    config["bar"] = "baz"

    @overload_configuration
    def test(define):
        return

    test(define=["foo"])
    assert config["foo"] == "bar"

    test(define=["bar=desk"])
    assert config["bar"] == "desk"

# Generated at 2022-06-12 07:10:19.721677
# Unit test for function overload_configuration
def test_overload_configuration():
    from .cli import parse_args

    args = ["release", "--define", "major_on_zero=true"]
    parsed_args = parse_args(args)
    assert config.get("major_on_zero") is True

# Generated at 2022-06-12 07:10:27.329437
# Unit test for function current_commit_parser
def test_current_commit_parser():

    bad_url = current_commit_parser()
    assert isinstance(bad_url, Callable)
    assert bad_url.__name__ == "_bad_url"

    # Now change the config to use a different commit parser
    config["commit_parser"] = "semantic_release.commit_parser:_good_url"
    good_url = current_commit_parser()
    assert isinstance(good_url, Callable)
    assert good_url.__name__ == "_good_url"



# Generated at 2022-06-12 07:10:34.690763
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test the overload_configuration function with a decorator."""
    assert config.get("upload_to_pypi")
    assert config.get("upload_to_release")

    @overload_configuration
    def disable_upload():
        assert not config.get("upload_to_pypi")
        assert not config.get("upload_to_release")

    disable_upload(define=["upload_to_pypi=false", "upload_to_release=false"])