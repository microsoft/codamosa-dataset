

# Generated at 2022-06-12 07:01:02.460799
# Unit test for function current_changelog_components
def test_current_changelog_components():
    @current_changelog_components.overload
    def get_components():
        return [
            "tests.changelog_components.invalid_component",
            "tests.changelog_components.valid_component",
        ]

    with get_components() as components:
        assert len(components) == 1
        assert components[0].__name__ == "valid_component"



# Generated at 2022-06-12 07:01:13.871261
# Unit test for function overload_configuration
def test_overload_configuration():
    """Function overload_configuration should transform override string
    into a dictionary of key/value.
    This unit test asserts that a fake configuration string is transformed
    as expected.
    """
    override = {
        "changelog_components": "semantic_release.changelog.changelog_components.default",
        "commit_parser": "semantic_release.commit_parser.parse_commit",
        "python_requires": ">=3.6, <4",
    }
    define = [
        "changelog_components=foo",
        "commit_parser=bar",
        "python_requires=>=3.6, <4",
        "changelog_components=foo1,foo2,foo3",
        "key_nonexistent=bootstrap",
    ]

# Generated at 2022-06-12 07:01:37.085586
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release import config as module_config

    assert module_config.config["commit_parser"] == "semantic_release.commit_parser.parse_own"

    @overload_configuration
    def config_definition():
        return config

    assert config_definition()["commit_parser"] == "semantic_release.commit_parser.parse_own"

    @overload_configuration
    def config_definition_with_define():
        return config

    module_config.config["commit_parser"] = "semantic_release.commit_parser.parse_own"
    assert config_definition_with_define(define=["commit_parser=semantic_release.commit_parser.parse_generic"])["commit_parser"] == "semantic_release.commit_parser.parse_generic"

# Generated at 2022-06-12 07:01:43.357481
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(a):
        return a

    assert test_func(a="b") == "b"

    @overload_configuration
    def test_func2(a):
        return config[a]

    config["c"] = "d"
    assert test_func2(a="c", define=["c=e"]) == "e"



# Generated at 2022-06-12 07:01:48.677741
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test"] = "first value"
    @overload_configuration
    def test_func(define=None):
        if define is None:
            return config["test"]
        else:
            return config["test"]
    print(test_func())
    print(test_func(define=None))
    print(test_func(define="test=second value"))
test_overload_configuration()

# Generated at 2022-06-12 07:01:56.390434
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def return_config(define=None):
        assert isinstance(define, list)
        return config

    assert return_config() == return_config(define=[])
    new_config = dict(config)
    new_config["test"] = 23
    assert return_config(define=["test=23"]) == return_config(define=["test=23", "test=23"]) == new_config
    assert return_config(define="test=23") == new_config
    assert return_config(define=["test"]) == config
    assert return_config(define=["toto=titi"]) == config

# Generated at 2022-06-12 07:02:04.243820
# Unit test for function current_changelog_components
def test_current_changelog_components():
    cp1 = current_changelog_components()
    # To test if the function can import a user-defined function.
    config["changelog_components"] = "tests.test_helpers.current_changelog_components"
    cp2 = current_changelog_components()
    # To test if the function catches the ImportError.
    config["changelog_components"] = "tests.test_helpers.not_a_function"
    with pytest.raises(ImproperConfigurationError):
        cp3 = current_changelog_components()
    # To test if the function catches the AttributeError.
    config["changelog_components"] = "tests.test_helpers.NoFunction"
    with pytest.raises(ImproperConfigurationError):
        cp4 = current_changel

# Generated at 2022-06-12 07:02:09.871495
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the decorator overload_configuration succeeds to modify config
    """

    config_before = config
    config_after = dict(config)
    config_after["a_key"] = "a_value"

    @overload_configuration
    def something_here(define):
        pass

    something_here(define=["a_key=a_value"])

    assert config_before == config_after

# Generated at 2022-06-12 07:02:14.586356
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(*args, **kwargs):
        return config.get("upload_to_release")

    assert f() == config.get("upload_to_release")
    assert f(define=["upload_to_release=false"]) == "false"

# Generated at 2022-06-12 07:02:19.775116
# Unit test for function current_changelog_components
def test_current_changelog_components():
    if not hasattr(config, "get"):
        config.get = lambda item: ""
    config["changelog_components"] = "semantic_release.changelog.header,tests.changelog.footer"
    assert current_changelog_components() == [header, footer]



# Generated at 2022-06-12 07:02:30.275888
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "test_value"

    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define=["test_key=new_value"]) == "new_value"

# Generated at 2022-06-12 07:02:34.725539
# Unit test for function overload_configuration
def test_overload_configuration():
    """The test checks if the key/value are being added to config through
    overload_configuration.
    """

    @overload_configuration
    def test_function(define):
        return config["test_key"]

    assert test_function(define="test_key=test_value") == "test_value"

# Generated at 2022-06-12 07:02:35.474974
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert current_commit_parser() is not None

# Generated at 2022-06-12 07:02:43.987448
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function(define=None):
        assert config["project_name"] == 'example-package'
        assert config["commits_changelog"] == '4c448f4,b049937:1c97a9a'
        assert config["changelog_components"] == 'semantic_release.changelog_components.changelog_component:changes_component'

    test_function(define=["project_name=example-package",
                          "commits_changelog=4c448f4,b049937:1c97a9a",
                          "changelog_components=semantic_release.changelog_components.changelog_component:changes_component"])

# Generated at 2022-06-12 07:02:51.476528
# Unit test for function current_changelog_components
def test_current_changelog_components():
    # This unit test requires that the entry "changelog_components" in the configuration file
    # is not empty
    if config.get("changelog_components") == "":
        raise ImproperConfigurationError(
            "The entry 'changelog_components' in the configuration file is empty"
        )
    # Call the function and test if it returns a list of functions
    assert callable(current_changelog_components()[0])



# Generated at 2022-06-12 07:02:57.133632
# Unit test for function overload_configuration
def test_overload_configuration():
    original_config = config

    class MockConfig:
        get = lambda self, k: original_config[k]

    config = MockConfig()

    @overload_configuration
    def return_config_value():
        return config.get("commit_parser")

    assert return_config_value() == "semantic_release.commit_parser.parse"
    assert return_config_value(define=["commit_parser=my_value"]) == "my_value"
    config = original_config

# Generated at 2022-06-12 07:03:01.638052
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def hello(define=None):
        return config.get("major_without_tag") is True

    assert hello(define=["major_without_tag=True"]) == True
    assert hello(define=["major_without_tag=False"]) == False

# Generated at 2022-06-12 07:03:11.671806
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test method for overload_configuration"""

    @overload_configuration
    def test_func(param1, define):
        return param1
    config["changelog_components"] = "noop"
    config["version_variable"] = "__version__"
    config["version_scheme"] = "guess-next-dev"
    config["tag_format"] = "v{new_version}"
    config["major_on_zero"] = True
    result = test_func('test', ['changelog_components=version', "version_variable=__version_test__",
                                "tag_format=newtag-{new_version}", "major_on_zero=False"])
    assert result == "test"
    assert config["changelog_components"] == "version"

# Generated at 2022-06-12 07:03:13.057976
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(define):
        return config["something"]

    assert func(define=["something=value1"]) == "value1"
    assert func(define=["something=value2"]) == "value2"

# Generated at 2022-06-12 07:03:18.468777
# Unit test for function overload_configuration
def test_overload_configuration():
    config.clear()
    config["hello"] = "world"
    config["foo"] = "bar"

    @overload_configuration
    def foo():
        return config["hello"] + " " + config["foo"]

    assert foo() == "world bar"

    foo(define=["hello=cruel"])
    assert config["hello"] == "cruel"
    assert foo() == "cruel bar"

    foo(define=["hello=cruel", "foo=world"])
    assert config["hello"] == "cruel"
    assert config["foo"] == "world"
    assert foo() == "cruel world"



# Generated at 2022-06-12 07:03:34.134755
# Unit test for function overload_configuration
def test_overload_configuration():
    import semantic_release.cli as cli
    cli.config['verbose_level'] = 0
    cli.config['package_files'] = ''
    # New values for config
    fake_config = [
        "package_files=my_package_file",
        "verbose_level=9001"
    ]
    # Execute in order to overload the config
    cli.main(["check"], define=fake_config)
    # Confirm that config was edited (without side effects)
    assert config['verbose_level'] == '9001'
    assert config['package_files'] == 'my_package_file'
    assert cli.config['verbose_level'] == 0
    assert cli.config['package_files'] == ''

# Generated at 2022-06-12 07:03:39.366110
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def f(define=None):
        return None

    f(define=["a=1", "b=2"])
    assert config["a"] == "1", "a should be 1"
    assert config["b"] == "2", "b should be 2"

    # Define array is optional
    f()

# Generated at 2022-06-12 07:03:42.582004
# Unit test for function overload_configuration
def test_overload_configuration():
    from .commands import publish

    config['package_name'] = 'original_package_name'
    publish(define=['package_name=overloaded_package_name'])
    assert config == {'package_name': 'overloaded_package_name'}

# Generated at 2022-06-12 07:03:47.972353
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import components

    for key in components.__dict__.keys():
        if key[0].isupper():
            config['changelog_components'] = 'semantic_release.changelog.components.' + key
            changelog_components = current_changelog_components()
            assert len(changelog_components) == 1
            assert changelog_components[0].__name__ == key

# Generated at 2022-06-12 07:03:51.959930
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Function 'current_commit_parser' gets parser function name from the
    'commit_parser' item and returns the parser function specified.
    """
    assert callable(current_commit_parser()) is True



# Generated at 2022-06-12 07:03:53.274562
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert isinstance(current_commit_parser(), Callable)


# Generated at 2022-06-12 07:03:58.740315
# Unit test for function overload_configuration
def test_overload_configuration():
    """This test verifies the @overload_configuration decorator changes config
    as expected.
    """
    config.clear()
    config["plugin_config"] = {}

    @overload_configuration
    def test_method(define):
        pass

    test_method(define=["foo=bar"])
    assert config["foo"] == "bar"

    test_method(define=["foo=baz"])
    assert config["foo"] == "baz"

# Generated at 2022-06-12 07:04:04.451622
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def foo(define):
        return

    foo(define="foo=bar")
    assert config["foo"] == "bar"
    foo(define=["foo=dummy"])
    assert config["foo"] == "dummy"
    foo(define=["foo=dummy2", "baz=baz"])
    assert config["foo"] == "dummy2"
    assert config["baz"] == "baz"

# Generated at 2022-06-12 07:04:07.633394
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return config

    new_config = test_func(define=["name=new name"])
    assert new_config["name"] == "new name"

# Generated at 2022-06-12 07:04:16.108440
# Unit test for function overload_configuration
def test_overload_configuration():
    global config

    # Test that the config has the right values
    assert config.get("changelog_components") == "semantic_release.changelog.components.gitlab_component"
    assert config.get("changelog_scope") is True

    # Mock the "define" input of the decorator
    @overload_configuration
    def define(define):
        pass

    define(define=["changelog_components=test.test_changelog_components", "changelog_scope=False"])

    assert config.get("changelog_components") == "test.test_changelog_components"
    assert config.get("changelog_scope") is False

# Generated at 2022-06-12 07:04:31.981550
# Unit test for function overload_configuration
def test_overload_configuration():
    from .utils import read_setup_cfg
    from .utils import get_config_value

    @overload_configuration
    def test_fn(define):
        return True

    # Test: nothing
    assert test_fn(define=None) is True

    # Test: one value
    assert test_fn(define="one=1") is True
    assert get_config_value("one") == "1"

    # Test: two values
    assert test_fn(define="one=1,two=2") is True
    assert get_config_value("one") == "1"
    assert get_config_value("two") == "2"

    # Test: values with wrong format
    assert test_fn(define="one=1,two=2,three") is True
    assert get_config_value("one") == "1"

# Generated at 2022-06-12 07:04:40.887632
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_function():
        return [config[key] for key in config]

    config["hello"] = "world"
    assert test_function() == ["world"]

    keys = ["define", "foo", "bar", "hello"]
    values = ["foo=1", "2", "3", "world"]
    params = {key:value for key, value in zip(keys, values)}
    test_function(**params)
    assert config["foo"] == "1"
    assert config["bar"] == "2"
    assert config["hello"] == "world"

# Generated at 2022-06-12 07:04:46.088045
# Unit test for function overload_configuration
def test_overload_configuration():
    config['key1'] = 'value1'
    config['key2'] = 'value2'
    assert config['key1'] == 'value1'
    assert config['key2'] == 'value2'

    @overload_configuration
    def overwrite_config(define):
        pass

    overwrite_config(define=['key1=overwritten1'])
    assert config['key1'] == 'overwritten1'

    overwrite_config(define=['key2=overwritten2'])
    assert config['key2'] == 'overwritten2'

# Generated at 2022-06-12 07:04:56.736898
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test for the overload_configuration decorator"""

    @overload_configuration
    def func1(arg1=None):
        return config[arg1] if arg1 else None

    @overload_configuration
    def func2(arg1=None, arg2=None, define=[]):
        return config[arg1] if arg1 else None

    config["new_key"] = "default_value"
    assert func1(arg1="new_key") == "default_value"

    assert func1() is None
    assert func2(arg1="new_key") == "default_value"
    assert func2(arg2="new_key") is None

    func2(define=["foo=bar", "bar=baz"])
    assert config["foo"] == "bar"

# Generated at 2022-06-12 07:05:03.315353
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(arg1, arg2, arg3="hello"):
        print(arg1, arg2, arg3)
        return arg1, arg2, arg3

    assert func("foo", "bar", define=["arg1=1", "arg2=2", "arg3=3"]) == ("1", "2", "3")

# Generated at 2022-06-12 07:05:09.900207
# Unit test for function overload_configuration
def test_overload_configuration():
    # Nothing to change in config
    assert overload_configuration(
        lambda x: config["changelog_scope"]
    )("patch", define=[]) == "major"
    # Change parameter in config
    assert overload_configuration(
        lambda x: config["changelog_scope"]
    )("patch", define=["changelog_scope=minor"]) == "minor"
    # Create new parameter in config
    assert config.get("new") is None
    assert overload_configuration(
        lambda x: config["new"]
    )("patch", define=["new=wow"]) is None
    assert config.get("new") == "wow"

# Generated at 2022-06-12 07:05:14.460898
# Unit test for function overload_configuration
def test_overload_configuration():
    config["test_key"] = "Default value"

    @overload_configuration
    def test(define):
        return config

    modified_config = test(define=["test_key=Modified value"])
    assert modified_config["test_key"] == "Modified value"

    default_config = test()
    assert default_config["test_key"] == "Default value"

# Generated at 2022-06-12 07:05:20.864877
# Unit test for function overload_configuration
def test_overload_configuration():
    # Test with no parameters
    assert config.get("publish_to") == "pypi"

    # Define publish to "testpypi"
    overload_configuration(lambda x: None)(define=["publish_to=testpypi"])
    assert config.get("publish_to") == "testpypi"

    # Reset
    config.clear()
    config.update(_config())
    assert config.get("publish_to") == "pypi"

# Generated at 2022-06-12 07:05:25.701247
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(a, b, c, define=None):
        return a + b + c

    assert func(1, 2, 3, define=["a=1", "b=2"]) == 6
    assert config["a"] == "1"
    assert config["b"] == "2"

# Generated at 2022-06-12 07:05:30.977884
# Unit test for function current_changelog_components
def test_current_changelog_components():
    components = current_changelog_components()
    assert len(components) == 5
    assert components[0]().__name__ == 'commit_parser'
    assert components[1]().__name__ == 'previous_version'
    assert components[2]().__name__ == 'removed_features'
    assert components[3]().__name__ == 'added_features'
    assert components[4]().__name__ == 'fixed_bugs'

# Generated at 2022-06-12 07:05:41.579059
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test(define):
        return config.get('foo')

    assert test(define=['foo=bar']) == 'bar'

# Generated at 2022-06-12 07:05:45.099701
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def function(define):
        return define

    assert function(define=["Hello=World"]) == ["Hello=World"]
    assert config.get("Hello") == "World"

# Generated at 2022-06-12 07:05:54.571514
# Unit test for function overload_configuration
def test_overload_configuration():
    from semantic_release.cli import parse_args
    from . import prepare_config
    from .errors import ImproperConfigurationError

    local_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(local_dir, "testdata")
    r = parse_args(["--config", "testdata/tox.ini", "--define", "plugin_config={}"])
    prepare_config(r)
    assert r.config == os.path.join(test_dir, "tox.ini")
    with open(os.path.join(test_dir, "tox.ini")) as f:
        config_content = f.read()
    assert "{}" in config_content
    assert config["plugin_config"] == "{}"



# Generated at 2022-06-12 07:05:58.995410
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def my_function(my_param: str):
        return config.get(my_param)

    assert my_function(my_param="no_edit") == "true"
    assert my_function(my_param="no_edit", define=["no_edit=false"]) == "false"

# Generated at 2022-06-12 07:06:03.484986
# Unit test for function overload_configuration
def test_overload_configuration():
    assert config.get('major_on_zero') == False
    @overload_configuration
    def test_func(major_on_zero):
        assert config.get('major_on_zero') == major_on_zero
        return True

    assert test_func(define=['major_on_zero=True'])

# Generated at 2022-06-12 07:06:10.457288
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def f(a, b, c, define=None):
        assert a == 1
        assert b == 2
        assert c == 3

    f(1, 2, 3)
    f(1, 2, 3, define=["a=1"])
    f(1, 2, 3, define=["a=1", "b=2"])
    f(1, 2, 3, define=["a=1", "b=2", "c=3"])

# Generated at 2022-06-12 07:06:17.477202
# Unit test for function overload_configuration
def test_overload_configuration():
    config = {}

    def func(foo, bar):
        config["foo"] = foo
        config["bar"] = bar

    # The config dict is empty
    assert config == {}
    # We call our decorated function without definitioons
    func("1", "2")
    # The config dict is NOT empty
    assert config == {"foo": "1", "bar": "2"}
    # We reset the config dict
    config = {}
    # Call the decorated function but with defined parameters
    func("1", "2", define=["foo=5", "bar=6"])
    # Since we passed definitions for foo and bar then the config dict must contain them
    assert config == {"foo": "5", "bar": "6"}

# Generated at 2022-06-12 07:06:20.572558
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func(**kwargs):
        return True

    assert func(define=["foo=bar"])
    assert config["foo"] == "bar"

# Generated at 2022-06-12 07:06:25.867599
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test that the "overload_configuration" decorator works properly."""
    @overload_configuration
    def _overload_configuration_test(define=None):
        return configure("test", define)

    configure("test", "foo=bar")
    assert config["test"] == "foo"
    _overload_configuration_test(define=["foo=baz"])
    assert config["test"] == "baz"

# Generated at 2022-06-12 07:06:28.670568
# Unit test for function overload_configuration
def test_overload_configuration():
    from .parsers import parse_message

    parse_message(message="fix(scope): release note", define=["patch_without_tag=0"])
    assert config["patch_without_tag"] == "0"

# Generated at 2022-06-12 07:06:37.069392
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())

# Generated at 2022-06-12 07:06:40.580676
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def test_func(define):
        return define

    assert test_func(define=['sample="data"']) == ['sample="data"']

# Generated at 2022-06-12 07:06:42.614462
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.parse_commits import parse_commits

    assert current_commit_parser() == parse_commits

# Generated at 2022-06-12 07:06:48.670389
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function tests the decorator overload_configuration."""
    config['test'] = 'false'

    @overload_configuration
    def test_func(define: str):
        assert type(define) == str

    test_func(define='test=true')
    assert config['test'] == 'true'
    test_func(define='')

# Generated at 2022-06-12 07:06:56.978960
# Unit test for function overload_configuration
def test_overload_configuration():
    # At the beginning of this test, we should have only the default values in
    # config
    assert config == {}

    @overload_configuration
    def fake_function(define):
        pass

    # We can define new key-value pairs, or edit the existing ones
    fake_function(define=["key=value", "other_key=other_value"])
    assert config["key"] == "value"
    assert config["other_key"] == "other_value"
    fake_function(define=["key=new_value"])
    assert config["key"] == "new_value"

# Generated at 2022-06-12 07:07:01.898595
# Unit test for function overload_configuration
def test_overload_configuration():
    """Unit test overload_configuration"""
    def func(self, test, define=[]):
        return True

    func = overload_configuration(func)

    assert func(None, "test", define=["foo=bar"])
    assert config["foo"] == "bar"

    del config["foo"]
    assert func(None, "test")

# Generated at 2022-06-12 07:07:04.980068
# Unit test for function overload_configuration
def test_overload_configuration():
    func = lambda: 0
    overload_configuration(func)(define=["a=1", "b=4"])
    assert config["a"] == "1"
    assert config["b"] == "4"

# Generated at 2022-06-12 07:07:13.163983
# Unit test for function overload_configuration
def test_overload_configuration():
    from unittest.mock import call

    class Mock(object):
        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    fn = overload_configuration(Mock)

    # Test without parameters
    fn()
    assert not hasattr(fn, "args")
    assert not hasattr(fn, "kwargs")

    # Test with one parameter and with "define" parameter
    fn(1, define=["foo=bar"])
    assert fn.args == (1, )
    assert fn.kwargs == {"define": ["foo=bar"]}
    assert config["foo"] == "bar"

    # Test with "define" and "foo" parameters
    fn(define=["foo=bar", "foo=spam"], foo="eggs")


# Generated at 2022-06-12 07:07:19.183486
# Unit test for function overload_configuration
def test_overload_configuration():
    import unittest

    class TestOverloadConfiguration(unittest.TestCase):
        def test_overload_configuration_function(self):

            @overload_configuration
            def test_function(**kwargs):
                return 0

            params = {"define": ["new_key=new_value", "new_key2=new_value2"]}
            result = test_function(**params)

            self.assertEqual(result, 0)
            self.assertEqual(config["new_key"], "new_value")
            self.assertEqual(config["new_key2"], "new_value2")

    unittest.main()

# Generated at 2022-06-12 07:07:23.171721
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.components.user_stories"
    assert callable(current_changelog_components()[0])

# Generated at 2022-06-12 07:07:40.977353
# Unit test for function overload_configuration
def test_overload_configuration():
    def test_func():
        return config["define_key"]

    def test_overload_func():
        return config["define_key"]

    # test_func does not have overload_configuration decorator
    # This is used to compare with test_overload_func()
    assert test_func() is None

    # test_overload_func() has overload_configuration decorator
    # So it should change the config["define_key"]
    test_overload_func(define=["define_key=test_value"])
    assert test_overload_func() == "test_value"

# Generated at 2022-06-12 07:07:42.329882
# Unit test for function current_commit_parser
def test_current_commit_parser():
    assert callable(current_commit_parser())


# Unit tests for function current_changelog_components

# Generated at 2022-06-12 07:07:54.245602
# Unit test for function overload_configuration
def test_overload_configuration():

    @overload_configuration
    def my_function(define=None):
        return config

    # A function to check if the global object contains the key and if it has the expected value
    def assert_overload_configuration(key, value):
        config = my_function(define=["{0}={1}".format(key, value)])
        assert key in config, "Attribute {0} must be in config".format(key)
        assert config[key] == value, "Attribute {0} must have value {1}"

    assert_overload_configuration("python_files", "*.py")
    assert_overload_configuration("semantic_release", "1")
    assert_overload_configuration("plugin_version", "0.0.1")
    # Check that an empty string value is accepted (i.e. no

# Generated at 2022-06-12 07:08:02.884771
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    Test if the decorator overload_configuration() works as expected.
    """
    from semantic_release.cli import main

    def main_callback(args):
        return args

    main_orig = main.main
    main.main = main_callback
    try:
        assert main(["prepare", "--define", "dummy_var=value"]) == {
            "action": "prepare",
            "define": ["dummy_var=value"],
        }
        assert "dummy_var" in config
    finally:
        main.main = main_orig



# Generated at 2022-06-12 07:08:06.760890
# Unit test for function overload_configuration
def test_overload_configuration():
    config["hello"] = "world"
    config["foo"] = "bar"

    @overload_configuration
    def test(define):
        pass

    test(define=["hello=pony"])
    assert config["hello"] == "pony"
    assert config["foo"] == "bar"

# Generated at 2022-06-12 07:08:08.891669
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Unit test for the function current_commit_parser."""

    assert current_commit_parser().__name__ == "default_parse_function"

# Generated at 2022-06-12 07:08:16.346961
# Unit test for function overload_configuration
def test_overload_configuration():
    config["foo"] = "bar"
    config["baz"] = "qux"

    @overload_configuration
    def use_config():
        assert config["foo"] == "bar"
        assert config["baz"] == "qux"

    use_config()

    @overload_configuration
    def use_config_overloaded(define):
        assert config["foo"] == "gar"
        assert config["baz"] == "qux"

    use_config_overloaded(define=["foo=gar"])

# Generated at 2022-06-12 07:08:22.500710
# Unit test for function current_commit_parser
def test_current_commit_parser():
    from semantic_release.commit_parser import parse_commits, parse_commits_with_scope
    assert current_commit_parser() == parse_commits
    config["commit_parser"] = "semantic_release.commit_parser.parse_commits"
    assert current_commit_parser() == parse_commits
    config["commit_parser"] = "semantic_release.commit_parser.parse_commits_with_scope"
    assert current_commit_parser() == parse_commits_with_scope

# Generated at 2022-06-12 07:08:30.943035
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config.setdefault(
        "changelog_components", "semantic_release.changelog_components.git_log"
    )
    assert current_changelog_components() == [
        semantic_release.changelog_components.git_log
    ]
    config.setdefault(
        "changelog_components",
        "semantic_release.changelog_components.git_log,"
        "semantic_release.changelog_components.github_api",
    )
    assert current_changelog_components() == [
        semantic_release.changelog_components.git_log,
        semantic_release.changelog_components.github_api,
    ]



# Generated at 2022-06-12 07:08:34.128189
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release.changelog import Issue, BreakingChange, GeneralChange

    current_components = current_changelog_components()
    assert Issue in current_components
    assert BreakingChange in current_components
    assert GeneralChange in current_components



# Generated at 2022-06-12 07:08:52.748194
# Unit test for function current_changelog_components
def test_current_changelog_components():
    import vcs
    current_changelog_components.__module__ = "semantic_release.vcs"

# Generated at 2022-06-12 07:08:56.894652
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test overloading of config file with command line arguments to
    the `setup.py release` command.
    """

    @overload_configuration
    def echo(**kwargs):
        return config["github_owner"]

    assert echo(define=["github_owner=Hello"]) == "Hello"

# Generated at 2022-06-12 07:08:58.486989
# Unit test for function current_changelog_components
def test_current_changelog_components():
    assert current_changelog_components() == []

# Generated at 2022-06-12 07:09:07.439203
# Unit test for function overload_configuration
def test_overload_configuration():
    """This tests overload_configuration()
    """

    config["test_overload_configuration_key"] = "test_overload_configuration_value"

    @overload_configuration
    def my_function(**kwargs):
        assert config["test_overload_configuration_key"] == kwargs["test_overload_configuration_key"]

    my_function(define="test_overload_configuration_key=test_overload_configuration_value_defined")

# Generated at 2022-06-12 07:09:17.854330
# Unit test for function overload_configuration
def test_overload_configuration():
    """Test of the "overload_configuration" decorator

    On a test function, we set an argument named "define", with a list of string
    containing the "key=value" pairs we want to set in config.
    Then, config is reloaded, and we check that the values we have set are in config
    """

    @overload_configuration
    def test_function(define=None):
        return True

    test_function(define=["new_key=1", "new_key_2=2"])
    _config_bis = _config()
    assert _config_bis["new_key"] == "1"
    assert _config_bis["new_key_2"] == "2"

# Generated at 2022-06-12 07:09:23.730572
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def func2(x):
        return x

    func2(3, define=["variable=4", "another=variable"])

    # given variable was defined as 4 in previous function invocation
    assert config["variable"] == "4"
    # given another was defined as "variable" in previous function invocation
    assert config["another"] == "variable"

    # given variable has no default value
    assert "variable" in config
    # given another has no default value
    assert "another" in config

# Generated at 2022-06-12 07:09:26.693247
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config['changelog_comonents'] = "semantic_release.components.Releases"
    assert current_changelog_components() == ['Releases']

# Generated at 2022-06-12 07:09:29.703749
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = "semantic_release.changelog.DefaultComponent"
    assert current_changelog_components == [
        semantic_release.changelog.DefaultComponent
    ]

# Generated at 2022-06-12 07:09:34.136315
# Unit test for function overload_configuration
def test_overload_configuration():
    "Test if the decorator overload_configuration works as expected"
    # pylint: disable=unused-variable
    @overload_configuration
    def mock_function(define):
        "Mock function to test the decorator overload_configuration. Not actualy used."
        pass

    mock_function(define="test=test")
    assert config["test"] == "test"

# Generated at 2022-06-12 07:09:36.840749
# Unit test for function overload_configuration
def test_overload_configuration():
    """
    This method test the decorator "overload_configuration" and its effects on
    the class "config". This method is used for testing purpose only.
    """
    assert config.get("remove_dist")



# Generated at 2022-06-12 07:09:51.496133
# Unit test for function current_changelog_components
def test_current_changelog_components():
    from semantic_release import changelog

    # Get the current config
    old_config = config.copy()

    # Force "changelog_components" to have an invalid value
    config["changelog_components"] = "foobar,baz"
    try:
        current_changelog_components()
    except ImproperConfigurationError as e:
        received_msg = e.args[0]
        expected_msg = 'Unable to import changelog component "baz"'
        assert received_msg == expected_msg
    else:
        raise Exception("Should have thrown ImproperConfigurationError")

    # Force "changelog_components" to have an valid value

# Generated at 2022-06-12 07:10:00.361850
# Unit test for function current_changelog_components
def test_current_changelog_components():
    config["changelog_components"] = (
        "semantic_release.changelog_components.summary_header,"
        "semantic_release.changelog_components.summary_footer,"
        "semantic_release.changelog_components.features,"
        "semantic_release.changelog_components.bugs,"
        "semantic_release.changelog_components.other"
    )
    assert len(current_changelog_components()) == 5
    assert current_changelog_components()[0].__name__ == "summary_header"
    assert current_changelog_components()[1].__name__ == "summary_footer"
    assert current_changelog_components()[2].__name__ == "features"
    assert current_changel

# Generated at 2022-06-12 07:10:05.265456
# Unit test for function overload_configuration
def test_overload_configuration():
    # Arrange
    @overload_configuration
    def test(param):
        return param

    # Act & Assert
    assert test({'define': ['key=value']}) == {'define': ['key=value']}
    assert 'key' in config
    assert config['key'] == 'value'

# Generated at 2022-06-12 07:10:08.974226
# Unit test for function overload_configuration
def test_overload_configuration():
    @overload_configuration
    def dummy(dummy):
        return dummy

    config["dummy"] = 0
    dummy(define=["dummy=1"], dummy="dummy")
    assert config["dummy"] == "1"

# Generated at 2022-06-12 07:10:21.072045
# Unit test for function overload_configuration
def test_overload_configuration():
    """This function checks if the function overload_configuration works as
    intended by calling the function with a mock configuration and defining a
    configuration key
    """
    global config
    tmp_config = config
    # We do not want to modify the actual configuration

# Generated at 2022-06-12 07:10:25.293006
# Unit test for function current_commit_parser
def test_current_commit_parser():
    """Test current_commit_parser().

    :raises ImproperConfigurationError: if ImportError or AttributeError is raised
    :returns: Commit parser
    """
    commit_parser = current_commit_parser()
    assert callable(commit_parser)

# Generated at 2022-06-12 07:10:30.472794
# Unit test for function overload_configuration
def test_overload_configuration():
    config["version"] = "0.0.0"
    @overload_configuration
    def test(version):
        return version

    assert test(version="1.0.0", define=["version=1.0.0"]) == "1.0.0"
    assert test(version="1.0.0", define=["version=2.0.0"]) == "2.0.0"
    assert config["version"] == "2.0.0"

# Generated at 2022-06-12 07:10:35.200676
# Unit test for function overload_configuration
def test_overload_configuration():
    def function(**kwargs):
        return kwargs

    f = overload_configuration(function)
    assert f(define=["semantic_release.commit_message_template=foo"]) == {"define": ["semantic_release.commit_message_template=foo"]}
    assert config["commit_message_template"] == "foo"

# Generated at 2022-06-12 07:10:44.480088
# Unit test for function overload_configuration
def test_overload_configuration():
    from .vcs import load
    from .utils import get_current_commit

    # Test the case when there is no 'define' in kwargs
    @overload_configuration
    def test():
        return config["default_config_file"]

    assert "default_config_file" in config
    assert test() == config["default_config_file"]

    # Test the case when 'define' exists in kwargs
    @overload_configuration
    def test2():
        return config["default_config_file"]

    default_config_file = config["default_config_file"]
    assert "default_config_file" in config
    assert test2(define=["default_config_file=setup.cfg"]) == "setup.cfg"
    assert config["default_config_file"] == "setup.cfg"

    #

# Generated at 2022-06-12 07:10:46.363318
# Unit test for function current_commit_parser
def test_current_commit_parser():
    function_name = current_commit_parser()
    assert "parse" in function_name.__name__

