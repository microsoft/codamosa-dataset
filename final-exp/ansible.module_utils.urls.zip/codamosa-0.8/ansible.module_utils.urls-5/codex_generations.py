

# Generated at 2022-06-11 06:31:51.101135
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    class SSLValidationHandlerTest(SSLValidationHandler):
        '''A class used to expose the detect_no_proxy method for testing'''
        def __init__(self):
            self.hostname = 'example.org'
            self.port = 443
            self.ca_path = None
        def make_context(self, cafile, cadata):
            pass
        def http_request(self, req):
            pass
        https_request = http_request

    # test without environment variable
    handler = SSLValidationHandlerTest()
    assert handler.detect_no_proxy('https://example.org/')

    # test with environment variable
    os.environ['no_proxy'] = 'example.org'
    handler = SSLValidationHandlerTest()

# Generated at 2022-06-11 06:31:57.199573
# Unit test for function getpeercert
def test_getpeercert():
    # Open a dummy https server to get the cert for testing
    def handler(dummy, response):
        response.write(b'OK')
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    server = HTTPServer(('127.0.0.1', 0), handler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.start()
    try:
        host, port = server.server_address
        response = openurl(u'https://%s:%s' % (host, port))
        cert = getpeercert(response)
        assert cert
        response.close()
    finally:
        server.shutdown()
        server_thread.join()



# Generated at 2022-06-11 06:31:59.338789
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = "https://www.sina.com.cn"
    handler = maybe_add_ssl_handler(url, False)
    print(handler)


# Generated at 2022-06-11 06:32:03.105272
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    # make a temp file
    filepath = tempfile.mktemp()
    # run the function
    atexit_remove_file(filepath)
    # the function should have deleted the temp file
    assert not os.path.exists(filepath)


# Generated at 2022-06-11 06:32:15.607754
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # load a sample certificate
    cert_path = "/path/to/sample/cert.pem"
    with open(cert_path, "rb") as file:
        certificate = ssl.PEM_cert_to_DER_cert(file.read())

    # reference the expected hash value

# Generated at 2022-06-11 06:32:17.807390
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile() as tmp_file:
        atexit_remove_file(tmp_file.name)
        assert not os.path.isfile(tmp_file.name)



# Generated at 2022-06-11 06:32:28.832132
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.six.moves.mock import MagicMock
    class AnsibleModule:
        def __init__(self):
            self.fail_json = MagicMock()
            self.params = {}
        def fail_json(msg):
            pass
    module = AnsibleModule()
    url = 'https://www.github.com/ansible/ansible'
    r, res = fetch_url(module, url)
    assert(res['status'] == 200)
    url = 'invalid url'
    try:
        r, res = fetch_url(module, url)
    except Exception:
        pass
    assert(module.fail_json.called)
    assert(module.fail_json.call_count==4)
    # UT for NoSSLError

# Generated at 2022-06-11 06:32:35.945460
# Unit test for function prepare_multipart
def test_prepare_multipart():

    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    content_type, body = prepare_multipart(fields)
    assert content_type
    assert body



# Generated at 2022-06-11 06:32:39.723667
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # Use SHA256 as the hashing algorithm, so we should get a digest of 32 bytes.
    digest = get_channel_binding_cert_hash(b'\x00' * 32)
    assert len(digest) == 32



# Generated at 2022-06-11 06:32:52.415044
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    from six.moves.urllib.error import URLError
    from six.moves.urllib.parse import urlparse

    def p(url):
        o = urlparse(url)
        return o.scheme, o.hostname, o.port
    old_create_connection = socket.create_connection

# Generated at 2022-06-11 06:34:33.412667
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    # create a file
    module_dir, _ = os.path.split(__file__)
    filename = os.path.join(module_dir, 'atexit_remove_file.test_file')
    fd = open(filename, 'w')
    fd.close()
    # unlink it
    atexit_remove_file(filename)
    # check if the file was removed
    assert not os.path.exists(filename)



# Generated at 2022-06-11 06:34:43.332327
# Unit test for function prepare_multipart
def test_prepare_multipart():
    expected_headers = (
        'Content-Type: multipart/form-data; boundary="===============9041764832722647789=="\r\n'
    )

# Generated at 2022-06-11 06:34:53.493841
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    The following tests were copied from
    https://github.com/ansible/ansible/blob/devel/test/units/modules/utils/test_module_utils_basic.py
    '''
    # Test to make sure that any invalid value for the follow_redirects parameter
    # will be treated as 'no'.
    handler = RedirectHandlerFactory('bogus value')
    req = RequestWithMethod('http://www.example.com', 'GET')
    assert req.get_method() == 'GET'
    try:
        res = handler.redirect_request(req, 'fp', 301, 'msg', {}, 'http://www.example.com/')
    except urllib_error.HTTPError:
        pass
    else:
        assert False, 'Should have raised an HTTPError exception'

   

# Generated at 2022-06-11 06:35:00.900102
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    class MockSocket():
        """Mock class that acts like a socket"""

        def __init__(self, host, port):
            if host == 'invalid_host':
                raise socket.error('Connection refused')
            self.host = host
            self.port = port
            self.timeout_value = socket._GLOBAL_DEFAULT_TIMEOUT
            self.sock = self

        def settimeout(self, timeout):
            self.timeout_value = timeout

        def connect(self, host):
            if self.host != host:
                raise OSError('Invalid Socket File (%s)' % host)

        def __call__(self, *args, **kwargs):
            return self

    uxhttpcon = UnixHTTPConnection('UNIX_SOCKET')
    uxhttpcon.connect()

# Generated at 2022-06-11 06:35:12.428428
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    '''
    Tests validate_proxy_response method of class SSLValidationHandler.
    '''
    valid_response_codes = [200, 202]

    # test with valid code
    ssl_handler = SSLValidationHandler(None, None)
    response_code = '200'
    response = ('HTTP/1.1 200 OK\r\n'
                'Proxy-agent: Netscape-Proxy/1.1\r\n'
                '\r\n')
    try:
        ssl_handler.validate_proxy_response(response, valid_response_codes)
    except:
        assert False, "SSLValidationHandler.validate_proxy_response() failed to process valid code."

    # test with invalid code
    ssl_handler = SSLValidationHandler(None, None)
    response_code = '302'

# Generated at 2022-06-11 06:35:20.096038
# Unit test for function fetch_file
def test_fetch_file():
    ''' test fetch_file function '''
    url_file = 'https://raw.githubusercontent.com/ansible/ansible/stable-2.9/test/httptester.ini'
    temp_file, info = fetch_file(url_file)

    assert os.path.isfile(temp_file)
    assert info['status'] == 200
    assert info['cookies_string'] == ''

    with open(temp_file, 'r') as f:
        content = f.read()
    assert '[test0]' in content
    assert '[test1]' in content


# Generated at 2022-06-11 06:35:24.050714
# Unit test for function getpeercert
def test_getpeercert():
    cert = getpeercert(urllib_request.urlopen("https://www.verisign.com"))
    search_string = "VeriSign"
    assert search_string in str(cert)


if __name__ == '__main__':
    test_getpeercert()

# Generated at 2022-06-11 06:35:35.285793
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class MockCustomHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, *args, **kwargs):
            CustomHTTPSConnection.__init__(self, *args, **kwargs)
            self.source_address = None

        def wrap_socket(self, *args, **kwargs):
            return True

    mock = MockCustomHTTPSConnection('test.test')
    assert mock.host == 'test.test'


# Some environments (Google Compute Engine's CoreOS deploys) do not compile
# against openssl and thus do not have any HTTPS support.
if CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, timeout=60, ssl_context=None, *args, **kwargs):
            urllib_request.HTTPS

# Generated at 2022-06-11 06:35:45.083213
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # This is the common name of the self-signed certificate we use in our mock
    COMMON_NAME = '/C=US/ST=NY/L=Brooklyn/O=Ansible/OU=Ansible/CN=localhost'

    # Create a self-signed cert for unit testing
    req = x509.CertificateSigningRequestBuilder()
    req = req.subject_name(x509.Name([x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, COMMON_NAME)]))

    cert = req.sign(private_key=rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend()),
                    algorithm=hashes.SHA256(),
                    backend=default_backend())

    digest_algs = {}

# Generated at 2022-06-11 06:35:52.723854
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    from ansible.utils.urls import SSLValidationHandler
    ssl_validation_handler = SSLValidationHandler('www.ansible.com', 80)
    response = b'HTTP/1.1 200 Connection established\r\n\r\n'
    ssl_validation_handler.validate_proxy_response(response)
    response = b''
    try:
        ssl_validation_handler.validate_proxy_response(response)
        assert False
    except AssertionError:
        raise
    except Exception as e:
        assert e.__class__.__name__ == 'ProxyError'
        assert str(e) == 'Connection to proxy failed'
    response = b'HTTP/1.1 404 Not Found\r\n\r\n'

# Generated at 2022-06-11 06:37:39.062739
# Unit test for function prepare_multipart
def test_prepare_multipart():

    fields = {
        'file1': {
            'filename': os.path.join(os.path.dirname(__file__), '__init__.py'),
            'mime_type': 'application/octet-stream',
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        },
        'text_form_field': 'value'
    }
    content_type, body = prepare_multipart(fields)
    assert len(body) > 0
    assert content_type.startswith('multipart/form-data; boundary=')

# Windows targets specific implementation of open_url, mainly to deal with the lack of
# the unix socket extension in the windows implementation of python.


# Generated at 2022-06-11 06:37:50.165540
# Unit test for function prepare_multipart
def test_prepare_multipart():
    test_data = {
        'test_string': "Test string",
        'test_file_obj': {
            'filename': os.path.join(TESTS_ROOT, 'test_results.txt'),
            'content': None
        },
        'test_dict': {
            'filename': None,
            'content': "Test string",
        }
    }
    # keys are sorted
    ct, body = prepare_multipart(test_data)

    assert 'multipart/form-data' in ct
    boundary = re.match(r'.*boundary="?([^"]+)"?', ct).group(1)

# Generated at 2022-06-11 06:37:54.654082
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule({
        'url': 'http://www.test.com/test.txt',
        'tmpdir': '/tmp',
        'validate_certs': True
    })
    assert fetch_file(module, 'http://www.test.com/test.txt') is not None

#
# Helper functions
#

# Generated at 2022-06-11 06:38:04.022166
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    class Environment:
        def __init__(self, case):
            self.host = 'host'
            self.port = '443'
            self.no_proxy = case
            self.https_proxy = None


# Generated at 2022-06-11 06:38:10.570348
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    try:
        import ssl
        class MockSSL():
            wrap_socket = ssl.wrap_socket
        ssl = MockSSL()
        import urllib3.connection
        urllib3.connection.ssl = ssl
        CustomHTTPSConnection.SSL_PROTOCOL = "tlsv1"
        CustomHTTPSConnection.DEFAULT_CIPHERS = "HIGH:!aNULL:!MD5"
    except:
        pass
    import socket
    class MockSocket():
        def create_connection(*args, **kwargs):
            return args
        def __getattr__(self, item):
            return MockSocket()
    socket = MockSocket()
    import urllib3.connection
    urllib3.connection.socket = socket

# Generated at 2022-06-11 06:38:21.050690
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return

    # use the code from urllib3, which is packaged with cryptography
    from urllib3.contrib import pyopenssl
    certificates = dict(CERT_NONE=None, CERT_REQUIRED=pyopenssl.DEFAULT_CA_BUNDLE_PATH)
    time_out = 60
    with pyopenssl.SSLConnection('www.google.com', 443, cert_reqs='CERT_NONE', timeout=time_out,
                                        ca_certs=certificates[None]) as http:
        http.set_tlsext_host_name('www.google.com')
        http.set_connect_state()
        http.connect()
        cert = http.get_peer_certificate()

    pyopenssl_channel_

# Generated at 2022-06-11 06:38:26.189740
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    """Function tests ``RedirectHandlerFactory``
    """
    urllib_request._opener = None

    handler = RedirectHandlerFactory('all')
    assert isinstance(handler, urllib_request.HTTPRedirectHandler)
    assert handler.redirect_request

    handler = RedirectHandlerFactory()
    assert isinstance(handler, urllib_request.HTTPRedirectHandler)
    assert handler.redirect_request

    handler = RedirectHandlerFactory(None)
    assert isinstance(handler, urllib_request.HTTPRedirectHandler)
    assert handler.redirect_request

    handler = RedirectHandlerFactory(True)
    assert isinstance(handler, urllib_request.HTTPRedirectHandler)
    assert handler.redirect_request
