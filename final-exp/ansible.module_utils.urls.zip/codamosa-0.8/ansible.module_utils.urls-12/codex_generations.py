

# Generated at 2022-06-11 06:32:31.476031
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    from ansible.module_utils.urls import SSLValidationHandler

# Generated at 2022-06-11 06:32:33.319591
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    assert 0


# Generated at 2022-06-11 06:32:40.914555
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    """
    Perform unit tests on SSLValidationHandler._method()
    """
    # (1)
    # Create an instance of class SSLValidationHandler
    hostname = 'self.hostname'
    port = 'self.port'
    obj = SSLValidationHandler(hostname, port)
    # Test line: if use_proxy and https_proxy:
    url = 'https://github.com/ansible/ansible/issues/26251'
    with patch.dict(os.environ, {'https_proxy': 'proxy_parts.get('}):
        # Test line: if use_proxy and https_proxy:
        req = url  # dummy
        with pytest.raises(ProxyError):
            obj.http_request(req)
    # Test line: if use_proxy and https_proxy:
    req = url

# Generated at 2022-06-11 06:32:45.739365
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    ssl_validation_handler = SSLValidationHandler('192.168.1.1', 12345)
    req = Request('https://192.168.1.1:12345')
    req = ssl_validation_handler.http_request(req)
    assert req



# Generated at 2022-06-11 06:32:48.743288
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    e = SSLValidationError('A very bad error')
    if six.PY2:
        assert six.text_type(e) == u'A very bad error'
    else:
        assert str(e) == 'A very bad error'


# SSLValidationHandler probably does not work in Python 3
# because the monkey patch is wrong and
# urllib_request.build_opener raises an exception.
# Don't run command line tests in Python 3.

# Generated at 2022-06-11 06:32:53.944032
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    '''
    Unit tests for the make_context method of the SSLValidationHandler class
    '''
    handler = SSLValidationHandler(None, None, None)
    context = handler.make_context(None, None)
    assert isinstance(context, ssl.SSLContext)



# Generated at 2022-06-11 06:33:04.722002
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    conn = CustomHTTPSConnection('localhost', port=443,
                                 key_file='/path/key.pem', cert_file='/path/cert.pem')
    assert conn.key_file == '/path/key.pem'
    assert conn.cert_file == '/path/cert.pem'

    conn = CustomHTTPSConnection('localhost', port=443, key_file='/path/key.pem')
    assert conn.key_file == '/path/key.pem'
    assert conn.cert_file is None

    conn = CustomHTTPSConnection('localhost', port=443, cert_file='/path/cert.pem')
    assert conn.key_file is None
    assert conn.cert_file == '/path/cert.pem'

    conn = CustomHTTPSConnection('localhost', port=443)


# Generated at 2022-06-11 06:33:17.078064
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest

    class RedirectHandlerTester(unittest.TestCase):
        def test_no_redirects(self):
            req = urllib_request.Request('http://www.ansible.com/')
            hdlr = RedirectHandlerFactory('no')()

            try:
                hdlr.redirect_request(req, None, 301, 'Moved Permanently', {}, 'http://www.ansible.com/')
            except urllib_error.HTTPError:
                pass
            else:
                self.fail('Should have raised HTTPError')

            try:
                hdlr.redirect_request(req, None, 302, 'Found', {}, 'http://www.ansible.com/')
            except urllib_error.HTTPError:
                pass

# Generated at 2022-06-11 06:33:27.409368
# Unit test for function prepare_multipart
def test_prepare_multipart():
    import io
    import base64
    import hashlib

    fields = {
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'some text for the second text file',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        },
        'text_form_field': 'value'
    }

    content_type, body = prepare_multipart(fields)
    assert 'multipart/form-data' in content_type

# Generated at 2022-06-11 06:33:36.980810
# Unit test for function fetch_url

# Generated at 2022-06-11 06:35:36.575300
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from ansible.module_utils.ssl_validation import SSLValidationHandler

    handler = SSLValidationHandler('www.googleapis.com', 443)
    req = urllib_request.Request('https://www.googleapis.com/discovery/v1/apis/compute/v1/rest?fields=kind')
    handler.http_request(req)


# Generated at 2022-06-11 06:35:40.330546
# Unit test for function fetch_file
def test_fetch_file():
    fetch_temp_file = fetch_file(None, "https://download.docker.com/linux/centos/docker-ce.repo")
    assert os.path.isfile(fetch_temp_file)
    os.remove(fetch_temp_file)


# Generated at 2022-06-11 06:35:48.652705
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    env_ip = os.environ.get('TEST_HTTPS_SERVER_IP', '10.240.0.1')
    env_port = int(os.environ.get('TEST_HTTPS_SERVER_PORT', 443))

    # Simple check for connect to our test server
    connection = CustomHTTPSConnection(env_ip, env_port)
    connection.connect()

    if HAS_SSLCONTEXT:
        # Test a simple non-verify context
        context = ssl.SSLContext(PROTOCOL)
        context.verify_mode = ssl.CERT_NONE
        connection = CustomHTTPSConnection(env_ip, env_port, context=context)
        connection.connect()

        # Test a simple non-verify context with hostname checking

# Generated at 2022-06-11 06:35:53.567745
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn = CustomHTTPSConnection(host=None, key_file=None, cert_file=None)
    assert conn.context is None
    assert conn.cert_file is None

    conn = CustomHTTPSConnection(host=None, key_file=None, cert_file='cert.pem')
    assert conn.context is not None
    assert conn.cert_file == 'cert.pem'




# Generated at 2022-06-11 06:35:57.050604
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    class A:
        def __init__(self):
            self.a = 0
    h = maybe_add_ssl_handler('http://foo.bar', True)
    a = A()
    h.http_request(a)
    assert a.a == 0
    h = maybe_add_ssl_handler('https://foo.bar', True)
    a = A()
    h.http_request(a)
    assert a.a == 0
    # TODO: add SSL tests
    # h.https_request(a)
    # assert a.a == 0



# Generated at 2022-06-11 06:36:07.273400
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # pylint: disable=too-many-locals,too-many-branches,unused-variable
    # pylint: disable=undefined-variable
    global event_count, has_sslcontext
    event_count = 0
    has_sslcontext = True

    class MockRequest(object):
        '''
        Mock object that is meant to be a urllib_request.Request object
        '''

        def __init__(self, url, data=None, headers=None, origin_req_host=None, unverifiable=True):
            self.url = url
            self.data = data
            self.headers = headers
            self.origin_req_host = origin_req_host
            self.unverifiable = unverifiable

        def get_method(self):
            return 'GET'


# Generated at 2022-06-11 06:36:16.808860
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-11 06:36:20.016302
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('http://www.example.com', 'GET')
    assert req.get_method() == 'GET'
    req = RequestWithMethod('http://www.example.com', 'PUT')
    assert req.get_method() == 'PUT'

# Used by the ProxyHelper to wrap a urllib2 request object with
# the CONNECT method needed to set up a tunnel through HTTP proxies.
# This enables urllib2 to talk to HTTPS servers through proxies
# that support the CONNECT method.

# Generated at 2022-06-11 06:36:29.294458
# Unit test for constructor of class CustomHTTPSConnection

# Generated at 2022-06-11 06:36:39.267023
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Test for existing no_proxy
    url = 'https://example.com'
    instance = SSLValidationHandler('example.com', 443)
    if 'no_proxy' in os.environ:
        del os.environ['no_proxy']

    expect_result = True
    try:
        result = instance.detect_no_proxy(url)
    except Exception as e:
        result = False

    print('1. Test for the case that no_proxy is not set. ')
    print('  The expected result is %s. The actual result is %s.' % (expect_result, result))
    if result == expect_result:
        print('  The test passed.')
    else:
        print('  The test failed.')

    expect_result = True