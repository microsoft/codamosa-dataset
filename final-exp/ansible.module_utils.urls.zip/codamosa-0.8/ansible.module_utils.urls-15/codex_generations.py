

# Generated at 2022-06-11 06:32:52.799809
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    ssl_handler = SSLValidationHandler(hostname="www.google.com", port=443, ca_path='/etc/ssl/certs')
    ca_path, cadata, paths_checked = ssl_handler.get_ca_certs()
    assert ca_path == '/etc/ssl/certs'
    assert cadata == bytearray()
    assert paths_checked == ['/etc/ssl/certs']

    ssl_handler = SSLValidationHandler(hostname="www.google.com", port=443, ca_path=None)
    ca_path, cadata, paths_checked = ssl_handler.get_ca_certs()
    assert ca_path == None
    assert cadata != bytearray()
    assert paths_checked != ['/etc/ssl/certs']


# Unit test

# Generated at 2022-06-11 06:32:56.772345
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    unix_conn = UnixHTTPConnection('/some/path')
    # unix_conn is an instance of HTTPConnection
    assert isinstance(unix_conn, httplib.HTTPConnection)



# Generated at 2022-06-11 06:33:06.797492
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Test the method connect of class UnixHTTPSConnection'''
    class TestConnection(UnixHTTPSConnection): # pylint: disable=too-few-public-methods
        def __init__(self, *args, **kwargs):
            self.call_super_connect_args = args
            self.call_super_connect_kwargs = kwargs
            self.called_super_connect = False

        def connect(self):
            self.called_super_connect = True
            # Disable pylint check for the super() call. It complains about TestConnection
            # being a NoneType because of the initial definition above, but it won't actually
            # be a NoneType when this code runs
            # pylint: disable=bad-super-call

# Generated at 2022-06-11 06:33:18.630248
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Verify that we can call RedirectHandlerFactory to get a RedirectHandler class instance
    redirect_handler = RedirectHandlerFactory(follow_redirects=None, validate_certs=True, ca_path=None)
    assert redirect_handler is not None

    # Verify that calling the RedirectHandlerFactory with a follow_redirects value of no returns a RedirectHandler
    # that is flagged to not follow redirects
    redirect_handler = RedirectHandlerFactory(follow_redirects='no', validate_certs=True, ca_path=None)
    assert redirect_handler.redirect_request(None, None, 301, 'Moved Permanently', None, None) is None
    assert redirect_handler is not None

    # Verify that calling the RedirectHandlerFactory with a follow_redirects value of all returns a RedirectHandler
    # that

# Generated at 2022-06-11 06:33:30.016697
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        pass

    assert httplib.HTTPConnection.connect == _connect


    class UnixHTTPSConnection(_x_urllib_request_UnixHTTPConnection, httplib.HTTPSConnection):

        def __init__(self, cert_file=None, key_file=None, unix_socket=None, **kwargs):
            _x_urllib_request_UnixHTTPConnection.__init__(self, unix_socket)
            httplib.HTTPSConnection.__init__(self, 'localhost', **kwargs)
            self.cert_file = cert_file
            self.key_file = key_file


# Generated at 2022-06-11 06:33:32.249518
# Unit test for function fetch_file
def test_fetch_file():
    import tempfile
    fetch_temp_file = tempfile.NamedTemporaryFile(dir='/tmp/', prefix='test_fetch', suffix='.txt', delete=False)
    try:
        fetch_temp_file.write('test')
    except Exception:
        pass
    finally:
        fetch_temp_file.close()
        os.remove(fetch_temp_file.name)



# Generated at 2022-06-11 06:33:42.938266
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    # test pass
    try:
        handler = urllib_request.HTTPSHandler(debuglevel=0)
        context = handler.make_context(cafile='/etc/ssl/certs/cacert.pem', cadata=b'')
    except NotImplementedError:
        pass

    if HAS_SSLCONTEXT:
        try:
            handler = urllib_request.HTTPSHandler(debuglevel=0)
            context = handler.make_context(cafile='/etc/ssl/certs/cacert.pem', cadata=b'')
        except NotImplementedError:
            pass

    # test fail

# Generated at 2022-06-11 06:33:47.556524
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        klass = CustomHTTPSHandler
    except NameError:
        return
    klass()

# While we want to use the urllib3 custom HTTPS connection for its ability
# to use the SSLContext, we still want the cert validation provided by
# urllib3's HTTPSConnectionPool.
#
# Because of this we cannot use the 'pool_connections' or
# 'pool_maxsize' options, as those are only used by the PoolManager
# which also uses the HTTPSConnectionPool, which we also use.
#
# This means we will be making a new request every time, and not
# reusing connections. However this should be okay since the number
# of connections will be limited by the number of forks and the fact
# that this module is only used for the urls in the inventory

# Generated at 2022-06-11 06:33:55.559163
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Unit test for function prepare_multipart
    msg = MIMEText('only text')
    msg.add_header('Content-Disposition', 'form-data')
    msg.set_param('name', 'text')

    msg_file = MIMEApplication(open('test/fixtures/test_multipart_file.txt').read())
    msg_file.add_header('Content-Disposition', 'form-data', filename='test/fixtures/test_multipart_file.txt')

    msg_file2 = MIMEApplication(open('test/fixtures/test_multipart_file.txt').read())
    msg_file2.add_header('Content-Disposition', 'form-data', filename='test/fixtures/test_multipart_file.txt')

# Generated at 2022-06-11 06:34:00.486896
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # no_proxy_paths = ['/etc/ssl/certs',
    #    '/etc/pki/ca-trust/extracted/pem', '/etc/pki/tls/certs',
    #    '/usr/share/ca-certificates/cacert.org', '/etc/ansible']
    no_proxy_paths = ['/etc/ssl/certs',
        '/etc/pki/ca-trust/extracted/pem', '/etc/pki/tls/certs',
        '/usr/share/ca-certificates/cacert.org']
    # no_proxy_paths = ['/etc/ssl/certs']
    # no_proxy_paths = ['/usr/share/ca-certificates/cacert.org']
    # no_proxy_path

# Generated at 2022-06-11 06:36:02.902555
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    exc = urllib_error.URLError('HTTP Error 500: Internal Server Error')

# Generated at 2022-06-11 06:36:13.132555
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # pylint: disable=too-few-public-methods,no-self-use,unused-argument
    class CustomHTTPSConnectionImpl(CustomHTTPSConnection):
        def __init__(self, *args, **kwargs):
            self.context = None
            self.cert_file = None
            self.key_file = None
            self.timeout = 0

    try:
        import ssl
    except ImportError:
        pass
    else:
        class PyOpenSSLContext(object):
            def __init__(self, *args, **kwargs):
                pass

            def load_cert_chain(self, certfile, keyfile):
                pass

            def wrap_socket(self, sock, server_hostname):
                return ssl.wrap_socket(sock, server_hostname=server_hostname)

# Generated at 2022-06-11 06:36:22.288264
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    import ssl
    assert ssl.PROTOCOL_SSLv23 == PROTOCOL, 'PROTOCOL should be ssl.PROTOCOL_SSLv23'
    class Mock(object):
        def __init__(self, hostname, port, ca_path=None):
            self.mock_http_request_count = 0
            self.mock_http_request_count = 0
            self.mock_cafile = None
            self.mock_cadata = None
            self.mock_context = None
            self.mock_context_content = None
            self.mock_context_content_args = None
            self.mock_context_args = None
            self.mock_context_load_verify_locations_args = None
            self.mock_context_wrap_

# Generated at 2022-06-11 06:36:31.523092
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        mutually_exclusive=[],
        required_together=[],
    )


# Generated at 2022-06-11 06:36:41.366586
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    import pprint
    h = CustomHTTPSHandler()
    conn = h.https_open('https://localhost')
    handler_obj = pprint.pformat(h.__dict__)
    h.close()
    conn_obj = pprint.pformat(conn.__dict__)
    pattern = "^    .*'_context': <.*?SSLContext.*?object at.*?>,?$"
    match = re.search(pattern, handler_obj, re.MULTILINE)
    if match:
        pytest.fail("Unexpected https handler object {0}".
                    format(handler_obj))
    else:
        match = re.search(pattern, conn_obj, re.MULTILINE)

# Generated at 2022-06-11 06:36:50.267099
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import urllib.request
    import urllib.error
    import urllib.parse

    follow_redirects = 'all'
    validate_certs = False
    ca_path = None
    RedirectHandler = RedirectHandlerFactory(follow_redirects, validate_certs, ca_path)


# Generated at 2022-06-11 06:36:57.230629
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Bugfix: https://github.com/ansible/ansible/issues/22113
    with patch('ansible.module_utils.urls.SSLValidationHandler.detect_no_proxy') as mock_detect_no_proxy:
        mock_detect_no_proxy.return_value = True
        vh = SSLValidationHandler('test_host', 443)
        assert vh.http_request(None) == None
        # Bugfix: https://github.com/ansible/ansible/issues/22113
        mock_detect_no_proxy.assert_called_once_with(None)


# Generated at 2022-06-11 06:37:05.576263
# Unit test for function prepare_multipart
def test_prepare_multipart():
    try:
        file_content = open('/tmp/file.txt').read()
    except IOError:
        file_content = "Fake file"
    fields = {"file": {"filename": "/tmp/file.txt", "mime_type": "text/plain"},
              "string": "ubiquitous"}
    content_type, body = prepare_multipart(fields)

    # Make sure content type is multipart
    assert content_type.find("multipart") != -1
    # Make sure that the fake file content is in the body
    assert file_content in body.decode()
    # Make sure that the string is in the body
    assert "ubiquitous" in body.decode()

# Generated at 2022-06-11 06:37:16.904004
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    fake_cert_path = "/etc/ansible/test_cert"
    fake_ca_cert_path = "/etc/ansible/test_cert.pem"

# Generated at 2022-06-11 06:37:21.122481
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    try:
        SSLValidationHandler(hostname='foo', port=443).get_ca_certs()
    except Exception as e:
        assert False, 'unexpected exception: %s' % to_native(e)

