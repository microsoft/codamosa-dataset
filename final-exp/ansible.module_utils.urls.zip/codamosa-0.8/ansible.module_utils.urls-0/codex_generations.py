

# Generated at 2022-06-11 06:32:16.875075
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule(argument_spec=dict(url=dict(type='str')))
    result = fetch_file(module, 'http://github.com/ansible/ansible/archive/devel.tar.gz')
    assert result is not None

# Generated at 2022-06-11 06:32:22.952601
# Unit test for function getpeercert
def test_getpeercert():
    """Test getpeercert function."""
    # pylint: disable=redefined-outer-name, unused-variable
    global HTTPConnection, HTTPSConnection, HTTPHandler, HTTPSHandler
    with contextlib.ExitStack() as stack:

        class FakeSocket():
            """ Fake socket object."""
            def getpeercert(self, binary_form=False):
                return None

        class FakeHTTPConnection():
            """ Fake connection object."""
            def __init__(self, host, port, **kwargs):
                if host == 'badhost':
                    raise OSError
                if host == 'badport':
                    host = 'localhost'
                if host == 'nomatch':
                    host = 'foobar'

        class FakeHTTPSConnection():
            """ Fake connection object."""

# Generated at 2022-06-11 06:32:24.919836
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn = CustomHTTPSConnection('127.0.0.1')
    try:
        conn.connect()
    except Exception as e:
        if not isinstance(e, ssl.SSLError):
            pass
        else:
            assert False


# Generated at 2022-06-11 06:32:29.597833
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    try:
        CustomHTTPSConnection('localhost', 80)
    except socket.gaierror:
        # No network so we can't connect to localhost
        pass
    except socket.error:
        # This test should be run don Linux and macOS
        # but it's possible the test environment does not
        # have a network connection or the host does not
        # have a webserver running.
        pass
    else:
        raise AssertionError('test_CustomHTTPSConnection_connect failed')


    # A local http server
    class CustomHTTPSHandler(HTTPServer.HTTPServer):
        def __init__(self):
            HTTPServer.HTTPServer.__init__(self, ("127.0.0.1", 0), SimpleHTTPRequestHandler)

    server = CustomHTTPSHandler()

# Generated at 2022-06-11 06:32:30.641242
# Unit test for method open of class Request
def test_Request_open():
    assert True

# Generated at 2022-06-11 06:32:36.903789
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = generic_urlparse(urllib_parse.urlsplit('https://foo:bar@localhost:8080/v1/path/to/resource?query#fragment'))
    assert parts['scheme'] == 'https', 'Scheme is not parsed correctly'
    assert parts['netloc'] == 'foo:bar@localhost:8080', 'Netloc is not parsed correctly'
    assert parts['path'] == '/v1/path/to/resource', 'Path is not parsed correctly'
    assert parts['params'] == '', 'Params are not parsed correctly'
    assert parts['query'] == 'query', 'Query is not parsed correctly'
    assert parts['fragment'] == 'fragment', 'Fragment is not parsed correctly'
    assert parts['username'] == 'foo', 'Username is not parsed correctly'

# Generated at 2022-06-11 06:32:49.863277
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    from ansible.module_utils.six.moves import urllib
    myurl = 'https://github.com/ansible/ansible/pull/12345'
    if hasattr(urllib.request, 'HTTPSHandler'):
        myhandler = CustomHTTPSHandler()
        try:
            myurlopen = urllib.request.build_opener(myhandler)
            myurlopen.open(myurl)
        except urllib.error.URLError:
            # Expected because there is no network connection available
            # in the context of this unit test.
            # See issue https://github.com/ansible/ansible/issues/19676
            # for more details.
            pass

#
# Monkey Patch for urllib3 to Add PyOpenSSL support
#

# Generated at 2022-06-11 06:32:54.162960
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from time import localtime
    from time import mktime
    from datetime import datetime

    lt = localtime(time.time())
    lt = [
        lt[0],  # year
        lt[1],  # month
        lt[2],  # day
        lt[3],  # hour
        lt[4],  # min
        lt[5],  # sec
        lt[6],  # weekday
    ]

    dts = rfc2822_date_string(lt)
    dt = datetime.strptime(dts, '%a, %d %b %Y %H:%M:%S -0000')
    assert mktime(lt) == mktime(dt.timetuple())



# Generated at 2022-06-11 06:33:04.844234
# Unit test for function prepare_multipart
def test_prepare_multipart():
    headers, content = prepare_multipart({
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    })

    m = re.match("^multipart/form-data; boundary=(.*)", headers)
    assert m

    boundary = m.group(1)

    body_re = re.compile("--%s(.*?)--%s--" % (boundary, boundary), re.MULTILINE | re.DOTALL)
    m = body_re.search(content)
   

# Generated at 2022-06-11 06:33:17.119126
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest2 as unittest
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import build_opener, HTTPRedirectHandler
    import ansible.module_utils.six.moves.urllib.request as urllib_request

    class FakeRequest(urllib_request.Request):
        def __init__(self, url, method=None, data=None, headers=None):
            self.url = url
            self.method = method
            self.data = data
            self.headers = headers or dict()
            self.code = 0

        def get_method(self):
            return self.method

        def get_data(self):
            return self.data


# Generated at 2022-06-11 06:34:22.329546
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    url = 'http://some.url.com'
    methods = ('POST', 'GET', 'PUT', 'DELETE')
    for method in methods:
        request = RequestWithMethod(url, method)
        assert request.get_method() == method.upper()

_python2_ssl_verify_error_errnos = None

# Generated at 2022-06-11 06:34:23.613217
# Unit test for function fetch_file
def test_fetch_file():
    from units.mock.module_utils import basic_defs
    assert hasattr(basic_defs, 'fetch_file')



# Generated at 2022-06-11 06:34:28.626723
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from time import gmtime, strptime
    orig = "Fri, 09 Nov 2001 01:08:47 -0000"
    later = rfc2822_date_string(gmtime(1005764127))
    assert orig == later
    assert time.mktime(strptime(orig,"%a, %d %b %Y %H:%M:%S %z")) == 1005741527.0

# Generated at 2022-06-11 06:34:33.439142
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class TestCustomHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, *args, **kwargs):
            super(TestCustomHTTPSConnection, self).__init__(*args, **kwargs)
            self.sslv23 = 0
            self.context = None

        connect = test_compare_functions(CustomHTTPSConnection.connect)

    h1 = TestCustomHTTPSConnection("hostname")
    h2 = TestCustomHTTPSConnection("hostname")
    h1.source_address = None
    h2.source_address = ("127.0.0.1", 1234)
    h2.timeout = 5.0
    h1.ssl_verify_mode = "optional"
    h2.ssl_verify_mode = "optional"
    h1.host = "hostname"
    h

# Generated at 2022-06-11 06:34:43.402684
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    from unittest import TestCase

    class Mock(object):
        pass

    class DummyTest(TestCase):
        def setUp(self):
            self.Mock = Mock()
            self.Mock.connect = None
            self.Mock.connect_called = False

        def test_patch(self):
            def test_connect(self):
                self.connect_called = True
            with unix_socket_patch_httpconnection_connect():
                self.Mock.connect = test_connect
                httplib.HTTPConnection.connect(self.Mock)
            self.assertTrue(self.Mock.connect_called)
    DummyTest('test_patch').test_patch()


# Generated at 2022-06-11 06:34:53.536044
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-11 06:35:00.926236
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler('hostname', 443, 'ca_path')
    url = 'https://hostname.com/path/path'

    # Testing without no_proxy env variable
    assert handler.detect_no_proxy(url) is True

    # Testing with empty no_proxy env variable
    os.environ['no_proxy'] = ''
    assert handler.detect_no_proxy(url) is True

    # Testing with no_proxy env variable set to hostname.com
    os.environ['no_proxy'] = 'hostname.com'
    assert handler.detect_no_proxy(url) is False

    # Testing with no_proxy env variable set to hostname.com,hostname.com
    os.environ['no_proxy'] = 'hostname.com,hostname.com'

# Generated at 2022-06-11 06:35:12.333802
# Unit test for function fetch_file
def test_fetch_file():
    # Create a Mock module
    mock_module = AnsibleModule(
        argument_spec=dict(
            url=dict(type='str'),
            data=dict(type='str'),
            headers=dict(type='dict'),
            method=dict(type='str'),
            use_proxy=dict(type='bool'),
            force=dict(type='bool'),
            last_mod_time=dict(type='int'),
            timeout=dict(type='int'),
            unredirected_headers=dict(type='list')
        )
    )
    # Get values for all variables the function accepts
    url = mock_module.params['url']
    data = mock_module.params['data']
    headers = mock_module.params['headers']
    method = mock_module.params['method']
    use_proxy = mock_module

# Generated at 2022-06-11 06:35:22.412346
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return

    # Known good certificate output.
    cert = cert = x509.load_der_x509_certificate(b_DUMMY_CA_CERT, default_backend())
    known_good_hash = 'jKDtRnFtHSsCYMk2jTtt8F+frq3Gq/NfDQPX9DX/sc8='  # base64 encoded hash

    # get_channel_binding_cert_hash expects DER encoded form
    cert_der = cert.public_bytes(encoding=serialization.Encoding.DER)

    # Get the SHA256 hash of the DER encoded public certificate
    # and base64 encode
    hash_algorithm = hashes.SHA256()

# Generated at 2022-06-11 06:35:28.185972
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    import time

    # Use fixed time to be testable
    fixed_time = (2003, 8, 4, 19, 27, 48, 0, 0, 1)
    time_tuple = time.struct_time(fixed_time)
    # We can't check the timezone so we set it to -0000
    assert rfc2822_date_string(time_tuple, zone='+0000') == 'Mon, 04 Aug 2003 19:27:48 +0000'

    # Make sure the default zone is -0000
    assert rfc2822_date_string(time_tuple) == 'Mon, 04 Aug 2003 19:27:48 -0000'



# Generated at 2022-06-11 06:37:16.055528
# Unit test for function fetch_url
def test_fetch_url():
    src_url = "http://example.com/foo"
    dest_url = "http://www.iana.org/domains/example/"
    redirect_url = "http://example.com/bar/redirect"
    client_cert = "fake-cert.pem"
    client_key = "fake-key.pem"
    unix_socket = "/tmp/fake-sock.sock"
    ca_path = "/tmp/fake-ca.pem"

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    # Test case where fetch_url fails and returns exception
    with pytest.raises(Exception, match='Invalid headers'):
        fetch_

# Generated at 2022-06-11 06:37:26.521037
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from time import gmtime
    # Although the time is in the past, it should always be formatted as UTC
    now = gmtime()
    assert rfc2822_date_string(now) == '%s, %02d %s %04d %02d:%02d:%02d -0000' % (
        ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][now[6]],
        now[2],
        ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][now[1] - 1],
        now[0], now[3], now[4], now[5])



# Generated at 2022-06-11 06:37:38.115826
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    globals()['HAS_SSL'] = True
    globals()['HAS_URLLIB3_PYOPENSSLCONTEXT'] = True
    globals()['HAS_URLLIB3_SSL_WRAP_SOCKET'] = True
    globals()['HAS_SSLCONTEXT'] = True
    globals()['PROTOCOL'] = 0 # Does not matter

    class FakeUrl:
        def __init__(self, netloc, port=None, scheme='http'):
            self.netloc = netloc
            self.port = port
            self.scheme = scheme

    url = FakeUrl('www.google.com', port=443, scheme='https')
    ssl_handler = maybe_add_ssl_handler(url, True)

# Generated at 2022-06-11 06:37:42.501609
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # type: () -> None
    assert hasattr(CustomHTTPSHandler, 'https_open')
    assert hasattr(CustomHTTPSHandler, 'https_request')

if hasattr(httplib, 'HTTPS'):

    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
        '''
        Extended version of HTTPSHandler. It allows providing a key_file and cert_file
        to be used when handling HTTPS requests.
        '''
        def __init__(self, key_file=None, cert_file=None, level=0):
            # type: (Optional[Union[str, TextIO]], Optional[Union[str, TextIO]], int) -> None
            urllib_request.HTTPSHandler.__init__(self, debuglevel=level)
            self.key_file = key_file


# Generated at 2022-06-11 06:37:53.900906
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    def test_valid_proxy_response(response, valid_codes):
        SSLValidationHandler.validate_proxy_response(response, valid_codes)
        # PASS: if it does not raise ProxyError

    # Test invalid response
    invalid_responses = [
        b'HTTP/1.1 abc xyz',
        b'HTTP/1.1 200 abc\r\n\r\n',
        b'HTTP/1.1 200 xyz\r\n',
    ]
    for response in invalid_responses:
        with pytest.raises(ProxyError):
            test_valid_proxy_response(response, [200, 400])
    # PASS: if it raises ProxyError

    # Test valid response

# Generated at 2022-06-11 06:37:57.498177
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    """ Test for function rfc2822_date_string """
    import calendar
    import time
    time_struct = time.gmtime()
    assert rfc2822_date_string(time_struct, '-0000') == calendar.formatdate(-time.timezone)



# Generated at 2022-06-11 06:38:02.155475
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod("foo", "post", "post_data", {'headers': 'foobar'}, "org_req_host", "unverifiable")
    method = request.get_method()
    assert method == 'POST'
    assert request.has_data() == True
    assert request.unverifiable == "unverifiable"


# Generated at 2022-06-11 06:38:07.550782
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Test to check if http proxy is invoked if https_proxy is not set
    # Use the following environment variables to test the scenario
    # https_proxy=https://192.168.2.135:3128
    # https_proxy=https://192.168.2.135:3128
    # no_proxy=localhost,127.0.0.1
    # no_proxy=localhost,127.0.0.1
    pass



# Generated at 2022-06-11 06:38:13.787026
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class MockSSLContext(object):
        called = []
        def load_cert_chain(self, cert_file, key_file):
            self.called.append(('load_cert_chain', cert_file, key_file))
        def wrap_socket(self, sock, server_hostname=None, **kwargs):
            self.called.append(('wrap_socket', sock, server_hostname))
            return sock

    class MockSSLSocket(object):
        def __init__(self, sock):
            self.called = []
            self.sock = sock
        def wrap_socket(self, *args, **kwargs):
            self.called.append(('wrap_socket', ) + args)
            return self.sock

    class MockSocket(object):
        def __init__(self):
            self.called

# Generated at 2022-06-11 06:38:18.203074
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():  # pylint: disable=R0915
    import unittest
    import ssl

    class TestHTTPSConnection(object):
        def __init__(self, host=None, port=None, key_file=None, cert_file=None,
                     timeout=None, source_address=None,
                     context=None):
            self.host = host
            self.port = port
            self.key_file = key_file
            self.cert_file = cert_file
            self.timeout = timeout
            self.source_address = source_address
            self.context = context
            self.sock = None

        def __call__(self):
            pass
