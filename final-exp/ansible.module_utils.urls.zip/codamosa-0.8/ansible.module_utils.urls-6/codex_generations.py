

# Generated at 2022-06-11 06:32:16.144204
# Unit test for function getpeercert

# Generated at 2022-06-11 06:32:21.157833
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    from .certifi import where
    cafile = where()
    s = SSLValidationHandler(None, None, cafile)
    context = s.make_context(cafile, None)
    assert context.verify_mode == ssl.CERT_REQUIRED


# Generated at 2022-06-11 06:32:31.387456
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    import urllib.request
    import urllib.parse

    url = 'https://www.google.com/'
    ca_path = '/etc/ssl/certs/ca-certificates.crt'
    handler = maybe_add_ssl_handler(url, True, ca_path)
    assert isinstance(handler, SSLValidationHandler)
    assert handler.ca_path == ca_path
    ca_path = '/nonexistent/path/ca-certificates.crt'
    handler = maybe_add_ssl_handler(url, True, ca_path)
    assert isinstance(handler, SSLValidationHandler)
    assert handler.ca_path is None

    url = 'https://www.example.com/'
    ca_path = '/etc/ssl/certs/ca-certificates.crt'

# Generated at 2022-06-11 06:32:34.612820
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime(), zone='+0000') == 'Mon, 13 Jul 2015 19:06:53 +0000'



# Generated at 2022-06-11 06:32:38.966237
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    https_url = 'https://192.168.3.3'
    validate_certs = True
    ca_path = None
    res_ssl_handler = maybe_add_ssl_handler(https_url, validate_certs, ca_path)
    print(res_ssl_handler.ca_path)

if __name__ == '__main__':
    test_maybe_add_ssl_handler()

# Generated at 2022-06-11 06:32:42.255581
# Unit test for method options of class Request
def test_Request_options():
    r"""
    Test options method

    :param self: class object
    :returns: None

    """
    r = request.Request()
    r.options()


# Generated at 2022-06-11 06:32:55.086622
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    from ansible.module_utils.six.moves.http_client import HTTPConnection
    from ansible.module_utils.six.moves.urllib.request import BaseHandler
    from ansible.module_utils.connection import _unix_socket_connection
    from ansible.module_utils import basic
    import unittest

    class MockHTTPHandler(BaseHandler):
        def do_open(self, http_class, req):
            http_class(req.host, unix_socket=req.unix_socket)

    class MockUnixHTTPConnection(HTTPConnection):
        def __init__(self, *args, **kwargs):
            self.unix_socket = kwargs['unix_socket']
            del kwargs['unix_socket']

# Generated at 2022-06-11 06:32:56.951447
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    SSLValidationHandler.validate_proxy_response("HTTP/1.0 200 ok \r\n")



# Generated at 2022-06-11 06:33:06.900487
# Unit test for function getpeercert
def test_getpeercert():
    """
    Test to ensure if a peer certificate can be obtained from urlopen.
    """
    if not HAS_SSL:
        raise SkipTest("SSL support for python is not available")
    try:
        import ssl
        ssl_context = ssl.create_default_context()
    except AttributeError:
        raise SkipTest("Python version does not support ssl.create_default_context")
    # create a webserver on localhost that presents a certificate
    import BaseHTTPServer
    import SimpleHTTPServer
    import SocketServer
    import ssl
    import os

# Generated at 2022-06-11 06:33:12.720868
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    port = 20343
    hostname = u'hostname'
    ca_path = u'/home/user/ca.pem'
    paths_checked = [u'/home/user/ca.pem', u'/etc/ssl/certs', u'/etc/ansible']

# Generated at 2022-06-11 06:36:00.770498
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    hostname_verification_was_enabled = C.HOSTNAME_VERIFICATION
    C.HOSTNAME_VERIFICATION = False
    try:
        os.unlink(C.DEFAULT_CACHE_PATH)
    except OSError:
        pass
    http_connection = CustomHTTPSConnection(C.DEFAULT_API_URL)
    http_connection.connect()
    assert http_connection.sock is not None
    assert http_connection.sock.cipher()[0] == "RC4-SHA"
    C.HOSTNAME_VERIFICATION = hostname_verification_was_enabled
    os.unlink(C.DEFAULT_CACHE_PATH)

    class _MockSSLError(Exception):
        pass


# Generated at 2022-06-11 06:36:05.799106
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    class DummyRequest(urllib_request.Request):
        def __init__(self, url, method, data=None, headers=None, origin_req_host=None, unverifiable=True):
            # Call parent's constructor
            urllib_request.Request.__init__(self, url, method, data,
                             headers, origin_req_host, unverifiable)
    # Test case 1: _method is not None
    req = RequestWithMethod("url", "method", "data", "headers", "origin_req_host", "unverifiable")
    assert 'method' == req.get_method()
    # Test case 2: _method is None. Since we are not mocking
    # get_method of urllib_request.Request, this will respond
    # as if we called parent's constructor.

# Generated at 2022-06-11 06:36:15.495279
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import random
    import string
    import unittest
    import uuid

    class TestRedirectHandlerFactory(unittest.TestCase):
        def test_redirect_handler_factory(self):
            urls = ['https://localhost', 'http://localhost']
            redirect_settings = ['yes', 'no', 'safe', 'all', 'none', 'urllib2',
                                 'random string', random.randint(1, 100), True, False]
            for url in urls:
                for redirect_setting in redirect_settings:
                    handler = RedirectHandlerFactory(follow_redirects=redirect_setting)
                    self.assertIsInstance(handler, RedirectHandlerFactory.RedirectHandler)
                    self.assertEqual(handler.follow_redirects, redirect_setting)
            self.assertTrue(True)


# Generated at 2022-06-11 06:36:24.439682
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils._text import to_bytes
    import ansible.utils.pycompat as pycompat
    from ansible.module_utils.urls import fetch_file, open_url
    import mock
    import tempfile

    class MockModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    class MockResponse(object):
        def __init__(self, obj, bufsize):
            self.obj = obj
            self.bufsize = bufsize
        def read(self, bufsize):
            data = self.obj.read(bufsize)
            if len(data) < bufsize:
                self.obj.seek(0)
            return data


# Generated at 2022-06-11 06:36:32.757354
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain'
        },
        'text_form_field': 'value'
    }
    content_type, body = prepare_multipart(fields)
    assert re.search(r'Content-Type: multipart/form-data.*boundary=', content_type)
    assert isinstance(content_type, string_types)
    assert isinstance(body, bytes)



# Generated at 2022-06-11 06:36:42.635711
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # mockup for httplib.HTTPSConnection
    class HTTPSConnection(object):
        def __init__(self):
            self.host = 'www.example.com'
            self.port = '443'
            self.timeout = None
            self.source_address = None
            self.sock = None

        def _tunnel(self):
            return 1

        def set_tunnel(self, host, port=None, headers=None):
            return 1

    # mockup for socket.create_connection
    def create_connection(address, timeout=None, source_address=None):
        return 1

    # mockup for ssl.wrap_socket
    def wrap_socket(sock, keyfile=None, cert_reqs=None, certfile=None, ssl_version=None):
        return 1

    #

# Generated at 2022-06-11 06:36:51.511659
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    import socket
    import ssl
    class TestHandler(SSLValidationHandler):
        def __init__(self):
            pass
        def http_request(self, req):
            cafile = 'CAFILE'
            cadata = 'CADATA'
            paths_checked = 'PATHS_CHECKED'
            self.get_ca_certs_return = (cafile, cadata, paths_checked)
            self.detect_no_proxy_bool = False
            self.socket_create_connection_return = socket.socket()
            self.ssl_wrap_socket_return = ssl.wrap_socket(self.socket_create_connection_return)
            self.socket_create_connection_return.close = lambda: None
            self.ssl_wrap_socket_return.unwrap = lambda: None
            return req



# Generated at 2022-06-11 06:37:00.494525
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    class OpenerDirector(object):
        add_handler_called = 0
        def add_handler(*args, **kwargs):
            OpenerDirector.add_handler_called += 1
    class HTTPRedirectHandler(object):
        redirect_request_called = 0
        def redirect_request(*args, **kwargs):
            HTTPRedirectHandler.redirect_request_called += 1
    class HTTPError(Exception):
        def __init__(self, *args, **kwargs):
            pass

    req = type('request', (object,), {
        'get_method': lambda self: 'GET',
        'headers': {'content-type': 'application/json', 'content-length': None, 'transfer-encoding': None},
    })()

    # Test no follow
    redirect_handler_factory = Redirect

# Generated at 2022-06-11 06:37:07.276723
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # setup
    ssl_validation_handler = SSLValidationHandler("hostname", "port")
    # test
    tmp_ca_cert_path, cadata, paths_checked = ssl_validation_handler.get_ca_certs()
    # assert
    assert type(tmp_ca_cert_path) == int # If CA is not found, temp file is created
    assert len(paths_checked) > 0 # Atleast one path is checked
    # teardown

# Generated at 2022-06-11 06:37:08.324114
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    _test_SSLValidationHandler_http_request()



# Generated at 2022-06-11 06:38:11.948860
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    paths = ["A", "B", "C"]
    try:
        build_ssl_validation_error("1.2.3.4", "443", paths)
    except Exception as e:
        if not isinstance(e, SSLValidationError):
            raise AssertionError("build_ssl_validation_error failed to raise SSLValidationError.")
    paths = ['/usr/lib/ssl/certs/ca-certificates.crt', '/etc/pki/tls/certs/ca-bundle.crt', '/etc/ssl/certs/ca-certificates.crt', '/etc/ssl/cert.pem']

# Generated at 2022-06-11 06:38:17.842899
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn = CustomHTTPSConnection('10.0.0.0', 1111)
    conn._tunnel_host = '127.0.0.1'
    conn._tunnel = MagicMock()
    conn.sock = MagicMock()
    conn.context = None
    conn.cert_file = 'cert.pem'
    conn.key_file = 'key.pem'
    conn.connect()
    assert conn.context
    conn.context.wrap_socket.assert_called_once_with(conn.sock, server_hostname='127.0.0.1')
    assert conn.sock == conn.context.wrap_socket.return_value
    conn.sock.close.assert_not_called()
    conn.sock = True
    conn.connect()

# Generated at 2022-06-11 06:38:22.854407
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    import binascii
    expected_result = binascii.unhexlify(b"e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4")
    with open("./test/sample_cert.der", "rb") as f:
        # Sample cert from https://www.sslshopper.com/certificate-key-matcher.html
        # SHA256 hash of cert is  e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4
        cert = f.read()
    result = get_channel_binding_cert_hash(cert)
    assert result == expected_result