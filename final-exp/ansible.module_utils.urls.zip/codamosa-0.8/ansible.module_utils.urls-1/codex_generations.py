

# Generated at 2022-06-11 06:35:28.377946
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule(
        argument_spec=dict(
            url=dict(type='str'),
            dest=dict(type='path')
        )
    )
    # TODO: write and use a good test here
    src = fetch_file(module, "http://www.gnu.org/licenses/gpl.txt")
    assert os.path.exists(src)
    assert os.path.exists(module.params['dest'])



# Generated at 2022-06-11 06:35:36.096921
# Unit test for function getpeercert
def test_getpeercert():
    try:
        # Test with a self-signed cert
        url = 'https://sni.velox.ch/'
        response = open_url(url)
        cert = getpeercert(response)
        if not cert:
            raise Exception("Certificate was not returned for %s" % url)

        # Test with a non-HTTPS URL
        url = 'http://www.google.com/humans.txt'
        response = open_url(url)
        getpeercert(response)
    except Exception:
        raise SkipTest



# Generated at 2022-06-11 06:35:44.213572
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    
    if six.PY2:
        try:
            import urllib3  # pylint: disable=unused-import
            import pyOpenSSL  # pylint: disable=unused-import
        except ImportError:
            pass
        msg = build_ssl_validation_error('foo', '80', ['a', 'b'], 'hi')
    else:
        try:
            import urllib3  # pylint: disable=unused-import
        except ImportError:
            pass
        msg = build_ssl_validation_error('foo', '80', ['a', 'b'], 'hi')



# Generated at 2022-06-11 06:35:47.986407
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    assert os.path.exists(temp_file)
    atexit_remove_file(temp_file)
    assert not os.path.exists(temp_file)



# Generated at 2022-06-11 06:35:57.349720
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        CustomHTTPSHandler()
    except NameError:
        pytest.skip("skipping CustomHTTPSHandler test")
    else:
        assert CustomHTTPSHandler is not None

if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
    #
    # The following code is under the terms and conditions of the
    # Python Software Foundation License
    #

    import json
    import os
    import warnings

    try:
        import certifi
    except ImportError:
        certifi = None

    try:
        import pyOpenSSL
    except ImportError:
        pyOpenSSL = None

    # The following block of code is under the terms and conditions of the
    # Python Software Foundation License
    #
    # Copyright (c) 2013-2016 Python Software Foundation.
    # All Rights

# Generated at 2022-06-11 06:36:07.556851
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.modules.extras.web_infrastructure.curl import main as curl_main
    from ansible.module_utils.basic import AnsibleModule

    if not HAS_URLPARSE:
        raise Exception("urlparse is not installed")

    # We do not want to depend on the module, so we just test the raw function
    # This test is a bit special, as it is not easy to test, since our open_url
    # function works with a context manager and we cannot easily mock it.
    # So it is required that we have a valid url where we can do the testing
    # As it is not really required to have a live url we do not really care
    # if the url is a real one or not

    # Create test urls
    # We do not care if the urls are valid, we just test if the function works
   

# Generated at 2022-06-11 06:36:14.937152
# Unit test for function getpeercert
def test_getpeercert():
    expect_cert = {
        'subject': ((('countryName', 'US'),),
                    (('stateOrProvinceName', 'California'),),
                    (('localityName', 'Mountain View'),),
                    (('organizationName', 'Google Inc'),),
                    (('commonName', 'www.google.com'),))
    }
    response = urllib_request.urlopen('https://www.google.com')
    cert = getpeercert(response)
    assert cert['subject'] == expect_cert['subject'], "%s != %s" % (cert['subject'], expect_cert['subject'])

# Generated at 2022-06-11 06:36:16.066417
# Unit test for method put of class Request
def test_Request_put():
    r = Request()
    r.put()

# Generated at 2022-06-11 06:36:24.956704
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    tmp_ca_cert_path, cadata, paths_checked = SSLValidationHandler('www.example.com', '443').get_ca_certs()

    exception_raised = False
    try:
        handler = SSLValidationHandler('www.example.com', '443')
        SSLValidationHandler.validate_proxy_response(handler, b'HTTP/1.0 999 Freeform message', [200])
    except ProxyError:
        exception_raised = True

    assert exception_raised
    assert SSLValidationHandler.validate_proxy_response(handler, b'HTTP/1.0 200 Freeform message', [200]) is None
    assert SSLValidationHandler.validate_proxy_response(handler, b'HTTP/1.0 200 Freeform message', [200, 201]) is None


# Generated at 2022-06-11 06:36:29.693835
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    if not HAS_HTTPS_HANDLER:
        # Cannot test this function on platforms that do not support the HTTPS handler
        return True
    # Test that the no_validate_certs option does not add an SSLValidationHandler
    validate_certs = False
    expected_result = None
    output_result = maybe_add_ssl_handler('https://www.ansible.com', validate_certs)
    assert output_result == expected_result

    # Test that the validate_certs option does add an SSLValidationHandler
    validate_certs = True
    expected_result = SSLValidationHandler('www.ansible.com', 443)
    output_result = maybe_add_ssl_handler('https://www.ansible.com', validate_certs)
    assert isinstance(output_result, type(expected_result))




# Generated at 2022-06-11 06:37:52.077616
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://localhost:80/path'
    handler = maybe_add_ssl_handler(url, False)
    assert handler == None
    handler = maybe_add_ssl_handler(url, True)
    assert hasattr(handler, 'hostname')
    assert handler.hostname == 'localhost'
    assert handler.port == 80

# Generated at 2022-06-11 06:37:56.863394
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname = 'www.ansible.com'
    port = 443
    ca_path = None

    ssl_validation_handler = SSLValidationHandler(hostname, port, ca_path)

    req = Request('http://www.ansible.com')
    ssl_validation_handler.http_request(req)
    assert True


# Generated at 2022-06-11 06:38:01.531439
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    '''
    Test for method http_request of class SSLValidationHandler
    '''
    # Initializing instance of SSLValidationHandler
    instance = SSLValidationHandler()
    # Initializing req
    req = Mock()
    # Calling http_request method of SSLValidationHandler instance
    instance.http_request(req)

# Generated at 2022-06-11 06:38:04.354120
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime()) == time.strftime('%a, %d %b %Y %H:%M:%S -0000', time.gmtime())



# Generated at 2022-06-11 06:38:10.885867
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        # Cannot test if cryptography is not available
        return

    with open(os.path.join(SELF_PATH, '..', '..', 'lib', 'hashes.py'), 'rb') as f:
        cert_der = f.read()

    digest = get_channel_binding_cert_hash(cert_der)

# Generated at 2022-06-11 06:38:16.837856
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():

    import os
    import tempfile

    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

# Generated at 2022-06-11 06:38:23.517801
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    test_obj = SSLValidationHandler()
    test_obj.get_ca_certs = MagicMock()
    test_obj.validate_proxy_response = MagicMock()
    test_obj.make_context = MagicMock()
    test_obj.hostname = MagicMock()
    test_obj.port = MagicMock()
    test_obj.ssl_wrap_socket = MagicMock()
    req = MagicMock()
    test_result = test_obj.http_request(req)
    assert test_result == req
