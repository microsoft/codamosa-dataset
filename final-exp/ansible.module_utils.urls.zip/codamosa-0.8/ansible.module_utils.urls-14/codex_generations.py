

# Generated at 2022-06-11 06:33:30.850869
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    @contextmanager
    def fake_httpconnection():
        httplib.HTTPConnection.fake = True
        yield

# Generated at 2022-06-11 06:33:41.400147
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from test.support.script_helper import assert_python_ok
    from test.support.script_helper import temp_dir, findfile
    from test.support.os_helper import TESTFN, unlink, PIPE, pwrite
    ssl_cert_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.travis', 'cert.pem')
    if not os.path.isfile(ssl_cert_file):
        ssl_cert_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'testcases', 'test_data', 'cert.pem')

# Generated at 2022-06-11 06:33:50.434157
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import urllib_parse as urlparse
    from ansible.module_utils.six.moves.urllib.parse import quote
    basic._ANSIBLE_ARGS = None

    url = 'https://example.com/foo@bar:?a=b'
    parsed = urlparse(url)
    assert parsed.netloc == 'foo@bar'
    assert parsed.path == ':', parsed.path
    assert parsed.query == 'a=b'


# Generated at 2022-06-11 06:33:56.690949
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler('test.com', 443)

    # test non-set environment variable
    assert handler.detect_no_proxy('http://test.com/test')

    # test environment variable set
    os.environ['no_proxy'] = 'a.b,c.d'
    # test with matching variable
    assert not handler.detect_no_proxy('http://a.b/test')
    # test with matching variable but different path
    assert not handler.detect_no_proxy('http://c.d.e/test')
    # test with non-matching variable
    assert handler.detect_no_proxy('http://e.f/test')
    os.environ.pop('no_proxy')


# Generated at 2022-06-11 06:33:58.437493
# Unit test for function fetch_file
def test_fetch_file():
    module = object()
    module.tmpdir = '/tmp'
    module.fail_json = lambda msg: None
    module.add_cleanup_file = lambda file: None

    data = 'testdata'
    temp_fil

# Generated at 2022-06-11 06:34:08.502845
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
  def mock_get(url, data=None, headers=None, method='GET', validate_certs=True, use_proxy=True, force=False, last_mod_time=None,
               timeout=10, http_agent='ansible-httpget', force_basic_auth=True, follow_redirects='urllib2',unix_socket=None,
               ca_path=None):
      assert url == 'https://ansible.com/redirect'
      assert method == 'GET'
      assert headers == {'Content-Type': 'application/json', 'Accept': 'application/json',
                   'Content-Length': '12'}
      assert data == '{"foo": "bar"}'
      assert timeout == 10
      assert http_agent == 'ansible-httpget'
      assert force_basic_auth is True
     

# Generated at 2022-06-11 06:34:17.588284
# Unit test for method open of class Request
def test_Request_open():
    url = "http://www.zippyshare.com/v/QZquPb5v/file.html"
    protocol = 'HTTP'
    method_test = 'GET'
    headers_test = {'User-agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'}
    request = Request()
    response = request._get_request(protocol, method_test, url, headers=headers_test)
    print("\t\t%s\n\t\t%s\n\t\t%s\n" % (response.status, response.get_method(), response.get_url()))


# Generated at 2022-06-11 06:34:19.217222
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.localtime()) == email.utils.formatdate()



# Generated at 2022-06-11 06:34:28.584604
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    class FakeUrlParse:
        def __init__(self, hostname, port=None):
            self.hostname = hostname
            self.port = port

    class FakeResponse:
        def __init__(self):
            self.headers = ['foo']

    resp = FakeResponse()
    handler = maybe_add_ssl_handler('http://www.ansible.com/foo', True)
    assert handler is None

    # first handle the actual SSLValidationHandler
    handler = maybe_add_ssl_handler('https://www.ansible.com/foo', True)
    req = urllib2.Request('https://www.ansible.com/foo')
    assert isinstance(handler, SSLValidationHandler)
    assert handler.hostname == u'www.ansible.com'

    # should raise an error if we don

# Generated at 2022-06-11 06:34:31.567327
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    rfc2822_date_string((2001, 11, 9, 1, 8, 47, 4, 313, 0), '-0000')



# Generated at 2022-06-11 06:35:41.202115
# Unit test for function fetch_file
def test_fetch_file():

    main_test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(main_test_dir, 'test_fetch_file')

    # Create a temp dir to save test file
    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-11 06:35:45.595351
# Unit test for function getpeercert
def test_getpeercert():
    """ Test if the getpeercert works. """
    response = None
    try:
        response = urllib_request.urlopen("https://www.google.com")
    except Exception as e:
        assert(False), "Failed to get response from https://www.google.com: %s" % e
    cert = getpeercert(response)
    assert(cert)

# Generated at 2022-06-11 06:35:50.435483
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname = "github.com"
    https_port = 443
    request = urllib_request.Request('https://%s:%d' % (hostname, https_port))
    handler = SSLValidationHandler(hostname, https_port)
    try:
        handler.http_request(request)
    except Exception as e:
        assert False, "Unexpected exception was raised: {}".format(str(e))
    assert True

# Generated at 2022-06-11 06:36:00.229092
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Setup
    test_ca_path = '/etc/ssl/certs'
    urllib_request.ProxyHandler = MagicMock()
    urllib_request.build_opener = MagicMock()
    urllib_request.install_opener = MagicMock()
    ssl_validation_handler = SSLValidationHandler('www.example.com', 443, test_ca_path)

    # Test with no_proxy set
    os.environ['no_proxy'] = "example.com,example2.com"
    assert ssl_validation_handler.detect_no_proxy("https://www.example.com") == False

    # Test with no_proxy not set
    del os.environ['no_proxy']

# Generated at 2022-06-11 06:36:03.635544
# Unit test for method open of class Request
def test_Request_open():
    handler = Request()
    handler.open('GET', 'http://www.google.com')

    # Testing when open method called with Method as case insenstive
    handler.open('get', 'http://www.google.com')



# Generated at 2022-06-11 06:36:13.735376
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler('localhost', 443)
    # Test correct parsing of no_proxy
    os.environ['no_proxy'] = 'localhost,192.168.1.7,www.example.com'
    # Test how it works with a matching url
    assert handler.detect_no_proxy('https://localhost') == False
    # Test it works with an url with a different port
    assert handler.detect_no_proxy('https://localhost:8443') == False
    # Test it works with an ip
    assert handler.detect_no_proxy('https://192.168.1.7') == False
    # Test it works with an ip with port
    assert handler.detect_no_proxy('https://192.168.1.7:8000') == False
    # Test it works with a domain with a port

# Generated at 2022-06-11 06:36:22.816309
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test the generic_urlparse function for a variety of inputs
    '''
    # Test with a new style parts object
    new_parts = generic_urlparse(urllib_parse.ParseResult('scheme', 'netloc', 'path', 'params', 'query', 'fragment'))
    for k, v in {'scheme': 'scheme', 'netloc': 'netloc', 'path': 'path',
        'params': 'params', 'query': 'query', 'fragment': 'fragment'}.items():
        assert new_parts[k] == v
    # Test with a old style tuple
    old_tuple = generic_urlparse(('scheme', 'netloc', 'path', 'params', 'query', 'fragment'))

# Generated at 2022-06-11 06:36:24.840350
# Unit test for method open of class Request
def test_Request_open():
    url = 'http://192.168.100.101'
    r = Request(url)
    print(r.open('GET'))


# Generated at 2022-06-11 06:36:34.621404
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    with patch.object(ssl, 'wrap_socket') as mock_wrap_socket:
        c = CustomHTTPSConnection('host', port=1, key_file='a', cert_file='b')
        mock_wrap_socket.assert_called_once_with(ANY, certfile='b', keyfile='a', ssl_version=PROTOCOL)


if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, *args, **kwargs):
            urllib_request.HTTPSHandler.__init__(self, *args, **kwargs)

            # Redirect urllib3's 'sslv3' protocol to PROTOCOL
            # This is needed because urllib3 has SSLError:

# Generated at 2022-06-11 06:36:44.109101
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():

    class MockSocket(object):
        def __init__(self):
            self.hostname = None
        def create_connection(self, hostname):
            self.hostname = hostname
            if hostname is not None:
                return True

    class MockSSLValidationHandler(SSLValidationHandler):
        def __init__(self, hostname, port, ca_path=None):
            self.ssl = MockSocket()
            self.error = False
            self.ssl_error = False
            self.certificate_error = False
            super(MockSSLValidationHandler, self).__init__(hostname, port, ca_path)
        def make_context(self, cafile, cadata):
            return True
        def get_ca_certs(self):
            return None

# Generated at 2022-06-11 06:38:09.227772
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    fetch_file(module, 'https://www.google.com')


# Generated at 2022-06-11 06:38:15.449609
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    host = 'example.com'
    port = None
    key_file = '/path/to/key'
    cert_file = '/path/to/cert'
    timeout = 2
    source_address = ('127.0.0.1', 0)

    class FakeContext:
        def __init__(self, hostname):
            pass

    original_create_connection = socket.create_connection
    original_wrap_socket = ssl.wrap_socket
    original_sslv23 = ssl.PROTOCOL_SSLv23
    original_context = ssl._create_stdlib_context
    socket.create_connection = FakeContext
    ssl.wrap_socket = FakeContext
    ssl._create_stdlib_context = FakeContext
    ssl.PROTOCOL_SSLv23 = PROTOCOL


# Generated at 2022-06-11 06:38:21.178850
# Unit test for function build_ssl_validation_error

# Generated at 2022-06-11 06:38:29.228111
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    handler = SSLValidationHandler('10.10.10.10', 443)
    # We should always return a path for the ca cert and a list of paths that were checked
    return_value = handler.get_ca_certs()
    assert len(return_value) == 3
    ca_cert_path, cadata, paths_checked = return_value

    assert ca_cert_path is not None
    assert cadata is not None
    assert paths_checked is not None
    assert len(paths_checked) > 0

    # Make sure that if we get a non-None self.ca_path argument, we always return it
    handler2 = SSLValidationHandler('10.10.10.10', 443, ca_path='/etc/ssl/certs/certificate.pem')
    ca_cert_path2, cadata2, paths