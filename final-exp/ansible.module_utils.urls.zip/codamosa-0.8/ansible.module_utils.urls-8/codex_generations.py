

# Generated at 2022-06-11 06:34:20.549460
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    request = lambda: None
    request.get_method = lambda: "GET"
    request.headers = {}
    request.get_full_url = lambda: "http://localhost/"
    fp = StringIO()
    hdrs = {'location': 'http://localhost/foo.html'}

    # RedirectHandlerFactory takes a single argument follow_redirects which
    # determines if the redirect call will raise an exception or return a
    # request. Passing any value that is not 'urllib2' will not redirect
    # the request and the handler will raise an exception. Passing
    # 'urllib2' as the argument will call urllib2's behavior which will
    # return a request with the url changed to the redirect url.
    handler = RedirectHandlerFactory('never')

# Generated at 2022-06-11 06:34:30.928732
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    global HAS_SSL

    class FakeOpener(object):
        def __init__(self):
            self.handlers = []

        def add_handler(self, handler):
            self.handlers.append(handler)

    # Test that it raises NoSSLError if HAS_SSL is False
    HAS_SSL = False
    url = 'https://localhost:8443'
    fake_opener = FakeOpener()
    assert_raises(NoSSLError, maybe_add_ssl_handler, url, True, fake_opener)

    # Test that it returns the SSLValidationHandler if HAS_SSL is True
    HAS_SSL = True
    ssl_handler = maybe_add_ssl_handler(url, True, fake_opener)
    assert isinstance(ssl_handler, SSLValidationHandler)



# Generated at 2022-06-11 06:34:37.013513
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from datetime import datetime
    r = 'Fri, 09 Nov 2001 01:08:47 -0000'
    t = (2001, 11, 9, 1, 8, 47, 4)
    z = '-0000'
    assert rfc2822_date_string(t, z) == r
    d = datetime(*t[:7])
    assert rfc2822_date_string(d, z) == r
# End unit test for function rfc2822_date_string



# Generated at 2022-06-11 06:34:47.335055
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    valid_codes = [200, 301, 401, 404, 405]
    # Test for some valid values for parameter response
    for code in valid_codes:
        handler = SSLValidationHandler('', '', '')
        response = "HTTP/1.0 %s OK" % code
        try:
            handler.validate_proxy_response(to_bytes(response, errors='surrogate_or_strict'))
        except ProxyError:
            assert False

    # Test for some invalid values for parameter response
    invalid_codes = [116, 203, 206, 401]
    for code in invalid_codes:
        handler = SSLValidationHandler('', '', '')
        response = "HTTP/1.0 %s OK" % code

# Generated at 2022-06-11 06:34:52.059446
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Tests to ensure the function generic_urlparse is behaving properly
    '''

# Generated at 2022-06-11 06:34:56.607438
# Unit test for function getpeercert
def test_getpeercert():
    response = get_response(urllib_request.urlopen)
    assert getpeercert(response) == get_response_cert(True)
    response = get_response(urllib_request.urlopen, scheme='https')
    assert getpeercert(response) == get_response_cert()
    assert getpeercert(response, True) == get_response_cert(True)
    assert getpeercert(response, False) == get_response_cert()


# Generated at 2022-06-11 06:35:02.508333
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    from __main__ import maybe_add_ssl_handler
    from six.moves.urllib.request import build_opener, HTTPSHandler
    url = 'http://www.google.com'
    handler = maybe_add_ssl_handler(url, validate_certs=True)
    assert handler is None
    url = 'https://www.google.com'
    # Make sure that the right type of handler is being added
    handler = maybe_add_ssl_handler(url, validate_certs=True)
    opener = build_opener(HTTPSHandler)
    try:
        opener.open(url)
    except Exception as e:
        assert type(e) == NoSSLError
    else:
        assert type(handler) == SSLValidationHandler



# Generated at 2022-06-11 06:35:14.075522
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Create an object of class SSLValidationHandler
    ssl_validation_handler = SSLValidationHandler("host", 443)

# Generated at 2022-06-11 06:35:18.632586
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    """ Test rfc2822_date_string function returns expected value """
    rfc2822_timetuple = (2016, 6, 27, 11, 46, 45, 0) # 1st second of 2016-06-27

    # Set timezone to UTC
    timezone_orig = os.environ.get('TZ', None)
    os.environ['TZ'] = 'UTC'
    time.tzset()

    # Get timezone from system clock
    time_local = time.localtime(calendar.timegm(rfc2822_timetuple))
    time_zone = time_local.tm_gmtoff

    # Set timezone to UTC
    if timezone_orig is None:
        del os.environ['TZ']
    else:
        os.environ['TZ'] = timezone_orig


# Generated at 2022-06-11 06:35:29.347631
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.urls as urls

    # This is needed for testing.  The method does not exist in AnsibleModule
    def fail_json(**kwargs):
        raise ValueError(kwargs)

    module = AnsibleModule(
        argument_spec=url_argument_spec(),
    )
    module.fail_json = fail_json
    module.params = {'url': 'http://httpbin.org/robots.txt'}
    module.tmpdir = tempfile.gettempdir()
    resp, info = fetch_url(module, module.params['url'], use_proxy=False)
    assert resp.read() == b'User-agent: *\nDisallow: /deny\n'
    resp.close()

   

# Generated at 2022-06-11 06:36:31.566840
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'www.example.com'
    port = 80
    paths = ['/etc/ssl/certs/ca-certificates.crt', '/etc/ssl/certs/ca-bundle.crt']
    with pytest.raises(SSLValidationError):
        raise build_ssl_validation_error(hostname, port, paths)


# Generated at 2022-06-11 06:36:41.408921
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    b_test_CustomHTTPSConnection = httplib.HTTPSConnection
    try:
        from ansible.module_utils.urls import CustomHTTPSConnection
        https = CustomHTTPSConnection('example.com', context=None)
        assert https.__class__ == CustomHTTPSConnection
    finally:
        httplib.HTTPSConnection = b_test_CustomHTTPSConnection


if hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        """
        An HTTPS handler that uses a CustomHTTPSConnection
        """
        def https_open(self, req):
            return self.do_open(CustomHTTPSConnection, req)



# Generated at 2022-06-11 06:36:50.305054
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    class SSLValidationHandler(object):
        @staticmethod
        def make_context(cafile, cadata):
            return ssl.create_default_context(cafile=cafile, cadata=cadata)


# Generated at 2022-06-11 06:36:59.432545
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    conn = UnixHTTPConnection('/my/socket')
    conn.connect()
    assert conn.sock is not None


    class UnixHTTPSConnection(httplib.HTTPSConnection):
        def __init__(self, unix_socket, *args, **kwargs):
            httplib.HTTPSConnection.__init__(self, *args, **kwargs)
            self._unix_socket = unix_socket

        def connect(self):
            with unix_socket_patch_httpconnection_connect():
                super(UnixHTTPSConnection, self).connect()
            # UTC time is used since this value is only used internally
            # to calculate the SSL session id and can safely differ from the
            # systemwide time.

# Generated at 2022-06-11 06:37:09.736759
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    req = RequestWithMethod('http://foo.org/','POST')
    RedirectHandlerFactory('no')().redirect_request(req,None,301,'test',{'Location':'http://bar.org/'},'')
    req = RequestWithMethod('http://foo.org/','GET')
    RedirectHandlerFactory('yes')().redirect_request(req,None,301,'test',{'Location':'http://bar.org/'},'')
    RedirectHandlerFactory('safe')().redirect_request(req,None,301,'test',{'Location':'http://bar.org/'},'')
    RedirectHandlerFactory('urllib2')().redirect_request(req,None,301,'test',{'Location':'http://bar.org/'},'')

# Generated at 2022-06-11 06:37:12.424580
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    reqest_method = RequestWithMethod(None, 'post').get_method()
    assert reqest_method == 'POST'

    reqest_method = RequestWithMethod(None, 'get').get_method()
    assert reqest_method == 'GET'



# Generated at 2022-06-11 06:37:13.673773
# Unit test for function fetch_file
def test_fetch_file():
    raise SkipTest('Not yet implemented')



# Generated at 2022-06-11 06:37:19.915232
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    try:
        with patch('ansible_mitogen.urllib_ext.socket.create_connection',
            Mock(side_effect=ConnectionError())):
            url = 'https://yum.baseurl.org/path'
            req = Request(url)
            handler = SSLValidationHandler('yum.baseurl.org', 443, '/etc/ansible/roles/mitogen/files/ca-bundle.crt')
            handler.http_request(req)
            assert False
    except ConnectionError:
        pass

# Generated at 2022-06-11 06:37:22.798928
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    '''
    Test atexit_remove_file
    '''
    tmp_file = tempfile.NamedTemporaryFile()
    atexit_remove_file(tmp_file.name)
    assert not os.path.exists(tmp_file.name)



# Generated at 2022-06-11 06:37:30.798590
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'http://127.0.0.1:8000/test/doc'
    handler = maybe_add_ssl_handler(url, validate_certs=True)
    assert handler is None

    url = 'https://127.0.0.1:8000/test/doc'
    handler = maybe_add_ssl_handler(url, validate_certs=False)
    assert handler is None

    url = 'http://127.0.0.1:8000/test/doc'
    handler = maybe_add_ssl_handler(url, validate_certs=False)
    assert handler is None

    url = 'https://127.0.0.1:8000/test/doc'
    handler = maybe_add_ssl_handler(url, validate_certs=True)
    assert handler is not None



# Generated at 2022-06-11 06:38:13.512303
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Verifies that the function get_channel_binding_cert_hash returns
        the expected channel binding app data when provided a DER formatted
        TLS certificate.
    """
    # OpenSSL cert with signature hash algorithm of SHA256

# Generated at 2022-06-11 06:38:19.377696
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class HTTPMock(object):
        pass
    class HTTPConnectionMock(object):
        pass
    class SSLSocketWrapperMock(object):
        def __init__(self, sock, keyfile, cert_reqs, certfile, ssl_version, server_hostname):
            self.sock = sock
            self.keyfile = keyfile
            self.cert_reqs = cert_reqs
            self.certfile = certfile
            self.ssl_version = ssl_version
            self.server_hostname = server_hostname

# Generated at 2022-06-11 06:38:24.763932
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    follow_redirect_flags = {
        'all': True,
        'yes': True,
        True: True,
        'no': False,
        'none': False,
        False: False,
        'safe': True
    }
    for follow_redirect, expected_result in follow_redirect_flags.items():
        handler = RedirectHandlerFactory(follow_redirect)
        if expected_result:
            ignored_url = 'http://localhost/'
            ignored_code = 302
            ignored_msg = 'ignored msg'
            ignored_hdrs = {'ignored': 'ignored'}
            new_url = 'http://localhost/new_url'
            request = RequestWithMethod(new_url, 'GET')