

# Generated at 2022-06-11 06:33:50.080495
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # ensure there are no errors raised when we create an object
    try:
        conn = CustomHTTPSConnection(HTTP_HOST, HTTP_PORT)
    except:
        pass
    conn.request('GET', '/')

if CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, *args, **kwargs):
            urllib_request.HTTPSHandler.__init__(self, debuglevel=kwargs.pop('debuglevel', 0))

        def https_open(self, req):
            return self.do_open(CustomHTTPSConnection, req)




# Generated at 2022-06-11 06:33:56.890945
# Unit test for function getpeercert
def test_getpeercert():
    """Tests that a response from a valid domain populates all necessary information from the certificate"""
    def parse(response):
        return getpeercert(response)

    response = urlopen('https://www.google.com')
    cert = parse(response)
    assert cert['subjectAltName'] == (('DNS', 'www.google.com'), ('DNS', 'google.com'))
    assert cert['notAfter'] == 'May 17 12:23:09 2020 GMT'
    assert cert['notBefore'] == 'Jul  3 12:00:00 2018 GMT'
    assert cert['issuer'] == ((('countryName', 'US'),), (('organizationName', 'Google Trust Services'),), (('organizationalUnitName', 'GTS CA 1B'),), (('commonName', 'GTS CA 1B'),))

# Generated at 2022-06-11 06:34:02.479712
# Unit test for constructor of class Request
def test_Request():
    '''
    >>> url = 'http://127.0.0.1:8080/test-url/'
    >>> request = Request(url, headers={'Content-Length': 0})
    >>> print(request) # doctest: +ELLIPSIS
    <urllib2.Request instance at ...>
    >>> print(request.get_full_url())
    http://127.0.0.1:8080/test-url/
    '''
    pass


# Generated at 2022-06-11 06:34:12.532277
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test function build_ssl_validation_error
    '''

    def do_test(expect_msg, **kwargs):
        '''
        Parameters:
            expect_msg: String, expected error message
            **kwargs: All parameters passed to function build_ssl_validation_error()
        '''
        try:
            build_ssl_validation_error(**kwargs)
        except SSLValidationError as ssl_exc:
            actual_msg = str(ssl_exc)
            assert expect_msg == actual_msg, 'expected:\n%s\nactual:\n%s' % (expect_msg, actual_msg)
        else:
            assert False, 'expect SSLValidationError'


# Generated at 2022-06-11 06:34:21.606719
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    from ansible.utils.encrypt import decrypt_text
    from .mock import patch


# Generated at 2022-06-11 06:34:24.769619
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    '''
    Test for get_ca_certs of class SSLValidationHandler
    '''
    ca_path = '/path/to/test/certs'
    ssl_handler = SSLValidationHandler('127.0.0.1', 443, ca_path=ca_path)
    assert len(ssl_handler.get_ca_certs()) == 3
    assert ssl_handler.get_ca_certs()[0] == ca_path


# Generated at 2022-06-11 06:34:35.400692
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():

    class Test:
        '''Test class for method get_ca_certs of class SSLValidationHandler'''

        def setUp(self):
            self.TestObj = SSLValidationHandler(hostname='8.8.8.8', port=443)
            # Use dummy_ca_cert
            self.ca_path = os.path.join(CERT_PATH, 'dummy_ca_cert')
            self.expected_result = (self.ca_path, b'', [self.ca_path])

        def tearDown(self):
            try:
                del(self.TestObj)
            except AttributeError:
                pass

        def test_case_1(self):
            '''
            Test get_ca_certs of class SSLValidationHandler with ca_path
            '''
            global LOADED_VER

# Generated at 2022-06-11 06:34:45.564894
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-11 06:34:55.375495
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    if not HAS_SSLCONTEXT:
        pytest.skip("Cannot test build_ssl_validation_error because python is too old")

    hostname = 'example.org'
    port = 80
    expected_error = ' '.join([
        'Failed to validate the SSL certificate for example.org:80.',
        ' Make sure your managed systems have a valid CA certificate installed.',
        'You can use validate_certs=False if you do not need to confirm the'
        ' servers identity but this is unsafe and not recommended.',
        ' Paths checked for this platform: /etc/ssl/certs/ca-certificates.crt.',
        'The exception msg was: "message".'
    ])


# Generated at 2022-06-11 06:35:05.990838
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    if HAS_SSLCONTEXT:
        expected_msg = "Failed to validate the SSL certificate for example.com:443. Make sure your managed systems have a valid CA certificate installed. You can use validate_certs=False if you do not need to confirm the servers identity but this is unsafe and not recommended. Paths checked for this platform: /etc/ssl/certs/ca-certificates.crt."

# Generated at 2022-06-11 06:36:26.595116
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Unit test for function get_channel_binding_cert_hash. """
    # Logic documented in RFC 5929 section 4 https://tools.ietf.org/html/rfc5929#section-4

# Generated at 2022-06-11 06:36:36.535154
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from ansible.module_utils.urls import SSLValidationHandler, ProxyError
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    import os

    # A dummy cert taken from Equifax Secure Certificate Authority

# Generated at 2022-06-11 06:36:43.807791
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    class TestSSLValidationHandler(SSLValidationHandler):
        def __init__(self, hostname, port, ca_path=None):
            SSLValidationHandler.__init__(self, hostname, port, ca_path)

    handler = TestSSLValidationHandler('127.0.0.1', 443)
    req = urllib_request.Request('https://127.0.0.1')
    handler.get_ca_certs = lambda: ('', '', '')
    handler.make_context = lambda cafile, cadata: mock.Mock()
    handler.http_request(req)

# Generated at 2022-06-11 06:36:49.198346
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    '''Unit test for method connect of class UnixHTTPConnection
    '''
    with pytest.raises(OSError) as excinfo:
        UnixHTTPConnection('/this/is/an/invalid/path/to/socket')
    expect_error = 'Invalid Socket File (/this/is/an/invalid/path/to/socket): '
    expect_error += '[Errno 2] No such file or directory'
    assert expect_error == str(excinfo.value)



# Generated at 2022-06-11 06:36:58.280305
# Unit test for function fetch_file
def test_fetch_file():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    def mock_fetch_url(module, url, data=None, headers=None, method=None,
               use_proxy=True, force=False, last_mod_time=None, timeout=10):
        return 'new_file_name.txt', None
    url = 'http://dummy.com/file.txt'
    data = 'test_data'
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    tempdir = tempfile.mkdtemp()
    module.tmpdir = tempdir
    module.params = dict(
        url = url,
        data = data,
        method = 'GET',
        unredirected_headers = None
    )

# Generated at 2022-06-11 06:37:08.515398
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test redirect handling
    target = 'http://httpbin.org'
    def make_mock_urlopen(status):
        def mock_urlopen(req):
            # Return a redirect
            class MockResponse(object):
                code = status
                info = lambda: {'Location': target}
                geturl = lambda: target
                isclosed = lambda: True
            return MockResponse
        return mock_urlopen


# Generated at 2022-06-11 06:37:18.644178
# Unit test for function getpeercert
def test_getpeercert():
    """Test getpeercert."""

    check_name_matches_cert = False
    proxyurl = os.environ.get('https_proxy')
    if proxyurl:
        if proxyurl.startswith('https:') or proxyurl.startswith('HTTPS:'):
            # If the HTTPS server uses a self-signed certificate,
            # use the following environment variables to suppress
            # InsecureRequestWarning and to disable certificate
            # name matching.
            os.environ['PYTHONWARNINGS'] = 'ignore:Unverified HTTPS request'
            check_name_matches_cert = True
        else:
            # We can't use proxy for HTTPS
            proxyurl = None

# Generated at 2022-06-11 06:37:26.004823
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    """
    This test does not verify the correctness of the connection but is just a
    check for syntax errors.
    """
    c = CustomHTTPSConnection('localhost', '443')
    c.connect()

if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, ssl_verify, *args, **kwargs):
            self.ssl_verify = ssl_verify
            urllib_request.HTTPSHandler.__init__(self, *args, **kwargs)

        def https_open(self, req):
            return self.do_open(self.getConnection, req)


# Generated at 2022-06-11 06:37:31.193692
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(None) is None

    class DummyResponse(object):
        def __init__(self):
            self.fp = DummyFile
    class DummyFile(object):
        def __init__(self):
            self._sock = DummySock()
    class DummySock(object):
        def __init__(self):
            self.fp = DummySocket()
    class DummySocket(object):
        def __init__(self):
            self.getpeercert = lambda: None

    response = DummyResponse()
    assert getpeercert(response) is None

# ==============================================================
# Subprocess based socket handling
#
# This is needed on Windows to ensure that is process
# doesn't hang when calling communicate() on a process
# object created by subprocess.Popen().


# Generated at 2022-06-11 06:37:33.367425
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod('http://localhost:8080/test', method='POST', data={})
    assert request.get_method() == 'POST'
    request = RequestWithMethod('http://localhost:8080/test', data={})
    assert request.get_method() == 'POST'

