

# Generated at 2022-06-11 06:32:46.269952
# Unit test for function getpeercert
def test_getpeercert():
    getpeercert(None)


# Generated at 2022-06-11 06:32:58.933001
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    CustomHTTPSConnection.connect=test_connect
    import unittest
    class MockSocket(object):
        def wrap_socket(self, sock, server_hostname=None, **kwargs):
            self.sock = sock
            self.server_hostname = server_hostname
            return 'sslsock'
    with tempfile.NamedTemporaryFile() as tmp:
        file_name = tmp.name
        def test_connect(self, *args, **kwargs):
            self.sock = MockSocket()
            self.sock.server_hostname = None
            self.sock.sock = None
            self.cert_file = file_name
            self.key_file = file_name
            self.context = 'context'
            self._tunnel_host = 'tunnel'

# Generated at 2022-06-11 06:33:07.872856
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if not hasattr(ssl, 'wrap_socket') or not hasattr(httplib, 'HTTPSConnection') or not hasattr(urllib_request, 'HTTPSHandler'):
        return None
    conn = CustomHTTPSConnection('127.0.0.1', timeout=10)
    return conn


if HAS_URLLIB3_PYOPENSSLCONTEXT:
    class SSLContext(PyOpenSSLContext):
        def __init__(self, protocol):
            if not HAS_SSLCONTEXT:
                # Divergence: Use pow() for Python 2.5 compat
                protocol = pow(2, getattr(ssl, 'PROTOCOL_%s' % protocol))
            super(SSLContext, self).__init__(protocol)



# Generated at 2022-06-11 06:33:13.360391
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    test_CustomHTTPSConnection.__name__ = 'CustomHTTPSConnection'
    try:
        # Verify that we get an exception as we don't have any server listening on localhost:1
        conn = CustomHTTPSConnection('localhost', 1)
        conn.connect()
    except Exception:
        pass


if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(CustomHTTPSConnection, req)


# Handle proxies that require authentication
if hasattr(urllib_request, 'ProxyBasicAuthHandler'):
    class CustomProxyBasicAuthHandler(urllib_request.ProxyBasicAuthHandler):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-11 06:33:18.953921
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    res = None
    try:
        test_CustomHTTPSHandler.handler = CustomHTTPSHandler(cert_file='dummy', key_file='dummy')
        res = True
    except TypeError:  # We need a context
        res = False
    assert res, "CustomHTTPSHandler() must be called with cert_file, key_file and a context"

# Create a new class with a constructor different signature than
# HTTPSClientAuthHandler.
# We still need to use HTTPSClientAuthHandler and can not use our
# own class with the same name as this would break urllib2.
# We need to change the signature to be able to create a context.

# Generated at 2022-06-11 06:33:30.102714
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    class MockRequest(object):
        def __init__(self, method, url):
            self.method = method
            self.url = url

        def get_method(self):
            return self.method

        def get_full_url(self):
            return self.url

    # test follow_redirects == 'urllib2'
    req = MockRequest('GET', 'foo')
    redirect_handler = RedirectHandlerFactory(follow_redirects='urllib2')
    new_req = redirect_handler.redirect_request(req, None, 302, 'foo', dict(), 'bar')
    assert new_req.get_full_url() == 'bar'
    assert new_req.get_method() == 'GET'

# Generated at 2022-06-11 06:33:39.888050
# Unit test for function prepare_multipart
def test_prepare_multipart():
    input_value = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }


# Generated at 2022-06-11 06:33:49.685362
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return

    # Let's get a real server certificate off the wire and use that.
    # We try to validate the cert when we get it, however that's not a blocker,
    # if we get a cert, we're good.
    try:
        with closing(urllib_request.urlopen('https://api.github.com/', cafile=os.path.dirname(__file__) + "/res/ansible-test.pem")) as req:
            cert = getpeercert(req, True)
            if req.getcode() == 200 and cert:
                cert_hash = get_channel_binding_cert_hash(cert)
                assert isinstance(cert_hash, bytes)
    except Exception:
        pass

test_get_channel_binding_cert_hash

# Generated at 2022-06-11 06:33:53.514978
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    """
    Unit test for method get_method of class RequestWithMethod
    """
    req = RequestWithMethod('http://127.0.0.1', 'GET', unverifiable=True)
    assert req.get_method() == 'GET'
    req = RequestWithMethod('http://127.0.0.1', 'POST', unverifiable=True)
    assert req.get_method() == 'POST'



# Generated at 2022-06-11 06:34:02.238722
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    import uuid
    for netloc in ('localhost', 'foo.com', 'bar.org:9443', 'my.com:443'):
        for host in ('localhost', 'foo.com', 'bar.org:9443', 'my.com:443', 'x.y.z.w'):
            args = dict(
                netloc=netloc,
                host=host,
            )
            u = 'http://%(netloc)s/some/path/%(random)s?a=1&b=2' % dict(args, random=uuid.uuid4())
            a = SSLValidationHandler(**args)
            if netloc.endswith(host) or netloc.split(':')[0].endswith(host):
                assert not a.detect_no_proxy(u)
               

# Generated at 2022-06-11 06:35:35.903223
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = ['http', 'user:pass@foo.com:8080', '/path/', '', '', '']
    generic_parts = generic_urlparse(parts)
    assert isinstance(generic_parts, dict)
    assert 'path' in generic_parts
    assert 'username' in generic_parts
    assert generic_parts['scheme'] == 'http'
    assert generic_parts['netloc'] == 'user:pass@foo.com:8080'
    assert generic_parts['hostname'] == 'foo.com'
    assert generic_parts['path'] == '/path/'
    assert generic_parts['port'] == 8080
    assert generic_parts['username'] == 'user'
    assert generic_parts['password'] == 'pass'

# Generated at 2022-06-11 06:35:45.597989
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    #import sys
    #sys.path.append('.')
    import lib.urllib.request
    url = 'https://192.168.121.128/test_ansible_http.php'

# Generated at 2022-06-11 06:35:49.356287
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():

    # Instanciate the class
    SSLValidationHandler_instance = SSLValidationHandler('github.com', 443, None)

    # Test the method
    try:
        SSLValidationHandler_instance.http_request('test_string')
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-11 06:35:55.976954
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    class MockUnixSocket(object):
        connected = False
        def __init__(self, *args, **kwargs):
            pass

        def connect(self, unix_socket):
            MockUnixSocket.connected = True

        def settimeout(self, timeout):
            pass

    try:
        unixsocket = MockUnixSocket()
        connection = UnixHTTPConnection(unix_socket=unixsocket)
        connection.connect()
        assert MockUnixSocket.connected
    except:
        assert False, "test_UnixHTTPConnection_connect has failed"


# Generated at 2022-06-11 06:36:06.029226
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Unit test for function get_channel_binding_cert_hash. """
    import binascii


# Generated at 2022-06-11 06:36:15.689592
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CustomHTTPSHandler:
        return

    handler = CustomHTTPSHandler()
    assert handler.do_open.__name__ == 'do_open'
    assert handler.do_open.__module__ == CustomHTTPSHandler.do_open.__module__

if not HAS_SSL:
    # We need to make sure HTTPSConnection is always available since it is referenced in the module
    class HTTPSConnection(CustomHTTPSConnection):
        pass

if HAS_SSLCONTEXT:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
        '''
        Basic SSL client authentication
        '''
        # Note the class-level attributes referenced in the constructor below
        # are set via the set_auth_cert_params() method.

# Generated at 2022-06-11 06:36:24.564247
# Unit test for function fetch_file
def test_fetch_file():
    class Module(object):
        # Mock the AnsibleModule
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
        # Mock the AnsibleModule's add_cleanup_file method
        def add_cleanup_file(self, file):
            pass
        # Mock the AnsibleModule's fail_json method
        def fail_json(self, *args, **kwargs):
            pass
    class MockResponse(object):
        def __init__(self, url):
            self.read = lambda size: "data"
        def geturl(self):
            return "http://foo"
        def info(self):
            return {}
    class MockFetchUrl(object):
        def __init__(self, response):
            self.response = response

# Generated at 2022-06-11 06:36:34.267752
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test build_ssl_validation_error
    '''

# Generated at 2022-06-11 06:36:43.806446
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CustomHTTPSHandler:
        return

    handler = CustomHTTPSHandler(**{})


if HAS_SSLCONTEXT:
    class HTTPSClientAuthHandler(urllib_request.BaseHandler):
        def __init__(self, key, cert, ca_certs=None, **kwargs):
            self._context = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH, cafile=ca_certs)
            self._context.load_cert_chain(cert, key)

            urllib_request.BaseHandler.__init__(self)

        def https_open(self, req):
            return self.do_open(
                functools.partial(
                    httplib.HTTPSConnection,
                    context=self._context
                ),
                req
            )

       

# Generated at 2022-06-11 06:36:52.654786
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    hostname, port = '127.0.0.1', 8080
    handler = SSLValidationHandler(hostname, port)
    url = "https://127.0.0.1:8080"

    ret = handler.detect_no_proxy(url)
    assert ret == True

    os.environ['no_proxy']='127.0.0.1'
    ret = handler.detect_no_proxy(url)
    assert ret == False

    url = "http://127.0.0.1:8080"
    ret = handler.detect_no_proxy(url)
    assert ret == True

    os.environ['no_proxy']='127.0.0.1,test.com'
    ret = handler.detect_no_proxy(url)
    assert ret == False


# Generated at 2022-06-11 06:37:38.079448
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    class MyHTTPBasicAuthHandler(urllib_request.HTTPBasicAuthHandler):
        def http_request(self, req):
            return req

        https_request = http_request

    class MyHTTPDigestAuthHandler(urllib_request.HTTPDigestAuthHandler):
        def http_request(self, req):
            return req

        https_request = http_request

    class HTTPRedirectHandler(urllib_request.HTTPRedirectHandler):
        def http_error_302(self, req, fp, code, msg, headers):
            return req

        http_error_301 = http_error_303 = http_error_307 = http_error_302


# Generated at 2022-06-11 06:37:44.692243
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    from tempfile import mkstemp

    _, tmp_ca_cert_path = mkstemp(prefix="ansible_test_")
    sslh = SSLValidationHandler("www.example.com", 443, tmp_ca_cert_path)
    tmp_ca_cert_path2, cadata, paths_checked = sslh.get_ca_certs()
    assert tmp_ca_cert_path == tmp_ca_cert_path2
    assert isinstance(cadata, bytearray)

# Generated at 2022-06-11 06:37:55.392393
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    def _test(follow_redirects, expected_follow_redirects):
        redirect_handler = RedirectHandlerFactory(follow_redirects)(
            debuglevel=1)
        assert redirect_handler.follow_redirects == expected_follow_redirects
    _test('urllib2', True)
    _test('all', True)
    _test('yes', True)
    _test(True, True)
    _test('no', False)
    _test('none', False)
    _test('safe', False)
    _test(False, False)

    # aliases
    _test('all_redirects', True)
    _test('no_redirects', False)
    _test('safe_redirects', False)



# Generated at 2022-06-11 06:38:04.571387
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import urllib_request
    # Test response with only code
    res = Response(url="http://foo.bar", code=301)
    # following redirects must be handled with a single HTTP handler
    redirect_handler = RedirectHandlerFactory(follow_redirects='no').redirect_request(None, None, res.getcode(), None, None, "http://bar.foo")
    assert redirect_handler.get_full_url() == "http://bar.foo"
    redirect_handler = RedirectHandlerFactory(follow_redirects='none').redirect_request(None, None, res.getcode(), None, None, "http://bar.foo")
    assert redirect_handler.get_full_url() == "http://bar.foo"
    redirect_handler = RedirectHandlerFactory(follow_redirects=False).redirect_

# Generated at 2022-06-11 06:38:11.068626
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils._text import to_bytes
    import json

    param_args = dict(
        url='http://example.org',
        url_username='user',
        url_password='pass',
        data={'k': 'v'},
        method='POST',
        validate_certs=True,
        follow_redirects='urllib2',
        use_gssapi=False,
    )

    class FakeModule(object):
        @property
        def params(self):
            return param_args

        @property
        def tmpdir(self):
            return None

        def jsonify(self, data):
            return json.dumps(data)


# Generated at 2022-06-11 06:38:14.697514
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    tmp_ca_cert_path, cadata, paths_checked = SSLValidationHandler.get_ca_certs()
    assert tmp_ca_cert_path is None
    assert cadata is not None
    assert paths_checked is not None


# Generated at 2022-06-11 06:38:15.677184
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # Not an exhaustive unit test.
    https_handler = CustomHTTPSHandler()

#
# Authentication
#


# Generated at 2022-06-11 06:38:24.372424
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler('domain.com', 123)

    valid_codes = [200]
    # Good response
    response = b'HTTP/1.1 200 OK\r\n'
    handler.validate_proxy_response(response, valid_codes)

    # Bad response (non-2xx code)
    response = b'HTTP/1.1 302 Bad\r\n'
    with pytest.raises(Exception):
        handler.validate_proxy_response(response, valid_codes)

    # Bad response (invalid code)
    response = b'HTTP/1.1 200 Bad\r\n'
    with pytest.raises(Exception):
        handler.validate_proxy_response(response, valid_codes)