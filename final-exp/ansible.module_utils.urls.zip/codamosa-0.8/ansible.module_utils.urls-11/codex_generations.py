

# Generated at 2022-06-11 06:32:05.941167
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    ssl_validation_handler = SSLValidationHandler('127.0.0.1', '443', ca_path='/non/existing/cert')
    with pytest.raises(SSLCertVerificationError):
        ssl_validation_handler.make_context(cafile ='/non/existing/cert', cadata=None)


# Generated at 2022-06-11 06:32:07.917582
# Unit test for method open of class Request
def test_Request_open():
    request = Request()
    assert True != False


# Generated at 2022-06-11 06:32:13.483149
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    if not os.path.exists("/tmp/myfile.txt"):
        open("/tmp/myfile.txt", 'a').close()
    assert True == os.path.exists("/tmp/myfile.txt")
    atexit_remove_file("/tmp/myfile.txt")
    assert True != os.path.exists("/tmp/myfile.txt")



# Generated at 2022-06-11 06:32:22.867606
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        },
        'text_form_field': 'value'
    }
    # If the function works correctly, we should not get an exception
    prepare_multipart(fields)
    # This one should fail
    try:
        prepare_multipart(('file1', 'file2'))
    except TypeError:
        pass



# Generated at 2022-06-11 06:32:33.975180
# Unit test for function prepare_multipart
def test_prepare_multipart():
    import random
    from collections import OrderedDict
    from io import BytesIO
    import base64
    import hashlib

    if PY3:
        from email.policy import HTTP
    else:
        from email import Generator, message_from_bytes as message_from_string
        from email.utils import fix_eols as eols_to_crlf
    import email.message
    import email.parser
    import email.mime.multipart
    import email.mime.nonmultipart

    RANDOM_DATA = b''.join(
        [
            bytes([random.randrange(0, 255), ])
            for _ in range(1000000)
        ]
    )

    hash_sha1 = hashlib.sha1(RANDOM_DATA).hexdigest()
    hash_sha256 = hashlib.sha

# Generated at 2022-06-11 06:32:41.343906
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    class MockOpen(object):
        def __init__(self):
            self.contents = None

        def __call__(self, file_path, mode):
            return self

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            pass

        def read(self):
            return self.contents

    # Test with existing CA path
    mock_open = MockOpen()
    mock_open.contents = b_DUMMY_CERT
    with patch('ansible.module_utils.urls.open', mock_open):
        ca_path = '/tmp/mock-ca.pem'
        ssl_handler = SSLValidationHandler('hostname', 'port', ca_path)
        ca_certs = ssl_handler.get_ca_

# Generated at 2022-06-11 06:32:48.115608
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if not CustomHTTPSConnection:
        return
    conn = CustomHTTPSConnection('www.example.com')
    assert conn.host == 'www.example.com'
    assert conn.port == httplib.HTTPS_PORT


# Note: py2.6 uses the same impl for UnixSocketHandler and UnixHTTPHandler
# Note: py2.6 impl doesn't call do_open but modern impls do

# Generated at 2022-06-11 06:33:00.698240
# Unit test for function fetch_url
def test_fetch_url():
    # Set up parameters to make the fetch_url function work
    module = Mock(params={'url_username': 'usr',
                          'url_password': 'pass',
                          'validate_certs': False,
                          'use_proxy': True,
                          'http_agent': 'soo',
                          'force_basic_auth': True,
                          'client_cert': 'cert',
                          'client_key': 'key'},
                  fail_json=lambda *args, **kwargs: None)

    class ResponseObj(object):

        def __init__(self):
            self.read = lambda *args, **kwargs: b'This is text'


# Generated at 2022-06-11 06:33:08.887621
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.http_client import HTTPSConnection

    if PY3:
        assert CustomHTTPSConnection is None
    elif HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT or HAS_URLLIB3_SSL_WRAP_SOCKET:
        assert CustomHTTPSConnection is not None
        assert CustomHTTPSConnection is not HTTPSConnection
    else:
        assert CustomHTTPSConnection is None


if CustomHTTPSConnection:
    class CustomHTTPSConnectionPool(urllib3.HTTPSConnectionPool):
        '''
        Extends urllib3.HTTPSConnectionPool.
        '''
        ConnectionCls = CustomHTTPSConnection


# Generated at 2022-06-11 06:33:20.386673
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-11 06:35:24.761849
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    Validate that the RedirectHandlerFactory function works
    '''
    # This is a simple unit test to validate the functionality of
    # RedirectHandlerFactory.  The tests around this functionality are
    # actually in the test suite for urllib3, specifically in
    # test_urllib3/test_util/test_request.py to avoid having
    # RedirectHandlerFactory as a global in this module.

    redirect_handler = RedirectHandlerFactory(follow_redirects=False)
    assert isinstance(redirect_handler, RedirectHandlerFactory.RedirectHandler)
    assert redirect_handler.redirect_request

    redirect_handler = RedirectHandlerFactory(follow_redirects=True)
    assert isinstance(redirect_handler, RedirectHandlerFactory.RedirectHandler)
    assert redirect_handler.redirect_

# Generated at 2022-06-11 06:35:35.954679
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    import os

    # No no_proxy environment variable set
    os.environ['no_proxy'] = ''
    ssl_context = SSLValidationHandler('localhost', 443)
    url = 'http://localhost:80/foo/bar'
    assert ssl_context.detect_no_proxy(url)

    # Full server name matches something in the no_proxy environment variable
    os.environ['no_proxy'] = 'localhost'
    ssl_context = SSLValidationHandler('localhost', 443)
    url = 'https://localhost:443/foo/bar'
    assert ssl_context.detect_no_proxy(url) is False

    # Full IP address matches something in the no_proxy environment variable
    os.environ['no_proxy'] = '127.0.0.1'
    ssl_context = SSLVal

# Generated at 2022-06-11 06:35:42.012414
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    Attempt to test the RedirectHandlerFactory function
    '''
    url_validate = "https://www.google.com"
    handler = RedirectHandlerFactory(follow_redirects=True)()
    req = handler.redirect_request(None, None, 301, None, None, url_validate)
    assert isinstance(req, urllib_request.Request)
    del handler

# Unit tests for function fetch_url

# Generated at 2022-06-11 06:35:48.465563
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    try:
        os.unlink('tmp_atexit_test')
    except Exception:
        pass
    with open('tmp_atexit_test', 'w') as fp:
        fp.write("test")
    assert os.path.exists('tmp_atexit_test')
    atexit_remove_file('tmp_atexit_test')
    assert not os.path.exists('tmp_atexit_test')



# Generated at 2022-06-11 06:35:52.007022
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://127.0.0.1:443'
    validate_certs = True
    _ssl_handler = maybe_add_ssl_handler(url, validate_certs)
    assert _ssl_handler.hostname == '127.0.0.1' and _ssl_handler.port == 443
    assert isinstance(_ssl_handler, SSLValidationHandler)


# Generated at 2022-06-11 06:35:58.406319
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    e = 'f2d1b8fd23d38edfb39a35f0d3f8d6c55a0e2778'
    with open(os.path.join(os.path.dirname(__file__), 'sample_cert.pem'), 'rb') as cert_file:
        ans = get_channel_binding_cert_hash(cert_file.read())
    assert e == binascii.hexlify(ans).decode('utf-8')


# Generated at 2022-06-11 06:36:04.756993
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    paths = ['path1', 'path2']
    exc = Exception('urllib2.URLError: <urlopen error [Errno -2] Name or service not known>')
    hostname = 'http://localhost:9200'
    port = 9200
    try:
        build_ssl_validation_error(hostname, port, paths, exc)
    except SSLValidationError:
        pass
    else:
        raise AssertionError("Should be raise a server_cert_validation error")



# Generated at 2022-06-11 06:36:14.813100
# Unit test for function build_ssl_validation_error

# Generated at 2022-06-11 06:36:18.140228
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    mock_opener = Mock()
    mock_opener.add_handler = Mock()
    urllib_request._opener = mock_opener
    RedirectHandlerFactory('all')
    assert mock_opener.add_handler.called is False

# Generated at 2022-06-11 06:36:23.725700
# Unit test for function fetch_file
def test_fetch_file():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule({})
    url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/network/cloudengine/ce_command.py'
    temp_file = fetch_file(m, url)
    assert os.path.exists(temp_file)
    os.remove(temp_file)
