

# Generated at 2022-06-11 06:31:48.308641
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    try:
        result = maybe_add_ssl_handler('https://url', True)
        assert 'SSLValidationHandler' in str(result)
    except NoSSLError as e:
        assert str(e) == 'SSL validation is not available in your version of python. You can use validate_certs=False,' \
                         ' however this is unsafe and not recommended'



# Generated at 2022-06-11 06:31:55.364210
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Testing a non-https scheme
    url = 'http://google.com'
    validate_certs = True
    ca_path = None
    ssl_handler = maybe_add_ssl_handler(url, validate_certs, ca_path=ca_path)
    assert ssl_handler is None, "This should be None when not using https scheme"

    # Testing with a valid ca-cert path
    url = 'https://google.com'
    validate_certs = True
    ca_path = '/etc/ssl/certs/ca-certificates.crt'
    ssl_handler = maybe_add_ssl_handler(url, validate_certs, ca_path=ca_path)
    assert isinstance(ssl_handler, (SSLValidationHandler, object)), "This should not be None"

    # Testing with an

# Generated at 2022-06-11 06:32:04.519245
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = urlparse('https://foo:bar@example.com')
    generic_parts = generic_urlparse(parts)
    assert generic_parts['scheme'] == 'https'
    assert generic_parts['username'] == 'foo'
    assert generic_parts['password'] == 'bar'
    assert generic_parts['hostname'] == 'example.com'
    assert generic_parts['port'] is None
    assert generic_parts['path'] == ''
    assert generic_parts['params'] == ''
    assert generic_parts['query'] == ''
    assert generic_parts['fragment'] == ''
    assert generic_parts['as_list']() == ['https', 'example.com', '', '', '', '']
    # test with trailing slash on netloc
    parts = urlparse('https://foo:bar@example.com/')

# Generated at 2022-06-11 06:32:10.700200
# Unit test for method get_ca_certs of class SSLValidationHandler

# Generated at 2022-06-11 06:32:19.062463
# Unit test for function open_url
def test_open_url():
    url = "https://httpstat.us/200"
    # When method is not specified, it should be default to 'GET'
    response = open_url(url)
    assert response.code == 200
    # When data is specified, method should be 'POST'
    response = open_url(url, data="dummy")
    assert response.code == 200
    # When method is specified, the value should be honored
    response = open_url(url, method='GET')
    assert response.code == 200
    response = open_url(url, method='POST')
    assert response.code == 200
    # Use GSSAPI authentication
    response = open_url(url, use_gssapi=True)
    assert response.code == 200


# Generated at 2022-06-11 06:32:24.770453
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule('fetch_url',
                           dict(url='http://www.example.com/test1.txt',
                                dest='/tmp/test1.txt',
                                timeout=10),
                           ignore_provider_argspec=True)
    r, info = fetch_url(module,
                        'http://www.example.com/test1.txt',
                        None,
                        None,
                        None,
                        True,
                        False,
                        None,
                        10)
    assert info['status'] == 200

# Generated at 2022-06-11 06:32:32.473911
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    try:
        build_ssl_validation_error('hostname', 'port', ['path1'])
    except SSLValidationError as e:
        assert to_native(e) == 'Failed to validate the SSL certificate for hostname:port.' \
                        ' Make sure your managed systems have a valid CA certificate installed.' \
                        ' You can use validate_certs=False if you do not need to confirm the servers identity but this is unsafe and not recommended.' \
                        ' Paths checked for this platform: path1.'



# Generated at 2022-06-11 06:32:41.875698
# Unit test for function generic_urlparse
def test_generic_urlparse():
    class ParseResult(object):
        def __init__(self, scheme, netloc, path, params, query, fragment, username=None, password=None, hostname=None, port=None):
            self.scheme = scheme
            self.netloc = netloc
            self.path = path
            self.params = params
            self.query = query
            self.fragment = fragment
            self.username = username
            self.password = password
            self.hostname = hostname
            self.port = port

    test_parts = ParseResult('scheme', 'netloc', 'path', 'params', 'query', 'fragment', 'username', 'password', 'hostname', 80)
    generic_parts = generic_urlparse(test_parts)
    assert(generic_parts.scheme == 'scheme')
   

# Generated at 2022-06-11 06:32:54.391343
# Unit test for function getpeercert
def test_getpeercert():
    import sys
    # Note: this test is skipped in the unit test suite if the python version is 2.6
    # because we don't currently support aiocoap on 2.6
    # construct response to emulate the python3 version
    if PY3:
        v = sys.version_info
        if v.major == 3 and v.minor >= 5:
            from aiocoap import Message, Context
            ctx = Context()
            r = ctx.request(Message(code=1, uri='coap://example.org/test'))
            try:
                getpeercert(r.response)
                assert True
            except Exception:
                assert False
    else:
        try:
            getpeercert(response)
        except Exception:
            assert True


# Generated at 2022-06-11 06:33:00.448692
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    obj = SSLValidationHandler("abc.com")
    result = obj.get_ca_certs()

    obj = SSLValidationHandler("abc.com", 443)
    result = obj.get_ca_certs()

    obj = SSLValidationHandler("abc.com", 443, "ca_path")
    result = obj.get_ca_certs()



# Generated at 2022-06-11 06:36:28.414174
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert("http://my.test.example.com/") == None


# Generated at 2022-06-11 06:36:38.430320
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler('localhost', 443)
    os.environ['no_proxy'] = 's3.amazonaws.com,s3-us-west-2.amazonaws.com,.rhcloud.com,.rhtapps.io'
    assert handler.detect_no_proxy('http://s3.amazonaws.com:443/') is False
    assert handler.detect_no_proxy('http://s3-us-west-2.amazonaws.com:443/') is False
    assert handler.detect_no_proxy('https://s3-us-west-2.amazonaws.com:443/') is False
    assert handler.detect_no_proxy('http://login.rhcloud.com:443/') is False

# Generated at 2022-06-11 06:36:42.711051
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    try:
        from urllib2 import build_opener, HTTPSHandler
    except ImportError:
        from urllib.request import build_opener, HTTPSHandler

    handler = SSLValidationHandler('www.google.com', 443)
    opener = build_opener(handler)
    opener.open('https://www.google.com')

# Generated at 2022-06-11 06:36:51.596881
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    '''
    unit test for method "__call__" of class "UnixHTTPSConnection"
    '''
    uc = UnixHTTPSConnection('/tmp/test_UnixHTTPSConnection___call__')
    uc('localhost')
    assert uc.sock
    assert uc.sock.family == socket.AF_UNIX
    assert uc.sock.type == socket.SOCK_STREAM
    assert uc.sock.proto == socket.getprotobyname('tcp')

    # make sure the patch management didn't go wrong,
    # and we created the socket via the unix version
    assert uc.sock.fileno() == 999

    try:
        # this should not raise
        uc.connect()
    except Exception:
        assert False, 'connect should not have raised exceptions'


# Generated at 2022-06-11 06:36:55.445198
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    url_handler = SSLValidationHandler('www.example.com', 443)
    tmp_ca_cert_path, cadata, paths_checked = url_handler.get_ca_certs()
    assert len(tmp_ca_cert_path) > 10
    assert len(cadata) > 10


# Generated at 2022-06-11 06:37:04.669362
# Unit test for function getpeercert
def test_getpeercert():
    from sys import version_info
    if version_info[:2] != (2, 7):
        raise SkipTest("test only valid with python 2.7")
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.pycompat24 import get_exception
    response = open_url('https://www.redhat.com')
    if not response:
        raise AssertionError('Unable to open https://www.redhat.com')
    try:
        cert = getpeercert(response)
    except BaseException as e:
        raise AssertionError("Unable to get peer cert: %s" % get_exception())

# Generated at 2022-06-11 06:37:11.512009
# Unit test for method post of class Request
def test_Request_post():
    url = 'http://localhost:8081/'
    values = {'username': 'admin', 'password': 'admin'}
    data = urllib_parse.urlencode(values).encode('utf8')
    req = urllib_request.Request(url, data)
    response = urllib_request.urlopen(req)
    the_page = response.read()
    print(the_page)
    response.close()


# Generated at 2022-06-11 06:37:21.141109
# Unit test for function generic_urlparse
def test_generic_urlparse():
    # Test the ParseResultDottedDict class
    # pylint: disable=invalid-name
    # pylint: disable=no-member
    result = ParseResultDottedDict((('scheme', 'http'), ('netloc', 'localhost'), ('path', '/'), ('params', ''), ('query', 'a=b'), ('fragment', '')))
    assert result['scheme'] == 'http'
    assert result.scheme == 'http'
    assert result['netloc'] == 'localhost'
    assert result.netloc == 'localhost'
    assert result.as_list() == ['http', 'localhost', '/', '', 'a=b', '']
    # Test the generic_urlparse function
    if hasattr(urllib_parse, 'urlsplit'):
        # Py >= 2.6
        url

# Generated at 2022-06-11 06:37:26.497687
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_socket = '/tmp/test_gssapi_socket'
    # Create a socket
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.bind(unix_socket)
        s.listen(1)
        try:
            # Try to connect to it
            UnixHTTPConnection(unix_socket).connect()
        except OSError:
            # If it failed to connect raise an error
            raise
        finally:
            # Make sure that the socket gets removed
            s.close()
            os.remove(unix_socket)



# Generated at 2022-06-11 06:37:33.572836
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    handler = SSLValidationHandler('test_hostname', 1234)
    context = handler.make_context(None, None)
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is True
    assert context.options == 0
    assert context.protocol == PROTOCOL
