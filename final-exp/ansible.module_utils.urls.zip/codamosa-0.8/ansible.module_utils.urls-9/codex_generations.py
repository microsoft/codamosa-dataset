

# Generated at 2022-06-11 06:32:52.799147
# Unit test for function prepare_multipart
def test_prepare_multipart():
    """
    Unit tests for function prepare_multipart
    """
    fields = {}
    fields['file1'] = "test content"
    fields['file2'] = {'filename':"test2.txt", 'content':"test content"}
    fields['file3'] = {'filename':"/bin/true", 'mime_type':"application/octet-stream"}

    expected_headers = ('Content-Type', 'multipart/form-data; boundary================11067903451898138413==')

# Generated at 2022-06-11 06:33:02.320772
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    handler = SSLValidationHandler('numbers', 443)
    request = urllib_request.Request('https://numbers.com')
    request.add_header('User-Agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8')
    request = handler.http_request(request)
    assert 'User-Agent' in request.header_items()
    assert request.get_full_url() == 'https://numbers.com'


# Generated at 2022-06-11 06:33:04.464918
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    '''Unit test for method connect of class UnixHTTPConnection
    '''
    my_socket = '/invalid/socket'
    with pytest.raises(OSError):
        UnixHTTPConnection(my_socket).connect()
    my_socket = '/tmp/unix.sock'
    UnixHTTPConnection(my_socket).connect()



# Generated at 2022-06-11 06:33:08.758683
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    ssl_handler = SSLValidationHandler('example.com', 443)
    my_url = 'https://example.com:443'

    def mock_env(var_name, val):
        def mock_env_inner(func):
            @wraps(func)
            def wrapper():
                orig_val = None
                try:
                    orig_val = os.environ[var_name]
                except KeyError:
                    pass
                os.environ[var_name] = val
                try:
                    ret = func()
                finally:
                    if orig_val is None:
                        del os.environ[var_name]
                    else:
                        os.environ[var_name] = orig_val
                return ret
            return wrapper
        return mock_env_inner


# Generated at 2022-06-11 06:33:09.207409
# Unit test for method open of class Request
def test_Request_open():
    pass



# Generated at 2022-06-11 06:33:13.027908
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    handler = SSLValidationHandler(
        'example.com', 443,
    )

# Generated at 2022-06-11 06:33:21.721868
# Unit test for function fetch_file
def test_fetch_file():
    import socket
    import tempfile
    from ansible.module_utils import basic

    class MockUrlLibModule(object):
        def urlopen(self, url):
            if url.geturl() == 'http://example.com':
                if url.get_full_url() == 'http://example.com':
                    return BytesIO(b'example content')
                else:
                    raise ValueError('unknown url: %s' % url.get_full_url())

    class MockModule(object):
        def __init__(self):
            self.params = dict(url='http://example.com')
            self.tmpdir = tempfile.mkdtemp()

        def fail_json(self, msg, **kwargs):
            raise Exception(msg % kwargs)


# Generated at 2022-06-11 06:33:25.651150
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    with pytest.raises(OSError) as e:
        UnixHTTPConnection("/tmp/sockt").connect()

    assert str(e.value) == "Invalid Socket File (/tmp/sockt): [Errno 2] No such file or directory"



# Generated at 2022-06-11 06:33:30.017049
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if hasattr(httplib, 'HTTPSConnection'):
        # Test with no arguments
        c = CustomHTTPSConnection()
        if not hasattr(c, 'context'):
            assert False, "Needs context attribute to be set"
        if not hasattr(c, 'cert_file'):
            assert False, "Needs cert_file attribute to be set"
        if not hasattr(c, 'key_file'):
            assert False, "Needs key_file attribute to be set"

        # Test with some arguments
        c = CustomHTTPSConnection("localhost", port=8000)
        if not hasattr(c, 'context'):
            assert False, "Needs context attribute to be set"

# Generated at 2022-06-11 06:33:34.326331
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    https_connection = CustomHTTPSConnection('example.com', port=443)


# Make sure we don't try to wrap an already wrapped socket.
if hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            if hasattr(self, '_context'):
                context = self._context
            else:
                context = None
            return self.do_open(self.getConnection, req, context=context)

        def getConnection(self, host, timeout=300):
            if HAS_SSLCONTEXT:
                context = ssl._create_unverified_context()

# Generated at 2022-06-11 06:34:52.240656
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import urllib3

    class _CustomHTTPSConnection(CustomHTTPSConnection, object):
        def _context(self):
            import urllib3.contrib.pyopenssl as pyopenssl
            return pyopenssl.PyOpenSSLContext(PROTOCOL)

    conn = _CustomHTTPSConnection('localhost', 80)
    conn.connect()
    assert isinstance(conn.sock, urllib3.contrib.pyopenssl.PyOpenSSLConnection)

    conn = _CustomHTTPSConnection('localhost', 80)
    import urllib3.contrib.pyopenssl as pyopenssl
    conn.context = pyopenssl.PyOpenSSLContext(PROTOCOL)
    conn.connect()
    assert isinstance(conn.sock, urllib3.contrib.pyopenssl.PyOpenSSLConnection)

# Generated at 2022-06-11 06:34:56.492233
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Load the module and test function
    from ansible.module_utils.urls import RedirectHandlerFactory
    test_dict = {
        'scheme': 'http',
        'netloc': '0.0.0.0:8080',
        'url': 'http://0.0.0.0:8080/',
        'path': '/',
        'hostname': '0.0.0.0',
        'port': 8080,
        'username': None,
        'password': None,
        'params': '',
        'query': '',
        'fragment': '',
    }
    test_url = 'http://0.0.0.0:8080/'
    # Test each case with different values for follow_redirects

# Generated at 2022-06-11 06:35:06.883971
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from nose.tools import assert_raises, assert_true
    from ansible.playbook.play_context import PlayContext

    class MyHandler(SSLValidationHandler):
        def validate_proxy_response(self, response, valid_codes=None):
            # We can't test this as it depends on the state of the local computer
            pass

        def detect_no_proxy(self, url):
            # We need to mock this out as we don't have a good way of testing that
            return True

        def make_context(self, cafile, cadata):
            # We can't test this as it depends on the state of the local computer
            pass

        def get_ca_certs(self):
            # We can't test this as it depends on the state of the local computer
            pass

    play_context = PlayContext()
    play_

# Generated at 2022-06-11 06:35:17.123138
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return

    # Use the test file etc/ssl/certs/alt_alt_alt.pem
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'etc', 'ssl', 'certs', 'alt_alt_alt.pem'), 'rb') as cert_file:
        cert_b = cert_file.read()
    cert_der = ssl.PEM_cert_to_DER_cert(cert_b)
    assert len(cert_der) == 1546  # Should be the same as the file length
    # Tests for the channel binding hash

# Generated at 2022-06-11 06:35:27.611293
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-11 06:35:37.123002
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    class FakeResponse:
        def __init__(self, code, msg=None):
            self.code = code
            self.msg = msg

        def info(self):
            return self.msg

    h = SSLValidationHandler(None, None)
    h.validate_proxy_response(b'HTTP/1.0 200 OK')
    # test for expected exception
    with pytest.raises(ProxyError):
        h.validate_proxy_response(b'HTTP/1.0 404 Not Found')
    # test for actual exception
    with pytest.raises(ProxyError):
        h.validate_proxy_response(FakeResponse(404))

# Generated at 2022-06-11 06:35:43.660281
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Ensure ``UnixHTTPSConnection.connect`` uses the correct logic to create self.sock
    '''
    unix_socket = '/path/to/unix/socket'
    conn = UnixHTTPSConnection(unix_socket)
    # pylint: disable=protected-access
    conn._unix_socket = unix_socket
    with unix_socket_patch_httpconnection_connect():
        conn.connect()
    assert conn.sock.family == socket.AF_UNIX

# Generated at 2022-06-11 06:35:52.312801
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = generic_urlparse(ParseResultDottedDict(scheme='scheme', netloc='netloc', path='path', params='params', query='query', fragment='fragment', username='username', password='password', hostname='hostname', port='port'))
    if parts != {'scheme': 'scheme', 'netloc': 'netloc', 'path': 'path', 'params': 'params', 'query': 'query', 'fragment': 'fragment', 'username': 'username', 'password': 'password', 'hostname': 'hostname', 'port': 'port'}:
        raise AssertionError("Failed to handle new style version of urlparse.")


# Generated at 2022-06-11 06:36:01.986116
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    """Unit test for function ``RedirectHandlerFactory``"""
    from .urls import _test_urllib2_and_httplib2

    class CustomException(Exception):
        pass

    def urllib2_redirect_handler_exception_test(url):
        try:
            return urllib_request.urlopen(url)
        except urllib_error.HTTPError as e:
            if e.code == 301:
                # urllib2 always throws exceptions for 301,
                # so if we get one here, everything is good.
                return e.read()
            else:
                # If we get any other error, fail
                raise CustomException(e.code)

    def urllib2_redirect_handler_test(url):
        # Test with urllib2's default redirect handler
        return ur

# Generated at 2022-06-11 06:36:07.367715
# Unit test for function fetch_file
def test_fetch_file():
    url = 'https://media.giphy.com/media/5xaOcLH5kzq3y/giphy.gif'
    rsp, info = fetch_url(None, url)

    filename = fetch_file(None, url)
    rsp, info = fetch_url(None, filename)
    assert info['status'] == 200


# Generated at 2022-06-11 06:37:05.702865
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url_list = {
    "https://www.example.com/resource/blah.html",
    "https://example.com/resource/blah.html"
    }
    d_param = {
    "no_proxy": "example.com",
    "no_proxy": "www.example.com"
    }
    for url in url_list:
        for key,value in d_param.items():
            os.environ[key] = value
            handler = SSLValidationHandler("www.example.com", 443)
            assert not handler.detect_no_proxy(url)
            del os.environ[key]


# Use urllib3's ssl wrap class if it's available. It's faster.
# And fall back to older, slower way if not.

# Generated at 2022-06-11 06:37:17.027890
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    sock = UnixHTTPConnection('/tmp/sock')
    # This test is for coverage only, we cannot test the socket.socket
    # calls due to the limited nature of mocks.
    if PY2:
        mock = Mock()
        mock.connect.side_effect = OSError
        with patch('socket.socket', return_value=mock) as mock_socket:
            try:
                sock.connect()
            except OSError:
                pass
            mock_socket.assert_called_once_with(socket.AF_UNIX, socket.SOCK_STREAM)
            mock.connect.assert_called_once_with('/tmp/sock')
    else:
        try:
            sock.connect()
        except OSError:
            pass

#
# Utility functions
#


# Generated at 2022-06-11 06:37:24.459143
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    import collections
    import os.path

    test_cases = collections.defaultdict(dict)
    test_cases[1] = {"ca_path": os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_certs/test.crt"), "result": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_certs/test.crt"), None, [])}
    test_cases[2] = {"ca_path": None, "result": (None, b'', [])}

    for test_id, test_case in test_cases.items():
        sslHandler = SSLValidationHandler("google.com", 443, test_case["ca_path"])
        ca_cert_path, cadata,

# Generated at 2022-06-11 06:37:25.359755
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    assert atexit_remove_file



# Generated at 2022-06-11 06:37:29.925887
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    urllib2_test()
    # Unit test for method http_request of class SSLValidationHandler
    class OurSSLValidationHandler(SSLValidationHandler):
        def http_request(self, req):
            return req
            raise Exception('This code should never be reached')
    # Make sure that it runs without raising an exception
    OurSSLValidationHandler('127.0.0.1', 443).http_request(urllib_request.Request('http://127.0.0.1'))




# Generated at 2022-06-11 06:37:31.905382
# Unit test for function fetch_url
def test_fetch_url():
    assert fetch_url(module, 'http://google.com') == response, info


# Generated at 2022-06-11 06:37:35.972025
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    tests = (
        (
            datetime.datetime(2001, 11, 9, 1, 8, 47),
            'Fri, 09 Nov 2001 01:08:47 -0000',
            'RFC 2822 date string is correct'
        ),
        (
            datetime.datetime(1971, 2, 3, 4, 5, 6),
            'Wed, 03 Feb 1971 04:05:06 -0000',
            'RFC 2822 date string is correct'
        ),
    )

    for dt, expected, test in tests:
        actual = rfc2822_date_string(dt.timetuple())
        assert expected == actual, test



# Generated at 2022-06-11 06:37:43.148630
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    rq_1 = RequestWithMethod('test_url', 'get')
    assert rq_1.get_method() == urllib_request.Request.get_method(rq_1)
    rq_2 = RequestWithMethod('test_url', 'post')
    assert rq_2.get_method() == rq_2._method
    rq_3 = RequestWithMethod('test_url', 'put')
    assert rq_3.get_method() == rq_3._method
    rq_4 = RequestWithMethod('test_url', 'delete')
    assert rq_4.get_method() == rq_4._method



# Generated at 2022-06-11 06:37:45.510386
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils.urls import fetch_file
    compute_url = "https://apidev.scaleway.com"
    token = "2f337b9d967b23c5b5e4f4d4d4bb8c88"
    method = "GET"
    headers = {"X-Auth-Token":token}
    fetch_file(method,compute_url,headers)

# Generated at 2022-06-11 06:37:56.295231
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    timetuple = time.gmtime()
    date_string = rfc2822_date_string(timetuple)
    year = timetuple[0]
    month = timetuple[1]
    day = timetuple[2]
    hour = timetuple[3]
    minute = timetuple[4]
    second = timetuple[5]
    day_of_the_week = timetuple[6]