

# Generated at 2022-06-11 06:34:29.125250
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    """Test the RedirectHandlerFactory"""
    from . import urllib_request
    from . import urllib_error

    # Check redirects (follow_redirects = False)

# Generated at 2022-06-11 06:34:32.321030
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert not hasattr(httplib.HTTPSConnection, 'context')
    assert hasattr(CustomHTTPSConnection, 'context')



# Generated at 2022-06-11 06:34:34.099167
# Unit test for function getpeercert
def test_getpeercert():
    expected = 'www.google.com'
    response = urllib_request.urlopen('https://' + expected)
    result = getpeercert(response, False)
    assert result['subject'][5][0][1] == expected


# Generated at 2022-06-11 06:34:44.098054
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    import mock
    from ansible.module_utils.urls import SSLValidationHandler
    ssl = SSLValidationHandler('https://www.example.com', 443)
    with mock.patch.dict('os.environ', {'no_proxy': 'example.com,www.example.com,www.example2.com'}):
        assert ssl.detect_no_proxy('https://www.example.com') == False
        assert ssl.detect_no_proxy('https://www.example2.com') == False
        assert ssl.detect_no_proxy('https://www.example.com:8080') == False
        assert ssl.detect_no_proxy('https://www.example2.com:8080') == False

# Generated at 2022-06-11 06:34:53.803747
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Test that ssl handler is added when cert is set to true.
    config = dict()
    config['validate_certs'] = True
    handlers = list()
    handlers.extend(maybe_add_ssl_handler('https://www.example.com', config['validate_certs']))
    actual = len(handlers)
    expected = 1
    assert actual == expected
    # Test that ssl handler is not added when cert is set to false.
    config['validate_certs'] = False
    handlers = list()
    handlers.extend(maybe_add_ssl_handler('https://www.example.com', config['validate_certs']))
    actual = len(handlers)
    expected = 0
    assert actual == expected


# Generated at 2022-06-11 06:34:57.877324
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Instantiate class for test
    class_instance = SSLValidationHandler('www.google.com',443)
    # Initialize the valid_codes parameter
    valid_codes = [200]
    # Initialize the response parameter
    response = ''
    # Call method with parameters to be tested
    class_instance.validate_proxy_response(response,valid_codes)



# Generated at 2022-06-11 06:35:01.693451
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    import urllib.request

    class testRedirectHandlerFactory(unittest.TestCase):
        def test_handler(self):
            handler = RedirectHandlerFactory()
            self.assertEqual(handler(None, None, None, None, None).__class__, urllib.request.Request)

    # Run unit test
    unittest.main(module=None, verbosity=2, buffer=True)
    return



# Generated at 2022-06-11 06:35:04.881035
# Unit test for constructor of class Request
def test_Request():
    test_obj1 = Request('GET', 'url', data='data')
    assert test_obj1.method == 'GET'
    assert test_obj1.url == 'url'


# Generated at 2022-06-11 06:35:15.999940
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Check for redirects being handled properly
    handler = RedirectHandlerFactory(True)
    assert handler.redirect_request(None, None, 303, '', None, 'http://127.0.0.1/foo')

    # Check for non-redirects handling properly
    handler = RedirectHandlerFactory(True)
    try:
        handler.redirect_request(None, None, 404, '', None, 'http://127.0.0.1/foo')
    except urllib_error.HTTPError:
        pass
    else:
        assert False

    # Check for redirects being handled properly
    handler = RedirectHandlerFactory('safe')
    assert handler.redirect_request(None, None, 303, '', None, 'http://127.0.0.1/foo')

    # Check for non-redirects

# Generated at 2022-06-11 06:35:26.558768
# Unit test for function fetch_url

# Generated at 2022-06-11 06:36:42.597255
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    this_dir = os.path.dirname(os.path.realpath(__file__))
    ca_path = os.path.join(this_dir, "test_certs/my_root_ca.pem")
    context = SSLValidationHandler("example.com", 443, ca_path)
    cafile, cadata, paths_checked = context.get_ca_certs()
    assert cafile == ca_path
    assert cadata is None
    assert paths_checked == [ca_path]

    # make sure a non-existant CA path fails correctly
    context = SSLValidationHandler("example.com", 443, "/bogus/ca_path")
    cafile, cadata, paths_checked = context.get_ca_certs()
    assert cafile != ca_path
    assert cadata is not None


# Generated at 2022-06-11 06:36:51.465359
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler(None, None)
    assert handler.validate_proxy_response(b"HTTP/1.0 200 ok")
    assert handler.validate_proxy_response(b"HTTP/1.0 302 Found")
    assert handler.validate_proxy_response(b"HTTP/1.1 302 Found")
    assert handler.validate_proxy_response(b"HTTP/2.2 302 Found")
    assert handler.validate_proxy_response(b"HTTP/1.0 302 Found", [302])
    assert handler.validate_proxy_response(b"HTTP/1.0 302 Found", [200, 302])
    assert handler.validate_proxy_response(b"HTTP/1.0 302 Found", [302, 200])

# Generated at 2022-06-11 06:36:54.854862
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    with pytest.raises(SSLValidationError):
        SSLValidationHandler('github.com', 443).http_request(urllib_request.Request(
            'https://github.com:443', headers={'User-Agent': 'custom_useragent'}))


# Generated at 2022-06-11 06:37:04.213744
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    class RedirectHandlerMock(RedirectHandlerFactory(follow_redirects='all')):
        def redirect_request(self, req, fp, code, msg, hdrs, newurl):
            self.code = code
            self.msg = msg
            self.hdrs = hdrs
            self.newurl = newurl
            self.req = req

        def http_error_302(self, req, fp, code, msg, hdrs):
            self.code = code
            self.msg = msg
            self.hdrs = hdrs
            self.req = req


# Generated at 2022-06-11 06:37:07.982435
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod('https://github.com/ansible/ansible', 'GET')
    assert request.get_method() == 'GET'
    request._method = 'POST'
    assert request.get_method() == 'POST'
    request._method = 'HEAD'
    assert request.get_method() == 'HEAD'
    request._method = 'PUT'
    assert request.get_method() == 'PUT'
    request._method = 'DELETE'
    assert request.get_method() == 'DELETE'


# Generated at 2022-06-11 06:37:18.178746
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    '''
    Unit test for method connect of class CustomHTTPSConnection.
    '''
    # create a temporary directory for this test
    temp_dir = tempfile.mkdtemp()
    # populate the temporary directory with test data
    cert_file = os.path.join(temp_dir, 'certfile')
    with open(cert_file, 'w') as fh:
        fh.write('certificate')
    key_file = os.path.join(temp_dir, 'keyfile')
    with open(key_file, 'w') as fh:
        fh.write('key')
    # run the test

# Generated at 2022-06-11 06:37:25.579337
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    def assert_in(needle, haystack):
        if needle not in haystack:
            raise AssertionError('%s not in %s' % (needle, haystack))

    if HAS_SSLCONTEXT:
        url = 'https://nossl.com'
        exc = 'error_msg'
        with pytest.raises(SSLValidationError) as exc_info:
            build_ssl_validation_error('nossl.com', 443, ['/etc', '/usr/local'], exc)

        assert_in('Failed to validate the SSL certificate for nossl.com:443.', str(exc_info.value))
        assert_in('You can use validate_certs=False if you do not need to confirm the servers identity', str(exc_info.value))

# Generated at 2022-06-11 06:37:28.788985
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    if not CustomHTTPSConnection:
        pytest.skip("unittest skipped because ssl is missing")
    with pytest.raises(ConnectionError) as e:
        conn = UnixHTTPSConnection('/tmp/im-unix-socket')
        conn.connect()
    assert "Tried to connect to /tmp/im-unix-socket but the connection failed." in str(e)
# end



# Generated at 2022-06-11 06:37:38.784899
# Unit test for function fetch_url
def test_fetch_url():
    import http.server
    import threading
    import ssl

    def server_handler(s, p):
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain')
                self.end_headers()
                self.wfile.write(b'Test body')

        httpd = http.server.HTTPServer(('127.0.0.1', 0), Handler)
        httpd.socket = s
        httpd.handle_request()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(50)

    ctx = ssl.create

# Generated at 2022-06-11 06:37:49.905963
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Import needed modules
    import urllib_request

    # create an instance
    x = SSLValidationHandler('127.0.0.1', 443, ca_path='/etc/ansible/my_cert.pem')

    # pickup a non existing file
    try:
        f = open('does_not_exist')
    except IOError as e:
        e = e

    # create a request
    r = urllib_request.Request('https://127.0.0.1')

    # invoke method
    try:
        x.http_request(r)
    except SSLValidationError as e:
        e = e

    # verify results
    assert('You can use validate_certs=False if you do not need to confirm the servers identity' in e.args[0])

