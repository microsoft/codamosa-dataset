

# Generated at 2022-06-25 01:52:42.634070
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    t_c_0 = CustomHTTPSConnection('foo')
    # call the method connect
    try:
        t_c_0.connect()
    except:
        # exception type was ssl.SSLError
        pass
    c_h_0 = CustomHTTPSConnection('foo')
    # call the method connect
    try:
        c_h_0.connect()
    except:
        # exception type was ssl.SSLError
        pass
    s_s_l_validation_error_0 = SSLValidationError()
    # call the method connect
    try:
        s_s_l_validation_error_0.connect()
    except:
        # exception type was ssl.SSLError
        pass


# Generated at 2022-06-25 01:52:53.479185
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    rfc2822_date_string_0 = rfc2822_date_string(())
    assert rfc2822_date_string_0 == 'Mon, 01 Jan -0001 00:00:00 -0000'
    rfc2822_date_string_1 = rfc2822_date_string((1882, 9, 4, 14, 20, 58, 2), '-0000')
    assert rfc2822_date_string_1 == 'Thu, 04 Oct 1882 14:20:58 -0000'
    rfc2822_date_string_2 = rfc2822_date_string((2049, 2, 20, 6, 18, 44, 4))
    assert rfc2822_date_string_2 == 'Thu, 20 Mar 2049 06:18:44'
    rfc2822_date_string_3 = r

# Generated at 2022-06-25 01:53:00.551121
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test follow_redirects is one of following values: 'urllib2', 'no', 'none', False, 'all', 'yes', True, 'safe'
    values = ['urllib2', 'no', 'none', False, 'all', 'yes', True, 'safe']
    for value in values:
        handler = RedirectHandlerFactory(follow_redirects=value)
        assert handler is not None, "url.RedirectHandlerFactory(follow_redirects=%s) returned None" % (value,)


# Generated at 2022-06-25 01:53:03.786622
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test case for expected value
    s_s_l_validation_handler_0 = SSLValidationHandler('localhost', 443)
    pass



# Generated at 2022-06-25 01:53:12.224878
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    import builtins
    builtins.t_0 = False
    if (hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler')):
        test_CustomHTTPSConnection_init = ansible.utils.urls.CustomHTTPSConnection("self", "host", "port", self.key_file, self.cert_file)
        builtins.t_0 = True
    assert builtins.t_0 == True


# Generated at 2022-06-25 01:53:23.277687
# Unit test for function generic_urlparse
def test_generic_urlparse():
    urlparse_test_url = 'http://username:password@[::1]:80/path/to?foo=bar&abc=123#baz'

# Generated at 2022-06-25 01:53:27.631329
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Empty input
    test_fields_0 = dict()
    test_body_0, test_content_type_0 = prepare_multipart(test_fields_0)
    print("test_body_0 is " + test_body_0)
    print("test_content_type_0 is " + test_content_type_0)
    class test_content_type_0():
        msg = MIMEBase("multipart", "form-data")
        msg['Content-Type'] = 'multipart/form-data; boundary=---------------------------9361611358908149291833140948'
        msg['MIME-Version'] = '1.0'
        msg['Content-Disposition'] = 'form-data; name="text_form_field"'
        msg.attach(MIMEText('value'))

# Generated at 2022-06-25 01:53:33.021321
# Unit test for method detect_no_proxy of class SSLValidationHandler

# Generated at 2022-06-25 01:53:33.996542
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")


# Generated at 2022-06-25 01:53:40.662802
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    test_url = 'https://www.ansible.com'
    check_url = 'ansible'
    os.environ['no_proxy'] = check_url
    ssl_handler = SSLValidationHandler('www.ansible.com', 443)
    assert ssl_handler.detect_no_proxy(test_url) == False
    os.environ.pop('no_proxy')


# Generated at 2022-06-25 01:56:53.044828
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    url = 'https://www.baidu.com'
    response = urllib_request.urlopen(url)

    # Preserve urllib2 compatibility
    RedirectHandlerFactory('urllib2').redirect_request('', '', '', '', '', url)
    # Handle disabled redirects
    RedirectHandlerFactory('no').redirect_request('', '', '', '', '', url)
    # Handle non-redirect HTTP status or invalid follow_redirects
    RedirectHandlerFactory('all').redirect_request('', '', '', '', '', url)
    RedirectHandlerFactory('safe').redirect_request('', '', '', '', '', url)


# Generated at 2022-06-25 01:57:01.608581
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    hostname = 'hostname'
    port = 'port'
    s_s_l_validation_handler_0 = SSLValidationHandler(hostname, port)

    test_ca_path = '/tmp/ansible_test_ca'

# Generated at 2022-06-25 01:57:07.709378
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    print("Test: http_request")
    tmp_ca_cert_path0, cadata0, paths_checked0 = SSLValidationHandler.get_ca_certs()
    a = 'http://127.0.0.1:8111'
    req = Request(a)
    sh = SSLValidationHandler('127.0.0.1', 8111)
    r = sh.http_request(req)
    print(r)


# Generated at 2022-06-25 01:57:13.184489
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # For tests
    global CustomHTTPSConnection
    global CustomHTTPSHandler
    global test_urllib_urlopen_args

    # Fixup args for python 2.4
    if sys.version_info < (2, 5):
        test_urllib_urlopen_args = (urllib_urlopen, )

    # Execute test
    CustomHTTPSConnection = None
    CustomHTTPSHandler = None
    test_urllib_urlopen_args = (urllib_request.urlopen, )
    # Should be a ssl.SSLError because the end node doesn't match the certificate.
    # This is the case because we're using the self-signed certificates from
    # test/integration/tls
    failed = False
    message = ''

# Generated at 2022-06-25 01:57:17.484933
# Unit test for function prepare_multipart
def test_prepare_multipart():
    test_fields = {
        "text_form_field": "value",
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        }
    }
    test_result = prepare_multipart(test_fields)
    test_content_type = 'multipart/form-data; boundary="===============1501108967=="'
    # Create a temporary file
    with tempfile.NamedTemporaryFile(suffix=".txt") as temp_name:
        temp_name.write('test')
        temp_name.seek(0)

# Generated at 2022-06-25 01:57:22.366727
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    test_prepare_multipart_1 = prepare_multipart(fields=fields)


# Generated at 2022-06-25 01:57:28.358047
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    cert_der = b_DUMMY_CA_CERT
    hash_value = get_channel_binding_cert_hash(cert_der)

    assert isinstance(hash_value, bytes)
    assert hash_value == binascii.unhexlify(b'c7b8e0a0962c9e1e6c58d39fafb6e538a7a4d4c2b7d8a0fb9829eb9f6dcd22f7')


# Generated at 2022-06-25 01:57:30.345649
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://www.baidu.com'
    validate_certs = 0
    ca_path = '/tmp/ca.pem'
    maybe_add_ssl_handler_0 = maybe_add_ssl_handler(url, validate_certs, ca_path)
    assert maybe_add_ssl_handler_0 is None


# Generated at 2022-06-25 01:57:40.360643
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    h = SSLValidationHandler('hostname', 443)
    # Test a location that does not match with no_proxy
    try:
        os.environ['no_proxy'] = 'google.de'
        assert h.detect_no_proxy('https://www.google.com/') == True
    finally:
        del os.environ['no_proxy']

    # Test a location that does match with no_proxy
    try:
        os.environ['no_proxy'] = 'google.com'
        assert h.detect_no_proxy('https://www.google.com/') == False
    finally:
        del os.environ['no_proxy']

    # Test a location with a port that does not match with no_proxy

# Generated at 2022-06-25 01:57:42.726886
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    import time
    from time import gmtime, strftime
    result = rfc2822_date_string(gmtime())
    assert(result == strftime('%a, %d %b %Y %H:%M:%S %z'))
