

# Generated at 2022-06-25 01:53:21.344001
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string((2000, 1, 1, 1, 1, 1))
    assert rfc2822_date_string((2001, 11, 9, 1, 8, 47), zone='-0000')
    assert rfc2822_date_string((2017, 6, 19, 13, 32, 59), zone='+1200')


# Generated at 2022-06-25 01:53:26.674298
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    ssl_validation_handler_0 = SSLValidationHandler('www.python.org', 443)
    proxy_response_0 = b'HTTP/1.1 200 OK\r\n\r\n'
    try:
        ssl_validation_handler_0.validate_proxy_response(proxy_response_0)
        assert True # got here means no exception was raised
    except Exception as e:
        print("Caught exception: %s" % str(e))
        assert False

    proxy_response_1 = b'HTTP/1.1 200 OK\r\n\r\nHTTP/1.1 200 OK\r\n\r\n'

# Generated at 2022-06-25 01:53:29.994914
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    custom_https_connection_0 = CustomHTTPSConnection()
    try:
        if hasattr(self, 'source_address'):
            ret = custom_https_connection_0.connect(create_connection(self.host, self.port), self.timeout, self.source_address)
        else:
            ret = custom_https_connection_0.connect(create_connection(self.host, self.port), self.timeout)
    except AttributeError:
        print('AttributeError')
    except Exception:
        print('Generic Exception')



# Generated at 2022-06-25 01:53:34.668196
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Imports
    import unittest
    import mock
    import sys

    # Some of the tests below deliberately cause errors and so will generate warnings
    # as a side-effect. Ignore these.
    if six.PY2:
        import warnings
        warnings.filterwarnings('ignore', 'tempnam', RuntimeWarning, module='ansible.module_utils.six.moves.urllib' )
        warnings.filterwarnings('ignore', 'tempnam', RuntimeWarning, module='urllib' )
        warnings.filterwarnings('ignore', 'tempnam', RuntimeWarning, module='urllib.request' )

    # Patch out stand in for global module vars

# Generated at 2022-06-25 01:53:39.125088
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # Example of calling constructor
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection(
        host='localhost',
        port=443,
        strict=False,
        timeout=30,
        source_address=None,
        blocksize=8192,
        cert_file=None,
        key_file=None)

    # Example of using method connect
    custom_h_t_t_p_s_connection_0.connect()


if HAS_SSLCONTEXT:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, ssl_context=None):
            self.ssl_context = ssl_context
            if ssl_context is None:
                # By default we create an SSL context that validates SSL certificates
                self.ssl

# Generated at 2022-06-25 01:53:44.870256
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    test_0_url = 'https://www.google.com/'
    test_0_validate_certs = True
    test_0_timeout = 1
    test_0_ca_path = None
    test_0_http_handler = urllib_request.HTTPHandler
    test_0_https_handler = urllib_request.HTTPSHandler
    test_0_response = None
    test_fake = FakeOpener()
    urllib_request.install_opener(test_fake)
    test_0_response = urllib_request.urlopen(test_0_url, timeout=test_0_timeout)
    assert test_0_response.getcode() == 200

    # Test case 0

# Generated at 2022-06-25 01:53:51.753329
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    svl_handler = SSLValidationHandler('api.example.com', 443)
    output = svl_handler.get_ca_certs()
    #print('output is {0}'.format(output))
    assert output[2][0] == "/etc/ssl/certs"

if __name__ == '__main__':
    test_SSLValidationHandler_get_ca_certs()

# Generated at 2022-06-25 01:53:54.771085
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()
    # Creation of http.client.HTTPConnection is not yet implemented.
    try:
        custom_h_t_t_p_s_handler_0.http_request('http.client.HTTPConnection')
    except NotImplementedError:
        pass


# Generated at 2022-06-25 01:54:01.016326
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    certificate_der = b'abc'

    if HAVE_DEFAULT_BACKEND:
        try:
            get_channel_binding_cert_hash(certificate_der)
        except NameError:
            pass
    else:
        try:
            get_channel_binding_cert_hash(certificate_der)
        except NameError:
            pass


# Generated at 2022-06-25 01:54:06.481261
# Unit test for function prepare_multipart

# Generated at 2022-06-25 01:55:42.140977
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.six.moves.urllib_parse import urlparse
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils import basic
    from ansible.module_utils.urls import fetch_url
    from ansible.modules.web_infrastructure.web import get

    args_0 = {
        u'http_agent': u'ansible-httpget',
        u'method': u'GET',
        u'timeout': 30,
        u'url': u'http://localhost:8181/provider/compute/api/json',
        u'use_proxy': True,
        u'url_password': None,
        u'url_username': None,
        u'validate_certs': False,
    }
    args

# Generated at 2022-06-25 01:55:42.820949
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    pass


# Generated at 2022-06-25 01:55:43.798305
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    test_get_channel_binding_cert_hash_0()


# Generated at 2022-06-25 01:55:48.365964
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    ret_0 = RedirectHandlerFactory()
    assert ret_0 is not None


# Generated at 2022-06-25 01:55:56.138769
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    from ansible.release import __version__

    ret = SSLValidationHandler.detect_no_proxy('http://github.com/ansible/ansible')
    assert ret == True
    ret = SSLValidationHandler.detect_no_proxy('https://github.com/ansible/ansible')
    assert ret == True
    ret = SSLValidationHandler.detect_no_proxy('https://localhost:8000/ansible/ansible')
    assert ret == True

    os.environ['no_proxy'] = 'github.com,localhost'
    ret = SSLValidationHandler.detect_no_proxy('https://localhost:8000/ansible/ansible')
    assert ret == False
    ret = SSLValidationHandler.detect_no_proxy('https://api.github.com/repos/ansible/ansible')


# Generated at 2022-06-25 01:56:02.865523
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():

    # test the GET method
    expected_code = 200
    expected_reason = b'OK'
    expected_result = b'this is a test'
    url = 'http://httpbin.org/get'

    # test the GET method with custom RedirectHandler
    RedirectHandler = RedirectHandlerFactory(follow_redirects='urllib2')
    urllib_request.install_opener(urllib_request.build_opener(RedirectHandler))
    req = urllib_request.Request(url)
    resp = urllib_request.urlopen(req)
    resp_code = resp.getcode()
    resp_reason = resp.reason
    resp_result = resp.read()
    assert resp_code == expected_code and resp_reason == expected_reason and resp_result == expected_result

   

# Generated at 2022-06-25 01:56:05.548898
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    custom_h_t_t_p_s_handler_0 = SSLValidationHandler('hostname', 0)
    url = '/'
    assert custom_h_t_t_p_s_handler_0.detect_no_proxy(url) == False


# Generated at 2022-06-25 01:56:11.888388
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Test the get_channel_binding_cert_hash function for correctness. """

    # Test empty certificate
    try:
        get_channel_binding_cert_hash(b'')
    except Exception:
        pass
    else:
        print("Empty certificate not handled correctly.")

    # Test invalid certificate
    try:
        get_channel_binding_cert_hash(b'\x00')
    except Exception:
        pass
    else:
        print("Invalid certificate not handled correctly.")

    # Test certificate with no signature hash algorithm
    cert_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../test/data/ansible-no-sig-alg.crt')
    file = open(cert_file, 'rb')
    certificate_der = file.read()


# Generated at 2022-06-25 01:56:17.755905
# Unit test for function fetch_file
def test_fetch_file():
    url_0 = 'https://github.com/ansible/ansible/archive/stable-2.9.zip'
    headers_0 = {'User-Agent': 'User-Agent'}
    file_name_0, file_ext_0 = os.path.splitext(url_0.rsplit('/', 1)[1])
    fetch_temp_file_0 = tempfile.NamedTemporaryFile(dir='/root', prefix=file_name_0, suffix=file_ext_0, delete=False)
    print(fetch_temp_file_0)
    print(fetch_temp_file_0.name)
    # print(fetch_file(url_0, headers_0))


# Generated at 2022-06-25 01:56:25.147704
# Unit test for function prepare_multipart
def test_prepare_multipart():
    assert prepare_multipart({"key1": "value"})[1] == b'--===============5833421209228008295==\r\nContent-Disposition: form-data; name=key1\r\n\r\nvalue\r\n--===============5833421209228008295==--\r\n'

# Generated at 2022-06-25 01:58:27.109899
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    cert = crypto.X509()
    cert.set_pubkey(crypto.PKey())
    cert.get_pubkey().generate_key()
    cert.sign(cert.get_pubkey(), 'sha256')
    open_ssl_version = crypto.OPENSSL_VERSION_NUMBER

# Generated at 2022-06-25 01:58:34.793323
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    unix_socket_path = '/tmp/test_unix_socket_patch_httpconnection_connect_unix_socket'
    http_response = 'HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n'

# Generated at 2022-06-25 01:58:39.556661
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    tmp_ca_cert_path, cadata, paths_checked = test_SSLValidationHandler_get_ca_certs()

    if HAS_SSLCONTEXT:
        context = create_default_context(cafile=tmp_ca_cert_path)
    elif HAS_URLLIB3_PYOPENSSLCONTEXT:
        context = PyOpenSSLContext(PROTOCOL)
    else:
        raise NotImplementedError('Host libraries are too old to support creating an sslcontext')

    if tmp_ca_cert_path or cadata:
        context.load_verify_locations(cafile=tmp_ca_cert_path, cadata=cadata)

    assert context.get_ca_certs() != []


# Generated at 2022-06-25 01:58:44.214416
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    result_0 = CustomHTTPSConnection.connect()
    assert result_0 is None
    # Failure message:
    # Exception raised: 'NoneType' object has no attribute 'connect'


# Generated at 2022-06-25 01:58:45.212132
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_http_connection_0 = UnixHTTPConnection()


# Generated at 2022-06-25 01:58:53.294140
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    assert get_channel_binding_cert_hash(ssl_test_data.test_certificate_der_0) == base64.b64decode(b'MzwRtChjCiPdWx3q9XkHABpZQLtD0umtNlEDpcCwGkY=')
    assert get_channel_binding_cert_hash(ssl_test_data.test_certificate_der_1) == base64.b64decode(b'O7VuI/HIDQZlB6UksB1UeceiiCjB6iyAkFK1x4D4aj4=')

# Generated at 2022-06-25 01:59:01.641354
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test the generic_urlparse function.

    :return: True if the test passes, otherwise False.
    :rtype: bool
    '''
    # This test code is copied from the Python 2 urllib standard library, so it
    # can be omitted from coverage since it is not our code.
    #
    # Note that ``parts`` is a reference to the actual parts tuple of the
    # generic_urlparse function, so the tests below modify that value. Since
    # we need the original parts variable for the next set of tests, we must
    # reset the value of parts between tests.
    #
    # pylint: disable=unused-variable
    p = urllib_parse.urlparse('http://www.cwi.nl:80/%7Eguido/Python.html')
    parts = generic_urlparse

# Generated at 2022-06-25 01:59:08.149566
# Unit test for function fetch_url
def test_fetch_url():
    # Setup
    module = MockModule()
    url = "https://example.com"
    data="example data"
    headers={"Content-type": "application/json"}
    method="POST"
    use_proxy=True
    force=False
    last_mod_time=None
    timeout=10
    use_gssapi=False
    unix_socket=None
    ca_path=None
    cookies=None
    unredirected_headers=None
    out_response, out_info = fetch_url(module, url, data, headers, method,
        use_proxy, force, last_mod_time, timeout, use_gssapi, unix_socket, ca_path, cookies, unredirected_headers)
    assert out_info['status'] == 200

# Generated at 2022-06-25 01:59:12.606012
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    assert get_channel_binding_cert_hash(b'\x00') == b'n\x12\xa2\xd2\x06\xabr\xce\x10\x1b\x00\x13\x10\x18\xb5\xdb\x1c\xf6\x16\x02'
