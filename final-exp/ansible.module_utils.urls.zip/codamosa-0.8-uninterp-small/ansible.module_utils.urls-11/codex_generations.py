

# Generated at 2022-06-25 01:52:32.303672
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():

    SSLValidationHandler_obj = SSLValidationHandler()
    custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()
    urllib_request.UNHANDLED_EXCEPTIONS = [ssl.SSLError]
    urllib_request.uninstall_opener(custom_h_t_t_p_s_handler_0)
    custom_h_t_t_p_s_handler_0.add_parent(SSLValidationHandler_obj)
    urllib_request.install_opener(custom_h_t_t_p_s_handler_0)

    # do what an invalid request does
    # params for the test
    custom_h_t_p_s_connection_0 = CustomHTTPSConnection()
    custom_h_t_t_p_s

# Generated at 2022-06-25 01:52:35.134074
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    ssl_validation_handler_0 = SSLValidationHandler()
    # 'req' is passed to the test case as a parameter.
    ssl_validation_handler_0.http_request(req)


# Generated at 2022-06-25 01:52:36.267917
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    build_ssl_validation_error()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:52:45.049283
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = None
    try:
        prepare_multipart(fields)
        assert False
    except TypeError:
        pass

    fields = 'str'
    try:
        prepare_multipart(fields)
        assert False
    except TypeError:
        pass

    fields = {'key': 'value'}
    prepare_multipart(fields)

    fields = {'key': {'content': 'content'}}
    prepare_multipart(fields)

    fields = {'key': {'filename': '/bin/true'}}
    prepare_multipart(fields)

    fields = {'key': {'filename': '/bin/true', 'content': 'content'}}
    try:
        prepare_multipart(fields)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-25 01:52:50.586795
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
       # if the constructor has parameters, they can be provided here
        urllib_request.HTTPSHandler()
    except TypeError as e:
        assert False


# Generated at 2022-06-25 01:52:55.301098
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    assert SSLValidationHandler(None).detect_no_proxy('https://www.example.com') == True


# Generated at 2022-06-25 01:52:58.186084
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'test'
    port = int(1234)
    paths = ['test']
    exc = None
    build_ssl_validation_error(hostname, port, paths, exc)


# Generated at 2022-06-25 01:53:00.155441
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    try:
        assert rfc2822_date_string(time.gmtime()) in time.ctime()
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 01:53:04.934337
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    custom_s_s_l_validation_handler_0 = SSLValidationHandler(None, None)
    url = 'http://cnn.com'
    custom_s_s_l_validation_handler_0.detect_no_proxy(url)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_SSLValidationHandler_detect_no_proxy']
    unittest.main()

# Generated at 2022-06-25 01:53:08.977729
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    result = RedirectHandlerFactory()
    assert isinstance(result, RedirectHandler)


# Generated at 2022-06-25 01:54:55.382160
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'localhost'
    port = '123'
    paths = ['path1', 'path2']

    expected_msg = ('Failed to validate the SSL certificate for %s:%s.'
                    ' Make sure your managed systems have a valid CA'
                    ' certificate installed. You can use validate_certs=False'
                    ' if you do not need to confirm the servers identity but'
                    ' this is unsafe and not recommended. Paths'
                    ' checked for this platform: %s.')
    expected_msg = expected_msg % (hostname, port, ", ".join(paths))

    try:
        build_ssl_validation_error(hostname, port, paths)
    except SSLValidationError as ssl_validation_error:
        msg = ssl_validation_error.message
        assert msg == expected_msg


# Generated at 2022-06-25 01:55:01.377505
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    # Test with arguments specified
    assert rfc2822_date_string(timetuple=(2018, 8, 13, 13, 13, 13, 0)) == "Mon, 13 Aug 2018 13:13:13 -0000"
    # Test with default arguments
    assert rfc2822_date_string() == "Mon, 13 Aug 2018 13:13:13 -0000"


# Generated at 2022-06-25 01:55:07.044968
# Unit test for function fetch_url
def test_fetch_url():
    # FIXME: test fails on Jenkins, see https://github.com/ansible/ansible/pull/13600 for details
    pytest.skip("test fails on Jenkins, see https://github.com/ansible/ansible/pull/13600 for details")
    test_function = fetch_url
    module = AnsibleModule(argument_spec=url_argument_spec())
    module.params = {
        'url': 'http://localhost/',
        'validate_certs': None
    }

    r, info = fetch_url(module, **module.params)
    assert isinstance(r, urllib2.addinfourl)
    assert 'url' in info
    assert info['url'] == module.params['url']
    assert info['status'] == 200
    assert info['msg'] == 'OK (unknown bytes)'

# Generated at 2022-06-25 01:55:09.365272
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    custom_ssl_validation_handler_0 = SSLValidationHandler('hostname', 80)
    result = custom_ssl_validation_handler_0.detect_no_proxy('url')


# Generated at 2022-06-25 01:55:14.960356
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    print("Testing function rfc2822_date_string")
    timetuple = (2009, 2, 13, 17, 31, 30, 4)
    actual = rfc2822_date_string(timetuple)
    expected = 'Fri, 13 Feb 2009 17:31:30 -0000'
    assert actual == expected, 'Failed to rfc2822_date_string'


# Generated at 2022-06-25 01:55:16.245254
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(response, True) == True #

# unit tests end


# Generated at 2022-06-25 01:55:26.753541
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    #
    # Define mock objects and method mocks
    #

    # mock object HTTPResponse
    class HTTPResponse:
        pass

    # mock object unix_http_connection_connect
    class unix_http_connection_connect:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            pass

    # mock object unix_http_connection
    class unix_http_connection:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            pass

    # mock object httplib

# Generated at 2022-06-25 01:55:33.189870
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule()
    
    assert fetch_url(module, url, data=None, headers=None, method=None,
              use_proxy=True, force=False, last_mod_time=None, timeout=10,
              use_gssapi=False, unix_socket=None, ca_path=None, cookies=None, unredirected_headers=None)

if __name__ == '__main__':
    import json
    print(json.dumps({"changed": False, "ansible_facts": {"fetch_url": test_fetch_url()}}, indent=4, sort_keys=True))

# Generated at 2022-06-25 01:55:34.440644
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    test_uri = 'https://test_uri.com'
    assert(maybe_add_ssl_handler(test_uri, True) == None)


# Generated at 2022-06-25 01:55:42.525149
# Unit test for function getpeercert
def test_getpeercert():
    class MockResponse(object):
        def __init__(self):
            self.fp = self

        class MockSocket(object):
            def getpeercert(self, binary_form):
                return binary_form

        def __getattr__(self, attr):
            return self.MockSocket()

    response = MockResponse()

    try:
        # catch AttributeError from getpeercert: if mock object does not have
        # attribute '_sock'
        getpeercert(response, binary_form=False)
    except AttributeError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_getpeercert()

    # s = socket.create_connection(('10.0.0.36', 443))
    # # ssl_s = ssl

# Generated at 2022-06-25 01:57:08.500843
# Unit test for function prepare_multipart

# Generated at 2022-06-25 01:57:13.865512
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    test_case_0()


# Generated at 2022-06-25 01:57:17.881072
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():

    # Testing custom type 'CustomHTTPSConnection'
    test_case_0()

    # Testing if the call to SSLValidationHandler.http_request() raises any exceptions
    instance = SSLValidationHandler('www.google.com', '80')
    req = HTTPRequest()
    try:
        instance.http_request(req)
    except Exception as e:
        print('Caught exception when calling SSLValidationHandler.http_request():' + str(e))
        raise



# Generated at 2022-06-25 01:57:23.816615
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    request = None
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_0.request = request
    s_s_l_validation_handler_0 = SSLValidationHandler(custom_h_t_t_p_s_connection_0)
    custom_h_t_t_p_s_connection_0.request = s_s_l_validation_handler_0.http_request(custom_h_t_t_p_s_connection_0.request)
    return (custom_h_t_t_p_s_connection_0.request)


# Generated at 2022-06-25 01:57:33.272579
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler('test_host', '123')

    # Test with response: 200
    response = b'HTTP/1.0 200 OK\r\n'
    handler.validate_proxy_response(response)

    # Test with response: 403
    # This should raise ProxyError
    response = b'HTTP/1.0 403 Why\r\n'
    with pytest.raises(ProxyError) as excinfo:
        handler.validate_proxy_response(response)
    assert to_text(str(excinfo.value)) == "Connection to proxy failed"



# Generated at 2022-06-25 01:57:36.831121
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    custom_ssl_validation_handler_0 = SSLValidationHandler(hostname='hostname', port=0)
    custom_ssl_validation_handler_0.get_ca_certs()
    return


# Generated at 2022-06-25 01:57:45.553209
# Unit test for function getpeercert
def test_getpeercert():
    # Testing if an attribute error is raised when a custom HTTPS connection
    # object is passed in as an argument
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_1 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_2 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_3 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_4 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_5 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_6 = CustomHTTPSConnection()


# Generated at 2022-06-25 01:57:55.400288
# Unit test for function generic_urlparse
def test_generic_urlparse():
    data_1 = {'fragment': None, 'password': None, 'params': '', 'path': '/v1/admin/info', 'hostname': '127.0.0.1',
              'scheme': 'http', 'netloc': '127.0.0.1:80', 'query': None, 'username': None, 'port': 80}
    params_1 = urllib_parse.urlparse('http://127.0.0.1:80/v1/admin/info')
    ret = generic_urlparse(params_1)
    assert type(ret) is ParseResultDottedDict, "Return type mismatch"
    assert ret == data_1, "Return value mismatch"


# Generated at 2022-06-25 01:57:58.524570
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # Test for actual constructor, of class CustomHTTPSConnection
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()

#
# Connection class
#



# Generated at 2022-06-25 01:58:02.470507
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    custom_ssl_validation_handler_0 = SSLValidationHandler()
    tmp_ca_cert_path, cadata, paths_checked_0 = custom_ssl_validation_handler_0.get_ca_certs()
    tmp_ca_cert_path, cadata, paths_checked_1 = custom_ssl_validation_handler_0.get_ca_certs()


# Generated at 2022-06-25 01:59:03.611299
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    assert RedirectHandlerFactory(follow_redirects='all') is not None
    assert RedirectHandlerFactory(follow_redirects='none') is not None
    assert RedirectHandlerFactory(follow_redirects='urllib2') is not None
    assert RedirectHandlerFactory(follow_redirects='no') is not None
    assert RedirectHandlerFactory(follow_redirects='none') is not None
    assert RedirectHandlerFactory(follow_redirects='safe') is not None
    try:
        assert RedirectHandlerFactory(follow_redirects='test') is not None
    except urllib_error.HTTPError as e:
        assert e is not None


# Generated at 2022-06-25 01:59:04.500611
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    assert True


# Generated at 2022-06-25 01:59:10.399467
# Unit test for function fetch_url
def test_fetch_url():
    # Test with a MissingModuleError
    with pytest.raises(AnsibleConnectionFailure):
        fetch_url(AnsibleModule(argument_spec=url_argument_spec()), 'https://github.com/')

    # Test with an HTTPError
    with pytest.raises(AnsibleConnectionFailure):
        fetch_url(AnsibleModule(argument_spec=url_argument_spec()), 'https://github.com/404')

    # Test with a URLError
    with pytest.raises(AnsibleConnectionFailure):
        fetch_url(AnsibleModule(argument_spec=url_argument_spec()), 'https://deadhost/a.txt')

    # Test with a socket.error