

# Generated at 2022-06-25 01:53:07.708243
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    from ansible.module_utils.urls import open_url
    import json
    import textwrap
    import tempfile
    import time
    import os
    import threading

    client_thread_stop = threading.Event()
    server_thread_stop = threading.Event()
    server_thread = threading.Thread(target=mockup_http_server, args=(server_thread_stop,))
    client_thread = threading.Thread(target=test_client, args=(client_thread_stop,))

    print('Starting mockup server')
    server_thread.start()
    print('Starting client thread')
    client_thread.start()
    print('Waiting for client thread')
    client_thread.join()
    print('Waiting for server thread')
    server_thread_stop.set()
    server_

# Generated at 2022-06-25 01:53:10.926448
# Unit test for method patch of class Request
def test_Request_patch():
    var_1 = fdopen()
    var_2 = RequestWithMethod('DELETE', 'http://localhost:8080/', var_1)
    var_2.patch('http://localhost:8443/')


# Generated at 2022-06-25 01:53:12.469619
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    var_0 = SSLValidationHandler('sample str', 'sample str')
    var_1 = getattr(var_0, 'get_ca_certs', lambda: None)()
    pass


# Generated at 2022-06-25 01:53:15.073088
# Unit test for function getpeercert
def test_getpeercert():
    response = object()
    binary_form = False
    assert False # FIXME
    # assert getpeercert(response, binary_form) == ''


# Generated at 2022-06-25 01:53:21.875462
# Unit test for method post of class Request
def test_Request_post():
    var_1 = Request()
    var_2 = test_case_0()
    var_1.post(var_2)
    var_3 = test_case_0()
    var_4 = test_case_0()
    var_1.post(var_3, data=var_4)


# Generated at 2022-06-25 01:53:23.500661
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url = 'https://www.google.com'
    handler = SSLValidationHandler(url, 443)
    assert handler.detect_no_proxy(url) == True


# Generated at 2022-06-25 01:53:25.561040
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    assert False, "Unit test for method test_SSLValidationHandler_detect_no_proxy of class SSLValidationHandler"
    handler = SSLValidationHandler(hostname, port, ca_path)
    url = foo
    method = detect_no_proxy(url)


# Generated at 2022-06-25 01:53:30.442990
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    args = dict(
        url=dict(type='str'),
    )

    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True
    )

    obj = SSLValidationHandler(module.params['url'])

    # We need to make sure 'no_proxy' is set. Hopefully we're running a test that is 
    # not using a proxy.
    if 'no_proxy' not in os.environ:
        os.environ['no_proxy'] = 'localhost,127.0.0.1'

    # check if no_proxy is set
    assert obj.detect_no_proxy('http://localhost') == False

    # clean up
    os.environ.pop('no_proxy')


# Generated at 2022-06-25 01:53:32.819678
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    timetuple = (2016, 7, 21, 17, 3, 38, 3)
    zone = '-0000'
    # Call function
    result = rfc2822_date_string(timetuple, zone)
    assert result == 'Thu, 21 Jul 2016 17:03:38 -0000'


# Generated at 2022-06-25 01:53:35.044062
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    req = None
    ssl_validation_handler = SSLValidationHandler(hostname="www.example.com", port=9999, ca_path=None)
    assert isinstance(ssl_validation_handler.http_request(req), HTTPError)


# Generated at 2022-06-25 01:55:26.581935
# Unit test for function getpeercert
def test_getpeercert():
    HOSTNAME = 'www.google.com'
    PORT = 443
    url = ''.join(['https://', HOSTNAME, ':', port])
    r = urlopen(url)
    peercert = getpeercert(r)
    assert peercert
    assert peercert.get('issuer')
    assert peercert.get('subject')
    assert peercert.get('notAfter')
    assert peercert.get('notBefore')
    assert peercert.get('subjectAltName')

    # Validate that we can call it twice without error
    assert getpeercert(r)


# Generated at 2022-06-25 01:55:30.952527
# Unit test for function fetch_file
def test_fetch_file():
    var_2 = None
    var_1 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_

# Generated at 2022-06-25 01:55:37.471884
# Unit test for function fetch_file
def test_fetch_file():
    _fetch_temp_file, _info = fetch_file(None, 'http://www.baidu.com')
    print(_fetch_temp_file)
    print(_info)


# Generated at 2022-06-25 01:55:38.836383
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    assert maybe_add_ssl_handler(url='http://localhost:80', 
                                 validate_certs=False) is None


# Generated at 2022-06-25 01:55:41.018514
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    var_0 = url_argument_spec()
    # Run test
    test_case_0()

# Generated at 2022-06-25 01:55:43.120121
# Unit test for function getpeercert
def test_getpeercert():
    response = None
    binary_form = False

    getpeercert(response, binary_form)


# Generated at 2022-06-25 01:55:53.865184
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-25 01:56:00.418343
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    hostname = 'github.com'
    port = 443
    ca_path = None
    self = SSLValidationHandler(hostname, port, ca_path)
    response = b"HTTP/1.0 200 Connection established\r\n\r\n"
    valid_codes = None

    # Call method
    self.validate_proxy_response(response, valid_codes)


# Generated at 2022-06-25 01:56:01.904184
# Unit test for function getpeercert
def test_getpeercert():
    url = 'http://www.google.com'
    response = urlopen(url)
    test = getpeercert(response)
    print(test)
    #assert(test == True)


# Generated at 2022-06-25 01:56:06.624449
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {}
    fields['name'] = 'Erick'
    fields['email'] = 'fake@email.com'
    fields['file1'] = {
        'filename': '/bin/true',
        'mime_type': 'application/octet-stream'
    }
    fields['file2'] = {
        'content': 'text based file content',
        'filename': 'fake.txt',
        'mime_type': 'text/plain',
    }
    fields['file3'] = {
        'content': 'text based file content',
        'mime_type': 'text/plain',
    }
    fields['file4'] = {
        'filename': 'fake.txt',
    }

# Generated at 2022-06-25 01:57:16.599081
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Create CustomHTTPSConnection object
    CustomHTTPSConnection_obj = CustomHTTPSConnection(host="www.example.com", port=443, key_file=None, cert_file=None, context=None, timeout=None, source_address=None)
    # Connect to a host on a given (SSL) port.
    CustomHTTPSConnection_obj.connect()


# Generated at 2022-06-25 01:57:28.179390
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    cert_file = "cert.pem"
    key_file = "key.pem"

    conn = CustomHTTPSConnection("host",
                                 port = 443,
                                 key_file = key_file,
                                 cert_file = cert_file,
                                 strict = True)

    assert conn.host == "host"
    assert conn.port == 443
    assert conn.strict == True
    assert conn.key_file == "key.pem"
    assert conn.cert_file == "cert.pem"



# Generated at 2022-06-25 01:57:32.825381
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url = 'http://example.com'
    handler = SSLValidationHandler('example.com', 443, '/certs')
    ret = handler.detect_no_proxy(url)
    assert type(ret) == bool


# Generated at 2022-06-25 01:57:34.683348
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    var_1 = UnixHTTPConnection('/var/run/docker.sock')


# Generated at 2022-06-25 01:57:43.070866
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    var_0 = SSLValidationHandler(u'https://www.ansible.com', 443, None)
    var_0.http_request(var_1)
    try:
        # Set up mock
        urlopen = mock.Mock()
        urlopen.return_value = True
        urllib_request.urlopen = urlopen

        # Call method
        var_0.http_request(var_1)

    # Restore
    except Exception as e:
        urllib_request.urlopen = orig_urllib_request_urlopen
        raise e

    # Restore
    urllib_request.urlopen = orig_urllib_request_urlopen


# Generated at 2022-06-25 01:57:48.811852
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    var_0 = SSLValidationHandler(hostname = 'host.example.com', port = 443)

    if hasattr(var_0, 'get_ca_certs'):
        print('get_ca_certs method is present')
    else:
        print('get_ca_certs method is not present')


# Generated at 2022-06-25 01:57:58.187834
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    try:
        # Test without any parameters
        print(get_channel_binding_cert_hash())
    except TypeError:
        pass

    try:
        # Test with a required parameter (without optional)
        print(get_channel_binding_cert_hash(certificate_der = 'abc'))
    except TypeError:
        pass

    try:
        # Test with an optional parameter
        get_channel_binding_cert_hash(certificate_der = 'abc', module = 'def')
    except TypeError:
        pass

    try:
        # Test with all parameters
        get_channel_binding_cert_hash(certificate_der = 'abc', module = 'def')
    except TypeError:
        pass


# Generated at 2022-06-25 01:58:01.673936
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Instantiation of class SSLValidationHandler with args hostname, port and ca_path
    var_1 = SSLValidationHandler(hostname, port, ca_path)
    try:
        # Calling get_ca_certs() of class SSLValidationHandler
        var_1.get_ca_certs()
    except:
        pass


# Generated at 2022-06-25 01:58:02.627481
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # Fail on no arguments
    test_CustomHTTPSHandler_none()


# Generated at 2022-06-25 01:58:08.895114
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream",
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    ret = prepare_multipart(fields)
    assert ret[0] == 'multipart/form-data; boundary="===============1529551785510771698=="'
    var_1 = ret[1]



if __name__ == '__main__':
    # Test for function test_case_0
    test_case_0()
    # Test for function prepare_multipart
    test