

# Generated at 2022-06-25 01:54:02.691638
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    # test no exception raised
    with unix_socket_patch_httpconnection_connect():
        pass
    # test no exception raised
    # verify test_patch_httpconnection_connect
    if True:
        raise ValueError('test_patch_httpconnection_connect failed')


# Generated at 2022-06-25 01:54:12.208883
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Test with invalid url scheme
    try:
        ssl_handler = maybe_add_ssl_handler('http://example.com', True)
    except NoSSLError:
        pass
    except:
        raise AssertionError('Expected exception was not raised')

    # Test with invalid port(s)
    try:
        ssl_handler = maybe_add_ssl_handler('https://example.com', True)
    except NoSSLError:
        pass
    except:
        raise AssertionError('Expected exception was not raised')

    # Test with valid url
    ssl_handler = maybe_add_ssl_handler('https://example.com:443', True)
    assert isinstance(ssl_handler, SSLValidationHandler)


# Generated at 2022-06-25 01:54:18.442620
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    # Test custom HTTPS handler
    kwargs = {}
    if HAS_SSLCONTEXT:
        kwargs['context'] = None
    handler = CustomHTTPSHandler(**kwargs)
    assert handler.https_open("123456789") == "https://127.0.0.1:123456789"

# Docker (1.x) API over SSL
# Test custom HTTPS handler https_open for Docker API

# Generated at 2022-06-25 01:54:28.571997
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Test with a dictionary that is not a mapping
    try:
        prepare_multipart('a')
    except TypeError as e:
        assert e.args[0] == 'Mapping is required, cannot be type str'
    else:
        raise AssertionError('Expected TypeError')
    # Test with a value that is neither a string nor a mapping
    try:
        prepare_multipart({'a': [1, 2, 3]})
    except TypeError as e:
        assert e.args[0] == 'value must be a string, or mapping, cannot be type list'
    else:
        raise AssertionError('Expected TypeError')
    # Test with a mapping with neither 'filename' nor 'content'

# Generated at 2022-06-25 01:54:39.674952
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    test_handler = SSLValidationHandler('', None)

    # No_proxy env variable set
    os.environ['no_proxy'] = 'example.com'
    assert test_handler.detect_no_proxy('http://example.com') == False

    # No_proxy env variable set, but url not included in it
    os.environ['no_proxy'] = 'example2.com'
    assert test_handler.detect_no_proxy('http://example.com') == True

    # No_proxy env variable set, but url not included in it, but it is a subdomain
    os.environ['no_proxy'] = 'example2.com'
    assert test_handler.detect_no_proxy('http://subdomain.example.com') == False

    # No_proxy env variable set, but url not included in it

# Generated at 2022-06-25 01:54:45.465647
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Tests that a RedirectHandler is returned, with the following
    # properties:
    # - redirect_request is a method of RedirectHandler
    # - redirect_request is a closure over the follow_redirects argument
    # - the method redirect_request is invoked, it will properly
    #   raise an Exception when the follow_redirects argument is set to
    #   'no', or not raise an exception in all other cases
    status_code = 307
    follow_redirects_tests = [('no', True), ('none', True), (False, True),
                              ('all', False), ('yes', False), (True, False),
                              ('safe', False), ('urllib2', False)]
    for follow_redirects, should_raise_exception in follow_redirects_tests:
        redirect_handler = Redirect

# Generated at 2022-06-25 01:54:47.201757
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    # This is a error class
    try:
        build_ssl_validation_error('test', 0, [])
    except Exception as ex:
        assert(isinstance(ex, SSLValidationError))


# Generated at 2022-06-25 01:54:53.954306
# Unit test for function prepare_multipart
def test_prepare_multipart():
    from ansible_collections.net.common.tests.unit.compat.mock import patch
    import shutil
    import os
    import tempfile

    (tmp_path, tmp_file) = tempfile.mkstemp()

    # create a file with some content
    with open(tmp_file, 'wb') as f:
        f.write('Hello, World')

    # create a second temporary file
    (tmp_path2, tmp_file2) = tempfile.mkstemp(prefix='content')

    # create a file with some content
    with open(tmp_file2, 'wb') as f:
        f.write('Howdy, World')

    # use an existing file as content
    fields = {'file1': {'filename': tmp_file}}

    # use the content of an existing file
    fields2

# Generated at 2022-06-25 01:54:58.620026
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    RedirectHandler = RedirectHandlerFactory('safe')
    assert(RedirectHandler(None, None, None, 301, None, None) == None)
    assert(RedirectHandler(None, None, None, 302, None, None) == None)
    assert(RedirectHandler(None, None, None, 303, None, None) == None)
    assert(RedirectHandler(None, None, None, 400, None, None) == None)
    assert(RedirectHandler(None, None, None, 401, None, None) == None)
    assert(RedirectHandler(None, None, None, 402, None, None) == None)
    assert(RedirectHandler(None, None, None, 403, None, None) == None)
    assert(RedirectHandler(None, None, None, 404, None, None) == None)

# Generated at 2022-06-25 01:55:07.942388
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():

    # CERT_NONE
    assert SSLValidationHandler(u'hostname', u'port', ca_path=u'ca_path').make_context(u'cafile', u'cadata')

    # CERT_OPTIONAL
    assert SSLValidationHandler(u'hostname', u'port', ca_path=u'ca_path').make_context(u'cafile', u'cadata')

    # CERT_REQUIRED
    assert SSLValidationHandler(u'hostname', u'port', ca_path=u'ca_path').make_context(u'cafile', u'cadata')



# Generated at 2022-06-25 01:56:29.281532
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    args0 = {}
    kwargs0 = {}
    obj0 = CustomHTTPSConnection(*args0, **kwargs0)
    assert isinstance(obj0, CustomHTTPSConnection)
    assert isinstance(obj0, httplib.HTTPSConnection)
    assert obj0.context is None
    if HAS_SSLCONTEXT:
        assert obj0.context is obj0._context
    elif HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert obj0.context is obj0._context
        assert isinstance(obj0._context, PyOpenSSLContext)
        assert obj0._context.protocol is PROTOCOL


# Generated at 2022-06-25 01:56:33.705839
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    no_s_s_l_validation_handler_0 = SSLValidationHandler(hostname='hostname_0', port='port_0')
    try:
        no_s_s_l_validation_handler_0.validate_proxy_response(response='response_0')
    except Exception as e:
        print(str(e))
    try:
        no_s_s_l_validation_handler_0.validate_proxy_response(response='response_0', valid_codes='valid_codes_0')
    except Exception as e:
        print(str(e))


# Generated at 2022-06-25 01:56:39.049482
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    if not hasattr(httplib, 'HTTPSConnection'):
        return
    con = CustomHTTPSConnection('www.google.com', 443)


if CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.AbstractHTTPHandler):
        def __init__(self, *args, **kwargs):
            self.connection_class = CustomHTTPSConnection
            urllib_request.AbstractHTTPHandler.__init__(self, *args, **kwargs)

        def https_open(self, req):
            return self.do_open(self.connection_class, req)

        # Overwrite the parent class's version
        https_request = urllib_request.AbstractHTTPHandler.do_request_

        # Does not use class variable https_request to avoid catching subclasses (don't want to pollute the
       

# Generated at 2022-06-25 01:56:41.035277
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {"file1": {"filename": "/bin/true"}}
    content_type, body = prepare_multipart(fields)
    assert content_type == 'multipart/form-data; boundary================3742190157686553719=='


# Generated at 2022-06-25 01:56:45.432181
# Unit test for function fetch_url
def test_fetch_url():
    from modules.fetch_url import fetch_url

    # NoSSL Error
    with pytest.raises(AnsibleFailJson):
        fetch_url("module", "url", "data", "headers", "method",
                  "use_proxy", "force", "last_mod_time", "timeout", "use_gssapi",
                  "unix_socket", "ca_path", "cookies", "unredirected_headers")
    # Connection Error
    with pytest.raises(AnsibleFailJson):
        fetch_url("module", "url", "data", "headers", "method",
                  "use_proxy", "force", "last_mod_time", "timeout", "use_gssapi",
                  "unix_socket", "ca_path", "cookies", "unredirected_headers")

# Generated at 2022-06-25 01:56:48.425208
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    http_handler = SSLValidationHandler(hostname=to_bytes('example.com'), port=443, ca_path=to_bytes('/path/to/ca_cert'))
    response = to_bytes('HTTP/1.0 200 Connection Established\r\n\r\n')
    if http_handler.validate_proxy_response(response) is None:
        return True
    else:
        return False



# Generated at 2022-06-25 01:56:54.422361
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    from sys import version_info
    if (version_info[0] < 3):
        from urllib2 import build_opener, HTTPSHandler
    else:
        from urllib.request import build_opener, HTTPSHandler

    # Constructor test case
    assert HTTPSHandler() is not None


# Generated at 2022-06-25 01:56:59.222623
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    tmp_ca_cert_path, cadata, paths_checked = SSLValidationHandler('localhost', '443', 'c:\\abc').get_ca_certs()
    assert isinstance(cadata, bytearray)
    assert isinstance(paths_checked, list)


# Generated at 2022-06-25 01:57:07.414409
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():

    certificate_der_0 = bytearray()

    try:
        channel_binding_cert_hash_0 = get_channel_binding_cert_hash(certificate_der_0)
    except NameError:
        channel_binding_cert_hash_0 = None

    # Test will fail if the exception is not raised.


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 01:57:11.649775
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # get_ca_certs method test for default parameters
    tmp_ca_cert_path, cadata, paths_checked = build_ssl_validation_handler('example.com', 443).get_ca_certs()
    assert tmp_ca_cert_path or cadata, 'cadata or tmp_ca_cert_path is empty'
    assert paths_checked, 'paths_checked is empty'


# Generated at 2022-06-25 01:58:03.151905
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    c_h_t_t_p_s_handler_0 = CustomHTTPSHandler()


if hasattr(socket, 'AF_UNIX') and hasattr(urllib_request, 'HTTPSHandler'):
    # The HTTPSConnection class in python's stdlib is an old style class so
    # we can only use super() safely on newer python versions when we're
    # inheriting from it.  Since sock_connect is an old style method, we have
    # to call it via the class and not via super()
    # i.e. socket.socket.connect(...) not super(...).connect(...)
    if PY3:
        BaseUnixHTTPSConnection = urllib_request.HTTPSConnection

# Generated at 2022-06-25 01:58:04.592890
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    unix_socket_patch_httpconnection_connect()


# Generated at 2022-06-25 01:58:05.690469
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    new_handler = RedirectHandlerFactory()
    new_handler.redirect_request(None, None, None, None, None, None)


# Generated at 2022-06-25 01:58:08.130108
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    customHTTPSHandler_0 = CustomHTTPSHandler()


# Generated at 2022-06-25 01:58:15.155906
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test case 0: HTTPError is raised here because follow_redirects is set to false
    try:
        no_redirect_handler_0 = RedirectHandlerFactory(follow_redirects=False)
        no_http_request_0 = urllib_request.Request(url='http://www.google.com')
        no_response_0 = no_redirect_handler_0.redirect_request(req=no_http_request_0, fp='', code=302, msg='', hdrs='', newurl='http://www.google.ca')
    except urllib_error.HTTPError:
        pass
    # Test case 1: HTTPError is raised here because follow_redirects is set to 'no'

# Generated at 2022-06-25 01:58:22.574798
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    """
        Try to fake the HTTPSHandler class here
    """
    class CustomHTTPSHandler_test(CustomHTTPSHandler):
        """
            Test Constructor
        """
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self._context = CustomHTTPSConnection.context

    # Test the constructor
    CustomHTTPSHandler_test(1, 2, 3)
    CustomHTTPSHandler_test(foo = 'bar')



# Generated at 2022-06-25 01:58:27.048083
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    iut = SSLValidationHandler('1.1.1.1', 443)
    ca_path, cadata, paths_checked = iut.get_ca_certs()

    assert(ca_path is not None and ca_path != '')
    assert(cadata is not None)
    assert(len(cadata) > 0)
    assert(paths_checked is not None)
    assert(len(paths_checked) > 0)


if __name__ == '__main__':
    test_case_0()
    test_SSLValidationHandler_get_ca_certs()

# Generated at 2022-06-25 01:58:28.564130
# Unit test for function fetch_file
def test_fetch_file():
    assert fetch_file(NoSSLError(), test_case_0) is None


# Generated at 2022-06-25 01:58:36.486114
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # verify that the class raises a NoSSLError
    # if SSL is not available, but required

    class MockSSLError(Exception):
        pass

    def mock_ssl_wrap_socket(sock, keyfile, cert_reqs, certfile, ssl_version, server_hostname):
        raise MockSSLError()

    # skip if no ssl module is available
    if not HAS_SSL:
        return

    if HAS_SSLCONTEXT:
        kwargs = {'_context': False}
    elif HAS_URLLIB3_PYOPENSSLCONTEXT:
        kwargs = {'_context': PyOpenSSLContext(PROTOCOL)}
    else:
        kwargs = {}

    # patch the ssl module

# Generated at 2022-06-25 01:58:37.908658
# Unit test for method open of class Request
def test_Request_open():
    request = Request()
    request.open('GET', 'http://test/')
