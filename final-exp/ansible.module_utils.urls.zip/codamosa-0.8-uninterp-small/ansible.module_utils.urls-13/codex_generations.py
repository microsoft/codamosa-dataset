

# Generated at 2022-06-25 01:53:11.107032
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # test_RedirectHandlerFactory_1 test case
    # 
    # CustomHTTPSHandler
    # 
    # 
    # 
    # 
    #
    # 
    #
    # 

    custom_h_t_t_p_s_handler_1 = CustomHTTPSHandler()

    # test_RedirectHandlerFactory_2 test case
    # 
    # HTTPSClientAuthHandler
    # 
    # 
    # 
    # 
    #
    # 
    #
    # 

    h_t_t_p_s_client_auth_handler_2 = HTTPSClientAuthHandler()

    # test_RedirectHandlerFactory_3 test case
    # 
    # HTTPSClientAuthHandler
    # 
    # 
    # 
    # 
    #


# Generated at 2022-06-25 01:53:18.476416
# Unit test for method options of class Request
def test_Request_options():
    # Imports
    try:
        from urllib.request import Request
    except ImportError:
        from urllib2 import Request
    # Variables
    r_0 = Request('http://example.com')
    r_0.options = 'value'
    # Assertions
    assert r_0.options == 'value', "r_0.options = 'value'; r_0.options was not modified."
    return None


# Generated at 2022-06-25 01:53:26.996009
# Unit test for method delete of class Request
def test_Request_delete():
    custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()
    http_connection_0 = HTTPConnection()
    # Check that the custom HTTPS handler is indeed used
    http_response_0 = http_connection_0.delete('https://fake')
    assert isinstance(http_response_0, http_modules.HTTPResponse)
    # Check that the custom HTTPS handler is indeed used
    # Check that the custom HTTPS handler is indeed used
    http_response_1 = http_connection_0.delete('https://fake')
    assert isinstance(http_response_1, http_modules.HTTPResponse)


# Generated at 2022-06-25 01:53:28.861618
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    pass
    #CustomHTTPSHandler(cert_file=None, key_file=None, context=None, unix_socket=None)
    #custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()



# Generated at 2022-06-25 01:53:32.473103
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    custom_h_t_t_p_s_handler_0 = SSLValidationHandler(
        hostname='',
        port=80,
    )
    # Return type is a tuple
    test_ca_certs = custom_h_t_t_p_s_handler_0.get_ca_certs()
    assert type(test_ca_certs) == tuple
    # First return path should be a string
    assert type(test_ca_certs[0]) == str


# Generated at 2022-06-25 01:53:34.654953
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    ssl_validation_handler_0 = SSLValidationHandler(hostname="hostname_0", port=80)
    url = "http://www.example.com/"
    assert ssl_validation_handler_0.detect_no_proxy(url) is False


# Generated at 2022-06-25 01:53:41.633923
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url_0 = 'http://10.172.42.42:8200/v1/secret/web/login/admin'
    validate_certs_0 = True
    ca_path_0 = None
    maybe_add_ssl_handler(url_0, validate_certs_0, ca_path_0)
    ####
    url_1 = 'http://10.172.42.42:8200/v1/secret/web/login/admin'
    validate_certs_1 = False
    ca_path_1 = None
    maybe_add_ssl_handler(url_1, validate_certs_1, ca_path_1)
    ####
    url_2 = 'http://10.172.42.42:8200/v1/secret/web/login/admin'
    validate_certs_

# Generated at 2022-06-25 01:53:48.148746
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_h_t_t_p_s_connection_0 = UnixHTTPSConnection('/tmp/etc-http-service-status')
    unix_h_t_t_p_s_connection_0('unix', 'service_status')


# Generated at 2022-06-25 01:53:57.903493
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection('host', 123)
    custom_h_t_t_p_s_connection_0.cert_file = 'cert_file'
    custom_h_t_t_p_s_connection_0.host = 'host'
    custom_h_t_t_p_s_connection_0.key_file = 'key_file'
    custom_h_t_t_p_s_connection_0.port = 123
    custom_h_t_t_p_s_connection_0.timeout = 5
    custom_h_t_t_p_s_connection_0.sock = mock.Mock()


# Generated at 2022-06-25 01:54:05.539206
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    try:
        assert rfc2822_date_string(time.localtime()) == time.strftime('%a, %d %b %Y %H:%M:%S -0000', time.localtime())
    except AssertionError:
        raise AssertionError('Failed to run unit test for function rfc2822_date_string')


# Generated at 2022-06-25 01:55:15.374000
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    assert callable(CustomHTTPSConnection.connect)


# Generated at 2022-06-25 01:55:19.715270
# Unit test for function fetch_url
def test_fetch_url():

    dict_0 = dict()
    str_0 = '/l+c0fM<6~H+C`_'
    dict_0[str_0] = str_0
    dict_0['url'] = str_0
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts'][str_0] = str_0
    dict_0['msg'] = str_0
    dict_0['status'] = int_0
    dict_1 = dict()
    str_1 = 'jr:c%@z(Jb!x+'
    dict_1[str_0] = str_1
    dict_1[str_1] = str_1
    dict_1['ansible_facts'] = dict()

# Generated at 2022-06-25 01:55:21.938515
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    obj_0 = SSLValidationHandler('foo.example.com',443)
    str_0 = 'https://foo.example.com/'
    var_0 = obj_0.detect_no_proxy(str_0)


# Generated at 2022-06-25 01:55:27.910893
# Unit test for function fetch_url
def test_fetch_url():
    print("testing fetch_url")

    # For testing module I used a local web server
    # listening in port 8000, without ssl and without
    # basic auth (containing only a 'index.html' file)
    # this is not a real test (should check the content
    # of the returned object, but at least we are testing
    # the code flow.

    # To test
    module = AnsibleModule(argument_spec=url_argument_spec())
    response, info = fetch_url(module,
                                "http://localhost:8000/index.html",
                                data="",
                                headers=dict(Content_type="aplication/x-www-form-urlencoded"),
                                method="POST")
    assert response != None
    assert info['status'] == 200


# Generated at 2022-06-25 01:55:34.763566
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    if CustomHTTPSConnection:
        test_case_0()

if HAS_SSL and HAS_URLLIB3:
    try:
        from urllib3.connectionpool import HTTPSConnectionPool, HTTPS_PORT
    except ImportError:
        # This is likely because we are on Python 2.6 which doesn't have urllib3
        # Import urllib3's ssl_wrap_socket as it contains the fixes to allow
        # cert validation on Python < 2.7.9
        from urllib3.contrib.pyopenssl import ssl_wrap_socket
    else:
        connect = CustomHTTPSConnection.connect

# Generated at 2022-06-25 01:55:39.498765
# Unit test for function atexit_remove_file
def test_atexit_remove_file():

    with open('random_file.txt', 'w') as f:
        f.write('Unit test for function atexit_remove_file')

    atexit_remove_file('random_file.txt')
    if os.path.exists('random_file.txt'):
        raise RuntimeError('atexit_remove_file not working properly')


# Generated at 2022-06-25 01:55:43.009535
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    test_obj = SSLValidationHandler('127.0.0.1', '22')
    var_0 = test_obj.make_context(None, None)


# Generated at 2022-06-25 01:55:48.166339
# Unit test for method options of class Request
def test_Request_options():
    test_params = [
        (5,),
        (5,),
        (5,),
    ]

    for test_param in test_params:
        yield test_Request_options, test_param


# Generated at 2022-06-25 01:55:54.173807
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Set up test data
    data = {
        'user': 'admin',
        'password': 'Admin123',
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        }
    }

    # Execute function
    result = prepare_multipart(data)

    # Check result

# Generated at 2022-06-25 01:55:56.046869
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    atexit_remove_file('')


# Generated at 2022-06-25 01:58:11.542037
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    seed = "test"
    expected = "$ansible_cbc$BlL6QOyOIlORr5r5WfLO8HHvQ2hLLdZa4Py4Wp8mURY="
    returned = get_channel_binding_cert_hash(b_DUMMY_CERT)
    assert(expected == _base64_encode(bytearray(binascii.a2b_hex(returned))))



# Generated at 2022-06-25 01:58:15.905544
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''Test for RedirectHandlerFactory'''
    str_0 = 'xX_2l" j!^>$C-p52y'
    var_0 = RedirectHandlerFactory(str_0)


if __name__ == '__main__':
    import logging
    import pprint
    logger = logging.getLogger()
    logger.level = logging.DEBUG
    logger.addHandler(logging.StreamHandler())
    test_case_0()
    test_RedirectHandlerFactory()

# Generated at 2022-06-25 01:58:22.095178
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    str_0 = 'xX_2l" j!^>$C-p52y'
    assert urllib_parse.urlparse(str_0) != generic_urlparse(str_0)
    # the generic version is more relaxed and accepts more
    assert urllib_parse.urlparse(str_0) == generic_urlparse(str_0, relaxed=True)


# Generated at 2022-06-25 01:58:24.468820
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    str_0 = 'U*'
    open(str_0, 'w').write(str_0)
    var_0 = os.path.exists(str_0)
    atexit_remove_file(str_0)
    var_1 = os.path.exists(str_0)
    assert(var_0 != var_1)
    assert(var_1 != True)


# Generated at 2022-06-25 01:58:29.244791
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    filename = 'user_input'
    # remove the file if it exists
    atexit_remove_file(filename)
    if not os.path.exists(filename):
        atexit_remove_file(filename)
    else:
        file = open(filename, 'w')
        file.write("remove me please")
        file.close()
        atexit_remove_file(filename)
        if os.path.exists(filename):
            file = open(filename, 'w')
            file.write("remove me please")
            file.close()
            atexit_remove_file(filename)
            if os.path.exists(filename):
                # remove the file if it exists
                atexit_remove_file(filename)



# Generated at 2022-06-25 01:58:40.419282
# Unit test for function generic_urlparse
def test_generic_urlparse():
    print('Testing function generic_urlparse()')

    str_0 = 'xX_2l" j!^>$C-p52y'
    var_0 = generic_urlparse(str_0)

    # Test case 0
    print('Test case 0')
    print('Expected:')
    print('{}')
    print('Got:')
    print(var_0)
    assert var_0 == {}, 'Test case 0: Failed'
    print('Passed\n')

    list_0 = [2, 3, 4]
    int_0 = len(list_0)
    str_1 = '%c %c %c %c'

# Generated at 2022-06-25 01:58:43.825857
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    url = "http://httpbin.org/get"
    try:
        r, info = fetch_url(module, url, force=True)
    except Exception as e:
        r, info = None, None


# Generated at 2022-06-25 01:58:50.075688
# Unit test for function fetch_url
def test_fetch_url():
    url = 'http://example.com/'
    data = {'RAW_STR' : 'test'}
    headers = {'Content-type' : 'application/json'}
    method = 'POST'
    force = False
    last_mod_time = ''
    timeout = 10
    use_gssapi = False
    unix_socket = ''
    cookies = {}
    unredirected_headers = []

    resp, info = fetch_url(url, data=data, headers=headers, method=method,
                  force=force, last_mod_time=last_mod_time, timeout=timeout,
                  use_gssapi=use_gssapi, unix_socket=unix_socket, cookies=cookies,
                  unredirected_headers=unredirected_headers)



# Generated at 2022-06-25 01:58:58.372873
# Unit test for function fetch_url
def test_fetch_url():
    url = 'http://www.baidu.com/'
    data = None
    headers = {'Accept-Language': 'en-US'}
    method = 'GET'
    use_proxy = True
    force = False
    last_mod_time = None
    timeout = 10
    use_gssapi = False
    unix_socket = None
    ca_path = None
    cookies = None
    unredirected_headers = None

# Generated at 2022-06-25 01:59:04.316076
# Unit test for method delete of class Request
def test_Request_delete():
    import unittest
    from sys import stderr

    class TestRequestDelete(unittest.TestCase):
        def test_Request_delete(self):
            result = False

            # Test for the following case:
            # The client provides data in a wrong type, the server can not
            # process the data and return an error response.