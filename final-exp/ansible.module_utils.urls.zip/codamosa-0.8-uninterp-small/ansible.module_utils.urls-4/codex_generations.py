

# Generated at 2022-06-25 01:53:51.290089
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'google.com'
    port = '80'
    paths = ['path1/path2']
    exc = 'no_exception'
    ssl_validation_error_0 = build_ssl_validation_error(hostname, port, paths, exc)
    print(ssl_validation_error_0)


# Generated at 2022-06-25 01:54:01.871962
# Unit test for function fetch_url
def test_fetch_url():
    args = dict(
        module=dict(type='dict'),
        url=dict(type='str'),
        data=dict(type='str'),
        headers=dict(type='dict'),
        method=dict(type='str'),
        use_proxy=dict(type='bool'),
        force=dict(type='bool'),
        last_mod_time=dict(type='str'),
        timeout=dict(type='int'),
        use_gssapi=dict(type='bool'),
        unix_socket=dict(type='str'),
        ca_path=dict(type='str'),
        cookies=dict(type='dict'),
        unredirected_headers=dict(type='list'),
    )


# Generated at 2022-06-25 01:54:03.187970
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    try:
        test_case_0()
        test_case_res = True
    except Exception:
        test_case_res = False
    assert test_case_res



# Generated at 2022-06-25 01:54:07.183568
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test different value of follow_redirects
    assert issubclass(RedirectHandlerFactory('no').__class__, urllib_request.HTTPRedirectHandler)
    assert issubclass(RedirectHandlerFactory('no').__class__, RedirectHandlerFactory)
    assert issubclass(RedirectHandlerFactory('no').__class__, RedirectHandlerFactory('yes').__class__)
    assert issubclass(RedirectHandlerFactory('yes').__class__, RedirectHandlerFactory('no').__class__)


# Generated at 2022-06-25 01:54:16.791521
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    no_s_s_l_error_0 = NoSSLError()
    custom_https_connection_0 = CustomHTTPSConnection('')
    assertRaises(no_s_s_l_error_0, custom_https_connection_0.connect)

if CustomHTTPSConnection:
    # We need to also patch urllib2/urllib.request to use the new class to
    # ensure that we are also using it when using urlopen()
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self):
            urllib_request.HTTPSHandler.__init__(self)

        def https_open(self, req):
            return self.do_open(self.getConnection, req)


# Generated at 2022-06-25 01:54:18.514036
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    assert get_channel_binding_cert_hash(b"") is not None

if __name__ == '__main__':
    test_case_0()
    # Unit test for function get_channel_binding_cert_hash
    test_get_channel_binding_cert_hash()

# Generated at 2022-06-25 01:54:28.643132
# Unit test for function fetch_url
def test_fetch_url():
    # Fixtures
    monkeypatch.setattr(http_get_url, 'open_url', lambda url, data=None, headers=None, method=None, use_proxy=True, force=False, last_mod_time=None, timeout=10, validate_certs=True, url_username=None, url_password=None, http_agent=None, force_basic_auth=None, follow_redirects=True, client_cert=None, client_key=None, cookies=None, use_gssapi=False, unix_socket=None, ca_path=None, unredirected_headers=None: None)
    monkeypatch.setattr(http_get_url, 'to_native', lambda data, errors='surrogate_or_strict': data)

# Generated at 2022-06-25 01:54:29.861056
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    h = CustomHTTPSHandler()
    return h


# Generated at 2022-06-25 01:54:38.777447
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    tmp_time_tuple = time.localtime()
    tmp_time_tuple_0 = time.localtime((time.time() + (3600 * 24)))
    tmp_zone = '-0000'
    # Test return type, should be a string
    assert isinstance(rfc2822_date_string(tmp_time_tuple, tmp_zone), str)
    # Test return value
    assert rfc2822_date_string(tmp_time_tuple_0, tmp_zone)[0:3] == 'Sat'


# Generated at 2022-06-25 01:54:48.139171
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        'text_form_field': 'value',
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream',
        },
        'file2': {
            'content': b'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        },
    }


# Generated at 2022-06-25 01:55:36.136518
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    assert_raises(ValueError, CustomHTTPSHandler, debuglevel=1, use_proxy=1)
    assert_raises(TypeError, CustomHTTPSHandler, debuglevel=1, key_file=1)
    assert_raises(TypeError, CustomHTTPSHandler, debuglevel=1, cert_file=1)
    assert_raises(ValueError, CustomHTTPSHandler, debuglevel=1, use_proxy=1, key_file=1, cert_file=1)
    custom_https_handler.CustomHTTPSHandler(debuglevel=1, use_proxy=1, key_file=1, cert_file=1)


# Generated at 2022-06-25 01:55:43.982853
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    global ssl_handle
    # Initalize the class
    ssl_handle = SSLValidationHandler('10.10.10.10', 443)

    global ca_cert_path
    # Get ca cert path
    ca_cert_path, cadata, paths_checked = ssl_handle.get_ca_certs()


# Generated at 2022-06-25 01:55:54.758138
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import json
    import mock
    import StringIO
    import sys
    import tempfile
    import types

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass


# Generated at 2022-06-25 01:55:56.768030
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    test_input = 'hostname'
    try:
        test_instance = CustomHTTPSHandler()
        test_output = test_instance._tunnel_host
    except Exception:
        test_output = None
    assert test_input == test_output


# Generated at 2022-06-25 01:55:58.314220
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    new_CustomHTTPSConnection = CustomHTTPSConnection(
        # No args
    )
    return


# Generated at 2022-06-25 01:56:00.316998
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    # Create temp file
    temp_file = tempfile.NamedTemporaryFile()
    atexit_remove_file(temp_file.name)


# Generated at 2022-06-25 01:56:11.494351
# Unit test for function generic_urlparse
def test_generic_urlparse():
    from ansible.compat.tests import unittest
    import urlparse

    class TestGenericUrlParse(unittest.TestCase):
        def test_py26_parse(self):
            parts = urlparse.urlparse('http://foo:bar@127.0.0.1:8080/foo')
            # parts.scheme won't exist on Py2.6, so we have to verify the output
            # by using the list of values
            parsed_parts = generic_urlparse(parts).as_list()
            self.assertEqual(parsed_parts, [
                'http',
                'foo:bar@127.0.0.1:8080',
                '/foo',
                '',
                '',
                ''
            ])

        def test_py27_parse(self):
            parts = urlparse

# Generated at 2022-06-25 01:56:20.387444
# Unit test for method http_request of class SSLValidationHandler

# Generated at 2022-06-25 01:56:22.276008
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    """
    This tests the main function of classes.
    """
    # Create an object of class UnixHTTPConnection
    unix_http_connection_0 = UnixHTTPConnection(unix_socket='/tmp/foo')



# Generated at 2022-06-25 01:56:30.103078
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    timetuple = (2012, 2, 22, 22, 22, 22, 3)
    zone = '-0200'
    ans = 'Wed, 22 Feb 2012 22:22:22 -0200'
    assert rfc2822_date_string(timetuple, zone) == ans
    timetuple = (2012, 2, 22, 22, 22, 22, 3)
    zone = '-0000'
    ans = 'Wed, 22 Feb 2012 22:22:22 -0000'
    assert rfc2822_date_string(timetuple, zone) == ans
    timetuple = (2012, 2, 22, 22, 22, 22, 3)
    zone = '+0200'
    ans = 'Wed, 22 Feb 2012 22:22:22 +0200'
    assert rfc2822_date_string(timetuple, zone) == ans
   

# Generated at 2022-06-25 01:57:20.766952
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test variables
    follow_redirects = False
    validate_certs = True
    ca_path = None

    RedirectHandlerFactory(follow_redirects, validate_certs, ca_path=ca_path)


# Generated at 2022-06-25 01:57:21.667150
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    http_handler_0 = CustomHTTPSHandler()


# Generated at 2022-06-25 01:57:28.231064
# Unit test for function fetch_url
def test_fetch_url():
    fetch_url(module=AnsibleModule(argument_spec={}), 
    url='https://www.google.com',
    data=None, 
    headers={"Host": "www.google.com", "User-Agent": "curl/7.35.0", "Accept": "*/*"}, 
    method="GET", 
    use_proxy=None,
    force=False, 
    last_mod_time=None, 
    timeout=10, 
    use_gssapi=False, 
    unix_socket=None,
    ca_path=None, 
    cookies=None, 
    unredirected_headers=None)
    


# Generated at 2022-06-25 01:57:33.125690
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():

    try:
        import_module('urllib_request')
    except ImportError:
        pytest.skip('Test requires urllib_request')

    handler = CustomHTTPSHandler()
    assert handler.https_request is AbstractHTTPHandler.do_request_
    return



# Generated at 2022-06-25 01:57:41.682161
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    tmp_ca_cert_path, cadata, paths_checked = SSLValidationHandler("localhost", 443).get_ca_certs()
    cafile = tmp_ca_cert_path
    cadata = None
    context = create_default_context(cafile=cafile)
    context.load_verify_locations(cafile=cafile, cadata=cadata)
    try:
        s = socket.create_connection(("localhost", 443))
        ssl_s = context.wrap_socket(s, server_hostname="localhost")
        s.close()
    except Exception as e:
        build_ssl_validation_error("localhost", 443, paths_checked, e)


# Generated at 2022-06-25 01:57:45.761194
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Check that the correct CA list is returned for the current platform
    handler = SSLValidationHandler('127.0.0.1', 443)
    paths_checked, go_paths = [], []
    ca_cert_path, cadata, paths_checked = handler.get_ca_certs()
    assert len(paths_checked) > 0


# Generated at 2022-06-25 01:57:55.422535
# Unit test for function fetch_file
def test_fetch_file():
    # fake ansible module data
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.tmpdir = "/fake/tmpdir"
            self.fail_json = lambda self, msg: 1/0
            self.add_cleanup_file = lambda self, arg: None

    # fake url object that returns an error code
    class FakeUrlError:
        def __init__(self, *args):
            pass
        def rs_split(self):
            return ["", "fake_error_code"]

    # url with no error code
    url = "www.google.com"

    # test with error code in url
    module = FakeModule()
    try:
        fetch_file(module, FakeUrlError())
    except ZeroDivisionError:
        pass
    else:
        return False

# Generated at 2022-06-25 01:58:01.250011
# Unit test for function generic_urlparse
def test_generic_urlparse():
    """Test that generic_urlparse works on all supported python versions"""
    # pylint: disable=unused-variable

# Generated at 2022-06-25 01:58:08.600198
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    obj = CustomHTTPSConnection()
    assert obj.__class__.__name__ == 'CustomHTTPSConnection'

if hasattr(ssl, 'PROTOCOL_SSLv23'):
    PROTOCOL = ssl.PROTOCOL_SSLv23
else:
    PROTOCOL = ssl.PROTOCOL_TLSv1



# Generated at 2022-06-25 01:58:11.335838
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url_0 = "http://github.com"
    assert maybe_add_ssl_handler(url_0, False) is None

    url_0 = "https://github.com"
    assert isinstance(maybe_add_ssl_handler(url_0, True), SSLValidationHandler) is True

    url_0 = "http://github.com"
    assert maybe_add_ssl_handler(url_0, False) is None

