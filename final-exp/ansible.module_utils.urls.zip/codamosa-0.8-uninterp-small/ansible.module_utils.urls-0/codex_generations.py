

# Generated at 2022-06-25 01:52:08.815850
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    obj = CustomHTTPSConnection()


# Generated at 2022-06-25 01:52:11.957621
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    args = None
    kwargs = {'follow_redirects': None, 'validate_certs': True, 'ca_path': None}
    RedirectHandlerFactory(*args, **kwargs)


# Generated at 2022-06-25 01:52:23.413218
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    if not HAS_SSLCONTEXT:
        return unittest.skip('Skipping SSLValidationHandler.validate_proxy_response test for python < 2.7.9')
    # Verify the jinja2 import and load of the mock_dwim_vars dict
    proxy_url = 'https://proxy.com:443'
    valid_codes = [200]
    handler = SSLValidationHandler('test.com', '443', ca_path=proxy_url)
    handler.validate_proxy_response(b'HTTP/1.0 200 Ok', valid_codes)
    # Verify the jinja2 import and load of the mock_dwim_vars dict
    proxy_url = 'https://proxy.com:443'
    valid_codes = [301]

# Generated at 2022-06-25 01:52:29.401224
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    parse_result_dotted_dict_0 = ParseResultDottedDict()
    request_with_method_0 = RequestWithMethod('', 'GET')
    request_with_method_0.get_method()


# Generated at 2022-06-25 01:52:38.869424
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    with open(DEFAULT_CA_BUNDLE_PATH, 'rb') as f:
        certificate_der = f.read()
    test_hash = get_channel_binding_cert_hash(certificate_der)
    expected_hash = b"\x8A\xEB\xA2\x84,\x1F\x88\x83:S\xE4o\x814\xA4\xD4\x1E;\xDE\xF3\xBAU\xC3\x8F\xC9ts\xB2\xE0\xAD\xC2\xD2\xE8\x04\xB6\xD7"
    assert test_hash == expected_hash

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:52:40.285010
# Unit test for function prepare_multipart
def test_prepare_multipart():
    test_prepare_multipart_0()


# Generated at 2022-06-25 01:52:42.728415
# Unit test for function atexit_remove_file
def test_atexit_remove_file():

    # Create a dummy file
    filename = tempfile.mktemp()
    open(filename, 'w')
    
    assert os.path.exists(filename)
    atexit_remove_file(filename)
    
    assert not os.path.exists(filename)


# Generated at 2022-06-25 01:52:49.363191
# Unit test for function fetch_url
def test_fetch_url():
    # test_case_0
    headers = {'X-Terraform-Version': '0.12.24'}
    r, info = fetch_url('ansible', 'https://api.github.com/repos/hashicorp/terraform/releases/latest')
    assert info['status'] == 200
#   print(r.read())


# Generated at 2022-06-25 01:52:49.935635
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    test_case_0()


# Generated at 2022-06-25 01:52:52.260513
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    req_0 = CustomHTTPSHandler().https_request(req=None)


# Generated at 2022-06-25 01:53:40.734981
# Unit test for constructor of class Request
def test_Request():
    url = 'http://foo.bar/path?query=val'
    method = 'POST'
    data = 'data'
    # Testing __init__() of class Request
    test_Request_0 = RequestWithMethod(url, method, data)
    url = 'http://foo.bar/path?query=val'
    method = 'POST'
    data = 'data'
    # Testing __init__() of class Request
    test_Request_1 = RequestWithMethod(url, method, data)


# Generated at 2022-06-25 01:53:44.251326
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    handler = CustomHTTPSHandler(
            debuglevel=1,
            check_hostname=True,
            ca_certs=b_DUMMY_CA_CERT,
            context=ssl._create_unverified_context,
        )


# Generated at 2022-06-25 01:53:51.183876
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    unix_socket_url_0 = 'https://test_url.com'
    test_UnHTTPSConn = UnixHTTPSConnection(unix_socket_url_0)
    # Call the connect method of class UnixHTTPSConnection
    test_UnHTTPSConn.connect()
    return test_UnHTTPSConn


# Generated at 2022-06-25 01:54:00.605870
# Unit test for function fetch_url
def test_fetch_url():
    params = dict(url='https://www.google.com',
                  use_proxy=True,
                  validate_certs=True,
                  url_username='username',
                  url_password='password',
                  force_basic_auth=False,
                  follow_redirects='urllib2',
                  client_cert=None,
                  client_key=None,
                  use_gssapi=True)

    module = AnsibleModule(argument_spec=url_argument_spec(), supports_check_mode=True)
    # The url and use_proxy is provided in argument_spec
    module.params.update(
        dict(url='https://www.google.com',
             use_proxy=True)
    )

    # Load param values into params
    params = load_params(module, params)

    print('')
   

# Generated at 2022-06-25 01:54:02.105021
# Unit test for constructor of class Request
def test_Request():
    # test default constructor of class Request
    req = Request('GET', 'https://www.google.com/')
    assert req.method == 'GET'
    assert req.url == 'https://www.google.com/'

# Generated at 2022-06-25 01:54:04.661420
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_https_connection_0 = UnixHTTPSConnection(u'', 1024)
    try:
        unix_https_connection_0(u'', u'', 1024)
    except:
        raise Exception()



# Generated at 2022-06-25 01:54:07.684764
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    test_handler_0 = SSLValidationHandler(hostname="test_hostname_0", port=22)
    test_handler_0.make_context(cafile="test_cafile_0", cadata="test_cadata_0")


# Generated at 2022-06-25 01:54:09.148592
# Unit test for function fetch_file
def test_fetch_file():
    pass


# Generated at 2022-06-25 01:54:14.437287
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    method = SSLValidationHandler.get_ca_certs
    obj = SSLValidationHandler(hostname=None, port=None, ca_path=None)

    with pytest.raises(NotImplementedError):
        method(obj)


# Generated at 2022-06-25 01:54:22.647171
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    test_case_0()
    args = {
        'hostname': 'api.opsgenie.com',
        'key_file': None,
        'unix_socket': '/tmp/apihost.sock',
        'cert_file': None
    }

    cert_file = None
    key_file = None
    context = None

    try:
        CustomHTTPSConnection(**args)
    except Exception:
        pass
    try:
        HTTPSClientAuthHandler(**args)
    except Exception:
        pass

    unix_conn = UnixHTTPSConnection(**args)
    unix_conn(args['hostname'])
    unix_conn.connect()
    conn = unix_conn
    conn.sock = None



# Generated at 2022-06-25 01:57:24.805700
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_h_t_t_p_connection_0 = UnixHTTPConnection()
    unix_h_t_t_p_connection_0.connect()


# Generated at 2022-06-25 01:57:30.334157
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # Test for case where certificate_der is not provided
    # In this case we will have no valid certificate_der to use
    assert get_channel_binding_cert_hash(None) is None

    # Test for a valid certificate_der
    certificate_der = x509.load_der_x509_certificate(b_OPENSSL_CERTIFICATE, default_backend()).public_bytes(Encoding.DER)
    assert get_channel_binding_cert_hash(certificate_der) is not None

# Generated at 2022-06-25 01:57:40.274781
# Unit test for function fetch_url
def test_fetch_url():
    _formatted_json = {
        'json': [{'foo': 1, 'bar': 2}, 3],
        'other': 'stuff'}
    f = open('test.json', 'w')
    f.write(json.dumps(_formatted_json, indent=4))
    f.close()
    _formatted_json = {
        'json': [{'foo': 1, 'bar': 2}, 3],
        'other': 'stuff'}
    f = open('test.json', 'w')
    f.write(json.dumps(_formatted_json, indent=4))
    f.close()
    _formatted_json = {
        'json': [{'foo': 1, 'bar': 2}, 3],
        'other': 'stuff'}

# Generated at 2022-06-25 01:57:44.801402
# Unit test for function getpeercert
def test_getpeercert():
    # build expected_result
    expected_result = getpeercert(custom_h_t_t_p_s_connection_0, binary_form=False)

    # get actual_result
    actual_result = getpeercert(custom_h_t_t_p_s_connection_0, binary_form=False)

    # compare results
    assert actual_result == expected_result


# Generated at 2022-06-25 01:57:52.772176
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    if not HAS_SSLCONTEXT:
        pytest.skip("urllib_ssl_handler requires python >= 2.7.9")
    # test_case_0
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    custom_h_t_t_p_s_connection_0._hostname = 'other.host.name'
    custom_h_t_t_p_s_connection_0._port = 443
    custom_h_t_t_p_s_connection_0.ca_path = None
    custom_h_t_t_p_s_connection_0.validate_certs = True
    custom_h_t_t_p_s_connection_0.assert_hostname = True
    custom_h_t_t_p_s_

# Generated at 2022-06-25 01:58:03.226611
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule(argument_spec=dict(
        url=dict(required=True, type='str'),
        data=dict(type='str'),
        headers=dict(type='str'),
        method=dict(type='str'),
        use_proxy=dict(type='bool'),
        force=dict(type='bool'),
        last_mod_time=dict(type='str'),
        timeout=dict(type='int'),
        use_gssapi=dict(type='bool'),
        unix_socket=dict(type='str'),
        ca_path=dict(type='str'),
        cookies=dict(type='str'),
        unredirected_headers=dict(type='str')))
   
    url = get_param(module.params, 'url')

# Generated at 2022-06-25 01:58:12.418519
# Unit test for function fetch_url
def test_fetch_url():
    url = 'https://www.google.com/'
    data = b''
    headers = None
    method = None
    use_proxy = True
    force = False
    last_mod_time = None
    timeout = 10
    use_gssapi = False
    cookies = None
    unredirected_headers = None
    assert fetch_url(None, url, data, headers, method,
            use_proxy, force, last_mod_time, timeout,
            use_gssapi, None, None, cookies, unredirected_headers) == (None, {'status': -1})

# Generated at 2022-06-25 01:58:15.506479
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    try:
        custom_h_t_t_p_s_connection_0.connect()
    except TimeoutError:
        pass
    except (ConnectionRefusedError, OSError):
        pass
    except Exception:
        pass



# Generated at 2022-06-25 01:58:25.360110
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Instantiate mock object
    mock_obj = SSLValidationHandler('hostname_0', 80)
    # Invoke method
    result_0 = mock_obj.get_ca_certs()
    # Check for equality
    assert result_0 == ('', bytearray(b''), ['', '/etc/pki/ca-trust/extracted/pem', '/etc/pki/tls/certs', '/usr/share/ca-certificates/cacert.org', '/usr/local/share/certs', '/etc/ssl', '/etc/openssl/certs', '/opt/local/etc/openssl/certs', '/etc/ansible']), 'Incorrect return value for method get_ca_certs returned'


# Generated at 2022-06-25 01:58:28.372178
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    custom_ssl_validation_handler_0 = SSLValidationHandler('')
    assert custom_ssl_validation_handler_0.get_ca_certs() == (None, bytearray(b''), [])
