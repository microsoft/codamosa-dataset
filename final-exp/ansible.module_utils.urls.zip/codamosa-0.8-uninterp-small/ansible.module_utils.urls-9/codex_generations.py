

# Generated at 2022-06-25 01:54:54.384718
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    s_s_l_validation_handler_0 = SSLValidationHandler()
    tmp_ca_cert_path_0 = os.path.join(ANSIBLE_TEST_DATA_ROOT, u'/roles/invalid_module/library/test_data/invalid_cert.pem')
    # AssertionError: expected ssl.SSLError with message match 'certificate verify failed' not found
    with pytest.raises(AssertionError) as exc_info:
        s_s_l_validation_handler_0.make_context(tmp_ca_cert_path_0)
    assert match(
        'expected ssl.SSLError with message match \'certificate verify failed\' not found',
        exc_info.value.args[0]
    )


# Generated at 2022-06-25 01:54:58.682130
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    print('')
    s_s_l_validation_error_0 = SSLValidationError()
    custom_https_connection_0 = CustomHTTPSConnection('host', 'port', 'key_file', 'cert_file', 'strict', 'timeout', 'source_address')


# Generated at 2022-06-25 01:55:03.289002
# Unit test for function fetch_url
def test_fetch_url():
    """This will test the fetch_url function. Fetch
    URL will fetch a fact from the ansible server
    if validly supplied with the correct arguments.
    """
    # Fetch url validates the url with the 'validate_certs' parameter
    # If set to false, the url will fetch the results
    validate_certs = True
    url = 'www.test.com'
    s = fetch_url(url, validate_certs)
    # If the url is found, the status should be 200
    # If not found, the status code should be different
    if s.getcode() == 200:
        return True
    else:
        return False





# Generated at 2022-06-25 01:55:07.398959
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {'text_form_field': 'value'}
    ret = prepare_multipart(fields)
    assert ret[0] == 'multipart/form-data; boundary================2726991842175518220=='
    assert ret[1] == b'--===============2726991842175518220==\r\nContent-Disposition: form-data; name="text_form_field"\r\n\r\nvalue\r\n--===============2726991842175518220==--\r\n'


# Generated at 2022-06-25 01:55:11.899263
# Unit test for function generic_urlparse
def test_generic_urlparse():
    def test_0():
        parts_0 = urlparse("http://user:password@hostname:8080/path?query=value&query2=value2#fragment")
        generic_parts_0 = generic_urlparse(parts_0)
        assert generic_parts_0['scheme'] == "http"
        assert generic_parts_0['netloc'] == "user:password@hostname:8080"
        assert generic_parts_0['path'] == "/path"
        assert generic_parts_0['params'] == ""
        assert generic_parts_0['query'] == "query=value&query2=value2"
        assert generic_parts_0['fragment'] == "fragment"
        assert generic_parts_0['username'] == "user"

# Generated at 2022-06-25 01:55:16.124892
# Unit test for function fetch_url
def test_fetch_url():

    mock_module = Mock(spec_set=AnsibleModule)
    mock_module.fail_json.side_effect = Exception('fail_json')
    mock_module.params = {}
    mock_module.tmpdir = '/tmp'

    mock_urlparse = Mock(spec_set=urlparse)
    mock_urlparse.return_value = ['http', 'www.example.com', '/', '', '', '']

    mock_open_url_response = Mock(spec_set=object)
    mock_open_url_response.info.return_value = dict()

    mock_open_url_response.headers = dict()
    mock_open_url_response.headers['content-length'] = '10'
    mock_open_url_response.headers['content-type'] = 'text/plain'
    mock_open

# Generated at 2022-06-25 01:55:22.689626
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname_0 = 'example.com'
    port_0 = 1234
    tmp_ca_cert_path_0, cadata_0, paths_checked_0 = get_ca_certs(None)
    ca_path_0 = None
    new_ssl_validation_handler_0 = SSLValidationHandler(hostname_0, port_0, ca_path_0)
    ssl_validation_handler_0 = SSLValidationHandler(hostname_0, port_0, ca_path_0)
    origin_req_host_0 = None

# Generated at 2022-06-25 01:55:33.622634
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Check that an SSLValidationError is raised when the custom cert file is not found
    not_existant_cert_file = os.path.join(os.path.dirname(__file__), 'test_data', 'not_existant_cert')
    not_existant_key_file = os.path.join(os.path.dirname(__file__), 'test_data', 'not_existant_key')
    try:
        test_conn = CustomHTTPSConnection("localhost", 12345, not_existant_cert_file, not_existant_key_file)
        test_conn.connect()
    except SSLValidationError as e:
        assert "No such file or directory" in str(e), "The exception does not contain the expected message!"

# Generated at 2022-06-25 01:55:40.466941
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    import base64

    # Generate the test certificate
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=1024,
        backend=default_backend()
    )

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"US"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"California"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"San Francisco"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"My Company"),
        x509.NameAttribute(NameOID.COMMON_NAME, u"mysite.com"),
    ])

    cert = x509.CertificateBuilder

# Generated at 2022-06-25 01:55:42.522584
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    pass


# Generated at 2022-06-25 01:57:26.893462
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        assert True


# Generated at 2022-06-25 01:57:35.941353
# Unit test for function fetch_file
def test_fetch_file():
    url = 'https://raw.githubusercontent.com/' + \
        'ansible/ansible/devel/lib/ansible/module_utils/urls.py'
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ansible.module_utils.basic.AnsibleModule = AnsibleModule
    ansible.module_utils.urls.AnsibleModule = AnsibleModule
    ansible.module_utils.urls.to_native = to_native
    ansible.module_utils.urls.fetch_url = fetch_url
    ansible.module_utils.urls.open_url = open_url
    ansible.module_utils.urls.fetch_file = fetch_file
    ansible.module_utils.urls.test_case_0 = test

# Generated at 2022-06-25 01:57:37.712361
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_http_conn = UnixHTTPConnection('foo')
    unix_http_conn.connect()


# Generated at 2022-06-25 01:57:40.577144
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    follow_redirects_0 = ''
    validate_certs_0 = False
    ca_path_0 = ''
    redirect_handler_factory_1 = RedirectHandlerFactory(follow_redirects_0, validate_certs_0, ca_path_0)
    assert redirect_handler_factory_1 is not None


# Generated at 2022-06-25 01:57:43.721168
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    dict_0 = {}
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection(**dict_0)
    custom_h_t_t_p_s_connection_0.validate_proxy_response(custom_h_t_t_p_s_connection_0)



# Generated at 2022-06-25 01:57:54.109301
# Unit test for function generic_urlparse
def test_generic_urlparse():
    dict_0 = {}
    dict_0['scheme'] = 'http'
    dict_0['netloc'] = '192.168.0.61'
    dict_0['path'] = '/v1/nodes/M4:00:50:42:FC:C1/catalog/service/redis'
    dict_0['params'] = ''
    dict_0['query'] = ''
    dict_0['fragment'] = ''
    dict_0['username'] = ''
    dict_0['password'] = ''
    dict_0['hostname'] = '192.168.0.61'
    dict_0['port'] = None
    parse_result = generic_urlparse(dict_0)
    assert parse_result.scheme == 'http'

# Generated at 2022-06-25 01:57:59.565569
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    ssl_validation_handler_0 = SSLValidationHandler('www.cnn.com', 443)
    urllib_request_0 = urllib_request.Request('http://www.cnn.com/')
    ssl_validation_handler_0.http_request(urllib_request_0)


# Generated at 2022-06-25 01:58:01.938206
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    url = "http://www.example.com/test"
    method = "POST"
    request_with_method_0 = RequestWithMethod(url, method)
    method = request_with_method_0.get_method()



# Generated at 2022-06-25 01:58:05.781677
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = "http://www.google.com/test/test.html"
    ca_path = "./test.pem"
    validate_certs = True
    maybe_add_ssl_handler(url, validate_certs, ca_path)

if __name__ == "__main__":
    url = "http://www.google.com:443"
    maybe_add_ssl_handler(url, True)

# Generated at 2022-06-25 01:58:09.414618
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    dict_0 = {}
    SSLValidationHandler_0 = SSLValidationHandler(**dict_0)

    SSLValidationHandler_0.get_ca_certs()


# Generated at 2022-06-25 01:58:51.827846
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    timetuple = (2000, 1, 1, 1, 1, 1, 1)
    zone = "-0000"
    assert rfc2822_date_string(timetuple, zone) == 'Sun, 01 Jan 2000 01:01:01 -0000'


# Generated at 2022-06-25 01:58:57.134565
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Create some parameters.
    url = 'http://localhost:8080'
    validate_certs = False
    ca_path = None
    # Call the method.
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)
    maybe_add_ssl_handler(url, validate_certs, ca_path)

# Generated at 2022-06-25 01:59:02.402801
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    timetuple_0 = (2017, 1, 3, 0, 0, 0, 1)
    zone_0 = '-0000'
    timetuple_1 = (2017, 1, 3, 0, 0, 0, 1)
    zone_1 = '-0000'
    timetuple_2 = (2017, 1, 3, 0, 0, 0, 1)
    zone_2 = '-0000'
    timetuple_3 = (2017, 1, 3, 0, 0, 0, 1)
    zone_3 = '-0000'
    timetuple_4 = (2017, 1, 3, 0, 0, 0, 1)
    zone_4 = '-0000'


# Generated at 2022-06-25 01:59:04.852726
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    dict_0 = {}
    s_s_l_validation_handler_0 = SSLValidationHandler(**dict_0)
    s_s_l_validation_handler_0.get_ca_certs()


# Generated at 2022-06-25 01:59:07.332586
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Create a RedirectHandler instance
    handler = RedirectHandlerFactory()
    assert isinstance(handler, RedirectHandlerFactory.RedirectHandler)

if __name__ == "__main__":
    test_case_0()
    test_RedirectHandlerFactory()