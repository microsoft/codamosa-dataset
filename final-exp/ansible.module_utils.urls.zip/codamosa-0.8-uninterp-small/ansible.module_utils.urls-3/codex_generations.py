

# Generated at 2022-06-25 01:52:20.050388
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    capath = 'ca.pem'
    s_v_h_0 = SSLValidationHandler('hostname', 443, capath)
    r_w_m_0 = RequestWithMethod('https://hostname:443/')
    try:
        s_v_h_0.http_request(r_w_m_0)
    except ProxyError:
        pass

test_cases = [
        test_case_0,
        test_SSLValidationHandler_http_request,
        ]


# Generated at 2022-06-25 01:52:27.361931
# Unit test for function fetch_file

# Generated at 2022-06-25 01:52:37.345494
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():

    timetuple = (2001, 11, 9, 1, 8, 47, 4, 313, 0)
    zone = "-0000"
    assert rfc2822_date_string(timetuple, zone) == 'Fri, 09 Nov 2001 01:08:47 -0000'

# Create test cases for function rfc2822_date_string
test_cases_rfc2822_date_string = [
    {
        'test_name': 'test_case_0',
        'timetuple': (2001, 11, 9, 1, 8, 47, 4, 313, 0),
        'zone': "-0000",
        'expected_result': 'Fri, 09 Nov 2001 01:08:47 -0000'
    }
]

# Run test cases for function rfc2822_date_string

# Generated at 2022-06-25 01:52:44.826368
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule({'url': 'http://127.0.0.1:22/hello.html', 'timeout': 20}, supports_check_mode=True)
    response, info = fetch_url(module, 'http://127.0.0.1:22/hello.html', timeout=20)
    assert response is not None
    assert info is not None

# Generated at 2022-06-25 01:52:47.182407
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    channel_binding_cert_hash_0 = to_bytes(get_channel_binding_cert_hash(b'certificate_der_0'))
    channel_binding_cert_hash_1 = get_channel_binding_cert_hash(b'certificate_der_1')
    assert channel_binding_cert_hash_0 == channel_binding_cert_hash_1


# Generated at 2022-06-25 01:52:50.702175
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    test_test = 'test'
    my_ssl_validation_handler = SSLValidationHandler(test_test, test_test)
    my_url = 'my_url'
    my_flag = my_ssl_validation_handler.detect_no_proxy(my_url)
    # test return value
    print('Test test_SSLValidationHandler_detect_no_proxy:')
    print('Return value: ' + str(my_flag))


# Generated at 2022-06-25 01:53:00.238787
# Unit test for function fetch_url
def test_fetch_url():
    test_module = AnsibleModule({})

    test_url = 'http://example.com'
    test_data = None
    test_headers = None
    test_method = None
    test_use_proxy = True
    test_force = False
    test_last_mod_time = None
    test_timeout = 10
    test_use_gssapi = False
    test_unix_socket = None
    test_ca_path = None
    test_cookies = None
    test_unredirected_headers = None

# Generated at 2022-06-25 01:53:03.786844
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    ssl_validation_handler = SSLValidationHandler(None, None)
    url = "<url>"
    result = ssl_validation_handler.detect_no_proxy(url)

    assert isinstance(result, bool)


# Generated at 2022-06-25 01:53:15.626185
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    filename = "/tmp/testfile"
    open(filename, "a").close()
    
    testobj = atexit_remove_file(filename)
    assert True

if __name__ == '__main__':
    import sys
    import __main__
    
    from ansible.module_utils.basic import *


# Generated at 2022-06-25 01:53:22.379046
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()

    # Act

    delattr(h_t_t_p_s_client_auth_handler_0, 'sock')
    try:
        h_t_t_p_s_client_auth_handler_0.connect()
    except:
        # Assert
        # Divergence: Py3 raises an AttributeError
        if sys.version_info < (3,):
            assert isinstance(sys.exc_info()[1], socket.error)
        else:
            assert isinstance(sys.exc_info()[1], AttributeError)
    else:
        # Assert
        assert False


    # Act


# Generated at 2022-06-25 01:54:07.972890
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    h_t_t_p_s_client_auth_handler_0 = SSLValidationHandler("c.s.com", 80, "ocsp_fetch_url")
    h_t_t_p_s_client_auth_handler_0.make_context("c.s.com", "c.s.com")


# Generated at 2022-06-25 01:54:09.141802
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn_obj_0 = CustomHTTPSConnection()
    conn_sock_0 = sock_0()
    conn_obj_0.connect()



# Generated at 2022-06-25 01:54:15.293322
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule(argument_spec={'url': {'type': 'str'}, 'data': {'type': 'str'}, 'headers': {'type': 'dict'}, 'method': {'type': 'str'}, 'use_proxy': {'type': 'bool', 'default': True}, 'force': {'type': 'bool', 'default': False}, 'last_mod_time': {'type': 'str'}, 'timeout': {'type': 'int', 'default': 10}, 'unredirected_headers': {'type': 'list', 'default': None}})
    fetch_file(module)


# Generated at 2022-06-25 01:54:17.250835
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    h_t_t_p_connection_0 = UnixHTTPConnection('/usr/share/doc/python')
    assert isinstance(h_t_t_p_connection_0, object)


# Generated at 2022-06-25 01:54:25.908542
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler(client_cert='../test_certs/client_cert.pem', client_key='../test_certs/client_key.pem')
    request_with_method_0 = RequestWithMethod(url=urlencode, method=HTTPConnection.request, data=1, headers=None, origin_req_host='', unverifiable=True)
    request_with_method_0._method = 'POST'
    assert request_with_method_0.get_method() == 'POST'



# Generated at 2022-06-25 01:54:34.754489
# Unit test for function getpeercert
def test_getpeercert():
    import tempfile
    if not HAS_SSL:
        raise NoSSLError('SSL validation is not available')
    from ansible import constants as C

    # Create a self signed cert
    key, cert = create_self_signed_cert()
    # Save to a temp file
    key_file = tempfile.NamedTemporaryFile()
    key_file.write(key)
    key_file.flush()
    cert_file = tempfile.NamedTemporaryFile()
    cert_file.write(cert)
    cert_file.flush()
    C.HOST_KEY_CHECKING = False
    # Start and HTTPS server using the created cert
    start_server(key_file.name, cert_file.name)

# Generated at 2022-06-25 01:54:39.511989
# Unit test for function fetch_file
def test_fetch_file():
    h_t_t_p_s_client_auth_handler_1 = HTTPSClientAuthHandler()


# Generated at 2022-06-25 01:54:45.368864
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # monkeypatch for urllib2.Request
    class Request(urllib_request.Request):
        def redirect_request(self, req, fp, code, msg, hdrs, newurl):
            return None

    # monkeypatch for urllib2.Request.get_method
    def get_method(self):
        return 'GET'

    # monkeypatch for urllib2.Request.info
    def info(self):
        return None
    # monkeypatch for urllib2.Request.get_full_url
    def get_full_url(self):
        return None

    urllib_request.Request.info = info
    urllib_request.Request.redirect_request = redirect_request
    urllib_request.Request.get_method = get_method
    urllib_request.Request

# Generated at 2022-06-25 01:54:46.895291
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    r = urllib_request.Request(None)
    s = SSLValidationHandler('hostname',443,'ca_path')
    s.http_request(r)


# Generated at 2022-06-25 01:54:50.035923
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()
    ca_path_0 = h_t_t_p_s_client_auth_handler_0.get_ca_certs()
    if ca_path_0[0] != None:
        print ('expected: %s\nactual: %s' % (None, ca_path_0[0]))


# Generated at 2022-06-25 01:55:43.502667
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    https_validation_handler_0 = SSLValidationHandler()
    https_validation_handler_0.get_ca_certs()


# Generated at 2022-06-25 01:55:45.169069
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    s_s_l_validation_handler_0 = SSLValidationHandler()
    req = test_req()
    s_s_l_validation_handler_0.http_request(req)


# Generated at 2022-06-25 01:55:50.218637
# Unit test for function fetch_file
def test_fetch_file():
    testargs = dict()
    testargs['url'] = 'https://www.ansible.com'
    result = fetch_file(AnsibleModule(argument_spec={}, supports_check_mode=False), **testargs)
    assert result == None

# Generated at 2022-06-25 01:55:54.586893
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {"sampleFile": {"content": "sample content", "filename": "fake.txt", "mime_type": "text/plain"}}
    ret = prepare_multipart(fields)
    assert ret[0] == "multipart/form-data"
    filename = ret[1].decode('utf-8')
    assert "Content-Type: text/plain" in filename
    assert "Content-Transfer-Encoding: base64" in filename
    assert "filename=\"fake.txt\"" in filename
    assert "c2FtcGxlIGNvbnRlbnQ=" in filename


# Generated at 2022-06-25 01:55:58.119398
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert the_exception
    assert 'Argument 1 of HTTPSClientAuthHandler is not a list' in str(the_exception)



# Generated at 2022-06-25 01:55:59.231893
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    assert get_channel_binding_cert_hash('') is None



# Generated at 2022-06-25 01:56:06.751413
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()
    h_t_t_p_s_client_auth_handler_0.ca_path = b'/etc/ssl/certs/ca-certificates.crt'
    url_0 = 'http://192.168.99.100:2376/containers/json'
    ret = h_t_t_p_s_client_auth_handler_0.detect_no_proxy(url_0)




# Generated at 2022-06-25 01:56:08.033886
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()


# Generated at 2022-06-25 01:56:10.148352
# Unit test for function prepare_multipart
def test_prepare_multipart():
    req = open_url("https://httpbin.org/anything", method='POST', headers={'Content-Type': 'multipart/form-data'}, data=b'This_is_my_data')
    print(req.getcode())
    print(req.read())

test_prepare_multipart()

# Generated at 2022-06-25 01:56:16.815929
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts1 = generic_urlparse(('https', 'unix:///tmp/docker.sock:12345/hello', 'world', '', '', ''))
    assert parts1['scheme'] == 'https'
    assert parts1['netloc'] == 'unix:///tmp/docker.sock:12345'
    assert parts1['path'] == '/hello'
    assert parts1['params'] == ''
    assert parts1['query'] == ''
    assert parts1['fragment'] == ''

    parts2 = generic_urlparse(('https', 'unix:///tmp/docker.sock/hello', 'world', '', '', ''))
    assert parts2['scheme'] == 'https'
    assert parts2['netloc'] == 'unix:///tmp/docker.sock'
    assert parts2['path']

# Generated at 2022-06-25 01:57:30.970054
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule(
        argument_spec=url_argument_spec()
    )

    # set up valid credentials
    module.params['url_username'] = 'test_user'
    module.params['url_password'] = 'test_pass'

    # Set up a basic HTTP server serving some static data
    test_server_port = 8080
    test_server_address = ('127.0.0.1', test_server_port)
    test_httpd = SocketServer.TCPServer(test_server_address, BasicHTTPServerRequestHandler)
    test_httpd_thread = threading.Thread(target=test_httpd.serve_forever)
    test_httpd_thread.daemon = True
    test_httpd_thread.start()

    # make sure we close the httpd server

# Generated at 2022-06-25 01:57:35.781569
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler(ca_certs=b_DUMMY_CA_CERT.decode())
    custom_https_connection_0 = CustomHTTPSConnection(ca_certs=b_DUMMY_CA_CERT.decode(), cert_file='/tmp/ansible_urllib3_cert_file.pem', host='host_0', key_file='/tmp/ansible_urllib3_key_file.pem', port=80, source_address='127.0.0.1', timeout=300)
    custom_https_connection_0.connect()


# Generated at 2022-06-25 01:57:42.811222
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves.urllib.error import URLError, HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import open_url, ConnectionError

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.debug = False
            self.warn = lambda msg: None
            self.fail_json = lambda **kwargs: None
            self.add_cleanup_file = lambda path: None

    m = FakeModule()
    m.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-25 01:57:46.704323
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()
    h_t_t_p_s_client_auth_handler_0.test_method('test_string_0')

    h_t_t_p_s_client_auth_handler_0.test_method('test_string_1')


# Generated at 2022-06-25 01:57:49.907042
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()
    response = b"HTTP/1.0 200 OK\r\n"
    valid_codes = [200]
    h_t_t_p_s_client_auth_handler_0.validate_proxy_response(response, valid_codes)


# Generated at 2022-06-25 01:58:00.381889
# Unit test for function fetch_file
def test_fetch_file():
    # Make sure that "module" argument exists
    assert "module" in inspect.getfullargspec(fetch_file).args
    # Initialize the class for "module" argument
    mock_module = AnsibleModule()
    mock_module.params = dict()
    # Initialize the return values for each method
    # mock_module.find_needle() = {"msg": "foo"}
    # mock_module.fail_json.return_value = ({"msg": "bar"}, False)
    # mock_module.add_cleanup_file.return_value = None
    # mock_module.fail_json.return_value = ({"msg": "baz"}, False)

    # Test fetch_file()
    with pytest.raises(AssertionError):
        fetch_file(None)
    # with patch.object(M

# Generated at 2022-06-25 01:58:11.239639
# Unit test for function fetch_url
def test_fetch_url():
    # Find the correct path for the boto.cfg file
    search_path = get_config_path(type="boto")

    # Create a mock module with default values

# Generated at 2022-06-25 01:58:16.363419
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # No http/https proxy set, no_proxy is empty
    https_proxy = None
    no_proxy = None
    http_proxy = None
    use_proxy = True
    testurl = 'http://www.example.com'
    ca_path = '/etc/ssl/ca_path'
    result = maybe_add_ssl_handler(testurl, True, ca_path)
    assert result == None
    # No http/https proxy set, no_proxy is not empty
    https_proxy = None
    no_proxy = 'example.com'
    http_proxy = None
    use_proxy = False
    testurl = 'http://www.example.com'
    ca_path = '/etc/ssl/ca_path'
    result = maybe_add_ssl_handler(testurl, True, ca_path)

# Generated at 2022-06-25 01:58:18.663990
# Unit test for method open of class Request
def test_Request_open():
    request = Request()
    url = 'http://example.com/'
    method = 'GET'
    result = request.open(method, url)
    pass


# Generated at 2022-06-25 01:58:28.994951
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    h_t_t_p_s_client_auth_handler_0 = HTTPSClientAuthHandler()
    dict_0 = dict()
    dict_0['verify_host'] = True
    dict_0['validate_certs'] = True
    dict_0['url_username'] = 'url_username'
    dict_0['url_password'] = 'url_password'
    dict_0['force_basic_auth'] = True
    dict_0['look_for_keys'] = True
    dict_0['cert_file'] = 'cert_file'
    dict_0['key_file'] = 'key_file'
    dict_0['ca_path'] = 'ca_path'
    dict_0['url'] = 'url'
    dict_0['host_key_checking'] = True