

# Generated at 2022-06-25 01:55:33.862073
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    args = dict(hostname = '1', port = '1', paths = '1')
    ret = build_ssl_validation_error(**args)
    assert isinstance(ret, Exception)



# Generated at 2022-06-25 01:55:40.678719
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Testing example that is shown in the module
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }

    expected_content_type = 'multipart/form-data; boundary="===============7304242976575705923=="'

# Generated at 2022-06-25 01:55:43.798154
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    var_0 = UnixHTTPSConnection('/tmp/foo')
    var_0.connect()
    assert var_0.sock, "Unable to connect to unix socket"


# Generated at 2022-06-25 01:55:49.963115
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # test 0
    try:
        test_case_0()
    except Exception as e:
        print('test_CustomHTTPSConnection unit test failed:', str(e))
        return False

    return True


# Generated at 2022-06-25 01:55:51.171281
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    var_0 = RequestWithMethod('', 'GET', None, None, None, True)
    var_0.get_method()



# Generated at 2022-06-25 01:55:58.578153
# Unit test for function fetch_file
def test_fetch_file():
    # source: https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/files/fetch.py
    # URL = "https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/files/fetch.py"
    URL = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/files/fetch.py?token=AAg-Ix6Zpms6DdUokd35Xqtiet-c6Q_rks5bdU6BwA%3D%3D'

# Generated at 2022-06-25 01:56:00.385627
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    handler = SSLValidationHandler(hostname='dummy',port=443)
    context = handler.make_context(cafile=None,cadata=None)


# Generated at 2022-06-25 01:56:02.602711
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with patch('os.unlink') as mock_unlink:
        test_file = '/etc/test_file'
        atexit_remove_file(test_file)
        mock_unlink.assert_called_once_with(test_file)


# Generated at 2022-06-25 01:56:04.269048
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    test_object = CustomHTTPSHandler()
    assert isinstance(test_object, CustomHTTPSHandler) == True


# Generated at 2022-06-25 01:56:06.900037
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    try:
        hostname = 'Host_one'
        port = 'port_one'
        paths = 'paths_one'
        exc = 'some exception'
        build_ssl_validation_error(hostname, port, paths, exc)
    except Exception as e:
        fatal_error(e)


# Generated at 2022-06-25 01:57:09.355378
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_sock_file = '/path/to/sockfile'
    unix_sock_connection = UnixHTTPConnection(unix_sock_file)
    unix_sock_connection.connect()
    assert unix_sock_connection.sock, "Failed to create the socket file"


# Generated at 2022-06-25 01:57:16.795375
# Unit test for function getpeercert
def test_getpeercert():
    try:
        import urllib2
    except ImportError:
        try:
            import urllib.request as urllib2
        except ImportError:
            # In case this is a python 2.6 system which has SSLValidationError
            # but not urllib2
            return
    # NOTE: To test this, we need to connect to HTTPS server that has a
    # certificate from a well known certificate authority. We cannot use
    # the local test server for this because the local test server does not
    # have such a certificate.
    try:
        response = urllib2.urlopen('https://www.github.com/')
    except urllib2.URLError:
        # NOTE: GitHub may be down. This case is not the purpose of this
        # test case.
        return
    cert = getpeerc

# Generated at 2022-06-25 01:57:19.488013
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    var_SSLValidationHandler = SSLValidationHandler('', 0)
    var_url = 'http://localhost:123'
    assert var_SSLValidationHandler.detect_no_proxy(var_url) == False



# Generated at 2022-06-25 01:57:28.257906
# Unit test for function generic_urlparse
def test_generic_urlparse():
    ret_0 = generic_urlparse('foo://bar.com/path/to/file.ext?key=value')

# Generated at 2022-06-25 01:57:35.154205
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    now = time.time()
    assert rfc2822_date_string(time.gmtime(now)) == email.utils.formatdate(now, usegmt=True)
    assert rfc2822_date_string(time.localtime(now)) == email.utils.formatdate(now, usegmt=False)
    # Test non-default timezone handling (zone parameter)
    assert rfc2822_date_string(time.gmtime(now), zone='+0100') == email.utils.formatdate(now, usegmt=True, localtime=True)


# Generated at 2022-06-25 01:57:38.511867
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    path = "/tmp/file.txt"
    with open(path, "w"):
        pass
    atexit_remove_file(path)
    try:
        os.stat(path)
    except Exception:
        return True



# Generated at 2022-06-25 01:57:48.562779
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'host'
    port = 80
    paths = ['path', 'paths']

    result = build_ssl_validation_error(hostname, port, paths)

# Generated at 2022-06-25 01:57:57.480154
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    var_1 = CustomHTTPSConnection()
    var_2 = var_1.context
    var_3 = var_1.cert_file
    var_4 = var_1.key_file
    var_5 = var_1.timeout
    var_6 = var_1.source_address
    var_7 = var_1.host
    var_8 = var_1.port
    var_9 = var_1.sock
    var_10 = var_1._tunnel_host
    var_11 = socket.create_connection()
    var_12 = ssl_wrap_socket()
    var_13 = ssl.wrap_socket()
    var_14 = var_1.connect()


# Generated at 2022-06-25 01:58:00.417468
# Unit test for function generic_urlparse
def test_generic_urlparse():
  assert generic_urlparse(['http', 'www.example.com', '/path', '', 'arg=val', 'frag']) == {'scheme': 'http', 'netloc': 'www.example.com', 'path': '/path', 'params': '', 'query': 'arg=val', 'fragment': 'frag'}


# Generated at 2022-06-25 01:58:01.912421
# Unit test for method delete of class Request
def test_Request_delete():
    """
    Test the method delete of class Request
    """
    req = Request()
    var_0 = req.delete('url', 'data', 'method', '**kwargs')


# Generated at 2022-06-25 01:59:03.902152
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    try:
        myconnection = CustomHTTPSConnection('hostname', 443)
        myconnection.connect()
    except ssl.SSLError as err:
        print(err)
    except socket.gaierror as err:
        print(err)
    except ConnectionError as err:
        print(err)


if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, *args, **kwargs):
            self.url = None
            self.protocol = PROTOCOL
            self.context = None
            if HAS_SSLCONTEXT:
                self.context = ssl.SSLContext(PROTOCOL)

# Generated at 2022-06-25 01:59:05.909928
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    input1 = 'no'
    input2 = True
    input3 = '/etc/ssl/certs'
    result = RedirectHandlerFactory(input1, input2, input3)
    print(result)


# Generated at 2022-06-25 01:59:06.973805
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    custom_handler = CustomHTTPSHandler()


# Generated at 2022-06-25 01:59:07.491900
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    pass
