

# Generated at 2022-06-25 01:53:49.051071
# Unit test for function fetch_url
def test_fetch_url():
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    expected = ('FAKE_CUSTOM_HTTPS_CONNECTION', 'FAKE_CUSTOM_HTTPS_CONNECTION')
    actual = CustomHTTPSConnection()
    assert actual == expected
    assert expected == actual


# Generated at 2022-06-25 01:53:56.468789
# Unit test for function fetch_url
def test_fetch_url():
    # HTTP
    sample_url = 'https://some_domain.com:443'
    sample_url_username = 'user'
    sample_url_password = '****'
    sample_use_proxy = True
    sample_force_basic_auth = False
    sample_timeout = 10
    sample_http_agent = 'ansible-httpget'
    sample_validate_certs = False
    sample_url_args = dict(url=sample_url, url_username=sample_url_username, url_password=sample_url_password, use_proxy=sample_use_proxy, force_basic_auth=sample_force_basic_auth, timeout=sample_timeout, http_agent=sample_http_agent, validate_certs=sample_validate_certs)
    sample_data = None
    sample_headers = None


# Generated at 2022-06-25 01:54:04.950225
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()
        print("Successfully instantiated CustomHTTPSHandler")
    except Exception as e:
        print("Error: " + str(e))

if hasattr(ssl, 'SSLContext'):
    if hasattr(ssl, 'PROTOCOL_TLSv1'):
        PROTOCOL = ssl.PROTOCOL_TLSv1
    else:
        PROTOCOL = ssl.PROTOCOL_TLSv1_2
else:
    PROTOCOL = None



# Generated at 2022-06-25 01:54:06.793709
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert(str(type(custom_h_t_t_p_s_connection_0)) == "<class 'ansible.module_utils.connection._http.CustomHTTPSConnection'>")


# Generated at 2022-06-25 01:54:09.849758
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'h'
    port = 2
    paths = ['p']
    exc = 'we are testing'
    assert build_ssl_validation_error(hostname, port, paths, exc) is None



# Generated at 2022-06-25 01:54:18.955093
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname = 'example.com'
    port = 7777

    # Create test SSLValidationHandler
    SSLValidationHandler_obj = SSLValidationHandler(hostname, port)

    # Create test Request object
    req_obj = Request(url="http://example.com")

    # Unit test for http_request method
    # We expect a ConnectionError as we cannot actually open a socket to example.com
    with pytest.raises(ConnectionError):
        SSLValidationHandler_obj.http_request(req_obj)



# Generated at 2022-06-25 01:54:28.754384
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    err = build_ssl_validation_error(
        'localhost',
        8000,
        [
            '/usr/lib/ssl/certs/ca-certificates.crt',
        ],
        exc=ValueError()
    )
    assert isinstance(err, SSLValidationError)

# Generated at 2022-06-25 01:54:37.049582
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():

    # generate_connection_unix.py
    #
    # Copyright 2016 Socify Inc.
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #     http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    #

    import unittest
    import mock
    import socket


# Generated at 2022-06-25 01:54:44.005444
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from time import gmtime, strftime
    time_str = strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime())
    assert rfc2822_date_string(gmtime()) == time_str


# Generated at 2022-06-25 01:54:49.415472
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Setup the test
    s_s_l_validation_handler_0 = SSLValidationHandler('', 443)
    # No arguments, check if the method raises an exception
    assert s_s_l_validation_handler_0.detect_no_proxy() == True
    # Setup the test
    s_s_l_validation_handler_1 = SSLValidationHandler('', 443)
    # No arguments, check if the method raises an exception
    assert s_s_l_validation_handler_1.detect_no_proxy() == True
    # Setup the test
    s_s_l_validation_handler_2 = SSLValidationHandler('', 443)
    # No arguments, check if the method raises an exception

# Generated at 2022-06-25 01:55:33.079141
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    custom_h_t_t_p_s_handler_0 = CustomHTTPSHandler()


# Generated at 2022-06-25 01:55:36.799630
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    ca_path = None
    handler = SSLValidationHandler(hostname, port, ca_path)
    cafile = handler.ca_path or cafile
    cadata = cadata or None
    """
    if HAS_SSLCONTEXT:
            context = create_default_context(cafile=cafile)
        elif HAS_URLLIB3_PYOPENSSLCONTEXT:
            context = PyOpenSSLContext(PROTOCOL)
        else:
            raise NotImplementedError('Host libraries are too old to support creating an sslcontext')
    """
    assert handler.make_context(cafile, cadata)



# Generated at 2022-06-25 01:55:39.100497
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        CustomHTTPSHandler()
    except:
        print("Constructor test for CustomHTTPSHandler class failed.")
        return(False)
    print("Constructor test for CustomHTTPSHandler class passed.")
    return(True)


# Generated at 2022-06-25 01:55:44.124239
# Unit test for function getpeercert
def test_getpeercert():
    hostname = 'github.com'
    # The following is a known good cert from github.com

# Generated at 2022-06-25 01:55:54.814610
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    url_0 = url('')
    headers_0 = headers()
    ip_0 = ip()
    ca_path_0 = ca_path()

    ssl_validation_handler_0 = SSLValidationHandler(hostname=ip_0, port=443, ca_path=ca_path_0)

    request_0 = request(url_0, headers=headers_0)
    ssl_validation_handler_0.http_request(request_0)

    ssl_validation_handler_0 = SSLValidationHandler(hostname=ip_0, port=443, ca_path=None)

    request_0 = request(url_0, headers=headers_0)
    ssl_validation_handler_0.http_request(request_0)

    # Unit test for method validate_proxy_response of class

# Generated at 2022-06-25 01:55:59.658578
# Unit test for function fetch_url
def test_fetch_url():
    m = MyModule()
    params = { 
        'url_password': 'j%&p$',
        'force_basic_auth': 'no',
        'ca_path': '/home/akshay/Downloads/cookies.txt',
        'client_cert': '/home/akshay/Downloads/cookies.txt',
        'http_agent': 'ansible-httpget',
        'client_key': 'f1',
        'follow_redirects': 'urllib2',
        'url_username': 'admin',
        'validate_certs': 'yes',
        'use_gssapi': 'no',
        'unix_socket': '/home/akshay/Downloads/cookies.txt',
    }

# Generated at 2022-06-25 01:56:08.607676
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()
    try:
        with unix_socket_patch_httpconnection_connect():
            custom_h_t_t_p_s_connection_0.connect()
    except Exception as err:
        print(err)

if HAS_SSL:
    def _https_verify_certs(conn, url, validate_certs):
        '''Verify HTTPS server certificates'''

        if not validate_certs:
            return

        # Check hostnames
        _cert_verify_hostname(conn.sock.getpeercert(), url)

    def _cert_verify_hostname(peercert, hostname):
        '''Verify the hostname we connected to the server by checking
        the certificate returned by the server'''

# Generated at 2022-06-25 01:56:13.394209
# Unit test for function getpeercert
def test_getpeercert():
    with open(os.devnull, "wb") as null:
        response = urllib_request.urlopen("http://www.python.org", timeout=2, cafile=os.devnull, capath=null)
        if PY3:
            assert response.getpeercert() == None
            assert getpeercert(response) == None
        else:
            assert response.fp._sock.fp._sock.getpeercert() == None
            assert getpeercert(response) == None

        response = urllib_request.urlopen("https://www.python.org", timeout=2, cafile=os.devnull, capath=null)
        if PY3:
            assert response.getpeercert() == None
            assert getpeercert(response) == None
        else:
            assert response

# Generated at 2022-06-25 01:56:20.782932
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    print("Testing CustomHTTPSConnection.connect()")
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()

if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        '''
        Extended version of the HTTPSHandler class.
        Uses the CustomHTTPSConnection class which allows to specify the
        client certificate and key.
        '''
        def __init__(self, key_file=None, cert_file=None):
            urllib_request.HTTPSHandler.__init__(self)
            self.key_file = key_file
            self.cert_file = cert_file

        def https_open(self, req):
            return self.do_open(self.getConnection, req)



# Generated at 2022-06-25 01:56:24.903124
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    custom_h_t_t_p_s_connection_0 = CustomHTTPSConnection()


    #
    """

    """
