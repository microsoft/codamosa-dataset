

# Generated at 2022-06-25 01:53:23.588609
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    hostname = 'localhost'
    port = 443
    ca_path = None
    handler = SSLValidationHandler(hostname, port, ca_path)
    assert handler.get_ca_certs()


# Generated at 2022-06-25 01:53:25.991099
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    follow_redirects = 'all'
    validate_certs = True
    ca_path = None
    test = RedirectHandlerFactory(follow_redirects, validate_certs, ca_path)
    assert isinstance(test, type)

if __name__ == '__main__':
    test_RedirectHandlerFactory()

# Generated at 2022-06-25 01:53:27.583028
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    request_0 = Request()
    request_0.url = 'http://www.google.com'
    request_0.validate_proxy_response(b'HTTP/1.1 200 OK')


# Generated at 2022-06-25 01:53:32.292042
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    request_0 = Request()
    # Instantiate the CustomHTTPSConnection object
    # The argument of the instantiation may be changed as needed
    CustomHTTPSConnection_0 = CustomHTTPSConnection()
    # Call method connect of CustomHTTPSConnection and pass argument request_0
    CustomHTTPSConnection_0.connect(request_0)

if CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, ca_path=None):
            urllib_request.HTTPSHandler.__init__(self)
            self.ca_path = ca_path


# Generated at 2022-06-25 01:53:33.726977
# Unit test for constructor of class Request
def test_Request():
    request_0 = Request()
    #print(request_0)
    pass

if __name__ == '__main__':
    test_Request()
    test_case_0()

# Generated at 2022-06-25 01:53:44.252544
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test case setup
    urllib_request.install_opener(urllib_request.build_opener())
    req = RequestWithMethod('http://localhost/', 'GET')

    # Expected Result:
    #  - No HTTPError is raised upon call to redirect_request.
    #  - redirect_request returns a urllib.request.Request object.
    # Test with follow_redirects = 'urllib2'
    urllib_request.install_opener(urllib_request.build_opener(RedirectHandlerFactory(follow_redirects='urllib2')))
    assert isinstance(urllib_request._opener.open(req), urllib_request.response.addinfourl)

    # Expected Result:
    #  - No HTTPError is raised upon call to redirect

# Generated at 2022-06-25 01:53:50.007297
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = ParseResult(1, 2, 3, 4, 5, 6)
    assert generic_urlparse(parts) == {
        'scheme': 1,
        'netloc': 2,
        'path': 3,
        'params': 4,
        'query': 5,
        'fragment': 6,
        'username': None,
        'password': None,
        'hostname': 2,
        'port': None,
    }


# Generated at 2022-06-25 01:53:51.921869
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect("/tmp/unix_http_connection.py")
    except:
        pass
    sock.settimeout(1.0)


# Generated at 2022-06-25 01:53:55.257743
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    ca_path_0 = "pZOd>}#m"
    ssl_validation_handler_0 = SSLValidationHandler("hostname_0", 65535, ca_path_0)

    try:
        ssl_validation_handler_0.get_ca_certs()
    except (IOError, OSError) as exc:
        if getattr(exc, 'filename', None) is not None and os.path.exists(exc.filename):
            raise AssertionError('Failed to open file ' + str(exc.filename))


# Generated at 2022-06-25 01:53:57.677661
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    assert 1 == 1


# Generated at 2022-06-25 01:55:59.689244
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    connection_0 = UnixHTTPSConnection(None)
    connection_0.connect()
    connection_0.close()


# Generated at 2022-06-25 01:56:05.740478
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler(None, None)

    # Test cases for attribute detect_no_proxy of class SSLValidationHandler
    # test value for attribute detect_no_proxy of class SSLValidationHandler for test case 0
    assert handler.detect_no_proxy("https://pypi.python.org/pypi") == True
    # test value for attribute detect_no_proxy of class SSLValidationHandler for test case 1
    assert handler.detect_no_proxy("pypi.python.org") == True
    # test value for attribute detect_no_proxy of class SSLValidationHandler for test case 2
    assert handler.detect_no_proxy("pypi") == True
    # test value for attribute detect_no_proxy of class SSLValidationHandler for test case 3

# Generated at 2022-06-25 01:56:08.378058
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    print("Case 0: Error with hostname, port and paths")
    try:
        build_ssl_validation_error("hostname", "port", "paths")
    except SSLValidationError as ssl_error:
        print("The SSL validation error is %s" % (ssl_error))

test_case_0()

# Generated at 2022-06-25 01:56:11.171264
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime(0), '+0000') == "Thu, 01 Jan 1970 00:00:00 +0000"
    assert rfc2822_date_string(time.gmtime(0)) == "Thu, 01 Jan 1970 00:00:00 -0000"


# Generated at 2022-06-25 01:56:14.341233
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    request_0 = Request()
    CustomHTTPSConnection(request_0)


# Generated at 2022-06-25 01:56:21.583439
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url_0 = urlparse('http://192.0.2.0')
    url_1 = urlparse('file:///localhost:8080/')
    url_2 = urlparse('https://192.0.2.0:8080/')

    # Case 0 - url is a string
    try:
        instance_0 = SSLValidationHandler('192.0.2.0', 8080)
        result_0 = instance_0.detect_no_proxy('192.0.2.0')
    except Exception as e:
        print(e)

    # Case 1 - url is a urllib.parse.ParseResult

# Generated at 2022-06-25 01:56:24.917631
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'test'
    port = None
    paths = []
    exc = None
    assert build_ssl_validation_error(hostname, port, paths, exc) is None
    pass


# Generated at 2022-06-25 01:56:29.170926
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    filename = 'tmp.txt'
    open(filename, 'a').close()
    atexit_remove_file(filename)
    if os.path.exists(filename) == False:
        return True
    else:
        return False


# Generated at 2022-06-25 01:56:30.153063
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    handler_0 = CustomHTTPSHandler()


# Generated at 2022-06-25 01:56:35.654889
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    request_0 = Request()
    request_0.url = 'TCP://www.google.com:443'
    request_0.body = ''
    request_0.headers = {'Accept': 'text/html', 'Cookie': '', 'Connection': 'keep-alive', 'Content-Type': 'text/html'}
    request_0.method = 'GET'
    request_0.verify_ssl = True
    request_0.timeout = 10
    request_0.use_proxy = False
    request_0.allow_redirects = True
    request_0.trusted_certs = ''
    request_0.untrusted_certs = ''
    request_0.follow_redirects = True
    request_0.connection_type = "TCP"

    # Detect if the session is coming from

# Generated at 2022-06-25 01:57:27.662150
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    # Create the object
    request_1 = RequestWithMethod(None, None, None, None, None, None)
    # Invoke the method
    try:
        result_0 = request_1.get_method()
        raise Exception("Expect exception here!")
    except Exception as e_0:
        pass



# Generated at 2022-06-25 01:57:32.086201
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    CustomHTTPSHandlerTester = CustomHTTPSHandler()
    assert isinstance(CustomHTTPSHandlerTester, CustomHTTPSHandler), 'Test Failed: Could not create instance of CustomHTTPSHandler'


# Generated at 2022-06-25 01:57:38.241112
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    hostname = 'ansible.com'
    port = 443
    sSLValidationHandler = SSLValidationHandler(hostname, port)
    cafile = 'D:\\workspace\\python\\certifi\\cacert.pem'
    cadata = ''
    res = sSLValidationHandler.make_context(cafile, cadata)
    assert res == ssl.SSLContext(ssl.PROTOCOL_SSLv23)


# Generated at 2022-06-25 01:57:41.723497
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    handler_0 = SSLValidationHandler(hostname='/etc/pki/tls/certs', port=443)
    assert handler_0.get_ca_certs()[0] == '/etc/pki/tls/certs'


# Generated at 2022-06-25 01:57:46.027819
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    # Test for function rfc2822_date_string
    print("Testing function rfc2822_date_string")
    assert rfc2822_date_string((2001, 12, 14, 4, 6, 14, 3, 348, 0)) == 'Fri, 14 Dec 2001 04:06:14 -0000', 'Wrong result'
    assert rfc2822_date_string((2001, 12, 14, 4, 6, 14, 3, 348, 0), zone='-0700') == 'Fri, 14 Dec 2001 04:06:14 -0700', 'Wrong result'
    assert rfc2822_date_string((2001, 12, 14, 4, 6, 14, 3, 348, 0), zone='+0700') == 'Fri, 14 Dec 2001 04:06:14 +0700', 'Wrong result'


# Generated at 2022-06-25 01:57:50.534491
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():

    # Just some code to make sure these classes actually work
    # I've tested it against unix sockets, but it should work against tcp sockets
    # as well, but this test is not set up to do that.
    if HAS_PYOPENSSL:
        import OpenSSL
        from OpenSSL import SSL

        _base_class = OpenSSL.SSL.Context
        class PyOpenSSLContext(_base_class):
            # Add compatibility for older PyOpenSSL (<16.0.0) which does not have
            # a __init__ method on Context
            try:
                _base_class.__init__
            except AttributeError:
                pass
        PROTOCOL = SSL.SSLv23_METHOD

    elif HAS_CRYPTO:
        import Crypto.SSL
        _base_class = Crypto.SSL.Context

# Generated at 2022-06-25 01:57:51.904527
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    assert 'context' in dir(functools.partial(CustomHTTPSConnection))


# Generated at 2022-06-25 01:58:02.660435
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    request_0 = Request()
    request_1 = Request()
    request_1.data = Mock()
    request_2 = Request()
    request_2.data = Mock()
    request_3 = Request()
    request_3.data = Mock()
    request_4 = Request()
    request_4.data = Mock()
    request_5 = Request()
    request_5.data = Mock()
    request_6 = Request()
    request_6.data = Mock()
    request_7 = Request()
    request_7.data = Mock()
    request_8 = Request()
    request_8.data = Mock()
    request_9 = Request()
    request_9.data = Mock()
    request_10 = Request()
    request_10.data = Mock()
    request_11 = Request()
    request_

# Generated at 2022-06-25 01:58:09.012002
# Unit test for method open of class Request
def test_Request_open():
    global request_0
    res = request_0.open("GET","http://www.baidu.com")
    assert res.getcode()==200
    res = request_0.open("GET","http://www.baidu.com",validate_certs=False)
    assert res.getcode()==200
    res = request_0.open("GET","http://www.baidu.com",timeout=1.0)
    assert res.getcode()==200
    res = request_0.open("GET","http://www.baidu.com",unix_socket="/home/gather/pycharm_project_1/MockRequest/unix_socket")
    assert res.getcode()==200

# Generated at 2022-06-25 01:58:09.909175
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    pass
