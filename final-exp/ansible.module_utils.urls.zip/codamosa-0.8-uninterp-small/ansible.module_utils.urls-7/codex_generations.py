

# Generated at 2022-06-25 01:53:33.796079
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
  path = './SSLValidationHandler'
  if not os.path.exists(path):
    os.mkdir(path)
  filename = os.path.join(path,'test_SSLValidationHandler_detect_no_proxy')
  if os.path.exists(filename):
    os.remove(filename)
  proxy = 'http://localhost:8080'
  handler = SSLValidationHandler('localhost',80)
  os.environ['no_proxy'] = ' '.join(['.com','.org','.net'])
  assert handler.detect_no_proxy(proxy) is False
  with open(filename,'w') as f:
    f.write(' '.join(['.edu','.cn','.us']))
  os.environ['no_proxy'] = '@'+filename
  assert handler.det

# Generated at 2022-06-25 01:53:35.374471
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    if NO_PYTHON_SSL_IMPL:
        return
    unix_http_connection_0 = UnixHTTPConnection('/tmp/')
    unix_http_connection_0.connect()


# Generated at 2022-06-25 01:53:36.371184
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
   assert isinstance(CustomHTTPSHandler(), CustomHTTPSHandler)


# Generated at 2022-06-25 01:53:41.122960
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    redirect_handler = RedirectHandlerFactory()
    assert isinstance(redirect_handler, type)


# Generated at 2022-06-25 01:53:42.722088
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_h_t_t_p_connection_0 = UnixHTTPConnection()
    try:
        unix_h_t_t_p_connection_0.connect()
    except OSError as e:
        pass


# Generated at 2022-06-25 01:53:52.721483
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Arrange
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }

    # Act
    content_type, body = prepare_multipart(fields)

    # Assert
    assert(content_type == 'multipart/form-data; boundary="===============1247480048725061709=="')
    assert(isinstance(body, bytes))

    # Arrange

# Generated at 2022-06-25 01:54:03.267500
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.fail_json = MagicMock()
    distribution = 'redhat'
    distribution.lower = MagicMock(return_value='redhat')

# Generated at 2022-06-25 01:54:06.231373
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_h_t_t_p_connection_0 = UnixHTTPConnection(str())
    unix_h_t_t_p_connection_0.connect()
    unix_h_t_t_p_connection_1 = UnixHTTPConnection(str())
    unix_h_t_t_p_connection_1.connect()


# Generated at 2022-06-25 01:54:09.474797
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert CustomHTTPSConnection._context is None
    assert CustomHTTPSConnection.context is None


# Generated at 2022-06-25 01:54:11.347173
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    assert maybe_add_ssl_handler(parsed.scheme, validate_certs, ca_path=None) == 0

# Generated at 2022-06-25 01:54:47.714190
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    server_hostname = 'hostname'
    server_host = ''
    server_port = 0
    tunnel_host = ''
    host = 'host'
    port = 0
    socket_ = socket.socket()
    ssl_wrap_socket = ssl.wrap_socket(socket_, ssl_version=SSL.SSLv23_METHOD)
    # create instance of class CustomHTTPSConnection
    connection = CustomHTTPSConnection(host, port, key_file=None, cert_file=None, strict=None)
    # check the value of connection.sock
    assert (connection.sock.getpeername() == ('', 0) and connection.sock.getsockname() == ('', 0))
    # set the value of connection.sock
    connection.sock = ssl_wrap_socket
    # set the value of

# Generated at 2022-06-25 01:54:48.700050
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    assert isinstance(UnixHTTPConnection('test_arg_0')(), UnixHTTPConnection)


# Generated at 2022-06-25 01:54:50.169547
# Unit test for constructor of class Request
def test_Request():
    # Test case 1
    request_1 = Request()
    assert request_1.get_method() == 'GET'


# Unit Test for function get_redirect_location when HTTP code is 301

# Generated at 2022-06-25 01:55:00.247956
# Unit test for function getpeercert
def test_getpeercert():
    '''Test of getpeercert'''
    url = 'https://www.google.com/'
    resp_file = urllib_request.urlopen(url)
    cert = getpeercert(resp_file, binary_form=False)
    assert 'subject' in cert
    # The following assertion is to confirm that we are using the self-signed certificate
    assert cert['subject'][0][0][1] == 'Google Internet Authority G2'
    resp_file.close()



try:
    test_case_0()
except Exception as e:

    print("Exception in test case 0")
    print("Type %s" % str(type(e)))
    print("Args %s " % str(e.args))
    print("Exception: %s" %  str(e))
    raise


# Generated at 2022-06-25 01:55:03.509435
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # FIXME: This does not test anything.
    test_case_0()


# Generated at 2022-06-25 01:55:07.898441
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    '''
    Unit test for method UnixHTTPConnection.__call__
    '''
    unix_http_connection_0 = UnixHTTPConnection('')
    httplib_http_connection_0 = httplib.HTTPConnection
    httplib_http_connection_1 = httplib_http_connection_0
    try:
        unix_http_connection_0.__call__('', '', '', '', '')
    except AttributeError:
        httplib_http_connection_1 = None


# Generated at 2022-06-25 01:55:15.936353
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # set up parameter to test
    param_0 = None
    param_1 = None
    param_2 = None
    param_3 = None
    param_4 = None
    param_5 = None
    param_6 = None
    param_7 = None
    param_8 = None
    param_9 = None
    param_10 = None
    param_11 = None
    param_12 = None
    param_13 = None
    param_14 = None
    param_15 = None
    param_16 = None
    param_17 = None
    param_18 = None
    param_19 = None
    param_20 = None
    param_21 = None
    param_22 = None
    param_23 = None
    param_24 = None
    param_25 = None
    param_26 = None
    param

# Generated at 2022-06-25 01:55:21.904505
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Create a socket object
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cafile = None
    cadata = None

    # Define the port on which you want to connect
    port = 8080
    tmp_ca_cert_path = 'E:/Python/Python37/Lib/site-packages/ansible/modules/packaging/os/win_feature.py'
    # connect to the server on local computer
    s.connect(('127.0.0.1', port))

    # receive data from the server
    #print(s.recv(1024))

    # close the connection
    s.close()
    print("Test case passed")


# Generated at 2022-06-25 01:55:29.533337
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    with pytest.raises(AttributeError) as excinfo:
        test_case_0()

    # Verify that the exception message is exactly what we expect it to be
    assert excinfo.value.args[0] == '__init__() takes at least 3 arguments (2 given)'


# Generated at 2022-06-25 01:55:33.048909
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():

    # Test the constructor of class CustomHTTPSHandler with no parameter
    handler_0 = CustomHTTPSHandler()


# Generated at 2022-06-25 01:57:44.457491
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Set up mock
    req = Mock(urllib_request.Request)
    req.get_full_url.return_value = 'mock_url'
    # Call method
    test_method = TestSSLValidationHandler()
    result = test_method.http_request(req)
    # Check results
    assert result == req, "test_SSLValidationHandler_http_request: Result does not match expected result"


# Generated at 2022-06-25 01:57:47.978854
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    ssl_validation_handler_obj = SSLValidationHandler(None, None, None)
    assert ssl_validation_handler_obj.get_ca_certs() != None


# Generated at 2022-06-25 01:57:51.650125
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    CustomHTTPSConnection()


# Generated at 2022-06-25 01:57:56.864234
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    unix_https_connection_0 = UnixHTTPSConnection(unix_socket_0)
    assert unix_https_connection_0.connect() == None


# Generated at 2022-06-25 01:58:07.994012
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # Test that the expected channel binding is returned when a certificate is used
    cert_der = load_fixture(os.path.join('crypto', 'cert.pem.der'))
    cert_hash = get_channel_binding_cert_hash(cert_der)
    assert to_bytes(hexlify(cert_hash), errors='surrogate_or_strict') == to_bytes(b'0b2ef11c77676cc48f10b72a8b71005cce056f5d28f5fe9d5e6a5259fe1b8feb', errors='surrogate_or_strict')

    # Test that no channel binding is returned when no certificate is used
    assert get_channel_binding_cert_hash(None) is None


# Generated at 2022-06-25 01:58:15.035372
# Unit test for function fetch_file
def test_fetch_file():
    print('Testing function fetch_file')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_

# Generated at 2022-06-25 01:58:20.407175
# Unit test for function prepare_multipart
def test_prepare_multipart():
    assert prepare_multipart({})
    assert prepare_multipart({"f1": "v1"}) == (
        'multipart/form-data; boundary="===============6227350861369609678=="',
        '--===============6227350861369609678==\r\n'
        'Content-Disposition: form-data; name="f1"\r\n'
        '\r\n'
        'v1\r\n'
        '--===============6227350861369609678==--\r\n'
    )

# Generated at 2022-06-25 01:58:27.910293
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    socket_path = '/some/socket/path'
    with unix_socket_patch_httpconnection_connect():
        connection = UnixHTTPSConnection(socket_path)('localhost')
    assert connection.unix_socket == socket_path


# Python3 added a 'server_hostname' argument to wrap_socket. This makes it
# possible to use SNI with Python3.3+ while avoiding a 2.6-2.7 compatibility
# nightmare.

# This is a backport of Python 3.4's ssl.create_default_context (PyOpenSSL
# already had this)

# Generated at 2022-06-25 01:58:32.813378
# Unit test for function getpeercert
def test_getpeercert():
    # test_case_0()
    # Here we cannot test https urls, since it is inconvenient to setup https server
    #  in other ports
    # For now only test http urls
    # test_https_url = "https://www.google.com:443"
    test_http_url = "http://www.google.com:80"

# Generated at 2022-06-25 01:58:39.705176
# Unit test for function fetch_file
def test_fetch_file():
    m = Ansible()
    filename = fetch_file(m, "https://gist.githubusercontent.com/briancline/7638f99a0e9b7ec63d13/raw/ca5b869f2040bbd6d0939c6026e8e1a6b1d85d87/ansible.cfg")
    assert os.path.isfile(filename)
    os.remove(filename)
