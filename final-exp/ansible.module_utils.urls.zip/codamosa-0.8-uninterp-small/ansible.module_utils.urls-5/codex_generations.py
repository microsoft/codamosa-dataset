

# Generated at 2022-06-25 01:54:40.358243
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    test_https_proxy = os.environ.get('https_proxy')
    class Test_SSLValidationHandler(SSLValidationHandler):
        def __init__(self, *args, **kwargs):
            self.detect_no_proxy_result = False
            SSLValidationHandler.__init__(self, *args, **kwargs)
        def detect_no_proxy(self, url):
            self.detect_no_proxy_result = SSLValidationHandler.detect_no_proxy(self, url)
            return self.detect_no_proxy_result
    url = 'http://localhost'
    test_ssl_validation_handler = Test_SSLValidationHandler('localhost', 80)
    test_ssl_validation_handler.detect_no_proxy(url)
    assert True == test_ssl_valid

# Generated at 2022-06-25 01:54:49.506008
# Unit test for function getpeercert
def test_getpeercert():
    from urllib.request import urlopen
    from urllib.error import HTTPError
    from urllib.parse import urlparse

    url = 'http://httpbin.org/get?headers=True'
    test_response = urlopen(url)
    response_cert = getpeercert(test_response)
    assert not response_cert, "getpeercert returned unexpected result."

    url = 'https://httpbin.org/get?headers=True'
    test_response = urlopen(url)
    response_cert = getpeercert(test_response)
    assert response_cert, "getpeercert returned unexpected result."

    try:
        response = urlopen('https://google.com', cafile='cafile_does_not_exist')
    except HTTPError:
        response = None
    response_cert

# Generated at 2022-06-25 01:54:54.808810
# Unit test for function build_ssl_validation_error

# Generated at 2022-06-25 01:54:58.714556
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Create an ssl validation handler object
    hostname = 'www.google.com'
    port = 443
    ca_path = '/etc/ansible/root_ca.crt'
    ssl_validation_handler = SSLValidationHandler(hostname, port, ca_path)

    ca_certs = ssl_validation_handler.get_ca_certs()

    # Assert
    assert os.path.exists(ca_certs[0])
    # clean up
    os.remove(ca_certs[0])


# Generated at 2022-06-25 01:55:07.779461
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    try:
        https_validation_handler = SSLValidationHandler("abs.cd", 443)
    except Exception as e:
        raise Exception("Error creating https_validation_handler: %s" % to_native(e))

    ssl_req_0 = Request("https://ansible.com/")

    try:
        https_validation_handler.http_request(ssl_req_0)
    except ProxyError:
        # Server does not expect proxy
        return
    except Exception as e:
        raise Exception("Unexpected exception: %s" % to_native(e))




# Generated at 2022-06-25 01:55:17.559759
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # create HTTPS handler with self-signed certificate
    httpsHandler = HTTPSClientAuthHandler(
        client_cert=CERT_FILEPATH,
        client_key=KEY_FILEPATH,
        unix_socket='/tmp/pytest_http_test.sock',
    )
    # create HTTPS opener using self-signed certificate
    opener = urllib_request.build_opener(httpsHandler)
    urllib_request.install_opener(opener)

    handler = RedirectHandlerFactory(follow_redirects=None)
    assert isinstance(handler, urllib_request.HTTPRedirectHandler)
    assert handler.__class__.__name__ == 'RedirectHandler'



# Generated at 2022-06-25 01:55:23.401814
# Unit test for method open of class Request
def test_Request_open():
    request = Request("url", "data", "timeout")
    try:
        request.open("method", "url", "data", "timeout")
    except Exception:
        pass


# Generated at 2022-06-25 01:55:30.473620
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule(argument_spec={'url': dict(required=True, type='str')})
    url = module.params['url']
    response, info = fetch_url(module, url)
    assert response!=None
    assert info['msg']=='OK (unknown bytes)'
    assert info['status']==200



# Generated at 2022-06-25 01:55:38.551865
# Unit test for method open of class Request
def test_Request_open():

    # check the working status of method open
    # Arrange
    temp = Request(url = 'https://github.com', headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:32.0) Gecko/20100101 Firefox/32.0', 'Accept-Encoding': 'gzip, deflate', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Connection': 'keep-alive'})


# Generated at 2022-06-25 01:55:43.204994
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    # Test 1: Call with good parameters
    test1_unix_socket = "test1_unix_socket"
    test1_host = "test1_host"
    test1_port = "test1_port"
    test1_key_file = "test1_key_file"
    test1_cert_file = "test1_cert_file"
    test1_context = "test1_context"
    test1_timeout = "test1_timeout"
    test1_source_address = "test1_source_address"

# Generated at 2022-06-25 01:56:49.048806
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():

    #
    # build an object of class SSLValidationHandler
    obj = SSLValidationHandler()

    #
    # build an object of class Request
    request = urllib_request.Request()

    #
    # invoke the method http_request of the object
    assert obj.http_request(request) == request

    #
    # build an object of class Request
    request = urllib_request.Request()

    #
    # invoke the method http_request of the object
    assert obj.http_request(request) == request

    #
    # build an object of class Request
    request = urllib_request.Request()

    #
    # invoke the method http_request of the object
    assert obj.http_request(request) == request

    #
    # build an object of class Request
    request = urllib_

# Generated at 2022-06-25 01:56:54.424588
# Unit test for function fetch_file
def test_fetch_file():
    test_module = MagicMock()
    test_module.tmpdir = '/tmp/'
    test_module.add_cleanup_file = MagicMock()
    test_module.fail_json = MagicMock()
    rsp = StringIO.StringIO(str(test_fetch_file))
    rsp.close = MagicMock()
    info = dict()
    with patch('os.path.splitext') as mock_splitext:
        mock_splitext.return_value = ('temp', '')
        with patch('tempfile.NamedTemporaryFile', create=True) as mock_temp_file:
            mock_temp_file.return_value.name = '/tmp/fetch.py'

# Generated at 2022-06-25 01:56:59.678245
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    ca_certs = SSLValidationHandler(hostname="google.ca", port=443).get_ca_certs()
    if (ca_certs[0] is None and ca_certs[1] is None):
        if not (ca_certs[2] == ['/etc/ssl/certs']):
            raise Exception()


# Generated at 2022-06-25 01:57:05.583335
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    params = {'context': None, 'cert_file': 'cert_file',
              '_tunnel_host': '_tunnel_host', 'sock': 'sock'}
    custom_https_connection = CustomHTTPSConnection(**params)

    # Test case with no certificate file
    params['cert_file'] = None
    custom_https_connection = CustomHTTPSConnection(**params)

    # Test case with no proxy
    params['_tunnel_host'] = None

    try:
        is_valid_connection = True
        custom_https_connection = CustomHTTPSConnection(**params)
        custom_https_connection.connect()
    except Exception:
        is_valid_connection = False

# Generated at 2022-06-25 01:57:08.777533
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    # Valid date
    assert rfc2822_date_string(time.gmtime(), zone='-0000') == 'Wed, 01 Jan 2014 00:00:00 -0000'

    # Invalid date
    invalid_date = rfc2822_date_string((100, 10, 10, 10, 10, 10, 10, 10, 10), zone='-0000')
    assert invalid_date == 'Sun, 10 Oct 2100 10:10:10 -0000'



# Generated at 2022-06-25 01:57:19.588033
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-25 01:57:27.636138
# Unit test for function fetch_file
def test_fetch_file():
    url = "http://example.com"
    data = "test_data"
    headers = {"Content-type": "application/json"}
    method = "POST"
    use_proxy = True
    force = False
    last_mod_time = None
    timeout = 10
    unredirected_headers = None
    fetch_file(url, data, headers, method, use_proxy, force, last_mod_time, timeout, unredirected_headers)


# Generated at 2022-06-25 01:57:30.767980
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    '''
    Unit test for method get_method of class RequestWithMethod
    '''
    test_req_with_method = RequestWithMethod('http://www.example.com', 'POST', headers={'User-Agent': 'python-requests/2.18.4'})
    assert test_req_with_method.get_method() == 'POST'


# Generated at 2022-06-25 01:57:37.576592
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    #no_proxy = 'myserver.example.com,localhost,127.0.0.1'
    https_proxy = 'http://user:pass@foo.example.com:3128'

    handler = SSLValidationHandler('myserver.example.com', 443)
    handler.make_context(None, None)

    handler = SSLValidationHandler('foo.example.com', 3128)

    # Should not throw 'ProxyError' exception
    handler.make_context(None, None)


# Generated at 2022-06-25 01:57:46.100756
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    no_proxy_1 = os.environ.get('no_proxy')
    os.environ['no_proxy'] = 'google.com, yahoo.com'
    url_1 = 'https://google.com:443'
    url_2 = 'https://yahoo.com'
    url_3 = 'https://yahoo.com:443'
    url_4 = 'https://bing.com:443'
    handler_obj = SSLValidationHandler('google.com', 443)
    assert handler_obj.detect_no_proxy(url_1) == False
    assert handler_obj.detect_no_proxy(url_2) == False
    assert handler_obj.detect_no_proxy(url_3) == False
    assert handler_obj.detect_no_proxy(url_4) == True