

# Generated at 2022-06-23 02:55:39.905600
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():

    assert SSLValidationHandler.make_context('cafile', 'cadata') == (None, None)


# Generated at 2022-06-23 02:55:50.591702
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import unittest
    class TestCase(unittest.TestCase):
        def test_patching(self):
            self.assertNotEqual(httplib.HTTPConnection.connect, UnixHTTPConnection.connect)
            with unix_socket_patch_httpconnection_connect():
                self.assertEqual(httplib.HTTPConnection.connect, UnixHTTPConnection.connect)
            self.assertNotEqual(httplib.HTTPConnection.connect, UnixHTTPConnection.connect)
    test_case = TestCase()
    test_case.test_patching()

    class TestCase(unittest.TestCase):
        def test_patching_1(self):
            self.assertNotEqual(httplib.HTTPConnection.connect, UnixHTTPConnection.connect)

# Generated at 2022-06-23 02:55:56.896987
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    """Test constructor of class UnixHTTPConnection"""
    unix_file_path = os.path.realpath(__file__)
    unix_http_connection = UnixHTTPConnection(unix_file_path)
    assert unix_http_connection is not None
    assert unix_http_connection._unix_socket == unix_file_path


# Generated at 2022-06-23 02:55:58.387450
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    res = SSLValidationHandler('www.example.com', 443)
    assert res is not None


# Generated at 2022-06-23 02:56:06.334333
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.utils import url

    module = MockModule()
    url.open_url = Mock()
    url.url_filename = Mock()
    url.fetch_url(module, 'http://www.example.com/test.txt')
    assert url.open_url.called
    assert url.url_filename.called
    assert url.fetch_url(module, 'http://www.example.com/test.txt') == (None, {'url': 'http://www.example.com/test.txt', 'status': -1})




# Generated at 2022-06-23 02:56:14.549131
# Unit test for method options of class Request
def test_Request_options():
    if request_support.__name__ == 'ansible.module_utils.urls.Request':
        request_support.test_start('test_Request_options')
        url_request = Request()
        url_response = url_request.options('https://www.google.com', timeout=12, headers={'User-Agent': 'ansible'})
        request_support.test_passed()


# Generated at 2022-06-23 02:56:24.807921
# Unit test for method head of class Request
def test_Request_head():
   
    # Initializing the HTTPResponse object
    resp = HTTPResponse()

    # Testing if the HTTPResponse object is initialized properly
    assert resp.status == 0
    assert resp.getheader('Accept-Encoding') == None

    # Initializing the Request object
    req = Request(use_proxy=True, unix_socket='/var/run/docker.sock', validate_certs=False, url_username='Requerio', url_password='1234567890')

    # Testing if the Request object is initialized properly
    assert req.use_proxy == True
    assert req.unix_socket == '/var/run/docker.sock'
    assert req.validate_certs == False
    assert req.url_username == 'Requerio'

# Generated at 2022-06-23 02:56:36.251533
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    try:
        import ssl
    except ImportError:
        raise SkipTest("Cannot run test on systems without ssl support")

    try:
        import http.client as http_client
    except ImportError:
        import httplib as http_client
    try:
        from urllib import request as urllib_request
    except ImportError:
        import urllib2 as urllib_request

    # NOTE: This test assumes you have a local webserver with certificate
    # authority set to C=US, ST=WA, L=Seattle, O=Ansible, CN=localhost, emailAddress=root@localhost
    # with a server certificate set to C=US, ST=WA, L=Seattle, O=Ansible, CN=localhost, emailAddress=root@localhost
    # set to listen on port 2222


# Generated at 2022-06-23 02:56:48.368853
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    class MockSSLValidationHandler(SSLValidationHandler):

        def __init__(self, *args, **kwargs):
            pass

        def make_context(self, cafile, cadata):
            return None

    class TestMock(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def __iter__(self):
            if self.kwargs.get('ensemblemime', '') == 'fail':
                raise OSError()
            return ['hello.crt', 'world.crt']


# Generated at 2022-06-23 02:57:02.053797
# Unit test for method head of class Request
def test_Request_head():
    # We do not need to test anything that is directly passed to urllib_request,
    # because we can't mock urllib_request.Request
    from ansible.utils.urls import Request
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    import pytest

    HTTP_PROXY = 'http://proxy.example.com:3128'
    HTTPS_PROXY = 'http://proxy.example.com:443'

    class FakeResponse:
        def __init__(self, code):
            self.code = code

    # GET /HEAD

# Generated at 2022-06-23 02:57:04.975712
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    assert UnixHTTPConnection('/tmp/doesnotexist')

#
# Utility classes and functions
#


# Generated at 2022-06-23 02:57:12.225602
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    # Sometimes the SSL entry point is not available because it is not installed
    # or because it was intentionally disabled
    ssl_entry_point = getattr(ssl, 'wrap_socket', None)
    if ssl_entry_point is None:
        return
    sock = '/tmp/foo.sock'
    try:
        unix_conn = UnixHTTPConnection(sock)
        assert unix_conn.host == 'localhost'
        assert unix_conn.port == httplib.HTTP_PORT
        assert unix_conn._unix_socket == sock
    except unix_conn.timeout:
        pytest.skip('timeout on unix socket')



# Generated at 2022-06-23 02:57:16.761780
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    ca_file = b'/path/to/ca_file'
    ca_data = b'ca_data'
    handler = SSLValidationHandler(b'test_hostname', 443, ca_file)
    handler.make_context(ca_file, ca_data)


# Generated at 2022-06-23 02:57:22.558738
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    if not PY3:
        assert_equal(RequestWithMethod('', 'a').get_method(), 'a')
    else:
        assert_equal(RequestWithMethod('', 'a').get_method(), 'A')
    assert_equal(RequestWithMethod('', '').get_method(), 'GET')


# dummy regex for a unix socket
UNIX_SOCKET_REGEX = re.compile(r'^\S+\.\S+$')



# Generated at 2022-06-23 02:57:27.477363
# Unit test for method patch of class Request
def test_Request_patch():
    try:
        urllib2 = imp.find_module('urllib2')
    except ImportError:
        urllib2 = imp.find_module('urllib.request')
    urllib2 = imp.load_module('urllib2', *urllib2)
    request = Request(None)
    request.urllib2 = urllib2
    request.open('GET', 'http://localhost/')


# Generated at 2022-06-23 02:57:34.155372
# Unit test for method get of class Request
def test_Request_get():
    url = """http://192.168.1.1:80/status"""
    urlusername = """admin"""
    urlpassword = """pass"""
    useproxy = False
    validatecerts = True
    request = Request
    expected_result = HTTPResponse

    result = request.get(url, urlusername, urlpassword, useproxy, validatecerts)
    assert (result == expected_result)



# Generated at 2022-06-23 02:57:41.400051
# Unit test for method put of class Request
def test_Request_put():
    kwargs = {}
    kwargs['url'] = "https://httpbin.org/put"
    try:
        url = "https://httpbin.org/put"
        payload = {'upload_file': open('D:/temp/1.txt', 'rb')}
        files = [
            ('upload_file', open('D:/temp/2.txt', 'rb'))
        ]
        data = Requests_put(url, files=files)
        print(data.text)
    except Exception as e:
        print(e)
    return data


# Generated at 2022-06-23 02:57:52.253556
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    http_handler = maybe_add_ssl_handler("https://www.google.com", True)
    assert type(http_handler) == SSLValidationHandler
    assert http_handler.ca_path == None
    assert http_handler.hostname == "www.google.com"
    assert http_handler.port == 443
    http_handler = maybe_add_ssl_handler("https://www.google.com", False)
    assert http_handler == None
    http_handler = maybe_add_ssl_handler("http://www.google.com", False)
    assert http_handler == None
    http_handler = maybe_add_ssl_handler("http://www.google.com", True)
    assert http_handler == None


# Generated at 2022-06-23 02:58:03.501800
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url = 'http://foo.com'
    url_with_port = 'http://foo.com:8080'
    testcase = [
        ('', True),
        ('foo.com', False),
        ('localhost', False),
        ('bar.com', True),
        ('foo.com,bar.com', False),
        ('localhost,foo.com,bar.com', False),
        ('bar.com,foo.com', False),
        (' localhost,foo.com,bar.com', False), # extra space after ,
        ('bar.com, foo.com', False), # extra space after ,
        ('foo.com,localhost,bar.com', False),
    ]
    for no_proxy, should_use_proxy in testcase:
        os.environ['no_proxy'] = no_proxy
        ssl_

# Generated at 2022-06-23 02:58:07.366967
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    ca_path = '/etc/ansible/user_ca.crt'
    cadata = bytearray()
    handler = SSLValidationHandler('foo', 443, ca_path)
    context = handler.make_context(ca_path, None)
    return context

# Generated at 2022-06-23 02:58:16.567855
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    assert httplib.HTTPConnection.connect is not UnixHTTPConnection.connect
    with unix_socket_patch_httpconnection_connect():
        httplib.HTTPConnection()
    assert httplib.HTTPConnection.connect is not UnixHTTPConnection.connect

    class SubHTTPConnection(httplib.HTTPConnection):
        def __init__(self):
            super(SubHTTPConnection, self).__init__()

    assert SubHTTPConnection.connect is not UnixHTTPConnection.connect
    with unix_socket_patch_httpconnection_connect():
        SubHTTPConnection()
    assert SubHTTPConnection.connect is not UnixHTTPConnection.connect

    class SubsubHTTPConnection(SubHTTPConnection):
        def __init__(self):
            super(SubsubHTTPConnection, self).__init__()

    assert SubsubHTTPConnection.connect is not UnixHTTPConnection.connect

# Generated at 2022-06-23 02:58:29.091093
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # simple test for function
    r = prepare_multipart(
        {
            'field': 'value',
            'file1': {
                'filename': '/bin/true',
                'mime_type': 'application/octet-stream'
            },
            'file2': {
                'content': 'text based file content',
                'filename': 'fake.txt',
                'mime_type': 'text/plain',
            }
        }
    )
    assert r[0] == 'multipart/form-data'
    assert b'form-data; name="field"' in r[1]
    assert b'form-data; name="file1"; filename="true"' in r[1]
    assert b'form-data; name="file2"; filename="fake.txt"' in r[1]

# Generated at 2022-06-23 02:58:31.531198
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    request = RequestWithMethod("http://www.example.com", "GET")
    assert request.get_method() == "GET"
    try:
        urllib_request.urlopen(request)
    except urllib_request.HTTPError as e:
        # Note this is probably a failure to connect to the web server,
        # not a problem with our implementation
        pass



# Generated at 2022-06-23 02:58:42.677229
# Unit test for method validate_proxy_response of class SSLValidationHandler

# Generated at 2022-06-23 02:58:46.509821
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    with tempfile.NamedTemporaryFile() as k,\
         tempfile.NamedTemporaryFile() as c:
        unix_https_connection = UnixHTTPSConnection('/does/not/exist')
        unix_https_connection.key_file = k.name
        unix_https_connection.cert_file = c.name
        with pytest.raises(IOError):
            unix_https_connection.connect()


#
# Function and classes related to retry mechanism
#


# Generated at 2022-06-23 02:58:50.844131
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    class FakeContext(object):
        wrap_socket = lambda self, sock, server_hostname=None: sock
    class FakeSocket(object):
        def __init__(self, file=None):
            self.file = file
        def fileno(self):
            return self.file
        def shutdown(self, *args, **kwargs):
            pass
    try:
        CustomHTTPSHandler(context=FakeContext())
    except AttributeError:
        # Has no _context attribute
        assert True
    return True

if HAS_KERBEROS:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
        """HTTPS client authentication handler.

        Thanks to Laszlo Nagy for the original patch.
        """


# Generated at 2022-06-23 02:59:06.332455
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule(argument_spec=dict(url=dict(type='str'),
                                              dest=dict(type='path'),))
    url = "http://example.com"
    data = None
    headers = {'Accept-Encoding': 'gzip,deflate', 'Accept': 'application/json'}
    method = "GET"
    use_proxy = True
    force = False
    last_mod_time = None
    timeout = 10
    unredirected_headers = None
    try:
        fetch_file(module, url, data, headers, method, use_proxy, force, last_mod_time, timeout, unredirected_headers)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFailJson)

# Generated at 2022-06-23 02:59:08.278961
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    error = SSLValidationError('foo')
    assert error.args[0] == 'foo'
    assert error == 'foo'


# Generated at 2022-06-23 02:59:20.598837
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''Assert that a dictionary of parts is returned when generic_urlparse is called'''
    orig_urlparse = urllib_parse.urlparse

# Generated at 2022-06-23 02:59:24.143163
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    from ansible.module_utils.urls import open_url
    # Testing the equivalent of 'curl -vvv -I https://www.google.de'
    response = open_url("https://www.google.de", validate_certs=False)
    assert response.read()
    response.close()


# Generated at 2022-06-23 02:59:33.052279
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    error message should include all strings in msg
    '''

# Generated at 2022-06-23 02:59:35.796167
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    conn = UnixHTTPSConnection('/foo/bar')

    # Calling the object should return the initialized object,
    # which is being used by the client to call httplib.HTTPSConnection
    assert conn('example.com') == conn



# Generated at 2022-06-23 02:59:39.958614
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    class HTTPConnection(object):
        def __init__(self, *args, **kwargs):
            pass

        def connect(self):
            pass

    class UnixHTTPHandler(urllib_request.HTTPHandler):
        def __init__(self, *args, **kwargs):
            pass

        def do_open(self, http_class, req):
            return 'Successful connection established!'

    unix_handler = UnixHTTPHandler()
    response = unix_handler.do_open(HTTPConnection, 'https:///var/run/docker.sock')
    assert response == 'Successful connection established!'


# Generated at 2022-06-23 02:59:45.767832
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    prdd = ParseResultDottedDict(scheme='scheme',netloc='netloc',path='path',params='params',query='query',fragment='fragment')
    assert prdd.as_list() == ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']
    assert prdd.as_list() == prdd.values()

#
# Utility functions
#


# Generated at 2022-06-23 02:59:47.203687
# Unit test for method head of class Request
def test_Request_head():
    req = Request()
    req.head('github.com')



# Generated at 2022-06-23 02:59:49.951515
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('http://httpbin.org/get', 'get')
    if req.get_method() != 'GET':
        raise Exception("Wrong method get_method()")



# Generated at 2022-06-23 03:00:02.099825
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    if not hasattr(httplib, 'HTTPSConnection') or not hasattr(urllib_request, 'HTTPSHandler'):
        return
    import tempfile
    import os
    import stat
    import sys

    class DummySocket(object):
        def recv(self, n):
            raise socket.error('Socket closed')

        def send(self, data):
            raise socket.error('Socket closed')

        def makefile(self, mode, bufsize):
            return tempfile.TemporaryFile(mode=mode)

    dummy = DummySocket()
    fd1 = tempfile.NamedTemporaryFile()
    fd2 = tempfile.NamedTemporaryFile()
    # This is needed because Python 2.6 on Debian does not have os.fchmod.

# Generated at 2022-06-23 03:00:12.872150
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    # Arrange
    ca_file = "tests/testdata/test_certs/salt_ca.crt"
    ca_data = None
    expected_default_verify_paths = ssl.DefaultVerifyPaths()

    # Act
    # Assert
    # 1. When neither ca_file nor ca_data is provided
    handler = SSLValidationHandler(None, None)
    context = handler.make_context(None, None)
    assert context.load_default_certs() == expected_default_verify_paths
    # 2. When ca_file is provided
    handler = SSLValidationHandler(None, None)
    context = handler.make_context(ca_file, None)
    assert context.get_ca_certs()[0] == ca_file
    # 3. When ca_data

# Generated at 2022-06-23 03:00:20.394289
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    try:
        # Using "certifi" module to get the SSL certificate data
        ca_path = CA_BUNDLE_PATH
        hostname = 'pypi.python.org'

        handler = SSLValidationHandler(hostname, 443, ca_path)
        assert handler is not None
    except SSLValidationError as e:
        # The SSL certificate not installed on current machine, so should
        # got error message here
        assert False


# Generated at 2022-06-23 03:00:27.534736
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    urlparse = generic_urlparse(urlparse('http://www.google.com'))
    assert urlparse.scheme == 'http'
    assert urlparse.hostname == 'www.google.com'
    assert urlparse.port is None

    urlparse = generic_urlparse(urlparse('http://www.google.com:8080'))
    assert urlparse.port == 8080

    urlparse = generic_urlparse(urlparse('http://admin@www.google.com:8080'))
    assert urlparse.port == 8080
    assert urlparse.username == 'admin'

    urlparse = generic_urlparse(urlparse('http://admin:1234@www.google.com:8080'))
    assert urlparse.port == 8080
    assert urlparse.username == 'admin'
    assert urlparse.password

# Generated at 2022-06-23 03:00:32.014240
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    expected_method = 'GET'
    req = RequestWithMethod('http://www.google.com', expected_method)
    assert req.get_method() == expected_method
    req = RequestWithMethod('http://www.google.com', 'post')
    assert req.get_method() == 'POST'


# Generated at 2022-06-23 03:00:35.101457
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError('test')
    except Exception as e:
        assert str(e) == 'test'



# Generated at 2022-06-23 03:00:37.273680
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(None) is None



# Generated at 2022-06-23 03:00:45.551292
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    ssl_handler = SSLValidationHandler('myhost', 443)
    url = 'https://myhost:443'

    os.environ['no_proxy'] = 'foo.com, bar.com'
    assert ssl_handler.detect_no_proxy(url)
    os.environ['no_proxy'] = 'foo.com, myhost.com, bar.com'
    assert not ssl_handler.detect_no_proxy(url)
    os.environ['no_proxy'] = 'foo.com, myhost, bar.com'
    assert not ssl_handler.detect_no_proxy(url)
    os.environ['no_proxy'] = '*'
    assert not ssl_handler.detect_no_proxy(url)
    del os.environ['no_proxy']
   

# Generated at 2022-06-23 03:00:48.931362
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    assert ParseResultDottedDict({'scheme': 'http', 'netloc': 'foo', 'path': 'bar'}).as_list() == ['http', 'foo', 'bar', None, None, None]



# Generated at 2022-06-23 03:00:58.954024
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():

    global_kwargs = dict(timeout=timeout, source_address=source_address)

    def _test(expected_args, expected_kwargs, *args, **kwargs):
        with patch('ansible.module_utils.urls.UnixHTTPConnection.__init__', autospec=True) as mock_init:
            with patch('ansible.module_utils.urls.UnixHTTPConnection.connect', autospec=True) as mock_connect:
                instance = UnixHTTPConnection('/tmp/foo')(*args, **kwargs)
                mock_init.assert_called_once_with(instance, *expected_args, **expected_kwargs)
                mock_connect.assert_called_once_with(instance)
                return instance

    # No args
    instance = _test((), global_kwargs)

# Generated at 2022-06-23 03:01:06.195943
# Unit test for constructor of class Request
def test_Request():
    def test_Request_1():
        url = 'http://www.google.com'
        method = 'GET'
        data = None
        request = RequestWithMethod(url, method, data)
        assert request.get_method() == 'GET'
        assert request.get_type() == 'http'

    def test_Request_2():
        url = 'https://www.google.com'
        method = 'POST'
        data = None
        request = RequestWithMethod(url, method, data)
        assert request.get_method() == 'POST'
        assert request.get_type() == 'https'

    def test_Request_3():
        url = 'ftp://www.google.com'
        method = 'HEAD'
        data = None
        request = RequestWithMethod(url, method, data)

# Generated at 2022-06-23 03:01:10.849151
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    expected = ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']
    d = ParseResultDottedDict()
    assert sorted(d.as_list()) == sorted(expected), 'ParseResultDottedDict.as_list has changed. please update this test.'
    d = ParseResultDottedDict(foo='bar')
    assert sorted(d.as_list()) == sorted(expected), 'ParseResultDottedDict.as_list has changed. please update this test.'



# Generated at 2022-06-23 03:01:12.954262
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod('http://a/', 'GET')
    request._method = 'POST'
    assert request.get_method() == 'POST'

    request = RequestWithMethod('http://a/', 'GET')
    request._method = None
    assert request.get_method() == 'GET'

#
# Functions
#



# Generated at 2022-06-23 03:01:25.947465
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn = CustomHTTPSConnection('example.com', 123)
    conn._tunnel_host = 'example.com'
    sock = mock.MagicMock()
    sock.recv = mock.Mock(return_value=b'HTTP/1.1 200 OK\r\n\r\n')
    sock.fileno = mock.Mock(return_value=None)
    conn.send = mock.Mock()
    conn.close = mock.Mock()
    conn.sock = sock
    conn._tunnel = mock.Mock()
    class FakeCtxt(object):
        def wrap_socket(self, sock, server_hostname=None):
            return sock
    conn._context = FakeCtxt()
    conn.connect()
    assert conn.sock == sock
    assert conn.close.called


#

# Generated at 2022-06-23 03:01:33.247229
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler(hostname='', port=443, ca_path=None)
    response = None
    # check that this code block exits with no exceptions when we pass in a valid http response code
    try:
        response = b'HTTP/1.0 200 Connection Established\r\n\r\nHTTP/1.1 200 OK\r\n\r\n'
        handler.validate_proxy_response(response, valid_codes=[200])
    except ProxyError:
        raise AssertionError('Unexpected ProxyError when using 200 code')
    # check that this code block exits with no exceptions when we pass in a non-default valid http response code

# Generated at 2022-06-23 03:01:44.802715
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    port = 12345
    conn = CustomHTTPSConnection('localhost', port)
    assert hasattr(conn, 'context')
    assert conn.context == None
    if HAS_URLLIB3_PYOPENSSLCONTEXT :
        assert hasattr(conn, '_context')
        assert isinstance(conn._context, type(ssl.SSLContext(ssl.PROTOCOL_TLSv1)))
        assert conn._context == conn.context
    assert hasattr(conn, 'cert_file')
    assert conn.cert_file == None
    assert hasattr(conn, 'key_file')
    assert conn.key_file == None
    assert hasattr(conn, 'host')
    assert conn.host == 'localhost'
    assert hasattr(conn, 'port')
    assert conn.port == port

# Generated at 2022-06-23 03:01:56.114265
# Unit test for function getpeercert
def test_getpeercert():
    from mock import patch, Mock
    from requests.structures import CaseInsensitiveDict
    class MyHTTPResponse(object):
        def __init__(self):
            self.fp = Mock()

    response1 = MyHTTPResponse()
    response2 = MyHTTPResponse()
    request1 = Mock()
    request1.get_method.return_value = 'GET'
    request1.headers = CaseInsensitiveDict({'Accept-Encoding': 'None'})
    request2 = Mock()
    request2.get_method.return_value = 'GET'
    request2.headers = CaseInsensitiveDict({'Accept-Encoding': 'None'})


# Generated at 2022-06-23 03:02:09.267297
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 03:02:19.430970
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    cur_socket_file = None

# Generated at 2022-06-23 03:02:28.565538
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    c = CustomHTTPSConnection(None, None)
    assert c.context is None
    c._context = 'testing'
    c.connect()
    assert c.context == 'testing'
    assert c.sock == 'testing'



# Generated at 2022-06-23 03:02:34.594777
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    url = 'http://www.example.com'
    unix_socket = './test_http_open.sock'
    req = urllib_request.Request(url)
    with open(unix_socket, 'w'):
        unix_handler = UnixHTTPHandler(unix_socket)
        unix_handler.http_open(req)
        assert os.path.exists(unix_socket)
        os.remove(unix_socket)



# Generated at 2022-06-23 03:02:37.823133
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    assert fetch_file(module, 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png')



# Generated at 2022-06-23 03:02:47.378449
# Unit test for method post of class Request
def test_Request_post():
    data = b'''
            {
              "login": {
                "username": "0d536ca0-68b6-11e6-b472-06caca9e4618",
                "password": "sh12345"
              }
            }
            '''
    headers = {'Content-Type': 'application/json;charset=UTF-8'}

    url = 'https://10.30.1.227/api/v2/monitor/login'
    response = Request('').post(url, headers=headers, data=data)
    with open('b.html', 'wb') as f:
        f.write(response.read())



# Generated at 2022-06-23 03:03:06.691556
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(client_cert='foo', client_key='bar', unix_socket='whatever')
    assert handler.client_cert == 'foo'
    assert handler.client_key == 'bar'
    assert handler._unix_socket == 'whatever'

if HAS_SSLCONTEXT:
    class UnixHTTPSConnection(httplib.HTTPConnection):
        def __init__(self, unix_socket=None, *args, **kwargs):
            httplib.HTTPConnection.__init__(self, *args, **kwargs)
            self._unix_socket = unix_socket

        def connect(self):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self._unix_socket)
            self.sock = ssl

# Generated at 2022-06-23 03:03:17.944702
# Unit test for function getpeercert
def test_getpeercert():
    """
    Test for function getpeercert
    """
    response = dict(
        fp=dict(
            _sock=dict(
                fp=dict(
                    _sock=dict(
                        getpeercert=lambda *args: 'foobar'
                    )
                )
            )
        )
    )
    assert getpeercert(response) == 'foobar'

    response['fp']['_sock']['fp']['_sock'] = None
    assert getpeercert(response) is None

    response['fp']['_sock']['fp']['_sock'] = 'foobar'
    assert getpeercert(response) == 'foobar'



# Generated at 2022-06-23 03:03:25.292911
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    """
    Unit Test for RedirectHandlerFactory
    """
    import json
    import six
    import os
    import sys
    import yaml
    from io import StringIO
    from unittest import mock
    from ansible.module_utils import basic
    from ansible.module_utils.urls import *
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    # Create a fake module object
    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # We are going to update the module's return values
    # depending on the parameters we test
    def module_fail_json(msg):
        module.fail_json(msg=msg)

    # The lines below are needed to fake a basic module env

# Generated at 2022-06-23 03:03:35.659693
# Unit test for function fetch_url
def test_fetch_url():
    # Test pre-reqs: create mock module
    module = MockModule()

    # Make a temp file for testing
    temp_dir = tempfile.gettempdir()
    _, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Set up return values
    temp_dir_used = module.params['tmpdir']
    temp_dir_return = temp_dir_used.encode('utf-8')
    url = 'file://' + temp_file
    data = None
    headers = None
    method = None
    use_proxy = False
    force = True
    last_mod_time = None
    timeout = 10
    validate_certs = True
    use_gssapi = False
    ca_path = None

    # Write content to file
    content = "test"

# Generated at 2022-06-23 03:03:46.152397
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Simple test for method get_ca_certs of class SSLValidationHandler
    hostname = 'example.org'
    port = 443
    ca_path = '/etc/ssl/certs/ca-certificates.crt'
    handler = SSLValidationHandler(hostname, port, ca_path)
    tmp_ca_cert_path, cadata, paths_checked = handler.get_ca_certs
    assert tmp_ca_cert_path == '/etc/ssl/certs/ca-certificates.crt'
    assert cadata == None
    assert paths_checked == ['/etc/ssl/certs/ca-certificates.crt', '/etc/pki/ca-trust/extracted/pem', '/etc/pki/tls/certs', '/etc/ansible']


# Generated at 2022-06-23 03:03:49.630515
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError(u'string')
    except SSLValidationError as exc:
        assert(exc.message == 'string')
        assert(exc.args[0] == 'string')



# Generated at 2022-06-23 03:03:59.547594
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    '''Unit test of UnixHTTPConnection'''
    with NamedTemporaryFile(mode='w') as tf:
        tf.write('#!/bin/sh\n')
        tf.write('echo hello\n')
        tf.flush()
        tf.seek(0)
        os.chmod(tf.name, 0o755)
        conn = UnixHTTPConnection(tf.name)
        conn.request('GET', '/')
        resp = conn.getresponse()
        data = resp.read()
        conn.close()
    assert data == b'hello'
#
# HTTP and HTTPS Handlers
#



# Generated at 2022-06-23 03:04:09.808329
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(client_cert='/path/to/cert/file',
                                     client_key='/path/to/key/file',
                                     unix_socket='/path/to/socket')
    # client_cert and client_key should be set
    assert_equal(handler.client_cert, '/path/to/cert/file')
    assert_equal(handler.client_key, '/path/to/key/file')


# This is a little hack to work around a bug in how proxy support works in urllib/urllib2
# See https://bugs.python.org/issue1424152 and https://github.com/ansible/ansible/issues/12682
# NoProxyHandler disables the proxy if the url matches a NO_PROXY variable

# Generated at 2022-06-23 03:04:16.952984
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    uut = UnixHTTPSConnection("unix-socket")
    with unix_socket_patch_httpconnection_connect():
        uut(host="host", port=1)
        assert hasattr(uut, "sock")



# Generated at 2022-06-23 03:04:26.804731
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():

    try:
        urllib_request.HTTPSHandler()
    except AttributeError as ae:
        assert ae.args[0] == '_context'

    # test if new HTTPSClientAuthHandler replace old HTTPSClientAuthHandler
    old_handler = urllib_request.HTTPSHandler
    urllib_request.HTTPSHandler = HTTPSClientAuthHandler
    urllib_request.HTTPSHandler()
    urllib_request.HTTPSHandler = HTTPSClientAuthHandler(
        client_cert='test_cert', client_key='test_key')
    urllib_request.HTTPSHandler()
    # restore old HTTPSClientAuthHandler
    urllib_request.HTTPSHandler = old_handler

# This is used if the ca file is not available on the system.  This is the
# case on some older EL6

# Generated at 2022-06-23 03:04:31.178403
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError("This is a proxy error")
    except Exception as e:
        assert e.args[0] == "This is a proxy error"
        assert e.__class__.__name__ is "ProxyError"
        assert str(e) == "ProxyError: This is a proxy error"



# Generated at 2022-06-23 03:04:32.309621
# Unit test for method head of class Request
def test_Request_head():
    pass



# Generated at 2022-06-23 03:04:41.680247
# Unit test for method open of class Request
def test_Request_open():
    # 1. Create an instance of the class
    obj_req = Request(force_basic_auth=False, use_gssapi=False, unredirected_headers=[])

    url = 'https://docs.ansible.com'
    method = 'GET'

    # 2. Call the method
    result = obj_req.open(method, url)

    # 3. Assert the result
    assert_that(result, instance_of(HTTPResponse))
    assert_that(result.code, is_not(0))
    assert_that(result.code, is_(any_of(200, 304)))

    # 4. Cleanup
    obj_req = None
    result = None


# Generated at 2022-06-23 03:04:45.459908
# Unit test for method head of class Request
def test_Request_head():
    # head
    url = 'https://ansible.com'
    r = Request()
    response = r.head(url)
    print(response.getcode())
    print(response.info())
    print(response.geturl())

# Generated at 2022-06-23 03:04:52.641189
# Unit test for method head of class Request
def test_Request_head():
    url = 'https://docs.python.org/3.5/library/urllib.request.html?highlight=urlretrieve#module-urllib.request'
    headers = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0'}
    # data = urllib.request.Request(url)
    # data.add_header('User-agent', headers['User-agent'])
    # data = Request(url=url, headers=headers)
    data = Request(url)
    # data1 = Request(url, headers=headers)
    # data.add_header('User-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; r

# Generated at 2022-06-23 03:04:55.263897
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError()
    except Exception as e:
        assert str(e) == ''
        assert repr(e) == 'ConnectionError()'



# Generated at 2022-06-23 03:05:06.209686
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import types

    assert httplib.HTTPConnection.connect != UnixHTTPConnection.connect
    with unix_socket_patch_httpconnection_connect():
        assert httplib.HTTPConnection.connect == UnixHTTPConnection.connect
    assert httplib.HTTPConnection.connect != UnixHTTPConnection.connect

    try:
        old_connect = httplib.HTTPConnection.connect
        with unix_socket_patch_httpconnection_connect():
            assert httplib.HTTPConnection.connect == UnixHTTPConnection.connect
            httplib.HTTPConnection.connect = old_connect
            with pytest.raises(RuntimeError):
                with unix_socket_patch_httpconnection_connect():
                    pass
    finally:
        # Restore the original function
        httplib.HTTPConnection.connect = old_connect



# Generated at 2022-06-23 03:05:18.044273
# Unit test for function open_url
def test_open_url():
    url = 'https://urllib_test:8080'
    kwargs = dict(url_username='user', url_password='password',
                  use_proxy=False, force=True,
                  force_basic_auth=True,
                  follow_redirects='urllib2',
                  client_cert='cert',
                  ca_path='path',
                  unix_socket='socket')
    request = Request()
    response = request.open('GET', url, **kwargs)
    if responses:
        assert isinstance(response, HTTPResponse)
    else:
        assert isinstance(response, urllib_error.URLError) or isinstance(response, URLError)

if __name__ == '__main__':
    test_open_url()

# Generated at 2022-06-23 03:05:29.575583
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """
    Tests that get_channel_binding_cert_hash returns the expected value
    """

# Generated at 2022-06-23 03:05:32.289431
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    '''Unit test to try and make sure we can construct a UnixHTTPHandler'''
    try:
        UnixHTTPHandler(unix_socket='')
    except TypeError:
        # If there is a TypeError then we are still failing to construct the handler
        # due to internal implemenation details.  This is bad, but we'll take it.
        raise
    except Exception:
        # The constructor should succeed without an exception
        assert False

#
# HTTP Handler code
#


# Generated at 2022-06-23 03:05:38.561822
# Unit test for method delete of class Request
def test_Request_delete():
  r = Request()
  assert isinstance(r.delete('a'), object)
