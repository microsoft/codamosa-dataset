

# Generated at 2022-06-23 02:55:43.842485
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('Test: %s', 'badness')
    except ProxyError as e:
        if "Test: badness" not in to_native(e):
            raise AssertionError("ProxyError('Test: %s', 'badness') should "
                                 "have printed 'Test: badness'")
    else:
        raise AssertionError("ProxyError('Test: %s', 'badness') should have "
                             "raised an exception")


# Generated at 2022-06-23 02:55:56.020864
# Unit test for function url_argument_spec
def test_url_argument_spec():
    ''' ansible.module_utils.urls.url_argument_spec() unittest'''
    mocker, url_mod = mocker_setup()


# Generated at 2022-06-23 02:56:04.298212
# Unit test for function url_argument_spec

# Generated at 2022-06-23 02:56:05.368676
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    exc = SSLValidationError()
    assert isinstance(exc, ConnectionError)



# Generated at 2022-06-23 02:56:07.581256
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    assert UnixHTTPConnection('/tmp/test.sock')('127.0.0.1', 8080)


#
# Helpers
#



# Generated at 2022-06-23 02:56:14.548936
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pe = ProxyError()
    assert ProxyError.__class__ == type(pe)
    assert ConnectionError.__class__ == type(pe)
    assert Exception.__class__ == type(pe)
    assert type(pe) == type(ProxyError())
    assert type(pe) == ProxyError.__class__



# Generated at 2022-06-23 02:56:18.849846
# Unit test for method delete of class Request
def test_Request_delete():
    url = "http://www.example.com"
    request = Request()
    #test error url
    url_error = ""
    with pytest.raises(ValueError) as excinfo:
        request.delete(url_error)
    #test url success
    url_success = url
    request.delete(url_success)

# Generated at 2022-06-23 02:56:24.947274
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    validate_certs = True
    url = 'https://127.0.0.1/'
    ssl_handler = maybe_add_ssl_handler(url, validate_certs)
    assert isinstance(ssl_handler, SSLValidationHandler)

    url = 'http://127.0.0.1:80/image/create'
    ssl_handler = maybe_add_ssl_handler(url, validate_certs)
    assert ssl_handler is None


# Generated at 2022-06-23 02:56:27.900156
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    test_file = '/tmp/test_file.txt'
    with open(test_file, 'wt') as f:
        f.write("hello")
    atexit_remove_file(test_file)
    assert not os.path.exists(test_file)



# Generated at 2022-06-23 02:56:29.038715
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError.__doc__ == ProxyError.__init__.__doc__



# Generated at 2022-06-23 02:56:36.872099
# Unit test for method options of class Request
def test_Request_options():
    req = Request()
    # Pass http
    urls = ['http://www.google.com/']
    # Pass https
    urls.append('https://www.google.com/')
    # Pass ftp
    urls.append('ftp://ftp.google.com/')
    # Pass invalid urls
    urls.append('abcd://google.com/')
    urls.append('google.com/')
    for test_url in urls:
        try:
            resp = req.options(test_url)
        except Exception:
            pass
        finally:
            if resp:
                resp.close()
    return True


# Generated at 2022-06-23 02:56:42.439073
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    class MockConnection(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def request(self, req):
            self.req = req

        def getresponse(self):
            return self.response

        def close(self):
            pass

    class MockHTTPConnection(object):
        def __init__(self, *args, **kwargs):
            pass

        def _connection_from_host(self, host, port, timeout=300, source_address=None):
            return MockConnection(host, port, timeout, source_address)

    class MockHTTPSHandler(HTTPSClientAuthHandler):
        def _build_https_connection(self, host, **kwargs):
            return MockHTTPConnection(host, **kwargs)


# Generated at 2022-06-23 02:56:50.672343
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''
    This function was added to test the UnixHTTPSConnection constructor
    It is a bit too simple; it would be better if it tried to actually connect
    to a socket but it seems like overkill for now
    '''
    conn = UnixHTTPSConnection('/some/random/file')
    assert conn._unix_socket == '/some/random/file'

##############################
#
# HTTP/S request functions
#
##############################

# from the requests library

# we alias the function here since it is needed in several places
# we use this so that the signature is the same

# Generated at 2022-06-23 02:56:55.760426
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    # pylint: disable=protected-access
    # positive case
    connection = UnixHTTPConnection('/var/run/docker.sock')
    assert connection.sock is None
    assert connection._unix_socket == '/var/run/docker.sock'

    # negative case
    collection = UnixHTTPConnection('')
    assert collection.sock is None
    assert collection._unix_socket == ''

if CustomHTTPSConnection:
    DocHTTPConnection = CustomHTTPSConnection
    DocHTTPSHandler = CustomHTTPSHandler
else:
    DocHTTPConnection = httplib.HTTPConnection
    DocHTTPSHandler = urllib_request.HTTPSHandler

#
# Basic authentication
#


# Generated at 2022-06-23 02:57:07.013962
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    ca_path = '/etc/ansible/keys/'
    sslvh = SSLValidationHandler('example.com', 443, ca_path)
    tmp_ca_cert_path, cadata, paths_checked = sslvh.get_ca_certs()
    context = sslvh.make_context(tmp_ca_cert_path, cadata)
    assert context is not None, 'Cannot create context with cadata'

    cafile = '/etc/ssl/certs/ca-certificates.crt'
    context = sslvh.make_context(cafile, None)
    assert context is not None, 'Cannot create context with cafile'

    context = sslvh.make_context('', None)
    assert context is not None, 'Cannot create context with empty cafile'



# Generated at 2022-06-23 02:57:10.558548
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    class NoSSLErrorTest(NoSSLError):
        def __init__(self):
            pass
    NoSSLErrorTest()


# Generated at 2022-06-23 02:57:18.255406
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # First, check that follow_redirects='urllib2' works
    follow_redirects='urllib2'
    req = urllib_request.Request('https://www.google.com/')
    handler = RedirectHandlerFactory(follow_redirects)(req, 502)
    with pytest.raises(urllib_error.HTTPError) as e:
        handler.http_error_302(req, urllib_response.addinfourl('fakedata', {}), 302, 'Found', {})
    assert e.value.code == 302

    # Now check that follow_redirects='no', which should raise an error
    follow_redirects='no'
    req = urllib_request.Request('https://www.google.com/')

# Generated at 2022-06-23 02:57:23.038943
# Unit test for method delete of class Request
def test_Request_delete():
    url = "http://www.example.com"
    r = request.Request()
    try:
        result = r.delete(url)
    except Exception as e:
        print(e)
        exit(1)
    if result is None and result == urllib_request.urlopen(r.delete(url)):
        exit(0)
    else:
        exit(1)


# Generated at 2022-06-23 02:57:23.789049
# Unit test for method options of class Request
def test_Request_options():
    pass



# Generated at 2022-06-23 02:57:35.136335
# Unit test for function getpeercert
def test_getpeercert():

    # Test with a pem file which should be a dictionary
    pemfile = os.path.join('test/units', '.test.pem')
    response = urllib_request.urlopen(pemfile)
    assert isinstance(getpeercert(response), dict)

    # Test with a non-existent file which should return None
    response = urllib_request.urlopen('file:///foo/bar/baz.pem')
    assert getpeercert(response) is None

    # Test with an http url, that should return a binary
    response = urllib_request.urlopen('https://github.com')
    assert isinstance(getpeercert(response, binary_form=True), bytes)

    # Test with an http url, that should return a dictionary
    response = urllib_request.urlopen

# Generated at 2022-06-23 02:57:35.992248
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    pass



# Generated at 2022-06-23 02:57:39.850080
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(None) is None
    assert getpeercert(None, binary_form=True) is None


_DEFAULT_TIMEOUT = 30.0

RETRY_ATTEMPTS = 3
RETRY_DELAY = 5



# Generated at 2022-06-23 02:57:48.346704
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    if not HAS_HTTPS_CLIENT_AUTH_HANDLER:
        pytest.skip("This test can only be run on Python >= 2.7.9")

    class FakeRequest:
        def add_header(self, name, value): pass

    # Create a fake handler.
    fake_handler = HTTPSClientAuthHandler(client_cert="/fake/cert.pem", client_key="/fake/key.pem")

    # Test with a non-unix domain socket.
    fake_socket = FakeSocket()
    fake_handler._build_https_connection = mock.Mock(return_value=fake_socket)
    fake_request = FakeRequest()
    fake_handler.https_open(fake_request)
    fake_handler._build_https_connection.assert_called_with(host="")

    # Test with a un

# Generated at 2022-06-23 02:57:51.113528
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    r = RequestWithMethod('some_url', 'GET')
    r.get_method() == 'GET'
    r = RequestWithMethod('some_url', 'POST')
    r.get_method() == 'POST'
    r = RequestWithMethod('some_url', 'PUT')
    r.get_method() == 'PUT'
    r = RequestWithMethod('some_url', 'DELETE')
    r.get_method() == 'DELETE'



# Generated at 2022-06-23 02:58:02.503098
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect(): # pylint: disable=too-many-statements
    import_traceback = ''
    if PY3:
        try:
            # Only needed by Python3
            import http.server  # pylint: disable=import-error,no-name-in-module
        except ImportError:
            import_traceback = ''.join(traceback.format_exc())
            http = None
    else:
        import SimpleHTTPServer  # pylint: disable=import-error
        import SocketServer  # pylint: disable=import-error

    # Do not run unit test on systems that don't have socket support
    if not hasattr(socket, 'AF_UNIX'):
        raise SkipTest('System does not support Unix sockets. Skipping UnixHTTPSConnection tests.')

    # We want a socket that starts with a underscore to ensure

# Generated at 2022-06-23 02:58:15.509342
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    handler = CustomHTTPSHandler()
    assert isinstance(handler, urllib_request.HTTPSHandler)


if HAS_PYOPENSSL and HAS_HTTPS_CLIENTAUTH:
    class UnixHTTPSConnection(httplib.HTTPConnection, object):
        """
        A custom HTTPSConnection that connects to a unix socket.
        """

        def __init__(self, uds_path, key_file=None, cert_file=None):
            self.uds_path = uds_path
            self.key_file = key_file
            self.cert_file = cert_file
            self.__context = None
            super(UnixHTTPSConnection, self).__init__(socket.getfqdn("localhost"), None)


# Generated at 2022-06-23 02:58:20.783566
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    try:
        handler = UnixHTTPHandler('/tmp/test')
        response = handler.http_open(urllib_request.Request('http://localhost/'))
        for line in response.fp:
            print(line)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 02:58:33.460511
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CustomHTTPSHandler:
        return

    class MockRequest(object):
        def __init__(self):
            self.full_url = "https://www.example.com/"
            self.host = "www.example.com"
            self.timeout = 15
            self.dict = {}
            self.dict['key_file'] = None
            self.dict['cert_file'] = None

    class MockHTTPConnection(object):
        def __init__(self, host, timeout, key_file, cert_file):
            self.host = host
            self.timeout = timeout

    class MockHTTPSConnection(object):
        def __init__(self, host, timeout, key_file, cert_file):
            self.host = host
            self.timeout = timeout


# Generated at 2022-06-23 02:58:37.654836
# Unit test for function fetch_url
def test_fetch_url():
    # TODO: add a unit test for this function.
    pass



# Generated at 2022-06-23 02:58:42.050370
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import ssl
    import httplib
    CustomHTTPSConnection = CustomHTTPSConnection

    def mock_wrap_socket(sock, keyfile, certfile, ssl_version, cert_reqs, server_hostname=None ):
        actual_ssl_version = ssl_version
        actual_cert_reqs = cert_reqs
        actual_server_hostname = server_hostname
        return Mock()

    with patch.multiple('ssl', wrap_socket=mock_wrap_socket):
        # Test connection
        connection = CustomHTTPSConnection('example.com', 443)
        connection.key_file = 'mock-key'
        connection.cert_file = 'mock-cert'

        actual_socket = Mock()
        with patch('socket.create_connection', return_value=actual_socket):
            connection.connect

# Generated at 2022-06-23 02:58:43.015833
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    err = NoSSLError()
    assert err.message == u'No module named ssl', err.message


# Generated at 2022-06-23 02:58:47.934947
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 02:58:52.714290
# Unit test for method get of class Request
def test_Request_get():
    req = Request()
    res = req.get('https://httpbin.org/get', data={'name': 'hello world'})
    res_json = res.json()
    assert res_json['args']['name'] == 'hello world'
    
    

# Generated at 2022-06-23 02:59:05.101248
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    cls = SSLValidationHandler
    cls.httplib = Mock()

    class _req:
        def get_full_url(self):
            return "https://www.google.com"
    req = _req()
    url = req.get_full_url()
    obj = cls("www.google.com", "443")


# Generated at 2022-06-23 02:59:13.264548
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    '''
    Test for class HTTPSClientAuthHandler

    :return: None
    :rtype: None
    '''
    cert = 'cert'
    key = 'key'

    # Test with unix socket
    unix_socket = '/var/run/docker.sock'
    handler = HTTPSClientAuthHandler(client_cert=cert, client_key=key, unix_socket=unix_socket)
    assert handler._unix_socket == unix_socket
    assert handler.client_cert == cert
    assert handler.client_key == key

    # Test without unix socket
    handler = HTTPSClientAuthHandler(client_cert=cert, client_key=key)
    assert handler._unix_socket == None
    assert handler.client_cert == cert
    assert handler.client_key == key



# Generated at 2022-06-23 02:59:23.216825
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    mock_sock = MagicMock()
    with patch('socket.socket', return_value=mock_sock), patch('socket.gethostname', return_value='hostname'):
        unix_conn = UnixHTTPSConnection('/path/to/socket')
        unix_conn._create_connection = MagicMock()
        unix_conn.connect()

        assert unix_conn._create_connection.call_args[0][0] == ('hostname', unix_conn._unix_socket)
        assert unix_conn.sock == mock_sock



# Generated at 2022-06-23 02:59:29.949880
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    url_tuple = ('http', 'user@host.edu', 'path', 'param', 'query', 'fragment')
    url = ParseResultDottedDict(url_tuple)
    for i in range(len(url_tuple)):
        assert getattr(url, ParseResult._fields[i]) == url_tuple[i]
    assert url.as_list() == list(url_tuple)
    assert url.as_list() == list(url.values())

#
# Functions
#


# Generated at 2022-06-23 02:59:33.129146
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    import_traceback = "Traceback (most recent call last)"
    mme = MissingModuleError("Some error message", import_traceback)
    assert mme.args[0] == "Some error message"
    assert mme.import_traceback == import_traceback


# Generated at 2022-06-23 02:59:36.218440
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("My ConnectionError")
    except ConnectionError as myerr:
        assert myerr.args[0] == "My ConnectionError"



# Generated at 2022-06-23 02:59:42.762431
# Unit test for function fetch_file
def test_fetch_file():
    # Assert that fetch_file() properly handles the case where
    # the URL is missing.
    module = Mock()
    module.fail_json = Mock()
    module.tmpdir = tempfile.gettempdir()
    fetch_file(module, None)
    assert module.fail_json.called

    # Assert that fetch_file() properly handles the case where
    # fetch_url cannot establish a connection.
    module = Mock()
    module.fail_json = Mock()
    module.tmpdir = tempfile.gettempdir()
    fetch_file(module, 'http://bad.host.invalid')
    assert module.fail_json.called

    # Assert that fetch_file() adds the temporary file to the
    # cleanup list.
    module = Mock()
    module.fail_json = Mock()
    module.add

# Generated at 2022-06-23 02:59:49.757825
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Arrange
    sslValidationHandler = SSLValidationHandler(None, None, None)
    ca_cert_path = 'ca_certs_path'
    sslValidationHandler.ca_path = ca_cert_path

    # Act
    result = sslValidationHandler.get_ca_certs()

    # Assert
    assert result[0] == ca_cert_path
    assert result[1] is None
    assert result[2] is not None


# Generated at 2022-06-23 02:59:50.892242
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    handler = CustomHTTPSHandler()
    assert handler.https_open(None) is None

# Generated at 2022-06-23 03:00:00.834261
# Unit test for method get of class Request
def test_Request_get():
    req = Request()
    url = "http://www.google.com"
    headers = {'abc':'xyz'}
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'
    timeout = 10.0
    method = 'GET'
    req.get(url=url,headers=headers,http_agent=user_agent,timeout=timeout)
    assert req.method == method
    assert req.url == url
    assert req.headers == headers
    assert req.http_agent == user_agent
    assert req.timeout == timeout
    assert req.use_proxy == False
    assert req.force == False
    assert req.last_mod_time == None
    assert req.validate_

# Generated at 2022-06-23 03:00:04.668569
# Unit test for method open of class Request
def test_Request_open():
    module = Request()
    assert module.open('GET','https://pypi.org/project/gssapi/') == None


# Generated at 2022-06-23 03:00:12.890951
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    handler = CustomHTTPSHandler()
    conn = handler.https_open('https://pypi.python.org')
    conn.close()

if hasattr(ssl, 'HAS_SNI') and not ssl.HAS_SNI:
    warnings.filterwarnings('ignore', message='A true SSLContext object is not available.*', module='ansible')
    warnings.filterwarnings('ignore', message='Certificate has no `subjectAltName`.*', module='ansible')

#
# https_connection - create an https_connection object for urllib3
#


# Generated at 2022-06-23 03:00:23.565887
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    '''
    Test the constructor of ParseResultDottedDict and the as_list method
    '''
    prdd = ParseResultDottedDict(scheme='https', path='/path')
    assert prdd.as_list() == ['https', '', '/path', '', '', '']

    prdd = ParseResultDottedDict({'scheme':'https', 'path':'/path'})
    assert prdd.as_list() == ['https', '', '/path', '', '', '']

    prdd = ParseResultDottedDict(prdd)
    assert prdd.as_list() == ['https', '', '/path', '', '', '']

    prdd = ParseResultDottedDict([('scheme','https'), ('path','/path')])

# Generated at 2022-06-23 03:00:30.000292
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    unix_socket = '/var/run/docker.sock'
    client = UnixHTTPConnection(unix_socket)
    client.connect()

#
# ICX REST API
#


# Generated at 2022-06-23 03:00:41.175407
# Unit test for constructor of class UnixHTTPHandler

# Generated at 2022-06-23 03:00:49.417589
# Unit test for method options of class Request
def test_Request_options():
    # Set up mock objects
    TASK_VARS = dict()
    MODULE_NAME = 'url_utils'

    url_utils_class_options_mock = Request()
    url_utils_class_options_mock.open = mock.MagicMock()

    # Set up the arguments that would be sent to the AnsibleModule
    params = dict()
    params.update(dict(url='http://www.google.com'))

    # Instantiate an AnsibleModule object
    am = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Run the url_utils module as if it had been invoked like so:
    #   ansible localhost -m url_utils -a "url=http://www.google.com"
    # and all required arguments and support for all supported

# Generated at 2022-06-23 03:00:50.662672
# Unit test for function url_argument_spec
def test_url_argument_spec():
    assert isinstance(url_argument_spec(), dict)


# Generated at 2022-06-23 03:00:52.341106
# Unit test for method put of class Request
def test_Request_put():
    assert True == True
# unit test for method options of class Request

# Generated at 2022-06-23 03:00:58.709946
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    try:
        raise SSLError("bad certificate")
    except SSLError as e:
        msg = build_ssl_validation_error("example.com", 443, ["/etc/ssl/certs/example.pem"], e)
        assert("Failed to validate the SSL certificate for example.com:443." in msg)
        assert("bad certificate" in msg)



# Generated at 2022-06-23 03:01:07.064007
# Unit test for constructor of class Request
def test_Request():
    """
    >>> data = 'somebytes'
    >>> headers = {'Accept': 'application/json'}
    >>> request = Request('GET', 'http://example.com', data=data, headers=headers)
    >>> request.get_method()
    'GET'
    >>> request.data
    'somebytes'
    >>> request.headers
    {'Accept': 'application/json'}
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 03:01:16.725501
# Unit test for function fetch_url
def test_fetch_url():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-23 03:01:28.969753
# Unit test for function open_url
def test_open_url():
    import threading
    from wsgiref import simple_server
    from multiprocessing import Process
    import random
    import string

    import pytest
    from pytest import raises
    from pytest import mark
    import six
    if six.PY2:
        import httplib as http_client
        ConnectionRefusedError = http_client.BadStatusLine
        import socketserver
    elif six.PY3:
        import http.client as http_client
        ConnectionRefusedError = ConnectionRefusedError
        import http.server as socketserver
    try:
        import ssl
    except ImportError:
        ssl = None

    # generates a new random string on each invocation
    def _generate_random_string():
        return ''.join(random.sample(string.ascii_lowercase, 10))



# Generated at 2022-06-23 03:01:38.336342
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Test: use a mock to simulate the HTTPSConnection and UnixHTTPConnection classes
    as well as the connect method of UnixHTTPSConnection.
    '''
    from mock import sentinel
    from ansible.module_utils import six
    from ansible.module_utils._text import to_bytes

    with unix_socket_patch_httpconnection_connect():

        # Setup the mocks:
        # - the mocks of the super classes, they should each receive a call to the ``__init__`` method
        #   with the arguments of the call to the mocked UnixHTTPSConnection object
        # - the mock of the UnixHTTPSConnection.connect method itself
        # - the mock of the httplib.HTTPConnection.connect method
        # - the mock of the UnixHTTPConnection.connect method
        https_connection_mock = six.moves.mock

# Generated at 2022-06-23 03:01:47.526956
# Unit test for method open of class Request
def test_Request_open():
    url = 'http://www.ansible.com'
    data='test'
    headers={'User-Agent': 'test'}
    use_proxy=False
    force=True
    timeout=30
    validate_certs=True
    url_username='testuser'
    url_password='test'
    http_agent='test'
    force_basic_auth=False
    follow_redirects='safe'
    client_cert='test'
    client_key='test'
    cookies=None
    use_gssapi=False
    unix_socket=''
    unredirected_headers=None

    timeout_func = getattr(socket, 'setdefaulttimeout', None)
    if timeout_func:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
       

# Generated at 2022-06-23 03:01:51.590367
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('username', 'password') == b'Basic dXNlcm5hbWU6cGFzc3dvcmQ='



# Generated at 2022-06-23 03:02:01.554944
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import tempfile
    import threading
    import socket
    import os
    import types

    # Create a UnixSocketServer
    sock = tempfile.NamedTemporaryFile()
    unix_socket_path = sock.name
    sock.close()

    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(unix_socket_path)
    listener.listen(1)

    def run_server():
        while True:
            conn, addr = listener.accept()
            with conn:
                try:
                    while True:
                        data = conn.recv(1024)
                        if not data:
                            break
                        conn.sendall(data)
                except BrokenPipeError:
                    pass

    server_thread = threading.Thread(target=run_server)

# Generated at 2022-06-23 03:02:07.905283
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.urls import SSLValidationError
    raise_exc = None
    ssl_err_msg = build_ssl_validation_error(hostname='localhost', port=80, paths=['/hello/'], exc=raise_exc)
    assert isinstance(ssl_err_msg, SSLValidationError)
    assert isinstance(ssl_err_msg, Exception)
    assert isinstance(ssl_err_msg, Mapping)


# Generated at 2022-06-23 03:02:11.462991
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    rwm = RequestWithMethod("http://example.com", "GET", "foo")
    assert rwm.get_method() == "GET"
    rwm = RequestWithMethod("http://example.com", "PUT", "foo")
    assert rwm.get_method() == "PUT"



# Generated at 2022-06-23 03:02:23.714453
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Build a dummy class to avoid testing the type(ssl.wrap_socket)
    class PyOpenSSLSocket(object):
        def __init__(self, sock, keyfile=None, certfile=None, server_side=False, cert_reqs=None, ssl_version=None, ca_certs=None, server_hostname=None, do_handshake_on_connect=False):
            self.sock = sock
            self.keyfile = keyfile
            self.certfile = certfile
            self.server_side = server_side
            self.cert_reqs = cert_reqs
            self.ssl_version = ssl_version
            self.ca_certs = ca_certs
            self.do_handshake_on_connect = do_handshake_on_connect
            self.server_hostname

# Generated at 2022-06-23 03:02:33.593807
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    make_context = SSLValidationHandler(hostname='www.google.com', port=443).make_context
    # Testing the make_context for usage of SNI if it is supported by the system and if it is working as intended
    if HAS_SSLCONTEXT:
        assert make_context('/some/path/to/a/certificate/file', None)._hostname_checked  # pylint: disable=protected-access
    # Testing the make_context with a path to a certificate
    try:
        assert make_context('/some/path/to/a/certificate/file', None)
    except NotImplementedError:
        assert False
    # Testing the make_context without a certificate
    try:
        assert make_context(None, None)
    except NotImplementedError:
        assert False
# Unit test

# Generated at 2022-06-23 03:02:41.021312
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # Constructor fails with failure to get the actual certificates
    # On Debian the following exception occurs:
    # IOError: [Errno 20] Not a directory: '/etc/ssl/certs/ca-certificates.crt'
    try:
        connection = CustomHTTPSConnection()
    except IOError:
        pass

    # Constructor fails with wrong https_ca_certs argument
    try:
        connection = CustomHTTPSConnection(https_ca_certs='abc')
    except ValueError:
        pass

    # Constructor fails with wrong https_ca_certs argument
    try:
        connection = CustomHTTPSConnection(https_ca_certs=b'abc')
    except ValueError:
        pass

    # Constructor fails with wrong https_ca_certs argument

# Generated at 2022-06-23 03:02:43.094329
# Unit test for method delete of class Request
def test_Request_delete():
    url = 'http://www.baidu.com'
    resp = Request().delete(url)
    print(resp.code())


# Generated at 2022-06-23 03:02:44.605128
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert CustomHTTPSConnection is not None



# Generated at 2022-06-23 03:02:47.186783
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError("foo")
    except ProxyError as e:
        assert "foo" in str(e)


# Generated at 2022-06-23 03:02:58.178813
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    parseResultDottedDict = ParseResultDottedDict()
    as_list_result = parseResultDottedDict.as_list()
    expected_result = [None] * 6
    assert as_list_result == expected_result

    parseResultDottedDict['scheme'] = 'scheme'
    as_list_result = parseResultDottedDict.as_list()
    expected_result = ['scheme'] + [None] * 5
    assert as_list_result == expected_result

    parseResultDottedDict['netloc'] = 'netloc'
    as_list_result = parseResultDottedDict.as_list()
    expected_result = ['scheme', 'netloc'] + [None] * 4
    assert as_list_result == expected_result


# Generated at 2022-06-23 03:03:09.925641
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with TemporaryDirectory(prefix='ansible_test_') as tmp_dir:
        tmp_file = os.path.join(tmp_dir, 'tmp_file')
        with open(tmp_file, 'w') as tmp_fd:
            tmp_fd.write('temp file to delete')
        # 1 - Test delete on file
        assert os.path.exists(tmp_file)
        atexit_remove_file(tmp_file)
        assert not os.path.exists(tmp_file)

        # 2 - Test delete on dir
        try:
            atexit_remove_file(tmp_dir)
            assert not os.path.exists(tmp_file)
        except Exception as e:
            assert to_native(e) == 'Failed to delete file or directory "%s"' % tmp_dir


# Generated at 2022-06-23 03:03:13.798066
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    _unix_socket = 'test'
    unix_http_conn = UnixHTTPConnection(_unix_socket)
    host = '127.0.0.1'
    port = 80
    timeout = 1
    unix_http_conn(host, port, timeout)
    assert unix_http_conn._unix_socket == _unix_socket
    assert unix_http_conn.host == host
    assert unix_http_conn.port == port
    assert unix_http_conn.timeout == timeout


# Generated at 2022-06-23 03:03:23.375390
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    '''
    The method __call__ of the class UnixHTTPSConnection is used in the method
    _build_https_connection of the class HTTPSClientAuthHandler
    '''
    # Create an instance of UnixHTTPSConnection with a value for its unix_socket attribute
    unix_https_connection = UnixHTTPSConnection('/var/run/docker.sock')
    # Call unix_https_connection with arguments for the httplib.HTTPSConnection constructor
    unix_https_connection('localhost', None, None)
    # If the unix_socket attribute still exists, the test has failed
    assert not hasattr(unix_https_connection, '_unix_socket')



# Generated at 2022-06-23 03:03:32.078551
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    dirname = os.path.dirname(__file__)
    test_file_path = os.path.join(dirname, 'test_urllib2_localnet')

# Generated at 2022-06-23 03:03:40.028741
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    with patch('urllib2.build_opener.open') as mock:
        handler = UnixHTTPHandler('/tmp/test.sock')
        handler.do_open = Mock(return_value=None)
        handler.http_open("req")
        handler.do_open.assert_called_with(UnixHTTPConnection("/tmp/test.sock"), "req")


# Generated at 2022-06-23 03:03:51.354685
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():

    class MockRequest:
        handlers = []

    URLLIB_REQUEST = '__ansible_test__.urllib_request'
    SOCKET = '__ansible_test__.socket'
    SSL = '__ansible_test__.ssl'

    class MOCK_URLLIB_REQUEST:
        AbstractHTTPHandler = None
        HTTPSHandler = None
        ProxyHandler = None
        HTTPBasicAuthHandler = None
        devices = None
        ftpwrapper = None
        opener_registry = None
        Request = None
        addinfourl = None
        result = None
        install_opener = Mock(side_effect=None)

        @staticmethod
        def build_opener():
            return MockRequest()

    class MOCK_SOCKET:
        error = None


# Generated at 2022-06-23 03:04:01.907051
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    from ansible.module_utils.connection import Connection

    with patch('ansible.module_utils.connection.Connection._get_socket_path', return_value='/a/b/c'):
        conn = Connection('local')
        # We want to make sure that UnixHTTPSConnection is patched.
        # Once patched, the connection will create a unix socket file.
        with patch('ansible.module_utils.connection.Connection._create_unix_socket') as create_unix_socket:
            with unix_socket_patch_httpconnection_connect():
                conn._create_unix_socket()

                # Make sure the patch worked.
                assert create_unix_socket.called

    # Make sure the patch is removed.

# Generated at 2022-06-23 03:04:08.269180
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    import unittest
    import os

    try:
        os.unlink('/tmp/python-http-testsocket')
    except OSError:
        pass

    # Mock socket that raises OSError
    class MockSocket(object):
        def __init__(self):
            self.connected = False
        def connect(self, *args, **kwargs):
            raise OSError('')
        def settimeout(self, *args, **kwargs):
            pass

    # Mock socket that raises socket.error
    class MockSocket2(object):
        def __init__(self):
            self.connected = False
        def connect(self, *args, **kwargs):
            raise socket.error('')
        def settimeout(self, *args, **kwargs):
            pass

    # Mock socket

# Generated at 2022-06-23 03:04:09.226491
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    SSLValidationError('test')



# Generated at 2022-06-23 03:04:18.855096
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = 'foo'
    port = 80
    paths = [u'/etc/ssl/certs/ca-certificates.crt', u'/etc/pki/tls/certs/ca-bundle.crt']
    exc = 'test'


# Generated at 2022-06-23 03:04:23.841744
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    from mock import patch

    def test_no_ssl_error(get_mock):
        with patch.dict(sys.modules, dict(ssl=None)):
            with patch('ansible.module_utils.urls.HAS_SSL', False):
                try:
                    maybe_add_ssl_handler('https://example.com/path', True)
                    assert False
                except NoSSLError as e:
                    assert str(e) == 'SSL validation is not available in your version of python. You can use validate_certs=False, however this is unsafe and not recommended'

    def test_ssl_validation_handler_returned(get_mock):
        class MockSSLValidationHandler:
            def __init__(self, hostname, port, ca_path=None):
                self.hostname = hostname
                self

# Generated at 2022-06-23 03:04:29.319240
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    e = NoSSLError('failing because SSL validation is needed', None)
    assert e.errno is None
    assert 'failing because SSL validation is needed' in str(e)



# Generated at 2022-06-23 03:04:32.327241
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    fd, filename = tempfile.mkstemp()
    atexit_remove_file(filename)
    assert not os.path.exists(filename)



# Generated at 2022-06-23 03:04:34.362895
# Unit test for method put of class Request
def test_Request_put():
    request = Request()
    request.put('https://httpbin.org/put')


# Generated at 2022-06-23 03:04:43.731970
# Unit test for method get of class Request
def test_Request_get():
    url = 'https://www.google.com/search?q=python&ie=utf-8&oe=utf-8&client=firefox-b-ab&gfe_rd=cr&dcr=0&ei=g8WbWPGXJIGKX5fZl5gI'
    r = Request()
    r.get(url)
    print('-------------------------------------')
    print('test_Request_get method')
    print(r)
    print('-------------------------------------')



# Generated at 2022-06-23 03:04:49.922460
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ex = ConnectionError("foo")
    assert ex.args[0] == "foo"
    try:
        raise ex
    except ConnectionError as ex:
        assert ex.args[0] == "foo"


# Generated at 2022-06-23 03:04:57.382131
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    # Create a temp file
    temp_fd, temp_path = tempfile.mkstemp()
    # Check that file exists
    assert os.path.exists(temp_path)
    # Register to remove file at exit
    atexit_remove_file(temp_path)
    # Call atexit_remove_file now
    atexit_remove_file(temp_path)
    # Check that file has been removed
    assert os.path.exists(temp_path) is False


# Generated at 2022-06-23 03:05:08.450723
# Unit test for method options of class Request
def test_Request_options():
    url ='unit-test-url'
    url_username = 'unit-test-url_username'
    url_password = 'unit-test-url_password'
    http_agent = 'unit-test-http_agent'
    force_basic_auth = True
    timeout = 1
    validate_certs = True
    client_cert = 'unit-test-client_cert'
    client_key = 'unit-test-client_key'
    cookies = {'unit':'test'}
    use_gssapi = True
    unix_socket = 'unit-test-unix_socket'
    ca_path = 'unit-test-ca_path'
    unredirected_headers = ['self-test-unredirected_headers']

# Generated at 2022-06-23 03:05:19.550275
# Unit test for function generic_urlparse

# Generated at 2022-06-23 03:05:22.820786
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    if sys.version_info[:2] == (2, 6):
        # Function formatdate() doesn't return the correct string on Python 2.6,
        # so we skip the test on that version.
        return
    localtime = time.localtime()
    rfc2822_date_from_email = email.utils.formatdate(localtime=localtime)
    rfc2822_date_from_urllib = rfc2822_date_string(localtime)
    assert rfc2822_date_from_email == rfc2822_date_from_urllib


# Generated at 2022-06-23 03:05:28.367039
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    from unittest.mock import patch
    sock_patcher = patch('urllib3.connection.CustomHTTPSConnection.connect')
    sock_patcher.start()
    if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
        ssl_patcher = patch('urllib3.connection.CustomHTTPSConnection.context.wrap_socket')
        ssl_patcher.start()
    elif HAS_URLLIB3_SSL_WRAP_SOCKET:
        ssl_patcher = patch('urllib3.connection.ssl_wrap_socket')
        ssl_patcher.start()
    else:
        ssl_patcher = patch('ssl.wrap_socket')
        ssl_patcher.start()

# Generated at 2022-06-23 03:05:30.733246
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    handler = SSLValidationHandler('localhost:443')
    assert handler.hostname == 'localhost'
    assert handler.port == 443



# Generated at 2022-06-23 03:05:39.823758
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    content_type, body = prepare_multipart(fields)
    assert content_type == 'multipart/form-data; boundary================3798991258309280049=='

    if not isinstance(body, bytes):
        body = to_bytes(body)

    body = body.split(b'\r\n\r\n')
