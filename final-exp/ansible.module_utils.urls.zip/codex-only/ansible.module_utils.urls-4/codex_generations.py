

# Generated at 2022-06-23 02:55:31.453273
# Unit test for method get of class Request
def test_Request_get():
 return 0

# Generated at 2022-06-23 02:55:43.710907
# Unit test for function url_argument_spec

# Generated at 2022-06-23 02:55:46.576181
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    req = urllib_request.Request(
        URL_NO_PROXY_NO_EXIST,
        headers={'User-Agent': USER_AGENT},
    )
    assert SSLValidationHandler(URL_NO_PROXY_NO_EXIST, 443).detect_no_proxy(req.get_full_url()) == True


# Generated at 2022-06-23 02:55:52.227028
# Unit test for method post of class Request
def test_Request_post():
    print('''
    # Unit test for method post of class Request
    url = 'http://www.baidu.com'
    r = Request()
    r.post(url)
    ''')
    url = 'http://www.baidu.com'
    r = Request()
    r.post(url)


# Generated at 2022-06-23 02:55:58.923916
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    try:
        with NamedTemporaryFile() as tf:
            socket_file = tf.name
            u = UnixHTTPConnection(socket_file)
            assert u is not None
    except OSError:
        # If there is no utmp file on the system,
        # the above test will fail.
        pass



# Generated at 2022-06-23 02:56:04.719015
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    """
    Unit test for constructor of class SSLValidationError
    """
    exc = SSLValidationError('Error Message')
    if not isinstance(exc, ConnectionError):
        raise AssertionError('SSLValidationError is not a ConnectionError')
    if not isinstance(exc, IOError):
        raise AssertionError('SSLValidationError is not a IOError')
    if str(exc) != 'Error Message':
        raise AssertionError('The message should be "Error Message"')



# Generated at 2022-06-23 02:56:06.795541
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        import no_such_module
    except ImportError:
        e = sys.exc_info()
    exc = MissingModuleError("foo", e)
    assert 'foo' in str(exc)


# Generated at 2022-06-23 02:56:19.354282
# Unit test for function url_argument_spec
def test_url_argument_spec():
    result = url_argument_spec()
    assert isinstance(result, dict)
    assert 'url' in result
    assert isinstance(result['url'], dict)
    assert result['url']['type'] == 'str'
    assert 'force' in result
    assert isinstance(result['force'], dict)
    assert result['force']['type'] == 'bool'
    assert result['force']['default'] == False
    assert 'aliases' in result['force']
    assert result['force']['aliases'] == ['thirsty']
    assert 'deprecated_aliases' in result['force']
    assert isinstance(result['force']['deprecated_aliases'], list)
    assert len(result['force']['deprecated_aliases']) == 1

# Generated at 2022-06-23 02:56:22.590361
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ConnectionError("")
    ConnectionError("", 1)



# Generated at 2022-06-23 02:56:31.665628
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    conn = UnixHTTPSConnection('/path/to/unix/socket')('hostname')
    assert conn._unix_socket == '/path/to/unix/socket'
    assert conn.host == 'hostname'

if hasattr(httplib, 'HTTPConnection'):

    class UnixHTTPConnection(httplib.HTTPConnection):
        '''
        This class is largely copied from Python's HTTPConnection class,
        with the parts that actually make connections to remote servers
        replaced with code that connects to a unix socket.
        '''
        def __init__(self, *args, **kwargs):
            if 'unix_socket' in kwargs:
                self._unix_socket = kwargs.pop('unix_socket')
            else:
                self._unix_socket = None
            httplib

# Generated at 2022-06-23 02:56:40.048669
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    with open(os.path.join(CERT_DIR, 'good_cert.pem'), 'rb') as f:
        good_cert_pem = f.read()
    assert get_channel_binding_cert_hash(good_cert_pem) == binascii.unhexlify('7dfdfc9e8d7f6c2d6f735baa59ce8d956583b27c61f3dd1a9362d8f39a3d28ed')

    with open(os.path.join(CERT_DIR, 'no_hash_cert.pem'), 'rb') as f:
        bad_cert_pem = f.read()

# Generated at 2022-06-23 02:56:47.340052
# Unit test for function url_argument_spec
def test_url_argument_spec():
    from ansible.module_utils import basic
    from ansible.module_utils.urls import url_argument_spec
    res = dict()
    result = basic.AnsibleModule(argument_spec=url_argument_spec()).params
    for key in result.keys():
        res[key] = result[key]
    assert result == res



# Generated at 2022-06-23 02:56:58.888049
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    def test_open(cls, req):
        conn = _CustomHTTPSConnection(**kwargs)
        conn.request(req.get_method(), req.get_selector(), req.data, req.headers)
        return conn.getresponse()
    _CustomHTTPSConnection = Mock()
    kwargs = {'host': 'hostname'}
    req = Mock()
    CustomHTTPSHandler().do_open = Mock(side_effect=test_open)
    CustomHTTPSHandler().https_open(req)
    _CustomHTTPSConnection.assert_called_with(**kwargs)



# Generated at 2022-06-23 02:57:09.466708
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    try:
        # This should work with import fails
        CustomHTTPSConnection('hostname', 443, key_file='/some/file.pem', cert_file='/some/file.crt')
    except NameError:
        pass
    except socket.error:
        pass


if CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(CustomHTTPSConnection, req)

    def test_CustomHTTPSHandler():
        # Ensure subclass of urllib_request.HTTPSHandler
        assert issubclass(CustomHTTPSHandler, urllib_request.HTTPSHandler)

        # Test instantiation, since we have a custom constructor this is a required step
        instance = CustomHTTPSHandler()


# Generated at 2022-06-23 02:57:20.702358
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    # Init a SSLValidationHandler instance
    obj = SSLValidationHandler('hostname', 'port')
    # Try to validate proxy response with valid data, no exception should be raised
    try:
        obj.validate_proxy_response(b'HTTP/1.0 200 OK', [200])
    except:
        assert False

    # Try to validate proxy response with invalid http_version, exception should be raised
    try:
        obj.validate_proxy_response(b'HTTP/1.1 200 OK', [200])
        assert False
    except:
        pass
    # Try to validate proxy response with invalid resp_code, exception should be raised
    try:
        obj.validate_proxy_response(b'HTTP/1.0 404 OK', [200])
        assert False
    except:
        pass



# Generated at 2022-06-23 02:57:27.257382
# Unit test for function open_url
def test_open_url():
    
    # test get
    resp = open_url('https://www.google.com')
    assert resp.getcode() == 200

    # test post
    resp = open_url('http://httpbin.org/post', data='foo')
    assert resp.getcode() == 200
    assert json.loads(resp.read().decode('utf8'))['form'] == {'foo': ''}

    # test put
    resp = open_url('http://httpbin.org/put', data='foo', method='PUT')
    assert resp.getcode() == 200
    assert json.loads(resp.read().decode('utf8'))['data'] == 'foo'

    # test delete
    resp = open_url('http://httpbin.org/delete', method='DELETE')
    assert resp.getcode() == 200

# Generated at 2022-06-23 02:57:31.702485
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    assert ParseResultDottedDict().as_list() == [None, None, None, None, None, None]
    assert ParseResultDottedDict(scheme='sql').as_list() == ['sql', None, None, None, None, None]
    assert ParseResultDottedDict(scheme='sql', netloc='host', path='/path', params='params', query='query', fragment='fragment').as_list() == ['sql', 'host', '/path', 'params', 'query', 'fragment']



# Generated at 2022-06-23 02:57:41.836418
# Unit test for function getpeercert

# Generated at 2022-06-23 02:57:54.062304
# Unit test for method detect_no_proxy of class SSLValidationHandler

# Generated at 2022-06-23 02:58:04.584842
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    old_version = sys.version
    old_exceutable = sys.executable
    sys.version = '2.6.3'
    sys.executable = '/usr/bin/python'
    hostname = 'myhost'
    port = '8443'
    paths = '/tmp/ca.pem'
    exc = 'exception'

# Generated at 2022-06-23 02:58:10.209747
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    cert, hostname = ssl.DER_cert_to_PEM_cert(b_DUMMY_CA_CERT), 'example.com'
    validation_msg = "Could not validate certificate '%s' for hostname '%s'" % (cert, hostname)
    raised_exception = SSLValidationError(cert, hostname)
    assert str(raised_exception) == validation_msg



# Generated at 2022-06-23 02:58:20.279966
# Unit test for method patch of class Request
def test_Request_patch():
    request = Request()
    with pytest.raises(TypeError) as e: # test that we get a TypeError
        assert request.patch("https://httpbin.org/patch")

    # test that we get a TypeError when there is no data
    assert request.patch("https://httpbin.org/patch", data=None)

    # test that we do not get a TypeError
    assert request.patch("https://httpbin.org/patch", data="")

    # test that we get a HTTPResponse object
    assert request.patch("https://httpbin.org/patch", data="").__class__.__name__ == "HTTPResponse"

    # test that we get a request with a 200 status_code
    assert request.patch("https://httpbin.org/patch", data="").status_code == 200



# Generated at 2022-06-23 02:58:26.397092
# Unit test for constructor of class ProxyError
def test_ProxyError():
    t = ProxyError("localhost", 8080)
    assert isinstance(t, ProxyError)
    assert t.args == ("localhost", 8080)



# Generated at 2022-06-23 02:58:37.213108
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    url = "https://host.example.com"
    # client_cert and client_key are not necessary for test.
    handler = HTTPSClientAuthHandler()
    request = handler.https_request(url)
    assert isinstance(request, urllib_request.Request)

if HAS_UNIX_SSL and hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
    class UnixHTTPSConnection(httplib.HTTPConnection):
        '''
        Based on http://stackoverflow.com/a/29513266/812183
        '''

        def __init__(self, socket_file):
            httplib.HTTPConnection.__init__(self, 'localhost')
            self.socket_file = socket_file

        def connect(self):
            sock

# Generated at 2022-06-23 02:58:43.519114
# Unit test for function url_argument_spec
def test_url_argument_spec():
    assert 'url_username' in url_argument_spec()
    assert 'url_password' in url_argument_spec()
    assert 'force' in url_argument_spec()
    assert 'http_agent' in url_argument_spec()
    assert 'use_proxy' in url_argument_spec()
    assert 'validate_certs' in url_argument_spec()
    assert 'force_basic_auth' in url_argument_spec()
    assert 'client_cert' in url_argument_spec()
    assert 'client_key' in url_argument_spec()
    assert 'use_gssapi' in url_argument_spec()
    # start py26 support
    assert 'aliases' in url_argument_spec()['force'].keys()
    # end py26 support



# Generated at 2022-06-23 02:58:52.103105
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    # This test is needed to allow the use of a mock in the function _get_response_object()
    # to test the UnixHTTPConnection.__call__() method.
    #
    # A test function must be called to perform the test because a mock in a test case
    # can't be accessed by another test case (or the mock would be shared between test cases).
    class MockUnixHTTPConnection(Mock):
        def __init__(self):
            super(MockUnixHTTPConnection, self).__init__(spec=UnixHTTPConnection(None))

    u = MockUnixHTTPConnection()

    with patch('ansible.module_utils.urls.os.path.exists') as exists_mock:
        exists_mock.return_value = True

# Generated at 2022-06-23 02:59:04.545655
# Unit test for method put of class Request
def test_Request_put():
    http = None
    http = connection_class(**dict)

    http.utf8_quote_plus = 'utf8_quote_plus'
    http.unix_socket = 'unix_socket'
    http.url_username = 'url_username'
    http.use_proxy = 'use_proxy'
    http.use_gssapi = 'use_gssapi'
    http.url = 'url'
    http.url_password = 'url_password'
    http.url_timeout = 'url_timeout'
    http.url_validate_certs = 'url_validate_certs'
    http.url_http_agent = 'url_http_agent'
    http.url_force_basic_auth = 'url_force_basic_auth'

# Generated at 2022-06-23 02:59:15.606358
# Unit test for function fetch_file
def test_fetch_file():
    '''Test fetch_file function'''

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Test SSL error
    try:
        fetch_file(module, 'https://self-signed.badssl.com/')
    except AnsibleFailJson as e:
        assert e.kwargs['msg'] == 'SSL: CERTIFICATE_VERIFY_FAILED'

    # Test 404 error
    try:
        fetch_file(module, 'https://httpbin.org/status/404')
    except AnsibleFailJson as e:
        assert e.kwargs['msg'] == 'Request failed: HTTP Error 404: NOT FOUND'

    # Test file downloaded successfully
    fetched_file = fetch_file(module, 'https://httpbin.org/bytes/3')
    fetched_

# Generated at 2022-06-23 02:59:26.910536
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Create a mock object of a custom class
    my_mock = mock.Mock(spec=SSLValidationHandler)

    # 'setup' our mock object
    my_mock.hostname = 'hostname'
    my_mock.port = '443'
    my_mock.ca_path = '/path/to/ca_cert.pem'

    # ensure detect_no_proxy() is called with no_proxy=None
    my_mock.detect_no_proxy = mock.MagicMock(name='detect_no_proxy', return_value=True)
    # NOTE: This line is never executed, but is necessary to avoid a pytest error
    # where the paramaterized test case is run multiple times. The 1st time this
    # test is invoked the environment variable no_proxy is set to 'test.local

# Generated at 2022-06-23 02:59:35.327666
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    # If Python < 2.6, skip this test since httplib can't create_connection
    if sys.version_info < (2, 6):
        return True
    else:
        try:
            import ssl
        except ImportError:
            return True

        import os

        import subprocess

        import tempfile

        # Get a temp directory
        tempdir = tempfile.mkdtemp()

        # Get a temp file for the server certificate
        server_cert_file = tempfile.NamedTemporaryFile(mode='w', dir=tempdir)
        server_cert_file.write(CERT_FILE_CONTENTS)
        server_cert_file.flush()

        # Get a temp file for the server key
        server_key_file = tempfile.NamedTemporaryFile(mode='w', dir=tempdir)
       

# Generated at 2022-06-23 02:59:41.194491
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    # pylint: disable=too-many-locals
    result = ParseResultDottedDict()
    assert result == {}

    result = ParseResultDottedDict(netloc='127.0.0.1', scheme='http')
    assert result == {'netloc': '127.0.0.1', 'scheme': 'http'}
    assert result.netloc == '127.0.0.1'
    assert result.scheme == 'http'
    assert result.as_list() == ['http', '127.0.0.1', None, None, None, None]
    assert str(result) == 'scheme=http, netloc=127.0.0.1, path=None, params=None, query=None, fragment=None'


# Generated at 2022-06-23 02:59:50.754766
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 02:59:57.798951
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Verify that the ssl library is loaded and working
    if not HAS_SSL:
        pytest.skip('SSL library not available')
    c = CustomHTTPSConnection(CERT_HOST, CERT_PORT)
    c.request('GET', '/')
    assert c.getresponse().status == 200



# Generated at 2022-06-23 03:00:06.443863
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class Connection(UnixHTTPConnection):
        '''Dummy object to simulate UnixHTTPConnection'''
        def __init__(self, host):
            self.host = host

    conn = Connection('host')
    assert conn.host == 'host'
    conn.sock = 'sock'
    assert conn.sock == 'sock'

    with unix_socket_patch_httpconnection_connect():
        conn.connect()
    assert conn.sock == None



# Generated at 2022-06-23 03:00:14.627626
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    e = ParseResultDottedDict(scheme='http', netloc='localhost:8080', path='/path', params='', query='', fragment='')
    assert e.as_list() == ['http', 'localhost:8080', '/path', '', '', '']

# The following class definition and the request_handler_factory function definition with the appropriate
# depending is_available conditionals are used to construct a request handler which will use the
# urllib/urllib2/requests as a basis for an HTTP(S) handler. The main goal is to define an interface
# which will allow to easily swap the underlying HTTP handler module (i.e. for testing purposes).


# Generated at 2022-06-23 03:00:17.944915
# Unit test for method head of class Request
def test_Request_head():
    try:
        request = Request();
        request.head('www.baidu.com');
        print('Success!')
    except Exception as e:
        print(e)

# Generated at 2022-06-23 03:00:22.221616
# Unit test for function fetch_file
def test_fetch_file():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import NoSSLError
    from ansible.module_utils.urls import MissingModuleError
    from ansible.module_utils.urls import urllib_error
    from ansible.module_utils.urls import httplib
    from ansible.module_utils.urls import socket

    class FakeModule():

        def __init__(self, tmpdir):
            self.params = dict()
            self.add_cleanup_file_called = False
            self.tmpdir = tmpdir
            self.add_cleanup_file_calls = []

        def add_cleanup_file(self, name):
            self.add_cleanup

# Generated at 2022-06-23 03:00:23.646080
# Unit test for constructor of class ProxyError
def test_ProxyError():
    msg = 'Failed to connect to proxy'
    try:
        raise ProxyError(msg)
    except ProxyError as e:
        assert isinstance(e, ConnectionError)
        assert e.message == msg


# Generated at 2022-06-23 03:00:34.317261
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    import tempfile
    import os

    class MockSSLContext(object):
        def __init__(self, *args, **kwargs):
            pass

        def load_verify_locations(self, *args, **kwargs):
            pass

    handler = SSLValidationHandler('example.com', 443)
    with tempfile.NamedTemporaryFile(prefix='ca.crt', delete=False) as ca_cert_file:
        ca_cert_file.write(b_DUMMY_CA_CERT)
    # Test with cafile and cadata
    with patch('ansible.module_utils.urls.ssl.create_default_context', create=True) as mock_create_default_context:
        mock_create_default_context.return_value = MockSSLContext()

# Generated at 2022-06-23 03:00:44.235512
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2
    try:
        import urllib
    except ImportError:
        import urllib.parse as urllib
    UNIX_SOCKET = 'test_sock'
    URL = 'http://localhost'
    class FakeSocket(object):
        def connect(self, host):
            self.host = host
        def settimeout(self, timeout):
            self.timeout = timeout
    def do_open(host, timeout=None):
        sock = FakeSocket()
        sock.connect(host)
        if timeout is not None:
            sock.settimeout(timeout)
        return sock
    unix_handler = UnixHTTPHandler(UNIX_SOCKET)
    unix_handler.do_open

# Generated at 2022-06-23 03:00:56.814873
# Unit test for function getpeercert
def test_getpeercert():
    import http.client
    import ssl
    class FakeSocket(object):
        def __init__(self, cert):
            self.cert = cert
        def getpeercert(self, binary_form):
            return self.cert
    class FakeResponse(object):
        def __init__(self, fp):
            self.fp = fp
    class FakeHTTPConnection(object):
        def __init__(self, socktype, cert):
            self.socktype = socktype
            self.cert = cert
        def connect(self):
            if self.socktype == 'http':
                self._sock = None
            elif self.socktype == 'https':
                self._sock = FakeSocket(self.cert)

# Generated at 2022-06-23 03:00:58.094435
# Unit test for method open of class Request
def test_Request_open():
    # Unit test for open function
    assert 1 == 1
    return

# Generated at 2022-06-23 03:01:07.665927
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    unix_socket = socket.socket(socket.AF_UNIX)

    monkeypatch = mock.patch('ansible.module_utils.six.moves.http_client.HTTPConnection')
    m = monkeypatch.start()
    # Make UnixHTTPConnection.connect return the unix_socket (this is the behavior we want)
    m.return_value.connect.return_value = unix_socket

    u = UnixHTTPSConnection(b'/foo/bar')
    assert u.sock is None
    u.connect()
    assert u.sock == unix_socket
    monkeypatch.stop()


# Generated at 2022-06-23 03:01:13.649701
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test execution of the method when internel map LOADED_VERIFY_LOCATIONS is empty
    expected_ca_path = os.path.join(os.getcwd(), 'ssl/certs/cacert.pem')

# Generated at 2022-06-23 03:01:26.084712
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    url = 'http://192.168.1.1/'
    method = 'POST'
    data = ('<h1>Hello</h1>',)
    headers = {'Content-Type': 'text/html'}
    # Using super() to call constructor of parent class doesn't work
    # See https://stackoverflow.com/a/12206328 for details
    # Hence, creating a new class which extends RequestWithMethod
    # and calling the constructor of RequestWithMethod
    class RequestWithMethodTest(RequestWithMethod):
        def __init__(self, url, method, data, headers):
            RequestWithMethod.__init__(self, url, method, data, headers)
    r = RequestWithMethodTest(url, method, data, headers)
    assert r.get_full_url() == url
    assert r.get

# Generated at 2022-06-23 03:01:28.866423
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('Test')
    except Exception as e:
        assert isinstance(e, ProxyError)
        assert "Test" in str(e)


# Generated at 2022-06-23 03:01:31.215841
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    test_CustomHTTPSHandler = CustomHTTPSHandler(context=None)
    assert True


# Generated at 2022-06-23 03:01:32.573581
# Unit test for method options of class Request
def test_Request_options():
    global obj
    obj.options('http://www.example.com/')


# Generated at 2022-06-23 03:01:34.434995
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    import pytest
    with pytest.raises(SSLValidationError):
        build_ssl_validation_error('hostname', 'port', 'path', exc='bad')



# Generated at 2022-06-23 03:01:46.395437
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Unit test for function get_channel_binding_cert_hash """
    print('Testing get_channel_binding_cert_hash()')
    cb_good = binascii.unhexlify(b'1ba188f075d504c48e7f1c2e8b7d72e12acb5e5e08c9ca5ec5d94c2ae5f5ef40')
    cb_bad = binascii.unhexlify(b'1ba188f075d504c48e7f1c2e8b7d72e12acb5e5e08c9ca5ec5d94c2ae5f5ef41')


# Generated at 2022-06-23 03:01:56.312385
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    from test.support import EnvironmentVarGuard
    import tempfile
    import urllib.request
    import ssl
    import socket

    # Create a temporary CA certificate
    ca_cert = tempfile.NamedTemporaryFile(delete=False)
    ca_cert_path = ca_cert.name
    ca_cert.write(b_DUMMY_CA_CERT)
    ca_cert.close()

    # Create a temporary server certificate
    server_cert = tempfile.NamedTemporaryFile(delete=False)
    server_cert_path = server_cert.name
    server_cert.write(b_DUMMY_CA_CERT)
    server_cert.close()

    # Create a temporary key file
    tmp_key = tempfile.NamedTemporaryFile(delete=False)
    tmp_key_path

# Generated at 2022-06-23 03:02:09.394364
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 03:02:12.396953
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    conn = UnixHTTPSConnection('/tmp/test.sock')
    conn.sock = None
    conn.connect()
    assert isinstance(conn.sock, socket.socket)
    conn.sock.close()



# Generated at 2022-06-23 03:02:24.237876
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():

    class FakeOpener(object):
        def __init__(self, result):
            self.result = result

        def open(self, *args, **kwargs):
            return self.result

    class FakeRequest(object):
        def __init__(self, origin_req_host, host):
            self.origin_req_host = origin_req_host
            self.host = host

        def has_data(self):
            return False

    class FakeConnection(object):
        def __init__(self, context, host, port=443, server_hostname=None):
            self.context = context
            self.host = host
            self.port = port
            self.server_hostname = server_hostname


# Generated at 2022-06-23 03:02:28.432001
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    url = 'https://foo.com'
    request_object = RequestWithMethod(url, 'PUT', data=b'Hello World')
    assert request_object.data == b'Hello World'
    assert request_object.get_method() == 'PUT'


# Generated at 2022-06-23 03:02:36.831885
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.common.utils import AnsibleModule

    m = AnsibleModule({})
    r, info = fetch_url(m, 'https://github.com/ansible/ansible/pull/30131')
    assert info['status'] == 200

    # Test fetch_url returning None for r, and a tuple for info, which
    # is expected when a failure occurs
    r, info = fetch_url(m, 'http://a.com/')
    assert info['status'] == -1

# Generated at 2022-06-23 03:02:48.813866
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test function generic_urlparse
    '''

# Generated at 2022-06-23 03:02:59.187087
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CustomHTTPSHandler:
        return

    class TestHTTPSHandler(CustomHTTPSHandler, urllib_request.HTTPSHandler):
        pass

    class MockHandler:
        def __init__(self):
            self.defaults = []
            self.opened = 0

        def do_open(self, http_class, req):
            self.opened += 1
            return MockResponse()

        def addheaders(self, headers):
            self.defaults = headers

    class MockResponse:
        def __init__(self):
            self.code = 200
            self.msg = ''
            self.headers = []
            self.data = ''

        def read(self, amt):
            return self.data

        def info(self):
            return self.headers

        def getcode(self):
            return self.code

# Generated at 2022-06-23 03:03:02.104473
# Unit test for method options of class Request
def test_Request_options():
    method = 'OPTIONS'
    url = 'http://www.example.com/'
    data = '이보영'  # The value type is 'str'
    args = (method, url, data)
    kwargs = {'url': url, 'data':data, 'method':method}
    expected = HTTPResponse(url=url, data=data, method=method)
    actual = Request.options(*args, **kwargs)
    assert expected == actual


# Generated at 2022-06-23 03:03:08.268735
# Unit test for function url_argument_spec
def test_url_argument_spec():
    test_args = dict(
        url="/some/url",
        force=True,
        http_agent="some-agent",
        use_proxy=True,
        validate_certs=True,
        url_username="some-user",
        url_password="password",
        force_basic_auth=True,
        client_cert="path/to/cert",
        client_key="path/to/key",
        use_gssapi=True,
    )
    res = url_argument_spec()
    test_res = ArgumentSpec().argument_spec
    assert(res == test_res)



# Generated at 2022-06-23 03:03:13.523865
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:03:15.644573
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    import time
    import email.utils
    assert rfc2822_date_string(time.localtime(1289922184)) == 'Fri, 29 Oct 2010 17:43:04 -0000'
    assert rfc2822_date_string(time.gmtime(1289922184)) == email.utils.formatdate(1289922184)

# End unit test



# Generated at 2022-06-23 03:03:23.584844
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Single field value
    expected_content = '''\
Content-Disposition: form-data
Content-Type: text/plain; charset="utf-8"

text
'''
    ct, content = prepare_multipart({'text': 'text'})
    assert(ct == 'multipart/form-data')
    assert(content == expected_content)
    # Single file
    expected_content = '''\
Content-Disposition: form-data; filename="true"
Content-Transfer-Encoding: binary
Content-Type: application/octet-stream

-
'''
    ct, content = prepare_multipart({'true': '/bin/true'})
    assert(ct == 'multipart/form-data')
    assert(content == expected_content)
    # Single file with Content-

# Generated at 2022-06-23 03:03:35.624704
# Unit test for method make_context of class SSLValidationHandler

# Generated at 2022-06-23 03:03:46.107516
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_socket = '/foo/bar/baz'
    # This class is a placeholder because HTTPSConnection has to be defined before
    # UnixHTTPSConnection can be defined
    class DummyHTTPSConnection(object):
        pass
    with patch.object(DummyHTTPSConnection, '__init__') as mock_DummyHTTPSConnection___init__:
        with unix_socket_patch_httpconnection_connect():
            unix_https_connection = UnixHTTPSConnection(unix_socket)
            assert unix_https_connection
            assert unix_https_connection('host') == unix_https_connection
            assert unix_https_connection.__doc__ == httplib.HTTPSConnection.__doc__

# Generated at 2022-06-23 03:03:48.060266
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(client_cert='/path/to/cert', client_key='/path/to/key')
    assert handler.client_cert == '/path/to/cert'
    assert handler.client_key == '/path/to/key'



# Generated at 2022-06-23 03:04:00.010471
# Unit test for function prepare_multipart
def test_prepare_multipart():

    fields = {}

    fields['text_form_field'] = 'value'

    fields['file1'] = {}
    fields['file1']['filename'] = '/bin/true'
    fields['file1']['mime_type'] = 'application/octet-stream'

    fields['file2'] = {}
    fields['file2']['content'] = 'text based file content'
    fields['file2']['filename'] = 'fake.txt'
    fields['file2']['mime_type'] = 'text/plain'

    content_type, body = prepare_multipart(fields)

    assert (len(content_type) > 0)
    assert (len(body) > 0)

# Generated at 2022-06-23 03:04:13.147253
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    # Asserts whether the method https_open is returning a value
    class httpconnection(object):
        def __init__(self):
            self.status = None
            self.reason = None
            self.debuglevel = None
            self.return_value = "test value"

    class request(object):
        def __init__(self):
            self.full_url = None
            self.http_response = None
            self.data = None
            self.headers = None

    class httpresponse(object):
        def __init__(self):
            self.status = None
            self.reason = None
            self.msg = None
            self.fp = None

    req = request()
    httpcon = httpconnection()
    htpres = httpresponse()
    req.full_url = "fake_full_url"
   

# Generated at 2022-06-23 03:04:17.492382
# Unit test for method put of class Request
def test_Request_put():
    request = Request("localhost", 80, "/", "PUT", "data")
    assert request.host == "localhost"
    assert request.port == 80
    assert request.path == "/"
    assert request.method == "PUT"
    request.path = "/index.html"
    assert request.path == "/index.html"



# Generated at 2022-06-23 03:04:27.983899
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    try:
        os.unlink('/tmp/test_UnixHTTPConnection_sock')
    except OSError:
        pass

    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('/tmp/test_UnixHTTPConnection_sock')

    http_conn = UnixHTTPConnection('/tmp/test_UnixHTTPConnection_sock')
    http_conn.connect()

    try:
        s.listen(5)
        client, addr = s.accept()
    except socket.timeout:
        assert False, 'UnixHTTPConnection is not connecting to the socket'

    s.close()
    os.unlink('/tmp/test_UnixHTTPConnection_sock')



# Generated at 2022-06-23 03:04:33.207922
# Unit test for method patch of class Request
def test_Request_patch():
    url = "http://www.example.com"
    data = "foo"
    method = "PATCH"
    req = urllib_request.Request(url, method=method, data=data)
    assert(req.get_method() == method)
    assert(req.data == data)

# Generated at 2022-06-23 03:04:45.420940
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    try:
        from unittest import mock
    except ImportError:
        import mock
    unix_http_obj = UnixHTTPConnection('/temp/unixhttpconnection')
    socket_mock = mock.Mock()
    mock_socket = socket_mock.return_value
    unix_http_obj.socket = socket_mock
    unix_http_obj.timeout = 10
    unix_http_obj.connect()
    assert mock_socket.connect.call_count == 1
    assert mock_socket.connect.call_args == mock.call('/temp/unixhttpconnection')
    assert mock_socket.settimeout.call_count == 1
    assert mock_socket.settimeout.call_args == mock.call(10)

# Generated at 2022-06-23 03:04:51.883369
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert "Fri, 09 Nov 2001 01:08:47 -0000" == rfc2822_date_string(time.gmtime(1005231327))
    assert "Fri, 09 Nov 2001 01:08:47 -0000" == rfc2822_date_string(time.gmtime(1005231327), zone='-0000')
    assert "Fri, 09 Nov 2001 01:08:47 +0000" == rfc2822_date_string(time.gmtime(1005231327), zone='+0000')
    assert "Fri, 09 Nov 2001 04:08:47 -0400" == rfc2822_date_string(time.gmtime(1005231327), zone='-0400')

# Generated at 2022-06-23 03:04:54.551548
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    with pytest.raises(ConnectionError):
        conn = UnixHTTPSConnection('/tmp/invalid_socket')
        conn.connect()



# Generated at 2022-06-23 03:05:05.815301
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    try:
        HTTPSClientAuthHandler(sys.argv[1], sys.argv[2], sys.argv[3])
    except IndexError:
        print("usage: %s [cert] [key] [url]" % sys.argv[0])
        raise SystemExit(1)
    raise SystemExit(0)


if not isinstance(ssl.SSLContext, object):
    if HAS_SSLCONTEXT:
        class SSLContext(object):
            def __init__(self, protocol):
                self.protocol = protocol
                self.ssl_context = ssl.SSLContext(protocol)

            def load_cert_chain(self, certfile, keyfile):
                self.ssl_context.load_cert_chain(certfile=certfile, keyfile=keyfile)


# Generated at 2022-06-23 03:05:08.157197
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler('/tmp/socket.sock')
    assert handler.protocol_version == 'HTTP/1.1'



# Generated at 2022-06-23 03:05:12.718615
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    a=ParseResultDottedDict({'scheme':'https','netloc':'myhost.mydomain.com','path':'/path/to/resource','params':'myparams','query':'myquery','fragment':'myfragment'})
    if a.as_list() != ['https', 'myhost.mydomain.com', '/path/to/resource', 'myparams', 'myquery', 'myfragment']:
        raise AssertionError("List from ParseResultDottedDict does not match expected values")

#
# Utility functions
#

# Helper to support bytes_body on python2
if not six.PY3:
    def b(val):
        return val
else:
    def b(val):
        return val.encode('latin1')


# Generated at 2022-06-23 03:05:22.759639
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Create a fake http response
    protocol = 'HTTP/1.1'
    msg = protocol + ' 301 Moved Permanently'
    response = [msg.encode()]
    response.append(b'Content-Type: text/html; charset=iso-8859-1')
    response.append(b'')
    response.append(b'<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">')
    response.append(b'<html><head>')
    response.append(b'<title>301 Moved Permanently</title>')
    response.append(b'</head><body>')
    response.append(b'<h1>Moved Permanently</h1>')

# Generated at 2022-06-23 03:05:32.185639
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    # Unsuccessful calls to constructor of class HTTPSClientAuthHandler
    # TypeError: __init__() takes at least 1 argument (3 given)
    if PY3:
        with pytest.raises(TypeError):
            HTTPSClientAuthHandler()


if hasattr(httplib, 'HTTPConnection'):
    class UnixHTTPConnection(httplib.HTTPConnection, object):
        # http://stackoverflow.com/questions/1112343/how-do-i-specify-a-unix-socket-with-python-requests-or-urllib2
        def __init__(self, unix_socket):
            self._unix_socket = unix_socket
            super(UnixHTTPConnection, self).__init__('localhost')
