

# Generated at 2022-06-23 02:55:40.854821
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    req = RequestWithMethod('https://127.0.0.1', 'POST')
    assert req.get_method() == 'POST'
    req = RequestWithMethod('https://127.0.0.1', 'GET')
    assert req.get_method() == 'GET'
    req = RequestWithMethod('https://127.0.0.1', '')
    assert req.get_method() == 'GET'
    req = RequestWithMethod('https://127.0.0.1', None)
    assert req.get_method() == 'GET'
    req = RequestWithMethod('https://127.0.0.1', 'PUT')
    assert req.get_method() == 'PUT'


if os.name == 'nt':
    default_nss_dir = "c:/nssdb"
else:
    default

# Generated at 2022-06-23 02:55:43.623779
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    # check whether __call__ returns an object of class UnixHTTPConnection
    obj = UnixHTTPConnection('')
    obj.__call__('')



# Generated at 2022-06-23 02:55:49.824727
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "text_form_field": "value",
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        }
    }
    content_type, body = prepare_multipart(fields)
    assert content_type.startswith('multipart/form-data'), "Content-Type should start with multipart/form-data"
    if PY3:
        boundary = content_type.partition('boundary=')[2]

# Generated at 2022-06-23 02:56:00.529930
# Unit test for function prepare_multipart
def test_prepare_multipart():
    data = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    mime_type, body = prepare_multipart(data)
    assert "text/plain" in mime_type
    assert "application/octet-stream" in mime_type
    assert "multipart/form-data" in mime_type
    assert "Content-Disposition: form-data; name=\"text_form_field\"" in to_native(body)

# Generated at 2022-06-23 02:56:06.276984
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    with mock.patch('socket.socket.sendall') as mock_sendall:
        with mock.patch('socket.socket.recv', return_value=b'HTTP/1.0 200 OK\r\n\r\n'):
            s = socket.socket()
            ssl_handler = SSLValidationHandler('127.0.0.1', 443)
            ssl_handler.validate_proxy_response(b'HTTP/1.0 200 OK\r\n\r\n')


# Generated at 2022-06-23 02:56:12.932808
# Unit test for method options of class Request
def test_Request_options():
    request = Request(headers={'Content-Type':'application/json'})
    assert request.options is not None
    assert request.method == 'OPTIONS'
    assert request.headers is not None
    assert request.headers['Content-Type'] == 'application/json'


# Generated at 2022-06-23 02:56:24.184179
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    '''
    Test case
    '''
    instance = RequestWithMethod('http://example.com/', 'get')
    assert instance.get_method() == 'GET'
    instance = RequestWithMethod('http://example.com/', 'post')
    assert instance.get_method() == 'POST'
    instance = RequestWithMethod('http://example.com/', 'put')
    assert instance.get_method() == 'PUT'
    instance = RequestWithMethod('http://example.com/', 'delete')
    assert instance.get_method() == 'DELETE'
    instance = RequestWithMethod('http://example.com/', 'head')
    assert instance.get_method() == 'HEAD'


# Generated at 2022-06-23 02:56:32.392453
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Create a unix socket that can be used to communicate with Postgres'''
    try:
        import psycopg2
        psycopg2_found = True
    except ImportError:
        psycopg2_found = False

    if not psycopg2_found:
        return False

    # connect to postgres using a unix socket
    conn = psycopg2.connect('dbname=postgres')
    # get the socket path of the database connection
    unix_socket = conn.dsn[len('dbname=postgres'):].strip()
    # close the postgres connection
    conn.close()
    # create a unix socket connection to the database
    conn = UnixHTTPSConnection(unix_socket)
    # call connect on the connection to initialize the socket
    conn.connect()
    # close the connection

# Generated at 2022-06-23 02:56:43.006879
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    # No exception
    if not HAS_SSLCONTEXT:
        old_executable = sys.executable
        sys.executable = '/bin/python'

    try:
        try:
            build_ssl_validation_error('www.example.com', '443', ['test/test_certs/'])
        except SSLValidationError as e:
            pass
    finally:
        if not HAS_SSLCONTEXT:
            sys.executable = old_executable

    # With exception
    try:
        try:
            raise AttributeError()
        except AttributeError as e:
            build_ssl_validation_error('www.example.com', '443', ['test/test_certs/'], e)
    except SSLValidationError as e:
        pass



# Generated at 2022-06-23 02:56:54.057043
# Unit test for method post of class Request
def test_Request_post():
    res = Request()
    url = 'post_url'
    data = 'post_data'
    kwargs = {'use_proxy': False, 'force': True, 'last_mod_time': None, 'timeout': None, 'validate_certs': True, 'url_username': 'post_username', 'url_password': 'post_password', 'http_agent': 'post_agent', 'force_basic_auth': True, 'follow_redirects': None, 'client_cert': 'post_cert', 'client_key': 'post_key', 'cookies': None, 'use_gssapi': False, 'unix_socket': None, 'ca_path': None, 'unredirected_headers': None}
    ret = res.post(url, data, **kwargs)
    return ret

# Generated at 2022-06-23 02:57:03.002335
# Unit test for method open of class Request

# Generated at 2022-06-23 02:57:07.740993
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        pass

# This exception is raised when a connection attempt is aborted
# by the client.

# Generated at 2022-06-23 02:57:20.348126
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    d = ParseResultDottedDict({'scheme': 'http', 'path': '/hello/world', 'query': '?1=2&3=4'})
    assert d.as_list() == ['http', None, '/hello/world', None, '?1=2&3=4', None]
    d = ParseResultDottedDict({'scheme': 'http', 'path': '/hello/world'})
    assert d.as_list() == ['http', None, '/hello/world', None, None, None]
    d = ParseResultDottedDict({'scheme': 'http', 'path': '/hello/world', 'netloc': '127.0.0.1'})

# Generated at 2022-06-23 02:57:33.338223
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import mock
    import ssl
    m = mock.MagicMock()
    m.host = 'foo'
    m.port = '123'
    m.timeout = None
    m.key_file = 'bar'
    m.cert_file = 'baz'
    _ssl_wrap_socket = ssl.wrap_socket
    ssl.wrap_socket = mock.MagicMock()
    CustomHTTPSConnection.connect(m)
    ssl.wrap_socket.assert_called_once_with(mock.ANY, keyfile='bar', certfile='baz', ssl_version=ssl.PROTOCOL_SSLv23, server_hostname='foo')
    ssl.wrap_socket = _ssl_wrap_socket

    m = mock.MagicMock()
    m.host = 'foo'
   

# Generated at 2022-06-23 02:57:35.801196
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        import foo
    except ImportError:
        raise MissingModuleError("foo is gone", traceback.format_exc())



# Generated at 2022-06-23 02:57:44.594790
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    cust_conn = CustomHTTPSConnection("localhost", port=443, cert_file="server.crt")
    from sslyze.utils.ssl_socket_patch import wrap_socket
    with mock.patch("sslyze.utils.ssl_socket_patch.wrap_socket", wraps=wrap_socket) as mock_wrap_socket:
        with mock.patch("sslyze.utils.ssl_socket_patch.connect", wraps=cust_conn.connect):
            cust_conn.connect()

# Generated at 2022-06-23 02:57:57.731940
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    '''
    Test case for SSLValidationHandler
    '''
    ca_bundle_path = os.path.expanduser('~/.ansible/roles/test_role/files/ca_bundle.pem')
    with open(ca_bundle_path, 'rb') as f:
        ca_bundle = f.read()

    # Case where ca_path is not None
    try:
        handler = SSLValidationHandler('github.com', 443, ca_bundle_path)
        handler.get_ca_certs()
    except Exception as err:
        raise AssertionError('Unexpected exception raised: %s' % to_native(err))

    # Case with ca_path is None, ca_bundle is None

# Generated at 2022-06-23 02:58:08.400598
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    import re
    import ssl
    from ansible.errors import AnsibleConnectionFailure
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    if not HAS_SSLCONTEXT and not HAS_URLLIB3_PYOPENSSLCONTEXT:
        module = AnsibleModule(argument_spec={
            'type': {'type': 'str', 'default': 'basic'},
            'type_extra': {'type': 'str', 'default': 'noarg'},
        })
        module.exit_json(msg='Not supported on py < 2.7.9.')

    # Test basic functionality without client authentication.
    req = urllib_request.Request('https://www.google.com/')
    handler = HTTPSClientAuthHandler()

# Generated at 2022-06-23 02:58:14.198695
# Unit test for function getpeercert
def test_getpeercert():
    # Test for Python 2 and Python 3
    # This test is far from perfect. But it is better than nothing.
    # It would be better if we could mock all urllib2.urlopen() calls.
    if PY3:
        from urllib.request import urlopen as urllib2_urlopen
    else:
        from urllib2 import urlopen as urllib2_urlopen
    response = urllib2_urlopen('https://www.python.org/')
    assert response

    actual_certificate = getpeercert(response)
    expected_certificate = response.fp.raw._sock.getpeercert()
    assert actual_certificate == expected_certificate

    actual_certificate = getpeercert(response, binary_form=True)

# Generated at 2022-06-23 02:58:18.929275
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    unix_handler = UnixHTTPHandler('/path/to/unix/sock')
    request = urllib_request.Request('http://example.com')
    connection = unix_handler.do_open(UnixHTTPConnection('/path/to/unix/sock'), request)
    assert connection.sock
    assert connection.sock.family == socket.AF_UNIX
    assert connection.sock.type == socket.SOCK_STREAM
    assert hasattr(unix_handler, 'do_open')
# End of unit test for method http_open of class UnixHTTPHandler



# Generated at 2022-06-23 02:58:26.625657
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    proxy_ssl = SSLValidationHandler(None, None)
    valid_codes=None
    response=b"HTTP/1.0 200 OK\r\n"
    #assert that exception is not raised
    proxy_ssl.validate_proxy_response(response, valid_codes)
    #assert that exception is raised
    response=b"HTTP/1.0 302 Redirect\r\n"
    with pytest.raises(ProxyError):
        proxy_ssl.validate_proxy_response(response, valid_codes)


# Generated at 2022-06-23 02:58:29.600765
# Unit test for method delete of class Request
def test_Request_delete():
    url = "http://www.baidu.com"
    c = Request()
    result = c.delete(url)
    print(result)


# Generated at 2022-06-23 02:58:39.439794
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    try:
        import ssl
    except ImportError:
        raise SkipTest("SSL not available on this platform")
    h = CustomHTTPSHandler()
    with patch.object(h, 'do_open', return_value='test', autospec=True) as mock_do_open:
        with patch.object(CustomHTTPSConnection, 'connect', return_value='test', autospec=True) as mock_connect:
            h.https_open('test')
            mock_do_open.assert_called_with(
                CustomHTTPSConnection,
                'test',
            )
            mock_connect.assert_called_with()


# Generated at 2022-06-23 02:58:44.006010
# Unit test for function fetch_file
def test_fetch_file():
    import os
    import requests
    import shutil
    import tempfile

    url="https://raw.githubusercontent.com/ansible/ansible/stable-2.9/lib/ansible/modules/files/copy.py"
    checksum="f455db4296ffc8d1fa2bf9830bd6e9f5"
    tempfd, temppath = tempfile.mkstemp()

# Generated at 2022-06-23 02:58:49.075880
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    import traceback
    try:
        from _invalid_module_import import invalid_module
    except ImportError:
        import_traceback = traceback.format_exc()
        try:
            raise MissingModuleError("Unit test of MissingModuleError constructor", import_traceback)
        except MissingModuleError as e:
            assert str(e) == "Unit test of MissingModuleError constructor"
            assert e.import_traceback == import_traceback
        else:
            raise Exception("MissingModuleError exception did not raise")



# Generated at 2022-06-23 02:58:54.994462
# Unit test for method options of class Request
def test_Request_options():
    request = Request()
    # Stub to return the first parameter given
    url = "url"
    kwargs = {}

    request.open = lambda method, url, **kwargs: url
    uri = request.options(url, **kwargs)

    assert uri == url


# Generated at 2022-06-23 02:58:56.689398
# Unit test for method put of class Request
def test_Request_put():
    req = Request(url)
    assert req.put(url) == "PUT"

# Generated at 2022-06-23 02:59:07.712420
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    import tempfile
    import atexit
    # We want to run prototype method
    # ssl_validation.SSLValidationHandler.http_request
    # with the following parameters:
    # req -
    # We make a dummy class
    class DummyReq:
        def get_full_url(self):
            return None

    # We make an instance of the dummy class
    dummy_req = DummyReq()
    tmp_ca_cert_path, cadata, paths_checked = ssl_validation.SSLValidationHandler.get_ca_certs(ssl_validation.SSLValidationHandler('www.google.com', 443))
    if tmp_ca_cert_path is None:
        tmp_ca_cert_path = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 02:59:08.359751
# Unit test for method get of class Request
def test_Request_get():
    pass

# Generated at 2022-06-23 02:59:14.044504
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    cert_path = os.path.join(CURRENT_DIR, 'test_certs')
    assert os.path.exists(cert_path),\
           "The cert path {0} doesn't exist, cannot perform unit test".format(cert_path)
    cert = os.path.join(cert_path, 'cert.pem')
    key = os.path.join(cert_path, 'private.pem')
    ca = os.path.join(cert_path, 'rootCA.pem')
    cert_reqs = ssl.CERT_REQUIRED
    ssl_version = PROTOCOL

    url = 'https://%s:%s' % (HOST_IPV4, HTTPS_PORT)

# Generated at 2022-06-23 02:59:25.844665
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Confirm that the generic_urlparse function works as expected
    '''
    import six
    import collections
    import types
    import pytest
    # Test older versions of urlparse
    for parts in [
        (
            'https',
            'google.com',
            '/some/url',
            '',
            '',
            ''
        ),
        (
            'https',
            'example.com:65535',
            '/another/url',
            '',
            'a=2&b=3',
            'fragment'
        )
    ]:
        value = types.SimpleNamespace(**generic_urlparse(parts))
        assert isinstance(value, collections.Mapping)
        assert hasattr(value, 'netloc')
        assert value.scheme == parts[0]


# Generated at 2022-06-23 02:59:29.374941
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    expected = 'test-reason'
    error = ConnectionError(expected)
    assert_equal(str(error), expected)


# Generated at 2022-06-23 02:59:37.319043
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    # Nothing should happen if no unix socket is specified
    c = UnixHTTPSConnection(unix_socket=None)
    c.connect()

    class Socket(object):
        connected = False
        sock_name = 'foo'
        def connect(self, address):
            self.connected = True
            self.address = address
        def setsockopt(self, level, option, value):
            pass
    sock = Socket()
    c = UnixHTTPSConnection(unix_socket='foo')
    c.sock = sock
    c.connect()
    assert c.sock.connected
    assert c.sock.address == c.sock.sock_name


# Generated at 2022-06-23 02:59:49.654787
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    '''Constructor of class CustomHTTPSHandler'''
    https_handler = CustomHTTPSHandler()
    assert https_handler._context is None
    assert hasattr(https_handler, 'https_open')
    assert hasattr(https_handler, 'https_request')

if hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
    class HTTPSClientAuthConnection(httplib.HTTPSConnection):
        """Class for HTTPS connection with client-side certificate"""

# Generated at 2022-06-23 03:00:01.688855
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    import imp
    import tempfile
    # Save default module search paths
    default_modules_search_paths = sys.path
    # We create a test directory containing our dummy module
    test_directory = tempfile.mkdtemp()
    test_directory = tempfile.mkdtemp()
    sys.path.append(test_directory)
    # We create a dummy module that has a class with the same name
    test_module_name = 'ansible_connection_class'
    test_module_file_name = '%s.py' % test_module_name

    test_module_code = """class CustomHTTPSConnection:
    pass"""

    open(os.path.join(test_directory, test_module_file_name), 'w').write(test_module_code)
    # We load the module to make sure it is not

# Generated at 2022-06-23 03:00:04.994282
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    uut = UnixHTTPConnection('any_socket')
    assert 'any_socket' == uut._unix_socket



# Generated at 2022-06-23 03:00:11.198074
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class HTTPConnection(httplib.HTTPConnection):
        def __init__(self, *args, **kwargs):
            httplib.HTTPConnection.__init__(self, *args, **kwargs)
            self.sock = None

        def connect(self):
            pass

    httplib.HTTPConnection = HTTPConnection
    try:
        unix_socket_patch_httpconnection_connect()
        assert(httplib.HTTPConnection.connect == UnixHTTPConnection.connect)
    finally:
        httplib.HTTPConnection = HTTPConnection

    with unix_socket_patch_httpconnection_connect():
        assert(httplib.HTTPConnection.connect == UnixHTTPConnection.connect)
    assert(httplib.HTTPConnection.connect != UnixHTTPConnection.connect)



# Generated at 2022-06-23 03:00:17.572881
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with temporary_file() as tmpfile:
        atexit_remove_file(tmpfile)
        assert not os.path.exists(tmpfile)
    # Test that it noops if file does not exist
    with temporary_file() as tmpfile:
        os.unlink(tmpfile)
        atexit_remove_file(tmpfile)

# Generated at 2022-06-23 03:00:25.907626
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    with requests_mock.mock() as m:
        m.get('https://example.com/', text='data')
        handler = CustomHTTPSHandler()
        response = urllib_request.urlopen(urllib_request.Request('https://example.com/'))
        assert response.read() == b'data'


if HAS_URLLIB3_PYOPENSSLCONTEXT and HAS_URLLIB3_SSL_WRAP_SOCKET:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):

        def __init__(self, key=None, cert=None, **kwargs):
            debug_sdk('key and cert should be byte strings')

# Generated at 2022-06-23 03:00:30.726534
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    con = CustomHTTPSConnection("127.0.0.1",
                                key_file="dummy_key_file",
                                cert_file="dummy_cert_file")
# End of unit test for constructor
    assert hasattr(con, 'context')
    assert con.cert_file == "dummy_cert_file"
    assert con.key_file == "dummy_key_file"


# Generated at 2022-06-23 03:00:31.528453
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert is not None



# Generated at 2022-06-23 03:00:36.812336
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    client_cert = 'test_cert'
    client_key = 'test_key'
    handler = HTTPSClientAuthHandler(client_cert, client_key)
    assert handler.client_cert == client_cert
    assert handler.client_key == client_key


# Generated at 2022-06-23 03:00:40.628485
# Unit test for method delete of class Request
def test_Request_delete():
    print("\n\nCalled unit test of method delete of class Request:")
    request = gRS.get_request(sys.argv)
    print(request.delete("https://www.google.com"))
    print("Finsished unit test of method get of class Request.")


# Generated at 2022-06-23 03:00:48.999534
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import contextlib
    with unix_socket_patch_httpconnection_connect():
        assert httplib.HTTPConnection.connect == UnixHTTPConnection.connect

    assert callable(httplib.HTTPConnection.connect)
    assert httplib.HTTPConnection.connect != UnixHTTPConnection.connect
    assert httplib.HTTPConnection.connect == _connect

    @contextlib.contextmanager
    def cm():
        pass

    with cm():
        pass

# Does not exist in Python3
# TODO: Fix exceptions and refactor tests to not use subclasses of
# the exceptions to be removed when dropping py2.
if hasattr(httplib, 'InvalidURL'):
    class InvalidURL(httplib.InvalidURL):
        pass

# Generated at 2022-06-23 03:01:01.659181
# Unit test for function prepare_multipart

# Generated at 2022-06-23 03:01:07.350774
# Unit test for method get of class Request
def test_Request_get():
    request = Request()
    try:
        request.get("") # The url should not be empty
    except Exception as e:
        print("test_Request_get() passed.")
        print("******************************")
        return

    print("test_Request_get() failed.")
    print("******************************")
    return


# Generated at 2022-06-23 03:01:13.447896
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    # Test for response without a valid code
    response = b'HTTP/1.0 666 Error\n'
    ssl_validation_handler = SSLValidationHandler('www.example.com', 443)
    exception_msg = 'Connection to proxy failed'
    with pytest.raises(ProxyError, match=re.escape(exception_msg)):
        ssl_validation_handler.validate_proxy_response(response)
    # Test for response with a valid code
    response = b'HTTP/1.0 200 OK\n'
    response = 'HTTP/1.0 200 OK\n'.encode('utf-8')
    ssl_validation_handler = SSLValidationHandler('www.example.com', 443)
    ssl_validation_handler.validate_proxy_response(response)


# Generated at 2022-06-23 03:01:17.561765
# Unit test for method get of class Request
def test_Request_get():
    requests = Request()
    assert requests.get('http://google.com') == requests.open('GET', 'http://google.com')


# Generated at 2022-06-23 03:01:26.830800
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    tmp_ca_cert_path, cadata, paths_checked = SSLValidationHandler(hostname, port).get_ca_certs()

    # If there is no ca_path, find a valid CA cert in one of the standard locations
    if not ca_path:
        assert paths_checked
        assert cadata
        assert tmp_ca_cert_path

    # If there is ca_path, return the path as is
    else:
        assert paths_checked == [ca_path]
        assert cadata is None
        assert tmp_ca_cert_path == ca_path

    # If this is the first time the method was run, paths should be empty
    assert LOADED_VERIFY_LOCATIONS == []



# Generated at 2022-06-23 03:01:33.982261
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    ansible_cert = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_cert.pem')
    ansible_key = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_key.pem')
    orig_cert = None
    orig_key = None
    if os.path.exists(ansible_cert):
        orig_cert = ansible_cert
    if os.path.exists(ansible_key):
        orig_key = ansible_key

    if not orig_cert:
        # Create a self-signed cert file
        test_cert, test_key = generate_self_signed_cert(CERT_FILE=ansible_cert, KEY_FILE=ansible_key, CN='test_CN.test')

    handler = CustomHTTPS

# Generated at 2022-06-23 03:01:44.868095
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if CustomHTTPSHandler is None:
        pytest.skip('CustomHTTPSHandler is None.')
    handler = CustomHTTPSHandler()
    assert handler.__class__.__name__ == 'CustomHTTPSHandler'
    assert isinstance(handler, urllib_request.HTTPSHandler)



# Generated at 2022-06-23 03:01:48.937016
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    certificate_error = SSLValidationError('certificate')
    assert str(certificate_error) == 'certificate'


# Generated at 2022-06-23 03:01:58.574180
# Unit test for method open of class Request
def test_Request_open():
    # create file_name
    file_name = os.path.basename(__file__)
    # create instance of Request class
    request = Request()
    # get temporary file_path to store test_values
    test_tmp_file = tempfile.mkstemp()
    tmp_file_path = test_tmp_file[1]
    # test method open with data = dictionary
    test_data = {'key': 'value'}
    data = request.open('POST', 'url', data=test_data, timeout=0.1)
    # test method open with data = None
    data = request.open('POST', 'url', data=None, timeout=0.1)
    # test method open with data = StringIO
    test_data = StringIO()
    test_data.write('test_data')

# Generated at 2022-06-23 03:02:03.490678
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    req = RequestWithMethod('http://ansible.com/', 'put', headers={'Content-type': 'application/json'})
    assert req.get_method() == 'PUT'
    assert req.has_header('Content-type') == True
    assert req.get_header('Content-type') == 'application/json'



# Generated at 2022-06-23 03:02:11.267947
# Unit test for method delete of class Request
def test_Request_delete():
  """Unit test for method delete of class Request"""
  # From test/lib/test_utils.py
  httpretty = Mock()
  httpretty.register_uri(httpretty.DELETE, 'http://localhost/', body='{ "status": "OK" }',
                         content_type='text/json')
  # From lib/ansible/executor/task_result.py
  kwargs = {}
  http = utils.http.Request(kwargs)
  url = 'http://localhost/'
  response = http.delete(url)
  response = json.load(response)
  assert response['status'] == 'OK'


# Generated at 2022-06-23 03:02:14.147875
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pe = ProxyError("Test ProxyError constructor")
    assert pe.message == "Test ProxyError constructor"



# Generated at 2022-06-23 03:02:24.411517
# Unit test for method post of class Request
def test_Request_post():
    request = Request(hostname='host', port=80, username=None, password=None, headers=None, use_proxy=True, timeout=None, validate_certs=True, url_username=None, url_password=None, http_agent='ansible-httpget', force_basic_auth=True, follow_redirects=None, client_cert=None, client_key=None, cookies=None, use_gssapi=False, unix_socket=None, ca_path=None, unredirected_headers=None)

    url="http://www.google.co.in/intl/en/policies/privacy/"
    # data=None
    request.post(url)

# test_Request_post()

# Generated at 2022-06-23 03:02:34.212457
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    """Test http_request"""

    #
    # If ssl.wrap_socket function is not defined, the condition is being unhandled
    #
    if not HAS_SSLCONTEXT:
        if not hasattr(ssl, 'wrap_socket'):
            return

    handler = SSLValidationHandler('github.com', 443)

    url = 'https://github.com'
    req = urllib_request.Request(url)
    res = handler.http_request(req)
    if HAS_SSLCONTEXT:
        assert res == req
    else:
        assert res.get_full_url() == url

    #
    # If ssl.wrap_socket function is not defined, the condition is being unhandled
    #

# Generated at 2022-06-23 03:02:47.350732
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    class Handler(CustomHTTPSHandler):
        def do_open(self, *args, **kwargs):
            print(args, kwargs)

        def do_request_(self, *args, **kwargs):
            print(args, kwargs)

    handler = Handler()
    handler.https_open(None)
    handler.https_request(None, 'foo', None, None)

if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):

        """
        Subclass of HTTPSHandler that uses a custom SSLContext that allows for
        SSL Certificate authentication
        """

        def __init__(self, key=None, cert=None, ca_cert=None, ca_path=None):
            self.key

# Generated at 2022-06-23 03:02:56.945563
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    '''Tests connect function of class UnixHTTPConnection'''
    fake_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    fake_sock.connect = MagicMock()
    with patch('socket.socket', return_value=fake_sock):
        unix_connection = UnixHTTPConnection('fake_socket_path')
        unix_connection.connect()
        fake_sock.connect.assert_called_once_with('fake_socket_path')
test_UnixHTTPConnection_connect_patch = patch('urllib3.util.connection.socket', new=socket)
test_UnixHTTPConnection_connect_patch.start()
addCleanup(test_UnixHTTPConnection_connect_patch.stop)



# Generated at 2022-06-23 03:03:01.484910
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import os
    import tempfile
    import unittest
    import shutil
    import socket

    class TestHTTPSConnection(httplib.HTTPSConnection):
        def connect(self):
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM, 0)
            self.sock.connect(self.host)

    class TestUnixHTTPSConnection(unixhttp.UnixHTTPConnection):
        """A class similar to HTTPSConnection, but connects over a unix socket."""

        def __init__(self, unix_socket, *args, **kwargs):
            self._unix_socket = unix_socket
            httplib.HTTPConnection.__init__(self, *args, **kwargs)


# Generated at 2022-06-23 03:03:04.448502
# Unit test for method post of class Request
def test_Request_post():

    # Given a Request instance
    request = Request(Connection())
    # when under test
    resp = request.post('http://127.0.0.1')
    # then
    assert resp.code == 200


# Generated at 2022-06-23 03:03:06.502187
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        import this
    except ImportError:
        dummy_tb = sys.exc_info()[2]
        message = "This is a user message"
        raise MissingModuleError(message, dummy_tb)
    else:
        pytest.fail("ImportError not raised")

#
# Public Functions
#



# Generated at 2022-06-23 03:03:11.709920
# Unit test for function fetch_url
def test_fetch_url():
    print("Testing fetch_url")
    module = FakeAnsibleModule()
    class HttpResponse(object):
        def __init__(self):
            self.info = {}
            self.headers = {}
            self.status_code = 200

    class TestException(Exception):
        pass
    '''
    def open_url(url, data=None, headers=None, method=None, use_proxy=True,
              force=False, last_mod_time=None, timeout=10, validate_certs=True,
              url_username=None, url_password=None, http_agent=None,
              force_basic_auth=False, follow_redirects='urllib2'):
    '''

    # Test successful connection
    print("Testing successful connection")

# Generated at 2022-06-23 03:03:14.871638
# Unit test for method options of class Request
def test_Request_options():
    request = Request()
    result = request.options("https://www.google.com/")
    print("\n result:", result)
    assert(result.getcode() == 200)


# Generated at 2022-06-23 03:03:17.984684
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    un_socket = "/var/run/docker.sock"
    unix_conn = UnixHTTPConnection(un_socket)
    assert unix_conn._unix_socket == un_socket


# Generated at 2022-06-23 03:03:19.105000
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler('/path/to/socket')
    assert handler

#
# Private utilities
#


# Generated at 2022-06-23 03:03:24.432733
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    h = SSLValidationHandler('example.com', 443)
    tmp_ca_cert_path, cadata, paths_checked = h.get_ca_certs()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ssl_s = ssl.wrap_socket(s)
    ssl_s.connect(('example.com', 443))
    # pylint: disable=unexpected-keyword-arg, no-value-for-parameter
    cert = ssl_s.getpeercert(True)



# Generated at 2022-06-23 03:03:26.590223
# Unit test for function fetch_file
def test_fetch_file():
    '''Unit test for fetch_file'''
    module = AnsibleModule(argument_spec={})
    url = 'http://docs.ansible.com/ansible/latest/modules/debug_module.html'
    file_name = fetch_file(module, url)
    assert len(file_name) > 0
    assert os.path.isfile(file_name)



# Generated at 2022-06-23 03:03:30.870267
# Unit test for method post of class Request
def test_Request_post():
    url = 'https://www.oschina.net/'  # 接口url
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'}
    resp = Request.post(url, headers=headers)
    html=resp.read().decode('utf-8')
    print(html)


# Generated at 2022-06-23 03:03:40.446665
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    from ansible.utils.urls import urlparse, ParseResultDottedDict
    # Note, this test will fail in python 2.6, since ParseResultDottedDict is not used there
    url_str = 'http://google.com/some/path'
    url = urlparse(url_str)
    assert url.as_list() == ParseResultDottedDict(url._asdict()).as_list()


#
# Parsing
#


# Generated at 2022-06-23 03:03:51.654317
# Unit test for function fetch_file
def test_fetch_file():
    '''unit test for fetch_file function'''
    import shutil
    import tempfile

    try:
        from ansible.module_utils.urls import open_url
    except ImportError:
        from ansible.module_utils.basic import open_url
    from ansible.module_utils._text import to_bytes

    file_name, ext = os.path.splitext('filename.ext')
    tempdir = tempfile.mkdtemp(prefix='ansible_test-')
    tmp_file = tempfile.NamedTemporaryFile(dir=tempdir, prefix=file_name, suffix=ext, delete=False)
    # Use a random byte sequence as the data, so it can avoid a false
    # positive of checking whether it succeeds in getting the correct
    # file content or not.
    data = os.urandom

# Generated at 2022-06-23 03:04:03.804344
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''Unit test for function build_ssl_validation_error
    '''
    exc = SSLError('[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed')

# Generated at 2022-06-23 03:04:14.934993
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test build_ssl_validation_error
    '''
    msg = [
        ('Failed to validate the SSL certificate for %s:%s.'
         ' Make sure your managed systems have a valid CA'
         ' certificate installed.')
    ]
    if not HAS_SSLCONTEXT:
        msg.append('If the website serving the url uses SNI you need'
                   ' python >= 2.7.9 on your managed machine')
        msg.append(' (the python executable used (%s) is version: %s)' %
                   (sys.executable, ''.join(sys.version.splitlines())))

# Generated at 2022-06-23 03:04:18.551003
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    def test_urlopen_returns_file_descriptor_like_object(input_mock):
        fd, http_handler = input_mock
        # http://bugs.python.org/issue16399
        assert hasattr(http_handler.do_open(fd, "" or None), "fileno")

    unix_socket = "tests/unix_socket"
    fd = UnixHTTPConnection(unix_socket)
    input_mock = (fd, UnixHTTPHandler(unix_socket))
    test_urlopen_returns_file_descriptor_like_object(input_mock)



# Generated at 2022-06-23 03:04:23.309862
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    parse_result = ParseResultDottedDict({'scheme': 'http', 'netloc': 'www.example.com', 'path': '/', 'params': '', 'query': '', 'fragment': ''})
    assert parse_result.as_list() == ['http', 'www.example.com', '/', '', '', '']



# Generated at 2022-06-23 03:04:35.238020
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    class MockSocket(object):
        def __init__(self):
            self.real_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.real_socket.connect = mock.Mock()
            self.real_socket.settimeout = mock.Mock()
        def __getattr__(self, name):
            return getattr(self.real_socket, name)

    # G
    mock_socket = MockSocket()
    with mock.patch("ansible.module_utils.six.moves.socket.socket", new=mock_socket):
        # W
        mock_socket.real_socket.timeout = socket._GLOBAL_DEFAULT_TIMEOUT
        uconn = UnixHTTPConnection("unix-socket")
        # T
        uconn.connect()
        mock_

# Generated at 2022-06-23 03:04:41.548820
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    ''' test for valid socket file'''
    didnot_raise = UnixHTTPConnection('/var/run/docker.sock')
    assert did_not_raise == UnixHTTPConnection
    did_raise = UnixHTTPConnection('/invalid/socket/file')
    assert did_raise == InvalidSocketError

#
# Requests
#



# Generated at 2022-06-23 03:04:43.822753
# Unit test for method options of class Request
def test_Request_options():
    fake_url = 'http://localhost:8000/api/v1/'
    method = 'OPTIONS'
    return Request(method, fake_url)


# Generated at 2022-06-23 03:04:55.962145
# Unit test for method put of class Request
def test_Request_put():
  test_url = "http://example.com/sample"
  test_data = "data"
  test_headers = { "name" : "value" }
  test_use_proxy = True
  test_force = True
  test_timeout = 4
  test_validate_certs = True
  test_url_username = ''
  test_url_password = ''
  test_http_agent = 'agent'
  test_force_basic_auth = True
  test_follow_redirects = True
  test_client_cert = ''
  test_client_key = ''
  test_cookies = 'cookies'
  test_use_gssapi = True
  test_unix_socket = True
  test_ca_path = 'ca_path'

  r = Request()

  # test the put method

# Generated at 2022-06-23 03:04:56.627510
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    pass


# Generated at 2022-06-23 03:05:02.431598
# Unit test for function url_argument_spec
def test_url_argument_spec():
    result = url_argument_spec()

# Generated at 2022-06-23 03:05:09.915894
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://something.somewhere.com:9999/'
    parsed = ['something.somewhere.com', 9999]
    test_handler = maybe_add_ssl_handler(url, True)

    assert hasattr(test_handler, 'hostname')
    assert hasattr(test_handler, 'port')
    assert test_handler.hostname == parsed[0]
    assert test_handler.port == parsed[1]

    raise SkipTest('test disabled temporarily due to failure')



# Generated at 2022-06-23 03:05:15.341867
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    # Special method values (per RFC2616)
    for method in ['GET', 'HEAD', 'POST', 'OPTIONS', 'PUT', 'DELETE', 'TRACE']:
        req = RequestWithMethod('http://example.com/', method)
        assert req.get_method() == method

    # Upper-cased method value
    req = RequestWithMethod('http://example.com/', 'prOPTIOnS')
    assert req.get_method() == 'PROPTIONS'

    # Lower-cased method value
    req = RequestWithMethod('http://example.com/', 'prOPTIOnS'.lower())
    assert req.get_method() == 'PROPTIONS'

    # Any arbitrary method value
    req = RequestWithMethod('http://example.com/', 'Wibble')
    assert req.get

# Generated at 2022-06-23 03:05:18.190402
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime()) == email.utils.formatdate(time.mktime(time.gmtime()))
    assert rfc2822_date_string(time.gmtime(), zone='+0000') == email.utils.formatdate(time.mktime(time.gmtime()), True)
    assert rfc2822_date_string(time.gmtime(), zone='-0500') == 'Fri, 10 Nov 2017 11:59:59 -0500'



# Generated at 2022-06-23 03:05:19.881418
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    bad_url = "http://bad.url.that.does.not.exist"
    try:
        r = urlopen(bad_url)
    except ConnectionError as e:
        assert bad_url in str(e)



# Generated at 2022-06-23 03:05:22.683884
# Unit test for method get of class Request
def test_Request_get():
    req = Request()
    # Test for the return type of the method get
    assert isinstance(req.get('url'), object)


# Generated at 2022-06-23 03:05:24.392635
# Unit test for method open of class Request
def test_Request_open():
    # TODO: Unit test -> test_Request_open
    return True


# Generated at 2022-06-23 03:05:27.426330
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    '''
    Test for SSLValidationHandler constructor
    '''
    module = AnsibleModule(argument_spec={})
    module.exit_json(changed=False)


# Generated at 2022-06-23 03:05:29.250877
# Unit test for constructor of class ProxyError
def test_ProxyError():
    from ansible.module_utils import connection
    e = connection.ProxyError("error_message", "proxy_url")
    assert str(e) == "ProxyError('error_message', 'proxy_url')"
    assert e.proxy_url == "proxy_url"


# Generated at 2022-06-23 03:05:30.024156
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError('err').message == 'err'


# Generated at 2022-06-23 03:05:36.511489
# Unit test for function open_url
def test_open_url():
    # HTTP GET and HEAD
    get = open_url('http://example.com')
    assert get.code == 200
    assert get.msg == 'OK'
    assert get.geturl() == 'http://example.com'
    # "read" it twice to make sure we didn't mess up when trying to reset position
    for i in range(2):
        get.read()

    head = open_url('http://example.com', method='HEAD')
    assert head.code == 200
    assert 'content-type' in head.msg.lower()
    assert head.geturl() == 'http://example.com'

    # HTTP POST
    post = open_url('http://example.com', data='foo')
    assert post.code == 200
    assert post.msg == 'OK'