

# Generated at 2022-06-23 02:55:43.926372
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    assert ParseResultDottedDict({'foo': 'one', 'bar': 'two'}).as_list() == [None, None, None, None, None, None]
    assert ParseResultDottedDict({'scheme': 'one', 'foo': 'bar'}).as_list() == ['one', None, None, None, None, None]
    assert ParseResultDottedDict({'scheme': 'one', 'netloc': 'foo'}).as_list() == ['one', 'foo', None, None, None, None]
    assert ParseResultDottedDict({'scheme': 'one', 'netloc': 'foo', 'path': 'bar'}).as_list() == ['one', 'foo', 'bar', None, None, None]

# Generated at 2022-06-23 02:55:47.960110
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        httplib.HTTPConnection.connect
        assert httplib.HTTPConnection.connect is UnixHTTPConnection.connect

    assert httplib.HTTPConnection.connect is not UnixHTTPConnection.connect



# Generated at 2022-06-23 02:55:58.136622
# Unit test for function url_argument_spec
def test_url_argument_spec():
    actual = url_argument_spec()

# Generated at 2022-06-23 02:55:59.828416
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    x = UnixHTTPConnection('/tmp/unicorn.sock')
    x.connect()



# Generated at 2022-06-23 02:56:08.399076
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    # Raises exception if file doesn't exist
    with pytest.raises(OSError) as exc:
        UnixHTTPConnection('doesntexist')().connect()
    assert 'doesntexist' in str(exc.value)
    # Raises exception if file exists but is not a socket
    with pytest.raises(OSError) as exc:
        UnixHTTPConnection('/bin/ls')().connect()
    assert '/bin/ls' in str(exc.value)

    # Create a temporary socket file which is cleaned up when done
    fd, tmp = tempfile.mkstemp(prefix='ansible_test_UnixHTTPConnection_')
    os.close(fd)
    os.unlink(tmp)
    socket_file = tmp + '.sock'

    # Create a server

# Generated at 2022-06-23 02:56:14.394192
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''
    Verify that this simple class works as intended
    '''
    # pylint: disable=protected-access
    # pylint: disable=no-member
    instance = UnixHTTPSConnection('/path/to/unix/socket')
    assert instance._unix_socket == '/path/to/unix/socket'
    assert instance.timeout is socket.getdefaulttimeout()
    assert instance.sock is None
    assert instance._tunnel_host is None
    assert instance._tunnel_port is None



# Generated at 2022-06-23 02:56:25.000135
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    h = CustomHTTPSHandler()
    assert h.__dict__.get('use_proxy') is None
    h = CustomHTTPSHandler(use_proxy=True)
    assert h.__dict__.get('use_proxy') is True


if HAS_SSLCONTEXT:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):

        # Wrapper to update default host port in case it has not been set
        # correctly (see python issue #9714).
        def https_open(self, req):
            def httplib_context(host, **kwargs):
                # Update Python 3.3+ location of ca_certs
                if 'ca_certs' in kwargs and not os.path.exists(kwargs['ca_certs']):
                    kwargs['ca_certs'] = os

# Generated at 2022-06-23 02:56:36.186271
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    '''
    Unit tests for SSLValidationHandler.make_context
    '''

    # This tests the case where sslcontext is unavailable
    if not HAS_SSLCONTEXT:
        handler = SSLValidationHandler('www.example.com', 443)
        with pytest.raises(NotImplementedError):
            handler.make_context('dummy_path', b'Dummy CAs')

    if HAS_SSLCONTEXT:
        handler = SSLValidationHandler('www.example.com', 443)

        # This tests normal behaviour
        # NOTE: It is not possible to make this test actually close the
        #       connection so it will always return a successful connection
        #       At least the make_context method is tested.
        #       If the connection was maintained it would be possible to
        #       make the test fail with a valid certificate

# Generated at 2022-06-23 02:56:39.934273
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    ca_path = os.path.join(os.path.dirname(__file__), 'test', 'unit', 'utils', 'test_modules', 'cacert.pem')
    test_handler = SSLValidationHandler('www.example.com', 443, ca_path)
    assert test_handler.hostname == 'www.example.com'
    assert test_handler.port == 443
    assert test_handler.ca_path == ca_path



# Generated at 2022-06-23 02:56:52.650982
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    d = ParseResultDottedDict()
    d['scheme'] = 'https'
    d['netloc'] = 'www.example.com'
    d['path'] = '/foo/bar'
    d['params'] = 'param1'
    d['query'] = 'query1=1'
    d['fragment'] = 'fragment1'
    assert d.as_list() == ['https', 'www.example.com', '/foo/bar', 'param1', 'query1=1', 'fragment1']

    d2 = ParseResultDottedDict()
    assert d2.as_list() == [None, None, None, None, None, None]

    d3 = ParseResultDottedDict({'scheme': 'http'})

# Generated at 2022-06-23 02:56:57.526293
# Unit test for method head of class Request
def test_Request_head():
    """
    This is the unit test for the method head of the class Request
    """
    # Creating a new instance of class Request
    req = Request()

    # Creates the url
    url = 'http://github.com'

    # Creates the request to the url
    request = req.head(url)

    # Returns the response code
    return request.getcode()



# Generated at 2022-06-23 02:57:06.612198
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    # Make a ParseResultDottedDict
    prdd = ParseResultDottedDict()
    prdd['scheme'] = 'myscheme'
    prdd['netloc'] = 'mynetloc'
    prdd['path'] = 'mypath'
    prdd['params'] = 'myparams'
    prdd['query'] = 'myquery'
    prdd['fragment'] = 'myfragment'

    # Compare to a list
    pr = ['myscheme', 'mynetloc', 'mypath', 'myparams', 'myquery', 'myfragment']
    assert prdd.as_list() == pr



# Generated at 2022-06-23 02:57:11.423402
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    from urlparse import urlparse
    rvd = ParseResultDottedDict(urlparse(u'http://www.example.com/path/to/file.html'))
    assert rvd.scheme == 'http'
    assert rvd.path == 'path/to/file.html'



# Generated at 2022-06-23 02:57:14.169890
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    "Ensure that the constructor for ConnectionError works."
    try:
        raise ConnectionError()
    except ConnectionError:
        pass
    else:
        assert False, "Didn't raise ConnectionError"



# Generated at 2022-06-23 02:57:24.256272
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname = "localhost"
    port = 80
    paths = ["some paths"]
    exc = "some exception"
    try:
        build_ssl_validation_error(hostname, port, paths, exc)
    except Exception as e:
        assert (str(e) == "Failed to validate the SSL certificate for localhost:80."
                " Make sure your managed systems have a valid CA"
                " certificate installed."
                " The exception msg was: some exception."
                " Paths checked for this platform: some paths."
                " You can use validate_certs=False if you do"
                " not need to confirm the servers identity but this is"
                " unsafe and not recommended.")

# Generated at 2022-06-23 02:57:35.634037
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Check if the test is executed on Linux
    system = platform.system()
    if system == "Linux":
        handler = SSLValidationHandler('example.com', 443)
        paths_checked = handler.get_ca_certs()[2]
        # Test if correct paths are found
        assert '/etc/pki/ca-trust/extracted/pem' in paths_checked
        assert '/etc/pki/tls/certs' in paths_checked
        assert '/usr/share/ca-certificates/cacert.org' in paths_checked
        assert '/etc/ansible' in paths_checked
        assert '/etc/ssl/certs' in paths_checked
    elif system == "SunOS":
        handler = SSLValidationHandler('example.com', 443)
        paths_checked = handler.get_ca_

# Generated at 2022-06-23 02:57:38.713583
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    """
    Test RequestWithMethod constructor.
    """
    r = RequestWithMethod('http://www.google.com', 'post')
    assert r.get_method() == 'POST'
    assert r.has_data() is True


# Generated at 2022-06-23 02:57:40.346838
# Unit test for method head of class Request
def test_Request_head():
    urllib2 = Urllib2()
    res = urllib2.head("https://123.sogou.com")
    print(res)


import unittest

# Generated at 2022-06-23 02:57:50.356429
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    class TestHTTPConnection(httplib.HTTPConnection):
        pass
    url='http://127.0.0.1'
    # Client authentication is not required
    handler1 = HTTPSClientAuthHandler(client_cert=None, client_key=None)
    handler1.do_open = MagicMock()

    handler1.do_open.return_value = TestHTTPConnection
    handler1.https_open(url)
    handler1.do_open.assert_called_once_with(handler1._build_https_connection, url)

    # Client authentication is required
    handler1 = HTTPSClientAuthHandler(client_cert=None, client_key=None)
    handler1.do_open = MagicMock()
    handler1.do_open.return_value = TestHTTPConnection
    handler1.https_open(url)
   

# Generated at 2022-06-23 02:57:55.208641
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert(rfc2822_date_string((2002, 12, 4, 17, 2, 37, 3, 337, -1)) ==
           'Wed, 04 Dec 2002 17:02:37 -0000')


# Generated at 2022-06-23 02:57:58.211512
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError("Proxy connection failed")
    except ProxyError as e:
        assert str(e) == "Proxy connection failed"
    else:
        assert False, "Did not catch ProxyError"



# Generated at 2022-06-23 02:58:03.041414
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    testing out generic_urlparse function
    '''

# Generated at 2022-06-23 02:58:09.423066
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    '''
    Test get_method in RequestWithMethod
    '''
    req = RequestWithMethod('url', 'method')
    assert req.get_method() == 'METHOD'
    req = RequestWithMethod('url', 'get')
    assert req.get_method() == 'GET'
    req = RequestWithMethod('url', 'POST')
    assert req.get_method() == 'POST'
    req = RequestWithMethod('url', '')
    assert req.get_method() == 'GET'

# Generated at 2022-06-23 02:58:13.840371
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    hostname = "test_hostname"
    port = "test_port"
    ca_path = "test_ca_path"

    handler = SSLValidationHandler(hostname, port, ca_path)
    assert handler.hostname == hostname
    assert handler.port == port
    assert handler.ca_path == ca_path

# Generated at 2022-06-23 02:58:16.733326
# Unit test for method put of class Request
def test_Request_put():
    url = None
    data = None
    method = 'PUT'
    request = Request(method=method, url=url, data=data)
    assert(request.method == method)
    assert(request.selector == url)


# Generated at 2022-06-23 02:58:21.442412
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    from time import localtime
    now = localtime()
    answer = rfc2822_date_string(now)
    assert answer == email_utils.formatdate(localtime=now), answer



# Generated at 2022-06-23 02:58:23.940458
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    context = SSLValidationHandler('localhost', 443).make_context(None, None)
    assert context is not None


# Generated at 2022-06-23 02:58:34.176579
# Unit test for function url_argument_spec
def test_url_argument_spec():
    field_list = url_argument_spec().keys()
    system_structure = {
        'url': 'str', 'force': 'bool', 'http_agent': 'str',
        'use_proxy': 'bool', 'validate_certs': 'bool',
        'url_username': 'str', 'url_password': 'str',
        'force_basic_auth': 'bool', 'client_cert': 'path',
        'client_key': 'path', 'use_gssapi': 'bool',
    }

    assert len(system_structure) == len(field_list), "Number of fields is not equal to the number of fields in system_structure!"
    for field in field_list:
        system_structure[field] == test_url_argument_spec.__annotations__[field]



# Generated at 2022-06-23 02:58:35.341421
# Unit test for method patch of class Request
def test_Request_patch():
    n = Request()
    n.patch()

# Generated at 2022-06-23 02:58:37.521661
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError()
    except NoSSLError as e:
        assert str(e).startswith('Needed to connect to an HTTPS url but no ssl library available to verify the '
                                 'certificate:')
        assert len(str(e)) > 60


# Generated at 2022-06-23 02:58:47.195466
# Unit test for method patch of class Request
def test_Request_patch():
    r = Request('http://localhost/')
    assert r.method == 'GET'
    r.patch('http://localhost/')
    assert r.method == 'PATCH'
    assert r.url == 'http://localhost/'
    try:
        r.patch('http://localhost/', data={})
        assert False
    except TypeError:
        assert True
    try:
        r.patch('http://localhost/', data=[])
        assert False
    except TypeError:
        assert True
    try:
        r.patch('http://localhost/', data=())
        assert False
    except TypeError:
        assert True
    try:
        r.patch('http://localhost/', data='')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 02:58:50.441683
# Unit test for method patch of class Request
def test_Request_patch():
    request = Request()
    url = 'https://www.baidu.com'
    data = 'xxxx'
    res = request.patch(url, data)

if __name__ == '__main__':
    # test_Request_patch()
    pass

# Generated at 2022-06-23 02:58:57.391915
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    cert_file = 'foo.cert'
    key_file = 'foo.key'
    unix_socket = 'foo.sock'
    req = 'foo_req'

    class _FooClass(HTTPSClientAuthHandler):
        def __init__(self, *args, **kwargs):
            self._input_args = args
            self._input_kwargs = kwargs
            HTTPSClientAuthHandler.__init__(self, *args, **kwargs)

        def _build_https_connection(self, host, **kwargs):
            self._input_kwargs2 = kwargs
            return host

    foo = _FooClass(cert_file=cert_file, client_key=key_file,
                    unix_socket=unix_socket, foobar='foobar')
    assert foo._input_

# Generated at 2022-06-23 02:59:08.112307
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    connection = CustomHTTPSConnection('somewhere.com', timeout=10, validate_certs=True, cert_file='cert_file', key_file='key_file')
    assert connection is not None
    assert connection.context


if not HAS_URLLIB3 and CustomHTTPSConnection:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(CustomHTTPSConnection, req)

    # Note: This actually only works with Python >= 2.7.9 or 2.7.8 + urllib3
    if HAS_SSLCONTEXT:
        class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
            def __init__(self, key, cert):
                urllib_request.HTTPSHandler.__init__

# Generated at 2022-06-23 02:59:09.105201
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ce = ConnectionError('msg')
    assert ce.message == 'msg'


# Generated at 2022-06-23 02:59:16.127886
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # create dummy class
    class mock_Request(object):
        def __init__(self, url, data=None, headers=None):
            self.url = url
            self.data = data
            self.headers = headers
        def get_full_url(self):
            return self.url
        def get_method(self):
            return 'GET'

    # create dummy class
    class mock_ssl(object):
        def __init__(self):
            self.args = {}
            self.kwargs = {}
        class SSLError(Exception):
            pass
        class _create_unverified_context(object):
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

# Generated at 2022-06-23 02:59:19.522542
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    try:
        maybe_add_ssl_handler("http://google.com", True)
    except NoSSLError:
        assert False


# Generated at 2022-06-23 02:59:23.816285
# Unit test for constructor of class Request
def test_Request():
    request = Request(
        action='get',
        method='GET',
        url='https://www.google.com',
        data=None,
        headers={},
        use_proxy=False,
        force=False,
        last_mod_time=False,
        timeout=90,
        validate_certs=True,
        url_username='',
        url_password='',
        http_agent='',
        force_basic_auth=False,
        follow_redirects='none'
    )
    assert request.action == 'get'
    assert request.method == 'GET'
    assert request.url == 'https://www.google.com'
    assert request.data is None
    assert request.headers == {}
    assert request.use_proxy == False
    assert request.force == False
    assert request.last

# Generated at 2022-06-23 02:59:37.929910
# Unit test for constructor of class CustomHTTPSConnection

# Generated at 2022-06-23 02:59:45.761594
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    url = to_bytes(to_url(''))
    connection = CustomHTTPSConnection(url)
    assert isinstance(connection, CustomHTTPSConnection)


if hasattr(ssl, 'PROTOCOL_SSLv23'):
    PROTOCOL_SSLv23 = ssl.PROTOCOL_SSLv23
else:
    PROTOCOL_SSLv23 = ssl.PROTOCOL_SSLv3


if hasattr(ssl, 'PROTOCOL_SSLv3'):
    PROTOCOL_SSLv3 = ssl.PROTOCOL_SSLv3
else:
    PROTOCOL_SSLv3 = ssl.PROTOCOL_SSLv23

# On py2.6, ssl.SSLContext is not available so we need to use the pyOpenSSL version
# On py2.6

# Generated at 2022-06-23 02:59:48.086717
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler('/var/run/docker.sock')
    conn = handler.https_open('http://localhost')
    assert conn is not None
    assert conn.sock is not None
    assert isinstance(conn.sock, socket.socket)
    assert conn.sock.type == socket.SOCK_STREAM

#
# Helpers
#



# Generated at 2022-06-23 02:59:57.720641
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Monkeypatch the normal HTTPSConnection connect method to verify
    that we indeed call the parent hasattr method when we call our own
    method connect.
    '''
    class MockSuperConnect(object):
        connect_calls = 0
        def __call__(self, *args, **kwargs):
            self.connect_calls += 1

    test_connection = UnixHTTPSConnection('/test-path')
    # Disable pylint check for the super() call. It complains about UnixHTTPSConnection
    # being a NoneType because of the initial definition above, but it won't actually
    # be a NoneType when this code runs
    # pylint: disable=bad-super-call
    with patch.object(test_connection, '__class__') as mock_super:
        mock_super.connect = MockSuperConnect()
        test

# Generated at 2022-06-23 03:00:09.727293
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    from ansible.module_utils._text import to_bytes

    # If cryptography module is not present, we expect None
    if not HAS_CRYPTOGRAPHY:
        assert get_channel_binding_cert_hash(b'some data') is None
        return


# Generated at 2022-06-23 03:00:13.772565
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    connection = CustomHTTPSHandler().https_open(object())
    assert isinstance(connection, CustomHTTPSConnection)

# Generated at 2022-06-23 03:00:15.292130
# Unit test for function fetch_file
def test_fetch_file():
    f = fetch_file("http://fetch_file_test", method = "GET", timeout = 10)
    assert(f == "http://fetch_file_test")
#
# Functions to parse facts
#


# Generated at 2022-06-23 03:00:22.424828
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    assert ParseResultDottedDict().as_list() == [None] * 6
    assert ParseResultDottedDict(scheme='ftp', netloc='192.168.1.1', path='/folder', params='section', query='name=value', fragment='hash').as_list() == ['ftp', '192.168.1.1', '/folder', 'section', 'name=value', 'hash']
    assert ParseResultDottedDict(scheme='ftp').as_list() == ['ftp', None] + [None] * 4


# Generated at 2022-06-23 03:00:31.954941
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    class dummy:

        def __init__(self):
            self.host = None
            self.port = None
            self.key_file = None
            self.cert_file = None
            self.timeout = None
            self.sock = None

        def set_tunnel(self, host, port=None, headers=None):
            pass

        def _tunnel(self):
            pass

    # construcotr with no args
    c = CustomHTTPSConnection()
    # constructor with just a hostname
    c = CustomHTTPSConnection('example.com')
    # constructor with a hostname and a port
    c = CustomHTTPSConnection('example.com', 1234)
    # constructor with a hostname, a port and a context
    c = CustomHTTPSConnection('example.com', 1234, context='context')
   

# Generated at 2022-06-23 03:00:37.274276
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError
    except NoSSLError as e:
        assert str(e) == "Needed to connect to an HTTPS url but no ssl library available to verify the certificate"
        assert repr(e) == "NoSSLError()"



# Generated at 2022-06-23 03:00:40.701492
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    """Unit test for constructor of class SSLValidationError"""
    value = "certificate verify failed"
    cert = None

    obj = SSLValidationError(value, cert)
    assert obj.args[0] == value
    assert obj.args[1] == cert



# Generated at 2022-06-23 03:00:49.153221
# Unit test for constructor of class Request
def test_Request():
    import base64
    req = Request('http://www.python.org')

    assert(req.get_method() == 'GET')

    req = Request('http://www.python.org', 'FOO')

    assert(req.get_method() == 'FOO')

    req = Request('http://www.python.org?foo=bar&baz=2', headers={'Content-type':'text/html', 'X-Foo': 'bar'})

    assert(req.get_full_url() == 'http://www.python.org?foo=bar&baz=2')
    assert(req.get_host() == 'www.python.org')
    assert(req.get_selector() == '?foo=bar&baz=2')
    assert(req.get_type() == 'http')

# Generated at 2022-06-23 03:00:59.177303
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # Test with no proxy
    c = CustomHTTPSHandler()
    assert c is not None

try:
    import ssl
except ImportError:
    CustomHTTPSConnection = None
    CustomHTTPSHandler = None
    HTTPSClientAuthHandler = None
    UnixHTTPSConnection = None
else:
    if not hasattr(ssl, 'create_default_context'):
        # Python 2.7.9 has SSLContext but no create_default_context
        # Python 2.7.8 and earlier does not have SSLContext at all
        try:
            ssl.SSLContext
        except AttributeError:
            HAS_SSLCONTEXT = False
        else:
            HAS_SSLCONTEXT = True
    else:
        HAS_SSLCONTEXT = True

#
# Base HTTPS support
#

# Generated at 2022-06-23 03:01:02.742635
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('Missing host')
    except ProxyError as e:
        assert 'Missing host' in str(e)

# Because of a bug in the Python 2.6 OpenSSL bindings, sometimes
# SSLError(1) will be raised when it should be SSLError(2)
# See: https://github.com/ansible/ansible/issues/11246
# This is a monkeypatch for the issue, since Python 2.6 is no longer
# receiving upstream bugfixes.
# Use this to patch the module in case the exception we're catching is an
# unpatched SSLError(1).



# Generated at 2022-06-23 03:01:07.548165
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test with specific ca_path

    ssl_handler = SSLValidationHandler('test_hostname', 'test_port', ca_path='test_ca_path')
    ca_path, cadata, paths_checked = ssl_handler.get_ca_certs()
    assert ca_path == 'test_ca_path'
    assert not cadata
    assert paths_checked == []
    
    
    

if __name__ == '__main__':
    test_SSLValidationHandler_get_ca_certs()

# Generated at 2022-06-23 03:01:16.414094
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    from getpass import getpass
    import json
    import sys
    import time
    import textwrap
    from ansible.module_utils._text import to_native, to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    results_callback = ResultCallback()
    inventory = InventoryManager(loader=loader, sources=['@/home/ansible/ansible/contrib/inventory/vmware_inventory.py'])
    variable_manager

# Generated at 2022-06-23 03:01:19.582337
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    handler = SSLValidationHandler('127.0.0.1', 443)
    result = handler.http_request(None)
    assert result is None



# Generated at 2022-06-23 03:01:32.561531
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():

    if not CustomHTTPSConnection:
        pytest.skip("CustomHTTPSConnection not available")
        
    class Connection(CustomHTTPSConnection):
        def __init__(self, *args, **kwargs):
            CustomHTTPSConnection.__init__(self, *args, **kwargs)
            self.context = None
            if HAS_SSLCONTEXT:
                self.context = self._context
            elif HAS_URLLIB3_PYOPENSSLCONTEXT:
                self.context = self._context = PyOpenSSLContext(PROTOCOL)
            if self.context and self.cert_file:
                self.context.load_cert_chain(self.cert_file, self.key_file)

        def connect(self):
            pass


# Generated at 2022-06-23 03:01:36.700464
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    '''Unit test for method get_ca_certs of class SSLValidationHandler'''
    handler = SSLValidationHandler('https://example.com', 443)
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert not paths_checked
    assert not ca_path
    assert not cadata



# Generated at 2022-06-23 03:01:42.799165
# Unit test for function open_url
def test_open_url():
    # Test open_url with https
    response = open_url('https://www.google.com/')
    assert response.geturl() == 'https://www.google.com/'
    response.close()
    # Test open_url with ftp
    response = open_url('ftp://speedtest.tele2.net/')
    assert response.geturl() == 'ftp://speedtest.tele2.net/'
    response.close()
    # Test open_url with non http nor ftp
    with pytest.raises(ValueError):
        open_url('file:///etc/passwd')


# Generated at 2022-06-23 03:01:53.862740
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_socket = "./test.sock"
    uc = UnixHTTPConnection(unix_socket)
    uc.connect()
    assert uc.sock.getpeername() == uc.sock.getsockname()
    assert uc.sock.fileno() > 0
    uc.close()



# Generated at 2022-06-23 03:01:59.492518
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    '''
    Basic test, just to make sure that RequestWithMethod can be constructed
    '''
    RequestWithMethod("http://www.google.com", "get")
    RequestWithMethod("https://www.google.com", "GET")
    RequestWithMethod("http://www.google.com", "HEAD")
    RequestWithMethod("http://www.google.com", "POST")
    RequestWithMethod("http://www.google.com", "PUT")
    RequestWithMethod("http://www.google.com", "DELETE")
    RequestWithMethod("http://www.google.com", "GET", headers={})



# Generated at 2022-06-23 03:02:02.006679
# Unit test for function url_argument_spec
def test_url_argument_spec():
    ''' Unit test for function url_argument_spec '''

    spec = url_argument_spec()
    assert spec
# END Unit test for function url_argument_spec



# Generated at 2022-06-23 03:02:07.529697
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    # We know that feedparser is not installed
    try:
        from feedparser import FeedParserDict
    except ImportError:
        import traceback
        mme = MissingModuleError('test_message', traceback.format_exc())
        assert mme.import_traceback == traceback.format_exc()
        assert str(mme) == "test_message"



# Generated at 2022-06-23 03:02:12.661433
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    # Test if file is removed at exit
    fd, filename = tempfile.mkstemp()
    atexit_remove_file(filename)
    assert os.path.isfile(filename)
    try:
        # Simulate exit
        sys.exitfunc()
        # Fail if not handled
        assert False
    except SystemExit:
        # SystemExit is the last exception to be called
        # and we can verify file no longer exists
        assert not os.path.isfile(filename)



# Generated at 2022-06-23 03:02:16.882180
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    unix_http_conn = UnixHTTPConnection('/dev/null')
    assert unix_http_conn._unix_socket == '/dev/null'



# Generated at 2022-06-23 03:02:21.610821
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    import six
    if six.PY2:
        from sys import version_info
        if version_info[:3] <= (2, 7, 10):
            # Python 2.7.10 does not like this test
            return

    # Test correct input
    test_dict = ParseResultDottedDict(scheme='http', netloc='localhost', path='/', params='', query='', fragment='')
    assert test_dict.scheme == 'http'
    assert test_dict.netloc == 'localhost'
    assert test_dict.path == '/'
    assert test_dict.params == ''
    assert test_dict.query == ''
    assert test_dict.fragment == ''

    # Test incorrect input

# Generated at 2022-06-23 03:02:32.068722
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # Test with a self-signed CA with SHA256 signature
    certificate_der = load_file(os.path.join(os.path.dirname(__file__), 'test_get_chanel_binding_cert_hash.der'))
    channel_binding_cert_hash = get_channel_binding_cert_hash(certificate_der)

# Generated at 2022-06-23 03:02:33.336418
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        raise MissingModuleError("Testing an import error", sys.exc_info()[2])
    except Exception as e:
        assert isinstance(e, MissingModuleError)


# Generated at 2022-06-23 03:02:46.022253
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    certificate = b'-----BEGIN CERTIFICATE-----\n-----END CERTIFICATE-----'
    proxy_cert = b'-----BEGIN CERTIFICATE-----\n-----END CERTIFICATE-----'

    class MockSSLContext(object):
        def __init__(self, *args, **kwargs):
            pass

        def wrap_socket(self, sock, *args, **kwargs):
            return True

    class MockSocket(object):
        def __init__(self, *args, **kwargs):
            pass

        def create_connection(self, *args, **kwargs):
            pass

        def sendall(self, *args, **kwargs):
            pass

        def recv(self, *args, **kwargs):
            return b'HTTP/1.0 200 Connection Established'


# Generated at 2022-06-23 03:02:54.016553
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    p = ParseResultDottedDict(scheme='https', netloc='github.com', path='/')
    assert p.scheme == 'https'
    assert p.netloc == 'github.com'
    assert p.path == '/'
    assert p.as_list() == ['https', 'github.com', '/', None, None, None]
    p.newkey = 'new value'
    assert p['newkey'] == 'new value'
    assert p.newkey == 'new value'

#
# HTTP helpers
#


# Generated at 2022-06-23 03:02:59.574713
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    import urllib.request

    unix_socket = '/tmp/test_http.sock'

    try:
        os.unlink(unix_socket)
    except OSError:
        pass

    httpd = http.server.HTTPServer(('localhost', 0), http.server.SimpleHTTPRequestHandler)
    url = "http://%s:%d/" % httpd.server_address
    unix_url = "http+unix://%s/%s" % (urllib.parse.quote('\0' + unix_socket, safe=''), url[7:])

    # start a thread with the server -- that thread will then start one
    # more thread for the actual service
    server_thread = threading.Thread(target=httpd.serve_forever)
    server_thread.set

# Generated at 2022-06-23 03:03:04.956571
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    unix_socket = '/tmp/socket'
    conn = UnixHTTPConnection(unix_socket)
    assert conn._unix_socket == unix_socket


# Generated at 2022-06-23 03:03:15.656699
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    with patch.object(SSLValidationHandler, 'get_ca_certs', return_value=['/tmp/x509.pem', None, []]):
        handler = SSLValidationHandler('host', 443)
        handler.make_context('/tmp/x509.pem', '')


    with patch.object(SSLValidationHandler, 'get_ca_certs', return_value=['', None, []]):
        handler = SSLValidationHandler('host', 443)
        handler.make_context('/tmp/x509.pem', '')


urllib_request.HTTPSHandler = SSLValidationHandler
urllib_request.HTTPHandler = RedirectHandler()



# Generated at 2022-06-23 03:03:23.617878
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():

    class MockContext(object):
        def __init__(self, cafile=None, cadata=None):
            self.cafile = cafile
            self.cadata = cadata

        def load_verify_locations(self, cafile=None, cadata=None):
            self.cafile = cafile or self.cafile
            self.cadata = cadata or self.cadata

    # Test with new context managers
    handler = SSLValidationHandler('hostname', 0, 'ca_file')
    context = handler.make_context(None, None)
    assert isinstance(context, MockContext)
    assert context.cafile == 'ca_file'
    assert context.cadata is None

    # Test with pyOpenSSL
    handler = SSLValidationHandler('hostname', 0)

# Generated at 2022-06-23 03:03:35.624216
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    try:
        import ssl
        _has_ssl = True
    except ImportError:
        _has_ssl = False

    try:
        import OpenSSL.SSL
        _has_pyopenssl = True
    except ImportError:
        _has_pyopenssl = False

    cert = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'http_utils/test/certs/client.pem')
    key = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'http_utils/test/certs/client.key')
    unix_socket = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'http_utils/test/certs/ansible.sock')

# Generated at 2022-06-23 03:03:41.109034
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    conn = UnixHTTPSConnection(unix_socket='/var/run/docker.sock')
    assert conn.__call__('/').__class__.__name__ == 'UnixHTTPSConnection'
    assert conn.__call__('/')._unix_socket == '/var/run/docker.sock'

#
# Credential handling
#


# Generated at 2022-06-23 03:03:49.084046
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import tempfile
    class _HTTPSConnection(httplib.HTTPSConnection):
        def connect(self):
            super(_HTTPSConnection, self).connect()
            self.sock.send('foo')

    # Write a unix socket
    unix_sock_fd, unix_sock = tempfile.mkstemp()
    os.close(unix_sock_fd)
    os.remove(unix_sock)
    with open(unix_sock, 'w+') as f:
        os.chmod(unix_sock, 0o666)
        _ = f.read(1)
        class _UnixHTTPSConnection(_HTTPSConnection):
            def __init__(self, *args, **kwargs):
                self.unix_socket = unix_sock

# Generated at 2022-06-23 03:04:01.171362
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    class Dummy(SSLValidationHandler):
        def get_ca_certs(self):
            tmp_path = None
            if not HAS_SSLCONTEXT:
                tmp_fd, tmp_path = tempfile.mkstemp()
                atexit.register(atexit_remove_file, tmp_path)
            return (tmp_path, None, [])

    # We need to mock ssl.SSLContext.context to test this
    def __init__(self, *args, **kwargs):
        pass

    def load_verify_locations(*args, **kwargs):
        pass

    def create_default_context(*args, **kwargs):
        return self


# Generated at 2022-06-23 03:04:05.921700
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('username', 'password') == b"Basic dXNlcm5hbWU6cGFzc3dvcmQ="



# Generated at 2022-06-23 03:04:09.436875
# Unit test for constructor of class ProxyError
def test_ProxyError():
    errmsg = 'Proxy failed'
    try:
        raise ProxyError(errmsg)
    except ProxyError as ex:
        assert str(ex) == errmsg
    else:
        assert False, 'ProxyError is not raised'



# Generated at 2022-06-23 03:04:14.400032
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    handler = UnixHTTPHandler('socket_path')
    assert handler.http_open('http://foo/') == handler.do_open(UnixHTTPConnection('socket_path'), 'http://foo/')


# Generated at 2022-06-23 03:04:16.102331
# Unit test for function open_url
def test_open_url():
    url = 'http://httpbin.org/get'
    res = open_url(url)
    assert res.code == 200
    assert res.msg == 'OK'
    data = json_loads(res.read())
    assert data['url'] == url


# Generated at 2022-06-23 03:04:19.720964
# Unit test for method open of class Request
def test_Request_open():

    # Create the request
    requester = Request()

    # Create the needed parameters for the method 
    method = "GET"
    url = "https://httpbin.org/get"
    
    # Create the response with the method open
    res = requester.open(method, url)


# Generated at 2022-06-23 03:04:28.003325
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    handler = UnixHTTPHandler('/tmp/socket')
    handler.do_open = Mock(return_value=Mock(status=200, reason='test'))
    req = handler.do_open.return_value.request
    req.get_method.return_value = 'GET'
    req.data = None
    result = handler.http_open(req)
    assert result.status == 200
    assert result.reason == 'test'
    assert handler.do_open.call_count == 1
    assert handler.do_open.call_args[0][0] == UnixHTTPConnection
    assert 'unix_socket' in handler.do_open.call_args[1]
    assert handler.do_open.call_args[1]['unix_socket'] == '/tmp/socket'


# Generated at 2022-06-23 03:04:39.721509
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    # create a request with a method specified
    dummy_url = 'http://dummy.example.com/'
    dummy_method = 'put'
    req = RequestWithMethod(dummy_url, method=dummy_method)
    assert req.get_method() == dummy_method.upper()
    # make sure the url attribute is set
    assert req.get_full_url() == dummy_url
    # make sure data is not set but header is
    assert req.get_data() is None
    assert req.get_header('User-agent') == 'Python-urllib/%s' % urllib_request.__version__
    # now try creating a request with data
    dummy_data = "dummy data"

# Generated at 2022-06-23 03:04:44.781625
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    # Test for valid code
    http_valid_code = 200
    http_resp_valid_code = b'HTTP/1.1 200 Connection established\r\n\r\n'
    assert SSLValidationHandler(None,None).validate_proxy_response(http_resp_valid_code, http_valid_code)

    # Test for invalid code
    http_invalid_code = 404
    http_resp_invalid_code = b'HTTP/1.1 404 Connection established\r\n\r\n'
    assert not SSLValidationHandler(None,None).validate_proxy_response(http_resp_invalid_code, http_invalid_code)

    # Test for multiple valid codes
    http_valid_codes = [200, 400]

# Generated at 2022-06-23 03:04:56.562492
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if not CustomHTTPSConnection:
        return

    assert CustomHTTPSConnection.__init__ is not httplib.HTTPSConnection.__init__, \
        "Constructor of class CustomHTTPSConnection should be overridden"


if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, ssl_version=None,
                     key_file=None,
                     cert_file=None,
                     ca_certs=None,
                     ca_checks=None,
                     retries=None,
                     assert_hostname=None,
                     assert_fingerprint=None,
                     client_cert=None,
                     ssl_context=None):
            urllib_request.HTTPSHandler.__init__(self)


# Generated at 2022-06-23 03:05:06.369023
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    '''
    Unit test for detect_no_proxy method of class SSLValidationHandler
    '''

# Generated at 2022-06-23 03:05:11.696523
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    try:
        conn = UnixHTTPConnection('/string/to/invalid/unix/socket')
        conn.connect()
    except OSError as e:
        assert str(e) == 'Invalid Socket File (/string/to/invalid/unix/socket): [Errno 2] No such file or directory'
    else:
        assert False

#
# functions
#



# Generated at 2022-06-23 03:05:23.727368
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    pass

    if is_py2:
        from ansible.utils.py26_compat import mock

        # set up mock for urllib.request for Python 2
        class MockSSLCerts(object):
            class _SSLCerts(object):
                cert_file = None
                key_file = None
            ssl_certs = None
        old_custom_https_connection = urllib.request._custom_https_connection
        MockSSLCerts.ssl_certs = MockSSLCerts._SSLCerts()
        urllib.request._custom_https_connection = old_custom_https_connection
        urllib.request._custom_https_connection.ssl_certs = MockSSLCerts.ssl_certs

# Generated at 2022-06-23 03:05:28.065776
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    d = ParseResultDottedDict(scheme='https', netloc='www.example.com', path='/foo/bar.sh')
    assert d.as_list() == ['https', 'www.example.com', '/foo/bar.sh', None, None, None]


# Generated at 2022-06-23 03:05:30.596649
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Divergence: Testing constructor on Python 3.3 and 3.4 is problematic.
    if sys.version_info[0:2] != (3, 3) and sys.version_info[0:2] != (3, 4):
        pe = ProxyError("foo")
        assert str(pe) == "foo"
        pe = ProxyError("foo", "bar")
        assert str(pe) == "foo"



# Generated at 2022-06-23 03:05:34.929780
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    conn = CustomHTTPSConnection('server', 'port')
    assert isinstance(conn, httplib.HTTPSConnection)
    assert hasattr(conn, 'context')
    assert conn.context is None
    assert conn.cert_file is None
    conn.key_file = 'keyfile'
    conn.cert_file = 'certfile'
    # Mock the method connect of super class
    mock_connect = Mock()
    conn.connect = mock_connect
    # Mock the method wrap_socket of ssl
    mock_wrap_socket = Mock()
    ssl.wrap_socket = mock_wrap_socket
    # Run the method connect() and check the calls to wrap_socket
    conn.connect()
    sock = Mock()
    assert mock_wrap_socket.call_count == 1
    args = mock_wrap_socket.call_