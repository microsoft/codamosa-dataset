

# Generated at 2022-06-23 02:55:38.597546
# Unit test for method make_context of class SSLValidationHandler

# Generated at 2022-06-23 02:55:39.577789
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    pass



# Generated at 2022-06-23 02:55:44.757180
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class_ = CustomHTTPSConnection
    cert_file = 'cert_file'
    key_file = 'key_file'
    context = 'context'
    host = 'host'
    port = 'port'
    timeout = 'timeout'
    source_address = 'source_address'
    sock = 'sock'
    server_hostname = 'server_hostname'
    wrap_socket = 'wrap_socket'
    tunnel_host = 'tunnel_host'

    m_ssl_wrap_socket = Mock()
    m_ssl_wrap_socket.return_value = wrap_socket
    m_ssl_wrap_socket_class = Mock(return_value=m_ssl_wrap_socket)

# Generated at 2022-06-23 02:55:50.549900
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    e1 = SSLValidationError("error message", "hostname", "certificate")
    assert e1.message == "error message"
    assert e1.hostname == "hostname"
    assert e1.certificate == "certificate"
    # Divergence: Python 2.7 needs __str__() implemented, Python3 has it builtin
    assert str(e1) != ""


# Generated at 2022-06-23 02:56:02.603365
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    from ansible.compat.tests.mock import patch

    mock_kwargs = dict(
        key_file='/foo/bar/key.pem',
        cert_file='/foo/bar/cert.pem'
    )

    with patch('ansible.utils.urls.UnixHTTPSConnection') as mock_UnixHTTPSConnection:
        uhtc = UnixHTTPSConnection('/foo/bar/unix.sock')(**mock_kwargs)
        mock_UnixHTTPSConnection.assert_called_once_with('/foo/bar/unix.sock')
        mock_UnixHTTPSConnection.return_value.__init__.assert_called_once_with(**mock_kwargs)
        assert uhtc is mock_UnixHTTPSConnection.return_value


#
# Functions
#

# Generated at 2022-06-23 02:56:04.346301
# Unit test for method get of class Request
def test_Request_get():
    url = "https://google.com"
    headers = {'user-agent': 'my-app/0.0.1'}
    req = Request(url)
    req.get(url, headers=headers)

# Generated at 2022-06-23 02:56:04.856280
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    pass



# Generated at 2022-06-23 02:56:16.628697
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    handler=SSLValidationHandler('example.com', 443)

# Generated at 2022-06-23 02:56:22.105170
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        unix_socket = f.name
        # unix_socket must not exist
        conn = UnixHTTPSConnection(unix_socket)
        assert conn.sock is None
        assert isinstance(conn, httplib.HTTPSConnection)


#
# File
#

_DEFAULT_CA_PATH = None


# Generated at 2022-06-23 02:56:27.716242
# Unit test for method open of class Request
def test_Request_open():
    class TestRequest(Request):
        pass

    request = TestRequest()
    options = {}
    options.setdefault("url", 'http://localhost')
    try:
        res = request.open("GET", options)
        assert True
    except:
        assert False



# Generated at 2022-06-23 02:56:36.750855
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    class Request(object):
        def get_full_url():
            return 'https://abc'
    ssl_handler = SSLValidationHandler('abc', 443)

    test_cases = [
        ({'https_proxy': 'https://user:pass@proxy.com:8080'}, to_bytes('CONNECT %s:%s HTTP/1.0\r\n\r\n' % ('abc', 443), errors='surrogate_or_strict')),
        ({}, to_bytes('CONNECT %s:%s HTTP/1.0\r\n\r\n' % ('abc', 443), errors='surrogate_or_strict'))
    ]
    for test_case in test_cases:
        os.environ = test_case[0]

# Generated at 2022-06-23 02:56:38.691129
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    with pytest.raises(OSError):
        UnixHTTPConnection('/dev/null')


#
# Utilities
#



# Generated at 2022-06-23 02:56:48.890334
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    prdd_blank = ParseResultDottedDict()
    assert prdd_blank == dict(scheme=None, netloc=None, path=None, params=None, query=None, fragment=None)
    assert prdd_blank.as_list() == [None, None, None, None, None, None]
    prdd = ParseResultDottedDict(scheme='ftp', netloc='www.example.com', path='/pub', params='', query='', fragment='')
    assert prdd == dict(scheme='ftp', netloc='www.example.com', path='/pub', params='', query='', fragment='')
    assert prdd.as_list() == ['ftp', 'www.example.com', '/pub', '', '', '']
    prdd2 = ParseResultDotted

# Generated at 2022-06-23 02:56:57.341719
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler('httpbin.org', 443)
    os.environ['no_proxy'] = '127.0.0.1,localhost,httpbin.org'
    assert handler.detect_no_proxy('http://127.0.0.1:8080/base/path') == False
    assert handler.detect_no_proxy('http://127.0.0.1:8080') == False
    assert handler.detect_no_proxy('http://127.0.0.1:443') == False
    assert handler.detect_no_proxy('http://localhost:8080/base/path') == False
    assert handler.detect_no_proxy('http://localhost:8080') == False
    assert handler.detect_no_proxy('http://localhost:443') == False
    assert handler.det

# Generated at 2022-06-23 02:57:01.027536
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError('hostname', 'cert')
    except SSLValidationError as e:
        assert (e.host, e.cert) == ('hostname', 'cert')



# Generated at 2022-06-23 02:57:02.706286
# Unit test for function url_argument_spec
def test_url_argument_spec():
    url_argument_spec()



# Generated at 2022-06-23 02:57:12.301249
# Unit test for function fetch_file
def test_fetch_file():
    module = mock.MagicMock()
    module.tmpdir = tempfile.gettempdir()

    fetch_temp_filename = fetch_file(module, 'http://localhost/example.txt')
    try:
        assert os.path.exists(fetch_temp_filename) is True
    finally:
        os.unlink(fetch_temp_filename)
        # The module should have been called with add_cleanup_file exactly once.
        assert 1 == module.add_cleanup_file.call_count



# Generated at 2022-06-23 02:57:17.976468
# Unit test for method patch of class Request
def test_Request_patch():
    request = Request()
    url = 'https://api.github.com/user'
    data = {'name': 'test'}
    res = request.patch(url,json=data)
    print(res.status_code)
    print(res.json())
    
    

# Generated at 2022-06-23 02:57:28.532842
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
  unix_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
  try:
    unix_socket.connect('/tmp/pytest-ansible')
  except OSError as e:
    raise OSError('Invalid Socket File (%s): %s' % ('/tmp/pytest-ansible', e))
  unix_conn = UnixHTTPConnection('/tmp/pytest-ansible')
  assert unix_conn is not None
  assert isinstance(unix_conn, UnixHTTPConnection)


# Generated at 2022-06-23 02:57:34.288337
# Unit test for method get of class Request
def test_Request_get():
    my_url = None
    # TEST CODE
    from ansible.module_utils.common.netcommon import Request
    my_obj = Request(my_url=my_url)
    actual_output = my_obj.get()
    desired_output = None
    # END OF TEST CODE
    assert actual_output == desired_output


# Generated at 2022-06-23 02:57:35.903310
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('url', 'method')
    assert str(req) == '<RequestWithMethod>', "get_method failed to return expected string"

# End unit tests


#
# Public functions
#



# Generated at 2022-06-23 02:57:36.655469
# Unit test for method post of class Request
def test_Request_post():
    # TODO
    pass



# Generated at 2022-06-23 02:57:38.603400
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError("my message")
    assert err.message == "my message"


# Generated at 2022-06-23 02:57:43.622633
# Unit test for method head of class Request
def test_Request_head():
    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2

    class TestError(Exception):
        pass

    class MockResponse(object):
        def __init__(self, status=200, msg='OK', headers={}, data='', geturl=None):
            self.status = status
            self.msg = msg
            self.headers = headers
            self.data = data
            self.geturl = geturl

        def read(self):
            return self.data

        def info(self):
            return self.headers

        def geturl(self):
            return self.geturl

    class MockOpener(object):
        def __init__(self):
            self.method = None
            self.url = None
            self.headers = None

# Generated at 2022-06-23 02:57:48.557986
# Unit test for method post of class Request
def test_Request_post():
    url = "https://www.google.com"
    url = urlparse(url)
    request = Request(url)
    
    return request.post()
data = test_Request_post()
print(data.getcode())


# Generated at 2022-06-23 02:57:55.980908
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    handler = UnixHTTPHandler(unix_socket='/tmp/foo')
    req = urllib_request.Request('http+unix://foo/bar')
    conn = handler.do_open(UnixHTTPConnection('/tmp/foo'), req)
    assert conn.sock.family == socket.AF_UNIX
    assert conn.sock.type == socket.SOCK_STREAM



# Generated at 2022-06-23 02:57:57.049686
# Unit test for method open of class Request
def test_Request_open():
    return 0
# class Request



# Generated at 2022-06-23 02:58:01.960379
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    """
    This is a test function for http_open method of class UnixHTTPHandler
    :return:
    """
    unix_http_handler = UnixHTTPHandler('/run/docker.sock')
    conn_obj = unix_http_handler.http_open('http://localhost')
    assert conn_obj

# Generated at 2022-06-23 02:58:14.772674
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    socket_path = os.path.join('/tmp', 'random' + str(uuid.uuid4()) + '.socket')
    httpd = BaseHTTPServer.HTTPServer(('localhost', 0), DummyHandler)
    httpd.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    httpd.socket.bind(socket_path)
    httpd.socket.listen(5)
    httpd.socket_path = socket_path
    t = threading.Thread(target=httpd.serve_forever)
    t.setDaemon(True)  # don't hang on exit
    t.start()
    time.sleep(0.1)


# Generated at 2022-06-23 02:58:16.542498
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    unix_http_connection = UnixHTTPConnection('/path/to/socket')
    assert unix_http_connection is unix_http_connection('fakeserver')

# Generated at 2022-06-23 02:58:29.040198
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    from datetime import datetime
    import ssl
    if not hasattr(ssl, 'OP_NO_SSLv3'):
        ssl.OP_NO_SSLv3 = 0


# Generated at 2022-06-23 02:58:39.678276
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test the generic_urlparse function
    '''
    # Test various schemes
    got = ParseResultDottedDict(scheme='http', netloc='www.example.com', path='/test',
                                params='', query='', fragment='')
    assert generic_urlparse(got).scheme == 'http'
    assert generic_urlparse(got).hostname == 'www.example.com'
    assert generic_urlparse(got).path == '/test'
    assert generic_urlparse(got).port is None
    assert generic_urlparse(got).username is None
    assert generic_urlparse(got).password is None
    got = ParseResultDottedDict(scheme='', netloc='www.example.com', path='/test',
                                params='', query='', fragment='')

# Generated at 2022-06-23 02:58:50.666875
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    import ssl
    # Create CustomHTTPSHandler for testing
    handler = CustomHTTPSHandler()
    # Create a HTTPS request for testing
    req = urllib_request.Request("https://www.google.com")
    # Create connection using https_open methond
    connection = handler.https_open(req)
    # Create socket using ssl.wrap_socket method
    if IS_PYOPENSSL:
        # Use custom method to get SSL socket
        sock = PyOpenSSLContext(PROTOCOL).wrap_socket(socket.socket(),
                                                     server_side=False,
                                                     do_handshake_on_connect=True,
                                                     suppress_ragged_eofs=True,
                                                     server_hostname="www.google.com")
    else:
        sock = ssl.wrap_

# Generated at 2022-06-23 02:58:55.048073
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    handler = SSLValidationHandler('www.google.com', 443)
    assert 'www.google.com' == handler.hostname
    assert 443 == handler.port


# Generated at 2022-06-23 02:58:56.771535
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    UnixHTTPHandler(unix_socket=None, debuglevel=1)


# Generated at 2022-06-23 02:59:07.792116
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    UNIX_HTTP_CONNECTION = UnixHTTPConnection(unix_socket='/example/path')
    UNIX_HTTP_CONNECTION.connect()
    assert UNIX_HTTP_CONNECTION.sock.family == socket.AF_UNIX
    assert UNIX_HTTP_CONNECTION.sock.type == socket.SOCK_STREAM


ConnectionError = ConnectionError
ProxyError = ProxyError
SSLValidationError = SSLValidationError
MissingModuleError = MissingModuleError

# Actually define the URL handlers here, as we can't do it in the top level
# of the module as we haven't imported everything we need yet.

# Generated at 2022-06-23 02:59:17.815579
# Unit test for constructor of class Request
def test_Request():
    '''
    Test the HTTP class constructor.
    '''

    # Test default timeout of 5 seconds.
    http = HTTP()
    assert http.timeout == 5
    assert http.force_basic_auth is True
    assert http.http_agent == 'Ansible-httpget'

    # Test custom timeout and validate_certs.
    http = HTTP(timeout=10, validate_certs=False)
    assert http.timeout == 10
    assert http.validate_certs is False
    assert http.http_agent == 'Ansible-httpget'

    # Test passing in an http_agent.
    http = HTTP(http_agent='foo')
    assert http.timeout == 5
    assert http.validate_certs is True
    assert http.http_agent == 'foo'

    # Test passing in force_basic_

# Generated at 2022-06-23 02:59:28.430589
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    myGet = UnixHTTPHandler('/run/docker.sock')
    req = urllib_request.Request(url='http://unix/version')
    fp = myGet.http_open(req)
    version = fp.read()
    assert version == b"{\"Version\":\"1.12\",\"ApiVersion\":\"1.24\",\"GitCommit\":\"b30f8ac\",\"GoVersion\":\"go1.6.2\",\"Os\":\"linux\",\"Arch\":\"amd64\",\"KernelVersion\":\"4.4.18-boot2docker\",\"BuildTime\":\"2016-08-15T22:53:41.169813885+00:00\"}\n"
# end of unit test for method http_open of class UnixHTTPHandler

#
# Module level utilities
#


# Generated at 2022-06-23 02:59:34.649369
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    with open(os.path.join(os.path.dirname(__file__), b'peercert.pem'), 'rb') as f:
        pem = f.read()
        der = ssl.PEM_cert_to_DER_cert(pem)
        cbh = get_channel_binding_cert_hash(der)
        assert cbh == b'\xc9\x9c\x07\xa7\x97\xda\x05\x64\xa6#\xd8\x1bE\x9c5U\xea\x8d\x98\xe6\xaf\x8a\xfc\xc4\x81\xba\xeaC'

# Generated at 2022-06-23 02:59:41.235922
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    req = urllib_request.Request(
        'https://docs.python.org/',
        headers={'User-agent': 'Mozilla/5.0'})
    handler = SSLValidationHandler(hostname='docs.python.org', port=443)
    assert(handler.http_request(req) == req)



# Generated at 2022-06-23 02:59:48.334049
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    import unittest.mock

    class TestRedirectHandlerFactory(unittest.TestCase):
        def test_redirect_handler_factory(self):
            handler = RedirectHandlerFactory(follow_redirects='all')
            with unittest.mock.patch.object(handler, 'redirect_request') as mck_redirect_request:
                req = unittest.mock.Mock()
                response = handler.redirect_request(req, None, 301, 'url', None, 'newurl')
                mck_redirect_request.assert_called_once_with(req, None, 301, 'url', None, 'newurl')
                self.assertEqual(response, None)
                self.assertEqual(req.get_method(), 'GET')

                mck

# Generated at 2022-06-23 02:59:59.149008
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    class Test():
        def assertEqual(self,a,b):
            if a != b:
                raise Exception("a (%s) != b (%s)" % (a,b))
        def assertRaises(self,error,func,*args,**kwargs):
            try:
                func(*args,**kwargs)
            except Exception as e:
                if isinstance(e,error):
                    return
            raise Exception("func did not raise desired exception")

    test = Test()

    # Test redirect_request for HTTP status < 300 and >= 400
    for code in [200, 299]:
        req = RequestWithMethod('http://localhost', method='GET')
        newurl = 'http://localhost/2'
        res = RedirectHandlerFactory('all').redirect_request(req, None, code, "msg", {}, newurl)

# Generated at 2022-06-23 03:00:09.821213
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test the generic_urlparse function to make sure it returns
    the same values as the modern urlparse does
    '''
    # pick a url to test
    url = 'http://people.redhat.com/~dwalsh'
    # get the expected values
    parts = urlparse.urlparse(url)
    expected = {}
    expected['scheme'] = parts.scheme
    expected['netloc'] = parts.netloc
    expected['path'] = parts.path
    expected['params'] = parts.params
    expected['query'] = parts.query
    expected['fragment'] = parts.fragment
    expected['username'] = parts.username
    expected['password'] = parts.password
    expected['hostname'] = parts.hostname

# Generated at 2022-06-23 03:00:12.726016
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():

    https_handler = maybe_add_ssl_handler('https://192.168.1.1', True)
    https_urllib_request = urllib_request.HTTPHandler()
    https_urllib_request.add_parent(https_handler)
    assert type(https_handler) is SSLValidationHandler


# Generated at 2022-06-23 03:00:23.495493
# Unit test for function url_argument_spec
def test_url_argument_spec():
    ''' Test url_argument_spec. Test that all options are present, and all default values are correct.'''
    spec = url_argument_spec()

    assert spec['url']['type'] == 'str'
    assert spec['force']['type'] == 'bool'
    assert spec['http_agent']['type'] == 'str'
    assert spec['http_agent']['default'] == 'ansible-httpget'
    assert spec['use_proxy']['type'] == 'bool'
    assert spec['use_proxy']['default'] == True
    assert spec['validate_certs']['type'] == 'bool'
    assert spec['validate_certs']['default'] == True
    assert spec['url_username']['type'] == 'str'

# Generated at 2022-06-23 03:00:34.292926
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parts = ('https', 'user:pass@test.com:8080', '/test/test/test', '', '', '')
    parsed = generic_urlparse(parts)
    assert parsed['scheme'] == parts[0]
    assert parsed['netloc'] == parts[1]
    assert parsed['path'] == parts[2]
    assert parsed['params'] == parts[3]
    assert parsed['query'] == parts[4]
    assert parsed['fragment'] == parts[5]
    assert parsed['username'] == 'user'
    assert parsed['password'] == 'pass'
    assert parsed['hostname'] == 'test.com'
    assert parsed['port'] == 8080
    # Now test with a tuple that doesn't have a port

# Generated at 2022-06-23 03:00:37.043807
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    u = UnixHTTPSConnection('/foo/bar')
    # We don't care what this returns, only that it's not None and we get
    # some random error if the method doesn't exist
    assert u()
test_UnixHTTPSConnection___call__()


# Generated at 2022-06-23 03:00:45.524539
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CustomHTTPSHandler:
        raise SkipTest("CustomHTTPSHandler not defined")
    # First, let's check that when ssl is available, no exception is raised
    try:
        CustomHTTPSHandler()
    except Exception as e:
        raise AssertionError("CustomHTTPSHandler must accept no arguments when ssl is available")
    # Now, let's force an exception to be raised
    orig_HTTPSConnection = httplib.HTTPSConnection
    orig_ssl_wrap_socket = ssl.wrap_socket
    httplib.HTTPSConnection = None
    ssl.wrap_socket = None

# Generated at 2022-06-23 03:00:51.388208
# Unit test for function getpeercert
def test_getpeercert():
    fake_response = type('', (), {'fp': type('', (), {'_sock': type('', (), {'fp': type('', (), {'_sock': type('', (), {'getpeercert': getpeercert})})})})})()
    assert getpeercert(fake_response) is not None



# Generated at 2022-06-23 03:00:57.665200
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile(delete=False) as tfile:
        tfile.close()
        assert os.path.exists(tfile.name)
        atexit_remove_file(tfile.name)
        assert not os.path.exists(tfile.name)


# Generated at 2022-06-23 03:01:02.061089
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    tmp_env = os.environ.copy()
    tmp_env['PYTHONHTTPSVERIFY'] = '1'
    tmp_env['REQUESTS_CA_BUNDLE'] = './tests/unit/static/ca.pem'

    # test for pyopenssl
    p = subprocess.Popen(
        [sys.executable, '-c', 'from requests.utils import HAS_SSLCONTEXT, HAS_URLLIB3_PYOPENSSLCONTEXT;print HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT'],
        stdout=subprocess.PIPE,
        env=tmp_env
    )
    assert int(p.communicate()[0].strip()) == 1

    # test for urllib3
    p

# Generated at 2022-06-23 03:01:11.519740
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    t = ParseResultDottedDict()
    assert t.as_list() == [None, None, None, None, None, None]
    t = ParseResultDottedDict(scheme='scheme', netloc='netloc')
    assert t.as_list() == ['scheme', 'netloc', None, None, None, None]
    t = ParseResultDottedDict(scheme='scheme', netloc='netloc', path='path', params='params', query='query', fragment='fragment')
    assert t.as_list() == ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']

#
# HTTP class
#


# Generated at 2022-06-23 03:01:16.007285
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    """Verify that constructing a ConnectionError object works
    """
    try:
        raise ConnectionError("message")
    except ConnectionError:
        pass



# Generated at 2022-06-23 03:01:19.164744
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    get_method_object = RequestWithMethod('http://localhost/test', 'POST')
    assert get_method_object.get_method() == 'POST'



# Generated at 2022-06-23 03:01:26.394251
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    err = MissingModuleError('test_message', 'test_traceback')
    assert 'test_message' == err.message
    assert 'test_traceback' == err.import_traceback
    try:
        raise MissingModuleError(None, None)
    except Exception as e:
        assert isinstance(e, MissingModuleError)



# Generated at 2022-06-23 03:01:27.537201
# Unit test for method post of class Request
def test_Request_post():
    pass


# Generated at 2022-06-23 03:01:37.505061
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    # noinspection PyUnresolvedReferences
    if not HAS_SSLCONTEXT:
        try:
            build_ssl_validation_error('myhost.mydomain.com', 443, ['./data/test_hosts/host_invalid_ssl_v2'])
        except SSLValidationError as e:
            assert e.__str__().startswith('Failed to validate the SSL certificate for myhost.mydomain.com:443.') and \
                   e.__str__().endswith('you can install the `urllib3`, `pyOpenSSL`, `ndg-httpsclient`, and `pyasn1` '
                                        'python modules to perform SNI verification in python >= 2.6.')
        else:
            assert False, 'No SSLValidationError occurred'

# Generated at 2022-06-23 03:01:38.759997
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    """Unit test for constructor of class ConnectionError"""
    try:
        raise ConnectionError("test")
    except ConnectionError as e:
        assert "test" in str(e)


# Generated at 2022-06-23 03:01:43.253444
# Unit test for function fetch_file
def test_fetch_file():
    p = ping.RunModule()
    module = p.module

    # Test invalid URL
    url = 'http://invalid.example.com/'
    actual = fetch_file(module, url)
    assert actual == 'ok'
    module.reset()

    # Test Google
    url = 'http://www.google.com/'
    actual = fetch_file(module, url)
    assert actual == 'ok'
    module.reset()

    # Test retries.
    MockSocket._count = 0
    url = 'http://example.com/'
    os.environ['ANSIBLE_HTTP_RETRIES'] = '2'
    actual = fetch_file(module, url)
    assert actual == 'ok'
    module.reset()

# Generated at 2022-06-23 03:01:55.431786
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    if not HAS_SSL:
        if maybe_add_ssl_handler('https://www.python.org', True):
            assert False, 'NoSSLError was not raised'
        return
    if not maybe_add_ssl_handler('http://www.python.org', True):
        assert False, 'Handler was not added'
    if maybe_add_ssl_handler('https://www.python.org', False):
        assert False, 'Handler was added'
    if not maybe_add_ssl_handler('https://www.python.org', True):
        assert False, 'Handler was not added'
    if not maybe_add_ssl_handler('https://www.python.org', True, '/etc/ssl/certs'):
        assert False, 'Handler was not added'



# Generated at 2022-06-23 03:01:59.576957
# Unit test for function fetch_file
def test_fetch_file():
    # Module should fail when it can't write to tmpdir
    module = AnsibleModule({'url': 'https://example.com/test'})
    os.environ['TMPDIR'] = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'test/spool')
    del os.environ['VIRTUAL_ENV']
    module.run_command_environ_update = dict()
    with pytest.raises(AnsibleExitJson):
        fetch_file(module, 'https://example.com/test')
    module.fail_json.assert_called_once_with(msg="Failure downloading https://example.com/test, %s" % '')
    # Module should not fail when it can successfully write a file to tmpdir


# Generated at 2022-06-23 03:02:10.614486
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    class FakeSSLError(OSError):
        '''
        We create a fake SSLError exception to use in the unit test.
        Sadly, the exception is not a simple class like others but a
        __class__ factory wrapped into a nested function.
        '''
        def __init__(self, *args, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    def _build_sslerror(*args, **kwargs):
        return FakeSSLError(*args, **kwargs)

    def _build_sslerror3(*args, **kwargs):
        return FakeSSLError(*args, **kwargs)


# Generated at 2022-06-23 03:02:22.897716
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    from nose.tools import assert_equal

    class FakeRequest(object):
        _test_data = {}

        @classmethod
        def reset(cls):
            cls._test_data = {}

        def __init__(self, url, method, data=None, headers=None, origin_req_host=None, unverifiable=True):
            if headers is None:
                headers = {}
            self._test_data['url'] = url
            self._test_data['method'] = method
            self._test_data['data'] = data
            self._test_data['headers'] = headers
            self._test_data['origin_req_host'] = origin_req_host
            self._test_data['unverifiable'] = unverifiable

        def get_method(self):
            return self._test_data['method']

# Generated at 2022-06-23 03:02:28.443504
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    connection = UnixHTTPSConnection('/tmp/foo')
    connection.connect()
    assert hasattr(connection, 'sock')
    assert connection.sock

#
# Custom session
#



# Generated at 2022-06-23 03:02:33.218068
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    '''
    Unit test for function rfc2822_date_string
    '''
    _date = rfc2822_date_string(time.gmtime(1416046931))
    assert '2014 Nov 09 11:48:51 -0000' == _date



# Generated at 2022-06-23 03:02:43.686845
# Unit test for method delete of class Request
def test_Request_delete():
    # DELETE /api/users/{userId}
    # Delete user
    #
    # :param str userId: User id to delete
    # :return: Empty object
    # :rtype: Void
    url = url_concat(base_url, '/api/users/{userId}')
    try:
        response = requests.delete(url)
        print('Response HTTP Status Code: {status_code}'.format(
            status_code=response.status_code))
        print('Response HTTP Response Body: {content}'.format(
            content=response.content))
    except requests.exceptions.RequestException:
        print('HTTP Request failed')


# Generated at 2022-06-23 03:02:55.182747
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not CUSTOM_HTTPS_HANDLER_INSTALLED:
        raise AssertionError("Custom HTTPS handler not installed")
    handler = CustomHTTPSHandler()
    assert isinstance(handler, urllib_request.HTTPSHandler)


# Generated at 2022-06-23 03:03:00.207788
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError
    except ProxyError:
        pass
    else:
        assert False



# Generated at 2022-06-23 03:03:02.183242
# Unit test for method delete of class Request
def test_Request_delete():
    request = Request()
    response = request.delete(url)
    assert isinstance(response, urllib_request.addinfourl)

# Generated at 2022-06-23 03:03:07.525236
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    class MockSSLContext(object):
        def __call__(self, protocol):  # protocol pylint: disable=unused-argument
            return self
        def load_verify_locations(self, cafile, cadata):  # cafile and cadata pylint: disable=unused-argument
            pass
    patcher = patch('ssl.create_default_context')
    patcher.start().return_value = MockSSLContext()
    sh = SSLValidationHandler('hostname', 443)
    assert sh.make_context(None, None) is not None


# Generated at 2022-06-23 03:03:18.567972
# Unit test for function prepare_multipart
def test_prepare_multipart():

    fields = {}
    fields['text_form_field'] = 'value'
    fields['file1'] = {"filename": "/bin/true", "mime_type": "application/octet-stream"}
    fields['file2'] = {"content": "text based file content", "filename": "fake.txt", "mime_type": "text/plain"}

    content_type, body = prepare_multipart(fields)

    assert 'multipart' in content_type
    assert 'boundary' in content_type
    assert 'Content-Disposition: form-data' in body
    assert 'Content-Type: application/octet-stream' in body
    assert 'Content-Type: text/plain' in body



# Generated at 2022-06-23 03:03:23.510334
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    try:
        urllib_request.HTTPSHandler()
    except TypeError as e:
        # Python 3.2 and 3.3 raise a TypeError here as parent class constructor is not called
        if getattr(e, 'args', [''])[0] == '__init__() takes at least 2 arguments (1 given)':
            handler = HTTPSClientAuthHandler()
        else:
            raise

if hasattr(socket, 'AF_UNIX') and hasattr(httplib, 'HTTPSConnection'):

    class UnixHTTPSConnection(httplib.HTTPSConnection):
        """HTTPSConnection based on AF_UNIX socket"""

        def __init__(self, unix_socket=None, **kwargs):
            self.unix_socket = unix_socket
            httplib.HTTPSConnection.__init__

# Generated at 2022-06-23 03:03:29.651639
# Unit test for constructor of class Request
def test_Request():
    request = Request(url='http://example.com/', method='GET')
    assert isinstance(request, urllib_request.Request)
    assert request.get_method() == 'GET'



# Generated at 2022-06-23 03:03:31.072671
# Unit test for constructor of class ProxyError
def test_ProxyError():
    _c = ProxyError('foo', 'bar')
    assert len(_c.args) == 2
    assert _c.args[0] == 'foo'
    assert _c.args[1] == 'bar'



# Generated at 2022-06-23 03:03:37.430867
# Unit test for method put of class Request
def test_Request_put():
    url = "http://127.0.0.1"
    data = "This is the text to send"
    # Basic test:
    # Request with minimal args
    r = Request()
    r.put(url, data=data)
    # Request with all args
    r.put(url, data=data, headers=None, use_proxy=False, force=False, last_mod_time=None, timeout=10, validate_certs=False, url_username=None, url_password=None, http_agent=None, force_basic_auth=None, follow_redirects=None, client_cert=None, client_key=None, cookies=None,
         use_gssapi=False, unix_socket=None, ca_path=None)


# Generated at 2022-06-23 03:03:49.835075
# Unit test for method delete of class Request
def test_Request_delete():
    rt = Request()
    rt.force = False
    rt.follow_redirects = 'all'
    rt.unix_socket = None
    rt.url_username = None
    rt.url_password = None
    rt.http_agent = 'ansible-httpget'
    rt.use_proxy = False
    rt.validate_certs = True
    rt.ca_path = None
    rt.timeout = 10
    rt.force_basic_auth = False
    rt.cookies = None
    rt.headers = {}
    rt.client_key = None
    rt.client_cert = None
    assert rt.delete('https://pypi.org/project/google-api-python-client/')



# Generated at 2022-06-23 03:03:54.202451
# Unit test for method open of class Request
def test_Request_open():
    # http examples
    req = Request()
    # simple
    req.open(method='GET', url='http://127.0.0.1:5000')
    # complex
    req.open(method='GET', url='http://127.0.0.1:5000/api/v1.0/tasks/2',
             headers={'Content-Type': 'application/json'},
             use_proxy=True,
             force=True,
             timeout=4.5,
             validate_certs=True,
             url_username='username',
             url_password='password',
             http_agent='Mozilla/5.0',
             force_basic_auth=True,
             follow_redirects='safe_redirects')
    # string example

# Generated at 2022-06-23 03:03:59.973513
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    unix_http_connection = UnixHTTPConnection('/some/file.sock')
    attempts = 0
    # Ensures that the object's attributes are properly initialized
    for attribute in ('default_port', 'strict', 'source_address', 'timeout', 'sock'):
        if hasattr(unix_http_connection, attribute):
            attempts += 1
    assert attempts == 5


# Generated at 2022-06-23 03:04:07.160159
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    filename = 'test_atexit_remove_file.txt'
    fdis = os.open(filename, os.O_CREAT | os.O_RDWR)
    fd = os.fdopen(fdis, 'w')
    fd.write('12')
    fd.close()
    atexit_remove_file(filename)
    assert not os.path.exists(filename)

atexit.register(atexit_remove_file)


# Generated at 2022-06-23 03:04:17.084825
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test function for generic_urlparse
    '''
    urlparse = getattr(urlparse, 'urlparse', None)
    parts = urlparse(u'https://user:paspass@foo.example.com:1234/path/to/somehwere?some=arguments#fragment')
    results = generic_urlparse(parts)
    assert results.scheme == 'https'
    assert results.netloc == 'user:paspass@foo.example.com:1234'
    assert results.path == '/path/to/somehwere'
    assert results.params == ''
    assert results.query == 'some=arguments'
    assert results.fragment == 'fragment'
    assert results.username == 'user'
    assert results.password == 'paspass'
    assert results.hostname

# Generated at 2022-06-23 03:04:26.873827
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class TestConn(httplib.HTTPConnection):
        def __init__(self, host, **kwargs):
            httplib.HTTPConnection.__init__(self, host, **kwargs)
            self.connected = False
        def connect(self):
            self.connected = True
    class TestUnixConn(UnixHTTPConnection):
        def __init__(self, host, **kwargs):
            UnixHTTPConnection.__init__(self, host, **kwargs)
            self.connected = False
        def connect(self):
            self.connected = True
    conn = TestConn(host='example.com')
    unix_conn = TestUnixConn(host='example.com')

# Generated at 2022-06-23 03:04:29.765552
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    # Calling UnixHTTPConnection should not raise an exception
    assert UnixHTTPConnection('/var/run/docker.sock')


#
# HTTP/HTTPS Connection
#


# Generated at 2022-06-23 03:04:32.079435
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    class SomeClass(object):
        def __init__(self, ssl_options):
            pass

    try:
        SomeClass(dict(validate_certs=False))
    except SSLValidationError:
        print("SSLValidationError constructor test passed")
        return
    print("SSLValidationError constructor test failed")


# Generated at 2022-06-23 03:04:34.155170
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    get_channel_binding_cert_hash(b'')

# Generated at 2022-06-23 03:04:38.412471
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    r = RequestWithMethod('https://host/path', 'POST', 'body')
    assert r.get_method() == 'POST'
    assert r.get_full_url() == 'https://host/path'
    assert r.get_data() == 'body'



# Generated at 2022-06-23 03:04:47.136973
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    #test case for issue #24283
    ssl_handler = SSLValidationHandler('localhost', 443)
    #test case for issue #24283

# Generated at 2022-06-23 03:04:49.974497
# Unit test for function getpeercert
def test_getpeercert():
    url = 'https://www.google.com'
    response = urllib_request.urlopen(url)
    assert getpeercert(response) is not None



# Generated at 2022-06-23 03:04:54.694876
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        import httplib
        assert httplib.HTTPConnection.connect == UnixHTTPConnection.connect

    import httplib
    assert httplib.HTTPConnection.connect != UnixHTTPConnection.connect
    assert not hasattr(httplib.HTTPConnection, '_patched_connect')


    class A(httplib.HTTPConnection):
        def connect(self):
            super(A, self).connect()
    with unix_socket_patch_httpconnection_connect():
        a = A('localhost')
        a.connect()
        assert len(a.__dict__) > 0  # make sure a.__dict__ is not empty

    a = A('localhost')
    a.connect()
    assert not len(a.__dict__)



# Generated at 2022-06-23 03:05:05.931139
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(
        client_cert='certificate',
        client_key='key',
        unix_socket='/tmp/test'
    )
    assert handler.client_cert == 'certificate'
    assert handler.client_key == 'key'
    assert handler._unix_socket == '/tmp/test'



# Generated at 2022-06-23 03:05:08.816674
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    url_filepath = 'https://127.0.0.1:8443/'
    http_request_handler = SSLValidationHandler('127.0.0.1', '8443')
    http_request_handler.http_request(url_filepath)


# Generated at 2022-06-23 03:05:14.486419
# Unit test for method head of class Request
def test_Request_head():
    r"""Test case for Request.head"""
    # Get a test URL
    url = get_test_url()

    response = Request().head(url)
    assert response is not None
    assert response.status == 200
    assert response.read() == ''  # should be empty as this is a HEAD



# Generated at 2022-06-23 03:05:23.349097
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    class FakeHTTPSConnection(object):
        def __init__(self, host, cert_file, key_file):
            self.host = host
            self.cert_file = cert_file
            self.key_file = key_file
            self.fake_socket = 'socket'

        def connect(self):
            pass

    class FakeHTTPSHandler(HTTPSClientAuthHandler):
        def do_open(self, https_connection_builder, req):
            return https_connection_builder(req.host, cert_file='certfile', key_file='keyfile'), 'addinfourl'

    client_cert = 'client_cert'
    client_key = 'client_key'
    handler = FakeHTTPSHandler(FakeHTTPSConnection, client_cert, client_key)

# Generated at 2022-06-23 03:05:25.429580
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    import mock
    method = UnixHTTPHandler(unix_socket='a-fake-unix-socket').http_open
    with mock.patch('urllib2.Request'):
        method(req='test-req')
# End of unit test for method http_open of class UnixHTTPHandler



# Generated at 2022-06-23 03:05:27.906709
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('http://localhost', 'post', '', {}, None, True)
    assert req.get_method() == 'POST'

