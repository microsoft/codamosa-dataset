

# Generated at 2022-06-23 02:55:38.574829
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ConnectionError()



# Generated at 2022-06-23 02:55:44.173104
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    exc = MissingModuleError("msg", "traceback")
    assert exc.import_traceback == "traceback"
    try:
        raise exc
    except MissingModuleError as e:
        assert exc.import_traceback == "traceback"
        assert str(e) == "msg"



# Generated at 2022-06-23 02:55:50.713936
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    c = CustomHTTPSConnection(host="example.com" , port=443, cert_file="/dev/null")
    c.connect()


    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, key_file=None, cert_file=None):
            urllib_request.HTTPSHandler.__init__(self)
            self.key_file = key_file
            self.cert_file = cert_file

        def https_open(self, req):
            if hasattr(req, 'host'):
                host = req.host
            elif hasattr(req, 'origin_req_host'):
                host = req.origin_req_host
            else:
                host = None
            if hasattr(req, 'timeout'):
                timeout = req.timeout

# Generated at 2022-06-23 02:56:00.514172
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    hostname = 'localhost'
    port = 443
    ca_path = None
    handler = SSLValidationHandler(hostname, port, ca_path)
    cafile = '/Users/james/ansible/test/support/ca_cert.pem'
    cadata = None
    result = handler.make_context(cafile, cadata)
    if HAS_SSLCONTEXT:
        assert isinstance(result, ssl.SSLContext)
    elif HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert isinstance(result, urllib3.contrib.pyopenssl.PyOpenSSLContext)


# Generated at 2022-06-23 02:56:08.209658
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    test_classes = [SSLValidationHandler("www.google.com", 443)]
    use_proxy = "http://some.proxy.com:8080"
    urls = ["http://www.google.com/",
            "https://www.google.com/",
            "http://www.no-proxy.com/",
            "http://www.proxy.com/",
            "http://www.proxy.com:8080/",
            "https://www.proxy.com:8080/",
            "http://proxy.com/",
            "http://proxy.com:8080/",
            "http://proxy.com.some.more.stuff/",
            "http://proxy.com:8080/more/stuff"]

# Generated at 2022-06-23 02:56:13.118622
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        import asdfasdfasdf
    except ImportError:
        err = sys.exc_info()
        raise MissingModuleError("testing", err)

#
# Utility functions
#



# Generated at 2022-06-23 02:56:17.372570
# Unit test for method post of class Request
def test_Request_post():
    #def post(self, url, data=None, **kwargs):
    # :arg url: URL to request
    # :kwarg data: (optional) bytes, or file-like object to send in the body of the request
    # :kwarg \*\*kwargs: Optional arguments that ``open`` takes.
    pass

# Generated at 2022-06-23 02:56:27.546110
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    c = CustomHTTPSHandler()

if HAS_SSL and OpenSSL is None and HAS_PYOPENSSL:
    # urllib3 performs a version check which you can override with
    # PYOPENSSL_NO_LEGACY_OPENSSL. If you set that flag then you'll need to
    # specify the protocol argument to SSL Wrapper yourself.
    # See: https://github.com/shazow/urllib3/blob/master/urllib3/contrib/pyopenssl.py#L96
    if not hasattr(ssl, 'PROTOCOL_TLSv1_2'):
        PROTOCOL = 'TLSv1_2'
    else:
        PROTOCOL = ssl.PROTOCOL_TLSv1_2


# Generated at 2022-06-23 02:56:32.306316
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    import unittest
    import doctest
    import ansible.utils.pycompat

    # We want our doctests to fail if the implementation is not correct.
    class FailOnException(unittest.TestCase, object):
        def runTest(self):
            pass

        def assertRaisesRegex(self, exception, regex, func, *args, **kwargs):
            try:
                func(*args, **kwargs)
            except exception as err:
                if not re.search(regex, str(err)):
                    raise self.failureException('"%s" does not match "%s"' % (regex, str(err)))
            except Exception as err:
                raise self.failureException(
                    "%s exception is not %s: %s" % (func, exception, err))
            else:
                raise self

# Generated at 2022-06-23 02:56:39.454349
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    from pkg_resources import resource_string
    ca_cert = resource_string(__name__, 'test/http/certs/mycert.pem')
    cert = resource_string(__name__, 'test/http/certs/mycert.pem')
    key = resource_string(__name__, 'test/http/certs/mykey.pem')

    HTTPSClientAuthHandler(ca_cert, cert, key)
    HTTPSClientAuthHandler(ca_cert=ca_cert, cert_file=cert, key_file=key)
    HTTPSClientAuthHandler(ca_cert=ca_cert, client_cert=cert, client_key=key)
    HTTPSClientAuthHandler(unix_socket="/foo/bar")
    HTTPSClientAuthHandler(ca_cert=ca_cert, unix_socket="/foo/bar")

# Generated at 2022-06-23 02:56:48.862184
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    class MockHTTPSHandler(CustomHTTPSHandler):
        assert_hostname = True

        def __init__(self, connection_class=CustomHTTPSConnection):
            self.connection_class = connection_class

        def https_open(self, request):
            self.request_url = request.get_full_url()
            return None

    mock = MockHTTPSHandler()
    req = urllib_request.Request("https://www.ansible.com")
    mock.https_open(req)
    assert mock.request_url == req.get_full_url()


if HAS_URLLIB3_PYOPENSSLCONTEXT:
    PyOpenSSLContext = urllib3.util.ssl_.create_urllib3_context
else:
    PyOpenSSLContext = None


# Generated at 2022-06-23 02:56:52.628968
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    result = prepare_multipart(fields)
    assert result[0].startswith('multipart/form-data')
    assert isinstance(result[1], bytes)
    # TODO: add a check on the output to see if it is what we expect



# Generated at 2022-06-23 02:56:57.304533
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    def test_func(hostname, port, paths, exc):
        return build_ssl_validation_error(hostname, port, paths, exc)
    # Test all the combinations
    test_func("foo.bar", 1, [], ValueError("bad"))
    test_func("foo.bar", 1, [], None)
    test_func("foo.bar", 1, ["/path1", "/path2"], None)


# Generated at 2022-06-23 02:57:08.305571
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return


# Generated at 2022-06-23 02:57:11.922961
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    with pytest.raises(OSError):
        unix_handler = UnixHTTPHandler('/tmp/foo')
        unix_handler.http_open(None)

#
# Utility functions
#



# Generated at 2022-06-23 02:57:23.077406
# Unit test for method post of class Request
def test_Request_post():
    from requests_mock.response import Response
    from requests_mock import MockAdapter
    from requests_mock import DOWNLOAD_DIR
    import requests
    import json
    import os
    import shutil
    import urllib_request
    from urllib_request import urlopen

    url = 'http://localhost:8080/getfile'
    url_dir = 'http://localhost:8080/downloadfile'
    path_dir = 'C:/Users/ANH/PycharmProjects/ansible/requests_mock/download'
    path_file_src = 'learning.pdf'
    path_file_dst = 'learning_test.pdf'
    path_test_file = 'C:/Users/ANH/PycharmProjects/ansible/requests_mock/download/learning_test.pdf'

# Generated at 2022-06-23 02:57:26.167774
# Unit test for constructor of class ProxyError
def test_ProxyError():
    """Verify ProxyError correctly prints arguments when instantiated"""
    try:
        raise ProxyError('arg')
    except ProxyError as e:
        assert str(e) == "('arg',)"



# Generated at 2022-06-23 02:57:35.633312
# Unit test for method put of class Request
def test_Request_put():

    content = b"""{
        "k1": "v1",
        "k2": "v2"
    }"""
    request = urllib_request.Request("https://www.google.com") 
    request.add_header('User-Agent', 'python-urllib')
    request.add_header('content-type', 'application/json')
    request.add_header('content-length', len(content))
    request.add_data(content)
    print(request.get_method())

    response = urllib_request.urlopen(request)

test_Request_put()


# Generated at 2022-06-23 02:57:44.299371
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    # Test path for the client cert and key
    certfile = os.path.join(os.path.dirname(__file__), 'test_httplib.pem')
    keyfile = os.path.join(os.path.dirname(__file__), 'test_httplib.key')

    # Constructor should not return an error
    urllib_request.HTTPSHandler(client_cert=certfile, client_key=keyfile)


if HAS_MATCH_HOSTNAME:
    # get a custom HTTPS connection if match_hostname is available
    HTTPSConnection = CustomHTTPSConnection
    HTTPSHandler = CustomHTTPSHandler
else:
    HTTPSConnection = httplib.HTTPSConnection
    HTTPSHandler = urllib_request.HTTPSHandler

    # capture the backport of match_hostname, if it's

# Generated at 2022-06-23 02:57:57.504652
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    cafile = 'cafile.crt'
    handler = SSLValidationHandler(
        hostname='test.com',
        port=443,
        ca_path=cafile
    )

    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3
    assert len(handler.get_ca_certs()) == 3

# Generated at 2022-06-23 02:58:06.265187
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    err = None
    try:
        import os
        os.path.join_my_friends("Dont", "Call", "This", "Function", "Huh")
    except:
        err = sys.exc_info()[1]
        import_traceback = err.__traceback__

    try:
        # Divergence: Python 3 requires 'exception' keyword.
        raise MissingModuleError("Test Message", import_traceback)
    except:
        mme = sys.exc_info()[1]
        assert mme.message == "Test Message"  # Divergence: Python 3 doesn't have the 'message' attribute
        assert mme.import_traceback == import_traceback


# Generated at 2022-06-23 02:58:13.134567
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    class DummyCustomHTTPSConnection:
        def mock_do_open(self, func, req):
            return 'Connected'

    dummyCustomHTTPSHandler = CustomHTTPSHandler()
    dummyCustomHTTPSHandler.do_open = DummyCustomHTTPSConnection.mock_do_open
    dummyRequest = 'dummyRequest'

    result = dummyCustomHTTPSHandler.https_open(dummyRequest)
    assert result == 'Connected'


# Generated at 2022-06-23 02:58:22.052796
# Unit test for function generic_urlparse

# Generated at 2022-06-23 02:58:26.145376
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(None) is None



# Generated at 2022-06-23 02:58:30.407452
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    unix_http_connection = UnixHTTPConnection('/foo/bar')

    assert unix_http_connection is not None
    assert unix_http_connection._unix_socket == '/foo/bar'

#
# Utility functions
#

DEFAULT_TIMEOUT = 10



# Generated at 2022-06-23 02:58:42.580852
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    http_valid_codes = [200]
    https_valid_codes = [200, 407]

    # Test HTTP request
    obj_handler_http = SSLValidationHandler(None, None)
    obj_handler_http.validate_proxy_response(b"HTTP/1.0 200 OK\r\n\r\n", http_valid_codes)

    # Test HTTPS request - Case 1, 200 OK
    obj_handler_https = SSLValidationHandler(None, None)
    obj_handler_https.validate_proxy_response(b"HTTP/1.0 200 OK\r\n\r\n", https_valid_codes)

    # Test HTTPS request - Case 2, 407 Proxy Authentication Required
    obj_handler_https = SSLValidationHandler(None, None)

# Generated at 2022-06-23 02:58:48.466970
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    validator=SSLValidationHandler('www.google.com',443)
    response=b'HTTP/1.0 200 Established\r\n\r\n'
    assert validator.validate_proxy_response(response)
    response=b'HTTP/1.0 301 Permananent\r\n\r\n'
    try:
        validator.validate_proxy_response(response)
        assert False
    except ProxyError:
        pass


# Generated at 2022-06-23 02:58:56.684063
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    # Test that a UnixHTTPSConnection object is returned by calling UnixHTTPSConnection(unix_socket=unix_path)
    # with a well-formed unix_path
    unix_path = 'unix_path'
    unix_https_connection = UnixHTTPSConnection(unix_path)(unix_path)

    # Test that the unix_socket value returned by UnixHTTPSConnection(unix_path)(unix_path) is correct
    assert(unix_https_connection._unix_socket == unix_path)


# Generated at 2022-06-23 02:59:06.029710
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    from io import StringIO

    # Construct a mock socket
    sock = StringIO()

    # Construct a mock SSL context
    ssl_context = DummySSLContext()

    # Construct a SSLValidationHandler
    handler = SSLValidationHandler('www.ansible.com', 8080)

    # Call its http_request method with the mock socket
    request = handler.http_request(sock)

    # Assert the handler returned an HTTPSConnection object
    assert isinstance(request, urllib_request.HTTPRedirectHandler)



# Generated at 2022-06-23 02:59:20.285548
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():

    # This is the code of httplib.HTTPSConnection.connect that we want to test
    #
    #     if self._tunnel_host:
    #         self._tunnel()
    #     self.sock = socket.create_connection((self.host, self.port),
    #                                          self.timeout, self.source_address)
    #     if getattr(self, '_tunnel_headers', None):
    #         self._send_request(self._tunnel_headers,
    #                            encode_chunked=False)

    # Make sure we don't do anything funky with the system state
    orig_create_connection = socket.create_connection
    orig_send_request = httplib.HTTPSConnection._send_request
    # Make sure we reset the connection state

# Generated at 2022-06-23 02:59:31.809181
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    mock_unix_socket = 'mock_unix_socket'
    mock_host = 'mock_host'
    mock_port = 'mock_port'
    mock_key_file = 'mock_key_file'
    mock_cert_file = 'mock_cert_file'

    try:
        mock_context = ssl.SSLContext(PROTOCOL)
        HAS_SSLCONTEXT = True
    except AttributeError:
        mock_context = None
        HAS_SSLCONTEXT = False

    mock_kwargs = {'mock_key': 'mock_value'}
    mock_httplib_HTTPSConnection = mock.Mock()
    mock_httplib_HTTPSConnection.__init__.return_value = None


# Generated at 2022-06-23 02:59:42.216645
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    with patch.object(ssl, 'wrap_socket'):
        with patch.object(httplib.HTTPSConnection, 'connect'):
            conn = CustomHTTPSConnection('test.com')
            assert conn.context == None
            assert conn.cert_file == None
            assert conn.key_file == None
            assert conn.ssl_version == PROTOCOL

            conn = CustomHTTPSConnection('test.com', cert_file='A', key_file='B')
            assert conn.context == None
            assert conn.cert_file == 'A'
            assert conn.key_file == 'B'
            assert conn.ssl_version == PROTOCOL
            conn.connect()
            assert conn.context != None
            assert conn.cert_file == 'A'
            assert conn.key_file == 'B'


# Generated at 2022-06-23 02:59:43.496510
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('john.doe', 'foobar') == b'Basic am9obi5kb2U6Zm9vYmFy'



# Generated at 2022-06-23 02:59:55.963921
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Tests function generic_urlparse
    '''
    def _test_urlparse_parts(parts, test_parts):
        '''
        Given a result from urlparse, ensure that it looks like the expected test parts
        '''
        assert parts.as_list() == test_parts.as_list()
        assert parts.scheme == test_parts.scheme
        assert parts.netloc == test_parts.netloc
        assert parts.path == test_parts.path
        assert parts.params == test_parts.params
        assert parts.query == test_parts.query
        assert parts.fragment == test_parts.fragment
        assert parts.username == test_parts.username
        assert parts.password == test_parts.password
        assert parts.hostname == test_parts.hostname

# Generated at 2022-06-23 03:00:02.546562
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    if HAS_SSLCONTEXT:
        try:
            import ssl
            ssl_version = ssl.OPENSSL_VERSION
        except ImportError:
            ssl_version = ''
        if sys.version_info[:2] < (2, 7):
            py_version = ''.join(map(str, sys.version_info[:3]))
        else:
            py_version = '.'.join(map(str, sys.version_info[:3]))
        url = 'https://www.ansible.com'
        err = NoSSLError(url, ssl_version, py_version)
        assert str(err).startswith('No SSL context is available to verify the certificate'), err
        assert 'https://www.ansible.com' in str(err), err

# Generated at 2022-06-23 03:00:13.041480
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    settings = {'no_proxy': 'localhost,sample.domain.com'}
    hostname = 'sample.domain.com'
    test_class = SSLValidationHandler(hostname)
    test_no_proxy = settings.get('no_proxy')
    if test_no_proxy:
        test_no_proxy = test_no_proxy.split(',')
        test_url_netloc = urlparse(test_class.hostname).netloc
        for test_host in test_no_proxy:
            if test_url_netloc.endswith(test_host) or test_url_netloc.split(':')[0].endswith(test_host):
                return False
    return True
# unit test for method get_ca_certs of class SSLValidationHandler

# Generated at 2022-06-23 03:00:21.493957
# Unit test for constructor of class Request
def test_Request():
   correct_request = urllib_request.Request('http://localhost/test_file',
                               data=open('test_file', 'r').read())
   request_to_test = RequestWithMethod('http://localhost/test_file', 'GET',
                               open('test_file', 'r').read())
   assert correct_request.get_method() == request_to_test.get_method()
   assert correct_request.get_type() == request_to_test.get_type()
   assert correct_request.get_full_url() == request_to_test.get_full_url()
   assert correct_request.get_host() == request_to_test.get_host()
   assert correct_request.get_selector() == request_to_test.get_selector()
   assert correct_request.has_

# Generated at 2022-06-23 03:00:32.152004
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    # Test RequestWithMethod constructor
    url = 'http://foo.com'
    method = 'DELETE'
    data = 'abc'
    headers = {'X-Foo': 'foo'}
    origin_req_host = 'foo.org'
    unverifiable = False

    r = RequestWithMethod(url, method, data, headers, origin_req_host, unverifiable)

    # Test if the constructor has set attributes correctly
    assert r.full_url == url, 'RequestWithMethod constructor: full_url is not set correctly'
    assert r.method == method, 'RequestWithMethod constructor: method is not set correctly'
    assert r.data == data, 'RequestWithMethod constructor: data is not set correctly'
    assert r.headers == headers, 'RequestWithMethod constructor: headers is not set correctly'

# Generated at 2022-06-23 03:00:36.584111
# Unit test for method put of class Request
def test_Request_put():
    url = 'http://127.0.0.1:8000/'
    res = Request().put(url,timeout=10)
    assert res is not None and res.getcode() == 200

# Generated at 2022-06-23 03:00:45.475231
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''unit test for function build_ssl_validation_error'''
    class SSLValidationError(Exception):
        '''mocked class SSLValidationError'''
        pass

    try:
        build_ssl_validation_error('', '', [])
    except SSLValidationError as err:
        assert err.args[0].startswith('Failed to validate the SSL certificate for :.')
        assert err.args[0].endswith('Paths checked for this platform: .')

    try:
        build_ssl_validation_error('', '', [], Exception('test'))
    except SSLValidationError as err:
        assert err.args[0].startswith('Failed to validate the SSL certificate for :.')

# Generated at 2022-06-23 03:00:52.930452
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    handler = SSLValidationHandler('www.example.com', 443)
    # Tests for case when cafile or cadata is None
    assert handler.make_context(None, None)
    assert handler.make_context('nonexistentca', None)
    # Tests for case when cadata is given
    assert handler.make_context(None, b'cadata')


# Note: this is a class so that we can mock it in unit tests

# Generated at 2022-06-23 03:01:00.764919
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    conn = UnixHTTPSConnection('/tmp/socket')
    assert conn is not None

    # pylint: disable=E1101
    conn = UnixHTTPSConnection('/tmp/socket')
    conn.host = 'foo'
    conn.port = 42
    conn.sock = 'sock'
    assert conn.host == 'foo'
    assert conn.port == 42
    assert conn.sock == 'sock'
    # pylint: enable=E1101

# Python 2.6 doesn't have ssl.PROTOCOL_SSLv3, just ssl.PROTOCOL_SSLv23.
# If ssl.PROTOCOL_SSLv3 was passed in we try to match it with ssl.PROTOCOL_SSLv23
# which means we'll also disable TLSv1.0, TLS

# Generated at 2022-06-23 03:01:04.380479
# Unit test for method patch of class Request
def test_Request_patch():
    # create a Request object
    req = Request()
    # assign a 'POST' value for method
    req.method = 'POST'
    assert req.method == "POST"

# Generated at 2022-06-23 03:01:05.136018
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    with pytest.raises(TypeError):
        ConnectionError(1)


# Generated at 2022-06-23 03:01:15.094463
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():

    class HTTPSHandlerTests(unittest.TestCase):
        def test_dummy(self):
            # NOTE: This test is just to ensure the class compiles and
            # instantiates properly.
            dummy = CustomHTTPSHandler()
            self.assertIsInstance(dummy, CustomHTTPSHandler)

    suite = unittest.TestLoader().loadTestsFromModule(HTTPSHandlerTests())
    unittest.TextTestRunner(verbosity=2).run(suite)


if 'ssl' in sys.modules and sys.version_info < (2, 7, 9):
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
        """HTTPS handler with authentication"""
        def __init__(self, key, cert):
            urllib_request.HTTPSHandler.__init__(self)
           

# Generated at 2022-06-23 03:01:24.121646
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    unix_conn = UnixHTTPSConnection('/path/to/unix/socket')
    assert unix_conn.sock is None
    # This call only works because _context is mocked in unit tests
    unix_conn.connect()
    assert unix_conn.sock is not None
    assert isinstance(unix_conn.sock, socket.socket)

if CustomHTTPSConnection:
    class ConnectionWithTimeout(CustomHTTPSConnection):
        def __init__(self, *args, **kwargs):
            self._timeout = kwargs.pop('timeout', None)
            CustomHTTPSConnection.__init__(self, *args, **kwargs)

        def connect(self):
            "Connect to a host on a given (SSL) port."

# Generated at 2022-06-23 03:01:34.690947
# Unit test for method patch of class Request
def test_Request_patch():
    # mock the urllib_request.urlopen function
    urllib_request.urlopen = mock.MagicMock()
    
    req = Request()
    
    # test with no input arguments
    req.patch()
    # check that urllib_request.urlopen was actually called
    urllib_request.urlopen.assert_called()
    
    # test with one input argument
    req.patch("http://www.example.com")
    # check that urllib_request.urlopen was actually called
    urllib_request.urlopen.assert_called()
    
    # test with multiple input arguments
    req.patch("http://www.example.com", data=("a", "b", "c"))
    # check that urllib_request.urlopen was actually called

# Generated at 2022-06-23 03:01:37.231064
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    try:
        unix_socket = '/var/run/docker.sock'
        handler = UnixHTTPHandler(unix_socket)
        handler.__repr__()
    except Exception:
        assert False, 'Class UnixHTTPHandler constructor throws an exception!'
    else:
        assert True, 'Class UnixHTTPHandler constructor does not throw an exception!'

# Generated at 2022-06-23 03:01:47.244504
# Unit test for function getpeercert
def test_getpeercert():
    # Make sure the cert is valid for 8 hours
    # Tests should not be run for more than 7.5 hours or certs will expire
    subprocess.check_call(['openssl', 'x509', '-req', '-days', '8', '-in', 'test/files/certs/req.pem', '-signkey', 'test/files/certs/key.pem', '-out', 'test/files/certs/chained.pem'])

    # Set up the server
    server = socket.socket()
    server.bind(('0.0.0.0', 0))
    server.listen(1)
    _, port = server.getsockname()
    thread = threading.Thread(target=lambda: server.accept())
    thread.start()

    # Run HTTPS request
    handler = SSL

# Generated at 2022-06-23 03:01:54.290849
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    '''Test https connection to unix socket'''
    unix_socket = u'/var/run/docker.sock'
    try:
        conn = UnixHTTPSConnection(unix_socket)
        conn.connect()
        conn.close()
    except OSError as e:
        raise OSError('Invalid Socket File (%s): %s' % (unix_socket, e))
    except ConnectionError as e:
        raise ConnectionError('Invalid Socket File (%s): %s' % (unix_socket, e))

#
# Transport
#


# Generated at 2022-06-23 03:01:58.477399
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_socket = '/tmp/foo'
    conn = UnixHTTPSConnection(unix_socket)
    conn(host='localhost')
    assert conn._unix_socket == unix_socket
    assert conn.host == 'localhost'
    conn(host='localhost', port=123)
    assert conn._unix_socket == unix_socket
    assert conn.host == 'localhost'
    assert conn.port == 123



# Generated at 2022-06-23 03:02:02.836653
# Unit test for method delete of class Request
def test_Request_delete():
    test_url = "https://httpbin.org/delete"
    req = Request()
    r = req.delete(test_url)
    print(r)



# Generated at 2022-06-23 03:02:06.009479
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    def test():
        try:
            raise NoSSLError()
        except NoSSLError as e:
            assert str(e) == "HTTPS certificate validation not supported: No module named ssl"
    test()

if not HAS_MATCH_HOSTNAME:
    class HostnameError(SSLValidationError):
        """Needed to connect to an HTTPS url but unable to match hostname"""
        pass



# Generated at 2022-06-23 03:02:17.203863
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import os
    with unix_socket_patch_httpconnection_connect():
        http = httplib.HTTPConnection('unix:/tmp/test')
        http.connect()
        assert isinstance(http.sock, socket.socket)
        assert http.sock.fileno() == -1
        assert http.sock.family == socket.AF_UNIX
        assert http.sock.type == socket.SOCK_STREAM
        assert http.sock.proto == socket.IPPROTO_IP

    with unix_socket_patch_httpconnection_connect():
        http = httplib.HTTPConnection(os.path.realpath('/tmp/test'))
        http.connect()
        assert isinstance(http.sock, socket.socket)
        assert http.sock.fileno() == -1

# Generated at 2022-06-23 03:02:26.762249
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    '''
    Test validate_proxy_response method of class SSLValidationHandler.
    '''
    tmp_ssl_validation_handler = SSLValidationHandler('localhost', 443, '/path/to/ca/file')

    # Testing Error: Connection to proxy failed
    try:
        tmp_ssl_validation_handler.validate_proxy_response('HTTP/1.0 200 OK\r\n\r\n')
    except Exception as e:
        assert e.__str__() == 'Connection to proxy failed'

    # Testing 200 OK
    assert tmp_ssl_validation_handler.validate_proxy_response('HTTP/1.0 200 OK\r\n\r\n', [200]), 'Testing 200 OK'

    # Testing 200

# Generated at 2022-06-23 03:02:33.029765
# Unit test for constructor of class Request
def test_Request():
    """Unit test for constructor of class Request"""
    req = Request(method='GET', url='http://test.com/',
                  headers={'test': 'test'}, data=b'test')
    assert req.method == 'GET'
    assert req.full_url == 'http://test.com/'
    assert req.data == b'test'
    assert req.headers['test'] == 'test'
    assert req.unredirected_hdrs['test'] == 'test'


# Generated at 2022-06-23 03:02:38.708180
# Unit test for method head of class Request
def test_Request_head():
    from lib.common.request import Request
    from collections import Counter
    url = 'https://www.baidu.com'
    request = Request()
    try:
        response = request.head(url)
    except Exception as e:
        print(e)
    print(response.getcode())
    print(response.getheaders())
    print(Counter(response.getheaders()))


# Generated at 2022-06-23 03:02:44.270004
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    test_handler = SSLValidationHandler('google.com', 443)
    test_handler.make_context(None, None)
    test_handler.get_ca_certs()



# Generated at 2022-06-23 03:02:53.711141
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    ''' test_ParseResultDottedDict_as_list
    Tests that method `as_list` of class `ParseResultDottedDict` works properly
    '''
    prdd = ParseResultDottedDict({'scheme': 's', 'netloc': 'n', 'path': 'p', 'params': 'pa', 'query': 'q', 'fragment': 'f'})
    assert prdd.as_list() == ['s', 'n', 'p', 'pa', 'q', 'f']
# EOF Unit test for method as_list of class ParseResultDottedDict


#
# Basic HTML parsing
#

# Generated at 2022-06-23 03:03:02.818753
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
   # Load certs from YAML file
   with open('ssl-validation-handler-test-certs.yaml', 'r') as stream:
       certs = yaml.load(stream)

   # certs['ca_certs'] contains a list of tuples (filename, webserver)
   # certs['ca'] contains the certificate to be used if ca_path is specified
   certs['ca_certs'] = [('cacert.pem', None)]
   certs['ca'] = 'blah'
   os.environ['https_proxy'] = 'http://www.google.com:80'

   # Get the current handler for http_request
   handler = urllib_request.get_connection_handler('https')
   # Replace the http_request handler with our custom handler

# Generated at 2022-06-23 03:03:08.395119
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # assert ConnectionError(Exception)
    # assert ConnectionError(Exception).__str__() == str(Exception)
    assert ConnectionError('Message').__str__() == 'Message'
    try:
        raise ConnectionError('Message')
    except Exception as e:
        assert str(e) == 'Message'



# Generated at 2022-06-23 03:03:19.724474
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler(hostname='foo', port='bar')
    host_match = handler.detect_no_proxy('https://ec2-54-93-2-75.eu-central-1.compute.amazonaws.com')
    assert host_match

    os.environ['no_proxy'] = 'foobar.com'
    host_match = handler.detect_no_proxy('https://ec2-54-93-2-75.eu-central-1.compute.amazonaws.com')
    assert host_match
    host_match = handler.detect_no_proxy('https://ec2-54-93-2-75.eu-central-1.compute.amazonaws.com')
    assert host_match


# Generated at 2022-06-23 03:03:22.356329
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError(to_native(u'Test', errors='surrogate_or_strict'))
    except ConnectionError as e:
        assert isinstance(str(e), str)
        assert isinstance(to_text(str(e)), text_type)



# Generated at 2022-06-23 03:03:25.899584
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    # test for ticket 7132
    assert "Fri, 09 Nov 2001 01:08:47 -0000" == rfc2822_date_string(
        (2001, 11, 9, 1, 8, 47, 4), "-0000")
    assert "Thu, 08 Nov 2001 01:08:47 -0000" == rfc2822_date_string(
        (2001, 11, 9, 1, 8, 47, 4), "+0000")
    assert "Thu, 08 Nov 2001 01:08:47 -0100" == rfc2822_date_string(
        (2001, 11, 9, 1, 8, 47, 4), "+0100")



# Generated at 2022-06-23 03:03:37.099034
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    def _create_socket_mock(family, type_):
        if sys.version_info[0] < 3:
            import __builtin__ as builtin
        else:
            import builtins as builtin
        mock = Mock()
        mock.return_value = (family, type_, None)
        builtin.socket.socket = mock
        return mock

    family = socket.AF_INET
    type_ = socket.SOCK_STREAM
    unix_socket = '/path/to/socket'
    socket_mock = _create_socket_mock(family, type_)

    connection = UnixHTTPSConnection(unix_socket)
    connection.connect()
    socket_mock.assert_called_with(family, type_)
    assert isinstance(connection.sock, Mock)

# Generated at 2022-06-23 03:03:39.513399
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    err = SSLValidationError('foo')
    assert err.args[0] == 'foo'



# Generated at 2022-06-23 03:03:46.820477
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        raise NotImplementedError("Unit test for constructor of class MissingModuleError")
    except ImportError as e:
        m = MissingModuleError("Oops, missing import", sys.exc_info()[2])
        assert isinstance(m, MissingModuleError)
        assert isinstance(m, ImportError)
        assert str(m) == "Oops, missing import"
        assert str(e.traceback) in str(m.import_traceback)


# Generated at 2022-06-23 03:03:56.010792
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    def test(url, validate_certs, ca_path, expected_result):
        result = maybe_add_ssl_handler(url, validate_certs, ca_path)
        assert result == expected_result

    test('https://example.com/', True, None, SSLValidationHandler)
    test('https://example.com/', False, None, None)
    test('http://example.com/', True, None, None)
    test('http://example.com/', False, None, None)
    test('https://example.com/', True, 'ca_file.pem', SSLValidationHandler)
    test('https://example.com/', False, 'ca_file.pem', None)
    test('http://example.com/', True, 'ca_file.pem', None)

# Generated at 2022-06-23 03:04:07.360613
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """get_channel_binding_cert_hash unit test
    This unit test verifies that the function produces the expected output on our test SHA1 cert and SHA256 cert
    """
    # SHA1 cert
    with open(UNIT_TEST_CERTFILE, 'rb') as f:
        certificate_der = f.read()
    cert_hash_sha1 = get_channel_binding_cert_hash(certificate_der)
    assert cert_hash_sha1.hex() == "0c5709d22b965a0e9f0d58d5a2bae1393f3c1d8e67e5a1b11aae2c2ff74eae8c"

    # SHA256 cert
    with open(UNIT_TEST_CERT_SHA256, 'rb') as f:
        certificate

# Generated at 2022-06-23 03:04:14.154651
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname = ''
    port = 443
    ca_path = ''
    obj = SSLValidationHandler( hostname, port, ca_path)
    # request  is type: <class 'urllib.request.Request'>
    request = urllib_request.Request("https://" + hostname)
    # req is type: <class 'urllib.request.Request'>
    req = obj.http_request( request)
    # req is type: <class 'urllib.request.Request'>
    req =obj.https_request( request)


# Generated at 2022-06-23 03:04:21.062521
# Unit test for method post of class Request
def test_Request_post():

    # Good
    file = open('test','r')
    request = Request(url='',data=file, headers={},http_agent='',last_mod_time='',force=True,timeout=345,
                  validate_certs=True,url_username='',url_password='',force_basic_auth=False,follow_redirects='',
                  client_cert='',client_key='',cookies='',use_gssapi=True,unix_socket='',ca_path='')
    request.post(url='')

    # Bad
    with raises(ValueError):
        request.post(url='',data=5)

# Generated at 2022-06-23 03:04:26.566320
# Unit test for function prepare_multipart
def test_prepare_multipart():
    from .urls import urlparse
    url = urlparse("http://localhost/test/post-targets/multipart")
    data = {"data":{"mime_type":"text/plain","filename":"test-data.txt","content":"test data"}}
    headers, body = prepare_multipart(data)
    res = open_url(url.url, data=body, headers=headers)
    assert res.read() == data["data"]["content"]



# Generated at 2022-06-23 03:04:39.448220
# Unit test for function fetch_file
def test_fetch_file():
    '''Test fetch_file'''

    # Test with an offline site
    module = AnsibleModule(
        argument_spec=dict(url=dict(type='str'),
                           dest=dict(type='path')),
    )
    url = module.params['url']
    dest = module.params['dest']


# Generated at 2022-06-23 03:04:43.053883
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    '''
    Test the atexit_remove_file function
    '''
    filename = os.path.join(os.path.dirname(__file__), "test_atexit_remove_file.txt")
    f = open(filename, "w+")
    f.close()
    # Make sure it is really there
    assert os.path.exists(filename)
    atexit_remove_file(filename)
    # Make sure it is deleted
    assert not os.path.exists(filename)



# Generated at 2022-06-23 03:04:53.787825
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    _connect = httplib.HTTPConnection.connect
    assert httplib.HTTPConnection.connect is not UnixHTTPConnection.connect
    with unix_socket_patch_httpconnection_connect():
        assert httplib.HTTPConnection.connect is UnixHTTPConnection.connect
    assert httplib.HTTPConnection.connect is not UnixHTTPConnection.connect
    assert httplib.HTTPConnection.connect is _connect

    # in case of an exception
    try:
        with unix_socket_patch_httpconnection_connect():
            raise Exception
    except:
        pass
    assert httplib.HTTPConnection.connect is _connect

    # do some actual monkey patching
    from httplib import HTTPConnection, HTTPS_PORT
    class TestHTTPConnection(HTTPConnection):
        def __init__(self, *args, **kwargs):
            self.args

# Generated at 2022-06-23 03:05:02.419566
# Unit test for constructor of class Request
def test_Request():
    if not (sys.version_info[0] == 2 and sys.version_info[1] in (4, 5)):
        r = Request("http://127.0.0.1/x", "data")
        assert r.get_method() == "POST"

        r = Request("http://127.0.0.1/x", "data", method="PUT")
        assert r.get_method() == "PUT"

        r = Request("http://127.0.0.1/x", None, method="PUT")
        assert r.get_method() == "PUT"
        assert r.data is None


# Generated at 2022-06-23 03:05:12.797475
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import ssl
    import socket
    import types
    import six
    class sock(object):
        def create_connection(self, args, kwargs):
            pass
    class ss(object):
        def wrap_socket(*args, **kwargs):
            pass
    class c(object):
        def __init__(self, *args, **kwargs):
            pass
        def wrap_socket(self, args, kwargs):
            pass

    if not isinstance(socket.socket.create_connection, types.BuiltinMethodType):
        socket.socket.create_connection = types.BuiltinMethodType(sock.create_connection, socket.socket)

    if hasattr(ssl, 'wrap_socket'):
        if not isinstance(ssl.wrap_socket, types.BuiltinFunctionType):
            ssl.wrap_

# Generated at 2022-06-23 03:05:17.674656
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        raise ImportError("TEST")
    except ImportError:
        tb = traceback.format_exc()
        exc = MissingModuleError("test", tb)
        assert exc.args == ("test",)
        assert exc.import_traceback == tb



# Generated at 2022-06-23 03:05:25.135969
# Unit test for function fetch_url
def test_fetch_url():
    """
    Test case for fetch_url function with various inputs
    """

    class FakeModule(object):
        def __init__(self):
            self.params = dict(
                url='http://www.example.com',
                force=True,
                use_proxy=True,
                validate_certs=False
            )

        def fail_json(**kwargs):
            pass

    class FakeResponse(object):
        def __init__(self):
            self.headers = dict(content_length=100, header1='value1')
            self.geturl = "www.example.com"
            self.code = 200

        def read(self):
            return "foo"

        def info(self):
            return self.headers

    class FakeCJ(object):
        def __init__(self):
            pass



# Generated at 2022-06-23 03:05:29.812142
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        import ssl
    except ImportError:
        ssl = None
    if ssl is None:
        return
    url = 'https://localhost/'
    context = ssl.create_default_context()
    handler = CustomHTTPSHandler(context=context)
    def get_connection_kwargs(self, url):
        connection_kwargs = super(CustomHTTPSHandler, self).get_connection_kwargs(url)
        return connection_kwargs
    get_connection_kwargs._context = context
    handler.get_connection_kwargs = get_connection_kwargs
    request = urllib_request.Request(url)

# Generated at 2022-06-23 03:05:34.577389
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    '''Test that UnixHTTPConnection.connect() raises OSError with invalid socket path'''
    if not os.path.exists('/tmp/invalid_socket_file'):
        with open('/tmp/invalid_socket_file', 'w'):
            pass
    with pytest.raises(OSError):
        UnixHTTPConnection('/tmp/invalid_socket_file').connect()

