

# Generated at 2022-06-23 02:55:41.241413
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    u = UnixHTTPConnection('/tmp/test')
    assert u.sock is None
    assert u._unix_socket == '/tmp/test'
    u.connect()
    assert u.sock is not None


# Generated at 2022-06-23 02:55:51.060650
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    handler = RedirectHandlerFactory('all')
    assert isinstance(handler(), urllib_request.HTTPRedirectHandler)
    handler = RedirectHandlerFactory('urllib2')
    assert isinstance(handler(), urllib_request.HTTPRedirectHandler)
    handler = RedirectHandlerFactory('no')
    assert isinstance(handler(), RedirectHandlerFactory('no').RedirectHandler)
    handler = RedirectHandlerFactory('safe')
    assert isinstance(handler(), RedirectHandlerFactory('safe').RedirectHandler)
    handler = RedirectHandlerFactory('yes')
    assert isinstance(handler(), RedirectHandlerFactory('yes').RedirectHandler)
    handler = RedirectHandlerFactory('None')
    assert isinstance(handler(), RedirectHandlerFactory('None').RedirectHandler)
    handler = RedirectHandlerFactory(False)
   

# Generated at 2022-06-23 02:55:55.691027
# Unit test for method head of class Request
def test_Request_head():
    req = Request('GET', 'http://example.com')
    assert req.get_method() == 'GET'

    req = Request('POST', 'http://example.com')
    assert req.get_method() == 'POST'


# Generated at 2022-06-23 02:56:00.420073
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    singleton__UnixHTTPConnection = UnixHTTPConnection('file')
    assert type(singleton__UnixHTTPConnection) == UnixHTTPConnection

# This class is used by the Azure SDK for Python (azure) and their unit tests
# have a direct reference to this class so we can't alias it to ConnectionError

# Generated at 2022-06-23 02:56:07.031551
# Unit test for function prepare_multipart
def test_prepare_multipart():
    content_type, body = prepare_multipart(fields={
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain'
        },
        'text_form_field': 'value'
    })

    assert content_type == 'multipart/form-data; boundary="===============2357069545151394891=="'


# Generated at 2022-06-23 02:56:19.466218
# Unit test for function open_url
def test_open_url():
    import sys
    import datetime
    if sys.version_info[0] == 3:  # Python3
        import urllib.parse as urlparse
    else:  # Python2
        import urlparse

    # Connection to the https web-site
    response = open_url("https://www.google.com/")
    assert response.code == 200
    assert response.headers['content-type'].startswith("text/html")
    assert response.geturl() == "https://www.google.com/"
    response.close()

    # Connection to the http web-site
    response = open_url("http://www.google.com/")
    assert response.code == 200
    assert response.headers['content-type'].startswith("text/html")

# Generated at 2022-06-23 02:56:29.330293
# Unit test for function build_ssl_validation_error

# Generated at 2022-06-23 02:56:34.047939
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert hasattr(CustomHTTPSConnection, '__init__')


    if sys.version_info < (2, 7):
        # The major issue was that the CustomHTTPSConnection accepts a 'context'
        # argument in Python 2.6, but it doesn't in 2.7 so py26 needs to test
        # for 'context' and py27 needs to test for '_context'.

        # verify there is no context and that Certs are not loaded
        c = CustomHTTPSConnection(host='localhost')
        assert not hasattr(c, 'context')
        assert not hasattr(c, '_context')
        assert not c.cert_file
        assert not c.key_file

        # verify there is no context and that Certs are loaded

# Generated at 2022-06-23 02:56:41.884339
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    ssl_handler = SSLValidationHandler('localhost', 443)
    assert ssl_handler.hostname == 'localhost'
    assert ssl_handler.port == 443
    tmp_path = ssl_handler.get_ca_certs()[0]
    assert tmp_path
    assert os.path.exists(tmp_path)
    os.unlink(tmp_path)



# Generated at 2022-06-23 02:56:49.155600
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    # Without HAS_SSLCONTEXT, there is only runtime testing available to us
    # and this is done in test_certificate_validation
    if HAS_SSLCONTEXT:
        from OpenSSL.crypto import load_certificate, FILETYPE_PEM
        from tempfile import mkdtemp
        from shutil import rmtree
        from random import randint
        import socket
        import tempfile

        port = randint(10000, 50000)
        cert_tempdir = mkdtemp()
        cert_path = tempfile.NamedTemporaryFile(suffix='.pem', dir=cert_tempdir).name
        key_path = tempfile.NamedTemporaryFile(suffix='.pem', dir=cert_tempdir).name
        # For some reason Travis doesn't work with an empty cert and key.
        #

# Generated at 2022-06-23 02:57:02.907203
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    # Test case: HTTPSClientAuthHandler should call do_open with _build_https_connection
    # and req
    # Test precondition: do_open of HTTPSClientAuthHandler is patched to raise an
    # exception
    h = HTTPSClientAuthHandler(client_cert='foo', client_key='bar')
    patch = mock.patch.object(h, 'do_open', side_effect=Exception)
    @patch
    def test(mock_do_open):
        with self.assertRaises(Exception):
            h.https_open('req')
        self.assertEqual(mock_do_open.call_count, 1)
        self.assertEqual(mock_do_open.call_args[0][0], h._build_https_connection)

# Generated at 2022-06-23 02:57:12.606144
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    class dummy(UnixHTTPSConnection):
        def __init__(self, *args, **kwargs):
            UnixHTTPSConnection.__init__(self, *args, **kwargs)
            self.sock = None

    x = dummy(unix_socket="/dev/null")
    x.host = random.choice(['example.com', 'sub.example.com'])
    try:
        x.connect()
    except: # pylint: disable=bare-except
        pass
    assert x.sock is not None

#
# Helper functions
#

# Get a ciphersuite in OpenSSL's formatting
#
# If the requested cipher suite is not available on this system, OpenSSL falls
# back to the next best cipher suite it can pick. This function tries to find
# the final picked cipher suite.
#


# Generated at 2022-06-23 02:57:13.201265
# Unit test for function fetch_file
def test_fetch_file():
    return



# Generated at 2022-06-23 02:57:23.208942
# Unit test for function open_url
def test_open_url():
    url = "http://example.com"
    resp = open_url(url)
    return resp


# Generated at 2022-06-23 02:57:25.156127
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    '''
    A unit test for constructor of class SSLValidationHandler.
    '''
    pass



# Generated at 2022-06-23 02:57:38.277544
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    # pylint: disable=too-many-nested-blocks,too-many-instance-attributes,too-many-arguments
    # pylint: disable=no-member,unused-argument
    # pylint: disable=attribute-defined-outside-init

    class MockReq(object):
        def __init__(self):
            pass

    class MockResponse(object):
        def __init__(self):
            self.code = 200
            self.msg = 'MockResponse'
            self.headers = {}
            self.url = 'MockUrl'


# Generated at 2022-06-23 02:57:40.048251
# Unit test for method patch of class Request
def test_Request_patch():

    url = 'http://127.0.0.1:8080/'
    data = 'asdf'

    request = Request()
    request.patch(url, data)


# Generated at 2022-06-23 02:57:46.983033
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    connection = CustomHTTPSConnection(host='www.google.com', strict=True)
    # Check if function connect is called
    with patch.object(connection, 'connect', autospec=True) as connect_mock:
        connection.connect()
        connect_mock.assert_called_once_with()
    # Check if create_connection is called
    create_connection_mock = MagicMock(return_value=False)
    with patch.multiple(socket, create_connection=create_connection_mock):
        connection.connect()
        create_connection_mock.assert_called_once()

    # Check if socket.socket is called
    socket_mock = MagicMock(return_value=False)
    with patch.object(socket, 'socket', autospec=True) as socket_mock:
        connection.connect()

# Generated at 2022-06-23 02:57:52.026774
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    # Constructor
    res = SSLValidationHandler('www.google.com', 443)
    assert res.hostname == 'www.google.com'
    assert res.port == 443
    assert res.ca_path is None


# Generated at 2022-06-23 02:57:55.208259
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler("/path/to/socket.sock")
# unit test for constructor of class UnixHTTPConnection

#
# Response Class
#



# Generated at 2022-06-23 02:57:59.930720
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    fd, fname = tempfile.mkstemp()
    atexit_remove_file(fname)
    # No exception raised
    os.close(fd)



# Generated at 2022-06-23 02:58:02.195533
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    import tempfile
    import os
    sock_fd, sock_path = tempfile.mkstemp()
    os.close(sock_fd)
    conn = UnixHTTPConnection(sock_path)
    conn.connect()
    assert conn.sock
    conn.close()
    os.unlink(sock_path)

#
# Helper functions
#


# Generated at 2022-06-23 02:58:09.036463
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    class TestHTTPSClientAuthHandler(HTTPSClientAuthHandler):
        def __init__(self, *args, **kwargs):
            super(TestHTTPSClientAuthHandler, self).__init__(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs
            # Mocking _build_https_connection in unit-test only
            def mock_build_https_connection(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs
                return None
            self._build_https_connection = mock_build_https_connection

    # Empty client cert and key
    client_cert = ''
    client_key = ''

    # Empty request
    req = ''

    # Verify if client cert and key are passed to _build_https_connection
    https_

# Generated at 2022-06-23 02:58:16.000384
# Unit test for method options of class Request
def test_Request_options():
    request = Request()
    url = 'http://www.example.com'
    
    # Options not supported in the C code path
    if not hasattr(request, 'parsed_url'):
        return 1
    
    request.open('OPTIONS', url)
    assert request.get_method() == 'OPTIONS'
    
    request.set_method('POST')
    
    def assert_raises_typeerror(method, *args, **kwargs):
        with pytest.raises(TypeError):
            request.set_method(method)
    
    yield assert_raises_typeerror

# Generated at 2022-06-23 02:58:25.183340
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # create a Handler instance that does not check the server certificate
    h = SSLValidationHandler('example.com', 443, '/nonexisting-ca.pem')
    r = h.http_request(urllib_request.Request('https://example.com'))

    # create a Handler instance that checks the server certificate
    h = SSLValidationHandler('example.com', 443, '/nonexisting-ca.pem')
    r = h.http_request(urllib_request.Request('https://example.com'))



# Generated at 2022-06-23 02:58:34.257755
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler('localhost', '443')
    assert handler.validate_proxy_response(b'HTTP/1.0 200 Connection established') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 200 Connection ok') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 201 Connection ok') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 203 Connection ok') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 206 Connection ok') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 300 Connection ok') == None
    assert handler.validate_proxy_response(b'HTTP/1.0 400 Connection ok') == None
    assert handler.validate_proxy_response

# Generated at 2022-06-23 02:58:39.039289
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler('client_cert', 'client_key')
    assert handler.client_cert == 'client_cert'
    assert handler.client_key == 'client_key'

if hasattr(socket, 'AF_UNIX'):

    class UnixHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, unix_socket, *args, **kwargs):
            self._unix_socket = unix_socket
            httplib.HTTPSConnection.__init__(self, *args, **kwargs)

        def connect(self):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self._unix_socket)
            self.sock = ssl.wrap_socket(sock)

#
# Retry functionality


# Generated at 2022-06-23 02:58:45.563826
# Unit test for function getpeercert
def test_getpeercert():
    """ Call getpeercert() to try to get the peer cert. """
    url = 'https://docs.python.org/2/'
    # python 2.7 has a different class name than 2.6
    try:
        response = urllib_request.urlopen(url)
    except NameError:
        response = urllib2.urlopen(url)
    cert = getpeercert(response)
    if cert:
        assert True
    else:
        assert False



# Generated at 2022-06-23 02:58:47.875864
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
        test_url = 'http://test_url'
        test_method = 'get'
        expect_get_method = 'GET'
        test_request_with_method = RequestWithMethod(test_url, test_method)
        assert expect_get_method == test_request_with_method.get_method()



# Generated at 2022-06-23 02:59:00.963229
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    class args:
        url = ''
    class req:
        get_full_url = lambda x: args.url
    check = SSLValidationHandler('', '')

    if sys.version_info[0] >= 3:
        os.environ['no_proxy'] = 'abc.com,cba.com,abc.com:123,cba.com:123'
    else:
        os.environ['no_proxy'] = 'abc.com,cba.com,abc.com:123,cba.com:123'.encode('utf-8')

    args.url = 'https://abc.com'
    assert check.detect_no_proxy(req) == False

    args.url = 'https://abc.com:123'
    assert check.detect_no_proxy(req) == False


# Generated at 2022-06-23 02:59:10.192184
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    CustomHTTPSHandler()


if HAS_SSLCONTEXT:
    class HTTPSClientAuthHandler(urllib_request.HTTPSHandler):
        """
        A handler for HTTPS that does client-side certificate authentication
        """
        def __init__(self, key, cert, level=ssl.CERT_NONE, ca_certs=None):
            urllib_request.HTTPSHandler.__init__(self)

            if ca_certs is None:
                ca_certs = DEFAULT_CA_BUNDLE_PATH

            self.key = key
            self.cert = cert
            self.level = level
            self.ca_certs = ca_certs

            self._context = ssl.SSLContext(PROTOCOL)
            self._context.verify_mode = level
            self._context.load

# Generated at 2022-06-23 02:59:17.175839
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    ca_certs = 'fake_path_for_certs'
    hostname = 'localhost'
    try:
        raise SSLValidationError(hostname, ca_certs)
    except SSLValidationError as e:
        assert e.args[0] == 'Error validating %s using %s' %(hostname, ca_certs)
        assert len(e.args) == 1


# Generated at 2022-06-23 02:59:20.729944
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string((2007, 11, 30, 6, 8, 30, 4, 335, 0)) == \
        'Fri, 30 Nov 2007 06:08:30 -0000'



# Generated at 2022-06-23 02:59:32.182789
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Negative server-hostname test
    conn = CustomHTTPSConnection('server-hostname')
    conn.key_file = 'keyfile'
    conn.cert_file = 'certfile'
    conn._tunnel_host = ''
    conn.host = 'hostname'
    conn.port = 1234
    conn.timeout = 1
    conn.context = None
    conn.sock = None
    conn._tunnel = Mock()
    conn.context.wrap_socket = Mock()

    conn.connect()
    conn._tunnel.assert_called_with()
    conn.context.wrap_socket.assert_called_with(conn.sock, server_hostname='hostname')

    # Positive server-hostname test
    conn = CustomHTTPSConnection('server-hostname')

# Generated at 2022-06-23 02:59:33.625028
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    assert URLFetchHandlerFactory() == URLFetchHandlerFactory()



# Generated at 2022-06-23 02:59:36.688700
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("Connection error message")
    except ConnectionError as e:
        assert repr(e) == "ConnectionError('Connection error message',)"


# Generated at 2022-06-23 02:59:47.627825
# Unit test for method delete of class Request
def test_Request_delete():
    request_ = Request()
    # with open("./ansible_collections/notstdlib/sub1/plugins/doc_fragments/http.rst") as f:
    #     result = request_.put(
    #             url="https://github.com/aharshac/testrepo/blob/master/ansible_collections/notstdlib/sub1/plugins/doc_fragments/http.rst",
    #             data=f,
    #             client_cert="client.crt",
    #             client_key="client.key",
    #             unix_socket="/var/run/docker.sock",
    #             validate_certs=True,
    #             timeout=120
    #         )
    #     print(result.read())

# Generated at 2022-06-23 02:59:57.390781
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    server = SocketServer.TCPServer(('localhost', 0), DummyHTTPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.setDaemon(True)
    server_thread.start()
    host, port = server.socket.getsockname()
    proxy = urllib_request.ProxyHandler({
        'https': 'https://%s:%d' % (host, port),
    })
    opener = urllib_request.build_opener(proxy)

    # Make an HTTPS request to the proxy
    with opener.open('https://example.com/'):
        pass

    # Make sure the HTTPS request above didn't try to make an HTTPS
    # connection to the proxy.

# Generated at 2022-06-23 03:00:07.342322
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    # Build HTTPS request
    url = "https://example.com"
    req = urllib_request.Request(url)
    req.method="GET"

    # Build context
    kwargs = {}
    kwargs['context'] = ssl._create_stdlib_context()

    # Build CustomHTTPSHandler
    if HAS_SSLCONTEXT:
        custom_handler = CustomHTTPSHandler(**kwargs)
    else:
        custom_handler = CustomHTTPSHandler()

    assert custom_handler.https_open(req)


# Generated at 2022-06-23 03:00:09.357432
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # ProxyError is a subclass of ConnectionError
    try:
        raise ProxyError()
    except ConnectionError:
        pass



# Generated at 2022-06-23 03:00:22.022171
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    import time
    result = rfc2822_date_string(time.gmtime())
    assert result.endswith('-0000')

HTTP_GET_HEADERS = {'Accept': 'application/json'}

HAS_URLLIB3_CONNECTIONPOOL = False
if HAS_URLLIB3:
    try:
        from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool, connection_from_url
        HAS_URLLIB3_CONNECTIONPOOL = True
    except ImportError:
        pass

HAS_URLLIB3_RESPONSE = False
if HAS_URLLIB3:
    try:
        from urllib3.response import HTTPResponse
        HAS_URLLIB3_RESPONSE = True
    except ImportError:
        pass

# Generated at 2022-06-23 03:00:31.858305
# Unit test for method patch of class Request
def test_Request_patch():
    http = HTTPConnection('httpbin.org')

    # Test with data as bytes
    resp = http.patch('/patch', data=b'foo')
    assert resp.status_code == 200
    assert resp.json()['data'] == 'foo'

    # Test with data as a file-like object
    with NamedTemporaryFile() as f:
        f.write(b'bar')
        f.seek(0)
        resp = http.patch('/patch', data=f)
        assert resp.status_code == 200
        assert resp.json()['data'] == 'bar'

    # Test with data as a unicode string
    resp = http.patch('/patch', data=u'baz')
    assert resp.status_code == 200
    assert resp.json()['data'] == 'baz'

    # Test with

# Generated at 2022-06-23 03:00:42.659331
# Unit test for method http_request of class SSLValidationHandler

# Generated at 2022-06-23 03:00:50.909736
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    prdd = ParseResultDottedDict({'scheme': 'http', 'netloc': 'localhost:8000', 'path': '/', 'params': '', 'query': '', 'fragment': ''})
    assert prdd.as_list() == ['http', 'localhost:8000', '/', '', '', '']
    prdd = ParseResultDottedDict()
    assert prdd.as_list() == [None, None, None, None, None, None]
    prdd = ParseResultDottedDict(scheme='http', params='a=1')
    assert prdd.as_list() == ['http', None, None, 'a=1', None, None]
    prdd = ParseResultDottedDict(foo='bar', baz='quux')

# Generated at 2022-06-23 03:01:04.290341
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # body
    (content_type, body) = prepare_multipart({
        'file1': {'filename': '/bin/true', 'mime_type': 'application/octet-stream'},
        'file2': {'content': 'text based file content', 'mime_type': 'text/plain', 'filename': 'fake.txt'},
        'text_form_field': 'value'
    })
    assert content_type == 'multipart/form-data; boundary="===============2028008690=="'

# Generated at 2022-06-23 03:01:14.250185
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(
        client_cert='cert.pem',
        client_key='key.pem',
        unix_socket='/home/user/cert.sock'
    )
    assert handler.client_cert == 'cert.pem'
    assert handler.client_key == 'key.pem'
    assert handler._unix_socket == '/home/user/cert.sock'


if hasattr(unix_socket, 'UnixConnection'):
    class UnixHTTPSConnection(httplib.HTTPSConnection, unix_socket.UnixConnection):
        def __init__(self, path, *args, **kwargs):
            httplib.HTTPSConnection.__init__(self, *args, **kwargs)
            unix_socket.UnixConnection.__init__(self, path)

# Generated at 2022-06-23 03:01:19.273601
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    '''
    Returns an object of type SSLValidationHandler
    '''
    url = 'https://google.com'
    assert isinstance(maybe_add_ssl_handler(url, validate_certs=True), SSLValidationHandler)


# Generated at 2022-06-23 03:01:32.468342
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest

    class TestRedirectHandlerFactory(unittest.TestCase):
        def test_redirect_handler_follow_redirects_urllib2(self):
            """ Follow redirects using urllib2 rules."""
            class MockRequest(object):
                def __init__(self, method=None, headers=None, data=None, origin_req_host=None):
                    self.method = method
                    self.headers = headers
                    self.data = data
                    self.origin_req_host = origin_req_host

                def get_full_url(self):
                    return 'https://example.com'

                def get_method(self):
                    return self.method

                def get_data(self):
                    return self.data

                def get_origin_req_host(self):
                    return self

# Generated at 2022-06-23 03:01:35.935702
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    # If you've gotten to this point and the next assert statement
    # fails, then that's a good sign that this __init__ call will
    # be able to succeed when outside of unit tests.
    assert UnixHTTPSConnection('/foo/bar/baz') is not None


#
# Connection support
#


# Generated at 2022-06-23 03:01:47.520995
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
     from unittest import TestCase
     import threading
     import select
     import socket
     class MockHTTPSConnection(object):
          def __init__(self, *args, **kwargs):
               self.sock = socket.socket()

          def connect(self):
               self.sock.listen(1)

          def set_context(self, context):
               self._context = context

          def get_context(self):
               return self._context

          def get_socket(self):
               return self._context.wrap_socket(self.sock)

          def send(self, data, lower_case=False):
               sock = self.get_socket()
               sock.listen(1)
               conn, addr = sock.accept()

# Generated at 2022-06-23 03:01:48.812169
# Unit test for method get of class Request
def test_Request_get():
    assert True == False


# Generated at 2022-06-23 03:01:55.301817
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    # Test with cafile
    handler = SSLValidationHandler('localhost', 443, ca_path='/etc/ssl/certs')
    context = handler.make_context(None, None)
    # Test with cadata
    handler = SSLValidationHandler('localhost', 443, ca_path=None)
    context = handler.make_context(None, b_DUMMY_CA_CERT)
    # Test no context
    handler = SSLValidationHandler('localhost', 443, ca_path=None)
    context = handler.make_context(None, None)

# Generated at 2022-06-23 03:02:00.991825
# Unit test for function open_url
def test_open_url():
    '''Unit test for module_util.py: open_url'''
    url = 'http://www.httputility.net/api/get/method/get'
    resp = open_url(url)
    assert resp.msg == 'OK'

# Generated at 2022-06-23 03:02:11.433861
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    host = '127.0.0.1'
    port = 1
    context = None
    timeout = 10
    req_class = None
    source_address = None
    cert_file = '/tmp/cert_file'
    key_file = '/tmp/key_file'
    key_password = None

# Generated at 2022-06-23 03:02:23.259126
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_socket = os.environ.get('UNIX_SOCKET', None)
    if not unix_socket:
        raise Exception('UNIX_SOCKET environment variable is not defined')
    # httplib.HTTPSConnection.__init__ doesn't have the same signature in Py2 vs Py3
    # pylint: disable=unexpected-keyword-arg,no-value-for-parameter
    connection = UnixHTTPSConnection(unix_socket)(host='cert', key_file='key_file', cert_file='cert_file', context='context')
    assert connection._unix_socket == unix_socket
    assert connection.host == 'cert'
    assert connection.key_file == 'key_file'
    assert connection.cert_file == 'cert_file'
    assert connection.context == 'context'

# Generated at 2022-06-23 03:02:28.003969
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string((2007, 8, 26, 0, 0, 0)) == 'Sun, 26 Aug 2007 00:00:00 -0000'
    assert rfc2822_date_string((2007, 8, 26, 0, 0, 0), zone='+0200') == 'Sun, 26 Aug 2007 00:00:00 +0200'



# Generated at 2022-06-23 03:02:37.913366
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    uxhc = UnixHTTPConnection('/var/run/docker.sock')
    assert uxhc.host == None
    assert uxhc.port == None

    uxhc = UnixHTTPConnection('/var/run/docker.sock')(host='foo', port='bar')
    assert uxhc.host == 'foo'
    assert uxhc.port == 'bar'

#
# HTTP Response codes not defined in the standard library
#

HTTP_TEMP_REDIRECT = 307  # RFC 7231
HTTP_PERM_REDIRECT = 308  # RFC 7538



# Generated at 2022-06-23 03:02:49.563088
# Unit test for constructor of class Request
def test_Request():
    url = 'https://www.google.com'
    method = 'GET'
    data = None
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.79 Safari/537.36'
    }

    request = Request(url, method, data, headers)
    assert request.url == url and request.method == method


# Generated at 2022-06-23 03:02:57.977006
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Unit test for the constructor of class ConnectionError
    ce = ConnectionError('message', 'url', 2)
    assert ce.args[0] == 'message'
    assert ce.args[1] == 'url'
    assert ce.args[2] == 2
    assert ce.message == 'message'
    assert ce.url == 'url'
    assert ce.code == 2
    assert repr(ce) == "ConnectionError('message', u'url', 2)"



# Generated at 2022-06-23 03:03:09.789472
# Unit test for function prepare_multipart

# Generated at 2022-06-23 03:03:14.216213
# Unit test for function generic_urlparse
def test_generic_urlparse():
    class ParseResult(object):
        def __init__(self, scheme, netloc, path, params, query, fragment, username, password, hostname, port):
            self.scheme = scheme
            self.netloc = netloc
            self.path = path
            self.params = params
            self.query = query
            self.fragment = fragment
            self.username = username
            self.password = password
            self.hostname = hostname
            self.port = port

    # To avoid 2to3 altering the tests, we'll use a dictionary lookup
    # to retrieve the correct class.
    t = {
        2: ParseResult,
        3: ParseResultDottedDict,
    }[sys.version_info[0]]


# Generated at 2022-06-23 03:03:20.840032
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    #testcase 1
    test_ca_path = "/test/ca/path"
    test_object = SSLValidationHandler("test_hostname", 443, test_ca_path)
    assert test_object.detect_no_proxy("https://test_hostname/test_url") == True

    #testcase 2
    test_object2 = SSLValidationHandler("test_hostname", 443, test_ca_path)
    test_object2.detect_no_proxy("https://not_in_no_proxy/test_url") == False

# Generated at 2022-06-23 03:03:25.205935
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class MockUnixHTTPConnection(UnixHTTPConnection):
        def connect(self):
            self.sock = True
            self.host = 'unix'
    class MockUnixHTTPSConnection(MockUnixHTTPConnection, UnixHTTPSConnection):
        def connect(self):
            with unix_socket_patch_httpconnection_connect():
                super(UnixHTTPSConnection, self).connect()

    connection = MockUnixHTTPSConnection('socket')
    connection.connect()
    assert connection.sock is True, \
        'When calling super(UnixHTTPSConnection, self).connect() we must have a socket'
    assert connection.host == 'unix', \
        'Monkey patching did not work, super(UnixHTTPSConnection, self).connect() did not create a unix socket'

    with pytest.raises(AttributeError):
        Mock

# Generated at 2022-06-23 03:03:30.294621
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    def get_module_version(module_str):
        if module_str == 'urllib3':
            return urllib3.__version__
        elif module_str == 'urllib3_pyopenssl':
            return urllib3_pyopenssl.__version__
        elif module_str == 'ssl':
            return ssl.__version__
        else:
            raise Exception('Unexpected module string: %s' % module_str)

    orig_ssl_wrap_socket = ssl_wrap_socket
    orig_pyopenssl_context = PyOpenSSLContext
    orig_ssl_wrap_socket = ssl_wrap_socket
    orig_wrap_socket = ssl.wrap_socket
    orig_ssl_version = PROTOCOL
    orig_urllib3_ssl_version = urllib3

# Generated at 2022-06-23 03:03:42.988463
# Unit test for function fetch_file
def test_fetch_file():
    if HAS_OPENSSL:
        import OpenSSL.SSL
    else:
        import ssl as OpenSSL
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock
    patch.object(OpenSSL.SSL.Connection, 'get_context', Mock(return_value=Mock()))
    # We patch these because they are used by fetch_url
    # When not patched fetch_url may try to connect to internet
    # which we want to avoid for unit tests
    patch.object(urllib_request.AbstractHTTPHandler, 'do_open', Mock())
    patch.object(urllib_request.BaseHandler, 'http_error_401', Mock(return_value=None))

    import ansible.module_utils.urls as url_utils

# Generated at 2022-06-23 03:03:46.808311
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    conn = UnixHTTPSConnection('/path/to/unix/socket')('localhost', 1234)
    os.path.exists(conn.sock.name)
    return conn.sock

#
# Request functions
#



# Generated at 2022-06-23 03:03:59.835244
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Ensure that the generic_urlparse function works as expected
    '''
    url = 'http://user:pass@example.com:8080/v1/path?query=True#frag'
    parts = generic_urlparse(urlparse.urlparse(url))
    assert parts['scheme'] == 'http'
    assert parts['netloc'] == 'user:pass@example.com:8080'
    assert parts['hostname'] == 'example.com'
    assert parts['path'] == '/v1/path'
    assert parts['query'] == 'query=True'
    assert parts['fragment'] == 'frag'
    assert parts['username'] == 'user'
    assert parts['password'] == 'pass'
    assert parts['port'] == 8080
    # Now test older versions of urlparse, where

# Generated at 2022-06-23 03:04:05.222132
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    error = SSLValidationError("Failed to connect to example.com")
    # Divergence: Python 2.6 str == bytes, unicode in 2.7+
    if sys.version_info > (2, 6):
        assert isinstance(error.args[0], text_type)
    assert 'Failed to connect to example.com' in error.args[0]



# Generated at 2022-06-23 03:04:13.911080
# Unit test for function prepare_multipart
def test_prepare_multipart():

    m = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }

    c_type, body = prepare_multipart(m)
    assert b'filename="true"' in body
    assert b'filename="fake.txt"' in body
    assert b'value' in body



# Generated at 2022-06-23 03:04:22.693631
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    url = 'http://google.com'
    url_object = urlparse(url)
    hostname = url_object.hostname
    port = url_object.port or 80
    try:
        req = RequestWithMethod('http://www.example.com', headers=None, method='HEAD')
        _handler = SSLValidationHandler(hostname, port)
        _handler.http_request(req)
    except Exception as e:
        print(e)

# Generated at 2022-06-23 03:04:28.552508
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    """Test that UnixHTTPSConnection.__call__() creates an instance of UnixHTTPSConnection
    """
    # Instantiation of UnixHTTPSConnection(self._unix_socket)
    unix_https_connection = UnixHTTPSConnection(unix_socket=_get_unix_socket_path())
    # Calling __call__ on unix_https_connection
    result_call = unix_https_connection(host='127.0.0.1')
    # Type checking
    expected_type = UnixHTTPSConnection
    assert isinstance(result_call, expected_type)
test_UnixHTTPSConnection___call__.unittest = True

#
# Helpers
#



# Generated at 2022-06-23 03:04:36.977557
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    '''Unit test for method as_list of class ParseResultDottedDict'''
    parse = ParseResultDottedDict()
    parse.scheme = 'test'
    parse.netloc = 'test'
    parse.path = 'test'
    parse.params = 'test'
    parse.query = 'test'
    parse.fragment = 'test'
    assert parse.as_list() == ['test', 'test', 'test', 'test', 'test', 'test']
    assert parse.as_list() == parse.values()



# Generated at 2022-06-23 03:04:38.988203
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('Failed to connect to https://docs.ansible.com')
    except ProxyError as e:
        assert 'https://docs.ansible.com' in str(e)



# Generated at 2022-06-23 03:04:40.080611
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError(to_bytes('test message'))
    assert exc.msg == to_bytes('test message')



# Generated at 2022-06-23 03:04:47.204140
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    import tempfile
    sock_file = tempfile.mktemp()
    with unix_socket_patch_httpconnection_connect():
        conn = UnixHTTPSConnection(sock_file)
        conn.connect()
    assert(isinstance(conn.sock, socket.socket))
    assert(conn.sock.fileno() > 0)
    os.remove(sock_file)



# Generated at 2022-06-23 03:04:55.059415
# Unit test for function generic_urlparse
def test_generic_urlparse():
    for test_case in [
            'foo.com',
            'foo.com:80',
            'foo.com:80/path',
            'http://foo.com:80/path',
            'http://admin:password@foo.com:80',
            'http://admin:password@foo.com:80/path',
            'http://[fe80::1]:80/path',
            'http://admin:password@[fe80::1]:80/path',
         ]:
        print(generic_urlparse(urlparse(test_case)))



# Generated at 2022-06-23 03:05:04.188793
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    import pytest
    unix_http_connection = UnixHTTPConnection('/unix/socket/file')
    unix_http_connection.connect()
    assert unix_http_connection.sock.family == socket.AF_UNIX
    assert unix_http_connection.sock.type == socket.SOCK_STREAM
    with pytest.raises(OSError) as excinfo:
        unix_http_connection = UnixHTTPConnection('/invalid/unix/socket/file')
        unix_http_connection.connect()
    assert 'Invalid Socket File' in str(excinfo.value)

#
# Utilities
#


# Generated at 2022-06-23 03:05:14.710054
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    # Test that http_open returns a response with read() returning the content
    with patch.object(UnixHTTPHandler, 'do_open', return_value='some response'):
        handler = UnixHTTPHandler(unix_socket='/some/path')
        with patch.object(handler, 'http_request', return_value='some request'):
            response = handler.http_open('some_url', 'some_data')
            assert response == 'some response'
            assert handler.do_open.mock_calls == [call(UnixHTTPConnection('/some/path'), 'some request')]
            assert handler.http_request.mock_calls == [call('some_url', 'some_data')]

#
# HTTP(S) connections
#


# Generated at 2022-06-23 03:05:23.681770
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    get = RequestWithMethod('http://www.google.com', 'GET')
    assert get.get_method() == 'GET'
    post = RequestWithMethod('http://www.google.com', 'POST')
    assert post.get_method() == 'POST'
    put = RequestWithMethod('http://www.google.com', 'PUT')
    assert put.get_method() == 'PUT'
    delete = RequestWithMethod('http://www.google.com', 'DELETE')
    assert delete.get_method() == 'DELETE'


# Generated at 2022-06-23 03:05:34.300705
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """
    Test cases for get_channel_binding_cert_hash function.
    """
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import hashes
    from cryptography.x509.oid import ExtensionOID

    with open("/etc/pki/tls/certs/ca-bundle.crt", "rb") as f:
        ca_bundle_der = f.read()

    ca_bundle_chain = x509.load_der_x509_certificate(ca_bundle_der, default_backend())
    ca_bundle_chain_extensions = ca_bundle_chain.extensions

    # checks if the cert has been signed with an algoritm that is NOT MD5 or SHA1
    # returns the "

# Generated at 2022-06-23 03:05:45.527939
# Unit test for method open of class Request
def test_Request_open():
    import urllib.error

    with pytest.raises(urllib.error.URLError) as excinfo:
        url = 'http://localhost:81/'
        handle = Request()
        handle.open(url, timeout=1)

    with pytest.raises(urllib.error.URLError) as excinfo:
        url = 'http://localhost:81/'
        handle = Request()
        handle.options(url, timeout=1)

    with pytest.raises(urllib.error.URLError) as excinfo:
        url = 'http://localhost:81/'
        handle = Request()
        handle.head(url, timeout=1)
