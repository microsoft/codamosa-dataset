

# Generated at 2022-06-23 02:55:38.653992
# Unit test for method open of class Request
def test_Request_open():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import Request
    req = Request()
    # Case 1: testing method with GET request
    res = req.get('https://httpbin.org/get')
    response_headers = res.headers
    response_content = res.read()

    # Testing httpbin.org/get with GET request
    assert response_headers['status'] == '200', 'response code should be 200'
    assert json.loads(response_content).get('url') == 'https://httpbin.org/get', \
        'response url should be https://httpbin.org/get'
    assert res.code == 200, 'response code should be 200'

    # Case 2: testing method with POST request


# Generated at 2022-06-23 02:55:50.508870
# Unit test for function fetch_file
def test_fetch_file():
    os.environ['SHOW'] = 'True'
    def result():
        url = "http://www.baidu.com"
        bufsize = 65536
        file_name, file_ext = os.path.splitext(str(url.rsplit('/', 1)[1]))
        fetch_temp_file = tempfile.NamedTemporaryFile(dir=module.tmpdir, prefix=file_name, suffix=file_ext, delete=False)
        module.add_cleanup_file(fetch_temp_file.name)

# Generated at 2022-06-23 02:56:02.192840
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    import mock
    import os
    import urllib.request

    with mock.patch('os.name', 'posix'):
        gc = RedirectHandlerFactory()

    class FakeRequest(object):
        def __init__(self):
            self.headers = dict()
            self.method = None
            self.data = None
            self.origin_req_host = None

        def get_header(self, header):
            return self.headers[header]

        def get_method(self):
            return self.method

        def get_data(self):
            return self.data

        def get_origin_req_host(self):
            return self.origin_req_host

    class FakeFilePointer(object):
        def __init__(self):
            self.num_reads = 0



# Generated at 2022-06-23 02:56:14.629400
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''Test UnixHTTPSConnection.connect creates a Unix socket'''
    unix_socket_path = tempfile.mktemp()
    class Connection(UnixHTTPSConnection):
        def __init__(self, *args, **kwargs):
            super(Connection, self).__init__(*args, **kwargs)
            self.socket = None
        def connect(self):
            self.socket = super(Connection, self).connect()
    connection = Connection(unix_socket_path)
    # This will test UnixHTTPSConnection.connect creates a Unix socket
    connection.connect()
    assert isinstance(connection.socket, socket.socket)
    assert connection.socket.family == socket.AF_UNIX
    connection.socket.close()
    os.remove(unix_socket_path)

#
# Helper methods for redirect handling

# Generated at 2022-06-23 02:56:24.874863
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    '''Unit test for method ``UnixHTTPSConnection.__call__`` '''
    hc = UnixHTTPSConnection('test')
    hc('a', 'b', 'c')
    assert hc.host == 'a'


#
# HTTP connection classes that support optional timeouts
#

if PY3:
    from http.client import HTTPConnection as _HTTPConnection
    from http.client import HTTPSConnection as _HTTPSConnection
else:
    from httplib import HTTPConnection as _HTTPConnection
    from httplib import HTTPSConnection as _HTTPSConnection


# Generated at 2022-06-23 02:56:29.476526
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    test_get_url = 'http://www.google.com/search?q=test'
    test_get_request = RequestWithMethod(test_get_url, 'GET')
    assert isinstance(test_get_request, urllib_request.Request)
    assert test_get_request.get_full_url() == test_get_url
    assert test_get_request.get_method() == 'GET'

    test_delete_url = 'https://www.google.com/search/delete?q=test'
    test_delete_request = RequestWithMethod(test_delete_url, 'DELETE')
    assert test_delete_request.get_full_url() == test_delete_url
    assert test_delete_request.get_method() == 'DELETE'


# Generated at 2022-06-23 02:56:32.527273
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''Unit test for module function build_ssl_validation_error.
    '''
    try:
        raise SSLValidationError()
    except SSLValidationError as exc:
        expected = """Failed to validate the SSL certificate for %s:%s. Make sure your managed systems have a valid CA certificate installed. You can use validate_certs=False if you do not need to confirm the servers identity but this is unsafe and not recommended. Paths checked for this platform: %s.""" % (hostname, port, ", ".join(paths))
        assert exc == expected


# Generated at 2022-06-23 02:56:42.517133
# Unit test for function getpeercert
def test_getpeercert():
    class FakeConnection(object):
        pass
    class FakeSocket(object):
        def __init__(self):
            self.cert = None
        def getpeercert(self, binary_form=False):
            return self.cert
    class FakeSocketWrapper(object):
        def __init__(self):
            self.sock = FakeSocket()
    fc = FakeConnection()
    fc.sock = FakeSocketWrapper()

# Generated at 2022-06-23 02:56:47.003682
# Unit test for function getpeercert
def test_getpeercert():
    #url = 'https://www.w3.org'
    url = 'http://www.baidu.com'
    response = urllib_request.urlopen(url)
    print(getpeercert(response))
    print(getpeercert(response, True))

# test_getpeercert()


# Generated at 2022-06-23 02:57:01.885563
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    class TaskTest(object):
        def __init__(self, test_dict):
            self.test_dict = test_dict

    def test_CustomHTTPSHandler_https_open_do_open(mock_functools_partial, mock_req):
        # Base test
        test_url = 'https://test/test'
        test_proxy = 'http://proxytest:8080'
        t = TaskTest({'url': test_url})
        handler = CustomHTTPSHandler(context=None)
        handler.set_task(t)
        handler.proxy = test_proxy
        handler.parent = mock.MagicMock()
        handler.parent.open = mock.MagicMock()
        test_sock = mock.MagicMock()

# Generated at 2022-06-23 02:57:07.694930
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod('http://localhost', 'GET', headers={'Content-Type': 'application/json'})
    assert request.get_method() == 'GET'
    request = RequestWithMethod('http://localhost', method='POST', data='foo', headers={'Content-Type': 'application/json'})
    assert request.get_method() == 'POST'



# Generated at 2022-06-23 02:57:11.382745
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    ssl = SSLValidationHandler("pypi.python.org", 443)
    ssl.get_ca_certs()


# Generated at 2022-06-23 02:57:15.990226
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    a = ParseResultDottedDict(scheme='http', netloc='localhost', path='/',
                             params='', query='', fragment='')
    assert a.scheme == 'http'
    assert len(a.as_list()) == 6


# Generated at 2022-06-23 02:57:18.293443
# Unit test for method put of class Request
def test_Request_put():
  ans = Request('https://example.com')
  ans.put('https://example.com', data=None, **kwargs)



# Generated at 2022-06-23 02:57:27.727629
# Unit test for function fetch_file
def test_fetch_file():
    ''' This is a unit test for fetch_file.
    '''
    import sys
    import shutil
    import tempfile
    import ansible.module_utils.urls as urls
    from ansible.module_utils.common.text_utils import strip_internal_keys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Create a temp dir for the test
    tmpdir = tempfile.mkdtemp()

    # Create the AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Set the tmpdir
    module.tmpdir = tmpdir

    # Open the file
    filename = 'testfile'
    test_file = tempfile.NamedTemporary

# Generated at 2022-06-23 02:57:31.276011
# Unit test for constructor of class Request
def test_Request():
    assert Request('http://127.0.0.1:80/')
    assert Request('http://127.0.0.1:80/', method="POST")


# Generated at 2022-06-23 02:57:40.300580
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    from urllib.error import URLError
    from urllib.request import HTTPBasicAuthHandler
    from urllib.request import HTTPPasswordMgrWithDefaultRealm
    from urllib.request import urlopen
    import mock

    url = 'https://some.url'
    host = "some.host"
    port = 8080
    request_path = '/some/path'
    http_response = 'OK'
    client_cert = 'client_cert'
    client_key = 'client_key'
    unix_socket = '/some/unix/path'
    https_conn = mock.MagicMock()
    https_conn.return_value.host = host
    https_conn.return_value.port = port
    https_conn.return_value.request.return_value.getcode.return_

# Generated at 2022-06-23 02:57:48.794892
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():

    import urllib.request as urllib2
    from urllib.error import HTTPError
    from ansible.module_utils.six import PY3

    #
    # Test redirection when follow_redirects=None. This should be the
    # same as if follow_redirects=True.
    #
    for follow_redirects in [None, True]:
        handler = RedirectHandlerFactory(follow_redirects)
        urllib_request._opener = urllib2.build_opener(handler)
        req = urllib2.Request('http://httpbin.org/redirect/1',
                              method='POST',
                              data='payload',
                              headers={'content-type': 'application/json'}
                              )

# Generated at 2022-06-23 02:57:57.366735
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    import unittest

    class ModuleTest(unittest.TestCase):
        def test_sslerror(self):
            self.assertRaises(NoSSLError, lambda: maybe_add_ssl_handler('https://example.com', False))
            self.assertRaises(NoSSLError, lambda: maybe_add_ssl_handler('https://example.com', True))

    u = unittest.TestLoader().loadTestsFromModule(ModuleTest())
    unittest.TextTestRunner(verbosity=2).run(u)


# Generated at 2022-06-23 02:58:08.127439
# Unit test for method open of class Request
def test_Request_open():
    import os
    import shutil
    req = Request()
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir_file = os.path.dirname(os.path.realpath(__file__))+"/test.txt"
    if os.path.exists(test_dir_file):
        os.remove(test_dir_file)
    os.mknod(test_dir_file)

# Generated at 2022-06-23 02:58:16.613859
# Unit test for method get of class Request
def test_Request_get():
    url = 'https://us-central1-deeplearning-265811.cloudfunctions.net/app/user'
    headers = {'Content-Type': 'application/json'}
    data = {"email": "test@test.test"}
    data = json.dumps(data)
    data = bytes(data, encoding='utf-8')
    method = 'POST'
    follow_redirects = 'all'
    http_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'
    use_gssapi = False
    unix_socket = None
    validate_certs = True
    url_username = None
    url_password = None
    force_basic_auth = True

# Generated at 2022-06-23 02:58:29.142615
# Unit test for function build_ssl_validation_error

# Generated at 2022-06-23 02:58:30.256413
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
   return




# Generated at 2022-06-23 02:58:41.753576
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    """
    Test for UnixHTTPConnection.__call__() method.
    """
    from httplib import HTTPConnection
    from ansible.module_utils.urls import ConnectionError
    _unix_socket = "/var/run/docker.sock"
    unix_http_connection = UnixHTTPConnection(_unix_socket)
    assert issubclass(unix_http_connection.__class__, HTTPConnection)
    unix_http_connection('example.com', timeout=60)
    http_connection = HTTPConnection('example.com', timeout=60)
    assert not hasattr(http_connection, 'sock')
    with pytest.raises(ConnectionError):
        http_connection.connect()

# Generated at 2022-06-23 02:59:04.452899
# Unit test for method delete of class Request

# Generated at 2022-06-23 02:59:08.763681
# Unit test for constructor of class ProxyError
def test_ProxyError():
    exc = ProxyError('Error message')
    assert str(exc) == 'Error message'



# Generated at 2022-06-23 02:59:20.052796
# Unit test for function fetch_url
def test_fetch_url():
    class MyModule():
        pass

    module = MyModule()
    module.params = {}
    module.params['url'] = 'https://www.google.com'
    module.params['force'] = 'force'

    response, info = fetch_url(module, 'https://www.google.com',force=True)
    print("response is ", response)
    print("info is ", info)
    print("info.get('url') is ", info.get('url'))
    print("info.get('status') is ", info.get('status'))
    print("info.get('msg') is ", info.get('msg'))
    print("info.get('headers') is ", info.get('headers'))


# Generated at 2022-06-23 02:59:31.617662
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    scheme, netloc, path, _, _, _ = urlparse("https://www.example.com/foo/bar")
    request = urllib_request.Request("https://example.com")
    # Preserve urllib2 compatibility
    follow_redirects = 'urllib2'
    try:
        RedirectHandlerFactory(follow_redirects=follow_redirects).redirect_request(
            request, None, 301, "Moved Permanently", {'Location': "https://example.com"},
            None
        )
    except urllib_error.HTTPError as e:
        assert e.code == 301

    # Handle disabled redirects
    follow_redirects = 'no'

# Generated at 2022-06-23 02:59:43.815146
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    var = build_ssl_validation_error("test","9898",["test1","test2"],"test error")
    assert isinstance(var,SSLValidationError)

# Generated at 2022-06-23 02:59:56.002603
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # This is a temporary hack as we're not testing the real thing
    import types
    from urllib.request import Request

    obj = SSLValidationHandler('google.com', 443)
    obj.detect_no_proxy = types.MethodType(lambda x, y: False, obj)
    obj.validate_proxy_response = types.MethodType(lambda x, y, z: None, obj)
    obj.get_ca_certs = types.MethodType(lambda x: (None, None, []), obj)
    obj.make_context = types.MethodType(lambda x, y, z: None, obj)

    # This is how we expect the socket to react if the test works correctly
    class MockSocket(object):
        def create_connection(self, connection, port):
            raise OSError

# Generated at 2022-06-23 03:00:05.811856
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Get the 'no_proxy' environment variable
    env_no_proxy = os.environ.get('no_proxy')
    if env_no_proxy:
        # Save the 'no_proxy' environment variable
        no_env_no_proxy = os.environ.get('no_proxy')

# Generated at 2022-06-23 03:00:15.330654
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    # If the message changes, we want the unit test to fail
    #  to alert us to update the docs
    try:
        build_ssl_validation_error('foo', '1234', ('/path1', '/path2'))
    except SSLValidationError as ssl_error:
        assert 'Failed to validate the SSL certificate for foo:1234.' in ssl_error.args[0]
        assert 'Make sure your managed systems have a valid CA certificate installed. If the website serving the url uses SNI you need python >= 2.7.9 on your managed machine (the python executable used (foo) is version: foo)' in ssl_error.args[0]
        assert 'or you can install the `urllib3`, `pyOpenSSL`, `ndg-httpsclient`, and `pyasn1` python modules' in ssl_error

# Generated at 2022-06-23 03:00:20.136371
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    fd, t_file = tempfile.mkstemp()
    os.close(fd)
    atexit_remove_file(t_file)
    assert not os.path.exists(t_file)

# Generated at 2022-06-23 03:00:30.598717
# Unit test for function url_argument_spec
def test_url_argument_spec():
    '''
    Unit test for module helper function url_argument_spec
    '''
    options = url_argument_spec()
    assert isinstance(options, dict)
    # assert there are arguments for url
    assert 'url' in options
    assert options['url']['type'] == 'str'
    # assert there are arguments for force
    assert 'force' in options
    assert options['force']['type'] == 'bool'
    assert options['force']['default'] == False
    # assert there are arguments with aliases
    assert 'thirsty' in options['force']['aliases']
    assert options['force']['deprecated_aliases'][0]['name'] == 'thirsty'
    # assert there are arguments for http_agent
    assert 'http_agent' in options

# Generated at 2022-06-23 03:00:31.946120
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    # Dummy test to satisfy flake8
    assert True


#
# Utilities
#


# Generated at 2022-06-23 03:00:36.112166
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    unix_socket = '/var/run/docker.sock'
    try:
        u_h_c = UnixHTTPConnection(unix_socket)
        u_h_c.connect()
        assert u_h_c.sock.fileno() > 0
    except:
        #The unix socket file may not exist of the user executing the test
        #doesn't have the right to access it.
        print('Cannot test UnixHTTPConnection.connect')


# Generated at 2022-06-23 03:00:44.970589
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    @contextmanager
    def unix_socket_noop(*args):
        yield

    @contextmanager
    def unix_socket_patch_httpconnection_connect_noop(*args):
        yield

    class LocalUnixHTTPSConnection(UnixHTTPSConnection):
        def __init__(self, unix_socket, *args, **kwargs):
            self.unix_socket = unix_socket
            super(LocalUnixHTTPSConnection, self).__init__(*args, **kwargs)

        def connect(self):
            return super(UnixHTTPSConnection, self).connect()

    def unix_socket_noop(*args):
        yield

    class LocalHTTPConnection(UnixHTTPConnection):
        def connect(self):
            self.sock = 'foo'

    with unix_socket_noop():
        conn = Local

# Generated at 2022-06-23 03:00:46.394765
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    UnixHTTPSConnection('/var/sock')

#
# Main
#

# Generated at 2022-06-23 03:00:56.972904
# Unit test for method options of class Request

# Generated at 2022-06-23 03:01:09.128062
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    def test_https_open(req_url, client_cert, client_key, unix_socket, expected_host, expected_port,
                        expected_client_cert, expected_client_key):
        # create a HTTPSClientAuthHandler object to test https_open method
        https_client_auth_handler = HTTPSClientAuthHandler(client_cert, client_key,
                                                           unix_socket=unix_socket)

        # replace class HTTPSClientAuthHandler._build_http_connection to
        # test https_open method
        def _build_https_connection(host, **kwargs):
            # check host and port of host
            assert (host == expected_host)
            assert (kwargs['port'] == expected_port)
            assert (kwargs['cert_file'] == expected_client_cert)

# Generated at 2022-06-23 03:01:21.223102
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    url = 'https://www.google.com'
    https_handler = HTTPSClientAuthHandler(client_cert='')
    http_handler = AbstractHTTPHandler()

    res = https_handler.https_open(urllib_request.Request(url))
    assert res.getcode() == 200, res.getcode()

    res = http_handler.do_open(https_handler._build_https_connection, urllib_request.Request(url))
    assert res.getcode() == 200, res.getcode()


# Generated at 2022-06-23 03:01:25.245841
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    '''
    test function atexit_remove_file
    '''
    f = tempfile.mkstemp()[1]
    assert os.path.exists(f)
    atexit_remove_file(f)
    assert not os.path.exists(f)


# Generated at 2022-06-23 03:01:26.431336
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    exc = SSLValidationError('certificate verify failed')
    assert exc.args[0] == 'certificate verify failed'



# Generated at 2022-06-23 03:01:29.501636
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler('/tmp/foo.sock', debuglevel=1)
    assert handler._unix_socket == '/tmp/foo.sock'



# Generated at 2022-06-23 03:01:37.378869
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from ansible.module_utils.urls import url_argument_spec
    url, url_parts, proxy_url, proxy_parts, no_proxy_arg, use_proxy, headers, basic_auth, client_cert, timeout, _, _, _ = url_argument_spec()
    req = urllib_request.RequestWithMethod('https://' + url_parts.hostname, method = 'GET', headers = headers, unverifiable = True)
    handler = SSLValidationHandler(url_parts.hostname, url_parts.port or 443, ca_path = None)
    resp = handler.http_request(req)
    return True

# Generated at 2022-06-23 03:01:47.287622
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parsed = generic_urlparse(urlparse('http://www.example.com'))
    assert parsed.scheme == 'http'
    assert parsed.netloc == 'www.example.com'
    assert parsed.path == ''
    assert parsed.params == ''
    assert parsed.query == ''
    assert parsed.fragment == ''
    assert parsed.username is None
    assert parsed.password is None
    assert parsed.hostname == 'www.example.com'
    assert parsed.port is None

    parsed = generic_urlparse(urlparse('http://username:password@www.example.com'))
    assert parsed.username == 'username'
    assert parsed.password == 'password'

    parsed = generic_urlparse(urlparse('http://username:password@www.example.com/path'))

# Generated at 2022-06-23 03:02:00.230997
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    for hostname, port, ca_path in [
            ('google.com', 443, None),
            ('yahoo.com', 443, None),
            ('myserver', 443, None),
            ('myca.local', 443, '/etc/ssl/certs/a_ca_cert.pem')
    ]:
        print(('Testing SSLValidationHandler(%s, %s, %s) constructor' % (hostname, port, ca_path)))
        try:
            handler = SSLValidationHandler(hostname, port, ca_path)
        except Exception as e:
            print(("SSLValidationHandler(%s, %s, %s) failed with '%s'" % (hostname, port, ca_path, e)))

# Generated at 2022-06-23 03:02:05.299721
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    parse_result = ParseResultDottedDict(
        scheme = 'http',
        netloc = '127.0.0.1:8080',
        path = '/test',
        params = '',
        query = 'param1=value1&param2=value2',
        fragment = '')
    parse_result_as_list = parse_result.as_list()
    assert parse_result_as_list[0] == 'http'
    assert parse_result_as_list[1] == '127.0.0.1:8080'
    assert parse_result_as_list[2] == '/test'
    assert parse_result_as_list[3] == ''
    assert parse_result_as_list[4] == 'param1=value1&param2=value2'
    assert parse_result

# Generated at 2022-06-23 03:02:16.394500
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    Perform a simple unit test of RedirectHandler, since
    it is a class factory.

    Note that this is not a complete test, as it does not test
    any of the following:
        - The lookup of the ``follow_redirects`` value
        - that the default value of follow_redirects is ``yes``
        - that follow_redirects is respected, nor
        - that _follow_redirects is correctly set on the Request object
    '''
    # pylint: disable=C0103
    def _fetch_url(request, **kwargs):
        '''
        Mock routine to mimic fetch_url without all of the logic.
        '''
        return (request, None, None, None)

    # Mock the fetch_url routine
    old_fetch_url = fetch_url
    fetch

# Generated at 2022-06-23 03:02:21.676527
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    #Create a temp file to test with
    (fd, fn) = tempfile.mkstemp()
    os.close(fd)
    try:
        atexit_remove_file(fn)
        assert not os.path.exists(fn)
    finally:
        os.unlink(fn)


# Generated at 2022-06-23 03:02:32.145224
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    url = 'http://www.google.com/'
    method = 'POST'
    data = 'foo=bar'
    headers = {'Content-type': 'application/x-www-form-urlencoded', 'Accept': 'text/plain'}
    r = RequestWithMethod(url, method, data, headers)
    assert r.get_method() == 'POST'
    assert r.data == 'foo=bar'

# A dictionary of the form {(cafile, capath): trusted_cert_store}.
# The idea is to cache the OpenSSL.crypto.X509Store objects that
# have been created by the _create_trusted_cert_store() function
# to avoid reading the same CA certificates over and over again.
_trusted_cert_store_cache = {}


# Generated at 2022-06-23 03:02:38.786865
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """
    Function to test get_channel_binding_cert_hash
    """
    # Test for a valid DER certificate
    assert get_channel_binding_cert_hash(VALID_CERTIFICATE_DER_DATA) is not None

    # Test for a valid PEM certificate
    assert get_channel_binding_cert_hash(VALID_CERTIFICATE_DATA) is not None

    # Test for an invalid certificate
    assert get_channel_binding_cert_hash('A.B.C.D') is None

    # Test for a None certificate
    assert get_channel_binding_cert_hash(None) is None

    # Test for an empty certificate
    assert get_channel_binding_cert_hash('') is None


# Generated at 2022-06-23 03:02:42.827778
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    handler = SSLValidationHandler("test", 8080, "/test/test")
    assert handler != None
    handler.get_ca_certs()



# Generated at 2022-06-23 03:02:54.679942
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Test detect_no_proxy function with no arguments
    SSLValidationHandler_nominal = SSLValidationHandler('', 443)
    assert SSLValidationHandler_nominal.detect_no_proxy('https://www.github.com') == True
    assert SSLValidationHandler_nominal.detect_no_proxy('https://localhost') == True
    assert SSLValidationHandler_nominal.detect_no_proxy('https://localhost:5000') == True
    assert SSLValidationHandler_nominal.detect_no_proxy('https://gitlab.com:5000') == True

    # Test detect_no_proxy function with arguments
    SSLValidationHandler_nominal = SSLValidationHandler('', 443)

# Generated at 2022-06-23 03:02:57.625227
# Unit test for method put of class Request
def test_Request_put():
    scanner = zap.ZAPv2(apikey=apikey)
    test = scanner._request('/base/')

    access = scanner._request.put('/base/')
    assert access == 200


# Generated at 2022-06-23 03:03:01.937855
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    class MockResponse(object):
        pass

    response = MockResponse()
    response.read = lambda size: b'HTTP/1.1 200 OK\r\n\r\n'
    ssl_validation_handler = SSLValidationHandler('localhost', 443)
    assert ssl_validation_handler.validate_proxy_response(response.read(4096)) is None, \
        'The validate_proxy_response should not return anything'



# Generated at 2022-06-23 03:03:09.146185
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    handler = HTTPSClientAuthHandler(client_cert='/path/to/cert', client_key='/path/to/key')
    return handler

if sys.platform.startswith("darwin"):
    class UnixHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, unix_socket, *args, **kwargs):
            self.unix_socket = unix_socket
            super(UnixHTTPSConnection, self).__init__('localhost', *args, **kwargs)

        def connect(self):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self.unix_socket)
            if HAS_SSLCONTEXT:
                self.sock = self.context.wrap_socket(sock)

# Generated at 2022-06-23 03:03:14.123301
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():

    assert maybe_add_ssl_handler('https://127.0.0.1',True,'ca_path') != {'scheme': 'https', 'hostname': '127.0.0.1', 'path': '', 'port': 443}



# Generated at 2022-06-23 03:03:21.685818
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    '''Assert that an exception is raised when given an invalid socket file'''
    try:
        # Try connecting to a valid socket file
        UnixHTTPConnection('/var/run/docker.sock')
    except OSError:
        # This test is not a good idea
        module.fail_json(msg='Could not connect to a host listening on a UNIX socket')  # pragma: no cover

    with pytest.raises(OSError) as e:
        # Try to use a broken socket file
        UnixHTTPConnection('/tmp/broken_sock')

    assert e is not None


#
# Utility functions
#


# Generated at 2022-06-23 03:03:27.467672
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    class MockSSLContext(object):
        '''
        This class is a mock to substitute for "ssl.SSLContext" when it is not available.
        The purpose of this class is to allow unit testing of make_context.
        '''
        def __init__(self):
            self.cafile = None
            self.cadata = None

        def load_verify_locations(self, cafile=None, cadata=None):
            self.cafile = cafile
            self.cadata = cadata

    # The purpose of the MockSSLHandler object is to mimic SSLValidationHandler
    # such that testing can be done in make_context.
    class MockSSLHandler(object):
        def get_ca_certs(self):
            return '/path/to/ca/certs', b'DER data', []

    # The

# Generated at 2022-06-23 03:03:29.611985
# Unit test for method head of class Request
def test_Request_head():
    req = Request()
    req.head('http://www.baidu.com')
# test
test_Request_head()
 

# Generated at 2022-06-23 03:03:42.251727
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class UnixHTTPConnectionPatch(httplib.HTTPConnection):
        '''HTTPConnection subclass to test calling ``super()``

        ``htpplib.HTTPConnection.connect`` is patched, so ``super()`` will
        actually be calling ``UnixHTTPConnection.connect``
        '''

        def connect(self):
            super(UnixHTTPConnectionPatch, self).connect()

    class UnixHTTPAttr(UnixHTTPConnectionPatch):
        def __init__(self, *args, **kwargs):
            self.sock = 'sock'
            super(UnixHTTPAttr, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 03:03:52.213141
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        c = UnixHTTPSConnection('/run/http_test.sock')
        assert c.host == 'localhost'
        assert c.port is None
        assert c._unix_socket == '/run/http_test.sock'
        assert c.sock is None
        c.connect()
        assert isinstance(c.sock, socket.socket)

if HAS_SSL:
    class UnixHTTPSConnection(httplib.HTTPSConnection):
        '''Establishes a HTTPS connection to a unix domain socket
        '''

# Generated at 2022-06-23 03:03:59.463307
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    def dummy_func():
        raise MissingModuleError(u"This is a test", "This is a traceback")
    try:
        dummy_func()
    except MissingModuleError as e:
        assert e.args[0] == u"This is a test"
        assert e.import_traceback == "This is a traceback"
    else:
        assert False, "MissingModuleError was not raised"


# Generated at 2022-06-23 03:04:01.835481
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    unix_socket = '/tmp/socket'
    handler = UnixHTTPHandler(unix_socket)
    assert handler._unix_socket == unix_socket



# Generated at 2022-06-23 03:04:12.065268
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    url = 'https://test.com'
    method = 'post'
    data = 'test data'
    headers = {'content-type': 'test'}
    origin_req_host = 'test.com'
    unverifiable = True
    req = RequestWithMethod(url, method, data, headers, origin_req_host, unverifiable)
    assert req.get_method() == 'POST'
    assert req.get_full_url() == url
    assert req.data == data
    assert req.headers == headers
    assert req.get_origin_req_host() == origin_req_host
    assert req.is_unverifiable() == unverifiable


# Generated at 2022-06-23 03:04:18.882988
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    conn = UnixHTTPSConnection(None)
    conn('host', port=1)
    assert conn.host == 'host'
    assert conn.port == 1

#
# HTTP/HTTPS connections
#


# Generated at 2022-06-23 03:04:27.516193
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    module = importlib.util.find_spec('ssl')
    if module is not None:
        importlib.import_module('ssl')
    try:
        request = urllib_request.Request('https://pypi.python.org/')
        opener = urllib_request.build_opener(HTTPSClientAuthHandler())
    except NameError:
        print('HTTPSClientAuthHandler does not exist')
        return


if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
    try:
        # Workaround https://bugs.python.org/issue15795
        from urllib.request import AbstractHTTPHandler, HTTPConnection
    except ImportError:
        from urllib2 import AbstractHTTPHandler, HTTPConnection


# Generated at 2022-06-23 03:04:31.078409
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {"text_form_field": "value", "file1": {"filename": "/bin/true", "mime_type": "application/octet-stream"}}
    types, body = prepare_multipart(fields)
    types = str(types)
    if "multipart/form-data" not in types:
        return False
    boundary = re.search("boundary=.*", types)
    boundary = boundary.group()
    boundary = boundary.replace("boundary=", "")
    if boundary not in body:
        return False
    return True


# Generated at 2022-06-23 03:04:40.174194
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    import ssl
    import socket
    # UnixHTTPConnection tests don't apply here because we don't have the
    # monkeypatching to make httplib.HTTPConnection.connect call
    # UnixHTTPConnection.connect

    # When _tunnel_host is set, _new_conn() isn't called, so we don't
    # need to test for that.
    #
    # The test for a unix socket when _tunnel_host is not set is actually
    # two tests combined, because we need to be sure that passing a
    # ``unix_socket`` argument to ``HTTPSConnection`` actually uses it
    # instead of creating a new ``unix_socket`` at the default location.

    # Generate a temporary unix socket path

# Generated at 2022-06-23 03:04:44.067615
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    '''This is a unit test for the UnixHTTPConnection class constructor'''

    # test a valid unix socket filepath
    unix_socket = '/var/run/docker.sock'
    u = UnixHTTPConnection(unix_socket)
    assert u.sock is None, 'Unit test for UnixHTTPConnection failed.'



# Generated at 2022-06-23 03:04:48.691317
# Unit test for method get of class Request
def test_Request_get():
    request = Request(url='http://www.google.com')
    assert isinstance(request.get(url='http://www.google.com'), HTTPResponse)


# Generated at 2022-06-23 03:04:59.054788
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():

    class TestHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, host, port=None, key_file=None, cert_file=None, strict=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None,
                     context=None):
            CustomHTTPSConnection.__init__(self, host, port,
                                           key_file=key_file, cert_file=cert_file,
                                           strict=strict,
                                           timeout=timeout,
                                           source_address=source_address)

    with patch.object(TestHTTPSConnection, 'connect'):
        # default constructor
        h = TestHTTPSConnection(host='192.168.1.1')
        assert h.host == '192.168.1.1'
        assert h.port == 443

# Generated at 2022-06-23 03:05:01.048683
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile() as tmpf:
        atexit_remove_file(tmpf.name)
        assert os.path.exists(tmpf.name) == False



# Generated at 2022-06-23 03:05:03.785899
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    # pylint: disable=protected-access
    e = SSLValidationError('foo')
    assert e.message == 'foo'
    assert e.__str__() == e.message
    assert e.args == ('foo',)
    assert repr(e) == repr(e.message)
    # pylint: enable=protected-access

#
# Functions
#



# Generated at 2022-06-23 03:05:07.807243
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    http_client = UnixHTTPSConnection(unix_socket='/foo')('localhost', port=80)
    assert http_client.sock.family == socket.AF_UNIX

#
# Module methods
#



# Generated at 2022-06-23 03:05:12.544704
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''Unit test for build_ssl_validation_error'''
    paths = ['/etc/foo/bar', '/etc/foo/corge', '/etc/foo/grault']
    try:
        build_ssl_validation_error('testserver', '443', paths)
    except SSLValidationError as exc:
        assert str(exc).startswith('Failed to validate the SSL certificate for testserver:443. Make sure your managed systems have a valid CA certificate installed.')
        assert 'to perform SNI verification in python >= 2.6.' in str(exc)
        assert ', '.join(paths) in str(exc)
    else:
        raise AssertionError('Failed to raise SSLValidationError')



# Generated at 2022-06-23 03:05:19.943703
# Unit test for method get of class Request
def test_Request_get():
  obj = Request()
  method = 'GET'
  url = 'https://www.example.com/'
  headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0'}
  # Test with parameters
  resp = obj.get(url, headers=headers)
  assert isinstance(resp, HTTPResponse)
  


# Generated at 2022-06-23 03:05:32.079168
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    import urllib.parse
    req = RequestWithMethod('http://foo.com/bar', 'POST')
    parts = urllib.parse.urlparse(req.get_full_url())
    assert parts.scheme == 'http'
    assert parts.hostname == 'foo.com'
    assert parts.port is None
    assert parts.path == '/bar'
    assert parts.params == ''
    assert parts.query == ''
    assert parts.fragment == ''
    assert req.get_method() == 'POST'
    assert req.data == None
    req = RequestWithMethod('http://foo.com/bar', 'POST', 'data')
    assert req.data == b'data'
    req = RequestWithMethod('http://foo.com/bar', 'POST', b'data')