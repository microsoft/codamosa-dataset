

# Generated at 2022-06-23 02:55:36.974459
# Unit test for method patch of class Request
def test_Request_patch():
    # - Create a Request object
    # - Create a Mock() of the class urllib_request.Request
    request = Request()
    request._patch_urllib_request_Request = Mock()
    request._patch_urllib_request_Request.return_value = None
    # - Make a call of method patch of the class Request
    request.patch()
    # - Check the call
    assert request._patch_urllib_request_Request.call_count == 1

# Generated at 2022-06-23 02:55:43.092982
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # pylint: disable=unused-variable
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    addr, port = s.getsockname()  # pylint: disable=invalid-name
    try:
        c1 = CustomHTTPSConnection(addr, port)
        c1.request('GET', '/')
        r1 = c1.getresponse()
        assert r1.status == 200
    finally:
        s.close()


if hasattr(urllib_request, 'HTTPSHandler'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def __init__(self, *args, **kwargs):
            ur

# Generated at 2022-06-23 02:55:44.258986
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ex = ProxyError()
    assert isinstance(ex, ConnectionError)



# Generated at 2022-06-23 02:55:56.701248
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from unittest.mock import patch
    hostname=''
    port=0
    paths_checked=[]
    ca_path=''
    hostname='127.0.0.1'
    port=443
    paths_checked=[]
    ca_path='/cacert.org'
    handler = SSLValidationHandler(hostname,port,ca_path)

# Generated at 2022-06-23 02:56:05.513322
# Unit test for function fetch_url

# Generated at 2022-06-23 02:56:13.058831
# Unit test for method patch of class Request
def test_Request_patch():
    url = 'http://www.example.com/path/to/page/'
    method = 'GET'
    data = None
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0'}
    use_proxy = False
    force = False
    last_mod_time = None
    timeout = None
    validate_certs = True
    url_username = None
    url_password = None
    http_agent = 'ansible-httpget'
    force_basic_auth = False
    follow_redirects = 'urllib2'
    client_cert = None
    client_key = None
    cookies = None
    use_gssapi = False

# Generated at 2022-06-23 02:56:23.280659
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest

    class TestRedirectHandlerFactory(unittest.TestCase):
        def testSupportedFollowRedirects(self):
            self.assertEqual(type(RedirectHandlerFactory('all')), type)
            self.assertEqual(type(RedirectHandlerFactory('no')), type)

        def testUnsupportedFollowRedirects(self):
            self.assertRaises(ValueError, RedirectHandlerFactory, 'fail')
            self.assertRaises(ValueError, RedirectHandlerFactory, '')
            self.assertRaises(ValueError, RedirectHandlerFactory, None)

        def testRedirectHandlerFactory(self):
            self.assertEqual(type(RedirectHandlerFactory()), type)

    unittest.main()
    test_RedirectHandlerFactory()



# Generated at 2022-06-23 02:56:27.832333
# Unit test for method head of class Request
def test_Request_head():
    r = Request()
    url = 'http://example.com/'
    res = r.head(url)
    assert res.code == 200

# Generated at 2022-06-23 02:56:37.658425
# Unit test for function getpeercert
def test_getpeercert():
    try:
        # We should call this function because the test suite
        # doesn't call getpeercert externally.
        SSLValidationHandler(None, None)
    except NoSSLError:
        raise SkipTest
    else:
        # Check that getpeercert returns a byte string.
        response = urllib_request.urlopen("https://pypi.python.org/pypi/ansible")
        assert isinstance(getpeercert(response), bytes)
test_getpeercert.skipif = lambda: not HAS_SSL


# Generated at 2022-06-23 02:56:48.689368
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 02:56:52.705738
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    # Fri, 09 Nov 2001 01:08:47 -0000
    test_tuple = (2001, 11, 9, 1, 8, 47, 4)
    assert rfc2822_date_string(test_tuple) == 'Fri, 09 Nov 2001 01:08:47 -0000'



# Generated at 2022-06-23 02:56:56.390205
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime())[-5:] == '-0000'
    assert rfc2822_date_string(time.gmtime(), '+0000')[-5:] == '+0000'
    assert rfc2822_date_string(time.localtime())[-5:] == '-000%02d' % (-time.altzone / 36)

# Generated at 2022-06-23 02:57:07.378117
# Unit test for constructor of class Request

# Generated at 2022-06-23 02:57:14.692520
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    """Test SSLValidationError

    This test fails if SSLValidationError is not defined with
    SSLValidationError(message) as the signature."""

    try:
        raise SSLValidationError('Test SSLValidationError message')
    except SSLValidationError as e:
        assert e.__str__() == 'Test SSLValidationError message'



# Generated at 2022-06-23 02:57:24.068873
# Unit test for function getpeercert
def test_getpeercert():
    from base64 import b64decode

    response = Dict({'commonName': 'example.com',
                     'notAfter': int(time.time() + (365 * 24 * 60 * 60)),
                     'notBefore': int(time.time()),
                     'serialNumber': 0,
                     'subject': ((('commonName', 'example.com'),),),
                     'version': 2})


# Generated at 2022-06-23 02:57:33.461940
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    host_config = {
        'hostname': 'help.github.com',
        'port': 443,
        'user': 'testuser',
        'pass': 'testpass',
        'validate_certs': True,
        'timeout': 10,
        'cert_file': '/path/cert_file',
        'key_file': '/path/key_file',
    }
    if sys.version_info < (3,):
        host_config['url_username'] = 'testuser'
        host_config['url_password'] = 'testpass'

    conn = HTTPSClientAuthHandler(client_cert=host_config['cert_file'], client_key=host_config['key_file'])
    assert conn.client_cert == host_config['cert_file']
    assert conn.client_key == host_

# Generated at 2022-06-23 02:57:39.600074
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    if not HAS_SSLCONTEXT and not HAS_URLLIB3_PYOPENSSLCONTEXT:
        return

    mock_secure_transport = Mock(spec=socket)
    mock_secure_transport.recv = Mock(return_value='200 OK'.encode('utf-8'))

    class MockSecureSocket(object):
        def __init__(self, cert_reqs=ssl.CERT_NONE):
            self.ctx = Mock(spec=ssl.SSLContext)
            self.ctx.wrap_socket.return_value = mock_secure_transport
            self.cert_reqs = cert_reqs

    class MockUnsecureSocket(object):
        def __init__(self):
            self.socket = Mock(spec=socket)


# Generated at 2022-06-23 02:57:48.560636
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        CustomHTTPSHandler()
    except Exception as exc:
        if HAS_SSLCONTEXT:
            assert '_context' in str(exc), "%s: %s" % (type(exc), str(exc))
        elif HAS_URLLIB3_PYOPENSSLCONTEXT:
            assert '_context' in str(exc), "%s: %s" % (type(exc), str(exc))
        else:
            raise


# The following 3 classes allow for unix domain socket support in
# python 2.6 and 2.7.  It is only for use where no ssl support is
# needed and aren't used in python >= 2.7.6 (which has all these
# features builtin)

# Generated at 2022-06-23 02:57:53.875199
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    e = NoSSLError()
    try:
        raise NoSSLError()
    except NoSSLError as e:
        err = str(e)
    assert err == NoSSLError.__doc__


# Generated at 2022-06-23 02:58:04.247942
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    h = httplib.HTTPConnection('127.0.0.1')
    h.connect()
    assert isinstance(h.sock, socket.socket)

    # verify that the patch works
    with unix_socket_patch_httpconnection_connect():
        h = httplib.HTTPConnection('/var/tmp/socket')
        h.connect()
        assert isinstance(h.sock, socket.socket)


    '''So...we have to do the same thing for SSL. I can't think of any better way, but
    making a unix socket ssl connection is *not* fun :(
    '''
    @contextmanager
    def unix_socket_patch_httpconnection_connect_ssl():
        _connect = httplib.HTTPSConnection.connect
        httplib.HTTPSConnection.connect = UnixHTTPS

# Generated at 2022-06-23 02:58:12.772965
# Unit test for method options of class Request
def test_Request_options():
    a = Request('http://google.com', 'GET')
    assert isinstance(a, Request)
    assert a.method == 'GET'
    assert a.url == 'http://google.com'
    assert a.headers == {}
    a.options('POST')
    assert a.method == 'POST'
    assert a.url == 'http://google.com'
    assert a.headers == {}
    a.options('PUT')
    assert a.method == 'PUT'
    assert a.url == 'http://google.com'
    assert a.headers == {}
    a.options('PATCH')
    assert a.method == 'PATCH'
    assert a.url == 'http://google.com'
    assert a.headers == {}
    a.options('DELETE')

# Generated at 2022-06-23 02:58:18.572209
# Unit test for function open_url
def test_open_url():
    url = 'http://localhost:$PORT/status'
    resp = open_url(url)
    assert resp.code == 200
    assert resp.msg == 'OK'
    assert resp.getheader('content-type') == 'application/json'
    assert resp.getheader('content-length') == '109'
    assert resp.getheader('server') == 'Werkzeug/0.11.15 Python/2.7.12'
    first = resp.readline()
    assert first == '{\n'

    resp = open_url(url, method='POST', data='{ "key": "value" }')
    assert resp.code == 200
    assert resp.msg == 'OK'
    assert resp.getheader('content-type') == 'application/json'

# Generated at 2022-06-23 02:58:29.697898
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    h = HTTPSClientAuthHandler()

# Reimplementation of httplib.HTTPSConnection for Unix domain sockets
if not CustomHTTPSConnection:
    class UnixHTTPSConnection(httplib.HTTPConnection):
        def __init__(self, socket):
            if sys.version_info >= (2, 6, 2):
                httplib.HTTPConnection.__init__(self, None, None)
            else:
                httplib.HTTPConnection.__init__(self, None)
            self._unix_socket = socket

        def connect(self):
            if sys.version_info >= (2, 6, 2):
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.connect(self._unix_socket)

# Generated at 2022-06-23 02:58:31.780841
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    '''Unit test for method __call__ of class UnixHTTPConnection'''
    assert UnixHTTPConnection('socket_file')('localhost') is not None



# Generated at 2022-06-23 02:58:42.800044
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Disable debug logging
    logging.disable(logging.CRITICAL)

    # Making temporary cert directory
    tmp_dir = tempfile.mkdtemp()
    atexit.register(shutil.rmtree, tmp_dir)

    # Writing a temporary certificate
    tmp_cert_path = os.path.join(tmp_dir, "ansible.pem")
    try:
        tmp_cert_file = open(tmp_cert_path, "w")
        tmp_cert_file.write(b_DUMMY_CA_CERT.decode('utf-8'))
        tmp_cert_file.close()
    except Exception:
        assert False, "Failed to write temporary cert file"

    # Valid IP
    obj = SSLValidationHandler("10.0.0.1", 443)

# Generated at 2022-06-23 02:58:47.455278
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    file_name = 'test_file'
    file = open(file_name, 'w')
    file.write('')
    file.close()
    atexit_remove_file(file_name)
    assert not os.path.exists(file_name)



# Generated at 2022-06-23 02:58:48.469019
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert(None) is None

# Generated at 2022-06-23 02:58:54.214041
# Unit test for function fetch_file
def test_fetch_file():
  # Create an AnsibleModule object
  module = AnsibleModule(
    argument_spec = dict(
    ),
    supports_check_mode=False
  )
  url = 'https://example.com'
  file = fetch_file(module, url)
  assert os.path.isfile(file)
  os.remove(file)

if __name__ == '__main__':
  test_fetch_file()

# Generated at 2022-06-23 02:59:01.381914
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    class MockRequest(object):
        def __init__(self, method, headers={}, data=None, origin_req_host='foo.bar'):
            self._method = method
            self._headers = headers
            self._data = data
            self._origin_req_host = origin_req_host

        def get_method(self):
            return self._method

        def get_data(self):
            return self._data

        def get_origin_req_host(self):
            return self._origin_req_host

        def headers(self):
            return self._headers

    class MockResponse(object):
        def __init__(self, code, msg, hdrs, fp):
            self._code = code
            self._msg = msg
            self._hdrs = hdrs
            self

# Generated at 2022-06-23 02:59:08.161208
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    class X(object):
        def __call__(self, *args, **kwargs):
            return

    with patch.object(UnixHTTPConnection, '__call__', return_value=X()):
        handler = UnixHTTPHandler('test-unix-socket')
        with pytest.raises(AttributeError):
            handler.http_open('test-req')


# Generated at 2022-06-23 02:59:20.555955
# Unit test for function generic_urlparse
def test_generic_urlparse():
    r = generic_urlparse(urlparse.urlparse('http://user:pass@example.com:123/path?q=arg'))
    assert r.netloc == 'example.com:123'
    assert r.scheme == 'http'
    assert r.path == '/path'
    assert r.query == 'q=arg'
    assert r.fragment == ''
    assert r.username == 'user'
    assert r.password == 'pass'
    assert r.hostname == 'example.com'
    assert r.port == 123
    r = generic_urlparse(urlparse.urlparse('file:/path/to/something'))
    assert r.netloc == ''
    assert r.scheme == 'file'
    assert r.path == '/path/to/something'

# Generated at 2022-06-23 02:59:30.422218
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    '''Test https_open of class HTTPSClientAuthHandler'''
    # pylint: disable=unused-argument
    def _build_https_connection(host, **kwargs):
        '''Test https connection'''
        return True
    handler = HTTPSClientAuthHandler()
    handler._build_https_connection = _build_https_connection
    result = handler.https_open(True)
    assert result is True

if sys.platform.startswith('linux'):
    class UnixHTTPSConnection(httplib.HTTPConnection):
        '''Handles connecting to a unix domain socket

        This is a fairly lightweight extension on HTTPConnection, and can be used
        in place of HTTPConnection
        '''
        def __init__(self, unix_socket):
            self._unix_socket = unix_socket
            htt

# Generated at 2022-06-23 02:59:31.812521
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    e = SSLValidationError('Foo')
    assert str(e) == 'Foo', 'Unexpected exception output'



# Generated at 2022-06-23 02:59:33.444986
# Unit test for function fetch_file
def test_fetch_file():
    url = 'http://www.yahoo.com'
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        fetch_file(url=url,headers=headers)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 02:59:37.809492
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    # Negative test for UnixHTTPConnection
    try:
        UnixHTTPConnection('/does/not/exist')
        raise AssertionError('expected error')
    except OSError as e:
        assert 'Invalid Socket File' in e.args[0]


# Generated at 2022-06-23 02:59:48.542359
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    #
    # class UnixHTTPSConnection(HAS_SSLCONTEXT and ssl.SSLSocket or socket.socket)
    #

    class DummySSLSocket(object):
        def __init__(self, *args, **kwargs):
            pass

    dummy_ssl_socket = DummySSLSocket()
    dummy_unix_socket = '/abc'

    # HAS_SSLCONTEXT is True
    unix_https_connection = UnixHTTPSConnection(dummy_unix_socket)
    assert isinstance(unix_https_connection, ssl.SSLSocket)

    # HAS_SSLCONTEXT is False
    HAS_SSLCONTEXT = False
    reload(httplib)
    reload(urllib_request)

# Generated at 2022-06-23 02:59:59.418994
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Dummy class
    class DummyClass(object):
        pass

    RedirectHandlerFactory(_follow_redirects=False)
    DummyClass._follow_redirects = 'no'
    RedirectHandlerFactory(_follow_redirects='no')
    DummyClass._follow_redirects = 'yes'
    RedirectHandlerFactory(_follow_redirects='yes')
    DummyClass._follow_redirects = 'safe'
    RedirectHandlerFactory(_follow_redirects='safe')
    DummyClass._follow_redirects = 'none'
    RedirectHandlerFactory(_follow_redirects='none')
    DummyClass._follow_redirects = False
    RedirectHandlerFactory(_follow_redirects=False)
    DummyClass._follow_redirects = True
    RedirectHandlerFactory

# Generated at 2022-06-23 03:00:07.898468
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # The only test case here is that the object is created without error
    CustomHTTPSConnection('localhost', '443')
test_CustomHTTPSConnection_connect.skip_if_missing_deps = True


# Generated at 2022-06-23 03:00:16.584978
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    hostname='test_host'
    port='test_port'
    paths=['test_path1','test_path2']
    error_msg='test_error'

    try:
        build_ssl_validation_error(hostname,port,paths,error_msg)
        assert False, "Do not throw error when exception message exists"
    except SSLValidationError as e:
        msg='Failed to validate the SSL certificate for test_host:test_port. Make sure your managed systems have a valid CA certificate installed. '
        assert e.args[0].startswith(msg)
        msg='If the website serving the url uses SNI you need python >= 2.7.9 on your managed machine '
        assert e.args[0].count(msg) > 0

# Generated at 2022-06-23 03:00:25.306659
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    mock_sock_file = '/tmp/testing.sock'
    try:
        sock_file_fd = os.open(mock_sock_file, os.O_CREAT)
        os.close(sock_file_fd)
        with unix_socket_patch_httpconnection_connect():
            connection = UnixHTTPSConnection(mock_sock_file)
            connection.connect()
            assert connection.sock.fileno() > 0
    finally:
        if os.path.exists(mock_sock_file):
            os.remove(mock_sock_file)

    class TestHTTPConnection(httplib.HTTPConnection):
        def __init__(self):
            self.test_var = None


# Generated at 2022-06-23 03:00:27.179857
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert('') == None


# Generated at 2022-06-23 03:00:32.707411
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    urllib_request.HTTPHandler = UnixHTTPHandler

    if not os.path.exists(a_unix_socket):
        print("Skipping test as %s does not exist" % a_unix_socket)
        return

    url = urlparse.urlparse("http://unix%s" % a_unix_socket)
    req = urllib_request.Request("http://unix%s" % a_unix_socket)
    resp = url.http_open(req)
    assert resp.getcode() == 200


# Generated at 2022-06-23 03:00:34.735061
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError("test")
    except SSLValidationError as e:
        assert str(e) == "test"
    except Exception:
        assert False, "Did not raise SSLValidationError exception"



# Generated at 2022-06-23 03:00:38.624867
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    x = NoSSLError("msg")
    try:
        raise x
    except NoSSLError as e:
        assert str(e) == "msg"
        assert type(e.__context__) is None


# Generated at 2022-06-23 03:00:45.027316
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain"
        },
        "text_form_field": "value"
    }
    ct, body = prepare_multipart(fields)
    assert ct == "multipart/form-data; boundary="
    assert len(body) > 0

# Generated at 2022-06-23 03:00:47.933215
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    # TODO: Write tests to test SSLValidationHandler
    pass

# Generated at 2022-06-23 03:00:50.716366
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    req = RequestWithMethod('http://example.com', 'get')
    assert req.get_full_url() == 'http://example.com'
    assert req.get_method() == 'GET'
    req = RequestWithMethod('http://example.com', 'post', data='a=1')
    assert req.get_full_url() == 'http://example.com'
    assert req.get_method() == 'POST'
    assert req.data == 'a=1'



# Generated at 2022-06-23 03:01:04.175702
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-23 03:01:08.620042
# Unit test for function open_url
def test_open_url():
    url="https://download.docker.com/mac/stable/Docker.dmg"
    r=open_url(url)
    print(r.info())
    with open("Docker.dmg","wb") as f:
        f.write(r.read())

# Generated at 2022-06-23 03:01:21.188045
# Unit test for function generic_urlparse
def test_generic_urlparse():
    import pprint
    parsed_url = generic_urlparse(urlparse.urlparse('http://user:pass@host:123/path;param?query#fragment'))
    assert parsed_url.scheme == 'http'
    assert parsed_url.username == 'user'
    assert parsed_url.password == 'pass'
    assert parsed_url.hostname == 'host'
    assert parsed_url.netloc == 'user:pass@host:123'
    assert parsed_url.port == 123
    assert parsed_url.path == '/path;param'
    assert parsed_url.params == 'param'
    assert parsed_url.query == 'query'
    assert parsed_url.fragment == 'fragment'

# Generated at 2022-06-23 03:01:25.564101
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    test_file = 'test_atexit_remove_file'
    with open(test_file, "w"):
        pass
    assert os.path.exists(test_file)
    atexit_remove_file(test_file)
    assert not os.path.exists(test_file)



# Generated at 2022-06-23 03:01:26.859081
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError('No SSL support')
    except NoSSLError as e:
        assert str(e) == 'No SSL support'



# Generated at 2022-06-23 03:01:38.152163
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    def fail_to_connect(self):
        raise socket.error("")
    # test with no context
    handler = CustomHTTPSHandler()
    conn = handler.https_open(None)
    assert isinstance(conn, CustomHTTPSConnection)
    # test with context
    if HAS_SSLCONTEXT:
        context = SSLContext(PROTOCOL)
        handler = CustomHTTPSHandler(context=context)
        conn = handler.https_open(None)
        assert isinstance(conn, CustomHTTPSConnection)
        assert conn.context is context
    else:
        pass
    # test with no connection
    handler = CustomHTTPSHandler()
    handler.do_open = fail_to_connect
    try:
        handler.https_open(None)
        assert False
    except HTTPError as e:
        assert e

# Generated at 2022-06-23 03:01:46.932893
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    VERIFY_CERTS_UNSET_OR_FALSE = [
        'http://example.com',
        'https://example.com?cert=false',
        'https://example.com?cert=0',
    ]
    VERIFY_CERTS_SET_AND_TRUE = [
        'https://example.com',
        'https://example.com?cert=true',
        'https://example.com?cert=1',
    ]
    VERIFY_CERTS_SET_AND_FALSE = [
        'https://example.com?cert=false',
        'https://example.com?cert=0',
    ]

# Generated at 2022-06-23 03:01:49.468479
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    import_traceback = '''
Traceback (most recent call last):
  File "<string>", line 1, in <module>
ImportError: No module named foo
'''.strip()
    missing_module_error = MissingModuleError("Test message", import_traceback)
    assert missing_module_error.__str__() == '''
Test message

The full traceback was:

%s'''.strip() % import_traceback


# Generated at 2022-06-23 03:01:57.197129
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    foo = ParseResultDottedDict(scheme='http', netloc='localhost', path='/', params='', query='', fragment='')
    assert foo.scheme == 'http'
    assert foo.netloc == 'localhost'
    assert foo.path == '/'
    assert foo.as_list() == ['http', 'localhost', '/', '', '', '']

#
# Helpers
#



# Generated at 2022-06-23 03:02:01.028519
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    import traceback
    try:
        raise SSLValidationError("Test exception message")
    except Exception as e:
        assert isinstance(e, Exception)
        trace = traceback.format_exc()
        assert "SSLValidationError: Test exception message" in trace, trace



# Generated at 2022-06-23 03:02:07.529918
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    file_name = 'temp_file'

    def open_file_for_atexit_remove_file():
        handle = open(file_name,'w')
        atexit_remove_file(file_name)
        handle.close()

    open_file_for_atexit_remove_file()

    if os.path.exists(file_name):
        raise AssertionError("Function atexit_remove_file did not remove file.")


# Generated at 2022-06-23 03:02:13.743030
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    # Load up a sample certificate
    with open('test/unit/testdata/test_x509_certificate.crt', 'rb') as f:
        data = f.read()
    assert get_channel_binding_cert_hash(data) == b'\xc1~\xd9\xcf\xccM\x94\xb5\xed\xa0\xde\x18\x91\x9f\x14\x8d\xa6\x0b\xf2\x1a\xbb\xdb\x9c\x8d\x95\x02\x1f\x08\x8f\x95\x83\x9a\xfe'



# Generated at 2022-06-23 03:02:25.068630
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    handler = SSLValidationHandler(hostname='dummy.hostname.org', port=443)
    print('---'*10)
    # test case 1
    os.environ['no_proxy'] = 'example.com, sub.example.com'
    url = 'https://sub.example.com/index.html'
    tls_verify = handler.detect_no_proxy(url)
    if tls_verify == False:
        print('Test case 1 passed')
    else:
        print('Test case 1 failed')

    # test case 2
    os.environ['no_proxy'] = 'example.com, sub.example.com'
    url = 'https://subsub.sub.example.com/index.html'
    tls_verify = handler.detect_no_proxy(url)


# Generated at 2022-06-23 03:02:33.149187
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    import socket
    from ipalib import api
    from ipatests.test_xmlrpc.tracker.xmlrpc_tracker import MethodTracker
    unix_socket = api.env.xmlrpc_uri_no_proto.replace('https://', '', 1)
    tracker = MethodTracker()
    tracker.wrap(socket, 'socket')
    with UnixHTTPSConnection(unix_socket) as conn:
        assert conn.sock is None
        conn.getresponse()
    assert tracker.called()


#
# Utilities
#


# Generated at 2022-06-23 03:02:38.366259
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    try:
        unix_socket = '/tmp/foo.sock'
        unix_http_conn = UnixHTTPConnection(unix_socket)
        assert unix_http_conn._unix_socket == unix_socket
    except Exception as e:
        assert False, e


# Generated at 2022-06-23 03:02:51.858068
# Unit test for method open of class Request
def test_Request_open():
	request = Request()
	# No arguments provided
	try:
		request.open()
	except TypeError as e:
		print("TypeError: test_Request_open -> No arguments provided")
	# Incorrect number of arguments
	try:
		request.open(1, 2, 3, 4, 5, 5, 6)
	except TypeError as e:
		print("TypeError: test_Request_open -> Incorrect number of arguments")
	# Incorrect datatype for argument method
	try:
		request.open(1, "http://127.0.0.1")
	except TypeError as e:
		print("TypeError: test_Request_open -> Incorrect datatype for argument method")
	# Incorrect datatype for argument url

# Generated at 2022-06-23 03:02:55.548638
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request_method_test = RequestWithMethod("url", method="GET")
    assert "GET" == request_method_test.get_method()

# End of Unit test for method get_method of class RequestWithMethod



# Generated at 2022-06-23 03:02:58.027027
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    request = Request('https://example.com')
    handler = maybe_add_ssl_handler(request.get_full_url(), True)
    # this test is basically checking if we can add the handler
    assert handler is not None



# Generated at 2022-06-23 03:03:06.090895
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    class MockRequest():
        def __init__(self):
            self._method = ""
    mock_request = MockRequest()
    request_with_method = RequestWithMethod('a', 'b', origin_req_host='c', unverifiable=True)
    request_with_method.get_method()


_HTTP_ERROR_MAP = None

# Generated at 2022-06-23 03:03:09.916370
# Unit test for method options of class Request
def test_Request_options():
    """
    Test for method options of class Request
    """
    url = 'http://www.example.com'
    req = Request(url)
    result = req.options()
    assert result == None
    

# Generated at 2022-06-23 03:03:12.323835
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    exc = NoSSLError('hello')
    assert 'hello' in str(exc)
    assert 'hello' in repr(exc)


# Generated at 2022-06-23 03:03:15.625962
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    uhtcp = UnixHTTPSConnection('some_socket')
    assert uhtcp._unix_socket == 'some_socket'



# Generated at 2022-06-23 03:03:20.100768
# Unit test for method post of class Request
def test_Request_post():
    url = 'https://github.com/ansible/ansible/issues/62487'
    answer = Request().post(url)
    assert '<title>Ansible bug tracker - Issues - Ansible Community' in answer.read(), 'POST request failed'
    return


# Generated at 2022-06-23 03:03:22.653233
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Unit test for constructor of class ConnectionError
    x = ConnectionError('test')
    assert x.args[0] == 'test'



# Generated at 2022-06-23 03:03:34.911693
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    if hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
        # pylint: disable=no-name-in-module,unused-variable
        from .shared import unix_socket_path

        assert UnixHTTPSConnection, 'Unable to find class UnixHTTPSConnection.  Please check CustomHTTPSConnection.'
        unix_connection = UnixHTTPSConnection(unix_socket_path(False))
        assert unix_connection, 'Failed to create UnixHTTPSConnection object'
        assert unix_connection.host is None, 'Expected unix_connection.host to be None'
        assert unix_connection.unix_socket == unix_socket_path(False), 'Expected unix_connection.unix_socket to be %s' % unix_socket

# Generated at 2022-06-23 03:03:45.528420
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    """Test the https_open method of class CustomHTTPSHandler.

    Asserts that the HTTPS connection to the server works,
    and that it defaults to not checking the server's certificate.
    """
    import urllib.request
    h = CustomHTTPSHandler()
    c = h.https_open(
        urllib.request.Request(
            "https://%s:8443/" % socket.getfqdn(),
            data=None
        )
    )
    c.read()
    c.close()

    # Make sure that it fails if the certificate is wrong.
    h = CustomHTTPSHandler()

# Generated at 2022-06-23 03:03:53.801522
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    cls = SSLValidationHandler('www.google.com', 8443)

    # Valid response codes
    cls.validate_proxy_response(b'HTTP/1.0 200 Connection established\r\n\r\n')
    cls.validate_proxy_response(b'HTTP/1.1 200 Connection established\r\n\r\n')

    # Invalid response codes
    try:
        cls.validate_proxy_response(b'HTTP/1.1 404 Connection established\r\n\r\n')
    except ProxyError as e:
        assert e.message == 'Connection to proxy failed'

    # Response without status code

# Generated at 2022-06-23 03:03:58.527010
# Unit test for function getpeercert
def test_getpeercert():
    # Empty object for now
    response = AnsibleModule()
    assert getpeercert(response) is None
    # For HTTPS, we can get the actual certificate
    response.fp._sock.fp._sock = ssl.wrap_socket(socket.socket(socket.AF_INET))
    assert isinstance(getpeercert(response), dict)

# Generated at 2022-06-23 03:04:09.599122
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():

    # setup
    args = ("localhost", 2000)
    kwargs = {}
    kwargs['key_file'] = '/path/to/key'
    kwargs['cert_file'] = '/path/to/cert'
    old_ssl_wrap_socket = ssl.wrap_socket
    old_pyopenssl_wrap_socket = PyOpenSSLContext.wrap_socket
    class fake_socket(object):
        def __init__(self):
            self.server_hostname = None

        def __getattr__(self, name):
            raise AttributeError("%r object has no attribute %r" % (self.__class__, name))


# Generated at 2022-06-23 03:04:16.417956
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    unix_socket_path = os.path.join(os.getcwd(), 'tests/unix_socket')

    def test_UnixHTTPSConnection(unix_socket):
        class TestUnixHTTPSConnection(UnixHTTPSConnection):
            def __init__(self, unix_socket):
                UnixHTTPSConnection.__init__(self, unix_socket)
                self.sock_error_expected = False

            def connect(self):
                super(TestUnixHTTPSConnection, self).connect()
                if self.sock_error_expected:
                    with pytest.raises(AttributeError) as exc:
                        self.sock
                        assert exc.traceback.strfind('sock')

        return TestUnixHTTPSConnection(unix_socket)


# Generated at 2022-06-23 03:04:23.071865
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    hostname = 'www.google.com'
    port = 443
    ca_path = '/home/test'

    ssl_handler = SSLValidationHandler(hostname, port, ca_path)

    ca_cert, cadata, paths_checked = ssl_handler.get_ca_certs()
    assert ca_cert == ca_path
    assert cadata is None
    assert paths_checked == [ca_path]


# Generated at 2022-06-23 03:04:25.524634
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    TEST_FILENAME = '__test_atexit_remove_file'
    with open(TEST_FILENAME, 'w+') as f:
        f.write('test')
    assert os.path.exists(TEST_FILENAME)
    atexit_remove_file(TEST_FILENAME)
    assert not os.path.exists(TEST_FILENAME)



# Generated at 2022-06-23 03:04:39.296612
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test function for generic_urlparse
    '''
    from urlparse import urlparse

# Generated at 2022-06-23 03:04:50.385101
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    tests = [
        ('/foo/bar', ParseResultDottedDict(path='/foo/bar')),
        ('http://example.com/foo/bar', ParseResultDottedDict(scheme='http', netloc='example.com', path='/foo/bar')),
        ('http://example.com/foo/bar?key=val', ParseResultDottedDict(scheme='http', netloc='example.com', path='/foo/bar', query='key=val')),
    ]

    for url, pdd in tests:
        assert urllib_parse.urlparse(url) == pdd.as_list()
        assert urllib_parse.parse_qs(pdd.query) == {'key': ['val']}

# Generated at 2022-06-23 03:04:58.658968
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    socket_file = tempfile.mktemp()
    mock_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    mock_sock.connect(socket_file)
    with mock.patch('socket.socket') as mock_socket:
        mock_socket.return_value = mock_sock
        unix_http_conn = UnixHTTPConnection(socket_file)
        unix_http_conn.connect()
        unix_http_conn.close()



# Generated at 2022-06-23 03:05:02.048906
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    method = 'DELETE'
    headers = {'Content-Type': 'application/json'}
    request = RequestWithMethod('https://1.1.1.1/api/v2/', method, data='{"bob": "alice"}', headers=headers)
    assert request.get_method() == method



# Generated at 2022-06-23 03:05:07.791253
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile() as atexit_file:
        passed = False
        atexit_remove_file(atexit_file.name)
        if not os.path.exists(atexit_file.name):
            passed = True
    if not passed:
        raise AssertionError("atexit_remove_file() failed to remove the temporary file")


# Generated at 2022-06-23 03:05:14.097015
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    _url = 'unix:////var/run/docker.sock'
    _kwargs = {'debuglevel': 1, 'timeout': 10}
    _handler = UnixHTTPHandler(_url, **_kwargs)
    assert _handler.debuglevel == 1
    assert _handler.timeout == 10
    assert _handler._unix_socket == '/var/run/docker.sock'

#
# Helpers
#


# Generated at 2022-06-23 03:05:23.593226
# Unit test for function generic_urlparse
def test_generic_urlparse():
    # Unit test for function generic_urlparse
    def make_parse_result(scheme, netloc, path='', params='', query='', fragment='', username=None, password=None, hostname=None, port=None):
        return {
            'scheme': scheme,
            'netloc': netloc,
            'path': path,
            'params': params,
            'query': query,
            'fragment': fragment,
            'username': username,
            'password': password,
            'hostname': hostname,
            'port': port
        }
    def check_result(result, expected):
        # Compare expected result to actual result without re-ordering keys
        assert sorted(list(result.keys())) == sorted(list(expected.keys()))
        for k in expected.keys():
            assert result.get

# Generated at 2022-06-23 03:05:28.875353
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import os

    # Get the current working directory
    path = os.path.join(os.path.dirname(__file__))

    # Test with all valid redirect options
    for redirect_option in ['urllib2', 'no', 'none', False,
                            'all', 'yes', True,
                            'safe']:
        handler = RedirectHandlerFactory(follow_redirects=redirect_option, ca_path=path)
        assert isinstance(handler, type)

    # Test with invalid redirect option
    try:
        handler = RedirectHandlerFactory(follow_redirects='invalid', ca_path=path)
        assert False
    except urllib_error.HTTPError:
        # If the expected HTTPError was raised, we did the right thing
        assert True


# Generated at 2022-06-23 03:05:33.082759
# Unit test for function fetch_url
def test_fetch_url():
    module = ImmutableModule(argument_spec={})
    url = 'http://127.0.0.1:9001/fetch_url_module'
    r, info = fetch_url(module,
                        url,
                        headers={'Content-type': 'application/json'}, method="POST", data='{"test": "data"}')
    full_response = r.read()
    response = json.loads(full_response)
    assert response['method'] == 'POST'
    assert response['path'] == '/fetch_url_module'
    assert response['headers']['Content-type'] == 'application/json'
    assert response['body'] == '{"test": "data"}'
    assert info['status'] == 200
    assert info['cookies_string'] == ''