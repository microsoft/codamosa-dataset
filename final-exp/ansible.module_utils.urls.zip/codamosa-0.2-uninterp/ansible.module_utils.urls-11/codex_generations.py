

# Generated at 2022-06-17 03:52:59.684118
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test with ca_path
    handler = SSLValidationHandler('www.example.com', 443, ca_path='/etc/ssl/certs/ca-certificates.crt')
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path == '/etc/ssl/certs/ca-certificates.crt'
    assert cadata == bytearray()
    assert paths_checked == ['/etc/ssl/certs/ca-certificates.crt']

    # Test without ca_path
    handler = SSLValidationHandler('www.example.com', 443)
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path is not None
    assert cadata is not None

# Generated at 2022-06-17 03:53:11.678116
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if not CustomHTTPSConnection:
        raise AssertionError("CustomHTTPSConnection is not defined")
    try:
        CustomHTTPSConnection('localhost', 80)
    except TypeError:
        raise AssertionError("CustomHTTPSConnection constructor failed")

    try:
        CustomHTTPSConnection('localhost', 80, key_file='/dev/null', cert_file='/dev/null')
    except TypeError:
        raise AssertionError("CustomHTTPSConnection constructor failed")

    try:
        CustomHTTPSConnection('localhost', 80, context=ssl._create_unverified_context())
    except TypeError:
        raise AssertionError("CustomHTTPSConnection constructor failed")



# Generated at 2022-06-17 03:53:20.459896
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Test with a valid cert
    handler = SSLValidationHandler('github.com', 443)
    req = urllib_request.Request('https://github.com')
    handler.http_request(req)

    # Test with an invalid cert
    handler = SSLValidationHandler('expired.badssl.com', 443)
    req = urllib_request.Request('https://expired.badssl.com')
    try:
        handler.http_request(req)
    except SSLValidationError:
        pass
    else:
        raise AssertionError('SSLValidationError not raised')

    # Test with a valid cert and a proxy
    handler = SSLValidationHandler('github.com', 443)
    req = urllib_request.Request('https://github.com')

# Generated at 2022-06-17 03:53:24.342694
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://www.google.com'
    validate_certs = True
    ca_path = None
    assert maybe_add_ssl_handler(url, validate_certs, ca_path) is not None


# Generated at 2022-06-17 03:53:32.409474
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    import tempfile
    import atexit
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    atexit.register(atexit_remove_file, filename)
    assert os.path.exists(filename)
    atexit.unregister(atexit_remove_file)
    assert os.path.exists(filename)
    atexit_remove_file(filename)
    assert not os.path.exists(filename)



# Generated at 2022-06-17 03:53:38.156994
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # This test is only valid if we have a ssl library available
    if not HAS_SSL:
        return

    # Test that we can create a CustomHTTPSHandler
    handler = CustomHTTPSHandler()
    assert handler is not None

    # Test that we can create a CustomHTTPSHandler with a context
    if HAS_SSLCONTEXT:
        handler = CustomHTTPSHandler(context=ssl.SSLContext(PROTOCOL))
        assert handler is not None

    # Test that we can create a CustomHTTPSHandler with a context
    if HAS_URLLIB3_PYOPENSSLCONTEXT:
        handler = CustomHTTPSHandler(context=PyOpenSSLContext(PROTOCOL))
        assert handler is not None



# Generated at 2022-06-17 03:53:48.012657
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    content_type, body = prepare_multipart(fields)
    assert content_type == 'multipart/form-data; boundary="===============8381750204412588880=="'

# Generated at 2022-06-17 03:53:54.477998
# Unit test for method get_ca_certs of class SSLValidationHandler

# Generated at 2022-06-17 03:54:02.887333
# Unit test for function fetch_url
def test_fetch_url():
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.urllib.error as urlerror
    import ansible.module_utils.six.moves.urllib.request as urllib2
    import ansible.module_utils.six.moves.http_cookiejar as cookielib
    import ansible.module_utils.six.moves.http_client as httplib
    import ansible.module_utils.six.moves.socketserver as socketserver
    import ansible.module_utils.six.moves.BaseHTTPServer as BaseHTTPServer
    import ansible.module_utils.six.moves.socketserver as socketserver

# Generated at 2022-06-17 03:54:17.092591
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler('hostname', 'port', 'ca_path')
    assert handler.validate_proxy_response(b'HTTP/1.0 200 OK')
    assert handler.validate_proxy_response(b'HTTP/1.0 200 OK', [200, 201])
    assert handler.validate_proxy_response(b'HTTP/1.0 201 OK', [200, 201])
    assert handler.validate_proxy_response(b'HTTP/1.0 202 OK', [200, 201])
    assert handler.validate_proxy_response(b'HTTP/1.0 202 OK', [200, 201, 202])
    assert handler.validate_proxy_response(b'HTTP/1.0 202 OK', [200, 202])

# Generated at 2022-06-17 03:55:27.698012
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    # Test with follow_redirects=False
    redirect_handler = RedirectHandlerFactory(follow_redirects=False)
    assert redirect_handler.__name__ == 'RedirectHandler'
    assert redirect_handler.__module__ == __name__
    assert redirect_handler.__doc__ == RedirectHandler.__doc__
    # Test with follow_redirects=True
    redirect_handler = RedirectHandlerFactory(follow_redirects=True)
    assert redirect_handler.__name__ == 'RedirectHandler'
    assert redirect_handler.__module__ == __name__
    assert redirect_handler.__doc__ == RedirectHandler.__doc__
    # Test with follow_redirects='safe'
    redirect_handler = RedirectHandlerFactory(follow_redirects='safe')
    assert redirect_handler.__name__

# Generated at 2022-06-17 03:55:32.701242
# Unit test for function fetch_url
def test_fetch_url():
    import unittest
    import tempfile
    import shutil
    import os
    import sys
    import json
    import base64
    import ssl
    import socket
    import time
    import threading
    import urllib
    import urllib2
    import httplib
    import urlparse
    import Cookie
    import socket
    import errno
    import traceback
    import warnings
    import random
    import string
    import re
    import os
    import shutil
    import tempfile
    import datetime
    import time
    import sys
    import os
    import subprocess
    import types
    import stat
    import platform
    import pwd
    import grp
    import getpass
    import pty
    import select
    import termios
    import tty
    import errno
    import signal

# Generated at 2022-06-17 03:55:42.924857
# Unit test for function fetch_url
def test_fetch_url():
    # Test fetch_url with a simple URL
    module = AnsibleModule(argument_spec=url_argument_spec())
    r, info = fetch_url(module, 'http://example.com')
    assert info['status'] == 200
    assert info['msg'] == 'OK (unknown bytes)'
    assert info['url'] == 'http://example.com/'

# Generated at 2022-06-17 03:55:54.381164
# Unit test for function fetch_url
def test_fetch_url():
    import unittest
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six.moves.urllib.error as urllib_error
    import ansible.module_utils.six.moves.urllib.request as urllib_request
    import ansible.module_utils.six.moves.http_client as httplib
    import ansible.module_utils.six.moves.http_cookiejar as cookielib
    import ansible.module_utils.six.moves.socketserver as socketserver
    import ansible.module_utils.six.moves.BaseHTTPServer as BaseHTTPServer
    import ansible.module_utils.six.moves.SimpleHTTPServer as SimpleHTTPServer
    import ansible.module_utils.six.m

# Generated at 2022-06-17 03:55:58.626542
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import ssl

    class RedirectHandlerFactoryTest(unittest.TestCase):
        def test_redirect_handler_factory(self):
            # Test that the redirect handler factory returns a class
            self.assertTrue(issubclass(RedirectHandlerFactory(), urllib.request.HTTPRedirectHandler))

            # Test that the redirect handler factory returns a class that is a subclass of HTTPRedirectHandler
            self.assertTrue(issubclass(RedirectHandlerFactory(), urllib.request.HTTPRedirectHandler))

            # Test that the redirect handler factory returns a class that is a subclass of HTTPRedirectHandler

# Generated at 2022-06-17 03:56:09.374713
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    if not CustomHTTPSConnection:
        return
    conn = CustomHTTPSConnection('localhost', 80)
    assert conn.context is None
    conn = CustomHTTPSConnection('localhost', 80, cert_file='cert.pem', key_file='key.pem')
    assert conn.context is not None
    assert conn.context.cert_store_stats()['x509_ca'] == 0
    assert conn.context.cert_store_stats()['crl'] == 0
    assert conn.context.cert_store_stats()['x509'] == 0
    assert conn.context.cert_store_stats()['x509_ca'] == 0
    assert conn.context.cert_store_stats()['x509_ca'] == 0
    assert conn.context.cert_store_stats()['x509_ca'] == 0


# Generated at 2022-06-17 03:56:21.900832
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import unittest
    import tempfile
    import os
    import shutil
    import stat
    import pwd
    import grp
    import socket
    import ssl
    import time
    import subprocess
    import ansible.module_utils.six.moves.http_client as httplib
    import ansible.module_utils.six.moves.urllib.request as urllib_request
    import ansible.module_utils.six.moves.urllib.error as urllib_error
    import ansible.module_utils.six.moves.urllib.parse as urllib_parse
    import ansible.module_utils.six.moves.urllib.response as urllib_response
    import ansible.module_utils.six.moves.urllib.robotparser

# Generated at 2022-06-17 03:56:26.140932
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-17 03:56:39.234004
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # Test with no cert_file
    conn = CustomHTTPSConnection('localhost', port=443)
    conn.connect()
    assert conn.sock is not None
    conn.close()

    # Test with cert_file
    conn = CustomHTTPSConnection('localhost', port=443, cert_file='/path/to/cert')
    conn.connect()
    assert conn.sock is not None
    conn.close()

    # Test with cert_file and key_file
    conn = CustomHTTPSConnection('localhost', port=443, cert_file='/path/to/cert', key_file='/path/to/key')
    conn.connect()
    assert conn.sock is not None
    conn.close()

    # Test with cert_file and key_file and context

# Generated at 2022-06-17 03:56:44.483445
# Unit test for function get_channel_binding_cert_hash