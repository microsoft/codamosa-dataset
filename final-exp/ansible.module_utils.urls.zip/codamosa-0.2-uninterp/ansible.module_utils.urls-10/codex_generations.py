

# Generated at 2022-06-17 03:53:40.584497
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''
    This is a unit test for the method connect of class UnixHTTPSConnection.
    It is not run as part of the normal test suite.
    '''
    # pylint: disable=too-few-public-methods,unused-variable
    class MockUnixHTTPConnection(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def connect(self):
            self.connected = True

    class MockUnixHTTPSConnection(UnixHTTPSConnection):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Test that the super() call to connect() works as expected
    unix_http_connection = MockUnixHTTPConnection('localhost', 80)


# Generated at 2022-06-17 03:53:50.647368
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Test with a valid certificate
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')
    handler.http_request(req)

    # Test with an invalid certificate
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')
    try:
        handler.http_request(req)
    except SSLValidationError as e:
        assert 'Failed to validate the SSL certificate for www.google.com:443' in to_native(e)

    # Test with a valid certificate and a proxy
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')


# Generated at 2022-06-17 03:54:02.035211
# Unit test for function fetch_url
def test_fetch_url():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.response import addinfourl
    from ansible.module_utils.six.moves.urllib.response import info as urllib_info
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import NoSSLError


# Generated at 2022-06-17 03:54:10.737113
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test with a valid ca_path
    handler = SSLValidationHandler('example.com', 443, ca_path='/etc/ssl/certs/ca-certificates.crt')
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path == '/etc/ssl/certs/ca-certificates.crt'
    assert cadata == bytearray()
    assert paths_checked == ['/etc/ssl/certs/ca-certificates.crt']

    # Test with an invalid ca_path
    handler = SSLValidationHandler('example.com', 443, ca_path='/etc/ssl/certs/ca-certificates.crt.invalid')
    ca_path, cadata, paths_checked = handler.get_ca_certs()


# Generated at 2022-06-17 03:54:15.966601
# Unit test for function fetch_file
def test_fetch_file():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.urllib.error as urllib_error
    import ansible.module_utils.six.moves.urllib.request as urllib_request
    import ansible.module_utils.six.moves.http_client as httplib
    import ansible.module_utils.six.moves.http_cookiejar as cookiejar
    import ansible.module_utils.six.moves.socketserver as socketserver
    import ansible.module_utils.six.moves.BaseHTTPServer as BaseHTTPServer
    import ansible.module_utils.six.moves.SimpleHT

# Generated at 2022-06-17 03:54:28.097612
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import unittest
    import os
    import tempfile
    import shutil
    import ssl
    import socket
    import sys
    import time
    import threading
    import subprocess
    import urllib
    import urllib2
    import httplib
    import BaseHTTPServer
    import SimpleHTTPServer
    import SocketServer
    import OpenSSL
    import pem
    import OpenSSL.crypto
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL
    import OpenSSL.SSL

# Generated at 2022-06-17 03:54:35.039905
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test with ca_path
    handler = SSLValidationHandler('hostname', 'port', ca_path='ca_path')
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path == 'ca_path'
    assert cadata == bytearray()
    assert paths_checked == []

    # Test without ca_path
    handler = SSLValidationHandler('hostname', 'port')
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path is not None
    assert cadata is not None
    assert paths_checked is not None



# Generated at 2022-06-17 03:54:39.390587
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    # Test with a unix socket
    unix_socket = '/tmp/test.sock'
    conn = UnixHTTPSConnection(unix_socket)
    conn.connect()
    assert conn.sock.family == socket.AF_UNIX
    assert conn.sock.type == socket.SOCK_STREAM
    assert conn.sock.getsockname() == unix_socket

    # Test with a normal hostname
    conn = UnixHTTPSConnection('localhost')
    conn.connect()
    assert conn.sock.family == socket.AF_INET
    assert conn.sock.type == socket.SOCK_STREAM

#
# HTTP(S) connection handling
#


# Generated at 2022-06-17 03:54:50.692711
# Unit test for function open_url
def test_open_url():
    '''
    Test open_url function
    '''
    # Test with a valid URL
    try:
        response = open_url('https://www.google.com')
        assert response.getcode() == 200
    except Exception as e:
        print(e)
        assert False

    # Test with an invalid URL
    try:
        response = open_url('https://www.google.com/invalid')
        assert False
    except Exception as e:
        assert True

    # Test with a valid URL and a method
    try:
        response = open_url('https://www.google.com', method='GET')
        assert response.getcode() == 200
    except Exception as e:
        print(e)
        assert False

    # Test with a valid URL and a method

# Generated at 2022-06-17 03:55:01.972529
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test the build_ssl_validation_error function
    '''
    try:
        build_ssl_validation_error('foo', 'bar', 'baz')
    except SSLValidationError as e:
        assert 'Failed to validate the SSL certificate for foo:bar.' in to_native(e)
        assert 'You can use validate_certs=False if you do not need to confirm the servers identity but this is unsafe and not recommended.' in to_native(e)
        assert 'Paths checked for this platform: baz.' in to_native(e)
        assert 'If the website serving the url uses SNI you need python >= 2.7.9 on your managed machine' in to_native(e)

# Generated at 2022-06-17 03:56:35.181438
# Unit test for function fetch_url
def test_fetch_url():
    module = AnsibleModule(argument_spec={})
    url = 'https://www.google.com'
    r, info = fetch_url(module, url)
    assert info['status'] == 200
    assert info['msg'] == 'OK (unknown bytes)'
    assert info['url'] == url
    assert info['cookies_string'] == ''
    assert info['cookies'] == {}
    assert r.read()


# Generated at 2022-06-17 03:56:46.125576
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest
    import urllib.request
    import urllib.error

    class TestRedirectHandlerFactory(unittest.TestCase):
        def test_redirect_handler(self):
            # Test redirect handler with follow_redirects=False
            handler = RedirectHandlerFactory(follow_redirects=False)
            urllib_request._opener.add_handler(handler)
            with self.assertRaises(urllib.error.HTTPError):
                urllib_request.urlopen('http://httpbin.org/redirect/1')

            # Test redirect handler with follow_redirects=True
            handler = RedirectHandlerFactory(follow_redirects=True)
            urllib_request._opener.add_handler(handler)

# Generated at 2022-06-17 03:56:50.989815
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        'file1': {
            'filename': '/bin/true',
            'mime_type': 'application/octet-stream'
        },
        'file2': {
            'content': 'text based file content',
            'filename': 'fake.txt',
            'mime_type': 'text/plain',
        },
        'text_form_field': 'value'
    }
    content_type, body = prepare_multipart(fields)
    assert content_type == 'multipart/form-data; boundary="===============9087341523448972644=="'

# Generated at 2022-06-17 03:56:55.232549
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-17 03:57:00.302860
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    assert maybe_add_ssl_handler('https://www.google.com', True) is not None
    assert maybe_add_ssl_handler('https://www.google.com', False) is None
    assert maybe_add_ssl_handler('http://www.google.com', True) is None
    assert maybe_add_ssl_handler('http://www.google.com', False) is None



# Generated at 2022-06-17 03:57:08.086703
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test the build_ssl_validation_error function
    '''
    try:
        build_ssl_validation_error('hostname', 'port', 'paths')
    except SSLValidationError as e:
        assert 'Failed to validate the SSL certificate for hostname:port.' in str(e)
        assert 'Make sure your managed systems have a valid CA certificate installed.' in str(e)
        assert 'Paths checked for this platform: paths.' in str(e)
        assert 'You can use validate_certs=False if you do not need to confirm the servers identity but this is unsafe and not recommended.' in str(e)
        assert 'If the website serving the url uses SNI you need python >= 2.7.9 on your managed machine' in str(e)

# Generated at 2022-06-17 03:57:13.813842
# Unit test for function fetch_file
def test_fetch_file():
    # Test fetch_file with a valid url
    url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/urls.py'
    module = AnsibleModule(argument_spec=dict(url=dict(required=True, type='str')))
    file_name = fetch_file(module, url)
    assert os.path.exists(file_name)
    os.remove(file_name)

    # Test fetch_file with an invalid url
    url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/urls.py_invalid'
    module = AnsibleModule(argument_spec=dict(url=dict(required=True, type='str')))

# Generated at 2022-06-17 03:57:22.226561
# Unit test for function fetch_file
def test_fetch_file():
    import tempfile
    import shutil
    import os
    import sys
    import stat
    from ansible.module_utils.urls import fetch_file
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.request import build_opener

# Generated at 2022-06-17 03:57:32.743889
# Unit test for function fetch_url
def test_fetch_url():
    import os
    import tempfile
    import shutil
    import json
    import time
    import datetime
    import pytz
    import requests
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.request import url2pathname
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import url

# Generated at 2022-06-17 03:57:43.282101
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Test with ca_path
    handler = SSLValidationHandler('hostname', 443, ca_path='/etc/ssl/certs/ca-certificates.crt')
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path == '/etc/ssl/certs/ca-certificates.crt'
    assert cadata == bytearray()
    assert paths_checked == ['/etc/ssl/certs/ca-certificates.crt']

    # Test without ca_path
    handler = SSLValidationHandler('hostname', 443)
    ca_path, cadata, paths_checked = handler.get_ca_certs()
    assert ca_path is not None
    assert cadata is not None
    assert paths_checked is not None

# Unit test

# Generated at 2022-06-17 03:59:38.570660
# Unit test for method http_request of class SSLValidationHandler