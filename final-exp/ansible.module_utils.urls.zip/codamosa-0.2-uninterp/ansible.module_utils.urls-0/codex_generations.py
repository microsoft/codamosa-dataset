

# Generated at 2022-06-17 03:54:14.571688
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-17 03:54:23.873058
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Test with a valid certificate
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')
    handler.http_request(req)

    # Test with an invalid certificate
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')
    try:
        handler.http_request(req)
    except SSLValidationError as e:
        assert 'Failed to validate the SSL certificate for www.google.com:443' in to_native(e)
    else:
        assert False, "SSLValidationError should have been raised"


# Generated at 2022-06-17 03:54:35.319060
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Test with a valid certificate
    handler = SSLValidationHandler('www.google.com', 443)
    req = urllib_request.Request('https://www.google.com')
    req = handler.http_request(req)
    assert req is not None

    # Test with a self-signed certificate
    handler = SSLValidationHandler('self-signed.badssl.com', 443)
    req = urllib_request.Request('https://self-signed.badssl.com')
    try:
        req = handler.http_request(req)
        assert False, "Should have raised an exception"
    except SSLValidationError:
        pass

    # Test with a certificate that does not match the hostname
    handler = SSLValidationHandler('wrong.host.badssl.com', 443)

# Generated at 2022-06-17 03:54:39.883105
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test function build_ssl_validation_error
    '''
    hostname = 'www.example.com'
    port = 443
    paths = ['/etc/ssl/certs/ca-certificates.crt', '/etc/ssl/certs/ca-bundle.crt']
    exc = 'Test exception'

# Generated at 2022-06-17 03:54:50.766489
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    # Test case 1: no_proxy is set, url is not included in no_proxy
    os.environ['no_proxy'] = 'localhost,127.0.0.1'
    url = 'https://www.google.com'
    handler = SSLValidationHandler('www.google.com', 443)
    assert handler.detect_no_proxy(url) == True

    # Test case 2: no_proxy is set, url is included in no_proxy
    url = 'https://localhost'
    handler = SSLValidationHandler('localhost', 443)
    assert handler.detect_no_proxy(url) == False

    # Test case 3: no_proxy is not set
    del os.environ['no_proxy']
    url = 'https://www.google.com'

# Generated at 2022-06-17 03:54:56.684356
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # Create a mock socket object
    class MockSocket(object):
        def __init__(self, hostname, port):
            self.hostname = hostname
            self.port = port
            self.s = None
            self.ssl_s = None

        def create_connection(self, hostname, port):
            self.s = socket.create_connection((hostname, port))
            return self.s

        def wrap_socket(self, s, ca_certs, cert_reqs, ssl_version):
            self.ssl_s = ssl.wrap_socket(s, ca_certs=ca_certs, cert_reqs=cert_reqs, ssl_version=ssl_version)
            return self.ssl_s

        def getpeercert(self):
            return self.ssl_s.getpe

# Generated at 2022-06-17 03:55:07.086279
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('http://www.example.com', 'get')
    assert req.get_method() == 'GET'
    req = RequestWithMethod('http://www.example.com', 'post')
    assert req.get_method() == 'POST'
    req = RequestWithMethod('http://www.example.com', 'put')
    assert req.get_method() == 'PUT'
    req = RequestWithMethod('http://www.example.com', 'delete')
    assert req.get_method() == 'DELETE'
    req = RequestWithMethod('http://www.example.com', 'head')
    assert req.get_method() == 'HEAD'
    req = RequestWithMethod('http://www.example.com', 'options')
    assert req.get_method() == 'OPTIONS'

# Generated at 2022-06-17 03:55:11.787110
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime()) == 'Fri, 09 Nov 2001 01:08:47 -0000'
    assert rfc2822_date_string(time.gmtime(), zone='+0000') == 'Fri, 09 Nov 2001 01:08:47 +0000'



# Generated at 2022-06-17 03:55:20.860597
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import unittest
    import ssl
    import socket
    import os
    import tempfile
    import shutil
    import sys
    import errno
    import time
    import subprocess
    import select
    import re
    import base64
    import pprint
    import urllib
    import urllib2
    import urlparse
    import httplib
    import traceback
    import threading
    import multiprocessing
    import platform
    import json
    import pkg_resources
    import netrc
    import getpass
    import warnings
    import random
    import string
    import datetime
    import calendar
    import hashlib
    import hmac
    import tempfile
    import shutil
    import os
    import stat
    import base64
    import errno
    import sys
    import types
   

# Generated at 2022-06-17 03:55:29.337744
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime()) == 'Fri, 09 Nov 2001 01:08:47 -0000'
    assert rfc2822_date_string(time.gmtime(), zone='+0000') == 'Fri, 09 Nov 2001 01:08:47 +0000'
    assert rfc2822_date_string(time.gmtime(), zone='+0100') == 'Fri, 09 Nov 2001 01:08:47 +0100'
    assert rfc2822_date_string(time.gmtime(), zone='-0100') == 'Fri, 09 Nov 2001 01:08:47 -0100'
    assert rfc2822_date_string(time.gmtime(), zone='+1200') == 'Fri, 09 Nov 2001 01:08:47 +1200'

# Generated at 2022-06-17 03:56:46.180148
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''
    Test the generic_urlparse function
    '''
    # Test with a ParseResult object
    parts = urlparse.urlparse('http://user:pass@example.com:8080/path?query=arg#fragment')
    assert generic_urlparse(parts) == {
        'scheme': 'http',
        'netloc': 'user:pass@example.com:8080',
        'path': '/path',
        'params': '',
        'query': 'query=arg',
        'fragment': 'fragment',
        'username': 'user',
        'password': 'pass',
        'hostname': 'example.com',
        'port': 8080,
    }

    # Test with a tuple

# Generated at 2022-06-17 03:56:57.947433
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    import unittest
    import mock
    import ssl

    class TestCustomHTTPSConnection(unittest.TestCase):
        def setUp(self):
            self.connection = CustomHTTPSConnection('host', 'port')
            self.connection.context = mock.MagicMock()
            self.connection.context.wrap_socket = mock.MagicMock(return_value='wrapped_socket')
            self.connection.sock = mock.MagicMock()
            self.connection.sock.create_connection = mock.MagicMock(return_value='socket')
            self.connection.sock.fileno = mock.MagicMock(return_value='fileno')
            self.connection.sock.getpeername = mock.MagicMock(return_value='peername')

# Generated at 2022-06-17 03:57:02.864418
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    '''
    Test atexit_remove_file
    '''
    import tempfile
    import shutil
    import atexit

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Register the temporary file to be removed at exit
    atexit.register(atexit_remove_file, tmpfile.name)

    # Check that the file exists
    assert os.path.exists(tmpfile.name)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check that the file does not exist
    assert not os.path.exists(tmpfile.name)



# Generated at 2022-06-17 03:57:14.360622
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Test for url with https scheme
    url = 'https://www.google.com'
    validate_certs = True
    ca_path = None
    handler = maybe_add_ssl_handler(url, validate_certs, ca_path)
    assert isinstance(handler, SSLValidationHandler)

    # Test for url with http scheme
    url = 'http://www.google.com'
    validate_certs = True
    ca_path = None
    handler = maybe_add_ssl_handler(url, validate_certs, ca_path)
    assert handler is None

    # Test for url with https scheme and validate_certs is False
    url = 'https://www.google.com'
    validate_certs = False
    ca_path = None

# Generated at 2022-06-17 03:57:24.558286
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    unix_socket = '/tmp/test_socket'
    unix_http_connection = UnixHTTPConnection(unix_socket)
    assert unix_http_connection._unix_socket == unix_socket
    assert unix_http_connection.sock is None
    unix_http_connection('localhost')
    assert unix_http_connection.sock is not None
    assert unix_http_connection.timeout is socket._GLOBAL_DEFAULT_TIMEOUT
    unix_http_connection('localhost', timeout=10)
    assert unix_http_connection.timeout == 10
    unix_http_connection('localhost', timeout=None)
    assert unix_http_connection.timeout is None

#
# Utilities
#


# Generated at 2022-06-17 03:57:28.687455
# Unit test for function getpeercert
def test_getpeercert():
    # Test with a valid certificate
    response = urllib_request.urlopen('https://www.google.com')
    assert getpeercert(response)

    # Test with an invalid certificate
    try:
        response = urllib_request.urlopen('https://expired.badssl.com')
    except urllib_error.URLError:
        pass
    else:
        assert getpeercert(response)



# Generated at 2022-06-17 03:57:34.162426
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://www.google.com'
    validate_certs = True
    ca_path = None
    assert maybe_add_ssl_handler(url, validate_certs, ca_path)


# Generated at 2022-06-17 03:57:38.370597
# Unit test for function fetch_file
def test_fetch_file():
    # Test fetch_file
    module = AnsibleModule(argument_spec={})
    url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/urls.py'
    file_name = fetch_file(module, url)
    assert os.path.exists(file_name)
    assert os.path.getsize(file_name) > 0
    os.unlink(file_name)


# Generated at 2022-06-17 03:57:41.945715
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    '''
    Test that UnixHTTPSConnection.__call__() returns an instance of UnixHTTPSConnection
    '''
    conn = UnixHTTPSConnection('/path/to/unix/socket')
    assert isinstance(conn('hostname', port=443), UnixHTTPSConnection)

#
# HTTP/HTTPS connection classes
#



# Generated at 2022-06-17 03:57:46.209091
# Unit test for function get_channel_binding_cert_hash

# Generated at 2022-06-17 03:59:42.587469
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    request = RequestWithMethod('http://www.google.com', 'GET')
    assert request.get_method() == 'GET'
    request = RequestWithMethod('http://www.google.com', 'POST')
    assert request.get_method() == 'POST'
    request = RequestWithMethod('http://www.google.com', 'PUT')
    assert request.get_method() == 'PUT'
    request = RequestWithMethod('http://www.google.com', 'DELETE')
    assert request.get_method() == 'DELETE'
    request = RequestWithMethod('http://www.google.com', 'HEAD')
    assert request.get_method() == 'HEAD'
    request = RequestWithMethod('http://www.google.com', 'OPTIONS')
    assert request.get_method() == 'OPTIONS'