

# Generated at 2022-06-20 21:13:03.245121
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    url = urlparse('https://127.0.0.1:8449/v1')
    assert ParseResultDottedDict(url._asdict()).as_list() == list(url)

#
# Utilities
#
if PY2:
    iteritems = (dict.iteritems if hasattr(dict, 'iteritems') else dict.items)

    def to_bytes(text, encoding='utf-8'):
        '''Return the byte representation of a text string, optionally encoding the text first.'''
        if isinstance(text, bytes):
            return text
        elif isinstance(text, string_types):
            return text.encode(encoding)
        else:
            raise TypeError('to_bytes expects str or unicode, got %s' % type(text))

# Generated at 2022-06-20 21:13:06.178873
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("Test")
    except Exception as e:
        if e.__str__() != "Test":
            raise Exception("Test of ConnectionError() constructor failed")



# Generated at 2022-06-20 21:13:08.120708
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError
    except ConnectionError:
        pass


# Generated at 2022-06-20 21:13:11.942728
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string((2009, 5, 8, 14, 11, 5, 4, 128, 1)) == \
        'Fri, 08 May 2009 14:11:05 -0000'



# Generated at 2022-06-20 21:13:24.265861
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    # Test a valid unix socket file
    unix_socket = '/path/to/some/unix/socket'
    unixconn = UnixHTTPConnection(unix_socket)
    assert unixconn._unix_socket == unix_socket

    # Test a missing unix socket file
    invalid_unix_socket = '/path/to/invalid/socket/file'
    with pytest.raises(OSError) as e:
        UnixHTTPConnection(invalid_unix_socket)
    message = str(e.value)
    assert message == 'Invalid Socket File (%s): [Errno 2] No such file or directory' % invalid_unix_socket

    # Test an invalid unix socket file path
    invalid_unix_socket = 'some-invalid-socket-file'

# Generated at 2022-06-20 21:13:29.645416
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    handler = UnixHTTPHandler('/some/path')
    assert handler._unix_socket == '/some/path'



# Generated at 2022-06-20 21:13:35.182825
# Unit test for method http_request of class SSLValidationHandler

# Generated at 2022-06-20 21:13:47.431801
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    conn = CustomHTTPSConnection('127.0.0.1', 1234)
    assert isinstance(conn, CustomHTTPSConnection)
    assert isinstance(conn, httplib.HTTPSConnection)
    assert conn.context is None

    if HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert isinstance(conn._context, PyOpenSSLContext)
        conn = CustomHTTPSConnection('127.0.0.1', 1234, cert_file='nonexistent.pem')
        conn.connect()

    sock = socket.socket()
    try:
        conn = CustomHTTPSConnection('google.com', 443, sock=sock, timeout=3)
        conn.connect()
        assert conn.sock == sock
    finally:
        sock.close()



# Generated at 2022-06-20 21:13:56.899743
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # Create a SSLValidationHandler object
    unittest_SSLValidationHandler = SSLValidationHandler(hostname='www.google.com', port=443, ca_path=None)
    # Test 1
    tmp_ca_cert_path, cadata, paths_checked = unittest_SSLValidationHandler.get_ca_certs()
    assert isinstance(tmp_ca_cert_path, str)
    assert len(tmp_ca_cert_path) > 0
    assert isinstance(cadata, tuple)
    assert isinstance(paths_checked, list)
    # Test 2
    unittest_SSLValidationHandler = SSLValidationHandler(hostname='www.google.com', port=443, ca_path='/etc/ssl/host.cert')
    tmp_ca_cert_path, cadata, paths_

# Generated at 2022-06-20 21:14:02.590507
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    conn = CustomHTTPSConnection('example.com')
    assert conn.host == 'example.com'
    assert conn.port == 443
    assert conn.timeout == socket._GLOBAL_DEFAULT_TIMEOUT
    conn = CustomHTTPSConnection('example.com', timeout=5)
    assert conn.timeout == 5
    assert conn.src_address is None
    conn = CustomHTTPSConnection('example.com', src_address=('127.0.0.1', 0))
    assert conn.src_address == ('127.0.0.1', 0)
    conn = CustomHTTPSConnection('example.com', src_address=('127.0.0.1', 1234))
    assert conn.src_address == ('127.0.0.1', 1234)



# Generated at 2022-06-20 21:16:33.714808
# Unit test for method open of class Request
def test_Request_open():
    def test(request,method,url,data=None,headers=None,use_proxy=None,force=None,last_mod_time=None,timeout=None,validate_certs=None,url_username=None,url_password=None,http_agent=None,force_basic_auth=None,follow_redirects=None,client_cert=None,client_key=None,cookies=None,use_gssapi=False,unix_socket=None,ca_path=None,unredirected_headers=None):
        # NOTE: The following variables are deepcopy()ed to prevent cross-test interference.
        method = copy.deepcopy(method)
        url = copy.deepcopy(url)
        data = copy.deepcopy(data)

# Generated at 2022-06-20 21:16:39.534698
# Unit test for function fetch_url
def test_fetch_url():
    module = Mock()
    module.tmpdir = C.DEFAULT_LOCAL_TMP
    module.params = dict(url_username='user', url_password='pass', http_agent='agent',
                         force_basic_auth=False, use_gssapi=False)
    url = 'https://test.com/'
    data = 'test data'
    headers = dict(header1='value1', header2='value2')
    method = 'PUT'
    use_proxy = False
    force = True
    last_mod_time = None
    timeout = 600
    use_gssapi = False
    validate_certs = True
    follow_redirects = 'urllib2'
    client_cert = None
    client_key = None
    unix_socket = None
    ca_path = None
   

# Generated at 2022-06-20 21:16:44.371861
# Unit test for function getpeercert
def test_getpeercert():
    assert getpeercert()['subjectAltName'] == None
    assert getpeercert()['subject'][5][0][0] == None


# Generated at 2022-06-20 21:16:55.344279
# Unit test for function fetch_url
def test_fetch_url():
    # Backwards compat tests
    test_data_dir = os.path.join(os.path.dirname(__file__), 'unit-data') + os.path.sep
    response = namedtuple("Response", "read")
    # Test unauth with no username/password
    http_error = urllib_error.HTTPError("url", 401, "Authentication Required", None, None)
    http_error.read = lambda: ""
    response.read = lambda: b"A Response"
    with patch('ansible.module_utils.six.moves.urllib_request.urlopen', return_value=http_error), \
         patch('ansible.errors.AnsibleError') as err_mock:
        r, info = fetch_url(None, 'http://domain.com')

# Generated at 2022-06-20 21:17:00.926793
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_socket_path = '/tmp/ansible-test-unix.sock'
    cert_file = os.path.join(os.path.dirname(__file__), 'test_data', 'https', 'client.crt')
    key_file = os.path.join(os.path.dirname(__file__), 'test_data', 'https', 'client.key')
    handler = HTTPSClientAuthHandler(unix_socket=unix_socket_path, client_cert=cert_file, client_key=key_file)
    manager = urllib_request.HTTPPasswordMgrWithDefaultRealm()
    manager.add_password(None, 'https://unix/', 'user', 'pass')
    auth_handler = urllib_request.HTTPBasicAuthHandler(manager)
    opener = urll

# Generated at 2022-06-20 21:17:06.496977
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    Test cases for RedirectHandlerFactory
    '''
    # To test the factory, we have to create a dummy urllib2 opener and
    # register the handler with it.
    original_opener = urllib_request._opener
    urllib_request._opener = urllib_request.build_opener()

    # Mock some dummy data so the requests go through, and the redirect
    # request gets generated
    response = MagicMock()
    response.code = 200
    response.msg = 'OK'
    response.info = response.msg
    response.getheaders = MagicMock(return_value=[])
    response.getheader = response.getheaders
    response.read = response.info
    response.iter_content = MagicMock(return_value=response.read())

    # We need a

# Generated at 2022-06-20 21:17:10.745489
# Unit test for function prepare_multipart
def test_prepare_multipart():
    from datetime import date
    from io import BytesIO  # noqa
    import base64
    import struct


# Generated at 2022-06-20 21:17:18.698707
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    handler = SSLValidationHandler('localhost', '443')
    tmp_ca_cert_path, cadata, paths_checked = handler.get_ca_certs()
    context = handler.make_context(tmp_ca_cert_path, cadata)
    assert isinstance(context, ssl.SSLContext)

    context = handler.make_context(None, None)
    assert isinstance(context, ssl.SSLContext)



# Generated at 2022-06-20 21:17:20.125027
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError('test')
    except NoSSLError as e:
        assert e.message == 'test'
        assert str(e) == 'test'



# Generated at 2022-06-20 21:17:23.921321
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    try:
        temp_file_fd, temp_file_name = tempfile.mkstemp()
        os.close(temp_file_fd)
        os.unlink(temp_file_name)
        socket_file = UnixHTTPConnection(temp_file_name)
        with pytest.raises(OSError):
            socket_file.connect()
        os.unlink(temp_file_name)
    finally:
        if os.path.exists(temp_file_name):
            os.unlink(temp_file_name)
# End of unit test for constructor of class UnixHTTPConnection

#
# Utility functions
#



# Generated at 2022-06-20 21:18:18.257136
# Unit test for function fetch_url
def test_fetch_url():
    # need a tty-less stdout
    # only required if you want to test with yaml/json callbacks
    # old_stdout = sys.stdout
    # fd = open(os.devnull, 'w')
    # sys.stdout = fd

    class FakeModule(object):
        def __init__(self):
            self.params = dict(
                url_username='foo',
                url_password='bar',
                validate_certs=False,
                url='http://httpbin.org/basic-auth/foo/bar',
                force_basic_auth=True,
                follow_redirects='urllib2',
                http_agent='fetch_url_unittest/0.1',
                use_proxy=False,
            )

    m = FakeModule()

    r, info

# Generated at 2022-06-20 21:18:28.868138
# Unit test for function url_argument_spec
def test_url_argument_spec():
    spec = url_argument_spec()
    assert 'url' in spec
    assert 'force' in spec
    assert 'validate_certs' in spec
    assert 'url_username' in spec
    assert 'url_password' in spec
    assert 'force_basic_auth' in spec
    assert 'client_cert' in spec
    assert 'client_key' in spec
    assert 'use_gssapi' in spec
    assert 'use_proxy' in spec

# Generated at 2022-06-20 21:18:36.049868
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    tmp_ca_cert_path = "/tmp/certs"
    cadata = "abcdefg"
    handler = SSLValidationHandler("hostname", 443, tmp_ca_cert_path)

    context = handler.make_context(tmp_ca_cert_path, cadata)
    assert context.get_ca_certs() == cadata

    context = handler.make_context(tmp_ca_cert_path, None)
    assert context.get_ca_certs() == cadata

    context = handler.make_context(None, cadata)
    assert context.get_ca_certs() == cadata

    context = handler.make_context(None, None)
    assert context.get_ca_certs() == None

# Generated at 2022-06-20 21:18:37.263401
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    SSLValidationHandler.validate_proxy_response(None, b'HTTP/1.0 200 OK', valid_codes=[401,200])


# Generated at 2022-06-20 21:18:38.745955
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    url = "https://github.com/ansible/ansible"
    req_with_method = RequestWithMethod(url, "PUT")
    assert "PUT" == req_with_method.get_method()



# Generated at 2022-06-20 21:18:54.790130
# Unit test for function prepare_multipart
def test_prepare_multipart():
    '''
    Test that prepare_multipart() correctly encodes a variety of input
    '''