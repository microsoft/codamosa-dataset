

# Generated at 2022-06-20 21:12:59.635959
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    # test with method, url and headers
    req = RequestWithMethod('url', 'put')
    assert req.get_method() == 'PUT'
    assert req.get_full_url() == 'url'
    assert req.header_items() == []

    # test with method, url and headers
    req = RequestWithMethod('url', 'put', None, {'Content-Type': 'text/plain', 'Accept': 'application/json'})
    assert req.get_method() == 'PUT'
    assert req.get_full_url() == 'url'
    assert req.header_items() == [['Accept', 'application/json'], ['Content-Type', 'text/plain']]


#
# URL funcs - public API
#


# Generated at 2022-06-20 21:13:03.659962
# Unit test for method options of class Request
def test_Request_options():
    import http.client
    req = http.client.HTTPSConnection("ansible_collections_cn.ansible.apache.demo_collection.apache.plugins.module_utils.http.Request")
    req.request("ansible_collections_cn.ansible.apache.demo_collection.apache.plugins.module_utils.http.Request")
    res = req.getresponse()
    assert(res.status == 200)


# Generated at 2022-06-20 21:13:08.304042
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    handler = SSLValidationHandler()

    assert handler.make_context(None, None).verify_mode == ssl.CERT_REQUIRED

    handler = SSLValidationHandler(ca_path='./tests/fixtures/test_urllib_util.py')

    assert handler.make_context(None, None).verify_mode == ssl.CERT_REQUIRED
    assert handler.make_context(None, None).get_ca_certs()[0] == './tests/fixtures/test_urllib_util.py'

    handler = SSLValidationHandler()

    assert handler.make_context(None, None).verify_mode == ssl.CERT_REQUIRED

    handler = SSLValidationHandler(ca_path='./tests/fixtures/test_urllib_util.py')

# Generated at 2022-06-20 21:13:12.494334
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    connection = UnixHTTPSConnection(unix_socket='/tmp/foo')
    assert connection.host == None
    assert connection.port == None
    assert connection._http_vsn == 11
    assert connection._http_vsn_str == 'HTTP/1.1'



# Generated at 2022-06-20 21:13:15.764420
# Unit test for function url_argument_spec
def test_url_argument_spec():
  url = url_argument_spec()
  assert url['force']['type'] == 'bool'

# Generated at 2022-06-20 21:13:23.752690
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Try to instantiate class ConnectionError
    try:
        ce = ConnectionError('')
    except Exception as exc:
        # Fail test if ConnectionError is not instantiated
        assert False, "Failed to instantiate ConnectionError class with message: %s" % exc
    # Verify that ConnectionError is an instance of class Exception
    assert isinstance(ce, Exception), \
           "ConnectionError is not an instance of Exception class"
    # Verify that ConnectionError is an instance of class ConnectionError
    assert isinstance(ce, ConnectionError), \
           "ConnectionError is not an instance of ConnectionError class"


# Generated at 2022-06-20 21:13:26.144874
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
        # test that the UnixHTTPConnection object can be created with two
        # parameters
        connection = UnixHTTPConnection('/var/run/docker.sock')('localhost', 0)
        assert connection != None
# /Unit test



# Generated at 2022-06-20 21:13:30.525802
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    url_parts = ParseResultDottedDict({'scheme':'http', 'netloc':'example.com',
                                 'path': '/path/to/my/resource',
                                 'params': 'param1=test1&param2=test2',
                                 'query': 'foo=bar',
                                 'fragment': 'documentation'})
    assert url_parts.scheme == 'http'
    assert url_parts.query == 'foo=bar'



# Generated at 2022-06-20 21:13:39.420827
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # test that we can use prepare_multipart with a string
    result = prepare_multipart({'text_form_field': 'value'})
    assert result[1] == b'value'

    # test that we can use prepare_multipart with text payload
    result = prepare_multipart({'file2': {'content': 'text based file content', 'filename': 'fake.txt'}})
    assert result[1] == b'Content-Type: text/plain\r\nContent-Disposition: form-data; filename="fake.txt"\r\n\r\ntext based file content'

    # test that we can use prepare_multipart with a file
    base64_output = b'/bin/true\r\n'

# Generated at 2022-06-20 21:13:49.775229
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    url = 'unix:///socket/path'
    url_with_query = url + '?query=string'
    unix_socket = '/socket/path'
    unix_https_handler = UnixHTTPHandler(unix_socket)
    assert unix_https_handler._unix_socket == unix_socket
    unix_request = unix_https_handler.get_unix_connection(url_with_query)
    assert unix_request.host == unix_socket


# Generated at 2022-06-20 21:14:29.304948
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('me', 'secret') == 'Basic bWU6c2VjcmV0'



# Generated at 2022-06-20 21:14:40.035702
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    class MockUrllibRequest:
        def __init__(self, url):
            self.url = url

        def get_full_url(self):
            return self.url

    nos_proxy = 'www.google.com,www.baidu.com'
    # enable no_proxy
    os.environ['no_proxy'] = nos_proxy
    test_handler = SSLValidationHandler('www.baidu.com', 443)
    request = MockUrllibRequest('https://www.baidu.com/')
    assert not test_handler.http_request(request)

    os.environ['no_proxy'] = nos_proxy.upper()
    test_handler = SSLValidationHandler('www.baidu.com', 443)

# Generated at 2022-06-20 21:14:45.008689
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    # Empty
    d = ParseResultDottedDict()
    assert d.as_list() == [None, None, None, None, None, None], d.as_list()

    # Full
    d = ParseResultDottedDict(scheme='ssh', netloc='user@host:22', path='/foo/bar')
    assert d.as_list() == ['ssh', 'user@host:22', '/foo/bar', None, None, None]

    # Partially filled
    d = ParseResultDottedDict(scheme='ssh', path='/foo/bar')
    assert d.as_list() == ['ssh', None, '/foo/bar', None, None, None]

    # Reordered
    d = ParseResultDottedDict(path='/foo/bar', scheme='ssh')

# Generated at 2022-06-20 21:14:50.823010
# Unit test for function url_argument_spec
def test_url_argument_spec():
    spec = url_argument_spec()
    assert 'url' in spec
    assert spec['url']['type'] == 'str'
    assert 'force' in spec
    assert spec['force']['type'] == 'bool'


# Generated at 2022-06-20 21:14:57.741486
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    with pytest.raises(OSError) as excinfo:
        # Invalid socket file
        UnixHTTPHandler('/notexistsocket')
    assert excinfo.value.args == ('Invalid Socket File (/notexistsocket): [Errno 2] No such file or directory',)
    handler = UnixHTTPHandler('/test.sock')
    req = urllib_request.Request('http://127.0.0.1/test')
    assert type(handler.http_open(req)) == UnixHTTPConnection



# Generated at 2022-06-20 21:15:04.289594
# Unit test for function url_argument_spec
def test_url_argument_spec():
    spec = url_argument_spec()

    assert_equal(spec['url']['type'], 'str')
    assert_equal(spec['force']['type'], 'bool')
    assert_true(spec['force']['default'])
    assert_equal(spec['http_agent']['type'], 'str')
    assert_equal(spec['http_agent']['default'], 'ansible-httpget')
    assert_equal(spec['use_proxy']['type'], 'bool')
    assert_true(spec['use_proxy']['default'])
    assert_equal(spec['validate_certs']['type'], 'bool')
    assert_true(spec['validate_certs']['default'])

# Generated at 2022-06-20 21:15:09.566651
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    original_cafile = os.environ.get('SSL_CERT_FILE')
    original_capath = os.environ.get('SSL_CERT_DIR')
    original_nossl = os.environ.get('ANSIBLE_NOCOLOR')
    original_path = os.environ.get('PATH')
    original_trust_env = ssl.OPENSSL_VERSION_INFO
    test_data_path = os.path.join(os.path.dirname(__file__), 'test_data')
    temp_dir = tempfile.mkdtemp()
    os.environ['ANSIBLE_DEBUG'] = 'true'
    os.environ['PATH'] = temp_dir
    os.environ['PYTHONIOENCODING'] = 'UTF-8'

# Generated at 2022-06-20 21:15:16.959489
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    import unittest
    import ansible.module_utils.urls as urls
    class TestUrls(unittest.TestCase):
        '''
        A class for SSLValidationError unit test
        '''

        def test_SSLValidationError(self):
            '''
            A method for testing the constructor of SSLValidationError class
            '''
            # catch the exception
            try:
                # call constructor of class SSLValidationError
                SSLValidationError()
            except Exception as e:
                # check if exception is of type SSLValidationError
                self.assertEqual(type(e), SSLValidationError)
            else:
                # test failed if exception was not raised
                self.fail('SSLValidationError constructor did not raise an exception')
    # run the test case
    unittest.main()


# Generated at 2022-06-20 21:15:21.984838
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    assert UnixHTTPSConnection('unixsocket').__call__('host', 'port') is not None

JSONDecodeError = None
if sys.version_info >= (3, 5):
    JSONDecodeError = json.decoder.JSONDecodeError
else:
    JSONDecodeError = ValueError

ParseError = None
if sys.version_info >= (3, 5):
    ParseError = csv.Error
else:
    ParseError = ValueError

try:
    from BaseHTTPServer import BaseHTTPRequestHandler
except ImportError:
    from http.server import BaseHTTPRequestHandler
    # Python 3.x
    MAXFD = resource.getrlimit(resource.RLIMIT_NOFILE)[1]
    if (MAXFD == resource.RLIM_INFINITY):
        MAXFD = MAXFD_L

# Generated at 2022-06-20 21:15:34.022045
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    url = 'http://ansible.com/'
    no_proxy = 'ansible.com,google.com'
    os.environ['no_proxy'] = no_proxy
    ssl_handler = SSLValidationHandler('ansible.com', 443)
    assert not ssl_handler.detect_no_proxy(url)
    url = 'http://www.ansible.com/'
    assert not ssl_handler.detect_no_proxy(url)
    url = 'http://www.google.com/'
    assert ssl_handler.detect_no_proxy(url)
    url = 'http://www.microsoft.com/'
    assert ssl_handler.detect_no_proxy(url)
    no_proxy = 'ansible.com,*.google.com'

# Generated at 2022-06-20 21:16:44.240847
# Unit test for function fetch_file
def test_fetch_file():
    import datetime

    def getaname():
        dt = datetime.datetime.now()
        return "test_%d%02d%02d_%02d%02d%02d" % (dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)

    class Input(object):
        def __init__(self, params=None, args=None):
            self.params = params
            self.args = args

    class Module(object):
        def __init__(self):
            self.tmpdir = os.path.realpath('.')
            self.params = {}
            self.args = {}
            self.failed = False
            self.check_mode = False

        @property
        def params(self):
            return self._params

       

# Generated at 2022-06-20 21:16:55.281232
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {"testkey1": "testvalue1", "testkey2": "testvalue2"}
    content_type, body = prepare_multipart(fields)
    content_type1, _ = prepare_multipart({"testkey1": "testvalue1"})
    content_type2, _ = prepare_multipart({"testkey2": "testvalue2"})
    non_string_dict = {"testkey3": {"content": "testvalue3"}}
    content_type3, _ = prepare_multipart(non_string_dict)
    non_string_dict = {"testkey3": {"content": "testvalue3", "filename": "/bin/true"}}
    content_type4, _ = prepare_multipart(non_string_dict)
    assert content_type is not content_type1 and content

# Generated at 2022-06-20 21:17:01.158217
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    import types
    handler = HTTPSClientAuthHandler()
    assert isinstance(handler.https_open, types.MethodType)

    hostname = 'host.example.com'
    port = 1234
    hostport = '%s:%d' % (hostname, port)

    req = urllib_request.Request(uri='https://%s/' % hostport)
    connection = handler.https_open(req)
    assert connection.host == hostname
    assert connection.port == port
    assert not connection.client_cert
    assert not connection.client_key

    client_cert = '/path/to/cert'
    client_key = '/path/to/key'
    handler = HTTPSClientAuthHandler(client_cert=client_cert, client_key=client_key)

# Generated at 2022-06-20 21:17:09.101090
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    unix_http_handler = UnixHTTPHandler('/var/lib/unix.sock')
    assert unix_http_handler is not None
    assert unix_http_handler._unix_socket == '/var/lib/unix.sock'
    assert unix_http_handler.do_open is not None

#
# Connection classes
#



# Generated at 2022-06-20 21:17:09.910162
# Unit test for method delete of class Request
def test_Request_delete():
    assert()

# Generated at 2022-06-20 21:17:16.845166
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    hostname = 'pypi.python.org'
    port = 443
    remote_ca_path = 'test/remote_ca.pem'
    handler = SSLValidationHandler(hostname, port, ca_path=remote_ca_path)
    assert handler.ca_path == remote_ca_path


# Generated at 2022-06-20 21:17:19.347317
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    handler = SSLValidationHandler('', 0)
    req_object = urllib_request.Request('')
    handler.http_request(req_object)


# Generated at 2022-06-20 21:17:25.605560
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    class Request(object):
        pass

    hostname = "apple.com"
    port = 443
    handler = SSLValidationHandler(hostname, port)
    ok_codes = [200]

    def validate_response(response, codes=None):
        # do nothing
        pass

    handler.validate_proxy_response = validate_response
    handler.detect_no_proxy = lambda url: True
    handler.get_ca_certs = lambda: ("cert-file", "cert-data", ("path1", "path2"))

    if not HAS_URLLIB3_PYOPENSSLCONTEXT:
        handler.make_context = lambda cafile, cadata: cafile
        handler.detect_no_proxy = lambda url: True

    req = Request()

# Generated at 2022-06-20 21:17:29.597625
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():

    def test():
        try:
            assert os.path.exists('/tmp/test_http_unix_connection')
            os.remove('/tmp/test_http_unix_connection')
        except OSError:
            pass
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind('/tmp/test_http_unix_connection')
        s.listen(1)
        conn = UnixHTTPConnection('/tmp/test_http_unix_connection')
        conn.connect()
        assert conn.sock is not None
        s.close()
        os.remove('/tmp/test_http_unix_connection')
    test()



# Generated at 2022-06-20 21:17:34.684038
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test with a single argument
    try:
        raise ProxyError("message with single string")
    except ProxyError as e:
        assert str(e) == "message with single string"
        pass
    else:
        assert False, "Test with a single argument should not fail"

    # Test with several arguments
    try:
        raise ProxyError("message with", "several arguments")
    except ProxyError as e:
        assert str(e) == "message with several arguments"
        pass
    else:
        assert False, "Test with several arguments should not fail"



#
# Timeout and read/write functions
#



# Generated at 2022-06-20 21:18:54.530093
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_socket = ('/tmp/foo')
    u_https_conn = UnixHTTPSConnection(unix_socket)
    assert isinstance(u_https_conn('foo.bar'), UnixHTTPSConnection)

if sys.platform.startswith("linux"):
    # We only need this class on a unix platform, since the native Windows
    # API doesn't support unix sockets.  At least not in Python 2.7
    class UnixHTTPConnection(httplib.HTTPConnection):
        def __init__(self, unix_socket):
            httplib.HTTPConnection.__init__(self, 'localhost')
            self._unix_socket = unix_socket

        def connect(self):
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)