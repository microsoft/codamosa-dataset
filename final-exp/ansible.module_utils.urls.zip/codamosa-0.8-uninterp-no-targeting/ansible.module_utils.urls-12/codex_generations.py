

# Generated at 2022-06-20 21:12:01.025796
# Unit test for method get of class Request
def test_Request_get():
    method = 'GET'
    url = ''
    kwargs = ''
    assert Request.get(url, **kwargs) =='urlopen(method, url, data=None, headers=None, use_proxy=None, force=None, last_mod_time=None, timeout=None, validate_certs=None, url_username=None, url_password=None, http_agent=None, force_basic_auth=None, follow_redirects=None, client_cert=None, client_key=None, cookies=None, use_gssapi=False, unix_socket=None, ca_path=None)'


# Generated at 2022-06-20 21:12:09.150137
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    input = {
        'scheme': 'scheme',
        'netloc': 'netloc',
        'path': 'path',
        'params': 'params',
        'query': 'query',
        'fragment': 'fragment'
    }
    d = ParseResultDottedDict(input)
    assert d.as_list() == ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']



# Generated at 2022-06-20 21:12:21.525718
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    from urllib import request as urllib_request
    from urllib import parse as urllib_parse

    class DummyOpener(urllib_request.OpenerDirector):
        pass

    # urllib_request.OpenerDirector.add_handler calls
    # getattr(handler, "add_parent", None) in a try block. If it fails,
    # the handler is ignored. In our case, the handler to add has no
    # add_parent method, so we have to add it manually.

    opener = DummyOpener()

    # create handler
    handler = CustomHTTPSHandler()

    # add it to the opener
    opener.handlers.append(handler)

    # avoid warning messages. verbose is not a constructor of AbstractHTTPHandler
    opener.handle_open["https"] = handler.https_open


# Generated at 2022-06-20 21:12:26.960588
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": "/bin/true",
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    content_type, body = prepare_multipart(fields)
    assert content_type == 'multipart/form-data; boundary=' + body.split(b"\r\n")[0][2:]
    if not PY3:
        assert b"\r\n" in body
    assert b"filename=\"fake.txt\"" in body
    assert b"filename=\"/bin/true\"" in body

# Generated at 2022-06-20 21:12:36.730972
# Unit test for function getpeercert
def test_getpeercert():
    try:
        # noinspection PyUnresolvedReferences
        import ssl
    except ImportError:
        raise SkipTest('test_getpeercert requires the ssl module')
    else:
        try:
            from urllib.request import urlopen
        except ImportError:
            from urllib2 import urlopen
        try:
            response = urlopen('https://www.ansible.com')
        except IOError:
            raise SkipTest('Could not open URL')
        else:
            return getpeercert(response)



# Generated at 2022-06-20 21:12:42.597199
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    class Result(Exception): pass
    def check_response(data, valid_codes=[200]):
        try:
            validate_proxy_response(data, valid_codes)
        except Exception:
            raise Result

    try:
        #valid response
        check_response('HTTP/1.0 200 Connection established\r\n\r\n')
        #invalid response
        check_response('HTTP/1.0 666 Connection established\r\n\r\n')
    except Result:
        pass
    else:
        assert False, "Invalid response parsed"

# Generated at 2022-06-20 21:12:53.383787
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    '''
    Return a list from a dictionary with keys like the ParseResult named tuple
    '''
    for idx in list(range(6)):
        d = ParseResultDottedDict()
        # Silly monkey configuration to make sure invalid args cause an error
        d['scheme'] = "http"
        d['netloc'] = "localhost"
        d['path'] = "/"
        d['params'] = None
        d['query'] = None
        d['fragment'] = None
        d[list(d.keys())[idx]] = "something"
        result = d.as_list()
        assert result[idx] == "something", "result = %s" % result


# Generated at 2022-06-20 21:13:02.551252
# Unit test for function getpeercert
def test_getpeercert():
    """Ensure that getpeercert() works with a simple HTTPS server."""
    import OpenSSL
    import BaseHTTPServer
    import ssl
    import threading
    import tempfile
    import shutil
    import atexit
    import subprocess
    import random
    import os

    PORT = random.randint(1025, 65535)
    HOST = 'localhost'

    class Handler(BaseHTTPServer.BaseHTTPRequestHandler):
        def do_HEAD(self):
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()

    def get_url():
        return 'https://{0}:{1}'.format(HOST, PORT)


# Generated at 2022-06-20 21:13:04.341197
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err_msg = 'abc'
    pe = ProxyError(err_msg)
    assert pe.message == err_msg



# Generated at 2022-06-20 21:13:08.979635
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    # Create SSLValidationHandler instance
    h = SSLValidationHandler("example.com", 443)
    # Check for correct values for local variables
    assert h.hostname == "example.com"
    assert h.port == 443
    assert h.ca_path is None

    h = SSLValidationHandler("example.com", 443, "/tmp/path/to/cacert")
    assert h.hostname == "example.com"
    assert h.port == 443
    assert h.ca_path == "/tmp/path/to/cacert"


# Generated at 2022-06-20 21:14:31.280657
# Unit test for function getpeercert
def test_getpeercert():
    try:
        # HTTP connection to Github
        response = urllib_request.urlopen('https://github.com')
        assert getpeercert(response) is None  # Not HTTPS
        # HTTPS connection to Github
        response = urllib_request.urlopen('https://github.com')
        assert getpeercert(response) is not None  # HTTPS
        assert getpeercert(response, binary_form=True) is not None  # HTTPS
    except Exception:
        pass
    response.close()



# Generated at 2022-06-20 21:14:33.441141
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    handler = SSLValidationHandler('', 443)
    result = handler.get_ca_certs()
    assert result, "The method get_ca_certs is not working."



# Generated at 2022-06-20 21:14:34.203400
# Unit test for method patch of class Request
def test_Request_patch():
    request = Request()
    request.patch('url')

# Generated at 2022-06-20 21:14:47.090454
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''Constructor of class UnixHTTPSConnection should return a instance with the given socket'''
    # Disable pylint check for the super() call. It complains about UnixHTTPSConnection
    # being a NoneType because of the initial definition above, but it won't actually
    # be a NoneType when this code runs
    # pylint: disable=bad-super-call
    conn = UnixHTTPSConnection(unix_socket='/tmp/ansible-test')
    # pylint: enable=bad-super-call
    assert conn.sock.family == socket.AF_UNIX
    assert conn.sock.type == socket.SOCK_STREAM
    assert conn.sock.proto == socket.IPPROTO_TCP


# Generated at 2022-06-20 21:14:55.450540
# Unit test for function getpeercert
def test_getpeercert():
    from ansible.module_utils.six.moves import http_client
    try:
        with http_client.HTTPSConnection('expired.badssl.com', timeout=10) as expired:
            expired.request('GET', '/')
            response = expired.getresponse()
            assert response.status in [http_client.OK, http_client.FOUND, http_client.MOVED_PERMANENTLY]
            getpeercert(response)
    except AttributeError:
        pass



# Generated at 2022-06-20 21:14:58.816353
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
        timetuple= (2012, 5, 25, 14, 47, 42, 4, 145, 0)
        zone = '-0000'
        assert rfc2822_date_string(timetuple, zone) == \
               'Fri, 25 May 2012 14:47:42 -0000'



# Generated at 2022-06-20 21:15:03.718681
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header(None, None) == b"Basic "
    assert basic_auth_header("user", "password") == b"Basic dXNlcjpwYXNzd29yZA=="



# Generated at 2022-06-20 21:15:14.676365
# Unit test for function fetch_url
def test_fetch_url():
    class DummyResponse(object):
        def __init__(self, headers):
            self._headers = headers

        def info(self):
            return self._headers

    module = DummyModule()

    # test case 1: get a cached copy
    r = DummyResponse({'content-type': 'audio/mpeg'})
    info = {'msg': 'OK (384 bytes)', 'url': 'http://example.com', 'status': 200}


# Generated at 2022-06-20 21:15:28.229814
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    """
    Ensure that RedirectHandlerFactory returns
    an instance of RedirectHandler only once,
    and that the instance is properly closed over.
    """

    # Boolean tests
    for follow_redirects in [True, False]:
        for validate_certs in [True, False]:
            for ca_file in [None, '/dev/null']:
                handler_instance = RedirectHandlerFactory(follow_redirects, validate_certs, ca_file)
                assert handler_instance is RedirectHandlerFactory(follow_redirects, validate_certs, ca_file)

    # String tests

# Generated at 2022-06-20 21:15:39.212423
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    # test the get_ca_certs method of the SSLValidationHandler class
    # returns tuple of (cafile, cadata, paths_checked)

    # test 1: no ca file, no cadata.  no paths checked
    handler = SSLValidationHandler('test.com', 443)
    cafile, cadata, paths_checked = handler.get_ca_certs()
    assert cafile == None
    assert len(cadata) == 0
    assert len(paths_checked) == 0

    # test 2: no ca file provided, but there is cadata and paths_checked
    handler = SSLValidationHandler('test.com', 443)
    cafile, cadata, paths_checked = handler.get_ca_certs()
    assert cafile == None
    assert len(cadata) == 0

# Generated at 2022-06-20 21:17:20.008060
# Unit test for function generic_urlparse
def test_generic_urlparse():
    '''Test the generic_urlparse function'''
    # Simple success cases
    parts = urlparse.urlparse('https://www.redhat.com')
    assert generic_urlparse(parts) == {
        'scheme': 'https',
        'netloc': 'www.redhat.com',
        'path': '',
        'params': '',
        'query': '',
        'fragment': '',
        'username': None,
        'password': None,
        'hostname': 'www.redhat.com',
        'port': None,
    }
    parts = urlparse.urlparse('https://www.redhat.com/')

# Generated at 2022-06-20 21:17:24.049144
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        conn = UnixHTTPSConnection('/tmp/httpsock')
        conn.connect()
        assert conn.sock is not None

    conn = UnixHTTPSConnection('/tmp/httpsock')
    with pytest.raises(socket.error):
        conn.connect()
        assert conn.sock is None

    class SubUnixHTTPSConnection(UnixHTTPSConnection):
        @classmethod
        def connect(cls):
            pass
    # Super should still connect after the classmethod is replaced, because
    # the classmethod was patched while in the contextmanager
    conn = SubUnixHTTPSConnection('/tmp/httpsock')
    conn.connect()
    assert conn.sock is not None



# Generated at 2022-06-20 21:17:31.433727
# Unit test for method put of class Request
def test_Request_put():
    r = Request( 'https://api.github.com')
    res = r.put('/user', data = {'name':'Micheal', 'password':'fakepassword'})
    assert res.status_code == 200
    assert res.get_data().decode() == '{"message":"Validation Failed","errors":[{"resource":"User","field":"login","code":"missing_field"}]}'


# Generated at 2022-06-20 21:17:35.919664
# Unit test for method get_ca_certs of class SSLValidationHandler

# Generated at 2022-06-20 21:17:37.037895
# Unit test for method options of class Request
def test_Request_options():
    request= Request()
    print(dir(request))
    print(request.options('https://www.baidu.com'))

# Generated at 2022-06-20 21:17:38.211912
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile() as temp:
        atexit_remove_file(temp.name)
        assert not os.path.exists(temp.name)



# Generated at 2022-06-20 21:17:46.140989
# Unit test for function open_url
def test_open_url():
    import base64
    # import the urllib2 module to make requests
    import urllib.request, urllib.error, urllib.parse
    import urllib.parse

    # create HTTPBasicAuthHandler
    passman = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    # Add username and password using HTTPBasicAuthHandler
    passman.add_password(None, 'https://httpbin.org', 'wzp', '123456')
    authhandler = urllib.request.HTTPBasicAuthHandler(passman)

    # create the cookiejar
    jar = urllib.request.CookieJar()

    # install the cookiejar
    opener = urllib.request.build_opener(authhandler, urllib.request.HTTPCookieProcessor(jar))

    # add some headers

# Generated at 2022-06-20 21:17:47.682452
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    o = UnixHTTPConnection('/tmp/unixsocket')
    assert o._unix_socket == '/tmp/unixsocket', o._unix_socket

#
# Public functions
#



# Generated at 2022-06-20 21:17:51.224109
# Unit test for method head of class Request
def test_Request_head():
    # create an instance of the class
    request = Request("https://www.host.com/",connect_timeout=120,validate_certs=False)
    # send a request and return a response
    response = request.head("https://www.host.com/")
    # check if the request returned a HTTP Response Code 200
    if response.getcode() == "200":
        # print the response body and response code
        log("Response Code:",response.getcode(),"Response Body:","".join([chr(ch) for ch in response.read()]))
    else:
        # print the HTTP Response Code
        log("Response Code:",response.getcode())

# Generated at 2022-06-20 21:17:59.549618
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    ans = ['scheme', 'netloc', 'path', 'params', 'query', 'fragment']
    assert [k for k in ParseResultDottedDict()] == ans
    assert ParseResultDottedDict().as_list() == ans
    assert ParseResultDottedDict(a='a').as_list() == ans
    assert ParseResultDottedDict(a='a', path='path').as_list() == [None, None, 'path', None, None, None]
    assert ParseResultDottedDict(a='a', path='path', query='query').as_list() == [None, None, 'path', None, 'query', None]
