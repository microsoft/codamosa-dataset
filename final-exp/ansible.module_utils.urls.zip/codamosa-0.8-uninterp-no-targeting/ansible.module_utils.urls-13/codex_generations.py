

# Generated at 2022-06-20 21:13:19.608347
# Unit test for method get of class Request
def test_Request_get():
    request = Request(1,2,3)
    response = request.get('https://jsonplaceholder.typicode.com/todos/1')
    global json_todo
    json_todo = json.load(response)
    assert isinstance(response, HTTPResponse)
    
    

# Generated at 2022-06-20 21:13:26.116739
# Unit test for function fetch_url
def test_fetch_url():
    url_spec = url_argument_spec()
    url_spec['url']['default'] = 'http://example.com'

    module = AnsibleModule(
        argument_spec=url_spec,
        supports_check_mode=True,
    )

    url = module.params.get('url')
    _resp, info = fetch_url(module, url, use_proxy=False)

    result = {}
    result.update(info)
    result.update(module.params)
    module.exit_json(**result)


#
# MIME related functions
#



# Generated at 2022-06-20 21:13:35.917066
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """
    Test the get_sha256_fingerprint function with various types of data.
    """

# Generated at 2022-06-20 21:13:43.521773
# Unit test for function open_url
def test_open_url():
    # Let's assume we have a web server locally that
    # returns HTTP 200 with a content of 'SUCCESS'
    url = urlparse('http://localhost:9000/')
    resp = open_url(url)
    assert resp.getcode() == 200
    assert resp.read().decode() == 'SUCCESS'



# Generated at 2022-06-20 21:13:55.939154
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    import traceback
    try:
        from foo import bar
    except ImportError as e:
        tb = sys.exc_info()[2]

    try:
        raise MissingModuleError('foo', tb)
    except MissingModuleError as e:
        msg = str(e)
        tb = e.import_traceback
        expected_msg = "foo\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):"
        assert msg.startswith(expected_msg)
        assert tb is not None

    # Verify that the traceback is formatted and information is preserved
    frames = [frame for frame in traceback.extract_tb(tb)]
    assert len(frames) == 3
    assert frames[0][0] == __file__
    assert frames

# Generated at 2022-06-20 21:13:56.702238
# Unit test for function fetch_url
def test_fetch_url():
    url_url_module()



# Generated at 2022-06-20 21:14:02.603073
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    import subprocess
    try:
        # First, check whether we can run the command.
        # The command may not be present on all operating systems.
        subprocess.check_call(['which', 'socat'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except (subprocess.CalledProcessError, OSError):
        # skip test
        return

    # Start a local https server
    p = subprocess.Popen(["socat", "OPENSSL-LISTEN:443,reuseaddr,fork,cert=tests/data/faux_cert.pem", "SYSTEM:cat"],
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)

# Generated at 2022-06-20 21:14:08.015654
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    prdd = ParseResultDottedDict({'scheme': 'http', 'query': 'id=1', 'path': '/'})
    return prdd.as_list() == ['http', None, '/', None, 'id=1', None]

# Generated at 2022-06-20 21:14:12.467198
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    with patch('ansible.module_utils.urls.CustomHTTPSConnection') as mock_CustomHTTPSConnection:
        with patch('ansible.module_utils.urls.AbstractHTTPHandler') as mock_AbstractHTTPHandler:
            mock_AbstractHTTPHandler.do_request_.__name__ = 'do_request_'
            urlopen_kwargs = {'some_kwarg': 'some_value'}
            req = "some_request"
            proxy_handler = Mock()
            target = CustomHTTPSHandler(proxy_handler=proxy_handler)
            call_list = [
                call("some_kwarg", "some_value"),
                call("keyfile", None),
                call("certfile", None),
                call("ssl_version", None),
                call("server_hostname", None)]

# Generated at 2022-06-20 21:14:16.387424
# Unit test for method options of class Request
def test_Request_options():
    request = Request()
    assert isinstance(request.options('/api/v1/'), HTTPResponse)


# Generated at 2022-06-20 21:15:07.097189
# Unit test for method head of class Request
def test_Request_head():
    try:
        import requests
    except ImportError:
        _skip_if_not_import('requests', '<2.21.0')
        return
    import requests
    in_vars = dict(url='https://www.baidu.com')
    out_vars = dict(headers={'content-type': 'text/html'})
    request = Request()
    response = request.head(in_vars['url'])
    assert response.headers['content-type'] == out_vars['headers']['content-type']


# Generated at 2022-06-20 21:15:16.257399
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    import ssl
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    host, port = sock.getsockname()
    ssl_sock = ssl.wrap_socket(sock, keyfile=CERT_FILE, certfile=KEY_FILE)
    ssl_sock.listen(1)

    base_url = 'https://%s:%s' % (host, port)
    last_req = None
    def handle_req(*args, **kwargs):
      global last_req
      last_req = args[1]
      return args, kwargs

    hac = HTTPSClientAuthHandler(CERT_FILE, KEY_FILE)
    hac.do_open = handle_req


# Generated at 2022-06-20 21:15:21.921960
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    _connect = httplib.HTTPConnection.connect
    with unix_socket_patch_httpconnection_connect():
        assert httplib.HTTPConnection.connect == UnixHTTPConnection.connect
    assert httplib.HTTPConnection.connect == _connect

    @contextmanager
    def unix_socket_patch_httpconnection_connect():
        '''Monkey patch ``httplib.HTTPConnection.connect`` to be ``UnixHTTPConnection.connect``
        so that when calling ``super(UnixHTTPSConnection, self).connect()`` we get the
        correct behavior of creating self.sock for the unix socket
        '''
        _connect = httplib.HTTPConnection.connect
        httplib.HTTPConnection.connect = UnixHTTPConnection.connect
        yield
        httplib.HTTPConnection.connect = _connect


# Generated at 2022-06-20 21:15:27.864042
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    with patch('ansible.module_utils.urls.CustomHTTPSConnection') as conn:
        req = "request"
        handler = CustomHTTPSHandler()
        handler.do_open = Mock()
        handler.do_open.return_value = "response"
        assert handler.https_open(req) == handler.do_open.return_value
        handler.do_open.assert_called_once_with(conn, req)

# Generated at 2022-06-20 21:15:38.945074
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    try:
        import http.client as http_client
    except ImportError:
        import httplib as http_client
    http_client.HTTPConnection.debuglevel = 1

    logging.basicConfig()  # you need to initialize logging, otherwise you will not see anything from requests
    logging.getLogger().setLevel(logging.DEBUG)
    requests_log = logging.getLogger("requests.packages.urllib3")
    requests_log.setLevel(logging.DEBUG)
    requests_log.propagate = True

    valid_handler = SSLValidationHandler('urllib3.readthedocs.io', 443)
    request = Request('https://urllib3.readthedocs.io')

# Generated at 2022-06-20 21:15:41.624721
# Unit test for method get of class Request
def test_Request_get():
    from ansible.utils.urls import open_url
    url = "https://www.google.com"
    resp = open_url(url, method='GET')
    return resp


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    print(test_Request_get())

# Generated at 2022-06-20 21:15:50.380124
# Unit test for method get of class Request
def test_Request_get():
    """
    Method get of class Request unit test stub.
    """
    if not is_playbook_executing():
        return
    response = Requests.get(url="http://192.168.1.1/index.html")
    if response.status_code == 200:
        print(response.content)
    else:
        print(response.status_code, response.reason)


# Generated at 2022-06-20 21:15:53.202786
# Unit test for method get of class Request
def test_Request_get():
    # Initialize class
    request = Request()
    # Set parameters
    url = 'test_value_1'
    # Execute method
    result = request.get(url)
    # Verify expected result
    assert result is not None

# Generated at 2022-06-20 21:16:08.045198
# Unit test for method open of class Request
def test_Request_open():
    url = 'https://www.google.com/'
    req = Request()
    resp = req.open(url, method='GET')
    assert resp.code == 200
    resp = req.get(url)
    assert resp.code == 200
    resp = req.options(url)
    assert resp.code == 200
    resp = req.head(url)
    assert resp.code == 200
    resp = req.post(url)
    assert resp.code == 405
    resp = req.put(url)
    assert resp.code == 405
    resp = req.patch(url)
    assert resp.code == 405
    resp = req.delete(url)
    assert resp.code == 405

# Generated at 2022-06-20 21:16:11.540620
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('myproxy.example.com', 8080)
    except ProxyError as e:
        assert e.proxy == "myproxy.example.com:8080"
    else:
        assert False



# Generated at 2022-06-20 21:17:42.674802
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():

    # param url: url string
    url_str = 'https://www.google.com'
    # param validate_certs: bool value
    bool_val = True
    # param ca_path: ca path string
    ca_path_str = '/path/to/ca/dir'
    return maybe_add_ssl_handler(url_str, bool_val, ca_path=ca_path_str)


# Generated at 2022-06-20 21:17:44.223284
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    assert UnixHTTPConnection(None)("")


# Generated at 2022-06-20 21:17:55.789757
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    # If a function called in a with clause throws an exception, the code
    # block after with will still be executed. So, if the test case below
    # passes, it means that the code block after with is executed.
    # Change None to any non-None value if you want to see how it goes if
    # UnixHTTPConnection.connect throws an exception.
    unix_http_connection_connect_return_value = None
    unix_http_connection_connect_side_effect = None
    unix_http_connection_connect_original = UnixHTTPConnection.connect
    class MyException(Exception):
        pass

# Generated at 2022-06-20 21:17:57.252716
# Unit test for method patch of class Request
def test_Request_patch():
    r = Request()
    url = "http://www.google.com"
    data = json.dumps({})
    r.patch(url,data)

test_Request_patch()
 

# Generated at 2022-06-20 21:18:05.165560
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    """
    Tests for rfc2822_date_string
    """

# Generated at 2022-06-20 21:18:11.867580
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    # We can't test this method as is because we have no server to test against
    # BUT we can test that it is present and has a context attribute as expected
    conn = CustomHTTPSConnection('localhost', 443)
    assert hasattr(conn, 'context')

if CustomHTTPSConnection is not None:
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            # Divergence: Split host and port into separate args for Python >= 2.6
            return self.do_open(CustomHTTPSConnection, req)

    # Unit tests for class CustomHTTPSHandler
    def test_CustomHTTPSHandler():
        url = "https://google.com/"
        handler = CustomHTTPSHandler()
        opener = urllib_request.build_opener(handler)
        req = urll

# Generated at 2022-06-20 21:18:15.886694
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    import tempfile
    from errno import ECONNREFUSED
    from os import remove
    UNIX_SOCKET_FILE = tempfile.mktemp()
    with open(UNIX_SOCKET_FILE, 'w'):
        pass
    try:
        with pytest.raises(OSError) as execinfo:
            # ECONNREFUSED means no process is listening on the socket
            unix_conn = UnixHTTPConnection(UNIX_SOCKET_FILE)
            unix_conn.connect()
        exc = execinfo.value
        assert exc.errno == ECONNREFUSED
    finally:
        remove(UNIX_SOCKET_FILE)


# Generated at 2022-06-20 21:18:24.727761
# Unit test for constructor of class Request
def test_Request():
    req = Request(url='http://google.com', orig_url='http://google.com',
                  real_url='http://google.com', method='GET',
                  select_timeout=1, connect_timeout=1, read_timeout=1,
                  headers={}, data=None, body=None, redirect_chain=[],
                  orig_body=None, last_mod_time=None)

    assert req.url == 'http://google.com'
    assert req.orig_url == 'http://google.com'
    assert req.real_url == 'http://google.com'
    assert req.method == 'GET'
    assert req.select_timeout == 1
    assert req.connect_timeout == 1
    assert req.read_timeout == 1
    assert req.headers == {}
    assert req.data is None
    assert req

# Generated at 2022-06-20 21:18:31.119519
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    with tempfile.NamedTemporaryFile() as temp:
        # Test -1 (no exception)
        atexit_remove_file(temp.name)
        assert not os.path.exists(temp.name)

        # Test -2 (exception)
        atexit_remove_file(temp.name)
        assert not os.path.exists(temp.name)



# Generated at 2022-06-20 21:18:34.752004
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    hostname = 'www.example.com'
    port = 443
    ca_path = '../test/test_data/test_cert.pem'

    handler = SSLValidationHandler(hostname, port, ca_path)

    import urllib.request
    req = urllib.request.Request('https://%s' % hostname)
    handler.http_request(req)
