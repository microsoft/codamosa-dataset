

# Generated at 2022-06-20 21:15:43.038458
# Unit test for method put of class Request
def test_Request_put():
    url = "/v1/branch"
    data = {
        "branch_name": "test",
        "catalog_id": "5da9615c74f40bc2a8b8a2d2",
        "domain_id": "5da91d3d74f40b6c0fce1d78"
    }

# Generated at 2022-06-20 21:15:50.777150
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    req = RequestWithMethod('https://example.com/', None)
    assert req.get_method() == 'GET'

    req = RequestWithMethod('https://example.com/', 'get')
    assert req.get_method() == 'GET'

    req = RequestWithMethod('https://example.com/', 'POST')
    assert req.get_method() == 'POST'



# Generated at 2022-06-20 21:15:56.590995
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        c = httplib.HTTPConnection('/path/to/unix/socket')
        assert isinstance(c.sock, socket.socket)

    c = httplib.HTTPConnection('hostname')
    assert c.sock is None
    c.connect()
    assert isinstance(c.sock, socket.socket)


if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
    class UnixHTTPSConnection(CustomHTTPSConnection):
        '''Class to allow HTTPS requests via Unix sockets
        '''

        default_port = None


# Generated at 2022-06-20 21:16:02.688489
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    try:
        reload(urllib_request)
    except NameError as e:
        import importlib
        importlib.reload(urllib_request)
    finally:
        reload(urllib_request)
    import urllib2
    urllib2.Request = RequestWithMethod

    class myrequest(urllib2.Request):
        def __init__(self, url, method='PUT', data=None, headers=None, origin_req_host=None, unverifiable=True):
            urllib2.Request.__init__(self, url, data, headers, origin_req_host, unverifiable)
            self._method = method.upper()

        def get_method(self):
            if self._method:
                return self._method
            else:
                return urllib2.Request

# Generated at 2022-06-20 21:16:06.197268
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    e = NoSSLError('foo')
    # Divergence: Python 3 raises a TypeError if a string is passed.
    if is_py3:
        assert('foo' == str(e))
    else:
        assert('foo' == e)



# Generated at 2022-06-20 21:16:07.752249
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    err = NoSSLError()
    assert isinstance(err, SSLValidationError)



# Generated at 2022-06-20 21:16:12.180878
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    ul = urllib_request.HTTPSHandler();
    assert issubclass(HTTPSClientAuthHandler, urllib_request.HTTPSHandler) == True
# End of unit test for method https_open of class HTTPSClientAuthHandler

if hasattr(socket, 'AF_UNIX'):
    class UnixHTTPConnection(httplib.HTTPConnection):
        '''HTTPConnection subclass that connects to a unix socket'''
        def __init__(self, unix_socket, *args, **kwargs):
            self._unix_socket = unix_socket
            httplib.HTTPConnection.__init__(self, 'localhost', timeout=2, *args, **kwargs)

        def connect(self):
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self

# Generated at 2022-06-20 21:16:23.279132
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    from ansible.utils.unicode import to_unicode
    # This could generate a deprecation warning on Python 3.4+ for the to_unicode call
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        nssl_err = NoSSLError()
        if sys.version_info < (3,):
            assert to_native(nssl_err.message) == to_native('No SSL library available to validate the certificate')
        else:
            assert to_native(nssl_err.args[0]) == to_native('No SSL library available to validate the certificate')



# Generated at 2022-06-20 21:16:29.906850
# Unit test for method open of class Request
def test_Request_open():
    r"""
    request.open(method='GET', url='https://docs.ansible.com/ansible/latest/dev_guide/developing_api.html')
    """

    request = Request()
    request.open(method='GET', url='https://docs.ansible.com/ansible/latest/dev_guide/developing_api.html')


# Generated at 2022-06-20 21:16:34.891907
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    e = ConnectionError()
    assert str(e) == ''
    e = ConnectionError('test')
    assert str(e) == 'test'



# Generated at 2022-06-20 21:17:59.804952
# Unit test for function url_argument_spec
def test_url_argument_spec():
    """Tests that url_argument_spec generates the expected argument spec"""
    arg_spec = url_argument_spec()

    assert arg_spec['url']['type'] == 'str'
    assert arg_spec['force']['type'] == 'bool'
    assert arg_spec['force']['default'] is False
    assert isinstance(arg_spec['force']['aliases'], list)
    assert 'thirsty' in arg_spec['force']['aliases']
    assert isinstance(arg_spec['force']['deprecated_aliases'], list)
    assert isinstance(arg_spec['force']['deprecated_aliases'][0], dict)
    assert arg_spec['force']['deprecated_aliases'][0]['name'] == 'thirsty'

# Generated at 2022-06-20 21:18:06.388828
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
	return True

if hasattr(urllib_request, 'HTTPSHandler') and hasattr(ssl, 'SSLContext') and hasattr(urllib_request, 'HTTPCookieProcessor'):
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            context = None

# Generated at 2022-06-20 21:18:18.058797
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    from ansible.utils.path import unfrackpath

    # Test with correct CA certificate
    url = "https://www.verisign.com/"
    hostname = "www.verisign.com"
    port = 443
    ca_path = unfrackpath("/etc/ssl/certs/ca-certificates.crt")
    handler = urllib_request.HTTPSHandler(debuglevel=0)
    opener = urllib_request.build_opener(handler, SSLValidationHandler(hostname, port, ca_path))
    try:
        opener.open(url)
    except urllib_error.HTTPError as e:
        if e.code != 200:
            raise
    except urllib_error.URLError as e:
        raise

# Generated at 2022-06-20 21:18:23.040315
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    import tempfile
    file1 = tempfile.NamedTemporaryFile(delete=False)
    atexit_remove_file(file1.name)
    assert not os.path.exists(file1.name)



# Generated at 2022-06-20 21:18:28.744624
# Unit test for method delete of class Request
def test_Request_delete():
    assert Request().delete('lalala', use_proxy=None) == Request().open('DELETE', 'lalala')

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 21:18:38.708749
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    # pylint: disable=E1121
    if not hasattr(socket, 'ssl'):
        try:
            raise NoSSLError()
        except NoSSLError as e:
            assert e.args[0] in ("SSL certificate validation is not available on this platform",
                                 "You need to install 'pyOpenSSL' module to validate certificates.")
    else:
        try:
            raise NoSSLError()
        except NoSSLError as e:
            assert e.args[0] == "You need to install 'pyOpenSSL' module to validate certificates."



# Generated at 2022-06-20 21:18:43.295463
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''Ensure that UnixHTTPSConnection will return an instance of a UnixHTTPConnection'''
    assert UnixHTTPSConnection('/var/run/docker.sock')



# Generated at 2022-06-20 21:18:49.220006
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    conn = UnixHTTPConnection(unix_socket='/tmp/foo')
    conn.connect()
    assert conn.sock
    assert conn.sock.timeout == socket._GLOBAL_DEFAULT_TIMEOUT
    conn = UnixHTTPConnection(unix_socket='/tmp/foo', timeout=10)
    conn.connect()
    assert conn.sock.timeout == 10



# Generated at 2022-06-20 21:18:54.710785
# Unit test for function fetch_file
def test_fetch_file():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import sys
    import urllib3
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={
        "url": dict(),
        "force": dict(),
        "http_agent": dict(),
        "use_proxy": dict(),
        "validate_certs": dict(),
        "url_username": dict(),
        "url_password": dict(),
        "force_basic_auth": dict(),
        "client_cert": dict(),
        "client_key": dict(),
        "use_gssapi": dict(),
    })
    # Mock the method to be tested
    mocker = mock.Mock()