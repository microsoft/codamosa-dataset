

# Generated at 2022-06-20 21:13:58.202921
# Unit test for function fetch_file
def test_fetch_file():
    failed = True
    try:
        module = object()
        module.add_cleanup_file = lambda x: False
        module.params = {'url_username': '', 'force_basic_auth': '', 'url_password': '',
                         'use_proxy': True, 'client_key': '', 'follow_redirects': 'urllib2', 'client_cert': '',
                         'http_agent': 'ansible-httpget', 'use_gssapi': False}
        url = 'https://github.com/ansible/ansible/archive/stable-2.2.zip'
        fetch_file(module, url)
        failed = False
    except Exception as e:
        pass
    assert not failed



# Generated at 2022-06-20 21:13:59.109064
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error = ConnectionError('nonsense')
    assert error.args == ('nonsense',)


# Generated at 2022-06-20 21:14:04.340714
# Unit test for function generic_urlparse

# Generated at 2022-06-20 21:14:15.255494
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''Test the build_ssl_validation_error function
    '''

    # This is an ugly hack to get coverage to register that we have
    # actually covered the SSLValidationError fallback
    global HAS_SSLCONTEXT
    global HAS_URLLIB3_PYOPENSSLCONTEXT
    global HAS_URLLIB3_SSL_WRAP_SOCKET
    global HAS_URLLIB3
    HAS_SSLCONTEXT = False
    HAS_URLLIB3_PYOPENSSLCONTEXT = False
    HAS_URLLIB3_SSL_WRAP_SOCKET = False
    HAS_URLLIB3 = False

    with pytest.raises(SSLValidationError) as exc:
        build_ssl_validation_error('example.com', 443, [])

# Generated at 2022-06-20 21:14:18.268513
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    try:
        import foo
    except ImportError as e:
        mme = MissingModuleError('This is a test', traceback.format_exc())
        import_traceback = str(mme).split(': ', 1)[1]
        expected_answer = str(e).split(': ', 1)[0]
        assert import_traceback == expected_answer, 'Traceback from MissingModuleError not as expected'

# This helper function can be used to catch and log exceptions in a way that the unit test
# will still fail properly.

# Generated at 2022-06-20 21:14:28.636678
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
  # Testcase with default values
  url='https://localhost/'
  req=HTTPRequest(url)
  handler=SSLValidationHandler('localhost',443)
  assert_equals(handler.detect_no_proxy(url),False)

  # Testcase for no_proxy variable set with direct hostname
  os.environ['no_proxy']='localhost'
  assert_equals(handler.detect_no_proxy(url),False)

  # Testcase for no_proxy variable set with ip and port
  os.environ['no_proxy']='127.0.0.1:443'
  assert_equals(handler.detect_no_proxy(url),False)

  # Testcase for no_proxy variable set with port
  os.environ['no_proxy']='127.0.0.1:443'

# Generated at 2022-06-20 21:14:33.622316
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    a_dict = ParseResultDottedDict(scheme='http', netloc='www.google.com', path='/x/y/z', params='', query='', fragment='')
    assert a_dict.scheme == 'http'
    assert a_dict.netloc == 'www.google.com'
    assert a_dict.path == '/x/y/z'
    assert a_dict.params == ''
    assert a_dict.query == ''
    assert a_dict.fragment == ''
    assert a_dict.as_list() == ['http', 'www.google.com', '/x/y/z', '', '', '']
    a_dict.scheme = 'https'
    assert a_dict.scheme == 'https'

# Generated at 2022-06-20 21:14:39.998720
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """
    This function tests get_channel_binding_cert_hash. It does not assume that the
    cryptography module is installed.
    """
    # Creates the test certificate based on the sample certificate used in the
    # section 4 of RFC 5929.

# Generated at 2022-06-20 21:14:42.950524
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    '''Unit test for constructor of class UnixHTTPHandler

    Passes if the constructor throws no exceptions.
    '''
    UnixHTTPHandler(**{'unix_socket': '/path/to/unix/socket.sock'})



# Generated at 2022-06-20 21:14:56.430773
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    try:
        HTTPSClientAuthHandler(client_cert='/foo')
    except TypeError:
        # No self
        pass
    try:
        HTTPSClientAuthHandler(client_cert='/foo', client_key='/bar')
    except TypeError:
        # No self
        pass


if hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler'):
    if HAS_SSLCONTEXT:
        class UnixHTTPSConnection(httplib.HTTPSConnection):
            """Unix socket-based HTTPS connection class."""

            def __init__(self, unix_socket=None, context=None, **kwargs):
                kwargs['context'] = context

# Generated at 2022-06-20 21:15:38.381276
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    conn = UnixHTTPSConnection('/var/lib/libvirt/libvirt-sock')
    # conn must be an instance of UnixHTTPSConnection, not an instance of httplib.HTTPSConnection
    assert isinstance(conn, UnixHTTPSConnection)

#
# Class for return of url_request and url_transfer_json
#



# Generated at 2022-06-20 21:15:47.839523
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():
    from ansible.module_utils.urls import SSLValidationHandler, ProxyError

    # test case 1: url in 'no_proxy' environment variable
    os.environ['no_proxy'] = 'example.com'
    handler = SSLValidationHandler('example.com', 443)
    assert handler.detect_no_proxy('https://example.com/') is False
    os.environ['no_proxy'] = ''

    # test case 2: url not in 'no_proxy' environment variable
    os.environ['no_proxy'] = 'google.com'
    handler = SSLValidationHandler('example.com', 443)
    assert handler.detect_no_proxy('https://example.com/') is True
    os.environ['no_proxy'] = ''

    # test case 3: 'no_proxy' environment variable is

# Generated at 2022-06-20 21:15:56.995821
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    import textwrap

# Generated at 2022-06-20 21:16:08.638016
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    pass

# Generated at 2022-06-20 21:16:13.992536
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    sh = SSLValidationHandler('foo', 123)
    # test for cafile and cadata = None
    context = sh.make_context(None, None)
    assert context

    # test for cafile and cadata = ''
    context = sh.make_context('', '')
    assert context

    # test for cafile = '' and cadata = None
    context = sh.make_context('', None)
    assert context

    # test for cafile = None and cadata = ''
    context = sh.make_context(None, '')
    assert context



# Generated at 2022-06-20 21:16:17.937053
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    kwargs = {'key_file': '', 'cert_file': ''}
    try:
        kwargs['context'] = ssl._create_default_https_context()
    except AttributeError:
        kwargs['context'] = ssl.create_default_context()
    conn = UnixHTTPSConnection('')("", **kwargs)
    conn.endheaders() #issue where socket isn't created until this is called
    conn.sock.fileno() # ensure socket is actually created

#
# Module utils
#



# Generated at 2022-06-20 21:16:22.174798
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    # Test with all the valid code
    code_list = [200]
    # Test with valid code and creating a bad response with it
    response = b"HTTP/1.1 " + to_bytes(str(code_list[0]), errors='surrogate_or_strict') + b" BAD_CODE"
    try:
        SSLValidationHandler.validate_proxy_response(SSLValidationHandler, response, code_list)
    except Exception:
        raise Exception("Unexpected failure to validate proxy response, with proper code")
    # Test with invalid code
    code_list = [201]
    # Test with invalid code and creating a bad response with it

# Generated at 2022-06-20 21:16:24.222537
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    assert rfc2822_date_string(time.gmtime()) == \
        'Mon, 08 May 2017 00:33:46 -0000'



# Generated at 2022-06-20 21:16:30.654827
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    class CustomHTTPSHandlerTest(CustomHTTPSHandler):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    # If we don't pass any arguments, we should get an empty list
    # for args, and an empty dict for kwargs
    handler = CustomHTTPSHandlerTest()
    assert handler.args == ()
    assert handler.kwargs == {}
    # If we pass in "foo" and "bar" as arguments, we should get a tuple
    # with those same values, and an empty dict
    handler = CustomHTTPSHandlerTest("foo", "bar",)
    assert handler.args == ("foo", "bar")
    assert handler.kwargs == {}
    # If we pass in "foo" and "bar" as keyword arguments, we should get
   

# Generated at 2022-06-20 21:16:39.586556
# Unit test for function open_url
def test_open_url():
    class Request:
        def __call__(self, *args, **kwargs):
            return Mock()

    with patch.dict(os.environ, {'http_proxy': 'test'}):
        r = open_url('test', use_proxy=False)

    with patch('ansible.module_utils.urls.Request') as Request:
        r = open_url('test')

    assert Request.call_count == 2



# Generated at 2022-06-20 21:17:30.424141
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    # create a fake request
    uri = 'https://foo.bar.baz'
    req = urllib_request.Request(uri)
    # create a fake connection class
    class FakeConnection(object):
        def __init__(self, host, context):
            self.host = host
            self.context = context
        def __call__(self, *args, **kwargs):
            return self
    # set up HTTPSClientAuthHandler
    class FakeClientAuthHandler(HTTPSClientAuthHandler):
        def __init__(self):
            self.client_cert = 'client_cert'
            self.client_key = 'client_key'
        def _build_https_connection(self, host, **kwargs):
            kwargs['client_cert'] = self.client_cert

# Generated at 2022-06-20 21:17:32.692717
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    hostname = 'www.google.com'
    port = 443
    ca_path = '/etc/ansible'
    handler = SSLValidationHandler(hostname, port, ca_path)



# Generated at 2022-06-20 21:17:37.867303
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest

    class TestRedirectHandlerFactory(unittest.TestCase):
        def test_follow_redirects(self):
            handler = RedirectHandlerFactory('all')()
            self.assertIsNot(handler.redirect_request, urllib_request.HTTPRedirectHandler.redirect_request)
            handler = RedirectHandlerFactory('no')()
            self.assertIsNot(handler.redirect_request, urllib_request.HTTPRedirectHandler.redirect_request)
            handler = RedirectHandlerFactory('safe')()
            self.assertIsNot(handler.redirect_request, urllib_request.HTTPRedirectHandler.redirect_request)
            handler = RedirectHandlerFactory('urllib2')()

# Generated at 2022-06-20 21:17:42.199833
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    conn = UnixHTTPSConnection('/var/run/docker.sock')
    assert conn._unix_socket is not None
    assert conn._unix_socket == '/var/run/docker.sock'
    assert conn.host is None


# The no_proxy list is a set of domain names for which we should bypass the proxy
# and connect directly to the remote host.
# The list should be in lower case.
no_proxy = set()

# If we have urllib3 installed, enable it by default.
# Users can disable it with the ANSIBLE_DISABLE_URLLIB3 environment
# variable.
if HAS_URLLIB3:
    if os.environ.get('ANSIBLE_DISABLE_URLLIB3', False):
        disable_urllib3 = True
    else:
        disable_urll

# Generated at 2022-06-20 21:17:46.939575
# Unit test for method post of class Request
def test_Request_post():

    # Arrange
    url = "http://127.0.0.1:8080/test_get"
    data = None
    use_proxy = None
    headers = None
    last_mod_time = None
    timeout = None
    validate_certs = None
    url_username = None
    url_password = None
    http_agent = None
    force_basic_auth = None
    follow_redirects = None
    client_cert = None
    client_key = None
    cookies = None
    unix_socket = None
    ca_path = None
    unredirected_headers = None
    method = 'POST'
    self = Request()

    # Act
    # HTTPresponse = self.open('POST', url, data=data, use_proxy=use_proxy,
    #                          last_mod

# Generated at 2022-06-20 21:17:56.365202
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    unix_socket = '/unix/socket/path'
    connection = UnixHTTPSConnection(unix_socket)
    with mock.patch('httplib.socket') as mocked_socket:
        with mock.patch('httplib.HTTPConnection.connect') as mocked_connection_connect:
            try:
                connection.connect()
            except AttributeError:
                pass  # Normal behavior when running the unit tests
            assert mocked_socket.socket.call_count == 1
            assert mocked_socket.socket.call_args == mock.call(socket.AF_UNIX, socket.SOCK_STREAM)
            assert mocked_connection_connect.call_count == 1


#
# HTTP
#


# Generated at 2022-06-20 21:18:04.560656
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    url = 'https://pypi.python.org/pypi/ansible'
    h = SSLValidationHandler(urlparse(url).hostname, 443, None)
    tmp_ca_path, cadata, paths_checked = h.get_ca_certs()
    assert paths_checked == ['~/.ansible/tmp/ansible-tmp-1460456534.25-236337349263643', '/etc/ssl/certs', '/etc/pki/ca-trust/extracted/pem', '/etc/pki/tls/certs', '/usr/share/ca-certificates/cacert.org', '/usr/local/share/certs', '/etc/openssl', '/etc/ansible']

    url = 'http://google.com'

# Generated at 2022-06-20 21:18:07.853619
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    """
    Unit test for constructor of class RequestWithMethod
    """
    try:
        request = RequestWithMethod("http://example.com", "PUT", "This is data.")
        assert request.get_method() == "PUT"
        assert request.get_full_url() == "http://example.com"
        assert request.get_data() == "This is data."
        assert request.get_host() == "example.com"
        assert request.get_selector() == ""
    except AttributeError:
        return False
    else:
        return True


# Generated at 2022-06-20 21:18:19.421872
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    host = 'www.google.com'
    client_cert = './test.pem'
    client_key = './test.key'
    handler = HTTPSClientAuthHandler(client_cert=client_cert, client_key=client_key)
    req = urllib_request.Request('https://' + host)
    https_open = handler.https_open(req)
    assert isinstance(https_open,CustomHTTPSConnection)
    assert https_open.cert_file == client_cert
    assert https_open.key_file == client_key

# Some environments (Google Compute Engine's CoreOS deploys) do not compile
# against openssl and thus do not have any HTTPS support.

# Generated at 2022-06-20 21:18:31.767530
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    # test_get_method with default method
    request = RequestWithMethod(url=None, method=None, data=None, headers=None, origin_req_host=None, unverifiable=True)
    method = request.get_method()
    assert (method == request._method)

    # test_get_method with defined method
    request = RequestWithMethod(url=None, method='someMethod', data=None, headers=None, origin_req_host=None, unverifiable=True)
    method = request.get_method()
    assert (method == 'SOMEMETHOD')
