

# Generated at 2022-06-20 21:12:04.600188
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.parsing.vault import VaultLib

    vault_pass_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'utils/ansible-vault-password')
    vault_pass = open(vault_pass_file).read()
    vault = VaultLib(vault_pass)

    vault_url = "https://vault.example.com/vault/file.yml"
    vault_url.replace('.yml', '.vault.yml')
    connection = Connection(vault_url)
    with open(vault_url.replace('.yml', '.vault.yml')) as f:
        encrypted_data = vault.decrypt(f.read())


# Generated at 2022-06-20 21:12:06.796369
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError('foo')
    except SSLValidationError as e:
        assert 'foo' in to_native(str(e))



# Generated at 2022-06-20 21:12:17.006278
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    class RequestWithMethod(urllib_request.Request):
        def __init__(self, *args, **kwargs):
            self._method = kwargs.pop('method', None)
            self._redirect_response = kwargs.pop('redirect_response', None)
            urllib_request.Request.__init__(self, *args, **kwargs)

        def get_method(self):
            if self._method:
                return self._method
            else:
                if self._redirect_response:
                    return 'GET'
                else:
                    return urllib_request.Request.get_method(self)

    # setup request
    http_proxy = "http://127.0.0.1:3128"
    url = "https://www.google.com"

# Generated at 2022-06-20 21:12:20.865998
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule({})
    assert fetch_file(module, "https://raw.githubusercontent.com/ansible/ansible/devel/test/test_http.py")

#
# Main function
#



# Generated at 2022-06-20 21:12:22.960023
# Unit test for function url_argument_spec
def test_url_argument_spec():
    spec = url_argument_spec()
    assert 'url' in spec


# Generated at 2022-06-20 21:12:25.799924
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    from ansible.compat.tests import unittest

    class TestSSLValidationHandler(unittest.TestCase):
        def test_ssl_context(self):
            ssl_validation_handler = SSLValidationHandler('hostname', 443)
            context = ssl_validation_handler.make_context(None, None)
            assert context



# Generated at 2022-06-20 21:12:28.097495
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    e = ConnectionError("foo")
    assert e.args == ("foo",)


# Generated at 2022-06-20 21:12:32.329404
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    fp = open('./ssl_handler.py', 'rb')
    content = fp.read()
    fp.close()
    url = 'https://www.google.com/'
    command = 'GET ' + url
    if sys.version_info[0] >= 3:
        command = bytes(command, 'ascii')
    else:
        command = command
    request = Request('https://www.google.com/')
    ssl_handler = SSLValidationHandler('www.google.com', 443)
    result = ssl_handler.http_request(request)
    assert isinstance(result, Request)
    assert isinstance(result.get_full_url(), str)
    assert result.get_full_url() == 'https://www.google.com/'

# Generated at 2022-06-20 21:12:43.804312
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    conn = CustomHTTPSConnection('localhost', 42, 'cert', 'key')
    if HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert conn.context.__class__.__name__ == 'PyOpenSSLContext'
        assert conn.context._protocol == PROTOCOL
    elif HAS_SSLCONTEXT:
        assert conn.context.__class__.__name__ == 'SSLContext'
    else:
        assert conn.context is None
    assert conn._context is conn.context

if CustomHTTPSConnection:
    # noinspection PyUnresolvedReferences
    class CustomHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(self.getConnection, req)


# Generated at 2022-06-20 21:12:49.603160
# Unit test for method post of class Request
def test_Request_post():
    url = 'http://www.baidu.com/'
    data = {'a': 1}
    headers = {'Content-type': 'application/json'}
    req = Request()
    request = req.post(url, data, headers=headers)
    print(request.read().decode())
if __name__ == '__main__':
    test_Request_post()


# Generated at 2022-06-20 21:15:19.458047
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        from urllib2 import urlopen
        urlopen("https://www.example.com/")
    except NoSSLError as e:
        # Check the correct string was passed through
        assert str(e) == 'SSL validation failure for "https://www.example.com/" due to no ssl library available: No module named ssl', str(e)
    except ImportError:
        pytest.skip("No ssl library available")


# Generated at 2022-06-20 21:15:29.874277
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    try:
        assert os.path.exists(TEST_FILE) == False
        assert os.path.exists(TEST_FILE_FAIL) == False

        with open(TEST_FILE, 'w+') as fh:
            atexit.register(atexit_remove_file, TEST_FILE)
            fh.write('test')
            fh.close()

        assert os.path.exists(TEST_FILE) == True
        assert os.path.exists(TEST_FILE_FAIL) == False
    except (AssertionError, IOError):
        raise
    finally:
        if os.path.exists(TEST_FILE):
            os.unlink(TEST_FILE)


# Generated at 2022-06-20 21:15:39.950078
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class MockUnixSocket(object):
        def __init__(self):
            self.connected = False

        def connect(self, *args, **kwargs):
            self.connected = True

    def _return_mock_unix_socket():
        return MockUnixSocket()

    sock = MockUnixSocket()
    with unix_socket_patch_httpconnection_connect():
        conn = httplib.HTTPConnection('localhost', timeout=1)
        conn.sock = None
        conn.create_unix_connection = _return_mock_unix_socket
        conn.connect()
        # if connect properly patched, we'll get a new unix socket connected
        assert not sock.connected
        assert conn.sock.connected
        assert type(conn.sock) == type(sock)



# Generated at 2022-06-20 21:15:43.482798
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    result = ParseResultDottedDict(scheme='http', netloc='www.google.com', path='/search', params='',
                                   query='q=test', fragment='')
    # Verify attributes can be modified
    result.netloc = 'www.google.co.uk'
    result.query = 'q=test2'
    # Verify attributes can be accessed
    assert result.netloc == 'www.google.co.uk'
    assert result.query == 'q=test2'
    assert result.as_list() == ['http', 'www.google.co.uk', '/search', '', 'q=test2', '']


# Generated at 2022-06-20 21:15:44.779361
# Unit test for method head of class Request
def test_Request_head():
    request = Request(url='www.google.com', method='HEAD')
    response = request.get_response()
    assert response.status == 200


# Generated at 2022-06-20 21:15:52.977607
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    unix_socket = '/tmp/unix-socket'
    if os.path.exists(unix_socket):
        os.remove(unix_socket)
    # Disable pylint check for the super() call. It complains about UnixHTTPSConnection
    # being a NoneType because of the initial definition above, but it won't actually
    # be a NoneType when this code runs
    # pylint: disable=bad-super-call
    handler = UnixHTTPHandler(unix_socket)
    assert handler


#
# Utilities
#


# Generated at 2022-06-20 21:16:07.841397
# Unit test for function prepare_multipart
def test_prepare_multipart():
    fields = {
        "file1": {
            "filename": __file__,
            "mime_type": "application/octet-stream"
        },
        "file2": {
            "content": "text based file content",
            "filename": "fake.txt",
            "mime_type": "text/plain",
        },
        "text_form_field": "value"
    }
    content_type, body = prepare_multipart(fields)
    assert isinstance(content_type, string_types)
    assert isinstance(body, BinaryType)
    assert 'form-data' in content_type
    assert b'-----' in body

# Generated at 2022-06-20 21:16:10.611949
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('auser', 'apassword') == b"Basic YXVzZXI6YXBhc3N3b3Jk"



# Generated at 2022-06-20 21:16:13.659617
# Unit test for function fetch_file
def test_fetch_file():
    module = AnsibleModule()
    fetch_file(module, 'http://localhost/file1', None, None, None, True, False, None, 10, None)
    fetch_file(module, 'http://localhost/file2', None, None, None, True, True, None, 10, None)



# Generated at 2022-06-20 21:16:14.922185
# Unit test for constructor of class RequestWithMethod
def test_RequestWithMethod():
    request = RequestWithMethod('https://example.com', 'GET')
    assert request.get_method() == 'GET'

#
# HTTP handlers
#



# Generated at 2022-06-20 21:16:49.652263
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    from test.support import EnvironmentVarGuard
    from unittest.mock import Mock, patch
    import tempfile
    import http.client

    with EnvironmentVarGuard():
        with patch('os.environ', {'DOCKER_HOST': 'unix://test_file.sock'}):
            unix_socket = os.environ.get('DOCKER_HOST').split('://')[1]

        # Create a dummy socket
        tmp = tempfile.NamedTemporaryFile(delete=False)
        os.close(tmp.file.fileno())
        tmp_name = tmp.name
        tmp.close()
        http.client.HTTPConnection._debuglevel = 1


# Generated at 2022-06-20 21:16:53.041179
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    msg = 'this is a test'
    nssle = NoSSLError(msg)
    assert nssle.args == (msg,)
    assert str(nssle) == msg


# Generated at 2022-06-20 21:16:59.316352
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class MockIOSock(object):
        def socket(self):
            return None

    class MockSocket(object):
        def create_connection(self, *args, **kwargs):
            return None

    class MockSSLWrapSocket(object):
        def wrap_socket(self, *args, **kwargs):
            return None

    class MockContext(object):
        def wrap_socket(self, *args, **kwargs):
            return None

    # Test case 1: SSLContext available, no tunneling
    conn = CustomHTTPSConnection("127.0.0.1")
    conn.context = MockContext()
    conn.sock = MockIOSock()
    conn.connect()
    # Test case 2: SSLContext available, tunneling
    conn = CustomHTTPSConnection("127.0.0.1")

# Generated at 2022-06-20 21:17:12.208777
# Unit test for function fetch_file
def test_fetch_file():
    module = FakeAnsibleModule()
    with patch.object(os.path, 'isfile') as mock_isfile:
        mock_isfile.return_value = False
        with patch.object(fetch_file, 'fetch_url') as mock_fetch_url:
            mock_fetch_url.return_value = (FakeResp(), dict(status=200))
            assert fetch_file(module, 'test_url')
            mock_isfile.assert_called_once_with('test_url')
            mock_fetch_url.assert_called_once_with(
                module,
                'test_url',
                None,
                None,
                None,
                True,
                False,
                None,
                10,
                unredirected_headers=None
            )



# Generated at 2022-06-20 21:17:13.727605
# Unit test for method put of class Request
def test_Request_put():
    req = Request()
    result = req.put("http://url.com")
    assert type(result) == requests.models.Response, "Response class not retrieved"

# Generated at 2022-06-20 21:17:20.260424
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    method = UnixHTTPHandler._UnixHTTPHandler__http_open
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('/tmp/a-sock-file')
    s.listen(1)
    unix_socket = s.getsockname()
    handler = UnixHTTPHandler(unix_socket=unix_socket)
    try:
        # Open a URL to a non-existent unix domain socket file
        with pytest.raises(OSError) as exception:
            method(handler, urlopen('http://example.com/'))
        assert 'Invalid Socket File' in str(exception.value)
    finally:
        s.close()
        os.unlink(unix_socket)
    # Open a URL to a unix domain socket file with a server

# Generated at 2022-06-20 21:17:25.042027
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    _original_unix_http_connection_connect = UnixHTTPConnection.connect

    def conn(*args, **kwargs):
        UnixHTTPConnection.connect = _original_unix_http_connection_connect
        return "foo"

    UnixHTTPConnection.connect = conn

    with unix_socket_patch_httpconnection_connect() as mgr:
        assert mgr is None
        assert UnixHTTPConnection.connect == conn

    # we're unpatched again
    assert UnixHTTPConnection.connect == _original_unix_http_connection_connect


    try:
        with unix_socket_patch_httpconnection_connect():
            raise Exception("foo")
    except Exception:
        pass

    # we're unpatched again
    assert UnixHTTPConnection.connect == _original_unix_http_connection_connect



# Generated at 2022-06-20 21:17:26.366445
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    handler = SSLValidationHandler(hostname='example.com', port=443)
    request = Request()
    handler.https_request(request)



# Generated at 2022-06-20 21:17:29.746024
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    """Test function atexit_remove_file."""
    # Create empty file
    testfile = tempfile.mkstemp(prefix='test_ansible_module_utils_module_runner_')[1]
    assert os.path.isfile(testfile) is True

    # Register test file for removal
    atexit_remove_file(testfile)

    # Execute atexit handlers
    atexit._run_exitfuncs()

    # Assert file was removed
    assert os.path.isfile(testfile) is False


# Generated at 2022-06-20 21:17:35.878045
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    if not UNIX_SOCKET_SUPPORTED:
        skip('unix domain socket not supported')
    elif not os.path.exists('/var/run/docker.sock'):
        skip('unix domain socket not readable')
    conn = UnixHTTPConnection('/var/run/docker.sock')(host='socket')
    assert conn.host == 'socket'

# Generated at 2022-06-20 21:18:07.844590
# Unit test for function getpeercert
def test_getpeercert():
    try:
        getpeercert(None)
    except IOError:
        pass  # Did not raise AttributeError as expected
    try:
        getpeercert(None, "notABool")
    except TypeError:
        pass  # Did not raise AttributeError as expected
    try:
        getpeercert("notAResponse")
    except AttributeError:
        pass  # Did not raise AttributeError as expected


# Generated at 2022-06-20 21:18:10.132927
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://www.google.com'
    validate_certs = False
    assert maybe_add_ssl_handler(url, validate_certs) == None
    validate_certs = True
    assert maybe_add_ssl_handler(url, validate_certs).hostname == 'www.google.com'
    assert maybe_add_ssl_handler(url, validate_certs).port == 443



# Generated at 2022-06-20 21:18:16.904379
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    try:
        if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
            connection = CustomHTTPSConnection(host='www.example.com', context=None)
        else:
            connection = CustomHTTPSConnection(host='www.example.com')
    except:
        raise AssertionError("Failed to create instance of CustomHTTPSConnection!")


# Generated at 2022-06-20 21:18:21.210991
# Unit test for method head of class Request
def test_Request_head():
    r = Request(url='url')
    assert(r.head('url') == r.open('HEAD', 'url'))

# Generated at 2022-06-20 21:18:23.275453
# Unit test for method options of class Request
def test_Request_options():
    url = "https://abc.def"
    r = Request(url)
    assert r.options(url) is not None, "method options of class Request failed"


# Generated at 2022-06-20 21:18:32.991503
# Unit test for method get of class Request
def test_Request_get():
    ansible_requests = Request(None)
    ansible_requests.get("https://example.com")
    ansible_requests.options("https://example.com")
    ansible_requests.head("https://example.com")
    ansible_requests.post("https://example.com")
    ansible_requests.put("https://example.com")
    ansible_requests.patch("https://example.com")
    ansible_requests.delete("https://example.com")
    ansible_requests.open("https://example.com")


# Generated at 2022-06-20 21:18:42.301296
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # monkey patching ssl to cause an error
    class fake_ssl(object):
        def __getattr__(self, _):
            raise AttributeError('Fake ssl')
    import sys
    import ansible.module_utils.six.moves.urllib.request
    global ssl
    ssl, sys.modules['ssl'] = sys.modules['ssl'], fake_ssl()
    try:
        assert maybe_add_ssl_handler('https://example.com', True) is None
    finally:
        sys.modules['ssl'] = ssl



# Generated at 2022-06-20 21:18:46.088371
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    u = UnixHTTPConnection('/path/to/socket')
    assert u._unix_socket == '/path/to/socket'



# Generated at 2022-06-20 21:18:52.421161
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    foo = ParseResultDottedDict(scheme='a', netloc='b', params='c', query='d', fragment='e')
    assert foo.as_list() == ['a', 'b', None, 'c', 'd', 'e']

#
# Client
#

