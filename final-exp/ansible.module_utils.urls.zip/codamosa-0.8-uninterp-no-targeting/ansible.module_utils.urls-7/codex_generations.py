

# Generated at 2022-06-20 21:13:57.494968
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    assert RequestWithMethod("http://127.0.0.1/", "GET", ).get_method() == 'GET'



# Generated at 2022-06-20 21:14:05.283870
# Unit test for method delete of class Request
def test_Request_delete():
    # Creates an instance of Request
    request = Request()
    # Tests the method delete with a valid call
    response = request.delete("https://ansible.com")
    # Tests the method delete with a call to an invalid url
    with pytest.raises(urllib_error.HTTPError) as exception:
        request.delete("https://httpbin.org/status/418")
    # Tests the method delete with a call to an invalid method
    with pytest.raises(request.InvalidMethodError) as exception:
        request.delete(method="get", url="https://httpbin.org/status/418")

# Generated at 2022-06-20 21:14:20.081001
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''Check that UnixHTTPSConnection class initializes normally'''
    # pylint: disable=invalid-name
    unix_socket = "/tmp/foo"
    x = UnixHTTPSConnection(unix_socket)
    assert x._unix_socket == "/tmp/foo"
#
# The following functions and classes are copied from urllib3's
# ``contrib/pyopenssl.py``. This code is licensed under the Apache License,
# Version 2.0, the same license as urllib3.
#
# Changes made:
#
# - Patched import of certs to work with Python 2/3.
# - Removed copies of certifi's cacert.pem, which is licensed under MPL2 and
#   therefore incompatible with our Apache 2 license.
# - Removed use of contrib/socket_patch.py, which

# Generated at 2022-06-20 21:14:32.026010
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    from ansible.module_utils.urls import SSLValidationHandler
    from distutils.version import LooseVersion
    from ssl import SSLContext
    import urllib3

    test_handler = SSLValidationHandler('hostname', 443)

    expected_protocol = SSLContext.PROTOCOL_SSLv23
    expected_verify_mode = SSLContext.CERT_REQUIRED
    if HAS_SSLCONTEXT:
        if LooseVersion(urllib3.__version__) >= LooseVersion('1.21.1'):
            expected_protocol = SSLContext.PROTOCOL_TLS
            expected_verify_mode = SSLContext.CERT_REQUIRED
        elif LooseVersion(urllib3.__version__) >= LooseVersion('1.21'):
            expected_prot

# Generated at 2022-06-20 21:14:37.419028
# Unit test for method post of class Request
def test_Request_post():
    # the response:
    response = mock.Mock()

    # the expected result with error
    # the result with no error
    result_error = {'code' : 1, 'msg' : 'Error'}
    result_no_error = {'result': 'Success'}

    # mock response object (a attr of result_error)
    response.read.return_value = json.dumps(result_error).encode('ascii')
    # mock the open() method to control its behavior
    with mock.patch('urllib.request.urlopen', return_value=response):
        test = Request()
        assert test.post('some_url', 'some_data', 'some_headers') == result_error

# Generated at 2022-06-20 21:14:39.709435
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    conn = UnixHTTPSConnection('/var/run/docker.sock')('localhost', None)
    assert conn.sock.family == socket.AF_UNIX
    assert conn.sock.type == socket.SOCK_STREAM
    assert conn.sock.getsockname() == '/var/run/docker.sock'


#
# Abstracted transport adapters
#


# Generated at 2022-06-20 21:14:51.253666
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    '''Unit test for method http_open of class UnixHTTPHandler'''
    unix_socket = '/tmp/test_UnixHTTPHandler_http_open.sock'
    req = urllib_request.Request('http://www.example.com')
    handler = UnixHTTPHandler(unix_socket)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        try:
            response = handler.http_open(req)
        except OSError:
            _unused, exc_value, _unused = sys.exc_info()
            expected_error = 'Invalid Socket File (%s)' % (unix_socket)
            if not isinstance(exc_value, OSError) or exc_value.args[0] != expected_error:
                raise



# Generated at 2022-06-20 21:14:55.737435
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    import unittest
    from ansible.module_utils.urls import SSLValidationHandler

    class TestSSLValidationHandler(unittest.TestCase):
        def setUp(self):
            self.ssl_validation_handler = SSLValidationHandler('', '')

    unittest.TextTestRunner(verbosity=2).run(unittest.TestLoader().loadTestsFromTestCase(TestSSLValidationHandler))


if HAS_SSLCONTEXT:
    def create_default_context(cafile=None, capath=None, cadata=None):
        '''
        A custom function to create default SSLContext

        Custom function is required because `create_default_context` was added
        in Python 2.7.9.
        '''
        context = ssl.create_default_context()

# Generated at 2022-06-20 21:15:06.642089
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    A_HOST = 'github.com'
    A_PORT = 443

    if CustomHTTPSConnection:
        connection = CustomHTTPSConnection(A_HOST, A_PORT, cert_file=CERT_FILE, key_file=KEY_FILE)
        assert connection.host == A_HOST
        assert connection.port == A_PORT
        assert connection.cert_file == CERT_FILE
        assert connection.key_file == KEY_FILE

    if CustomHTTPSConnection and HAS_SSLCONTEXT:
        connection = CustomHTTPSConnection(A_HOST, A_PORT, cert_file=CERT_FILE, key_file=KEY_FILE, context=SSLContext(PROTOCOL))
        assert connection.host == A_HOST
        assert connection.port == A_PORT
        assert connection.cert_file == CERT

# Generated at 2022-06-20 21:15:16.063959
# Unit test for method head of class Request
def test_Request_head():
    """
    Unit test for method head of class Request
    """
    def _file_to_module(self):
        """
        Override method of class Request
        """
        return ""
    module_return = "module_return"
    url = "http://www.example.com"
    response_return = "response_return"
    response_obj = type('obj', (object,), {'read': lambda self: response_return})
    exception_return = Exception('exception')

    # Test case 1: verbose is False
    params = dict(
        url=url, verbose=False
    )
    mock_args = _mock_args(params)
    request_obj = Request(mock_args)
    request_obj.module = _mock_module()
    request_obj.urlopen = _mock

# Generated at 2022-06-20 21:16:24.781068
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    try:
        handler = maybe_add_ssl_handler('https://localhost:443/foo/bar', validate_certs = True)
        assert  isinstance(handler,SSLValidationHandler) == True
    except NotImplementedError:
        assert isinstance(handler,SSLValidationHandler) == False


# Generated at 2022-06-20 21:16:30.174448
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    hostname = 'test-host'
    port = 443
    cafile = None
    cadata = None
    ca_path = None

    cafile, cadata, paths_checked = SSLValidationHandler(hostname, port, ca_path).get_ca_certs()
    expected_value = SSLValidationHandler(hostname, port, ca_path).make_context(cafile, cadata)
    try:
        assert type(expected_value) == ssl.SSLContext
    except AssertionError:
        assert isinstance(expected_value, ssl.SSLContext)



# Generated at 2022-06-20 21:16:46.583769
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    # pylint: disable=protected-access,too-few-public-methods
    class TestArguments(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    # pylint: enable=protected-access,too-few-public-methods
    test_args = TestArguments('foo.example.com', bar=123)
    u = UnixHTTPSConnection('/foo/bar')
    u(**test_args.kwargs)
    # pylint: disable=unsubscriptable-object
    assert (u.host, u.port) == test_args.args
    assert u.sock == None
    assert u._tunnel_host == None

# Generated at 2022-06-20 21:16:51.076690
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    proxy_url = 'http://127.0.0.1:8080'
    https_proxy = 'https://127.0.0.1:8080'
    https_proxy_env = 'https://127.0.0.1:8080'
    https_proxy_env2 = 'https://127.0.0.1:8080'
    https_proxy_env3 = 'https://127.0.0.1:8080'

    http_valid_code = 200
    http_invalid_code = 400

    http_valid_resp = 'HTTP/1.0 200 Connection established\r\n\r\n'
    http_invalid_resp = 'HTTP/1.0 400 Bad Request\r\n\r\n'

    handler = SSLValidationHandler('www.example.com', 8080)
 

# Generated at 2022-06-20 21:16:56.783974
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    actual = ParseResultDottedDict().as_list()
    expected = [None, None, None, None, None, None]
    assert actual == expected
    for args in [
            ('sven',),
            ('sven', 'eu'),
            ('sven', 'eu', 'x'),
            ('sven', 'eu', 'x', 'y'),
            ('sven', 'eu', 'x', 'y', 'z'),
            ('sven', 'eu', 'x', 'y', 'z', 'a'),
            ]:
        actual = ParseResultDottedDict({'index': args[0]}).as_list()
        expected = [None, args[0], None, None, None, None]
        assert actual == expected

# Generated at 2022-06-20 21:16:59.570838
# Unit test for method patch of class Request
def test_Request_patch():
    req = Request()
    assert req.patch('http://www.google.com') != None


# Generated at 2022-06-20 21:17:05.150645
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    class myUnixHTTPConnection(UnixHTTPConnection):
        def __init__(self, *args, **kwargs):
            self.test_args = args
            self.test_kwargs = kwargs
            UnixHTTPConnection.__init__(self, args[0])

    un_http = myUnixHTTPConnection('test', 'test2')
    assert un_http.test_args == ('test', 'test2')
    assert un_http.test_kwargs == {}


#
# Unicode
#

# Divergence: Ansible core defines `to_native` which returns `to_bytes`
# if input is bytes, `to_text` otherwise. This can be used in
# all places where we only have bytes or text as input, not both.

# Divergence: Ansible core defines `to_unicode` which is the same as

# Generated at 2022-06-20 21:17:13.393960
# Unit test for method post of class Request
def test_Request_post():
    with HTTMock(mock_api):
        obj = Request(use_proxy=True, validate_certs=True, url_username='abc',
                      url_password='123', client_cert='/cert.pem', client_key='/key.pem',
                      cookies='/cookies.jar', unix_socket='/path/to/file.sock',
                      ca_path='/path/to/cacert.pem')
        headers = {'Accept': 'application/json'}
        res = obj.post('https://www.ansible.com/', data='data',
                       headers=headers, timeout=20, unredirected_headers=['abc'])
        assert res.msg == 'OK'

# Generated at 2022-06-20 21:17:17.741754
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    msg = 'SSL validation failed'
    err = SSLValidationError(msg)
    if err.message != msg:
        raise AssertionError('message is not given')


# Generated at 2022-06-20 21:17:31.767932
# Unit test for method options of class Request
def test_Request_options():
    'Test the urllib2_utils.Request.options() method.'
    response = HTTPResponse(url="Test")
    request = Request('Test', 'GET', 'Test', url_username='Test', url_password='Test', http_agent='Test',
                      force_basic_auth=True, follow_redirects='Test', client_cert='Test', client_key='Test',
                      cookies='Test', use_gssapi=True, unix_socket='Test', unredirected_headers='Test')
    result = request.options('Test', data='Test', headers='Test', use_proxy=True, force=True,
                             last_mod_time='Test', timeout='Test', validate_certs=True, ca_path='Test')
    assert result is response
