

# Generated at 2022-06-20 21:13:00.679294
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    # None
    prdd = ParseResultDottedDict()
    assert prdd.as_list() == [None]*6

    # Real
    prdd = ParseResultDottedDict(dict(scheme='https', netloc='www.example.com', path='/api', query='param1=1', fragment='foo'))
    assert prdd.as_list() == ['https', 'www.example.com', '/api', None, 'param1=1', 'foo']



# Generated at 2022-06-20 21:13:01.696255
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    with pytest.raises(SSLValidationError):
        SSLValidationHandler('example.com', 443)

# Generated at 2022-06-20 21:13:06.131124
# Unit test for function basic_auth_header
def test_basic_auth_header():
    base64_string = basic_auth_header('test', 'test')
    assert base64_string == b'Basic dGVzdDp0ZXN0'



# Generated at 2022-06-20 21:13:12.942037
# Unit test for function generic_urlparse
def test_generic_urlparse():
    urlparse = urlparse_helpers.generic_urlparse
    urlparse('http://example.com').netloc == 'example.com'
    urlparse('http://user@example.com').username == 'user'
    urlparse('http://example.com').username == None
    urlparse('http://user:pass@example.com').password == 'pass'
    urlparse('http://example.com').password == None
    urlparse('http://example.com').hostname == 'example.com'
    urlparse('http://example.com').port == None
    urlparse('http://example.com').path == ''
    urlparse('http://example.com/').path == '/'
    urlparse('http://example.com:8080/').port == 8080

# Generated at 2022-06-20 21:13:17.677365
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():

    if HAS_SSLCONTEXT:
        context = SSLValidationHandler.make_context(
            cafile='/path/to/cafile',
            cadata=None
        )
        assert context.verify_mode == ssl.CERT_REQUIRED
        assert tuple(context.get_ca_certs()) == ()

        context = SSLValidationHandler.make_context(
            cafile='/path/to/cafile',
            cadata=b'filedata'
        )
        assert context.verify_mode == ssl.CERT_REQUIRED
        assert context.get_ca_certs() == (b'filedata',)


# Generated at 2022-06-20 21:13:18.742313
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    cafile = None
    cadata = None
    context = SSLValidationHandler().make_context(cafile, cadata)

# Generated at 2022-06-20 21:13:20.096651
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('localhost', 2181)
    except ProxyError as error:
        assert 'localhost' in str(error)
        assert str(2181) in str(error)



# Generated at 2022-06-20 21:13:22.631599
# Unit test for method delete of class Request
def test_Request_delete():
    req = requests.Request('DELETE', 'http://httpbin.org/delete')
    req = req.prepare()
    s = requests.Session()
    r = s.send(req)
    pprint(r.json())



# Generated at 2022-06-20 21:13:29.000598
# Unit test for function generic_urlparse
def test_generic_urlparse():
    parse = generic_urlparse(urlparse.urlparse('http://foo:bar@localhost:8080/v1/path?query=foo#frag'))

    assert parse['scheme'] == 'http'
    assert parse['username'] == 'foo'
    assert parse['password'] == 'bar'
    assert parse['hostname'] == 'localhost'
    assert parse['port'] == 8080
    assert parse['path'] == '/v1/path'
    assert parse['query'] == 'query=foo'
    assert parse['fragment'] == 'frag'
    assert parse.as_list() == ['http', 'foo:bar@localhost:8080', '/v1/path', '', 'query=foo', 'frag']


# Generated at 2022-06-20 21:13:32.181675
# Unit test for constructor of class Request
def test_Request():
    url = 'https://www.ansible.com'
    http_agent = 'test_http_agent'

    got = Request(url, http_agent=http_agent)
    assert got.url == url
    assert got.http_agent == http_agent

# Generated at 2022-06-20 21:14:19.741032
# Unit test for function prepare_multipart
def test_prepare_multipart():
    # Test fields parameter can only be mapping
    with pytest.raises(TypeError):
        prepare_multipart('test')
    # Test value must be a string or mapping
    with pytest.raises(TypeError):
        prepare_multipart({'test': ['a', 'b']})
    # Test filename or content must be provided
    with pytest.raises(ValueError):
        prepare_multipart({'test': {'mime_type': 'text/plain'}})
    with pytest.raises(ValueError):
        filename = os.path.join(os.path.dirname(__file__), 'testdata', 'ascii')
        prepare_multipart({'test': {'filename': filename}})

# Generated at 2022-06-20 21:14:22.129315
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    '''
    Test for the constructor of class UnixHTTPSConnection
    '''
    unix_socket = '/var/run/docker.sock'
    unix_https_connection = UnixHTTPSConnection(unix_socket)
    assert unix_https_connection is not None

#
# Url connection handlers
#



# Generated at 2022-06-20 21:14:27.091513
# Unit test for method get of class Request
def test_Request_get():
    r = Request()
    r.get(r.get_url())
    r.get(r.get_url(), headers=r.get_headers())
    r.get(r.get_url(), data=None)
    r.get(r.get_url(), data=None, headers=r.get_headers())
    r.get(r.get_url(), data=None, headers=r.get_headers(), use_proxy=None)
    r.get(r.get_url(), data=None, headers=r.get_headers(), force=False)
    r.get(r.get_url(), data=None, headers=r.get_headers(), last_mod_time=None)
    r.get(r.get_url(), data=None, headers=r.get_headers(), timeout=10)

# Generated at 2022-06-20 21:14:31.781307
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    from base64 import b64encode
    from os import unlink
    import tempfile
    import threading
    import time
    import socket
    import json

    # Generate a pem file with a private key and a CA
    ca_pem, ca_key = tempfile.mkstemp()
    ca_dn = dict(C='US', ST='California', L='Mountain View', O='Acme Inc.', OU='Foo', CN='Acme Inc.')
    ca_key_passphrase = b64encode(os.urandom(8)).decode('ascii')
    subprocess.check_call(['openssl', 'genrsa', '-des3', '-passout', 'pass:{}'.format(ca_key_passphrase), '-out', ca_key, '2048'])
    ca

# Generated at 2022-06-20 21:14:41.591576
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    cah = HTTPSClientAuthHandler('mycert.pem', 'mykey.pem')
    return cah



# Generated at 2022-06-20 21:14:44.988092
# Unit test for function url_argument_spec
def test_url_argument_spec():
    spec = url_argument_spec()
    assert len(spec['url']) == 1
    assert 'type' in spec['url']
    assert spec['url']['type'] == 'str'
    assert len(spec['use_proxy']) == 2
    assert 'default' in spec['use_proxy']
    assert 'type'in spec['use_proxy']
    assert spec['use_proxy']['default'] == True
    assert spec['use_proxy']['type'] == 'bool'



# Generated at 2022-06-20 21:14:56.971960
# Unit test for method put of class Request
def test_Request_put():
    # method instance
    handler = Request()
    # test args
    url = ""
    data = "data"
    # test kwargs
    force = None
    timeout = 30
    validate_certs = True
    url_username = None
    url_password = None
    http_agent = "ansible-httpget"
    force_basic_auth = True
    follow_redirects = None
    client_cert = None
    client_key = None
    cookies = None
    unix_socket = None
    ca_path = None
    unredirected_headers = None
    use_proxy = True
    method = "PUT"
    headers = None
    expect = HTTPResponse
    actual = handler.put(url, data=data)
    assert isinstance(actual, expect)

# Generated at 2022-06-20 21:15:08.211024
# Unit test for method https_open of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler_https_open():
    try:
        import urllib3
    except ImportError:
        # We can't test this without urllib3
        pass
    else:
        class FakeHTTPSConnection(object):
            def __init__(self, client_cert, client_key, **kwargs):
                self.client_cert = client_cert
                self.client_key = client_key
                self.kwargs = kwargs

            def __call__(self, *args, **kwargs):
                return FakeHTTPSConnection(self.client_cert, self.client_key, **kwargs)

        client_cert = os.path.join(CERT_DATA_PATH, 'client.pem')
        client_key = os.path.join(CERT_DATA_PATH, 'client.key')

# Generated at 2022-06-20 21:15:24.545419
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    exception = Exception('an exception')
    paths = ['/path/to/ca', '/path/to/cert']
    try:
        build_ssl_validation_error('192.168.1.1', '443', paths, exception)
    except SSLValidationError as e:
        assert 'Failed to validate the SSL certificate for 192.168.1.1:443.' in e.args[0]
        assert 'Make sure your managed systems have a valid CA certificate installed.' in e.args[0]

# Generated at 2022-06-20 21:15:36.308587
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    try:
        # This test will only pass if ssl is installed
        conn = CustomHTTPSHandler()
    except Exception as e:
        raise AssertionError("Could not create a CustomHTTPSHandler to test it: " + str(e))
    return True


# Generated at 2022-06-20 21:17:36.986995
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    try:
        raise SSLValidationError()
    except SSLValidationError as e:
        if e.args[0] != "Failure to connect due to SSL validation failing":
            raise AssertionError('Unexpected error message when '\
                                 'raising SSLValidationError: %s' %
                                 e.args[0])



# Generated at 2022-06-20 21:17:41.213090
# Unit test for method delete of class Request
def test_Request_delete():
    # Initialization
    # Instantiate a 'Request' object
    url = 'http://ansible.com/'
    content_type_header = 'content-type'
    connection_header = 'connection'
    keep_alive_value = 'keep-alive'
    auth_header = 'Authorization'
    rh = Request(url=url, headers={content_type_header: CONTENT_TYPE_FORM_URLENCODED, connection_header: keep_alive_value})
    # Call method 'delete' to remove the authorization header
    rh.delete(url)
    # Check
    assert not rh.headers.get(auth_header)
    # Instantiate a 'Request' object with authorization header

# Generated at 2022-06-20 21:17:51.119583
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():

    cafile = 'cafilepath'
    cadata = 'cadata'

    handler = SSLValidationHandler('host_name',8889, ca_path=cafile)
    assert handler.make_context(cafile, cadata) == create_default_context(cafile=cafile)
    cafile = ''
    cadata = 'cadata'
    assert handler.make_context(cafile, cadata) == create_default_context(cadata=cadata)
    cafile = 'cafilepath'
    cadata = ''
    assert handler.make_context(cafile, cadata) == create_default_context(cafile=cafile)
    cafile = ''
    cadata = ''
    assert handler.make_context(cafile, cadata) == create_default_

# Generated at 2022-06-20 21:18:02.276806
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    class FakeHTTPSConnection(CustomHTTPSConnection):
        def __init__(self, cert_file, key_file, *args, **kwargs):
            # Store cert_file and key_file in self because it's not
            # passed to __init__() like we want but as a keyword
            self.cert_file = cert_file
            self.key_file = key_file
            CustomHTTPSConnection.__init__(self, *args, **kwargs)

    class MockSSLContext(object):
        def __init__(self, *args, **kwargs):
            pass

        def wrap_socket(self, sock, **kwargs):
            return None

        def load_cert_chain(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 21:18:06.047606
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    '''
    Test if the SLValidationError will work fine with SSLValidationError and CertifiCAError
    '''
    class CertifiCAError(Exception):
        pass
    try:
        raise CertifiCAError('error')
    except CertifiCAError as exc:
        build_ssl_validation_error('test.com', '443', '', exc=exc)


# Generated at 2022-06-20 21:18:08.694957
# Unit test for method options of class Request
def test_Request_options():
    method = 'GET'
    parsed = generic_urlparse(urlparse('http://www.example.com/'))
    kwargs = {'url': 'http://www.example.com/'}
    r = Request(method=method, parsed=parsed, **kwargs)#, ca_path=ca_path)
    response = r.options(**kwargs)
    print(response)


# Generated at 2022-06-20 21:18:13.192733
# Unit test for method options of class Request
def test_Request_options():
    r"""Test method options."""
    url_1 = Url('http://www.apple.com/')
    url_2 = Url('https://www.apple.com/')
    url_3 = Url('http://www.apple.com/a')
    url_4 = Url('https://www.apple.com/a')
    url_5 = Url('http://www.apple.com/b')
    url_6 = Url('https://www.apple.com/b')
    url_7 = Url('http://www.apple.com/c')
    url_8 = Url('https://www.apple.com/c')
    url_9 = Url('http://www.apple.com/d')
    url_10 = Url('https://www.apple.com/d')
    url

# Generated at 2022-06-20 21:18:18.900290
# Unit test for method delete of class Request
def test_Request_delete():
    class Response:
        def read(self):
            return '{"status":"success"}'
    http_obj = Request()
    response = http_obj.delete('www.google.com')
    assert response.read() == Response().read()

# Generated at 2022-06-20 21:18:33.800483
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # If SSL is not supported, we should not even import this
    # file.
    if hasattr(sys, 'getwindowsversion'):
        window_version = sys.getwindowsversion()
        if window_version < (6, 0):
            pytest.skip("Windows versions before Vista lack SSL support.")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    _, port = sock.getsockname()
    server = BaseHTTPServer.HTTPServer(('127.0.0.1', port), SimpleHTTPServer.SimpleHTTPRequestHandler)
    t = threading.Thread(target=server.serve_forever)
    t.start()

# Generated at 2022-06-20 21:18:38.356906
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    unix_socket = '/tmp/test'
    connection = UnixHTTPSConnection(unix_socket)
    assert connection._unix_socket == unix_socket
    assert connection.sock is None

#
# This class is rather complex, so some explanation is in order.
#
# When using httplib's HTTPConnection (besides being blocking) methods like
# request() and send() don't account for file-like objects (they require plain
# strings).  The idea here is to provide an API that allows the use of file-
# like objects, since that makes dealing with things like the body of HTTP
# PATCH requests much easier.  That in itself could be done by subclassing
# httplib.HTTPConnection and overriding relevant methods.
#
# The problem is that urllib2 does not use HTTPConnection, it uses its own
# version of HTTP