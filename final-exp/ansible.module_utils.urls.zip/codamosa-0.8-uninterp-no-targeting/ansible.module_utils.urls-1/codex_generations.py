

# Generated at 2022-06-20 21:14:24.745343
# Unit test for function fetch_url
def test_fetch_url():
    # WIP
    #module = AnsibleModule(argument_spec={
    #    'url': {'required': True, 'type': 'str'},
    #})
    #r, info = fetch_url(module, 'http://www.google.com')
    #assert info['status'] == 200
    assert True

# Generated at 2022-06-20 21:14:32.011874
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    """Unit test for method __call__ of class UnixHTTPConnection"""
    with patch('os.path.exists', return_value=True) as mock_exists:
        with patch.object(socket.socket, 'connect', return_value=None) as mock_connect:
            test_connection = UnixHTTPConnection('/test/unix/socket')
            test_connection('localhost')
            assert test_connection.sock == socket.socket.return_value
            mock_exists.assert_called_once_with('/test/unix/socket')
            mock_connect.assert_called_once_with('/test/unix/socket')


#
# Module constants
#

# httplib.HTTPConnection.__init__ will try to connect "soon" (actually, it
# seems it tries to connect as soon as there is data to

# Generated at 2022-06-20 21:14:36.342087
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    import unittest
    import tempfile
    import os

    ca = tempfile.NamedTemporaryFile(delete=False)
    ca.write(b_DUMMY_CA_CERT)
    ca.close()

    bad_ca = tempfile.NamedTemporaryFile(delete=False)
    bad_ca.write(b'BAD_CERT')
    bad_ca.close()

    class TestSSLCerts(unittest.TestCase):
        def test_maybe_add_ssl_handler_no_ssl(self):
            try:
                maybe_add_ssl_handler('http://example.com', True)
                self.fail("Exception not thrown for http without ssl")
            except NoSSLError:
                pass


# Generated at 2022-06-20 21:14:37.599575
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test')
    except ConnectionError as err:
        assert err.args[0] == 'test'
        assert str(err) == 'test'



# Generated at 2022-06-20 21:14:48.775836
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    cert_file = 'test/unit/utils/test_data/'
    # Test case 1: using SHA1 signature
    with open(cert_file + 'test_server.crt', 'rb') as f:
        server_cert = f.read()
    expected_cb_cert_hash = b'\xF7\x84\xC7\xC4\xEF\xD4\xE4\x4C\x9C\x64' \
                             b'\x3C\xFD\xB3\xB0\x1C\x1A\xD9\x83\xA0\x21'

    assert get_channel_binding_cert_hash(server_cert) == expected_cb_cert_hash

    # Test case 2: using SHA256 signature

# Generated at 2022-06-20 21:14:53.104703
# Unit test for method http_request of class SSLValidationHandler

# Generated at 2022-06-20 21:14:54.751837
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    # SSLValidationHandler.http_request() usage
    ssl_validation_handler = urllib_request.SSLValidationHandler('www.google.com', 443)
    ssl_validation_handler.http_request()



# Generated at 2022-06-20 21:15:06.113972
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils import basic
    import sys

    p = basic._ANSIBLE_ARGS

    if sys.version_info >= (2, 7):
        import unittest
        class Tests(unittest.TestCase):

            unix_handler = UnixHTTPHandler(unix_socket='/opt/ansible/inst/ansible/ansible.socket')

            def test_basic(self):
                req = basic.AnsibleModule(
                    argument_spec=dict(),
                ).url_request('unix:///opt/ansible/inst/ansible/ansible.socket')
                with self.assertRaises(socket.error):
                    self.unix_handler.http_open(req)


# Generated at 2022-06-20 21:15:10.118091
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    hc = UnixHTTPConnection('/dev/null')
    assert hc('localhost') == hc


#
# Utils
#


# Generated at 2022-06-20 21:15:13.215831
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError()
    except NoSSLError as e:
        # This test is only valid if the exception object has no attribute 'message'
        try:
            e.message
            # If it has attribute 'message' pass the test by raising some unexpected exception
            raise Exception()
        except AttributeError:
            pass


# Generated at 2022-06-20 21:15:55.603810
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    def test_timeout(host, port=None, strict=None, timeout=1, source_address=None):
        '''test_timeout should not be called if the unix socket is used'''
        raise Exception('test_timeout called')

    with unix_socket_patch_httpconnection_connect():
        conn = UnixHTTPSConnection('/some/unix/socket')
        conn.timeout = 1
        conn.connect()
        # Verify that timeout was not called
        conn.sock.create_connection = test_timeout
        conn.sock.connect()



# Generated at 2022-06-20 21:16:02.719266
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    # Test for for https://github.com/ansible/ansible/issues/10969
    # In this case, we should fail the connection.
    with pytest.raises(ValueError):
        UnixHTTPSConnection('/some/bad/path')

#
# HTTP classes
#


# Generated at 2022-06-20 21:16:06.282557
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    """
    check that function generates a string that matches the
    format of 'Fri, 09 Nov 2001 01:08:47 -0000'
    """
    # a known date that can be verified
    date_string = 'Tue, 10 Jun 2014 08:00:00 -0000'
    import email
    parsed_string = email.utils.parsedate_tz(date_string)
    from calendar import timegm
    timestamp = timegm(parsed_string[:-1])
    new_date_string = rfc2822_date_string(time.gmtime(timestamp), parsed_string[-1])
    assert new_date_string == date_string



# Generated at 2022-06-20 21:16:11.793261
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    class SSLValidationHandler(object):
        @staticmethod
        def get_ca_certs():
            return None

    class call_obj:
        def __init__(self, orig=None):
            self.orig = orig

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return self.orig

    _ssl_wrap_socket = call_obj(True)
    _ssl_wrap_socket_old = call_obj(True)
    _ssl_wrap_socket.orig = _ssl_wrap_socket_old
    _ssl_wrap_context = call_obj(True)
    _ssl_wrap_context_old = call_obj(True)
    _ssl_wrap_context.orig = _ssl_wrap_context_old


# Generated at 2022-06-20 21:16:24.780176
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():
    from test.support import unlink
    from tempfile import mkstemp
    from socketserver import ThreadingTCPServer, BaseRequestHandler
    from time import sleep

    class EchoHandler(BaseRequestHandler):
        def handle(self):
            line = b''
            while True:
                chunk = self.request.recv(100)
                if not chunk:
                    break
                line += chunk
                if b'\r\n' in line:
                    break
            self.request.sendall(line)

    # Create a server with an in memory socket
    with mkstemp('ansible_test') as (fd, tmp_socket_path):
        unlink(tmp_socket_path)
        server = ThreadingTCPServer(tmp_socket_path, EchoHandler)
        server_thread = server.serve_forever
        #

# Generated at 2022-06-20 21:16:31.284259
# Unit test for constructor of class ProxyError
def test_ProxyError():
    exc = ProxyError('http://proxy:3128', 'http://example.com', 'Failed to connect')
    assert exc.url == 'http://example.com'
    assert exc.proxyurl == 'http://proxy:3128'
    assert str(exc) == 'Failed to connect to http://example.com via http://proxy:3128'
    #
    exc = ProxyError(None, 'http://example.com', 'Failed to connect')
    assert exc.url == 'http://example.com'
    assert exc.proxyurl is None
    assert str(exc) == 'Failed to connect to http://example.com'
    #
    exc = ProxyError(None, 'http://example.com')
    assert exc.url == 'http://example.com'
    assert exc.proxyurl is None

# Generated at 2022-06-20 21:16:47.941362
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    global HAS_SSLCONTEXT, HAS_URLLIB3_SSL_WRAP_SOCKET
    HAS_SSLCONTEXT = True
    HAS_URLLIB3_SSL_WRAP_SOCKET = False

    class MockSock(object):
        def __init__(self, unix_sock):
            self.unix_sock = unix_sock

    class MockContext(object):
        def wrap_socket(self, sock, **kwargs):
            return sock

    test_socket = '/some/socket/path'
    expected_context = MockContext()
    expected_context.wrap_socket = mock.Mock()

    def mock_get_context(protocol):
        return expected_context


# Generated at 2022-06-20 21:16:54.867862
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    unix_socket = '/tmp/socket'
    if os.path.exists(unix_socket):
        os.remove(unix_socket)
    unix_http_connection = UnixHTTPConnection(unix_socket)
    assert unix_http_connection.__init__ == UnixHTTPConnection.__init__
    assert unix_http_connection._unix_socket == unix_socket
    assert unix_http_connection.connect == UnixHTTPConnection.connect
    assert unix_http_connection.__call__ == UnixHTTPConnection.__call__

#
# Redirection
#


# Generated at 2022-06-20 21:16:56.437712
# Unit test for method patch of class Request
def test_Request_patch():
    assert True == True


# Generated at 2022-06-20 21:17:01.972815
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    if not hasattr(httplib, 'HTTPSConnection'):
        raise NothingToTestError('httplib.HTTPSConnection: not available')
    if not hasattr(urllib_request, 'HTTPSHandler'):
        raise NothingToTestError('urllib_request.HTTPSHandler: not available')
    conn = CustomHTTPSConnection('localhost')
    # This method is not available on macOS as per issue #24071 and on
    # CentOS 7 as per issue #30244
    if hasattr(conn, 'source_address'):
        # Any port that is not in use
        conn.connect()
        conn.close()
        # No port
        try:
            conn.connect()
            conn.close()
        except ConnectionError:
            pass

# Generated at 2022-06-20 21:18:34.644592
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    fname = '/tmp/test_file'
    touch(fname)
    atexit_remove_file(fname)
    assert not os.path.exists(fname)



# Generated at 2022-06-20 21:18:40.032224
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():

    # Create a suite for testing the class factory RedirectHandlerFactory
    # and an instance of the factory to test across all tests in the suite
    suite = unittest.TestSuite()
    factory = RedirectHandlerFactory(follow_redirects=True)

    # Create RedirectHandler instance, with the class factory's follow_redirects value,
    # and assign it to a variable to use in tests
    handler = factory()

    # Create a RedirectHandler instance and assign it to a variable
    # to use in tests and reference against the factory-created handler
    handler_test = RedirectHandler(follow_redirects=True)

    def test_isinstance():
        '''Test that the class factory's RedirectHandler instance is
        an instance of the RedirectHandler class
        '''
        assert isinstance(handler, RedirectHandler)

   

# Generated at 2022-06-20 21:18:43.154990
# Unit test for function basic_auth_header
def test_basic_auth_header():
    assert basic_auth_header('foo', 'bar') == b"Basic Zm9vOmJhcg=="
    # test that the utf-8 encoding of the string is used in Python3
    assert basic_auth_header('foo', 'бар') == b"Basic Zm9vOuKvhqw="



# Generated at 2022-06-20 21:18:49.025135
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    e = ConnectionError()
    assert str(e) == ''
    assert repr(e) == 'ConnectionError()'
    e = ConnectionError('message')
    assert str(e) == 'message'
    assert repr(e) == "ConnectionError('message',)"
    e = ConnectionError('message', 'code')
    assert str(e) == 'message'
    assert repr(e) == "ConnectionError('message', 'code')"
    try:
        raise ConnectionError
    except ConnectionError as e:
        assert str(e) == ''
        assert repr(e) == 'ConnectionError()'
    try:
        raise ConnectionError('message')
    except ConnectionError as e:
        assert str(e) == 'message'
        assert repr(e) == "ConnectionError('message',)"