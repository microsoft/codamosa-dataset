

# Generated at 2022-06-20 21:14:36.935758
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    assert hasattr(httplib, 'HTTPSConnection') and hasattr(urllib_request, 'HTTPSHandler')
    assert CustomHTTPSConnection



# Generated at 2022-06-20 21:14:37.452305
# Unit test for method get of class Request
def test_Request_get():
    pass

# Generated at 2022-06-20 21:14:40.182402
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():  # pylint: disable=invalid-name
    # Test with a valid socket file
    with tempfile.NamedTemporaryFile() as _file:
        unix_conn = UnixHTTPConnection(_file.name)
        unix_conn.connect()
        # Test with an invalid socket file
        with pytest.raises(OSError):
            unix_conn = UnixHTTPConnection('/invalid/dir/file/name')
            unix_conn.connect()


# Generated at 2022-06-20 21:14:48.113922
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        from urllib import request as url_request
    except ImportError:
        url_request = None

    try:
        from urllib3 import connectionpool
    except ImportError:
        connectionpool = None

    try:
        from requests.packages.urllib3 import connectionpool
    except ImportError:
        pass

    # Don't fail if we are missing mock_module
    try:
        # pylint: disable=unused-variable
        from test.support import mock_module
    except ImportError:
        mock_module = None

    try:
        from unittest import mock
    except ImportError:
        mock = None


# Generated at 2022-06-20 21:14:55.200531
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    answer = 'Mon, 02 Jun 2003 11:22:33 -0400 (EDT)'
    tt = time.strptime(answer, '%a, %d %b %Y %H:%M:%S %z (%Z)')
    assert rfc2822_date_string(
        time.gmtime(time.mktime(tt)),
        date.tzname(tt, True)
    ) == answer



# Generated at 2022-06-20 21:14:57.014435
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    msg = 'Failure message'
    exc = NoSSLError(msg)
    assert exc.message == msg
    # Verify is backwards compat with the old name of this exception
    assert exc.message == exc.args[0]



# Generated at 2022-06-20 21:15:01.277340
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    test_ca_path = 'C:/Ansible/ca_path.pem'
    class TestUrlparse(object):
        def __init__(self, p):
          self.path = p
          self.port = None
          self.hostname = None
    class DummySSLError(Exception):
        pass
    ssl_handler = maybe_add_ssl_handler('https://google.com', True, ca_path=test_ca_path)
    assert isinstance(ssl_handler, SSLValidationHandler) == True
    assert ssl_handler.hostname == 'google.com'
    assert ssl_handler.port == 443
    assert ssl_handler.ca_path == test_ca_path

# Generated at 2022-06-20 21:15:02.161547
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    msg = 'test msg'
    e = ConnectionError(msg)
    assert str(e) == msg



# Generated at 2022-06-20 21:15:06.386652
# Unit test for constructor of class MissingModuleError
def test_MissingModuleError():
    exception = None
    try:
        import module_that_should_not_exist
    except ImportError as e:
        exception = MissingModuleError("test_MissingModuleError", traceback.format_exc())

    # Verify that the import_traceback contains lines from the actual ImportError that is caught
    # We don't compare the full traceback because the line numbers will differ
    for line in exception.import_traceback:
        assert("module_that_should_not_exist" in line or "test_MissingModuleError" in line)



# Generated at 2022-06-20 21:15:15.149860
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    import unittest

    class RedirectHandlerTest(unittest.TestCase):
        def test_redirect_handler_factory_class(self):
            rhf = RedirectHandlerFactory(follow_redirects=False)
            self.assertEqual(rhf.__name__, 'RedirectHandler')
            self.assertTrue(issubclass(rhf, urllib_request.HTTPRedirectHandler))

        def test_redirect_handler_factory_instance(self):
            rhf = RedirectHandlerFactory(follow_redirects=False)
            redirect_handler = rhf()
            self.assertEqual(redirect_handler.__class__.__name__, 'RedirectHandler')
            self.assertIsInstance(redirect_handler, urllib_request.HTTPRedirectHandler)



# Generated at 2022-06-20 21:16:06.805681
# Unit test for method patch of class Request
def test_Request_patch():
    params = {}
    params[u"url"] = u"http://www.google.com"
    params[u"data"] = u"test"
    params[u"headers"] = u"test"
    params[u"use_proxy"] = "False"
    params[u"force"] = "False"
    params[u"last_mod_time"] = "None"
    params[u"timeout"] = "5"
    params[u"validate_certs"] = "False"
    params[u"url_username"] = "None"
    params[u"url_password"] = "None"
    params[u"http_agent"] = "None"
    params[u"force_basic_auth"] = "False"
    params[u"follow_redirects"] = "yes"

# Generated at 2022-06-20 21:16:11.327042
# Unit test for function generic_urlparse

# Generated at 2022-06-20 21:16:12.910767
# Unit test for constructor of class SSLValidationError
def test_SSLValidationError():
    err = SSLValidationError('the message')
    assert str(err) == "the message"



# Generated at 2022-06-20 21:16:18.597003
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    '''This is a hack to allow us to access the private attribute _unix_socket
    since it's defined in the __init__ method and therefore not part of the
    instance's __dict__.
    '''
    # pylint: disable=protected-access
    _unix_socket = UnixHTTPSConnection.__init__.__func__.__code__.co_varnames.index('unix_socket')
    conn = UnixHTTPSConnection('unix://hostname:8080')
    conn._set_hostport('hostname', '8080')
    conn.connect()
    assert conn.sock == mock.ANY
    assert conn.sock._sock.fileno() == _unix_socket + 1
    # pylint: enable=protected-access



# Generated at 2022-06-20 21:16:22.977167
# Unit test for method __call__ of class UnixHTTPConnection
def test_UnixHTTPConnection___call__():
    '''test_UnixHTTPConnection___call__'''
    unix_socket = '/tmp/test.sock'
    uh = UnixHTTPConnection(unix_socket)
    uh(host=unix_socket, port=8080)



# Generated at 2022-06-20 21:16:23.370936
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    pass

# Generated at 2022-06-20 21:16:25.967890
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    # Test with and without an exception
    for exc in (None, Exception('fake')):
        try:
            build_ssl_validation_error('localhost', 443, ['fakepath'], exc)
        except SSLValidationError as e:
            if exc:
                assert str(exc) in str(e)
            else:
                assert str(exc) not in str(e)



# Generated at 2022-06-20 21:16:38.782081
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    # pylint: disable=unused-variable
    ssl_kwargs = {'ssl_version': PROTOCOL,
                  'keyfile': None,
                  'certfile': None,
                  'cert_reqs': ssl.CERT_NONE,
                  'ca_certs': None,
                  'suppress_ragged_eofs': True}

    url1 = urlparse('https://127.0.0.1:8080')
    conn1 = UnixHTTPSConnection('/path/to/unix_socket')
    actual = conn1('127.0.0.1', 8080)
    assert actual.host == url1.hostname
    assert actual.port == url1.port
    assert actual._sock is None
    assert actual._unix_socket == '/path/to/unix_socket'

# Generated at 2022-06-20 21:16:44.687889
# Unit test for function rfc2822_date_string
def test_rfc2822_date_string():
    import time
    test_time = time.localtime(1173759067)
    assert(rfc2822_date_string(test_time) == 'Fri, 09 Nov 2007 01:08:47 -0000')



# Generated at 2022-06-20 21:16:48.886694
# Unit test for function url_argument_spec
def test_url_argument_spec():
    assert isinstance(url_argument_spec(), dict)
    assert url_argument_spec()['url'] == dict(type='str')
    assert url_argument_spec()['force'] == dict(type='bool', default=False, aliases=['thirsty'],
                                                deprecated_aliases=[dict(name='thirsty', version='2.13',
                                                                         collection_name='ansible.builtin')])
    assert url_argument_spec()['http_agent'] == dict(type='str', default='ansible-httpget')
    assert url_argument_spec()['use_proxy'] == dict(type='bool', default=True)
    assert url_argument_spec()['validate_certs'] == dict(type='bool', default=True)