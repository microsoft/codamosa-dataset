

# Generated at 2022-06-20 21:13:18.188379
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    url = "https://github.com"
    req = urllib_request.Request(url)
    hostname, port = get_hostname(req)
    ssl_handler = SSLValidationHandler(hostname, port)
    assert ssl_handler.hostname == hostname
    assert ssl_handler.port == port



# Generated at 2022-06-20 21:13:26.890274
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    d = ParseResultDottedDict(scheme='http', netloc='localhost')
    assert d['scheme'] == 'http'
    assert d.scheme == 'http'
    assert d.netloc == 'localhost'
    assert d.as_list() == ['http', 'localhost', None, None, None, None]

# Note the NOQA below is to disable "Unused variable" warnings. It is
# important these calls are made so that the module that uses this module can
# make equivilant calls so that they are not missing the modules when they
# are loaded
requests  # NOQA
urllib_request  # NOQA
urllib_error  # NOQA
urllib_parse  # NOQA


#
# URL helpers
#

_VALID_SCHEMES = re

# Generated at 2022-06-20 21:13:32.459961
# Unit test for method options of class Request
def test_Request_options():
    dummy_url = 'http://www.dummy.com'
    req = Request()
    #print(">>>>>>>>>>>>>>>", req.options(dummy_url))
    #for key, value in req.options(dummy_url).headers.items():
    #    print("{}:{}".format(key, value))
test_Request_options()

# Generated at 2022-06-20 21:13:40.283874
# Unit test for constructor of class ParseResultDottedDict
def test_ParseResultDottedDict():
    data = {
        'scheme': 'ftp',
        'netloc': 'foo',
        'path': 'bar',
        'params': 'foo',
        'query': 'bar',
        'fragment': 'baz',
        'blah': 'not_here',
    }
    prdd = ParseResultDottedDict(data)
    assert isinstance(prdd, dict)
    assert isinstance(prdd, ParseResultDottedDict)
    assert hasattr(prdd, 'scheme')
    assert hasattr(prdd, 'netloc')
    assert not hasattr(prdd, 'blah')
    assert prdd.scheme == 'ftp'
    assert prdd['path'] == 'bar'
    assert prdd.blah == None

# Generated at 2022-06-20 21:13:47.422328
# Unit test for method post of class Request
def test_Request_post():
    """
    Test post method of class Request
    :return:
    """
    print(Request.post.__doc__)
    url = 'http://www.google.com'
    result = Request.post(url)
    print(result.read().decode())


if __name__ == '__main__':
    test_Request_post()

# Generated at 2022-06-20 21:13:56.900814
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    http = HTTPSClientAuthHandler(client_cert='foo', client_key='bar')
    assert http.client_cert == 'foo'
    assert http.client_key == 'bar'


if sys.platform.startswith('linux') and hasattr(socket, 'AF_UNIX'):
    class UnixHTTPSConnection(httplib.HTTPConnection):
        def __init__(self, unix_socket, *args, **kwargs):
            self.unix_socket = unix_socket
            httplib.HTTPConnection.__init__(self, *args, **kwargs)

        def connect(self):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self.unix_socket)

# Generated at 2022-06-20 21:14:00.512328
# Unit test for method delete of class Request
def test_Request_delete():
    url = "https://httpbin.org/delete"
    req = Request()
    req.delete(url)
    print("TEST SUCESSFUL")



# Generated at 2022-06-20 21:14:03.109245
# Unit test for method post of class Request
def test_Request_post():
    httplib2_request = Request()
    str1 = httplib2_request.post("https://www.google.com/")
    assert(str1.status == 200)


# Generated at 2022-06-20 21:14:09.186820
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    import os
    import base64
    from cryptography.hazmat.primitives.hashes import Hashes
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.backends import default_backend
    from cryptography.x509.base import load_der_x509_certificate
    pyopenssl_backend = cryptography.hazmat.backends.openssl.backend

    ca_cert_path = os.path.expanduser(os.path.join('test', 'files', 'ansible_test_ca.crt'))
    server_cert_path = os.path.expanduser(os.path.join('test', 'files', 'ansible_test_cert.pem'))

# Generated at 2022-06-20 21:14:17.147187
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    try:
        conn = CustomHTTPSConnection(host="10.99.99.26", port="443", key_file="C:\\temp\\client.pem", cert_file="C:\\temp\\client.pem")
        conn.connect()
        print(conn.sock)
    except Exception as e:
        print(e)


# Generated at 2022-06-20 21:15:31.496140
# Unit test for method connect of class CustomHTTPSConnection
def test_CustomHTTPSConnection_connect():
    NONE_VALUE = None
    FALSE_VALUE = False
    TRUE_VALUE = True
    ZERO_VALUE = 0
    ONE_VALUE = 1
    TWO_VALUE = 2
    SPOOF_ADDRESS = "127.0.0.1"
    SPOOF_SOCKET = socket.create_connection((SPOOF_ADDRESS, 80), ONE_VALUE)
    SPOOF_SOCKET_RETURN = ssl.wrap_socket(SPOOF_SOCKET, keyfile=NONE_VALUE, certfile=NONE_VALUE, ssl_version=ssl.PROTOCOL_SSLv23)
    SPOOF_PORT = 443
    SPOOF_TUNNEL_HOST = "SpoofTunnelHost"
    SPOOF_HOST = "SpoofHost"
   

# Generated at 2022-06-20 21:15:40.519772
# Unit test for method detect_no_proxy of class SSLValidationHandler
def test_SSLValidationHandler_detect_no_proxy():

    class FakeReq(object):
        def __init__(self, url):
            self.url = url

        def get_full_url(self):
            return self.url

    handler = SSLValidationHandler('hostname', 443)
    # Check when no_proxy is set to a list of hostnames, wildcards
    os.environ['no_proxy'] = '*.dummy.com,hostname.com,1.1.1.1,0.0.0.0'
    # Check when no_proxy is set to a list of hostnames, wildcards
    assert handler.detect_no_proxy(FakeReq('https://www.dummy.com')) == False
    assert handler.detect_no_proxy(FakeReq('https://www.dummy.com:636')) == False

# Generated at 2022-06-20 21:15:42.898139
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    try:
        http_handler = CustomHTTPSHandler(debuglevel=0)
        http_handler.https_open("https://www.google.com")
    except Exception as error:
        assert False, "test_CustomHTTPSHandler_https_open() thrown error: " + str(error)


# Generated at 2022-06-20 21:15:53.306209
# Unit test for method make_context of class SSLValidationHandler
def test_SSLValidationHandler_make_context():
    if not HAS_SSLCONTEXT and not HAS_URLLIB3_PYOPENSSLCONTEXT:
        pytest.skip("SSL libraries too old for this test")
    ssl_handler = SSLValidationHandler("www.python.org", 443)
    tmp_ca_cert_path, _, _ = ssl_handler.get_ca_certs()
    if HAS_SSLCONTEXT:
        assert create_default_context(cafile=tmp_ca_cert_path) == ssl_handler.make_context(tmp_ca_cert_path, None)
    elif HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert PyOpenSSLContext(PROTOCOL) == ssl_handler.make_context(tmp_ca_cert_path, None)



# Generated at 2022-06-20 21:15:58.668444
# Unit test for method delete of class Request
def test_Request_delete():
    try:
        file_name = os.path.join(tempfile.gettempdir(), "log_%s_%s_%s.txt" % (strftime("%Y"), strftime("%m"), strftime("%d")))
        file1 = open(file_name, "w")
        file1.write("This is just a log file for testing purposes")
        file1.close()

        import shutil
        shutil.rmtree(file_name)
    except:
        pass

# Generated at 2022-06-20 21:16:09.465074
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    from ansible.module_utils.six.moves.urllib.request import Request, build_opener, install_opener
    SSLValidationHandler__hostname = '192.168.56.101'
    SSLValidationHandler__port = 443
    SSLValidationHandler__ca_path = None
    SSLValidationHandler__cert_file = None
    SSLValidationHandler__key_file = None
    SSLValidation_Handler = SSLValidationHandler(SSLValidationHandler__hostname, SSLValidationHandler__port, SSLValidationHandler__ca_path, SSLValidationHandler__cert_file, SSLValidationHandler__key_file)
    SSLValidation_Handler_http_request_req = Request('https://192.168.56.101:443/', None, None, {})
    SSLValidation_Handler_http_request_result

# Generated at 2022-06-20 21:16:11.403276
# Unit test for method get of class Request
def test_Request_get():
    request = Request()
    response = request.get('https://www.baidu.com')
    return response.read()

# Generated at 2022-06-20 21:16:17.753884
# Unit test for method validate_proxy_response of class SSLValidationHandler
def test_SSLValidationHandler_validate_proxy_response():
    handler = SSLValidationHandler('localhost', 80)
    try:
        handler.validate_proxy_response(b'HTTP/1.0 200 OK\r\n\r\n')
    except ProxyError:
        raise AssertionError('Connection to proxy is valid but exception is raised!')

    with pytest.raises(ProxyError) as exception:
        handler.validate_proxy_response(b'HTTP/1.0 200 OK\r\n\r\n', [404])
    assert 'Connection to proxy failed' == str(exception.value)



# Generated at 2022-06-20 21:16:23.279597
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    os.environ.pop('REQUESTS_CA_BUNDLE', None)

    handler = CustomHTTPSHandler()
    assert handler._context is None

    os.environ['REQUESTS_CA_BUNDLE'] = 'test/test_data/test-ca.pem'
    handler = CustomHTTPSHandler()
    if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert handler._context is not None

    os.environ['REQUESTS_CA_BUNDLE'] = 'test/test_data/test-bundle.pem'
    handler = CustomHTTPSHandler()
    if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
        assert handler._context is not None

    os

# Generated at 2022-06-20 21:16:29.949065
# Unit test for method delete of class Request
def test_Request_delete():
    # Test using this syntax:
    # r = Request()
    # filename = 'ansible_module_get_url_file'
    # r.delete(url = '/tmp/' + filename)

    r = Request()
    filename = 'ansible_module_get_url_file'
    r.delete(url = '/tmp/' + filename)


# Generated at 2022-06-20 21:18:24.062909
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    try:
        import pytest
        from py._xmlgen import html
    except ImportError:
        pytest = None
    has_ssl = HAS_SSL
    HAS_SSL = True

# Generated at 2022-06-20 21:18:26.743425
# Unit test for method patch of class Request
def test_Request_patch():
    pass



# Generated at 2022-06-20 21:18:32.469114
# Unit test for constructor of class UnixHTTPHandler
def test_UnixHTTPHandler():
    try:
        from unittest import TestCase
    except ImportError:
        from unittest2 import TestCase

    class TestUnixHTTPHandler(TestCase):
        def test_unix_http_handler_construction(self):
            handler = UnixHTTPHandler('foo')
            self.assertTrue(isinstance(handler, UnixHTTPHandler))

    tc = TestUnixHTTPHandler()
    tc.test_unix_http_handler_construction()



# Generated at 2022-06-20 21:18:35.150062
# Unit test for method patch of class Request
def test_Request_patch():
    urllib_request=Request()
    url="test"
    method="test"
    valid=True
    try:
        urllib_request.patch(url, method=method)
    except:
        valid=False
    assert valid
    assert urllib_request.get_method == method

# Generated at 2022-06-20 21:18:37.448966
# Unit test for constructor of class ProxyError
def test_ProxyError():
    e = ProxyError("foo")
    assert str(e) == "foo", "str() result should be 'foo' but is %s" % e
    assert e.__class__.__name__ == "ProxyError", "__class__.__name__ result should be 'ProxyError' but is %s" % e.__class__.__name__



# Generated at 2022-06-20 21:18:44.319821
# Unit test for method connect of class UnixHTTPConnection
def test_UnixHTTPConnection_connect():

    temp_socket = tempfile.mktemp()

    unix_http_connection = UnixHTTPConnection(temp_socket)
    # If an exception is thrown, the test will fail
    unix_http_connection.connect()
    os.unlink(temp_socket)


# Generated at 2022-06-20 21:18:47.903754
# Unit test for method __call__ of class UnixHTTPSConnection
def test_UnixHTTPSConnection___call__():
    unix_htc = UnixHTTPSConnection('/tmp/test')
    assert unix_htc('localhost')


# Generated at 2022-06-20 21:18:53.375110
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    url = 'https://github.com/ansible/ansible/pulls'
    handler, _ = maybe_add_ssl_handler(url, validate_certs=True)
    assert isinstance(handler, SSLValidationHandler) is True