

# Generated at 2022-06-20 21:13:08.254545
# Unit test for function maybe_add_ssl_handler
def test_maybe_add_ssl_handler():
    # Builtin urllib does not support proxies
    if not HAS_URLLIB3:
        return
    # SSLValidationHandler requires a hostname, skip if no network connection
    try:
        socket.gethostbyname(socket.gethostname())
    except Exception:
        return
    ca_path = '/etc/ssl/certs/ca-certificates.crt'
    if not os.path.exists(ca_path):
        ca_path = '/etc/pki/tls/cert.pem'

    args = [
        ('https://github.com', True, None),
        ('https://github.com', False, None),
        ('https://github.com', True, ca_path),
        ('http://github.com', True, ca_path),
    ]

# Generated at 2022-06-20 21:13:12.657928
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    # Note: On some platforms urllib2 does not define HTTPSHandler, so if
    # HTTPSHandler is not defined we skip the unit test
    if CustomHTTPSHandler is None:
        return
    class TestHTTPSHandler(CustomHTTPSHandler):
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
        def https_open(self, req):
            self.do_open(*self._args, **self._kwargs)

    def test(ssl_version):
        if not HAS_SSLCONTEXT:
            return
        handler = TestHTTPSHandler()
        connection = CustomHTTPSConnection._context.wrap_socket(
            socket.socket(),
            ssl_version=ssl_version,
        )
        handler.do_open(connection, None)

# Generated at 2022-06-20 21:13:15.076704
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    class TestSSLValidationHandler(SSLValidationHandler):
        pass
    handler = TestSSLValidationHandler(None, None)

    # Test 1
    # set ca_path
    handler.ca_path = '/etc/ansible/test'
    assert_equal(handler.get_ca_certs(), ('/etc/ansible/test', bytearray(), []))

# Generated at 2022-06-20 21:13:20.948321
# Unit test for function fetch_file
def test_fetch_file():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        # write a temporary file
        f.write(b"Hello world")
        f.seek(0)
        # use the temporary file as a url
        assert fetch_file(None, f.name) == f.name


# Generated at 2022-06-20 21:13:25.459847
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    b = ParseResultDottedDict({'scheme':'scheme', 'netloc':'netloc', 'path':'path', 'params':'params', 'query':'query', 'fragment':'fragment'})
    assert(b.as_list() == ['scheme', 'netloc', 'path', 'params', 'query', 'fragment'])


# Generated at 2022-06-20 21:13:35.916043
# Unit test for method get of class Request
def test_Request_get():
    # Create a request object
    req = Request()
    
    # Session object test
    s = requests.Session()
    req = Request(s)
    
    # Test the get method
    r = req.get('http://httpbin.org/get')
    #print(r.status_code)
    #print(r.text)
    #print(r.content)
    assert r.status_code == 200
    #print(r.headers)
    assert (r.headers['Content-Type'] == 'application/json')
    
    # Test the get method with arguments
    r = req.get('http://httpbin.org/get?a=5&b=10')
    assert r.status_code == 200
    #print(r.text)
    #print(r.content)
    #print(r.

# Generated at 2022-06-20 21:13:39.940676
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    SSLValidationHandler('google.com', 443)


# Generated at 2022-06-20 21:13:42.139884
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    # Test that CustomHTTPSHandler object is created successfully
    https_handler = CustomHTTPSHandler()
    assert https_handler is not None



# Generated at 2022-06-20 21:13:48.207972
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    u = UnixHTTPConnection('/tmp/foo')
    assert u._unix_socket == '/tmp/foo'
    assert u.timeout is socket._GLOBAL_DEFAULT_TIMEOUT

    u = UnixHTTPConnection('/tmp/foo', timeout=1)
    assert u._unix_socket == '/tmp/foo'
    assert u.timeout == 1


# Generated at 2022-06-20 21:13:57.557687
# Unit test for constructor of class HTTPSClientAuthHandler
def test_HTTPSClientAuthHandler():
    '''Tests the constructor of class HTTPSClientAuthHandler'''

    # Test that ssl_client_auth_handler's constructor sets its _context
    # attribute to a ssl._SSLContext instance
    # Note: ssl_client_auth_handler is a proxy to class HTTPSClientAuthHandler,
    # and it is used instead of HTTPSClientAuthHandler directly because the
    # former is imported in module urllib3
    ssl_client_auth_handler = HTTPSClientAuthHandler()
    assert hasattr(ssl_client_auth_handler, '_context')
    assert isinstance(ssl_client_auth_handler._context, ssl.SSLContext)

    # Test that ssl_client_auth_handler's constructor sets its _context
    # attribute to a urllib3.contrib.pyopenssl.WrappedContext instance
    # Note:

# Generated at 2022-06-20 21:15:21.890913
# Unit test for method open of class Request
def test_Request_open():
    """
    Test method open of class:`Request`

    :return:
    """

    # Test case 1
    method = 'GET'
    url = 'http:www.google.com'
    data = b'aa'
    header = {'header_key': 'header_value'}
    use_proxy = False
    force = False
    last_mod_time = datetime.now()
    timeout = 33
    validate_certs = True
    url_username = None
    url_password = None
    http_agent = None
    force_basic_auth = None
    follow_redirects = None
    client_cert = None
    client_key = None
    cookies = None
    use_gssapi = False
    unix_socket = None
    ca_path = None
    unredirected_headers

# Generated at 2022-06-20 21:15:31.222702
# Unit test for method get_ca_certs of class SSLValidationHandler
def test_SSLValidationHandler_get_ca_certs():
    class MockObjectPath():
        def __init__(self, isdir=False):
            self.isdir = isdir

    class MockObjectFile():
        def __init__(self, read=False):
            self.read = read

    class MockObjectStat():
        def __init__(self, isfile=False):
            self.isfile = isfile

    class MockObjectWrapper():
        def __init__(self, exists=False, isfile=False):
            self.isfile = isfile
            self.exists = exists

    class MockObjectSSLContext():
        return_value = ""

    class MockObjectSubprocess():
        return_value = "1.1"

    class MockObjectSSLSocket():
        def __init__(self, isfile=False):
            self.isfile = isfile


# Generated at 2022-06-20 21:15:39.830759
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        unix_connection = UnixHTTPConnection('/path/to/socket')
        unix_connection.connect()
        assert unix_connection.sock is not None

    connection = httplib.HTTPConnection('host')
    connection.connect()
    assert connection.sock is not None


    with unix_socket_patch_httpconnection_connect():
        unix_connection = UnixHTTPSConnection('/path/to/socket')
        unix_connection.connect()
        assert unix_connection.sock is not None

    connection = httplib.HTTPSConnection('host')
    connection.connect()
    assert connection.sock is not None



# Generated at 2022-06-20 21:15:52.171213
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    if not HAS_CRYPTOGRAPHY:
        return

    # Use a SHA256 digest.
    test_certificate = CERT_SHA256

    # Check if cert hash produced matches expected hash.
    cert_hash = get_channel_binding_cert_hash(test_certificate)
    ansible_cert_hash = binascii.a2b_hex("c297f0a05d72b2e1fededa664a0eeaf58ce6b5c5c5e6283b25602d4183d3b681")
    assert cert_hash == ansible_cert_hash

    # Use a SHA1 digest.
    test_certificate = CERT_SHA1

    # Check if cert hash produced matches expected hash.
    cert_hash = get_channel_binding_cert_hash(test_certificate)

# Generated at 2022-06-20 21:15:57.433733
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    class Foobar(UnixHTTPConnection):
        def __init__(self, *args, **kwargs):
            super(Foobar, self).__init__(*args, **kwargs)
            # Make sure sock is set correctly
            assert self.sock.family == socket.AF_UNIX, "sock family should be AF_UNIX"
            assert self.sock.type == socket.SOCK_STREAM, "sock type should be SOCK_STREAM"

    with unix_socket_patch_httpconnection_connect():
        Foobar('/foo')


    class BarBaz(Foobar, httplib.HTTPConnection):
        pass

    with unix_socket_patch_httpconnection_connect():
        BarBaz('/foo')



# Generated at 2022-06-20 21:16:11.332735
# Unit test for method connect of class UnixHTTPSConnection
def test_UnixHTTPSConnection_connect():
    test_ssl_version = 'SSLv23'

    class TestUnixHTTPSConnection(UnixHTTPSConnection):

        def __init__(self, unix_socket):
            self.ssl_version_called = None
            super(TestUnixHTTPSConnection, self).__init__(unix_socket)

        def _wrap_socket(self, sock, server_hostname=None):
            self.ssl_version_called = PROTOCOL
            return super(TestUnixHTTPSConnection, self)._wrap_socket(sock, server_hostname)

        def connect(self):
            with unix_socket_patch_httpconnection_connect():
                super(TestUnixHTTPSConnection, self).connect()

    unix_socket = '/tmp/test_UnixHTTPSConnection.sock'

# Generated at 2022-06-20 21:16:19.423455
# Unit test for constructor of class CustomHTTPSConnection
def test_CustomHTTPSConnection():
    # Constructor of class CustomHTTPSConnection sets self.context
    # using self.cert_file, self.key_file in the following case:
    # HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT == True
    if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
        # create a instance of class CustomHTTPSConnection
        custom_https_connection = CustomHTTPSConnection('', 0)
        # create a dummy self.cert_file, self.key_file
        cert_file = key_file = 'dummy'
        # set self.context using self.cert_file, self.key_file
        custom_https_connection.context = custom_https_connection._context
        custom_https_connection.cert_file = cert_file
       

# Generated at 2022-06-20 21:16:19.886178
# Unit test for method http_request of class SSLValidationHandler
def test_SSLValidationHandler_http_request():
    pass


# Generated at 2022-06-20 21:16:30.755359
# Unit test for function url_argument_spec
def test_url_argument_spec():

    from ansible.module_utils.urls import url_argument_spec

    t_result = url_argument_spec()
    assert isinstance(t_result, dict)
    assert 'url' in t_result
    assert 'force' in t_result
    assert 'http_agent' in t_result
    assert 'use_proxy' in t_result
    assert 'validate_certs' in t_result
    assert 'url_username' in t_result
    assert 'url_password' in t_result
    assert 'force_basic_auth' in t_result
    assert 'client_cert' in t_result
    assert 'client_key' in t_result
    assert 'use_gssapi' in t_result

    t_result = url_argument_spec()['url']

# Generated at 2022-06-20 21:16:38.501512
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    unix_socket = '/var/run/docker.sock'
    mock_req = Mock()
    handler = UnixHTTPHandler(unix_socket)
    handler.do_open = Mock()
    handler.http_open(mock_req)
    handler.do_open.assert_called_once_with(UnixHTTPConnection(unix_socket), mock_req)


# Generated at 2022-06-20 21:17:41.817150
# Unit test for constructor of class NoSSLError
def test_NoSSLError():
    try:
        raise NoSSLError
    except SSLValidationError:
        pass
    except Exception as e:
        raise AssertionError("NoSSLError constructor failed: raised %s" % e.__class__.__name__)
test_NoSSLError()


# Generated at 2022-06-20 21:17:44.814998
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    url = 'http://www.example.com/'
    method = 'DELETE'
    data = None
    headers = {'Content-Type': 'application/json'}
    origin_req_host = None
    unverifiable = True
    request = RequestWithMethod(url, method, data, headers, origin_req_host, unverifiable)
    assert request.get_method() == method.upper()

#
# Character encoding
#


# Generated at 2022-06-20 21:17:46.511777
# Unit test for method put of class Request
def test_Request_put():
    # Test put method
    request = Request()
    request_object = request.put("https://placeholder.com/")
    assert request_object is not None
    print("Status code: " + str(request_object.status_code))


# Generated at 2022-06-20 21:17:58.018308
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    # Testing https_open method of CustomHTTPSHandler
    # with context provided
    context = ssl.create_default_context()
    customHTTPSHandler = CustomHTTPSHandler()

    if HAS_SSLCONTEXT:
        customHTTPSHandler._context = context
        conn = CustomHTTPSHandler.https_open(customHTTPSHandler, None)
        assert conn._context is not None
    # without context provided
    else:
        conn = CustomHTTPSHandler.https_open(customHTTPSHandler, None)
        assert conn._context is None


if HAS_URLLIB3:
    class UnixHTTPConnection(urllib3.connection.HTTPConnection):
        def __init__(self, host, port=None, timeout=DEFAULT_TIMEOUT, strict=None, socket_path=None, **kwargs):
            urllib

# Generated at 2022-06-20 21:18:05.509481
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    http_handler = CustomHTTPSHandler()
    assert isinstance(http_handler, custom_urllib_request.CustomHTTPSHandler)
    assert isinstance(http_handler, urllib_request.HTTPSHandler)

if hasattr(socket, 'AF_UNIX') and sys.platform.startswith('linux'):
    class UnixHTTPSConnection(httplib.HTTPConnection):
        """
        HTTPS connection over a UNIX socket
        """

# Generated at 2022-06-20 21:18:13.588865
# Unit test for constructor of class SSLValidationHandler
def test_SSLValidationHandler():
    hostname = "www.example.com"
    port = 443
    ca_path = "/etc/ssl/certs"
    # If ca_path is provided, test initializing SSLValidationHandler
    SSLValidationHandler(hostname, port, ca_path)
    # If ca_path is not provided, test initializing SSLValidationHandler with default value.
    SSLValidationHandler(hostname, port)


# Generated at 2022-06-20 21:18:15.490616
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError("test_ConnectionError")
    assert to_native(err) == "test_ConnectionError"
    err = ConnectionError(10, "test_ConnectionError")
    assert to_native(err) == "(10, test_ConnectionError)"



# Generated at 2022-06-20 21:18:31.997104
# Unit test for constructor of class Request
def test_Request():
    def test(url):
        req = Request(url)
        assert req.host == 'www.example.com', req.host
        assert req.port == 80, req.port
        assert req.path == '/', req.path
        assert req.get_full_url() == 'http://www.example.com/', req.get_full_url()

    for url in ['http://www.example.com/', 'http://www.example.com', '//www.example.com']:
        yield test, url

if __name__ == '__main__':
    import sys
    import unittest
    sys.path.append('..')
    from test_urllib2 import FakeRedirectedHTTPConnection

    class MockSocket():
        def __init__(self):
            self._connected = False


# Generated at 2022-06-20 21:18:37.692008
# Unit test for function RedirectHandlerFactory
def test_RedirectHandlerFactory():
    '''
    Verify that the code returns an appropriate instance of the
    RedirectHandler class for the desired version of urllib.
    '''
    features = ('urllib3', 'urllib2_kerberos',)
    for feature in features:
        handler = RedirectHandlerFactory(follow_redirects=feature)()
        assert isinstance(handler, urllib_request.HTTPRedirectHandler)



# Generated at 2022-06-20 21:18:41.649054
# Unit test for function atexit_remove_file
def test_atexit_remove_file():
    '''
    test the atexit_remove_file() method
    '''
    filename = '/tmp/test_atexit_remove_file'
    with open(filename, 'w') as _file:
        _file.write(str(datetime.now()))
    atexit_remove_file(filename)
    assert not os.path.exists(filename)


JSONDecodeError = ValueError
if not hasattr(json, 'JSONDecodeError'):
    JSONDecodeError = ValueError

