

# Generated at 2022-06-20 21:13:51.269349
# Unit test for constructor of class UnixHTTPConnection
def test_UnixHTTPConnection():
    with pytest.raises(OSError) as exc:
        unix_socket = './test/test_runner/test/test_fixtures/test_urllib_no_socket'
        _ = UnixHTTPConnection(unix_socket)
    assert 'Invalid Socket File' in str(exc)



# Generated at 2022-06-20 21:13:52.865863
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    try:
        conn = UnixHTTPSConnection(None)
        conn('host', None)
    except Exception:  # pylint: disable=broad-except
        raise AssertionError('Constructor of class UnixHTTPSConnection does not work')



# Generated at 2022-06-20 21:14:04.691552
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    certificate_der = bytearray()
    if not HAS_CRYPTOGRAPHY:
        return
    digest_sha1 = b'\x19\xaf\x8e\x6e\xa6\x5c\xd5\xce\x3d\xf5\x36\x73\x8a\xc3\x02\x5b\x5b\x3d\xe5\x00'

# Generated at 2022-06-20 21:14:15.426070
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    filepath = os.path.join(os.path.dirname(__file__), 'fixtures', 'server.pem')

    with open(to_bytes(filepath, errors='surrogate_or_strict'), 'rb') as f:
        cert_pem = f.read()

    cert_der = ssl.PEM_cert_to_DER_cert(to_native(cert_pem))

    if HAS_CRYPTOGRAPHY:
        h = get_channel_binding_cert_hash(cert_der)

# Generated at 2022-06-20 21:14:22.117615
# Unit test for method put of class Request
def test_Request_put():
	url = "https://example.com"
	data = ""
	use_proxy = True 
	force = True
	timeout = 1
	validate_certs = True
	url_username = "username"
	url_password = "password"
	http_agent = "http_agent"
	force_basic_auth = True
	follow_redirects = "follow_redirects"
	client_cert = "client_cert"
	client_key = "client_key"
	cookies = {}
	use_gssapi = True
	unix_socket = "unix_socket"
	ca_path = "ca_path"
	unredirected_headers = ["",""]

	request = Request()

# Generated at 2022-06-20 21:14:24.744603
# Unit test for method as_list of class ParseResultDottedDict
def test_ParseResultDottedDict_as_list():
    assert list(ParseResultDottedDict().as_list()) == [None, None, None, None, None, None]
    assert list(ParseResultDottedDict(scheme='https').as_list()) == ['https', None, None, None, None, None]



# Generated at 2022-06-20 21:14:31.275526
# Unit test for function get_channel_binding_cert_hash
def test_get_channel_binding_cert_hash():
    """ Unit test for function get_channel_binding_cert_hash """
    if not HAS_CRYPTOGRAPHY:
        return

    # Load a certificate, and then use the DER version to test the channel binding,
    # as the only cert we can guarantee we have is this one.
    cert = x509.load_pem_x509_certificate(to_bytes(DEFAULT_BIND_CERT_FILE_TEXT), default_backend())
    # Get the DER version of the same cert
    certificate_der = cert.public_bytes(serialization.Encoding.DER)
    # Verify the hash algorithm is SHA256
    cert_hash = get_channel_binding_cert_hash(certificate_der)
    assert len(cert_hash) == 32

# Generated at 2022-06-20 21:14:37.072081
# Unit test for method http_open of class UnixHTTPHandler
def test_UnixHTTPHandler_http_open():
    url = 'http://localhost/'
    unix_socket = '/tmp/test.sock'
    env = dict(HTTP_PROXY=url, HTTPS_PROXY=url, http_proxy=url, https_proxy=url)
    def reset_environment(env):
        for envar in env:
            if env[envar]:
                os.environ[envar] = env[envar]
            else:
                if envar in os.environ:
                    del os.environ[envar]
    reset_environment(env)
    handler = UnixHTTPHandler(unix_socket, debuglevel=1)
    conn = handler.http_open(urllib_request.Request(url))
    env['HTTP_PROXY'] = None
    env['http_proxy'] = None
    reset_environment(env)


# Generated at 2022-06-20 21:14:47.428700
# Unit test for function build_ssl_validation_error
def test_build_ssl_validation_error():
    from ansible.utils.urls import build_ssl_validation_error
    global HAS_SSLCONTEXT
    global HAS_URLLIB3_PYOPENSSLCONTEXT
    global HAS_URLLIB3_SSL_WRAP_SOCKET

    temp_HAS_SSLCONTEXT = HAS_SSLCONTEXT
    temp_HAS_URLLIB3_PYOPENSSLCONTEXT = HAS_URLLIB3_PYOPENSSLCONTEXT
    temp_HAS_URLLIB3_SSL_WRAP_SOCKET = HAS_URLLIB3_SSL_WRAP_SOCKET

    # case 1: normal case for py >= 2.7.9
    HAS_SSLCONTEXT = True
    HAS_URLLIB3_PYOPENSSLCONTEXT = True


# Generated at 2022-06-20 21:14:50.953611
# Unit test for method put of class Request
def test_Request_put():
    req = Request()
    req.put('https://httpbin.org', data = 'me')
    return

# Generated at 2022-06-20 21:15:49.049890
# Unit test for constructor of class Request
def test_Request():
    request = Request('GET', 'http://test.com')
    assert request.get_unredirected_header('test') == None
    request.add_unredirected_header('test', 'test')
    assert request.get_unredirected_header('test') == 'test'
    request.remove_unredirected_header('test')
    assert request.get_unredirected_header('test') == None
    request.add_unredirected_header('test', 'test')
    assert request.get_unredirected_header('test') == 'test'


# Generated at 2022-06-20 21:15:57.703772
# Unit test for method delete of class Request
def test_Request_delete():
    import json
    import urllib.request
    import urllib.error
    import urllib.parse

    #response = delete(self, url, **kwargs)
    headers = {}
    headers['Content-Type'] = 'application/json'

    data = '{"email": "all@yourbase.com", "password": "hunter2"}'

    req = urllib.request.Request('http://test.com/auth', data.encode('utf8'), headers)
    req.get_method = lambda: 'DELETE'
    req.add_unredirected_header('Content-Type', 'application/json')

    resp = urllib.request.urlopen(req)
    print(resp.read())
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-20 21:16:00.682272
# Unit test for function unix_socket_patch_httpconnection_connect
def test_unix_socket_patch_httpconnection_connect():
    with unix_socket_patch_httpconnection_connect():
        httpcon = httplib.HTTPConnection(None)
        httpcon.connect()
        assert isinstance(httpcon.sock, socket.socket)

    httpcon = httplib.HTTPConnection(None)
    with pytest.raises(OSError):
        httpcon.connect()



# Generated at 2022-06-20 21:16:06.247900
# Unit test for function basic_auth_header
def test_basic_auth_header():
    b64 = base64.b64encode(to_bytes("Username:Password", errors='surrogate_or_strict'))
    assert b'Basic '+b64 == basic_auth_header('Username', 'Password')



# Generated at 2022-06-20 21:16:09.200568
# Unit test for method get_method of class RequestWithMethod
def test_RequestWithMethod_get_method():
    url = 'https://www.python.org'
    method = 'GET'
    data = None
    headers = None
    origin_req_host = None
    unverifiable = True
    request = RequestWithMethod(url, method, data, headers, origin_req_host, unverifiable)
    assert request.get_method() == 'GET'



# Generated at 2022-06-20 21:16:10.908582
# Unit test for function getpeercert
def test_getpeercert():
    try:
        response = urllib_request.urlopen("https://www.google.com")
        cert = getpeercert(response)
        assert (cert is not None)
    except Exception:
        assert(False)



# Generated at 2022-06-20 21:16:19.069330
# Unit test for method https_open of class CustomHTTPSHandler
def test_CustomHTTPSHandler_https_open():
    with pytest.raises(AttributeError):
        CustomHTTPSHandler()
    class MyCustomHTTPSHandler(CustomHTTPSHandler):
        def do_open(self, connection, req):
            return "A String"
    assert MyCustomHTTPSHandler().https_open('request') == "A String"

if HAS_SSLCONTEXT or HAS_URLLIB3_PYOPENSSLCONTEXT:
    class UnixHTTPSConnection(CustomHTTPSConnection):
        '''
        Unix domain socket HTTPSConnection class. Behaves the same as a regular
        HTTPS connection, but connects over a unix socket.
        '''
        # This implementation has been heavily influenced by the implementation
        # of UnixSocketHandler in werkzeug (BSD-licensed).

# Generated at 2022-06-20 21:16:29.589341
# Unit test for function url_argument_spec

# Generated at 2022-06-20 21:16:36.076329
# Unit test for constructor of class CustomHTTPSHandler
def test_CustomHTTPSHandler():
    c = CustomHTTPSHandler()



# Generated at 2022-06-20 21:16:38.316851
# Unit test for constructor of class UnixHTTPSConnection
def test_UnixHTTPSConnection():
    with UnixHTTPSConnection('/foo/bar') as conn:
        return conn

