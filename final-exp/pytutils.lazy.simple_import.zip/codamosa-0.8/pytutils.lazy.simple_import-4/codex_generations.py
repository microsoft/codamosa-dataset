

# Generated at 2022-06-12 07:44:04.244522
# Unit test for function make_lazy
def test_make_lazy():
    import my_module

    # assert `mod` is not loaded
    assert my_module is not None
    assert hasattr(my_module, 'y') is True
    assert my_module.y == 3

    # now assert it is loaded
    assert my_module.__dict__['y'] == 3
    assert hasattr(my_module, 'x') is False



# Generated at 2022-06-12 07:44:13.428263
# Unit test for function make_lazy
def test_make_lazy():

    # Create a fake module and add it to sys.modules
    class MyModule(object):
        def __init__(self, name):
            self.name = name

    my_module = MyModule('my_module')
    sys.modules['my_module'] = my_module

    # Ensure `my_module` exists
    assert 'my_module' in sys.modules

    # Remove `my_module` from sys.modules and call make_lazy
    del sys.modules['my_module']
    make_lazy('my_module')

    # Ensure `my_module` was not re-imported
    assert 'my_module' not in sys.modules

    # Ensure isinstance works on modules created by `make_lazy`
    assert isinstance(sys.modules['my_module'], _LazyModuleMarker)

    #

# Generated at 2022-06-12 07:44:22.121882
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    # Replace the sys.modules with our own dict
    # (it's a builtin so we can only override it)
    sys.modules = {}

    # Make a "fake" module so we can test against it.
    # We just put an attribute in the dict to fake out a module.
    module_name = 'a.b.c'
    sys.modules[module_name] = {'test': True}

    make_lazy(module_name)

    # Test that we have a lazy module
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # Test that accessing an attribute doesn't actually import
    try:
        sys.modules[module_name].test
        assert False, "Should error out of test attribute doesn't exist"
    except AttributeError:
        pass

    #

# Generated at 2022-06-12 07:44:29.633643
# Unit test for function make_lazy
def test_make_lazy():
    from twisted.trial.unittest import TestCase
    from twisted.internet.address import IPv4Address
    from twisted.internet.interfaces import IAddress
    from zope.interface.verify import verifyObject

    make_lazy('twisted.internet.address')
    make_lazy('zope.interface.verify')

    class T(TestCase):
        def test_lazy_module(self):
            test_ip = IPv4Address('TCP', '127.0.0.1', 12345)
            verifyObject(IAddress, test_ip)

    T().run()

# Generated at 2022-06-12 07:44:37.456221
# Unit test for function make_lazy
def test_make_lazy():
    # Make lazy module
    make_lazy('test_lazy_module')

    import test_lazy_module

    # Check if the lazy module is loaded
    assert sys.modules['test_lazy_module'] is not None

    # Check if the module has the right type
    assert isinstance(test_lazy_module, _LazyModuleMarker)

    # Check if we can access an attribute in the lazy module
    assert test_lazy_module.test_value == 'Test Value'

    # Check if the module still has the right type
    assert isinstance(test_lazy_module, _LazyModuleMarker)

    # Check if the module is loaded again
    assert sys.modules['test_lazy_module'] is not None

# Generated at 2022-06-12 07:44:46.472420
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to see if the make_lazy function works.
    """
    def get_obj():
        """
        Grab an object from a module.
        """
        from crc import crc_hq

        return crc_hq.base.BASE_URL

    assert get_obj() == "http://localhost:8000"

    # Now make the module 'cr.crc' lazy.
    make_lazy('cr.crc')

    # Ensure that lazy imported modules don't get loaded from
    # the preloader (see cr_preload_apps)
    assert get_obj() == "http://localhost:8000"

    # Ensure that lazy imported modules don't get loaded from
    # the preloader (see cr_preload_apps)
    assert sys.modules.get('hq', None) is None

# Generated at 2022-06-12 07:44:55.149950
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy'] = None
    import test_make_lazy as mod
    make_lazy('test_make_lazy')
    # Check for ModuleType
    assert isinstance(mod, ModuleType)
    # Check for LazyModuleType
    assert isinstance(mod, _LazyModuleMarker)
    # Check that we haven't yet imported the module
    assert mod.test_make_lazy_fail is None
    # Return the module to its original state
    del sys.modules['test_make_lazy']



# Generated at 2022-06-12 07:44:58.730472
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo')
    import foo
    import sys
    assert isinstance(foo, _LazyModuleMarker)
    assert sys.modules['foo'].__class__ == ModuleType
    assert foo.__class__ == ModuleType

# Generated at 2022-06-12 07:45:05.965544
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('lazy_module_test_mod', None)

    module = make_lazy('lazy_module_test_mod')

    # module is a LazyModule instance
    assert isinstance(module, _LazyModuleMarker)

    # It should be a module type
    assert isinstance(module, ModuleType)

    # It should not have attr foo
    with pytest.raises(AttributeError):
        module.foo

    # When it is reimported, it should have attr foo
    import lazy_module_test_mod
    assert hasattr(lazy_module_test_mod, 'foo')

# Generated at 2022-06-12 07:45:09.269384
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    PATH = 'test_make_lazy_module'
    sys.modules[PATH] = 'fake module'

    make_lazy(PATH)

    assert PATH in sys.modules
    assert isinstance(sys.modules[PATH], _LazyModuleMarker)

    del sys.modules[PATH]

# Generated at 2022-06-12 07:45:21.915094
# Unit test for function make_lazy
def test_make_lazy():
    # Programmatically import `os` with `make_lazy`
    # and make sure it works for future imports (meaning `isinstance` works).
    module_path = 'os'
    make_lazy(module_path)
    lazy_os = sys.modules[module_path]

    import os
    assert os is sys.modules[module_path]
    assert isinstance(os, _LazyModuleMarker)
    assert os == lazy_os

    # Try to import `os` again, this time it should already be loaded.
    # Make sure the value didn't change.
    import os
    assert os is sys.modules[module_path]
    assert isinstance(os, _LazyModuleMarker)
    assert os == lazy_os

# Generated at 2022-06-12 07:45:30.250650
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy works properly.
    """
    # Test that make_lazy can be called without exception.
    make_lazy('test.test_lazy')

    try:
        # Can we access an attribute off of a lazy module?
        getattr(test_lazy, 'test_make_lazy')

        # We should have imported the module.
        assert module_test_lazy.is_imported
    finally:
        # Clean up
        del sys.modules['test.test_lazy']
        del sys.modules['test.module_test_lazy']


# Generated at 2022-06-12 07:45:39.735784
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        def __init__(self):
            self.a = 42
            self.b = 100

    sys.modules = {}

    make_lazy("test")

    # test module should not be loaded yet
    assert "test" not in sys.modules
    assert "test" not in globals()

    # test module should be loaded only when something is accessed
    assert sys.modules["test"].a == 42
    assert sys.modules["test"].b == 100

    assert "test" in sys.modules
    assert "test" in globals()

    # test module should be re-loaded when the lazy module is deleted
    assert sys.modules["test"].a == 42
    assert sys.modules["test"].b == 100

    assert "test" in sys.modules
    assert "test" in globals()

# Generated at 2022-06-12 07:45:50.324386
# Unit test for function make_lazy
def test_make_lazy():
    # Note: The unit test needs an absolute path for the module
    # in order for it to be found, so this test does not work as a relative
    # import.
    module_path = os.path.abspath(os.path.join('..', '..', '..', '..', 'lib', 'calculate', '__init__.py'))
    sys.path.append(os.path.abspath(".."))
    # Sanity check
    module = __import__("calculate")
    assert(hasattr(module, 'STOP'))
    assert(hasattr(module, 'FIVE'))

    # First, we reload the module. This empties the sys.modules dict
    # and lets us test the module's behavior from scratch
    reload(sys)
    sys.modules.pop("calculate")

# Generated at 2022-06-12 07:46:00.501106
# Unit test for function make_lazy
def test_make_lazy():
    from six.moves import reload_module
    import gc
    # Make sure that we don't import lazily for our unit test.
    # If we do, we cannot test that make_lazy does indeed
    # only import the module when called.
    try:
        del sys.modules['tests.test_lazy']
        gc.collect()
        import tests.test_lazy
        assert False, "Previous import should not have succeeded."
    except KeyError:
        pass

    make_lazy('tests.test_lazy')

    # Assert that the module is not yet loaded
    try:
        reload_module(sys.modules['tests.test_lazy'])
        assert False, "Module loaded lazily but should not have been."
    except TypeError:
        pass

    # assert that attributes are not loaded until called

# Generated at 2022-06-12 07:46:11.380765
# Unit test for function make_lazy
def test_make_lazy():
    assert sys.modules['pack_lazy_test_module'] is None
    import pack_lazy_test_module
    assert isinstance(pack_lazy_test_module, _LazyModuleMarker)
    assert pack_lazy_test_module.__name__ == 'pack_lazy_test_module'
    pack_lazy_test_module.__package__ == 'pack_lazy_test_module'
    sys.modules['pack_lazy_test_module'] is None
    assert 'test_func' not in sys.modules

    # Executing function 'test_func' from the test module
    pack_lazy_test_module.test_func()

    # Check that the module and it's attr was loaded
    assert sys.modules['pack_lazy_test_module'] is not None

# Generated at 2022-06-12 07:46:21.664290
# Unit test for function make_lazy
def test_make_lazy():
    """
    The function `make_lazy` should not import the desired module until
    a attribute is needed off of the module.
    """
    # Create a fake module with an attribute of 'A'
    import os
    test_path = 'test_lazy_attribute'
    with open(os.path.join(test_path, '__init__.py'), 'w') as f:
        f.write('A = 1')

    # Try to import the module
    import test_lazy_attribute
    assert hasattr(test_lazy_attribute, 'A')

    reload(sys)
    sys.setdefaultencoding('utf-8')

    # Simulate a browser page refresh where the module is still in memory
    del sys.modules[test_path]

    # Mark that we should not import it until an attribute is requested
   

# Generated at 2022-06-12 07:46:25.651989
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import name_test
    import sys
    make_lazy('name_test')
    assert isinstance(name_test, _LazyModuleMarker)
    assert name_test.test_me == 'Hello world!'
    assert isinstance(name_test, ModuleType)
    del sys.modules['name_test']

# Generated at 2022-06-12 07:46:35.523429
# Unit test for function make_lazy
def test_make_lazy():
    # Remove the module from sys.modules if it already exists
    module_name = "test_make_lazy_module"
    module_path = "test_make_lazy_module"
    if module_name in sys.modules:
        del sys.modules[module_name]

    make_lazy(module_path)

    # Verify that the module is not loaded and is a LazyModule
    if module_name in sys.modules:
        raise AssertionError("Module should not be loaded before first use")
    if not isinstance(sys.modules[module_path], _LazyModuleMarker):
        raise AssertionError("Module should be a LazyModule type")

    # LazyModule should respond to getattribute without error
    sys.modules[module_path].__getattribute__("VALUE")

# Generated at 2022-06-12 07:46:41.354379
# Unit test for function make_lazy
def test_make_lazy():
    # Test case
    import sys
    import sys

    make_lazy('sys')

    # No exception will be raised if the function works correctly
    if sys.version_info > (3,):
        assert sys.version_info == (3,7,4, 'final', 0)
    else:
        assert sys.version_info == (2,7,15,'final',0)

    print('Tested')


# Calling the test function
test_make_lazy()

# Generated at 2022-06-12 07:46:53.314737
# Unit test for function make_lazy
def test_make_lazy():
    import os.path
    make_lazy('os.path')
    assert isinstance(os.path, _LazyModuleMarker)
    assert os.path.basename('/home/user/test.txt') == 'test.txt'
    assert os.path.basename('/home/user/') == 'user'
    assert os.path.basename('/home/user') == 'user'
    assert os.path.basename('/home') == 'home'
    assert os.path.basename('/abc') == 'abc'
    assert os.path.basename('/') == '/'
    assert os.path.basename('') == ''

# Generated at 2022-06-12 07:46:56.791428
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo')
    assert isinstance(sys.modules['foo'], _LazyModuleMarker)

    # Re-importing foo should return the same object
    import foo
    assert foo is sys.modules['foo']

# Generated at 2022-06-12 07:47:05.098347
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy
    """
    from cosmo.test import test_module
    assert test_module.__name__ == 'cosmo.test.test_module'
    assert isinstance(test_module, ModuleType)
    assert not isinstance(test_module, _LazyModuleMarker)
    assert test_module.attr == 'attr_value'

    make_lazy('cosmo.test.test_module')
    assert 'cosmo.test.test_module' in sys.modules
    assert isinstance(sys.modules['cosmo.test.test_module'], _LazyModuleMarker)
    assert not isinstance(sys.modules['cosmo.test.test_module'], ModuleType)

    assert test_module.attr == 'attr_value'

# Generated at 2022-06-12 07:47:10.600643
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['module_under_test'] = 'module_under_test'
    make_lazy('module_under_test')
    with pytest.raises(AttributeError) as err:
        sys.modules['module_under_test']
    assert err.value.args[0] == 'LazyModule object has no attribute foo'


# Generated at 2022-06-12 07:47:17.080614
# Unit test for function make_lazy
def test_make_lazy():
    """
    Lazy modules can be imported without causing importation errors.
    """
    make_lazy('os.path')
    import os
    assert os.path
    assert isinstance(os.path, _LazyModuleMarker)
    assert os.path.isfile is os.path.exists is os.path.dirname
    assert os.path.dirname.__module__ == 'os.path'
    assert callable(os.path.dirname)
    assert isinstance(os.path, _LazyModuleMarker)

# Generated at 2022-06-12 07:47:25.950712
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit tests for make_lazy() and NonLocal
    """
    # check if NonLocal works
    nonlocal_var = NonLocal(0)
    assert nonlocal_var.value == 0
    nonlocal_var.value = 1
    assert nonlocal_var.value == 1
    # check if make_lazy works
    sys.modules['a'] = None
    make_lazy('a')
    assert 'a' in sys.modules
    a = sys.modules['a']
    assert 'b' not in sys.modules
    assert hasattr(a, '__name__')
    assert hasattr(a, '__file__')
    assert isinstance(a, _LazyModuleMarker)
    assert isinstance(a, ModuleType)
    assert isinstance(a, object)
    assert a.__name

# Generated at 2022-06-12 07:47:29.037141
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy('test_module')

    from test_module import a

    assert isinstance(a, NonLocal)

# Generated at 2022-06-12 07:47:40.264899
# Unit test for function make_lazy
def test_make_lazy():
    try:
        raise ValueError
    except ImportError:
        import sys
        import traceback
        return len(traceback.extract_tb(sys.exc_info()[2])) >= 4
    except:
        pass
    return False

if test_make_lazy() == True:
    _LazyModules = (
        'os',
        'io',
        're',
        'time',
        'traceback',
        'unicodedata',
        'zipimport',
        'imp',
        'posix',
        'errno',
        'signal',
        '__builtin__',
        'thread',
        'exceptions',
        '_functools',
    )


# Generated at 2022-06-12 07:47:47.143850
# Unit test for function make_lazy
def test_make_lazy():
    from .utils import _random_name, _random_module_name
    # import the module we are going to lazy-load
    mod_name = _random_module_name()
    var_name = _random_name()
    exec("from {} import {} as {}".format(mod_name, var_name, var_name))
    mod = __import__(mod_name)

    # make it lazy
    make_lazy(mod_name)

    # verify that it is lazy
    assert isinstance(mod, _LazyModuleMarker)

    # use it and make sure it gets imported
    some_var = getattr(mod, var_name)
    assert some_var == _random_name()

# Generated at 2022-06-12 07:47:57.337587
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    assert LazyModule not in sys.modules

    # Create a dummy module that we can import
    with open('lazy-test.py', 'w') as f:
        f.write('exit = False\n'
                'def do_exit():\n'
                '    global exit\n'
                '    exit = True\n')

    # import the module
    sys.path.append(os.getcwd())
    import lazy_test

    # ensure we actually loaded it
    assert lazy_test.exit is False

    lazy_test.do_exit()
    assert lazy_test.exit is True

    # clear and remove from sys.modules
    sys.path = [x for x in sys.path if x != os.getcwd()]
    del sys.modules['lazy_test']

# Generated at 2022-06-12 07:48:12.350239
# Unit test for function make_lazy
def test_make_lazy():
    import test.fakes.test_make_lazy

    assert isinstance(test, _LazyModuleMarker)
    assert isinstance(test.fakes, _LazyModuleMarker)
    assert isinstance(test.fakes.test_make_lazy, _LazyModuleMarker)

    assert isinstance(test.fakes.test_make_lazy.__name__, NonLocal)
    assert isinstance(test.fakes.test_make_lazy.__file__, NonLocal)

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-12 07:48:16.464765
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("lazy")
    print("first import")
    import lazy
    print("second import")
    import lazy
    print("first import after make_lazy")
    import lazy
    assert lazy.LAZY == "LAZY"
    assert lazy.laZy == "laZy"


# Generated at 2022-06-12 07:48:25.846665
# Unit test for function make_lazy
def test_make_lazy():
    # Test for normal cases
    for mod in ['os', 'sys']:
        try:
            del globals()[mod]
        except:
            pass

        try:
            del sys.modules[mod]
        except:
            pass

        import os
        import sys

        try:
            make_lazy(mod)
            assert mod not in globals()
            assert isinstance(sys.modules[mod], _LazyModuleMarker)

            # Try accessing the module attribute
            # It should be imported and the module object updated properly.
            getattr(sys.modules[mod], '__name__')
            assert mod in globals()
            assert isinstance(sys.modules[mod], ModuleType)
        finally:
            del sys.modules[mod]

    # Test for edge case
    make_lazy('_lazy')

# Generated at 2022-06-12 07:48:36.808052
# Unit test for function make_lazy
def test_make_lazy():
    class my_class(object):
        pass
    # create the dummy module
    import tempfile
    module_name = tempfile.mktemp()
    sys.modules[module_name] = my_class()
    # check that we can import the module normally
    import sys
    assert sys.modules[module_name] == my_class()
    # mark the module as lazy loading
    make_lazy(module_name)
    # check that the module is not loaded until we reference an object from it
    from pyfasta import __version__
    from pyfasta import __version__  # doing it twice just to be sure
    # check that the module is now properly loaded and return the correct object
    assert sys.modules[module_name] == my_class()

# ENSURE THAT OUR SYMBOLS ARE AS EXPECTED
test_

# Generated at 2022-06-12 07:48:42.400426
# Unit test for function make_lazy
def test_make_lazy():
    def lazy_import():
        # make_lazy won't be imported before accessing it's attribute
        make_lazy(__name__)

        make_lazy.make_lazy

    # Everything is fine here
    lazy_import()

    # Test if it is still lazy
    lazy_import()



# Generated at 2022-06-12 07:48:49.385483
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import pkg_resources

    # We should be able to import .version from the top level
    from .version import version

    # But the module should not be loaded into sys.modules until we
    # access an attribute.
    assert pkg_resources not in sys.modules

    make_lazy('pkg_resources')

    # Now, we should not be able to access version
    with pytest.raises(AttributeError):
        version

    # But we should be able to access pkg_resources.version
    assert sys.modules['pkg_resources'].version == version

# Generated at 2022-06-12 07:49:00.534495
# Unit test for function make_lazy
def test_make_lazy():
    import django.template.loaders.app_directories as _django_template_loaders_app_directories
    import django.template.loaders.filesystem as _django_template_loaders_filesystem
    import django.template.loaders.eggs as _django_template_loaders_eggs

    # Mark these modules as lazy
    make_lazy('django.template.loaders.app_directories')
    make_lazy('django.template.loaders.filesystem')
    make_lazy('django.template.loaders.eggs')

    # Import
    import django.template.loaders.app_directories as django_template_loaders_app_directories
    import django.template.loaders.filesystem as django_template_loaders_filesystem


# Generated at 2022-06-12 07:49:08.391102
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['foo'] = 0

    make_lazy('foo')

    # when
    import foo

    # then
    assert 'foo' in sys.modules
    assert sys.modules['foo'] == 0

    foo.bar = 42

    # when
    import foo

    # then
    assert 'foo' in sys.modules
    assert foo.bar == 42

    # cleanup
    del sys.modules['foo']

# Mark which modules should never be imported.
make_lazy('django_ilmoitin.models')
make_lazy('django_ilmoitin.template_tags')
make_lazy('django_ilmoitin.views')

# Generated at 2022-06-12 07:49:15.148491
# Unit test for function make_lazy
def test_make_lazy():
    # Ensure we need to import a module normally
    import logging
    assert isinstance(logging, ModuleType)

    # Ensure we can create a lazy module
    make_lazy('logging')
    assert isinstance(logging, _LazyModuleMarker)

    # Ensure it gets imported when we expect it to
    assert isinstance(logging.getLogger(), logging.Logger)

    # Ensure that the module gets removed when we expect it to
    del sys.modules['logging']
    assert 'logging' not in sys.modules

# Generated at 2022-06-12 07:49:23.959446
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """
    sys_modules = sys.modules

    module_path = 'test_module'
    module_name = 'test_func'

    def test_func():
        return module_name

    def test_main():
        """
        Test module.
        """
        return test_func()

    test_module = ModuleType(module_path)
    test_module.test_main = test_main

    sys_modules[module_path] = test_module

    make_lazy(module_path)

    assert module_path in sys_modules
    assert module_path not in sys.modules

    assert module_path in sys_modules
    assert not isinstance(sys_modules[module_path], ModuleType)

    assert module_path in sys_modules
    assert module_path

# Generated at 2022-06-12 07:49:37.693759
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import test_make_lazy
    make_lazy('test_make_lazy.foo')
    assert isinstance(test_make_lazy.foo, _LazyModuleMarker)
    assert not hasattr(test_make_lazy.foo, 'bar')
    assert not hasattr(sys.modules['test_make_lazy.foo'], 'bar')
    assert test_make_lazy.foo.bar == 'baz'
    assert hasattr(test_make_lazy.foo, 'bar')
    assert hasattr(sys.modules['test_make_lazy.foo'], 'bar')
    assert hasattr(test_make_lazy.foo, '__mro__')
    assert isinstance(test_make_lazy.foo, ModuleType)

    import test_make_l

# Generated at 2022-06-12 07:49:46.360045
# Unit test for function make_lazy
def test_make_lazy():
    """Tests to make sure make_lazy work correctly"""
    m = make_lazy('tests.lazymod')
    old_m = sys.modules.get('tests.lazymod')
    assert not old_m
    assert m
    assert isinstance(m, _LazyModuleMarker)
    assert m.test1
    assert m.test1() == 1
    new_m = sys.modules['tests.lazymod']
    assert m is new_m
    assert isinstance(new_m, ModuleType)

if __name__ == '__main__':
    test_make_lazy() # pragma: no cover

# Generated at 2022-06-12 07:49:57.518123
# Unit test for function make_lazy
def test_make_lazy():
    def import_err(*args, **kwargs):
        """
        Throw an ImportError
        """
        raise ImportError()

    test_module_path = 'import_error_module'

    sys.modules[test_module_path] = __import__(test_module_path)
    saved_import = __import__

    __builtins__.__import__ = import_err
    make_lazy(test_module_path)

    assert not hasattr(sys.modules[test_module_path], '__mro__')
    assert not hasattr(sys.modules[test_module_path], '__getattribute__')

    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)
    assert isinstance(sys.modules[test_module_path], ModuleType)

    # Test that accessing an

# Generated at 2022-06-12 07:50:09.330973
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    make_lazy('_test_dummy_module')
    mod = sys_modules['_test_dummy_module']
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__name__ == '_test_dummy_module'
    assert mod.__path__ == []
    assert mod.__package__ == ''
    assert mod.__doc__ is None
    assert mod.__loader__ is None
    assert mod.__file__ is None
    assert mod.__builtins__ is __builtins__
    assert mod.__cached__ is None
    assert mod.__spec__ is None
    assert isinstance(mod.__dict__, dict)
    assert mod.__dict__ == {}
    assert mod.__doc__ is None
    assert mod.__name__

# Generated at 2022-06-12 07:50:18.242186
# Unit test for function make_lazy
def test_make_lazy():
    import os
    path = os.path.abspath(__file__)
    dir_path = os.path.dirname(path)
    module_path = os.path.join(dir_path, 'lazy_module.py').replace('.py', '')
    make_lazy(module_path)

    # module_path is expected to be in sys.modules
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    from .lazy_module import FUNC_NAME
    assert FUNC_NAME == 'USER_DEFINED_FUNCTION'

# Generated at 2022-06-12 07:50:20.355207
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import os
        make_lazy('os')
        assert(isinstance(sys.modules['os'], _LazyModuleMarker))
        assert(not isinstance(os, _LazyModuleMarker))
        assert(isinstance(os, ModuleType))
    finally:
        # Restore original module
        sys.modules['os'] = os



# Generated at 2022-06-12 07:50:30.126263
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('my_import')

# Generated at 2022-06-12 07:50:40.552031
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    # Clear sys.modules, so we can import a blank module to test with
    sys.modules.clear()

    # Import a blank module, and check that it has been imported properly
    import test_mod_is_lazy

    assert test_mod_is_lazy.__name__ == 'test_mod_is_lazy'
    assert isinstance(test_mod_is_lazy, ModuleType)

    # Clear the module from sys.modules again, so we can try loading it
    # lazily
    del sys.modules['test_mod_is_lazy']

    # Mark the module as being lazy
    make_lazy('test_mod_is_lazy')

    # Check that the module is still importable, but that it is lazy

# Generated at 2022-06-12 07:50:47.110611
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run a simple unit test.
    """
    make_lazy("foo")
    import foo
    assert not isinstance(foo, _LazyModuleMarker)
    assert isinstance(sys.modules["foo"], _LazyModuleMarker)

    # This should trigger the load-up of 'foo'
    assert foo.__name__ == "foo"
    assert isinstance(foo, _LazyModuleMarker)
    assert not isinstance(sys.modules["foo"], _LazyModuleMarker)



# Generated at 2022-06-12 07:50:51.703535
# Unit test for function make_lazy
def test_make_lazy():
    import math
    assert make_lazy('math') == None
    assert math.__mro__() == (math.LazyModule,
                              types.ModuleType)
    assert math.__getattribute__('pi') == 3.141592653589793
    assert math.__getattribute__('e') == 2.718281828459045

# Generated at 2022-06-12 07:51:07.979135
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('spam')
    assert 'spam' not in sys.modules
    spam = __import__('spam')
    assert spam is sys.modules['spam']
    assert spam is not None

# Generated at 2022-06-12 07:51:17.292402
# Unit test for function make_lazy
def test_make_lazy():
    def do_assert():
        assert hasattr(mod, 'FooBar'), "A LazyModule should appear to have any attribute"

    # First, we'll test that a LazyModule does not actually import it's module
    # That is, this should not throw an exception
    for module_path in ('os', 'shutil', 'sys', 'socket', 'subprocess'):
        do_assert()

    # Next, we'll test that a LazyModule has a __mro__, and responds to
    # `isinstance` by saying yes
    for module_path in ('os', 'shutil', 'sys', 'socket', 'subprocess'):
        assert isinstance(mod, _LazyModuleMarker), "LazyModule should be an instance of _LazyModuleMarker"

    # Now we'll test that our LazyModule can actually import a

# Generated at 2022-06-12 07:51:28.742967
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import random
    def see_if_lazy(attribute_name):
        if sys.modules[module_path].value is not None:
            raise Exception("Module has been loaded")

        getattr(sys.modules[module_path], attribute_name)
        if sys.modules[module_path].value is None:
            raise Exception("Module has not been loaded")

        # In this test we are only checking if the module has loaded.
        # We don't care about the actual value of the attribute
        # if the module has loaded.
        pass

    module_path = "test_" + str(random.random())
    make_lazy(module_path)
    see_if_lazy("asdf")
    see_if_lazy("zxcv")



# Generated at 2022-06-12 07:51:39.781844
# Unit test for function make_lazy
def test_make_lazy():
    class DummyException(Exception): pass

    def source():
        sys.modules["foo.bar"] = (1, 2, 3)

    def target():
        import foo.bar #@UnusedImport
        import foo.bar as bar #@UnresolvedImport
        from foo import bar

    # First make sure that the target imports work
    source()
    try:
        target()
    except ImportError:
        raise DummyException("Target imports are failing")
    finally:
        del sys.modules["foo.bar"]

    # Now the tricky part is using make_lazy on the source
    source()
    make_lazy("foo.bar")

    # Now lets try the same thing again
    target()

if __name__ == '__main__':
    # Run the unit test
    test_make_lazy()

# Generated at 2022-06-12 07:51:48.527977
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import imp

    # Create a module

    path = 'lazy_module'
    open(path, 'w').close()
    lazy_module = imp.load_source('lazy_module', path)
    os.remove(path)

    # Check that the module is loaded normally
    assert sys.modules['lazy_module'] is lazy_module

    # Mark the module to be lazy
    make_lazy('lazy_module')

    # Check that the module is not loaded
    assert sys.modules['lazy_module'] is not None
    assert sys.modules['lazy_module'] is not lazy_module
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

    # Check that the module can still be accessed

# Generated at 2022-06-12 07:51:58.894707
# Unit test for function make_lazy
def test_make_lazy():
    # Test importing nested modules
    make_lazy('test_module')

    try:
        import test_module
        assert not isinstance(test_module, _LazyModuleMarker)
    except ImportError:
        # if we are on python 3 this doesn't work.
        pass
    else:
        assert isinstance(test_module, _LazyModuleMarker)
        assert hasattr(test_module, '__mro__')
        assert hasattr(test_module, '__getattribute__')
        assert not hasattr(test_module, 'foo')

        module = test_module


# Generated at 2022-06-12 07:52:10.090296
# Unit test for function make_lazy
def test_make_lazy():
    import random
    import sys

    for _ in range(10):
        sys.modules.clear()
        make_lazy('random')

        assert not isinstance(sys.modules['random'], random.Random)
        assert isinstance(sys.modules['random'], _LazyModuleMarker)
        assert sys.modules['random'].Random is random.Random

        sys.modules.clear()
        make_lazy('random')

        assert not isinstance(sys.modules['random'], random.Random)
        assert isinstance(sys.modules['random'], _LazyModuleMarker)
        assert sys.modules['random'].__name__ == 'random'
        assert sys.modules['random'].Random is random.Random

        sys.modules.clear()
        make_lazy('random')


# Generated at 2022-06-12 07:52:20.035264
# Unit test for function make_lazy
def test_make_lazy():
    assert(sys.modules.has_key("my_module"))
    assert(sys.modules["my_module"] is None)

    make_lazy("my_module")

    assert(sys.modules.has_key("my_module"))
    assert(isinstance(sys.modules["my_module"], _LazyModuleMarker))

    assert(not hasattr(sys.modules["my_module"], "some_attr"))
    assert(not hasattr(sys.modules["my_module"], "some_func"))

    # This will trigger the import
    sys.modules["my_module"].some_attr

    # Check that it still works
    assert(hasattr(sys.modules["my_module"], "some_attr"))
    assert(hasattr(sys.modules["my_module"], "some_func"))


# Generated at 2022-06-12 07:52:30.002846
# Unit test for function make_lazy
def test_make_lazy():
    import test_module
    assert not isinstance(test_module, _LazyModuleMarker)
    make_lazy('test_module')
    assert isinstance(test_module, _LazyModuleMarker)
    assert test_module.test_func() == 'test_func'
    assert isinstance(test_module, _LazyModuleMarker)


# Import all modules as lazy modules, to prevent full loading of modules
# until they're needed.
pesto_path = 'pesto'
make_lazy(pesto_path)
make_lazy('pesto.dev_tools')
make_lazy('pesto.database')

# Mark all modules in pesto as lazy modules

# Generated at 2022-06-12 07:52:38.929354
# Unit test for function make_lazy
def test_make_lazy():
    import os
    module_path = os.__name__

    # clean up the module_path
    try:
        os_module = sys.modules[module_path]
        del sys.modules[module_path]
    except KeyError:
        pass

    make_lazy(module_path)
    # make sure that there is no import
    assert module_path not in sys.modules
    # make sure that we can get the module
    assert sys.modules[module_path].__name__ == module_path
    # make sure that the module is a LazyModule
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert isinstance(sys.modules[module_path], ModuleType)
    # make sure that the module is an object

# Generated at 2022-06-12 07:53:14.056602
# Unit test for function make_lazy
def test_make_lazy():
    # At this point, the module lazy_module does not exist.
    try:
        import lazy_module
    except ImportError:
        pass
    else:
        assert False, "lazy_module already imported"

    # use lazy loading to make lazy_module
    make_lazy("lazy_module")

    # Test that the module is not imported.
    assert not hasattr(sys.modules["lazy_module"], "app")

    # Test that its a LazyModule.
    assert isinstance(sys.modules["lazy_module"], _LazyModuleMarker)

    # Test that it works when we try to import something.
    from lazy_module import app as lazy_app

    # Test that its imported now.
    assert hasattr(sys.modules["lazy_module"], "app")

    # Test that its an app.

# Generated at 2022-06-12 07:53:22.180638
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import mylib
    assert mylib.__name__ == 'mylib'
    assert isinstance(sys.modules['mylib'], ModuleType)
    assert not isinstance(sys.modules['mylib'], _LazyModuleMarker)

    make_lazy('mylib')
    assert mylib.__name__ == 'mylib'
    assert not isinstance(sys.modules['mylib'], ModuleType)
    assert isinstance(sys.modules['mylib'], _LazyModuleMarker)
    assert isinstance(sys.modules['mylib'], ModuleType)

    assert mylib.__name__ == 'mylib'
    assert isinstance(sys.modules['mylib'], ModuleType)
    assert not isinstance(sys.modules['mylib'], _LazyModuleMarker)


# Generated at 2022-06-12 07:53:30.673010
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['data'] = NonLocal(None)

    class DataModule(object):
        def __init__(self):
            self.a = 'a'

    def check_getattr():
        import data
        assert data.a == 'a'

    make_lazy('data')

    # Make sure we get an import error, then instantiate the module
    # and check the attribute.
    try:
        import data
    except ImportError:
        pass
    else:
        raise Exception("Should have caused an import error")

    # set the module
    sys.modules['data'].value = DataModule()
    check_getattr()

    # reset sys.modules to what it was before
    sys.modules.pop('data')
    check_getattr()

# Generated at 2022-06-12 07:53:35.024006
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo_bar.baz.qux.quux')

    sys.modules['foo_bar.baz.qux'].quux = 42

    assert 'foo_bar.baz.qux.quux' not in sys.modules
    assert sys.modules['foo_bar.baz.qux.quux'] == 42

# Generated at 2022-06-12 07:53:45.334240
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests a lazy module can be successfully used.
    """
    module_path = 'tests.ns1.ns2.ns3.test_module'

    make_lazy(module_path)

    # The module is not yet imported
    try:
        from .ns1.ns2.ns3 import test_module
    except:
        assert False

    # The module should now be imported
    assert module_path in sys.modules
    assert 'test_module' in sys.modules
    assert 'ns1' in sys.modules
    assert 'ns2' in sys.modules
    assert 'ns3' in sys.modules

    # The module should now be able to be imported
    from .ns1.ns2.ns3 import test_module

    # The module should be able to be used
    assert test_module.attr == 42

# Generated at 2022-06-12 07:53:48.435197
# Unit test for function make_lazy
def test_make_lazy():
    """
    Demonstrates the features of the function 'make_lazy'.
    """
    print('Importing the `lazy_module` using the "from" keyword.')
    from make_lazy_examples import lazy_module


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:53:57.103837
# Unit test for function make_lazy
def test_make_lazy():
    # Check that make_lazy works as expected
    test_modname = 'make_lazy_test_module'
    sys_modules = sys.modules

    # Check that module is not loaded in sys.modules
    assert test_modname not in sys_modules.keys()

    # Mark the module as lazy
    make_lazy(test_modname)

    # Check that make_lazy has loaded a LazyModule
    assert isinstance(sys_modules[test_modname], _LazyModuleMarker)

    # Check that accessing attributes causes the module to be loaded
    assert sys_modules[test_modname].make_lazy_test_attr == 'b'
    assert isinstance(sys_modules[test_modname], ModuleType)

# Generated at 2022-06-12 07:54:00.006981
# Unit test for function make_lazy
def test_make_lazy():
    global mod1
    make_lazy("mod1")
    assert isinstance(mod1, _LazyModuleMarker)
    assert mod1.loaded == "loaded"
    assert mod1.loaded2 == "loaded2"