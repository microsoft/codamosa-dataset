

# Generated at 2022-06-12 07:44:05.035002
# Unit test for function make_lazy
def test_make_lazy():
    import unittest

    class TestLazyLoad(unittest.TestCase):
        def test_module_is_lazy(self):
            """
            Tests that the module is lazy
            """
            import os
            self.assertNotIn('os', sys.modules)
            self.assertIsInstance(os, _LazyModuleMarker)
            self.assertNotIn('os', sys.modules)

        def test_accessing_module(self):
            """
            Tests accessing a module attribute
            """
            import os
            self.assertIn('os', sys.modules)
            self.assertIsNotNone(os)
            # Check that everything is still there
            self.assertIsInstance(os.path, ModuleType)
            self.assertEquals(os.name, 'posix')


# Generated at 2022-06-12 07:44:14.993623
# Unit test for function make_lazy
def test_make_lazy():
    from django import template
    import django.template as temp

    # Ensure that module is loaded normally
    reload(template)  # Make sure we really have a module
    assert isinstance(temp, ModuleType)
    assert template.add_to_builtins is not None

    # Ensure module is un-imported
    reload(temp)  # Make sure template is un-imported
    try:
        template
    except NameError:
        pass  # Expected
    else:
        raise AssertionError('Module should not be imported')

    # Make our module lazy
    make_lazy('django.template')

    # Ensure that we can access it's attributes normally
    assert template.add_to_builtins is not None

    # Ensure that the module is not imported until accessed
    reload(temp)  # Make sure template is un-

# Generated at 2022-06-12 07:44:23.772896
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Unit test for module make_lazy. Need to be executed inside a directory
    containing a python package "demo" with a module "foo" inside it.
    '''
    import demo
    # something is expected to happen here
    assert not isinstance(demo, _LazyModuleMarker)  # cannot see that
    assert not isinstance(sys.modules['demo'], _LazyModuleMarker)  # cannot see that

    make_lazy('demo')
    assert isinstance(demo, _LazyModuleMarker)
    assert isinstance(sys.modules['demo'], _LazyModuleMarker)

    assert hasattr(demo, 'foo')
    assert isinstance(demo.foo, ModuleType)

    # nothing is expected to happen here
    make_lazy('demo')


# Generated at 2022-06-12 07:44:32.656985
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_make_lazy'

    def assert_(boolean):
        if not boolean:
            raise AssertionError()

    # check that it is lazy
    make_lazy(module_path)
    assert_(module_path not in sys.modules)

    # check that it was not imported
    module = sys.modules[module_path]
    assert_(isinstance(module, _LazyModuleMarker))

    # check that it will be imported when an attribute is accessed
    module.__name__
    assert_(isinstance(sys.modules[module_path], ModuleType))

    # check that make_lazy() is idempotent
    make_lazy(module_path)
    module.__name__
    assert_(isinstance(sys.modules[module_path], ModuleType))


# Generated at 2022-06-12 07:44:43.639863
# Unit test for function make_lazy
def test_make_lazy():
    # The following code is designed to be run in the same process, it won't
    # work if run in a subprocess
    import pytest
    import sys

    def get_module_recursively(module_path):
        module = __import__(module_path)
        for module_path_part in module_path.split(".")[1:]:
            module = getattr(module, module_path_part)

        return module

    # The following code is going to be run in two locations:
    # - At import time: the code below will be run when the __file__ is being
    #   imported by the python interpreter in order to make it lazy
    # - At runtime: the code below will be run when the make_lazy function is
    #   used in a specific unit test

# Generated at 2022-06-12 07:44:54.617526
# Unit test for function make_lazy
def test_make_lazy():
    import _test_make_lazy
    assert isinstance(_test_make_lazy, _LazyModuleMarker)
    assert hasattr(_test_make_lazy, '__file__')
    assert _test_make_lazy.__file__.endswith('_test_make_lazy.py')
    import os
    os.path.exists(_test_make_lazy.__file__)
    assert hasattr(_test_make_lazy, 'x')


# Override the modules that are to be lazy-loaded.
# You can have multiple calls to `make_lazy` to mark your modules.
make_lazy('_test_make_lazy')

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:45:03.398118
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    from types import ModuleType

    import smoketest
    assert isinstance(smoketest, ModuleType)
    assert os in smoketest.__dict__

    del sys.modules["smoketest"]
    make_lazy("smoketest")
    import smoketest
    assert isinstance(smoketest, _LazyModuleMarker)
    assert os not in smoketest.__dict__

    assert smoketest.os is os
    assert os in smoketest.__dict__

if __name__ == "__main__":
    test_make_lazy()
    sys.exit(0)

# Generated at 2022-06-12 07:45:08.569656
# Unit test for function make_lazy
def test_make_lazy():  # pragma: no cover
    import sys
    import six

    if six.PY2:
        make_lazy('six')
        six.add_move('shutil.move', 'six.moves.shutil_move')
        assert sys.modules['six.moves.shutil_move'] is None
        from six.moves import shutil  # noqa
        import shutil_move
        assert sys.modules['six.moves.shutil_move'] is shutil_move

# Generated at 2022-06-12 07:45:15.271148
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test module lazy loading.
    """
    import sys
    from types import ModuleType
    from types import FunctionType

    # We use the builtin 'imp' module because it is small.
    make_lazy('imp')
    assert sys.modules['imp'] is not None
    assert isinstance(sys.modules['imp'], ModuleType)
    assert isinstance(sys.modules['imp'], _LazyModuleMarker)
    assert hasattr(sys.modules['imp'], 'load_source')
    assert isinstance(sys.modules['imp'].load_source, FunctionType)

# Generated at 2022-06-12 07:45:17.518862
# Unit test for function make_lazy
def test_make_lazy():
    import pkg
    assert isinstance(pkg, _LazyModuleMarker)
    pkg.__name__
    assert not isinstance(pkg, _LazyModuleMarker)

# Generated at 2022-06-12 07:45:22.230914
# Unit test for function make_lazy
def test_make_lazy():
    # import a module dynamically
    try:
        make_lazy('seismometer')
        import seismometer  # NOQA
    finally:
        del sys.modules['seismometer']

# Generated at 2022-06-12 07:45:33.021850
# Unit test for function make_lazy
def test_make_lazy():
    # Delete module under test to ensure it isn't imported unless needed
    import lazy_import
    del sys.modules['lazy_import']

    make_lazy('lazy_import')

    # LazyModule class should be created
    assert 'lazy_import' in sys.modules, 'LazyModule class should'\
        ' be created'
    mod = sys.modules['lazy_import']

    # LazyModule class should be of class 'LazyModule'
    assert type(mod) == type(_LazyModuleMarker), 'LazyModule class should'\
        ' be of class "LazyModule"'

    # LazyModule class should not be an instance of 'LazyModule'

# Generated at 2022-06-12 07:45:41.436440
# Unit test for function make_lazy
def test_make_lazy():
    def LazyMod(name):
        module = sys.modules[name] = ModuleType(name)
        module.__dict__['lazy_loaded'] = False
        return module

    make_lazy('foo')
    foo = __import__('foo')
    assert foo.lazy_loaded == False

    make_lazy('bar')

    assert isinstance(sys.modules['foo'], ModuleType)
    assert isinstance(sys.modules['bar'], ModuleType)

    foo = __import__('foo')
    bar = __import__('bar')

    assert foo.lazy_loaded == True
    assert bar.lazy_loaded == True

    assert isinstance(foo, ModuleType)
    assert isinstance(bar, ModuleType)

    assert isinstance(foo, _LazyModuleMarker)

# Generated at 2022-06-12 07:45:52.417018
# Unit test for function make_lazy
def test_make_lazy():

    module_name = 'test_make_lazy_mod'
    module_path = 'unit_tests.test_make_lazy_mod'

    m = 'import unit_tests.test_make_lazy_mod'

    # Test to make sure that the module is not imported on declaration
    make_lazy(module_path)
    assert module_name not in sys.modules
    assert module_path not in sys.modules
    assert eval(m) is not sys.modules[module_name]

    # Test basic attribute lookup
    assert eval(m).__name__ == module_name
    assert eval(m).__name__ == module_name
    assert module_name in sys.modules
    assert module_path in sys.modules
    assert eval(m) is sys.modules[module_name]

    # Test to make sure that the

# Generated at 2022-06-12 07:45:58.978389
# Unit test for function make_lazy
def test_make_lazy():

    # Create lazy module
    make_lazy('django.template.debug')

    # Check existence of lazy module
    assert 'django.template.debug' in sys.modules

    from django.template.debug import __doc__
    assert __doc__ == 'Not yet imported'

    from django.template.debug import __dict__
    assert '__doc__' in __dict__

    from django.template.debug import __file__
    assert __file__ == 'Not yet imported'

# Generated at 2022-06-12 07:46:01.792966
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    make_lazy('os')
    sys.modules['os'].uname()
    assert isinstance(sys.modules['os'], _LazyModuleMarker)

# Generated at 2022-06-12 07:46:07.804967
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    assert sys.modules['platform'].system() == 'Windows'
    sys_modules = sys.modules
    del sys_modules['platform']

    make_lazy('platform')

    assert 'platform' in sys_modules

    assert sys.modules['platform'] is not None
    assert sys.modules['platform'] is not platform
    assert sys.modules['platform'].system() == 'Windows'
    assert sys.modules['platform'] is platform

# Generated at 2022-06-12 07:46:19.105462
# Unit test for function make_lazy
def test_make_lazy():
    # `x` module doesn't exist, so an ImportError should be raised on importing it.
    try:
        import x
        assert False, "Never should have gotten here"
    except ImportError:
        pass

    # `x` module doesn't exist, but `make_lazy` shoudn't cause an import error.
    make_lazy("x")
    # This should work fine, but `x` should still be a LazyModule
    import x
    assert isinstance(x, _LazyModuleMarker)

    make_lazy("sys")
    # This should work fine, but `sys` should be a LazyModule
    import sys
    assert isinstance(sys, _LazyModuleMarker)

    # Now sys is a LazyModule, so we can't directly call `sys.exit`

# Generated at 2022-06-12 07:46:25.921374
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['mymodule'] = None

    make_lazy('mymodule')
    mymodule = sys.modules['mymodule']

    assert isinstance(mymodule, _LazyModuleMarker)

    with pytest.raises(AttributeError):
        mymodule.foo

    sys.modules['mymodule'] = None
    sys.modules['mymodule2'] = None

    make_lazy('mymodule2')
    mymodule2 = sys.modules['mymodule2']

    assert isinstance(mymodule2, _LazyModuleMarker)

    with pytest.raises(AttributeError):
        mymodule2.foo



# Generated at 2022-06-12 07:46:35.525396
# Unit test for function make_lazy
def test_make_lazy():
    import logging
    import os
    import sys

    assert 'logging' in sys.modules

    # make logging lazy
    make_lazy('logging')
    assert not isinstance(sys.modules['logging'], logging.__class__)
    assert 'logging' in sys.modules

    # trigger the import
    assert hasattr(logging, 'Logger')
    assert isinstance(sys.modules['logging'], logging.__class__)  # not a proxy class

    # make sure we properly updated the module cache
    assert id(logging) == id(sys.modules['logging'])
    assert id(logging.Logger) == id(sys.modules['logging'].Logger)

    # verify we left the rest of the imports alone
    assert os.__file__ == sys.modules['os'].__

# Generated at 2022-06-12 07:46:48.721745
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_lazy')

    assert not sys.modules.get('test_lazy')

    assert isinstance(test_lazy, _LazyModuleMarker)

    assert hasattr(test_lazy, '__name__'), '__name__'
    assert hasattr(test_lazy, '__doc__'), '__doc__'
    assert hasattr(test_lazy, '__file__'), '__file__'
    assert hasattr(test_lazy, '__path__'), '__path__'

    import test_lazy

    # The lazy module should be replaced
    assert isinstance(sys.modules['test_lazy'], ModuleType), sys.modules['test_lazy']

# Generated at 2022-06-12 07:47:00.117292
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests for the make_lazy function
    """
    # Setting up our environment
    sys_modules = sys.modules
    test_module_path = "test.path"

    # A helper function to retrieve our module
    def get_module():
        return sys_modules[test_module_path]

    # Ensure there is no module with this name to start with
    assert test_module_path not in sys_modules
    assert not isinstance(get_module(), _LazyModuleMarker)

    # Do the magic, and test it
    make_lazy(test_module_path)

    assert get_module() is not None
    assert isinstance(get_module(), _LazyModuleMarker)
    assert get_module().__mro__ == (get_module().__class__, ModuleType)
    assert not hasattr

# Generated at 2022-06-12 07:47:07.036022
# Unit test for function make_lazy
def test_make_lazy():
    # Make lazy this module
    make_lazy(__name__)
    # There are no side effects when importing this module

# Generated at 2022-06-12 07:47:14.396154
# Unit test for function make_lazy
def test_make_lazy():
    def import_test():
        # The import of 'test' is lazy, so it will not actually be imported
        # and code in the module will not be run
        import test

    import test
    test.setup_class()
    del sys.modules['test']

    import_test()
    assert not test.module_is_imported
    test.test_module()  # test.test_module will actually import module 'test'
    assert test.module_is_imported

    test.teardown_class()

# Generated at 2022-06-12 07:47:20.938915
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure the lazy module gets set up correctly.
    """
    fake_module = 'fake_module'
    if fake_module in sys.modules:
        del sys.modules[fake_module]
    assert fake_module not in sys.modules

    make_lazy(fake_module)
    assert isinstance(sys.modules[fake_module], _LazyModuleMarker)
    assert not hasattr(sys.modules[fake_module], '__file__')
    assert not hasattr(sys.modules[fake_module], '__name__')

    # Trigger module import
    sys.modules[fake_module].fake_func()
    assert hasattr(sys.modules[fake_module], '__file__')
    assert hasattr(sys.modules[fake_module], '__name__')

    # import statement also works


# Generated at 2022-06-12 07:47:22.926200
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure make_lazy works...

    import lazy_module
    assert lazy_module.z == 42

# Generated at 2022-06-12 07:47:33.555671
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make_lazy module.
    """
    sys.modules.pop("test_lazy", None)  # Clean up on old test runs
    make_lazy("test_lazy")

    import test_lazy
    assert isinstance(test_lazy, _LazyModuleMarker)

    # Check to make sure the module was delayed
    assert "test_lazy" not in sys.modules
    assert not hasattr(test_lazy, "__file__")

    # Make sure attributes can be allocated
    test_lazy.TEST = "TEST"
    assert sys.modules["test_lazy"].TEST == "TEST"

    # Make sure the module was really loaded
    assert sys.modules["test_lazy"] == test_lazy

# Generated at 2022-06-12 07:47:44.237810
# Unit test for function make_lazy
def test_make_lazy():

    __name__ = '__test__'

    class ClassToLazyLoad(object):
        """
        A class that is used to test lazy loading
        """
        def __init__(self, module_path):
            self.module_path = module_path
            self.called = False

        def __call__(self):
            """
            Called when the module is loaded.
            We can check module.called to see if it's been loaded
            """
            self.called = True

    ClassToLazyLoad(__name__)

    sys_modules = sys.modules  # cache in the locals
    make_lazy(__name__)

    # This is the module that is lazily loaded
    test_module = sys_modules[__name__]

    assert isinstance(test_module, ModuleType)

# Generated at 2022-06-12 07:47:51.428230
# Unit test for function make_lazy
def test_make_lazy():
    module_name = "test_make_lazy"

    # add module ahead of time
    sys.modules[module_name] = ModuleType(module_name)

    # make the module lazy
    make_lazy(module_name)

    # check that it's lazy
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # add attr to module
    sys.modules[module_name].x = 2

    # check that we can get the module.
    x = sys.modules[module_name].x

    assert x == 2

# Generated at 2022-06-12 07:47:59.913463
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    module_path = 'canary'

    # Let's make sure that module is valid and loaded before we proceed
    assert module_path not in sys.modules

    # Let's make sure we aren't accidentally relying on an old import in the test
    assert module_path not in os.environ

    # Make sure we can't access the environment directly
    with pytest.raises(AttributeError):
        os.environ.canary

    # Now we can lazy load our module
    make_lazy(module_path)

    # Make sure we can access it in the environment
    assert os.environ.canary == 'a'

    # Make sure the module is valid
    assert module_path in sys.modules

    # Make sure our lazy loader is still in the sys.modules

# Generated at 2022-06-12 07:48:14.924913
# Unit test for function make_lazy
def test_make_lazy():
    def test_lazy(module_name):
        make_lazy(module_name)
        assert(isinstance(sys.modules[module_name], _LazyModuleMarker))
        assert(hasattr(sys.modules[module_name], '__mro__'))

        import django.test
        from django.test import TestCase

        assert(TestCase is not None)

    module_name = 'django.test'
    test_lazy(module_name)

    module_name = 'django.test.testcases'
    test_lazy(module_name)

    module_name = 'django.test.testcases.TestCase'
    test_lazy(module_name)

# Generated at 2022-06-12 07:48:20.709101
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test of make_lazy.

    This test has a dependency on the mpmath modules.
    However, to test make_lazy, we can make it a lazy module
    and only import it on demand.
    """
    import mpmath
    version = mpmath.__version__

    del sys.modules['mpmath']
    make_lazy('mpmath')
    import mpmath

    # should not have imported the module
    assert mpmath.__version__ == version



# Generated at 2022-06-12 07:48:28.648896
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy()
    """
    import logging
    import os
    import sys

    sys_modules = sys.modules.copy() # backup system modules
    logger = logging.getLogger()

    # Make logging module lazy
    make_lazy('logging')

    # Test the module after making the module lazy
    assert isinstance(sys.modules['logging'], _LazyModuleMarker)
    assert isinstance(logging, _LazyModuleMarker)
    assert not hasattr(logging, 'getLogger')
    assert not hasattr(logging, 'INFO')
    assert not hasattr(logging, 'FORMAT')

    # Test the module after making the module non-lazy, i.e. importing the module
    assert logging.getLogger() is not None # import the module
   

# Generated at 2022-06-12 07:48:38.262714
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """

    test_module = 'foo.bar'
    sys.modules[test_module] = 'foo.bar'

    assert sys.modules[test_module] == 'foo.bar'
    make_lazy(test_module)
    assert sys.modules[test_module] == 'foo.bar'

    # magic is here
    assert isinstance(sys.modules[test_module], _LazyModuleMarker)
    assert not isinstance(sys.modules[test_module], ModuleType)

    # magic is here
    assert sys.modules[test_module].__name__ == test_module
    assert sys.modules[test_module].__file__ == test_module + '.pyc'
    assert sys.modules[test_module].__doc__ == 'Doc String'



# Generated at 2022-06-12 07:48:41.037361
# Unit test for function make_lazy
def test_make_lazy():
    import cProfile
    cProfile.run("make_lazy('os')")


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:48:50.247045
# Unit test for function make_lazy
def test_make_lazy():
    """Test that make_lazy properly sets up the module"""
    import sys

    sys.modules.pop('test_make_lazy_module', None)
    __import__('test_make_lazy_module')

    assert sys.modules['test_make_lazy_module'].__class__.__name__ == 'module'

    make_lazy('test_make_lazy_module')
    assert sys.modules['test_make_lazy_module'].__class__.__name__ == 'LazyModule'

    assert sys.modules['test_make_lazy_module'].__name__ == 'test_make_lazy_module'
    assert sys.modules['test_make_lazy_module'].__package__ == ''



# Generated at 2022-06-12 07:49:01.197611
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['my.fancy.module'] = True
    make_lazy('my.fancy.module')
    lazy = sys.modules['my.fancy.module']
    assert isinstance(lazy, _LazyModuleMarker)
    assert lazy.__mro__() == (_LazyModuleMarker, ModuleType)
    assert lazy.__class__ == _LazyModuleMarker

    # test that the module is lazily loaded.
    is_lazy = True
    try:
        __import__('my.fancy.module')
    except AttributeError:
        is_lazy = False
    assert is_lazy

    # test that subsequent imports work as expected
    is_loaded = True

# Generated at 2022-06-12 07:49:10.220601
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'lazy_module'
    sys_modules = sys.modules

    # Test the module isn't imported
    assert module_path not in sys_modules

    # Test it is imported after an access
    make_lazy(module_path)
    assert module_path in sys_modules

    sys_modules[module_path].foo = 'bar'
    assert sys_modules[module_path].foo == 'bar'

    # Test it is normally importable
    del sys_modules[module_path]
    assert sys_modules.get(module_path, 'notfound') == 'notfound'

    import lazy_module
    assert 'foo' not in lazy_module.__dict__


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:49:19.256315
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import io
    import os
    import atexit
    try:
        from cStringIO import StringIO
    except:
        from StringIO import StringIO

    # create a temporary Python module in a temporary directory
    tmpdir = tempfile.mkdtemp()
    atexit.register(lambda: os.rmdir(tmpdir)) # clean up directory at exit
    tmpfilename = os.path.join(tmpdir, 'tmp.py')

# Generated at 2022-06-12 07:49:31.454244
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the implementation of make_lazy
    """
    if sys.version_info.major == 2:
        make_lazy('os.path')
        # The import of os should not be done
        assert not hasattr(os.path, 'exists')
        # But it still exists in sys.modules
        assert sys.modules['os.path'] is not None
        # Now we should be able to import it
        assert callable(os.path.exists)

    else:
        make_lazy('collections.abc')
        # The import of os should not be done
        assert not hasattr(collections.abc, 'Sequence')
        # But it still exists in sys.modules
        assert sys.modules['collections.abc'] is not None
        # Now we should be able to import it
        assert callable

# Generated at 2022-06-12 07:49:54.840238
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo.bar')

    assert 'foo.bar' in sys.modules
    assert isinstance(sys.modules['foo.bar'], _LazyModuleMarker)
    assert 'foo.bar' in globals()
    # note that object does not have a name attribute,
    # so type(foo.bar) != object is the same as
    # not isinstance(foo.bar, object)
    assert type(foo.bar) != object
    assert foo.bar.__class__.__name__ == 'LazyModule'
    assert not hasattr(foo, 'bar')


# Generated at 2022-06-12 07:50:02.033971
# Unit test for function make_lazy
def test_make_lazy():
    """
    The function make_lazy is a decorator for lazy module imports.
    It needs to temporarily overwrite sys.modules and then restore
    it back to its original value when the decorated function is called.
    """
    sys_modules = sys.modules
    make_lazy('foo')
    assert isinstance(sys_modules['foo'], _LazyModuleMarker)
    assert sys_modules['foo'].__class__.__name__ == 'LazyModule'
    # The module 'foo' is now loaded.
    sys_modules['foo'].bar = 'foo.bar'
    assert sys_modules['foo'].bar == 'foo.bar'

# Generated at 2022-06-12 07:50:10.304314
# Unit test for function make_lazy
def test_make_lazy():
    assert 'test_module' not in sys.modules
    import test_module
    assert 'test_module' in sys.modules

    assert 'baz' not in test_module.__dict__

    del sys.modules['test_module']
    make_lazy('test_module')

    assert 'test_module' in sys.modules
    assert 'baz' not in test_module.__dict__

    assert test_module.baz == 'baz'
    assert 'baz' in test_module.__dict__


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:50:18.765484
# Unit test for function make_lazy
def test_make_lazy():
    def does_not_exist(*args):
        import does_not_exist.a.b.c
        return does_not_exist.a.b.c

    make_lazy('does_not_exist.a.b.c')
    assert isinstance(sys.modules['does_not_exist.a.b.c'], _LazyModuleMarker)
    assert does_not_exist()
    assert does_not_exist is sys.modules['does_not_exist.a.b.c']

# Generated at 2022-06-12 07:50:29.118209
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import datetime
    sys.modules.pop('datetime', None)

    make_lazy('datetime')
    assert 'datetime' in sys.modules
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)

    getattr(sys.modules['datetime'], 'datetime')
    assert 'datetime' in sys.modules
    assert not isinstance(sys.modules['datetime'], _LazyModuleMarker)
    assert sys.modules['datetime'] is datetime

    # now make sure it works with a sub module
    sys.modules.pop('datetime', None)
    make_lazy('datetime.date')
    assert 'datetime' in sys.modules
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)

    getattr

# Generated at 2022-06-12 07:50:39.967961
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit tests for make_lazy.
    """
    from os.path import join
    import unittest
    import os.path
    import sys
    import os

    lazy_module = os.path

    # First ensure that importing os.path works
    unittest.TestCase().assertNotEqual(None, lazy_module)

    # Now make this module lazy
    make_lazy(lazy_module.__name__)

    # Rebind lazy_module to our new lazy module.
    lazy_module = sys.modules[lazy_module.__name__]

    # Ensure that it is now a LazyModule
    unittest.TestCase().assertIsInstance(lazy_module, _LazyModuleMarker)

    # Ensure that any method will now force the import

# Generated at 2022-06-12 07:50:50.134839
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # Use a temporary directory so as not to interfere with any real modules
    temp_path = tempfile.mkdtemp()

# Generated at 2022-06-12 07:50:55.604811
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import django  # noqa
    except ImportError:
        pass
    else:
        pytest.skip("django module already existed.")

    make_lazy('django')
    module = sys.modules['django']

    assert isinstance(module, _LazyModuleMarker)



# Generated at 2022-06-12 07:51:04.444337
# Unit test for function make_lazy
def test_make_lazy():
    class ModuleStuff(object):
        def a(self):
            return 'a'

        def b(self):
            return 'b'

    sys_modules = sys.modules  # cache in the locals

    MOD_PATH = 'tests.modules.fixtures.test_make_lazy'
    if MOD_PATH in sys_modules:
        del sys_modules[MOD_PATH]

    mod = sys_modules.get(MOD_PATH)
    assert mod is None

    make_lazy(MOD_PATH)
    mod = sys_modules.get(MOD_PATH)
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__mro__() == (mod.__class__, ModuleType)

    # Test that we can add a method to our lazy module
    # This happens within the __getattribute__ method

# Generated at 2022-06-12 07:51:12.010982
# Unit test for function make_lazy
def test_make_lazy():
    """
    Assert that make_lazy works properly.
    """
    name = 'tests.fixtures.lazy_importing'
    assert name not in sys.modules

    make_lazy(name)

    assert isinstance(sys.modules[name], _LazyModuleMarker)

    assert not hasattr(sys.modules[name], 'bacon')

    assert sys.modules[name].bacon == random.randint(0, 100)

    assert hasattr(sys.modules[name], 'bacon')

# Generated at 2022-06-12 07:51:46.990127
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'tests.lazy_test_mod'
    module = sys.modules.get(module_path)

    if module is not None and module_path in sys.modules:
        del sys.modules[module_path]
    assert sys.modules.get(module_path) is None

    make_lazy(module_path)
    mod = sys.modules[module_path]
    assert isinstance(mod, _LazyModuleMarker)
    assert sys.modules.get(module_path) is not None
    assert mod.name is None

    from .lazy_test_mod import name
    assert mod.name == name == 'tests.lazy_test_mod'
    assert 'name' in vars(mod)
    assert 'name' not in vars(sys.modules[module_path])

    del sys

# Generated at 2022-06-12 07:51:57.369649
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for `make_lazy` function above.
    """
    # This should pass with python 2.7
    # assert not hasattr(os.path, 'foo')

    # This should pass with python 3
    assert hasattr(os.path, 'foo') is False

    # Monkey patch os.path to not import itself until its used.
    make_lazy('os.path')

    # This should pass with python 2.7
    # assert not hasattr(os.path, 'foo')

    # This should pass with python 3
    assert hasattr(os.path, 'foo') is False

    # This should pass with python 2.7
    # if os.path.foo:
    #    pass

    # This should pass with Python 3
    if os.path.foo:
        pass

    # This should pass with

# Generated at 2022-06-12 07:52:07.647037
# Unit test for function make_lazy
def test_make_lazy():
    """
    This test ensures that any python code can use the make_lazy function
    without any issues.
    """
    class FakeModuleType(object):
        """
        Simulates a module type
        """
        def __init__(self, module_name):
            """
            Sets the name of the module
            """
            self.__name__ = module_name

    loaded_modules = []

    def fake_import_module(name):
        """
        Simulates sys.import_module.
        """
        loaded_modules.append(name)

        return FakeModuleType(name)

    sys.modules = {}
    sys.modules['os'] = fake_import_module('os')

    # Standard import
    import os

    # Lazy import
    make_lazy('six')

    import six

    # Check to ensure

# Generated at 2022-06-12 07:52:13.587149
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.clear()
    # it should not have been imported yet
    assert 'module_path' not in sys.modules
    make_lazy('module_path')
    assert 'module_path' in sys.modules
    assert isinstance(sys.modules['module_path'], LazyModule)
    # here is where it actually loads
    sys.modules['module_path'].spam
    # now it should be back after being loaded
    assert isinstance(sys.modules['module_path'], ModuleType)
    assert module_path.spam == 'spam'
    assert sys.modules['module_path'] is module_path

# Generated at 2022-06-12 07:52:17.303601
# Unit test for function make_lazy
def test_make_lazy():
    import os
    make_lazy('os')
    assert not isinstance(os, ModuleType)

    assert isinstance(os, _LazyModuleMarker)
    assert not hasattr(os, 'path')

    assert os.path is not None
    asse

# Generated at 2022-06-12 07:52:27.711303
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import types

    def _is_lazy_module(mod):
        return isinstance(mod, _LazyModuleMarker)

    def _is_nonlazy_module(mod):
        return not isinstance(mod, _LazyModuleMarker)

    assert _is_nonlazy_module(os), 'Module os is not lazy'
    assert _is_nonlazy_module(sys), 'Module sys is not lazy'
    assert _is_nonlazy_module(types), 'Module types is not lazy'

    make_lazy('os')
    make_lazy('sys')
    make_lazy('types')

    assert _is_lazy_module(os), 'Module os is lazy'
    assert _is_lazy_module(sys), 'Module sys is lazy'
   

# Generated at 2022-06-12 07:52:34.453169
# Unit test for function make_lazy
def test_make_lazy():
    # create fake module using this file as a placeholder
    import tests  # noqa

    # test that it caches the file to make sure we can call it twice.
    assert tests.__file__ == sys.modules[__name__].__file__

    # test that make_lazy prevents importing
    make_lazy('tests')
    assert sys.modules['tests'] is not tests
    assert tests.__file__ != sys.modules['tests'].__file__

    # test that the module is still the same
    sys.modules['tests'] = None
    assert tests.__file__ == sys.modules[__name__].__file__
    assert tests.__file__ != sys.modules['tests'].__file__

# Generated at 2022-06-12 07:52:44.248782
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'django.utils.functional'

    # Store the initial state of the module so we can reset it later
    sys_modules = sys.modules
    module = sys.modules[module_path]
    del sys.modules[module_path]

    # Make sure the module we want to test with is not already loaded
    assert module_path not in sys.modules

    # Now make the module lazy
    make_lazy(module_path)
    assert module_path in sys.modules

    # Check that the module is a LazyModule
    mod = sys.modules[module_path]
    assert isinstance(mod, _LazyModuleMarker) is True

    #  Check that the module is not imported until accessed
    assert not hasattr(mod, 'curry')

    # Use the lazy module's attribute to load the module
   

# Generated at 2022-06-12 07:52:51.073918
# Unit test for function make_lazy
def test_make_lazy():
    import tempfile
    import os

    def foo():
        return "test"

    with tempfile.NamedTemporaryFile() as temp_file:
        module_name = 'my_module.py'
        module_path = os.path.join(os.path.dirname(temp_file.name), 'my_module.py')


# Generated at 2022-06-12 07:52:57.378792
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule(object):
        var = 'lazy'

    # import unit tests
    sys_modules = sys.modules
    test_module_path = 'lazymock.test'
    test_module = TestModule()
    sys_modules[test_module_path] = test_module

    make_lazy(test_module_path)

    # check if lazy is created and checked to false
    assert sys_modules[test_module_path].var == 'lazy'

    # check if module is reloaded after using the variable
    assert sys_modules[test_module_path] is test_module

    # cleanup
    del sys_modules[test_module_path]

# Generated at 2022-06-12 07:53:56.427801
# Unit test for function make_lazy
def test_make_lazy():
    module = uuid.uuid4().hex

    make_lazy(module)

    assert module in sys.modules
    assert isinstance(sys.modules[module], _LazyModuleMarker)

    # after a getattr, it should be the real module.
    _ = getattr(sys.modules[module], '__name__')
    assert isinstance(sys.modules[module], ModuleType)

