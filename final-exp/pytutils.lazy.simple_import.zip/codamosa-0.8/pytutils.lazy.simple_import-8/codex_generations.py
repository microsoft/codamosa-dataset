

# Generated at 2022-06-12 07:44:06.460869
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_path = 'test_lazy_module'

    # Delete any left over references to the test module.
    if lazy_module_path in sys.modules:
        del sys.modules[lazy_module_path]

    if lazy_module_path in globals():
        del globals()[lazy_module_path]

    # Create a test module.
    test_module = ModuleType(lazy_module_path)
    test_module.test_attr = 'test attr'
    sys.modules[lazy_module_path] = test_module

    # Create a LazyModule for the test module.
    make_lazy(lazy_module_path)
    import_lazy_test_module = sys.modules[lazy_module_path]

    # Check that attributes can be accessed.

# Generated at 2022-06-12 07:44:17.645105
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import types

    def is_lazy(m):
        return isinstance(m, _LazyModuleMarker)

    #    import this
    #    print this.__dict__

    make_lazy('os')

    assert is_lazy(os)
    assert isinstance(os.path, types.ModuleType)

    # Check that we can still reference all of the attributes
    attrs = os.__all__ + ['popen', 'tmpnam', 'tmpfile', 'name', 'linesep',
                          'sep', 'curdir', 'pardir', 'altsep']

    for attr in attrs:
        assert getattr(os, attr) is not None


# Turn on all of the lazies
make_lazy('os')
make_lazy('os.path')



# Generated at 2022-06-12 07:44:23.498710
# Unit test for function make_lazy
def test_make_lazy():

    import sys

    # sys.modules is a dict, values are module objects.
    # LazyModule is a standin to prevent the module from being
    # loaded until an attribute is accessed.
    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Accessing an attribute on the lazy module should cause the
    # module to be imported and set in sys.modules
    assert sys.modules[module_path].__name__ is not None
    assert isinstance(sys.modules[module_path], ModuleType)

# Generated at 2022-06-12 07:44:32.123917
# Unit test for function make_lazy
def test_make_lazy():
    import unittest2
    import sys
    sys.modules['foo'] = 'foo'

    class SimpleTest(unittest2.TestCase):
        def test(self):
            self.assertEquals(sys.modules['foo'], 'foo')

            make_lazy('foo')

            self.assertTrue(isinstance(sys.modules['foo'], LazyModule))
            self.assertTrue(isinstance(sys.modules['foo'], _LazyModuleMarker))
            self.assertFalse(isinstance(sys.modules['foo'], ModuleType))

            self.assertEquals(sys.modules['foo'].__name__, 'foo')
            self.assertEquals(sys.modules['foo'].__name__, 'foo')

# Generated at 2022-06-12 07:44:43.441049
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """

    make_lazy('edx.analytics.tasks.tests.config.lazy_module')
    from edx.analytics.tasks.tests import config

    # Unit test 1
    # Checks that lazy_module is not loaded in sys.modules before needed
    assert 'lazy_module' not in sys.modules

    # Unit test 2
    # Checks that lazy_module is loaded in sys.modules after attribute access
    assert isinstance(config.lazy_module, ModuleType) and isinstance(config.lazy_module, _LazyModuleMarker)
    assert 'lazy_module' in sys.modules

    # Unit test 3
    # Checks that lazy_module is an instance of ModuleType and _LazyModuleMarker
    # after it has been imported
   

# Generated at 2022-06-12 07:44:54.752898
# Unit test for function make_lazy
def test_make_lazy():
    def test_module(name, func_name, func=None):
        """
        Test module

        :param name: Name of the module
        :param func_name: Name of the function to check
        :param func: The function to check
        """
        try:
            del sys.modules['utils.lazy.%s' % name]
        except KeyError:
            pass
        __import__('utils.lazy.%s' % name)
        assert not hasattr(sys.modules['utils.lazy.%s' % name], func_name)
        if func:
            func()
        assert hasattr(sys.modules['utils.lazy.%s' % name], func_name)

    def test_module_normal():
        """
        Test normal module
        """

# Generated at 2022-06-12 07:45:02.595735
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy functions correctly.
    """
    # Ensure the target module is not already loaded
    assert 'make_lazy_module' not in sys.modules
    make_lazy('make_lazy_module')
    # Ensure the target module is now a LazyModule instance
    assert isinstance(sys.modules['make_lazy_module'], _LazyModuleMarker)
    mod = sys.modules['make_lazy_module']
    # Ensure that accessing an attribute from the module
    # will import the module.
    assert getattr(mod, 'a') == 99
    # Ensure that the lazy module was deleted
    assert 'make_lazy_module' not in sys.modules
    # Ensure that the target module was actually imported
    assert 'make_lazy_module' in sys.modules

# Generated at 2022-06-12 07:45:10.369586
# Unit test for function make_lazy
def test_make_lazy():
    """ Test function make_lazy.
    """

    class Module:
        """ Test module.
        """
        pass

    module_path = 'test_lazy_module'

    # Save original sys.modules
    old_modules = sys.modules

    # Make an empty sys.modules
    sys.modules = {}

    # Set the module to be lazy
    make_lazy(module_path)

    # Check that the module was properly set as lazy module
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Import the module and check that it was loaded
    test_module = __import__(module_path)
    assert isinstance(test_module, Module)

    # Check that the module is no longer lazy

# Generated at 2022-06-12 07:45:17.818157
# Unit test for function make_lazy
def test_make_lazy():
    # create a "fake" module that we can lazily import.
    module_path = 'lazyimport.tests.a'
    imp.new_module('tests.a')
    sys.modules['tests.a'] = imp.new_module('tests.a')
    sys.modules['tests.a'].__file__ = 'lazyimport/tests/a.py'
    sys.modules['lazyimport.tests.a'] = sys.modules['tests.a']

    # Add an attribute to the module that we can check later.
    sys.modules['lazyimport.tests.a'].foo = 'bar'

    make_lazy(module_path)

    # By this point, the module should be importable.
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Check the attributes

# Generated at 2022-06-12 07:45:22.963302
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['a'] = 1
    make_lazy('a')
    assert isinstance(sys.modules['a'], _LazyModuleMarker)
    sys.modules['a'] = None
    assert not isinstance(sys.modules['a'], _LazyModuleMarker)
    sys.modules['a'] = 1

# Generated at 2022-06-12 07:45:33.069749
# Unit test for function make_lazy
def test_make_lazy():
    import __main__

    module_path = '<test_make_lazy>'
    module = __main__.__dict__[module_path] = object()  # random object

    assert isinstance(module, object)
    assert not isinstance(module, _LazyModuleMarker)

    make_lazy(module_path)

    lazy_module = __main__.__dict__[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # ensure the 'load' works
    getattr(lazy_module, '__name__')
    assert isinstance(__main__.__dict__[module_path], object)


# Generated at 2022-06-12 07:45:41.466110
# Unit test for function make_lazy
def test_make_lazy():
    # unit test for the __all__ usage
    test_all_module = os.path.join(os.path.dirname(__file__), '_test_data', 'mod_with_all.py')
    make_lazy(test_all_module)
    assert sys.modules[test_all_module].__all__ == ['func_1', 'func_2']

    # ensure unit test data is present in __init__
    test_init_module = os.path.join(os.path.dirname(__file__), '_test_data', 'mod_with_init.py')
    make_lazy(test_init_module)
    assert sys.modules[test_init_module].__all__ == ['func_1', 'func_2']

    # test an import without any __all__ or __init__.

# Generated at 2022-06-12 07:45:45.879931
# Unit test for function make_lazy
def test_make_lazy():
    from pkgutil import extend_path  # ensure that module is lazy

    import numpy  # ensure that module is not lazy

    make_lazy('numpy')
    assert isinstance(sys.modules['numpy'], _LazyModuleMarker)

    assert np.sum([1, 2, 3]) == 6


test_make_lazy()

# Generated at 2022-06-12 07:45:50.945454
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'time'
    make_lazy(module_path)
    assert module_path not in sys.modules

    module = __import__(module_path)

    assert isinstance(module, _LazyModuleMarker)
    assert isinstance(module, ModuleType)

    assert module_path in sys.modules

# Generated at 2022-06-12 07:46:00.765486
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the 'make_lazy' function is functional
    """
    # create a fake module that we can use to test
    class FakeModule(object):
        """
        A fake module
        """
        pass

    fake_mod_namespace = {'__name__': '___fake___'}
    sys.modules['___fake___'] = FakeModule()  # make the module importable

    # create a sub module of '___fake___' and make it lazy
    sys.modules['___fake___'].___fake___ = FakeModule()
    make_lazy('___fake___.___fake___')

    # test that 'isinstance' works for LazyModule types
    assert isinstance(sys.modules['___fake___'].___fake___, _LazyModuleMarker)

# Generated at 2022-06-12 07:46:11.665869
# Unit test for function make_lazy
def test_make_lazy():

    def import_test():
        import impala.interpreter
        return impala.interpreter.Cursor

    def make_lazy_test():
        import impala
        impala.interpreter.Cursor

    if 'impala' in sys.modules:
        del sys.modules['impala']

    # Ensure the module is imported when we don't use make_lazy
    assert import_test() is impala.interpreter.Cursor

    # Ensure the module is not imported when we use make_lazy
    # Also, the fake module should be lazy
    make_lazy('impala.interpreter')
    assert isinstance(sys.modules['impala.interpreter'], _LazyModuleMarker)
    assert not hasattr(sys.modules['impala'], 'interpreter')

# Generated at 2022-06-12 07:46:16.344087
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('django.utils.deprecation')
    assert isinstance(django.utils.deprecation, _LazyModuleMarker)
    assert issubclass(django.utils.deprecation.RemovedInDjango11Warning, Warning)

# Generated at 2022-06-12 07:46:24.000090
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_lazy'] = None
    make_lazy('test_lazy')
    sys.modules['test_lazy.foo'] = None
    make_lazy('test_lazy.foo')
    sys.modules['test_lazy'].foo

    class TestClass(object):
        """
        This class should be sublass of module 
        """
        pass

    assert type(sys.modules['test_lazy']) is TestClass
    assert TestClass in TestClass.mro()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:46:33.932100
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import shutil
    import tempfile

    # create a temporary directory
    tempdir = tempfile.mkdtemp()
    # create the file structure
    os.makedirs(tempdir + '\\mypackage\\mymodule')
    # create __init__.py
    open(os.path.join(tempdir, 'mypackage', '__init__.py'), 'a').close()
    # create mymodule.py
    with open(os.path.join(tempdir, 'mypackage', 'mymodule', '__init__.py'),
              'w') as f:
        f.write('A = 5')
    # add the module to sys
    sys.path.append(tempdir)

    module_path = 'mypackage.mymodule'

    # it shouldn't be in sys.modules


# Generated at 2022-06-12 07:46:41.227676
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to ensure that a module is not imported until it is
    needed.
    """
    # Test that lazy module is not loaded until it is referenced.

# Generated at 2022-06-12 07:46:51.829049
# Unit test for function make_lazy
def test_make_lazy():
    import math
    import sys
    import inspect

    try:
        (name, _) = inspect.getmodule(lambda: None).__name__.rsplit('.', 1)
    except ValueError:
        name = ''

    mod = '_test'
    mod_path = name + '.' + mod

    try:
        make_lazy(mod_path)
    except Exception as e:
        raise AssertionError("Test failed: making module lazy was unsuccessful")
    else:
        print("Making module lazy was successful")

    if mod_path in sys.modules:
        print("Module was added to sys.modules successfully")
    else:
        raise AssertionError("Test failed: module was not added to sys.modules")


# Generated at 2022-06-12 07:47:02.105650
# Unit test for function make_lazy
def test_make_lazy():
    """
    A simple test to show that the lazy module works.
    """
    try:
        import xlrd
    except ImportError:
        raise unittest.SkipTest("xlrd needs to be installed for this test")

    # we need to get rid of this in case the test was run before
    if 'lazy_xlrd' in sys.modules:
        del sys.modules['lazy_xlrd']

    # show that the module is not imported yet
    assert 'xlrd' not in sys.modules

    make_lazy('xlrd')
    # save off the module
    lazy_xlrd = sys.modules['xlrd']

    # this should not have actually imported it yet
    assert 'xlrd' not in sys.modules

    # show that it is registered as a lazy module

# Generated at 2022-06-12 07:47:13.611810
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test.test_module_loading_lazy.a')
    import test.test_module_loading_lazy
    assert isinstance(test.test_module_loading_lazy.a, _LazyModuleMarker)
    assert hasattr(test.test_module_loading_lazy.a, '__mro__')  # we do this to verify __mro__ is working.
    assert not hasattr(test.test_module_loading_lazy.a, 'b')
    from test.test_module_loading_lazy.a import b
    assert test.test_module_loading_lazy.a.b == 'b'

# test that we can mark a module as lazy, define an attribute and access it
# through the lazy module.

# Generated at 2022-06-12 07:47:18.128457
# Unit test for function make_lazy
def test_make_lazy():
    # This module is already loaded, so normally the sys.modules
    # lookup would prevent this from working.
    make_lazy('sys')

    # Make sure we can get sys.modules
    assert sys.modules

    # Make sure we can get sys.modules again
    assert sys.modules

# Generated at 2022-06-12 07:47:26.633973
# Unit test for function make_lazy
def test_make_lazy():
    import gc
    import six

    sys_modules = sys.modules

    def mock_import(fullname):
        if fullname == 'foo.bar':
            mod = ModuleType(fullname)
            sys_modules[fullname] = mod
            return mod

        raise ImportError('cannot import %s' % fullname)

    orig_import = __builtins__['__import__']

# Generated at 2022-06-12 07:47:30.127478
# Unit test for function make_lazy
def test_make_lazy():
    try:
        mod = __import__('foo.bar')
        assert False, 'expected Exception'
    except ImportError:
        pass
    make_lazy('foo.bar')
    import foo

# Generated at 2022-06-12 07:47:41.442601
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that make_lazy works and that it re-imports the module,
    instead of just creating a new one, when the import is repeated.

    (i.e. `__import__`) is used instead of `import` because this is
    what will be used internally.  If we used `import` we would create
    a new module definition.
    """
    # Arrange
    module_path = 'testmodule'
    sys_modules = sys.modules
    module = __import__(module_path)
    module.imported_value = 1
    make_lazy(module_path)
    module = __import__(module_path)

    # Act
    module.imported_value = 2
    lazy_module = __import__(module_path)

    # Assert
    assert lazy_module == module


# Generated at 2022-06-12 07:47:48.282495
# Unit test for function make_lazy
def test_make_lazy():
    # Append current path to sys.path
    sys.path.insert(0, '')
    try:
        assert not hasattr(sys.modules, 'test_module')
        make_lazy('test_module')
        import test_module

        # Test module is lazy module
        assert isinstance(test_module, _LazyModuleMarker)

        # Test module will import when attr is accessed
        assert not hasattr(sys.modules, 'test_module1')
        assert test_module.value == 1
        assert hasattr(sys.modules, 'test_module')
        assert not isinstance(test_module, _LazyModuleMarker)
    finally:
        # Clean up
        del sys.path[0]
        del sys.modules['test_module']
        del sys.modules['test_module1']

# Generated at 2022-06-12 07:47:58.260305
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    fd, name = tempfile.mkstemp()
    os.close(fd)
    

# Generated at 2022-06-12 07:48:05.163458
# Unit test for function make_lazy
def test_make_lazy():
    # Create a dummy module that has a Foo class in it
    class MyModule(object):
        class Foo(object):
            pass

    # Make sure we can import the module and create a Foo
    foo1 = MyModule.Foo()

    # Now make the module lazy
    make_lazy('mymodule')

    # Verify that we can still instantiate Foo
    foo2 = MyModule.Foo()

    # Verify that foo1 and foo2 are the saame object
    assert foo1 == foo2

# Generated at 2022-06-12 07:48:10.433864
# Unit test for function make_lazy
def test_make_lazy():
    import django.conf

    if (not hasattr(django.conf, 'LazySettings') or
            not isinstance(django.conf.LazySettings, _LazyModuleMarker)):
        raise AssertionError("make_lazy function did not work.")

# Generated at 2022-06-12 07:48:16.179496
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy("_lazy_mod")
    assert mod == sys.modules["_lazy_mod"]
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__mro__() == (LazyModule, ModuleType)
    assert mod.__getattribute__("__mro__")() == (LazyModule, ModuleType)


make_lazy('twisted.internet.threads')
make_lazy('twisted.internet.defer')

# Generated at 2022-06-12 07:48:22.300693
# Unit test for function make_lazy
def test_make_lazy():
    # Test that we may access modules marked as lazy
    make_lazy('__builtin__')
    assert __builtin__.any

    # Test that a LazyModule can be used as a standin
    make_lazy('sys')
    import gc
    gc.collect()



# Generated at 2022-06-12 07:48:29.288012
# Unit test for function make_lazy
def test_make_lazy():
    def dummy_imp(name):
        raise ImportError()
    # capture the real import function
    real_import = __builtins__.__import__
    try:
        # swap it out for our dummy
        __builtins__.__import__ = dummy_imp
        # this should work and not throw an ImportError
        make_lazy('foo')
    finally:
        # restore the real import function
        __builtins__.__import__ = real_import



# Generated at 2022-06-12 07:48:37.067343
# Unit test for function make_lazy
def test_make_lazy():
    module_path = "tests.stub_module"
    import tests.stub_module
    make_lazy(module_path)

    # Need to reload because we del'ed it
    m = sys.modules[module_path]

    # The module should be a LazyModule
    assert isinstance(m, _LazyModuleMarker)

    # Attempting to get an attribute should cause it to import
    assert m.an_attribute == "REALLY_SOME_IMPORTANT_VALUE"

    # But the whole module is still not loaded:
    assert not hasattr(m, "another_attribute")

# Generated at 2022-06-12 07:48:47.829613
# Unit test for function make_lazy
def test_make_lazy():
    """
    Will create a module of name `test_module`, and test that the module
    is a LazyModule
    """
    module_name = 'test_module'
    test_module_name = 'test_module.x'
    class_name = 'test_class'
    function_name = 'test_function'
    module_num = 99

    make_lazy(test_module_name)
    assert isinstance(sys.modules[test_module_name], _LazyModuleMarker)


# Generated at 2022-06-12 07:48:59.680579
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    assert sys.modules['test_make_lazy'] is None
    make_lazy('test_make_lazy')
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    assert sys.modules['test_make_lazy'].__name__ == 'test_make_lazy'
    from test_make_lazy import __name__
    assert __name__ != 'test_make_lazy'
    # __name__ was dynamically loaded from the lazy module
    assert sys.modules['test_make_lazy'].__name__ == __name__
    # The module is still lazily loaded as __name__ is unset
    assert sys.modules['test_make_lazy'].__name__ is __name__

# Generated at 2022-06-12 07:49:05.349088
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests if module is properly marked as lazy.
    """
    import test.test_lazy_module

    # Check if the module has not been loaded
    assert not isinstance(test.test_lazy_module, test.test_lazy_module.__class__)

    # Load the module
    test.test_lazy_module.x

    # Check if the module has been loaded
    assert isinstance(test.test_lazy_module, test.test_lazy_module.__class__)

    # Check if the attribute could be accessed
    assert test.test_lazy_module.x == 5

# Generated at 2022-06-12 07:49:15.189683
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    import os
    import sys
    import unittest

    class TestLoadLazyModule(unittest.TestCase):
        """
        Test for loading the lazy module.
        """

        def test_load_lazy_module(self):
            """
            Test to load the lazy module.
            """
            module_name = 'os'
            curpath = os.path.dirname(os.path.abspath(__file__))

            module = sys.modules[module_name]

            # Check the module was loaded before.
            self.assertTrue(module)

            # Check the module is not lazy.
            self.assertFalse(isinstance(module, _LazyModuleMarker))

            make_lazy(module_name)

            # Check the

# Generated at 2022-06-12 07:49:23.988703
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_lazymodule'
    sys_modules = sys.modules

    # test that the module hasn't been imported
    assert module_path not in sys_modules.keys()

    # create the lazy module
    make_lazy(module_path)

    # test that the module has been imported
    assert module_path in sys_modules.keys()

    # test the module has been substituted with a LazyModule class
    assert isinstance(sys_modules[module_path], _LazyModuleMarker)

    # test the module is not yet imported
    assert sys_modules[module_path].__getattribute__('__name__') == module_path

    # test an attribute access imports the module
    sys_modules[module_path].__getattribute__('True')

    # test the module has been imported now
    assert sys_

# Generated at 2022-06-12 07:49:35.432852
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that `make_lazy` works as expected.
    """
    import sys

    class DummyModule(ModuleType):
        def __init__(self, name):
            ModuleType.__init__(self, name)
            self.init = True

    def _new_module(name, doc=''):
        """
        Returns a new module with a given name and docstring
        """
        return DummyModule(name)
    builtins = __import__('__builtin__')

# Generated at 2022-06-12 07:49:38.907179
# Unit test for function make_lazy
def test_make_lazy():
    import types
    module_path = 'django.utils.functional'
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], types.ModuleType)
    assert module_path in sys.modules

# Generated at 2022-06-12 07:49:49.857918
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # Make sure a module is not in sys.modules
    module_path = 'os'
    assert module_path in sys.modules
    if module_path in sys.modules:
        del sys.modules[module_path]
    assert module_path not in sys.modules

    # Mark the package as lazy
    make_lazy(module_path)
    assert module_path in sys.modules
    lazy_os = sys.modules[module_path]
    assert isinstance(lazy_os, _LazyModuleMarker)
    assert not isinstance(lazy_os, ModuleType)

    # Access an attribute to load the module
    assert lazy_os.path
    assert module_path in sys.modules
    assert isinstance(lazy_os, ModuleType)

# Generated at 2022-06-12 07:49:56.217011
# Unit test for function make_lazy
def test_make_lazy():
    import os.path as op
    import message
    make_lazy('message')
    sys.modules['os.path'] = op

    # validate that `message` is not loaded
    assert 'message' not in sys.modules
    assert message.__name__ == 'message'

    # validate that the correct files is loaded
    assert message.__file__ == op.join(op.dirname(__file__), '../message.py')


# Generated at 2022-06-12 07:49:59.020581
# Unit test for function make_lazy
def test_make_lazy():
    import rpync.sync
    try:
        make_lazy('rpync.sync')
        assert rpync.sync is not None
    finally:
        del sys.modules['rpync.sync']

# Generated at 2022-06-12 07:50:10.191623
# Unit test for function make_lazy
def test_make_lazy():

    def make_module(module_loc, module_name, value):
        """
        Make a module in memory
        """

        if module_loc:
            sys.path.insert(0, module_loc)

        module = imp.new_module(module_name)
        module.value = value
        sys.modules[module_name] = module

        return module

    # Test that importing the module works
    try:
        sys.path.insert(0, '')
        make_module('foo', 'foo', 'value')
        module = __import__('foo')
        assert(module.value == 'value')

    finally:
        # Cleanup our messes
        del sys.modules['foo']
        del sys.path[0]

    # Test that a reference to a module does not import it

# Generated at 2022-06-12 07:50:21.208264
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import numpy

    make_lazy('numpy')

    # Make sure that we can import the module, and that it is lazy
    assert isinstance(numpy, _LazyModuleMarker), 'Failed to import lazy module'

    # Access an attribute off of the module to force it to load
    t = time.time()
    arr = numpy.array([1, 2, 3])
    t = time.time() - t

    assert hasattr(numpy, 'array'), 'Failed to import attribute'
    assert isinstance(numpy.array, types.FunctionType), 'Failed to import correct type'
    assert t < 1, 'Too much time passed.  Is numpy installed?'

# Generated at 2022-06-12 07:50:30.032909
# Unit test for function make_lazy
def test_make_lazy():
    def inner_test():
        from . import views  # pylint: disable=import-outside-toplevel
        return views

    make_lazy('x.views')

    assert not hasattr(sys.modules['x'], 'views')

    try:
        import x.views  # pylint: disable=import-outside-toplevel
    except ImportError:
        pass
    else:
        raise AssertionError('ImportError not raised')

    assert not hasattr(sys.modules['x'], 'views')

    import x.views  # pylint: disable=import-outside-toplevel

    assert inner_test() == sys.modules['x.views']


# Unit tests for function NonLocal

# Generated at 2022-06-12 07:50:35.315985
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        @property
        def test(self):
            return 'hello'

    import os
    make_lazy('os')
    assert 'test' not in dir(os)
    assert 'test' in dir(A)
    assert os.path == os.path
    test_a = A()
    assert test_a.test == 'hello'

# Generated at 2022-06-12 07:50:38.768753
# Unit test for function make_lazy
def test_make_lazy():
    import os
    make_lazy('os')
    old_modules = os.__dict__.copy()
    os.uname()
    assert old_modules != os.__dict__
    assert old_modules['uname'] != os.uname

# Generated at 2022-06-12 07:50:51.837705
# Unit test for function make_lazy
def test_make_lazy():
    # Use the regex module as a guinea pig
    import regex
    module_path = 'regex'

    # Remove the module if already there
    sys_modules = sys.modules
    if module_path in sys_modules:
        del sys_modules[module_path]

    # Check that our value is loaded
    make_lazy(module_path)
    assert module_path in sys_modules
    assert isinstance(sys_modules[module_path], _LazyModuleMarker)
    assert not hasattr(sys_modules[module_path], 'VERBOSE')

    # Check that the module was loaded after we looked for an attribute
    sys_modules[module_path].VERBOSE
    assert module_path in sys_modules
    assert isinstance(sys_modules[module_path], ModuleType)

# Generated at 2022-06-12 07:51:03.282324
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        pass

    class B(object):
        pass

    # patch out sys.modules for test
    sys_modules = sys.modules

# Generated at 2022-06-12 07:51:13.895003
# Unit test for function make_lazy

# Generated at 2022-06-12 07:51:18.887685
# Unit test for function make_lazy
def test_make_lazy():
    module_name = "make_lazy"
    make_lazy(module_name)
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)
    module = sys.modules[module_name]
    assert module.make_lazy is make_lazy
    assert module.__class__ == ModuleType
    assert not isinstance(module, _LazyModuleMarker)

#-------------------------------------------------------------------------------

# Generated at 2022-06-12 07:51:26.532883
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure the `make_lazy` function works as expected.
    """
    import sys
    import re
    import warnings

    # Save the module out to a temporary location.
    tmp_path = tempfile.mkdtemp()
    re_path = os.path.join(tmp_path, 're.py')


# Generated at 2022-06-12 07:51:33.995695
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_make_lazy')

    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    # make sure the module gets imported after an attribute is accessed
    assert hasattr(sys.modules['test_make_lazy'], '__name__')
    assert hasattr(sys.modules['test_make_lazy'], '__getattribute__')
    assert hasattr(sys.modules['test_make_lazy'], '__mro__')
    assert hasattr(sys.modules['test_make_lazy'], '__file__')
    assert not isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)

    make_lazy('test_make_lazy2')

# Generated at 2022-06-12 07:51:44.441243
# Unit test for function make_lazy
def test_make_lazy():
    from datetime import datetime
    from copy import deepcopy

    sys_modules = deepcopy(sys.modules)
    import datetime as lazy_datetime
    assert lazy_datetime is sys_modules['datetime']

    make_lazy('datetime')
    import datetime as lazy_datetime_2
    assert lazy_datetime_2 is sys_modules['datetime']
    assert isinstance(lazy_datetime_2, _LazyModuleMarker)

    # datetime should not be imported yet.
    assert 'datetime' not in sys_modules

    # now, we need to access the datetime module
    assert datetime is sys_modules['datetime']
    assert lazy_datetime_2.datetime is datetime


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-12 07:51:46.385270
# Unit test for function make_lazy
def test_make_lazy():
    import test_util
    make_lazy("test_util")
    import test_util
    assert isinstance(test_util, _LazyModuleMarker)



# Generated at 2022-06-12 07:51:55.664353
# Unit test for function make_lazy
def test_make_lazy():
    """
    Asserts function make_lazy works as desired
    """
    assert 'lazymodule' not in sys.modules
    lazy_module = make_lazy('lazymodule')
    assert lazy_module is not None
    assert 'lazymodule' in sys.modules
    assert sys.modules['lazymodule'] is not lazy_module
    assert not isinstance(sys.modules['lazymodule'], lazy_module)

    make_lazy('lazymodule')
    make_lazy('lazymodule')

    assert lazy_module is not None
    assert 'lazymodule' in sys.modules
    assert sys.modules['lazymodule'] is not lazy_module
    assert not isinstance(sys.modules['lazymodule'], lazy_module)

# Generated at 2022-06-12 07:52:03.350742
# Unit test for function make_lazy
def test_make_lazy():
    if sys.platform == "win32":
        raise pytest.skip("Test not compatible with Windows")

    # Setup
    module_path = 'temp_module'
    file_path = os.path.join(os.path.dirname(__file__), module_path)
    file_path += ".py"


# Generated at 2022-06-12 07:52:13.827010
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_test'] = None
    module = sys.modules['lazy_test']
    assert module is None

    make_lazy('lazy_test')
    assert module is not None
    assert isinstance(module, _LazyModuleMarker)

    with pytest.raises(ImportError):
        module.no_such_attribute

# Generated at 2022-06-12 07:52:22.449235
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    make_lazy('os')

    # check to make sure a real module hasn't been loaded
    if sys.modules['os'] is os:
        raise Exception('Improper lazy loading.')

    # test the lazy loading
    if sys.modules['os'].path is not os.path:
        raise Exception('Improper lazy loading.')

    # test the lazy loading
    if sys.modules['os'].path is not os.path:
        raise Exception('Improper lazy loading.')

    # test isinstance
    if not isinstance(sys.modules['os'], _LazyModuleMarker):
        raise Exception('__mro__ not properly overridden.')

# Generated at 2022-06-12 07:52:29.034595
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy('os')

    assert 'os' not in sys.modules
    assert isinstance(sys.modules['os'], _LazyModuleMarker)

    assert not hasattr(os, 'path')

    assert hasattr(os, 'sep')

    assert hasattr(os, 'sep')

    assert hasattr(os, 'path')
    assert os.path == os.path


if __name__ == "__main__":
    import os
    print(os.path)

# Generated at 2022-06-12 07:52:33.698550
# Unit test for function make_lazy
def test_make_lazy():
    def dummy_module():
        module = sys.modules['lazy.dummy_module']
        module.foo = 'bar'
        return module

    make_lazy('lazy.dummy_module')

    import lazy.dummy_module

    assert isinstance(lazy.dummy_module, _LazyModuleMarker)
    assert lazy.dummy_module.foo is None

    dummy_module()
    assert lazy.dummy_module.foo == 'bar'

# Generated at 2022-06-12 07:52:43.261286
# Unit test for function make_lazy
def test_make_lazy():
    # Test for import is lazy
    sys.modules['testlazy'] = None
    make_lazy('testlazy')
    try:
        assert sys.modules['testlazy'] is not None
    except:
        raise AssertionError("Module should be imported")

    # Test if import is not lazy
    sys.modules['testlazy'] = None
    make_lazy('testlazy')
    try:
        import testlazy
    except:
        raise AssertionError("Module should be imported")

    # Test if attributes are fetched correctly
    sys.modules['testlazy'] = None
    make_lazy('testlazy')
    mod = sys.modules['testlazy']
    assert mod.__getattribute__('__name__') == 'testlazy'

# Generated at 2022-06-12 07:52:54.248666
# Unit test for function make_lazy
def test_make_lazy():
    """
    Returns True if function works properly.
    """
    
    def do_test(mod_name, attribute):
        # Create the module foo.bar
        mod = types.ModuleType(mod_name)
        setattr(mod, attribute, lambda: None)
        sys.modules['foo.bar'] = mod

        # Lazy load foo.bar into foo.lazy
        make_lazy('foo.lazy')
        assert isinstance(sys.modules['foo.lazy'], _LazyModuleMarker)

        # Check that getting an attribute from mod works as expected
        assert getattr(sys.modules['foo.lazy'], attribute)() is None
        assert isinstance(sys.modules['foo.lazy'], ModuleType)

# Generated at 2022-06-12 07:53:01.437985
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import unittest

    # Create a temporary module to use for testing.
    dir_name = os.path.dirname(os.path.abspath(__file__))
    src_file = os.path.join(dir_name, 'temp_make_lazy_test.py')
    with open(src_file, 'wb+') as f:
        f.write('import os; A = os')
    module_path = 'temp_make_lazy_test'

    # Test that the module is normally imported. This also adds the
    # module to the modules list.
    test = __import__(module_path)
    assert test.A is os

    # Verify the module appears in the modules list.
    assert module_path in sys.modules

    # Mark the module as lazy.


# Generated at 2022-06-12 07:53:04.904307
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verify that monkeypatching is working
    """
    import django.apps  # NOQA
    assert not isinstance(django.apps, _LazyModuleMarker)

    make_lazy('django.apps')
    assert isinstance(django.apps, _LazyModuleMarker)

    assert django.apps.__name__ == 'django.apps'
    assert django.apps.__file__ == 'test_make_lazy',\
        'The module should not be loaded at this point.'

    assert not isinstance(django.apps, _LazyModuleMarker)



# Generated at 2022-06-12 07:53:13.447864
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that a lazy module is not imported until
    an attribute is accessed.
    """
    imp.acquire_lock()  # I'm not sure if we need this

    module_path = '_test_module'
    make_lazy(module_path)
    assert module_path not in sys.modules

    # touch the module and then test that it is loaded
    module = sys.modules[module_path]
    assert isinstance(module, _LazyModuleMarker)
    module.attr = 1
    assert module.attr == 1
    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], ModuleType)

    # make sure that the module is not reloaded
    module.attr = 2
    assert module.attr == 2

    # cleanup

# Generated at 2022-06-12 07:53:21.647019
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info[0] >= 3:
        from importlib import reload

    import lazy_module
    reload(lazy_module)

    # __file__ attribute is a marker for not being lazy.
    assert not hasattr(lazy_module, '__file__')

    # lazy_module should not yet be loaded
    assert not hasattr(lazy_module, 'loaded')

    # ask for a property
    assert lazy_module.property == "property"
    # lazy_module should now be loaded
    assert lazy_module.loaded == True

    # reload lazy_module
    reload(lazy_module)
    # __file__ attribute should now exist
    assert hasattr(lazy_module, '__file__')
    # lazy_module should not be reloaded again
    assert lazy_module.loaded == True
    #

# Generated at 2022-06-12 07:53:32.532034
# Unit test for function make_lazy

# Generated at 2022-06-12 07:53:42.926905
# Unit test for function make_lazy
def test_make_lazy():
    class RaceCondition(Exception):
        pass

    class UserModule:
        # If a user module imports the lazy module, it should be a race condition
        def __getattribute__(self, attr):
            raise RaceCondition()

    import sys
    import unittest
    from types import ModuleType

    from lazy_object_proxy import (
        NonLocal,
        # For testing
        _LazyModuleMarker,
        make_lazy,
    )

    class TestMakeLazy(unittest.TestCase):
        def setUp(self):
            self.mod_name = 'lazy_object_proxy.test.test_make_lazy.test_lazy'
            make_lazy(self.mod_name)


# Generated at 2022-06-12 07:53:50.292693
# Unit test for function make_lazy
def test_make_lazy():
    # Fake `sys.modules`
    class Module(object):
        def __init__(self, name):
            self.__name__ = name

    sys.modules = {
        'test': Module('test'),
        'test.module': Module('test.module'),
    }

    assert 'test.module' in sys.modules
    assert 'test.module' not in sys.modules['test'].__dict__

    make_lazy('test.module')

    # Make sure `sys.modules` and `sys.modules['test'].__dict__` don't change
    assert 'test.module' in sys.modules
    assert 'test.module' not in sys.modules['test'].__dict__

    # Make sure the `sys.modules['test.module']` is lazy,
    # and doesn't really import the module.


# Generated at 2022-06-12 07:53:58.396898
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('tests.lazyimport_tests', None)
    assert 'tests.lazyimport_tests' not in sys.modules

    make_lazy('tests.lazyimport_tests')
    assert 'tests.lazyimport_tests' in sys.modules

    assert isinstance(sys.modules['tests.lazyimport_tests'], _LazyModuleMarker)
    assert not hasattr(sys.modules['tests.lazyimport_tests'],  '_lazyimport')

    tests = sys.modules['tests.lazyimport_tests']
    assert tests._lazyimport
    assert hasattr(tests, '_lazyimport')