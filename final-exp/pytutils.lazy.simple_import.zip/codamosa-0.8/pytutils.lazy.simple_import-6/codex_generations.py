

# Generated at 2022-06-12 07:44:04.460706
# Unit test for function make_lazy
def test_make_lazy():

    # Make a temp module.
    mod_name = str(hash(os.times()))
    mod_filename = 'lazy_module_%s.py' % mod_name
    mod_path = mod_filename.replace('.py', '')
    with open(mod_filename, 'w') as f:
        f.write("""hello = 'world'""")

    # Import it.
    mod = importlib.import_module(mod_path)
    assert mod.hello == 'world'
    mod_id = id(mod)

    # Mark the module as lazy.
    make_lazy(mod_path)
    mod = importlib.import_module(mod_path)

    # Check that the module is lazy.
    assert mod_id != id(mod)

# Generated at 2022-06-12 07:44:14.049039
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the behavior of make_lazy().
    """
    # Indicate that the test_make_lazy.test_mod module should be loaded lazily
    make_lazy('test_make_lazy.test_mod')

    # Import the module without running any code in the module
    import test_make_lazy.test_mod

    # Put code in the module after the import
    test_make_lazy.test_mod.a = 1

    # Import the module again, this time running code
    import test_make_lazy.test_mod

    # Check that the code in the module was run.
    assert test_make_lazy.test_mod.a == 1

    # Check that the module was loaded into sys.modules
    assert 'test_make_lazy.test_mod' in sys.modules

# Generated at 2022-06-12 07:44:20.223124
# Unit test for function make_lazy
def test_make_lazy():

    def use_module(module_path):
        sys.modules[module_path]
        return sys.modules[module_path]

    make_lazy('my_module')
    assert not 'my_module' in sys.modules, 'Lazy module is in sys.modules.'
    my_mod = use_module('my_module')
    assert my_mod.__name__ == 'my_module', 'Lazy module did not actually load module.'

# Generated at 2022-06-12 07:44:30.400653
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import random
    import string

    # get a unique name for the test module
    rand_str = ''.join(random.choice(string.ascii_lowercase) for _ in range(13))
    module_path = 'attr_delay_ut_%s' % rand_str

    # make sure the module doesn't already exist
    assert module_path not in sys.modules

    # make a module with the random name
    with open(module_path + '.py', 'w') as f:
        f.write('def func(): return "func"\n')

    # import it for the first time
    first_module = __import__(module_path)

    # make sure the module is properly imported into sys.modules
    assert module_path in sys.modules

# Generated at 2022-06-12 07:44:41.656823
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function `make_lazy`
    """
    # Dummy module for test
    class DummyModule(object):
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            cls.mro = cls.__mro__[1:]
            cls.mro_string = ''.join(cls.mro.__str__())
        def my_func():
            return "Vishal"
        def __init__(self):
            self.my_func = my_func
        # Function that makes dummy module lazy
        make_lazy('dummy_module')

    # Check if it can be imported
    import dummy_module as dm
    # Check if it is an instance of LazyModule
    assert isinstance

# Generated at 2022-06-12 07:44:45.374234
# Unit test for function make_lazy
def test_make_lazy():
    import imp
    import os
    import tempfile

    # This module depends on the test module.
    # We will test in the next step that this is fine.
    # The module also uses __future__, so we do that too.

# Generated at 2022-06-12 07:44:51.078633
# Unit test for function make_lazy
def test_make_lazy():
    from lazyload import make_lazy
    make_lazy('lazyload')

    import lazyload
    assert isinstance(lazyload, _LazyModuleMarker)

    # Now use the lazy module
    import lazyload  # noqa
    assert isinstance(lazyload, _LazyModuleMarker)


test_make_lazy()

# Generated at 2022-06-12 07:45:01.676229
# Unit test for function make_lazy
def test_make_lazy():
    import test_make_lazy_pkg

    # Mark the module as lazy.
    make_lazy('test_make_lazy_pkg')

    test_make_lazy_pkg.__name__
    assert 'inner' not in dir(test_make_lazy_pkg)
    assert isinstance(test_make_lazy_pkg, _LazyModuleMarker)
    assert not isinstance(test_make_lazy_pkg, ModuleType)
    # When we access attribute on the package, it is imported.
    test_make_lazy_pkg.inner
    assert 'inner' in dir(test_make_lazy_pkg)
    assert isinstance(test_make_lazy_pkg, ModuleType)
    assert not isinstance(test_make_lazy_pkg, _LazyModuleMarker)

# Generated at 2022-06-12 07:45:05.032298
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.clear()
    make_lazy('lazy_me')

    # LazyModule should be in sys for lazy_me
    assert 'lazy_me' in sys.modules

# Generated at 2022-06-12 07:45:09.786588
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules.clear()
    import os
    os_path = os.__name__
    make_lazy(os_path)
    assert isinstance(os, _LazyModuleMarker)
    assert not hasattr(os, '__file__')
    assert os.path.exists(__file__)
    assert hasattr(os, '__file__')
    assert isinstance(os, ModuleType)
    assert os.path.exists(__file__)

# Generated at 2022-06-12 07:45:15.272144
# Unit test for function make_lazy
def test_make_lazy():
    # Import 'os' module for testing purpose
    m = __import__('os')

    # Make the module lazy
    make_lazy('os')
    assert sys.modules['os']

    # Call function make_lazy again
    with pytest.raises(KeyError):
        make_lazy('os')


# Generated at 2022-06-12 07:45:26.321314
# Unit test for function make_lazy
def test_make_lazy():
    """
    This is not a real unit test, but rather a simple script to
    test the functionality of the `make_lazy` function.
    """
    import my_plugin

    assert isinstance(my_plugin, _LazyModuleMarker)
    assert not hasattr(my_plugin, 'hey_look_im_a_module')

    # See? it is still a LazyModule
    assert not isinstance(my_plugin, ModuleType)

    # If we use something in the module, it will be imported.
    assert my_plugin.hey_look_im_a_module == 'yay'

    # But it will no longer be lazy
    assert isinstance(my_plugin, ModuleType)

    # If we try to access something not in the module, it will raise an
    # AttributeError, just like normal modules.
   

# Generated at 2022-06-12 07:45:31.728214
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType

    make_lazy('foo')

    # Check that `sys.modules` contains our LazyModule.
    assert isinstance(sys.modules['foo'], _LazyModuleMarker)
    # Check that our LazyModule still passes `isinstance(ModuleType)`
    assert isinstance(sys.modules['foo'], ModuleType)



# Generated at 2022-06-12 07:45:38.690017
# Unit test for function make_lazy
def test_make_lazy():
    module = 'make_lazy_test_module'
    if module in sys.modules:
        del sys.modules[module]
    import make_lazy_test_module
    assert isinstance(make_lazy_test_module, ModuleType)
    del sys.modules[module]
    make_lazy(module)
    assert isinstance(make_lazy_test_module, _LazyModuleMarker)
    from make_lazy_test_module import a  # noqa
    assert isinstance(make_lazy_test_module, ModuleType)

# Generated at 2022-06-12 07:45:44.340871
# Unit test for function make_lazy
def test_make_lazy():
    """
    The purpose of this test:
        1. Validate the correct binding id of a lazy module
        2. Validate the correct behavior after the first time access.

    See PEP 3121 for more information.
    "while a package like foo.bar.baz is a module, it is not an instance of
    module type; it is an instance of some other type."

    "When a module object has been created, its name (the variable used in
    import or from) is bound directly to the module object. This can lead to
    confusion -- the name of the module is not the same as the module object!"
    """
    module_path = '__main__'
    sys_modules = sys.modules
    # The original binding id of module that is imported by __import__.
    original_binding_id = id(sys_modules[module_path])

# Generated at 2022-06-12 07:45:56.147422
# Unit test for function make_lazy
def test_make_lazy():
    # Test dynamic module loading, make sure it works every time
    for i in xrange(10):
        make_lazy('test_make_lazy')
        from test_make_lazy import test_make_lazy

    assert type(test_make_lazy) is int
    assert test_make_lazy == 1

    # Test basic is_lazy
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)

    # Test is_lazy with isinstance
    import test_make_lazy
    assert isinstance(test_make_lazy, _LazyModuleMarker)

    # Test is_lazy after accessing attribute
    assert test_make_lazy == test_make_lazy.test_make_lazy

# Generated at 2022-06-12 07:46:01.972055
# Unit test for function make_lazy
def test_make_lazy():
    assert sys.modules.get('import_me') is None
    make_lazy('import_me')
    import_me = sys.modules['import_me']
    assert isinstance(import_me, _LazyModuleMarker)
    # Test module has been loaded
    import_me.foo = 'bar'
    assert import_me.foo == 'bar'
    assert sys.modules['import_me'] is not import_me
    import_me = sys.modules['import_me']
    assert isinstance(import_me, ModuleType)
    assert import_me.foo == 'bar'


# Generated at 2022-06-12 07:46:13.090421
# Unit test for function make_lazy
def test_make_lazy():
    """
    test_make_lazy()
    Unit test for function make_lazy()
    """
    import tempfile
    filename = tempfile.mktemp()
    with open(filename, 'w') as fh:
        fh.writelines(['# Test module for make_lazy\n',
                       'Laziness = 42\n',
                       'import time\n',
                       'time.sleep(1)\n',
                       ])


# Generated at 2022-06-12 07:46:22.601956
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'test_module'

    # this is the the module we will be lazy loading
    test_module = ModuleType('test_module')

    # make sure it doesn't exist in sys.modules
    assert module_name not in sys.modules, 'test_module is already in sys.modules'

    # make our module lazy
    make_lazy(module_name)

    # verify that our lazy module is in sys.modules
    assert module_name in sys.modules, 'test_module is not in sys.modules'

    # verify the module is a LazyModule
    assert isinstance(sys.modules[module_name], _LazyModuleMarker), 'sys.modules[module_name] is not a LazyModule'

    # assert the module hasn't loaded yet
    assert sys.modules[module_name].__class__.__

# Generated at 2022-06-12 07:46:25.655123
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy function, to ensure that it can import
    a module when called.
    """
    import __hello__
    make_lazy('__hello__')
    assert hasattr(__hello__, 'hello')

# Generated at 2022-06-12 07:46:36.614354
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the `make_lazy` function.
    """
    # The following tests can only be run in a new interpreter.
    # When this is imported, the module will be in sys.modules.
    # Thus, we spawn a new interpreter here to test the function.

# Generated at 2022-06-12 07:46:41.142892
# Unit test for function make_lazy
def test_make_lazy():
    # Ensure the function can be called without error
    class FakeModule:
        def foo(self):
            pass
    sys.modules['fake_module'] = f = FakeModule()
    make_lazy('fake_module')
    assert isinstance(f, _LazyModuleMarker)
    del sys.modules['fake_module']

# Generated at 2022-06-12 07:46:43.620515
# Unit test for function make_lazy
def test_make_lazy():
    # The function is used in test_import_string and the
    # lazy imports are executed in the test.
    assert(True)

test__all__ = [test_make_lazy]

# Generated at 2022-06-12 07:46:49.125463
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import imp

    sys.modules['django.db.models.fields.files'] = True

    make_lazy('django.db.models.fields.files')

    assert sys.modules['django.db.models.fields.files']
    assert not os.path.exists(imp.find_module('django.db.models.fields.files')[1])



# Generated at 2022-06-12 07:46:59.153293
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy
    """
    import six.moves.urllib.parse

    assert isinstance(six.moves.urllib.parse, _LazyModuleMarker)
    assert six.moves.urllib.parse.__name__ == 'six.moves.urllib.parse'
    assert 'urlparse' in sys.modules
    assert 'urllib.parse' not in sys.modules

    assert six.moves.urllib.parse.urlparse is not None
    assert 'urllib.parse' in sys.modules
    assert isinstance(six.moves.urllib.parse, ModuleType)



# Generated at 2022-06-12 07:47:07.326742
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that lazy module works as expected.
    """
    import sys

    import mock
    import pytest

    # Storing this value in the test_make_lazy module dict
    make_lazy('test_make_lazy.non_existing_module')

    with mock.patch.object(sys, 'modules', {}):
        # Importing again to make sure the module is in sys.modules
        __import__('test_make_lazy.non_existing_module')

        with pytest.raises(ImportError) as exc_info:
            __import__('non_existing_module')
        assert non_existing_module.__class__.__name__ == 'LazyModule'
        assert isinstance(non_existing_module, _LazyModuleMarker)


# Non-existing modules

# Generated at 2022-06-12 07:47:17.357532
# Unit test for function make_lazy
def test_make_lazy():
    # defualt imports/exports
    imports = set(sys.modules)
    exports = set(sys.modules)

    module_path = 'lazymodule'
    class ExpectedModule(object):
        pass
    expected_module = ExpectedModule()
    with patch('sys.modules', {}) as sys_modules_dict, \
            patch('__builtin__.__import__', return_value=expected_module) as import_patch:
        make_lazy(module_path)

        # test if module is in sys.module after import
        assert module_path in sys.modules
        # test if module in sys.modules is an instance of LazyModule
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        # test if the LazyModule returned the expected module

# Generated at 2022-06-12 07:47:26.180503
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # make sure our NonLocal variable works as expected
    nl = NonLocal(None)
    assert nl.value is None
    nl.value = 'something'
    assert nl.value == 'something'

    # make sure the _LazyModuleMarker does not look like a module
    assert not isinstance(_LazyModuleMarker(), ModuleType)

    # make sure the LazyModule does look like a module
    mod = LazyModule()
    assert isinstance(mod, ModuleType)
    assert isinstance(mod, _LazyModuleMarker)

    # make sure the LazyModule looks like the os module
    assert isinstance(os, ModuleType)
    assert isinstance(mod, type(os))

    # make sure we don't blow up when we query a non-existent attribute

# Generated at 2022-06-12 07:47:33.235149
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('lazy_module', None)

    import lazy_module
    assert not isinstance(lazy_module, _LazyModuleMarker)

    make_lazy('lazy_module')

    import lazy_module
    assert isinstance(lazy_module, _LazyModuleMarker)

    lazy_module.test_val = 10

    assert lazy_module.test_val == 10
    assert not isinstance(lazy_module, _LazyModuleMarker)

    del sys.modules['lazy_module']

# Generated at 2022-06-12 07:47:44.025936
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import six

    module_name = 'test_module_name'
    if six.PY2:
        reload(sys)
        sys.setdefaultencoding('utf-8')

    sys.modules[module_name] = None
    make_lazy(module_name)
    assert module_name in sys.modules
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)
    try:
        assert 'func' not in sys.modules[module_name].__dict__
    except AttributeError:
        if six.PY2:
            raise
        import types
        assert 'func' not in dir(sys.modules[module_name])

    func = sys.modules[module_name].func
    assert func.__name__ == 'func'
    assert module_name in sys

# Generated at 2022-06-12 07:47:59.331339
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import imp
    import os


# Generated at 2022-06-12 07:48:10.221698
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    module_name = 'lazy_test'

    def remove_module():
        if module_name in sys.modules:
            del sys.modules[module_name]

    try:
        module = __import__(module_name)
    except ImportError as e:
        if e.message != 'No module named %r' % module_name:
            raise

    class LazyTest(object):
        pass

    make_lazy(module_name)

    module = __import__(module_name)
    assert isinstance(module, _LazyModuleMarker)

    remove_module()
    make_lazy(module_name)

    module = __import__(module_name)
    assert isinstance(module, _LazyModuleMarker)

    sys.modules[module_name] = None
    make

# Generated at 2022-06-12 07:48:19.800708
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules
    from os import path
    from types import ModuleType
    assert 'lazy_module' not in modules
    # Careful with this, you can break a real module
    make_lazy('lazy_module')
    assert 'lazy_module' in modules
    assert isinstance(modules['lazy_module'], ModuleType)
    assert isinstance(modules['lazy_module'], _LazyModuleMarker)
    assert not hasattr(modules['lazy_module'], '__loader__')
    assert not hasattr(modules['lazy_module'], '__file__')
    assert not hasattr(modules['lazy_module'], '__name__')
    assert modules['lazy_module'].__name__ == 'lazy_module'
    assert modules['lazy_module'].__loader

# Generated at 2022-06-12 07:48:26.563206
# Unit test for function make_lazy
def test_make_lazy():
    mod = sys.modules.get('my_lazy_module')
    if mod is not None:
        del sys.modules['my_lazy_module']
    make_lazy('my_lazy_module')
    assert 'my_lazy_module' in sys.modules

    mod = sys.modules.get('my_lazy_module')
    assert isinstance(mod, _LazyModuleMarker)
    assert '__mro__' in dir(mod)
    assert '__getattribute__' in dir(mod)

    func = getattr(mod, 'func')
    assert func() == 'result'

# Generated at 2022-06-12 07:48:34.534444
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test'

    # Create testing module
    sys.modules[module_path] = ModuleType(module_path)
    sys.modules[module_path].attribute = 'value'

    assert module_path in sys.modules
    assert sys.modules[module_path].attribute == 'value'

    make_lazy(module_path)

    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert sys.modules[module_path].attribute == 'value'

# Generated at 2022-06-12 07:48:41.507624
# Unit test for function make_lazy
def test_make_lazy():
    import types
    import os, sys

    __test__ = False

    # make a fake module
    # put it in the python path so we can import it and find it
    sys.path.append(os.path.dirname(os.path.dirname( os.path.realpath(__file__))))

    from setup import make_lazy

    # ensure our fake module is not in the sys.modules
    assert 'test_lazy_module' not in sys.modules

    make_lazy('test_lazy_module')

    # ensure our fake module _is_ in the sys.modules
    assert 'test_lazy_module' in sys.modules

    # ensure our fake module is not actually imported
    assert 'test_lazy_module.teststring' not in sys.modules

    # ensure our fake module is an instance of a module

# Generated at 2022-06-12 07:48:50.796249
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import warnings
    import test_lazyimport

    module_path = "test_lazyimport"

    def test_unlazy_module_import():
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            del sys.modules["test_lazyimport"]

        import test_lazyimport

    # Test that the module is not created when we create a lazy import,
    # and that when we access the module, it is created.
    os.environ["TEST_LAZYIMPORT"] = "initial"

    # Create a lazy import
    make_lazy(module_path)

    # Make sure it was not loaded yet
    assert os.environ["TEST_LAZYIMPORT"] == "initial"

    # Try to access the module
    test_lazyimport.access

# Generated at 2022-06-12 07:48:52.299686
# Unit test for function make_lazy
def test_make_lazy():
    import json
    make_lazy('json')
    assert isinstance(json, _LazyModuleMarker)

    # First access to json module loads it
    assert json is not None
    assert hasattr(json, 'loads')



# Generated at 2022-06-12 07:48:59.341295
# Unit test for function make_lazy
def test_make_lazy():

    test_module = "test"

    make_lazy(test_module)

    if test_module not in sys.modules:
        raise ValueError("Something wrong with make_lazy. Test module %s not in sys.modules" % test_module)

    # Try to access attribute
    try:
        sys.modules[test_module].val
    except:
        raise ValueError("Something wrong with make_lazy. Test module %s can not be accessed" % test_module)

# Generated at 2022-06-12 07:49:04.770054
# Unit test for function make_lazy
def test_make_lazy():
    """
    Check to make sure make_lazy works properly
    """
    from . import fixtures
    from .fixtures.lazy_module import lazy_module

    assert 'lazy_module' in fixtures.__dict__
    assert 'lazy_module2' not in fixtures.__dict__

    assert isinstance(fixtures.lazy_module, _LazyModuleMarker)
    assert fixtures.lazy_module.lazy_module2 is not None
    assert 'lazy_module2' in fixtures.__dict__



# Generated at 2022-06-12 07:49:24.632414
# Unit test for function make_lazy
def test_make_lazy():
    import random
    import math
    import os

    # Let's assert that these modules are not lazy.
    assert not isinstance(random, _LazyModuleMarker)
    assert not isinstance(math, _LazyModuleMarker)
    assert not isinstance(os, _LazyModuleMarker)

    # Now, let's make them lazy!
    make_lazy('random')
    make_lazy('math')
    make_lazy('os')

    # Now, let's assert that we can't access them anymore,
    # until we load them using one of thei attributes.
    try:
        random
    except KeyError:
        pass
    else:
        raise AssertionError('Accessing random did not raise KeyError!')
    try:
        math
    except KeyError:
        pass

# Generated at 2022-06-12 07:49:29.116736
# Unit test for function make_lazy
def test_make_lazy():  # pylint: disable=W0613
    """
    Unit test for function make_lazy
    """
    import mock
    from docker_registry_client import formatter

    def mock_import(module):
        """
        Mock import for this test
        """
        if module == 'docker_registry_client.formatter':
            return formatter
        return mock.DEFAULT

    with mock.patch.object(formatter, '__import__', mock_import):
        make_lazy('docker_registry_client.formatter')
        from docker_registry_client.formatter import (
            DeltaFormatter, ImageDigestFormatter, ImageFormatter, TagFormatter
        )
        test_formatter = DeltaFormatter()
        assert test_formatter.__class__.__name__ == 'DeltaFormatter'



# Generated at 2022-06-12 07:49:37.170620
# Unit test for function make_lazy
def test_make_lazy():
    import timeit
    import random
    t = timeit.timeit('test_make_lazy_imports()',
                      setup='from %s import test_make_lazy_imports' % __name__,
                      number=100)
    print('Test 1: %ss' % t)

    # Load the `timeit` module right before we try to use it
    make_lazy('timeit')
    t = timeit.timeit('test_make_lazy_imports()',
                      setup='from %s import test_make_lazy_imports' % __name__,
                      number=100)
    print('Test 2: %ss' % t)

    # Load the random module right before we try to use it
    make_lazy('random')

# Generated at 2022-06-12 07:49:42.973099
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy
    """
    # pylint: disable=W0612,W0613
    make_lazy('foo')
    import foo # noqa
    # make sure we overrode the import.
    assert not isinstance(foo, ModuleType)
    # make sure we can get attributes
    foo.bar = 'hello there!'
    assert foo.bar == 'hello there!'

# Generated at 2022-06-12 07:49:54.071122
# Unit test for function make_lazy
def test_make_lazy():
    class _X:
        def __init__(self, val):
            self.val = val

    class _Y:
        def __init__(self, val):
            self.val = val

    x = _X(1)
    y = _Y(2)

    # Create a namespace where we will define the variables

    ns = {}

    # Define a function that modifies the local variables
    def mod_locals(val):
        x = _X(val)
        y = ns['y']

    # Modify the local variables
    mod_locals(10)

    print(x, x.val)  # _X object at 0x1005b2148, 1
    print(y, y.val)  # _Y object at 0x100bcef10, 2

    ns = {}

    # Define

# Generated at 2022-06-12 07:50:02.747702
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys
    import os
    from types import ModuleType
    from shutil import rmtree
    from tempfile import mkdtemp
    from tempfile import mkstemp

    tempdir = mkdtemp()


# Generated at 2022-06-12 07:50:12.388214
# Unit test for function make_lazy
def test_make_lazy():
    d = {}
    d['__name__'] = 'test_make_lazy'
    d['__file__'] = '/tmp/test_make_lazy.py'
    d['lazy'] = make_lazy('test_make_lazy')
    d['lazy'].__globals__['__name__'] = 'test_make_lazy'

    # Ensure that the module has not been initialized.
    assert d['lazy'].__dict__ == {}

    # Ensure that it does not error out when attempting to import something
    # that does not exist.
    try:
        d['lazy'].does_not_exist
    except Exception as e:
        assert 'does_not_exist' in str(e)

    # Add something to the module.

# Generated at 2022-06-12 07:50:21.974878
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests for function make_lazy
    """
    import sys
    assert sys.modules["dummy"].__class__.__name__ == "_LazyModuleMarker"
    assert sys.modules["dummy"].__name__ == "dummy"
    assert sys.modules["dummy"].__dict__ == {}

    import dummy
    assert sys.modules["dummy"].__class__.__name__ == "module"
    assert sys.modules["dummy"].__name__ == "dummy"
    assert sys.modules["dummy"].__dict__["test_str"] == "test"


test_str = "test"
make_lazy("dummy")

# Generated at 2022-06-12 07:50:30.362792
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that using make_lazy works as expected.
    """
    try:
        del sys.modules['django.contrib.gis.gdal.envelope']
    except KeyError:
        pass

    import django.contrib.gis.gdal

    assert('django.contrib.gis.gdal.envelope' not in sys.modules)
    envelope = django.contrib.gis.gdal.envelope
    assert('django.contrib.gis.gdal.envelope' in sys.modules)
    assert(envelope is sys.modules['django.contrib.gis.gdal.envelope'])

# Generated at 2022-06-12 07:50:40.553702
# Unit test for function make_lazy
def test_make_lazy():
    from django.utils import six

    module_path = 'django_util_lazymodule_test.module'

    make_lazy(module_path)
    assert module_path not in sys.modules

    lazy_module = sys.modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(lazy_module, ModuleType)

    # We can't import it
    assert not hasattr(lazy_module, 'test_attr')
    assert not hasattr(six, 'test_attr')

    # We can't use it
    try:
        from django_util_lazymodule_test import module
    except ImportError:
        pass
    else:
        raise RuntimeError("We should not be able to import the module.")


# Generated at 2022-06-12 07:51:11.124212
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('time')
    import time
    assert isinstance(time, _LazyModuleMarker)
    assert time.time() > 0

    make_lazy('sys')
    import sys
    assert isinstance(sys, _LazyModuleMarker)
    assert sys.version_info[0] >= 3

# Generated at 2022-06-12 07:51:18.597228
# Unit test for function make_lazy
def test_make_lazy():
    import django.contrib.messages
    import django.core.context_processors
    import django.core.mail
    import django.core.urlresolvers
    import django.forms
    import django.http
    import django.shortcuts
    import django.template
    import django.test
    import django.utils
    import django.utils.functional
    import django.views
    import django.views.decorators

    assert 'django.contrib.messages' in sys.modules
    assert 'django.core.context_processors' in sys.modules
    assert 'django.core.mail' in sys.modules
    assert 'django.core.urlresolvers' in sys.modules
    assert 'django.forms' in sys.modules

# Generated at 2022-06-12 07:51:24.861029
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for the function make_lazy
    """

    lazy_module = 'lazy_module'
    module = make_lazy(lazy_module)

    assert module is sys.modules[lazy_module]  # test if lazy module is created
    assert not isinstance(module, ModuleType)
    assert isinstance(module, _LazyModuleMarker)

# Generated at 2022-06-12 07:51:32.396909
# Unit test for function make_lazy
def test_make_lazy():
    """
    This is a standalone unit test for the make_lazy function.
    """
    import os
    import tempfile
    import shutil
    import importlib
    import inspect

    # Create a temporary directory to put the module we are going to create
    # in.
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 07:51:42.991516
# Unit test for function make_lazy
def test_make_lazy():
    """function for testing what make_lazy does"""
    import sys
    sys.modules['sys.modules.lazymodule'] = {}
    make_lazy('sys.modules.lazymodule')
    if isinstance(sys.modules['sys.modules.lazymodule'], _LazyModuleMarker):
        print('TEST 1 PASSED, sys.modules.lazymodule is instance of _LazyModuleMarker')
    else:
        print('TEST 1 FAILED, sys.modules.lazymodule is not an instance of _LazyModuleMarker')
    import sys.modules.lazymodule
    if isinstance(sys.modules['sys.modules.lazymodule'], _LazyModuleMarker):
        print('TEST 2 PASSED, sys.modules.lazymodule is now a standard module')

# Generated at 2022-06-12 07:51:46.002973
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('lazy')
    import lazy
    assert isinstance(lazy, _LazyModuleMarker)


# After calling make_lazy, all modules that should be autoloaded will be
# in the form of lazy._ModuleName.
# This function extracts the module names

# Generated at 2022-06-12 07:51:55.491337
# Unit test for function make_lazy
def test_make_lazy():
    import os, sys
    import tempfile

    path = tempfile.mkdtemp()

    with open(os.path.join(path, 'somemodule.py'), 'w', encoding='utf-8') as f:
        f.write('attr = 42')

    sys.path = [path] + sys.path

    module_path = 'somemodule'
    assert module_path not in sys.modules

    assert sys.modules[module_path].attr == 42

    make_lazy(module_path)

    assert sys.modules[module_path].attr == 42
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    import shutil
    shutil.rmtree(path)
    assert module_path not in sys.modules

# Generated at 2022-06-12 07:52:01.176782
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test out the make_lazy function
    """
    lazy_mod_str = 'test_make_lazy_mod'
    lazy_mod_path = 'test_make_lazy_mod'

    make_lazy(lazy_mod_path)
    mod = lazy_mod_path
    assert isinstance(sys.modules[mod], _LazyModuleMarker)
    sys.modules[mod].__loader__


if  __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-12 07:52:11.372129
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy('magic')

    # Lazy module should be in sys.modules
    assert('magic' in sys.modules)
    # Should be of type LazyModule
    assert(isinstance(sys.modules['magic'], _LazyModuleMarker))

    # Importing magic shouldn't actually import the library
    try:
        import magic
    except Exception as e:
        assert(False)

    # Lazy module should still be in sys.modules
    assert('magic' in sys.modules)

    # Lazy module should be of type LazyModule
    assert(isinstance(sys.modules['magic'], _LazyModuleMarker))

    # Access a very common attribute on the magic module to force the library
    # to lazy-load
    assert(magic.open(magic.MAGIC_NONE) is not None)

    #

# Generated at 2022-06-12 07:52:16.960712
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    if sys.version_info < (3, 0):
        # We need to make sure that `module.value` is a NonLocal
        # and not a local variable. This ensures that the module
        # won't get imported by the `module.value = __import__(module_path)`
        # statement.
        assert 'module' not in locals()
    assert isinstance(make_lazy('django.utils'), _LazyModuleMarker)

# Generated at 2022-06-12 07:53:20.345410
# Unit test for function make_lazy
def test_make_lazy():
    """
    A unit test to ensure that the function make_lazy works as intended.
    """
    # Mock the modules dict to test the behaviour.
    old_modules = sys.modules
    sys.modules = {}

    def reset_sys_module_dict():
        """
        Reset the module dict to the original state.
        """
        sys.modules = old_modules

    # This should not fail.
    make_lazy('sys')

    # The imported module should not be a real lazy module.
    assert not isinstance(sys.modules['sys'], _LazyModuleMarker)
    # The module should be importable now.
    assert isinstance(__import__('sys'), ModuleType)
    # The module dict should have been populated as we imported the sys module.
    assert 'sys' in sys.modules and 'sys' in sys

# Generated at 2022-06-12 07:53:28.985721
# Unit test for function make_lazy
def test_make_lazy():
    import tempfile
    path = tempfile.mkdtemp()
    # import path of module we want to lazily load
    module_path = path + '/test_mod.py'

    assert path in sys.path
    sys.modules.pop(module_path, None)

    # This module will be marked as lazy
    with open(module_path, 'wt') as f:
        f.write('b = 3\n'
                'def add(a):\n'
                '    return a + b\n'
                'c = add(3)')

    make_lazy(module_path)

    # Check that the module is not yet imported
    assert 'c' not in sys.modules
    # Check that the module is in sys.modules

# Generated at 2022-06-12 07:53:38.890657
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy produces the expected result.
    """
    def name_in_sys_modules():
        """
        Checks for expected results in sys.modules
        """
        lazy_module = sys.modules['packaging.version']
        assert isinstance(lazy_module, _LazyModuleMarker)
        assert lazy_module.__class__.__name__ == 'LazyModule'

        # Make sure that __import__('packaging.version') does not work
        # as expected.
        assert 'packaging.version' not in sys.modules

    # First check that the 'packaging.version' module exists in sys.modules
    assert 'packaging.version' in sys.modules

    # Use make_lazy to lazy-load the 'packaging.version' module

# Generated at 2022-06-12 07:53:45.415971
# Unit test for function make_lazy
def test_make_lazy():
    import types
    import os
    import tempfile
    import sys
    import imp

    def make_temp_module(name, source):
        tempdir = tempfile.gettempdir()
        module_file = open(os.path.join(tempdir, name + '.py'), 'w')
        module_file.write(source)
        module_file.close()
        return imp.load_source(name, os.path.join(tempdir, name + '.py'))


# Generated at 2022-06-12 07:53:54.775932
# Unit test for function make_lazy
def test_make_lazy():
    from os.path import abspath
    file_path = abspath(__file__)
    file_name, _ = os.path.splitext(os.path.basename(file_path))
    try:
        del sys.modules[file_name]
    except KeyError:
        pass
    assert file_name not in sys.modules
    make_lazy(file_name)
    assert file_name in sys.modules
    assert isinstance(sys.modules[file_name], _LazyModuleMarker)
    assert sys.modules[file_name].__mro__()[1] == ModuleType
    assert not hasattr(sys.modules[file_name], 'make_lazy')
    assert hasattr(sys.modules[file_name], '__mro__')
    assert file_name not in sys.modules