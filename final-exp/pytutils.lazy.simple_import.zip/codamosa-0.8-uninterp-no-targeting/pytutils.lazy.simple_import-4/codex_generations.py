

# Generated at 2022-06-21 21:57:23.638006
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('example')
    assert isinstance(example, _LazyModuleMarker)
    assert not hasattr(example, '__file__')
    assert hasattr(example, 'foo')
    assert hasattr(example, '__file__')
    assert example.__file__

# Generated at 2022-06-21 21:57:32.426980
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """
    import collections
    import sys

    module_path = 'collections'
    module = sys.modules[module_path]

    make_lazy(module_path)

    assert isinstance(module, _LazyModuleMarker), \
            "Expected <class '%s'> got <class '%s'>" % (
                    _LazyModuleMarker.__name__, module.__class__.__name__)
    assert issubclass(collections.Callable, object)

    # Make sure we can actually import the module.
    import collections

# Generated at 2022-06-21 21:57:35.055116
# Unit test for constructor of class NonLocal
def test_NonLocal():
	a = NonLocal(3)
	assert(a.value == 3)

# Generated at 2022-06-21 21:57:40.102274
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Foo(object):
        def __init__(self, name):
            self.name = name
    a = NonLocal(Foo('bar'))
    assert a.value.name == 'bar'


# Generated at 2022-06-21 21:57:46.378181
# Unit test for function make_lazy
def test_make_lazy():
    import six
    if six.PY3:
        # make_lazy will only work in Python 2, because it requires being able
        # to remove non-global variables from the global scope.
        return
    else:
        # create a normal module
        import __main__
        __main__.foo = 'bar'
        # define a lazy module
        make_lazy('__main__')
        # try to access foo
        assert __main__.foo == 'bar'

# Generated at 2022-06-21 21:57:49.353110
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    make_lazy('sys')
    assert sys.modules['sys'].__class__ == NonLocal
    assert sys.version

# Generated at 2022-06-21 21:57:57.871255
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info[0] == 2:
        import __builtin__
    else:
        import builtins as __builtin__

    make_lazy(__name__)

    # Check if available in the builtins
    if '_LazyModuleMarker' not in __builtin__.__dict__:
        raise Exception('Lazy modules not in the builtins')

    # Check if available in the sys.modules
    if '_LazyModuleMarker' not in sys.modules[__name__].__dict__:
        raise Exception('Lazy modules not in the sys.modules [%s]' % __name__)

    # Check if they are the same

# Generated at 2022-06-21 21:57:59.565221
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object) == True


# Generated at 2022-06-21 21:58:02.221939
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal('foo')
    ok_(nonlocal_.value == 'foo')
    ok_(nonlocal_.value == getattr(nonlocal_, 'value'))

# Generated at 2022-06-21 21:58:09.069612
# Unit test for function make_lazy
def test_make_lazy():
    """
    Simple unit test that verifies that the function make_lazy
    behaves as expected.
    """
    make_lazy("nonlazy_module")
    import nonlazy_module
    assert isinstance(nonlazy_module, _LazyModuleMarker)
    assert nonlazy_module.__name__ == "nonlazy_module"
    assert nonlazy_module.__file__ is not None
    assert nonlazy_module.__loader__ is not None
    assert nonlazy_module.__package__ is None
    assert nonlazy_module.__doc__ is not None

# Generated at 2022-06-21 21:58:11.623018
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-21 21:58:22.562072
# Unit test for function make_lazy
def test_make_lazy():
    from random import choice

    # Make sure we don't import big modules if possible
    mods_to_test = [mod for mod in sys.modules.values()
                    if isinstance(mod, ModuleType)
                    and mod.__name__.find('.') == -1]
    mod = choice(mods_to_test)
    mod_path = mod.__name__
    mod_attrs = dir(mod)

    make_lazy(mod_path)
    lazy_mod = sys.modules[mod_path]

    # Check that the module instance is now a LazyModule
    assert isinstance(lazy_mod, _LazyModuleMarker) is True

    # Check that we can get an attribute off of the lazy module
    # and it will load the full module and replace the lazy module
    # with the full module.
    att

# Generated at 2022-06-21 21:58:27.509890
# Unit test for function make_lazy
def test_make_lazy():
    import test
    assert(isinstance(test, _LazyModuleMarker))
    assert(not hasattr(test, 'x'))
    test.x = 10
    assert(test.x == 10)
    assert(isinstance(test, ModuleType))
    test.y = 20
    assert(test.y == 20)

# Generated at 2022-06-21 21:58:35.101479
# Unit test for function make_lazy
def test_make_lazy():
    from django.utils import six
    six_marked_as_lazy = make_lazy('django.utils.six')

    assert sys.modules['django.utils.six'].__class__ is LazyModule, "The module django.utils.six should be an instance of LazyModule"
    assert isinstance(six_marked_as_lazy, _LazyModuleMarker), "The module django.utils.six should be an instance of _LazyModuleMarker"
    assert isinstance(six_marked_as_lazy, six.MovedModule), "The module django.utils.six should be an instance of six.MovedModule"


make_lazy('django.utils.six')

# Generated at 2022-06-21 21:58:36.461455
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl=NonLocal(3)
    assert nl.value==3

# Generated at 2022-06-21 21:58:38.619583
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = 10
    b = NonLocal(a)

# Generated at 2022-06-21 21:58:48.761059
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('test')
    assert isinstance(sys.modules['test'], _LazyModuleMarker)
    from test import lazy_module, nonlazy_module
    assert isinstance(sys.modules['test'], ModuleType)
    assert sys.modules['test'].lazy_module
    assert sys.modules['test'].nonlazy_module
    assert isinstance(sys.modules['test.lazy_module'], ModuleType)
    assert isinstance(sys.modules['test.nonlazy_module'], ModuleType)
    assert sys.modules['test.nonlazy_module'].foobar
    assert sys.modules['test.nonlazy_module'].baz
    assert sys.modules['test.lazy_module'].foo

# Generated at 2022-06-21 21:58:54.099171
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

    def f():
        n = NonLocal(2)
        return n

    assert f().value == 2

    def g():
        def h():
            n = NonLocal(3)
            return n

        return h()

    assert g().value == 3, "failed to store NonLocal in nested function"



# Generated at 2022-06-21 21:58:57.017181
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    non = NonLocal(10)
    assert non.value == 10



# Generated at 2022-06-21 21:59:06.762706
# Unit test for function make_lazy
def test_make_lazy():
    import os
    global sys_modules

    sys_module_backup = sys.modules.copy()
    sys_modules = sys.modules

    # Set module path
    module_path = 'os'

    # Check if module is already loaded, then remove if so
    if sys_modules.get(module_path):
        del sys_modules[module_path]

    # Make module lazy
    make_lazy(module_path)

    # Check if module is now in sys.modules
    assert sys_modules.get(module_path)

    # Check if module is lazy instance
    assert isinstance(sys_modules[module_path], _LazyModuleMarker)

    # Check if lazy module returns correct values
    assert sys_modules[module_path].getcwd() == os.getcwd()

    # Reset sys.modules and remove

# Generated at 2022-06-21 21:59:19.814512
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the behavior of make_lazy.
    """
    import os
    import sys
    import django.conf
    import django.core
    import django.contrib.auth
    import django.core.handlers.wsgi

    def reset_modules():
        # The test modules.
        modules = {
            'tests.lazy_test.test_module': 'mod',
            'tests.lazy_test.test_module2': 'mod2',
            'tests.lazy_test.test_module3': 'mod3',
            'tests.lazy_test.test_module4': 'mod4',
        }

        # Delete the test modules.
        for name in sys.modules.keys():
            if name in modules.values():
                del(sys.modules[name])

        # Create

# Generated at 2022-06-21 21:59:31.108063
# Unit test for function make_lazy
def test_make_lazy():
    import numpy
    import inspect

    assert inspect.getfile(numpy) == '/home/me/miniconda/envs/py2/lib/python2.7/site-packages/numpy/__init__.pyc'

    make_lazy('numpy')
    import numpy
    assert inspect.getfile(numpy) == 'ignored'

    import numpy
    assert inspect.getfile(numpy) == '/home/me/miniconda/envs/py2/lib/python2.7/site-packages/numpy/__init__.pyc'
    assert inspect.getfile(numpy) == '/home/me/miniconda/envs/py2/lib/python2.7/site-packages/numpy/__init__.pyc'

# Generated at 2022-06-21 21:59:41.097905
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import types

    mod_name = 'testing.lazy_import.lazy_import'

    # we create a module, which we won't actually load, until a member
    # is accessed
    make_lazy(mod_name)
    # make sure this module is not loaded already
    assert mod_name not in sys.modules
    # but we should have a placeholder module
    lazy_import = sys.modules[mod_name]
    assert isinstance(lazy_import, types.ModuleType)
    # when we access a member, we load the module, and it should have
    # the attribute
    assert lazy_import.__name__ == mod_name
    assert mod_name in sys.modules
    # now, we can actually use the module
    assert NonLocal is lazy_import.NonLocal


# Generated at 2022-06-21 21:59:46.799488
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 21:59:58.196170
# Unit test for function make_lazy
def test_make_lazy():
    """
    If tests pass we will see no output. If a test fails,
    we will see an AssertionError with a Stacktrace.
    """
    def get_module_depth(module):
        # Finds the depth of the module in the recursive import tree.
        # If the module has no recursive imports, return -1
        depth = -1
        for mod in sys.modules.values():
            if isinstance(mod, ModuleType):
                if module in mod.__dict__.values():
                    depth += 1
        return depth

    def find_module(module_name):
        for mod in sys.modules.values():
            if mod.__name__ == module_name:
                return mod
        return None

    # Tests that when a lazy module's attribute is accessed,
    # the module is properly imported.

# Generated at 2022-06-21 22:00:01.475113
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazymodule = _LazyModuleMarker()
    assert isinstance(lazymodule, _LazyModuleMarker), \
           "Failure to create instance of class _LazyModuleMarker"


# Generated at 2022-06-21 22:00:03.027820
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-21 22:00:05.425436
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    myclass = _LazyModuleMarker()
    assert isinstance(myclass, _LazyModuleMarker)

# Generated at 2022-06-21 22:00:07.726159
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This is a test for the constructor for class _LazyModuleMarker
    """
    module = _LazyModuleMarker()
    return module


# Generated at 2022-06-21 22:00:10.478335
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_nonlocal = NonLocal(None)
    assert my_nonlocal.value == None
    my_nonlocal.value = 1
    assert my_nonlocal.value == 1
    my_nonlocal.value = None
    assert my_nonlocal.value == None


# Generated at 2022-06-21 22:00:15.358381
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(None)
    assert non_local.value == None

# Generated at 2022-06-21 22:00:22.835933
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests function make_lazy.
    """
    # pylint: disable=global-statement
    global test_module
    make_lazy('lazy_module.test_module')
    import lazy_module.test_module as test_module

    assert isinstance(test_module, _LazyModuleMarker)
    assert not test_module.imported
    assert hasattr(test_module, 'lazy_module_variable')
    assert test_module.imported



# Generated at 2022-06-21 22:00:26.055987
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(0)
    assert value.value == 0
    value.value = 1
    assert value.value == 1



# Generated at 2022-06-21 22:00:31.457310
# Unit test for function make_lazy
def test_make_lazy():
    import module_under_test
    assert isinstance(module_under_test, _LazyModuleMarker)
    assert module_under_test.attr == 'attr'
    assert hasattr(module_under_test, 'another_attr')
    assert module_under_test.another_attr == 'another_attr'

# Generated at 2022-06-21 22:00:42.384908
# Unit test for function make_lazy
def test_make_lazy():

    # Test that the function can be imported
    make_lazy("test_make_lazy_function")

    # Change value of m to an object
    m = "test_make_lazy_function"

    # Test that module is lazily imported
    assert m == "test_make_lazy_function"
    assert isinstance(sys_modules[m], _LazyModuleMarker)
    assert isinstance(sys_modules[m], ModuleType)
    assert isinstance(sys_modules[m], _LazyModuleMarker)
    assert not isinstance(sys_modules[m], ModuleType)

    # Test that isinstance() works as expected (only checks its most-derived base class)
    assert isinstance(sys_modules[m], _LazyModuleMarker)

    # Test that calling an attribute on the module pulls it out of sys

# Generated at 2022-06-21 22:00:46.364561
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    foo = _LazyModuleMarker()
    assert foo.__class__.__name__ == "_LazyModuleMarker"
    assert foo.__class__.__module__ == "lazy_imports.lazy"


# Generated at 2022-06-21 22:00:48.537231
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        nonlocal_var = NonLocal(None)
    except:
        return False
    return True


# Generated at 2022-06-21 22:00:54.566876
# Unit test for function make_lazy
def test_make_lazy():
    def inner():
        import sys
        make_lazy('sys')
        assert isinstance(sys, _LazyModuleMarker)
        assert hasattr(sys, 'version_info')

    def inner2():
        import sys
        make_lazy('sys')
        version_info = sys.version_info
        assert isinstance(sys, ModuleType)
        assert isinstance(version_info, tuple)

    inner()
    inner2()

# Generated at 2022-06-21 22:01:01.253456
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test if NonLocal() can be used to simulate nonlocal keyword in Python 2
    """
    def outer_func():
        """
        Outer Function
        """

        def inner_func():
            """
            Inner Function
            """
            # NonLocal instance used as a nonlocal variable
            inner_nlocal = NonLocal(0)
            inner_nlocal.value = 1
            return inner_nlocal.value

        return inner_func()

    assert(outer_func() == 1)

# Generated at 2022-06-21 22:01:10.824082
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    make_lazy('sys')
    assert 'sys' in sys.modules
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)
    assert isinstance(sys.modules['sys'], types.ModuleType)
    assert not hasattr(sys.modules['sys'], 'modules')
    assert 'modules' not in sys.modules['sys'].__dict__
    assert isinstance(sys.modules, dict)
    assert 'modules' in sys.modules['sys'].__dict__
    assert 'sys' in sys.modules['sys'].modules
    assert isinstance(sys.modules['sys'].modules, dict)

# Generated at 2022-06-21 22:01:18.111686
# Unit test for constructor of class NonLocal
def test_NonLocal():
    print("Test initialization of class NonLocal")
    a = NonLocal(1)
    assert a.value == 1
    return True


# Generated at 2022-06-21 22:01:22.136561
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure we are able to import modules after a module was made lazy
    make_lazy(mod_path)
    __import__(mod_path)

# Generated at 2022-06-21 22:01:24.017119
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    assert isinstance(lm, _LazyModuleMarker)


# Generated at 2022-06-21 22:01:36.173523
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('test_lazy_module', None)
    sys.modules.pop('lazy_module', None)

    import test_lazy_module
    reload(test_lazy_module)
    assert 'LAZY' in dir(test_lazy_module)

    make_lazy('lazy_module')
    import lazy_module
    assert not hasattr(lazy_module, 'lazy_module')
    lazy_module.lazy_module
    assert 'lazy_module' in dir(lazy_module)
    assert isinstance(lazy_module, _LazyModuleMarker)

    assert test_lazy_module.return_lazy_module() is lazy_module
    assert test_lazy_module.return_lazy_module_import() is lazy_module

# Generated at 2022-06-21 22:01:39.771239
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-21 22:01:42.557728
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(1)
    nonlocal_var.value = 2
    assert nonlocal_var.value == 2


# Generated at 2022-06-21 22:01:54.782211
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test `make_lazy`.
    """
    make_lazy('os')

    # Test __mro__
    assert isinstance(os, ModuleType) is True, (
        "Expected isinstance(os, ModuleType) to be True. "
        "Since os is a lazy module, __mro__ should be overidden to "
        "trick this isinstance check"
    )
    assert isinstance(os, os.__class__) is True, (
        "Expected isinstance(os, os.__class__) to be False."
        "Since os is a lazy module, __mro__ should be overidden to "
        "trick this isinstance check"
    )

    # Test that nothing was imported yet

# Generated at 2022-06-21 22:01:59.922317
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the functionality of make_lazy
    """
    def assert_not_in_module_cache(module_name):
        """
        Checks if a module is not in the sys.modules cache.
        """
        assert module_name in sys.modules
        cached_module = sys.modules[module_name]
        assert isinstance(cached_module, _LazyModuleMarker)
        assert not hasattr(cached_module, '__file__')
        assert not hasattr(cached_module, '__loader__')
        assert not hasattr(cached_module, '__name__')

    def assert_in_module_cache(module_name):
        """
        Checks if a module is in the sys.modules cache.
        """
        assert module_name in sys.modules

# Generated at 2022-06-21 22:02:00.569333
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass

# Generated at 2022-06-21 22:02:03.201361
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(None)
    value.value = 'foo'
    assert value.value == 'foo'



# Generated at 2022-06-21 22:02:09.647459
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-21 22:02:10.552913
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(1)
    assert i.value == 1


# Generated at 2022-06-21 22:02:15.478402
# Unit test for constructor of class NonLocal
def test_NonLocal():
    @make_lazy('pandas')
    def function(a):
        return a
    function_2 = function
    assert function is function_2



# Generated at 2022-06-21 22:02:17.579405
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NonLocal(1)


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:02:21.668642
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from unittest import TestCase
    class Test(TestCase):
        def test_NonLocal(self):
            x = NonLocal(4)
            assert x.value == 4
    Test().test_NonLocal()


# Generated at 2022-06-21 22:02:23.140683
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-21 22:02:26.199148
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    sys.path.append("..")
    import lazy_module
    lazy_module.make_lazy("the_lazy_module")
    assert isinstance(the_lazy_module, _LazyModuleMarker)


# Generated at 2022-06-21 22:02:28.153516
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal("value")
    assert non_local.value == "value"


# Generated at 2022-06-21 22:02:37.999795
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import pandas.tseries.frequencies
    assert isinstance(pandas.tseries, _LazyModuleMarker)
    assert pandas.tseries.frequencies.has_duplicated is not None


# Ugly hack to make sure the above module is processed and then this
# is only included in the coverage report if the module was lazy.
for mod in ((
    'pandas.tseries.frequencies',
    # 'pandas.io.sas.saslib',
    # 'pandas.io.clipboard',
    # 'pandas.io.wb',
    # 'pandas.io.formats.printing',
)):
    if sys.modules.get(mod, None) is None:
        continue

# Generated at 2022-06-21 22:02:40.470580
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(4)
    assert(nl.value == 4)

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:03:01.590096
# Unit test for function make_lazy
def test_make_lazy():
    import timeit

    # Original time taken for import
    original_time = timeit.timeit('import faker',
                                  number=1,
                                  setup='import pkg_resources')

    # Function to get time taken for import of faker
    def get_time(module_path):
        import sys
        import timeit
        # Returns time taken in importing the module
        return timeit.timeit('import %s' % module_path,
                             number=1,
                             setup='import pkg_resources',
                             globals=sys.modules)

    module_path = 'faker'
    make_lazy(module_path)
    time_after_lazy_import = get_time(module_path)
    assert time_after_lazy_import < original_time
    import faker
    time_

# Generated at 2022-06-21 22:03:02.604473
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    a.value = 2
    assert a.value == 2



# Generated at 2022-06-21 22:03:11.461520
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('lazy_module')
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

    x = sys.modules['lazy_module']
    x.LazyModule.__mro__()
    x.non_existant_attr
    x.__mro__()

    assert 'lazy_module' in sys.modules
    assert isinstance(sys.modules['lazy_module'], ModuleType)

    del sys.modules['lazy_module']
# End unit test for function make_lazy


try:
    make_lazy(__name__ + '.py3_compat')
except NameError:
    # This file is being imported directly, so don't make ourself lazy
    pass

# Generated at 2022-06-21 22:03:20.133186
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import tempfile
    import shutil
    import os

    def get_module_path(mod):
        modfile = mod.__file__
        if modfile.endswith('.pyc'):
            modfile = modfile[:-1]
        return os.path.splitext(modfile)[0].replace(os.sep, '.')

    def get_lazy_module_path(mod):
        mod_name = mod.__name__
        return '%s.%s' % (mod_name, mod_name)

    def get_module(mod):
        mod_name = mod.__name__
        return __import__(mod_name, fromlist=[mod_name])


# Generated at 2022-06-21 22:03:22.006000
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker == _LazyModuleMarker()


# Generated at 2022-06-21 22:03:23.503602
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker().__mro__() == (_LazyModuleMarker, object)



# Generated at 2022-06-21 22:03:27.477751
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    mark = _LazyModuleMarker()
    assert mod is not None
    assert mark is not None


# Generated at 2022-06-21 22:03:28.459632
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:03:32.271974
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl_obj = NonLocal(None)
    assert nl_obj.value == None
    nl_obj.value = "Hello Person!"
    assert nl_obj.value == "Hello Person!"

# Generated at 2022-06-21 22:03:41.243468
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_equal
    from unittest import main

    mod = _LazyModuleMarker()
    assert_equal(type(mod), _LazyModuleMarker)
    assert_equal(isinstance(mod, _LazyModuleMarker), True)
    assert_equal(isinstance(mod, ModuleType), False)
    assert_equal(isinstance(mod, type), True)

    mod = ModuleType('mod')
    assert_equal(type(mod), ModuleType)
    assert_equal(isinstance(mod, _LazyModuleMarker), False)
    assert_equal(isinstance(mod, ModuleType), True)
    assert_equal(isinstance(mod, type), True)


# Generated at 2022-06-21 22:04:02.193034
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from pympler import asizeof
    a = NonLocal(10)
    assert asizeof.asizeof(a) == 32
    assert a.value == 10
    a.value = 20
    assert a.value == 20


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:04:13.972034
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os.path
    import itertools

    sys.modules['os.path'] = None

    make_lazy('os.path')

    # This import should not be imported, but it should look
    # like it is.
    import os.path as op

    assert op is sys.modules['os.path']
    assert isinstance(op, _LazyModuleMarker)
    assert not isinstance(op, ModuleType)

    if sys.version_info >= (3, 0):
        for _ in itertools.starmap(getattr, itertools.product([op], dir(op))):
            pass
    else:
        for _ in itertools.starmap(getattr, itertools.product([op], dir(op)), {}):
            pass


# Generated at 2022-06-21 22:04:16.273166
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Make sure that we can create an instance of class _LazyModuleMarker
    """
    _LazyModuleMarker()


# Generated at 2022-06-21 22:04:17.869473
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    token = _LazyModuleMarker()
    return token


# Generated at 2022-06-21 22:04:26.753937
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import tests.lazy_module
    import tests.lazy_module2
    module_path = 'tests.lazy_module'
    make_lazy(module_path)
    assert sys.modules['tests.lazy_module'] is not None
    assert sys.modules['tests.lazy_module2'] is not None
    if sys.version_info[0] <= 2:
        assert isinstance(sys.modules['tests.lazy_module'], _LazyModuleMarker)
    else:
        assert isinstance(sys.modules['tests.lazy_module'],
                          (tests.lazy_module.__class__, _LazyModuleMarker))
    assert sys.modules['tests.lazy_module2'] == tests.lazy_module2

# Generated at 2022-06-21 22:04:33.383908
# Unit test for function make_lazy
def test_make_lazy():
    test_lazy_module = 'test_lazy_module'
    module_value = 'this is not a real module'
    module_path = 'weird_place_for_a_module'

    module_attrs = {'__doc__': None,
                    '__file__': module_path,
                    '__name__': test_lazy_module,
                    '__package__': None,
                    '__path__': [],
                    'test_attr': module_value}
    sys.modules[test_lazy_module] = module_attrs

    non_lazy_path = 'this.is.a.normal.module'
    non_lazy_module = 'module_not_lazy'
    sys.modules[non_lazy_path] = 'Non Lazy Module'

# Generated at 2022-06-21 22:04:41.176110
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure that the function make_lazy works as expected.
    """
    assert sys.modules['test_module'] is None
    make_lazy('test_module')
    assert sys.modules['test_module'] is not None
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    # test that a call to getattr works as expected
    assert sys.modules['test_module'].test_attr == 'test_attr'
    assert sys.modules['test_module'].test_attr == 'test_attr'

# Generated at 2022-06-21 22:04:42.887400
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert type(test_marker) == _LazyModuleMarker


# Generated at 2022-06-21 22:04:44.682150
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert(x.value is None)
    x.value = 1
    assert(x.value == 1)


# Generated at 2022-06-21 22:04:47.931215
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_obj = _LazyModuleMarker()
    assert isinstance(test_obj, _LazyModuleMarker)



# Generated at 2022-06-21 22:05:30.456631
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)



# Generated at 2022-06-21 22:05:35.810850
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os
    import sys

    assert sys.modules["os"] != os

    make_lazy("os")
    assert sys.modules["os"] != os

# Generated at 2022-06-21 22:05:36.679591
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NonLocal('1')



# Generated at 2022-06-21 22:05:38.676415
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5
    a.value = 10
    assert a.value == 10



# Generated at 2022-06-21 22:05:41.265963
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__ == "_LazyModuleMarker", "_LazyModuleMarker.__name__ should be '_LazyModuleMarker' but is " + _LazyModuleMarker.__name__

test__LazyModuleMarker()


# Generated at 2022-06-21 22:05:48.518176
# Unit test for function make_lazy
def test_make_lazy():
    old_module = sys.modules.copy()

# Generated at 2022-06-21 22:05:51.854979
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, _LazyModuleMarker)
    assert not isinstance(lazy_module_marker, ModuleType)


# Generated at 2022-06-21 22:05:52.514191
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None

# Generated at 2022-06-21 22:05:58.276522
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import ok_
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)
    marker = _LazyModuleMarker()
    marker.__dict__['test'] = 'test'
    ok_(isinstance(marker, _LazyModuleMarker))
    ok_(marker.test == 'test')
    del marker.test
    print(marker.test)
    ok_(marker.test == 'test')
    print(marker.__dict__)

# Generated at 2022-06-21 22:06:03.866569
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except:
        pass
    # check if _LazyModuleMarker() has its data members
    assert hasattr(_LazyModuleMarker(), '__slots__')
    assert _LazyModuleMarker.__slots__ == []
    # check if _LazyModuleMarker() is a type
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)