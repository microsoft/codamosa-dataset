

# Generated at 2022-06-21 21:57:18.463130
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """Test the constructor of the class NonLocal"""
    st = NonLocal(None)
    assert st.value is None
    st = NonLocal(5)
    assert st.value == 5
    st = NonLocal("this is a test")
    assert st.value == "this is a test"



# Generated at 2022-06-21 21:57:24.522977
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__doc__ == 'Simulates nonlocal keyword in Python 2'
    assert NonLocal.__init__.__doc__ == 'Initialize self.'
    assert 'NonLocal' == NonLocal(1).__class__.__name__
    assert 1 == NonLocal(1).value


# Generated at 2022-06-21 21:57:29.184037
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the constructor of class _LazyModuleMarker
    """
    # pylint: disable=unused-variable
    with _LazyModuleMarker():
        pass

# Generated at 2022-06-21 21:57:32.585755
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1, "NonLocal.value should be 1"


# Generated at 2022-06-21 21:57:43.340076
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure make_lazy works as expected.
    """
    import os
    import tempfile
    import shutil


# Generated at 2022-06-21 21:57:50.766631
# Unit test for function make_lazy
def test_make_lazy():
    import sys, types
    # Make sure it exists in the sys.modules
    assert 'async_lazy_import' in sys.modules
    # Make sure it is not the module.
    assert not isinstance(sys.modules['async_lazy_import'], types.ModuleType)
    # Make sure the imported module is there
    assert 'async_lazy_import.async_lazy_import' in sys.modules
    # Make sure it is the module.
    assert isinstance(sys.modules['async_lazy_import.async_lazy_import'], types.ModuleType)

# Make this module lazy.
make_lazy('async_lazy_import')

# Generated at 2022-06-21 21:58:00.141713
# Unit test for function make_lazy
def test_make_lazy():
    if getattr(sys, '_called_from_test', False):
        # We are being called from our own test suite, to
        # help test the make_lazy function.
        def test_package():
            """
            A test module that we will import 'lazily'
            """
            test_module = NonLocal(None)

            class LazyTestModule(_LazyModuleMarker):
                """
                A standin for a module to prevent it from being imported
                """
                def __mro__(self):
                    """
                    Override the __mro__ to fool `isinstance`.
                    """
                    return (LazyTestModule, ModuleType)

                def __getattribute__(self, attr):
                    """
                    Override __getattribute__ to hide the implementation details.
                    """

# Generated at 2022-06-21 21:58:09.352909
# Unit test for function make_lazy
def test_make_lazy():
    """
    This is a unit test of the make_lazy function.
    """
    # Make sure we clean up the sys.modules cache
    import module_util
    sys.modules['module_util'] = None
    make_lazy('module_util')

    # Make sure we can load a module that does not exist
    import_exception = False
    try:
        import no_exist
    except ImportError:
        import_exception = True
    assert import_exception is True

    # Make sure we can load a module that does not exist
    import_exception = False
    try:
        from no_exist import test_v
    except ImportError:
        import_exception = True
    assert import_exception is True

    # Make sure we can load a module that does not exist
    import_exception = False


# Generated at 2022-06-21 21:58:11.748195
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for _LazyModuleMarker constructor
    """
    assert(LazyModuleMarker
           == 'from lazy_import import _LazyModuleMarker\n'
           + 'LazyModuleMarker = _LazyModuleMarker\n')


# Generated at 2022-06-21 21:58:13.688067
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('value')
    assert(nl.value == 'value')


# Generated at 2022-06-21 21:58:17.260237
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local_inst = NonLocal(1)
    assert non_local_inst.value == 1

# Generated at 2022-06-21 21:58:24.502255
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    # Test setup
    module_path = "test_module"
    sys.modules[module_path] = None

    for attr in ["foo", "bar", "baz", "qux"]:
        make_lazy(module_path)
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)

        # Trigger import
        assert hasattr(sys.modules[module_path], attr)
        assert isinstance(sys.modules[module_path], ModuleType)

# Generated at 2022-06-21 21:58:31.149338
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test constructor of class NonLocal
    """
    a = NonLocal(object)
    assert(not hasattr(a, '__slots__'))
    a.value = "Hello"
    assert(hasattr(a, 'value'))
    assert(a.value == "Hello")
    del a.value
    assert(not hasattr(a, 'value'))
    try:
        a.value = "Hello"
    except Exception as e:
        assert(e.message == '\'value\' is not defined')



# Generated at 2022-06-21 21:58:42.108654
# Unit test for function make_lazy
def test_make_lazy():
    from .test_lazy_module.lib import lazy

    # First, lazy should not be imported (and hence, not exist in sys_modules)
    assert 'lazy' not in sys.modules

    # Now, import the module and check that it is still not loaded
    import test_lazy_module.lib

    assert 'lazy' in sys.modules
    assert sys.modules['lazy'] is test_lazy_module.lib.lazy

    # Finally, check that the module is not loaded until
    # something is needed from it.

    assert 'lazy' in sys.modules
    assert sys.modules['lazy'] is test_lazy_module.lib.lazy

    # Finally, check that the module is not loaded until
    # something is needed from it.


# Generated at 2022-06-21 21:58:48.658994
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(_LazyModuleMarker, _LazyModuleMarker)

    class BadLazyModule(_LazyModuleMarker):
        """
        The mere fact of inheriting from _LazyModuleMarker
        should not be enough to fool isinstance.
        """
        pass

    assert not isinstance(BadLazyModule(), _LazyModuleMarker)
    assert not isinstance(BadLazyModule, _LazyModuleMarker)


# Generated at 2022-06-21 21:58:50.611991
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 21:58:51.983117
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """

# Generated at 2022-06-21 21:58:56.783853
# Unit test for function make_lazy
def test_make_lazy():
    from modelstore.tests import testing_module

    make_lazy('modelstore.tests.testing_module')
    from modelstore.tests import testing_module

    assert isinstance(testing_module, _LazyModuleMarker)
    assert hasattr(testing_module, '__name__')
    assert hasattr(testing_module, '__file__')
    assert hasattr(testing_module, '__doc__')
    assert hasattr(testing_module, '__path__')
    assert hasattr(testing_module, '__package__')
    assert hasattr(testing_module, '__spec__')
    assert hasattr(testing_module, 'test_value')
    assert isinstance(testing_module.test_value, str)

    # check type
    assert isinstance(testing_module, ModuleType)

# Generated at 2022-06-21 21:58:58.284148
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import pocoo.ext
    assert isinstance(pocoo.ext, _LazyModuleMarker)



# Generated at 2022-06-21 21:59:07.970788
# Unit test for function make_lazy
def test_make_lazy():
    sys._sys_modules_before_test_make_lazy = sys.modules.copy()
    sys.modules.clear()

    make_lazy("test_module")
    assert ("test_module" in sys.modules)

    test_module = sys.modules["test_module"]

    # check that it is a module
    assert (isinstance(test_module, ModuleType))
    assert (isinstance(test_module, _LazyModuleMarker))
    assert (hasattr(test_module, "__getattribute__"))
    assert (hasattr(test_module, "__mro__"))

    # make sure it raises an attribute error
    try:
        test_module.member  # pylint: disable=pointless-statement
    except AttributeError:
        pass
    else:
        assert (False)

    #

# Generated at 2022-06-21 21:59:20.482729
# Unit test for function make_lazy
def test_make_lazy():
    test_module = 'test_make_lazy_module'
    test_module_path = '.'.join([__name__, test_module])
    make_lazy(test_module_path)

    import test_make_lazy_module

    assert isinstance(test_make_lazy_module, _LazyModuleMarker)
    try:
        result = test_make_lazy_module.value
    except ImportError:
        # We want this to raise an import error
        pass
    else:
        raise Exception('Import error was not raised: %s' % result)

    # Now we import the module to make sure the import works
    import test_make_lazy_module

    assert test_make_lazy_module.value == 1



# Generated at 2022-06-21 21:59:23.457888
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert type(test_marker) == _LazyModuleMarker


# Generated at 2022-06-21 21:59:25.407090
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_class = NonLocal(value=3)
    assert test_class.value == 3


# Generated at 2022-06-21 21:59:27.695991
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod,_LazyModuleMarker)


# Generated at 2022-06-21 21:59:33.363418
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy() can make a module lazy
    """
    import tempfile

    lazy_test_path = tempfile.mkdtemp()

    # setup the code

# Generated at 2022-06-21 21:59:34.673170
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-21 21:59:37.690132
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    

# Generated at 2022-06-21 21:59:39.574234
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None

# Generated at 2022-06-21 21:59:48.536838
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import types

    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'
    assert _LazyModuleMarker.__doc__  is not None
    assert _LazyModuleMarker.__module__ == __name__
    assert _LazyModuleMarker.__slots__ == []
    assert _LazyModuleMarker.__mro__ == (object,)
    assert sys.getrefcount(_LazyModuleMarker) == 2
    assert type(_LazyModuleMarker) is types.TypeType


# Generated at 2022-06-21 21:59:52.937982
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('fakemodule')
    import fakemodule
    assert isinstance(fakemodule, _LazyModuleMarker)
    assert isinstance(fakemodule, ModuleType)

    if sys.version_info < (3,):
        assert isinstance(fakemodule, types.ModuleType)

    try:
        fakemodule.__name__
    except AttributeError:
        pass
    else:
        assert False, 'Make_lazy didn\'t prevent loading of module'

# Generated at 2022-06-21 22:00:05.436689
# Unit test for function make_lazy
def test_make_lazy():
    """
    test_make_lazy
    """
    def _test():
        make_lazy("my_made_up_module")
        make_lazy("my_made_up_module.foo")
        make_lazy("my_made_up_module.foo.bar")

        # This normally fails because the module is not loaded
        assert isinstance(sys.modules["my_made_up_module"].foo.bar, ModuleType)

    # run the test
    _test()

    # Now run it again to make sure that the modules were lazily loaded
    # and then "reloaded" so they will be normal modules.
    _test()

    # This normally fails because the module was not loaded.
    assert isinstance(sys.modules["my_made_up_module"].foo.bar, ModuleType)

# Generated at 2022-06-21 22:00:08.911770
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonLocal = NonLocal(5)
    assert (nonLocal.value == 5)

if __name__ == '__main__':
    #test_NonLocal()
    make_lazy("test")
    sys.modules['test'].__getattribute__('abc')

# Generated at 2022-06-21 22:00:18.655555
# Unit test for function make_lazy
def test_make_lazy():
    for i in range(2):
        try:
            import Z.A
        except:
            pass

        make_lazy('Z.A')
        assert 'Z.A' in sys.modules
        assert isinstance(sys.modules['Z.A'], _LazyModuleMarker)

        try:
            import Z.A
        except:
            pass

        try:
            import Z.A as A
        except:
            pass

        assert 'Z.A' in sys.modules
        assert isinstance(sys.modules['Z.A'], _LazyModuleMarker)

        try:
            from Z.A import b
        except:
            pass

        assert 'Z.A' in sys.modules
        assert isinstance(sys.modules['Z.A'], _LazyModuleMarker)


# Generated at 2022-06-21 22:00:29.314375
# Unit test for function make_lazy
def test_make_lazy():
    test_module_name = 'test_module'

    sys_modules = sys.modules

    def validate(x):
        if isinstance(x, NonLocal):
            return True
        assert x == 42
        return True

    class TestModule(NonLocal):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(None)

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the NonLocal implementation
            details.
            """
            return validate

    sys_modules[test_module_name] = TestModule()

    from_module = __import__(test_module_name)
    assert from_module.validate == validate

    make_lazy(test_module_name)


# Generated at 2022-06-21 22:00:31.838157
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    assert 'lazy_test' not in sys.modules

    make_lazy('lazy_test')

    assert isinstance(sys.modules['lazy_test'], _LazyModuleMarker)
    assert 'lazy_test' not in sys.modules

    # make sure we can access the loaded lazy module
    assert sys.modules['lazy_test'].foo == 1
    assert 'lazy_test' in sys.modules



# Generated at 2022-06-21 22:00:33.152720
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()


# Generated at 2022-06-21 22:00:35.358431
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_non_local = NonLocal(8)
    assert my_non_local.value == 8


# Generated at 2022-06-21 22:00:36.538316
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(object(), _LazyModuleMarker)
    

# Generated at 2022-06-21 22:00:38.516665
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert(isinstance(n, NonLocal))



# Generated at 2022-06-21 22:00:39.889763
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-21 22:00:48.173887
# Unit test for function make_lazy
def test_make_lazy():
    foo = sys.modules['foo']
    assert isinstance(foo, _LazyModuleMarker)
    assert not hasattr(foo, 'bar')
    assert foo.bar == 'baz'
    assert hasattr(foo, 'bar')
    assert not isinstance(foo, _LazyModuleMarker)

make_lazy('foo')


# Generated at 2022-06-21 22:00:58.593968
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    import imp

    # Create a module in a temporary location
    test_module_name = 'test_module'
    test_module_contents = 'test = 42'
    test_module_path = os.path.join(tempfile.gettempdir(), 'test_module.py')
    with open(test_module_path, 'w') as test_module_file:
        test_module_file.write(test_module_contents)

    # Ensure the module can be imported directly
    test_module = imp.load_source(test_module_name, test_module_path)
    assert test_module.test == 42

    # Make the module lazy, and ensure it still works
    make_lazy(test_module_name)
    assert test_module.test == 42

    # Set

# Generated at 2022-06-21 22:01:00.717683
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test 1: test that value is initialized to input value
    assert NonLocal(1).value == 1


# Generated at 2022-06-21 22:01:05.829264
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    print("Is _LazyModuleMarker instance? ", isinstance(lazy_module_marker, _LazyModuleMarker))



# Generated at 2022-06-21 22:01:10.764265
# Unit test for constructor of class NonLocal
def test_NonLocal():
    z_obj = NonLocal(10)
    assert isinstance(z_obj, NonLocal)
    assert z_obj.value == 10
    z_obj.value += 1
    assert z_obj.value == 11


# Generated at 2022-06-21 22:01:20.377281
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create _LazyModuleMarker object
    a = _LazyModuleMarker()
    assert isinstance(a, object)
    # Unit test for __mro__()
    mro_ = a.__mro__()
    assert mro_ == (_LazyModuleMarker, ModuleType)

if __name__ == '__main__':
    # Unit tests
    test__LazyModuleMarker()
    print('Test complete')

# Generated at 2022-06-21 22:01:26.454167
# Unit test for function make_lazy
def test_make_lazy():
    from nose.tools import assert_false, assert_true
    orig_dir = sys.path
    sys.path += ['/tmp']

    try:
        make_lazy('test_module')
        test_mod = sys.modules['test_module']
        assert_false('foo' in test_mod.__dict__)
        assert_true(isinstance(test_mod, _LazyModuleMarker))
        assert_true('foo' in test_mod.__dict__)
    finally:
        del sys.modules['test_module']
        sys.path = orig_dir



# Generated at 2022-06-21 22:01:31.344424
# Unit test for function make_lazy
def test_make_lazy():
    class Test(object):
        def __init__(self, value=1):
            self.value = value

    test = Test()
    assert isinstance(test, Test)

    make_lazy('test_make_lazy')

    test_2 = Test()
    assert not isinstance(test_2, Test)

# Generated at 2022-06-21 22:01:33.533468
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-21 22:01:35.741606
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert(n.value == None)
    n.value = 1
    assert(n.value == 1)

# Generated at 2022-06-21 22:01:44.279419
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(None).value is None
    assert NonLocal(0).value == 0
    assert NonLocal('a').value == 'a'
    assert NonLocal(False).value is False
    assert NonLocal(True).value is True



# Generated at 2022-06-21 22:01:49.375579
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    import shutil
    import sys

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 22:01:51.343070
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test.test_lazy')
    import test.test_lazy as test

    assert isins

# Generated at 2022-06-21 22:01:54.302478
# Unit test for function make_lazy
def test_make_lazy():
    import abc
    make_lazy('abc')
    print(abc.__name__)

# Generated at 2022-06-21 22:01:55.253894
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker


# Generated at 2022-06-21 22:01:56.360639
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test for the constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker() is not None

# Generated at 2022-06-21 22:02:07.038849
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys_modules = sys.modules  # cache in the locals

    module = NonLocal(None)

    # Test function of __mro__, if the return value is a tuple of LazyModule and ModuleType
    def test_getmro(self):
        return (type(self), ModuleType)

    # Test function of __getattribute__, if the module is not None, return the value of attr
    def test_getattribute(self, attr):
        if module.value is None:
            del sys_modules[module_path]
            module.value = __import__(module_path)
            sys_modules[module_path] = __import__(module_path)
        return getattr(module.value, attr)

    # Same as before, we are using class LazyModule to check the functions of __mro__ and __get

# Generated at 2022-06-21 22:02:17.959335
# Unit test for function make_lazy
def test_make_lazy():
    module1_called = [0]
    module2_called = [0]

    class DummyModule(object):
        def __init__(self, i):
            self.i = i

        def test_method(self):
            return True

    def importer():
        dummy_module1 = DummyModule(1)
        dummy_module2 = DummyModule(2)

        module1_called[0] += 1
        module2_called[0] += 1

        return {'module1': dummy_module1,
                'module2': dummy_module2}

    # Monkey-patch __import__ to ensure we do not actually
    # import anything
    old_import = __import__
    __import__ = importer

    # We should not have imported any modules at this point
    assert module1_called[0] == 0

# Generated at 2022-06-21 22:02:27.796061
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run tests to ensure that make_lazy works as expected.
    """
    def check_modulepath_not_imported(module_path):
        """
        Ensure a module is not imported.
        """
        if module_path in sys.modules:
            raise Exception('Module is in sys.modules, but expected not.')

        try:
            __import__(module_path)
        except ImportError:
            pass
        else:
            raise Exception('Module was successfully imported, expected not.')

    def check_modulepath_is_imported(module_path):
        """
        Ensure a module is imported.
        """
        if module_path not in sys.modules:
            raise Exception('Module is not in sys.modules, but expected it.')


# Generated at 2022-06-21 22:02:34.654741
# Unit test for function make_lazy
def test_make_lazy():
    # Test make_lazy without loading module
    make_lazy('unittest')
    assert isinstance(sys.modules['unittest'], _LazyModuleMarker) is True
    assert 'unittest' not in sys.modules

    # Test make_lazy with loading module
    make_lazy('unittest')
    assert isinstance(sys.modules['unittest'], _LazyModuleMarker) is True
    assert 'unittest' in sys.modules

# Generated at 2022-06-21 22:02:45.170713
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Initialize the NonLocal class with a value
    n = NonLocal(5)

    # assert the value of our class attribute 'value'
    assert n.value is 5

# Generated at 2022-06-21 22:02:47.661946
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class MyNonLocal(NonLocal):
        pass

    test_nonlocal = MyNonLocal(1)

    assert isinstance(test_nonlocal.value, int)


# Generated at 2022-06-21 22:03:01.543007
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    assert 'tests.utils.test_lazy' in sys.modules

    del sys.modules['tests.utils.test_lazy']
    assert 'tests.utils.test_lazy' not in sys.modules
    assert 'test_lazy' not in sys.modules

    make_lazy('tests.utils.test_lazy')

    assert isinstance(sys.modules['tests.utils.test_lazy'], _LazyModuleMarker)
    assert sys.modules['tests.utils.test_lazy'].__name__ == 'tests.utils.test_lazy'
    assert 'test_lazy' not in sys.modules
    assert 'tests.utils.test_lazy' in sys.modules

    from tests.utils import test_lazy

    assert isinstance(test_lazy, ModuleType)


# Generated at 2022-06-21 22:03:03.937373
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = [0]
    x = NonLocal(a)
    assert a == x.value

    a[0] = 1
    assert a == x.value



# Generated at 2022-06-21 22:03:06.270293
# Unit test for constructor of class NonLocal
def test_NonLocal():
    testObj = NonLocal('value')
    assert testObj.value == 'value', \
           'NonLocal constructor not returning correct value'


# Generated at 2022-06-21 22:03:09.549405
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_test_string = "Hello world"

    nl = NonLocal(my_test_string)

    assert nl.value == my_test_string
    assert nl.value is my_test_string



# Generated at 2022-06-21 22:03:19.512122
# Unit test for function make_lazy
def test_make_lazy():
    """Unit test for function make_lazy."""
    import sys

    # old modules should not be any different
    mod = sys.modules['sys']
    assert(not isinstance(mod, _LazyModuleMarker))

    make_lazy('test.test_make_lazy.tmp')
    assert('test.test_make_lazy.tmp' in sys.modules)
    mod = sys.modules['test.test_make_lazy.tmp']
    assert(isinstance(mod, _LazyModuleMarker))
    with pytest.raises(AttributeError):
        mod.foo

    # we should now be able to access the real module.
    mod = sys.modules['test.test_make_lazy.tmp']
    assert(not isinstance(mod, _LazyModuleMarker))

# Generated at 2022-06-21 22:03:27.460389
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy creates a lazy module that behaves as expected.
    """
    # This module needs to be imported so that it can be put in `sys.modules`
    # under the name being tested.
    import lazytest

    # Make the module lazy.
    make_lazy('lazytest')

    # Import the module, making sure that it *remains* lazy.
    import lazytest
    assert isinstance(lazytest, _LazyModuleMarker)

    # We may have forgotten to add a method.
    def test_type_checks():
        assert type(lazytest) is _LazyModuleMarker
        assert isinstance(lazytest, _LazyModuleMarker)
        assert isinstance(lazytest, ModuleType)

    test_type_checks()

    # Access an attribute on the module

# Generated at 2022-06-21 22:03:38.932050
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make_lazy function.
    """
    import sys
    import tempfile
    import random

    # Create a temporary package
    test_package_name = 'make_lazy_test_package_' + str(random.randint(1, 100000))
    temp_package = tempfile.mkdtemp(suffix="_" + test_package_name)
    sys.path.append(temp_package)
    package_init = open(os.path.join(temp_package, '__init__.py'), 'w')
    package_init.close()

    # Create a module
    test_module_name = 'make_lazy_test_module_' + str(random.randint(1, 100000))

# Generated at 2022-06-21 22:03:40.473637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert isinstance(LazyModuleMarker, _LazyModuleMarker)


# Generated at 2022-06-21 22:04:01.702211
# Unit test for function make_lazy
def test_make_lazy():
    # Test custom import
    sys.modules["my.module"] = _LazyModuleMarker
    make_lazy("my.module")
    assert isinstance(sys.modules["my.module"], _LazyModuleMarker)

    # Test exisitng module
    make_lazy("pysnmp")
    assert isinstance(sys.modules["pysnmp"], _LazyModuleMarker)

# Generated at 2022-06-21 22:04:13.813073
# Unit test for function make_lazy
def test_make_lazy():

    class Class1(object):
        pass

    class Class2(object):
        pass

    # Mark a module as lazy
    import tests.make_lazy_test as lazy_test
    initial_lazy_test_module = sys.modules['tests.make_lazy_test']

    make_lazy('tests.make_lazy_test')

    lazy_test.Class1()
    import tests.make_lazy_test as lazy_test_after_import

    # the module is still marked as lazy
    assert_true(initial_lazy_test_module is sys.modules['tests.make_lazy_test'])
    assert_true(isinstance(sys.modules['tests.make_lazy_test'], _LazyModuleMarker))

    # Trigger module's import by accessing some attribute
    lazy_test_after

# Generated at 2022-06-21 22:04:24.046887
# Unit test for function make_lazy
def test_make_lazy():
    module_path = "tests.test_lazy"

# Generated at 2022-06-21 22:04:31.953826
# Unit test for function make_lazy
def test_make_lazy():
    from nose.tools import assert_equals, assert_raises, assert_true

    assert_raises(ImportError, __import__, 'lazy_tests.module_a')

    # Imports should fail before the lazy module is initialized
    try:
        from lazy_tests.module_a import SuccessClass
        assert_true(False)
    except ImportError:
        pass

    # now make it lazy
    make_lazy('lazy_tests.module_a')
    assert_equals(type(sys.modules['lazy_tests.module_a']), _LazyModuleMarker)
    assert_equals(sys.modules['lazy_tests'], None)

    # The import should now succeed
    from lazy_tests.module_a import SuccessClass
    assert_equals(SuccessClass.magic_number, 5)

# Generated at 2022-06-21 22:04:34.355101
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__ == "_LazyModuleMarker"


# Generated at 2022-06-21 22:04:43.624293
# Unit test for function make_lazy
def test_make_lazy():
    # Test case 1: Python 3
    if sys.version_info >= (3, 0):
        make_lazy("PYTHON3")
        assert isinstance(PYTHON3, _LazyModuleMarker)
        assert PYTHON3.version == 3
        assert not isinstance(PYTHON3, _LazyModuleMarker)

    # Test case 2: Python 2
    else:
        make_lazy("PYTHON2")
        assert isinstance(PYTHON2, _LazyModuleMarker)
        assert PYTHON2.version == 2
        assert not isinstance(PYTHON2, _LazyModuleMarker)

    # Test case 3: Python 2


# Run make_lazy tests
test_make_lazy()

# Generated at 2022-06-21 22:04:47.929934
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(4)
    assert x.value == 4
    x.value = 5
    assert x.value == 5
    x.value = "hello"
    assert x.value == "hello"



# Generated at 2022-06-21 22:04:53.018839
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo')
    assert 'foo' not in sys.modules

    import foo
    assert isinstance(foo, _LazyModuleMarker)
    assert foo.marker == 'bar'
    assert foo.__name__ == 'foo'
    assert 'foo' in sys.modules
    assert type(sys.modules['foo']) == ModuleType

# Generated at 2022-06-21 22:05:01.854336
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run tests to make sure that the make_lazy function is working properly
    """
    import nested_1.mod_a
    assert not isinstance(nested_1.mod_a, _LazyModuleMarker)
    assert "make_lazy_test_mod" not in sys.modules

    import nested_1.mod_b
    assert isinstance(nested_1.mod_b, _LazyModuleMarker)
    assert "make_lazy_test_mod" not in sys.modules

    nested_1.mod_b.foo()
    import make_lazy_test_mod
    assert "make_lazy_test_mod" in sys.modules
    assert not isinstance(make_lazy_test_mod, _LazyModuleMarker)

# Generated at 2022-06-21 22:05:03.399119
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal("Non Local")
    assert n.value == "Non Local"


# Generated at 2022-06-21 22:05:44.575598
# Unit test for function make_lazy
def test_make_lazy():
    assert 'test_make_lazy' not in sys.modules
    make_lazy("sys.modules['test_make_lazy']")
    assert sys.modules['test_make_lazy'] is not None
    assert sys.modules['test_make_lazy'].__name__ == 'test_make_lazy'
    assert 'test_make_lazy' in sys.modules
    del sys.modules['test_make_lazy']
    assert 'test_make_lazy' not in sys.modules
    make_lazy("sys.modules['test_make_lazy']")
    assert sys.modules['test_make_lazy'] is not None
    assert sys.modules['test_make_lazy'].__name__ == 'test_make_lazy'

# Generated at 2022-06-21 22:05:48.612454
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(20)
    assert a.value == 20

    a.value = 30
    assert a.value == 30

# Generated at 2022-06-21 22:05:51.607170
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Dummy(object):
        def __init__(self):
            self.value = 3

    obj = Dummy()
    var = NonLocal(obj)
    assert(var.value is obj)

# Generated at 2022-06-21 22:05:59.530764
# Unit test for constructor of class NonLocal
def test_NonLocal():
    at_level1 = NonLocal(None)
    def level2():
        def level3():
            print("Level3: at_level1.value is", at_level1.value)
            at_level1.value = "level3"
            print("Level3: set at_level1.value as", at_level1.value)
        print("Level2: at_level1.value is", at_level1.value)
        at_level1.value = "level2"
        print("Level2: set at_level1.value as", at_level1.value)
        print("Level2: at_level1.value is", at_level1.value)
        level3()
        print("Level2: at_level1.value is", at_level1.value)
        return

# Generated at 2022-06-21 22:06:00.732764
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()



# Generated at 2022-06-21 22:06:06.334762
# Unit test for function make_lazy
def test_make_lazy():
    import datetime

    try:
        del sys.modules['datetime']
    except:
        pass

    make_lazy('datetime')

    assert isinstance(datetime, _LazyModuleMarker)
    assert not hasattr(datetime, 'date')
    date = datetime.date

    assert sys.modules['datetime'] == datetime.date

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:06:09.644723
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(5)

    assert(nonlocal_value.value == 5)

# Generated at 2022-06-21 22:06:14.781661
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    # Unit test for class _LazyModuleMarker
    assert isinstance(marker, _LazyModuleMarker)
    assert not isinstance(marker, type)


# Generated at 2022-06-21 22:06:23.090219
# Unit test for function make_lazy
def test_make_lazy():
    import os

    if 'os' in sys.modules:
        del sys.modules['os']

    make_lazy('os')
    assert 'os' in sys.modules
    assert isinstance(sys.modules['os'], _LazyModuleMarker)

    # Now, attempt to access an attr.
    # This will cause the module to be imported
    # and it will remove the LazyModule instance from sys.modules.
    assert os.getcwd()  # noqa

# Generated at 2022-06-21 22:06:24.089074
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()