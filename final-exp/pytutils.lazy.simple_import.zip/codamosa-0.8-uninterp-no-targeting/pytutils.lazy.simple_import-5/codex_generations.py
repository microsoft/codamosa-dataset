

# Generated at 2022-06-21 21:57:24.466610
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # check if it's a class
    if issubclass(_LazyModuleMarker, object):
        print('class')
    else:
        print('not class')
    # check if it's a type
    if isinstance(_LazyModuleMarker, type):
        print('type')
    else:
        print('not type')
    # check if it's a superclass
    if issubclass(_LazyModuleMarker, type):
        print('superclass')
    else:
        print('not superclass')
    # check if it's a subclass
    if issubclass(_LazyModuleMarker, ModuleType):
        print('subclass')
    else:
        print('not subclass')


# Generated at 2022-06-21 21:57:33.440487
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy('test')

    # Make sure that we can still import the module
    test = __import__('test')

    # Make sure that isinstance works correctly
    assert isinstance(test, ModuleType)
    assert isinstance(mod, _LazyModuleMarker)
    assert isinstance(mod, ModuleType)

    # Make sure that nothing is imported until needed
    next = make_lazy('test.test')

    # Make sure that the module is still not loaded
    test_test = sys.modules.get('test.test')
    assert test_test is None

    # Now actually use the module
    next.test_test_attribute = True

    # Make sure the module has been loaded
    assert sys.modules['test.test']

# Generated at 2022-06-21 21:57:40.962962
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Create an empty class containing a NonLocal object.
    class NonLocalClass(object):
        __slots__ = ['nonlocal_object']
        def __init__(self):
            self.nonlocal_object = NonLocal('Original Value')
    # Create an object of class NonLocalClass.
    nlc = NonLocalClass()
    # Check that the correct value is printed.
    assert nlc.nonlocal_object.value == 'Original Value'


# Generated at 2022-06-21 21:57:43.056972
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(5)
    assert(nonlocal_obj.value == 5)

# Generated at 2022-06-21 21:57:47.243999
# Unit test for constructor of class NonLocal
def test_NonLocal():
    global_var = 1
    class Test(object):
        def func(self):
            nonlocal_var = NonLocal(1)
            nonlocal_var.value += 1
            global_var = nonlocal_var.value
            return nonlocal_var.value
    test = Test()
    assert test.func() == 2
    assert global_var == 2

# Generated at 2022-06-21 21:57:49.884041
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(None)
    assert nonlocal_.value is None


# Generated at 2022-06-21 21:57:58.194973
# Unit test for function make_lazy
def test_make_lazy():
    module_path = "os.path"

    sys_modules = sys.modules  # cache in the locals
    make_lazy(module_path)

    lazy_module = sys_modules[module_path]

    # assert that it's a module
    assert isinstance(lazy_module, ModuleType)

    # assert that it's not the actual module
    assert lazy_module is not sys.modules["os.path"]

    # assert that it's not a lazy module (we're trying to hide this implementation)
    assert not isinstance(lazy_module, _LazyModuleMarker)
    is_lazy_instance = isinstance(lazy_module, _LazyModuleMarker)

    # assert that attempting to get attributes on the module prevents import
    assert "isdir" not in sys_modules["os.path"].__dict__



# Generated at 2022-06-21 21:58:01.915994
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert inspect.isclass(_LazyModuleMarker)
    assert issubclass(_LazyModuleMarker, (object, ))
    assert _LazyModuleMarker().__class__.__name__ == "_LazyModuleMarker"


# Generated at 2022-06-21 21:58:03.746120
# Unit test for constructor of class NonLocal
def test_NonLocal():

    assert(isinstance(NonLocal(3), NonLocal))
    assert(isinstance(NonLocal("aaa"), NonLocal))

# Generated at 2022-06-21 21:58:04.509974
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3

# Generated at 2022-06-21 21:58:07.342011
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl=NonLocal(1)
    nl.value=3
    assert nl.value==3

# Generated at 2022-06-21 21:58:09.272308
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    t = _LazyModuleMarker()
    msg = "_LazyModuleMarker() should return object"
    assert isinstance(t, object), msg


# Generated at 2022-06-21 21:58:10.517919
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal("test_NonLocal")
    assert obj.value == "test_NonLocal"


# Generated at 2022-06-21 21:58:12.651238
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    assert(isinstance(lm, _LazyModuleMarker))
    try:
        lm.fake_attr1
    except AttributeError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-21 21:58:15.145120
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2

# Generated at 2022-06-21 21:58:21.139818
# Unit test for function make_lazy
def test_make_lazy():
    from datetime import datetime
    make_lazy('datetime')  # No import required, just a function call.
    assert isinstance(datetime, _LazyModuleMarker)
    assert not datetime.datetime.now  # It hasn't been imported yet.
    assert datetime.datetime.today().year  # Imported on use.
    assert datetime.datetime.now  # Imported on use.



# Generated at 2022-06-21 21:58:23.485140
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-21 21:58:25.638501
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()
    print("Unit test for constructor of class _LazyModuleMarker passed!")


# Generated at 2022-06-21 21:58:34.613651
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys_modules = sys.modules  # cache in the locals

    # store our 'instance' data in the closure.
    module = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """

        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (LazyModule, ModuleType)


# Generated at 2022-06-21 21:58:38.090455
# Unit test for function make_lazy
def test_make_lazy():
    import math

    make_lazy('math')

    assert isinstance(math, _LazyModuleMarker)
    assert math.pi == math.pi
    assert math.pi == 3.141592653589793



# Generated at 2022-06-21 21:58:40.568626
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    l = _LazyModuleMarker()
    assert l is not None


# Generated at 2022-06-21 21:58:41.623988
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print('This is a unit test')

# Generated at 2022-06-21 21:58:43.554449
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('val')
    assert nl.value == 'val'


# Generated at 2022-06-21 21:58:45.321559
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Check the class values
    obj = NonLocal(1)
    assert obj.value == 1



# Generated at 2022-06-21 21:58:47.455672
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal(2)
    assert nonlocal_object.value is 2


# Generated at 2022-06-21 21:58:48.919313
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(3)
    print(i.value)


# Generated at 2022-06-21 21:58:52.174361
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = 1
    nonlocal_obj = NonLocal(a)
    assert nonlocal_obj.value == a
    assert nonlocal_obj.__getattribute__("__slots__") == ['value']

# Generated at 2022-06-21 21:58:54.461878
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(2)
    assert n.value == 2
    n.value = 3
    assert n.value == 3


# Generated at 2022-06-21 21:59:02.094695
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test non-local variable
    if sys.version_info[0] < 3:
        result = 99
        def f():
            # Python 2
            no = NonLocal(0)
            def g():
                global result
                result = no.value
                no.value = 10
            g()
        f()
        assert result == 0
        f()
        assert result == 10
    else:
        # Python 3: must use the nonlocal keyword
        result = 99
        def f():
            # Python 3
            no = NonLocal(0)
            def g():
                nonlocal no
                global result
                result = no.value
                no.value = 10
            g()
        f()
        assert result == 0
        f()
        assert result == 10

if __name__ == '__main__':
    test

# Generated at 2022-06-21 21:59:03.725130
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    t = _LazyModuleMarker()
    assert type(t) == _LazyModuleMarker

# Generated at 2022-06-21 21:59:06.610186
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-21 21:59:18.568845
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy()
    """
    sys_modules = sys.modules.copy()

    def _run(module_path='my_module'):
        """
        Simulates the running of module_path.
        """
        make_lazy(module_path)
        mod = sys.modules[module_path]

        assert not hasattr(mod, '__name__')
        assert not hasattr(mod, '__package__')
        assert not hasattr(mod, '__file__')

        assert not hasattr(mod, 'Foo')

        assert isinstance(mod, _LazyModuleMarker)

        have_foo = False
        try:
            mod.Foo()
            have_foo = True
        except AttributeError:
            assert not have_foo


# Generated at 2022-06-21 21:59:19.814374
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(5)
    assert x.value == 5

# Generated at 2022-06-21 21:59:31.499198
# Unit test for function make_lazy
def test_make_lazy():
    from my_package.lazy_mod import *

    foo_mod = sys.modules['test_make_lazy.foo_mod']
    assert isinstance(foo_mod, _LazyModuleMarker)

    # Accessing an attribute should import the module.
    assert foo is None
    assert foo_mod.foo is None
    foo_mod = sys.modules['test_make_lazy.foo_mod']
    assert not isinstance(foo_mod, _LazyModuleMarker)

    # Modules imported in the lazy module should also be lazy.
    assert bar_mod is None
    assert isinstance(bar_mod, _LazyModuleMarker)
    assert bar_mod.bar is None
    assert not isinstance(bar_mod, _LazyModuleMarker)

    # Modules imported in the non-lazy module should

# Generated at 2022-06-21 21:59:38.095659
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()

    # Check LazyModuleMarker instance attributes
    assert marker.__module__ == '__main__'
    assert marker.__name__ == '_LazyModuleMarker'
    assert marker.__doc__ is None
    assert marker.__dict__ == dict()
    assert marker.__weakref__ is None
    assert marker.__slots__ is None


# Generated at 2022-06-21 21:59:44.160083
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function.
    """
    # Create a dummy module to replace the one we will make lazy.
    class DummyModule(ModuleType):
        """
        A dummy module to test `make_lazy`.
        """
        def __init__(self, *args, **kwargs):
            super(DummyModule, self).__init__(*args, **kwargs)
            self.__all__ = ['foo']
            self.foo = 1

        def __getitem__(self, item):
            """
            Allow indexing to work.
            """
            return self.__dict__[item]

    # Name of the module we will make lazy.
    module_name = 'module_name'

    # Pass in a dummy module into sys.modules.
    sys.modules[module_name] = D

# Generated at 2022-06-21 21:59:50.425379
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    import sys
    from types import ModuleType
    from importlib import import_module
    sys.modules['some.module'] = ModuleType('some.module')
    module = lambda: sys.modules['some.module']
    assert not module().__dict__

    # Exercise
    make_lazy('some.module')
    assert isinstance(module(), _LazyModuleMarker)
    assert module().__name__ == 'some.module'

    # Verify
    assert module().__dict__ == import_module('some.module').__dict__



# Generated at 2022-06-21 21:59:53.449189
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    x.value = 3
    assert x.value == 3, "test_NonLocal failed"


# Generated at 2022-06-21 21:59:58.041113
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    marker = NonLocal('xyz')
    assert marker.value == 'xyz'


# Generated at 2022-06-21 22:00:06.520291
# Unit test for function make_lazy
def test_make_lazy():
    # Save a copy of sys.modules for testing purposes
    old_modules = sys.modules.copy()
    old_modules_keys = set(old_modules.keys())

    # Create a function that we can use to check if an object was imported
    # from another module.
    check_imported = lambda m, attr: getattr(globals()[m], attr) is not getattr(sys.modules[m], attr)

    # Create a temporary module
    temp_module = types.ModuleType('temp_module')
    temp_module.foo = 'foo'
    sys.modules['temp_module'] = temp_module

    # Mark temp_module as lazy
    make_lazy('temp_module')

    # Check that temp_module is marked as lazy
    assert 'temp_module' in sys.modules

    # Check

# Generated at 2022-06-21 22:00:09.339893
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2


# Generated at 2022-06-21 22:00:11.959051
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker


# Generated at 2022-06-21 22:00:13.862886
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__init__ is not object.__init__

# Generated at 2022-06-21 22:00:16.630716
# Unit test for function make_lazy
def test_make_lazy():
    import sys  # unit test
    path = '__main__.test_make_lazy_module'
    make_lazy(path)
    assert isinstance(sys.modules[path], _LazyModuleMarker)



# Generated at 2022-06-21 22:00:20.656068
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Initialize _LazyModuleMarker
    _LazyModuleMarker()
    print("test_make_lazy(): constructor of class _LazyModuleMarker tested successfully")


# Generated at 2022-06-21 22:00:23.798226
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(3)
    assert nonlocal_.value == 3

    nonlocal_.value = 5
    assert nonlocal_.value == 5



# Generated at 2022-06-21 22:00:31.322618
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make_lazy function
    """
    class A(object):
        pass

    # Create LazyModule type
    make_lazy('mypackage.mymodule')

    # Check that LazyModule is actually created
    assert 'mypackage.mymodule' in sys.modules
    assert isinstance(sys.modules['mypackage.mymodule'], _LazyModuleMarker)

    # Check LazyModule for equality
    assert sys.modules['mypackage.mymodule'] == sys.modules['mypackage.mymodule']
    assert hash(sys.modules['mypackage.mymodule']) == \
        hash(sys.modules['mypackage.mymodule'])
    assert sys.modules['mypackage.mymodule'] != object()
    assert sys.modules['mypackage.mymodule'] != A()

    # Check LazyModule

# Generated at 2022-06-21 22:00:40.607472
# Unit test for function make_lazy
def test_make_lazy():
    class FakeModule(object):
        pass

    # Set our module to pretend it is imported
    sys.modules['fake.module'] = FakeModule()
    assert sys.modules['fake.module'] is not None

    # Make it lazy, it should be `None` again
    make_lazy('fake.module')
    assert sys.modules['fake.module'] is not None
    assert isinstance(sys.modules['fake.module'], _LazyModuleMarker)

    # touch the module
    assert sys.modules['fake.module'].__name__ == "fake.module"
    assert isinstance(sys.modules['fake.module'], ModuleType)



# Generated at 2022-06-21 22:00:44.391387
# Unit test for constructor of class NonLocal
def test_NonLocal():
    b = NonLocal(2)
    a = NonLocal('a')
    c = NonLocal(b)
    b.value = 3
    assert b.value == a.value
    assert c.value.value == b.value
    #assert c.value.value == a.value # Error!
    assert not isinstance(a, NonLocal)
    assert isinstance(c, NonLocal)


# Generated at 2022-06-21 22:00:46.782982
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests whether the constructor of class _LazyModuleMarker works properly.
    """
    _LazyModuleMarker()


# Generated at 2022-06-21 22:00:53.716170
# Unit test for function make_lazy
def test_make_lazy():
    import rf.test.make_lazy
    assert isinstance(rf.test.make_lazy, _LazyModuleMarker)
    assert not isinstance(rf.test.make_lazy, ModuleType)
    assert rf.test.make_lazy.TestClass == TestClassInner


TestClassInner = None

if __name__ == '__main__':
    import pytest
    make_lazy(__name__)
    TestClassInner = type('TestClassInner', (object,), {})
    pytest.main()

# Generated at 2022-06-21 22:00:56.560921
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker
    assert marker is _LazyModuleMarker
    assert marker is not None
    assert isinstance(marker, object)

# Generated at 2022-06-21 22:00:59.823390
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(1)
    assert nl1.value == 1
    nl2 = NonLocal('a')
    assert nl2.value == 'a'

# Generated at 2022-06-21 22:01:02.009669
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10

# Generated at 2022-06-21 22:01:14.367806
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # We are going to test a private class, so we need to use a
    # reflection API to get the class
    cls = getattr(sys.modules[__name__], '_LazyModuleMarker')
    marker = cls()
    # first we will test the __mro__
    mro = marker.__mro__()
    assert mro[0] == marker, "The __mro__ should have the marker as the first item. The lazy module marker is %s and mro is %s" % (marker, mro)
    # we will now test inheritance
    assert isinstance(marker, _LazyModuleMarker) == True, "The marker should be an instance of _LazyModuleMarker"
    assert isinstance(marker, LazyModule) == True, "The marker should be an instance of LazyModule"

# Generated at 2022-06-21 22:01:22.638265
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    _LazyModuleMarker class should be initialized without errors.
    """
    import sys
    import types
    import inspect

    assert isinstance(_LazyModuleMarker(), types.ObjectType)
    assert _LazyModuleMarker.__module__ == '__main__'
    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'
    assert inspect.isclass(_LazyModuleMarker)

    # Test for constructor
    assert _LazyModuleMarker() == _LazyModuleMarker()


# Generated at 2022-06-21 22:01:23.669165
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert isinstance(NonLocal(None), NonLocal)

# Generated at 2022-06-21 22:01:27.368644
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo.bar')
    last_bar = None
    for _ in range(2):
        foo = __import__('foo')
        bar = foo.bar
        assert bar is not last_bar  # ensure we have a cached value
        last_bar = bar
        assert bar.thing is not None  # ensure that the attribute import worked
        assert isinstance(bar, _LazyModuleMarker)  # check that we can fool isinstance
        assert isinstance(bar, ModuleType)  # check that we can fool isinstance

# Generated at 2022-06-21 22:01:32.449048
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class A(object):
        def print_a(self):
            value = NonLocal(2)
            def b():
                c = NonLocal(3)

# Generated at 2022-06-21 22:01:34.341699
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 22:01:40.194176
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    A function to test the constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker

# Generated at 2022-06-21 22:01:48.925948
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    assert sys.modules['__main__'].__name__ == __name__, 'name is not correct'
    assert sys.modules['__main__'].__file__ == __file__, 'file is not correct'
    assert sys.modules['__main__'].__package__ == '', 'package is not correct'
    assert isinstance(sys.modules['__main__'], ModuleType), 'not instance of ModuleType'
    assert not isinstance(sys.modules['__main__'], _LazyModuleMarker), 'instance of ModuleType cannot be instance of _LazyModuleMarker'


# Generated at 2022-06-21 22:01:55.253637
# Unit test for function make_lazy
def test_make_lazy():
    # TODO: make this an actual test.
    import sys
    make_lazy('os')
    make_lazy('sys')
    make_lazy('pdb')
    make_lazy('os.path')
    # now try to actually use it...

# Generated at 2022-06-21 22:01:56.360896
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy(__name__) == None
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)

# Generated at 2022-06-21 22:01:58.870107
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2

# Generated at 2022-06-21 22:02:00.303774
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal([])
    return x.value



# Generated at 2022-06-21 22:02:09.392921
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('mypackage')
    make_lazy('mypackage')
    from . import mypackage
    make_lazy('mypackage')
    assert(isinstance(mypackage, _LazyModuleMarker))
    assert(not hasattr(mypackage, '__file__'))
    assert(hasattr(mypackage, '__mro__'))
    assert(hasattr(mypackage, '__path__'))
    assert(hasattr(mypackage, '__name__'))
    assert(not hasattr(mypackage, '__package__'))

    # second import should not trigger the __import__
    import mypackage
    assert(isinstance(mypackage, _LazyModuleMarker))

    # accessing an attribute should trigger the __import__
    assert(mypackage.__package__ == 'mypackage')

# Generated at 2022-06-21 22:02:12.436024
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 22:02:25.656473
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure the `LazyModule` we created is a valid module.
    import lazy
    assert isinstance(lazy, ModuleType)
    m = sys.modules['lazy']
    m.hello = "world"
    assert m.hello == "world"
    # Make sure `isinstance(LazyModule, ModuleType)`
    assert isinstance(m, ModuleType)
    # Assert that LazyModule is a subclass of ModuleType
    assert issubclass(m.__class__, ModuleType)
    # Assert that the __mro__ has been overridden
    assert m.__mro__ == (lazy.LazyModule, ModuleType)


# Iterates over modules and patches them to the LazyModule type
for m in PATCHED_MODULES:
    make_lazy(m)

# Unit

# Generated at 2022-06-21 22:02:30.186335
# Unit test for constructor of class NonLocal
def test_NonLocal():

    # Check if the constructor throws an exception on arguments
    # of number type
    try:
        NonLocal(100)
    except TypeError as err:
        assert str(err) == ("__init__() takes exactly 2 arguments "
                            "(1 given)")


# Generated at 2022-06-21 22:02:37.228132
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  marker = _LazyModuleMarker()
  assert isinstance(marker, _LazyModuleMarker)
  assert isinstance(marker, object)


# Generated at 2022-06-21 22:02:41.204722
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test constructor of class _LazyModuleMarker.
    """
    arg = _LazyModuleMarker()
    new_marker = _LazyModuleMarker()
    assert arg is not None
    assert new_marker is not None


# Generated at 2022-06-21 22:02:42.556797
# Unit test for constructor of class NonLocal
def test_NonLocal():
    instance = NonLocal('value')
    assert instance.value == 'value'

# Generated at 2022-06-21 22:02:45.345669
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-21 22:02:52.641841
# Unit test for function make_lazy
def test_make_lazy():
    # Clean out sys.modules so that we can add stuff to it.
    for key in sys.modules.keys():
        if key.startswith("test_make_lazy."):
            del sys.modules[key]

    __import__("test_make_lazy.fake_module")
    make_lazy("test_make_lazy.fake_module")

    # At this point, fake_module was not actually imported,
    # but sys.modules contains an entry for it, so the import
    # statement above didn't fail.

    from test_make_lazy import fake_module
    assert fake_module.__name__ == "test_make_lazy.fake_module"

    # At this point, fake_module was actually imported,
    # and we can access attributes directly.


# Generated at 2022-06-21 22:03:03.718511
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'django.db'
    assert module_path in sys.modules

    make_lazy(module_path)
    assert sys.modules[module_path] is not None
    assert module_path not in sys.modules

    assert 'DatabaseError' not in sys.modules[module_path].__dict__
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert isinstance(sys.modules[module_path], ModuleType)
    assert isinstance(sys.modules[module_path], type)

    assert hasattr(sys.modules[module_path], 'DatabaseError')
    assert 'DatabaseError' in sys.modules[module_path].__dict__
    assert not isinstance(sys.modules[module_path], _LazyModuleMarker)

# Generated at 2022-06-21 22:03:07.147857
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not hasattr(_LazyModuleMarker(), '__mro__')
    assert hasattr(LazyModule(), '__mro__')
    assert not hasattr(_LazyModuleMarker(), '__getattribute__')
    assert hasattr(_LazyModuleMarker(), '__getattribute__')


# Generated at 2022-06-21 22:03:14.831435
# Unit test for function make_lazy
def test_make_lazy():
    import __main__
    import sys

    try:
        sys.modules['__main__'].foo = 'bar'
    except AttributeError:
        pass

    assert 'foo' not in __main__.__dict__
    make_lazy('__main__')
    assert 'foo' in __main__.__dict__

    __main__.foo = 'baz'

    assert __main__.foo == 'baz'

    del sys.modules['__main__']

# Generated at 2022-06-21 22:03:16.516982
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    instance = _LazyModuleMarker()
    assert isinstance(instance, _LazyModuleMarker)


# Generated at 2022-06-21 22:03:25.901817
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function.
    """
    class _SoloModule(object):
        """
        Dummy module to use for testing.
        """
        def foo(self):
            """
            A method to test lazy module loading.
            """

# Generated at 2022-06-21 22:03:32.125036
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value == None


# Generated at 2022-06-21 22:03:35.366179
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal.
    """
    obj_value = "obj_value"
    obj = NonLocal(obj_value)
    assert obj.value == obj_value

# Generated at 2022-06-21 22:03:44.026995
# Unit test for function make_lazy
def test_make_lazy():
    # This will expose the transpiled code to our test.
    # There are some tricks to make this work, so read on!
    sys.modules['test_make_lazy.package'] = package = _LazyModuleMarker()

    def cleanup_test():
        del sys.modules['test_make_lazy.package']
        modules = list(sys.modules.keys())
        for key in modules:
            if key.startswith('test_make_lazy.package'):
                del sys.modules[key]

    cleanup_test()

# Generated at 2022-06-21 22:03:48.503266
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal("first string")
    assert nonlocal_var.value == "first string"
    nonlocal_var.value = "second string"
    assert nonlocal_var.value == "second string"

# Test case for method make_lazy

# Generated at 2022-06-21 22:03:50.666454
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    markers = _LazyModuleMarker()
    str(markers)

# Generated at 2022-06-21 22:03:57.146405
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_1 = _LazyModuleMarker()
    test_2 = _LazyModuleMarker()

    # Check that test_1 is a LazyModuleMarker
    assert isinstance(test_1, _LazyModuleMarker)

    # Check that test_2 is a LazyModuleMarker
    assert isinstance(test_2, _LazyModuleMarker)

    # Test if test_1 is the same object as test_2
    assert test_1 is not test_2


# Generated at 2022-06-21 22:04:04.497423
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Imports
    from types import ModuleType

    class LazyModule(_LazyModuleMarker):
        """
        Test Class for constructor of class _LazyModuleMarker
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (LazyModule, ModuleType)

    # Test if the given object is instance of LazyModule
    assert isinstance(LazyModule, LazyModule)

# Generated at 2022-06-21 22:04:06.912978
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    A test function for the constructor of class _LazyModuleMarker
    """
    a = _LazyModuleMarker()



# Generated at 2022-06-21 22:04:08.908508
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(5)
    assert nl.value == 5


# Generated at 2022-06-21 22:04:20.013472
# Unit test for function make_lazy

# Generated at 2022-06-21 22:04:35.252471
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value is None

    nl.value = 'Hello'
    assert nl.value is 'Hello'

# Generated at 2022-06-21 22:04:38.547067
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl_obj = NonLocal(1)
    assert nl_obj.value == 1
    nl_obj.value = 2
    assert nl_obj.value == 2


# Generated at 2022-06-21 22:04:41.802850
# Unit test for function make_lazy
def test_make_lazy():
    global math_square_root
    import math

    make_lazy('math')
    print(math)
    print(math.sqrt)
    print(math.square_root)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:04:47.743482
# Unit test for function make_lazy
def test_make_lazy():
    # Test if NonLocal works correctly
    nonlocal_test = NonLocal(10)
    assert nonlocal_test.value == 10
    nonlocal_test.value = 20
    assert nonlocal_test.value == 20

    # Test if a LazyModule is detected as lazily loaded
    del sys.modules['sys']
    make_lazy('sys')
    sys = sys.modules['sys']
    assert isinstance(sys, _LazyModuleMarker)

    # Test if a LazyModule can be loaded correctly
    assert sys.path[0] == ''
    assert sys.path[1] == '/system/bin'
    assert sys.path[2] == '/vendor/bin'
    assert sys.path[3] == '/sbin'

    # Test if a LazyModule can be reloaded if module is already loaded
   

# Generated at 2022-06-21 22:04:50.186462
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    a.value = 2
    assert a.value == 2
    b = NonLocal(2)
    assert b.value == 2

# Generated at 2022-06-21 22:04:53.049579
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        a = NonLocal(123)
        assert a.value == 123
    except AttributeError:
        assert False


# Generated at 2022-06-21 22:04:55.258207
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(12)
    assert nonlocal_instance.value == 12

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:04:58.629373
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Tests the constructor of _LazyModuleMarker
    with pytest.raises(TypeError):
        # We are not allowed to instantiate this class
        t = _LazyModuleMarker()
    return



# Generated at 2022-06-21 22:05:01.980861
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import datetime
    test_module = _LazyModuleMarker()
    make_lazy(test_module)
    assert datetime.__mro__ == test_module.__mro__
    assert datetime.__getattribute__ == test_module.__getattribute__

# Generated at 2022-06-21 22:05:12.319401
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('test_make_lazy')
    mod = sys.modules[__name__]
    assert not hasattr(mod, 'x'), "module already loaded"

    mod.x = 1
    assert mod.x == 1, "attribute not found"

    del mod.x
    del sys.modules[__name__]
    make_lazy('test_make_lazy')
    assert not hasattr(mod, 'x'), "module already loaded"

    mod.x = 1
    assert mod.x == 1, "attribute not found"

make_lazy('Algorithm')
make_lazy('Algorithm_')
make_lazy('Algorithm__')
make_lazy('Algorithm___')
make_lazy('Algorithm____')
make_lazy('Algorithm_____')
make_

# Generated at 2022-06-21 22:05:37.881794
# Unit test for function make_lazy
def test_make_lazy():
    def assert_success(module_name, load_func, load_func_args=None, load_func_kwargs=None):
        assert load_func_args is None
        assert load_func_kwargs is None
        make_lazy(module_name)
        mod = sys.modules[module_name]
        assert isinstance(mod, _LazyModuleMarker)
        load_func()
        mod = sys.modules[module_name]
        assert not isinstance(mod, _LazyModuleMarker)
        assert module_name in sys.modules

    # make sure that make_lazy doesn't raise an exception
    assert_success('random', lambda: random.random())


make_lazy('django.conf')
make_lazy('django.conf.global_settings')

# Generated at 2022-06-21 22:05:46.345372
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not inspect.isclass(_LazyModuleMarker)
    assert not inspect.isfunction(_LazyModuleMarker)
    assert not inspect.ismethod(_LazyModuleMarker)
    assert not inspect.isgeneratorfunction(_LazyModuleMarker)
    assert not inspect.ismodule(_LazyModuleMarker)
    assert not inspect.istraceback(_LazyModuleMarker)
    assert not inspect.isframe(_LazyModuleMarker)
    assert not inspect.iscode(_LazyModuleMarker)
    assert not inspect.isbuiltin(_LazyModuleMarker)
    assert not inspect.isroutine(_LazyModuleMarker)
    assert not inspect.isabstract(_LazyModuleMarker)
    assert not inspect.ismethoddescriptor(_LazyModuleMarker)
    assert not inspect.isdat

# Generated at 2022-06-21 22:05:48.709734
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)



# Generated at 2022-06-21 22:05:50.086801
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert 'value' in NonLocal('value').__slots__


# Generated at 2022-06-21 22:05:58.871221
# Unit test for function make_lazy
def test_make_lazy():
    """
    You may have to execute the entire file to catch ImportErrors
    """
    import requests  # using the standard library package
    import _random_package_name  # some random package to test on
    make_lazy("_random_package_name")
    make_lazy("_random_package_name2")

    try:
        from _random_package_name import urandom
    except ImportError:
        assert True
    urandom()

    try:
        from _random_package_name2 import urandom
    except ImportError:
        assert True
    urandom()

    try:
        from requests import urandom
    except ImportError:
        assert True
    urandom()

    # Python 3 Disallows reassigning modules in sys.modules
    # but just incase we want to allow this to work anyways...

# Generated at 2022-06-21 22:06:02.722372
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _Test__LazyModuleMarker(object):
        def test__init__(self):
            LazyModule = _LazyModuleMarker()
            Assertion(isinstance(LazyModule, _LazyModuleMarker)).is_true()
    _Test__LazyModuleMarker().test__init__()

# Generated at 2022-06-21 22:06:09.637882
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Creating a dummy class
    class MyClass(object):
        pass

    # Creating an instance of MyClass
    class_instance = MyClass()

    # Assertion to check if class_instance is an instance of class MyClass
    assert isinstance(class_instance, MyClass)

    # Creates a _LazyModuleMarker object
    marker = _LazyModuleMarker()

    # Assertion to check if marker object is an instance of _LazyModuleMarker
    assert isinstance(marker, _LazyModuleMarker)


# Generated at 2022-06-21 22:06:13.075230
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(100)
    assert a, "A NonLocal object could not be instantiated."

# Generated at 2022-06-21 22:06:25.009629
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test make_lazy has the expected behavior
    '''
    foo = "foo"
    test_module_path = '.'.join(['tests', 'unit', 'test_lazy', foo])

    try:
        del sys.modules[test_module_path]
    except KeyError:
        pass

    make_lazy(test_module_path)

    # The module 'test_module' should not be in sys.modules yet
    assert 'tests.unit.test_lazy.foo' not in sys.modules

    # The object returned by sys.modules[test_module_path] should
    # be a LazyModule
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)

    # The module 'test_module' should be in sys.modules after its
    #

# Generated at 2022-06-21 22:06:32.101283
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(make_lazy('config')) == _LazyModuleMarker



# Generated at 2022-06-21 22:07:04.676360
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker().__class__ == _LazyModuleMarker
    assert _LazyModuleMarker().__doc__ == None


# Generated at 2022-06-21 22:07:07.202012
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3

    # Test if we can change the value
    x.value = 4
    assert x.value == 4


# Generated at 2022-06-21 22:07:13.535002
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy
    """
    sys_modules = sys.modules
    sys_modules['lazy_test'] = None

    make_lazy('lazy_test')

    module_name = sys_modules['lazy_test']
    assert isinstance(module_name, _LazyModuleMarker)
    module_name.__getattribute__('__mro__')
    module_name.__getattribute__('__getattribute__')

    assert module_name._LazyModuleMarker__mro__ == \
               (module_name._LazyModuleMarker, ModuleType)

    assert module_name._LazyModuleMarker__getattribute__ == module_name.__getattribute__

# Generated at 2022-06-21 22:07:15.840645
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_module = _LazyModuleMarker()
    assert(isinstance(test_module, _LazyModuleMarker) == True)


# Generated at 2022-06-21 22:07:20.722244
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # create an instance of the _LazyModuleMarker
    lmm = _LazyModuleMarker()
    # print the instance type