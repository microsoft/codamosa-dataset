

# Generated at 2022-06-21 21:57:24.754396
# Unit test for function make_lazy
def test_make_lazy():
    import lazymodule

    module_path = "lazymodule"

    assert isinstance(lazymodule, _LazyModuleMarker)
    assert lazymodule.__name__ == module_path
    assert hasattr(lazymodule, "func")
    assert lazymodule.func() == "func"
    assert lazymodule.__name__ == module_path

    del lazymodule
    del sys.modules[module_path]

    make_lazy(module_path)
    import lazymodule

    assert isinstance(lazymodule, _LazyModuleMarker)
    assert lazymodule.__name__ == module_path
    assert hasattr(lazymodule, "func")
    assert lazymodule.func() == "func"
    assert lazymodule.__name__ == module_path

# Generated at 2022-06-21 21:57:30.691089
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_make_lazy')

    # test importing a lazy package
    assert test_make_lazy.NonLocal is NonLocal

    # test importing a lazy module
    import test_make_lazy.test_make_lazy1
    assert test_make_lazy1.test_make_lazy2 is test_make_lazy.test_make_lazy1.test_make_lazy2

# Generated at 2022-06-21 21:57:33.812232
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1

    a.value = 2
    assert a.value == 2



# Generated at 2022-06-21 21:57:41.015639
# Unit test for function make_lazy
def test_make_lazy():

    import this
    import os
    import sys
    import random
    import re

    tests = [this, os, sys, random, re]

    def _test_lazy(mod):
        assert isinstance(mod, _LazyModuleMarker)
        assert hasattr(mod, '__file__')
        assert hasattr(mod, '__name__')
        assert hasattr(mod, '__doc__')
        assert not hasattr(mod, '__path__')

    def _test_loaded(mod):
        assert isinstance(mod, ModuleType)
        assert hasattr(mod, '__file__')
        assert hasattr(mod, '__name__')
        assert hasattr(mod, '__doc__')
        assert '__path__' in mod.__dict__
        return True

    # Test our patching


# Generated at 2022-06-21 21:57:43.192598
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3


# Generated at 2022-06-21 21:57:45.068431
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-21 21:57:47.134575
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal(3)
    var.value = 5
    assert var.value == 5
    assert type(var) is NonLocal


# Generated at 2022-06-21 21:57:49.397524
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5

# Generated at 2022-06-21 21:57:57.904168
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import pickle
    import unittest
    import sys

    class TestMakeLazy(unittest.TestCase):
        def test__getattribute__(self):
            sys.modules['os.foo'] = sys.modules.pop('os')

            try:
                make_lazy('os.foo')
            finally:
                sys.modules['os'] = sys.modules.pop('os.foo')

            self.assertIsInstance(os.foo, _LazyModuleMarker)
            self.assertTrue(isinstance(os.foo, ModuleType))
            self.assertFalse(isinstance(os.foo, LazyModule))

            self.assertEqual(os.foo.path, os.path)
            self.assertIsInstance(os.foo.path, ModuleType)


# Generated at 2022-06-21 21:58:02.015964
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    class Temp(object):
        pass
    temp = Temp()
    temp.f = NonLocal(2)

    def f():
        temp.f.value += 1
        return temp.f.value
    assert f() == 3


# Generated at 2022-06-21 21:58:06.160204
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('value')
    assert nl.value == 'value'

# Unit tests for class LazyModule
import unittest
from copy import copy


# Generated at 2022-06-21 21:58:18.173985
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function by using it to wrap
    two modules, and everything within them.
    """
    try:
        make_lazy('import_lazy.test_module')
        import_lazy.test_module.mod_attr
        print('Module within module test passed.')
    except Exception as e:
        print('Module within module test failed!')
        print(e)

    try:
        make_lazy('import_lazy.test_module.mod_attr')
        import_lazy.test_module.mod_attr.mod_attr
        print('Nested module test passed.')

    except Exception as e:
        print('Nested module test failed!')
        print(e)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 21:58:24.548745
# Unit test for constructor of class NonLocal
def test_NonLocal():
    s = NonLocal(10)
    # Test for variable value initialization
    assert(s.value == 10)
    # Test whether variable value is changed
    s.value = 100
    assert(s.value == 100)
    # Test whether variable is added
    s.a = 1000
    assert(s.a == 1000)
    # Test whether variable is removed
    # del s.value
    # assert(s.value == None)


# Generated at 2022-06-21 21:58:25.921906
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert m is not None


# Generated at 2022-06-21 21:58:27.162075
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	import python_toolbox.marker as test
	method = test._LazyModuleMarker()
	isinstance(method, object)


# Generated at 2022-06-21 21:58:28.515126
# Unit test for constructor of class NonLocal
def test_NonLocal():
    f = NonLocal(1)
    assert f.value == 1

# Generated at 2022-06-21 21:58:32.267501
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import ast
    import argparse
    import numpy.random

    assert not isinstance(ast.arguments, _LazyModuleMarker)
    assert isinstance(argparse.ArgumentParser, _LazyModuleMarker)
    assert isinstance(numpy.random, _LazyModuleMarker)

# Generated at 2022-06-21 21:58:33.127221
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-21 21:58:38.668366
# Unit test for function make_lazy
def test_make_lazy():
    import test_suite.support

    sys_modules = sys.modules
    make_lazy('test_suite.support')
    assert 'test_suite.support' in sys_modules

    # Check that the module is marked as a _LazyModuleMarker
    assert isinstance(sys_modules['test_suite.support'], _LazyModuleMarker)
    assert not isinstance(sys_modules['test_suite.support'], ModuleType)

    # the module should not be in sys.modules at this point
    assert 'test_suite.support' not in sys_modules

    # Check that when we access an attribute, the module is loaded
    assert 'DummyModulePath' in dir(test_suite.support)
    assert 'test_suite.support' in sys_modules

    # Check that the module is not

# Generated at 2022-06-21 21:58:40.421277
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(12)
    assert nonlocal_obj.value == 12

# Generated at 2022-06-21 21:58:52.615698
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import logging
    import threading
    import django.test.testcases

    # Check that we can get the logging module loaded.
    logging.warning('First call from logging')

    # Check that we can get django.test.testcases loaded.
    django.test.testcases.TestCase()

    # Mark logging and django.test.testcases as lazy modules.
    make_lazy('logging')
    make_lazy('django.test.testcases')

    # Check that we can still get logging module loaded.
    logging.warning('Second call from logging')

    # Check that we can still get django.test.testcases loaded.
    django.test.testcases.TestCase()

    # Check that the module was loaded since we called its function.
    assert 'logging' in sys.modules

# Generated at 2022-06-21 21:58:54.275072
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import __main__
    actual = __main__._LazyModuleMarker().__class__.__name__
    assert actual == "_LazyModuleMarker"


# Generated at 2022-06-21 21:59:02.003851
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test function make_lazy(). Tests that the function properly marks
    a module as lazy, and tests that the module is properly imported
    when the module is accessed.
    '''
    import sys
    import datetime  # This is a standard python module that we can test
    assert datetime.datetime.now() is not None  # Just to see that datetime works
    sys.modules['datetime'] = None  # This undoes the import on the original line for datetime
    make_lazy('datetime')
    assert datetime.datetime.now() is not None  # Just to see that datetime still works after the module was marked as lazy
    assert type(datetime) is not NonLocal  # Make sure the module wasn't imported yet
    assert 'datetime' in sys.modules  # Make sure datetime is still in the module

# Generated at 2022-06-21 21:59:09.944818
# Unit test for function make_lazy

# Generated at 2022-06-21 21:59:17.722169
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function works as expected.
    """
    make_lazy('test_lazy')

    module = sys.modules['test_lazy']
    assert isinstance(module, _LazyModuleMarker)

    # Make sure we can get attributes from the module without
    # importing it.
    assert module.__name__ == 'test_lazy'

    # Make sure it has been imported
    assert module.__file__.endswith('/test_lazy.py')

# Generated at 2022-06-21 21:59:29.216986
# Unit test for function make_lazy

# Generated at 2022-06-21 21:59:40.052062
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    _, module_name = tempfile.mkstemp('.py')
    module_name = os.path.basename(module_name)
    module_path = '.'.join(module_name.split('.')[:-1])
    func_name = 'foo'
    with open(module_name, 'w') as f:
        f.write('{} = 0'.format(func_name))

    import sys
    sys.path.insert(0, '.')
    make_lazy(module_path)
    from importlib import reload
    reload(module_path)

    assert sys.modules[module_path] is not None
    assert not hasattr(module_path, func_name)
    assert sys.modules[module_path].__class__ == type
    assert isinstance

# Generated at 2022-06-21 21:59:49.819242
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function ``make_lazy``.
    """
    import sys
    import tempfile

    old_sys_modules = sys.modules.copy()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:59:58.119899
# Unit test for function make_lazy
def test_make_lazy():
    _lazy_module_name = '_lazy_module'
    _lazy_module_path = '.'.join([__name__, _lazy_module_name])

    import sys
    import imp
    import os.path


# Generated at 2022-06-21 22:00:00.209885
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    cls = _LazyModuleMarker
    cls()



# Generated at 2022-06-21 22:00:07.978028
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Foo(object):
        def __init__(self):
            self.x = NonLocal(3)

        def bar(self):
            self.x.value = 4

    a = Foo()
    assert a.x.value == 3
    a.bar()
    assert a.x.value == 4


# Generated at 2022-06-21 22:00:09.656329
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-21 22:00:13.112023
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(None)
    v.value = 'hello'
    assert v.value == 'hello'



# Generated at 2022-06-21 22:00:15.564831
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    l = _LazyModuleMarker()
    assert l is not None
    assert isinstance(l, _LazyModuleMarker) == True


# Generated at 2022-06-21 22:00:18.745634
# Unit test for constructor of class NonLocal
def test_NonLocal():
    attr = NonLocal(1)
    assert attr.value == 1

    attr.value = 2
    assert attr.value == 2

# Unit test to check whether the module is lazy or not

# Generated at 2022-06-21 22:00:29.366417
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test to prove the make_lazy function works correctly.
    '''
    import os
    import sys
    import types

    # Ensure we can properly import modules with absolute imports
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    make_lazy('ldap.schema')

    from ldap.schema import AttributeType, ObjectClass

    # Check that the module object is a LazyModule object
    assert isinstance(ldap.schema, types.ModuleType)
    assert isinstance(ldap.schema, _LazyModuleMarker)
    assert not isinstance(ldap.schema, AttributeType)
    assert not isinstance(ldap.schema, ObjectClass)

    # Check that we can access the underlying module directly

# Generated at 2022-06-21 22:00:38.515222
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__=='_LazyModuleMarker'
    assert _LazyModuleMarker.__repr__()=='<_LazyModuleMarker object at 0x7f9e9d5da6d0>'
    assert _LazyModuleMarker.__module__=='pypy_gensupport._LazyModuleMarker'
    assert _LazyModuleMarker.__str__()=='<_LazyModuleMarker object at 0x7f9e9d5da6d0>'


# Generated at 2022-06-21 22:00:41.213201
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test that NonLocal stores the value
    """
    value = "foo"
    nonlocal_test = NonLocal(value)

    assert nonlocal_test.value == value


# Generated at 2022-06-21 22:00:42.724616
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(3)
    assert value.value == 3
    value.value = 5
    assert value.value == 5


# Generated at 2022-06-21 22:00:50.747777
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import pytest
    lazyModule = sys.modules['edx_lazy_module']
    assert isinstance(lazyModule, _LazyModuleMarker)
    # If any of the following lines fail, uncomment the one you want and comment the others
    #x = lazyModule.help()
    #x = lazyModule.isinstance([1,2,3], list)
    #x = lazyModule.isinstance([1,2,3], LazyModule)
    x = lazyModule.isinstance(lazyModule, _LazyModuleMarker)
    assert x == True


# Generated at 2022-06-21 22:00:59.485773
# Unit test for function make_lazy
def test_make_lazy():
    from nose.tools import assert_equal
    import mock
    import sslscan

    # Clear sys.modules.
    for module in sys.modules.keys():
        if module.startswith("sslscan"):
            del sys.modules[module]

    # We want to delay the SSLHandshake module from being imported.
    make_lazy("sslscan.SSLHandshake")
    assert_equal(list(sys.modules.keys()), ["sslscan"])

    # Get the SSLHandshake class.
    handshake = sslscan.SSLHandshake()
    assert_equal(list(sys.modules.keys()), ["sslscan", "sslscan.SSLHandshake"])
    assert_equal(type(handshake), mock.Mock)


# Generated at 2022-06-21 22:01:13.519349
# Unit test for function make_lazy
def test_make_lazy():
    import example
    import example.foo
    import example.foo.bar

    # clear out the module cache to ensure
    # the logic inside is tested.
    sys.modules = {}

    # We need to check the object's identity
    # since it could be reloaded into a different
    # identity (eg, `importlib.reload`)
    assert example.foo is not example.foo

    # ensure that the modules were imported before
    # make_lazy was called
    assert 'example' in sys.modules
    assert 'example.foo' in sys.modules
    assert 'example.foo.bar' in sys.modules

    # They should have already been imported
    assert example.foo is example.foo
    assert example.foo is not None
    assert example.foo.bar is example.foo.bar

# Generated at 2022-06-21 22:01:15.813160
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(callable(_LazyModuleMarker))


# Generated at 2022-06-21 22:01:20.695846
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test.module'
    make_lazy(module_path)

    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    del sys.modules[module_path]

# Generated at 2022-06-21 22:01:26.332416
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker), 'isinstance(LazyModule(), LazyModule) must be True'
    assert isinstance(LazyModule(), ModuleType), 'isinstance(LazyModule(), ModuleType) must be True'
    assert isinstance(LazyModule(), _LazyModuleMarker), 'isinstance(LazyModule(), _LazyModuleMarker) must be True'
    assert isinstance(LazyModule(), object), 'isinstance(LazyModule(), object) must be True'


# Generated at 2022-06-21 22:01:30.886960
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # First create an instance of Nonlocal
    n = NonLocal('hello')
    assert n.value == 'hello'

    # Now check if it was initialized correctly
    n.value = 'world'
    assert n.value == 'world'


# Unit test class LazyModule

# Generated at 2022-06-21 22:01:39.385979
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    import_module('tests.test_import.module_for_test_make_lazy')

# Generated at 2022-06-21 22:01:42.502926
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1
    assert NonLocal(2).value == 2
    assert NonLocal(3).value == 3



# Generated at 2022-06-21 22:01:44.056705
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5


# Generated at 2022-06-21 22:01:51.342436
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure our module is 'lazy', and doesn't actually get imported
    make_lazy('lazy_module_test')
    assert not 'lazy_module_test' in sys.modules

    # Now let's access an attribute on it and make sure it gets imported
    from lazy_module_test import hello
    assert hello == 'world'

    # Make sure it doesn't show up as a lazy module anymore
    assert not isinstance(sys.modules['lazy_module_test'], _LazyModuleMarker)

# Generated at 2022-06-21 22:02:05.384644
# Unit test for function make_lazy
def test_make_lazy():

    # create a example module called 'foo.bar', containing a function 'bar'
    sys_module_orig = sys.modules
    sys.modules = copy(sys.modules)

    try:
        sys.modules['foo'] = types.ModuleType('foo')
        sys.modules['foo.bar'] = types.ModuleType('foo.bar')
        sys.modules['foo.bar'].bar = lambda: 'bar'
    finally:
        sys.modules = sys_module_orig

    import foo.bar
    assert foo.bar.bar() == 'bar'

    make_lazy('foo.bar')

    # import foo.bar did not import it
    assert not hasattr(foo, 'bar')
    # the first access to attribute 'bar' will import it
    assert foo.bar.bar() == 'bar'
    # and then

# Generated at 2022-06-21 22:02:14.891314
# Unit test for function make_lazy
def test_make_lazy():
    import types
    # Make it lazy
    make_lazy('make_lazy')
    # Test that we can import it
    import make_lazy
    assert isinstance(make_lazy, types.ModuleType)
    assert make_lazy.__name__ == 'make_lazy'
    # Test that we get the same reference
    # to the module after importing it twice
    import make_lazy
    assert isinstance(make_lazy, types.ModuleType)
    assert make_lazy.__name__ == 'make_lazy'
    # Test that it really is lazy
    del sys.modules['make_lazy']
    make_lazy.test_make_lazy()
    import make_lazy
    assert sys.modules['make_lazy'] == make_lazy
    # Test that it is a

# Generated at 2022-06-21 22:02:19.227896
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = 'blah'
    nonLocal = NonLocal(value)

    assert nonLocal.value == value

# Generated at 2022-06-21 22:02:21.141680
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(2)
    assert x.value == 2
    assert x.value == 2


# Generated at 2022-06-21 22:02:28.425484
# Unit test for function make_lazy
def test_make_lazy():
    import os

    # Make sure that the os module has already been imported.
    assert os
    sys.modules.pop('os')
    assert 'os' not in sys.modules
    assert not isinstance(os, _LazyModuleMarker)

    make_lazy('os')
    assert 'os' in sys.modules
    assert isinstance(os, _LazyModuleMarker)
    assert not isinstance(os, ModuleType)

    # Make sure that we can still get attributes off of the os object.
    assert os.path.exists(__file__)


# Tests module in test_make_lazy
if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:02:30.233605
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 22:02:38.485912
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    import sys

    def _clean(mod):
        if mod in sys.modules:
            del sys.modules[mod]

    _clean('test_make')
    _clean('test_make.lazy')

    # Python 2.6 doesn't have the modules attribute
    # on sys.modules
    if hasattr(sys.modules, 'modules'):
        del sys.modules.modules

    import test_make
    assert 'test_make' in sys.modules
    assert 'test_make.lazy' not in sys.modules

    test_make.lazy
    assert 'test_make.lazy' in sys.modules
    assert sys.modules['test_make.lazy'] is test_make.lazy



# Generated at 2022-06-21 22:02:41.079487
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy('django.core.files.storage')
    assert isinstance(mod, _LazyModuleMarker)
    mod.FileSystemStorage

# Generated at 2022-06-21 22:02:45.747214
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import pytest

    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        _LazyModuleMarker()  # pylint: disable=abstract-class-instantiated


# Generated at 2022-06-21 22:02:48.140405
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mlm = _LazyModuleMarker()
    assert isinstance(mlm, _LazyModuleMarker)
    assert isinstance(mlm, object)


# Generated at 2022-06-21 22:02:54.166798
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    make_lazy("mypath")
    seq = sys.modules['mypath']
    assert isinstance(seq, _LazyModuleMarker)

# Generated at 2022-06-21 22:02:56.119791
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()



# Generated at 2022-06-21 22:03:00.515064
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class TestModule(NonLocal):
        def __init__(self):
            super(TestModule, self).__init__("Hello World")

        def get_value(self):
            return self.value

    test_module = TestModule()
    assert test_module.get_value() == "Hello World"

# Generated at 2022-06-21 22:03:02.616932
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker.__class__.__name__ == "LazyModuleMarker"


# Generated at 2022-06-21 22:03:12.729795
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import os
    from unittest import TestCase
    from subprocess import Popen, PIPE

    class TestLazyLoading(TestCase):
        def test_make_lazy_works(self):
            module_name = 'test_lazy_loading_works'

            # prepare a file to be imported
            with open('%s.py' % module_name, 'w') as f:
                f.write('time.sleep(0.5)\n'
                        'print "i have been imported"\n'
                        'value = 0\n')

            # init a simple subprocess to import it

# Generated at 2022-06-21 22:03:20.680471
# Unit test for function make_lazy
def test_make_lazy():
    import inspect
    mod_name = 'test_make_lazy_module'
    module_path = 'make_lazy'
    assert module_path not in sys.modules

    make_lazy(module_path)
    assert module_path in sys.modules
    assert not inspect.ismodule(sys.modules[module_path])

    def import_mod():
        import make_lazy as mod
        return mod

    mod = import_mod()
    assert inspect.ismodule(mod)
    assert isinstance(mod, _LazyModuleMarker)
    assert not inspect.ismodule(sys.modules[module_path])
    assert mod.__name__ == module_path
    assert mod.__package__ == mod_name
    assert mod.__file__.endswith('.pyc')

# Generated at 2022-06-21 22:03:27.630421
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 22:03:34.810626
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['tests.module'] = None
    make_lazy('tests.module')

    mod = sys.modules['tests.module']
    assert isinstance(mod, _LazyModuleMarker)
    assert getattr(mod, '__name__') == 'tests.module'
    assert getattr(mod, 'conf', None) == 'This is set in the module'


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:03:36.712489
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(2)
    v.value = 1
    assert(v.value == 1)

# Generated at 2022-06-21 22:03:44.737497
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Proxy(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (Proxy, ModuleType)

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """

# Generated at 2022-06-21 22:03:57.234476
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # make sure it can be a base class
    class MyClass(_LazyModuleMarker):
        pass
    # make sure it can't be instantiated
    try:
        # noinspection PyArgumentList
        _LazyModuleMarker()
        assert False
    except TypeError:
        pass



# Generated at 2022-06-21 22:04:01.596977
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert 'object' in _LazyModuleMarker().__mro__()
    assert _LazyModuleMarker().__mro__() == (LazyModule, ModuleType, object)
    assert trues(isinstance(LazyModule, ModuleType))
    assert trues(isinstance(_LazyModuleMarker(), LazyModule))


# Generated at 2022-06-21 22:04:13.761421
# Unit test for function make_lazy
def test_make_lazy():

    # Import a module
    import json
    # Should have a __version__
    assert(hasattr(json, '__version__'))
    # Add a field to json module
    json.foo = 'bar'

    # Now make it lazy
    make_lazy('json')
    # The json module unloaded from sys.modules
    assert('json' not in sys.modules)
    # It should still be accessible
    assert(hasattr(json, '__version__'))
    # The field added above should still be available
    assert(json.foo == 'bar')

# Example of using a lazy module
if __name__ == "__main__":

    # Make json lazy
    make_lazy('json')


# Generated at 2022-06-21 22:04:24.005232
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f(x):
        y = x+1
        def g():
            z = y*2
            def h():
                t = z+x
                return t
            return h()
        return g()

    print(f(2)) # Outputs 6
    # We can use the NonLocal class to create a function
    # that is almost identical to f, but instead of taking an
    # argument x to f, it takes an object of class NonLocal
    def f_nonlocal(nonlocal_x):
        y = nonlocal_x.value+1 # Notice the use of nonlocal_x.value
        def g():
            z = y*2
            def h():
                t = z+nonlocal_x.value
                return t
            return h()
        return g()
    # We can then use this function with a non

# Generated at 2022-06-21 22:04:25.799175
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(make_lazy('unicodedata'), _LazyModuleMarker))

test__LazyModuleMarker()

# Generated at 2022-06-21 22:04:33.044299
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A:
        pass

    def func(x):
        pass

    lazy = _LazyModuleMarker()

    # _LazyModuleMarker inherits from object
    assert isinstance(lazy, object)
    # _LazyModuleMarker is an instance of _LazyModuleMarker
    assert isinstance(lazy, _LazyModuleMarker)
    # _LazyModuleMarker is not an instance of module
    assert isinstance(lazy, ModuleType) is False

    # _LazyModuleMarker is an instance of LazyModule
    assert isinstance(lazy, LazyModule)
    # _LazyModuleMarker is not a subclass of LazyModule
    assert issubclass(_LazyModuleMarker, LazyModule) is False

    # _LazyModuleMarker is not an instance of A

# Generated at 2022-06-21 22:04:34.615044
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()


# Generated at 2022-06-21 22:04:38.379049
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Testing for constructor of class _LazyModuleMarker
    """
    # Check it's a class
    assert isinstance(_LazyModuleMarker, type), "not a class"



# Generated at 2022-06-21 22:04:39.619784
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal("abc")
    assert n.value == "abc"

# Generated at 2022-06-21 22:04:41.220628
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    if not isinstance(_LazyModuleMarker(), object):
        raise RuntimeError

test__LazyModuleMarker()

# Generated at 2022-06-21 22:05:04.862522
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = ModuleType('test', 'Test Module')
    assert isinstance(module, _LazyModuleMarker) is False

    # We do not need to instantiate class _LazyModuleMarker
    # because it is only a marker and does not define any
    # attributes nor method.
    # module_marker = _LazyModuleMarker()
    # assert isinstance(module_marker, _LazyModuleMarker) is True



# Generated at 2022-06-21 22:05:06.344584
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This unit test will test the constructor of class _LazyModuleMarker
    """
    test = _LazyModuleMarker()
    assert(test)


# Generated at 2022-06-21 22:05:18.390824
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import ok_, eq_
    from ... import _LazyModuleMarker
    ok_("_LazyModuleMarker" in globals())
    x = _LazyModuleMarker()
    ok_(isinstance(x, _LazyModuleMarker))
    ok_(not isinstance(x, type))
    ok_(not isinstance(x, object))
    ok_(not isinstance(x, list))
    ok_(not isinstance(x, tuple))
    ok_(not isinstance(x, dict))
    ok_(not isinstance(x, str))
    ok_(not isinstance(x, unicode))
    ok_(not isinstance(x, bool))
    ok_(not isinstance(x, int))
    ok_(not isinstance(x, float))
    ok_(not isinstance(x, file))


# Generated at 2022-06-21 22:05:26.630757
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import json  # this should fail because json is lazy
        assert False, 'Expected an exception'
    except ImportError:
        pass

    # Now, json is lazy
    make_lazy('json')
    assert isinstance(json, _LazyModuleMarker)

    # But json is still importable
    import json  # noqa

    # And we can access it's attributes.
    assert isinstance(json.loads('{}'), dict)

    # Re-importing should just get us the same module instance
    import json as json2  # noqa
    assert json2 is json


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:05:30.142386
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test for constructor of class _LazyModuleMarker
    """
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 22:05:32.313707
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    print(a.value)
    a.value = 4
    print(a.value)


# Generated at 2022-06-21 22:05:35.305553
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)


# Generated at 2022-06-21 22:05:38.666289
# Unit test for function make_lazy
def test_make_lazy():
    import datetime

    # Test that the function runs without error.
    make_lazy('datetime')
    assert isinstance(datetime, _LazyModuleMarker)

    # Test that the module is imported upon first use
    assert datetime.datetime.today()



# Generated at 2022-06-21 22:05:40.441050
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    nl.value = 69
    assert nl.value == 69

test_NonLocal()


# Generated at 2022-06-21 22:05:42.743158
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None
    x.value = 'something'
    assert x.value == 'something'


# Generated at 2022-06-21 22:06:21.588641
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_val = NonLocal(1)
    assert nonlocal_val.value == 1



# Generated at 2022-06-21 22:06:26.021193
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 22:06:35.861221
# Unit test for function make_lazy
def test_make_lazy():
    def test_lazy_import():
        make_lazy('_test_lazy_import')

        return importlib.import_module('_test_lazy_import')

    class TestLazyImport(unittest.TestCase):
        def test_lazy_module_is_lazy(self):
            lazy_module = test_lazy_import()
            self.assertEquals(lazy_module.__name__, '_test_lazy_import')
            self.assertTrue(isinstance(lazy_module, _LazyModuleMarker))

        def test_lazy_module_becomes_non_lazy_after_access(self):
            lazy_module = test_lazy_import()
            self.assertEquals(lazy_module.__name__, '_test_lazy_import')


# Generated at 2022-06-21 22:06:39.054871
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    method = _LazyModuleMarker()
    assert isinstance(method, _LazyModuleMarker)
    assert _LazyModuleMarker().__class__ == _LazyModuleMarker

# Generated at 2022-06-21 22:06:42.775392
# Unit test for constructor of class NonLocal

# Generated at 2022-06-21 22:06:48.093466
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'foo'
    make_lazy(module_name)
    assert module_name not in sys.modules
    assert module_name in sys.modules
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)
    from foo import x
    assert x == 'x'
    assert isinstance(sys.modules[module_name], ModuleType)



# Generated at 2022-06-21 22:06:49.883312
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(isinstance(a,_LazyModuleMarker))


# Generated at 2022-06-21 22:07:01.761557
# Unit test for function make_lazy
def test_make_lazy():
    """
    This should pass.
    """
    def lazy_import():
        try:
            from django.core import serializers
            return False
        except (ImportError, AttributeError):
            return True

    try:
        make_lazy('django.core.serializers')
        assert lazy_import()
        from django.core import serializers
        assert hasattr(serializers, 'serialize')
        assert not lazy_import()
    finally:
        if 'django.core.serializers' in sys.modules:
            del sys.modules['django.core.serializers']

if sys.version_info[0] == 2:
    make_lazy('django.utils.six')
    make_lazy('django.utils.six.moves')


# Generated at 2022-06-21 22:07:03.322067
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()

# Generated at 2022-06-21 22:07:12.099409
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy works.
    """