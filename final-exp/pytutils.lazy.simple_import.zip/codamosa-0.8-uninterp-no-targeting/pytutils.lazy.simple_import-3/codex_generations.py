

# Generated at 2022-06-21 21:57:22.156186
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10, "constructor of NonLocal not working"


# Generated at 2022-06-21 21:57:33.147578
# Unit test for function make_lazy
def test_make_lazy():
    test_module_path = 'tests.test_lazy'

    class Foo(object):
        pass

    def noop_import(name):
        """
        Fake import function for the test.
        """
        return sys.modules[test_module_path]

    # backup sys.modules
    saved_modules = sys.modules.copy()

    sys.modules[test_module_path] = Foo()
    assert test_module_path in sys.modules

    make_lazy(test_module_path)

    # check that the module is now proxy.
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)
    # check that the test_module_path's __name__ is still test_module_path
    assert sys.modules[test_module_path].__name__ == test_module_

# Generated at 2022-06-21 21:57:41.245167
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys.modules['pylazy.tests.tests.test__LazyModuleMarker'] = __import__('pylazy.tests.tests.test__LazyModuleMarker')
    make_lazy('pylazy.tests.tests.test__LazyModuleMarker')
    assert isinstance(sys.modules['pylazy.tests.tests.test__LazyModuleMarker'], _LazyModuleMarker)

# Generated at 2022-06-21 21:57:44.162796
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(value = '42')
    assert nl.value == '42', 'NonLocal constructor failed to set value'


test_NonLocal()

# Generated at 2022-06-21 21:57:54.680076
# Unit test for function make_lazy
def test_make_lazy():
    # Test that the laziness works
    import pymacaroons
    # We know the secret key is not None because we have it hardcoded.
    # The secret key is the only thing which is guaranteed to exist
    assert pymacaroons.SECRET_KEY is not None
    # Test that the module can be lazily imported
    make_lazy('pymacaroons')
    # Test that the module can be considered a lazy module
    import pymacaroons
    assert isinstance(pymacaroons, _LazyModuleMarker)
    # Test that other modules are not considered 'lazy'
    assert not isinstance(sys, _LazyModuleMarker)


# If this file is run directly, run self-tests
if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 21:57:55.878271
# Unit test for constructor of class NonLocal

# Generated at 2022-06-21 21:57:58.854295
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(isinstance(a, _LazyModuleMarker))
    assert(isinstance(a, ModuleType))


# Generated at 2022-06-21 21:58:02.169572
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 21:58:05.159195
# Unit test for function make_lazy
def test_make_lazy():
    assert 'lazy_test' not in sys.modules
    make_lazy('lazy_test')
    assert isinstance(sys.modules['lazy_test'], _LazyModuleMarker)

# Generated at 2022-06-21 21:58:09.442319
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModule = _LazyModuleMarker("LazyModule", (object,), {})
    assert sys.modules is not None,\
        "sys.modules is None, please check if import modules properly"
    sys.modules["LazyModule"] = LazyModule
    isinstance(LazyModule, _LazyModuleMarker)
    assert isinstance(sys.modules["LazyModule"], _LazyModuleMarker)

# Generated at 2022-06-21 21:58:16.138780
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import datetime
    # First, put the module into sys.modules to simulate it being imported
    sys.modules['datetime'] = datetime
    # Next, we overwrite the module to be our lazy type
    make_lazy('datetime')
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)
    # Next, we access an attribute, which causes the module to be imported
    assert sys.modules['datetime'].date is datetime.date
    # Finally, we ensure that the module was imported
    assert sys.modules['datetime'] is datetime

# Generated at 2022-06-21 21:58:18.530959
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests that _LazyModuleMarker does not fail when created
    """
    marker = _LazyModuleMarker()


# Generated at 2022-06-21 21:58:28.785642
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Tester(object):
        def __init__(self):
            self.var = {} # Creating a instance variable

        def test(self):
            nonlocal_var = NonLocal('test nonlocal')
            self.var['test_nonlocal'] = nonlocal_var
            assert(nonlocal_var.value == self.var['test_nonlocal'].value)
            nonlocal_var.value = 'new test nonlocal'
            assert(nonlocal_var.value == self.var['test_nonlocal'].value)
            nonlocal_var.value = 'another test nonlocal'
            assert(nonlocal_var.value == self.var['test_nonlocal'].value)
    tester = Tester()
    tester.test()



# Generated at 2022-06-21 21:58:32.848758
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test(x):
        nonlocal_val = NonLocal(x)

        def test_nonlocal():
            nonlocal_val.value = nonlocal_val.value + 1
            return nonlocal_val.value
        return test_nonlocal
    t = test(1)
    assert 2 == t()
    assert 3 == t()


# Generated at 2022-06-21 21:58:36.517629
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10
    nl.value = 20
    assert nl.value == 20


# Generated at 2022-06-21 21:58:44.450536
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    logger = logging.getLogger(__name__)

    class test_NonLocal(object):
        """
        A test class for NonLocal class
        """

        def __init__(self):
            self.test = "test"

    nonlocal_test = NonLocal(test_NonLocal())

    assert nonlocal_test.value.test == "test"
    logger.info("constructor of class NonLocal is OK")

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-21 21:58:46.962350
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(5)
    assert x.value == 5


# Generated at 2022-06-21 21:58:48.442106
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(a is not None)

# Generated at 2022-06-21 21:58:58.130288
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    A test for the constructor of class _LazyModuleMarker
    """
    module_path = "tests.lazy_module"
    make_lazy(module_path)
    lazy_module = sys.modules[module_path]
    # test if `lazy_module` is a LazyModule object
    assert(isinstance(lazy_module, _LazyModuleMarker))
    # test if `lazy_module` is just a standin for a module
    assert(not callable(lazy_module))
    # test if none of the attributes are present in `lazy_module`
    try:
        lazy_module.attr1
        assert(False)
    except AttributeError:
        pass


# Generated at 2022-06-21 21:58:59.661657
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker       # It is hard to test anything else


# Generated at 2022-06-21 21:59:03.782305
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 21:59:07.665579
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test for initialization
    lazy = _LazyModuleMarker()
    assert lazy is not None, "Failed to initilize _LazyModuleMarker()"
    return True



# Generated at 2022-06-21 21:59:19.181217
# Unit test for function make_lazy
def test_make_lazy():
    import random  # this module is real
    import os  # this module is faked
    import math  # this module is faked

    if 'os' in sys.modules:
        del sys.modules['os']
    if 'math' in sys.modules:
        del sys.modules['math']

    sys.modules['random'] = random
    make_lazy('os')
    make_lazy('math')

    def get_module(path):
        return sys.modules[path]

    assert( isinstance(get_module('os'), _LazyModuleMarker) )
    assert( isinstance(get_module('math'), _LazyModuleMarker) )
    assert( isinstance(get_module('random'), ModuleType) )


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 21:59:21.363468
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    assert a.value == 0


# Generated at 2022-06-21 21:59:32.624816
# Unit test for function make_lazy
def test_make_lazy():
    # sys.modules MUST be cleared before the test is run.
    # Otherwise, older tests will leave entries around,
    # causing this test to fail.
    if 'random' in sys.modules:
        del sys.modules['random']

    def check_random():
        import sys
        # The random module should NOT be imported yet
        assert 'random' not in sys.modules
        # It should be a class of type LazyModule
        assert isinstance(sys.modules['random'], _LazyModuleMarker)

    check_random()

    # TODO: find a more elegant way to do the above test
    #
    # The test above is currently fragile. If the random module
    # is in the scope of this module we will have a false positive.
    # (It won't be lazy because it is already in the scope.)
    #
   

# Generated at 2022-06-21 21:59:42.122373
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import pytest
    sys.modules['test_test_make_lazy'] = None

    test_path = 'test_test_make_lazy'
    test_file = '/tmp/test_test_make_lazy.py'
    with open(test_file, 'w') as f:
        f.write('def some_func():\n\treturn "Hello World"')

    try:
        make_lazy(test_path)
        import test_test_make_lazy
        assert test_test_make_lazy is not None
        assert test_test_make_lazy.__file__ == test_file
        assert test_test_make_lazy.some_func() == "Hello World"
    finally:
        os.remove(test_file)
        # Cannot

# Generated at 2022-06-21 21:59:45.015714
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("test")
    assert nl.value == "test"


# Generated at 2022-06-21 21:59:47.901378
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lazy = _LazyModuleMarker()
    assert isinstance(lazy, _LazyModuleMarker) is True


# Generated at 2022-06-21 21:59:49.535870
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local_value = NonLocal(5)
    assert local_value.value == 5


# Generated at 2022-06-21 21:59:53.761282
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2
    del nl
    assert "nl" not in locals().keys()

# Generated at 2022-06-21 22:00:10.704926
# Unit test for function make_lazy
def test_make_lazy():
    def is_lazy(module):
        """
        Checks if a module is lazy.
        """
        mod_type = type(module)
        return isinstance(mod_type, _LazyModuleMarker)

    # Don't actually pull the module in.
    make_lazy('tests.make_lazy')

    import tests.make_lazy  # noqa: F401
    assert is_lazy(tests.make_lazy)

    import tests.make_lazy  # noqa: F401
    assert is_lazy(tests.make_lazy)

    # Using import directly should make it not lazy.
    from tests.make_lazy import is_lazy  # noqa: F401
    import tests.make_lazy  # noqa: F401

# Generated at 2022-06-21 22:00:12.122173
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1



# Generated at 2022-06-21 22:00:19.583764
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that this function actually can mark a module as 'lazy'.
    """
    import imp, os

    # If this test fails, it means that the current directory is
    # the same as another directory called test_make_lazy.
    # That is a pretty ridiculous directory name, so this should
    # be a valid assumption.
    assert __name__ == '__main__', '__name__ == %r' % (__name__,)

    # Create a module in the current directory
    f = open('test_make_lazy.py', 'w')
    f.write('Var = 42\n')
    f.close()

    import test_make_lazy

    # Test that it is not lazy

# Generated at 2022-06-21 22:00:25.643358
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    class NewLazyModuleMarker(_LazyModuleMarker):
        def __init__(self, path):
            self.path = path
            self.__dict__ = sys.modules[self.path].__dict__

    a = NewLazyModuleMarker('__main__')
    a.x = 1
    print(a.x)

# Generated at 2022-06-21 22:00:31.957498
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    # Manually add a module that hasn't been loaded yet
    sys.modules["fake_module"] = None

    # Check that make_lazy makes the module lazy
    make_lazy("fake_module")
    assert isinstance(sys.modules["fake_module"], _LazyModuleMarker)

    # Clean up
    del sys.modules["fake_module"]

# Generated at 2022-06-21 22:00:42.706474
# Unit test for function make_lazy
def test_make_lazy():
    # Make a module called 'fake_module' and then import it
    sys.modules['fake_module'] = ModuleType('fake_module')

    from lazy_module import fake_module
    assert isinstance(fake_module, _LazyModuleMarker)

    # Now load the 'fake_module'
    module = fake_module.__getattribute__('__mro__')()
    assert isinstance(module, ModuleType)

    # Check that the real module is actually in sys.modules
    assert isinstance(sys.modules['fake_module'], ModuleType)

    # Check that loading the module twice has no effect
    fake_module.__getattribute__('__mro__')()
    assert isinstance(sys.modules['fake_module'], ModuleType)

    # Clean up after ourselves
    del sys.modules['fake_module']



# Generated at 2022-06-21 22:00:45.391296
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = 7
    assert nl.value == 7


# Generated at 2022-06-21 22:00:47.142641
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert module is not None



# Generated at 2022-06-21 22:00:48.802805
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert isinstance(module, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:51.364283
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    dummy_module = _LazyModuleMarker()
    assert not isinstance(dummy_module, ModuleType)
    assert isinstance(dummy_module, _LazyModuleMarker)


# Generated at 2022-06-21 22:01:12.750269
# Unit test for function make_lazy
def test_make_lazy():
    """
    A test for make_lazy
    """
    # Assign a variable to a module
    # This variable should remain unchanged when the module gets reloaded
    make_lazy('time')
    var = time.time()

    # Test that the module is in our lazy state
    assert isinstance(time, _LazyModuleMarker)

    # Test that the variable is still set to the original value
    assert var == time.time()

    # Test that the module can be used like a regular module
    time.sleep(1)

# Generated at 2022-06-21 22:01:14.266284
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 22:01:24.117522
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit tests for function make_lazy.
    """
    # setup
    module_path = 'my_fake_module'
    my_fake_module = 'my_fake_module'

    # pre checks
    assert not hasattr(sys.modules, module_path)

    # action
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert not hasattr(sys.modules[module_path], my_fake_module)

    # verify
    sys.modules[module_path].my_fake_module = my_fake_module
    assert hasattr(sys.modules[module_path], my_fake_module)
    assert sys.modules[module_path].my_fake_module == my_fake_module

# Generated at 2022-06-21 22:01:35.211924
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    module_path = 'test_module'

    class TestModule(object):

        def __eq__(self, other):
            return isinstance(other, TestModule)

        def __getattribute__(self, attr):
            return None

    sys.modules[module_path] = TestModule()
    make_lazy(module_path)

    assert not isinstance(sys.modules[module_path], TestModule)
    assert sys.modules[module_path] == TestModule()

    sys.modules[module_path]

    assert isinstance(sys.modules[module_path], TestModule)
    assert sys.modules[module_path] == TestModule()

# Generated at 2022-06-21 22:01:48.814993
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    import sys, os
    import tempfile

    def make_file(name, contents):
        path = os.path.join(temp_dir, name)
        with open(path, "w") as f:
            f.write(contents)
        return path

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 22:01:52.059905
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Simulate nonlocal keyword in Python2
    t = NonLocal(None)
    assert t.value is None
    t.value = 123
    assert t.value == 123
    assert t.value is 123

# Generated at 2022-06-21 22:02:01.575550
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the constructor and the methods of the class _LazyModuleMarker

    :return:
    """
    # Class _LazyModuleMarker
    assert isinstance(_LazyModuleMarker, object)
    print("\tClass _LazyModuleMarker")
    print("\t\tMethods: ")
    for attr in dir(_LazyModuleMarker):
        print("\t\t\t{0}".format(attr))
    print("\t\tAttributes: ")
    for attr in dir(_LazyModuleMarker):
        print("\t\t\t{0}".format(attr))


# Generated at 2022-06-21 22:02:10.271262
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():

    class ExtendedLazyModule(_LazyModuleMarker):
        pass

    class NotExtendedLazyModule():
        pass

    # Create instance of class _LazyModuleMarker
    my_lazy_module = _LazyModuleMarker()

    # Test that instance is an instance of class _LazyModuleMarker
    assert isinstance(my_lazy_module, _LazyModuleMarker)

    # Test that instance is an instance of its subclass
    assert isinstance(my_lazy_module, ExtendedLazyModule)

    # Create instance of subclass
    my_extended_lazy_module = ExtendedLazyModule()

    # Test that instance is an instance of class _LazyModuleMarker
    assert isinstance(my_extended_lazy_module, _LazyModuleMarker)

    # Test that subclass instance is an instance

# Generated at 2022-06-21 22:02:16.363332
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Testing NonLocal constructor.
    """
    try:
        non_local = NonLocal(None)
        non_local.value = 3
        assert non_local.value == 3
    except AttributeError:
        assert False, "test_NonLocal failed"



# Generated at 2022-06-21 22:02:17.906636
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker


# Generated at 2022-06-21 22:02:47.323388
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    instance = _LazyModuleMarker();
    assert(instance);
    

# Generated at 2022-06-21 22:02:52.125343
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert lazy_module.__mro__() == (_LazyModuleMarker, ModuleType)



# Generated at 2022-06-21 22:02:59.799583
# Unit test for function make_lazy
def test_make_lazy():
    # Mock sys.modules
    sys.modules = {}

    make_lazy('sys')
    # A lazy module is not loaded yet
    assert 'sys' not in sys.modules

    # A lazy module is loaded when you call one of its functions
    try:
        sys.getrefcount(2)
    except AttributeError:
        pass
    assert 'sys' in sys.modules

    # A lazy module of the same name has been loaded
    assert isinstance(sys.modules['sys'], ModuleType)

# Generated at 2022-06-21 22:03:01.066347
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    '''
    unit test for constructor of class _LazyModuleMarker
    '''
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-21 22:03:01.874343
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10

# Generated at 2022-06-21 22:03:02.676660
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()



# Generated at 2022-06-21 22:03:12.813598
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import shutil
    from tempfile import mkdtemp

    # Make a temporary module
    tmp_dir = mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.py')
    with open(tmp_file, 'w') as f:
        f.write('foo = "bar"')

    # Make the module lazy, accessing it should import it.
    make_lazy(os.path.splitext(os.path.basename(tmp_file))[0])
    assert sys.modules['test'].__class__.__name__ == 'LazyModule'
    assert sys.modules['test'].foo == 'bar'

    # Cleanup
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-21 22:03:17.400925
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test constructor
    try:
        mark = _LazyModuleMarker()
    except:
        assert False, "_LazyModuleMarker constructor not implmented"
    # Test superclass of _LazyModuleMarker
    if _LazyModuleMarker.__bases__[0] != object:
        assert False, "_LazyModuleMarker does not inherit from object"


# Generated at 2022-06-21 22:03:21.088038
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    a.value = 100
    assert a.value == 100
    a.value = 10
    assert a.value == 10


# Generated at 2022-06-21 22:03:32.176926
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import django
    except ImportError:
        raise SkipTest("Django not found")

    from django.core.exceptions import ImproperlyConfigured
    from django.conf import settings

    # Test that this raises an ImportError
    try:
        from django.conf import settings
        raise Exception("Should not have imported this")
    except ImportError:
        pass

    # Set up a lazy import
    make_lazy('django.conf')
    assert isinstance(sys.modules['django.conf'], _LazyModuleMarker)

    # We need to access the module to trigger the import
    # (this is what django's code needs)
    import django.conf

    # Test that this module is now available

# Generated at 2022-06-21 22:04:39.619082
# Unit test for function make_lazy
def test_make_lazy():
    # Should be able to import make_lazy without triggering django
    import vumi.persist.txredis_manager  # NOQA
    # Should also be able to 'import vumi.persist' without triggering django
    import vumi.persist  # NOQA
    # Should be able to 'from vumi.persist import model' without triggering django
    from vumi.persist import model  # NOQA

# Generated at 2022-06-21 22:04:41.216355
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)



# Generated at 2022-06-21 22:04:44.243752
# Unit test for function make_lazy
def test_make_lazy():
    import os

    assert not isinstance(os, _LazyModuleMarker)
    assert os.path == sys.modules['os.path']

    make_lazy('os.path')
    assert isinstance(os, _LazyModuleMarker)
    assert os.path == sys.modules['os.path']


# Generated at 2022-06-21 22:04:48.403251
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    assert not hasattr(sys.modules['os'], 'path')
    assert 'os.path' not in sys.modules

    # Should not have to import module
    assert hasattr(os, 'path')
    assert 'os.path' in sys.modules

    # After import, should be the same module
    path_module = os.path

    assert 'os.path' in sys.modules
    assert os.path is path_module

    # Cleanup
    del sys.modules['os.path']
    del sys.modules['os']


# Adapted from: http://stackoverflow.com/questions/4094628

# Generated at 2022-06-21 22:04:49.370384
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import random
    sys.modu

# Generated at 2022-06-21 22:04:55.164475
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the make_lazy function works as expected.
    """
    import datetime
    make_lazy('datetime')

    # Make sure that our LazyModule is not a subclass of the actual type
    assert not isinstance(datetime, ModuleType)

    # Now lazy import the module
    datetime.datetime.now()

    # Check that our LazyModule is now a LazyModule
    assert isinstance(datetime, ModuleType)

# Generated at 2022-06-21 22:04:58.179143
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    def test():
        nonlocal a
        a = NonLocal(3)
        assert a.value == 3
    test()
    assert a.value == 3


# Generated at 2022-06-21 22:04:59.779373
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local_var = NonLocal(0)
    assert(local_var.value == 0)


# Generated at 2022-06-21 22:05:00.509781
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NonLocal(3)
    return True

# Generated at 2022-06-21 22:05:02.154444
# Unit test for constructor of class NonLocal