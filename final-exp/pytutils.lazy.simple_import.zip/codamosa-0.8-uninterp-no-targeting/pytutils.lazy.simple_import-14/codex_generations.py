

# Generated at 2022-06-21 21:57:28.456925
# Unit test for function make_lazy
def test_make_lazy():
    # Test that an unknown module is added to sys.modules as a LazyModule
    # and it doesn't raise an exception
    make_lazy("does_not_exist")
    assert("does_not_exist" in sys.modules)
    assert(isinstance(sys.modules["does_not_exist"], _LazyModuleMarker))
    # Test that we can't import a lazy module
    with pytest.raises(ImportError):
        import does_not_exist
    # Test that we can import a lazy module after importing it once using
    # attribute lookup
    sys.modules["does_not_exist"].__getattribute__("does_not_exist")
    import does_not_exist

# Generated at 2022-06-21 21:57:33.208652
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print(isinstance(_LazyModuleMarker, type))
    print(isinstance(_LazyModuleMarker, object))
    print(isinstance(_LazyModuleMarker, ModuleType))


# Generated at 2022-06-21 21:57:36.220050
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('sys'), _LazyModuleMarker)



# Generated at 2022-06-21 21:57:40.961637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class LazyModuleMarker(_LazyModuleMarker):
        pass

    assert issubclass(LazyModuleMarker, _LazyModuleMarker)
    assert isinstance(LazyModuleMarker(), _LazyModuleMarker)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:57:43.056988
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Verify constructor
    x = NonLocal(43)
    assert x.value == 43


# Generated at 2022-06-21 21:57:45.061314
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local = NonLocal(1)
    assert local.value == 1
    local.value = 2
    assert local.value == 2



# Generated at 2022-06-21 21:57:47.414921
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal("this is a test")
    assert t.__class__.__name__ == "NonLocal"
    assert t.value == "this is a test"


# Generated at 2022-06-21 21:57:49.434645
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal.
    """
    class_object = NonLocal(100)
    assert class_object.value == 100


# Generated at 2022-06-21 21:57:51.606617
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker.__class__.__name__ == '_LazyModuleMarker'


# Generated at 2022-06-21 21:57:53.887962
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonloc = NonLocal(3)
    assert nonloc.value == 3

    # Setters and getters for object attribute
    nonloc.value = 5
    assert nonloc.value == 5

# Generated at 2022-06-21 21:57:59.186111
# Unit test for constructor of class NonLocal
def test_NonLocal():
    print("Testing NonLocal constructor")
    x = NonLocal(1)
    assert x.value == 1


# Generated at 2022-06-21 21:58:00.793668
# Unit test for constructor of class NonLocal
def test_NonLocal():
    _test = NonLocal('value')
    assert _test.value == 'value'

# Generated at 2022-06-21 21:58:09.742727
# Unit test for function make_lazy
def test_make_lazy():
    # Unit test for function make_lazy
    import sys
    import random
    import string

    # Random module name
    module_name = "".join(
        random.choice(string.ascii_uppercase + string.digits)
        for _ in range(12)
    )
    path = "test.test_module_utils.test_make_lazy." + module_name

    # Ensure it is not in sys.modules
    assert path not in sys.modules

    # Create the test module
    path_obj = path.split(".")
    init_path = ".".join(path_obj[:-1])
    package_init = """
try:
    from . import %s
except ImportError:
    pass
""" % path_obj[-1]

# Generated at 2022-06-21 21:58:13.738627
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that classes are correctly created
    """
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)
    assert _LazyModuleMarker.__mro__ == (object,)

# Generated at 2022-06-21 21:58:24.843347
# Unit test for function make_lazy
def test_make_lazy():
    """
    Simple test to ensure make_lazy works as expected.
    """
    import os

    # Save the original state
    orig_sys_modules = sys.modules.copy()
    orig_os = os

    # Make os lazy
    make_lazy('os')

    import os  # noqa F401

    # Ensure os is lazy
    assert isinstance(os, _LazyModuleMarker)
    assert not orig_os is os

    # Ensure 'original' os is still there
    assert 'os' in sys.modules
    assert orig_os is orig_sys_modules['os']

    # Ensure sys.modules is still the same
    assert sys.modules == orig_sys_modules

    # Ensure os has a non-lazy copy
    os.path
    assert 'os' in sys.modules
    assert orig_os

# Generated at 2022-06-21 21:58:28.647173
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)
    assert isinstance(marker, object)
    assert not isinstance(marker, ModuleType)
    assert not isinstance(marker, int)



# Generated at 2022-06-21 21:58:34.510947
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy'] = ModuleType('test_make_lazy')
    try:
        make_lazy('test_make_lazy')

        module = sys.modules['test_make_lazy']
        assert module.__name__ == 'test_make_lazy'
        module.foo = 'bar'
        assert getattr(module, 'foo') == 'bar'
        assert isinstance(module, _LazyModuleMarker)

    finally:
        del sys.modules['test_make_lazy']

# Generated at 2022-06-21 21:58:45.366947
# Unit test for function make_lazy
def test_make_lazy():
    # make sure that this module doesn't exist
    try:
        del sys.modules['tests.unit.test_lazy_module']
    except KeyError:
        pass

    # mark it as lazy
    make_lazy('tests.unit.test_lazy_module')

    # Check that the lazy module was created
    assert 'tests.unit.test_lazy_module' in sys.modules

    # Check the type of the module
    our_mod = sys.modules['tests.unit.test_lazy_module']
    assert isinstance(our_mod, _LazyModuleMarker)
    assert not isinstance(our_mod, ModuleType)

    # Import the module, to make sure it's working.
    import tests.unit.test_lazy_module  # NOQA

    # Check that we now have the right type

# Generated at 2022-06-21 21:58:50.889944
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    sys.modules.pop('test_lazy', None)

    make_lazy('test_lazy')

    assert sys.modules['test_lazy']

    assert not hasattr(sys.modules['test_lazy'], '__file__')

    import test_lazy

    assert sys.modules['test_lazy'] is test_lazy

# Generated at 2022-06-21 21:58:53.532025
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    b = NonLocal(123)
    c = NonLocal('I\'m fine')
    a.value = 123
    b.value = 'I\'m fine'
    # simulated nonlocal keyword in Python 3
    print(a.value)
    print(b.value)
    print(c.value)


# Generated at 2022-06-21 21:59:08.892088
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for make_lazy function
    """
    # -------------------------------------------------------------------------
    def _mod_import_check(module_path):
        """
        Asserts the module `module_path` is _not_ in sys.modules yet
        """
        assert module_path not in sys.modules, \
            'Module {} should not be imported yet.'.format(module_path)

    # -------------------------------------------------------------------------
    def _mod_import_check2(module_path):
        """
        Asserts the module `module_path` _is_ in sys.modules
        """
        assert module_path in sys.modules, \
            'Module {} should be imported.'.format(module_path)

    # -------------------------------------------------------------------------

    module_prefix = 'test_lazy_module'
    module_path_1 = '{}_1'.format

# Generated at 2022-06-21 21:59:12.475532
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(None)
    assert nonlocal_obj.value == None
    nonlocal_obj.value = 'foo'
    assert nonlocal_obj.value == 'foo'

# Generated at 2022-06-21 21:59:13.421563
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker)


# Generated at 2022-06-21 21:59:15.038597
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nsl_obj = NonLocal(23)
    assert nsl_obj.value == 23


# Generated at 2022-06-21 21:59:17.430452
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal("hey")
    assert var.value == "hey"

# Generated at 2022-06-21 21:59:24.652155
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    import sys
    import tables
    import operator
    import math
    import numpy.core.numeric as ncnumeric


# Generated at 2022-06-21 21:59:28.286624
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    make_lazy('datetime')
    assert isinstance(datetime, _LazyModuleMarker)
    assert isinstance(datetime.datetime, datetime.datetime)

# Generated at 2022-06-21 21:59:29.233826
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert "_LazyModuleMarker object" == str(_LazyModuleMarker())


# Generated at 2022-06-21 21:59:32.539858
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test constructor
    # use constructor to create a NonLocal object
    nl = NonLocal("fakeValue")
    assert nl.value == "fakeValue", "NonLocal does not have correct value"

test_NonLocal()


# Generated at 2022-06-21 21:59:34.006552
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-21 21:59:44.266583
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class LazyModule(_LazyModuleMarker):
        pass
    assert hasattr(LazyModule, '__mro__')

# Generated at 2022-06-21 21:59:47.681587
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_nonlocal = NonLocal(25)
    assert test_nonlocal.value == 25
    test_nonlocal.value = 5
    assert test_nonlocal.value == 5


# Generated at 2022-06-21 21:59:50.843212
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class LazyModule1(_LazyModuleMarker):
        pass
    lazy_module1 = LazyModule1()
    assert isinstance(lazy_module1, _LazyModuleMarker)
    assert isinstance(lazy_module1, ModuleType)


# Generated at 2022-06-21 21:59:55.574938
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    lm.lazymodulemarker = 'lazymodulemarker'
    assert lm.lazymodulemarker == 'lazymodulemarker'



# Generated at 2022-06-21 22:00:02.324611
# Unit test for function make_lazy
def test_make_lazy():
    import tests

    # function make_lazy, no arguments
    make_lazy('tests.foobar1')
    assert sys.modules['tests.foobar1'] is not None
    assert isinstance(sys.modules['tests.foobar1'], tests.foobar1.__class__) is False

    try:
        # function make_lazy, arguments
        make_lazy('tests.foobar2')
        assert sys.modules['tests.foobar2'] is not None
        assert isinstance(sys.modules['tests.foobar2'], tests.foobar2.__class__) is False
    except ImportError:
        pass   # This is ok, as foobar2 is not a module



# Generated at 2022-06-21 22:00:04.674630
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker.__dict__ == {}

# Generated at 2022-06-21 22:00:06.035555
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert x is not None

# Generated at 2022-06-21 22:00:13.131223
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import shutil
    import tempfile
    from .. import lazy_import

    test_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(test_dir, 'test_modules'))
    with open(os.path.join(test_dir, 'test_modules', '__init__.py'), 'w') as fp:
        fp.write('# test\n')
    with open(os.path.join(test_dir, 'test_modules', 'foo.py'), 'w') as fp:
        fp.write('# test\n')

    old_sys_path = sys.path
    old_sys_modules = sys.modules
    sys.path = [test_dir]
    sys.modules = {}

    test_lazy_import = lazy_

# Generated at 2022-06-21 22:00:13.989699
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert a


# Generated at 2022-06-21 22:00:17.260002
# Unit test for function make_lazy
def test_make_lazy():
    # Test the basic functionality
    make_lazy('xmodule.tests.test_lazymodule.foo')
    assert 'xmodule.tests.test_lazymodule.foo' in sys.modules
    assert isinstance(sys.modules['xmodule.tests.test_lazymodule.foo'], _LazyModuleMarker)
    assert not hasattr(sys.modules['xmodule.tests.test_lazymodule.foo'], '__mro__')
    assert not hasattr(sys.modules['xmodule.tests.test_lazymodule.foo'].__class__, '__mro__')

    # Test that it doesn't cause an infinite loop when used together.
    make_lazy('xmodule.tests.test_lazymodule.bar')

    # Test that a lazy module is not actually imported until needed.
    import x

# Generated at 2022-06-21 22:00:41.317927
# Unit test for function make_lazy
def test_make_lazy():
    from nose.tools import assert_equal, assert_false, assert_true

    # This is the module we need to use as a test case.
    class ModuleA(object):
        pass

    # This is the module we want to replace with a lazy module.
    class ModuleB(object):
        pass

    # This is the module that imports and uses ModuleB, triggering the import
    class ModuleC(object):
        def get_lazy_module(self):
            return ModuleB

    # Setup
    sys_modules = sys.modules.copy()
    sys.modules['module_a'] = ModuleA()
    sys.modules['module_b'] = ModuleB()
    sys.modules['module_c'] = ModuleC()

    # Mark module_b as lazy
    module_b_path = 'module_b'
    make_lazy

# Generated at 2022-06-21 22:00:42.667848
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(object())
    assert nonlocal_.value is not None

# Generated at 2022-06-21 22:00:46.319964
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker, type)
    assert issubclass(_LazyModuleMarker, object)
    assert _LazyModuleMarker() is _LazyModuleMarker


# Generated at 2022-06-21 22:00:50.226778
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class _TestClass(NonLocal):
        is_cls = True

    non_local = NonLocal(123)
    assert non_local.value == 123

    cls = _TestClass(321)
    assert cls.value == 321
    assert cls.is_cls == True


# Generated at 2022-06-21 22:00:51.077045
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-21 22:01:01.765397
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if sys.version_info >= (3, 0):
        pass
    else:
        # Use the 2to3 generated code
        from __future__ import absolute_import

# Generated at 2022-06-21 22:01:04.424825
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    x.value = 5
    assert x.value == 5



# Generated at 2022-06-21 22:01:11.988119
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'tests.lazy_test'

    make_lazy(module_path)

    # Check if sys.modules doesn't contain our module.
    assert module_path not in sys.modules

    import tests.lazy_test
    assert tests.lazy_test.success is True
    assert module_path in sys.modules

# Generated at 2022-06-21 22:01:14.993244
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)


# Generated at 2022-06-21 22:01:17.211844
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    assert a.value == 2


# Generated at 2022-06-21 22:01:55.542787
# Unit test for function make_lazy
def test_make_lazy():
    """
    A simple unit test to ensure that make_lazy works.
    """
    import random
    import sys

    module_path = "random"

    # Remove module_path from sys.modules if it exists
    if module_path in sys.modules:
        del sys.modules[module_path]

    # Make sure the module is not imported
    assert not sys.modules.has_key(module_path)

    # Tags the module as lazy
    make_lazy(module_path)

    # The module is not imported
    assert sys.modules.has_key(module_path)
    assert sys.modules[module_path] is not random

    # Invoke an attribute off the module
    randint = random.randint
    assert randint is not None

    # The module is now loaded
    assert sys.modules.has_

# Generated at 2022-06-21 22:02:05.797739
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os
    import sys
    import inspect
    import tempfile
    # Create a temporary test script
    (fd, path) = tempfile.mkstemp(suffix='.py')
    fd = os.fdopen(fd, "w")
    fd.write('from types import ModuleType\n')
    fd.write('class T(ModuleType):\n')
    fd.write('    pass\n')
    fd.write('t = T()\n')
    fd.close()
    # Import it
    modulename = os.path.basename(path)
    modulename = os.path.splitext(modulename)[0]
    sys.path.insert(0, os.path.dirname(path))
    loaded_module = __import__(modulename)
   

# Generated at 2022-06-21 22:02:10.510107
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal('this is a nonlocal')
    assert nl1.value == 'this is a nonlocal'

    assert nl1.value == nl1.value

# Generated at 2022-06-21 22:02:12.743108
# Unit test for function make_lazy
def test_make_lazy():
    # A module named 'test_make_lazy' is not expected to exist
    make_lazy('test_make_lazy')
    assert 'test_make_lazy' not in sys.modules

# Generated at 2022-06-21 22:02:15.610283
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None

# Generated at 2022-06-21 22:02:18.550946
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test
    my_var = NonLocal(3)
    assert my_var.value == 3
    
if __name__=='__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:02:22.188157
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("tests.lazy")
    import tests.lazy as lazy

    assert isinstance(lazy, _LazyModuleMarker)
    assert lazy.TEST == "TEST"

# Generated at 2022-06-21 22:02:22.912328
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() == _LazyModuleMarker()


# Generated at 2022-06-21 22:02:24.194209
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(RuntimeError):
        _LazyModuleMarker()


# Generated at 2022-06-21 22:02:34.446407
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'foo.bar'

    def mock_import_module(name):
        if name == module_path:
            return None, [], []

    def mock_getattribute(self, attr):
        if attr == '__spec__':
            return None
        raise AttributeError()

    # monkey patch __import__
    old_import = builtins.__import__
    builtins.__import__ = mock_import_module
    # monkey patch LazyModule to raise.
    old_getattribute = LazyModule.__getattribute__
    LazyModule.__getattribute__ = mock_getattribute
    # Check

# Generated at 2022-06-21 22:03:38.932766
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(ModuleType('a'), _LazyModuleMarker)
    assert not isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(NonLocal(1), _LazyModuleMarker)
    assert not isinstance(LazyModule(), _LazyModuleMarker)
    assert isinstance(module.value, NonLocal)

# Generated at 2022-06-21 22:03:45.695481
# Unit test for function make_lazy
def test_make_lazy():
    from codegen.defaults import ENABLED
    from codegen.defaults import set_option
    # Enable code generation
    set_option('CODE_GENERATION', ENABLED)

    import codegen.defaults
    from codegen.defaults import _LazyModuleMarker
    from codegen.defaults import _write_file

    assert LazyModuleMarker == _LazyModuleMarker

    # Check that codegen.defaults is a LazyModule
    assert isinstance(codegen.defaults, _LazyModuleMarker)

    # Check that we get the correct exception when attr is not found
    try:
        codegen.defaults.i_am_not_an_attr
    except AttributeError:
        pass
    else:
        assert False, "AttributeError should have been raised"

   

# Generated at 2022-06-21 22:03:47.227117
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    l = _LazyModuleMarker()
    assert l is not None


# Generated at 2022-06-21 22:03:49.204760
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10


# Generated at 2022-06-21 22:03:51.345707
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(10).value == 10



# Generated at 2022-06-21 22:03:53.660089
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker=_LazyModuleMarker()
    # assert( isinstance(marker,_LazyModuleMarker)==True )

# Generated at 2022-06-21 22:03:58.879448
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy('os.path')

    assert isinstance(os.path, _LazyModuleMarker)

    # The module should now be imported
    assert os.path.abspath is not None

    make_lazy('os')

    # Even though we have already imported os.path, os should be a lazy module
    # because we have just set it as lazy.
    assert isinstance(os, _LazyModuleMarker)

# Generated at 2022-06-21 22:04:02.067422
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test for constructor of class NonLocal
    """
    nonlocal_keyword = NonLocal("Python 2")
    assert nonlocal_keyword.value is "Python 2"

make_lazy("harpy.test_lazy_import")

# Generated at 2022-06-21 22:04:05.707334
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert(isinstance(mod, _LazyModuleMarker))
    assert(_LazyModuleMarker == type(mod))


# Generated at 2022-06-21 22:04:07.237597
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(22).value == 22


# Generated at 2022-06-21 22:06:35.584792
# Unit test for function make_lazy
def test_make_lazy():
    import __builtin__
    from os import path
    make_lazy('os.path')

    assert sys.modules['os.path'] is not None
    assert isinstance(sys.modules['os.path'], _LazyModuleMarker)

    from os import path
    assert path is not None
    assert isinstance(path, ModuleType)
    assert path is sys.modules['os.path']


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:06:39.426605
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        cls = _LazyModuleMarker()
    except Exception as err:
        logging.info('Error in class constructor!')
        print(str(err))


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:06:42.256357
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test normal import
    import django
    # test lazy import
    make_lazy("logging")
    logging   # noqa


# Generated at 2022-06-21 22:06:46.054384
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test of NonLocal class and updating of __slots__
    """
    n = NonLocal(3)
    assert n.value == 3
    n.value = 6
    assert n.value == 6

    print("test_NonLocal: OK")


# Generated at 2022-06-21 22:06:48.199658
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal('__init__')
    assert nonlocal_value.value == '__init__'



# Generated at 2022-06-21 22:06:57.505702
# Unit test for function make_lazy
def test_make_lazy():
    assert not hasattr(sys.modules, 'lazy_module')
    make_lazy('lazy_module')
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)
    assert not hasattr(sys.modules['lazy_module'], 'a')
    sys.modules['lazy_module'].a = 1
    assert hasattr(sys.modules['lazy_module'], 'a')
    assert sys.modules['lazy_module'].a == 1
    assert isinstance(sys.modules['lazy_module'], ModuleType)
    del sys.modules['lazy_module']

# Generated at 2022-06-21 22:07:00.243294
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    assert(nl.value == 123)
    nl.value = 456
    assert(nl.value == 456)



# Generated at 2022-06-21 22:07:10.474337
# Unit test for function make_lazy
def test_make_lazy():
    # Can't run this test. Importing the test module will trigger
    # all of the top level import statements, and importing the
    # test module is necessary to run the tests.
    if __name__ == '__main__':
        return

    import os
    sys.modules['os'] = NonLocal(None)
    make_lazy('os')

    assert os.path is None
    assert 'os' in sys.modules

    from os import path
    assert path is not None
    assert sys.modules['os'].path is path

    # Check for correct non-importing behavior
    sys.modules.pop('os')
    os = sys.modules['os'] = NonLocal(None)
    make_lazy('os')

    path = os.path
    assert path is not None

# Generated at 2022-06-21 22:07:21.375972
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    test_module_name = 'test_module'
    test_module_path = test_module_name + '.py'

    f = open(test_module_path, 'w')
    f.write('# This is a test module\n\n')
    f.write('test_var = \'test variable\'')
    f.close()

    sys.modules.pop(test_module_name, None)

    make_lazy(test_module_name)

    # test that module is not in system
    assert test_module_name not in sys.modules.keys()

    # test that our lazy module is in system
    assert test_module_name in sys.modules.keys()

    # test that we can't access vars in our module