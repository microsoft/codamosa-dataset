

# Generated at 2022-06-21 21:57:20.814689
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    return True


# Generated at 2022-06-21 21:57:33.045855
# Unit test for function make_lazy
def test_make_lazy():
    from .test.test_make_lazy import TestLazyModule  # noqa: F401
    import tests.test_make_lazy  # noqa: F401
    assert isinstance(tests.test_make_lazy, _LazyModuleMarker)
    assert TestLazyModule.test() == 'OK'


# Non-lazy imports
from .dynd import nd, ndt, dispatch as dynd_dispatch  # noqa: F401
from .dynd import _lowlevel as lowlevel  # noqa: F401
from .dynd import ndarray  # noqa: F401
from .dynd import ndoffset  # noqa: F401
from .dynd import ndpointer  # noqa: F401
from .dynd import ndt_type  # noqa: F401

# Generated at 2022-06-21 21:57:36.245075
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # compare the Result of NonLocal.value with 3
    x = NonLocal(3)
    assert x.value == 3

# Generated at 2022-06-21 21:57:39.863853
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2

# Generated at 2022-06-21 21:57:51.517744
# Unit test for function make_lazy
def test_make_lazy():
    import test_lazy_module.marker
    import test_lazy_module.module
    import test_lazy_module.attributes  # pylint: disable=unused-variable
    import test_lazy_module.imports  # pylint: disable=unused-variable
    import test_lazy_module.nested  # pylint: disable=unused-variable
    import test_lazy_module.nested.attributes  # pylint: disable=unused-variable
    import test_lazy_module.nested.imports  # pylint: disable=unused-variable
    assert test_lazy_module.module.init_count == 1
    assert test_lazy_module.marker.module_init_count == 1
    assert test_lazy_module.nested.module

# Generated at 2022-06-21 21:57:58.851095
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
      
    sys.modules['__main__'].__nonlocal__ = NonLocal(1234)

    #print("__main__.__nonlocal__.value is: " + str(__main__.__nonlocal__.value))
    #print("__main__.__nonlocal__.value is: " + str(__main__.__nonlocal__.value))

    #sys.modules['__main__'].__nonlocal__.value = 5678
    #print("__main__.__nonlocal__.value is: " + str(__main__.__nonlocal__.value))

    #print("__main__.__nonlocal__.value is: " + str(__main__.__nonlocal__.value))

# testing for lazy module

# Generated at 2022-06-21 21:58:01.356565
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = 2
    test_nl = NonLocal(test_value)
    assert test_value == test_nl.value


# Generated at 2022-06-21 21:58:03.198550
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Test case"""
    obj = _LazyModuleMarker()
    assert obj



# Generated at 2022-06-21 21:58:06.144022
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('__main__')
    assert 'test_make_lazy' not in sys.modules
    test_make_lazy.value = 'test'
    assert test_make_lazy.value == 'test'
    assert 'test_make_lazy' in sys.modules



# Generated at 2022-06-21 21:58:07.027255
# Unit test for constructor of class NonLocal
def test_NonLocal():
    z = NonLocal(42)
    assert z.value == 42


# Generated at 2022-06-21 21:58:11.513325
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-21 21:58:16.397593
# Unit test for function make_lazy
def test_make_lazy():
    import os
    module_path = "os"
    make_lazy(module_path)
    assert isinstance(os, NonLocal), \
           f"Instance of os is not NonLocal it is {type(os)}"
    assert isinstance(os.path, _LazyModuleMarker),\
           f"Instance of os.path is not {_LazyModuleMarker} it is {type(os.path)}"
    assert isinstance(os.path.abspath, object),\
           f"Instance of os.path.abspath is not object it is {type(os.path.abspath)}"
    assert not isinstance(os.path.abspath, NonLocal),\
           f"Instance of os.path.abspath is NonLocal"

# Generated at 2022-06-21 21:58:20.376531
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class test(object):
        pass
    lazy = _LazyModuleMarker()
    assert(isinstance(lazy, _LazyModuleMarker))
    assert(not isinstance(lazy, test))
    assert(not isinstance(lazy, object))



# Generated at 2022-06-21 21:58:21.819350
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('Foo')
    assert nl.value == 'Foo'

# Generated at 2022-06-21 21:58:24.892449
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert isinstance(NonLocal(1), NonLocal)
    assert hasattr(NonLocal(1), 'value')
    assert NonLocal(1).value == 1


# Generated at 2022-06-21 21:58:26.425409
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    result = make_lazy(module_path)
    assert result

# Generated at 2022-06-21 21:58:28.097028
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_NonLocal = NonLocal(True)
    assert test_NonLocal.value


# Generated at 2022-06-21 21:58:36.097083
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    def __mro__(self):
        return (LazyModule, ModuleType)

    def __getattribute__(self, attr):
        return getattr(module.value, attr)

    def __init__(self, module_path, sys_modules):
        self.module_path = module_path
        self.sys_modules = sys_modules
        self.module = NonLocal(None)

    LazyModule = _LazyModuleMarker()
    LazyModule.__init__ = __init__
    LazyModule.__mro__ = __mro__
    LazyModule.__getattribute__ = __getattribute__

    sys_modules = {}
    LazyModule(module_path='tests.__init__', sys_modules=sys_modules)
    assert 'tests.__init__' in sys_modules




# Generated at 2022-06-21 21:58:39.516107
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_type = _LazyModuleMarker()
    assert isinstance(test_type, _LazyModuleMarker)
    assert not isinstance(test_type, ModuleType)


# Generated at 2022-06-21 21:58:42.157484
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(None)
    assert(value.value is None)
    value.value = "foo"
    assert(value.value == "foo")


# Generated at 2022-06-21 21:58:47.455882
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_test = NonLocal(1)
    assert nonlocal_test.value == 1


# Generated at 2022-06-21 21:58:49.794109
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(1)
    assert nonlocal_value.value == 1

make_lazy('django.db.backends')

# Generated at 2022-06-21 21:58:52.228000
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal(5)
    assert var.value == 5, "Constructor of class NonLocal not working"


# Generated at 2022-06-21 21:58:53.064546
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()


# Generated at 2022-06-21 21:58:54.099457
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 21:58:55.559384
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker, '__mro__')



# Generated at 2022-06-21 21:59:00.022350
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert not issubclass(_LazyModuleMarker, ModuleType)
    assert not issubclass(_LazyModuleMarker, type)
    assert not issubclass(_LazyModuleMarker, LazyModule)


# Generated at 2022-06-21 21:59:01.981540
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-21 21:59:09.944465
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests `make_lazy` to ensure that the module is not loaded until
    an attribute is needed off it.
    """

    # Note, there is a race condition in this test function, but it is
    # a good enough approximation for our usecase.
    def save_print_statements(print_func):
        """
        Save the contents of `print_func` in a list and return it.
        """
        print_lines = []

        def put_lines(*args, **kwargs):
            print_lines.extend(args)
        return print_lines, put_lines

    real_print, real_print_func = save_print_statements(print)


# Generated at 2022-06-21 21:59:13.005821
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker.
    """
    # No exception raised
    assert(_LazyModuleMarker())


# Generated at 2022-06-21 21:59:25.819432
# Unit test for function make_lazy
def test_make_lazy():
    import os
    assert os is not None  # to satisfy my ide
    make_lazy('os')
    assert os is not None
    assert isinstance(os, _LazyModuleMarker)
    assert os.path.join('a', 'b') == 'a/b'
    assert os.path.join('a', 'b') == 'a/b'
    assert isinstance(os, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:28.610067
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    if a.value != 1:
        print('test_NonLocal for NonLocal class failed')

test_NonLocal()

# Generated at 2022-06-21 21:59:34.142568
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class TestClass(object):
        def __init__(self):
            self.value = NonLocal(None)
        def __call__(self, new_value):
            self.value = new_value
    test_class = TestClass()
    assert test_class.value.value is None
    test_class("New value")
    assert test_class.value.value == "New value"
    

# Generated at 2022-06-21 21:59:35.878136
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(TypeError):
        _LazyModuleMarker()



# Generated at 2022-06-21 21:59:38.013589
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert False


# Generated at 2022-06-21 21:59:39.468300
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    M = _LazyModuleMarker()
    assert type(M) == type(_LazyModuleMarker())

# Generated at 2022-06-21 21:59:47.413001
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the lazy module creation works.
    """
    make_lazy('hello')

    import hello
    assert isinstance(hello, _LazyModuleMarker)
    # We can still import this module
    from hello import world
    assert world() == 'hello world'
    # But we don't have to!
    assert hello.world() == 'hello world'

# Generated at 2022-06-21 21:59:50.160181
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def foo():
        bar = NonLocal(3)

# Generated at 2022-06-21 21:59:53.567710
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert not issubclass(object, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:03.925203
# Unit test for function make_lazy
def test_make_lazy():
    try:
        class LazyModule(_LazyModuleMarker):
            class A:
                pass

        make_lazy(LazyModule)
        assert isinstance(LazyModule, _LazyModuleMarker)
    finally:
        if 'LazyModule' in sys.modules:
            del sys.modules['LazyModule']

    try:
        class LazyModule(_LazyModuleMarker):
            class A:
                def b(self):
                    pass

            def c(self):
                pass
        make_lazy(LazyModule)
        assert isinstance(LazyModule, _LazyModuleMarker)
    finally:
        if 'LazyModule' in sys.modules:
            del sys.modules['LazyModule']

# Generated at 2022-06-21 22:00:28.422840
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the function make_lazy
    """
    import test_module

    make_lazy('test_module')

    assert id(test_module) == id(sys.modules['test_module'])
    assert str(test_module) == str(sys.modules['test_module'])
    assert isinstance(test_module, _LazyModuleMarker)
    assert not isinstance(test_module, ModuleType)
    assert test_module.__name__ == 'test_module'
    assert repr(test_module) == repr(sys.modules['test_module'])

    # Make sure it works with multiple modules
    import re
    make_lazy('re')
    assert isinstance(re, ModuleType)
    assert not isinstance(re, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:34.031793
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        make_lazy('examples.test')
        import examples.test
        assert isinstance(examples.test, _LazyModuleMarker)
    except:
        print ('test__LazyModuleMarker failed')
        return

    print ('test__LazyModuleMarker succeeded')


# Generated at 2022-06-21 22:00:35.429156
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    assert x.value == 42

# Generated at 2022-06-21 22:00:36.579266
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-21 22:00:39.394992
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_var = NonLocal("")

    if not test_var.value == "":
        print("Failed test constructor of class NonLocal")



# Generated at 2022-06-21 22:00:42.284919
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class LazyModule(_LazyModuleMarker):
        pass

    # Pass the test if the constructor is defined correctly
    dummy = LazyModule()

# Generated at 2022-06-21 22:00:43.098517
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker


# Generated at 2022-06-21 22:00:47.231474
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    print(a)
    b = make_lazy("this_is_lazy")
    print(b)

if __name__ == "__main__":
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:00:51.887921
# Unit test for function make_lazy
def test_make_lazy():
    # Test loading of a module with a common Python package name
    sys.modules['foo.bar'] = None
    make_lazy('foo.bar')
    assert isinstance(sys.modules['foo.bar'], _LazyModuleMarker)
    assert not hasattr(sys.modules['foo.bar'], '__file__')


# Once the unit test is completed, delete the function
del test_make_lazy

# Generated at 2022-06-21 22:01:02.369595
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    test_mod = 'os'
    assert test_mod in sys.modules, (
        'os should be in sys.modules')

    make_lazy(test_mod)

    assert isinstance(sys.modules[test_mod], ModuleType), (
        'make_lazy should mark the module as a module')

    assert sys.modules[test_mod] == os, (
        'make_lazy should not change the value of the sys.modules entry')

    assert not hasattr(sys.modules[test_mod], 'path'), (
        'The module should not have any attributes at the beginning')

    path = os.path
    assert isinstance(sys.modules[test_mod], ModuleType), (
        'The module instance should still be a module after attributes'
        'are fetched')


# Generated at 2022-06-21 22:01:38.198741
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import pytest
    from types import ModuleType

    test_module = NonLocal(None)
    sys.modules['test_module'] = test_module
    assert sys.modules['test_module'] is not None
    assert sys.modules['test_module'] is test_module

    # 1. module is not None.
    test_module.value = ModuleType('test_module')
    assert sys.modules['test_module'].value is not None
    assert sys.modules['test_module'].value is sys.modules['test_module']
    # 2. module is not a module.
    test_module.value = ModuleType('test_module')
    with pytest.raises(TypeError):
        sys.modules['test_module'].value = ModuleType('test_module')

# Generated at 2022-06-21 22:01:41.958074
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value == None
    a.value = 'abc'
    assert a.value == 'abc'


# Generated at 2022-06-21 22:01:46.592331
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test():
        x = NonLocal(10)
        y = NonLocal(20)
        z = x
        assert x == z
        assert x != y
        return x

    x = test()
    assert isinstance(x, NonLocal)
    assert x.value == 10



# Generated at 2022-06-21 22:01:50.434222
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _lazymodule_marker = _LazyModuleMarker()
    assert isinstance(_lazymodule_marker, _LazyModuleMarker)
    assert issubclass(type(_lazymodule_marker), object)


# Generated at 2022-06-21 22:02:02.520336
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('test_make_lazy_module', None)

    try:
        sys.modules['test_make_lazy_module']

        assert(False)
    except KeyError:
        pass

    make_lazy('test_make_lazy_module')

    assert(isinstance(sys.modules['test_make_lazy_module'], _LazyModuleMarker))

    try:
        sys.modules['test_make_lazy_module'].DEFAULT_SENTINEL
        assert(False)
    except  AttributeError as e:
        pass

    sys.modules['test_make_lazy_module'].DEFAULT_SENTINEL = '_'

    assert('_' == sys.modules['test_make_lazy_module'].DEFAULT_SENTINEL)



# Generated at 2022-06-21 22:02:12.457549
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy
    """
    import sys
    import logging
    import time
    logging.basicConfig(level=logging.DEBUG,
    format='%(asctime)s %(levelname)s %(filename)s %(message)s',
    datefmt='%Y/%m/%d %H:%M:%S')
    logger = logging.getLogger(__name__)

    module_path = 'lazy'
    def calc():
        ret = 0
        for i in range(10000):
            ret += i
        return ret

    if module_path in sys.modules:
        del sys.modules[module_path]

    # make_lazy(module_path)
    import lazy
    t1 = time.time()
    print(lazy.calc())

# Generated at 2022-06-21 22:02:18.339786
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test test_LazyModuleMarker
    """
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-21 22:02:27.966834
# Unit test for function make_lazy
def test_make_lazy():
    # Clear the sys.modules cache
    sys.modules.pop('foo', None)

    module_path = 'foo'

    make_lazy(module_path)

    assert sys.modules[module_path]

    # Check that ModuleType isn't loaded into foo
    # This is coming soon (this tests broke today)
    # with pytest.raises(AttributeError):
    #     sys.modules[module_path].ModuleType

    # Check that the module was loaded
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert isinstance(sys.modules[module_path], ModuleType)
    assert 'foo' in sys.modules

    # Check that the module was fully loaded when we call sys.modules[module_path]
    assert 'ModuleType' in sys.modules[module_path].__dict

# Generated at 2022-06-21 22:02:37.049737
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure our lazy module is compatible with `isinstance`
    """
    make_lazy('test')
    mod = sys.modules['test']
    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)

    assert not hasattr(mod, '__mro__')
    assert not hasattr(mod, '__getattribute__')
    assert not hasattr(mod, '__dict__')
    assert not hasattr(mod, '__name__')

    assert not hasattr(mod, '__doc__')
    assert not hasattr(mod, '__file__')
    assert not hasattr(mod, '__path__')


# Generated at 2022-06-21 22:02:48.367167
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        class B(object):
            class C(object):
                pass

    # Invalid cases
    try:
        make_lazy(None)
    except:
        pass
    else:
        assert False

    try:
        make_lazy(123)
    except:
        pass
    else:
        assert False

    # Valid cases
    try:
        make_lazy("A.B.C")

    except:
        assert False
    else:
        assert True

    try:
        import A.B.C

        assert not isinstance(A.B.C, _LazyModuleMarker)
    except:
        assert False

    # Reimporting an already imported module should not turn it into a LazyModule
    make_lazy("A.B.C")

# Generated at 2022-06-21 22:03:56.376556
# Unit test for function make_lazy
def test_make_lazy():
    # Arrange
    make_lazy("pip.utils.lazy_module")

    # Act
    import pip.utils

    # Assert
    assert isinstance(pip.utils.lazy_module, _LazyModuleMarker)

    # Act
    # import module recursively
    from pip.utils import lazy_module

    # Assert
    assert isinstance(pip.utils.lazy_module, ModuleType)
    assert not isinstance(pip.utils.lazy_module, _LazyModuleMarker)
    assert lazy_module.__name__ == "pip.utils.lazy_module"


# Generated at 2022-06-21 22:03:57.997862
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_marker = _LazyModuleMarker()
    # print(lazy_marker)
    return True

# Generated at 2022-06-21 22:03:59.622650
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    assert "module_path" in sys.modules


# Generated at 2022-06-21 22:04:02.566830
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-21 22:04:04.231509
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-21 22:04:07.131946
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        n = NonLocal(1)
    except AttributeError:
        assert(False)
    else:
        assert(n.value == 1)


# Generated at 2022-06-21 22:04:15.202158
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    make_lazy('os')
    assert type(sys.modules['os']) == sys.modules['dynamic_imports'].LazyModule
    assert sys.modules['os'].path == os.path
    assert isinstance(sys.modules['os'], sys.modules['dynamic_imports'].LazyModule)

    # Ensure the new module was imported on a second retrieval.
    assert sys.modules['os'].path == os.path
    assert sys.modules['os'] == os
    assert type(sys.modules['os']) == type(os)

# Generated at 2022-06-21 22:04:17.197544
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert isinstance(test, _LazyModuleMarker)


# Generated at 2022-06-21 22:04:20.453567
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 22:04:22.048474
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-21 22:06:52.248989
# Unit test for function make_lazy
def test_make_lazy():
    import os
    # save the current module
    current_module = sys.modules[__name__]
    sys.modules[__name__] = ModuleType(__name__)
    # test the code
    make_lazy(__name__)
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)
    with pytest.raises(AttributeError):
        sys.modules[__name__].os
    assert sys.modules[__name__].os is os
    assert sys.modules[__name__].os is os
    # restore the current module
    sys.modules[__name__] = current_module

# Generated at 2022-06-21 22:06:54.626245
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test case 1: a primitive type
    a = NonLocal("aaa")
    assert a.value == "aaa"

    # Test case 2: a list
    a = NonLocal(["aaa", "bbb"])
    assert a.value == ["aaa", "bbb"]


# Generated at 2022-06-21 22:06:58.306859
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal('x')
    assert non_local.value == 'x'

# Unit test of function make_lazy

# Generated at 2022-06-21 22:07:00.594340
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    testing constructor of class NonLocal
    """
    test_nonlocal = NonLocal(1)
    assert test_nonlocal.value == 1

# Generated at 2022-06-21 22:07:03.424450
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2

# Generated at 2022-06-21 22:07:09.161262
# Unit test for function make_lazy
def test_make_lazy():
    # This module is used for testing only
    make_lazy(__name__)

    import pylint.utils
    # Assert that our module is now lazy
    assert isinstance(sys.modules[__name__], pylint.utils._LazyModuleMarker)

    # Finally actually import the module
    sys.modules[__name__].test_make_lazy  # pylint: disable=pointless-statement
    return True

# Generated at 2022-06-21 22:07:10.976834
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        x = _LazyModuleMarker()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 22:07:19.209545
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(0)
    # If the constructor works, we should be able to set the attribute 'value'
    nonlocal_var.value = 1
    assert nonlocal_var.value == 1, "Constructor of class NonLocal is not working"
    nonlocal_var.value = 2
    assert nonlocal_var.value == 2, "Constructor of class NonLocal is not working"
    print(
        "Successfully tested constructor of class NonLocal"
    )
