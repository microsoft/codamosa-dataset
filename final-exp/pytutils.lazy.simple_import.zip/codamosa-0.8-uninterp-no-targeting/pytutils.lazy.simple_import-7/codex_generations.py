

# Generated at 2022-06-21 21:57:17.753513
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(None)
    assert test.value is None


# Generated at 2022-06-21 21:57:21.332293
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal('value')
    assert var.value == 'value'


# Generated at 2022-06-21 21:57:25.357895
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert not issubclass(_LazyModuleMarker, ModuleType)


# Generated at 2022-06-21 21:57:33.945185
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile
    import shutil

    def create_module(module_name, mod_code):
        tempdir = tempfile.mkdtemp()
        try:
            mod_file = os.path.join(tempdir, module_name + '.py')
            with open(mod_file, 'w') as fh:
                fh.write(mod_code)
            if tempdir not in sys.path:
                sys.path.insert(0, tempdir)
            return os.path.join(tempdir, module_name)
        finally:
            shutil.rmtree(tempdir)

    # Make sure our function works for a basic example.
    test_mod = create_module('testmod', '''if True:
        a = 1
        b = 2
    ''')

# Generated at 2022-06-21 21:57:35.558445
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-21 21:57:39.249177
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_obj = _LazyModuleMarker()
    assert(type(test_obj) == _LazyModuleMarker)



# Generated at 2022-06-21 21:57:44.739051
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that the function works as expected.
    """
    assert 'test_lazy' not in sys.modules, 'test_lazy should not be imported'

    make_lazy('test_lazy')

    assert 'test_lazy' in sys.modules, 'test_lazy should be in sys modules'
    assert isinstance(sys.modules['test_lazy'], _LazyModuleMarker), \
        'should be a LazyModule'

    # Try accessing imported module
    assert sys.modules['test_lazy'].__name__ == 'test_lazy'

    assert 'test_lazy' in sys.modules, 'test_lazy should be in sys modules'
    assert isinstance(sys.modules['test_lazy'], ModuleType), \
        'should be a ModuleType'

# Generated at 2022-06-21 21:57:46.822874
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    The constructor of class NonLocal
    """
    nl = NonLocal(12345)
    assert nl.value == 12345



# Generated at 2022-06-21 21:57:51.414719
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker=class_
    LazyModuleMarker.__init__(marker_obj,_LazyModuleMarker)
    assert(isinstance(marker_obj,_LazyModuleMarker))

# Unit Test for constructor of class Make_Lazy

# Generated at 2022-06-21 21:57:52.695084
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    empty = _LazyModuleMarker()


# Generated at 2022-06-21 21:57:57.777347
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Tests the constructor of class NonLocal.
    """
    test_value = 'test'
    nl = NonLocal(test_value)
    assert nl.value == test_value



# Generated at 2022-06-21 21:58:00.693681
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(15)
    assert nl.value == 15
    nl.value = 20
    assert nl.value == 20


# Generated at 2022-06-21 21:58:07.381358
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Use of a closure to simulate the nonlocal keyword from Python 3
    """
    def make_counter():
        """
        Returns a counter function.
        """
        i = NonLocal(0)

        def counter():
            """
            Returns the current count and increments the counter.
            """
            i.value += 1
            return i.value
        return counter

    counter1 = make_counter()
    counter2 = make_counter()

    print(counter1())
    print(counter2())
    print(counter1())



# Generated at 2022-06-21 21:58:09.578236
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert len(_LazyModuleMarker.__slots__) == 0
    assert lazy_module_marker is not None


# Generated at 2022-06-21 21:58:13.298383
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['test_make_lazy'] = None
    sys.modules['test_make_lazy.test_make_lazy'] = None
    make_lazy('test_make_lazy.test_make_lazy')
    assert len(sys.modules) == 1
    assert 'test_make_lazy.test_make_lazy' in sys.modules
    assert type(sys.modules['test_make_lazy.test_make_lazy']) == _LazyModuleMarker

# Generated at 2022-06-21 21:58:14.934347
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-21 21:58:19.350997
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Unit test for _LazyModuleMarker")
    print("_LazyModuleMarker is a type")
    assert(isinstance(_LazyModuleMarker, type))
    print("_LazyModuleMarker is not an instance")
    assert(isinstance(NonLocal, NonLocal) is False)


# Generated at 2022-06-21 21:58:20.757803
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(1)
    assert nonlocal_obj.value == 1

# Generated at 2022-06-21 21:58:31.102970
# Unit test for function make_lazy
def test_make_lazy():
    from os.path import dirname, join, basename
    import sys

    try:
        # Make a fake module and make sure it is lazy
        make_lazy("foo_bar")
        assert isinstance(sys.modules["foo_bar"], _LazyModuleMarker)

        # Hit a fake exception path via a non-existent attribute
        try:
            sys.modules["foo_bar"].this_does_not_exist
        except AttributeError:
            pass

    finally:
        del sys.modules["foo_bar"]


# Generated at 2022-06-21 21:58:33.320577
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)


# Generated at 2022-06-21 21:58:39.675070
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert isinstance(obj, _LazyModuleMarker)


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 21:58:41.077156
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker();
    assert(a)


# Generated at 2022-06-21 21:58:50.103957
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verifies that make_lazy works
    """
    # Check the initial condition
    assert sys.modules["six.moves.queue"] is not None
    # Make sys.modules["six.moves.queue"] be a LazyModule
    make_lazy("six.moves.queue")
    # Check that it is a LazyModule
    assert isinstance(sys.modules["six.moves.queue"], _LazyModuleMarker)
    # Check that the real queue isn't imported yet
    assert "queue" not in sys.modules
    # Check that getattr still works as expected
    assert sys.modules["six.moves.queue"].Queue
    # Check that the real queue module is imported
    assert "queue" in sys.modules
    # Check it is the real queue

# Generated at 2022-06-21 21:58:58.086005
# Unit test for function make_lazy
def test_make_lazy():
    class Foo(object):
        def __init__(self):
            self.a = 1

    class Bar(object):
        def __init__(self):
            self.a = 2

    sys.modules['foo'] = Foo()
    make_lazy('foo')
    make_lazy('bar')
    assert sys.modules['foo'].a == 1, 'foo was not lazily loaded'
    assert sys.modules['bar'].a == 2, 'bar was not lazily loaded'
    assert add_lazy_load_reload_hook('foo') is True, 'foo had already loaded'



# Generated at 2022-06-21 21:59:07.817033
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the __init__ function of _LazyModuleMarker

    Mocks:
        Nothing

    Assertions:
        Nothing
    """
    import sys
    import django

    test = NonLocal(None)
    print(test.value)

    print(sys.modules['django'])

    make_lazy('django')
    print(sys.modules['django'])
    print(sys.modules['django'].__mro__())

    assert isinstance(sys.modules['django'], _LazyModuleMarker)
    assert issubclass(sys.modules['django'], ModuleType)
    print(sys.modules['django'].__name__)
    print(sys.modules['django'].__file__)

# Generated at 2022-06-21 21:59:18.154311
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile

    # make a temporary file to hold the module
    temp_fd, temp_path = tempfile.mkstemp()
    os.close(temp_fd)

    # create the temporary module
    with open(temp_path, 'w') as fp:
        fp.write('x = 3')

    # make a temporary module name with the random name
    name = os.path.basename(temp_path).replace('.py', '')
    sys.path.append(os.path.dirname(temp_path))

    make_lazy(name)

    # cleaning up
    os.remove(temp_path)
    sys.path.pop()
    del sys.modules[name]

# Generated at 2022-06-21 21:59:24.944699
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the make_lazy function works as expected.

    Use the `config` module as a standin.
    """
    import config

    # first test that the module is imported
    assert isinstance(config.foo, bool)

    # reset the module
    del sys.modules['config']
    make_lazy('config')
    assert isinstance(config, _LazyModuleMarker)

    # we haven't imported the module, so we should get an
    # AttributeError when accessing a member.
    with pytest.raises(AttributeError):
        config.foo

    # Now, after assigning a value, the module should have been
    # imported and we should be able to access the value.
    config.foo = 123
    assert isinstance(config.foo, int)
    assert config.foo == 123

    #

# Generated at 2022-06-21 21:59:26.477366
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal(None)
    assert var.value is None



# Generated at 2022-06-21 21:59:30.757839
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    b = NonLocal(2)
    l = [a.value, b.value]
    l_expected = [1, 2]

    assert l == l_expected

# Unit tests for function make_lazy.

# Generated at 2022-06-21 21:59:39.696356
# Unit test for function make_lazy
def test_make_lazy():
    # Create a dummy module on the python path
    module_name = '_temp_'
    sys.path.append(os.path.dirname(__file__))
    test_mod = open(module_name + '.py', 'w')
    test_mod.write('x = 10\n')
    test_mod.close()

    # Basic sanity test
    make_lazy(module_name)
    temp = sys.modules[module_name]
    assert temp.x == 10
    os.remove(module_name + '.pyc')
    os.remove(module_name + '.py')
    del sys.path[-1]

# Generated at 2022-06-21 21:59:48.499141
# Unit test for constructor of class NonLocal
def test_NonLocal():
    o = NonLocal(42)
    assert o.value == 42


# Generated at 2022-06-21 21:59:54.298976
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test Python version
    import sys
    if sys.version_info[0] < 3:
        sys.exit('This test is for Python 3')

    import warnings
    warnings.simplefilter('ignore', DeprecationWarning)

    # Test name
    obj = _LazyModuleMarker()
    assert obj.__name__ == '_LazyModuleMarker'
    assert str(obj) == '<_LazyModuleMarker object>'

    # Test built-in function
    assert hasattr(obj, '__getattribute__')
    assert hasattr(obj, '__mro__')

    # Test method
    assert hasattr(obj, '__getattribute__')

    return


# Generated at 2022-06-21 21:59:55.951583
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker())


# Generated at 2022-06-21 21:59:57.371734
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-21 21:59:59.104141
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Creating NonLocal  object
    a = NonLocal(3)
    assert a.value == 3



# Generated at 2022-06-21 22:00:06.598167
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import sys
        make_lazy("webdriver.firefox")
        lazy_mod = sys.modules["webdriver.firefox"]
        assert isinstance(lazy_mod, _LazyModuleMarker)
        lazy_mod.Firefox()  # should import webdriver.firefox
    finally:
        del sys.modules["webdriver.firefox"]



# Generated at 2022-06-21 22:00:07.939999
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    assert(x.value == 42)

# Generated at 2022-06-21 22:00:12.547735
# Unit test for constructor of class NonLocal
def test_NonLocal():
    _x = NonLocal(None)
    assert _x.value == None
    assert _x.__slots__ == ['value']
    _x = NonLocal(1)
    assert _x.value == 1
    _x = NonLocal('a')
    assert _x.value == 'a'
    _x = NonLocal([1,2,3])
    assert _x.value == [1,2,3]
    _x = NonLocal({'a':'b'})
    assert _x.value == {'a':'b'}

# Generated at 2022-06-21 22:00:14.513716
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3


# Generated at 2022-06-21 22:00:17.806797
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('my_lazy_module')

    mod = sys.modules['my_lazy_module']
    assert mod is not None
    assert isinstance(mod, _LazyModuleMarker), "Lazy Module was not loaded correctly"

    sys.modules['sys'].__getattribute__('')

# Generated at 2022-06-21 22:00:32.942252
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import site
    import datetime
    import sys
    import os

    sys.modules['datetime'] = NonLocal(None)

    make_lazy('datetime')
    assert sys.modules['datetime']
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)
    assert datetime.datetime
    assert not isinstance(datetime, _LazyModuleMarker)
    assert type(datetime) == ModuleType

# Generated at 2022-06-21 22:00:42.351351
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function to make sure it works as expected.
    """
    import copy

    # Copy the sys.modules dict to test with
    sys_modules = copy.deepcopy(sys.modules)
    dummy = 'django_lazy_apps'

    # Test that the new module exists in the sys.modules dict
    assert dummy in sys_modules
    assert isinstance(sys_modules[dummy], _LazyModuleMarker)

    # Test that we can access attributes off of our module
    assert '__name__' in sys_modules[dummy].__dict__

    # Test that the module is now imported
    assert sys_modules[dummy].__name__ == dummy



# Generated at 2022-06-21 22:00:48.935792
# Unit test for function make_lazy
def test_make_lazy():
    from django.conf import settings
    import django.utils

    assert isinstance(settings, (ModuleType, _LazyModuleMarker))
    assert isinstance(django.utils, (ModuleType, _LazyModuleMarker))
    assert not hasattr(settings, '__path__')
    assert not hasattr(django.utils, '__path__')
    assert hasattr(settings, 'DATABASES')
    assert hasattr(django.utils, 'text')

# Generated at 2022-06-21 22:01:00.510879
# Unit test for function make_lazy

# Generated at 2022-06-21 22:01:04.274324
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert(nl.value == 42)


# Generated at 2022-06-21 22:01:07.590940
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(5)
    assert nonlocal_instance.value == 5


# Generated at 2022-06-21 22:01:13.288364
# Unit test for function make_lazy
def test_make_lazy():
    # We are going to import a package which imports the built-in time module
    # in the process. It will happen in the __init__ function.
    make_lazy("tests.import.pkg_import_time")

# Generated at 2022-06-21 22:01:25.379438
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import timeit
    import os

    def check_module(mod):
        import time
        start = time.time()
        mod.check()
        end = time.time()
        return end - start

    print('Testing make_lazy...')
    time.sleep(1)
    print('Slept for a second')
    check_module(time)
    check_module(time)
    check_module(os)
    check_module(os)

    module_name = 'time'
    make_lazy(module_name)
    start = time.time()
    check_module(time)
    end = time.time()
    assert end - start < 0.01
    print('Tests completed successfully')

# Generated at 2022-06-21 22:01:31.195680
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'os'
    if module_path in sys.modules:
        del sys.modules[module_path]

    make_lazy(module_path)

    assert module_path not in sys.modules
    assert os.sep == b'/'
    assert module_path in sys.modules

# Generated at 2022-06-21 22:01:39.540386
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os
    import sys

# Generated at 2022-06-21 22:01:55.978937
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 'test'
    print(nl.value)
    assert nl.value == 'test'


# Generated at 2022-06-21 22:02:06.099892
# Unit test for function make_lazy
def test_make_lazy():
    from django.utils import six

    module_path = 'django.utils.six'
    make_lazy('django.utils.six')

    assert 'django.utils.six' in sys.modules
    assert isinstance(sys.modules['django.utils.six'], _LazyModuleMarker)
    # Test that the module is a lazy module
    assert isinstance(six, _LazyModuleMarker)
    assert not hasattr(six, 'add_metaclass')

    # Test that the module loads when it's attributes are accessed.
    assert callable(six.add_metaclass)
    assert 'django.utils.six' in sys.modules
    # Test that the top level module is an importer
    assert isinstance(sys.modules['django.utils.six'], ModuleType)

    #

# Generated at 2022-06-21 22:02:15.131105
# Unit test for function make_lazy
def test_make_lazy():
    """
    This module contains a test for `make_lazy` and
    is only meant to be run as a script.
    """
    import os
    import sys

    # Setup the test
    mod_name = os.path.join(os.path.dirname(__file__),
                            'test_make_lazy.py')
    attr_name = 'var'
    sys.argv = ['', mod_name, attr_name]

    # Only run if no arguments
    if len(sys.argv) < 3:
        raise RuntimeError('Not called as the second argument to exec.')

    # Grab the arguments and start the test
    mod_name, attr_name = sys.argv[1:]

    # Put the module in sys.path

# Generated at 2022-06-21 22:02:22.060155
# Unit test for function make_lazy
def test_make_lazy():
    _import_before = sys.modules.copy()
    make_lazy('__builtin__')
    _import_after = sys.modules.copy()

    assert _import_before != _import_after
    assert isinstance(sys.modules['__builtin__'], _LazyModuleMarker)

    return sys.modules['__builtin__']

lazy = test_make_lazy()

# Generated at 2022-06-21 22:02:27.747459
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests for make_lazy
    """
    # just another module used for testing
    import sys
    # make module lazy
    make_lazy('sys')
    # check that module name is in sys.modules
    assert 'sys' in sys.modules
    # check that module is lazy
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)
    # check that sys still works
    assert sys.modules['sys'] is sys
    # check that version is still accessible
    assert sys.version is not None

# Generated at 2022-06-21 22:02:35.309657
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function of making a module lazy.
    """

    import os.path
    import os

    cur_path = os.path.dirname(os.path.abspath(__file__))
    print("cur_path: ", cur_path)
    make_lazy("os.path")
    # import os.path
    import sys
    print("sys.modules: ", sys.modules)
    print("sys.modules['os.path']: ", sys.modules['os.path'])
    print("os.path: ", os.path)

# Generated at 2022-06-21 22:02:42.094347
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    some_path = '/a/b/c'
    module = sys.modules.get(some_path)
    if module:
        del sys.modules[some_path]

    make_lazy(some_path)
    assert isinstance(sys.modules[some_path], _LazyModuleMarker)
    assert hasattr(sys.modules[some_path], '__mro__')
    assert hasattr(sys.modules[some_path].__mro__(), _LazyModuleMarker)
    assert isinstance(sys.modules[some_path], ModuleType)

    del sys.modules[some_path]

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:02:43.387535
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Create the NonLocal object
    """
    test_value = 'abc'
    nonlocal_obj = NonLocal(test_value)
    assert nonlocal_obj.value == test_value

# Generated at 2022-06-21 22:02:49.028749
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(4)
    assert n.value == 4
    n.value = 5
    assert n.value == 5
    n2 = NonLocal(n)
    assert n2.value == n
    assert n2.value.value == 5
    n2.value.value = 8
    assert n2.value.value == 8
    assert n.value == 8

# Generated at 2022-06-21 22:02:51.811353
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal(None)
    assert obj.value == None



# Generated at 2022-06-21 22:03:22.383247
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mark = _LazyModuleMarker()
    assert type(mark) is _LazyModuleMarker


# Generated at 2022-06-21 22:03:23.836245
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    sys.stdout.write("NonLocal test passed..\n")

# Generated at 2022-06-21 22:03:31.977777
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert 'value' in NonLocal.__slots__, \
        "NonLocal class should have a value slot"
    assert NonLocal(1).value == 1, \
        "NonLocal class should set value properly"
    assert NonLocal('asdf').value == 'asdf', \
        "NonLocal class should set value properly"
    assert NonLocal([]).value == [], \
        "NonLocal class should set value properly"


# Generated at 2022-06-21 22:03:33.836569
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-21 22:03:38.350892
# Unit test for function make_lazy
def test_make_lazy():
    """
    This verifies that we can use make_lazy to mark a module lazy
    """
    import test_make_lazy_mod
    assert not isinstance(test_make_lazy_mod, _LazyModuleMarker)
    make_lazy('test_make_lazy_mod')
    assert isinstance(test_make_lazy_mod, _LazyModuleMarker)
    assert test_make_lazy_mod.test == 'test'

# Generated at 2022-06-21 22:03:40.710277
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert(isinstance(x, _LazyModuleMarker))

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 22:03:43.258982
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test class constructor
    x = _LazyModuleMarker()
    x.__mro__()
    x.__getattribute__('attr')
if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:03:46.014748
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an instance
    marker = _LazyModuleMarker()

    # Check that __mro__ is not defined
    assert not hasattr(marker, '__mro__')

    # Check that __getattribute__ is not defined
    assert not hasattr(marker, '__getattribute__')

    # Check that == behaves as normal
    assert marker == _LazyModuleMarker()



# Generated at 2022-06-21 22:03:57.104620
# Unit test for function make_lazy
def test_make_lazy():
    assert(module_path == __name__)

    # ensure our test module isn't already loaded in sys.modules
    mod_name = __name__ + ".make_lazy_test"
    mod_path = __name__ + ".make_lazy_test"
    assert(mod_path not in sys.modules)

    # ensure our test module can be imported
    import make_lazy_test

    # mark the module as lazy
    make_lazy(mod_path)

    # ensure the module is in sys.modules
    mod = sys.modules[mod_name]
    assert(isinstance(mod, _LazyModuleMarker))

    # ensure we haven't actually imported the module
    assert(mod_path not in sys.modules)

    # ensure attribute access loads the module
    assert(mod.foo == "foo")

# Generated at 2022-06-21 22:03:58.711157
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(TypeError):
        obj = _LazyModuleMarker('fake')

# Generated at 2022-06-21 22:05:15.378245
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests to make sure that the make_lazy function
    works properly.
    """
    import sys
    import datetime

    # Make sure the datetime module is loaded and in the sys cache
    d = datetime.datetime.now()

    assert d
    assert 'datetime' in sys.modules

    # reset the cache and then mark it as lazy
    sys.modules = {}
    make_lazy('datetime')
    assert 'datetime' not in sys.modules

    # Request for the datetime attribute
    d = datetime.datetime.now()
    assert d

    # Assert that the datetime module is now loaded and in the sys cache
    assert 'datetime' in sys.modules

# Generated at 2022-06-21 22:05:18.740359
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    mod = _LazyModuleMarker()
    equal("_LazyModuleMarker", mod.__class__.__name__)


# Generated at 2022-06-21 22:05:19.740417
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)

# Generated at 2022-06-21 22:05:21.152637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _ = _LazyModuleMarker()


# Generated at 2022-06-21 22:05:22.654095
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    print(a.value)



# Generated at 2022-06-21 22:05:29.405929
# Unit test for function make_lazy
def test_make_lazy():
    import mock
    import sys

    # Check if a lazy module is lazy
    make_lazy('tests.unit.lazy_test_module')
    assert isinstance(sys.modules['tests.unit.lazy_test_module'], _LazyModuleMarker)
    assert isinstance(sys.modules['tests.unit.lazy_test_module'], ModuleType)
    assert not isinstance(sys.modules['tests.unit.lazy_test_module'], object)

    # Check that a lazy module does not import until it is used
    with mock.patch('importlib.import_module') as mock_import_module:
        assert sys.modules['tests.unit.lazy_test_module'].test_function() == 'test'
        assert mock_import_module.called

    # Check that a non-lazy module is

# Generated at 2022-06-21 22:05:31.617313
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker(), '__mro__') and hasattr(_LazyModuleMarker(), '__getattribute__')

# Generated at 2022-06-21 22:05:33.113177
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value == 0


# Generated at 2022-06-21 22:05:41.078431
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy works as a decorator, and that the lazy module
    is properly replaced on demand.
    """

    try:
        @make_lazy
        class TestModule(object):
            lazy = "Test"

        assert isinstance(TestModule, _LazyModuleMarker)
        assert not hasattr(TestModule, "lazy")

        assert TestModule.lazy == "Test"

        assert TestModule.__dict__ == TestModule.__class__.__dict__
    finally:
        del sys.modules['__main__.TestModule']

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-21 22:05:42.501956
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(None)
    assert test.value is None