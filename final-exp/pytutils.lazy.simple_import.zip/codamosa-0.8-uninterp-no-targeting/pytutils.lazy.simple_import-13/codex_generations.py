

# Generated at 2022-06-21 21:57:22.206554
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import logging
    import ctypes
    import time

    make_lazy('temp')

    # Check that we can get the temp module
    from temp import __all__

    # Check that the module gets deleted
    time.sleep(1)
    assert not os.path.isfile('temp.pyc')



# Generated at 2022-06-21 21:57:33.152615
# Unit test for function make_lazy
def test_make_lazy():
    # Fake out the sys.modules
    modules = {}

    def my_import_module(module_path):
        if module_path not in modules:
            raise ImportError()

        return modules[module_path]

    class FakeModule(object):
        def __init__(self, module_path):
            self.__name__ = module_path
            self.__file__ = "<Magic>"
            self.__package__ = '.'.join(module_path.split('.')[:-1])

            # we'll keep track of how many times we were imported
            self.imported = 0

        def __getattr__(self, attr):
            # If a client accesses an attribute, we're effectively imported
            self.imported += 1

            # Each time they access an attribute, make sure we increment the
            # attribute count

# Generated at 2022-06-21 21:57:42.509126
# Unit test for function make_lazy
def test_make_lazy():
    from edx_django_utils.testing import (
        TestCase,
        override_settings,
    )
    from edx_django_utils.cache import RequestCache
    from django.forms import widgets
    from django.forms import fields
    from django.forms import forms

    class LazyForm(forms.Form):
        lazy_field = fields.CharField(
            label='Lazy Field',
            widget=widgets.TextInput(attrs={'class': 'lazy-field'}),
        )
        lazy_widget = widgets.TextInput(attrs={'class': 'lazy-widget'})
        normal_widget = widgets.TextInput(attrs={'class': 'normal-widget'})

    class LazyFormTestCase(TestCase):
        """Verify the form lazy loads fields and widgets"""



# Generated at 2022-06-21 21:57:46.866953
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the function make_lazy
    """
    test_module = 'test_module'
    import sys

    make_lazy(test_module)
    if test_module in sys.modules:
        assert isinstance(sys.modules[test_module], _LazyModuleMarker)

# Generated at 2022-06-21 21:57:50.667632
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for the LazyModuleMarker constructor
    """
    lmm = _LazyModuleMarker()
    assert isinstance(lmm, _LazyModuleMarker)


# Generated at 2022-06-21 21:57:53.095784
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests for the constructor of the class LazyModuleMarker
    """
    x = _LazyModuleMarker()
    print(x)

test__LazyModuleMarker()

# Generated at 2022-06-21 21:57:54.970137
# Unit test for constructor of class NonLocal
def test_NonLocal():
    o = NonLocal(None)
    o.value = 1
    assert o.value == 1
    o.value = 'test'
    a

# Generated at 2022-06-21 21:57:58.465955
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Tests that only a _LazyModuleMarker is created without error.
    from middleware.application_insights._internal.collectors.lazy_module import _LazyModuleMarker
    _LazyModuleMarker()

    # Tests that the _LazyModuleMarker is instance of object
    assert isinstance(_LazyModuleMarker(), object)



# Generated at 2022-06-21 21:58:00.142893
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-21 21:58:01.155442
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 21:58:05.936806
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = 1
    nonlocal_value = NonLocal(value)
    assert nonlocal_value.value == 1

    def func():
        nonlocal value

# Generated at 2022-06-21 21:58:07.171826
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(20).value == 20


# Generated at 2022-06-21 21:58:10.329141
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5



# Generated at 2022-06-21 21:58:16.828910
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('test_make_lazy', None)
    make_lazy('test_make_lazy')

    assert test_make_lazy.__name__ == 'test_make_lazy'
    assert isinstance(test_make_lazy, _LazyModuleMarker)

    test_make_lazy
    assert isinstance(test_make_lazy, ModuleType)


# vim:sw=4:et:ai

# Generated at 2022-06-21 21:58:18.758647
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value is None



# Generated at 2022-06-21 21:58:20.946958
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)


# Generated at 2022-06-21 21:58:23.324592
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(5)
    assert non_local.value == 5


# Generated at 2022-06-21 21:58:25.017351
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None

# Unit Test for constructor of class NonLocal

# Generated at 2022-06-21 21:58:27.316177
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert not nl
    nl.value = 5
    assert nl.value == 5



# Generated at 2022-06-21 21:58:29.715749
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    this_lazy_module = make_lazy(__name__)
    assert isinstance(this_lazy_module, _LazyModuleMarker)


# Generated at 2022-06-21 21:58:38.527940
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure that everything works as expected.
    """

    # Let's create a module and make sure it works
    import os
    assert 'os' in sys.modules
    assert isinstance(os, ModuleType)
    assert not isinstance(os, _LazyModuleMarker)

    # Let's make it lazy
    make_lazy('os')
    print(sys.modules['os'])

    # Check we have our LazyModule, and that it passes an `isinstance` check
    lazy_os = sys.modules['os']
    assert isinstance(lazy_os, _LazyModuleMarker)
    assert isinstance(lazy_os, ModuleType)

    # Make sure that if we try and look up an attribute, we don't get an error.

# Generated at 2022-06-21 21:58:41.962390
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal(0)
    assert 0 == obj.value
    obj.value = 1
    assert 1 == obj.value
    assert NonLocal(1) is not obj


# Generated at 2022-06-21 21:58:43.914777
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal('nonlocal')
    assert nonlocal_.value == 'nonlocal'



# Generated at 2022-06-21 21:58:54.516963
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test make_lazy function in lazy_imports module.
    '''

    import sys
    sys.modules['lazy_imports_mock_module'] = None
    make_lazy('lazy_imports_mock_module')
    lazy = sys.modules['lazy_imports_mock_module']
    _LazyModuleMarker.__mro__(lazy)
    assert isinstance(lazy, _LazyModuleMarker)
    lazy.__getattribute__('mocked')
    assert 'mocked' in lazy.__dict__
    del sys.modules['lazy_imports_mock_module']


# Generated at 2022-06-21 21:59:02.406918
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import _internal_util
    test_var = NonLocal(5)
    test_var.value += 1
    assert test_var.value == 6
    test_var = NonLocal(0.5)
    test_var.value *= 2.0
    assert test_var.value == 1.0
    test_var = NonLocal("abc")
    test_var.value += "def"
    assert test_var.value == "abcdef"
    return True


# Generated at 2022-06-21 21:59:07.037787
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test whether the constructor of class NonLocal can be called.
    """
    nl = None
    try:
        nl = NonLocal(None)
    except:
        assert False

    assert nl is not None

    try:
        nl = NonLocal(1)
    except:
        assert False

    assert nl is not None and nl.value == 1



# Generated at 2022-06-21 21:59:18.660679
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure that make_lazy actually works
    import os
    import sys
    sys.modules['os'] = object()
    make_lazy('os')
    assert 'os' in sys.modules
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert os is sys.modules['os']
    assert isinstance(os, _LazyModuleMarker)
    assert isinstance(os.path, ModuleType)
    assert os.path is sys.modules['os.path']
    assert os.path is os.path

    # Make sure that it works multiple times
    import os
    assert 'os' in sys.modules
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert os is sys.modules['os']

# Generated at 2022-06-21 21:59:21.069144
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert isinstance(m, _LazyModuleMarker)
    assert m.__class__.__name__ == "_LazyModuleMarker"


# Generated at 2022-06-21 21:59:22.466408
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(100)



# Generated at 2022-06-21 21:59:24.390540
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10


# Generated at 2022-06-21 21:59:34.600251
# Unit test for constructor of class NonLocal

# Generated at 2022-06-21 21:59:43.163585
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    import tests.lazy_test_module as mod

    assert hasattr(mod, '__file__')
    assert mod.__file__.endswith('tests/lazy_test_module.pyc')

    # Test
    del sys.modules['tests.lazy_test_module']

    make_lazy('tests.lazy_test_module')

    import tests.lazy_test_module as mod
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__name__ == 'tests.lazy_test_module'

    # Test lazy module
    assert not hasattr(mod, '__file__')
    assert mod.value == 'a_value'  # Test access of value
    assert hasattr(mod, '__file__')
    assert mod.__file__.endsw

# Generated at 2022-06-21 21:59:47.770505
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert isinstance(lazy_module, object)
    assert isinstance(lazy_module, ModuleType)
    assert type(lazy_module) == _LazyModuleMarker



# Generated at 2022-06-21 21:59:52.653643
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    sys.path.append('./test/unit')
    make_lazy('test_lazy_module')
    from test_lazy_module import test_lazy_module_class
    test = test_lazy_module_class()

# Generated at 2022-06-21 21:59:55.425879
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Simple constructor test
    """
    _LazyModuleMarker()

# Generated at 2022-06-21 21:59:56.808375
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()

# Generated at 2022-06-21 22:00:00.169555
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print('test__LazyModuleMarker')
    str(LazyModule())
    assert True

test__LazyModuleMarker()

# Generated at 2022-06-21 22:00:02.698987
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    b = _LazyModuleMarker()


# Generated at 2022-06-21 22:00:08.367199
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__name__ == 'NonLocal', '__name__ check failed'
    assert NonLocal.__dict__.__len__() == 1, '__dict__ check failed'
    assert NonLocal.__slots__.__len__() == 1, '__slots__ check failed'
    assert NonLocal.__slots__[0] == 'value', '__slots__ check failed'



# Generated at 2022-06-21 22:00:16.245120
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy works correctly by asserting that a newly created
    module can't be imported until an attribute is accessed.
    """
    import os
    if os.path.exists('test_module'):
        return

    import test_module

    with pytest.raises(AttributeError):
        test_module.non_existant_value
    with pytest.raises(ImportError):
        os.remove('test_module')

    assert test_module.existing_value == 'exists!'

# Generated at 2022-06-21 22:00:31.679521
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class LazyModule(_LazyModuleMarker):
        pass

    assert isinstance(LazyModule(), _LazyModuleMarker)


# Generated at 2022-06-21 22:00:34.031268
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value += 2
    assert nl.value == 3

# Generated at 2022-06-21 22:00:37.913926
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(1)
    assert nl1.value == 1
    nl1.value = 2
    assert nl1.value == 2


if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-21 22:00:44.875845
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import builtins

    time_module = time

    # remove the module from sys.modules, so that it would not be
    # cached in the import mechanisim.
    del sys.modules['time']

    make_lazy('time')

    # the module should not be imported at this point.
    assert 'time' not in sys.modules

    # we should be able to get the module.
    assert time_module.gmtime() == sys.modules['time'].gmtime()

    # a new reference to the module should be returned every time.
    assert time_module is not sys.modules['time']

    # remove the module from sys.modules, so that it would not be
    # cached in the import mechanisim.
    del sys.modules['time']

    # force the module to be imported.
    time.gm

# Generated at 2022-06-21 22:00:46.500353
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("ONE")
    assert nl.value == "ONE"

# Generated at 2022-06-21 22:00:47.319402
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from types import ModuleType
    from .lazy_module import _LazyModuleMarker
    assert isinstance(_LazyModuleMarker(), ModuleType)

# Generated at 2022-06-21 22:00:53.318181
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that we can make the module lazy.
    """
    module_path = 'some.module.path'
    sys.modules[module_path] = ModuleType(module_path)
    import sys
    make_lazy(module_path)
    assert not isinstance(sys.modules['some.module.path'], ModuleType), \
           "sys.modules[some.module.path] is not LazyModule"
    assert 'some.module.path' not in sys.modules, \
           "some.module.path is still in sys.modules"

# Generated at 2022-06-21 22:00:56.207407
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert isinstance(nl, NonLocal)
    assert nl.value == 10


# Generated at 2022-06-21 22:01:04.276247
# Unit test for function make_lazy
def test_make_lazy():
    import inspect

    def test_lazy(module_path, attr):
        # test if module_path is lazy
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        # test if attr is imported correctly
        assert isinstance(getattr(sys.modules[module_path], attr),
                          type(inspect))
        # test if module_path is still lazy
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    def test_lazy_lazy(module_path, attr):
        # test if module_path is lazy
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        # test if attr is lazy

# Generated at 2022-06-21 22:01:05.776311
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-21 22:01:33.580481
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    import os

# Generated at 2022-06-21 22:01:39.917038
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    def _convert(name, expected):
        actual = LazyModule(name)
        assert actual == expected, \
            'conversion from {0} to {1} failed'.format(name, expected)
    _convert('super', 'super')
    _convert(1, '1')
    _convert([1, 2, 3], '[1, 2, 3]')
    _convert(None, 'None')
    _convert(('a', 'b'), "('a', 'b')")
    _convert(1.0, '1.0')


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-21 22:01:51.392543
# Unit test for function make_lazy
def test_make_lazy():
    # When we first use a lazy module, it will be imported.
    make_lazy('os')
    assert os.path.sep == '/'

    # If the module is already imported, it won't be re-imported.
    make_lazy('os')
    assert os.path.sep == '/'

    # The modules are cached so we get the same object back when we
    # import them again.
    os_cached = os
    make_lazy('os')
    assert os is os_cached

    # Modules are only imported when something is accessed off of them.
    make_lazy('os.path')
    assert os.path.sep == '/'

    # The __mro__ is overriden so we pass isinstance checks.
    assert isinstance(os, types.ModuleType)

# Generated at 2022-06-21 22:01:54.737751
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(10)
    assert non_local.value == 10, 'Constructor did not work properly!'



# Generated at 2022-06-21 22:02:05.246668
# Unit test for function make_lazy

# Generated at 2022-06-21 22:02:14.825110
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile


# Generated at 2022-06-21 22:02:16.530463
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5



# Generated at 2022-06-21 22:02:19.395639
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():

    c1 = _LazyModuleMarker()
    assert isinstance(c1, _LazyModuleMarker)



# Generated at 2022-06-21 22:02:28.227401
# Unit test for function make_lazy
def test_make_lazy():
    def function_in_module(a):
        return a + 1

    sys.modules.clear()
    sys.modules["mymodule"] = None

    import mymodule
    assert mymodule is None
    make_lazy("mymodule")

    assert isinstance(mymodule, _LazyModuleMarker)
    assert mymodule.__name__ == "mymodule"
    assert mymodule.__file__ is None
    assert mymodule.__path__ is None
    assert mymodule.__dict__ is None
    assert mymodule.__package__ == ""
    assert not hasattr(mymodule, "function_in_module")

    new_module = ModuleType("mymodule")
    new_module.function_in_module = function_in_module
    sys.modules["mymodule"] = new_module

    assert mymodule.function_in

# Generated at 2022-06-21 22:02:32.056703
# Unit test for function make_lazy
def test_make_lazy():
    mod_name = "lazy_test"
    make_lazy(mod_name)

    assert mod_name in sys.modules
    assert isinstance(sys.modules[mod_name], _LazyModuleMarker)

# Generated at 2022-06-21 22:03:31.122661
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(2)

# Generated at 2022-06-21 22:03:34.547153
# Unit test for constructor of class NonLocal
def test_NonLocal():
	# Making a NonLocal variable
    nonlocal_variable = NonLocal(1)
    # Test for __init__ and __slots__
    assert nonlocal_variable.value == 1

# Test for __getattribute__

# Generated at 2022-06-21 22:03:36.870921
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), LazyModule)
    assert isinstance(__import__('threading'), LazyModule)



# Generated at 2022-06-21 22:03:43.684704
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    import sys
    make_lazy('datetime')

    # Remove the datetime module from sys.modules to simulate it
    # not having been imported yet.
    del sys.modules['datetime']
    assert 'datetime' not in sys.modules.keys()

    assert isinstance(datetime, _LazyModuleMarker)

    # Access datetime.datetime
    assert datetime.datetime
    assert isinstance(datetime, ModuleType)


if __name__ == '__main__':
    test_make_lazy()
    print('Unit tests pass.  Use make_lazy(module_path) to use this function.')

# Generated at 2022-06-21 22:03:46.203192
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    if not issubclass(_LazyModuleMarker, object):
        raise Exception("_LazyModuleMarker is not subclass of object")


# Generated at 2022-06-21 22:03:49.891580
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # make sure the function retruns the right type.
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker), \
        'make_lazy returned an inappropriate type'

# Generated at 2022-06-21 22:03:52.750107
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1


# Tests for constructor and return value of functions method __mro__ in class LazyModule
#

# Generated at 2022-06-21 22:03:55.400853
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = _LazyModuleMarker()
    assert a is not None
    assert b is not None


# Generated at 2022-06-21 22:04:00.187824
# Unit test for function make_lazy
def test_make_lazy():
    # prepare
    import sys
    import os
    import imp
    import stat
    # make temp test module
    fd, filepath = tempfile.mkstemp(suffix=".py")

    lazy_path = "lazy_test_" + str(os.getpid())

    f = open(filepath, 'w')

# Generated at 2022-06-21 22:04:04.042650
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = NonLocal(object)
    assert test_value.value == object


# Generated at 2022-06-21 22:06:22.418417
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)

# Generated at 2022-06-21 22:06:27.101033
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocal(object):
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    def test():
        x = NonLocal(42)
        return x.value

    assert test() == 42

# Unit tests for constructor of class LazyModule

# Generated at 2022-06-21 22:06:29.193058
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(isinstance(NonLocal("foo"), NonLocal))


# Generated at 2022-06-21 22:06:31.378099
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    nl.value = 'abc'
    assert nl.value == 'abc'

# Generated at 2022-06-21 22:06:34.688906
# Unit test for function make_lazy
def test_make_lazy():
    import time

    make_lazy('time')
    assert sys.modules['time'] is not time
    assert isinstance(sys.modules['time'], _LazyModuleMarker)
    assert time == sys.modules['time']
    assert isinstance(sys.modules['time'], ModuleType)

# Generated at 2022-06-21 22:06:38.606974
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5
    n.value = 10
    assert n.value == 10
    n = NonLocal('foobar')
    assert n.value == 'foobar'
    n.value = 'blah'
    assert n.value == 'blah'


# Generated at 2022-06-21 22:06:40.813942
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)

# Generated at 2022-06-21 22:06:43.400413
# Unit test for function make_lazy
def test_make_lazy():
    # create a module with one function
    module_path = "io_test"

# Generated at 2022-06-21 22:06:45.754454
# Unit test for constructor of class NonLocal
def test_NonLocal():
   a = NonLocal(1)
   assert(a.value == 1)
   a.value = 2
   assert(a.value == 2)


# Generated at 2022-06-21 22:06:46.952242
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()
