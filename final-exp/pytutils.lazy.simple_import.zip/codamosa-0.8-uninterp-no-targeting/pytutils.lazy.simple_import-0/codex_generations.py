

# Generated at 2022-06-21 21:57:22.882282
# Unit test for function make_lazy
def test_make_lazy():
    # This test imports a module with a side effect and simulates the
    # lazy loading of the module to ensure that the side effect occurs
    # only once when the module is imported.

    # The module is a dummy module that creates a global counter
    # and creates a counter on all objects
    # and logs when it does.
    global_count = 0
    class Counter(object):
        def __new__(cls):
            cls.count = 0
            return object.__new__(cls)

        def __repr__(self):
            return '{}({})'.format(type(self).__name__, self.count)

        def __init__(self):
            global global_count
            global_count += 1
            type(self).count += 1

    # This is the loaded module that creates side effects
    module = type

# Generated at 2022-06-21 21:57:26.927868
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not issubclass(_LazyModuleMarker, object)


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 21:57:29.882432
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker.__new__(_LazyModuleMarker),
                      _LazyModuleMarker)



# Generated at 2022-06-21 21:57:37.396234
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test 'isinstance' on our class stand-in
    assert isinstance(LazyModule(), _LazyModuleMarker)
    assert isinstance(LazyModule(), ModuleType)
    assert issubclass(LazyModule, _LazyModuleMarker)
    assert issubclass(LazyModule, ModuleType)



# Generated at 2022-06-21 21:57:46.817668
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Tests that the function returning a LazyModule works.
    '''

    collect_statistics = 1
    app = 'test_make_lazy'

    lm = make_lazy(app)

    assert isinstance(sys.modules[app], ModuleType)
    assert isinstance(sys.modules[app], _LazyModuleMarker)
    assert hasattr(sys.modules[app], 'collect_statistics')
    assert sys.modules[app].collect_statistics != 1
    assert sys.modules['{}.collect_statistics'.format(app)] == 1

# Generated at 2022-06-21 21:57:48.303531
# Unit test for constructor of class NonLocal
def test_NonLocal():
    new1 = NonLocal(1)
    assert(new1.value == 1)

# Generated at 2022-06-21 21:57:57.650513
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    if getattr(_LazyModuleMarker, '__doc__', None) is None:
        raise Exception('getattr() failed, __doc__ is None')

    if hasattr(_LazyModuleMarker, 'text'):
        raise Exception('hasattr() failed, expected nonexistent attr')

    mro_list = _LazyModuleMarker().__mro__

    if not isinstance(mro_list, list):
        raise Exception('type check in isinstance() failed, '
                        'expected list, got {}'.format(type(mro_list)))

    if not mro_list:
        raise Exception('list check in mro failed, expected non-empty list')


# Generated at 2022-06-21 21:58:00.240560
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

    x.value = 2
    assert x.value == 2


# Generated at 2022-06-21 21:58:02.482381
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys

    module = _LazyModuleMarker()
    assert isinstance(module, _LazyModuleMarker)



# Generated at 2022-06-21 21:58:03.890303
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(LazyModule(), _LazyModuleMarker) == True



# Generated at 2022-06-21 21:58:11.370346
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Parent(object):
        pass

    class Child(Parent):
        pass

    class GrandChild(_LazyModuleMarker):
        pass

    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

    assert issubclass(_LazyModuleMarker, object)
    assert issubclass(_LazyModuleMarker, type)
    assert not issubclass(_LazyModuleMarker, Parent)

    assert not isinstance(Child(), _LazyModuleMarker)
    assert isinstance(GrandChild(), _LazyModuleMarker)
    assert isinstance(GrandChild, _LazyModuleMarker)


# Generated at 2022-06-21 21:58:13.738730
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0
    x.value = 1
    assert x.value == 1

# Generated at 2022-06-21 21:58:22.918090
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    ################################################################################
    #  Constructor for class _LazyModuleMarker
    #
    #  Parameter: None
    #
    #  Return: none
    #
    #  Possible error: none
    #
    #  Requirement: EI_EI_EI_Mapping_Lazy_Modules_v0.3.7.pdf, version 0.3.7
    #
    ################################################################################
    obj = _LazyModuleMarker()

# Generated at 2022-06-21 21:58:32.719930
# Unit test for function make_lazy
def test_make_lazy():
    class AttrNotFoundException(Exception):
        pass

    class FakeModule(object):
        def __init__(self):
            self.attr = AttrNotFoundException()
            self.attr2 = 1

        def not_attr(self):
            raise AttrNotFoundException()

    sys.modules["fake_module"] = FakeModule()

    def run():
        # we do not need to write a try/except for this.
        fake_module.attr
        raise Exception("Attribute was loaded!")

    # test when the attribute wasn't loaded, it should raise the exception
    # that we defined in FakeModule
    make_lazy("fake_module")
    fake_module = sys.modules["fake_module"]
    assert isinstance(fake_module, _LazyModuleMarker)

# Generated at 2022-06-21 21:58:39.529247
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test_name is the name of the test case
    test_name = 'test__LazyModuleMarker'
    # Create an object of class _LazyModuleMarker
    x = _LazyModuleMarker()
    # Test if the object is an instance of class _LazyModuleMarker
    assert isinstance(x, _LazyModuleMarker), test_name + ': FAILED'



# Generated at 2022-06-21 21:58:41.816425
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
   lazy_module = _LazyModuleMarker()
   assert lazy_module
# Test for class LazyModule
from types import ModuleType

# Generated at 2022-06-21 21:58:43.763727
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)



# Generated at 2022-06-21 21:58:52.669427
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Simple test of constructor to class _LazyModuleMarker
    """
    import imp
    from mock import MagicMock
    from mock import patch

    def mock_import(name, globals=None, locals=None, fromlist=None):
        """
        Raises NameError if the module does not exist
        """
        if name in sys.builtin_module_names:
            raise ImportError('No module named ' + name)
        path = name
        file = None
        if sys.path:
            for dirname in sys.path:
                try:
                    fp, path, desc = imp.find_module(name, [dirname])
                except ImportError:
                    continue
                else:
                    file = fp
                    break

        if file is None:
            raise ImportError('No module named ' + name)

# Generated at 2022-06-21 21:58:54.833374
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    path = "x.y.z"
    make_lazy(path)
    my_module = sys.modules[path]
    assert isinstance(my_module, _LazyModuleMarker)
    assert isinstance(my_module, ModuleType)

# Generated at 2022-06-21 21:59:02.288622
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit tests for make_lazy
    """
    def _my_module():
        """
        A function that defines a module.
        """
        class MyClass(object):
            """
            The module's class
            """
            pass

        return MyClass

    module_path = 'edx_toggles.test_module'
    class_name = 'MyClass'
    sys.modules['edx_toggles.test_module'] = None
    make_lazy(module_path)
    assert sys.modules['edx_toggles.test_module'] is not None
    assert isinstance(sys.modules['edx_toggles.test_module'], _LazyModuleMarker)

    # Verify that the _LazyModuleMarker says it doesn't support isinstance.

# Generated at 2022-06-21 21:59:07.708909
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import datetime
    my_datetime = datetime.datetime(2012,12,31)
    my_lazy_datetime = _LazyModuleMarker()
    assert (isinstance(my_datetime, datetime.datetime) ==
            isinstance(my_lazy_datetime, _LazyModuleMarker))


# Generated at 2022-06-21 21:59:10.593195
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    assert_equals(isinstance(_LazyModuleMarker, object), True)


# Generated at 2022-06-21 21:59:12.721524
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal(1)

    assert(nonlocal_object.value == 1)

# Generated at 2022-06-21 21:59:22.430352
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile

    def test_file(path):
        with open(path, 'w') as f:
            f.write('test')

    tmp_dir = tempfile.mkdtemp()
    test_file(os.path.join(tmp_dir, 'file.py'))
    test_file(os.path.join(tmp_dir, 'file.pyc'))
    test_file(os.path.join(tmp_dir, 'file.pyo'))


# Generated at 2022-06-21 21:59:29.077671
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    sys_modules = sys.modules
    try:
        make_lazy('copy')
        assert 'copy' not in sys_modules
        module = __import__('copy')
        assert isinstance(module, ModuleType)

    finally:
        sys_modules.pop('copy')


__all__ = ['make_lazy', '_LazyModuleMarker', 'NonLocal']

# Generated at 2022-06-21 21:59:30.954363
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()

    assert isinstance(lmm, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:32.409616
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(NonLocal('hi').value == 'hi')


# Generated at 2022-06-21 21:59:42.020336
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys
    import mysomemodule
    sys.modules.pop('mysomemodule', None)
    make_lazy('mysomemodule')
    assert 'mysomemodule' in sys.modules
    assert isinstance(sys.modules['mysomemodule'], _LazyModuleMarker)
    assert not isinstance(sys.modules['mysomemodule'], ModuleType)
    assert sys.modules['mysomemodule'].__mro__() == (_LazyModuleMarker, ModuleType)
    assert sys.modules['mysomemodule'].name == 'mysomemodule'
    assert 'mysomemodule' not in sys.modules

# Generated at 2022-06-21 21:59:44.266447
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker, '__mro__')


# Generated at 2022-06-21 21:59:54.342346
# Unit test for function make_lazy
def test_make_lazy():
    # This is a tough one to unit test. We're going to set up a fake
    # module to validate that LazyModule is working correctly.

    class _FunkyModule(_LazyModuleMarker):
        """
        A class to test the lazy module.
        """

        # just a value to check that we can access the module data.
        attr1 = 'One'

        def __init__(self):
            """
            Only to make this class instantiable.
            """
            pass

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """
            raise ValueError('Boom!')

    # Set up a fake module that we can override
    sys.modules['test.test_utils'] = _FunkyModule()

    # Set up a fake LazyModule

# Generated at 2022-06-21 21:59:58.887983
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(1)
    assert nonlocal_value.value == 1
    nonlocal_value.value = 2
    assert nonlocal_value.value == 2



# Generated at 2022-06-21 22:00:04.823023
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    
    # Testing incorrect initialization
    with pytest.raises(TypeError):
        _LazyModuleMarker(10)
        
    # Testing correct initialization
    assert(_LazyModuleMarker())
    

# Generated at 2022-06-21 22:00:07.589451
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A(object):
        pass

    a = A()
    assert_false(isinstance(a, _LazyModuleMarker))
    assert isinstance(a, object)


# Generated at 2022-06-21 22:00:08.704803
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-21 22:00:18.551336
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    import django.utils.lazy

    # Django internals depend on re_path
    make_lazy('django.urls.base')

    # Make sure we can import it normally
    try:
        import django.urls.base
    except ImportError:
        raise AssertionError('Should be able to import module normally')

    # Make sure we can import it normally
    try:
        import django.urls.base
    except ImportError:
        raise AssertionError('Should be able to import module normally')

    # Make sure the module is lazy
    try:
        django.urls.base.re_path
        raise AssertionError('Module not lazy after make_lazy')
    except AttributeError:
        pass

    # Make sure the module is still lazy,

# Generated at 2022-06-21 22:00:28.615581
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import foo
        raise Exception('`foo` is already imported')
    except ImportError:
        pass

    def test_lazy_import():
        """
        Internal helper function to unit test lazy import.
        """
        make_lazy('foo')

        # Reloading a module should not throw an exception
        # When the module is not needed, the import statement should
        # throw an ImportError
        reload(sys.modules['foo'])

        # The module should be imported
        import foo
        assert foo.__name__ == 'foo'
        assert hasattr(foo, '__file__')

    test_lazy_import()
    del sys.modules['foo']
    test_lazy_import()

# Generated at 2022-06-21 22:00:34.663226
# Unit test for function make_lazy
def test_make_lazy():
    import subprocess
    assert isinstance(subprocess, _LazyModuleMarker)
    # Trigger import
    subprocess.Popen(['date'], stdout=subprocess.PIPE)
    assert isinstance(subprocess, ModuleType)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:00:36.790366
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10


# Generated at 2022-06-21 22:00:37.912994
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModul

# Generated at 2022-06-21 22:00:39.812959
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test if local var initialized properly
    test = NonLocal(None)
    assert test.value is None


# Generated at 2022-06-21 22:00:42.385428
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1


# Generated at 2022-06-21 22:00:45.747139
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    lazy_module = _LazyModuleMarker()
    assert(isinstance(lazy_module, ModuleType)) # Type of 'lazy_module' should
                                                # be ModuleType

# Generated at 2022-06-21 22:00:48.847769
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Let's check the _LazyModuleMarker class.
    """
    # check whether _LazyModuleMarker is initialized properly
    assert isinstance(_LazyModuleMarker(), object)



# Generated at 2022-06-21 22:00:49.741219
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-21 22:00:53.541011
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker) and \
        isinstance(_LazyModuleMarker, _LazyModuleMarker) and \
        not isinstance(_LazyModuleMarker, object) and \
        not isinstance(object(), _LazyModuleMarker)



# Generated at 2022-06-21 22:00:57.199767
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  x = _LazyModuleMarker()
  assert isinstance(x, _LazyModuleMarker)

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:00:59.636720
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = getattr(NonLocal, 'value')
    assert a == None, "Error NonLocal"
    return True

# Generated at 2022-06-21 22:01:13.709299
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    local_path = 'test_lazy_module'

    def create_local_module():
        """
        Creates a test module for processing.
        """
        with open(local_path + '.py', 'w') as test_file:
            test_file.write('def test(): return "successful"')

    # Create a test module to process
    create_local_module()


# Generated at 2022-06-21 22:01:23.990800
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile
    import shutil


# Generated at 2022-06-21 22:01:25.436176
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 5
    assert a.value == 5



# Generated at 2022-06-21 22:01:28.332650
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assertNonLocalInstance(NonLocal(None))


# Generated at 2022-06-21 22:01:31.305461
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class B(object):
        def __init__(self, a):
            self.a = a

    a = NonLocal(B(1))
    print(a.value.a)

# Generated at 2022-06-21 22:01:32.749240
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

# Generated at 2022-06-21 22:01:34.941705
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    
    sys.path.append('./')
    make_lazy('s')

    l = sys.modules['s']
    print(l)
    print(type(l))


# Generated at 2022-06-21 22:01:48.252120
# Unit test for function make_lazy
def test_make_lazy():
    from django.utils.six import wraps

    @wraps(make_lazy)
    def make_lazy_wrapper(module_path):
        make_lazy(module_path)

    @make_lazy_wrapper('py.test')
    def pytest_func():
        """
        This is a function that will force py.test to be lazy loaded.
        """
        pass

    @wraps(test_make_lazy)
    def test_make_lazy_wrapper():
        import py

        # Make sure py.test is lazy-loaded
        assert py.test not in sys.modules

        # This will force py.test to be loaded.
        pytest_func()

        # Make sure it's loaded
        assert py.test in sys.modules

        # Make sure our function is wrapped.
        assert pytest

# Generated at 2022-06-21 22:01:51.543306
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(5)
    
    assert hasattr(nonlocal_instance, 'value')
    assert nonlocal_instance.value == 5
    assert nonlocal_instance.__slots__ == ['value']

# Generated at 2022-06-21 22:02:03.473978
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    def reset_modules_for_test():
        # reload modules
        module = None
        module_path = None
        sys.modules.pop('test_module', None)
        sys.modules.pop('test_module.test_module', None)

        module = sys.modules.pop('test_module.test_module.test_module', None)

    def verify():
        assert os.path.isdir(module_path)
        assert os.path.isdir(module_path + '.test_module')
        assert os.path.isdir(module_path + '.test_module.test_module')

        # verify that make_lazy is actually lazy
        assert len(os.listdir(module_path)) == 0
        test_module.test_module.test_module

# Generated at 2022-06-21 22:02:04.649929
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(3)
    assert test.value == 3


# Generated at 2022-06-21 22:02:05.462136
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  assert _LazyModuleMarker()


# Generated at 2022-06-21 22:02:09.855666
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    except NameError:
        assert False


# Generated at 2022-06-21 22:02:16.475075
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal('hello')
    assert(a.value == 'hello')


# Generated at 2022-06-21 22:02:21.039114
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(42)
    assert nl1.value == 42
    try:
        nl1.new_attr = 'hello'
    except AttributeError:
        print("'NonLocal' instance has no attribute 'new_attr'")


# Generated at 2022-06-21 22:02:28.858847
# Unit test for function make_lazy
def test_make_lazy():
    # 1st: Unit test for module a
    a = __import__('a')
    # 1.1 a is already imported
    assert sys.modules["a"] == a
    # 1.2 a is an instance of ModuleType
    assert isinstance(a, ModuleType)

    # 2nd: Unit test for function make_lazy
    make_lazy('b')
    # 2.1 b is still not imported
    assert sys.modules['b'] != b
    # 2.2 b is an instance of LazyModule
    assert isinstance(sys.modules['b'], _LazyModuleMarker)
    # 2.3 '__mro__' of b is LazyModule
    assert sys.modules['b'].__mro__() == (LazyModule, ModuleType)

    # 3rd: Unit test for attribute from b


# Generated at 2022-06-21 22:02:38.290410
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        from unittest import mock
    except:
        return

    # Verify that the value attribute is set properly
    nl1 = NonLocal(5)
    assert nl1.value == 5

    # Verify that the value attribute can be mocked
    nl2 = NonLocal(5)
    with mock.patch.object(nl2, 'value') as nl2_value:
        nl2_value.__str__.return_value = '3.1415'
        assert str(nl2.value) == '3.1415'

    # Verify that the value attribute cannot be reset
    try:
        nl3 = NonLocal(5)
        nl3.value = 10
    except AttributeError:
        pass
    except Exception as e:
        raise e
    else:
        raise Assertion

# Generated at 2022-06-21 22:02:43.263565
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        a = NonLocal(1)
        b = a.value
        # Python 2.7: AttributeError: 'NonLocal' object has no attribute 'value'
        # old style class cannot have __slots__
        assert False
    except AttributeError:
        pass
    except Exception:
        assert False
    # __slots__ without __dict__ or __weakref__
    assert not hasattr(a, "__dict__") and not hasattr(a, "__weakref__")
    assert hasattr(a, "value")
    assert a.__slots__[0] == "value"
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-21 22:02:46.714181
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(1)
    assert nonlocal_.value == 1
    nonlocal_.value = 2
    assert nonlocal_.value == 2

# Generated at 2022-06-21 22:02:48.593221
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2

# Generated at 2022-06-21 22:02:53.467289
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """

    my_nonlocal = NonLocal('my_value')

    assert my_nonlocal.value == 'my_value'


# Generated at 2022-06-21 22:02:56.064987
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal("hello")
    assert x.value == "hello"


# Generated at 2022-06-21 22:03:06.241699
# Unit test for function make_lazy
def test_make_lazy():

    import tempfile
    import os
    import sys

    def _capture():
        orig_stdout = sys.stdout
        orig_stderr = sys.stderr
        sys.stdout = sys.stderr = open(os.devnull, 'w')
        try:
            yield
        finally:
            sys.stdout.close()
            sys.stderr.close()
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr

    def test_module_not_found(path):
        # Ensure that the module isn't present in sys.modules
        try:
            del sys.modules[path]
        except:
            pass

        # Ensure that we get the correct error message

# Generated at 2022-06-21 22:03:20.159898
# Unit test for function make_lazy
def test_make_lazy():
    # True if imported
    imported_marker = False

    # Create a fake module by using a class.
    class FakeModule(object):
        class Foo(object):
            pass

    import sys
    if sys.version_info < (3, 0):
        import __builtin__ as builtin
    else:
        import builtins as builtin

    # A decorator to wrap `__import__` to simulate importing situations
    def import_wrapper(import_):
        def wrapper(*args, **kwargs):
            # Call the original import function.
            # If it is the module we want, we mark it
            if args[0] == 'fake_module':
                global imported_marker
                imported_marker = True
                return FakeModule
            else:
                return import_(*args, **kwargs)
        return wrapper

   

# Generated at 2022-06-21 22:03:23.307616
# Unit test for constructor of class NonLocal
def test_NonLocal():
    d = {'foo': 1}
    nonlocalobj = NonLocal(d)
    assert nonlocalobj.value == d
    assert hasattr(NonLocal(d), 'value')


# Generated at 2022-06-21 22:03:26.042397
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(1)
    assert t.value == 1


# Generated at 2022-06-21 22:03:27.884271
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert(m is _LazyModuleMarker)


# Generated at 2022-06-21 22:03:35.517106
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    # Unit test for function __mro__
    def test_mro():
        assert (marker.__mro__() == (_LazyModuleMarker, ModuleType))
    test_mro()
    # Unit test for function __getattribute__
    def test_getattribute():
        assert (marker.__getattribute__('test') == 'test')
    test_getattribute()

if __name__ == "__main__":
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:03:39.085238
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f():
        var = NonLocal(1)

# Generated at 2022-06-21 22:03:42.479858
# Unit test for function make_lazy
def test_make_lazy():
    import os
    modpath = os.path.realpath(__file__)
    modpath = os.path.splitext(modpath)[0]
    make_lazy(modpath)
    import_time = importlib.import_module(modpath).import_time
    time.sleep(1)

# Generated at 2022-06-21 22:03:43.802109
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    L = _LazyModuleMarker()
    assert L is not None


# Generated at 2022-06-21 22:03:50.930751
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Lazy modules are instances of _LazyModuleMarker
    mod = make_lazy('b')
    assert isinstance(mod, _LazyModuleMarker)
    # Test that the module returns the correct object
    assert isinstance(mod.__mro__, _LazyModuleMarker.__mro__.__class__)
    # Test LazyModule inheritance of ModuleType
    assert isinstance(mod, ModuleType)



# Generated at 2022-06-21 22:03:52.750265
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(5)
    assert non_local.value == 5


# Generated at 2022-06-21 22:04:03.168534
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10



# Generated at 2022-06-21 22:04:06.025911
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test whether constructor of class NonLocal works
    nl = NonLocal(4)
    assert nl.value == 4


# Generated at 2022-06-21 22:04:07.565104
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None

# Generated at 2022-06-21 22:04:09.493879
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class MyClass(NonLocal):
        value = NonLocal(True)

    assert MyClass.value.value == True

# Generated at 2022-06-21 22:04:11.393580
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker().__class__.__name__ == '_LazyModuleMarker')


# Generated at 2022-06-21 22:04:14.597387
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__name__ == "NonLocal"
    assert NonLocal.__doc__ == "Simulates nonlocal keyword in Python 2"
    assert hasattr(NonLocal, "value") is True

# Generated at 2022-06-21 22:04:15.808225
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1

# Generated at 2022-06-21 22:04:18.075820
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    assert a.value == 0
    a.value = 1
    assert a.value == 1


# Generated at 2022-06-21 22:04:27.152585
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the module make_lazy
    """
    module_path = 'test.module.name'

    # mock python module called test.module.name
    class MockModule(object):
        """
        A mock module object
        """
        pass

    # mock sys.modules object
    class MockSys(object):
        """
        A mock sys module object
        """
        def __init__(self):
            """
            Constructor for MockSys
            """
            self.modules = {}

    # mock the sys.modules module
    sys = MockSys()

    make_lazy(module_path)

    # check for Lazy Module
    assert isinstance(sys.modules[module_path], _LazyModuleMarker) is True
    assert isinstance(sys.modules[module_path], ModuleType) is True

   

# Generated at 2022-06-21 22:04:28.547255
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, object)



# Generated at 2022-06-21 22:04:44.621110
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class_var = _LazyModuleMarker()
    print('Class Created Successfully!')


# Generated at 2022-06-21 22:04:47.160942
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3


# Generated at 2022-06-21 22:04:49.700303
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert (marker.__class__ == object)
    assert (marker.__mro__ == object.__mro__)

# Generated at 2022-06-21 22:04:54.192292
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    if isinstance(_LazyModuleMarker(), _LazyModuleMarker):
        print("Class _LazyModuleMarker instantiated correctly.")
    else:
        print("Class _LazyModuleMarker not instantiated correctly.")


# Generated at 2022-06-21 22:04:56.864486
# Unit test for constructor of class NonLocal
def test_NonLocal():
    global_test = NonLocal(10)
    assert 10 == global_test.value
    global_test.value = 20
    assert 20 == global_test.value


# Generated at 2022-06-21 22:04:58.502491
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(4)

# Generated at 2022-06-21 22:05:06.763268
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)
    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (LazyModule, ModuleType)

# Generated at 2022-06-21 22:05:08.197538
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    foo = _LazyModuleMarker()
    assert isinstance(foo, _LazyModuleMarker)


# Generated at 2022-06-21 22:05:15.028334
# Unit test for constructor of class NonLocal
def test_NonLocal():

    class TestNonLocal(unittest.TestCase):
        def test_constructor(self):
            value = "value"
            test_non_local = NonLocal(value)
            self.assertEqual(test_non_local.value, value)

    unittest.main(verbosity=2)



# Generated at 2022-06-21 22:05:21.152611
# Unit test for function make_lazy
def test_make_lazy():
    pkg_name = 'pkg_test'

    pkg_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), pkg_name)
    sys.path.insert(0, pkg_path)

    make_lazy(pkg_name)
    # test object
    assert not sys.modules[pkg_name]
    assert sys.modules['pkg_test.foo']
    assert sys.modules['pkg_test.bar']

# Generated at 2022-06-21 22:05:56.866539
# Unit test for function make_lazy
def test_make_lazy():

    # Create a temporary python module with content
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write("print 'hello'")

    # Mark the module as lazy
    make_lazy(path)

    # Load the module
    import path

    # Check if we can see the content
    assert not hasattr(path, 'print')

    # Access a function
    path.print

    # Check if we can see the content
    assert hasattr(path, 'print')

    # Clean up
    os.unlink(path)

# Generated at 2022-06-21 22:06:04.910608
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the following properties:
        *   Importing a module marked as lazy does not actually import
            the module.
        *   Accessing attributes on the lazy module actually import
            the module.
    """
    module_name = 'test_make_lazy_module'
    module_path = 'lazy_import.tests.{}'.format(module_name)
    make_lazy(module_path)

    # We haven't actually imported the module yet
    assert module_name not in sys.modules.keys()

    # Now we import the module.
    import_module(module_path)

    assert module_name in sys.modules.keys()



# Generated at 2022-06-21 22:06:06.876341
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal("Hello")
    assert a.value == "Hello"

    a.value = "World"
    assert a.value == "World"


# Generated at 2022-06-21 22:06:11.490450
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        foo = NonLocal(10)
        assert(foo.value == 10)
    except AttributeError:
        return False
    return True


# Generated at 2022-06-21 22:06:21.757738
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function.
    """
    assert not hasattr(sys.modules, '_make_lazy_unittest_module')

    # check that it is lazy
    make_lazy('_make_lazy_unittest_module')
    assert isinstance(sys.modules['_make_lazy_unittest_module'], _LazyModuleMarker)

    # check that it is lazy
    make_lazy('_make_lazy_unittest_module_2')
    assert isinstance(sys.modules['_make_lazy_unittest_module_2'], _LazyModuleMarker)

    # check that it is lazy
    make_lazy('_make_lazy_unittest_module_3')

# Generated at 2022-06-21 22:06:33.654397
# Unit test for function make_lazy
def test_make_lazy():
    test_module_name = 'cinder.tests.unit.test_make_lazy'
    assert test_module_name not in sys.modules
    assert test_module_name not in globals()
    assert isinstance(make_lazy, types.FunctionType)
    make_lazy(test_module_name)
    assert test_module_name in sys.modules
    assert test_module_name in globals()
    assert isinstance(sys.modules[test_module_name],
                      _LazyModuleMarker)
    assert isinstance(globals()[test_module_name],
                      _LazyModuleMarker)
    # Test that lazy module can actually be imported later
    from cinder import tests
    assert tests is not None
    assert tests.unit is not None
    assert tests.unit.test_make_l

# Generated at 2022-06-21 22:06:35.690061
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal
    """
    test = NonLocal(1)
    assert test.value == 1, "Test the constructor of class NonLocal"


# Generated at 2022-06-21 22:06:46.522075
# Unit test for function make_lazy
def test_make_lazy():
    # Throws an key error because this module doesn't exist yet.
    with pytest.raises(KeyError):
        sys.modules['test_module']
    # Create a lazy module
    make_lazy('test_module')
    # Make sure the key does exist so we can check that the import is happening
    assert 'test_module' in sys.modules
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    # We haven't actually imported the module yet.
    with pytest.raises(AttributeError):
        sys.modules['test_module'].foo
    # Now we need to have something on the module, so the lazy import happens.
    # First we create the module and make sure an attribute exists on it.
    test_module = ModuleType('test_module')
    test_module.foo

# Generated at 2022-06-21 22:06:52.095029
# Unit test for function make_lazy
def test_make_lazy():
    def tmod(module_name):
        make_lazy(module_name)

    class Invalid:
        pass

    with pytest.raises(ImportError):
        tmod('importlib')

    # Ensure that we are actually returning a ModuleType
    # and not some other class.
    assert isinstance(sys.modules['importlib'], ModuleType)

    type_ = type(sys.modules['importlib'])
    assert isinstance(sys.modules['importlib'], LazyModule)

# Generated at 2022-06-21 22:06:53.269237
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Unit tests for make_lazy