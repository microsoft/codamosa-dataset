

# Generated at 2022-06-21 21:57:17.596157
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("test")
    assert nl.value == "test"


# Generated at 2022-06-21 21:57:20.967521
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-21 21:57:33.045892
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType
    from djangocms_text_ckeditor import __version__
    module_path = "djangocms_text_ckeditor"
    make_lazy(module_path)

    assert isinstance(sys.modules[module_path], ModuleType)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Versions are set in setup.py
    assert sys.modules[module_path].__version__ != __version__

    # Importing this forces loading of the actual module
    import djangocms_text_ckeditor

    # This will import the module, but it already exists
    import djangocms_text_ckeditor

    assert sys.modules[module_path].__version__ == __version__

# Generated at 2022-06-21 21:57:35.562709
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-21 21:57:39.158395
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('unittest')
    import unittest
    assert isinstance(unittest, _LazyModuleMarker)



# Generated at 2022-06-21 21:57:44.724545
# Unit test for function make_lazy
def test_make_lazy():
    test_module_name = "make_lazy_test_module"
    assert test_module_name not in sys.modules
    make_lazy(test_module_name)
    assert test_module_name in sys.modules

    # Accessing module instance attributes should result in the module being imported
    lazy_module = sys.modules[test_module_name]
    attribute_to_access = "test_attribute"
    assert not hasattr(lazy_module, attribute_to_access)
    lazy_module.test_attribute = "test_attribute_value"
    assert hasattr(lazy_module, attribute_to_access)
    assert sys.modules[test_module_name] != lazy_module
    assert sys.modules[test_module_name].test_attribute == "test_attribute_value"
    # Cleanup
   

# Generated at 2022-06-21 21:57:46.174172
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3



# Generated at 2022-06-21 21:57:48.345959
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1, "NonLocal class is not initialized properly"


# Generated at 2022-06-21 21:57:56.287260
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('system.settings') # module not exists

    try:
        settings = __import__('system.settings')
        assert 'system.settings' in sys.modules
        assert isinstance(sys.modules['system.settings'], _LazyModuleMarker)
    except ImportError:
        assert False

    try:
        settings = __import__('system.settings')
        assert 'system.settings' in sys.modules
        assert not isinstance(sys.modules['system.settings'], _LazyModuleMarker)
    except ImportError:
        assert False

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 21:58:06.840812
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """
    import sys
    sys.path.append('../..')

    make_lazy('nose.tools')

    import nose.tools
    assert isinstance(nose.tools, _LazyModuleMarker)

    # Test that module is imported
    assert nose.tools.eq is not None

    # Test that we can access nested imports
    assert nose.tools.eq.Pa
    assert isinstance(nose.tools.eq.Pa, _LazyModuleMarker)

    # Test that we can access nested imports
    assert not isinstance(nose.tools.eq.Pa._Params, _LazyModuleMarker)

    del sys.modules['nose.tools']
    del sys.modules['nose.tools.eq']

# Generated at 2022-06-21 21:58:12.979823
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        nl = NonLocal(1)
        nl.value
        nl.value = 2
        nl.value
    except:
        return False
    return True


# Generated at 2022-06-21 21:58:24.253086
# Unit test for function make_lazy
def test_make_lazy():
    # If currently the module is installed and imported, the test will fail.
    # Try to temporarily uninstall the module.
    try:
        from importlib import reload
    except ImportError:
        import imp
        reload = imp.reload
    try:
        reload(os)
    except ImportError:
        pass

    import gc

    check_attribute = 'stat'

    # Make sure the module is unloaded before we start the test.
    for i in gc.get_referrers(os):
        if isinstance(i, ModuleType) and i.__name__ == 'os':
            import copy
            i = copy.deepcopy(i)  # test if this code could be executed.
            assert False, "The target module should not be in sys.modules"
    del gc.garbage[:]

    # do things that should

# Generated at 2022-06-21 21:58:33.242954
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # This should run without having any error
    class NonLocalTest(object):
        """
        A test case
        """
        local = 1

        def __init__(self):
            self.local = 2

# Generated at 2022-06-21 21:58:35.357612
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    '''
    test for constructor of class _LazyModuleMarker
    '''
    a=_LazyModuleMarker()
    assert isinstance(a,_LazyModuleMarker)


# Generated at 2022-06-21 21:58:37.940828
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Unit test for constructor of class _LazyModuleMarker"""
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 21:58:48.256209
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    sys.modules['test.test'] = None

    make_lazy('test.test')

    # test isinstance
    assert(isinstance(sys.modules['test.test'], ModuleType) is True)
    assert(isinstance(sys.modules['test.test'], _LazyModuleMarker) is True)

    # test attr
    assert(hasattr(sys.modules['test.test'], 'abc') is False)
    with pytest.raises(AttributeError):
        sys.modules['test.test'].abc

    # test normal module
    test = __import__('test.test')
    assert(isinstance(test, ModuleType) is True)
    assert(isinstance(test, _LazyModuleMarker) is False)
   

# Generated at 2022-06-21 21:58:49.794089
# Unit test for constructor of class NonLocal
def test_NonLocal():
	a = NonLocal(1)
	assert a.value == 1


# Generated at 2022-06-21 21:58:59.444728
# Unit test for function make_lazy
def test_make_lazy():
    """
    Testing module lazy loading
    """
    from importlib import util
    import os
    os.environ['A_MODULE'] = ''
    if hasattr(util, 'module_from_spec'):
      spec = util.spec_from_loader('a', None)
      module = util.module_from_spec(spec)
    else:
      if sys.version_info[:2] == (2, 7):
        module = types.ModuleType('a')
      else:
        module = ModuleType('a')
    module.__path__ = ''
    lazy_module = make_lazy('a')
    assert(isinstance(lazy_module, _LazyModuleMarker))
    assert(isinstance(module, ModuleType))
    assert(not isinstance(module, _LazyModuleMarker))


# Generated at 2022-06-21 21:59:06.999739
# Unit test for function make_lazy
def test_make_lazy():
    import tests.lazy_imports.fake_module
    assert not isinstance(tests.lazy_imports.fake_module, _LazyModuleMarker)

    make_lazy('tests.lazy_imports.fake_module')
    assert isinstance(tests.lazy_imports.fake_module, _LazyModuleMarker)

    # Accessing the module should make it "real" again
    assert hasattr(tests.lazy_imports.fake_module, 'unused_attribute')
    assert not isinstance(tests.lazy_imports.fake_module, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:17.760803
# Unit test for function make_lazy
def test_make_lazy():
    """

    """
    import test_make_lazy  # noqa
    import test_make_lazy2  # noqa

    assert isinstance(test_make_lazy, _LazyModuleMarker)
    assert isinstance(test_make_lazy2, _LazyModuleMarker)

    assert 'test_make_lazy2.foo' not in sys.modules
    assert test_make_lazy.foo == 'foo'
    assert 'test_make_lazy2.foo' in sys.modules

    assert 'test_make_lazy2.bar' not in sys.modules
    assert test_make_lazy.bar == 'bar'
    assert 'test_make_lazy2.bar' in sys.modules

# Generated at 2022-06-21 21:59:23.255230
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''Test the initializer of class NonLocal'''
    test_value = 1
    test_non_local = NonLocal(test_value)
    assert test_non_local.value == test_value



# Generated at 2022-06-21 21:59:34.318519
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # check that we can import our module before the patch is applied
    try:
        import test.test_test_support
    except ImportError:
        raise unittest.SkipTest('test.test_test_support not found')

    module_name = 'test.test_test_support'
    make_lazy(module_name)


# Generated at 2022-06-21 21:59:37.081108
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal("test")
    assert test.value == "test"


# Generated at 2022-06-21 21:59:49.100656
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    mod = "make_lazy.test_mod"
    test_mod = sys.modules[mod] = ModuleType(mod)
    test_mod.load_global = True
    def _test():
        make_lazy(mod)
        import make_lazy.test_mod
        if hasattr(make_lazy.test_mod, "load_global"):
            raise AssertionError("Attribute load_global from test_mod exists unexpectedly.")
        if not hasattr(make_lazy, "test_mod"):
            raise AssertionError("Attribute test_mod from make_lazy does not exist unexpectedly.")
        if not hasattr(make_lazy.test_mod, "load_local"):
            raise AssertionError("Attribute load_local from test_mod does not exist unexpectedly.")

# Generated at 2022-06-21 22:00:00.315929
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy behaves as expected
    """

    # assert
    make_lazy('test_make_lazy.test')
    assert 'test_make_lazy.test' not in sys.modules
    assert isinstance(test_make_lazy.test, _LazyModuleMarker)

    # act
    test_make_lazy.test.attr1

    # assert
    assert 'test_make_lazy.test' in sys.modules
    assert not isinstance(test_make_lazy.test, _LazyModuleMarker)
    assert isinstance(sys.modules['test_make_lazy.test'], ModuleType)
    assert hasattr(test_make_lazy.test, 'attr1')



# Generated at 2022-06-21 22:00:04.178379
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None

    a.value = 'test'
    assert a.value == 'test'

# Generated at 2022-06-21 22:00:05.578291
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10


# Generated at 2022-06-21 22:00:08.450004
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests for constructor of class
    :class: `_LazyModuleMarker`
    """
    lazy_module_marker = _LazyModuleMarker()

    assert(lazy_module_marker is not None)


# Generated at 2022-06-21 22:00:14.652612
# Unit test for function make_lazy
def test_make_lazy():
    test_mod = 'make_lazy_test'
    assert not test_mod in sys.modules, "Test setup failure: test module already in sys.modules"

    import os.path
    test_file = os.path.join(os.path.dirname(__file__), test_mod + '.py')
    assert os.path.exists(test_file), "Test setup failure: test file does not exist: " + test_file

    make_lazy(test_mod)

    test_mod_lazy = sys.modules[test_mod]
    assert isinstance(test_mod_lazy, _LazyModuleMarker), "Failed to create lazy module"

    test_mod_lazy_attr = test_mod_lazy.attr


# Generated at 2022-06-21 22:00:17.237568
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker is not None
    assert callable(_LazyModuleMarker)
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-21 22:00:21.444901
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker, type)

# Generated at 2022-06-21 22:00:25.553476
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert (isinstance(marker, _LazyModuleMarker)
            , "Constructor of class _LazyModuleMarker is not working!")


# Generated at 2022-06-21 22:00:31.830887
# Unit test for function make_lazy
def test_make_lazy():
    import importlib
    import sys

    # create a fresh sys module with a new dummy module
    old_sys_modules = sys.modules
    sys.modules = {}
    sys.modules['dummy_module'] = importlib.import_module('dummy_module')

    from importlib import dummy_module
    # check that there is some code called in dummy_module
    assert dummy_module.some_code.__name__ == 'some_code'

    # lazy load dummy_module
    make_lazy('dummy_module')

    # check that dummy_module is now lazy loaded
    assert not isinstance(sys.modules['dummy_module'], importlib.import_module('dummy_module'))

    # check that the attribute some_code is still accessible in dummy_module
    assert sys.modules['dummy_module'].some

# Generated at 2022-06-21 22:00:37.859277
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'selene_sdk.helpers.utils'
    make_lazy(module_path)
    assert type(sys.modules[module_path]) is _LazyModuleMarker, \
        'the module {0} is not lazy, the module type is {1}'.format(
            module_path,
            type(sys.modules[module_path]))

# Generated at 2022-06-21 22:00:42.202116
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["lazymodule"] = ModuleType("lazymodule")
    make_lazy("lazymodule")
    assert isinstance(sys.modules["lazymodule"], _LazyModuleMarker)
    assert isinstance(sys.modules["lazymodule"], ModuleType)
    assert not isinstance(sys.modules["lazymodule"], type)

# Generated at 2022-06-21 22:00:42.967884
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()

# Generated at 2022-06-21 22:00:52.252184
# Unit test for function make_lazy
def test_make_lazy():
    import test_make_lazy
    test_test_make_lazy_import = None

    def test_test_make_lazy_import_func():
        nonlocal test_test_make_lazy_import
        test_test_make_lazy_import = True
        assert test_make_lazy.test_make_lazy_import == True

    make_lazy('test_make_lazy.test_make_lazy')

    test_make_lazy.test_make_lazy.test_make_lazy_import_func()

    assert test_test_make_lazy_import == True

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-21 22:00:53.994047
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert isinstance(test, _LazyModuleMarker)



# Generated at 2022-06-21 22:01:02.248489
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test the constructor of class NonLocal
    assert(isinstance(NonLocal, type))
    assert(NonLocal.__name__ == 'NonLocal')
    assert(NonLocal.__class__.__name__ == 'type')
    assert(NonLocal.__doc__ == '\n    Simulates nonlocal keyword in Python 2\n    ')
    nl = NonLocal('apple')
    assert(isinstance(nl, NonLocal))
    assert(repr(nl) == "<NonLocal at " + id(nl) + ": 'apple'>")
    assert(nl.value == 'apple')


# Generated at 2022-06-21 22:01:11.419184
# Unit test for function make_lazy
def test_make_lazy():
    assert 'tests.test_lazy_import' not in sys.modules

    make_lazy('tests.test_lazy_import')

    assert 'tests.test_lazy_import' in sys.modules
    assert isinstance(sys.modules['tests.test_lazy_import'], _LazyModuleMarker)
    assert not hasattr(sys.modules['tests.test_lazy_import'], 'LAZY_CONST')

    from tests.test_lazy_import import LAZY_CONST

    assert LAZY_CONST == 9814

    from tests.test_lazy_import import NON_LAZY_CONST

    assert NON_LAZY_CONST == 1586

# Generated at 2022-06-21 22:01:24.191196
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import test_lazy
    make_lazy('test_lazy')
    assert not hasattr(test_lazy, 'os')
    assert isinstance(test_lazy, _LazyModuleMarker)
    test_lazy.os
    assert hasattr(test_lazy, 'os')
    assert test_lazy.os is os
    assert test_lazy.bar is os.path.join
    assert isinstance(test_lazy, ModuleType)

# Generated at 2022-06-21 22:01:26.628158
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker


# Generated at 2022-06-21 22:01:28.326818
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-21 22:01:32.098770
# Unit test for function make_lazy
def test_make_lazy():
    def test(attr):
        try:
            make_lazy(attr)
            # puts "Error: should have thrown exception."
            assert False
        except ImportError:
            pass

    yield test, "os"
    yield test, "sys"

# Generated at 2022-06-21 22:01:39.963060
# Unit test for function make_lazy
def test_make_lazy():

    # Our testing module
    class _TestModule(object):
        def __init__(self, name):
            self.name = name

        def test1(self):
            return self.name

        def test2(self):
            return self.name

    # A fake sys.modules to test the behavior of make_lazy
    _fake_sys_modules = NonLocal(_TestModule('sys.modules'))

    # Make sure that the module is not lazily imported until a resource
    # is requested
    _fake_sys_modules.value.test1 = make_lazy('sys.modules.test1')
    _fake_sys_modules.value.test2 = make_lazy('sys.modules.test2')

    assert isinstance(_fake_sys_modules.value.test1, _LazyModuleMarker)
    assert isinstance

# Generated at 2022-06-21 22:01:40.791333
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(25)
    print ("Value of variable x: ", x.value)
 
test_NonLocal()

# Generated at 2022-06-21 22:01:42.446467
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)



# Generated at 2022-06-21 22:01:43.554440
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()

# Generated at 2022-06-21 22:01:55.590243
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy works.
    """
    import sys
    import types
    from collections import namedtuple

    def reload_module(module):
        """
        Reload a module
        """
        if module.__name__ in sys.modules:
            del sys.modules[module.__name__]
        return types.ModuleType(
            module.__name__,
            module.__doc__,
        )

    # Test on a new module
    Test = namedtuple('Test', ['module_path', 'module_name', 'attr_name'])
    Test.__new__.__defaults__ = (None,) * len(Test._fields)

    test_modules = [Test('foo', 'foo', None), Test('foo.bar', 'bar', 'foo')]


# Generated at 2022-06-21 22:01:58.452484
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert type(lazy_module) == _LazyModuleMarker

# Test for constructor of class NonLocal

# Generated at 2022-06-21 22:02:04.871194
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    func = lambda: lazy_module.__mro__ + lazy_module.__getattribute__ + lazy_module.__init__
    assert func


# Generated at 2022-06-21 22:02:14.577140
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info[0] < 3:
        from nose.plugins.skip import SkipTest
        raise SkipTest("""This test needs Python 3 to run.""")

    import importlib
    import sys

    # Importing a module
    importlib.import_module('test_lazy_import')
    module = importlib.import_module('test_lazy_import.test_module')
    assert module.value == 42

    # Making lazy import
    make_lazy('test_lazy_import.test_module')
    module_lazy = sys.modules['test_lazy_import.test_module']
    assert module_lazy != module
    assert _LazyModuleMarker not in module.__mro__()
    assert isinstance(module_lazy, _LazyModuleMarker)

    # Imports are

# Generated at 2022-06-21 22:02:25.702723
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from unittest import main
    from mock import patch, MagicMock

    test_cases = (
        ('django.contrib.messages.storage.cookie', ('django', 'contrib', 'messages', 'storage', 'cookie')),
    )

    for given_module_path, expected in test_cases:
        with patch('sys.modules', new=dict()) as mock_sys_modules:
            make_lazy(given_module_path)
            mr = _LazyModuleMarker()

            # Unit test checking the attribute of __mro__ of class LazyModule
            assert mr.__mro__() == (LazyModule, ModuleType)

            # Unit test checking the attribute of __getattribute__ of class LazyModule
            assert mr.__getattribute__('__mro__') == mr.__

# Generated at 2022-06-21 22:02:28.831573
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class MyLazyModule(_LazyModuleMarker):
        def __init__(self):
            pass

    foo = MyLazyModule()
    assert isinstance(foo, _LazyModuleMarker)



# Generated at 2022-06-21 22:02:30.830371
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) is _LazyModuleMarker


# Generated at 2022-06-21 22:02:31.859889
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass



# Generated at 2022-06-21 22:02:33.498109
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(123)
    assert value.value == 123, "value.value == 123"

# Generated at 2022-06-21 22:02:38.628989
# Unit test for function make_lazy
def test_make_lazy():
    import os
    assert os.getcwd() == '.'
    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)
    assert os.getcwd() == os.getcwd()

# Dependencies for module numpy
make_lazy('numpy')

# Dependencies for module numpy.linalg
make_lazy('numpy.linalg')

# Dependencies for module numpy.random
make_lazy('numpy.random')



# Generated at 2022-06-21 22:02:40.778396
# Unit test for constructor of class NonLocal
def test_NonLocal():

    nl = NonLocal(None)

    assert isinstance(nl, NonLocal)
    assert nl.value is None



# Generated at 2022-06-21 22:02:46.194466
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'django.contrib.comments.forms'
    make_lazy(module_path)

    import django.contrib.comments.forms as _
    assert isinstance(_, _LazyModuleMarker)

    # Used to raise ImportError
    django.contrib.comments.forms.CommentForm()

# Generated at 2022-06-21 22:02:55.844375
# Unit test for function make_lazy
def test_make_lazy():
    import os
    make_lazy('os')
    assert not os.__dict__
    os.getcwd()
    assert os.__dict__

# Generated at 2022-06-21 22:03:06.112478
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import six
    # this should not import urllib2
    make_lazy('urllib2')

    assert 'urllib2' in sys.modules
    assert isinstance(sys.modules['urllib2'], six._LazyModuleMarker)
    assert not hasattr(sys.modules['urllib2'], '__file__')
    assert not hasattr(sys.modules['urllib2'], 'urlopen')
    # this should not import urllib
    make_lazy('urllib')

    assert 'urllib' in sys.modules
    assert isinstance(sys.modules['urllib'], six._LazyModuleMarker)
    assert not hasattr(sys.modules['urllib'], '__file__')

# Generated at 2022-06-21 22:03:15.895836
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest
    import sys
    import know_me

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.module_path = "know_me.test_module"

        def test_constant_creation(self):
            """
            Check that the module match the expected constant
            """
            make_lazy(self.module_path)
            self.assertIsInstance(sys.modules[self.module_path], _LazyModuleMarker)

        if __name__ == '__main__':
            unittest.main()

        test = TestCase()
        test.setUp()
        test.test_constant_creation()

# Generated at 2022-06-21 22:03:17.755105
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the __init__ function of _LazyModuleMaker
    """
    _LazyModuleMarker()


# Generated at 2022-06-21 22:03:23.507405
# Unit test for function make_lazy
def test_make_lazy():
    try:
        original_module = make_lazy('foo')
        assert not isinstance(sys.modules['foo'], ModuleType)
    finally:
        del sys.modules['foo']

# Generated at 2022-06-21 22:03:28.774862
# Unit test for function make_lazy
def test_make_lazy():
    class Test(object):
        def foo(self):
            return 'bar'
    # Add a module, which has a function
    sys.modules['test'] = Test()

    make_lazy('test')

    assert sys.modules['test'].foo() == 'bar'

# Generated at 2022-06-21 22:03:40.010500
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy function.
    """
    import os
    import sys

    # Function to remove module from sys.modules
    def remove_module(module_name):
        """
        Remove module from sys.modules
        """
        if module_name in sys.modules:
            del sys.modules[module_name]

    remove_module('test_make_lazy')

    import test_make_lazy
    assert sys.modules['test_make_lazy'] is test_make_lazy

    # Mark that this module should not be imported until an attribute is
    # needed off of it.
    make_lazy('test_make_lazy')

    # Remove the cached module
    remove_module('test_make_lazy')

    import test_make_lazy

# Generated at 2022-06-21 22:03:46.184951
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    # Add this directory to PATH to find test_module.
    sys.path.append(os.path.dirname(__file__))

    # Save a copy of sys.modules to restore its state
    modules = sys.modules.copy()

    # Remove "test_lazy_module" if it already exists in sys.modules,
    # and add it back in later.
    del sys.modules["test_lazy_module"]

    # Remove "test_lazy_module.foo" if it already exists in sys.modules,
    # and add it back in later.
    del sys.modules["test_lazy_module.foo"]

    make_lazy('test_lazy_module')

    # Test that the module is lazy by checking sys.modules

# Generated at 2022-06-21 22:03:57.231255
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    def test_make_lazy(module_path):
        sys_modules = sys.modules # cache in the locals

        # store our 'instance' data in the closure.
        module = NonLocal(None)

        class LazyModule(_LazyModuleMarker):

            def __mro__(self):
                # We don't use direct subclassing because `ModuleType` has an incompatible metaclass base with object (they are both in c) and we are overridding __getattribute__.
                # By putting a __mro__ method here, we can pass `isinstance` checks without ever invoking our __getattribute__ function.
                return (LazyModule, ModuleType)


# Generated at 2022-06-21 22:04:04.539579
# Unit test for function make_lazy
def test_make_lazy():
    # Create a fake module
    class FakeModule(object):
        foo = 1
    # Create fake sys.modules
    sys_modules = {'fake_module': FakeModule()}
    # Make a test function that uses make_lazy
    def test_function(module_path):
        make_lazy(module_path)
        return sys.modules[module_path]
    # Store the original sys.modules
    old_sys_modules = sys.modules
    # Assign test variable
    sys.modules = sys_modules
    # Perform the test

# Generated at 2022-06-21 22:04:27.151819
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
    assert _LazyModuleMarker() != _LazyModuleMarker()
    assert not (_LazyModuleMarker() == _LazyModuleMarker())
    assert _LazyModuleMarker() != object()
    assert not (_LazyModuleMarker() == object())

#Unit test for the class LazyModule
# def test_LazyModule():
#     import sys
#     class FakeModule(ModuleType):
#         pass
#     fake_mods = []
#     sys.modules = dict()
#     class FakeSys(object):
#         modules = dict()
#     fake_sys = FakeSys()
#     dummy_module_path = "lazy_module.test_lazy_module"
#     fake_module = FakeModule()
#     sys.modules[dummy_module_

# Generated at 2022-06-21 22:04:28.857047
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)

# Generated at 2022-06-21 22:04:34.361034
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'test.test_lazy_module_marker'
    module = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """
            if module.value is None:
                del sys_modules[module_path]
                module.value = __import__(module_path)

            return getattr(module.value, attr)


# Generated at 2022-06-21 22:04:40.673339
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Set up a non-local variable
    x = NonLocal(None)

    # A callable is a closure
    def set_x():
        x.value = 5

    # Run the closure and see if the non-local variable is set.
    set_x()

# Generated at 2022-06-21 22:04:44.783790
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_1 = NonLocal(None)
    nonlocal_2 = NonLocal(None)
    print(nonlocal_1 == nonlocal_2)

    nonlocal_1.value = 1
    print(nonlocal_1.value)
    print(nonlocal_2.value)


# Generated at 2022-06-21 22:04:45.923001
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(None)
    assert non_local.value == None



# Generated at 2022-06-21 22:04:48.597726
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-21 22:04:56.595793
# Unit test for function make_lazy
def test_make_lazy():
    assert 'lazy_obj' not in sys.modules
    make_lazy('lazy_obj')

    assert isinstance(sys.modules['lazy_obj'], _LazyModuleMarker)
    assert 'lazy_obj' not in sys.modules
    with pytest.raises(AttributeError):
        sys.modules['lazy_obj'].whatever

    assert 'lazy_obj' in sys.modules
    assert sys.modules['lazy_obj'].__name__ == 'lazy_obj'
    assert hasattr(sys.modules['lazy_obj'], '__mro__')

# Generated at 2022-06-21 22:04:57.885101
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(3)
    assert value.value == 3


# Generated at 2022-06-21 22:05:06.285470
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    sys_modules = sys.modules.copy()

    # Set up module_1
    def make_module_1(module_path):
        """
        Make a module that is just as expensive to import as module_2
        """
        class Module1(object):
            pass
        return Module1

    def make_module_2(module_path):
        """
        Make a module that is really expensive to import.
        """
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid()
        os.getpid

# Generated at 2022-06-21 22:05:38.668554
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = 2
    assert nl.value == 2



# Generated at 2022-06-21 22:05:40.132506
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10



# Generated at 2022-06-21 22:05:41.062430
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('foo')
    assert nl.value == 'foo'


# Generated at 2022-06-21 22:05:42.823550
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl=NonLocal(9)
    nl.value=6
    assert nl.value==6

# Generated at 2022-06-21 22:05:44.093247
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(NonLocal(1).value == 1)


# Generated at 2022-06-21 22:05:51.168121
# Unit test for function make_lazy
def test_make_lazy():
    import sys, os
    # Backup sys.modules
    sys.modules_backup = sys.modules.copy()
    # Clean up sys.modules
    sys.modules = {}
    # Create a empty module named 'test_make_lazy'
    sys.modules['test_make_lazy'] = ModuleType(os.path.basename('test_make_lazy'))
    # Mark the above module as lazy
    make_lazy('test_make_lazy')
    # Try to access a property of the lazy module (normally this is when it is
    # imported/loaded)
    test_make_lazy = sys.modules['test_make_lazy']
    assert isinstance(test_make_lazy, _LazyModuleMarker)

# Generated at 2022-06-21 22:05:58.860149
# Unit test for function make_lazy
def test_make_lazy():
    _old_sys_modules = sys.modules
    sys.modules = {}
    test_mod_path = 'foo.bar'

    assert test_mod_path not in sys.modules

    make_lazy(test_mod_path)

    assert test_mod_path in sys.modules
    assert sys.modules[test_mod_path] is not None
    assert isinstance(sys.modules[test_mod_path], _LazyModuleMarker)

    sys.modules = _old_sys_modules


# Use the make_lazy function to mark modules
if sys.version_info < (3, 3):
    # We need the test runner to be able to import these lazily
    make_lazy('django.test.utils')
    make_lazy('django.test.testcases')

    # We need to import these

# Generated at 2022-06-21 22:06:03.069867
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can use `make_lazy` as intended.
    """
    import sys

    import dateutil.parser

    assert isinstance(dateutil.parser, _LazyModuleMarker)
    assert not hasattr(dateutil.parser, '__mro__')

    assert dateutil.parser.parse('today')

# Generated at 2022-06-21 22:06:05.679777
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3
    a.value = 5
    assert a.value == 5

# Generated at 2022-06-21 22:06:17.944766
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    # Remove sys.modules['test_module'] if it exists
    if 'test_module' in sys.modules:
        del sys.modules['test_module']

    # Import test_module normally
    import test_module
    test_module.imported = True

    # Make test_module lazy, and it should not be imported
    make_lazy('test_module')
    import test_module
    assert test_module.imported is False

    # Access an attribute on test_module, and it should be imported
    import test_module.foo
    assert id(test_module.foo) == id(test_module.foo)
    assert test_module.imported is True

    # Remove sys.modules['test_module'] if it exists