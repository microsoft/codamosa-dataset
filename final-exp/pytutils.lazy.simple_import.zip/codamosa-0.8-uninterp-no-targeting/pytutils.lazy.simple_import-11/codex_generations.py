

# Generated at 2022-06-21 21:57:18.308347
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert not hasattr(NonLocal(None), 'value')
    n = NonLocal(1)
    assert n.value == 1


# Generated at 2022-06-21 21:57:22.472777
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = get_lazy_module_marker()
    assert lazy_module_marker == _LazyModuleMarker


# Generated at 2022-06-21 21:57:26.844469
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-21 21:57:29.593012
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value == 0
    n.value = 1
    assert n.value == 1


# Generated at 2022-06-21 21:57:32.351587
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert(LazyModuleMarker)


# Generated at 2022-06-21 21:57:35.710929
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = 5
    foo = NonLocal(x)
    assert foo.value == x


# Generated at 2022-06-21 21:57:38.748045
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 21:57:43.657214
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 1
    assert(nl.value == 1)
    nl.value = 2
    assert(nl.value == 2)

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-21 21:57:44.663481
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_marker = _LazyModuleMarker()

# Generated at 2022-06-21 21:57:47.058784
# Unit test for constructor of class NonLocal
def test_NonLocal():
    expected = "value"
    non_local = NonLocal(expected)
    assert non_local.value == expected
    assert non_local.value == "value"


# Generated at 2022-06-21 21:57:50.824030
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('test')
    assert nl.value == 'test'



# Generated at 2022-06-21 21:57:53.887514
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0
    x.value = 1
    assert x.value == 1
    x.value = 'a'
    assert x.value == 'a'



# Generated at 2022-06-21 21:57:56.653013
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy("test_module_hello_world")
        assert(test_module_hello_world.hello == "hello")
    finally:
        del sys.modules["test_module_hello_world"]


# Generated at 2022-06-21 21:58:07.212062
# Unit test for function make_lazy
def test_make_lazy():
    # Check that the module is not imported unless requested
    mod = sys.modules.pop('test_make_lazy_mod', None)
    if mod:
        del sys.modules['test_make_lazy_mod']
    make_lazy('test_make_lazy_mod')

    assert not hasattr(sys.modules['test_make_lazy_mod'], 'func')

    # Check that the module gets imported when an attribute is accessed
    sys.modules['test_make_lazy_mod'].func()
    assert hasattr(sys.modules['test_make_lazy_mod'], 'func')

    # Check that the module is able to be called
    # if the attribute is accessed first
    mod = __import__('test_make_lazy_mod')
    mod()

    # Check that the module is a

# Generated at 2022-06-21 21:58:20.011424
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("os")
    if isinstance(os, ModuleType):
        raise ImportError("os isn't lazy")
    os.path.basename("/tmp/foo.txt")
    from os import path
    if isinstance(os, ModuleType):
        raise ImportError("os isn't lazy")
    if isinstance(path, ModuleType):
        raise ImportError("os.path isn't lazy")
    os.path.basename("/tmp/foo.txt")

    # Be sure our lazy attribute is working correctly after the second import.
    make_lazy("os.path")
    try:
        os.path.basename("/tmp/foo")
    except AttributeError:
        raise ImportError("os.path is lazy")

# Generated at 2022-06-21 21:58:21.820394
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("value")
    assert nl.value == "value"

# Generated at 2022-06-21 21:58:32.064750
# Unit test for function make_lazy
def test_make_lazy():
    # Import our test module
    import test.test_lazyload
    import sys

    # Put the full module into memory
    test.test_lazyload.func_that_imports_its_own_module()

    # Make sure that the full module isn't in memory
    make_lazy('test.test_lazyload')
    import test.test_lazyload

    # Make sure that the full module is loaded into memory
    test.test_lazyload.atr1.atr1
    if test.test_lazyload.__img__ is not None:
        with open(test.test_lazyload.__img__, 'rb') as img:
            # Full module isn't in memory
            assert not img.read()

# Generated at 2022-06-21 21:58:33.242652
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-21 21:58:35.873759
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lame = _LazyModuleMarker()



# Generated at 2022-06-21 21:58:41.769478
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    module_path = 'a_fake_module'
    module = sys.modules[module_path]
    assert make_lazy(module_path) is None
    assert sys.modules[module_path] is not module
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    del sys.modules[module_path]
    assert module_path not in sys.modules

# Generated at 2022-06-21 21:58:46.713824
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1



# Generated at 2022-06-21 21:58:50.775402
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if __name__ == '__main__':
        print(NonLocal)
        test_NonLocal.value = []
        a = NonLocal(test_NonLocal.value)
        test_NonLocal.value.append(1)
        assert a.value == [1]

# Generated at 2022-06-21 21:58:53.141151
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-21 21:58:55.069566
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    assert a.value == 2
    a.value = 3
    assert a.value == 3

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:59:06.243778
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["foo.bar"] = 1
    make_lazy("foo.bar")
    assert sys.modules["foo.bar"] != 1
    assert not isinstance(sys.modules["foo.bar"], LazyModule)
    assert isinstance(sys.modules["foo.bar"], ModuleType)
    assert isinstance(sys.modules["foo.bar"], _LazyModuleMarker)
    assert getattr(sys.modules["foo.bar"], "__getattribute__") is not ModuleType.__getattribute__


# This is a list of modules that are safe to infer.
# Classes here are not safe to infer, only the modules.

# Generated at 2022-06-21 21:59:11.495159
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    # pylint: disable=import-error
    try:
        import example.lazy_module.lib.module2
        import example.lazy_module.lib.module3

        assert(True)
    except ImportError:
        assert(False)

# Generated at 2022-06-21 21:59:21.798749
# Unit test for function make_lazy
def test_make_lazy():
    # the __mro__ method of the LazyModule class must override the __mro__
    # method of the ModuleType class.
    # to do this, the following line overrides the LazyModule's __mro__
    # method (if it exists) to return a list of
    # classes that includes the ModuleType class
    LazyModule.__mro__ = staticmethod(lambda: (LazyModule, ModuleType))
    # if the __getattribute__ was not defined, the module would be
    # imported immediately
    m = __import__('__main__')
    assert isinstance(m, _LazyModuleMarker)
    assert not isinstance(m, ModuleType)
    # this line tries to call the __getattribute__ method of the
    # LazyModule, which causes the real module to be imported.
    # at this point

# Generated at 2022-06-21 21:59:30.108147
# Unit test for function make_lazy
def test_make_lazy():
    from test_module_1 import a
    assert a == 2

    # now, mark test_module_2 as a lazy module
    make_lazy('test_module_1')
    import test_module_1

    # Make sure we return the correct class
    assert isinstance(test_module_1, ModuleType)

    # Make sure it doesn't import yet
    assert test_module_1.b == 2

    # Make sure we can import the module
    from test_module_1 import c

    # Make sure the function is in the module
    assert test_module_1.d == 4

# Generated at 2022-06-21 21:59:37.358922
# Unit test for function make_lazy
def test_make_lazy():
    class FooModule(object):
        pass

    lazy_module = 'TEST_foo_module'
    make_lazy(lazy_module)
    module_to_test = sys.modules[lazy_module]

    assert isinstance(module_to_test, FooModule) is False
    assert hasattr(module_to_test, '__mro__')

    class Bar(object):
        def bar(self, module):
            return isinstance(module, FooModule)

    bar = Bar()
    assert bar.bar(module_to_test) is False
    sys.modules[lazy_module] = FooModule()
    assert bar.bar(module_to_test) is True

    del sys.modules[lazy_module]
    assert lazy_module not in sys.modules.keys()

# Generated at 2022-06-21 21:59:39.468677
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

# Generated at 2022-06-21 21:59:43.679236
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(value=1)

    assert nonlocal_obj.value == 1



# Generated at 2022-06-21 21:59:49.041706
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('txt_calculator.calculator')
    from txt_calculator.calculator import Calculator
    assert isinstance(sys.modules['txt_calculator.calculator'],
                      _LazyModuleMarker)
    assert isinstance(Calculator(), Calculator)
    assert not isinstance(Calculator(), _LazyModuleMarker)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-21 21:59:50.807524
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert n.value == None

    n = NonLocal(100)
    assert n.value == 100

# Generated at 2022-06-21 21:59:53.579149
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(
        _LazyModuleMarker(),
        _LazyModuleMarker
    )

# Generated at 2022-06-21 21:59:56.988821
# Unit test for constructor of class NonLocal
def test_NonLocal():
    f = NonLocal(3)
    print(f.value)

# Unit test of function make_lazy

# Generated at 2022-06-21 22:00:00.315898
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocalTest(_LazyModuleMarker):
        def __init__(self):
            self.a = NonLocal(2)

        def get_a(self):
            return self.a.value

    test = NonLocalTest()
    assert test.get_a() == 2



# Generated at 2022-06-21 22:00:01.916279
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker

# Generated at 2022-06-21 22:00:05.514075
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    assert type(lazy) == _LazyModuleMarker

# Test cases for test_make_lazy

# Generated at 2022-06-21 22:00:09.903720
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'django.utils.functional'
    make_lazy(module_name)

    # At this point, the module should not have loaded
    assert module_name not in sys.modules

    # But lazily importing the module should now work
    from django.utils.functional import allow_lazy

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:00:18.169242
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os, sys
    import imp
    import types

    try:
        # construct a module in memory, then add it to sys.modules
        test = imp.new_module('test')
        sys.modules['test'] = test
        assert type(test) is types.ModuleType

        # mark the module as a lazymodule
        make_lazy('test')

        # test the module
        assert isinstance(test, _LazyModuleMarker)

        # clean up
        del sys.modules['test']
    except:
        del sys.modules['test']
        raise

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 22:00:26.437572
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["foo"] = None
    make_lazy("foo")
    lazy_module = sys.modules["foo"]
    ok_(isinstance(lazy_module, _LazyModuleMarker))

    ok_(not hasattr(lazy_module, "attr"))
    # Access a function in the module - only then will it be imported.
    lazy_module.attr = 1
    ok_(hasattr(lazy_module, "attr"))

# Generated at 2022-06-21 22:00:38.884858
# Unit test for function make_lazy
def test_make_lazy():
    import pymongo
    try:
        import traceback
    except ImportError:  # python < 2.5
        import sys

        sys.stderr.write(
            "Warning: Unable to import traceback. "
            "Skipping test_make_lazy()\n")
        return

    make_lazy('traceback')
    assert isinstance(sys.modules['traceback'], _LazyModuleMarker)
    assert not hasattr(sys.modules['traceback'], 'format_tb')
    try:
        1/0
    except Exception:
        tb = sys.modules['traceback'].format_tb(sys.exc_info()[2])
    assert isinstance(sys.modules['traceback'], ModuleType)
    assert len(tb) > 0

# Generated at 2022-06-21 22:00:40.901504
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test for constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker()



# Generated at 2022-06-21 22:00:42.389266
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert x.value == 10

# To test if a module is lazy, we just check to see if it is an instance
# of our class.

# Generated at 2022-06-21 22:00:51.364871
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'testing.test_module_path'
    sys_modules = sys.modules
    try:
        sys_modules[module_path] = 'old_value'
        make_lazy(module_path)
        assert isinstance(sys_modules[module_path], _LazyModuleMarker)

        assert sys_modules[module_path].is_lazy_module == True
        assert isinstance(sys_modules[module_path], _LazyModuleMarker)

        assert sys_modules[module_path] is not sys.modules[module_path]
    finally:
        del sys_modules[module_path]


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:00:52.701421
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    ml = _LazyModuleMarker()
    assert ml is not None


# Generated at 2022-06-21 22:00:53.682992
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value==3

# Generated at 2022-06-21 22:00:55.794750
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nlObj = NonLocal(5)
    assert nlObj.value == 5

# Generated at 2022-06-21 22:00:57.951350
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_mod = _LazyModuleMarker()
    assert isinstance(test_mod, _LazyModuleMarker)


# Generated at 2022-06-21 22:01:05.094607
# Unit test for function make_lazy
def test_make_lazy():
    import unittest

    class TestModule(unittest.TestCase):
        def test_simple(self):
            """
            Test simple import (synchronous)
            """
            make_lazy('_lazy_module.utils.simple_module')
            from _lazy_module.utils.simple_module import SIMPLE_VALUE
            self.assertEqual(SIMPLE_VALUE, 'hello')

        def test_dynamic(self):
            """
            Test import of module with dynamically generated
            dependencies.
            """
            make_lazy('_lazy_module.utils.dynamic_module')
            from _lazy_module.utils.dynamic_module import DYNAMIC_VALUE
            self.assertEqual(DYNAMIC_VALUE, 'hello')


# Generated at 2022-06-21 22:01:13.110830
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(__name__)

    import pytest

    from _pytest.compat import isgenerator

    assert isinstance(pytest, _LazyModuleMarker)
    assert not isgenerator(pytest)

    assert isinstance(pytest.test, _LazyModuleMarker)
    assert isgenerator(pytest.test)

    del sys.modules[__name__]

# Generated at 2022-06-21 22:01:16.633788
# Unit test for constructor of class NonLocal
def test_NonLocal():
    __l = NonLocal(0)
    assert __l.value == 0
    __l.value = 1
    assert __l.value == 1

# Generated at 2022-06-21 22:01:20.591269
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy('.')
    assert isinstance(sys.modules['.'], _LazyModuleMarker)



# Generated at 2022-06-21 22:01:25.046421
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f():
        x = NonLocal("spam")
        x.value = 42
        #print("end of f x.value=", x.value)
        return x

    x = f()
    #print("after invoking f() x.value=", x.value)
    assert x.value == 42



# Generated at 2022-06-21 22:01:28.888723
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2


# Generated at 2022-06-21 22:01:31.397042
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl_obj = NonLocal(0)
    nl_obj.value = 3
    assert nl_obj.value == 3


# Generated at 2022-06-21 22:01:35.213762
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    nonlocal_mod = NonLocal(None)
    nonlocal_mod.value = [1,2,3]
    nonlocal_mod.value[1] = 4
    nonlocal_mod.value
    assert nonlocal_mod.value == [1,4,3]


# Generated at 2022-06-21 22:01:46.540967
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """

# Generated at 2022-06-21 22:01:58.598066
# Unit test for function make_lazy
def test_make_lazy():
    import os

    def test_lazy_import_os_path(module_path):
        make_lazy(module_path)
        lazy_os = sys.modules['os']

        # No exception means this worked
        os_path = lazy_os.path

    def test_is_lazy_module(module_path):
        import types
        make_lazy(module_path)
        module = sys.modules[module_path]
        assert isinstance(module, _LazyModuleMarker)

    def test_lazy_module_can_be_imported_twice(module_path):
        import types
        make_lazy(module_path)
        module = sys.modules[module_path]
        assert isinstance(module, _LazyModuleMarker)
        from os import path

# Generated at 2022-06-21 22:02:02.475230
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    nl.value = 6
    assert nl.value == 6
    assert nl == NonLocal(6)
    assert nl != NonLocal(5)
    assert nl != 3


# Generated at 2022-06-21 22:02:11.801045
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    This is not a unit test.
    Unit test for constructor of class NonLocal
    """
    nonlocal_ = NonLocal(100)

# Generated at 2022-06-21 22:02:15.918796
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert nl.value == 42



# Generated at 2022-06-21 22:02:26.617966
# Unit test for function make_lazy
def test_make_lazy():
    from functools import wraps
    from time import sleep
    GLOBALS=globals()
    def module(name):
        return GLOBALS[name]

    def lazy(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            make_lazy(f.__module__)
            return f(*args, **kwargs)
        return wrapper

    @lazy
    def test():
        from sys import modules
        sleep(2)
        return True

    # Test to ensure that it is lazy.
    assert module('test') is not True
    assert isinstance(module('test'), _LazyModuleMarker)

    # Test ensuring that it is not lazy.
    assert module('test') is True
    assert module('test') is True

# Generated at 2022-06-21 22:02:30.186530
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-21 22:02:32.009168
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def temp():
        m = NonLocal(3)
        print(m.value)
    temp()

# Generated at 2022-06-21 22:02:34.820000
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'tests.test_imports.LazyModule'
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

# Generated at 2022-06-21 22:02:35.992867
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None

# Generated at 2022-06-21 22:02:39.667771
# Unit test for function make_lazy
def test_make_lazy():
    """
    Sanity check to see if we captured the function or not
    """
    import sys
    assert 'make_lazy' not in sys.modules



# Generated at 2022-06-21 22:02:49.946597
# Unit test for function make_lazy
def test_make_lazy():
    def test_module_is_lazy(module_path):
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # test module
    module_path = 'tests.test_module_is_lazy'
    test_module = types.ModuleType(module_path)
    sys.modules[module_path] = test_module
    test_module.test_attr = 1
    test_module.test_list = [1, 2, 3]

    # make the module lazy
    make_lazy(module_path)

    test_module_is_lazy(module_path)

    # test attribute accessing
    assert sys.modules[module_path].test_attr == 1
    test_module_is_lazy(module_path)

    # test item accessing

# Generated at 2022-06-21 22:03:02.014189
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_name = 'lazy_module'

    module_attr_name = 'module_attr'

    module_attr_value = 'value'

    make_lazy(lazy_module_name)  # mark the module as lazy

    test_lazy_module = sys.modules[lazy_module_name]

    assert isinstance(test_lazy_module, _LazyModuleMarker)

    assert not hasattr(test_lazy_module, module_attr_name)

    test_lazy_module.module_attr = module_attr_value

    assert test_lazy_module.module_attr is module_attr_value

    assert hasattr(test_lazy_module, module_attr_name)

    assert isinstance(test_lazy_module, ModuleType)

# Generated at 2022-06-21 22:03:19.517432
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module'] = 'fake_module'

    # Mark the module as lazy
    make_lazy('lazy_module')

    # Now, the module shouldn't be imported
    assert sys.modules['lazy_module'] == 'fake_module'

    # While the module isn't imported, it should be a proxy
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

    # Now, by trying to get an attribute on it, it should be imported
    assert sys.modules['lazy_module'].__name__ == 'lazy_module'
    # And it shouldn't be a proxy any more
    assert not isinstance(sys.modules['lazy_module'], _LazyModuleMarker)
    # And the module object should be valid

# Generated at 2022-06-21 22:03:27.460691
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import pytest
    from types import ModuleType
    class C(object):
        pass

    lazy_module = _LazyModuleMarker()
    module = ModuleType('test_module')

    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(module, _LazyModuleMarker)
    assert not isinstance(C, _LazyModuleMarker)

    # Unit test for isinstance(mod, _LazyModuleMarker)
    def test_isinstance():
        import pytest
        from types import ModuleType
        class C(object):
            pass

        lazy_module = _LazyModuleMarker()
        module = ModuleType('test_module')

        assert isinstance(lazy_module, _LazyModuleMarker)

# Generated at 2022-06-21 22:03:30.688058
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        make_lazy(module_path = 'a')
    except BaseException:
        assert False
    else:
        assert True


# Generated at 2022-06-21 22:03:32.371914
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-21 22:03:36.872455
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Initialize a NonLocal variable
    example = NonLocal(1)
    # Check the value of the variable
    assert example.value == 1
    # Check that there is no exception thrown when assigning a new value
    example.value = 2
    # Check the value of the variable
    assert example.value == 2


# Generated at 2022-06-21 22:03:44.807151
# Unit test for function make_lazy
def test_make_lazy():
    import unittest
    import sys

    sys.modules.pop('test_mod', None)

    try:
        import test_mod  # noqa: F401
        assert False, 'This import should have thrown an assertion error.'
    except AssertionError:
        pass

    make_lazy('test_mod')

    test_mod = sys.modules['test_mod']
    assert isinstance(test_mod, NonLocal)
    assert test_mod.value is None

    try:
        test_mod.foo
        assert False, 'This should have thrown an attribute error.'
    except AttributeError:
        pass

    # Check isinstance
    assert isinstance(test_mod, _LazyModuleMarker)
    assert not isinstance(test_mod, ModuleType)

    # Check class hierarchy

# Generated at 2022-06-21 22:03:48.822079
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(sys, _LazyModuleMarker)
    assert not isinstance(_LazyModuleMarker(), ModuleType)



# Generated at 2022-06-21 22:03:52.205522
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    isinstance("notamodule", _LazyModuleMarker)


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-21 22:03:54.885643
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonloc = NonLocal(value=None)
    nonloc.value = module_path
    assert(nonloc.value == module_path)


# Generated at 2022-06-21 22:03:56.840201
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test of the constructor of NonLocal
    """
    a = NonLocal(1)
    assert a.value == 1



# Generated at 2022-06-21 22:04:16.741440
# Unit test for function make_lazy
def test_make_lazy():

    def get_module(name):
        return sys.modules[name]

    def check_lazy(name):
        import pytest

        module = get_module(name)
        pytest.assert_(isinstance(module, _LazyModuleMarker))

    def check_not_lazy(name):
        import pytest

        module = get_module(name)
        pytest.assert_(not isinstance(module, _LazyModuleMarker))

    if sys.version_info[0] >= 3:
        import imp

        def mock_find_module(name, *args):
            return (None, name, imp.PKG_DIRECTORY)


# Generated at 2022-06-21 22:04:18.365906
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert type(mod) == _LazyModuleMarker

# Generated at 2022-06-21 22:04:27.311535
# Unit test for function make_lazy
def test_make_lazy():
    _LOCAL_TEST_MODULES = {}

    class _TestSysModule(object):
        """
        Mocks sys.modules
        """
        def __init__(sel):
            self.modules = {}

        def __getitem__(self, key):
            return self.modules[key]

        def __setitem__(self, key, value):
            self.modules[key] = value

        def __delitem__(self, key):
            del self.modules[key]

    # Get our local copy
    _test_sys_modules = _TestSysModule()
    _test_sys_modules.modules = _LOCAL_TEST_MODULES

    # Setup module
    test_module = 'importable_module_name'
    _test_sys_modules.modules[test_module] = None

    #

# Generated at 2022-06-21 22:04:31.344837
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure a fake module is put in sys.modules
    # We don't import the types module to avoid an additional dependency.
    class FakeModule(object):
        pass
    sys.modules['types'] = FakeModule()

    # Now make the module lazy
    make_lazy('types')

    # Now make sure that it loads the real module
    import types as t
    assert isinstance(t, types.ModuleType)

# Generated at 2022-06-21 22:04:34.861766
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        assert(isinstance(object(), _LazyModuleMarker))
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-21 22:04:37.051998
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert isinstance(NonLocal('abc'), NonLocal)



# Generated at 2022-06-21 22:04:38.421463
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert not hasattr(NonLocal(5), 'value')


# Generated at 2022-06-21 22:04:40.393476
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
    assert _LazyModuleMarker().__class__ == _LazyModuleMarker


# Generated at 2022-06-21 22:04:44.406452
# Unit test for function make_lazy
def test_make_lazy():
    import math
    make_lazy('math')
    assert isinstance(sys.modules['math'], _LazyModuleMarker)
    assert sys.modules['math'] is not math
    assert isinstance(sys.modules['math'], ModuleType)
    assert sys.modules['math'].sin is math.sin
    assert sys.modules['math'].cos is math.cos
    assert sys.modules['math'] is math

# Generated at 2022-06-21 22:04:46.662876
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(type(LazyModule()), _LazyModuleMarker)
    assert not isinstance(type(LazyModule()), _LazyModuleMarker)
    assert isinstance(LazyModule(), _LazyModuleMarker)


# Generated at 2022-06-21 22:05:20.451527
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-21 22:05:21.516383
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()



# Generated at 2022-06-21 22:05:28.920384
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_make_lazy_module'

    # test module does not exist
    assert module_path not in sys.modules

    # import module.
    make_lazy(module_path)

    # module should now be in sys.modules
    assert module_path in sys.modules

    # module is a LazyModule
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # no actual module exists
    assert not hasattr(sys.modules[module_path], '__file__')

    # import a submodule.
    submodule = __import__(module_path, fromlist=['submodule'])

    # module should now be loaded into sys.modules
    assert module_path in sys.modules

    # actual module should now be in sys.modules
    assert submodule.__

# Generated at 2022-06-21 22:05:32.357076
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert isinstance(x, NonLocal)
    assert hasattr(x, 'value')
    assert x.value == 1
    x.value = 2
    assert x.value == 2

# Generated at 2022-06-21 22:05:40.481483
# Unit test for function make_lazy
def test_make_lazy():
    try:
        sys.modules.pop('testmod')
    except KeyError:
        pass

    import testmod

    assert isinstance(testmod, ModuleType)

    make_lazy('testmod')

    assert isinstance(testmod, _LazyModuleMarker)

    import testmod as testmod2
    assert isinstance(testmod2, _LazyModuleMarker)

    assert hasattr(testmod, '__name__')
    assert testmod.__name__ == 'testmod'

    assert testmod.a == 10

    sys.modules.pop('testmod2')


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:05:43.185695
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)


# Module under test
make_lazy("module_under_test")


# Generated at 2022-06-21 22:05:45.476514
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	marker_test = _LazyModuleMarker()
	try:
		isinstance(marker_test, _LazyModuleMarker)
	except:
		return False
	return True


# Generated at 2022-06-21 22:05:48.081050
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker().__class__ is _LazyModuleMarker)


# Generated at 2022-06-21 22:05:56.427766
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    m = __import__('os')
    assert m is sys.modules['os']

    make_lazy('os')

    module = __import__('os')
    assert sys.modules['os'] is not module

    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert not isinstance(module, _LazyModuleMarker)

    os_version = module.__version__

    assert sys.modules['os'] is not module
    assert sys.modules['os'].__version__ == os_version

    # Shouldn't load the module twice.
    assert sys.modules['os'].__version__ == os_version

# Generated at 2022-06-21 22:05:58.688074
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(5)
    assert(nonlocal_obj.value == 5)
    assert(nonlocal_obj.value == nonlocal_obj.value)



# Generated at 2022-06-21 22:06:40.251626
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(None)
    assert t.value == None
    t.value = 'test'
    assert t.value == 'test'


# Generated at 2022-06-21 22:06:50.593981
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType
    from bitmath.tests.test_bitmath import BitmathTest
    sys.modules.pop("bitmath.tests.test_bitmath")

    make_lazy("bitmath.tests.test_bitmath")
    assert "bitmath.tests.test_bitmath" in sys.modules
    assert isinstance(sys.modules["bitmath.tests.test_bitmath"], ModuleType)

    module = sys.modules["bitmath.tests.test_bitmath"]
    assert module.BitmathTest is None
    assert not isinstance(module, BitmathTest)
    assert isinstance(module, _LazyModuleMarker)

    assert module.BitmathTest is not None

    assert isinstance(module, BitmathTest)
    assert "BitmathTest" in dir(module)

# Generated at 2022-06-21 22:06:52.094551
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal("a")
    assert x.value == "a"



# Generated at 2022-06-21 22:06:56.089597
# Unit test for function make_lazy
def test_make_lazy():
    global sys
    sys.modules['the_module'] = None
    assert not isinstance(sys.modules['the_module'], _LazyModuleMarker)
    assert not isinstance(sys.modules['the_module'], ModuleType)
    assert not isinstance(sys.modules['the_module'], type(object))

    make_lazy('the_module')
    assert isinstance(sys.modules['the_module'], _LazyModuleMarker)
    assert isinstance(sys.modules['the_module'], ModuleType)
    assert not isinstance(sys.modules['the_module'], type(object))

# Generated at 2022-06-21 22:07:01.066590
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Check if the constructor of the _LazyModuleMarker class works.
    """
    try:
        import os
        test = _LazyModuleMarker()
        assert isinstance(test, _LazyModuleMarker)
    except AssertionError:
        print("assertion error")


# Generated at 2022-06-21 22:07:03.423987
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1



# Generated at 2022-06-21 22:07:07.095904
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an object of class _LazyModuleMarker
    test_marker = _LazyModuleMarker()
    # Check that object's type is _LazyModuleMarker
    assert(isinstance(test_marker, _LazyModuleMarker))
    # Check that object's type is not object
    assert(not isinstance(test_marker, object))
    # Check that object's type is not int
    assert(not isinstance(test_marker, int))
## Unit test for constructor of class NonLocal

# Generated at 2022-06-21 22:07:10.436599
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import pytest

    nl = NonLocal(None)
    nl.value = 1
    assert nl.value == 1, "incorrect value of NonLocal object"
    with pytest.raises(AttributeError):
        nl.abc = 1


# Generated at 2022-06-21 22:07:17.300549
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys

    sys.modules["test__LazyModuleMarker"] = sys.modules["__main__"]

    make_lazy("test__LazyModuleMarker")

    assert "test__LazyModuleMarker" in sys.modules
    assert isinstance(sys.modules["test__LazyModuleMarker"], _LazyModuleMarker)

    # clean up
    del sys.modules["test__LazyModuleMarker"]

