

# Generated at 2022-06-21 21:57:22.154721
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Unit test for constructor of class _LazyModuleMarker"""
    lazy = _LazyModuleMarker()
    assert(isinstance(lazy, _LazyModuleMarker))

# Generated at 2022-06-21 21:57:26.760737
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-21 21:57:29.098894
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3


# Generated at 2022-06-21 21:57:38.501123
# Unit test for function make_lazy
def test_make_lazy():
    @make_lazy('os')
    def test_func():
        return 'test_make_lazy'

    assert isinstance(test_func, _LazyModuleMarker)

    # LazyModule must be subclass of ModuleType to be recognized as module
    assert issubclass(test_func, ModuleType)
    assert isinstance(test_func, ModuleType)

    # Check that LazyModule is not imported
    assert 'os' not in sys.modules

    # Check that accessing attribute imports it
    assert callable(test_func.path)
    assert 'os' in sys.modules

# Generated at 2022-06-21 21:57:40.049456
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)

# Generated at 2022-06-21 21:57:43.395940
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class MyClass(object):
        pass

    o = MyClass()
    o.p = NonLocal(5)
    o.p.value = 6
    assert o.p.value == 6

# Generated at 2022-06-21 21:57:46.540767
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    test = _LazyModuleMarker()
    print(type(test))
    print(isinstance(test, _LazyModuleMarker))


# Generated at 2022-06-21 21:57:47.821304
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None


# Generated at 2022-06-21 21:57:55.832750
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure we can't import the module before it is made lazy.
    assert_raises(ImportError, __import__, 'make_lazy_test_module')

    # Make our module lazy
    make_lazy('make_lazy_test_module')

    # Make sure we are now able to import the module.
    assert_true(__import__('make_lazy_test_module'))

    # Make sure we can import all of the attributes on the module.
    module = __import__('make_lazy_test_module')
    assert_equals(module.hello_world(), 'Hello World!')

    # Make sure our module is now considered a LazyModule
    assert_true(isinstance(module, _LazyModuleMarker))

    # Make sure we can import the module after it is made lazy.

# Generated at 2022-06-21 21:57:56.614097
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 21:58:06.922286
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _LazyModuleMarkerTest(object):
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    class LazyModuleTest(_LazyModuleMarkerTest):

        def __mro__(self):
            return (LazyModuleTest, ModuleType)

        def __getattribute__(self, attr):
            if module.value is None:
                del sys_modules[module_path]
                module.value = __import__(module_path)

                sys_modules[module_path] = __import__(module_path)

            return getattr(module.value, attr)

    sys_modules[module_path] = LazyModuleTest()

# Generated at 2022-06-21 21:58:08.058268
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    pass


# Generated at 2022-06-21 21:58:11.319396
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()


# Generated at 2022-06-21 21:58:13.237437
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(value=3)
    assert nonlocal_instance.value == 3



# Generated at 2022-06-21 21:58:15.719215
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(25)
    assert(nonlocal_value.value == 25)
    assert(nonlocal_value is not None)

# Generated at 2022-06-21 21:58:18.063147
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a1 = _LazyModuleMarker()
    a2 = _LazyModuleMarker()
    assert a1 == a2


# Generated at 2022-06-21 21:58:21.139472
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from nose.tools import assert_equal

    l = NonLocal(3)
    assert_equal(l.value, 3)
    l.value = 7
    assert_equal(l.value, 7)


# Generated at 2022-06-21 21:58:31.393023
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that a new '_LazyModuleMarker' class is created.
    """
    # create a non-lazy module
    sys_modules = sys.modules  # cache in the locals

    module_path = "a.b.c"
    module = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `is

# Generated at 2022-06-21 21:58:33.280905
# Unit test for constructor of class NonLocal
def test_NonLocal():
    proxy = NonLocal(0)
    assert proxy.value == 0

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:58:45.228848
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    # Make sure we aren't already unit testing
    if 'TEST_LAZY_MODULE' in os.environ:
        return

    os.environ['TEST_LAZY_MODULE'] = 'True'
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    # Make sure we don't already import the module
    try:
        import lazy_module
        raise Exception("Importing lazy_module should throw an exception")
    except ImportError:
        pass

    make_lazy('lazy_module')

    # Make sure we don't import lazy_module yet
    import lazy_module
    del sys.modules['lazy_module']

    make_lazy('lazy_module')

    # Make sure we can import the module

# Generated at 2022-06-21 21:58:48.036137
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assume(False)

# Generated at 2022-06-21 21:58:49.953532
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("test")
    print("test_NonLocal: assign value to lacal variable nl")

# Generated at 2022-06-21 21:58:58.833848
# Unit test for function make_lazy
def test_make_lazy():
    assert not hasattr(sys.modules[__name__], 'make_lazy')
    assert not hasattr(sys.modules[__name__], 'NonLocal')
    assert hasattr(sys.modules[__name__], 'test_make_lazy')

    make_lazy(__name__)
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)

    assert hasattr(sys.modules[__name__], 'make_lazy')
    assert not hasattr(sys.modules[__name__], 'NonLocal')
    assert hasattr(sys.modules[__name__], 'test_make_lazy')


# Register the test module for lazy loading
make_lazy(__name__)

# Generated at 2022-06-21 21:59:08.345600
# Unit test for function make_lazy

# Generated at 2022-06-21 21:59:10.439933
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModule = _LazyModuleMarker()
    assert isinstance(lazyModule, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:21.069212
# Unit test for function make_lazy
def test_make_lazy():
    # Case where module is not yet loaded.
    sys.modules.pop("app.utils.make_lazy", None)
    make_lazy("app.utils.make_lazy")
    assert "app.utils.make_lazy" not in sys.modules
    # Check that module can be imported.
    __import__("app.utils.make_lazy")
    assert "app.utils.make_lazy" in sys.modules
    assert sys.modules["app.utils.make_lazy"].make_lazy is make_lazy

    # Case where module is already loaded.
    make_lazy("app.utils.make_lazy")
    assert "app.utils.make_lazy" in sys.modules
    assert sys.modules["app.utils.make_lazy"].make_lazy is make_l

# Generated at 2022-06-21 21:59:32.570117
# Unit test for function make_lazy
def test_make_lazy():
    # Unit tests for 'make_lazy'
    import os.path
    import sys

    class TestException(Exception):
        pass

    find_test_file = 'rplugin/python3/deoplete/util/find_rplugins.py'
    test_file_exists = os.path.exists(find_test_file)

    def __import__(name, globals=None, locals=None, fromlist=(), level=0):
        if name == 'rplugin.python3.deoplete.util.find_rplugins':
            raise TestException

    backup_import = __import__
    orig_sys_modules = sys.modules.copy()
    sys.modules['find_rplugins'] = None
    del sys.modules['find_rplugins']

# Generated at 2022-06-21 21:59:34.187393
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except TypeError:
        pass
    else:
        print("_LazyModuleMarker constructor test failed")
        

# Generated at 2022-06-21 21:59:35.923069
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_int = NonLocal(5)
    assertNonlocalIntEqual(nonlocal_int)


# Generated at 2022-06-21 21:59:38.691755
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    o = _LazyModuleMarker()
    assert isinstance(o, _LazyModuleMarker)


# Generated at 2022-06-21 21:59:44.790620
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()


# Generated at 2022-06-21 21:59:49.316962
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['foo'] = None
    make_lazy('foo')
    assert isinstance(sys.modules['foo'], _LazyModuleMarker)
    assert hasattr(sys.modules['foo'], '__getattribute__')
    assert hasattr(sys.modules['foo'], '__mro__')
    assert not hasattr(sys.modules['foo'], 'x')

    del sys.modules['foo']
    assert 'foo' not in sys.modules

# Generated at 2022-06-21 21:59:52.468138
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    assert isinstance(lm, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:02.718190
# Unit test for function make_lazy
def test_make_lazy():
    # import os
    # make_lazy('os')
    # with pytest.raises(ImportError):
    #     import os
    # assert os.path.exists('.')

    a = type('a', (object, ), {'x': 2})
    b = type('b', (object, ), {'x': 3})

    make_lazy('a')
    import a
    assert a.x == 2

    make_lazy('b')
    import b
    assert b.x == 3

    import sys
    assert 'a' in sys.modules
    assert 'b' in sys.modules



# Generated at 2022-06-21 22:00:05.931071
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(value=None)
    assert non_local.value == None
    assert non_local.__dict__ == {'value': None}


# Generated at 2022-06-21 22:00:08.242872
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for check constructor of class _LazyModuleMarker
    """
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))


# Generated at 2022-06-21 22:00:18.417722
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests make_lazy on a simple module with a string attribute.
    """
    make_lazy("test_module")

# Generated at 2022-06-21 22:00:28.243824
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Unit test for constructor
    test = _LazyModuleMarker()
    # Unit test for attribute module_path
    assert hasattr(test, "module_path") == False
    # Unit test for method __mro__
    assert hasattr(test, "__mro__") == True
    # Unit test for method __getattribute__
    assert hasattr(test, "__getattribute__") == True
    # Unit test for default method module_path
    assert test.module_path == None
    # Unit test for default method __mro__
    assert test.__mro__ == None
    # Unit test for default method __getattribute__
    assert test.__getattribute__ == None
    return

# Generated at 2022-06-21 22:00:34.327967
# Unit test for constructor of class NonLocal
def test_NonLocal():
    __assert = Assertions()

    class TestClass:
        a = NonLocal(1)

        def __init__(self):
            self.a = 2

        def inner(self):
            self.a = 3
            return self

    TestClass().inner().a == 3
    __assert(TestClass().inner().a, 3)

# Generated at 2022-06-21 22:00:35.928290
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_true(isinstance(_LazyModuleMarker(), object))



# Generated at 2022-06-21 22:00:51.733463
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function
    """
    def load_lazy():
        """
        A function to load a lazy module to test the make_lazy function.
        """
        make_lazy('_test_lazy_mod')

    def test_lazy_mod(arg):
        """
        This function will be loaded lazily.
        """
        return arg + 1

    sys.modules['_test_lazy_mod'] = sys.modules['__main__']
    load_lazy()
    del sys.modules['_test_lazy_mod']

    # Test that it returns the correct value
    assert test_lazy_mod(1) == 2

    # Test that it only loads once
    def reset():
        """
        Reset the mutable internal state.
        """

# Generated at 2022-06-21 22:00:52.770593
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)
    assert n.value == 3



# Generated at 2022-06-21 22:01:01.176430
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule(object):
        TEST = 1

    module_name = "test_lazy_module"
    sys.modules[module_name] = TestModule()

    make_lazy(module_name)
    assert isinstance(sys.modules[module_name], _LazyModuleMarker), "Module should be Lazy"
    assert sys.modules[module_name].TEST == 1, "LazyModule should allow us to access the actual module attributes"
    assert isinstance(sys.modules[module_name], TestModule), "LazyModule should pass isinstance checks"

# Generated at 2022-06-21 22:01:05.899234
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class X(object):
        def __init__(self, x):
            self.x = x

    x = X(1)
    assert NonLocal(x).value == x, "unit test failed"


# Generated at 2022-06-21 22:01:08.025434
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a=_LazyModuleMarker()
    assert(True)


# Generated at 2022-06-21 22:01:10.259060
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(7)
    assert n.value == 7



# Generated at 2022-06-21 22:01:12.215364
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker



# Generated at 2022-06-21 22:01:17.214137
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(lazy_imports._LazyModuleMarker, '__mro__')
    assert hasattr(lazy_imports._LazyModuleMarker, '__getattribute__')



# Generated at 2022-06-21 22:01:26.919665
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['__lazy__'] = None
    mod = sys.modules['__lazy__']

    def reload(mod):
        sys.modules['__lazy__'] = mod

    make_lazy('__lazy__')
    # mod should be a lazy module now.
    assert isinstance(mod, _LazyModuleMarker)
    # all attributes should be in the lazy module (e.g. __name__)
    for x in dir(mod):
        assert x in dir(mod.__class__)

    # On access, the module should be imported.
    reload(object())
    assert mod.__name__ == 'object'

    from os.path import join
    reload(join)
    assert mod.join('foo', 'bar') == 'foo/bar'


# Generated at 2022-06-21 22:01:32.045964
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazymod_instance = _LazyModuleMarker()
    # Type Error when passing in non-string
    with pytest.raises(TypeError):
        assert isinstance(1, _LazyModuleMarker)
    assert isinstance(lazymod_instance, _LazyModuleMarker)
    assert lazymod_instance is not None


# Generated at 2022-06-21 22:01:45.852759
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Test(_LazyModuleMarker):
        def __init__(self):
            super().__init__()
    t = Test()
    assert isinstance(t, _LazyModuleMarker)

# Generated at 2022-06-21 22:01:47.413167
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_is_instance(_LazyModuleMarker(), object)

# Generated at 2022-06-21 22:01:59.326146
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from ddt import ddt, data, unpack
    from nose.tools import assert_equal, assert_raises

    @ddt
    class TestNonLocal(object):
        # in closure, 'module' is a NonLocal(None)
        @data(False, True)
        def test_receives_value(self, init_value):
            module = NonLocal(init_value)
            assert_equal(module.value, init_value)

        # in closure, 'module' is a NonLocal(None)
        @data(False, True)
        def test_set_value(self, new_value):
            module = NonLocal(None)
            assert_equal(module.value, None)
            module.value = new_value
            assert_equal(module.value, new_value)

        # in closure, '

# Generated at 2022-06-21 22:02:08.744518
# Unit test for function make_lazy
def test_make_lazy():
    import unittest
    import tempfile
    import platform

    class TestMakeLazy(unittest.TestCase):
        def test_make_lazy(self):
            tempdir = tempfile.mkdtemp()
            filename = 'make_lazymocks.py'
            file_path = os.path.join(tempdir, filename)

# Generated at 2022-06-21 22:02:10.633287
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy('django.utils.module_loading.module_loading')
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-21 22:02:24.258508
# Unit test for function make_lazy
def test_make_lazy():
    modpath = "mylazydummymodule"

    assert modpath not in sys.modules
    make_lazy(modpath)
    assert modpath in sys.modules
    assert isinstance(sys.modules[modpath], _LazyModuleMarker)
    assert not isinstance(sys.modules[modpath], ModuleType)

    with pytest.raises(AttributeError):
        sys.modules[modpath].some_attribute

    class my_dummy_module(object):
        some_attribute = True

    make_real(modpath, my_dummy_module)
    assert isinstance(sys.modules[modpath], ModuleType)
    assert not isinstance(sys.modules[modpath], _LazyModuleMarker)
    assert sys.modules[modpath].some_attribute

    del sys.modules[modpath]
   

# Generated at 2022-06-21 22:02:26.304755
# Unit test for constructor of class NonLocal
def test_NonLocal():
    result = NonLocal(3)
    assert result.value == 3

# Generated at 2022-06-21 22:02:36.825377
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure the mock module behaves as expected
    """
    module_path = 'lazy_import.test_lazy_import.LazyModule'
    module = __import__(module_path)
    assert module.__dict__ == {'__name__': module_path, '__doc__': None, '__package__': None}
    assert 'X' not in module.__dict__

    from lazy_import.test_lazy_import import LazyModule
    assert LazyModule.X == 10

    LazyModule.Y = 20
    assert LazyModule.__dict__ == {'__name__': module_path, '__doc__': None, '__package__': None, 'X': 10, 'Y': 20}

    assert isinstance(sys.modules[module_path], ModuleType)
    assert isinstance

# Generated at 2022-06-21 22:02:38.276937
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()
    return True


# Generated at 2022-06-21 22:02:39.850661
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3


# Generated at 2022-06-21 22:03:04.123757
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    x=NonLocal(2)
    assert x.value==2
    assert type(x) is NonLocal

# Generated at 2022-06-21 22:03:09.463490
# Unit test for function make_lazy
def test_make_lazy():
    _test_mod = imp.new_module('test_module')

    class AwesomeClass(object):
        pass

    _test_mod.AwesomeClass = AwesomeClass

    sys.modules['test_module'] = _test_mod

    make_lazy('test_module')

    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)

    assert AwesomeClass is sys.modules['test_module'].AwesomeClass
    assert issubclass(sys.modules['test_module'].AwesomeClass, AwesomeClass)
    assert isinstance(sys.modules['test_module'].AwesomeClass(), AwesomeClass)

    sys.modules.pop('test_module')

# Generated at 2022-06-21 22:03:12.247688
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker != object


# Generated at 2022-06-21 22:03:14.438626
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''
    >>> nl1 = NonLocal(3)
    >>> nl1.value
    3
    '''



# Generated at 2022-06-21 22:03:17.364209
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test against standard modules.
    """
    import __builtin__
    make_lazy('__builtin__')
    assert(not isinstance(__builtin__, _LazyModuleMarker))


test_make_lazy()

# Generated at 2022-06-21 22:03:26.513551
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy function
    """
    # test a module that doesn't exist yet
    make_lazy('somenonexistentmodule')
    # it should show up in sys.modules now
    assert 'somenonexistentmodule' in sys.modules
    # but the module should not be the real module
    assert isinstance(sys.modules['somenonexistentmodule'], _LazyModuleMarker)

    # test a module that does exist
    make_lazy('os.path')
    # it should show up in sys.modules now
    assert 'os.path' in sys.modules
    # but the module should not be the real module
    assert isinstance(sys.modules['os.path'], _LazyModuleMarker)
    # and it should only be a lazy module

# Generated at 2022-06-21 22:03:30.136761
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    assert isinstance(lm, _LazyModuleMarker), 'lm is not an instance of _LazyModuleMarker'


# Generated at 2022-06-21 22:03:40.751700
# Unit test for function make_lazy
def test_make_lazy():
    from tests.test_lazy_load.dummy_module import do_something_dummy
    import tests.test_lazy_load.dummy_module
    make_lazy("tests.test_lazy_load.dummy_module")
    assert("tests.test_lazy_load.dummy_module" in sys.modules)
    assert(isinstance(sys.modules["tests.test_lazy_load.dummy_module"], ModuleType))
    assert(isinstance(sys.modules["tests.test_lazy_load.dummy_module"], _LazyModuleMarker))
    assert(sys.modules["tests.test_lazy_load.dummy_module"].do_something_dummy == do_something_dummy)

# Generated at 2022-06-21 22:03:46.104252
# Unit test for function make_lazy
def test_make_lazy():
    assert sys.modules.has_key('tests.test_sys')

    test_sys = sys.modules['tests.test_sys']
    assert isinstance(test_sys, ModuleType)

    # remove the module from memory
    del sys.modules['tests.test_sys']
    assert not sys.modules.has_key('tests.test_sys')


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 22:03:47.687754
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()


# Generated at 2022-06-21 22:04:46.733691
# Unit test for function make_lazy
def test_make_lazy():
    orig_sys_modules = sys.modules.copy()

    # This module imports
    import test_lazy_import
    test_lazy_import.__name__ = 'test_lazy_import'

    assert 'test_lazy_import' in sys.modules
    assert orig_sys_modules != sys.modules

    make_lazy('test_lazy_import')
    sys.modules['test_lazy_import'].__mro__
    assert 'test_lazy_import' in sys.modules
    assert orig_sys_modules != sys.modules

    dest = sys.modules['test_lazy_import']
    assert isinstance(dest, _LazyModuleMarker)
    del sys.modules['test_lazy_import']
    sys.modules['test_lazy_import'] = dest


# Generated at 2022-06-21 22:04:50.734604
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class a():
        def __init__(self):
            a.x = NonLocal(0)

        def set(self, x):
            a.x.value = x
    cl = a()
    cl.set(1)
    assert a.x.value == 1, "value is not 1"


# Generated at 2022-06-21 22:04:52.855451
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(LazyModule, _LazyModuleMarker)


# Generated at 2022-06-21 22:04:57.108844
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal(None)
    assert var.value == None
    var = NonLocal(None)
    assert var.value == None
    var = NonLocal([]), var.value
    assert hasattr(var, 'value')
    assert var.value == []
    var = NonLocal(None)
    assert var.value == None

# Generated at 2022-06-21 22:05:01.522097
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert obj.__class__ == _LazyModuleMarker
    assert obj.__class__.__name__ == "_LazyModuleMarker"
    assert obj.__dict__ == {}
    assert repr(obj) == "<class '_LazyModuleMarker'>"
    assert obj.__class__ == _LazyModuleMarker

# Generated at 2022-06-21 22:05:03.114535
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(5)
    assert non_local.value == 5


# Generated at 2022-06-21 22:05:12.477027
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import django.utils
    import django.utils.version

    assert sys.modules["django"].__class__ != make_lazy
    assert sys.modules["django.utils"].__class__ != make_lazy
    assert sys.modules["django.utils.version"].__class__ != make_lazy

    make_lazy('django.utils')

    assert sys.modules["django"].__class__ != make_lazy
    assert sys.modules["django.utils"].__class__ == make_lazy
    assert sys.modules["django.utils.version"].__class__ != make_lazy

    assert isinstance(django.utils.version, ModuleType)

# Generated at 2022-06-21 22:05:23.189253
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import stat

    # Cleanup os in the module cache
    if 'os' in sys.modules:
        del sys.modules['os']

    assert 'os' not in sys.modules
    make_lazy('os')
    assert 'os' in sys.modules
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert hasattr(sys.modules['os'], '__mro__')
    assert isinstance(sys.modules['os'], ModuleType)

    # Test that the stat module is really not yet loaded
    assert 'stat' not in sys.modules
    # Accessing a global on os will import the os module
    stat.S_ISDIR(0)
    assert 'stat' in sys.modules

    # Test that the lazy module got replaced

# Generated at 2022-06-21 22:05:30.806265
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that importing a module marked `make_lazy` doesn't import
    the module until an attribute is accessed.
    """
    test_module = 'tests.lazy_module_test'
    make_lazy(test_module)
    assert isinstance(sys.modules[test_module], _LazyModuleMarker)

    # Test that an attribute has been imported
    assert sys.modules[test_module].foo == 1

    # Test `isinstance`
    import tests.lazy_module_test
    assert isinstance(tests.lazy_module_test, ModuleType)

# Generated at 2022-06-21 22:05:32.959491
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert type(x) is NonLocal
    assert x.value is None
