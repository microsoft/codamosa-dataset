

# Generated at 2022-06-21 21:57:28.897680
# Unit test for function make_lazy
def test_make_lazy():
    def _test_module_path():
        # Make sure that the module can be resolved to an importable object.
        try:
            import path_test
        except ImportError:
            # This function is called by the unit tests inside tox.ini
            # tox.ini is located in the root directory, so running tox
            # from the current directory will fail to find the test module.
            # Try the directory above the current one:
            sys.path.append('..')
            import path_test
        return path_test.__name__

    # Before we make a module lazy, it should be importable.
    name = _test_module_path()
    importlib.import_module(name)

    # After we make it lazy, it should no longer be importable.
    make_lazy(name)

# Generated at 2022-06-21 21:57:32.604144
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f(x):
        nl = NonLocal(x)
        nl.value += 1
    f(2)



# Generated at 2022-06-21 21:57:37.886251
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Test constructor of class _LazyModuleMarker.
    """
    try:
        mark = _LazyModuleMarker()
    except:
        return False
    return True



# Generated at 2022-06-21 21:57:41.353413
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value == 0
    n.value = 1
    assert n.value == 1

# Generated at 2022-06-21 21:57:43.444083
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(5)
    assert x.value == 5

# Unit tests for the functions

# Generated at 2022-06-21 21:57:44.391163
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-21 21:57:47.645668
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # This is to test _LazyModuleMarker is callable
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, _LazyModuleMarker) == True
    return True


# Generated at 2022-06-21 21:57:48.454778
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-21 21:57:56.609891
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from mock import patch
    from nose.tools import assert_false, assert_true

    sys.modules['testmod'] = None
    make_lazy('testmod')

    # Check that the module was not loaded
    assert_false('testmod' in sys.modules)

    # Check that it is of type LazyModule
    assert_true(isinstance(sys.modules['testmod'], _LazyModuleMarker))

    # Check that it doesn't load with no attribute lookup
    assert_false('testmod' in sys.modules)

    # Check that it loads with an attribute lookup.
    with patch('__builtin__.__import__') as mock_import:
        sys.modules['testmod'].stuff

        assert_true(mock_import.called)

# Generated at 2022-06-21 21:57:59.837747
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var1 = NonLocal(None)
    assert var1.value == None
    var1.value = 1
    assert var1.value == 1



# Generated at 2022-06-21 21:58:02.026812
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1


# Generated at 2022-06-21 21:58:08.644956
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("foo.bar")
    import foo
    import foo.bar

    # Module is present but hasn't been loaded yet
    assert isinstance(foo.bar, _LazyModuleMarker)

    # Module is now loaded
    assert foo.bar.lorem == "ipsum"

    # Mypy should reject the following, as it won't accept isinstance(foo.bar, str)
    # but python will happily accept it
    if isinstance(foo.bar, str):
        assert False, "foo.bar is not a string!"  # pragma: no cover

# Generated at 2022-06-21 21:58:12.315988
# Unit test for constructor of class NonLocal

# Generated at 2022-06-21 21:58:14.830635
# Unit test for constructor of class NonLocal
def test_NonLocal():
    d = NonLocal(3)
    assert d.value == 3
    d.value = 4
    assert d.value == 4


# Generated at 2022-06-21 21:58:19.657199
# Unit test for function make_lazy
def test_make_lazy():
    import astroid  # pylint: disable=unused-variable,import-error
    assert not isinstance(astroid, _LazyModuleMarker)

    make_lazy('astroid')
    import astroid  # pylint: disable=unused-variable,import-error
    assert isinstance(astroid, _LazyModuleMarker)

# Generated at 2022-06-21 21:58:20.717081
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-21 21:58:23.969102
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('foo')
    assert nl.value == 'foo'
    nl.value = 'bar'
    assert nl.value == 'bar'



# Generated at 2022-06-21 21:58:31.269137
# Unit test for function make_lazy
def test_make_lazy():
    import os  # YES, this is the unit test!
    import sys
    make_lazy('os')
    assert 'os' in sys.modules
    assert not isinstance(sys.modules['os'], ModuleType)

    assert sys.modules['os'].path == os.path
    assert sys.modules['os'].path != 'foo'
    assert sys.modules['os'] == os


# Generated at 2022-06-21 21:58:32.515535
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    assert x.value == 42



# Generated at 2022-06-21 21:58:33.944526
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal
    assert isinstance(NonLocal(5), NonLocal)
    assert NonLocal(5).value == 5

# Generated at 2022-06-21 21:58:47.483700
# Unit test for function make_lazy
def test_make_lazy():
    from imp import reload
    from sys import modules
    import mylazymodule
    reload(mylazymodule)
    for mod in modules.values():
        if mod is __builtins__:
            continue
        assert getattr(mod, '__lazy__', False) == (mod.__name__ == 'mylazymodule')
    assert hasattr(mylazymodule, 'B')
    assert isinstance(mylazymodule, _LazyModuleMarker)



# Generated at 2022-06-21 21:58:50.722406
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModuleMarker = _LazyModuleMarker()
    # test that only an instance of the object is returned
    assert isinstance(lazyModuleMarker, _LazyModuleMarker)


# Generated at 2022-06-21 21:58:54.307234
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert(a.value == 1)
    a.value = 2
    assert(a.value == 2)
    b = NonLocal()
    assert(b.value == None)


# Generated at 2022-06-21 21:58:59.359343
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that make_lazy works
    """
    make_lazy('yak')

    from yak import hasattr  # ensure it propigated to the other modules
    assert not hasattr('yak', 'hasattr')

    from yak import hasattr  # ensure it propigated to the other modules
    assert hasattr('yak', 'hasattr')


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 21:59:02.211518
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''
    >>> Non = NonLocal(10)
    >>> Non.value
    10
    '''


# Generated at 2022-06-21 21:59:10.049992
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the behavior of make_lazy
    """
    # test that we successfully prevent importing
    from nose.plugins.skip import SkipTest
    import os

    make_lazy('os')

    try:
        os.path
    except AttributeError as e:
        assert "module" in str(e) and "'os' has no attribute 'path'" in str(e)
        assert sys.modules['os'] is os

    # test that we properly import
    os.path
    assert sys.modules['os'] is os

    # test that we prevent importing again
    import os

    try:
        os.path
    except AttributeError as e:
        assert "module" in str(e) and "'os' has no attribute 'path'" in str(e)
        assert sys.modules['os'] is os

    # test

# Generated at 2022-06-21 21:59:13.378804
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert(nl.value == 1)
    assert(hasattr(nl, 'value'))
    assert(not hasattr(nl, 'value2'))

# Generated at 2022-06-21 21:59:20.738786
# Unit test for function make_lazy
def test_make_lazy():
    #our_module_path = 'scrapy.utils.test_module'
    #our_module = import_module(our_module_path)
    #print our_module.test_mod
    make_lazy('scrapy.utils.test_module')
    #mod = import_module(module_path='scrapy.utils.test_module')
    mod = sys.modules['scrapy.utils.test_module']
    #print mod.test_mod
    assert not isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:23.254814
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    assert a.value == 2

# Unit test make_lazy function

# Generated at 2022-06-21 21:59:24.760634
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import inspect
    assert inspect.isclass(_LazyModuleMarker)


# Generated at 2022-06-21 21:59:39.279215
# Unit test for function make_lazy
def test_make_lazy():
    try:
        from test import lazy_module
        del sys.modules['test.lazy_module']
    except Exception:
        pass

    make_lazy('test.lazy_module')

    from test import lazy_module
    assert isinstance(lazy_module, _LazyModuleMarker)

    import test
    assert test.lazy_module is not lazy_module

    # Check that it still works with the module defined in sys.modules again.
    try:
        del sys.modules['test.lazy_module']
    except Exception:
        pass

    import test
    test.lazy_module.a

    assert test.lazy_module is not sys.modules['test.lazy_module']
    assert test.lazy_module.a is not sys.modules['test.lazy_module'].a




# Generated at 2022-06-21 21:59:42.791521
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import pytest
    my_non_local = NonLocal(1)
    assert(my_non_local.value == 1)



# Generated at 2022-06-21 21:59:45.049953
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(4)
    assert n.value == 4


# Generated at 2022-06-21 21:59:53.618161
# Unit test for function make_lazy
def test_make_lazy():
    def check_make_lazy(module_path):
        # Check that `mod` is a LazyModule
        mod = sys.modules[module_path]
        assert isinstance(mod, _LazyModuleMarker)

        # Check that we can get a version attribute properly.
        from importlib import __version__
        assert mod.__version__ == __version__

        # Check that the module is now no longer a LazyModule
        mod = sys.modules[module_path]
        assert not isinstance(mod, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:04.400315
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import pre_test
    except ImportError:
        pass
    else:
        raise ImportError('pre_test exists. Please clean up!')
    module_path = 'pre_test'
    make_lazy(module_path)
    import pre_test
    assert isinstance(pre_test, _LazyModuleMarker)
    try:
        import pre_test.submodule
    except ImportError:
        pass
    else:
        raise ImportError('pre_test.submodule exists. Please clean up!')
    try:
        import pre_test.class_
    except ImportError:
        pass
    else:
        raise ImportError('pre_test.class_ exists. Please clean up!')
    assert not hasattr(pre_test, 'CLASS')

# Generated at 2022-06-21 22:00:05.380714
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-21 22:00:10.383090
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    try:
        del sys.modules["lib.lazy_module_test"]
    except KeyError:
        pass
    make_lazy("lib.lazy_module_test")
    assert "lib.lazy_module_test" not in sys.modules
    assert hasattr(lib.lazy_module_test, "x")
    assert sys.modules["lib.lazy_module_test"] == lib.lazy_module_test



# Generated at 2022-06-21 22:00:13.716143
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Test(_LazyModuleMarker):
        pass
    assert isinstance(Test(), _LazyModuleMarker)
    assert isinstance(Test(), ModuleType)

# Generated at 2022-06-21 22:00:16.317000
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Act
    mod = _LazyModuleMarker()

    # Assert
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__class__ == _LazyModuleMarker


# Generated at 2022-06-21 22:00:22.394530
# Unit test for function make_lazy
def test_make_lazy():
    import test_module
    assert hasattr(test_module, 'test')

    make_lazy('test_module')

    # Make sure the module has been replaced
    assert not hasattr(test_module, 'test')

    # Make sure it is lazy
    assert isinstance(test_module, _LazyModuleMarker)

    # Make sure a lazy module is still an impo

# Generated at 2022-06-21 22:00:31.510270
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test a simple example to ensure our code works.
    """
    make_lazy('module_a')

    try:
        from module_a import a

        assert a == 1, "module state changed from when we set it up"
    except ImportError:
        assert False, "module should not have been imported"

# Generated at 2022-06-21 22:00:37.524228
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test.test_lazyimport'
    assert module_path not in sys.modules
    assert sys.modules[module_path] is make_lazy(module_path)
    assert module_path in sys.modules
    assert not hasattr(sys.modules[module_path], '__name__')
    assert sys.modules[module_path].__name__ == module_path

# Generated at 2022-06-21 22:00:44.859728
# Unit test for function make_lazy
def test_make_lazy():
    # Create a test module
    mod = imp.new_module('module')
    mod.foo = 'bar'

    def test():
        # Put the module in sys.modules
        sys.modules['module'] = mod

        # Make the module lazy
        make_lazy('module')

        # Assert that the module is now lazy
        assert isinstance(sys.modules['module'], _LazyModuleMarker)

        # Grab an attribute off of the module
        try:
            sys.modules['module'].foo
        except AttributeError as e:
            # AttributeErrors are OK because the LazyModule doesn't
            # have any attributes.
            pass
        else:
            # The module should not have been imported.
            assert False

        # Assert that the module has now been fully imported
        assert sys.modules['module']

# Generated at 2022-06-21 22:00:48.449145
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # make_lazy('a.b.c')
    module = NonLocal(None)
    assert(module.value is None)

    module = NonLocal(2)
    assert(module.value == 2)


# Generated at 2022-06-21 22:00:56.237346
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert inspect.isclass(_LazyModuleMarker)
    assert inspect.isclass(_LazyModuleMarker())
    assert not inspect.ismodule(_LazyModuleMarker)
    assert not inspect.ismodule(_LazyModuleMarker())
    assert not inspect.isfunction(_LazyModuleMarker)
    assert not inspect.isfunction(_LazyModuleMarker())
    assert not inspect.isbuiltin(_LazyModuleMarker)
    assert not inspect.isbuiltin(_LazyModuleMarker())
    assert not inspect.ismethod(_LazyModuleMarker)
    assert not inspect.ismethod(_LazyModuleMarker())

# Generated at 2022-06-21 22:00:57.503700
# Unit test for constructor of class NonLocal
def test_NonLocal():
    ''' 
    Test the constructor of class NonLocal
    '''
    a = NonLocal('a')
    assert a.value == 'a'

# Generated at 2022-06-21 22:00:59.584745
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("test")
    assert nl.value == "test"

# Generated at 2022-06-21 22:01:11.985190
# Unit test for function make_lazy
def test_make_lazy():
    # Simple case: lazy imports work
    import os
    make_lazy('os')
    from os import path  # expect no exception here
    assert isinstance(os, _LazyModuleMarker)


    # `import os` can still be used as normal
    import os

    def test_import_os():
        # import os
        # assert isinstance(os, _LazyModuleMarker)
        raise AssertionError("Lazy import should not have been loaded yet")

    def test_import_path():
        assert path.exists(__file__)

    test_import_os()
    test_import_path()

# Generated at 2022-06-21 22:01:14.994150
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_instance = NonLocal(1)
    assert test_instance.value == 1


# Generated at 2022-06-21 22:01:17.784554
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(sys.modules['django.utils.lazy'], _LazyModuleMarker)

# Generated at 2022-06-21 22:01:30.586206
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mod = _LazyModuleMarker()
    mod = ModuleType('test_module')
    assert type(lazy_mod) != type(mod)
    assert type(lazy_mod) == _LazyModuleMarker
    assert type(mod) == ModuleType


# Generated at 2022-06-21 22:01:39.228107
# Unit test for function make_lazy
def test_make_lazy():
    # Test public interface.
    from pythontesting import TestingModule
    assert isinstance(TestingModule, _LazyModuleMarker)
    assert TestingModule.TestClass

    make_lazy('pythontesting.test_make_lazy')

    # Test public interface.
    from pythontesting import test_make_lazy
    assert isinstance(test_make_lazy, _LazyModuleMarker)
    assert test_make_lazy.make_lazy

    # Test calling function
    test_make_lazy.make_lazy('pythontesting.test_make_lazy2')
    from pythontesting import test_make_lazy2
    assert isinstance(test_make_lazy2, _LazyModuleMarker)
    assert test_make_lazy2.make_lazy2

# Generated at 2022-06-21 22:01:51.344443
# Unit test for function make_lazy
def test_make_lazy():
    # Clean up the sys.modules so that the test is independent
    from itertools import chain
    from functools import wraps
    #
    # Clear the module cache
    #
    rm_lazy = lambda module_name: sys.modules.pop(module_name, None)
    cleand = [rm_lazy(module_name) for module_name in sys.modules]
    del cleand
    #
    # Add a module to the system
    #
    module_name = 'test_make_lazy'
    test_module = ModuleType(module_name)
    test_module.__dict__['__doc__'] = "Unit test for function make_lazy"
    sys.modules[module_name] = test_module
    #
    # Check that it is in the system
    #

# Generated at 2022-06-21 22:01:55.113125
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Check assigning and accessing class NonLocal
    l = NonLocal(1)
    assert l.value == 1
    l.value = 2
    assert l.value == 2


# Generated at 2022-06-21 22:02:03.519920
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import os.path
    import sys

    sys.modules['os.path'] = None

    make_lazy('os.path')
    assert isinstance(os.path, _LazyModuleMarker)
    assert os.path.dirname is os.path.dirname
    assert os.path.dirname('.') == os.path.dirname
    assert os.path.dirname is os.path.dirname
    assert 'os.path' in sys.modules
    assert sys.modules['os.path'] is not None
    assert isinstance(os.path, ModuleType)


# Generated at 2022-06-21 22:02:04.960902
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert (issubclass(LazyModule, _LazyModuleMarker))


# Generated at 2022-06-21 22:02:09.980470
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker) == True
    assert isinstance(marker, ModuleType) == False


# Generated at 2022-06-21 22:02:12.365305
# Unit test for function make_lazy
def test_make_lazy():
    from os import path

    assert path.join('a', 'b') == 'a/b'

    make_lazy('os')

    assert path.join('a', 'b') == 'a/b'

# Generated at 2022-06-21 22:02:23.442560
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from w3af.core.data.misc.encoding import smart_str_ignore


# Generated at 2022-06-21 22:02:28.025928
# Unit test for function make_lazy
def test_make_lazy():
    import my
    import unittest

    class TestLazyModule(unittest.TestCase):
        def test_isinstance(self):
            # Test that we can correctly check if a module is lazy.
            self.assert_(isinstance(my, _LazyModuleMarker))

        def test_proxy_lazy_module(self):
            # Test that we can correctly check if a module is lazy.
            self.assertEqual(my.x, 'lazy-loaded')

    unittest.main()

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:02:46.144789
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_nonlocal = NonLocal(2)
    assert test_nonlocal.value == 2


# Generated at 2022-06-21 22:02:52.024720
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test if the NonLocal object is behaving as expected.
    """
    class TestNonLocal(object):
        """
        A class which uses NonLocal class
        """
        def __init__(self):
            self.nonlocal_obj = NonLocal(None)
            self.nonlocal_obj.value = 1

        def get_value(self):
            """
            Return the value of nonlocal object
            """
            return self.nonlocal_obj.value

    # Create a object of TestNonLocal
    obj = TestNonLocal()
    # Check if the value is set correctly
    assert 1 == obj.get_value()



# Generated at 2022-06-21 22:02:53.566461
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)

# Generated at 2022-06-21 22:02:59.061347
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)

# get module path
if __name__ == "__main__":
    test__LazyModuleMarker()
    module_path = 're'
    make_lazy(module_path)
    sys.modules[module_path]

# Generated at 2022-06-21 22:03:06.713941
# Unit test for function make_lazy
def test_make_lazy():
    "Test make_lazy function"
    import types
    module_path = "test_lazy_module"
    mod = types.ModuleType(module_path)
    mod.val = "this is required module"
    sys.modules[module_path] = mod

    make_lazy(module_path)
    mod = sys.modules[module_path]

    assert isinstance(mod, _LazyModuleMarker)

    # Accessing any attribute, triggers import.
    assert mod.val == "this is required module"
    assert isinstance(mod, types.ModuleType)
    assert mod.__name__ == module_path

# Generated at 2022-06-21 22:03:17.686624
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """
    sys_modules = sys.modules  # cache in the locals
    module_path = 'tests.lazy'
    if module_path in sys.modules:
        del sys.modules[module_path]
    from tests.lazy import module
    del sys.modules[module_path]
    to_patch = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'lazy.py')
    assert not os.path.exists(to_patch)
    make_lazy(module_path)
    module_obj = sys.modules[module_path]
    assert isinstance(module_obj, _LazyModuleMarker)

# Generated at 2022-06-21 22:03:21.044038
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()

    assert(isinstance(lazy_module, _LazyModuleMarker))


# Generated at 2022-06-21 22:03:22.342187
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(3)
    assert i.value == 3



# Generated at 2022-06-21 22:03:24.084131
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    assert isinstance(nl, NonLocal)
    assert nl.value == 123



# Generated at 2022-06-21 22:03:28.520022
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert lazy_module.__module__ == 'newrelic.common.lazy_module'


# Unit tests for class LazyModule

# Generated at 2022-06-21 22:03:59.918852
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  print("Constructor for class _LazyModuleMarker")

# Generated at 2022-06-21 22:04:13.142970
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'import_me'
    module_path = 'tests.lazy_import.import_me'
    module = sys.modules[module_path]
    import_me = module.import_me = ModuleType(module_name)
    import_me.a = 'foo'

    make_lazy(module_path)

    # Check that we did not import the module on create.
    assert not isinstance(module, ModuleType)
    assert module.__name__ == module_name
    assert type(module).__name__ == 'LazyModule'
    assert 'import_me' not in sys.modules

    # Check that we can still access attributes.
    assert module.a == 'foo'

    # Check that we imported the module after access
    assert isinstance(module, ModuleType)
    assert type(module).__

# Generated at 2022-06-21 22:04:14.647198
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(3)
    assert v.value == 3


# Generated at 2022-06-21 22:04:24.694487
# Unit test for function make_lazy
def test_make_lazy():
    import __main__
    import os

    def helper_assert_module_was_imported(module):
        '''
        Helper function to assert that the module is loaded into sys.modules
        and that we can access the module attributes without executing __getattribute__
        since a module is loaded directly into sys.modules we can access the attributes
        using the module.attribute format instead of using the __getattribute__ method.
        '''
        assert module_path in sys.modules
        assert module.PATH == __file__
        assert module.FILE == os.path.basename(__file__)
        assert module.DIR == os.path.dirname(__file__)
        assert module.MESSAGE == 'Hello from test_make_lazy()'

    # Create a module to load

# Generated at 2022-06-21 22:04:25.837499
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-21 22:04:31.473231
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)

    os.getcwd()  # import os
    assert isinstance(os, ModuleType)
    assert hasattr(os, 'getcwd')

    # os should be imported now.
    make_lazy('os')
    assert isinstance(os, ModuleType)
    assert hasattr(os, 'getcwd')

    # force import!
    os.getegid()
    assert hasattr(os, 'getegid')

# Generated at 2022-06-21 22:04:42.575694
# Unit test for function make_lazy
def test_make_lazy():
    def test_mod(module_path):
        sys_modules = sys.modules
        # Local variable
        test_var = 100
        module = NonLocal(None)

        class LazyModule(_LazyModuleMarker):
            def __mro__(self):
                return (LazyModule, ModuleType)

            def __getattribute__(self, attr):
                if module.value is None:
                    del sys_modules[module_path]
                    module.value = __import__(module_path)
                    sys_modules[module_path] = __import__(module_path)

                return getattr(module.value, attr)

        sys_modules[module_path] = LazyModule()

    # Import make_lazy
    make_lazy('make_lazy')

    # Test make_lazy as lazy import

# Generated at 2022-06-21 22:04:45.382473
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if sys.version_info >= (3,):
        def test():
            x = 10
            print(x)

        assert_raises(SyntaxError, test)
    x = NonLocal(10)
    assert x.value == 10
    x.value = 20
    assert x.value == 20


# Generated at 2022-06-21 22:04:56.383268
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        def __init__(self):
            self.value = 1

    sys.modules["A"] = A()
    make_lazy("A")

    # Since we are making A lazy, if we access any attribute it will
    # import A, thus setting the attribute value to 2
    sys.modules["A"].value = 2
    assert sys.modules["A"].value == 2
    assert isinstance(sys.modules["A"], ModuleType)
    assert not isinstance(sys.modules["A"], _LazyModuleMarker)
    assert sys.modules["A"].__class__.__name__ == "A"

    # Making A lazy again should not change the state of A
    make_lazy("A")
    assert sys.modules["A"].value == 2

# Generated at 2022-06-21 22:04:58.055005
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal("test")
    assert nonlocal_.value == "test"


# Generated at 2022-06-21 22:06:13.000588
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)



# Generated at 2022-06-21 22:06:14.782739
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    val = _LazyModuleMarker()
    assert isinstance(val, _LazyModuleMarker)


# Generated at 2022-06-21 22:06:24.882872
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_make_lazy_module'

    def is_lazy(module):
        return isinstance(module, _LazyModuleMarker)

    # Check that the module is lazy
    assert is_lazy(sys.modules[module_path])

    # Access an attribute to make sure it's loaded.
    assert sys.modules[module_path]._is_loaded

    # Check to make sure the module is no longer lazy.
    assert not is_lazy(sys.modules[module_path])


# Create the module to test if it's lazy
make_lazy('test_make_lazy_module')

# Generated at 2022-06-21 22:06:27.297251
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test __init__ method of the NonLocal class
    nl = NonLocal(1)
    assert(nl.value == 1)



# Generated at 2022-06-21 22:06:35.526706
# Unit test for constructor of class NonLocal
def test_NonLocal():
    declared_at_global_scope = NonLocal(None)

    def test():
        declared_at_function_scope = NonLocal(None)
        assert declared_at_global_scope.value is None
        assert declared_at_function_scope.value is None

        def test():
            # Assert that declared_at_function_scope is not the same object
            # as the declared_at_function_scope in test().
            assert declared_at_function_scope.value is None
        test()

        declared_at_function_scope.value = 'setting a value'
        assert declared_at_function_scope.value == 'setting a value'

    test()


# Generated at 2022-06-21 22:06:46.354006
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for make_lazy
    """
    import sys
    import django
    if django.VERSION[:2] >= (1, 7):
        print("Skip this test because python3 force to load all the modules")
    else:
        import os
        import os.path

        make_lazy('os')
        make_lazy('os.path')

        assert 'os' not in sys.modules
        assert 'os.path' not in sys.modules

        os.path
        os
        assert 'os' in sys.modules
        assert 'os.path' in sys.modules


# Marks that given module should not be imported until an
# attribute is needed off of it.

# Generated at 2022-06-21 22:06:57.606219
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    class module_factory(object):
        def __init__(self, module_path):
            self.module_path = module_path
        def __getattribute__(self, attr):
            if attr == 'value':
                del sys_modules[self.module_path]
                self.value = __import__(self.module_path)
                sys_modules[self.module_path] = self.value
            return super(module_factory, self).__getattribute__(attr)

    module_path = 'lazy_module'
    lazy_module = module_factory(module_path)
    sys_modules[module_path] = lazy_module
    make_lazy(module_path)
    # Now that the module is lazy, we shouldn't be able to import it


# Generated at 2022-06-21 22:07:01.564492
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'os.path'
    make_lazy(module_path)
    assert not os.path  # This will be a NotImportedError object
    from os import path
    assert path.__name__ == 'os.path'


# Generated at 2022-06-21 22:07:03.931780
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test the constructor
    a = NonLocal(10)
    assert a.value == 10


# Generated at 2022-06-21 22:07:09.287589
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    bi = NonLocal(4)
    assert bi.value == 4
    try:
        bi.value = 5
    except Exception:
        pass
    else:
        assert False
    # Test if we can access bi.value
    assert bi.value == 4
    assert sys.getrefcount(bi) == 2
    # Return a non-nil value to indicate success
    return 'OK'

