

# Generated at 2022-06-21 21:57:27.744933
# Unit test for function make_lazy
def test_make_lazy():
    import django.db

    # Check that there is an error before make_lazy
    try:
        django.db.connections
        assert False, "No error raised."
    except ImportError:
        pass

    django.db.connections
    make_lazy('django.db')
    try:
        django.db.connections
        assert False, "No error raised."
    except ImportError:
        pass

    # Check that there is no error after importing
    import django.db
    django.db.connections



# Generated at 2022-06-21 21:57:30.737873
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, object)


# Generated at 2022-06-21 21:57:32.813862
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value == None


# Generated at 2022-06-21 21:57:34.629873
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)

# Generated at 2022-06-21 21:57:40.352304
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    y = x
    assert x.value == 1
    assert y.value == 1
    x.value = 2
    assert x.value == 2
    assert y.value == 2


# Generated at 2022-06-21 21:57:43.364014
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1

    with pytest.raises(AttributeError):
        nl.value = 2


# Generated at 2022-06-21 21:57:51.564134
# Unit test for function make_lazy
def test_make_lazy():
    import os
    from types import ModuleType

    sys.modules.pop('mymodule', None)

    assert mymodule not in sys.modules
    assert 'mymodule' not in os.listdir(os.curdir)

    import mymodule
    assert inspect.ismodule(mymodule)
    assert mymodule in sys.modules
    assert 'mymodule' in os.listdir(os.curdir)

    make_lazy('mymodule')
    assert inspect.ismodule(mymodule)
    assert isinstance(mymodule, _LazyModuleMarker)
    assert mymodule in sys.modules
    assert 'mymodule' not in os.listdir(os.curdir)

    assert mymodule.foo() == 1
    assert inspect.ismodule(mymodule)

# Generated at 2022-06-21 21:57:53.147288
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except TypeError:
        print('__init__() takes no parameters')


# Generated at 2022-06-21 21:57:55.358223
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value == None
    nl.value = 1
    assert nl.value == 1




# Generated at 2022-06-21 21:57:56.757911
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = 1
    nl = NonLocal(x)
    assert nl.value == 1


# Generated at 2022-06-21 21:58:04.090761
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker, '__repr__')
    assert hasattr(_LazyModuleMarker, '__str__')
    assert hasattr(_LazyModuleMarker, '__getattribute__')
    assert hasattr(_LazyModuleMarker, '__mro__')


# Generated at 2022-06-21 21:58:05.808139
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1

# unit test for make_lazy

# Generated at 2022-06-21 21:58:07.772404
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert isinstance(obj, _LazyModuleMarker), "obj is not an instance of _LazyModuleMarker"
    return obj



# Generated at 2022-06-21 21:58:14.831122
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_true
    from nose.tools import assert_false
    m = _LazyModuleMarker()
    assert_true(isinstance(m, _LazyModuleMarker))
    assert_false(isinstance(m, object))
    # print('test__LazyModuleMarker pass')


# Generated at 2022-06-21 21:58:18.006166
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Test(_LazyModuleMarker):
        def __init__(self):
            pass
    t = Test()
    assert(t.__mro__ == (Test, object))



# Generated at 2022-06-21 21:58:19.729530
# Unit test for constructor of class NonLocal
def test_NonLocal():
    global_val = None
    x = NonLocal(global_val)

# Generated at 2022-06-21 21:58:21.570186
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert lazy_module is not None


# Generated at 2022-06-21 21:58:24.671683
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None
    b = NonLocal("Lazy Loader")
    assert b.value == "Lazy Loader"


# Generated at 2022-06-21 21:58:27.694089
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    a = NonLocal(3)
    assert a.value == 3
    a.value = 5
    assert a.value == 5

# Generated at 2022-06-21 21:58:29.762408
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    print(nl.value)


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:58:46.750976
# Unit test for function make_lazy
def test_make_lazy():
    # Skip this test in Python 3, since a LazyModule no longer inherits from
    # ModuleType.
    import sys
    if sys.version_info[0] == 3:
        return

    import sys
    import os
    import imp
    import tempfile

    # First create a temporary module
    module_name = 'test_lazy_import'
    test_module = tempfile.NamedTemporaryFile(suffix='.py', prefix='foo',
                                              delete=False)
    test_module.write(
        'class Foo:\n'
        '    def __repr__(self):\n'
        '        return "foo"\n'
        'bar = Foo()\n'
    )
    test_module.close()

    # Import the module the normal way

# Generated at 2022-06-21 21:58:51.700224
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value1 = "Hello World"
    test_value2 = "Goodbye Moon"

    test_object = NonLocal(test_value1)
    assert test_object.value == test_value1

    test_object.value = test_value2
    assert test_object.value == test_value2


# Generated at 2022-06-21 21:59:00.362015
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    assert 'tests.make_lazy.test_module' not in sys.modules
    assert 'tests.make_lazy.test_module2' not in sys.modules

    make_lazy('tests.make_lazy.test_module')
    make_lazy('tests.make_lazy.test_module2')

    assert sys.modules['tests.make_lazy.test_module'] is not None
    assert sys.modules['tests.make_lazy.test_module2'] is not None
    assert isinstance(sys.modules['tests.make_lazy.test_module'], _LazyModuleMarker)
    assert isinstance(sys.modules['tests.make_lazy.test_module2'], _LazyModuleMarker)

    import tests.make_lazy.test_module

# Generated at 2022-06-21 21:59:01.982312
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-21 21:59:03.971457
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        assert _LazyModuleMarker()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 21:59:11.067540
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that a lazy module is accessed correctly.
    """
    # Make a new module
    module_path = 'test_module'
    sys_modules = sys.modules

    module_attrs = {'FOO': 'bar'}
    module = ModuleType(module_path)
    module.__dict__ = module_attrs

    sys_modules[module_path] = module

    # Make it lazy
    make_lazy(module_path)
    lazy_module = sys_modules[module_path]

    # Check the attributes (make sure it hasn't been loaded)
    assert not hasattr(lazy_module, 'FOO')
    assert not hasattr(lazy_module, 'BAZ')

    # Access the attribute
    assert lazy_module.FOO == 'bar'

# Generated at 2022-06-21 21:59:21.528471
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can use make_lazy to delay importing a module and have
    it's correct dunder methods.
    """
    mod_path = '__test_make_lazy__'

    make_lazy(mod_path)

    sys.modules[mod_path]

    # We should not be able to import the module.
    with pytest.raises(AttributeError):
        import __test_make_lazy__

    # Providing an attr should work.
    sys.modules[mod_path].__name__

    # We sould be able to import the module.
    import __test_make_lazy__

    # The dunder methods should be here now.
    assert isinstance(sys.modules[mod_path], ModuleType)

# Generated at 2022-06-21 21:59:32.676121
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests make_lazy function.
    """
    sys_modules = sys.modules.copy()

# Generated at 2022-06-21 21:59:41.039739
# Unit test for function make_lazy
def test_make_lazy():
    # test sys.modules
    assert 'django.core' in sys.modules
    assert 'django.core' not in sys.modules.copy()
    make_lazy('django.core')
    assert 'django.core' in sys.modules

    # test security.middleware
    assert 'django.core.signing' not in sys.modules
    assert 'django.core.signing' not in sys.modules.copy()
    make_lazy('django.core.signing')
    assert 'django.core.signing' in sys.modules
    from django.core import signing
    assert 'django.core.signing' in sys.modules

# Generated at 2022-06-21 21:59:43.849614
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy("inspect"), _LazyModuleMarker)


# Generated at 2022-06-21 21:59:52.684351
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = 42
    nonlocal_value = NonLocal(value)
    assert nonlocal_value.value == value


# Generated at 2022-06-21 21:59:57.813561
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Setup
    some_value = "Some Value"

    # Exercise
    n = NonLocal(some_value)

    # Verify
    assert n.value == some_value


# Generated at 2022-06-21 22:00:03.582429
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('make_lazy', None)
    make_lazy('make_lazy')
    from make_lazy import LazyModule
    assert isinstance(LazyModule, _LazyModuleMarker)
    assert isinstance(LazyModule, ModuleType)
    assert hasattr(LazyModule, 'make_lazy')
    assert isinstance(LazyModule.make_lazy, types.FunctionType)
    assert LazyModule.make_lazy == make_lazy

# Generated at 2022-06-21 22:00:10.710417
# Unit test for function make_lazy
def test_make_lazy():
    test_obj = 'test.obj'

    __import__('test.obj')
    sys.modules['test.obj'] = 'test.obj'

    make_lazy('test.obj')

    # should not import the object.
    assert test_obj != sys.modules['test.obj']
    assert sys.modules['test.obj'] != 'test.obj'

    assert hasattr(sys.modules['test.obj'], '__mro__')
    assert isinstance(sys.modules['test.obj'], _LazyModuleMarker)

# Generated at 2022-06-21 22:00:13.386071
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mrk = _LazyModuleMarker()
    assert(isinstance(mrk, _LazyModuleMarker))


# Generated at 2022-06-21 22:00:15.451595
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-21 22:00:26.973160
# Unit test for function make_lazy
def test_make_lazy():
    def check_lazy(module):
        assert isinstance(module, _LazyModuleMarker)
        assert module._dummy_var == 5

    module_path = __name__ + '.dummy_module'
    make_lazy(module_path)

    # Test that the module is not imported
    dummy_module = sys.modules[module_path]
    assert not hasattr(dummy_module, '_dummy_var')

    check_lazy(dummy_module)

    # Test that the module is imported and cached
    dummy_module = sys.modules[module_path]
    assert dummy_module._dummy_var == 5

    check_lazy(dummy_module)

    del sys.modules[module_path]
test_make_lazy()

# Generated at 2022-06-21 22:00:32.444233
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)

    assert non_local.value == 1
    # noinspection PyUnresolvedReferences
    non_local.value = 2
    assert non_local.value == 2
    non_local.value = 3
    assert non_local.value == 3



# Generated at 2022-06-21 22:00:35.700733
# Unit test for constructor of class NonLocal
def test_NonLocal():

    x = NonLocal(1)
    assert(x.value == 1)

    y = NonLocal(2)
    assert(y.value == 2)
    return True


# Generated at 2022-06-21 22:00:39.860684
# Unit test for function make_lazy
def test_make_lazy():
    import xblock.test.tools.test_lazy_import
    assert isinstance(xblock.test.tools.test_lazy_import, _LazyModuleMarker)
    assert not isinstance(xblock.test.tools.test_lazy_import, ModuleType)

# Generated at 2022-06-21 22:00:55.487921
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert issubclass(LazyModule, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:56.907930
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(citeproc, _LazyModuleMarker)

# Generated at 2022-06-21 22:00:59.337931
# Unit test for constructor of class NonLocal
def test_NonLocal():
    y = NonLocal(1)
    assert(y.value==1)


# Generated at 2022-06-21 22:01:00.593549
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    foo = make_lazy("foo")
    assert foo is not None


# Generated at 2022-06-21 22:01:14.222988
# Unit test for function make_lazy
def test_make_lazy():
    # Import this function so that test_make_lazy is not lazy.
    import test
    import string

    # Confirm our test members are already there.
    assert hasattr(string, 'join')
    assert hasattr(test, 'my_join')

    # Force the test module to be lazy.
    make_lazy('test')

    # The test module should still be there.
    assert sys.modules.has_key('test')
    assert not isinstance(sys.modules['test'], ModuleType)
    assert 'test' in sys.modules

    # Confirm the joined function is still in string.
    assert hasattr(string, 'join')

    # Confirm our custom join function is not there.
    assert not hasattr(test, 'my_join')

    # Do an import to load the module.
    import test


# Generated at 2022-06-21 22:01:19.259035
# Unit test for constructor of class NonLocal
def test_NonLocal():
    outer_var = NonLocal(1)
    def func():
        def helper():
            outer_var.value = 3
            print(outer_var.value)
        helper()
    func()


# Generated at 2022-06-21 22:01:23.252404
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(100)
    assert nl.value == 100

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 22:01:25.045799
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    sys.path.append('..')
    from NonLocal import NonLocal
    a = NonLocal(333)
    a.value = 333


# Generated at 2022-06-21 22:01:36.977298
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import random
    import string
    import shutil

    # Create random path where to create our fake module
    # module_path will be something like 'tmp/fake_module_name'
    module_name = ''.join(
            random.choice(string.ascii_lowercase) for _ in range(4)
        )
    module_dir = 'tmp'
    if not os.path.exists(module_dir):
        os.makedirs(module_dir)
    module_path = os.path.join(module_dir, module_name)

    # Create fake module with a name and a variable

# Generated at 2022-06-21 22:01:44.282159
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert isinstance(LazyModuleMarker, type)
    assert LazyModuleMarker.__class__.__name__ == 'type'
    assert LazyModuleMarker.__class__.__name__ == 'type'
    assert LazyModuleMarker.__class__.__mro__ == (type, object)


# Generated at 2022-06-21 22:02:13.605464
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert inspect.isclass(_LazyModuleMarker) and _LazyModuleMarker is not object


# Generated at 2022-06-21 22:02:21.516906
# Unit test for function make_lazy
def test_make_lazy():
    import lazily_imported_mod
    assert isinstance(lazily_imported_mod, _LazyModuleMarker)

    # After being accessed it should be a module
    assert isinstance(lazily_imported_mod.foo, int)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:02:31.028724
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys
    import re

    from edx_lint import make_lazy

    # Clear out any existing modules
    sys.modules.pop("edx_lint.test_make_lazy_module", None)

    # Make the module lazy
    make_lazy("edx_lint.test_make_lazy_module")

    # Test that the module is lazy by trying to import it
    import edx_lint.test_make_lazy_module as tmlm

    # The module returns its own name
    assert tmlm.get_name() == "edx_lint.test_make_lazy_module"

    # Test that the module is a subclass of ModuleType
    assert isinstance(tmlm, ModuleType)

    # Test

# Generated at 2022-06-21 22:02:32.462081
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(0)
    assert test.value == 0



# Generated at 2022-06-21 22:02:39.815358
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import test_module
        raise AssertionError('import test_module did not fail when expected')
    except ImportError:
        pass

    make_lazy('test_module')
    import test_module
    assert isinstance(test_module, _LazyModuleMarker), 'Cannot lazy load module'

    attribute = getattr(test_module, 'Attribute')
    assert isinstance(attribute, object), 'Lazy loading failed'


if __name__ == '__main__':
    import doctest
    (failures, tests) = doctest.testmod()
    print('{} failures, {} tests'.format(failures, tests))

    test_make_lazy()

# Generated at 2022-06-21 22:02:44.125682
# Unit test for function make_lazy
def test_make_lazy():
    from importlib import import_module
    from mock import patch

    module_path = 'mock.name'

    # Raise ImportError for import_module if it is called in function make_lazy
    with patch('importlib.import_module', side_effect=ImportError):
        # Call function make_lazy
        make_lazy(module_path)
        # Check isinstance(sys.modules['mock.name'], _LazyModuleMarker) is True
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        import_module(module_path)
        # Check isinstance(sys.modules['mock.name'], _LazyModuleMarker) is False
        assert not isinstance(sys.modules[module_path], _LazyModuleMarker)
        # Check sys.modules['m

# Generated at 2022-06-21 22:02:44.899960
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(12)
    assert nonlocal_value.value == 12



# Generated at 2022-06-21 22:02:45.522258
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1

# Generated at 2022-06-21 22:02:51.905536
# Unit test for function make_lazy
def test_make_lazy():
    def setUp():
            make_lazy('test_lazy')
            import test_lazy
            make_lazy('test_lazy.sub')
            test_lazy.sub
            return test_lazy
    def test_lazy_module():
        assert isinstance(setUp(), _LazyModuleMarker)
    def test_submodule_nonexistent():
        assert 'sub' not in dir(setUp())
    def test_submodule_attr_nonexistent():
        assert 'test' not in dir(setUp())
    def test_submodule_attr_exists():
        setUp().sub.test
        assert 'test' in dir(setUp())

# Generated at 2022-06-21 22:02:53.455624
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('oo')
    assert(nl.value == 'oo')

# Generated at 2022-06-21 22:03:57.654685
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('this.module.does.not.exist')
        assert False, "ImportError not thrown"
    except ImportError:
        pass


mod = sys.modules[__name__]
make_lazy(__name__)

assert isinstance(mod, _LazyModuleMarker)
mod.submodule = mod
assert isinstance(mod.submodule, ModuleType)



# Generated at 2022-06-21 22:04:04.714136
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the module is not imported until it is used.
    """
    # Create a new module just for the purpose of this test
    # and remove it later so we don't pollute other tests

# Generated at 2022-06-21 22:04:15.809257
# Unit test for function make_lazy
def test_make_lazy():
    """
    The lazy module should behave like a normal module if imported directly
    """
    import sys
    import tests.remind
    assert tests.remind

    def test_mro():
        """
        Our hack to pass isinstance checks should work
        """
        assert isinstance(tests.remind, ModuleType)

    sys.modules['tests.remind'].__mro__ = test_mro

    # Mocks out the actual import.
    sys.modules['tests.remind'] = object()

    # The module should not be loaded yet.
    assert sys.modules['tests.remind'] is not None

    import tests.remind

    assert tests.remind is not None
    assert sys.modules['tests.remind'] is not None

    # We should be able to get the module by importing again, since we
    #

# Generated at 2022-06-21 22:04:18.076000
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    ins_marker = _LazyModuleMarker()
    assert isinstance(ins_marker, _LazyModuleMarker)


# Generated at 2022-06-21 22:04:22.742501
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Testing constructor of class _LazyModuleMarker
    """
    # Testing __init__ function of _LazyModuleMarker class

# Generated at 2022-06-21 22:04:28.280069
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert repr(_LazyModuleMarker()) == '_LazyModuleMarker()'
    assert str(_LazyModuleMarker()) == '_LazyModuleMarker()'
    assert _LazyModuleMarker().__doc__ == 'A marker to indicate a LazyModule type.\n    Allows us to check module\'s with `isinstance(mod, _LazyModuleMarker)`\n    to know if the module is lazy.'


# Generated at 2022-06-21 22:04:30.025929
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)

# Generated at 2022-06-21 22:04:32.872566
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5
    n.value = 4
    assert n.value == 4


# Generated at 2022-06-21 22:04:36.299507
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = 1
    y = 3

    def foo():
        x = NonLocal(5)
        x.value += 1

    foo()
    assert(x == 1)



# Generated at 2022-06-21 22:04:38.712323
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n=NonLocal(5)
    assert n.value==5


# Generated at 2022-06-21 22:05:54.110244
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()

# Generated at 2022-06-21 22:05:58.910986
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    module_path = os.path.join("test", "test_module.py")

    @make_lazy(module_path)
    class LazyModule(object):
        pass

    sys.modules[module_path] = LazyModule

    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-21 22:06:00.981412
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''
    Test constructor of the class NonLocal
    '''
    nl = NonLocal('Hello World')


# Generated at 2022-06-21 22:06:03.946300
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = a.__mro__()
    assert len(b) == 2
    assert b[0] == _LazyModuleMarker
    assert b[1] == object

# Generated at 2022-06-21 22:06:05.798349
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test __init__
    x = NonLocal(8)
    assert x.value == 8


# Generated at 2022-06-21 22:06:13.430740
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import pytest

    n = NonLocal(7)
    assert n.value == 7

    try:
        n.value = 5
        assert False
    except AttributeError:
        assert True
    except:
        assert False

    pytest.raises(AttributeError, "n.value = 5")
    assert n.value == 7


# Generated at 2022-06-21 22:06:14.352799
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(6)

# Generated at 2022-06-21 22:06:18.439684
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make lazy function
    """
    make_lazy("foo.bar")
    assert isinstance(sys.modules["foo.bar"], _LazyModuleMarker)

# Generated at 2022-06-21 22:06:30.627263
# Unit test for function make_lazy
def test_make_lazy():
    class A:
        def set_name(self, name):
            self.name = name
            return self

    def check_lazy_module(mod):
        assert mod.a is None
        mod.a = A()
        mod.a.set_name('mod a')
        assert isinstance(mod.a, A)
        assert mod.a.name == 'mod a'

    try:
        import test_make_lazy
    except ImportError:
        pass

    make_lazy('test_make_lazy')
    assert 'test_make_lazy' in sys.modules
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    check_lazy_module(sys.modules['test_make_lazy'])

# Generated at 2022-06-21 22:06:37.418363
# Unit test for function make_lazy
def test_make_lazy():
    from . import lazy_module_import

    assert 'lazy_module_import' in sys.modules
    assert isinstance(sys.modules['lazy_module_import'], _LazyModuleMarker)

    # Shouldn't be loaded yet
    assert not hasattr(sys.modules['lazy_module_import'], '_initialized')

    # Should be initialized now
    assert lazy_module_import._initialized is True
    assert hasattr(sys.modules['lazy_module_import'], '_initialized')

    # Should be restored to the original
    assert not isinstance(sys.modules['lazy_module_import'], _LazyModuleMarker)
    assert isinstance(sys.modules['lazy_module_import'], ModuleType)

    # Shouldn't be loaded again for the second time
    assert lazy_module_import