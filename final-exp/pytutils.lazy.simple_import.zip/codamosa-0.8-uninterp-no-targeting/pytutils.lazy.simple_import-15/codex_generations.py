

# Generated at 2022-06-21 21:57:22.281041
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)

    assert a.value == 1, "value should be 1"
    a.value = 2
    assert a.value == 2, "value should be 2"

# Generated at 2022-06-21 21:57:33.147691
# Unit test for function make_lazy
def test_make_lazy():
    # Create a mock module for testing
    lazy_module_name = "my_lazy_module"
    mock_module = types.ModuleType(lazy_module_name)
    mock_module.some_module_var = "lazy"
    mock_module.some_module_func = lambda: "lazy module func"
    sys.modules[lazy_module_name] = mock_module
    make_lazy(lazy_module_name)

    # Test that the module has not been imported
    import my_lazy_module
    assert not hasattr(my_lazy_module, "some_module_var")
    assert not hasattr(my_lazy_module, "some_module_func")

    # Test that the module has been imported after calling a module function
    some_module_func = my_lazy_

# Generated at 2022-06-21 21:57:39.494206
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


if __name__ == '__main__':
    # Unit tests to test the methods of class _LazyModuleMarker
    test__LazyModuleMarker()

# Generated at 2022-06-21 21:57:44.511061
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        nonlocal_variable
    except NameError:
        nonlocal_variable = 'hello'

    # The statement below throws the NameError exception
    # because there is no binding for nonlocal_variable.
    # nonlocal nonlocal_variable
    nonlocal_variable_1 = NonLocal('world')

    def test_nonlocal():
        nonlocal nonlocal_variable
        nonlocal nonlocal_variable_1

        nonlocal_variable = nonlocal_variable_1

        assert(nonlocal_variable is nonlocal_variable_1)
        nonlocal_variable_1.value = 'Python'
        assert(nonlocal_variable == 'Python')

    test_nonlocal()

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:57:46.771725
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10
    a.value = 20
    assert a.value == 20



# Generated at 2022-06-21 21:57:48.117774
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert x.value == 10


# Generated at 2022-06-21 21:57:50.571286
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal
    """
    a = NonLocal(5)

# Generated at 2022-06-21 21:57:58.569083
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    assert NonLocal(True).value is True

    non_local = NonLocal(False)
    assert non_local.value is False

    non_local = NonLocal('')
    assert non_local.value is ''
    assert non_local.value == ''

    non_local = NonLocal(0)
    assert non_local.value is 0
    assert non_local.value == 0

    non_local = NonLocal(None)
    assert non_local.value is None
    assert non_local.value == None

    non_local = NonLocal([])
    assert non_local.value == []

    non_local = NonLocal({})
    assert non_local.value == {}

    non_local = NonLocal(())

# Generated at 2022-06-21 21:58:08.429497
# Unit test for function make_lazy
def test_make_lazy():
    import tests.toolkit.test_make_lazy as t


# Generated at 2022-06-21 21:58:20.863884
# Unit test for function make_lazy
def test_make_lazy():
    # Create a sample module
    sys.modules['test_lazy_module'] = ModuleType('test_lazy_module')
    # Add some attributes to the module
    sys.modules['test_lazy_module'].a = 1
    sys.modules['test_lazy_module'].b = 2
    sys.modules['test_lazy_module'].c = 3

    # Mark it as lazy
    make_lazy('test_lazy_module')
    # Check that the module still exists
    assert sys.modules['test_lazy_module'] is not None
    # Check that the module is still a module
    assert isinstance(sys.modules['test_lazy_module'], ModuleType)
    # Check that isinstance won't tell you the module is lazy

# Generated at 2022-06-21 21:58:25.020556
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker) is True


# Generated at 2022-06-21 21:58:26.568528
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) == _LazyModuleMarker


# Generated at 2022-06-21 21:58:27.508457
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-21 21:58:29.585419
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, object)


# Generated at 2022-06-21 21:58:36.936232
# Unit test for function make_lazy
def test_make_lazy():
    def _test_inner():
        package = 'test_package'
        module_name = 'foo'
        module_path = package + '.' + module_name
        make_lazy(module_path)

        test_package = __import__(package)
        assert isinstance(test_package.foo, _LazyModuleMarker)

        # Test that attributes can be accessed
        test_package.foo.bar
        # Test that repeated accesses don't fail
        test_package.foo.bar
        # Test that the import is removed from sys.modules
        assert module_path not in sys.modules
        # Test that the import is replaced in sys.modules
        assert sys.modules[module_path] is test_package.foo

    _test_inner()

    # Test that the import was removed from sys.modules

# Generated at 2022-06-21 21:58:47.522259
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # The only data that the object should contain are static or class data.
    # Static data is a class variable (or a variable assigned in the body of
    # the class).  Class data is run in the function body of the class
    # itself.
    # If a class is a built-in class, then it will have a __mro__ attribute.
    # We can check on this attribute to see if we should import the module
    # or not.
    marker = _LazyModuleMarker()
    assert marker.__class__.__name__ == '_LazyModuleMarker'
    assert marker.__doc__ == 'A marker to indicate a LazyModule type.\n    Allows us to check module\'s with `isinstance(mod, _LazyModuleMarker)\n    to know if the module is lazy.\n    '

# Generated at 2022-06-21 21:58:48.859014
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-21 21:58:50.833115
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker().__mro__() == (_LazyModuleMarker, object)


# Generated at 2022-06-21 21:58:52.330931
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-21 21:58:55.456572
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert callable(_LazyModuleMarker)
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-21 21:59:02.976565
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test to make sure the NonLocal object is created. If created, test passes.
    a = NonLocal(3)
    if a.value == 3:
        print("NonLocal constructor test passed!")
    else:
        print("NonLocal constructor test failed!")


# Generated at 2022-06-21 21:59:07.193309
# Unit test for function make_lazy
def test_make_lazy():
    import types

    make_lazy("math")
    assert not isinstance(sys.modules["math"], types.ModuleType)
    lazy_module = sys.modules["math"]
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(lazy_module, types.ModuleType)

    from math import floor
    assert floor(1.51) == 1

# Generated at 2022-06-21 21:59:09.793406
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    eq_(isinstance(x, _LazyModuleMarker), True)
    eq_(isinstance(x, ModuleType), False)


# Generated at 2022-06-21 21:59:11.078239
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-21 21:59:14.285189
# Unit test for constructor of class NonLocal

# Generated at 2022-06-21 21:59:17.760549
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mm = _LazyModuleMarker()
    assert isinstance(mm, _LazyModuleMarker)
    assert isinstance(mm, object)


# Generated at 2022-06-21 21:59:19.301180
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    print(a.value)
    a.value = 3
    print(a.value)


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:59:22.414655
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    a.value = 1
if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-21 21:59:26.869248
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'threading'
    make_lazy(module_path)
    from threading import _shutdown
    assert _shutdown() is None
    make_lazy(module_path)
    from threading import _shutdown
    assert _shutdown() is None



# Generated at 2022-06-21 21:59:35.704845
# Unit test for function make_lazy
def test_make_lazy():
    module_type_1 = type(make_lazy)
    import pkgutil
    module_type_2 = type(pkgutil)
    assert not isinstance(make_lazy, module_type_2)
    assert isinstance(pkgutil, module_type_2)
    assert isinstance(make_lazy, module_type_1)
    assert isinstance(make_lazy, _LazyModuleMarker)
    assert isinstance(make_lazy, types.ModuleType)
    assert not isinstance(pkgutil, module_type_1)
    assert not isinstance(pkgutil, _LazyModuleMarker)


# Import the lazy modules
make_lazy('pkgutil')

# Generated at 2022-06-21 21:59:44.682695
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert isinstance(test, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:47.172894
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert(isinstance(test, object))


# Generated at 2022-06-21 21:59:54.374150
# Unit test for function make_lazy
def test_make_lazy():
    class MyClass(object):
        pass

    make_lazy(__name__)

    if hasattr(MyClass, '__name__'):
        # an attribute on a class is not enough to import it
        assert isinstance(MyClass, _LazyModuleMarker)

    assert not isinstance(os, _LazyModuleMarker)

# Generated at 2022-06-21 21:59:56.951770
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal('value')
    assert test.value == 'value'



# Generated at 2022-06-21 22:00:00.250271
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('pandas'), _LazyModuleMarker)

# Unit test to see if it works with `isinstance`

# Generated at 2022-06-21 22:00:04.179221
# Unit test for constructor of class NonLocal
def test_NonLocal():
    p = NonLocal(1)
    assert p.value == 1
    p.value = 2
    assert p.value == 2

# Generated at 2022-06-21 22:00:10.077250
# Unit test for function make_lazy
def test_make_lazy():
    """
    This function is not intended to be called from an import statement.
    """
    import math

    print(math.cos(0))

    make_lazy('math')

    # should not have been imported yet
    assert sys.modules['math'] is not math

    print(math.cos(0))

    assert sys.modules['math'] is math

    print(math.cos(1))

    print(math.pi)
    print(math.pi)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-21 22:00:14.555934
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test constructor of class _LazyModuleMarker
    """
    try:
        _LazyModuleMarker()
    except Exception as e:
        pytest.fail('Exception raised in constructor of _LazyModuleMarker: {}'.format(e))

# Generated at 2022-06-21 22:00:15.709725
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()


# Generated at 2022-06-21 22:00:17.278740
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(1)
    assert nonlocal_var.value == 1


# Generated at 2022-06-21 22:00:31.109652
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-21 22:00:32.821364
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(4)
    assert x.value == 4

# Generated at 2022-06-21 22:00:36.915233
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    def mk():
        """
        make a new instance of _LazyModuleMarker
        """
        return _LazyModuleMarker()
    obj = mk()
    assert isinstance(obj, _LazyModuleMarker) == True



# Generated at 2022-06-21 22:00:40.103311
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Function to unit test class _LazyModuleMarker
    """
    mark = _LazyModuleMarker()
    assert mark is not None


# Generated at 2022-06-21 22:00:41.504287
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1


# Generated at 2022-06-21 22:00:43.240983
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker) is False)



# Generated at 2022-06-21 22:00:48.847621
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    We do not test the following attributes directly because we cannot get to them.
    - __module__
    - __bases__
    """
    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'
    assert _LazyModuleMarker.__doc__ is None
    assert _LazyModuleMarker.__dict__ == {}


# Generated at 2022-06-21 22:00:51.074917
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    print(lm)

# function make_lazy() test

# Generated at 2022-06-21 22:00:54.994563
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(42)
    assert nonlocal_.value == 42
    nonlocal_.value = False
    assert nonlocal_.value is False
    if sys.version < '3':
        with pytest.raises(AttributeError):
            nonlocal_.x = 1
    else:
        with pytest.raises(SyntaxError):
            nonlocal_.x = 1


# Generated at 2022-06-21 22:00:56.858744
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert(nl.value == 42)


# Generated at 2022-06-21 22:01:26.256428
# Unit test for function make_lazy
def test_make_lazy():
    module_path = "test_module_path"
    class TestModule(ModuleType):
        pass

    sys_modules = sys.modules

    class TestClass(object):
        pass

    sys_modules[module_path] = TestModule(module_path)
    test_module = sys_modules[module_path]
    assert isinstance(test_module, ModuleType)
    assert not isinstance(test_module, _LazyModuleMarker)

    make_lazy(module_path)

    lazy_module = sys_modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(lazy_module, ModuleType)
    assert not hasattr(lazy_module, "test_attr")

    test_module.test_attr = TestClass()

# Generated at 2022-06-21 22:01:37.061049
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules = {}
    import tastypie.fields as module

    make_lazy('tastypie.fields')
    assert isinstance(module, _LazyModuleMarker)
    assert module.__name__ is 'tastypie.fields'
    assert isinstance(module.CharField, _LazyModuleMarker)
    assert module.__file__ is None

    from django.db import models
    import models as models_module

    assert not isinstance(models, _LazyModuleMarker)
    assert isinstance(models_module, _LazyModuleMarker)

    # Now we will load the module to make sure it loads correctly
    module.CharField
    import models

# Execute the unit test if this module is invoked directly.
if __name__ == '__main__':
    test_make_lazy

# Generated at 2022-06-21 22:01:42.950257
# Unit test for function make_lazy
def test_make_lazy():
    # Test for issue #1202
    # https://bitbucket.org/pypy/pypy/issues/1202/
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)
    assert isinstance(sys.modules['types'], _LazyModuleMarker)

# Generated at 2022-06-21 22:01:44.500076
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('value')
    assert nl.value == 'value'

# Generated at 2022-06-21 22:01:56.399182
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import pytest

    # Create a dummy module
    test_module = {'hello': 'world'}
    sys.modules['tests.lazy'] = test_module

    # Test that module is loaded without make_lazy
    assert isinstance(sys.modules['tests.lazy'], ModuleType)
    assert sys.modules['tests.lazy'].hello == 'world'

    # Force import of LazyModule class
    import tests.contrib.lazy.lazy as lazy
    make_lazy('tests.lazy')

    # Test the object type
    assert isinstance(sys.modules['tests.lazy'], lazy.LazyModule)
    assert not isinstance(sys.modules['tests.lazy'], ModuleType)

# Generated at 2022-06-21 22:02:04.117954
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test the make_lazy function
    """
    import pdb; pdb.set_trace()
    paths = [
        'test1.foo.bar',
        'test2.foo.bar.baz',
        'test3.baz.bar',
    ]

    for p in paths:
        make_lazy(p)
        assert not hasattr(sys.modules[p], '__file__')

        mod = __import__(p)
        assert hasattr(sys.modules[p], '__file__')

# Generated at 2022-06-21 22:02:11.684807
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules
    from django.core.files.storage import Storage

    assert 'django.core.files.storage' not in modules
    make_lazy('django.core.files.storage')
    assert 'django.core.files.storage' in modules
    assert isinstance(modules['django.core.files.storage'], _LazyModuleMarker)
    assert issubclass(Storage, modules['django.core.files.storage'])

# Generated at 2022-06-21 22:02:15.220806
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x=NonLocal(20)
    assert x.value == 20, "Value is 20"

# Generated at 2022-06-21 22:02:19.227273
# Unit test for constructor of class NonLocal
def test_NonLocal():
  foo = NonLocal(1)
  print(foo.value)

#Unit test for class LazyModule

# Generated at 2022-06-21 22:02:24.457381
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        x = NonLocal(1)
    except NameError:
        x = NonLocal(1)
    assert x.value == 1
    x.value = 2
    assert x.value == 2
    del x.value
    try:
        x.value
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 22:03:21.541601
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy



# Generated at 2022-06-21 22:03:22.746916
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(42)
    assert n.value == 42


# Generated at 2022-06-21 22:03:23.873117
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value is None


# Generated at 2022-06-21 22:03:34.970231
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocal(object):
        """
        Simulates nonlocal keyword in Python 2
        """
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    def foo():
        x = NonLocal(10)
        def bar():
            x.value += 1
            print(x.value)
            return x

        return bar

    foo2 = foo()
    print(foo2.__closure__[0].cell_contents.value)
    foo2()
    print(foo2.__closure__[0].cell_contents.value)


if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-21 22:03:36.459115
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

# Generated at 2022-06-21 22:03:40.222690
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Define a function
    def func():
        # Initialize a NonLocal class
        nonlocal_obj = NonLocal(10)
        nonlocal_obj.value = 20
        return nonlocal_obj.value
    assert func() == 20


# Generated at 2022-06-21 22:03:50.719717
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import django
    import boto
    import s3

    module_name = 's3'
    module_path = '{0}.{1}'.format(__name__, module_name)

    # test that s3 import works
    import s3


    # test that s3 was imported
    assert s3

    # test that s3 was added to sys.modules
    assert module_path in sys.modules

    # test that s3 is not a LazyModule
    assert not isinstance(sys.modules[module_path], _LazyModuleMarker)

    # test boto was imported
    assert boto

    # test that boto was imported
    assert 'boto' in sys.modules

    # test that boto is not a LazyModule

# Generated at 2022-06-21 22:03:51.396967
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass

# Generated at 2022-06-21 22:04:01.210449
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Check the attributes of the __mro__ method
    assert hasattr(_LazyModuleMarker, '__mro__') and \
           hasattr(_LazyModuleMarker.__mro__, '__call__')
    # Check the attributes of the __getattribute__ method
    assert hasattr(_LazyModuleMarker, '__getattribute__') and \
           hasattr(_LazyModuleMarker.__getattribute__, '__call__')
    # Check the attributes of the __init__ method
    assert hasattr(_LazyModuleMarker, '__init__') and \
           hasattr(_LazyModuleMarker.__init__, '__call__')
    # Check the attributes of the type

# Generated at 2022-06-21 22:04:04.107629
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0



# Generated at 2022-06-21 22:06:23.298861
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    "Unit testing of class _LazyModuleMarker"
    import sys
    lmm = _LazyModuleMarker()
    assert(isinstance(lmm, ModuleType))
    assert(not isinstance(lmm, object))


# Generated at 2022-06-21 22:06:27.644717
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    '''
    Unit test for constructor of class _LazyModuleMarker
    '''
    try:
        lazymodulemarker = _LazyModuleMarker()
    except:
        assert False
    else:
        assert isinstance(lazymodulemarker, _LazyModuleMarker)


# Generated at 2022-06-21 22:06:34.786638
# Unit test for function make_lazy
def test_make_lazy():
    # Example of using make_lazy
    module_path = 'datascience.utils'

    make_lazy(module_path)
    assert sys.modules[module_path] is not None

    # import the module without importing the module
    module = sys.modules[module_path]
    assert module is not None
    assert not isinstance(module, ModuleType)


    # calling an attribute of the module imports that module
    assert module.is_module_lazy is True
    assert isinstance(module, ModuleType)



# Generated at 2022-06-21 22:06:36.700353
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        x = NonLocal(1)
        assert x.value == 1
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-21 22:06:39.223047
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    # Check that we can use isinstance to check
    assert isinstance(marker, _LazyModuleMarker)

# Generated at 2022-06-21 22:06:44.691039
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    
    # Create an empty object of type _LazyModuleMarker
    X = _LazyModuleMarker()
    assert X != None
    assert type(X) == _LazyModuleMarker
    assert X.__class__ == _LazyModuleMarker
    assert dir(X) == ['__class__']
    

# Generated at 2022-06-21 22:06:50.164817
# Unit test for function make_lazy
def test_make_lazy():
    try:
        # Testing that it really does not import the module until used
        import os
        assert os.listdir is 'unset'

        # Testing that it pretends to be the module without importing
        assert isinstance(os, _LazyModuleMarker)

        # Testing that it will load the module if attributes are asked
        os.listdir
        assert os.listdir
        assert isinstance(os, ModuleType)
    finally:
        del sys.modules['os']

# Generated at 2022-06-21 22:06:51.387265
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal("test")
    assert(test.value == "test")

# Generated at 2022-06-21 22:06:52.600359
# Unit test for constructor of class NonLocal
def test_NonLocal():
    c = NonLocal(1)
    assert c.value == 1


# Generated at 2022-06-21 22:06:53.429081
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
