

# Generated at 2022-06-26 02:26:05.442386
# Unit test for function make_lazy
def test_make_lazy():
    # Can make_lazy be called?
    assert callable(make_lazy)

    # Arbitrary module path to test with
    module_path = 'some_module'

    # Should be able to make a lazy module for this path
    make_lazy(module_path)

    # Check that it's a LazyModule
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Check that it's a LazyModule (2)
    assert isinstance(sys.modules[module_path], ModuleType)

    # Check that it's a lazy module
    assert issubclass(sys.modules[module_path].__class__, _LazyModuleMarker)

    # Check that it's still a module
    assert isinstance(sys.modules[module_path], ModuleType)



# Generated at 2022-06-26 02:26:12.175914
# Unit test for function make_lazy
def test_make_lazy():
    def mock_import(name, globals=None, locals=None, fromlist=None):
        if name == 'module':
            return ModuleType('module')
        else:
            assert False, 'unexpected import of %r' % name

    glob_dict = {'__import__': mock_import}
    import_mock = Mock(side_effect=mock_import)
    with patch('__builtin__.__import__', import_mock):
        make_lazy('module')
        assert sys.modules['module'] is not None
        assert len(import_mock.call_args_list) == 0
        assert sys.modules['module'] is not None
        sys.modules['module'].__class__.__name__
        assert len(import_mock.call_args_list) == 1
        assert sys

# Generated at 2022-06-26 02:26:18.214674
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["test_module_path"] = 3
    make_lazy("test_module_path")
    assert(isinstance(sys.modules["test_module_path"], _LazyModuleMarker))
    test = sys.modules["test_module_path"]
    assert(test.value == 3)

# REQ-BL-0012: Make_lazy shall mark a module as lazy when importing
# REQ-BL-0013: Make_lazy shall import the module when imported

# Generated at 2022-06-26 02:26:25.542868
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    make_lazy('importlib')
    assert all('importlib' not in module for module in sys.modules)
    del sys.modules['importlib']
    assert 'importlib' not in sys.modules
    importlib = __import__('importlib')
    assert 'importlib' in sys.modules
    assert sys.modules['importlib'] is importlib
    assert all('importlib' not in module for module in sys.modules)
    importlib = __import__('importlib')
    assert 'importlib' in sys.modules
    assert sys.modules['importlib'] is importlib

# Generated at 2022-06-26 02:26:34.870751
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['_os'] = 'asdf'
    make_lazy('_os')
    assert sys.modules['_os'].__mro__() == (sys.modules['_os'], ModuleType)
    assert isinstance(sys.modules['_os'], _LazyModuleMarker)
    assert sys.modules['_os'].__getattribute__
    assert sys.modules['_os'].__getattribute__ == sys.modules['_os'].__getattribute__
    assert sys.modules['_os'].__getattribute__('name').startswith('_os')

# Functional test for function make_lazy

# Generated at 2022-06-26 02:26:46.896342
# Unit test for function make_lazy
def test_make_lazy():
    print ("Testing make_lazy()")

    # Test Case 1:
    # Create a module "foo", and lazyload it
    # then check that the module is an instance of a LazyModule
    # then delete sys.module["foo"] and check that it is not an instance
    # of a LazyModule
    module_path_0 = "foo"
    make_lazy(module_path_0)
    is_lazy = isinstance(sys.modules[module_path_0], _LazyModuleMarker)
    assert is_lazy, "LazyModule was not created"

    del sys.modules["foo"]
    is_lazy = isinstance(sys.modules.get(module_path_0), _LazyModuleMarker)
    assert is_lazy != True, "LazyModule was not deleted"

    #

# Generated at 2022-06-26 02:26:49.064216
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_0 = _LazyModuleMarker()
    if True:
        pass
    if False:
        pass

# Generated at 2022-06-26 02:26:56.782922
# Unit test for function make_lazy
def test_make_lazy():
    import pkgutil
    import sys
    import types

    def check_list_attribute(list_name, module_name, attribute_name):
        """
        Helper to test that a module is indeed lazy.
        """
        mod = pkgutil.find_loader(module_name).load_module(module_name)

        list_ = getattr(sys, list_name)
        list_.remove(module_name)
        list_.append(module_name)

        # If the module is not lazy, the line below will cause
        # import to blow up because the module is not found
        # in sys.modules
        make_lazy(module_name)

        mod = pkgutil.find_loader(module_name).load_module(module_name)
        assert isinstance(mod, _LazyModuleMarker)
        mod

# Generated at 2022-06-26 02:27:04.195132
# Unit test for function make_lazy
def test_make_lazy():
    # See if make_lazy works in regular usage.
    make_lazy('x.y')
    assert isinstance(sys.modules['x.y'], _LazyModuleMarker)
    assert sys.modules['x.y'].__mro__() == (sys.modules['x.y'].__class__, ModuleType)
    assert sys.modules['x.y'].__getattribute__(1) == sys.modules['x.y']


# Generated at 2022-06-26 02:27:07.359447
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'collections'

    assert module_path not in sys.modules

    make_lazy(module_path)

    assert isinstance(sys.modules[module_path], _LazyModuleMarker)



# Generated at 2022-06-26 02:27:19.004405
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)
    str_1 = "P]m$}oIYwosK'B\nR."
    str_2 = "P]m$}oIYwosK'B\nR."
    str_3 = "P]m$}oIYwosK'B\nR."
    str_4 = "P]m$}oIYwosK'B\nR."
    str_5 = "P]m$}oIYwosK'B\nR."
    str_6 = "P]m$}oIYwosK'B\nR."

# Generated at 2022-06-26 02:27:19.981771
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(0)


# Generated at 2022-06-26 02:27:21.088296
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:27:22.161462
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)
    make_lazy('path')
    assert sys.modules['path']



# Generated at 2022-06-26 02:27:23.682792
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(int())
    non_local_1 = NonLocal(str())


# Generated at 2022-06-26 02:27:28.857581
# Unit test for function make_lazy
def test_make_lazy():
    test_module = "test_module"
    non_local_0 = NonLocal(test_module)

    str_0 = "/<"
    non_local_1 = NonLocal(str_0)

    if make_lazy(test_module) == sys.modules[test_module]:
        assert False

    # This should not cause the real module to be loaded.
    if "test_module" == sys.modules[test_module]:
        assert False

    if sys.modules[test_module] == sys.modules[test_module]:
        assert False

    if sys.modules[test_module] == sys.modules[test_module]:
        assert False

if __name__ == '__main__':
    # test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:27:32.165410
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "KpA'V?v\nW:E"
    non_local_0 = NonLocal(str_0)
    non_local_0.value = None
    non_local_0.value = None

# Generated at 2022-06-26 02:27:42.823921
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    # In this function, we are going to test that our make_lazy function
    # properly returns a correct LazyModule object when we 'import' it.
    # This unit test does:

    #    1) call make_lazy with a fake module path,
    #    2) import the fake module path and assert that it is not None,
    #    3) assert that the fake module is an instance of _LazyModuleMarker
    #    4) import some attribute off the module and assert that an
    #       ImportError is not raised
    #    5) assert that the module's attribute is equal to our known value.

    fake_module_path = "fake_module_path"
    make_lazy(fake_module_path)

    import fake_module_path
   

# Generated at 2022-06-26 02:27:49.456825
# Unit test for function make_lazy
def test_make_lazy():
    # the library is marked as lazy
    # to save the user an import.
    make_lazy("more_itertools")
    # mod is a LazyModule now.
    mod = sys.modules["more_itertools"]

    # assert that we're really lazy
    assert not hasattr(mod, "__version__")

    # now ask for an attribute
    ver = mod.__version__
    assert ver == __version__

    # check that the module is loaded now
    assert isinstance(sys.modules["more_itertools"], ModuleType)

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:27:59.597194
# Unit test for function make_lazy

# Generated at 2022-06-26 02:28:04.908854
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["conftree"] = "conftree"
    make_lazy("conftree")
    print(sys.modules["conftree"].__class__.__mro__)



# Generated at 2022-06-26 02:28:12.670832
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy != None
    import inspect
    import ast
    #import pprint
    #pp = pprint.PrettyPrinter(indent=4)

    def check_ast(ast_parsed):
        """
        Check the AST to ensure that it is correct
        """
        ast.dump(ast_parsed)

        for node in ast.walk(ast_parsed):
            assert ast.dump(node) != None

    # Test that we can parse the function
    parsed = ast.parse(inspect.getsource(make_lazy))

    check_ast(parsed)

    # Test that we can transform the function
    trans_parsed = ast.parse(inspect.getsource(make_lazy))
    transformed = ast.fix_missing_locations(trans_parsed)



# Generated at 2022-06-26 02:28:19.869478
# Unit test for function make_lazy
def test_make_lazy():
    def test_function_0(non_local_0):
        str_0 = type(non_local_0)
        str_1 = str(str_0)

# Generated at 2022-06-26 02:28:25.339067
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)

    make_lazy("sys")
    str_0 = "Attempting to import lazy modules"
    non_local_0.value = str_0
    str_1 = "Attempting to import lazy modules"
    assert non_local_0.value == str_1

    # Tests that a lazy module is actually lazy
    str_2 = "sys"
    str_3 = "sys"
    assert sys.modules[str_3] == str_2

    str_4 = "sys"
    assert isinstance(sys.modules[str_4], _LazyModuleMarker)
    str_5 = "sys"
    str_6 = "sys"
    str_7 = "modules"
    assert sys.modules[str_6].modules == str_7

    # Tests that you

# Generated at 2022-06-26 02:28:29.670847
# Unit test for function make_lazy
def test_make_lazy():
    str_5 = "eS,|}p.BK=%\n,~EZU"
    non_local_0 = NonLocal(str_5)

if __name__ == '__main__':

    sys_modules = sys.modules  # cache in the locals
    non_local_0 = NonLocal(sys_modules)
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:28:35.056338
# Unit test for function make_lazy
def test_make_lazy():

	make_lazy("lazy")
	assert "lazy" not in sys.modules
	with pytest.raises(AttributeError):
		lazy.foobar

	str_0 = "P]m$}oIYwosK'B\nR."
	non_local_0 = NonLocal(str_0)

# Generated at 2022-06-26 02:28:43.891527
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    make_lazy('six.moves')
    copied = sys.modules['six.moves']
    assert "__mro__" in dir(copied)

    make_lazy('six.moves.urllib')
    copied = sys.modules['six.moves.urllib']
    assert "quote" in dir(copied)

    make_lazy('six.moves.urllib.parse')
    copied = sys.modules['six.moves.urllib.parse']
    assert "urlparse" in dir(copied)

    make_lazy('six.moves.urllib.parse')
    copied = sys.modules['six.moves.urllib.parse']
    assert "urlparse" in dir(copied)


# Generated at 2022-06-26 02:28:46.744210
# Unit test for function make_lazy
def test_make_lazy():
    np_ans = test_case_0.__code__.co_names
    print(non_local_0)
    print(type(non_local_0))

# Generated at 2022-06-26 02:28:50.971895
# Unit test for function make_lazy
def test_make_lazy():
    sys_0 = sys
    make_lazy(sys_0)

if __name__ == '__main__':
    # Ideally, we would use the unittest framework for this
    # but we should try to be as minimal as possible for
    # these example binaries.
    test_make_lazy()

# Generated at 2022-06-26 02:29:02.917874
# Unit test for function make_lazy
def test_make_lazy():
    print('Testing make_lazy...', end='')
    # create the module 'foo.bar'
    ensure_dir_exists('foo/bar.py')
    with open('foo/bar.py', 'w') as f:
        f.write('\n')
    # import it...
    import foo.bar
    assert('foo.bar' in sys.modules)
    assert(not isinstance(foo.bar, _LazyModuleMarker))
    assert(foo.bar.__name__ == 'foo.bar')
    # make it lazy
    make_lazy('foo.bar')
    assert(isinstance(foo.bar, _LazyModuleMarker))
    assert('foo.bar' in sys.modules)
    assert(foo.bar.__name__ == 'foo.bar')
    # import it again


# Generated at 2022-06-26 02:29:15.397221
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal("test")
    make_lazy(non_local_0.value)
    non_local_0.value = sys.modules[non_local_0.value]
    assert isinstance(non_local_0.value, _LazyModuleMarker)
    assert non_local_0.value.__mro__() == (_LazyModuleMarker, ModuleType)
    non_local_1 = NonLocal("os")
    make_lazy(non_local_1.value)
    non_local_1.value = sys.modules[non_local_1.value]
    assert isinstance(non_local_1.value, _LazyModuleMarker)
    assert non_local_1.value.__mro__() == (_LazyModuleMarker, ModuleType)


# Unit

# Generated at 2022-06-26 02:29:16.193610
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_case_0.py')

# Generated at 2022-06-26 02:29:18.577244
# Unit test for function make_lazy
def test_make_lazy():
    test_case_1()
    test_case_0()

main = test_make_lazy

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 02:29:28.260018
# Unit test for function make_lazy
def test_make_lazy():
    closure_0 = ["QnE:J!\nAK/P(".encode("base64")]
    str_0 = closure_0[0]
    closure_0.append("4FV.K%zH2}Zq3Hi^b2aW8@v".encode("base64"))
    str_1 = closure_0[1]
    non_local_0 = NonLocal("8lpv.K%zH2}Zq3Hi^b2aW8@v")
    str_2 = "8lpv.K%zH2}Zq3Hi^b2aW8@v"
    if str_0 == str_2:
        print("True")
    else:
        print("False")
    print("@i" == "Rx")

# Generated at 2022-06-26 02:29:38.221725
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)

    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_1 = NonLocal(str_0)

    non_local_2 = NonLocal(None)

    str_1 = 'gW'
    non_local_3 = NonLocal(str_1)

    str_2 = 'GJ'
    non_local_4 = NonLocal(str_2)

    str_3 = 'X|>v'
    non_local_5 = NonLocal(str_3)

    str_4 = 'Q*1?<X|>v'
    non_local_6 = NonLocal(str_4)

    str_5 = 'GJ'
    non_local_7 = NonLocal(str_5)



# Generated at 2022-06-26 02:29:45.216167
# Unit test for function make_lazy
def test_make_lazy():
    class NonLocal_0(object):
        __slots__ = ['value']
        def __init__(self,value):
            self.value = value

    class LazyModule(object):

        def __mro__(self):
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            if non_local_0.value is None:
                del sys.modules[module_path]
                non_local_0.value = __import__(module_path)
                sys.modules[module_path] = __import__(module_path)
            return getattr(non_local_0.value, attr)

    module_path = 'unit_tests'
    non_local_0 = NonLocal_0(None)
    sys.modules[module_path] = LazyModule()

# Generated at 2022-06-26 02:29:53.086965
# Unit test for function make_lazy
def test_make_lazy():

    # Test variables
    result = 0
    value = 0

    # Initialize a module that has no dependencies
    make_lazy("test_module")

    # Check that the module is not imported into the system
    if 'test_module' in sys.modules:
        value += 1
    else:
        value += 0

    # Check that a function defined in the module can still be accessed
    import test_module
    if 'test_mod_func' in dir(test_module):
        value += 1
    else:
        value += 0

    result = value

    return result



# Generated at 2022-06-26 02:29:54.495710
# Unit test for function make_lazy
def test_make_lazy():
    assert 0, "Test not implemented"
  

# Generated at 2022-06-26 02:29:55.270234
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 02:30:01.373926
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)
    test_case_0()
    test = (non_local_0.value is str_0)
    assert test
    test = (not (non_local_0.value is not str_0))
    assert test

test_make_lazy()

# Generated at 2022-06-26 02:30:12.500306
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)

    make_lazy("test_make_lazy")

    try:
        assert sys.modules["test_make_lazy"] != None
    except AssertionError:
        raise AssertionError("test_make_lazy failed")

# Generated at 2022-06-26 02:30:18.063050
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the 'make_lazy' function.
    """
    # Unlazy a module.
    import sys
    import settings

    assert settings.debug is False
    assert 'settings' not in sys.modules.keys()

    # Lazy a module.
    sys.modules.pop('settings')

    make_lazy('settings')

    assert 'settings' in sys.modules.keys()

    # Access the module.
    import settings

    assert 'settings' in sys.modules.keys()
    assert settings.debug is False

# Generated at 2022-06-26 02:30:19.355393
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)



# Generated at 2022-06-26 02:30:28.543423
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import numpy as np
    import threading
    import unittest

    #import numpy as np
    #a = np.array([1,2,3,4])

    #import time
    #time.time()

    #import threading
    #threading.local()

    class TestRun(unittest.TestCase):
        def test_run(self):
            make_lazy(module_path = "numpy")
            make_lazy(module_path = "time")
            make_lazy(module_path = "threading")

            import numpy as np
            a = np.array([1,2,3,4])

            import time
            time.time()

            import threading
            threading.local()

            print(sys.modules)


# Generated at 2022-06-26 02:30:35.353133
# Unit test for function make_lazy
def test_make_lazy():
    # Example from the documentation
    # http://docs.python.org/2/library/sys.html#sys.modules
    module_path = 'string'
    make_lazy(module_path)
    import string
    assert string.ascii_letters == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

    # Try to prevent side effects by removing the string module
    del sys.modules[module_path]



# Generated at 2022-06-26 02:30:36.962153
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

make_lazy(__name__)


# Generated at 2022-06-26 02:30:39.473475
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)


# Generated at 2022-06-26 02:30:43.980562
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module = make_lazy(non_local_0.value)
    str_0 = "P]m$}oIYwosK'B\nR."
    str_1 = lazy_module
    assert str_1 != str_0

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:30:49.324846
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal("P]m$}oIYwosK'B\nR.")
    non_local_0.value = non_local_0.value + non_local_0.value.replace(non_local_0.value.replace(non_local_0.value.replace(non_local_0.value, ""), ""), "")


# Generated at 2022-06-26 02:30:59.773863
# Unit test for function make_lazy
def test_make_lazy():
    from types import ModuleType
    from six import StringIO
    import sys
    import io
    import os
    import io

    saved_stderr = sys.stderr
    sys.stderr = StringIO()


# Generated at 2022-06-26 02:31:25.302557
# Unit test for function make_lazy
def test_make_lazy():
    # Expected results
    expected_0 = (
        "lazy_import.py:2: "
        "NonLocal variable 'non_local_0' referenced before assignment"
    )
    expected_1 = "lazy_import.py:8: UnboundLocalError: local variable 'non_local_1' referenced before assignment"
    expected_2 = "'module' object has no attribute 'value'"
    expected_3 = (
        "lazy_import.py:4: "
        "SyntaxError: nonlocal declaration not allowed at module level"
    )

    # Code to test
    non_local_1 = NonLocal("c[ft0jU6`Ce")

    # Test cases

# Generated at 2022-06-26 02:31:29.207348
# Unit test for function make_lazy
def test_make_lazy():
    assert_equals(test_case_0(), make_lazy('P]m$}oIYwosK\'B\nR.'))

# Generated at 2022-06-26 02:31:34.822577
# Unit test for function make_lazy
def test_make_lazy():
    mod_0 = __import__('tests.test_lazyimport')
    assert(not isinstance(mod_0, _LazyModuleMarker))
    make_lazy('tests.test_lazyimport')
    mod_1 = __import__('tests.test_lazyimport')
    assert(isinstance(mod_1, _LazyModuleMarker))


# Generated at 2022-06-26 02:31:42.963196
# Unit test for function make_lazy
def test_make_lazy():
  # 1. Is make_lazy.py in sys.modules?
  # 2. If so, does make_lazy.py have a __mro__ attribute?
  # 3. If so, does make_lazy.py's __mro__ attribute contain
  #    LazyModule in its return list?
  # 4. If so, then the test passed.

  import make_lazy

  # 1
  assert make_lazy.__name__ in sys.modules

  # 2
  assert hasattr(make_lazy, "__mro__")

  # 3
  mro = make_lazy.__mro__()
  if not LazyModule in mro:
    # 4
    assert False, mro

if __name__ == "__main__":
  make_lazy("make_lazy")


# Generated at 2022-06-26 02:31:51.896036
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)
    make_lazy(str_0)
    assert isinstance(sys.modules[str_0], _LazyModuleMarker)
    str_1 = "P]m$}oIYwosK'B\nR."
    assert sys.modules[str_1] == sys.modules[str_0]
    foo = getattr(sys.modules[str_1], "foo")
    assert sys.modules[str_1].foo == foo
    str_2 = "P]m$}oIYwosK'B\nR."
    str_3 = "P]m$}oIYwosK'B\nR."

# Generated at 2022-06-26 02:31:53.353099
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    print("Passed all tests")


# Generated at 2022-06-26 02:32:04.127835
# Unit test for function make_lazy
def test_make_lazy():
    original_import = __import__
    module_name = __name__ + '_test'

    def import_(name, *args, **kwargs):
        # Note: we use the name to stub it, because the second import sets
        # the module's parent to our current global namespace, which sets
        # the `__loader__` to None, which causes importlib to raise a
        # ValueError.
        if name == module_name:
            raise ModuleNotFoundError("No module named '%s'" % module_name)
        return original_import(name, *args, **kwargs)

    sys.modules[module_name] = None


# Generated at 2022-06-26 02:32:14.361301
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)
    sys_modules = sys.modules  # cache in the locals
    module_path = "W8CSw4|e{ah^AQAoN&W"  # random string
    make_lazy(module_path)
    if sys_modules[module_path].__mro__() == (LazyModule, ModuleType):
        if not isinstance(sys_modules[module_path], ModuleType):
            print("Unit test for function make_lazy PASSED")
        else:
            print("Unit test for function make_lazy FAILED")
    else:
        print("Unit test for function make_lazy FAILED")



# Generated at 2022-06-26 02:32:18.092743
# Unit test for function make_lazy
def test_make_lazy():
    module = ModuleType('module')
    assert not isinstance(module, _LazyModuleMarker)
    make_lazy(module.__name__)
    assert isinstance(module, _LazyModuleMarker)



if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:32:29.273287
# Unit test for function make_lazy
def test_make_lazy():
    str_1 = "jU@*aUoZ6Y`m9^}"
    def inner_0():
        str_3 = "L;*Kb<6L@U6RleY"
        assert isinstance(inner_0, object)
        def inner_1():
            assert isinstance(inner_1, object)
        assert isinstance(inner_1, object)
        inner_1()
    assert isinstance(inner_0, object)
    inner_0()
    assert isinstance(inner_0, object)
    def inner_2():
        def inner_3():
            def inner_4():
                assert isinstance(inner_4, object)
            assert isinstance(inner_4, object)
            inner_4()
            assert isinstance(inner_4, object)

# Generated at 2022-06-26 02:33:09.621800
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "P]m$}oIYwosK'B\nR."
    non_local_0 = NonLocal(str_0)
    make_lazy(str_0)
    # Unit test for function test_case_0
    def test_case_0():
        str_0 = "P]m$}oIYwosK'B\nR."
        non_local_0 = NonLocal(str_0)


# Generated at 2022-06-26 02:33:11.831681
# Unit test for function make_lazy
def test_make_lazy():
    str_3 = "zw\x0bI\x0c\x1d\t\r"
    non_local_0 = NonLocal(str_3)


# Generated at 2022-06-26 02:33:14.443978
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "d9*Q'1@yUNM|,/30bkW"
    non_local_0 = NonLocal(str_0)
    local_0 = __import__(str_0)
    module_path_0 = "__main__"
    non_local_0.value = module_path_0

test_make_lazy()

# Generated at 2022-06-26 02:33:26.599382
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['__main__'].test_case_0 = test_case_0
    sys.modules['__main__'].NonLocal = NonLocal
    make_lazy('__main__.test_case_0')
    assert sys.modules['__main__.test_case_0'].__mro__()[0] == __main__.NonLocal
    assert sys.modules['__main__.test_case_0'].__getattribute__('str_0') == 'P]m$}oIYwosK\'B\nR.'

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:33:33.930015
# Unit test for function make_lazy
def test_make_lazy():
    """
    Testing that the 'make_lazy' function works as expected
    """
    # 'sys.modules' in this unit test is not modified
    lazy_import = 'tests.python.unit_tests.lazy_import.test_lazy'

    # Lazy imports
    make_lazy(lazy_import)
    module = __import__(lazy_import)

    assert isinstance(module, _LazyModuleMarker)
    assert module.__name__ == lazy_import
    assert module.A == 'A'

    # Import the module again, and make sure the module has been imported
    # exactly once.
    module = __import__(lazy_import)
    assert module.__name__ == lazy_import
    assert module.A == 'A'

    # Check that the module can be imported with full path.

# Generated at 2022-06-26 02:33:42.815817
# Unit test for function make_lazy
def test_make_lazy():
    # Test the case when normal import works.
    str_0 = '__main__'
    str_1 = 'p'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_2 = str_0 + str_1
    make_lazy(str_2)
    str_3 = str_0 + str_1
    make_lazy(str_3)
    str_4 = str_0 + str_1
    make_lazy(str_4)
    str_5 = str_0 + str_1
    make_lazy(str_5)


# Generated at 2022-06-26 02:33:52.413216
# Unit test for function make_lazy
def test_make_lazy():
    import json
    make_lazy('json')
    assert 'json' in sys.modules
    json_module = sys.modules['json']
    assert json_module.__class__.__name__ == 'LazyModule'
    assert isinstance(json_module, _LazyModuleMarker)
    assert json_module.__mro__ == (json_module.__class__, ModuleType)
    assert json_module.__module__ == '__main__'
    assert isinstance(json_module, _LazyModuleMarker)
    assert json_module.__name__ == 'json'
    assert json_module.__doc__ == None
    assert json_module.__package__ == ''
    assert json_module.__class__ != json.__class__
    assert json_module.__file__ != json.__file__


# Generated at 2022-06-26 02:33:54.423566
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    pass

# Generated at 2022-06-26 02:33:58.421224
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_lazymodules'
    with LazyModules([module_path]):
        # Imported from the future, so we don't need to load ourselves.
        import __future__


# Generated at 2022-06-26 02:34:08.567534
# Unit test for function make_lazy
def test_make_lazy():
    # Check initialization
    mod_path = 'six.moves.queue'
    # The module should not be loaded yet

    # Mark as lazy
    make_lazy(mod_path)

    module = sys.modules[mod_path]

    # Check if the module has been set to lazy properly
    assert isinstance(module, _LazyModuleMarker)
    # Check if a property of the module is accessible
    assert hasattr(module, 'Empty')
    # Check if the module is now loaded properly
    assert sys.modules[mod_path] is not module
    assert not isinstance(sys.modules[mod_path], _LazyModuleMarker)
    assert hasattr(sys.modules[mod_path], 'Empty')

    # Check if the module can be lazy-imported again
    make_lazy(mod_path)
   

# Generated at 2022-06-26 02:35:36.004842
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import types
    import unittest

    sys_modules_orig = sys.modules
    sys.modules = {
        'test_os': os
    }

    def test_initial_import():
        import test_os
        assert isinstance(test_os, types.ModuleType)
        # We should still be able to load a regular os module.
        import os

    def test_lazy_import():
        make_lazy('test_os')
        import test_os
        assert not isinstance(test_os, types.ModuleType)
        # We should still be able to load a regular os module.
        import os

    def test_delayed_import():
        from test_os import mkdir
        assert isinstance(test_os, types.ModuleType)
        import os


# Generated at 2022-06-26 02:35:46.472813
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "lazy_module"
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)
    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            if module.value is None:
                del sys_modules[str_0]
                module.value = __import__(str_0)

                sys_modules[str_0] = __import__(str_0)

            return getattr(module.value, attr)
    sys_modules[str_0] = LazyModule()


# Generated at 2022-06-26 02:35:56.608282
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = "a"
    str_1 = "bCD"
    str_2 = "F"
    str_3 = "rJAB"
    str_4 = "J"
    str_5 = "j"
    str_6 = "."
    str_7 = "6"
    str_8 = "I"
    str_9 = "R"
    str_10 = "Q"
    str_11 = "S"
    str_12 = "T"
    str_13 = "U"
    str_14 = "V"
    str_15 = "W"
    str_16 = "X"
    str_17 = "Y"
    str_18 = "Z"
    str_19 = "_"
    str_20 = "a"
    str_21 = "b"
