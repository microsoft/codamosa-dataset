

# Generated at 2022-06-26 02:26:06.754560
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    lazy_module_marker_0 = _LazyModuleMarker(*list_0)
    module_type_0 = ModuleType(module_path)
    list_1 = None
    lazy_module_marker_1 = _LazyModuleMarker(*list_1)
    module_type_1 = ModuleType(module_path)
    list_2 = None
    lazy_module_marker_2 = _LazyModuleMarker(*list_2)
    module_type_2 = ModuleType(module_path)
    list_3 = None
    lazy_module_marker_3 = _LazyModuleMarker(*list_3)
    module_type_3 = ModuleType(module_path)
    list_4 = None
    lazy_module_marker_4 = _LazyModuleMarker

# Generated at 2022-06-26 02:26:13.505009
# Unit test for function make_lazy
def test_make_lazy():
    # Test with a simple as possible module.
    sys.modules['simple_module'] = ModuleType('simple_module')

    assert sys.modules['simple_module'].__name__ == 'simple_module'

    make_lazy('simple_module')

    # fake the module to be empty
    assert sys.modules['simple_module'].__name__ == 'simple_module'

# Generated at 2022-06-26 02:26:24.228913
# Unit test for function make_lazy
def test_make_lazy():
    stypy_return_type_4 = None

    # Test code.
    make_lazy("test")

    # Type inference callbacks.
    # Type inference callbacks.
    str_8 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 0, 0), 'str', 'list.py')

    @norecursion
    def func_with_no_return(localization, *varargs, **kwargs):
        global module_type_store
        # Assign values to the parameters with defaults
        defaults = []
        # Create a new context for function 'func_with_no_return'
        module_type_store = module_type_store.open_function_context('func_with_no_return', 0, 0, False)
        
        # Passed

# Generated at 2022-06-26 02:26:25.122435
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:26:26.476274
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = None
    make_lazy(module_path_0)

test_make_lazy()

# Generated at 2022-06-26 02:26:31.047838
# Unit test for function make_lazy
def test_make_lazy():
  try:
    assert_equal(make_lazy(1), NotImplemented)
  except:
    assert True
  try:
    assert_equal(make_lazy('module_path'), NotImplemented)
  except:
    assert True



# Generated at 2022-06-26 02:26:42.619212
# Unit test for function make_lazy
def test_make_lazy():
    # Conceptual test
    class A(object):
        def __init__(self):
            self.a1 = 1
            self.a2 = 2
        def get_a1(self):
            return 5
        def set_a1(self):
            self.a1 = 2

    a = A()
    #print a.get_a1()
    a.set_a1()
    #assert(a.get_a1() == 2)
    
    make_lazy(A)
    assert(A.a1 == 1)
    assert(A.a2 == 2)
    assert(A.get_a1() == 5)
    assert(A.get_a1() == 5)
    A.set_a2()
    assert(A.get_a1() == 5)
    
    


# Generated at 2022-06-26 02:26:53.214780
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test to check if a module is lazy
    '''
    import sys
    import unittest
    import os
    import types

    # make a dummy module called lazy_module
    sys.modules['lazy_module'] = 0
    make_lazy('lazy_module')
    module_name = sys.modules['lazy_module']

    # Check if lazy module is instance of LazyModule
    # (implementation of lazy module)
    assert isinstance(module_name, _LazyModuleMarker)

    # Checking if lazy module is an instance of module type
    assert isinstance(module_name, types.ModuleType)

    # Try to import some random module
    # which does not exist.

# Generated at 2022-06-26 02:26:55.070584
# Unit test for function make_lazy
def test_make_lazy():
   assert make_lazy == make_lazy()

# Generated at 2022-06-26 02:26:56.663958
# Unit test for function make_lazy
def test_make_lazy():
    # Test for make_lazy
    make_lazy("math")
    make_lazy("math")



# Generated at 2022-06-26 02:27:00.108068
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:27:02.527300
# Unit test for function make_lazy
def test_make_lazy():
    var_1 = make_lazy()
    assert type(var_1) == _LazyModuleMarker


# Generated at 2022-06-26 02:27:06.794108
# Unit test for function make_lazy
def test_make_lazy():
    import sys, types, traceback
    try:
        make_lazy()
    except Exception:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print(exc_type, exc_value, repr(traceback.format_tb(exc_traceback)))
        assert False


# Generated at 2022-06-26 02:27:17.359260
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'setuptools'
    var_0 = sys.modules.get(module_path, None)
    assert var_0 is None, \
        'Line: %d, Found: %r, Expected: %r' % (
            inspect.currentframe().f_lineno, var_0, None)

    var_1 = make_lazy(module_path)
    var_2 = sys.modules.get(module_path, None)
    var_3 = isinstance(var_2, _LazyModuleMarker)
    assert var_3, \
        'Line: %d, Found: %r, Expected: %r' % (
            inspect.currentframe().f_lineno, var_3, True)

    var_4 = var_2.__mro__()
    var_5 = var

# Generated at 2022-06-26 02:27:17.870985
# Unit test for function make_lazy
def test_make_lazy():
    pass



# Generated at 2022-06-26 02:27:26.465917
# Unit test for function make_lazy
def test_make_lazy():
    from unittest import mock
    import sys

    @mock.patch('sys.modules')
    def test_module_exists(all_modules):
        module_path = 'test_module_path'
        module = NonLocal(None)
        all_modules[module_path] = module

        make_lazy(module_path)
        assert isinstance(module.value, _LazyModuleMarker)
        assert all_modules[module_path] == module.value

        assert not hasattr(module.value, '__mro__')

        with pytest.raises(AttributeError) as exc_info:
            getattr(module.value, 'test_attr')

        assert str(exc_info.value) == "module 'test_module_path' has no attribute 'test_attr'"


# Generated at 2022-06-26 02:27:27.389055
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:27:37.799740
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import sys
    import filecmp

    with open(os.devnull, "w") as fnull:
        save_stdout = sys.stdout
        sys.stdout = fnull
        try:
            import numpy
        except ImportError:
            print("Skipping test_make_lazy. Need numpy.")
            return

        sys.stdout = save_stdout

        sys.modules['numpy'] = None


# Generated at 2022-06-26 02:27:39.556413
# Unit test for function make_lazy
def test_make_lazy():
    var_1 = "import urllib"
    make_lazy(var_1)


# Generated at 2022-06-26 02:27:48.747914
# Unit test for function make_lazy
def test_make_lazy():
    var_1 = ''
    run = 0
    var_1 = 'foo'
    var_1 = make_lazy(var_1)
    try:
        #if var_1.bar:
        #    raise Exception('Failed')
        raise Exception('failed')
    except AttributeError:
        pass
    else:
        raise Exception('Failed')
    var_1 = var_1.bar
    if var_1 != 42:
        raise Exception('Failed')
    var_1 = ''
    var_1 = 'foo'
    var_1 = make_lazy(var_1)
    if var_1.bar != 42:
        raise Exception('Failed')
    var_1 = ''
    var_1 = 'foo'
    var_1 = make_lazy(var_1)
   

# Generated at 2022-06-26 02:27:54.847897
# Unit test for function make_lazy
def test_make_lazy():

    # init
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    #case_0(non_local_0)

    # assert
    assert non_local_0.value == False

# test_make_lazy()

# Generated at 2022-06-26 02:27:56.197694
# Unit test for function make_lazy
def test_make_lazy():
    # Just verify that the function exists.
    assert make_lazy


# Generated at 2022-06-26 02:28:05.146919
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    str_0 = 'start.py'
    str_1 = 'start'
    sys_modules = sys.modules  # cache in the locals
    str_2 = None
    bool_1 = False
    non_local_1 = NonLocal(bool_1)
    module_path = None
    make_lazy('start.py')
    try:
        make_lazy('start')
    except (ImportError, InvocationTargetException) as err:
        str_2 = str(err)
    assert str_2 == "No module named 'start'", "wrong exception"

# Generated at 2022-06-26 02:28:12.790642
# Unit test for function make_lazy
def test_make_lazy():
    system_modules = {
        'lxml': 'lxml',
        'lxml.etree': 'lxml.etree',
        'lxml.etree.XPath': 'lxml.etree.XPath',
        'lxml.etree.XPathResult': 'lxml.etree.XPathResult',
        'lxml.etree.XPathElementEvaluator': 'lxml.etree.XPathElementEvaluator',
        'lxml.etree._Element': 'lxml.etree._Element',
        'lxml.etree._ElementTree': 'lxml.etree._ElementTree',
        'lxml.etree.XSLT': 'lxml.etree.XSLT',
    }


# Generated at 2022-06-26 02:28:15.485786
# Unit test for function make_lazy
def test_make_lazy():
    import sys, os, os.path
    import django.utils.unittest
    from django.views import debug, shortc

# Generated at 2022-06-26 02:28:26.825037
# Unit test for function make_lazy
def test_make_lazy():
    # Initialization
    test_make_lazy_0 = False
    sys_modules = sys.modules  # cache in the locals
    # store our 'instance' data in the closure.
    module_0 = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        # Initialization
        bool_0 = False
        bool_1 = False
        bool_2 = False
        # Function Attribute
        # Function Assignment

        # Function Call
        def __mro__(self):
            # Type Assertion
            assert isinstance(self, LazyModule)
            # State Assertion
            assert not bool_0
            assert not bool_1
            assert not bool_2
            # Function Call
            assert not test_make_lazy_0
            # State Update
            bool_0 = True
            #

# Generated at 2022-06-26 02:28:28.850890
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import dill
    bool_0 = True
    non_local_0 = NonLocal(bool_0)

    sys.modules = {}
    make_lazy('test_module')
    try:
        import test_module
    except:
        print('Unable to import test_module')
        sys.modules = dill.dumps(sys.modules)


# Generated at 2022-06-26 02:28:34.252842
# Unit test for function make_lazy
def test_make_lazy():
    # This test function is not supposed to be executed directly
    # (but can be executed by nose)
    # It is used by test_lazy_module.py to test the lazy module
    # mechanism

    print("Loading test module")
    import test_lazy_module

    print("Assertion 1")
    assert test_lazy_module.var_0 == 12

    print("Assertion 2")
    assert test_lazy_module.var_1 == 34

    print("Assertion 3")
    assert test_lazy_module.var_2 == 56

    print("Assertion 4")
    assert test_lazy_module.var_3 == 78


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:28:41.453977
# Unit test for function make_lazy
def test_make_lazy():
    with patch('sys.modules') as patch_sys_module:
        mock_export = MagicMock()

        mock_module = MagicMock(spec=ModuleType)
        mock_module.get_context = MagicMock(return_value=mock_export)

        mock_sys_module = MagicMock()
        mock_sys_module[mock_module.__name__] = mock_module
        patch_sys_module.__getitem__ = mock_sys_module.__getitem__
        patch_sys_module.__setitem__ = mock_sys_module.__setitem__

#         mocked_import = MagicMock()
#         with patch('__builtin__.__import__', mock_import):
        make_lazy(mock_module.__name__)

        assert patch_sys_module.__

# Generated at 2022-06-26 02:28:52.168720
# Unit test for function make_lazy
def test_make_lazy():
    # In this test case lazy module is mocked
    # before the attr is called on it, lazy module
    # should be deleted and real module should be imported
    # and stored in the same position on sys.modules
    bool_0 = False
    test_0 = lambda: bool_0
    test_1 = lambda: bool_1
    non_local_0 = NonLocal(bool_0)
    non_local_1 = NonLocal(test_0)
    non_local_2 = NonLocal(test_1)
    assert not non_local_0.value
    non_local_0.value = True
    assert non_local_0.value
    assert non_local_1.value()
    non_local_1.value = test_1
    assert non_local_2.value()

test_case_0()


# Generated at 2022-06-26 02:28:56.153612
# Unit test for function make_lazy
def test_make_lazy():
    assert False

# Generated at 2022-06-26 02:28:58.269693
# Unit test for function make_lazy
def test_make_lazy():
    # Test case 0
    result_0 = test_case_0()
    assert result_0 is None


# Unit test to provide code coverage for main
# Note: This is not part of the assignment.
# Note: Add additional tests by copying the functions from the skeleton file

# Generated at 2022-06-26 02:29:05.351578
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy(__name__)

    # Assert that the type is a LazyModule
    from types import ModuleType
    import sys
    assert isinstance(sys.modules[__name__], ModuleType)
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)

    # Make sure that the module still has its attributes
    assert sys.modules[__name__].test_case_0 == test_case_0



# Generated at 2022-06-26 02:29:06.763705
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy("foo") is None


# Generated at 2022-06-26 02:29:08.903328
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:29:17.228584
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import re

    non_local_0 = NonLocal(None)

    # User code begins
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)

    test_module = 'tests.test_lazy_mod'

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
           

# Generated at 2022-06-26 02:29:19.614036
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('uclibc')

    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:29:26.763499
# Unit test for function make_lazy
def test_make_lazy():
    assert not hasattr(sys.modules, 'test_case_0')
    import test_case_0
    assert hasattr(sys.modules, 'test_case_0')
    assert isinstance(test_case_0, _LazyModuleMarker)
    assert not isinstance(test_case_0, ModuleType)
    assert hasattr(test_case_0, 'test_make_lazy')
    assert isinstance(test_case_0, ModuleType)
    assert not isinstance(test_case_0, _LazyModuleMarker)



# Generated at 2022-06-26 02:29:28.398327
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)


test_case_0()
test_make_lazy()

# Generated at 2022-06-26 02:29:32.056567
# Unit test for function make_lazy
def test_make_lazy():
    # Test that the function doesn't make any assertions
    try:
        make_lazy("make_lazy")
    except:
        assert False, "A test for function make_lazy raised an unexpected exception."


# Generated at 2022-06-26 02:29:41.247838
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy'] = 42

    make_lazy('lazy')

    assert type(sys.modules['lazy']) is _LazyModuleMarker

    # Should not raise
    assert sys.modules['lazy']


# Generated at 2022-06-26 02:29:47.087508
# Unit test for function make_lazy
def test_make_lazy():
    from modules.lazy_module import lazy_module
    if hasattr(lazy_module, 'factorial'):
        raise Exception("lazy_module.factorial should not exist yet")
    # Use the factorial function to simulate an import

    assert lazy_module.factorial(5) == 120
    if not hasattr(lazy_module, 'factorial'):
        raise Exception("lazy_module.factorial should have been created by now")



# Generated at 2022-06-26 02:29:58.222430
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    def get_dict(self):
        return self.__dict__

    def test_case_0():
        test_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '__test_module__')
        sys.modules['__test_module__'] = None
        module_path = '__test_module__'
        del sys.modules['__test_module__']
        module_0 = NonLocal(None)

        # Run method make_lazy
        make_lazy(module_path)


# Generated at 2022-06-26 02:29:59.754626
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:30:03.980590
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Unit test for function make_lazy
    '''

    def assert_lazy(module_path):
        '''
        Define lazy module
        '''
        make_lazy(module_path)
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        return sys.modules[module_path]

    def assert_not_lazy(module_path):
        '''
        Define non-lazy module
        '''
        assert isinstance(sys.modules[module_path], ModuleType)
        return sys.modules[module_path]

    def test_case_1():
        '''
        Test with `make_lazy`
        '''
        lazy_module = assert_lazy('my_module')
        assert 'fake_attr' not in lazy_

# Generated at 2022-06-26 02:30:08.693521
# Unit test for function make_lazy
def test_make_lazy():
    test_bool = True
    test_string_0 = "test"
    test_0 = make_lazy(test_string_0)
    test_string_1 = "test_1"
    test_1 = make_lazy(test_string_1)
    test_string_2 = "test_2"
    test_2 = make_lazy(test_string_2)
    test_string_3 = "test_3"
    test_3 = make_lazy(test_string_3)
    assert test_bool


# Generated at 2022-06-26 02:30:12.180927
# Unit test for function make_lazy
def test_make_lazy():
    """
    Python 2 doesn't have nonlocal.
    """
    test_case_0()
    non_local_0 = NonLocal(False)
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 02:30:14.132086
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    make_lazy(non_local_0)


# Generated at 2022-06-26 02:30:16.657559
# Unit test for function make_lazy
def test_make_lazy():
    import subprocess

    make_lazy('subprocess')
    assert isinstance(subprocess, _LazyModuleMarker)
    assert subprocess.PIPE is subprocess.PIPE


# Generated at 2022-06-26 02:30:24.205316
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(bool_0)
    non_local_1 = NonLocal(bool_0)
    bool_0 = True
    make_lazy("module_0")
    non_local_0.value = bool_0
    bool_0 = False
    non_local_0.value = bool_0
    bool_0 = True
    non_local_0.value = bool_0
    bool_0 = False
    non_local_0.value = bool_0
    bool_0 = True
    non_local_0.value = bool_0
    bool_0 = False


# Generated at 2022-06-26 02:30:39.127504
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_case_0')


# Generated at 2022-06-26 02:30:42.189384
# Unit test for function make_lazy
def test_make_lazy():
    module_name_0 = 'sys'
    test_case_0()
    make_lazy(module_name_0)

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:30:52.190647
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    make_lazy("os")
    sys.modules["os"] = NonLocal(None)
    try:
        # Open a file
        f = os.open("foo.txt", os.O_RDWR|os.O_CREAT)
        # Write one string
        os.write(f, "This is test")
        os.close( f )
    except Exception:
        bool_0 = True
    print(bool_0)
    assert not bool_0

if __name__ == "__main__":
    make_lazy("os")
    # Open a file
    f = os.open("foo.txt", os.O_RDWR|os.O_CREAT)
    # Write one string

# Generated at 2022-06-26 02:30:55.749555
# Unit test for function make_lazy
def test_make_lazy():
    mod = __import__('os')
    make_lazy('os')
    is_lazy = isinstance(mod, _LazyModuleMarker)
    if(is_lazy == False):
        print("make_lazy failed")
        exit()



# Generated at 2022-06-26 02:31:02.687049
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    
    def fun_0():
        bool_0 = True
        non_local_0.value = bool_0
        return bool_0
    
    if fun_0():
        pass
    else:
        raise Exception('')
        

test_make_lazy()
test_case_0()

# Generated at 2022-06-26 02:31:09.821757
# Unit test for function make_lazy

# Generated at 2022-06-26 02:31:21.190977
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule(object):

        def __init__(self):
            self.initialized = True

    test_mod_path = 'tests.modules.test.make_lazy'

    sys.modules[test_mod_path] = TestModule()

    make_lazy(test_mod_path)
    try:
        assert 'tests.modules.test.make_lazy' in sys.modules
        assert isinstance(sys.modules[test_mod_path], _LazyModuleMarker)

        assert not sys.modules[test_mod_path].initialized
        del sys.modules['tests.modules.test.make_lazy']
        sys.modules['tests.modules.test.make_lazy'].initialized
    finally:
        del sys.modules[test_mod_path]



# Generated at 2022-06-26 02:31:22.122417
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(1)



# Generated at 2022-06-26 02:31:23.579235
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    sys.modules['tests.lazy'].__dict__['bool_0'] = NonLocal(False)

# Generated at 2022-06-26 02:31:29.076385
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = make_lazy('make_lazy')
    dict_0 = sys.modules
    dict_0['make_lazy']
    assert isinstance(sys.modules['make_lazy'], _LazyModuleMarker)


# Generated at 2022-06-26 02:31:47.534583
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import inspect
    import os

    class_0 = test_case_0
    module_path = inspect.getmoduleinfo(class_0.__code__).name

    make_lazy(module_path)
    module_0 = sys.modules[module_path]

    assert module_0.__name__ == module_path
    assert "test_case_0" in module_0.__dict__


# Generated at 2022-06-26 02:31:49.453642
# Unit test for function make_lazy
def test_make_lazy():
    # Place your code here
    pass



# Generated at 2022-06-26 02:32:00.868340
# Unit test for function make_lazy
def test_make_lazy():
    # __CPROVER_assume(python_input_counter < python_input_len);
    # current_input_string = python_input_strings[python_input_counter];
    # python_input_counter+=1;
    # module_path = str(current_input_string);
    __CPROVER_assume(python_input_counter < python_input_len);
    current_input_string = python_input_strings[python_input_counter];
    python_input_counter+=1;
    module_path = str(current_input_string);
    from types import ModuleType
    module_path = str(current_input_string);
    # __CPROVER_assume(0 <= python_input_counter < python_input_len);
    # current_input_string = python_input_strings[python_input

# Generated at 2022-06-26 02:32:06.659434
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    sys_modules_0 = sys.modules
    module_0 = NonLocal(None)
    lazy_module_0 = LazyModule()

    # test case for function make_lazy
    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            if module_0.value is None:
                del sys_modules_0[module_path]
                module_0.value = __import__(module_path)
                sys_modules_0[module_path] = __import__(module_path)
            return getattr(module_0.value, attr)

    sys_modules_0[module_path] = lazy_module_0


# Generated at 2022-06-26 02:32:15.969534
# Unit test for function make_lazy
def test_make_lazy():
    mod_1 = None
    sys_modules_0 = sys.modules
    module_path_0 = random_string()
    non_local_0 = NonLocal(mod_1)

    class LazyModule_0(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule_0, ModuleType)

        def __getattribute__(self, attr_0):
            non_local_0.value = None
            del sys_modules_0[module_path_0]
            non_local_0.value = __import__(module_path_0)

            sys_modules_0[module_path_0] = non_local_0.value
            return getattr(non_local_0.value, attr_0)


# Generated at 2022-06-26 02:32:26.672912
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    
    try:
        os.environ['APPVEYOR']
        sys.exit(0)
    except KeyError:
        None  # do nothing
    
    __file__ = os.path.realpath(__file__)
    this_file = os.path.dirname(__file__)
    parent_dir = os.path.dirname(this_file)
    make_lazy(parent_dir)
    
    assert os.chdir(parent_dir) is None
    
    try:
        assert __file__ == os.path.realpath(__file__)
    except AssertionError:
        __file__ = os.path.realpath(__file__)
    
    assert os.path.dirname(__file__) == this_file
    
   

# Generated at 2022-06-26 02:32:31.831473
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType

    def test_case_0():
        bool_0 = False
        non_local_0 = NonLocal(bool_0)


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()
    ret = doctest.testmod()
    if ret.failed == 0:
        print("Congratulations!! Testcases passed.")
    else:
        sys.exit(ret.failed)

# Generated at 2022-06-26 02:32:42.707435
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy
    """
    # Imports
    import sys
    from types import ModuleType
    import os

    # Setup before the test
    loc = locals()
    test_dir = os.path.dirname(os.path.abspath(__file__))
    sys.modules[__name__] = ModuleType(__name__)
    globals()[__name__] = sys.modules[__name__]
    make_lazy("mdssdk.connection")

    # Test statements
    loc['module_path'] = 'mdssdk.connection'
    loc['module'].__getattribute__('__mro__')()
    module_path
    loc['module_path']
    loc['module'].__getattribute__('__getattribute__')('__mro__')()
   

# Generated at 2022-06-26 02:32:52.523815
# Unit test for function make_lazy
def test_make_lazy():
    import math
    import types
    import sys

    # Test lazy module does not exist yet
    assert 'LazyTest' not in globals()
    assert 'LazyTest' not in sys.modules

    # Add lazy module and make sure it is a stand-in module
    make_lazy('LazyTest')
    assert '_LazyModuleMarker' in globals()
    assert 'LazyTest' in globals()
    assert globals()['LazyTest'].__class__.__name__ == 'LazyModule'
    assert isinstance(globals()['LazyTest'], types.ModuleType)
    assert isinstance(globals()['LazyTest'], _LazyModuleMarker)
    import LazyTest # noqa

# Generated at 2022-06-26 02:32:55.042068
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    non_local_0.value = False
    non_local_0.value = False
    non_local_0.value = False

# Generated at 2022-06-26 02:33:25.167949
# Unit test for function make_lazy
def test_make_lazy():
    # Check if the type of the module is of type LazyModule
    test_case_0()
    if __name__ == '__main__':
        assert True
    else:
        assert False

# Generated at 2022-06-26 02:33:29.085497
# Unit test for function make_lazy
def test_make_lazy():  # noqa
    module_path = "__main__"
    bool_0 = False
    non_local_0 = NonLocal(bool_0)
    make_lazy(module_path)
    bool_0 = True
    test_case_0()


# Generated at 2022-06-26 02:33:35.989332
# Unit test for function make_lazy
def test_make_lazy():
    """
    === Module ===
    test_make_lazy

    === Function ===
    def test_make_lazy():
        """
    """
    A test for function make_lazy.
    """
    str_0 = "This is a test."
    make_lazy(str_0)


# Generated at 2022-06-26 02:33:50.633517
# Unit test for function make_lazy
def test_make_lazy():

    # Create modules
    module_0 = ModuleType('module_0')
    module_1 = ModuleType('module_1')

    # Create member variables
    module_0.boolean_0 = True
    module_0.boolean_1 = False
    module_0.boolean_2 = True
    module_0.integer_0 = 0
    module_0.index_0 = 0
    module_0.string_0 = 'string_0'
    module_0.string_1 = 'string_1'
    module_0.string_2 = 'string_2'
    module_1.integer_0 = 0
    module_1.integer_1 = 1
    module_1.integer_2 = 2
    module_1.integer_3 = 3
    module_1.integer_4 = 4
    module_1

# Generated at 2022-06-26 02:33:53.277559
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:33:57.857434
# Unit test for function make_lazy
def test_make_lazy():
    # test non-local store
    test_case_0()
    assert not non_local_0.value


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:34:05.193472
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    non_local_0 = NonLocal(bool_0)

    def test_case_0():
        bool_0 = False
        non_local_0 = NonLocal(bool_0)

    class TestMakeLazyTestCase(unittest.TestCase):
        def test_make_lazy_test_0(self):
            self.assertTrue(False)
            self.assertFalse(bool_0)
            self.assertFalse(non_local_0.value)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-26 02:34:06.025200
# Unit test for function make_lazy
def test_make_lazy():
    assert True

# Generated at 2022-06-26 02:34:12.216054
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = False
    module_0 = None

    # Test that the lazy module is a LazyModule
    make_lazy('lister')
    bool_0 = isinstance(lister, _LazyModuleMarker)

    # Test that the lazy module needs to be accessed to
    # get the real module
    assert bool_0
    assert lister.Lister.__name__ == 'Lister'

# Generated at 2022-06-26 02:34:20.183451
# Unit test for function make_lazy
def test_make_lazy():
    # We can't test this with printing, because the actual tests
    # will be run through imports, rather than being a top-level.

    # So instead, lets test this with a "sentinel" value.
    # We'll set it to False and then if we end up importing a module
    # it will set it to True.

    bool_0 = False
    non_local_0 = NonLocal(bool_0)

    sys.modules['modulename'] = non_local_0

    mods = sys.modules

    # Clean up sys.modules
    del sys.modules['modulename']

    # test
    make_lazy('modulename')
    modulename = sys.modules['modulename']

    # We do not have an instance of sys.modules['modulename'] yet.

# Generated at 2022-06-26 02:35:26.174150
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import shutil
    import os
    import tempfile

    # Make the temporary directory
    temp_dir = tempfile.mkdtemp()

    # Make the temporary module_path
    module_path = os.path.join(temp_dir, 'test_module')

    # Make the temporary file
    temp_file = open(module_path, 'w')
    temp_file.write("test = 'test'")
    temp_file.close()

    # Test
    sys.modules.pop('test_module', None)
    make_lazy('test_module')
    assert 'test_module' in sys.modules
    assert 'test' not in dir(sys.modules['test_module'])
    test = sys.modules['test_module'].test

# Generated at 2022-06-26 02:35:29.154838
# Unit test for function make_lazy
def test_make_lazy():
    assert(isinstance(test_case_0, _LazyModuleMarker) == True)
    assert(bool_0 == False)
    assert(non_local_0.value == False)

# Generated at 2022-06-26 02:35:33.881644
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(bool_1)
    bool_0 = True
    bool_1 = False
    make_lazy(module_path='sudokusolver', non_local_0=non_local_0)
    assert bool_0 is bool_1


# Generated at 2022-06-26 02:35:39.415504
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    assert non_local_0.value
    make_lazy(module_path='test.test_module1')
    from test import test_module1
    test_module1.test_case_0()
    assert not bool_0
    assert test_module1.non_local_0.value

# Generated at 2022-06-26 02:35:48.027691
# Unit test for function make_lazy
def test_make_lazy():
    # Init here
    sys_modules = sys.modules
    non_local_0 = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)
        def __getattribute__(self, attr):
            if non_local_0.value is None:
                del sys_modules[module_path]
                non_local_0.value = __import__(module_path)
                sys_modules[module_path] = __import__(module_path)
            return getattr(non_local_0.value, attr)
    sys_modules[module_path] = LazyModule()



# Generated at 2022-06-26 02:35:49.322054
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    assert False


# Generated at 2022-06-26 02:35:57.189479
# Unit test for function make_lazy
def test_make_lazy():
    import pickle
    import sys
    module_path_0 = 'test_module'
    sys_modules_0 = sys.modules
    make_lazy(module_path_0)
    try:
        import test_module
        test_module.test()
        test_module.test()
    except:
        pass
    try:
        import test_module
        test_module.test()
        test_module.test()
    except:
        pass
    try:
        import test_module
        test_module.test()
        test_module.test()
    except:
        pass

if __name__ == '__main__':
    test_case_0()
    test_make_lazy()