

# Generated at 2022-06-26 02:25:56.769975
# Unit test for function make_lazy
def test_make_lazy():
    # Create a mock module named 'test_module'
    test_module = Mock()
    sys.modules['test_module'] = test_module
    make_lazy('test_module')
    assert (sys.modules['test_module'] is not test_module)



# Generated at 2022-06-26 02:26:04.505448
# Unit test for function make_lazy
def test_make_lazy():
    import email
    make_lazy('email')
    assert not isinstance(email, _LazyModuleMarker)
    assert isinstance(email.base64mime, _LazyModuleMarker)
    # Because we executed 'import email', it should be in sys.modules
    assert 'email' in sys.modules
    # It should also be in our local scope
    assert 'email' in locals()


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:26:10.478084
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module'] = lazy_module_marker_1 = _LazyModuleMarker()

    # Test the module is lazy
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

    # Test the module is lazy
    make_lazy('lazy_module')
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

    # Test the module is not lazy anymore
    del sys.modules['lazy_module']
    assert not isinstance(sys.modules['lazy_module'], _LazyModuleMarker)

# Generated at 2022-06-26 02:26:13.143732
# Unit test for function make_lazy
def test_make_lazy():
    # this is a simple case, without path
    make_lazy("simple_case_0")
    assert isinstance(simple_case_0, _LazyModuleMarker)


# Generated at 2022-06-26 02:26:15.707938
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(make_lazy(0), _LazyModuleMarker)


# Generated at 2022-06-26 02:26:24.381260
# Unit test for function make_lazy
def test_make_lazy():
    # Lazy module can be used with isinstance
    assert hasattr(sys, 'modules')
    make_lazy('micro_pylog')
    assert hasattr(sys, 'modules')
    assert isinstance(sys.modules['micro_pylog'], _LazyModuleMarker)
    make_lazy('micro_pylog')
    assert isinstance(sys.modules['micro_pylog'], _LazyModuleMarker)

    # Module will import on first access __getattribute__
    make_lazy('datetime')
    assert isinstance(sys.modules['datetime'], ModuleType)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:26:32.291821
# Unit test for function make_lazy
def test_make_lazy():
    """
    make_lazy should lazy load the test module.
    """
    test_module_path = 'autolazy.tests'

    assert test_module_path not in sys.modules

    make_lazy(test_module_path)

    assert test_module_path in sys.modules
    assert test_module_path in sys.modules
    assert sys.modules[test_module_path] is not None
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)



# Generated at 2022-06-26 02:26:43.517713
# Unit test for function make_lazy
def test_make_lazy():
    e = None
    module_path = 'lazy_load.lazy_load'
    lazy_module_marker = NonLocal(None)

    # This is a bit of a hack to fool the import detection.
    #  It's important we do this because it will prevent the
    #  module from actually being imported and evaluated.
    #  We're more likely to actually evaluate the lazy_module
    #  if we don't do this.
    test_case_0()

    setattr(sys, 'modules', {})  # reset the modules
    make_lazy(module_path)

    # check to make sure our module was imported properly

# Generated at 2022-06-26 02:26:49.017004
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_case_0'
    make_lazy(module_path)
    lazy_module = sys.modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)

if __name__ == '__main__':
    #test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:26:51.756571
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module'] = None
    make_lazy('lazy_module')
    import lazy_module
    assert isinstance(lazy_module, _LazyModuleMarker)



# Generated at 2022-06-26 02:26:59.054270
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("some.module")

    assert sys.modules["some.module"] is not None
    assert isinstance(sys.modules["some.module"], _LazyModuleMarker)


# Generated at 2022-06-26 02:27:08.958019
# Unit test for function make_lazy
def test_make_lazy():
    # Test.__init__ is imported lazily.
    make_lazy('tests.lazy_module.lazy_module_marker')

    # Test if lazy module_path can be imported successfully.
    import tests.lazy_module.lazy_module_marker

    # Test.__init__ is not imported yet.
    assert not isinstance(tests.lazy_module.lazy_module_marker, _LazyModuleMarker)

    # Test if lazy module_path can be imported successfully.
    import tests.lazy_module.lazy_module_marker
    assert not isinstance(tests.lazy_module.lazy_module_marker, _LazyModuleMarker)

    # Test if lazy module_path can be imported successfully.
    from tests.lazy_module import lazy_module_marker
   

# Generated at 2022-06-26 02:27:17.359816
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os, os.path
    module_path = os.path.abspath(os.path.join(os.path.dirname(os.__file__), 'path'))
    make_lazy(module_path)
    module = sys.modules[module_path]
    assert module.__mro__() == (LazyModule, ModuleType)
    assert module.join is os.path.join
    assert isinstance(module, LazyModule) is True
    assert isinstance(module, _LazyModuleMarker) is False
    assert isinstance(module, ModuleType) is True

# Generated at 2022-06-26 02:27:25.106052
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('testcase0_0_0', None)
    make_lazy('testcase0_0_0')

    assert not hasattr(sys.modules['testcase0_0_0'], 'A')
    testcase0_0_0 = __import__('testcase0_0_0')
    assert hasattr(testcase0_0_0, 'A')
    assert isinstance(sys.modules['testcase0_0_0'], ModuleType)
    sys.modules.pop('testcase0_0_0', None)


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:27:30.176325
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules

    try:
        # We don't have a way to reliably test that the module was actually
        # imported.
        # pylint: disable=no-member
        make_lazy('os')
        module_type = type(os)
        assert module_type == _LazyModuleMarker, module_type
    finally:
        del sys_modules['os']

# Generated at 2022-06-26 02:27:41.059382
# Unit test for function make_lazy
def test_make_lazy():
    import vistrails.tests.resources.lazy_modules as lazy_modules

    make_lazy('vistrails.tests.resources.lazy_modules')

    assert isinstance(sys.modules['vistrails.tests.resources.lazy_modules'],
                      _LazyModuleMarker)
    assert 'test_lazy_module' not in sys.modules

    # check that the LazyModule is functioning
    assert lazy_modules.test_lazy_module.my_func(50) == 52

    assert 'test_lazy_module' in sys.modules
    assert 'test_lazy_module_2' not in sys.modules

    # check that the lazily loaded module returns the same thing

# Generated at 2022-06-26 02:27:49.508886
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import os.path
    import pickle
    # Create a temporary directory in the OS's temp folder
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-26 02:27:56.956943
# Unit test for function make_lazy
def test_make_lazy():
    old_sys_modules = {}
    old_sys_modules.update(sys.modules)
    make_lazy('test_module')
    assert(isinstance(sys.modules['test_module'], _LazyModuleMarker))
    old_sys_modules.update(sys.modules)
    del old_sys_modules['test_module']
    sys.modules.clear()
    sys.modules.update(old_sys_modules)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 02:28:02.414649
# Unit test for function make_lazy
def test_make_lazy():
    print("Start test_make_lazy")

    make_lazy("doesnt_exist")
    import doesnt_exist  # will raise an `import` error
    assert isinstance(doesnt_exist, _LazyModuleMarker)

    print("End test_make_lazy")

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:28:11.267008
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['temp_module'] = None
    make_lazy('temp_module')
    assert sys.modules['temp_module'].__class__.__name__ == 'LazyModule'
    assert hasattr(sys.modules['temp_module'], '__mro__') == True
    assert hasattr(sys.modules['temp_module'], '__getattribute__') == True
    assert hasattr(sys.modules['temp_module'], '__init__') == True
    assert hasattr(sys.modules['temp_module'], '__call__') == True
    assert hasattr(sys.modules['temp_module'], '__format__') == True
    assert hasattr(sys.modules['temp_module'], '__get__') == True

# Generated at 2022-06-26 02:28:20.663920
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module = make_lazy('cms.djangoapps.modules.lms_modules_tests.test_data.test_module_0')

    module_0 = import_module('cms.djangoapps.modules.lms_modules_tests.test_data.test_module_0')

    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(module_0, _LazyModuleMarker)


# Generated at 2022-06-26 02:28:26.517567
# Unit test for function make_lazy
def test_make_lazy():
    # arbitrary module to test with
    print('foo.bar')
    print(make_lazy('foo.bar'))
    # make sure it's there
    print(sys.modules['foo.bar'])
    # make sure it's lazy
    print(isinstance(sys.modules['foo.bar'], _LazyModuleMarker))
    # make sure it imports when we ask for something off of it
    print(sys.modules['foo.bar'].__name__)
    # make sure it's not a LazyModule anymore
    print(not isinstance(sys.modules['foo.bar'], _LazyModuleMarker))


if __name__ == '__main__':

    # Unit test for function _LazyModuleMarker
    test_case_0()

    # Unit test for function make_lazy
    test_make

# Generated at 2022-06-26 02:28:37.561724
# Unit test for function make_lazy
def test_make_lazy():
    # This is how the module is normally imported
    import_1 = sys.modules['django.utils.module_loading']

    # Check that the module is already loaded in the system modules
    assert import_1 is not None
    
    # Make the module lazy
    make_lazy('django.utils.module_loading')

    # Get the module from the sys.modules
    lazy_module_marker_1 = sys.modules['django.utils.module_loading']


    # Isinstance test
    assert isinstance(lazy_module_marker_1, _LazyModuleMarker)


    # Check that the module is loaded after we access one of the attributes
    # in the module
    assert sys.modules['django.utils.module_loading'].make_lazy is not None


    # Check that the lazy module has

# Generated at 2022-06-26 02:28:48.469840
# Unit test for function make_lazy
def test_make_lazy():
    # check if the module is already present
    if sys.modules.get('joblib.test.test_lazy_import', None) is not None:
        del sys.modules['joblib.test.test_lazy_import']
    if sys.modules.get('joblib.test.test_lazy_import_getattribute', None) is not None:
        del sys.modules['joblib.test.test_lazy_import_getattribute']
    make_lazy('joblib.test.test_lazy_import')
    make_lazy('joblib.test.test_lazy_import_getattribute')
    test_lazy_import = sys.modules['joblib.test.test_lazy_import']

# Generated at 2022-06-26 02:28:53.206321
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules  # cache in the locals
    make_lazy("string")
    assert "string" in sys_modules
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(sys_modules["string"], lazy_module_marker)
    del sys_modules["string"]


# Generated at 2022-06-26 02:29:05.189302
# Unit test for function make_lazy
def test_make_lazy():
    from rpython.translator.c.test.test_genc import compile
    from rpython.translator.translator import TranslationContext
    from rpython.translator.c.genc import CStandaloneBuilder
    import tempfile, sys, os
    import random

    t = TranslationContext()
    rand = random.random()
    mod_name = "mod" + str(rand)
    module_path = 'rpython.rtyper.test_case_lazy_module_' + str(rand)
    make_lazy(module_path)

    def func():
        mod = __import__(module_path)
        assert not isinstance(mod, _LazyModuleMarker)

    a = t.buildannotator()
    s = a.build_types(func, [], annmodel.s_None)
   

# Generated at 2022-06-26 02:29:14.428087
# Unit test for function make_lazy
def test_make_lazy():
    tests = [
        [
            "a.b.c",
            [
                "a",
                [
                    "b",
                    [
                        "c",
                        "test"
                    ]
                ]
            ]
        ],
        [
            "a.b",
            [
                "a",
                "test"
            ]
        ]
    ]

    sys_modules = sys.modules  # cache in the locals
    for module, exp_mods in tests:
        make_lazy(module)
        # module is not imported yet
        assert module not in sys_modules

        module_chain = module.split(".")
        mod = sys_modules[module_chain[0]]
        # mod is now the lazy module
        assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-26 02:29:23.885764
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that a module is not loaded until a reference is
    fetched from it.
    """
    # Make sure we have the actual `BaseHTTPRequestHandler` mod.
    # We need to do this in case the lazy module was already created
    # before this test was run.
    import BaseHTTPRequestHandler as mod
    BaseHTTPRequestHandler = mod
    assert BaseHTTPRequestHandler is not None

    # Now make it lazy, and then make sure the module is not loaded.
    make_lazy('BaseHTTPRequestHandler')
    BaseHTTPRequestHandler = None

    # Make sure the module isn't loaded yet.
    import gc
    assert 'BaseHTTPRequestHandler' not in gc.get_referrers(mod)

    # Now import BaseHTTPRequestHandler, and make sure we get
    # our module.
    import BaseHTTPRequestHandler

# Generated at 2022-06-26 02:29:33.805858
# Unit test for function make_lazy
def test_make_lazy():
    """
    Generate a LazyModule that has not been imported yet
    """
    module_path = 'python_utils._test_make_lazy_0'
    assert module_path not in sys.modules

    make_lazy(module_path)

    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    assert module_path not in sys.modules

    assert sys.modules[module_path].__name__ == 'python_utils._test_make_lazy_0'

    assert sys.modules[module_path].__spec__.name == 'python_utils._test_make_lazy_0'

    assert 'python_utils._test_make_lazy_0' in sys.modules


# Generated at 2022-06-26 02:29:42.645864
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    class _T(object):
        pass

    # Test case 0
    # Note: we do not want to make "tests" lazy
    for mod_name in ["_LazyModuleMarker", "sys"]:
        module = sys.modules[mod_name]
        assert module is not None
        make_lazy(mod_name)
        assert sys.modules[mod_name] is not None
        assert not isinstance(sys.modules[mod_name], _LazyModuleMarker)

    # Test case 1
    _T._old_mc = _T.__module__
    _T.__module__ = None
    sys.modules["_T"] = _T
    make_lazy("_T")
    assert _T.__module__ == "_T"
    del sys.modules["_T"]
    _

# Generated at 2022-06-26 02:29:55.498354
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    sys.modules['lazy_module_0'] = None
    lazy_module_marker_0 = make_lazy('lazy_module_0')

    from types import ModuleType

    assert isinstance(lazy_module_marker_0, _LazyModuleMarker)

    assert lazy_module_marker_0 is sys.modules['lazy_module_0']
    assert isinstance(sys.modules['lazy_module_0'], _LazyModuleMarker)
    assert isinstance(sys.modules['lazy_module_0'], ModuleType)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:29:58.368018
# Unit test for function make_lazy
def test_make_lazy():
    assert_equals(make_lazy('./test_lazy_module'), None)

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:30:03.391568
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules.pop('lazy_module_marker_0')

    make_lazy('lazy_module_marker_0')

    sys.modules.pop('lazy_module_marker_0')
    sys.modules.pop('lazy_module_marker_1')



# Generated at 2022-06-26 02:30:05.241343
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_0 = _LazyModuleMarker()
    assert not isinstance(make_lazy("0"), lazy_module_marker_0)

# Generated at 2022-06-26 02:30:13.637858
# Unit test for function make_lazy
def test_make_lazy():
    # test the normal imports
    import os
    import sys

    # now lazy import the same modules
    make_lazy('os')
    make_lazy('sys')

    # now we should be able to overwrite the imported module with
    # a fake LazyModule instance
    os = 'fake os'
    sys = 'fake sys'

    # now compare their types to ensure the lazy import is non-destructive
    assert type(os) is str
    assert type(sys) is str

    # now check if they can be used as normal
    assert os.path.abspath('/') == '/'
    assert sys.getrecursionlimit() == 1000
    assert sys.platform.startswith('darwin')


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()


# Generated at 2022-06-26 02:30:21.208691
# Unit test for function make_lazy
def test_make_lazy():
    import inspect
    import sys

    def check_lazy_module(module_path):
        """
        Check that a module inserted into sys.modules by make_lazy is actually
        lazy.
        """
        assert module_path in sys.modules

        # Store a copy of the module as this will be mutated as soon as we do an attribute access.
        module = sys.modules[module_path]

        assert isinstance(module, _LazyModuleMarker)

        # Forcing the import should change the module.
        value = inspect.getmodule(inspect.stack()[1][0])
        assert isinstance(value, ModuleType)

        assert module is not value

        # Ensure that the module is now a normal module.
        assert module_path in sys.modules
        assert sys.modules[module_path] is value

    check_l

# Generated at 2022-06-26 02:30:26.281406
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules  # cache in the locals
    module_path = 'os'
    make_lazy(module_path)
    is_lazy = isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert is_lazy is True

if __name__ == "__main__":
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:30:27.280634
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(_LazyModuleMarker)
    test_case_0()

# Generated at 2022-06-26 02:30:37.141768
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('module_1')

    assert(module_1.module_1_0.CONSTANT_VALUE == 0)

    module_1_0 = module_1.module_1_0

    assert(module_1_0.CONSTANT_VALUE == 0)
    assert(module_1_0.FUNCTION_0() == 0)
    assert(module_1_0.FUNCTION_1(1) == 1)

    assert(module_1.module_1_1.CONSTANT_VALUE == 1)

    module_1_1 = module_1.module_1_1

    assert(module_1_1.CONSTANT_VALUE == 1)
    assert(module_1_1.FUNCTION_0() == 0)

# Generated at 2022-06-26 02:30:40.005399
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('base')
    mod = sys.modules['base']

    assert isinstance(mod, _LazyModuleMarker)
    assert isinstance(mod, ModuleType)



# Generated at 2022-06-26 02:30:50.348247
# Unit test for function make_lazy
def test_make_lazy():
    from random import randint
    rand = randint(0, 10**5)
    m = 'os'
    make_lazy(m)
    assert isinstance(sys.modules[m], _LazyModuleMarker)

# Generated at 2022-06-26 02:30:57.025452
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker = _LazyModuleMarker()
    lazy_module_path = '__builtin__'

    module = make_lazy(lazy_module_path)
    module_name = sys.modules[lazy_module_path]

    assert isinstance(module_name, _LazyModuleMarker)
    assert module_name.__mro__() == (lazy_module_marker, ModuleType)
    assert isinstance(module_name, lazy_module_marker)
    assert module_name.__getattribute__('abs') == abs

# Generated at 2022-06-26 02:31:07.862447
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_0 = _LazyModuleMarker()

    # mock the __import__ function.
    lazy_module_marker_0 = NonLocal(None)

    orig_import = __builtins__.__import__

    def mock_import(name, globals={}, locals={}, fromlist=[], level=-1):
        if name == 'lazy_module_marker_0':
            if lazy_module_marker_0 is None:
                raise NameError

            return lazy_module_marker_0
        else:
            return orig_import(name, globals, locals, fromlist, level)

    __builtins__.__import__ = mock_import

    def mock_delitem(dicitonary, key):
        if key == 'lazy_module_marker_0':
            lazy_

# Generated at 2022-06-26 02:31:13.084903
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    module_path = 'utils.lazy.test'
    make_lazy(module_path)

    lazy_module_marker_0 = _LazyModuleMarker()

    lazy_module_0 = sys.modules[module_path]

    assert( isinstance(lazy_module_0, lazy_module_marker_0.__class__) )



# Generated at 2022-06-26 02:31:21.852992
# Unit test for function make_lazy
def test_make_lazy():
    import x
    import y
    import z

    make_lazy('x')
    make_lazy('y')
    make_lazy('z')

    assert sys.modules['x'] is not x
    assert sys.modules['y'] is not y
    assert sys.modules['z'] is not z

    assert x.value == 10
    assert y.value == 20
    assert z.value == 30

    assert sys.modules['x'] is x
    assert sys.modules['y'] is y
    assert sys.modules['z'] is z



# Generated at 2022-06-26 02:31:29.486536
# Unit test for function make_lazy
def test_make_lazy():
    print('Test case 0')
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()
    print('End of test case')

# Generated at 2022-06-26 02:31:36.401766
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('tests.test_modules.lazymodule')
    import tests.test_modules.lazymodule
    from tests.test_modules.lazymodule import config
    from tests.test_modules.lazymodule import config2
    from tests.test_modules.lazymodule import config3
    
    assert isinstance(tests.test_modules.lazymodule, _LazyModuleMarker)
    asser

# Generated at 2022-06-26 02:31:43.747997
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    test_setup()
    import sys
    sys_modules = sys.modules  # cache in the locals
    sys.modules = {}

    from test_case_0 import lazy_module_marker_0
    from test_case_0 import module_with_unused_imports
    from test_case_0 import module_with_used_imports

    # Test
    make_lazy('test_case_0.lazy_module_marker_0')
    make_lazy('test_case_0.module_with_unused_imports')
    make_lazy('test_case_0.module_with_used_imports')

    # Assert
    assert isinstance(lazy_module_marker_0, _LazyModuleMarker)

# Generated at 2022-06-26 02:31:52.356292
# Unit test for function make_lazy
def test_make_lazy():
    from .dummy.lazy import A
    from .dummy.lazy.inner import B

    def do_test(msg, module_path, result):
        make_lazy(module_path)

        assert(result == isinstance(sys.modules[module_path], _LazyModuleMarker))
        print(msg)

    do_test("Test 0", 'A', True)
    do_test("Test 1", 'A.B', True)
    do_test("Test 2", 'A.B.C', True)
    do_test("Test 3", 'A.B.C.D', True)

    # Make sure our make_lazy function works with package hierarchy.
    do_test("Test 4", 'A.B.C.D.E', True)

# Generated at 2022-06-26 02:31:58.838138
# Unit test for function make_lazy
def test_make_lazy():
    def test_case_0():
        make_lazy('sys')
        sys_0 = sys.modules['sys']
        assert isinstance(sys_0, _LazyModuleMarker)

        sys_0_0 = sys_0.__name__
        assert sys_0_0 == 'sys'

        sys_0_1 = sys_0.__doc__
        assert sys_0_1 is not None

    test_case_0()


# Generated at 2022-06-26 02:32:22.152762
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import re
    import unicodedata
    import inspect
    import unittest
    import collections

    # This is the setup of the test.
    # Each path in the ordered dict gets loaded, and then
    # we check if the module was lazy loaded (that it is a _lazyModuleMarker)
    # then we get the attribute (like 'split') and then call it ('split()')
    # which will cause the module to be loaded.
    # Then we check that the module is not a _lazyModuleMarker and then
    # we check if the function (like split) is the same as the original import
    # we did at the start.
    lazy_module_marker_0 = _LazyModuleMarker()

# Generated at 2022-06-26 02:32:31.642885
# Unit test for function make_lazy
def test_make_lazy():
    # test object attribute inheritance (__mro__)
    assert isinstance([], _LazyModuleMarker)
    # no lazy module is added to sys.modules
    assert 'some_package.some_module' not in sys.modules
    # no lazy module is added to sys.modules
    assert 'some_package' not in sys.modules

    # prevent module being imported
    make_lazy('some_package.some_module')
    # lazy module is added to sys.modules as LazyModule
    assert 'some_package.some_module' in sys.modules
    assert isinstance(sys.modules['some_package.some_module'], _LazyModuleMarker)
    # lazy module is added to sys.modules as LazyModule
    assert 'some_package' not in sys.modules

    # no module has been imported

# Generated at 2022-06-26 02:32:42.707188
# Unit test for function make_lazy
def test_make_lazy():
    # We are going to import `lazy_module_marker_0`
    global lazy_module_marker_0

    # Since we haven't yet imported lazy_module_marker_0,
    # it should be None
    assert lazy_module_marker_0 is None

    # Import lazy_module_marker_0 and make sure we get the right value
    import lazy_module_marker_0
    assert isinstance(lazy_module_marker_0, _LazyModuleMarker)

    # Now unload the module and import it lazily
    del sys.modules['lazy_module_marker_0']
    make_lazy('lazy_module_marker_0')

    # We should still have the correct value for `lazy_module_marker_0`
    assert lazy_module_marker

# Generated at 2022-06-26 02:32:51.615912
# Unit test for function make_lazy
def test_make_lazy():
    # TestCase 0
    assert isinstance(test_case_0(), _LazyModuleMarker)


if __name__ == "__main__":
    import sys
    import traceback
    import __builtin__
    
    if sys.argv[-1] == "-ut":
        sys.argv.pop()
        unittest.main()
    else:
        __builtin__._ = LazyString(sys.argv[1])

# Generated at 2022-06-26 02:32:53.008385
# Unit test for function make_lazy
def test_make_lazy():
    assert True == isinstance(test_case_0(), _LazyModuleMarker)


# Generated at 2022-06-26 02:33:03.745704
# Unit test for function make_lazy
def test_make_lazy():
    old_sys_modules = sys.modules.copy()

    lazy_module_name = 'eazy_import.test_lazy_module_1'

    assert lazy_module_name not in sys.modules

    make_lazy(lazy_module_name)

    assert isinstance(sys.modules[lazy_module_name], _LazyModuleMarker)
    assert sys.modules[lazy_module_name]
    assert not hasattr(sys.modules[lazy_module_name], '__name__')
    assert not hasattr(sys.modules[lazy_module_name], '__file__')

    import eazy_import.test_lazy_module_1

    test_module = sys.modules[lazy_module_name]

    assert test_module is eazy_import.test_lazy_module_

# Generated at 2022-06-26 02:33:08.650885
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    sys.modules['foo'] = 1
    make_lazy('foo')
    assert isinstance(sys.modules['foo'], types.ModuleType)
    assert isinstance(sys.modules['foo'], _LazyModuleMarker)
    del sys.modules['foo']


# Generated at 2022-06-26 02:33:14.743040
# Unit test for function make_lazy
def test_make_lazy():
    mp = 'cpython-36.lib'
    __import__(mp)
    assert mp in sys.modules
    del sys.modules[mp]
    make_lazy(mp)
    assert isinstance(sys.modules[mp], _LazyModuleMarker)
    assert mp not in sys.modules
    make_lazy(mp)
    make_lazy(mp)
    make_lazy(mp)
    assert mp not in sys.modules
    sys.modules[mp]
    assert mp in sys.modules


if __name__ == "__main__":
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:33:26.800570
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure that make_lazy works.
    """
    assert sys.modules['my_fake_module'].__name__ == 'my_fake_module'
    assert isinstance(sys.modules['my_fake_module'], LazyModule)

    assert sys.modules['my_fake_module.fake_submodule'].__name__ == \
        'my_fake_module.fake_submodule'
    assert isinstance(sys.modules['my_fake_module.fake_submodule'], LazyModule)

if __name__ == "__main__":
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:33:34.017660
# Unit test for function make_lazy
def test_make_lazy():
    # Lazy module
    module_path = 'os.path'
    make_lazy(module_path)
    mod = sys.modules[module_path]
    # We should be able to verify if it is a lazy module
    assert isinstance(mod, _LazyModuleMarker), 'Failed to make lazy'

    # Next we will try to access a module attribute, exists_
    try:
        mod.exists_
    except AttributeError:
        assert True, 'Accessing lazy module attribute failed'

    # We should be able to verify if it is a lazy module
    assert isinstance(mod, _LazyModuleMarker), 'After accessing lazy attribute, isinstance failed'

    # Make sure the lazy module is loaded when we access an attribute
    assert mod.__name__.endswith('path'), 'Lazy module not loaded'

# Generated at 2022-06-26 02:34:30.102795
# Unit test for function make_lazy
def test_make_lazy():
    # Test #0
    lazy0 = make_lazy('test0')
    assert(lazy0)

    # Test #1
    lazy1 = make_lazy('test1')
    assert(lazy1)


test_case_0()
test_make_lazy()

# Generated at 2022-06-26 02:34:31.567637
# Unit test for function make_lazy
def test_make_lazy():
    # We are testing here that we have correctly initialized the
    # LazyModule marker
    test_case_0()



# Generated at 2022-06-26 02:34:39.092519
# Unit test for function make_lazy
def test_make_lazy():
    import os, sys

    # Use os.path to make sure we can pull in a module that needs other modules
    make_lazy("os.path")
    import os
    assert isinstance(os, _LazyModuleMarker)
    assert os.path is not None
    assert os.path.split("a/b/c") == ["a/b", "c"]

    # Make sure that running `import {lazy_module.attr}`
    # properly works and caches the lazy module.
    make_lazy("os")
    assert isinstance(os, _LazyModuleMarker)

    # Make sure that we can reload a lazy module and
    # cache the new value.
    import os
    reload(os)
    assert isinstance(os, _LazyModuleMarker)

    # Make sure that we can use a lazy module

# Generated at 2022-06-26 02:34:50.123740
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules.pop('test_make_lazy_module', None)
    assert test_make_lazy_module not in sys.modules

    make_lazy('test_make_lazy_module')
    assert test_make_lazy_module in sys.modules

    assert isinstance(test_make_lazy_module, _LazyModuleMarker)
    assert isinstance(test_make_lazy_module, ModuleType)

    make_lazy_module_attr_0 = test_make_lazy_module.attr_0
    assert make_lazy_module_attr_0 == 'attr_0_value'

    assert isinstance(test_make_lazy_module, ModuleType)
    assert not isinstance(test_make_lazy_module, _LazyModuleMarker)



# Generated at 2022-06-26 02:34:57.235744
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['x'] = None
    mock_module = Mock()
    import x
    x.__import__ = Mock(return_value=mock_module)
    make_lazy('x')
    sys.modules['x'].__mro__()
    sys.modules['x'].__mro__
    assert isinstance(sys.modules['x'], _LazyModuleMarker)
    assert not isinstance(mock_module, _LazyModuleMarker)
    assert sys.modules == {'x': mock_module}
    x.__import__.assert_called_with('x')
    del sys.modules['x']

# Generated at 2022-06-26 02:34:58.650997
# Unit test for function make_lazy
def test_make_lazy():
    assert inspect.getsource(make_lazy) == inspect.getsource(test_make_lazy)


# Generated at 2022-06-26 02:35:03.954573
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    def import_fails(name, globals=None, locals=None, fromlist=(), level=0):
        raise ImportError("Mocking import")

    orig_import = __import__
    sys.modules["imported_module.re_module"] = None
    sys.modules["imported_module.sub_sub_module"] = None
    sys.modules["imported_module.sub_sub_sub_module"] = None
    sys.modules["imported_module.sub_sub_sub_sub_module"] = None
    sys.modules["imported_module.sub_sub_sub_sub_sub_module"] = None
    # Test the basic case.
    make_lazy("imported_module.re_module")


# Generated at 2022-06-26 02:35:14.672903
# Unit test for function make_lazy
def test_make_lazy():

    # Put a module in sys.modules
    sys.modules["TestMe"] = ModuleType("TestMe")

    # Put another module in sys.modules
    sys.modules["TestYou"] = ModuleType("TestYou")

    # Test that marking 'TestMe' as lazy works
    make_lazy("TestMe")

    # Test that marking 'TestYou' as lazy works
    make_lazy("TestYou")

    # Test that TestMe is the right type
    if (type(sys.modules["TestMe"]) != _LazyModuleMarker):
        print("FAIL: TestMe is not a _LazyModuleMarker object.")
    else:
        print("PASS: TestMe is the correct type.")
        print(type(sys.modules["TestMe"]))

    # Test that TestYou is the right type

# Generated at 2022-06-26 02:35:20.501255
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_1 = _LazyModuleMarker()
    sys.modules["test_make_lazy"] = lazy_module_marker_1
    make_lazy("test_make_lazy")
    test_make_lazy_mod = sys.modules["test_make_lazy"]
    assert isinstance(test_make_lazy_mod, _LazyModuleMarker)
    assert isinstance(test_make_lazy_mod, LazyModule)

# Generated at 2022-06-26 02:35:23.399882
# Unit test for function make_lazy
def test_make_lazy():
    import lazy_import.tests.sample
    assert isinstance(lazy_import.tests.sample, _LazyModuleMarker)
    make_lazy('lazy_import.tests.sample')
    assert not isinstance(lazy_import.tests.sample, _LazyModuleMarker)

