

# Generated at 2022-06-26 02:25:52.321683
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:25:54.446056
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)



if __name__ == "__main__":
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:25:57.449304
# Unit test for function make_lazy
def test_make_lazy():
    """stand in test
    """
    assert True  # TODO: implement your test here


# Generated at 2022-06-26 02:25:58.900639
# Unit test for function make_lazy
def test_make_lazy():
    res = make_lazy('collections')
    assert res is None



# Generated at 2022-06-26 02:26:04.158045
# Unit test for function make_lazy
def test_make_lazy():
    foo = 'foo'
    make_lazy(foo)
    assert isinstance(sys.modules[foo], _LazyModuleMarker)
    try:
        sys.modules[foo].__name__
    except AttributeError:
        assert sys.modules[foo].__name__ == 'foo'

# Generated at 2022-06-26 02:26:05.531626
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:26:16.715972
# Unit test for function make_lazy
def test_make_lazy():
    # This example was created by @ejona86
    class MyException(Exception):
        pass

    class MyException2(Exception):
        pass

    class MyClass:
        def __init__(self, a):
            self.a = a

    import __builtin__
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()


# Generated at 2022-06-26 02:26:26.084316
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure function make_lazy raises an error when passed bad types
    with pytest.raises(TypeError):
        make_lazy(None)
    with pytest.raises(TypeError):
        make_lazy(1)
    with pytest.raises(TypeError):
        make_lazy(True)

    # Make sure function make_lazy raises an error when passed bad values
    with pytest.raises(ValueError):
        make_lazy('   ')

    # Make sure function make_lazy doesn't raise an error when passed valid types
    make_lazy('os')
    make_lazy('sys')
    make_lazy('math')
    make_lazy('random')

    # Make sure function make_lazy doesn't raise an error when passed valid values

# Generated at 2022-06-26 02:26:37.173958
# Unit test for function make_lazy
def test_make_lazy():
    import types
    import sys
    # Run this test as an internal program
    # Check if function make_lazy is defined
    assert ('make_lazy' in globals() or 'LazyModules.make_lazy' in globals())
    m = sys.modules[__name__] # get module reference
    # Check if it is a module
    assert isinstance(m, types.ModuleType)
    # Check if it is lazy
    assert isinstance(m, _LazyModuleMarker)
    # Use of NonLocal
    bool_1 = True
    non_local_1 = NonLocal(bool_1)
    assert non_local_1.value
    # Use of NonLocal
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    assert non_local_0.value

# Generated at 2022-06-26 02:26:49.285451
# Unit test for function make_lazy
def test_make_lazy():
    """
    A test for the make_lazy function
    """
    from types import ModuleType
    global sys
    make_lazy("sys")
    assert isinstance(sys, ModuleType)
    assert hasattr(sys, '__name__')
    assert sys.__name__ == 'sys'
    assert hasattr(sys, '__file__')
    assert sys.__file__ == '/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/sys.pyc'
    assert hasattr(sys, '__doc__')

# Generated at 2022-06-26 02:26:55.532277
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy_0'] = None
    make_lazy('test_make_lazy_0')
    # Make sure the module is lazy
    assert(isinstance(sys.modules['test_make_lazy_0'], _LazyModuleMarker))
    # Make sure the module isn't loaded yet
    assert(sys.modules['test_make_lazy_0'] is not None)



# Generated at 2022-06-26 02:26:56.442232
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy()


# Generated at 2022-06-26 02:27:07.523669
# Unit test for function make_lazy
def test_make_lazy():

    try:
        import ctypes
    except ImportError:
        pass
    else:
        assert isinstance(ctypes, _LazyModuleMarker), \
            "Did not lazy load ctypes module because it was imported"

        assert not isinstance(ctypes.CDLL, _LazyModuleMarker), \
            "Result of importing ctypes was also lazy loaded"

        assert ctypes.CDLL.LoadLibrary.__name__ == 'LoadLibrary', \
            "Did not have access to ctypes.CDLL.LoadLibrary"

        try:
            import ctypes.util
        except ImportError:
            pass
        else:
            assert isinstance(ctypes.util, _LazyModuleMarker), \
                "Did not lazy load ctypes.util module because it was imported"


# Generated at 2022-06-26 02:27:11.805901
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    modules_original = sys.modules

    test_case_0()

    assert sys.modules is modules_original


if (__name__ == "__main__"):
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-26 02:27:17.909957
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import pytest
    with pytest.raises(KeyError):
        sys.modules.pop('test_module')
    test_module = make_lazy('test_module')
    assert isinstance(test_module, _LazyModuleMarker)
    assert len(sys.modules) == 1
    assert sys.modules['test_module'] == test_module
    import test_module
    assert sys.modules['test_module'] == test_module


# Generated at 2022-06-26 02:27:20.014739
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_case_0()
    except NameError as e:
        print('NameError:', e)
        raise


# Generated at 2022-06-26 02:27:24.393414
# Unit test for function make_lazy
def test_make_lazy():
    from tests.test_data import TestData
    test_data = TestData
    empty_data = TestData('//')
    empty_data.add_default_data()
    make_lazy('tests.test_data.TestData')
    assert 'tests.test_data' in sys.modules
    assert isinstance(sys.modules['tests.test_data'], _LazyModuleMarker)
    assert not hasattr(sys.modules['tests.test_data'], 'TestData')
    assert test_data is not empty_data
    assert test_data.default_data is not empty_data.default_data
    assert test_data.default_data is empty_data.default_data
    assert test_data is empty_data


# Generated at 2022-06-26 02:27:33.962350
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy('sys')

    sys_module = sys.modules['sys']

    if not isinstance(sys_module, _LazyModuleMarker):
        raise Exception('Expected an instance of LazyModule')

    if 'platform' not in sys_module.__dict__:
        raise Exception('Expected the LazyModule to not have an attribute named platform')

    platform = sys_module.platform
    if not isinstance(platform, str):
        raise Exception('Expected the value of sys.platform to be a string')

    if not platform.startswith('win'):
        raise Exception('Expected the sys.platform to start with "win"')

    if 'platform' in sys_module.__dict__:
        raise Exception('Expected the LazyModule to not have an attribute named platform after the first access')


# Generated at 2022-06-26 02:27:44.625266
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None
    assert make_lazy(0) == None

# Generated at 2022-06-26 02:27:48.857053
# Unit test for function make_lazy
def test_make_lazy():
    # Replace with your code
    test_case_0()

# Python 3.0+, uses importlib.util.module_from_spec
# Python 2.7, uses imp.new_module
# Python 2.6, uses types.ModuleType.__init__

# Generated at 2022-06-26 02:27:59.636577
# Unit test for function make_lazy
def test_make_lazy():
    # Prepare a module
    prepare()

    # Import the module
    import test_module_0

    # Ensure it's not lazy
    assert not isinstance(test_module_0, _LazyModuleMarker)

    # Mark it as lazy
    make_lazy("test_module_0")

    # Import it again
    import test_module_0

    # Ensure its lazy
    assert isinstance(test_module_0, _LazyModuleMarker)

    # Access an attribute
    test_module_0.test_attr

    # Ensure its no longer lazy
    assert not isinstance(test_module_0, _LazyModuleMarker)

# Generated at 2022-06-26 02:28:07.651324
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = True
    test_case_0()
    bool_1 = not __import__('os').path.isdir('/')
    if bool_1:
        __import__('sys').setrecursionlimit(__import__('sys').getrecursionlimit() * 2)
        print('Using Python 2')
    else:
        print('Using Python 3')
    if __name__ == '__main__':
        make_lazy('os')
        make_lazy('sys')
        print('This should not raise an exception.')
    return 0


# Generated at 2022-06-26 02:28:09.422398
# Unit test for function make_lazy
def test_make_lazy():
    # Test case 0
    test_case_0()
    # Unit test for function make_lazy



# Generated at 2022-06-26 02:28:11.500048
# Unit test for function make_lazy
def test_make_lazy():
    # TODO: implement this method.
    pass

# Generated at 2022-06-26 02:28:22.640938
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    module_path = 'case_0'
    make_lazy(module_path)
    assert module_path in sys_modules, "Failed to add the lazy module to the sys.modules dictionary: %s" % sys_modules
    assert sys.modules[module_path].__getattribute__('value') is None, \
        "Failed to set the module value to None: %s" % sys_modules[module_path]
    assert sys.modules[module_path].__getattribute__('value') is None, \
        "Failed to set the module value to None: %s" % sys_modules[module_path]
    assert module_path in sys_modules, "Failed to add the lazy module to the sys.modules dictionary: %s" % sys_modules

# Generated at 2022-06-26 02:28:24.247913
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:28:31.441093
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    def test_case_0():
        non_local_0 = NonLocal(bool_0)

    # test case 1
    make_lazy("")
    assert sys.modules[""].__mro__()[0] == LazyModule and sys.modules[""].__mro__()[1] == ModuleType

    # test case 2
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    def test_case_0():
        non_local_0 = NonLocal(bool_0)

    # test case 3
    bool_0 = True
    non_local_0 = NonLocal(bool_0)

# Generated at 2022-06-26 02:28:39.624970
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import time
    
    # lazy import should not work for a module in the path
    mod_path = 'lazy_import_test'
    assert(mod_path not in sys.modules)
    make_lazy('lazy_import_test')
    mod_path = 'lazy_import_test'
    assert(mod_path in sys.modules)
    
    import lazy_import_test
    
    # lazy import should only mark the module name, but not import it
    try:
        _ = lazy_import_test
    except:
        pass
    else:
        assert(False)

    # lazy module support test
    def func1():
        make_lazy('lazy_import_test')
        import lazy_import_test

        # lazy import should work for a module not in the path
       

# Generated at 2022-06-26 02:28:41.476307
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:28:46.135878
# Unit test for function make_lazy
def test_make_lazy():
    def _main():
        make_lazy("argparse")
        from argparse import ArgumentParser
        from types import ModuleType
        assert isinstance(sys.modules["argparse"], ModuleType)
        assert sys.modules["argparse"] != ArgumentParser
        ArgumentParser

        return 0


    _main()


# Generated at 2022-06-26 02:28:50.024598
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()



# Generated at 2022-06-26 02:28:52.710834
# Unit test for function make_lazy
def test_make_lazy():
    pass
#    lazy_module_path = "lazy_module_path"
#    make_lazy(lazy_module_path)



# Generated at 2022-06-26 02:29:04.586130
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import copy
    import os
    import types

    def test_module(module_name, path):
        """
        Test that a module that lives in the given path is lazy.
        """
        def test_regular_module(regular_module):
            # Make sure that the module loads and start with an empty module
            assert regular_module.__name__ == module_name
            assert len(regular_module.__dict__) == 0

            module_contents = {}

            # Import our module and store the contents
            exec("from {name} import *".format(name=regular_module.__name__), module_contents)

            # Pop out the special module name, as it is not included
            module_contents.pop("__name__")
            module_contents.pop("__doc__")

            # Make sure that

# Generated at 2022-06-26 02:29:14.206140
# Unit test for function make_lazy
def test_make_lazy():
    # We need to somehow put `sys.modules` into a NonLocal object context
    # As we cannot directly access `sys.modules` from other environments.
    def _make_lazy(module_path):
        make_lazy(module_path)

    module_1 = "twisted.internet.reactor"
    _make_lazy(module_1)
    bool_1 = True
    if sys.modules[module_1] is None:
        bool_1 = False
    assert bool_1

    module_2 = "twisted.internet.protocol"
    _make_lazy(module_2)
    bool_2 = True
    if sys.modules[module_2] is None:
        bool_2 = False
    assert bool_2

    module_3 = "twisted.internet.defer"
    _

# Generated at 2022-06-26 02:29:15.470932
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("test_case_0")



# Generated at 2022-06-26 02:29:24.989382
# Unit test for function make_lazy
def test_make_lazy():
    # Tests the scenario that makes sure an existing value is not overwritten.
    try:
        # Module 'copy' already exists.
        make_lazy('copy')
    except:
        pass
    else:
        raise AssertionError("Failed to raise exception at test #0")
    # Tests the scenario that makes sure the module is not loaded
    # until an attribute is needed off of it.
    try:
        # Module 'random' does not exists.
        make_lazy('random')
    except:
        pass
    else:
        raise AssertionError("Failed to raise exception at test #1")
    # Tests the scenario that makes sure the module is not loaded
    # when the attribute is not accessed.

# Generated at 2022-06-26 02:29:34.893868
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    module_path_0 = 'axiom.test.test_nonlocal.foo'
    non_local_0 = NonLocal(None)
    expected_0 = sys.modules
    sys_modules_0 = sys.modules
    make_lazy(module_path_0)

# Generated at 2022-06-26 02:29:43.368500
# Unit test for function make_lazy
def test_make_lazy():
    def test_0(module_path):
        bool_0 = True
        non_local_0 = NonLocal(bool_0)
        str_0 = 'abcdefghijklmnopqrstuvwxyz'
        bool_0 = (not (str_0 in module_path))
        non_local_0.value = bool_0
        if (non_local_0.value == bool_0):
            str_0 = 'abcdefghijklmnopqrstuvwxyz'
            bool_0 = (not (str_0 in module_path))
            non_local_0.value = bool_0
        else:
            str_0 = 'abcdefghijklmnopqrstuvwxyz'
            bool_0 = (not (str_0 in module_path))
            non_

# Generated at 2022-06-26 02:29:54.385070
# Unit test for function make_lazy
def test_make_lazy():
    # TODO: Implement test for function make_lazy
    pass
#
#     # Prepare for testing
#     import sys
#
#     # Set module name
#     module_name = 'temp_module'
#
#     # Save current value of the module
#     temp_module = sys.modules.get(module_name, None)
#
#     # Remove the module if it exists in sys.modules
#     if temp_module is not None:
#         del sys.modules[module_name]
#
#     # Call the function under test
#     make_lazy(module_name)
#
#     # Assert that it is loaded
#     assert module_name in sys.modules
#     assert isinstance(sys.modules[module_name], _LazyModuleMarker)
#
#     # Assert that it

# Generated at 2022-06-26 02:29:56.354127
# Unit test for function make_lazy
def test_make_lazy():
    # Assert type of returned instance
    assert callable(make_lazy)


# Generated at 2022-06-26 02:30:11.261626
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)
    module_path = "e"

# Generated at 2022-06-26 02:30:19.705871
# Unit test for function make_lazy
def test_make_lazy():
    import json
    import os
    import jsonschema

    # Replace `jsonschema` with a lazy-loading version so that it
    # can be imported later.
    make_lazy('jsonschema')

    test_make_lazy.counter = 0

    def run_test():
        test_make_lazy.counter += 1

        local_dict_0 = locals()
        nonlocal_1 = NonLocal(local_dict_0)

        # print('Running test #{}'.format(test_make_lazy.counter))

        try:
            json.dumps(non_local_0, indent=2)
        except jsonschema.exceptions.SchemaError:
            # print('Error caught!')
            non_local_0 = 1
        except AttributeError:
            non_local_

# Generated at 2022-06-26 02:30:23.425243
# Unit test for function make_lazy
def test_make_lazy():
    def unit_test():
        non_local_0 = NonLocal(None)
        bool_0 = True
        if bool_0:
            non_local_0.value = 0;
        else:
            non_local_0.value = 1;

    unit_test()

# Generated at 2022-06-26 02:30:31.142138
# Unit test for function make_lazy
def test_make_lazy():
    #
    try:
        #
        import urllib.request
        #
        assert(urllib.request.urlopen(
            'http://www.python.org/').read().decode('utf-8') is not None)
        #
    except ImportError:
        #
        # Unittest in python 2.7
        #
        try:
            #
            import urllib2
            #
            assert(urllib2.urlopen(
                'http://www.python.org/').read().decode('utf-8') is not None)
            #
        except ImportError:
            #
            assert False, 'unable to download from the internet'
            #

    #
    import sys
    #
    sys.modules.pop('urllib')
    #


# Generated at 2022-06-26 02:30:35.835347
# Unit test for function make_lazy
def test_make_lazy():
    from tests import lib
    import sys
    module_path = 'tests.lib'
    assert  isinstance(lib, ModuleType)
    make_lazy(module_path)
    assert not isinstance(lib, ModuleType)
    assert isinstance(lib, _LazyModuleMarker)
    assert lib.a == 1
    assert  isinstance(lib, ModuleType)

# Generated at 2022-06-26 02:30:39.042458
# Unit test for function make_lazy
def test_make_lazy():
    assert(str(type(make_lazy('spacy'))).find('_LazyModuleMarker') != -1)
    assert(str(type(make_lazy('spacy'))).find('spacy'))



# Generated at 2022-06-26 02:30:49.286257
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = {}  # type: Dict[str, ModuleType]
    sys_modules["nltk.tokenize"] = {"word_tokenize": True}
    make_lazy("nltk.tokenize")
    # Test that module is lazy as expected
    assert not isinstance(sys_modules["nltk.tokenize"], ModuleType)
    assert isinstance(sys_modules["nltk.tokenize"], _LazyModuleMarker)
    # Test that lazy module throws appropriate error when module is requested
    try:
        sys_modules["nltk.tokenize"].word_tokenize("")
    except Exception as e:
        assert "No module named nltk" in str(e)
    sys_modules["nltk"] = True
    # Test that lazy module is actually a module when needed

# Generated at 2022-06-26 02:30:57.109415
# Unit test for function make_lazy
def test_make_lazy():
    _lazy_modules = sys.modules
    sys.modules = {}

    make_lazy('test')

    def check_types():
        if not isinstance(sys.modules['test'], _LazyModuleMarker):
            raise TypeError('expected LazyModule')

    check_types()

    if not isinstance(sys.modules['test'], ModuleType):
        raise TypeError('expected ModuleType')

    try:
        sys.modules['test'].some_attr
    except (AttributeError, KeyError, TypeError, NameError, ModuleNotFoundError):
        raise Exception('Unexpected error')

    sys.modules = _lazy_modules


# Generated at 2022-06-26 02:30:59.539810
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(__name__)



# Generated at 2022-06-26 02:31:08.682370
# Unit test for function make_lazy
def test_make_lazy():
    from os.path import join, dirname
    from sys import modules, getrefcount
    from types import ModuleType

    from os.path import join
    from sys import modules, getrefcount
    from types import ModuleType

    # store the parent module
    old_parent = modules.get("test_helpers")


# Generated at 2022-06-26 02:31:22.251602
# Unit test for function make_lazy
def test_make_lazy():
    # Check the default value of the function
    assert make_lazy('foo') is None

# Generated at 2022-06-26 02:31:24.507146
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    assert(not non_local_0.value)
    non_local_0.value = False
    assert(non_local_0.value)

test_make_lazy()

# Generated at 2022-06-26 02:31:29.898637
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import math
    except ImportError:
        return
    try:
        math.ceil()
    except:
        try:
            make_lazy("math")
            math.ceil()
        except:
            return False
        import math
        try:
            math.ceil()
        except:
            return False
        return True
    return False


# Generated at 2022-06-26 02:31:40.274664
# Unit test for function make_lazy
def test_make_lazy():
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))
    assert True == (make_lazy((0)))

# Generated at 2022-06-26 02:31:47.201984
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy("test.test_lazy_module.test_case_0")
    sys.modules["test.test_lazy_module.test_case_0"].__mro__()
    sys.modules["test.test_lazy_module.test_case_0"].__getattribute__("non_local_0")
    test_case_0()


# Generated at 2022-06-26 02:32:00.837093
# Unit test for function make_lazy
def test_make_lazy():
    import collections

    non_local_0 = NonLocal(None)
    sys_modules_0 = sys.modules
    non_local_1 = NonLocal(None)

    class class_0(object):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # return a tuple of the module, type, and object
            return (module_type_0, module_type_1, object)

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """
            if non_local_1.value is None:
                del sys_modules_0[module_path_0]
                non_local_

# Generated at 2022-06-26 02:32:03.311704
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_case_0()
    except NameError:
        pass
    else:
        assert False



# Generated at 2022-06-26 02:32:04.765870
# Unit test for function make_lazy
def test_make_lazy():
    unit_test.not_implemented()


# Generated at 2022-06-26 02:32:11.349530
# Unit test for function make_lazy
def test_make_lazy():
    print("Test of function make_lazy")
    bool_0 = True
    mod_name_0 = 'abc'
    module_path = mod_name_0
    make_lazy(module_path)
    bool_0 = hasattr(sys.modules[module_path], '__mro__')
    assert bool_0
    module_path = mod_name_0
    bool_0 = hasattr(sys.modules[module_path], '__mro__')
    assert bool_0


# Generated at 2022-06-26 02:32:14.285739
# Unit test for function make_lazy
def test_make_lazy():
    global sys_modules
    make_lazy("sys.modules")
    assert_equal(sys_modules, sys.modules)

if __name__ == "__main__":
    run_local_tests()

# Generated at 2022-06-26 02:32:42.836437
# Unit test for function make_lazy
def test_make_lazy():
    pass

# Generated at 2022-06-26 02:32:52.661673
# Unit test for function make_lazy
def test_make_lazy():
    import lazy_modules as lm

    bool_0 = True
    non_local_0 = NonLocal(bool_0)

    lm.make_lazy('lazy_modules.test_module')
    lazy_mod = sys.modules['lazy_modules.test_module']

    assert isinstance(lazy_mod, _LazyModuleMarker)
    assert not hasattr(lazy_mod, 'well_known_thing')

    assert lazy_mod.well_known_thing == 'hello world'
    assert isinstance(lazy_mod, _LazyModuleMarker)
    assert hasattr(lazy_mod, 'well_known_thing')

    assert lazy_mod.well_known_thing == 'hello world'
    assert lazy_mod.well_known_thing == 'hello world'


# Generated at 2022-06-26 02:32:54.609426
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_case_0')
    assert(bool_0 == NonLocal(bool_0).value)
    assert(True)

# Generated at 2022-06-26 02:33:05.281021
# Unit test for function make_lazy
def test_make_lazy():
    from miniflow import make_lazy
    def test_case_0():
        test_module_path = "test_module_path"
        sys_modules = sys.modules
        module_0 = ModuleType(test_module_path)
        module_0.attribute_0 = "attribute_0"
        sys_modules[test_module_path] = module_0
        make_lazy(test_module_path)
        assert(not isinstance(module_0, _LazyModuleMarker))
        assert(sys_modules["test_module_path"] is not module_0)
        assert(isinstance(sys_modules["test_module_path"], _LazyModuleMarker))
        module_1 = sys_modules["test_module_path"]
        module_2 = getattr(module_1, "attribute_0")

# Generated at 2022-06-26 02:33:14.508894
# Unit test for function make_lazy
def test_make_lazy():
    print("Inside test_make_lazy")
    sys_modules = sys.modules  # cache in the locals

    # store our 'instance' data in the closure.
    module = NonLocal("test")

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.

# Generated at 2022-06-26 02:33:17.213698
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    make_lazy(str_0)


# Generated at 2022-06-26 02:33:27.392402
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure importing works as normal
    import itertools
    assert isinstance(itertools, ModuleType)
    assert 'cycle' in itertools.__dict__

    # Make sure we can still import after marking a module as lazy
    sys.modules['itertools'] = None
    make_lazy('itertools')
    assert isinstance(itertools, _LazyModuleMarker)
    import itertools
    assert isinstance(itertools, ModuleType)
    assert 'cycle' in itertools.__dict__

# Generated at 2022-06-26 02:33:34.205649
# Unit test for function make_lazy
def test_make_lazy():
    # Set up the module path and load the module
    module_path = 'test.test_util'
    my_module = __import__(module_path)

    # Verify that the module has the expected name
    assert my_module.__name__ == 'test.test_util'

    # Verify that we are not yet a lazy module
    assert not isinstance(my_module, _LazyModuleMarker)

    # Make the module lazy
    make_lazy(module_path)

    # Verify that we are now a lazy module
    assert isinstance(my_module, _LazyModuleMarker)

    # Verify that we are still the same module
    assert sys.modules[module_path] is my_module

    # Try to access a known attribute to force import
    assert my_module.test_case_0 is test_case_0

# Generated at 2022-06-26 02:33:42.882254
# Unit test for function make_lazy
def test_make_lazy():
    # Test module sys
    imported_modules = [False]
    def test_module_0(module_path):
        try:
            make_lazy(module_path)
        except ImportError:
            imported_modules[0] = True
        assert(imported_modules[0])
        imported_modules[0] = False

    def test_module_1(module_path):
        try:
            make_lazy(module_path)
        except ImportError:
            imported_modules[0] = True
        assert(imported_modules[0])
        imported_modules[0] = False

    def test_module_2(module_path):
        try:
            make_lazy(module_path)
        except ImportError:
            imported_modules[0] = True
        assert(imported_modules[0])

# Generated at 2022-06-26 02:33:47.284019
# Unit test for function make_lazy
def test_make_lazy():
    from pylibs import lazy_module
    lazy_module.make_lazy('pylibs.lazy_module')

    import pylibs.lazy_module
    assert isinstance(pylibs.lazy_module, lazy_module._LazyModuleMarker)


# Generated at 2022-06-26 02:34:49.052141
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()



# Generated at 2022-06-26 02:34:58.001032
# Unit test for function make_lazy
def test_make_lazy():
    module = NonLocal(None)
    sys_modules = sys.modules

    def tester(module_path):
        sys_modules[module_path] = module
        make_lazy(module_path)

        # Verify that we replaced the module with a LazyModule
        assert isinstance(sys_modules[module_path], _LazyModuleMarker)

        # Use it
        sys_modules[module_path].test

        # Verify that it was replaced with the real module
        assert sys_modules[module_path] is module

    module_path = 't_tests.tests.test_lazy'
    tester(module_path)

    module_path = 't_tests.tests.test_lazy.foo'
    tester(module_path)


if __name__ == '__main__':
    test_case

# Generated at 2022-06-26 02:35:01.599118
# Unit test for function make_lazy
def test_make_lazy():
    assert 'make_lazy' in globals()  # function exists
    assert '_LazyModuleMarker' in globals()  # marker class exists

    module_path = 'foo'

    # Assert that the module does not exist.
    assert module_path not in sys.modules

    make_lazy(module_path)

  

# Generated at 2022-06-26 02:35:03.718284
# Unit test for function make_lazy
def test_make_lazy():
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    make_lazy(str())

# Generated at 2022-06-26 02:35:05.102564
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_case_1')
    import test_case_1


# Generated at 2022-06-26 02:35:16.621829
# Unit test for function make_lazy
def test_make_lazy():
    # Generate inputs
    module_path_0 = 'test'
    module_path_1 = 'test1'
    module_path_2 = 'test2'
    module_path_3 = 'test3'

    # Setup
    module = sys.modules[__name__]
    del sys.modules[__name__]

    test_non_lazy = NonLocal(None)

    class Test_Non_Lazy(_LazyModuleMarker):
        def __mro__(self):
            return (Test_Non_Lazy, ModuleType)

        def __getattribute__(self, attr):
            if test_non_lazy.value is None:
                del sys.modules[__name__]
                test_non_lazy.value = __import__(__name__)

# Generated at 2022-06-26 02:35:17.833289
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:35:24.826505
# Unit test for function make_lazy
def test_make_lazy():
    # Test with a non-corner-case
    make_lazy("py_test")
    import py_test
    assert py_test.__name__ == "py_test"
    bool_0 = True
    non_local_0 = NonLocal(bool_0)
    real_module = sys.modules["py_test"]
    bool_0 = isinstance(py_test, _LazyModuleMarker)
    non_local_0 = NonLocal(bool_0)
    bool_0 = not bool_0
    non_local_0 = NonLocal(bool_0)
    bool_0 = isinstance(real_module, _LazyModuleMarker)
    non_local_0 = NonLocal(bool_0)
    bool_0 = not bool_0

# Generated at 2022-06-26 02:35:27.888723
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('runtests')


# Generated at 2022-06-26 02:35:36.690306
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    module_path_0 = '_lazy_module'
    non_local_0 = NonLocal(None)
    module_0 = None
    mod = NonLocal(None)
    class LazyModule(ModuleType):
        __mro__ = (LazyModule, ModuleType)
        def __getattribute__(self, attr):
            if mod.value is None:
                del sys.modules[module_path_0]
                mod.value = __import__(module_path_0)
                sys.modules[module_path_0] = __import__(module_path_0)
            return getattr(mod.value, attr)
    if module_0 is None:
        sys.modules[module_path_0] = LazyModule()
    # Setup