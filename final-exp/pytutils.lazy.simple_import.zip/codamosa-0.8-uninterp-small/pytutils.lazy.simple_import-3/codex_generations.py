

# Generated at 2022-06-26 02:25:57.157011
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()




# Generated at 2022-06-26 02:26:06.301506
# Unit test for function make_lazy
def test_make_lazy():
    import os

    with utils.TempDir() as temp_dir:
        module_path = 'a'
        name, ext = os.path.splitext(module_path)
        file_name = os.path.join(temp_dir, name+'.py')

        with open(file_name, 'w') as f:
            f.write(u'foo = 1')

        make_lazy(module_path)

        # get the module registered with sys.modules
        mod = sys.modules[module_path]

        assert isinstance(mod, _LazyModuleMarker)
        assert mod.foo == 1



# Generated at 2022-06-26 02:26:12.571636
# Unit test for function make_lazy
def test_make_lazy():
    from .context.desktop_win7_x86_64.win7_x86_64_warcraft3_frozen_throne.lib_build.win7_x86_64_warcraft3_frozen_throne.lib_build import (
        _LazyModuleMarker
    )
    import sys
    make_lazy('lib_build')
    assert sys.modules['lib_build'].__class__.__mro__() == (
        _LazyModuleMarker,
        ModuleType
    ), "make_lazy failed to provide a suitable class for sys.modules['lib_build']"

# Generated at 2022-06-26 02:26:23.304486
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy
    """
    make_lazy("urllib.request")
    # On Python 2, this module is actually named urllib.
    urllib = sys.modules["urllib.request"]
    # Check that the module is marked as lazy.
    assert isinstance(urllib, _LazyModuleMarker)
    # Check that the module is usable.
    urllib.urlopen("https://www.example.org")
    # Check that the module is still marked as lazy.
    assert isinstance(urllib, _LazyModuleMarker)
    # Check that the module is still usable.
    urllib.urlopen("https://www.example.org")


if __name__ == "__main__":
    test_make_lazy()
    print("Test passed")

# Generated at 2022-06-26 02:26:24.891926
# Unit test for function make_lazy
def test_make_lazy():
    import re
    make_lazy('re')
    from re import compile


# Generated at 2022-06-26 02:26:33.302743
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    module_path = 'nested_module'
    make_lazy(module_path)

    assert(sys_modules[module_path] is not None)
    assert(sys_modules[module_path].__class__.__name__ == 'LazyModule')
    assert(sys_modules[module_path].__module__ == '__main__')
    assert(sys_modules[module_path].__class__.__module__ == '__main__')

    print('Test "make_lazy" - ok')


# Generated at 2022-06-26 02:26:35.618034
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('string')
    assert(isinstance(sys.modules['string'], _LazyModuleMarker))
    assert(not isinstance(sys.modules['string'], string))



# Generated at 2022-06-26 02:26:47.681011
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    # Ensure the module isn't loaded before the test.
    assert 'test_lazy_module' not in sys.modules
    make_lazy('test_lazy_module')
    assert sys.modules['test_lazy_module']
    # Ensure that `test_lazy_module` is a `ModuleType` instance.
    assert isinstance(sys.modules['test_lazy_module'], ModuleType)
    # Ensure that `test_lazy_module` is a standin for a lazy module.
    assert isinstance(sys.modules['test_lazy_module'], _LazyModuleMarker)
    # Ensure that `test_lazy_module` is a `ModuleType` instance
    # or a standin for a lazy module.

# Generated at 2022-06-26 02:26:56.095523
# Unit test for function make_lazy
def test_make_lazy():
    import pkgutil
    import nose.tools
    def test_make_lazy_use_case_0():
        # Testing non-import vs. import uses
        import os.path
        make_lazy('os.path')
        nose.tools.assert_true(isinstance(os.path, _LazyModuleMarker))
        nose.tools.assert_equal(os.path.dirname('foo'), '.')
        nose.tools.assert_true(isinstance(os.path, ModuleType))
        nose.tools.assert_false(isinstance(os.path, _LazyModuleMarker))

    def test_make_lazy_use_case_1():
        # Testing meta module viz `os`
        import os
        make_lazy('os')  # No error, though no obvious benefit.
        nose.tools

# Generated at 2022-06-26 02:27:05.623281
# Unit test for function make_lazy
def test_make_lazy():
    # use __import__ to get a module.
    module = __import__('test_lazy')

    # a module should not be a _LazyModuleMarker
    assert not isinstance(module, _LazyModuleMarker)

    # now mark it as lazy.
    make_lazy('test_lazy')

    # it should now be a lazy module
    assert isinstance(module, _LazyModuleMarker)

    # now try to access an attribute off of it.
    module.test_case_0()

    # it should now be the real value and not the lazy version.
    assert not isinstance(module, _LazyModuleMarker)



# Generated at 2022-06-26 02:27:11.424878
# Unit test for function make_lazy
def test_make_lazy():
    # foo is not imported, and this should not raise an error
    make_lazy('foo')
    assert True


# Generated at 2022-06-26 02:27:21.483166
# Unit test for function make_lazy
def test_make_lazy():
    from os import path, name
    from tempfile import mkdtemp

    prefix = path.join(
        path.abspath(path.dirname(__file__)), 'test_make_lazy_')
    dirname = mkdtemp(prefix=prefix)

    # Write out a simple module.
    with open(path.join(dirname, 'test0.py'), 'w') as fp:
        fp.write('foo = 42\n')


# Generated at 2022-06-26 02:27:24.506656
# Unit test for function make_lazy
def test_make_lazy():
    global sys_modules
    test_case_0()
    assert(sys_modules['_LazyModuleMarker'])
    assert(sys_modules['__getattribute__'])
    assert(sys_modules['__mro__'])
    assert(sys_modules['__mro__'])
    assert(sys_modules['attr'])



if __name__=="__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:27:29.310540
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('sys')
    except:
        return False
    if not isinstance(sys, _LazyModuleMarker):
        return False
    try:
        if not isinstance(sys, ModuleType):
            return False
    except:
        return False
    if not sys.stdin:
        return False
    if not sys._getframe:
        return False
    return True



# Generated at 2022-06-26 02:27:31.550396
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_case_0'
    make_lazy(module_path)
    assert sys.modules[module_path]() is None

# Generated at 2022-06-26 02:27:42.198725
# Unit test for function make_lazy
def test_make_lazy():
    # Lazy module without __mro__
    make_lazy('test.test_lazy_module')
    import test.test_lazy_module
    assert(isinstance(test.test_lazy_module, _LazyModuleMarker))
    assert(not hasattr(test.test_lazy_module, '__mro__'))
    assert(not hasattr(test.test_lazy_module, 'lazy_module_marker_0'))
    assert(hasattr(test, 'test_lazy_module'))

    # Lazy module with __mro__
    make_lazy('test.test_lazy_module_with_mro')
    import test.test_lazy_module_with_mro

# Generated at 2022-06-26 02:27:49.992759
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules
    module_path = 'test_module'

    # Make sure we're starting from scratch
    if module_path in modules:
        del modules[module_path]

    make_lazy(module_path)
    assert module_path not in modules
    lazy_module = modules[module_path]

    # Make sure the object we get back is _LazyModuleMarker
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert lazy_module.__class__.__mro__ == (lazy_module.__class__, ModuleType)

    # Make sure the lazy module actually works
    test_case_0()

    # Now we have to reload the module because it was modified
    reload(lazy_module)

# Generated at 2022-06-26 02:27:54.398094
# Unit test for function make_lazy
def test_make_lazy():
    # The name of the module is '<string>', so it will not cause any side
    # effects.
    module_path = 'import this'
    make_lazy(module_path)
    assert module_path in sys.modules.keys()


# Generated at 2022-06-26 02:28:04.846626
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker = _LazyModuleMarker()
    mock_sys_modules = {'foo': lazy_module_marker}

    original_sys_modules = sys.modules
    sys.modules = mock_sys_modules

    import foo

    make_lazy('foo')

    assert sys.modules['foo'] is lazy_module_marker
    assert isinstance(sys.modules['foo'], lazy_module_marker)

    # make sure we can still `import foo`
    assert foo is lazy_module_marker

    assert '__mro__' in dir(sys.modules['foo'])
    assert '__getattribute__' in dir(sys.modules['foo'])

    # make sure the module is still lazy
    assert isinstance(sys.modules['foo'], lazy_module_marker)

    #

# Generated at 2022-06-26 02:28:12.620537
# Unit test for function make_lazy
def test_make_lazy():
    class NullModule(object):
        def __init__(self, name): self.name = name
        def __repr__(self): return self.name
        def __getattr__(self, attr): return '%s.%s' % (self.name, attr)

    def make_new_module_name():
        make_new_module_name.i += 1
        return 'new_module_' + str(make_new_module_name.i)
    make_new_module_name.i = 0

    def check_import(name, path, attr):
        s = sys.modules.copy()
        make_lazy(path)
        m = __import__(name)
        assert m.__name__ == name, 'make_lazy did not set __name__ correctly'
        assert m.__

# Generated at 2022-06-26 02:28:24.198816
# Unit test for function make_lazy
def test_make_lazy():
    # Check that make_lazy will actually make a module lazy
    f = tempfile.NamedTemporaryFile()
    f.write(dedent('''
        def foo(x):
            return x + 1
    '''))
    f.flush()

    make_lazy(f.name)


# Generated at 2022-06-26 02:28:29.224972
# Unit test for function make_lazy
def test_make_lazy():

    def test_case_0():
        module_name = "module_name"
        module_path = "non_existing_module.module_name"
        make_lazy(module_path)
        assert(module_name not in sys.modules.keys())
        assert(module_path not in sys.modules.keys())

    #import
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:28:31.888652
# Unit test for function make_lazy
def test_make_lazy():
    # Test default case
    make_lazy(0)
    make_lazy(test_case_0)

# Generated at 2022-06-26 02:28:41.852539
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_0 = _LazyModuleMarker()
    sys_modules_0 = sys.modules
    module_path_0 = 'pypy_test_make_lazy'
    lazy_module_marker_1 = _LazyModuleMarker()
    sys_modules_1 = sys.modules
    module_path_1 = 'pypy_test_make_lazy'
    lazy_module_marker_2 = _LazyModuleMarker()
    sys_modules_2 = sys.modules
    module_path_2 = 'pypy_test_make_lazy'
    lazy_module_marker_3 = _LazyModuleMarker()
    sys_modules_3 = sys.modules
    module_path_3 = 'pypy_test_make_lazy'
    lazy_

# Generated at 2022-06-26 02:28:46.949685
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('sys')
        make_lazy('os')
        assert sys.modules['sys'] is sys.modules['os']
        del sys.modules['os']
        assert sys.modules['sys'] is sys.modules['os']
    finally:
        del sys.modules['sys']


# Generated at 2022-06-26 02:28:55.064833
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import lazy_module_marker
    module_path = 'lazy_module_marker'

    # Check that the module is not in sys.modules.
    assert module_path not in sys.modules

    # Check that we can get the module from sys.modules
    # after we 'make_lazy' it.
    make_lazy(module_path)
    lazy_mod = sys.modules[module_path]

    assert lazy_mod.__name__ == 'lazy_module_marker'

    # Mark that this module should not be imported until an
    # attribute is needed off of it.
    # Check that the ``_LazyModuleMarker`` type is returned.
    assert isinstance(lazy_mod, _LazyModuleMarker)

    # Check that the module is in sys.modules.

# Generated at 2022-06-26 02:29:06.557578
# Unit test for function make_lazy
def test_make_lazy():
    # we do some wacky stuff here:
    # 1) we don't import the name (it will import itself the first time)
    # 2) we store the imported module in a local copy of sys.modules
    # 3) we capture the local copy of sys.modules in the closure of
    #    the inner function, so we can use it without a global
    import sys
    import types

    cache = {}

    def get_module(module_name):
        if module_name not in cache:
            # import the module
            __import__(module_name)
            # save the module to the cache so we can use it
            cache[module_name] = sys.modules[module_name]

        return cache[module_name]

    # we'll use this module to import ourselves.
    make_lazy('make_lazy')

    #

# Generated at 2022-06-26 02:29:09.080124
# Unit test for function make_lazy
def test_make_lazy():
    print('Test: make_lazy')
    test_case_0()

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:29:16.322015
# Unit test for function make_lazy
def test_make_lazy():
    print("FUNCTION: test_make_lazy")

    # Reset sys.modules
    sys.modules = {}

    make_lazy("lazily_imported_module")

    assert "lazily_imported_module" in sys.modules

    assert isinstance(sys.modules["lazily_imported_module"], _LazyModuleMarker)

    assert not hasattr(sys.modules["lazily_imported_module"], "__dict__")

    assert not hasattr(sys.modules["lazily_imported_module"], "__mro__")

    assert sys.modules["lazily_imported_module"] != None



# Generated at 2022-06-26 02:29:26.076860
# Unit test for function make_lazy
def test_make_lazy():
    from os import path
    from sys import modules

    module_path = 'sys'
    assert module_path in modules

    module = __import__(module_path)

    make_lazy(module_path)

    assert module is not modules[module_path]

    assert isinstance(modules[module_path], _LazyModuleMarker)

    assert module is modules[module_path]

    assert module is modules[module_path]

    make_lazy(module_path)

    assert module is modules[module_path]

    module_path = path.join('os', 'path')
    assert module_path not in modules

    make_lazy(module_path)

    assert module_path in modules

    assert isinstance(modules[module_path], _LazyModuleMarker)


# Generated at 2022-06-26 02:29:35.349878
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import shutil

    # Create a temp test package, package will be deleted after test.
    dirname = os.path.dirname(os.path.abspath(__file__))
    temp_dir = os.path.join(dirname, 'temp')
    if os.path.isdir(temp_dir):
        shutil.rmtree(temp_dir, ignore_errors=True)
    os.makedirs(temp_dir, exist_ok=True)

    test_file = os.path.join(temp_dir, '__init__.py')
    with open(test_file, 'w') as f:
        f.write('import sys\n')
        f.write('print ("importing test_package")\n')
    # Add temp_dir to sys path.


# Generated at 2022-06-26 02:29:40.010119
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_1 = _LazyModuleMarker()
    make_lazy("lazy_module_marker_1")
    assert(isinstance(lazy_module_marker_1, _LazyModuleMarker))
    print(lazy_module_marker_1.__dict__)

# tests to verify make_lazy correctly loads modules

# Generated at 2022-06-26 02:29:46.147809
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure
    test_case_0()

    assert not isinstance(sys.modules[__name__], _LazyModuleMarker)

    make_lazy("segpy")
    print(sys.modules['segpy'])
    assert isinstance(sys.modules['segpy'], _LazyModuleMarker)

    # make sure __getattribute__ is called when trying to access the module
    assert isinstance(sys.modules['segpy'].TraceHeaderRev3, type)
    assert isinstance(sys.modules['segpy'], _LazyModuleMarker)
    # make sure we don't do redundant calls to __getattribute__
    assert isinstance(sys.modules['segpy'].TraceHeaderRev1, type)

    # make sure the module isn't lazy anymore.
    assert not isinstance

# Generated at 2022-06-26 02:29:55.403622
# Unit test for function make_lazy
def test_make_lazy():
    print('test_make_lazy')

    def test_case_1():
        pass

    def test_case_2():
        # Since 'foo.bar' is lazy, foo should not have been imported.
        print(sys.modules['foo'])
        assert sys.modules['foo'] is None

        # Now that foo is need, it should be imported and sys.modules should be updated.
        print(foo.bar)
        assert sys.modules['foo'] is not None

    make_lazy('foo.bar')
    test_case_1()
    test_case_2()

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:30:04.673664
# Unit test for function make_lazy
def test_make_lazy():

    # a set of module names to be made lazy
    modules = ['sys', 'os', 'threading', 'socket', 'getpass', 'instructor_tools']

    # make all modules lazy
    for mod in modules:
        make_lazy(mod)

    assert isinstance(sys, _LazyModuleMarker)
    assert isinstance(os, _LazyModuleMarker)
    assert isinstance(threading, _LazyModuleMarker)
    assert isinstance(socket, _LazyModuleMarker)
    assert isinstance(getpass, _LazyModuleMarker)
    assert isinstance(instructor_tools, _LazyModuleMarker)



# Generated at 2022-06-26 02:30:11.977521
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure NoneType is not the same as _LazyModuleMarker.
    assert not(type(None) is type(_LazyModuleMarker()))

    # Since we haven't called any functions, the module should be a
    # NonLocal object, not a real module loaded with `import`.
    assert isinstance(sys.modules['make_lazy'], NonLocal)

    # After calling, we should have a real module of type ModuleType.
    # The point is that we don't want `import make_lazy` to fail because
    # it's a function that is called in a loop.
    make_lazy('make_lazy')
    assert isinstance(sys.modules['make_lazy'], ModuleType)

    # Since we have a real module, calling make_lazy on it again
    # should do nothing (not overwrite)

# Generated at 2022-06-26 02:30:16.024013
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(TestModule)
    isinstance(TestModule, _LazyModuleMarker) # Expected True
    isinstance(TestModule, ModuleType)        # Expected True
    isinstance(TestModule, object)            # Expected True
    isinstance(TestModule, _LazyModuleMarker) # Expected True


# Test Module to be lazy-imported

# Generated at 2022-06-26 02:30:20.726334
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import syslog
    assert(syslog not in sys.modules)
    make_lazy('syslog')
    assert(sys.modules['syslog'])
    assert(isinstance(sys.modules['syslog'], _LazyModuleMarker))
    assert(syslog not in sys.modules)
    import syslog
    assert(sys.modules['syslog'])
    assert(syslog in sys.modules)


test_make_lazy()

# Generated at 2022-06-26 02:30:29.586360
# Unit test for function make_lazy

# Generated at 2022-06-26 02:30:39.759973
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import re
    import types

    # - check that make_lazy(module_path) function exists
    assert callable(make_lazy) is True

    # - check that make_lazy(module_path) function returns nothing
    assert make_lazy('') is None

    if 'test_case_1' in sys.modules:
        del sys.modules['test_case_1']

    # - check that sys.modules does not contain key 'test_case_1'
    assert 'test_case_1' not in sys.modules

    # - check that sys.modules['test_case_1'] is a LazyModule
    make_lazy('test_case_1')
    assert str(type(sys.modules['test_case_1'])) == "<class '__main__.LazyModule'>"

# Generated at 2022-06-26 02:30:50.499434
# Unit test for function make_lazy
def test_make_lazy():
    import types
    module_0 = types.ModuleType('test_module')
    make_lazy('test_module')
    test_case_0()
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    assert not isinstance(sys.modules['test_module'], types.ModuleType)

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:30:54.014744
# Unit test for function make_lazy
def test_make_lazy():
    float_0 = -2665.144
    non_local_0 = NonLocal(float_0)
    assert_equals(non_local_0.value, float_0)

test_make_lazy()
print('finished test_make_lazy')

# Generated at 2022-06-26 02:31:05.786290
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    test_make_lazy.total_points += 1

test_make_lazy.total_points = 0
if __name__ == '__main__':
    def total_points():
        return test_make_lazy.total_points
    import sys
    if len(sys.argv) == 2:
        import imp
        import runpy
        input_name = sys.argv[1]
        module_name = 'test_cases.' + os.path.splitext(input_name)[0]
        module = imp.load_source(module_name, input_name)
        runpy.run_module(module_name)
        print(total_points())
    else:
        print('Usage: %s test_case_x.py' % sys.argv[0])


# Generated at 2022-06-26 02:31:16.104759
# Unit test for function make_lazy
def test_make_lazy():
    count_0 = 0
    if 1:
        def non_local_0():
            non_local_1 = NonLocal(non_local_1)
            non_local_2 = NonLocal(non_local_2)
            non_local_3 = NonLocal(non_local_3)
            non_local_4 = NonLocal(non_local_4)
            non_local_5 = NonLocal(non_local_5)
            non_local_6 = NonLocal(non_local_6)
            def non_local_7():
                non_local_8 = NonLocal(non_local_8)
                non_local_9 = NonLocal(non_local_9)
                non_local_10 = NonLocal(non_local_10)
                non_local_11 = NonLocal(non_local_11)

# Generated at 2022-06-26 02:31:25.880982
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(0)
    float_0 = 0.464
    nonlocal_arg_0 = NonLocal(float_0)

    def test_function_0(str_arg_0, *args):
        return test_function_0(str_arg_0, *args)
        return

    def test_function_0(str_arg_0):
        nonlocal nonlocal_arg_0
        bool_0 = str_arg_0 != '1'
        if bool_0:
            return str_arg_0

        nonlocal_arg_0.value = 2.0
        return nonlocal_arg_0.value

    make_lazy(test_function_0)

    True
    str_arg_0 = '1'

# Generated at 2022-06-26 02:31:29.209203
# Unit test for function make_lazy

# Generated at 2022-06-26 02:31:30.816713
# Unit test for function make_lazy
def test_make_lazy():
    module_path = None

    make_lazy(module_path)


# Generated at 2022-06-26 02:31:40.347868
# Unit test for function make_lazy
def test_make_lazy():
    # print(sun.sun.sun_rise_set('-79.3832', '43.6532'))
    sun.sun.__getattribute__('sun_rise_set')
    # print(sun.sun.sun_rise_set('-79.3832', '43.6532'))
    # print(sun.sun.sun_rise_set('-79.3832', '43.6532'))
    # make_lazy('sun.sun.sun_rise_set')
    # print(sun.sun.sun_rise_set('-79.3832', '43.6532'))
    # print(sun.sun.sun_rise_set('-79.3832', '43.6532'))


# Generated at 2022-06-26 02:31:48.194307
# Unit test for function make_lazy
def test_make_lazy():
    # test1
    make_lazy('some_path')
    # test2
    make_lazy(None)
    # test3
    make_lazy('test_case_0')
    # test4
    make_lazy(test_case_0)
    # test5
    make_lazy(test_make_lazy)


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:31:52.752727
# Unit test for function make_lazy
def test_make_lazy():
    print("\033[30;48;5;82m")
    test_case_0()
    print("\033[0m")

# Generated at 2022-06-26 02:32:05.721150
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 02:32:15.271461
# Unit test for function make_lazy
def test_make_lazy():
    # We need a global variable to put the result of __import__ in.
    global test_case_0
    # NonLocal does nothing here, we just need a function that can take a
    # nonlocal argument.
    test_make_lazy.__slots__ = ['test_case_0']
    # We need a module with a name that we can use as the module path for
    # __import__.
    test_case_0 = NonLocal(None)
    assert isinstance(test_make_lazy, ModuleType)

    test_make_lazy.__slots__ = ['test_make_lazy']
    make_lazy('test_make_lazy')
    # Nothing should have been imported yet
    assert test_make_lazy.__slots__ is None

    # Now we import our test module

# Generated at 2022-06-26 02:32:25.978348
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = 'case_0.py'
    make_lazy(module_path_0)
    assert(module_path_0 in sys.modules)
    assert(isinstance(sys.modules[module_path_0], _LazyModuleMarker))
    case_0_module = sys.modules[module_path_0]
    assert(isinstance(case_0_module, _LazyModuleMarker))
    assert(non_local_0 not in dir(case_0_module))
    non_local_0_value = case_0_module.non_local_0.value
    assert(non_local_0_value == float_0)
    assert(non_local_0 in dir(case_0_module))
    assert(isinstance(sys.modules[module_path_0], ModuleType))

# Generated at 2022-06-26 02:32:32.078219
# Unit test for function make_lazy
def test_make_lazy():
    # Testing code...
    float_0 = -9099.813
    test_case_0()
    int_0 = 0
    float_1 = float_0
    # Make sure that the NonLocal object is set correctly
    assert non_local_0.value == float(float_1)

    for i in range(0, 3):
        float_1 = (float_1 * float_1)
        if (int_0 < 400):
            int_0 = (int_0 + 1)

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:32:42.821151
# Unit test for function make_lazy
def test_make_lazy():
    # We are in lazy module
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()

    # Lazy module value
    non_local_0 = NonLocal(float_1)
    non_local_1 = NonLocal(float_2)
    non_local_2 = NonLocal(float_3)
    non_local_3 = NonLocal(float_4)
    non_local_4 = NonLocal(float_5)
    non_local_5 = NonLocal(float_6)
    non_local_6

# Generated at 2022-06-26 02:32:45.426986
# Unit test for function make_lazy
def test_make_lazy():
    global float_0
    global non_local_0

    test_case_0()
    assert float_0 == non_local_0.value

# Generated at 2022-06-26 02:32:53.357146
# Unit test for function make_lazy
def test_make_lazy():
    # Create a python module dynamically
    import imp
    module_name = "mymodule"
    fp = open('mymodule.py', 'w')
    try:
        fp.write('print "hello from mymodule"')
    finally:
        fp.close()
    test_make_lazy_0 = imp.load_source(module_name, 'mymodule.py')
    non_local_0 = NonLocal(test_make_lazy_0)
    make_lazy(module_name)

    # Check that mymodule is not in sys.modules
    if (module_name in sys.modules.keys()):
        raise AssertionError('make_lazy failed')


# Generated at 2022-06-26 02:32:59.292754
# Unit test for function make_lazy
def test_make_lazy():
    float_0 = -2665.144
    non_local_0 = NonLocal(float_0)
    float_0 = float_0 # Compiler could not infer type of float_0
    float_0_ = non_local_0.value
    float_1 = float_0_
    float_1 = float_1 # Compiler could not infer type of float_1
    non_local_0.value = float_1
    test_case_0()
    test_case_0()



# Generated at 2022-06-26 02:33:00.205004
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()



# Generated at 2022-06-26 02:33:02.851156
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:33:32.000403
# Unit test for function make_lazy
def test_make_lazy():
    start = time.time() * 1000
    non_local_0 = NonLocal(None)
    while True:
        test_case_0()
        if time.time() * 1000 - start >= 1000:
            break
    non_local_1 = NonLocal(None)
    non_local_2 = NonLocal(None)
    for i in xrange(0, 10000):
        locals = {"module_path": "os"}

# Generated at 2022-06-26 02:33:33.947325
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 02:33:41.203606
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = make_lazy('test_case_0')
    string_1 = sys.modules['test_case_0'].__name__
    str_1 = 'test_case_0'
    assert(str_1 == string_1)
    non_local_0 = sys.modules['test_case_0'].non_local_0
    float_0 = non_local_0.value
    float_1 = -2665.144
    assert(abs(float_0 - float_1) < DELTA)
    sys.modules = {}

# Generated at 2022-06-26 02:33:51.795095
# Unit test for function make_lazy
def test_make_lazy():
    print("Testing 'make_lazy' ...")
    class lazy_module:
        """
        A standin for a module to prevent it from being imported
        """
        def __init__(self, module_path):
            self.module_path = module_path
            self.is_imported = False

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """
            if self.is_imported is False:
                self.is_imported = True

            return getattr(self, attr)

    sys_modules = sys.modules
    sys_modules["lazy_module"] = lazy_module("lazy_module")
    sys_modules["lazy_module.x"] = lazy_module("lazy_module.x")

    check_module

# Generated at 2022-06-26 02:34:04.070259
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = NonLocal(None)
    var_1 = NonLocal(None)
    var_2 = systelems()
    assert_equal(var_2.parse("((a))"), var_2.parens("(a)"))
    var_2.parse("((a))")
    var_2.parens("(a)")
    var_3 = NonLocal(None)
    assert_equal(var_2.parens("(a)"), var_2.parens("(a)"))
    var_2.parens("(a)")
    var_3 = NonLocal(None)
    assert_equal(var_2.parens("(a)"), var_2.parens("(a)"))
    var_2.parens("(a)")
    var_3 = NonLocal(None)


# Generated at 2022-06-26 02:34:14.326503
# Unit test for function make_lazy
def test_make_lazy():
    # Test for correct behavior of function make_lazy
    non_local_0 = NonLocal(None)
    assert_equal(sys.modules.has_key(non_local_0), False)
    make_lazy(non_local_0)
    assert_equal(sys.modules.has_key(non_local_0), True)
    non_local_0 = NonLocal(0.0)
    assert_equal(sys.modules.has_key(non_local_0), True)
    make_lazy(non_local_0)
    assert_equal(sys.modules.has_key(non_local_0), True)
    non_local_0 = NonLocal(0)
    assert_equal(sys.modules.has_key(non_local_0), True)

# Generated at 2022-06-26 02:34:15.165310
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("")


# Generated at 2022-06-26 02:34:16.015503
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('test_make_lazy')
    except:
        assert False, "could not make lazy"


# Generated at 2022-06-26 02:34:17.256838
# Unit test for function make_lazy
def test_make_lazy():
    # Tests for `make_lazy`
    print("Test make_lazy start")

    test_case_0()
    print("Test make_lazy stop")


# Generated at 2022-06-26 02:34:19.344437
# Unit test for function make_lazy
def test_make_lazy():
    # Testing the values assigned to non_local_0
    float_0 = -2665.144
    test_case_0()
    assert float_0 == non_local_0.value

test_make_lazy()

# Generated at 2022-06-26 02:35:01.018627
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_make_lazy_data.make_lazy_data.test_case_0')
    from test_make_lazy_data import test_case_0
    test_case_0()

# Generated at 2022-06-26 02:35:03.302918
# Unit test for function make_lazy
def test_make_lazy():
    assert None is test_case_0()
    assert None is test_make_lazy()

# Generated at 2022-06-26 02:35:06.362327
# Unit test for function make_lazy
def test_make_lazy():
    float_2 = 3.644567694e-14
    non_local_1 = NonLocal(float_2)
    float_1 = 1.0438e+07
    non_local_0 = NonLocal(float_1)


# Generated at 2022-06-26 02:35:08.585669
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:35:12.534497
# Unit test for function make_lazy
def test_make_lazy():
    from test_support import run_unittest

    try:
        make_lazy(__name__)
        assert False
    except ValueError:
        pass
    else:
        assert False


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:35:16.225909
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

    # BEGIN TESTS
    #
    # import os
    # make_lazy('os')
    # print os.path.abspath('.')
    #
    # END TESTS


test_make_lazy()

# Generated at 2022-06-26 02:35:21.590252
# Unit test for function make_lazy
def test_make_lazy():

    def function_0():
        int_0 = 0
        int_1 = 0
        int_0 = random.randint(0, 100)
        int_1 = random.randint(0, 100)
        float_0 = 0.0
        float_0 = (int_1 / int_0)
        non_local_0 = NonLocal(float_0)
        make_lazy(sys.modules)

    function_0()



# Generated at 2022-06-26 02:35:30.297379
# Unit test for function make_lazy
def test_make_lazy():
    # test 0
    float_0 = -2665.144
    non_local_0 = NonLocal(float_0)
    assert isinstance(non_local_0, NonLocal)
    assert non_local_0.value == float_0
    test_case_0()
    assert non_local_0.value == float_0
    assert isinstance(non_local_0, NonLocal)
    # test 1
    # Note: @lru_cache not used as decorator here
    # Note: get_total_time is not a function, but a method of a class
    from os.path import exists, join, basename
    from functools import lru_cache
    from os import getcwd, chdir, remove

    dir_name = join(getcwd(), 'tests/test_data')

# Generated at 2022-06-26 02:35:34.144912
# Unit test for function make_lazy
def test_make_lazy():
    string_0 = 'test_make_lazy'
    module_path = 'test_make_lazy'

    # call function make_lazy with arguments
    result = make_lazy(module_path)

    pass



# Generated at 2022-06-26 02:35:44.406992
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(None)
    non_local_1 = NonLocal(None)

    def function_1(arg_1):
        non_local_2 = NonLocal(None)

        def function_2():
            non_local_2.value = arg_1.__trunc__()
            return non_local_2.value

        non_local_1.value = function_2()
        return non_local_1.value

    non_local_0.value = function_1(non_local_0.value)
    return non_local_0.value