

# Generated at 2022-06-26 02:26:00.977426
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("test_module")
    assert isinstance(sys.modules["test_module"], _LazyModuleMarker)


if __name__ == "__main__":
    import sys
    make_lazy("test_module")
    assert isinstance(sys.modules["test_module"], _LazyModuleMarker)
    print(sys.modules["test_module"].__mro__)

# Generated at 2022-06-26 02:26:09.982794
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    module_name = 'test_make_lazy_test_module'

    sys.modules.pop(module_name, None)

    module_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             module_name)

    make_lazy(module_path)

    import test_make_lazy_test_module

    assert isinstance(test_make_lazy_test_module, _LazyModuleMarker)

    test_make_lazy_test_module.test_case_0()

    # if we get here, the module was imported.
    assert not isinstance(test_make_lazy_test_module, _LazyModuleMarker)


if __name__ == '__main__':
    test_make

# Generated at 2022-06-26 02:26:14.323827
# Unit test for function make_lazy
def test_make_lazy():
    from rez.config import _config
    from rez.exceptions import RezSystemError
    from rez.exceptions import ResourceError

    from rez_utilities_base_tests import BaseTest
    from rez_utilities_base_tests import DoesNotRaise
    from rez_utilities_base_tests import Raises

    with BaseTest(make_lazy,
                  # Strings
                  "test",
                  # ints
                  1,
                  # floats
                  1.0,
                  # None
                  None,
                  # other
                  object(),
                  ) as it:
        it.Each(Raises(TypeError))
        it.done()


# Generated at 2022-06-26 02:26:17.361133
# Unit test for function make_lazy
def test_make_lazy():
    assert lazy_module_marker_0 is not None
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(lazy_module_marker_0, _LazyModuleMarker)

# Generated at 2022-06-26 02:26:22.276056
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_0 = LazyModule()
    assert(isinstance(lazy_module_marker_0, _LazyModuleMarker))
    assert(isinstance(lazy_module_marker_0, ModuleType))

if __name__ == "__main__":
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:26:27.009033
# Unit test for function make_lazy
def test_make_lazy():
    # Test that make_lazy marks a module as lazy.
    sys.modules['test_module'] = None
    test_module_marker = NonLocal(None)
    make_lazy('test_module')
    assert 'test_module' in sys.modules

    # Test that make_lazy uses the correct module.
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    del sys.modules['test_module']

# Generated at 2022-06-26 02:26:30.345199
# Unit test for function make_lazy
def test_make_lazy():
    m = make_lazy("_test_make_lazy_0")
    assert(m.__class__.__name__ == "LazyModule")


# Generated at 2022-06-26 02:26:41.935443
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    from pint_test_cases import _get_test_case_path
    import sys
    import os
    import tempfile
    test_case_path = _get_test_case_path()
    test_case_path_0 = test_case_path
    module_name = 'test_module_0'
    module_name_0 = module_name
    module_path = os.path.join(test_case_path_0, module_name_0)
    module_path_0 = module_path
    module_path_1 = module_path_0
    module_path_2 = module_path_1
    module_path_3 = module_path_2
    module_path_4 = module_path_3
    module_path_5 = module

# Generated at 2022-06-26 02:26:43.622203
# Unit test for function make_lazy
def test_make_lazy():
    """
    We can't do an actual unit test for this functionality
    """
    return True


# Generated at 2022-06-26 02:26:50.572299
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(sys.modules['nonlocal_keyword'], _LazyModuleMarker)
    assert not isinstance(sys.modules['nonlocal_keyword'], ModuleType)
    assert not isinstance(sys.modules['nonlocal_keyword'], object)
    assert not hasattr(sys.modules['nonlocal_keyword'], 'NonLocal')
    non = NonLocal(None)
    assert isinstance(non, _LazyModuleMarker)


# Generated at 2022-06-26 02:26:59.193596
# Unit test for function make_lazy
def test_make_lazy():
    # Test with no module name
    try:
        make_lazy("")
        test_case_0()
    except (Exception) as e:
        print("test_make_lazy failed, returned:", e)
    else:
        print("test_make_lazy passed")


# Generated at 2022-06-26 02:27:03.954144
# Unit test for function make_lazy
def test_make_lazy():
    # Unit test: Setup
    # Unit test: Exercise
    make_lazy("test_case_1")
    # Unit test: Verify
    if __name__ != "__main__":  # pragma: no cover
        import sys
        if "test_case_1" in sys.modules:
            raise RuntimeError("Module already imported")



# Generated at 2022-06-26 02:27:14.332486
# Unit test for function make_lazy
def test_make_lazy():
    assert 'make_lazy' not in sys.modules, 'make_lazy already imported in ' + sys.modules['make_lazy'].__file__
    make_lazy('make_lazy')
    mod = sys.modules['make_lazy']
    assert isinstance(mod, _LazyModuleMarker), 'make_lazy should be of type _LazyModuleMarker'
    assert make_lazy.__doc__ == '\n    Mark that this module should not be imported until an\n    attribute is needed off of it.\n    ', 'Unexpected make_lazy.__doc__: ' + make_lazy.__doc__

# Generated at 2022-06-26 02:27:18.684467
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules[__name__] = None
    try:
        import six
        assert not isinstance(six, _LazyModuleMarker)
        make_lazy('six')
        import six
        assert isinstance(six, _LazyModuleMarker)
    finally:
        sys.modules.pop(__name__, None)

# Generated at 2022-06-26 02:27:26.887421
# Unit test for function make_lazy
def test_make_lazy():
    # test non-local
    class C(object):
        def __init__(self):
            self.x = NonLocal(0)
        def get_lazy_x(self):
            return self.x.value
        def set_lazy_x(self, value):
            self.x.value = value

    c = C()
    assert c.get_lazy_x() == 0
    c.set_lazy_x(1)
    assert c.get_lazy_x() == 1
    c.set_lazy_x(2)
    assert c.get_lazy_x() == 2

    # test make_lazy
    class FakeModuleType(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-26 02:27:31.214731
# Unit test for function make_lazy
def test_make_lazy():
    # example usage
    make_lazy("yaml")

    # test that the module really didn't get imported
    # (importing a module that doesn't exist throws an error)
    assert "yaml" not in sys.modules

    # test that this module can still be imported
    import yaml
    assert yaml.__name__ == "yaml"

# Generated at 2022-06-26 02:27:37.849865
# Unit test for function make_lazy
def test_make_lazy():
    from utils.redis_utils import RedisUtils
    _lazy_module_marker = _LazyModuleMarker()
    assert isinstance(RedisUtils, _lazy_module_marker) == False
    make_lazy("utils.redis_utils")
    assert isinstance(RedisUtils, _lazy_module_marker) == True
    assert isinstance(RedisUtils, ModuleType) == False
    #print(RedisUtils)

# Generated at 2022-06-26 02:27:46.105420
# Unit test for function make_lazy
def test_make_lazy():
    path = 'utils.lazy_module.make_lazy'
    make_lazy('utils.lazy_module')
    assert isinstance(sys.modules[path], _LazyModuleMarker)
    assert not hasattr(sys.modules[path], 'make_lazy')
    sys.modules[path].make_lazy('utils.lazy_module')
    assert isinstance(sys.modules[path], _LazyModuleMarker)
    assert hasattr(sys.modules[path], 'make_lazy')


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', '--pdb', __file__])

# Generated at 2022-06-26 02:27:56.998635
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules # cache in the locals
    
    # Define module_path to use in tests
    module_path = 'lazy_module_marker_0'
    
    # Test that exceptions are raised when trying to access attributes on 
    # a lazy module before the module has been imported
    lazy_module_marker_0 = _LazyModuleMarker()
    sys_modules[module_path] = lazy_module_marker_0
    
    with pytest.raises(AttributeError):
        sys_modules[module_path].value

    # Test that attributes are returned correctly once a module has been 
    # imported
    del sys_modules[module_path]
    lazy_module_marker_0 = test_case_0()
    sys_modules[module_path] = lazy_module_marker

# Generated at 2022-06-26 02:28:05.984500
# Unit test for function make_lazy
def test_make_lazy():
    # If a module is not yet loaded the module path must be the same in sys.modules
    # Doing this allows our __import__ override to be called in the path of the real __import__
    make_lazy('mymath.trapezoid')

    # Load the module
    from mymath import trapezoid

    assert(isinstance(trapezoid, _LazyModuleMarker))

    # Load the attribute from the module
    from mymath.trapezoid import trapezoid

    assert(isinstance(trapezoid, _LazyModuleMarker) is False)

    # Make sure it actually works
    assert(trapezoid(5,5) == 25.0)


# Generated at 2022-06-26 02:28:24.336026
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType
    from types import ModuleType as _ModuleType

    # We want to make sure that our LazyModule is a subclass of ModuleType
    # but, because of the __mro__ hack, we can't directly check this.
    assert bool(LazyModule) and issubclass(LazyModule, _ModuleType)

    # Assert the type of our value
    assert isinstance(sys.modules["UnitTest.lazy_module.lazy_module"],
                      LazyModule)
    # Assert that we can use the types object, even though it's not imported
    assert isinstance(sys.modules["UnitTest.lazy_module.lazy_module"], ModuleType)

    # Assert that we can read and write the module

# Generated at 2022-06-26 02:28:29.510111
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    module_path = 'my.module'

    # All the data we need to check
    all_data = [
        {'input': module_path},
    ]

    # Run the test
    results = [make_lazy(**kwargs) for kwargs in all_data]
    #print(results)

    # Verify the results
    assert_equal(results, [None]*len(all_data))

# Generated at 2022-06-26 02:28:30.374612
# Unit test for function make_lazy
def test_make_lazy():
    pass

# Generated at 2022-06-26 02:28:34.396861
# Unit test for function make_lazy
def test_make_lazy():
    assert(make_lazy('a') is None)
    assert(make_lazy('b') is None)
    assert(make_lazy('c') is None)
    assert(make_lazy('d') is None)



# Generated at 2022-06-26 02:28:38.181131
# Unit test for function make_lazy
def test_make_lazy():
    # Test that a lazy module is instance of _LazyModuleMarker
    make_lazy('test_make_lazy')
    try:
        assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    finally:
        del sys.modules['test_make_lazy']



# Generated at 2022-06-26 02:28:41.584288
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('os')
    assert 'os' in sys.modules
    assert os is sys.modules['os']
    assert isinstance(os, _LazyModuleMarker)



# Generated at 2022-06-26 02:28:45.465649
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy
    """
    # make_lazy()
    module_path_0 = 'sys'
    make_lazy(module_path_0)
    # assert_equal(module.value, sys)

# Generated at 2022-06-26 02:28:53.116258
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestMakeLazy(unittest.TestCase):
        def test_make_lazy(self):
            import sys
            import os

            module_name = 'test_module'

            self.assertTrue(module_name not in sys.modules)

            # Create a test module
            os.mkdir(module_name)
            with open(os.path.join(module_name, '__init__.py'), 'w+') as f:
                f.write('attr = 1\n')

            # Mark this module as lazy
            make_lazy(module_name)

            # Assert that it is in sys modules now
            self.assertTrue(module_name in sys.modules)

            # Assert that

# Generated at 2022-06-26 02:29:00.852361
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    lazy_module_path = 'make_lazy_test_module'
    make_lazy(lazy_module_path)
    lazy_module_marker = sys_modules[lazy_module_path]
    assert isinstance(lazy_module_marker, _LazyModuleMarker)
    loaded_module = lazy_module_marker.make_lazy_test_module
    assert isinstance(loaded_module, ModuleType)

# Generated at 2022-06-26 02:29:04.713951
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["lazy"] = None
    make_lazy("lazy")
    lazy = sys.modules["lazy"]
    assert isinstance(lazy, _LazyModuleMarker)
    assert not hasattr(lazy, "__name__")


# Generated at 2022-06-26 02:29:12.802619
# Unit test for function make_lazy
def test_make_lazy():
    # make_lazy(list_0)
    test_case_0()


test_make_lazy()

# Generated at 2022-06-26 02:29:14.328032
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)



# Generated at 2022-06-26 02:29:15.910935
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_case_0')
    test_case_0()

test_make_lazy()

# Generated at 2022-06-26 02:29:17.611600
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-26 02:29:19.195757
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)

test_make_lazy()

# Generated at 2022-06-26 02:29:19.781430
# Unit test for function make_lazy
def test_make_lazy():

    assert True

# Generated at 2022-06-26 02:29:23.974299
# Unit test for function make_lazy
def test_make_lazy():
    # setup
    test_make_lazy_0_variable = None
    import sys
    # set up variable
    sys.modules['test_make_lazy_0'] = test_make_lazy_0_variable

    # test
    test_case_0()


test_make_lazy()

# Generated at 2022-06-26 02:29:29.213651
# Unit test for function make_lazy
def test_make_lazy():
    """
    @return: none
    """
    import random

    import utils
    list_0 = None
    var_0 = make_lazy(list_0)
    var_1 = True
    while var_1:
        var_2 = utils.random_gen()
        if var_2 == 5:
            break
    var_3 = "I'm lazy!"
    var_4 = var_3

# Generated at 2022-06-26 02:29:31.817955
# Unit test for function make_lazy
def test_make_lazy():
    assert True


if __name__ == "__main__":
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:29:39.562345
# Unit test for function make_lazy
def test_make_lazy():
    test_cases = [
        (  # test_case_0
            # list_0
            'make_lazy',
            # var_0
            NonLocal(None)
        ),
    ]

    for test_case in test_cases:
        list_0 = test_case[0]
        var_0 = test_case[1]

        make_lazy(list_0)
        if not isinstance(var_0, NonLocal):
            print("Expected {}, but got {}".format(NonLocal, type(var_0)))
            # continue


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:29:58.318010
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy('__builtin__')
    assert type(var_0) is _LazyModuleMarker
    try:
        from __builtin__ import list
        assert type(list) is not _LazyModuleMarker
    except ImportError:
        from builtins import list
        assert type(list) is not _LazyModuleMarker


# Generated at 2022-06-26 02:30:02.946416
# Unit test for function make_lazy
def test_make_lazy():
    """
    Function that tests the make_lazy function
    """
    list_0 = ["HELLO WORLD"]
    var_0 = make_lazy(list_0)
    assert isinstance(var_0, _LazyModuleMarker)

test_case_0()
test_make_lazy()

# Generated at 2022-06-26 02:30:11.938276
# Unit test for function make_lazy
def test_make_lazy():
    # Declare the global and nonlocal variables
    global list_0
    nonlocal_var_0 = NonLocal(None)

    def func0():
        list_0 = 'list'
        func0.__code__ = compile('assert False', '<string>', 'exec')

    def func1():
        var_0 = NonLocal(None)
        func1.__code__ = compile('assert False', '<string>', 'exec')

    def func2():
        list_0 = ['list']
        func2.__code__ = compile('import list; assert False', '<string>', 'exec')

    def func3():
        var_0 = ('list',)
        func3.__code__ = compile('import list; assert False', '<string>', 'exec')


# Generated at 2022-06-26 02:30:14.635736
# Unit test for function make_lazy
def test_make_lazy():
    assert True == True



# Boilerplate to make this a test module.
if __name__ == '__main__':
    import pytest
    pytest.main(args=["--capture=sys", "-v", __file__])

# Generated at 2022-06-26 02:30:15.537969
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:30:25.087481
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    class_definition = """
    class MakeLazyTestCase(unittest.TestCase):
        def testCase010(self):
            list_0 = None
            var_0 = make_lazy(list_0)
    if __name__ == '__main__':
        unittest.main()
    """
    expected_result = """
    .
    ----------------------------------------------------------------------
    Ran 1 test in 0.000s

    OK
    """

# Generated at 2022-06-26 02:30:28.246540
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)
    assert var_0 is None

if __name__ == '__main__':
    try:
        sys.exit(test_make_lazy())
    except SystemExit:
        pass

# Generated at 2022-06-26 02:30:30.302018
# Unit test for function make_lazy
def test_make_lazy():
    arg0 = None
    assert make_lazy(arg0) == None



# Generated at 2022-06-26 02:30:33.366634
# Unit test for function make_lazy
def test_make_lazy():

    # Check if expected exception is raised by make_lazy
    with pytest.raises(TypeError):
        print(make_lazy())
# jitdriver for function test_case_1

# Generated at 2022-06-26 02:30:37.768730
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)
    try:
        raise Exception('Assertion failed')
    except:
        _, e, _ = sys.exc_info()
        raise type(e)(str(e) + ' : ' + 'Unable to resolve value of module list_0')

test_make_lazy()

# Generated at 2022-06-26 02:31:07.926372
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)
    assert var_0 is None


# Generated at 2022-06-26 02:31:09.812863
# Unit test for function make_lazy
def test_make_lazy():
    from test_list_0_1 import test_case_0

    test_case_0()

# Generated at 2022-06-26 02:31:11.039529
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)

# Generated at 2022-06-26 02:31:13.206728
# Unit test for function make_lazy
def test_make_lazy():
    # Use some python magic to test our code.
    assert isinstance(make_lazy, types.FunctionType) is True


# Generated at 2022-06-26 02:31:19.021888
# Unit test for function make_lazy
def test_make_lazy():
    tests = [
        (
            (
                "os.path.dirname"
            ),  # <Param>
        ),  # <Test>
    ]

    for test in tests:
        module_path = test[0]
        with pytest.raises(TypeError):
            make_lazy(module_path)



# Generated at 2022-06-26 02:31:27.506399
# Unit test for function make_lazy
def test_make_lazy():
    # Create a module to hold our attributes
    mod = ModuleType('mod')
    sys.modules['mod'] = mod

    # Note: we could use a with statement for this, but this would also
    # require that we depend on contextlib2 or enum34 on Python 2.

# Generated at 2022-06-26 02:31:28.979315
# Unit test for function make_lazy
def test_make_lazy():
    assert True == True
    

# Generated at 2022-06-26 02:31:30.128918
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:31:31.121178
# Unit test for function make_lazy
def test_make_lazy():
    # Add your code here.
    pass

# Generated at 2022-06-26 02:31:39.266877
# Unit test for function make_lazy
def test_make_lazy():
    # Testing for ValueError
    try:
        test_case_0()
    except ValueError:
        pass

#
# Test Cases for function make_lazy
#
#
# import unittest
#
#
# class Testmake_lazy(unittest.TestCase):
#
#     def test_make_lazy(self):
#         # Testing for ValueError
#         self.assertRaises(ValueError, test_make_lazy())
#
#
# def suite():
#     return unittest.TestLoader().loadTestsFromTestCase(Testmake_lazy)

# Generated at 2022-06-26 02:32:40.585872
# Unit test for function make_lazy
def test_make_lazy():
    print('Test make_lazy')

    test_case_0()

    print('\n')


test_make_lazy()

# Generated at 2022-06-26 02:32:42.226829
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:32:47.624869
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy('aklsjdflkj')
    assert var_0 == None
    var_1 = make_lazy('a')
    var_2 = make_lazy('b')
    var_3 = make_lazy('c')
    var_4 = make_lazy('d')
    var_5 = make_lazy('e')


# Generated at 2022-06-26 02:32:53.884189
# Unit test for function make_lazy
def test_make_lazy():
    """
    Note that this test case is not guaranteed to run. The lazy module
    is marked at the top of the file (or function) but never declared.
    """
    import sys

    mod_name = 'testMod'
    make_lazy(mod_name)
    assert sys.modules[mod_name] is not None
    assert sys.modules[mod_name] is not importlib.import_module(mod_name)
    assert sys.modules[mod_name] is not None


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:32:55.003572
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here



# Generated at 2022-06-26 02:32:57.652540
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    list_0 = None
    var_0 = make_lazy(list_0)
    assert var_0 == None

    # Cleanup - none necessary



# Generated at 2022-06-26 02:32:58.562850
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:33:10.074501
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_case_0()
    except TypeError as e:
        if str(e) == 'num':
            print('AssertionError')


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:33:11.549600
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(ValueError):
        make_lazy("")
        make_lazy("/")

# Generated at 2022-06-26 02:33:13.207478
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)

    assert var_0 == None



# Generated at 2022-06-26 02:35:32.641098
# Unit test for function make_lazy
def test_make_lazy():
    list_1 = None
    # Make pytype happy
    try:
        make_lazy(list_1)
    except AttributeError:
        pass

# Generated at 2022-06-26 02:35:37.278452
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

if __name__ == '__main__':
    test_make_lazy()
    print('All test cases passed.')

# Generated at 2022-06-26 02:35:40.308142
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = ['list_0', 'list_0']
    make_lazy(var_0)
    var_1 = []
    make_lazy(var_1)
    var_2 = {}
    make_lazy(var_2)


# Generated at 2022-06-26 02:35:45.444113
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    var_0 = make_lazy(list_0)
    var_1 = isinstance(list_0, _LazyModuleMarker)
    assert var_1


# Generated at 2022-06-26 02:35:47.631312
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'collections'
    make_lazy(module_path)
    sys.modules[module_path]


# Generated at 2022-06-26 02:35:51.822237
# Unit test for function make_lazy
def test_make_lazy():
    from test_support import run_unittest
    from test.test_make_lazy import TestMakeLazy

    run_unittest(TestMakeLazy)


if __name__ == "__main__":
    test_case_0()
    test_make_lazy()