

# Generated at 2022-06-26 02:25:52.286259
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()



# Generated at 2022-06-26 02:26:04.263863
# Unit test for function make_lazy
def test_make_lazy():
    new_module_name = 'pyquickhelper.loghelper.lazy_module.pyq_module_for_module_lazy_module'
    assert new_module_name not in sys.modules

    module_path = 'pyquickhelper.loghelper.lazy_module'
    m = sys.modules[module_path]


# Generated at 2022-06-26 02:26:11.610878
# Unit test for function make_lazy
def test_make_lazy():
    def test_module():
        """
        A test module to be used in our tests.
        """
        return 'abc'
    orig_import = __builtins__['__import__']

    def mock_import(module, *args, **kwargs):
        """
        A mock for __import__ that asserts that we only import once.
        """
        if module == 'foo.bar':
            assert False, "foo.bar should not be imported"
        return orig_import(module, *args, **kwargs)

    # cache the import function so we can restore it later.
    __builtins__['__import__'] = mock_import


# Generated at 2022-06-26 02:26:21.824161
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules

    sys_modules.clear()
    sys_modules["test_module_1"] = None

    make_lazy("test_module_1")

    assert "test_module_1" in sys_modules
    assert isinstance(sys_modules["test_module_1"], _LazyModuleMarker)
    assert sys_modules["test_module_1"].__doc__ is None

    sys_modules.clear()
    sys_modules["test_module_1"] = "I am a string"

    make_lazy("test_module_1")

    assert "test_module_1" in sys_modules
    assert isinstance(sys_modules["test_module_1"], _LazyModuleMarker)
    assert sys_modules["test_module_1"].__doc__ is None

    sys_

# Generated at 2022-06-26 02:26:29.951792
# Unit test for function make_lazy
def test_make_lazy():
    _lazy_module_marker = NonLocal(None)
    _lazy_module_marker.value = _LazyModuleMarker()
    _lazy_module_marker.value.__getattribute__ = _LazyModuleMarker.__getattribute__
    _lazy_module_marker.value.__mro__ = _LazyModuleMarker.__mro__
    _sys_modules = NonLocal(None)
    _sys_module = NonLocal(None)
    _sys_module.value = dict()
    _sys_modules.value = _sys_module.value
    _module_path = NonLocal(None)
    _module_path.value = "lazy_attr.lazy_module_0"

# Generated at 2022-06-26 02:26:41.543158
# Unit test for function make_lazy
def test_make_lazy():

    lazy_module_marker_0 = _LazyModuleMarker()
    mod_0 = make_lazy("test_make_lazy")
    assert isinstance(mod_0, lazy_module_marker_0)

    mod_0.m = "_LazyModuleMarker"
    assert hasattr(mod_0, "m")
    assert mod_0.m == "_LazyModuleMarker"
    assert not isinstance(mod_0, lazy_module_marker_0)


# def test_lazy_import_0(lazy_module):
#     assert lazy_module.a == 1
#     assert lazy_module.b.c == 3
#     assert lazy_module.d.e == 5
#     assert lazy_module.d.f.g == 7


# @pytest.fixture
#

# Generated at 2022-06-26 02:26:42.182715
# Unit test for function make_lazy
def test_make_lazy():
    pass



# Generated at 2022-06-26 02:26:46.157157
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('mock_module_0')
    try:
        mock_module_0
        assert False, "mock_module_0 not undefined"
    except NameError:
        pass

    mock_module_0.MockAttribute()

# Generated at 2022-06-26 02:26:55.182076
# Unit test for function make_lazy
def test_make_lazy():
    # Test that two classes that share a common base class
    # can be used without errors, but will not be initially
    # considered an instance of that base class.
    # We want to ensure that the base class check in our
    # LazyModule class will not fail.
    #
    # The test case we want to ensure is true is:
    #   type(lazy_module_marker_0) != _LazyModuleMarker
    assert not isinstance(test_case_0.lazy_module_marker_0, _LazyModuleMarker)

    # Make sure that isinstance does not break.
    assert not isinstance(test_case_0.lazy_module_marker_0, LazyModule)

    # Ensure that lazy modules return correct results
    import sys
    assert sys.modules[__name__] is not test

# Generated at 2022-06-26 02:27:04.342462
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("test.test_make_lazy_module")
    import test.test_make_lazy_module  # pylint: disable=W0611, W0401
    lazy_module = sys.modules["test.test_make_lazy_module"]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # Ensure the module is a _LazyModule, but not a _LazyModuleMarker
    assert not isinstance(lazy_module, _LazyModuleMarker)

    # Ensure we can access the module, which will import it.
    assert hasattr(lazy_module, "TEST")

# Generated at 2022-06-26 02:27:07.936334
# Unit test for function make_lazy
def test_make_lazy():
    def test_func_0():
        test_case_0()
    test_func_0()


# Test of NonLocal.__init__

# Generated at 2022-06-26 02:27:18.487425
# Unit test for function make_lazy
def test_make_lazy():
    # Input
    module_path = 'some_module'

    # Mocks

    # Expected results
    expected_result = None

    # Setup
    sys_modules = {module_path: 1234}
    sys.modules = sys_modules

    # Exercise function
    make_lazy(module_path)

    # Assert results
    assert sys_modules[module_path].__class__.__name__ == 'LazyModule'
    assert sys_modules[module_path].__class__.__mro__()[0] == sys_modules[module_path].__class__
    assert sys_modules[module_path].__class__.__mro__()[1] == ModuleType


if __name__ == '__main__':
    test_make_lazy()
    print('Testing finished.')

# Generated at 2022-06-26 02:27:25.750924
# Unit test for function make_lazy
def test_make_lazy():
    # Populate sys.modules before `import abc` so that we can
    # verify that `abc` is not imported if we don't ask for it.
    sys.modules['abc'] = 6

    assert sys.modules['abc'] == 6

    make_lazy('abc')
    assert isinstance(sys.modules['abc'], _LazyModuleMarker)

    with pytest.raises(AttributeError):
        sys.modules['abc'].ABCMeta

    # since we are mirroring sys.modules in our LazyModule, we need
    # to override the `abc` module again after importing it.
    sys.modules['abc'] = __import__('abc')

# Generated at 2022-06-26 02:27:35.801975
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)

    test_module_0 = "test.test_module"
    test_module_1 = "test.test_module"
    test_module_2 = "test.test_module"
    test_module_3 = "test.test_module"
    test_module_4 = "test.test_module"
    test_module_5 = "test.test_module"

    int_1 = 517
    non_local_1 = NonLocal(int_1)

    test_module_6 = "test.test_module"
    test_module_7 = "test.test_module"
    test_module_8 = "test.test_module"
    test_module_9 = "test.test_module"
    test_

# Generated at 2022-06-26 02:27:45.876839
# Unit test for function make_lazy
def test_make_lazy():
    import os, sys
    import os.path
    import sys
    import sysconfig
    if sys.version_info <= (3, 4, 1):
        assert sysconfig.get_python_inc().decode() == u'c:\\users\\smadni\\appdata\\local\\temp\\tmpjrplnt\\python27.amd64\\include'

    if sys.version_info >= (3, 6):
        import subprocess
        int_0 = 523
        str_0 = 'C:\\Users\\smadni\\AppData\\Local\\Temp\\tmpjrplnt\\python27.amd64\\include'
        from subprocess import check_output
        import os, sys
        import os.path
        import sys
        import sysconfig

# Generated at 2022-06-26 02:27:48.093398
# Unit test for function make_lazy
def test_make_lazy():
    pytest.skip('TODO: Implement unit tests.')
    
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-26 02:27:49.539241
# Unit test for function make_lazy
def test_make_lazy():
    for test in tests:
        with raises(AssertionError):
            test()

# Generated at 2022-06-26 02:27:50.478796
# Unit test for function make_lazy
def test_make_lazy():
    pass


# Generated at 2022-06-26 02:27:53.674156
# Unit test for function make_lazy
def test_make_lazy():

    int_0 = 517
    non_local_0 = NonLocal(int_0)
    non_local_0 = NonLocal(int_0)


# Entry point for program

# Generated at 2022-06-26 02:28:00.073249
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module = mock.MagicMock(spec=LazyModule)
    attr = 'attr'
    attr_value = 1
    setattr(lazy_module, attr, attr_value)
    sys.modules = {'lazy_module': lazy_module}

    imp.reload(lazy_module)

    # Test that we get the correct attr
    assert getattr(lazy_module, attr) == attr_value
    assert sys.modules['lazy_module'] == lazy_module



# Generated at 2022-06-26 02:28:11.774178
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from cPickle import dumps
    from types import ModuleType
    import netlib.test.test_lazy
    import netlib.test.test_lazy._lazy_test

    sys.modules["netlib.test.test_lazy"] = netlib.test.test_lazy
    sys.modules["netlib.test.test_lazy._lazy_test"] = netlib.test.test_lazy._lazy_test

    assert hasattr(netlib.test.test_lazy._lazy_test, "stuff") == True
    assert netlib.test.test_lazy._lazy_test.stuff == "hah"
    assert isinstance(netlib.test.test_lazy._lazy_test, ModuleType) == True

# Generated at 2022-06-26 02:28:22.974656
# Unit test for function make_lazy
def test_make_lazy():
    assert not hasattr(sys.modules, 'unittest.test')
    assert not hasattr(sys.modules, 'unittest.test.test_foo')
    make_lazy('unittest.test.test_foo')
    assert isinstance(sys.modules['unittest.test.test_foo'], _LazyModuleMarker)
    assert not hasattr(sys.modules, 'unittest.test')
    assert not hasattr(sys.modules, 'unittest.test.test_foo')
    assert hasattr(sys.modules['unittest.test.test_foo'], 'test_foo')
    assert not hasattr(sys.modules, 'unittest.test')
    assert 'test_test_make_lazy' in dir(sys.modules['unittest.test.test_foo'])

# Generated at 2022-06-26 02:28:24.791054
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 127
    non_local_0 = NonLocal(int_0)
    make_lazy(non_local_0)


# Generated at 2022-06-26 02:28:37.028754
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)
    mod = None
    sys.modules['test_lazy'] = mod
    non_local_1 = NonLocal(mod)
    make_lazy('test_lazy')
    # Assert that NonLocal is a _LazyModuleMarker
    assert isinstance(sys.modules['test_lazy'], _LazyModuleMarker)
    test_lazy = sys.modules['test_lazy']
    # Assert that we don't trigger the __getattribute__ method and that
    # we still have our original object in 'test_lazy'.
    assert isinstance(test_lazy, NonLocal)
    # Assert that NonLocal is a _LazyModuleMarker

# Generated at 2022-06-26 02:28:40.940673
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import pyperf
    runner = pyperf.Runner()
    runner.timeit('test_case_0', 'test_make_lazy()', globals=globals())

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:28:42.018637
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)



# Generated at 2022-06-26 02:28:44.079726
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)



# Generated at 2022-06-26 02:28:48.469603
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('test')
    assert isinstance(sys.modules['test'], _LazyModuleMarker)
    sys.modules['test'].__getattribute__('__name__')
    assert isinstance(sys.modules['test'], ModuleType)



# Generated at 2022-06-26 02:28:50.240701
# Unit test for function make_lazy
def test_make_lazy():
    int_1 = 517
    make_lazy(int_1)


# Generated at 2022-06-26 02:28:57.481910
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    str_0 = 'test_case_0'

    non_local_0 = NonLocal(str_0)
    assert non_local_0.value == 'test_case_0'

    make_lazy(str_0)
    assert non_local_0.value == 'test_case_0'


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()
    print('Test passed')

# Generated at 2022-06-26 02:29:11.006951
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import copy
    import types

    def test_func():
        int_0 = 517
        non_local_0 = NonLocal(int_0)

        return False

    if sys.version_info[0] >= 3:
        _builtin_module_0 = importlib.util.find_spec(
            "builtins")
    else:
        _builtin_module_0 = importlib.util.find_spec("__builtin__")
    if _builtin_module_0 is not None:
        test_func()
    else:
        pass



# Generated at 2022-06-26 02:29:16.531020
# Unit test for function make_lazy
def test_make_lazy():
    import ctypes
    ctypes.CDLL('libc.so.6', use_errno=True).strerror_r.restype = ctypes.c_char_p

    make_lazy('argparse')

    import argparse

    argparse.ArgumentParser()

    make_lazy('pdb')

    import pdb

    # removes the lazy module from sys.modules (and so prevents
    # pdb from being a lazy module in subsequent tests)
    del sys.modules['pdb']

    return


# Generated at 2022-06-26 02:29:26.285601
# Unit test for function make_lazy
def test_make_lazy():
    # This test checks whether make_lazy correctly short-circuits standard
    # module imports.
    sys.modules['test_module'] = None
    make_lazy('test_module')
    assert 'test_module' not in sys.modules
    assert isinstance(test_module, _LazyModuleMarker)
    assert test_module is not None
    assert hasattr(test_module, '__path__')
    assert isinstance(test_module.__path__, list)
    assert 'test_module' in sys.modules
    lazy_mod = sys.modules['test_module']
    assert isinstance(lazy_mod, LazyModule)
    assert test_module is sys.modules['test_module']
    assert test_module.__loader__ is None
    assert test_module.__name__ == 'test_module'

# Generated at 2022-06-26 02:29:28.285254
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)
    assert isinstance(make_lazy('sys'), _LazyModuleMarker)


# Generated at 2022-06-26 02:29:38.223257
# Unit test for function make_lazy
def test_make_lazy():
    import copy
    from types import ModuleType
    from types import CodeType

    # Test 1
    test_case_0()

    # Test 2

# Generated at 2022-06-26 02:29:40.631863
# Unit test for function make_lazy
def test_make_lazy():
    int_1 = 758
    non_local_1 = NonLocal(int_1)
    print(int_1)
    print(non_local_1)


# Generated at 2022-06-26 02:29:41.952122
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:29:52.731607
# Unit test for function make_lazy
def test_make_lazy():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import just
    from hypothesis.strategies import sampled_from
    from hypothesis.strategies import emails
    import hypothesis.strategies as st

    @given(st.lists(text()))
    def test_make_lazy_inner(xs):
        #@st.settings(deadline=1000)
        def test_make_lazy_inner_inner():
            if xs in ([], ['x'], ['xx'], ['xxx'], ['xxxx'], ['xxxxx'], ['xxxxxx'], ['xxxxxxx'], ['xxxxxxxx'], ['xxxxxxxxx']):
                pass

# Generated at 2022-06-26 02:29:58.701905
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules
    import random
    import string
    import sys

    random.seed(0)

    module_path = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    assert module_path not in modules

    make_lazy(module_path)
    assert isinstance(modules[module_path], _LazyModuleMarker)



# Generated at 2022-06-26 02:30:02.831851
# Unit test for function make_lazy
def test_make_lazy():
    import unittest

    class TestMakeLazy(unittest.TestCase):
        def test_0(self):
            int_0 = 517
            non_local_0 = NonLocal(int_0)

    unittest.main()



# Generated at 2022-06-26 02:30:18.312417
# Unit test for function make_lazy
def test_make_lazy():
    # Test for int
    int_0 = 517
    non_local_0 = NonLocal(int_0)

    assert non_local_0.value == int_0



# Generated at 2022-06-26 02:30:20.355961
# Unit test for function make_lazy
def test_make_lazy():
    module_path = '__main__'
    make_lazy(module_path)
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:30:29.325877
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)
    str_0 = "test_case_0"
    str_1 = "foo_0"
    str_2 = "__name__"
    str_3 = "bar_0"
    int_1 = 11
    module_path = str_0
    int_2 = 4
    int_3 = 10
    int_4 = 4
    str_4 = "__getattribute__"
    int_5 = 2
    int_6 = 3
    int_7 = 7
    int_8 = 9
    int_9 = 6
    int_10 = 5
    str_5 = "__mro__"
    int_11 = 8
    int_12 = 1

# Generated at 2022-06-26 02:30:39.556589
# Unit test for function make_lazy
def test_make_lazy():
    python_path_0 = sys.path[0]
    python_path_1 = sys.path[1]
    int_0 = 0
    long_0 = 2**60
    long_1 = long_0 - long_0
    int_1 = int_0 >> 1
    long_2 = long_1 << long_0
    python_path_2 = sys.path[2]
    python_path_3 = sys.path[3]
    int_2 = len(sys.path)
    python_path_4 = sys.path[4]
    python_path_5 = sys.path[5]
    python_path_6 = sys.path[6]
    int_3 = int_1 & int_0
    int_4 = int_3 << int_3
    python_path_7 = sys.path

# Generated at 2022-06-26 02:30:49.875251
# Unit test for function make_lazy
def test_make_lazy():
    global _LazyModuleMarker
    global NonLocal
    global sys_modules
    global LazyModule
    global attr
    global module_path
    global module
    global sys
    global getattr
    global __import__
    global make_lazy

    int_0 = 517
    non_local_0 = NonLocal(int_0)
    module_path = 'foo'
    module = NonLocal(None)
    sys_modules = sys.modules
    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)
        def __getattribute__(self, attr):
            if module.value is None:
                del sys_modules[module_path]
                module.value = __import__(module_path)


# Generated at 2022-06-26 02:30:56.667677
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    int_1 = 11070
    assert sys.modules['test_make_lazy'] == int_1
    int_2 = 617
    make_lazy(str_0)
    assert sys.modules['test_make_lazy'] == int_2
    int_3 = 3600
    make_lazy(str_1)
    assert sys.modules['test_make_lazy'] == int_3
    str_1 = 'test_make_lazy'
    str_0 = 'test_make_lazy'


# Generated at 2022-06-26 02:31:07.643358
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules

    # Test Code

    # Non-local Test Cases
    prev_len = sys.modules.__len__()
    make_lazy('sys')
    assert sys.modules['sys'].__class__.__name__ == 'LazyModule'
    assert prev_len == sys.modules.__len__()


    # Local Test Cases
    # Test Code
    prev_len = sys.modules.__len__()
    make_lazy('sys')
    assert sys.modules['sys'].__class__.__name__ == 'LazyModule'
    assert prev_len == sys.modules.__len__()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 02:31:18.082738
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    str_0 = '-MekI'
    module_path = 'BASE_DIR'
    str_1 = f'path.join(BASE_DIR, "{str_0}")'
    module_path += str_1
    module = sys.modules[module_path]
    lazy = non_local_0 = _LazyModuleMarker()
    sys.modules[module_path] = lazy
    make_lazy(module_path)
    assert sys.modules[module_path] is lazy
    assert module is lazy

# Generated at 2022-06-26 02:31:23.421115
# Unit test for function make_lazy
def test_make_lazy():
    # This function is called before the first call to the function make_lazy.
    # The function make_lazy is imported only in the first call.
    test_case_0()
    # Please check the printed value.
    print(non_local_0.value)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:31:30.044684
# Unit test for function make_lazy
def test_make_lazy():
    # Stub function make_lazy for testing purposes
    def make_lazy_stub(module_path):
        pass

    make_lazy_stub('module_path')


# Generated at 2022-06-26 02:32:04.905000
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    # get the real sys.modules value
    original_sys_modules = sys.modules

    def get_fake_module_to_import(name):
        """
        Creates a fake module that can be imported by name.
        """
        def make_it_a_module():
            """
            Tricks python into thinking it's a module
            """
            return sys.modules[name]
        if name in sys.modules:
            return sys.modules[name]

        sys.modules[name] = make_it_a_module()
        return sys.modules[name]

    test_module_name = 'test_module'

    # create a fake module
    test_module = get_fake_module_to_import(test_module_name)

    # create an attribute in the fake module
    test_module.test

# Generated at 2022-06-26 02:32:07.970225
# Unit test for function make_lazy
def test_make_lazy():
    testcase_0(make_lazy)
    test_case_0()

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:32:10.657101
# Unit test for function make_lazy
def test_make_lazy():
    assert not hasattr(sys.modules, "lazy_test")
    make_lazy("lazy_test")
    assert isinstance(sys.modules["lazy_test"], _LazyModuleMarker)

# Generated at 2022-06-26 02:32:11.492476
# Unit test for function make_lazy
def test_make_lazy():
    pass



# Generated at 2022-06-26 02:32:21.936923
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import inspect
    import types
    import mpikat

    test_case_0()

    assert sys.modules["mpikat"].__class__ == types.ModuleType
    assert inspect.getmodule(NonLocal) == mpikat.commonutils
    assert sys.modules["mpikat.commonutils"].__class__ == types.ModuleType

    make_lazy("mpikat.commonutils")

    assert sys.modules["mpikat.commonutils"].__class__ == types._LazyModuleMarker
    assert "NonLocal" in vars(mpikat.commonutils)

    test_case_0()

    assert sys.modules["mpikat"].__class__ == types.ModuleType
    assert inspect.getmodule(NonLocal) == mpikat.commonutils

# Generated at 2022-06-26 02:32:30.320110
# Unit test for function make_lazy
def test_make_lazy():
    import sys

# Generated at 2022-06-26 02:32:35.560390
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    sys_modules = sys.modules
    mod_path = '__main__'
    if mod_path not in sys.modules:
        sys_modules[mod_path] = __import__(mod_path)
    mod = sys_modules[mod_path]
    make_lazy(mod_path)

# Generated at 2022-06-26 02:32:37.705054
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)
    return



# Generated at 2022-06-26 02:32:38.517965
# Unit test for function make_lazy
def test_make_lazy():
    pass # TODO

# Generated at 2022-06-26 02:32:42.821390
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    sys_modules = sys.modules
    make_lazy(int_0)
    if (str(type(sys_modules[int_0])) == "<class '__main__.LazyModule'>"):
        assert True
    else:
        assert False


# Generated at 2022-06-26 02:33:45.468246
# Unit test for function make_lazy
def test_make_lazy():
    # Test for correct typing and correct values
    int_0 = 517
    make_lazy(int_0)
    try:
        # Test for correct exception
        non_local_0 = NonLocal(int_0)
    except TypeError:
        pass
    


if __name__ == '__main__':
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:33:50.555237
# Unit test for function make_lazy
def test_make_lazy():
    # Initializations
    global non_local_0
    non_local_0 = None
    global int_0
    int_0 = 0
    # Function call
    test_case_0()
    # Verification
    assert non_local_0.value == int_0


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:33:53.289525
# Unit test for function make_lazy
def test_make_lazy():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:34:04.976972
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = '__import__'
    str_1 = '__mro__'
    str_2 = '__getattribute__'
    str_3 = 'LazyModule'
    str_4 = '__main__'
    str_5 = 'testing'
    str_6 = 'should_not_be_imported'
    str_7 = 'called'
    str_8 = '__slots__'
    str_9 = '__name__'
    str_10 = 'value'
    str_11 = 'NonLocal'
    str_12 = 'make_lazy'
    dict_0 = globals()
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_5 = dict_0


# Generated at 2022-06-26 02:34:05.822054
# Unit test for function make_lazy
def test_make_lazy():
    pass


# Generated at 2022-06-26 02:34:09.978050
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(int_0)
    assert non_local_0.value == int_0, \
        "The `NonLocal` should be initialized with the input value."
    return


# Generated at 2022-06-26 02:34:18.561243
# Unit test for function make_lazy
def test_make_lazy():
    # py2
    with helpers.py2_mode():
        import sys
        sys.modules['app'] = None

        make_lazy('app')
        assert sys.modules['app'].__class__.__name__ == 'LazyModule'
        assert sys.modules['app'].__class__.__base__.__name__ == 'ModuleType'
        assert isinstance(sys.modules['app'], _LazyModuleMarker)

        import app
        assert app.__class__.__name__ == 'module'
        assert app.__class__.__base__.__name__ == 'object'

        assert sys.modules['app'].__class__.__name__ == 'module'
        assert sys.modules['app'].__class__.__base__.__name__ == 'object'

    # py3
   

# Generated at 2022-06-26 02:34:21.182800
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    non_local_0 = NonLocal(int_0)
    make_lazy("test_module_0")
    make_lazy("test_module_1")


# Generated at 2022-06-26 02:34:23.924832
# Unit test for function make_lazy
def test_make_lazy():
    print("Test #1: Non local data")
    test_case_0()

# main()
test_make_lazy()

# Generated at 2022-06-26 02:34:31.168710
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 517
    str_0 = '\\*\\/'
    list_0 = ['q', 'y', 'i']
    int_1 = hash(str_0)
    non_local_0 = NonLocal(int_1)
    list_1 = sys.modules
    make_lazy(str_0)
    module_0 = list_1[str_0]
    try:
        isinstance(module_0, _LazyModuleMarker)
    except TypeError:
        raise ValueError