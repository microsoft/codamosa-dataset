

# Generated at 2022-06-26 02:26:07.101567
# Unit test for function make_lazy
def test_make_lazy():
    list_1 = []
    non_local_0 = NonLocal(*list_1)
    lazy_module_1 = lazy_module(*list_1)
    sys_modules_mock_0 = mocker.Mock()
    mocker.patch('sys.modules', new=sys_modules_mock_0)
    mocker.patch('builtins.getattr', return_value=getattr_mock_0)
    mocker.patch('sys.modules.update', return_value=sys_modules_update_mock_0)
    mocker.patch('sys.modules.__getitem__', return_value=sys_modules___getitem___mock_0)
    mocker.patch('builtins.type', return_value=type_mock_0)

# Generated at 2022-06-26 02:26:14.137806
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = _LazyModuleMarker()
    sys_modules_0 = sys.modules  # cache in the locals

    # store our 'instance' data in the closure.
    module_0 = NonLocal(None)
    sys_modules_0[module_path_0] = module_0


if __name__ == '__main__':
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:26:24.268683
# Unit test for function make_lazy
def test_make_lazy():
    import bz2
    import logging
    import os
    import sys

    from homura.utils.misc import make_lazy

    if sys.version_info < (3, 3):
        print('skipping lazy import test; python version not supported')
        return

    if "HOMURA_LAZY_IMPORT" in os.environ:
        return

    if os.path.basename(sys.argv[0]) == "nosetests":
        return

    if sys.argv[0].endswith(('.pyc', '.pyo')):
        return

    _ = logging.getLogger  # NOQA
    make_lazy('logging')
    _ = os.urandom  # NOQA
    make_lazy('os')


# Generated at 2022-06-26 02:26:31.314947
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = []
    str_0 = "fake_module"
    make_lazy(str_0)
    try:
        __import__(str_0)
    except KeyError as e:
        assert str_0 in e.args
    try:
        scope_0 = __import__(str_0)
    except KeyError as e:
        assert str_0 in e.args

# Generated at 2022-06-26 02:26:32.398608
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:26:34.460555
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = 'test'
    make_lazy(module_path_0)


# Generated at 2022-06-26 02:26:46.564482
# Unit test for function make_lazy
def test_make_lazy():
    import os
    from shutil import rmtree

    from types import ModuleType

    # create a new virtual python environment
    path = os.path.join(os.path.abspath(os.path.dirname(__file__)), '_testenv')
    if os.path.isdir(path):
        rmtree(path)

    os.makedirs(os.path.join(path, 'lib', 'python2.7', 'site-packages'))

    # create a module on it
    with open(os.path.join(path, 'lib', 'python2.7', 'site-packages', 'foo.py'), 'w') as f:
        f.write("""
foo = 0

print 'imported foo'
        """)

    # create a dummy module on it

# Generated at 2022-06-26 02:26:47.810411
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:26:49.976235
# Unit test for function make_lazy
def test_make_lazy():
    import a.b.c
    test_module = a.b.c
    assert isinstance(test_module, _LazyModuleMarker)

# Generated at 2022-06-26 02:26:51.253529
# Unit test for function make_lazy
def test_make_lazy():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:27:00.298644
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    make_lazy(str_0)

if __name__ == '__main__':

    test_case_0()
    test_make_lazy()
    print("Completed")

# Generated at 2022-06-26 02:27:10.040947
# Unit test for function make_lazy

# Generated at 2022-06-26 02:27:16.287297
# Unit test for function make_lazy
def test_make_lazy():
    # Test for module __main__
    str_1 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_1)
    # Test for module __main__
    pass


# Generated at 2022-06-26 02:27:25.105046
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy('Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    ')
# Test pypy-5.7, pypy-5.8, and cpython-2.7.9, cpython-3.6.8.
# We need to use different lazy_import statements for the different
# Python interprators.
# If a lazy import is not available, try to fall back to a regular import
try:
    from _pypy_interplevel import lazy_import as _lazy_import
except ImportError:
    _lazy_import = __import__

_lazy_re_compile = None


# Generated at 2022-06-26 02:27:26.304110
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)



# Generated at 2022-06-26 02:27:28.271389
# Unit test for function make_lazy
def test_make_lazy():
    A = make_lazy('django.apps.registry')
    assert isinstance(A, _LazyModuleMarker)


# Generated at 2022-06-26 02:27:32.311325
# Unit test for function make_lazy
def test_make_lazy():
    str_1 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_1 = make_lazy(str_1)

# Generated at 2022-06-26 02:27:33.020901
# Unit test for function make_lazy
def test_make_lazy():
    pass

# Generated at 2022-06-26 02:27:38.808112
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    var_1 = isinstance(var_0,_LazyModuleMarker)
    assert var_1 is True


# Generated at 2022-06-26 02:27:42.652964
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    make_lazy(str_0)

# Generated at 2022-06-26 02:27:53.577300
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    test_case_0()


if __name__ == '__main__':
    import sys
    import nose
    #from nose.tools import *
    
    argv = sys.argv[:]
    argv.append('--cover-package=lazy')
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-26 02:28:04.064309
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = u'importlib_metadata.tests.test_lazy'
    make_lazy(var_0)
    var_1 = u'importlib_metadata.tests.test_lazy'
    var_2 = sys.modules[var_1]
    assert isinstance(var_2, _LazyModuleMarker)
    var_3 = u'importlib_metadata.tests.test_lazy'
    if var_3 in sys.modules:
        del sys.modules[var_3]
    import importlib_metadata.tests.test_lazy
    var_4 = u'importlib_metadata.tests.test_lazy'
    var_5 = sys.modules[var_4]
    assert isinstance(var_5, importlib_metadata.tests.test_lazy.__class__)



# Generated at 2022-06-26 02:28:05.316937
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert the_exception

# Generated at 2022-06-26 02:28:09.567350
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    assert_equal(str_0, 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    ')

# Generated at 2022-06-26 02:28:14.821746
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy('bisect')
    import re
    var_1 = type(re.compile)
    var_2 = _LazyModuleMarker
    if var_1 == var_2:
        return 0
    return 1


# Generated at 2022-06-26 02:28:15.835882
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:28:16.950633
# Unit test for function make_lazy
def test_make_lazy():
    assert 1 == 1


# Generated at 2022-06-26 02:28:27.897196
# Unit test for function make_lazy
def test_make_lazy():
    from re import compile as _compile
    from re import _compile_repl as _orig_compile_repl

    # Store the original values of re.compile and re.compile_repl
    ORIG_RE_COMPILE = _compile
    ORIG_RE_COMPILE_REPL = _orig_compile_repl

    # Make re lazy import.
    make_lazy('re')

    # re.compile should be a LazyModule now
    assert isinstance(re.compile, _LazyModuleMarker)

    assert re.compile.__name__ == 'compile'
    assert re.compile.__module__ == 're'
    assert re.sub.__doc__

    # We shouldn't have imported re until we touched it.
    assert ORIG_RE_COMPILE is not re.compile

# Generated at 2022-06-26 02:28:35.413177
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    lazy_module = make_lazy(str_0)
    assert isinstance(lazy_module, _LazyModuleMarker)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 02:28:39.761072
# Unit test for function make_lazy
def test_make_lazy():
    # Make lazy_compile the default compile mode for regex compilation.
    #
    # This overrides re.compile with lazy_compile. To restore the original
    # functionality, call reset_compile().
    make_lazy('re')


# Generated at 2022-06-26 02:28:53.777836
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy('sre_compile')
    assert repr(var_0) == "LazyModule('sre_compile')"
    assert not isinstance(var_0, ModuleType)
    assert isinstance(var_0, _LazyModuleMarker)
    try:
        # This should fail because we've marked it as lazy
        # and it hasn't been imported yet
        var_0.compile()
        assert False, "We shouldn't get here"
    except AttributeError:
        pass
    # Now call compile, this will import the module
    # and cache it in var_0
    var_1 = var_0.compile('foo')
    assert var_1.pattern == 'foo'
    assert isinstance(var_0, ModuleType)

# Generated at 2022-06-26 02:29:03.984934
# Unit test for function make_lazy
def test_make_lazy():
    # It is difficult to test enough here because the whole idea is to delay the
    # import of a module until a property / attribute is accessed.

    # Initial `sys.modules` value
    sys_modules = sys.modules

    # Make a lazy module
    make_lazy('test_make_lazy')

    # Ensure it is lazified
    assert 'test_make_lazy' in sys.modules
    lazy_module = sys.modules['test_make_lazy']
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert 'test_make_lazy' in sys_modules

    # Reset the module
    sys.modules = sys_modules


# Generated at 2022-06-26 02:29:13.619100
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    str_1 = 'Return the original compile function.\n\n    This may be used to restore the original re.compile function if it was\n    replaced earlier.\n    '
    str_2 = 'Return the original search function.\n\n    This may be used to restore the original re.search function if it was\n    replaced earlier.\n    '
    str_3 = 'Return the original match function.\n\n    This may be used to restore the original re.match function if it was\n    replaced earlier.\n    '

# Generated at 2022-06-26 02:29:14.092761
# Unit test for function make_lazy
def test_make_lazy():
    pass

# Generated at 2022-06-26 02:29:23.398987
# Unit test for function make_lazy
def test_make_lazy():
    import re
    import sys

    sys_modules = sys.modules  # cache in the locals
    assert 're' in sys_modules
    assert re.compile('a')
    assert len(set(sys_modules)) == len(sys_modules)

    # now make it lazy.
    make_lazy('re')

    # we should have a lazy "re" object still in sys.modules
    assert sys_modules['re']

    # but we can't call its compile function because it's not imported yet.
    with pytest.raises(AttributeError):
        sys_modules['re'].compile('b')

    # now we should get a real "re" module back
    re2 = __import__('re')

    # both should be the same module
    assert re is re2

    # and we should still have just one.

# Generated at 2022-06-26 02:29:28.363771
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import re
    var_0 = make_lazy('re')
    var_0 = re.compile('cat')
    var_1 = re.compile('dog')
    var_2 = re.compile('horse')
    var_3 = re.compile('house')
    var_4 = re.compile('python')
    var_4 = sys.modules


# Generated at 2022-06-26 02:29:31.122469
# Unit test for function make_lazy
def test_make_lazy():
    global module_path
    module_path = 'test_module'

    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:29:36.247106
# Unit test for function make_lazy

# Generated at 2022-06-26 02:29:40.171520
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'func_0'
    var_0 = make_lazy(str_0)
    assert_equal(var_0, 1)
    var_0 = isinstance(var_0, _LazyModuleMarker)
    assert_equal(var_0, True)


# Generated at 2022-06-26 02:29:46.237366
# Unit test for function make_lazy
def test_make_lazy():
    # BEGIN PYTHON 2
    # str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    # var_0 = make_lazy(str_0)
    # assert isinstance(var_0, _LazyModuleMarker)
    # assert var_0.__name__ == str_0
    # assert var_0.__module__ == str_0
    # END PYTHON 2

    # BEGIN PYTHON 3
    str_0 = 're'
    var_0 = make_lazy(str_0)
    assert isinstance(var_0, _LazyModuleMarker)
    assert var_0.__

# Generated at 2022-06-26 02:29:50.714028
# Unit test for function make_lazy
def test_make_lazy():

    #assert make_lazy() == None
    assert True


# Generated at 2022-06-26 02:29:52.681743
# Unit test for function make_lazy
def test_make_lazy():
    # Test correct io (no exception)
    test_case_0()


# Generated at 2022-06-26 02:29:57.059693
# Unit test for function make_lazy
def test_make_lazy():

    # Make lazy_compile the default compile mode for regex compilation.
    #
    # This overrides re.compile with lazy_compile. To restore the original
    # functionality, call reset_compile().
    test_case_0()

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:29:57.912123
# Unit test for function make_lazy
def test_make_lazy():
    assert True


# Generated at 2022-06-26 02:30:00.341162
# Unit test for function make_lazy
def test_make_lazy():
    pass


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:30:10.058262
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    var_1 = isinstance('x', _LazyModuleMarker)
    var_2 = isinstance('x', ModuleType)
    var_3 = isinstance(var_0, ModuleType)
    var_4 = isinstance(var_0, _LazyModuleMarker)
    var_5 = re.compile('x')
    var_6 = isinstance(var_0, _LazyModuleMarker)
    var_7 = re.compile('x')

# Generated at 2022-06-26 02:30:15.839548
# Unit test for function make_lazy
def test_make_lazy():
    assert True == pytest.mark.skipif(
        not sys.platform.startswith('linux'),
        reason='Not supported under WIN, Mac'
    )

    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    assert isinstance(var_0, str)

test_make_lazy()

# Generated at 2022-06-26 02:30:17.175045
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

test_make_lazy()

# Generated at 2022-06-26 02:30:23.441770
# Unit test for function make_lazy
def test_make_lazy():
    # obj.TEST_CASE_0() # TypeError: 'module' object is not callable
    assert isinstance(globals()["lazy_loader"], _LazyModuleMarker)

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'profile':
        import cProfile

        cProfile.run('test_case_0()', 'prof')
    else:
        main(sys.argv)

# Generated at 2022-06-26 02:30:26.168214
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'This is a test string.'
    result = make_lazy(str_0)
    assert True # "make_lazy('This is a test string.')"

if __name__ == '__main__':
    import sys
    sys.exit(pystone.main(sys.argv))

# Generated at 2022-06-26 02:30:34.103022
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    return "ok"



# Generated at 2022-06-26 02:30:38.364114
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:30:38.929035
# Unit test for function make_lazy
def test_make_lazy():
    assert False


# Generated at 2022-06-26 02:30:44.083302
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:30:49.039660
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    assert var_0 is True


# Generated at 2022-06-26 02:30:58.599582
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    assert str_0 == 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    assert isinstance(var_0, _LazyModuleMarker)
    if __name__ == '__main__':
        pass
    # Run the tests
    run_tests()



# Generated at 2022-06-26 02:31:00.810442
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test_make_lazy')


# Generated at 2022-06-26 02:31:06.962126
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_path = 'tests.test_lazy'
    lazy_module = sys.modules[lazy_module_path]

    # String is an attribute of the lazy module, but it is not really imported
    # until we attempt to get it from the module object.
    assert 'String' in dir(lazy_module)
    assert 'String' not in dir(sys.modules[__name__])

    assert lazy_module.String == sys.modules[__name__].String



# Generated at 2022-06-26 02:31:08.781743
# Unit test for function make_lazy
def test_make_lazy(): # added
    test_case_0()

# Unit tests

# Generated at 2022-06-26 02:31:19.939460
# Unit test for function make_lazy
def test_make_lazy():
    # Test that the module isn't imported until a getattr call.
    module_name = 'unittest_fixtures.test_make_lazy.not_loaded_yet'
    if module_name in sys.modules:
        del sys.modules[module_name]

    make_lazy(module_name)

    # Test that it creates a lazy module that appears to be a normal module
    assert sys.modules[module_name] is not None
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)
    assert isinstance(sys.modules[module_name], ModuleType)

    # Test that it isn't loaded in the sys.modules
    loaded_module = sys.modules[module_name]
    del sys.modules[module_name]
    loaded_module = sys.modules[module_name]
   

# Generated at 2022-06-26 02:31:34.457898
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy('test')

# Generated at 2022-06-26 02:31:39.642584
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    # assert str(type(make_lazy(str_0))) == "<class 'lazy_loader.lazy_loader.LazyModule'>"


# Generated at 2022-06-26 02:31:42.310300
# Unit test for function make_lazy
def test_make_lazy():
    print()
    print('Test make_lazy')

    test_case_0()


# Generated at 2022-06-26 02:31:44.279820
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:31:49.647331
# Unit test for function make_lazy
def test_make_lazy():
    module_str = 'foo.bar.baz'
    sys.modules[module_str] = None

    make_lazy(module_str)

    assert isinstance(sys.modules[module_str], _LazyModuleMarker)

    # Will raise an AttributeError if this isn't a regular module.
    assert sys.modules[module_str].__file__ is not None

# Generated at 2022-06-26 02:31:59.124974
# Unit test for function make_lazy
def test_make_lazy():
    def test_case_0():
        str_0 = 'def f():\n    pass\n\n'
        var_0 = make_lazy(str_0)
    test_case_0()

    def test_case_1():
        str_1 = 'def __init__(self, attr):\n        self.attr = attr\n        \n    def __getattribute__(self, attr):\n        return getattr(self.attr, attr)\n        \n'
        var_0 = make_lazy(str_1)

    test_case_1()

test_make_lazy()

# Generated at 2022-06-26 02:32:05.361711
# Unit test for function make_lazy
def test_make_lazy():
    import re
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    make_lazy(str_0)
    assert _LazyModuleMarker in re.compile.__mro__
    str_1 = 'Returns a compiled version of the supplied regular expression.\n\n    This is a wrapper around the standard library re.compile() function with\n    certain optimizations enabled by default.\n    '
    make_lazy(str_1)
    assert _LazyModuleMarker in re.compile.__mro__

# Generated at 2022-06-26 02:32:10.920506
# Unit test for function make_lazy

# Generated at 2022-06-26 02:32:14.488709
# Unit test for function make_lazy
def test_make_lazy():
    from test_support import run_unittest
    from test_lazy_impl import LazyTestCase
    run_unittest(LazyTestCase)


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:32:21.528400
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    assert isinstance(var_0, NonLocal)
    assert isinstance(var_0.value, _LazyModuleMarker)

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:32:53.493857
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:32:59.032539
# Unit test for function make_lazy

# Generated at 2022-06-26 02:33:02.692288
# Unit test for function make_lazy
def test_make_lazy():
    mod = make_lazy('_lazy_regex')
    # assert mod is not None

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:33:12.550033
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)
    str_1 = 'Restore re.compile to the original implementation.\n    '
    var_1 = make_lazy(str_1)
    str_2 = 'A Python 2/3 compatible lazy regex compile decorator.\n    '
    var_2 = make_lazy(str_2)

# Generated at 2022-06-26 02:33:17.250305
# Unit test for function make_lazy
def test_make_lazy():
    assert(make_lazy)

lazy_compile = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
make_lazy(lazy_compile)
make_lazy('from importlib import import_module')
import re
from importlib import import_module



# Generated at 2022-06-26 02:33:18.160302
# Unit test for function make_lazy
def test_make_lazy():
    assert False


# Generated at 2022-06-26 02:33:31.179714
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'branch'
    var_0 = make_lazy(str_0)

    time_0 = time.time()

    list_0 = []

    for i in range(0, 1000):
        list_0.append(i)

    var_1 = list_0.pop()

    time_1 = time.time()

    print(time_0, time_1)

    str_1 = 'branch'

    bool_0 = str_1 is str_0

    time_2 = time.time()

    var_2 = sys.modules[str_1]

    time_3 = time.time()

    print(time_2, time_3)

    list_1 = []

    for i in range(0, 1000):
        list_1.append(i)


# Generated at 2022-06-26 02:33:33.619366
# Unit test for function make_lazy
def test_make_lazy():
    # This function will not be tested since it changes the behavior of
    # the import system.
    pass


# Generated at 2022-06-26 02:33:36.138816
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(test_case_0, _LazyModuleMarker)

# Generated at 2022-06-26 02:33:50.633614
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)

    str_1 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_1 = make_lazy(str_1)


# Generated at 2022-06-26 02:34:58.719408
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(make_lazy('python'))

# Generated at 2022-06-26 02:35:02.981181
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)


# Generated at 2022-06-26 02:35:07.773403
# Unit test for function make_lazy
def test_make_lazy():
    str_1 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_1 = make_lazy(str_1)
    assert var_1 is not None



# Generated at 2022-06-26 02:35:12.376022
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_0 = make_lazy(str_0)

# Generated at 2022-06-26 02:35:17.147711
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy("regex")
    assert(isinstance(var_0, _LazyModuleMarker))
    assert(isinstance(var_0, ModuleType))
    try:
        var_0.regex
    except:
        pass
    else:
        raise AssertionError("Module was incorrectly loaded.")

# Generated at 2022-06-26 02:35:23.735245
# Unit test for function make_lazy
def test_make_lazy():
    str_1 = 'Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    '
    var_1 = make_lazy(str_1)

    try:
        import re
        import lazyscripts.util
        assert lazyscripts.util.make_lazy == make_lazy
    finally:
        # reset the import in sys.modules
        del sys.modules['re']


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()
    print('Tests passed')

# Generated at 2022-06-26 02:35:29.982396
# Unit test for function make_lazy
def test_make_lazy():
    print('Unit test for make_lazy')
    assert(make_lazy == make_lazy), "Test #1 failed"
    assert((lambda: make_lazy) == make_lazy), "Test #2 failed"
    assert(False), "Test #3 failed"


# Generated at 2022-06-26 02:35:34.181663
# Unit test for function make_lazy
def test_make_lazy():
    assert make_lazy('Make lazy_compile the default compile mode for regex compilation.\n\n    This overrides re.compile with lazy_compile. To restore the original\n    functionality, call reset_compile().\n    ') is None

# Test with pytest

# Generated at 2022-06-26 02:35:39.924549
# Unit test for function make_lazy
def test_make_lazy():
    # Version 0.1.1
    test_case_0()
    # Version 0.1.0
    #test_case_1()
    # Version 0.0.3
    #test_case_2()
    # Version 0.0.2
    #test_case_3()
    # Version 0.0.1
    #test_case_4()



# Generated at 2022-06-26 02:35:46.610340
# Unit test for function make_lazy
def test_make_lazy():
    lazyre_0 = var_0
    str_1 = '__doc__'
    assert hasattr(lazyre_0, str_1)
    str_2 = '__mro__'
    assert hasattr(lazyre_0, str_2)
    str_3 = '__getattribute__'
    assert hasattr(lazyre_0, str_3)


test_make_lazy()