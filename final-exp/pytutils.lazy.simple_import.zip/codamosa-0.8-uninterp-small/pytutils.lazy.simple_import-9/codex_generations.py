

# Generated at 2022-06-26 02:25:58.517413
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'test'
    module_path = 'test_module.test'
    # Make a lazy module
    make_lazy(module_path)
    # Add the module to sys.modules
    sys.modules[module_name] = sys.modules[module_path]
    # Import it again to make sure it is lazy
    m = __import__(module_name)
    # Confirm we got a lazy module marker
    assert isinstance(m, _LazyModuleMarker)


# Generated at 2022-06-26 02:26:08.817496
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['my_mod'] = ModuleType('my_mod')

    make_lazy('my_mod')

    assert isinstance(sys.modules['my_mod'], _LazyModuleMarker)

    # import the module
    sys.modules['my_mod'].my_attr

    # assert that the module is built
    assert isinstance(sys.modules['my_mod'], ModuleType)

    # assert that the module was only imported once
    assert sys.modules['my_mod'].my_attr.count == 1


# def test_make_lazy_with_aliases():
#     sys.modules['my_mod'] = ModuleType('my_mod')
#     sys.modules['my_mod_alias'] = sys.modules['my_mod']

#     make_lazy('my_mod')



# Generated at 2022-06-26 02:26:16.519264
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    make_lazy("mypackage.mymodule")

    # https://stackoverflow.com/a/5347829/3952757
    assert isinstance(sys.modules["mypackage.mymodule"], _LazyModuleMarker)

    # https://stackoverflow.com/a/7175792/3952757
    assert "mypackage" in sys.modules["mypackage.mymodule"].__dict__  # pylint: disable=pointless-statement

# Generated at 2022-06-26 02:26:25.045559
# Unit test for function make_lazy
def test_make_lazy():
    # Function makes sure that 'module_name_0' is not imported until it is asked for
    # A test to make sure that the module was not imported until lastTest was called
    make_lazy('module_name_0')
    sys.modules['module_name_0'].testVar1 = 'this was not imported until lastTest was called'
    sys.modules['module_name_0'].testVar2 = 'this was not imported until lastTest was called'
    assert sys.modules['module_name_0'].testVar1 == 'this was not imported until lastTest was called'
    assert sys.modules['module_name_0'].testVar2 == 'this was not imported until lastTest was called'



# Generated at 2022-06-26 02:26:32.190259
# Unit test for function make_lazy
def test_make_lazy():
    tmp_dict = {}

# Generated at 2022-06-26 02:26:33.873929
# Unit test for function make_lazy
def test_make_lazy():
    assert (callable(make_lazy))



# Generated at 2022-06-26 02:26:39.414984
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info >= (3, 0):
        return

    import os
    import tempfile
    import pytest

    # Create a temporary directory to use
    tmpdir = tempfile.mkdtemp()
    # Create another temporary directory to use
    tmpdir_import = tempfile.mkdtemp()

# Generated at 2022-06-26 02:26:46.937651
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('os')
    make_lazy('__main__.test_make_lazy')
    make_lazy('os')
    assert not isinstance(os, _LazyModuleMarker)
    assert isinstance(test_case_0, _LazyModuleMarker)

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:26:47.886222
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:26:55.978998
# Unit test for function make_lazy
def test_make_lazy():
    assert not isinstance(sys.modules['six.moves'], _LazyModuleMarker)

    make_lazy('six.moves')
    assert isinstance(sys.modules['six.moves'], _LazyModuleMarker)
    assert not hasattr(sys.modules['six.moves'], '__name__')

    assert sys.modules['six.moves'].__name__ == 'six.moves'
    assert isinstance(sys.modules['six.moves'], _LazyModuleMarker)

    assert sys.modules['six.moves'].map == map
    assert isinstance(sys.modules['six.moves'], ModuleType)

if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:27:08.030335
# Unit test for function make_lazy
def test_make_lazy():
    # Check for the existance of module
    try:
        assert imp.find_module('lazy_module_0') is not None
    except ImportError:
        assert False
    else:
        lazy_module_0 = imp.load_module('lazy_module_0', *imp.find_module('lazy_module_0'))

    # Check for the existance of module
    try:
        assert imp.find_module('lazy_module_1') is not None
    except ImportError:
        assert False
    else:
        lazy_module_1 = imp.load_module('lazy_module_1', *imp.find_module('lazy_module_1'))

    # Check for the existance of module

# Generated at 2022-06-26 02:27:13.577285
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    module_path = "fake_module"
    assert module_path not in sys_modules, "fake_module was already imported"
    make_lazy(module_path)
    assert module_path in sys_modules, "fake_module was not added to sys.modules"
    assert isinstance(sys_modules[module_path], _LazyModuleMarker)

# Generated at 2022-06-26 02:27:15.493422
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:27:19.005310
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules.pop('__mp_test_lazy_0', None)

    make_lazy('__mp_test_lazy_0')

    assert '__mp_test_lazy_0' not in sys.modules
    assert isinsta

# Generated at 2022-06-26 02:27:23.297057
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['module_path'] = _LazyModuleMarker()
    make_lazy('module_path')
    assert(sys.modules['module_path'].__getattribute__() == None)

# Test case for function make_lazy
test_make_lazy()
test_case_0()

# Generated at 2022-06-26 02:27:31.906793
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    import shutil
    import sys
    from types import ModuleType

    import six
    from six import add_metaclass

    sys.path.append(os.getcwd())

    # We have to use os.mkdir because the tempfile module assumes that you
    # are Windows and delays importing until the file is closed.
    temp_directory = tempfile.mkdtemp()

    # We don't want to depend on the tempfile module in our test case
    # to avoid other importing behavior that would affect our test
    # case results.
    directory = temp_directory

    # On Windows, the os.path.join function can't properly handle unicode
    # strings.
    # See:  http://bugs.python.org/issue13277
    # We convert it to bytes so that we can properly form the path

# Generated at 2022-06-26 02:27:42.610340
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_module'] = None

    make_lazy('test_module')
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)

    # Test that trying to import the module causes the module to be
    # loaded into the sys modules cache.
    module_a = __import__('test_module')
    assert isinstance(module_a, _LazyModuleMarker)
    assert module_a.__name__ == 'test_module'

    # Checking inside the lazy module will cause it to load
    assert module_a.__name__ == 'test_module'
    assert module_a.__name__ == 'test_module'  # ensure it works twice
    assert type(module_a) == ModuleType

    # Explictly load the module and make sure that it is the same module.


# Generated at 2022-06-26 02:27:49.873602
# Unit test for function make_lazy
def test_make_lazy():
    module_path = "test_lazy"

    class TestLazyModule(object):
        pass

    # make a fake module to check against.
    sys.modules[module_path] = TestLazyModule()

    make_lazy(module_path)

    # Check the cache
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Check that the fake module is still there.
    assert sys.modules[module_path].__name__ == module_path

    # Is it a lazy module?
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Grab a proper module off of it.
    assert isinstance(sys.modules[module_path].__mro__, tuple)

# Generated at 2022-06-26 02:27:53.062170
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy( 'lazy_module_marker' )
    assert(lazy_module_marker.__class__.__name__ == 'LazyModule')



# Generated at 2022-06-26 02:27:56.065016
# Unit test for function make_lazy
def test_make_lazy():
    # Check for case when module path is not valid
    with pytest.raises(ImportError):
        make_lazy("foo")

    # Check for case when module path is valid
    make_lazy("sys")

# Generated at 2022-06-26 02:28:07.898149
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy("test_make_lazy_lazy")

    # Check that the module is not yet loaded.
    try:
        from test_make_lazy_lazy import foo
        assert False
    except ImportError:
        pass

    # Check that the module exists but is a standin.
    assert sys.modules["test_make_lazy_lazy"] is not None
    assert isinstance(sys.modules["test_make_lazy_lazy"], _LazyModuleMarker)

    # Check that the module gets lazily loaded.
    assert sys.modules["test_make_lazy_lazy"].foo == 42
    assert isinstance(sys.modules["test_make_lazy_lazy"], ModuleType)


if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-26 02:28:10.561770
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("{guid}_0".format(guid=str(uuid.uuid4())))
    make_lazy("{guid}_1".format(guid=str(uuid.uuid4())))



# Generated at 2022-06-26 02:28:18.384487
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy('sys')

    # This test fails atm.
    #assert 'sys' in sys.modules
    #assert not isinstance(sys, _LazyModuleMarker)
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)

    # This test fails atm.
    # This fails because the module is not actually imported yet.
    #assert getattr(sys, 'version') == '1.0'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:28:28.711440
# Unit test for function make_lazy
def test_make_lazy():
    if 'lazy_module_marker_1' in sys.modules:
        del sys.modules['lazy_module_marker_1']
    make_lazy('lazy_module_marker_1')
    assert isinstance(lazy_module_marker_1, _LazyModuleMarker)
    assert 'lazy_module_marker_1' in sys.modules
    assert 'lazy_module_marker_1' not in sys.modules['lazy_module_marker_1'].__dict__
    assert 'lazy_module_marker_1' not in sys.modules['lazy_module_marker_1'].__dict__['__builtins__'].__dict__
    assert isinstance(sys.modules['lazy_module_marker_1'], _LazyModuleMarker)

# Generated at 2022-06-26 02:28:38.999527
# Unit test for function make_lazy
def test_make_lazy():
    assert 'test_lazy_module_2' not in sys.modules
    assert 'test_lazy_module_3' not in sys.modules
    assert 'test_lazy_module_4' not in sys.modules

    make_lazy('test_lazy_module_3')
    assert 'test_lazy_module_2' not in sys.modules
    assert 'test_lazy_module_3' not in sys.modules
    assert 'test_lazy_module_4' not in sys.modules

    make_lazy('test_lazy_module_4')
    assert 'test_lazy_module_2' not in sys.modules
    assert 'test_lazy_module_3' not in sys.modules
    assert 'test_lazy_module_4' not in sys.modules

    # make_l

# Generated at 2022-06-26 02:28:41.739917
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('foobar')
    assert isinstance(sys.modules['foobar'], _LazyModuleMarker)


# Generated at 2022-06-26 02:28:45.258478
# Unit test for function make_lazy
def test_make_lazy():
    # Test that make_lazy works
    make_lazy('test_case_0')

    # Test that we can still access a module
    lazy_module_marker_0 = _LazyModuleMarker()

# Generated at 2022-06-26 02:28:52.374793
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    if "test_lazy_import" in sys_modules:
        del sys_modules["test_lazy_import"]

    make_lazy("test_lazy_import")

    assert sys_modules["test_lazy_import"] is not None

    import test_lazy_import

    class_0 = test_lazy_import.TestClass

    assert class_0 is not None


if __name__ == "__main__":
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:29:04.223297
# Unit test for function make_lazy
def test_make_lazy():
    modules_path = 'test.test_mod_0'
    make_lazy(modules_path)
    assert modules_path in sys.modules
    module_0 = sys.modules[modules_path]
    assert isinstance(module_0, _LazyModuleMarker)

    make_lazy('test.test_mod_1')
    assert 'test.test_mod_1' in sys.modules
    module_1 = sys.modules['test.test_mod_1']
    assert isinstance(module_1, _LazyModuleMarker)

    module_0.__getattribute__('test_case_0')
    assert 'test.test_mod_0' in sys.modules
    new_module_0 = sys.modules['test.test_mod_0']

# Generated at 2022-06-26 02:29:13.202943
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy'] = None
    make_lazy('test_make_lazy')

    # Modules should be lazy until a method is called on it.
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    sys.modules['test_make_lazy'].__file__
    assert not isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)

    # Make sure that the module was actually imported.
    assert sys.modules['test_make_lazy'].__file__ == '<unknown>'


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:29:24.901374
# Unit test for function make_lazy

# Generated at 2022-06-26 02:29:32.945910
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import numpy
    numpy_path = numpy.__name__
    assert numpy_path in sys.modules

    make_lazy(numpy_path)

    assert sys.modules[numpy_path].__class__.__name__ == 'LazyModule'

    assert numpy is not sys.modules[numpy_path]

    assert numpy.array is sys.modules[numpy_path].array
    assert numpy.add is sys.modules[numpy_path].add


# Import Guarding
if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:29:42.062432
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test.mock_modules.module_flask'] = ModuleType('test.mock_modules.module_flask')
    make_lazy('test.mock_modules.module_flask')

    assert(isinstance(sys.modules['test.mock_modules.module_flask'], _LazyModuleMarker))
    assert(len(sys.modules) == 3)

    from test import mock_modules
    assert(isinstance(mock_modules.module_flask, ModuleType))
    assert(len(sys.modules) == 3)

    assert(mock_modules.module_flask.app.config['DEBUG'] == True)
    assert(len(sys.modules) == 4)

# Generated at 2022-06-26 02:29:46.791885
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_marker_1 = _LazyModuleMarker()

    my_module = 'foo'
    make_lazy(my_module)
    assert my_module in sys.modules

    lazy_module = sys.modules[my_module]
    assert isinstance(lazy_module, _LazyModuleMarker)

# Generated at 2022-06-26 02:29:48.965951
# Unit test for function make_lazy
def test_make_lazy():
    is_instance_0 = isinstance(test_case_0(), _LazyModuleMarker) # test that isinstance returns true



# Generated at 2022-06-26 02:30:00.341446
# Unit test for function make_lazy
def test_make_lazy():
    import sys, os
    import random
    file_name = "test_file_lazy_module.py"
    path_to_file = os.path.dirname(os.path.realpath(__file__)) + "\\" + file_name
    mod_path = "test_file_lazy_module"

    # Randomly generate a test_file_lazy_module and make it lazy
    file_content = open(path_to_file, "w")

    random_str = str(random.random())
    file_content.write("a = %s\n" % random_str)
    file_content.close()

    make_lazy(mod_path)

    import test_file_lazy_module
    if "a" in dir(test_file_lazy_module):
        import pytest


# Generated at 2022-06-26 02:30:04.345720
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module'] = None
    make_lazy('lazy_module')
    assert sys.modules['lazy_module'] is not None
    assert isinstance(sys.modules['lazy_module'], _LazyModuleMarker)


# Generated at 2022-06-26 02:30:05.304736
# Unit test for function make_lazy
def test_make_lazy():
    assert False, 'Test Not implemented'


# Generated at 2022-06-26 02:30:12.905483
# Unit test for function make_lazy
def test_make_lazy():
    # this module wont be imported until an attribute is needed off of it
    # i.e. `from .. import app_test` will not import this module.
    make_lazy(__name__)
    assert __name__ in sys.modules

    # we will use `importlib` to import the module. This is to
    # make sure that `importlib` sees the module as a LazyModule.
    # this test will fail if `importlib` can import our module normally
    # (if the `make_lazy` is not called)
    from importlib import import_module
    lazy_import_module = import_module(__name__)

    # if `import_module` does not see it as a LazyModule, this will fail
    assert isinstance(lazy_import_module, _LazyModuleMarker)

    # if we

# Generated at 2022-06-26 02:30:17.632897
# Unit test for function make_lazy
def test_make_lazy():
    assert_equals(type(lazy_module_marker_0), _LazyModuleMarker)
    make_lazy(lazy_module_marker_0)
    assert_equals(type(lazy_module_marker_0), lazy_module_marker_0)
    assert_true(isinstance(lazy_module_marker_1, _LazyModuleMarker))
    
    pass



# Generated at 2022-06-26 02:30:24.614222
# Unit test for function make_lazy
def test_make_lazy():
    # Test the validity of the module, variable, and function
    # declarations.
    is_instance_0 = isinstance(sys.modules["pytest_lazyfixture.lazy"], _LazyModuleMarker)
    assert is_instance_0 is True

if __name__ == "__main__":
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:30:29.012996
# Unit test for function make_lazy
def test_make_lazy():
    assert hasattr(sys.modules['sys'], '__mro__')
    assert sys.modules['sys'].__mro__ == (sys.modules['sys'], object)

    make_lazy('sys')
    assert not hasattr(sys.modules['sys'], '__mro__')
    assert sys.modules['sys'].__mro__ == (sys.modules['sys'], ModuleType)



# Generated at 2022-06-26 02:30:39.281038
# Unit test for function make_lazy
def test_make_lazy():
    import test_make_lazy

    test_case_0()
    str_0 = "test_make_lazy"
    make_lazy(str_0)
    module = sys.modules[str_0]
    assert isinstance(module, _LazyModuleMarker), "Expected an instance of LazyModule."
    assert module.__name__ == str_0, "Expected __name__ to be set properly."
    assert test_make_lazy is module, "Expected new module to replace the old module in sys.modules."

    # we can import classes from the module
    from test_make_lazy import TestCaseClass
    assert TestCaseClass is not None, "Failed to import TestCaseClass"

    # we can also import functions from the module
    from test_make_lazy import test_case_0
   

# Generated at 2022-06-26 02:30:43.037195
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = str()
    make_lazy(module_path_0)
    module_path_1 = str()
    make_lazy(module_path_1)
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 02:30:44.682720
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = -56
    make_lazy(int_0)


# Generated at 2022-06-26 02:30:54.761814
# Unit test for function make_lazy
def test_make_lazy():
    str_0 = 'test_module.test_module_0'
    make_lazy(str_0)
    # inferred as: { type: 'list', elttype: {type: 'literal', value: 'str'}, location: [{type: 'builtin'}] }
    list_0 = [str_0]
    list_1 = [] # inferred as: { type: 'list', elttype: None, location: [{type: 'builtin'}] }
    list_2 = [str_0] # inferred as: { type: 'list', elttype: {type: 'literal', value: 'str'}, location: [{type: 'builtin'}] }
    list_1.append(list_2)

# Generated at 2022-06-26 02:31:06.340549
# Unit test for function make_lazy
def test_make_lazy():
    import tests.utils.stubs.make_lazy_stubs.mod_0
    import tests.utils.stubs.make_lazy_stubs.mod_1
    import tests.utils.stubs.make_lazy_stubs.mod_2
    import tests.utils.stubs.make_lazy_stubs.mod_3
    import tests.utils.stubs.make_lazy_stubs.mod_4
    import tests.utils.stubs.make_lazy_stubs.mod_5
    import tests.utils.stubs.make_lazy_stubs.mod_6
    import tests.utils.stubs.make_lazy_stubs.mod_7
    import tests.utils.stubs.make_lazy_stubs.mod_8
    import tests.utils.stubs.make

# Generated at 2022-06-26 02:31:16.928911
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    int_0 = -255
    non_local_0 = NonLocal(int_0)
    sys_modules = sys.modules  # cache in the locals
    module_path = 'foo'
    module = NonLocal(None)
    class LazyModule_0(object):
        def __mro__(self):
            return (LazyModule_0, ModuleType)
        def __getattribute__(self, attr):
            if module.value is None:
                del sys_modules[module_path]
                module.value = __import__(module_path)

                sys_modules[module_path] = __import__(module_path)

            return getattr(module.value, attr)
    module_0 = LazyModule_0()
    sys_modules[module_path] = module_0


# Generated at 2022-06-26 02:31:17.754059
# Unit test for function make_lazy
def test_make_lazy():
    assert True


# Generated at 2022-06-26 02:31:23.232418
# Unit test for function make_lazy
def test_make_lazy():
    module_path_0 = 'a'
    non_local_0 = NonLocal(module_path_0)

    def function_0():
        nonlocal_0 = NonLocal(module_path_0)
        nonlocal_0.value = module_path_0
        make_lazy(nonlocal_0.value)

    function_0()


# Generated at 2022-06-26 02:31:38.503411
# Unit test for function make_lazy
def test_make_lazy():
    import sys, sys
    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy
    sys.path.append('/home/blah/blah/blah')
    import sys

    # make_lazy


# Generated at 2022-06-26 02:31:45.002409
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 5
    non_local_0 = NonLocal(int_0)
    int_1 = 1
    non_local_1 = NonLocal(int_1)
    bool_0 = bool(int_1)

    src_0 = "../test/test_project/test_cases/test_case_0.py"
    src_0 = os.path.abspath(src_0)

    test_case_0()
    test_type_0 = type(test_case_0)
    assert isinstance(test_case_0, ModuleType)
    assert test_case_0.__name__ == "test_case_0"
    assert test_case_0.__file__ == src_0

    src_1 = "test_case_1"
    make_lazy(src_1)



# Generated at 2022-06-26 02:31:47.717746
# Unit test for function make_lazy
def test_make_lazy():
    # initialize
    test_case_0()
    # run tests
    make_lazy('functions')


test_make_lazy()

# Generated at 2022-06-26 02:31:48.643447
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:31:54.934724
# Unit test for function make_lazy
def test_make_lazy():
    non_local_0 = NonLocal(0)
    int_0 = -225
    int_1 = -257
    int_2 = -257
    
    # Test function make_lazy with arguments:
    #   make_lazy(int_0)
    sys.modules[int_0] = ModuleType(int_0)
    test_case_0()
    
    # Test function make_lazy with arguments:
    #   make_lazy(int_1)
    sys.modules[int_1] = ModuleType(int_1)
    non_local_0.value = NonLocal(int_1)
    
    # Test function make_lazy with arguments:
    #   make_lazy(int_2)
    sys.modules[int_2] = ModuleType(int_2)
    non

# Generated at 2022-06-26 02:31:58.048022
# Unit test for function make_lazy
def test_make_lazy():
    # Unit test for function make_lazy.create_lazy_module
    # AssertionError: expected False to be None
    assert_equals(NonLocal(int_0), None)


# Generated at 2022-06-26 02:32:03.691308
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

    make_lazy('base')
    # We will now try to access a top-level attribute in the base module.
    # If the module is not lazy, this will fail.
    from base import *  # noqa
    print("Importing base performed in the lazy mode.")


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:32:10.175173
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('math')
    math = sys.modules['math']
    assert isinstance(math, _LazyModuleMarker)
    assert sys.modules['math'] == math
    assert math.pi == 3.141592653589793
    assert sys.modules['math'] != math
    assert isinstance(math, ModuleType)

    # Now we create a new module object!
    assert id(math) != id(sys.modules['math'])

# Generated at 2022-06-26 02:32:20.598014
# Unit test for function make_lazy
def test_make_lazy():
    class_0 = [
        bytearray,
        bytearray,
        bytearray,
        bytearray,
        bytearray,
        bytearray,
    ]
    int_2 = 64
    int_1 = 2
    int_0 = 1
    float_0 = float(int_2)
    float_1 = float(int_1)
    float_2 = float(int_0)
    class_2 = [
        class_0[int_0](),
        class_0[int_1](),
        class_0[int_2](),
        class_0[int_2](),
        class_0[int_2](),
        class_0[int_2](),
    ]
    slice_0 = slice(None, None)
    int

# Generated at 2022-06-26 02:32:26.672362
# Unit test for function make_lazy
def test_make_lazy():
    # assign
    int_0 = -255
    non_local_0 = NonLocal(int_0)
    str_0 = 'itertools'
    dict_0 = {}

    # call function make_lazy
    make_lazy(str_0)
    dict_0 = sys.modules
    non_local_0.value = dict_0[str_0]

    # assert
    assert isinstance(non_local_0.value, _LazyModuleMarker)

# Generated at 2022-06-26 02:32:46.502633
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    bool_0 = False
    run_test(test_case_0)
    non_local_1 = NonLocal(int_0)
    non_local_2 = NonLocal(bool_0)
    int_1 += 1
    int_1 += 1
    # Test passing of lazy and non-lazy modules to TestCase.addModule(module)
    # and TestCase.addImportedModule(module)
    test_case_0()
    int_1 += 1
    int_1 += 1
    # Test passing of lazy and non-lazy modules to TestCase.addImportedModule(module)
    test_case_0()
    # Test passing of lazy and non-lazy modules to TestCase.addImportedModule(module)
   

# Generated at 2022-06-26 02:32:54.677527
# Unit test for function make_lazy
def test_make_lazy():
    try:
        # Test without real import
        make_lazy('abc')
        import abc
        assert abc.__class__.__name__ == 'LazyModule'
        assert isinstance(abc, _LazyModuleMarker)
        assert abc.__mro__() == (abc.__class__, ModuleType)
    except:
        assert False

    try:
        # Test with real import
        make_lazy('collections')
        import collections
        assert collections.__class__.__name__ == 'module'
        assert not isinstance(collections, _LazyModuleMarker)
        assert collections.__mro__() == (collections.__class__, object)
    except:
        assert False


# Generated at 2022-06-26 02:32:56.101207
# Unit test for function make_lazy
def test_make_lazy():
    import pycbc.waveform
    assert pycbc.waveform is not None



# Generated at 2022-06-26 02:33:07.436105
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    print("Testing function make_lazy")
    try:
        make_lazy("datetime")
        assert "datetime" not in sys.modules
        assert type(datetime) is _LazyModuleMarker
        assert isinstance(datetime, _LazyModuleMarker)
        assert datetime.datetime.__name__ == "datetime"
        assert "datetime" in sys.modules
        assert type(datetime) is not _LazyModuleMarker
        assert not isinstance(datetime, _LazyModuleMarker)
    except FileNotFoundError:
        print("Skipping function test for function make_lazy")

test_make_lazy()
test_case_0()

# Generated at 2022-06-26 02:33:15.055724
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for make_lazy.
    """
    # Try to make lazy an already loaded module
    module_path = 'string'
    if module_path in sys.modules:
        del sys.modules[module_path]
    make_lazy(module_path)
    assert sys.modules[module_path] is not None
    assert module_path in sys.modules
    assert sys.modules[module_path] is not None
    assert sys.modules[module_path].find is not None
    assert sys.modules[module_path].find('s') == 0
    assert sys.modules[module_path].find('a') == -1

    # Lazy loading a module and using it
    module_path = 'string'
    if module_path in sys.modules:
        del sys.modules[module_path]
   

# Generated at 2022-06-26 02:33:28.419331
# Unit test for function make_lazy

# Generated at 2022-06-26 02:33:40.512077
# Unit test for function make_lazy
def test_make_lazy():
    # Source: 7_lazy_loading_and_non_local.py
    int_0 = -255
    non_local_0 = NonLocal(int_0)
    str_0 = 'lazy'
    make_lazy(str_0)
    module_0 = sys.modules[str_0]
    test_0 = isinstance(module_0, _LazyModuleMarker)
    assert __main__._LazyModuleMarker is _LazyModuleMarker # should be true
    assert non_local_0.value == int_0 # should be true
    assert test_0 # should be true
    assert __main__.ModuleType is ModuleType # should be true

# Test _LazyModuleMarker

# Generated at 2022-06-26 02:33:42.547710
# Unit test for function make_lazy
def test_make_lazy():
    assert test_case_0() != None


# Generated at 2022-06-26 02:33:52.259025
# Unit test for function make_lazy
def test_make_lazy():
    """
        Non-local assignment OR nonlocal keyword isn't supported on python 2.6 and below
    """
    if sys.version_info < (2, 7):
        import nose
        raise nose.SkipTest()

    # Test function make_lazy
    # Do a non-local assignment
    make_lazy('make_lazy')
    try:
        assert isinstance(make_lazy, _LazyModuleMarker)
        assert isinstance(make_lazy.__mro__(), _LazyModuleMarker)
    # Do a non-local assignment
        assert isinstance(NonLocal, _LazyModuleMarker)
        assert isinstance(NonLocal.__mro__(), _LazyModuleMarker)
    finally:
        # Do a non-local assignment
        del make_lazy.__mro__.__

# Generated at 2022-06-26 02:34:04.389718
# Unit test for function make_lazy
def test_make_lazy():
    # Check if the function can handle the import operation
    module_name = b'os'
    module_path_0 = module_name
    make_lazy(module_path_0)
    lazy_module_0 = sys.modules[module_path_0]
    lazy_module_attr_0 = dir(lazy_module_0)
    assert_true(isinstance(lazy_module_0, _LazyModuleMarker))
    assert_true(isinstance(lazy_module_0, (ModuleType)))
    assert_equal(len(lazy_module_attr_0), 1)
    os_attr_0 = dir(os)
    assert_equal(len(os_attr_0), len(lazy_module_attr_0))

# Generated at 2022-06-26 02:34:20.081100
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:34:23.369749
# Unit test for function make_lazy
def test_make_lazy():
    local_0 = NonLocal(None)

    test_case_0()

    non_local_0 = local_0.value
    assert non_local_0 == -255



# Generated at 2022-06-26 02:34:24.681725
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:34:28.377575
# Unit test for function make_lazy
def test_make_lazy():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:34:37.080198
# Unit test for function make_lazy
def test_make_lazy():
    # Test reading from a dict that isn't loaded
    make_lazy('_pytest.python')
    # Test the dict with a non-existent key

    try:
        return_value_0 = _pytest.python.non_existent_key
    except AttributeError:
        pass

    # Test the dict with an actual key
    return_value_1 = _pytest.python.PYTEST_VERSION

    # Write to the dict
    _pytest.python.new_key = True

    # Test that the write was successful

    try:
        return_value_2 = _pytest.python.new_key
    except AttributeError:
        pass

    # Test reading from a dict that isn't loaded
    make_lazy('_pytest.python')
    # Test the dict with a non-existent key


# Generated at 2022-06-26 02:34:41.178725
# Unit test for function make_lazy
def test_make_lazy():
    # SUT
    make_lazy('__main__')

    assert_true(int_0 == -255)
    non_local_0.value = 42
    assert_true(int_0 == 42)

if __name__ == "__main__":
    # test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:34:52.692481
# Unit test for function make_lazy
def test_make_lazy():
    # This should import the module at the time of the call, but not
    # immediately.
    make_lazy('foo.bar')
    # This should import the module immediately.
    import foo.bar
    # This should keep the module from being imported until we actually
    # use something off of it.
    from foo import bar
    int_0 = -255
    non_local_0 = NonLocal(int_0)
    if __debug__:
        string_0 = 'foo.bar'
        assert sys.modules[string_0] is bar
        assert not isinstance(bar, _LazyModuleMarker)
    int_1 = 1
    non_local_1 = NonLocal(int_1)
    if __debug__:
        int_2 = 3
        non_local_2 = NonLocal(int_2)


# Generated at 2022-06-26 02:35:00.792098
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import functools
    from sys import gettrace
    from types import ModuleType
    from types import TracebackType
    from os import name
    from sys import modules
    from test_utils import _get_var
    from test_utils import _set_var
    import six

    class NonLocal(object):
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    def make_lazy(module_path):
        sys_modules = sys_modules_0
        module = module_0
        class LazyModule(LazyModule_0):
            def __mro__(self):
                return (LazyModule, ModuleType)


# Generated at 2022-06-26 02:35:09.520419
# Unit test for function make_lazy
def test_make_lazy():
    # Testing ValueError: 
    # A positional argument is expected.
    with raises(ValueError):
        make_lazy()
    # Testing AttributeError: 
    # Unable to retrieve attribute 'value'.
    with raises(AttributeError):
        # Check if test_case_0() is stored in sys.modules
        if 'test_case_0' not in sys.modules:
            test_case_0()
        # Check if the module has been imported as a non local variable
        assert isinstance(non_local_0, NonLocal)

# Test if the module is not yet imported

# Generated at 2022-06-26 02:35:19.657842
# Unit test for function make_lazy
def test_make_lazy():
    import io
    import sys
    capturedOutput = io.StringIO()

    # py2 and py3 compatible
    module_path = 'email.message'
    try:
        module = __import__(module_path, globals(), locals(), [], 0)
    except ImportError:
        module_path = 'email.message'
        module = __import__(module_path)

    assert not isinstance(module, _LazyModuleMarker)
    make_lazy(module_path)

    try:
        module = __import__(module_path, globals(), locals(), [], 0)
    except ImportError:
        module_path = 'email.message'
        module = __import__(module_path)

    assert isinstance(module, _LazyModuleMarker)

    message = module.Message()