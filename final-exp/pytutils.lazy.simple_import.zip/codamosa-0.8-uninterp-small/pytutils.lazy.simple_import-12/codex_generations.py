

# Generated at 2022-06-26 02:26:00.257993
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    # Test whether module is lazily loaded or not
    assert 'os' not in sys.modules

    os = sys.modules['os']
    assert os is not None

    # Test whether 'os' is a lazy module or not
    assert not isinstance(os, _LazyModuleMarker)

# Generated at 2022-06-26 02:26:04.559610
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('lazy')
    assert sys.modules['lazy'] is not None
    import lazy
    assert sys.modules['lazy'] is not None
    assert not isinstance(lazy, _LazyModuleMarker)
    assert isinstance(lazy, types.ModuleType)

# Generated at 2022-06-26 02:26:11.587583
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import datetime
        del sys.modules['datetime']
    except ImportError:
        pass

    make_lazy('datetime')
    assert 'datetime' in sys.modules
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)

    # Be careful with my alias
    dt = datetime
    assert 'datetime' in sys.modules
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)

    assert not isinstance(dt, _LazyModuleMarker)
    assert isinstance(dt.datetime, ModuleType)
    assert dt.datetime is sys.modules['datetime']


# Function code is copied from Python3.7 Lib/test/test_importlib/__init__.py

# Generated at 2022-06-26 02:26:21.780562
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'test_modules.consumer'

    # Make sure module is imported
    import test_modules.consumer  # noqa

    # Make it lazy
    make_lazy(module_name)

    # Is it lazy?
    assert isinstance(test_modules.consumer, _LazyModuleMarker)
    assert not isinstance(test_modules.consumer, ModuleType)

    # Import
    from test_modules.consumer import consumer1

    # Is it lazy?
    assert isinstance(test_modules.consumer, ModuleType)
    assert not isinstance(test_modules.consumer, _LazyModuleMarker)

    # Try to use it
    consumer1()

    # Make it lazy
    make_lazy(module_name)

    # Is it lazy?

# Generated at 2022-06-26 02:26:26.646477
# Unit test for function make_lazy
def test_make_lazy():
    module_name = "Lazy_Module1"

    make_lazy(module_name)

    # Check that the module is lazy
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # Check that the module can be imported
    module = __import__(module_name)
    assert module

    # Check that the module was not lazy after importing
    assert not isinstance(module, _LazyModuleMarker)



# Generated at 2022-06-26 02:26:30.852222
# Unit test for function make_lazy
def test_make_lazy():
    assert config.MLPerf_Log_Path == './'
    make_lazy('mlperf_loadgen.log')
    assert config.MLPerf_Log_Path == './mlperf_loadgen.log/'

# Generated at 2022-06-26 02:26:32.857837
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("django.db")
    assert "django" not in sys.modules


# Generated at 2022-06-26 02:26:38.549543
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('inspect')

    # Check if the function was imported properly
    assert hasattr(sys.modules['inspect'], 'signature')

    # Check if the module is lazy
    assert isinstance(sys.modules['inspect'], _LazyModuleMarker)

    # Check if the module is still lazy
    assert isinstance(sys.modules['inspect'], _LazyModuleMarker)



# Generated at 2022-06-26 02:26:42.027867
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('foo.bar')
        assert True
    except NameError:
        assert False
    else:
        assert False

# Generated at 2022-06-26 02:26:52.725827
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        def test(self):
            return 1234

    before_0 = sys.modules['__main__']
    assert 'A' not in sys.modules

    make_lazy('__main__')

    after_0 = sys.modules['__main__']
    assert 'A' not in sys.modules

    assert isinstance(after_0, _LazyModuleMarker)

    lazy_module_marker_0 = sys.modules['__main__']

    assert isinstance(lazy_module_marker_0, _LazyModuleMarker)

    # module is not initialized yet
    try:
        foo = A()
    except NameError:
        pass
    else:
        assert False, 'Module is not initialized yet'

    # module is initialized
    foo = A()
    assert foo.test

# Generated at 2022-06-26 02:27:02.970962
# Unit test for function make_lazy
def test_make_lazy():
    assert 'mod' not in sys.modules

    module_path = 'mod'
    make_lazy(module_path)
    mod = sys.modules['mod']

    assert sys.modules['mod'] is mod

    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)

    # This triggers the actual import to happen
    mod.something

    assert 'mod' in sys.modules
    assert sys.modules['mod'] is mod
    assert isinstance(mod, ModuleType)
    assert not isinstance(mod, _LazyModuleMarker)



# Generated at 2022-06-26 02:27:04.910051
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('test')
    except TypeError:
        assert False
    else:
        assert True



# Generated at 2022-06-26 02:27:07.360317
# Unit test for function make_lazy
def test_make_lazy():
    # Ensure that the function behaves as expected
    make_lazy(test_case_0)
    assert isinstance(test_case_0, _LazyModuleMarker)

# Generated at 2022-06-26 02:27:17.911217
# Unit test for function make_lazy
def test_make_lazy():
    import types
    import os
    import sys
    from types import ModuleType
    import math
    import string
    import random
    # Verifying that a math module is loaded and working normally
    assert math.cos(1) != None
    # Testing if the math module is a type of module
    assert isinstance(sys.modules["math"], ModuleType)
    # Making the math module lazy
    make_lazy("math")
    # Verifying that the math module is now lazy
    assert isinstance(sys.modules["math"], _LazyModuleMarker)
    # Verifying that the math module is not reloaded after being made lazy
    assert math.cos(1) != None
    # Verifying that a string module is loaded and working normally
    assert string.ascii_lowercase != None
    # Testing if the string module is a type of module

# Generated at 2022-06-26 02:27:26.467971
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = []
    module_path_0 = ['__builtins__',
                     '__file__',
                     '__name__',
                     '__package__',
                     'make_lazy']
    module_path_1 = ['__builtins__',
                     '__file__',
                     '__name__',
                     '__package__',
                     'test_case_0']

    result = make_lazy('test_case_0')

    assert result is None
    assert sys.modules['test_case_0'] is not None
    assert sys.modules['test_case_0'] is not None
    assert isinstance(sys.modules['test_case_0'], _LazyModuleMarker)

# Generated at 2022-06-26 02:27:29.141781
# Unit test for function make_lazy
def test_make_lazy():
    # TODO: Re-implement this
    # This can't be tested in standard python until we have
    # an easy way to add an attribute to the module for this
    # function.
    pass

# Generated at 2022-06-26 02:27:39.730041
# Unit test for function make_lazy
def test_make_lazy():
    # Store current sys.modules state
    sys_modules = sys.modules.copy()
    # Test for function make_lazy
    if sys.version_info.major == 3:
        test_module_path = 'test_module_path_3'
    else:
        test_module_path = 'test_module_path_2'

    # Lazy module not loaded yet
    print('Lazy module not loaded yet')
    assert test_module_path not in sys.modules

    # Create Lazy Module
    print('Create Lazy Module')
    make_lazy(test_module_path)

    # Lazy module not loaded yet
    print('Lazy module not loaded yet')
    assert test_module_path in sys.modules
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)


# Generated at 2022-06-26 02:27:48.839425
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    assert not isinstance(sys.modules['log_lib'].logging, ModuleType)
    #
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    assert isinstance(sys.modules['log_lib'].logging, _LazyModuleMarker)
    #

# Generated at 2022-06-26 02:27:59.268991
# Unit test for function make_lazy
def test_make_lazy():
  FOO0 = "foo0"
  FOO1 = "foo1"
  FOO2 = "foo2"
  FOO3 = "foo3"
  FOO4 = "foo4"
  FOO5 = "foo5"
  FOO6 = "foo6"
  FOO7 = "foo7"
  FOO8 = "foo8"
  FOO9 = "foo9"
  BAR0 = "bar0"
  BAR1 = "bar1"
  BAR2 = "bar2"
  BAR3 = "bar3"
  BAR4 = "bar4"
  BAR5 = "bar5"
  BAR6 = "bar6"
  BAR7 = "bar7"
  BAR8 = "bar8"
  BAR9 = "bar9"

# Generated at 2022-06-26 02:28:08.696029
# Unit test for function make_lazy
def test_make_lazy():
    class Mod:
        def __init__(self):
            self.x = "foo"

    old_modules = sys.modules.copy()
    try:
        mod = Mod()
        sys.modules["x.foo"] = mod
        make_lazy("x.foo")
        assert isinstance(sys.modules["x.foo"], _LazyModuleMarker)
        assert sys.modules["x.foo"].__mro__() == (_LazyModuleMarker, ModuleType)
        assert sys.modules["x.foo"].x == "foo"
    finally:
        sys.modules = old_modules


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:28:16.885187
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules = {}
    assert 'sys' not in sys.modules
    make_lazy('sys')  # noqa
    assert 'sys' in sys.modules
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)
    assert not isinstance(sys.modules['sys'], ModuleType)

    # Acessing the module will import it.
    assert sys.modules['sys'].maxsize != 0

# Generated at 2022-06-26 02:28:21.621362
# Unit test for function make_lazy
def test_make_lazy():

    assert(isinstance(sys.modules[__name__], _LazyModuleMarker))

    def run_test():
        func_0 = make_lazy
        func_0(__name__)
        assert(sys.modules[__name__] is not None)

    main(run_test)


# Generated at 2022-06-26 02:28:26.826227
# Unit test for function make_lazy
def test_make_lazy():

    import sys
    import cmath

    make_lazy('cmath')

    assert(sys.modules['cmath'] is not None)
    assert(isinstance(sys.modules['cmath'], _LazyModuleMarker))

    # This should trigger the module load
    assert(cmath.pi == math.pi)



# Generated at 2022-06-26 02:28:27.933600
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:28:38.533520
# Unit test for function make_lazy
def test_make_lazy():
    from typing import List

    class A:
        pass

    class B:
        pass

    make_lazy('test.a')
    module_0 = sys.modules['test.a']  # type: module, None

    if isinstance(module_0, _LazyModuleMarker):
        if hasattr(module_0, 'A'):
            pass
        else:
            module_0.A = A

        if hasattr(module_0, 'B'):
            pass
        else:
            module_0.B = B

    else:
        if hasattr(module_0, 'A'):
            pass
        else:
            module_0.A = A

        if hasattr(module_0, 'B'):
            pass
        else:
            module_0.B = B

    list_1

# Generated at 2022-06-26 02:28:49.720506
# Unit test for function make_lazy
def test_make_lazy():
    # We test with a module that is not real so that
    # we can ensure we do not bring something into sys.modules
    # that will be imported, but we can't "unimport" it.
    make_lazy('lib.leap.bitmask.keymanager.lazymoduletest.fakemodule')

    local_module = sys.modules['lib.leap.bitmask.keymanager.lazymoduletest.fakemodule']

    assert isinstance(local_module, _LazyModuleMarker)

    attribute = local_module.attribute

    assert attribute == 'value'

    # Make sure the import happened
    assert 'lib.leap.bitmask.keymanager.lazymoduletest.fakemodule' in sys.modules

    # Make sure we dont' have a LazyModule type left behind

# Generated at 2022-06-26 02:28:51.616182
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import test_lazy
    except ImportError:
        raise AssertionError()



# Generated at 2022-06-26 02:29:01.910118
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    module_path = '__main__'
    module = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            if module.value is None:
                del sys_modules[module_path]
                module.value = __import__(module_path)
                sys_modules[module_path] = __import__(module_path)

            return getattr(module.value, attr)

    sys_modules[module_path] = LazyModule()


# Generated at 2022-06-26 02:29:05.709394
# Unit test for function make_lazy
def test_make_lazy():
    module_dict = sys.modules
    test_make_lazy_0 = module_dict['sphinx.util.testing']

    module = NonLocal(1)

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """

        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (LazyModule, ModuleType)


# Generated at 2022-06-26 02:29:09.079549
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy()
    # test lazy import
    import lazy_import
    # test lazy import
    from lazy_import import bar


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:29:13.085465
# Unit test for function make_lazy
def test_make_lazy():
    conftest_lazy = make_lazy('conftest')
    assert not isinstance(conftest_lazy, ModuleType)



# Generated at 2022-06-26 02:29:16.215891
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules.copy()
    f_0 = nonlocal_module.f_0
    f_1 = nonlocal_module.f_1
    test_case_0()


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:29:16.728903
# Unit test for function make_lazy
def test_make_lazy():
    pass # TODO

# Generated at 2022-06-26 02:29:23.399797
# Unit test for function make_lazy
def test_make_lazy():
    # Setup test environment
    sys.modules['this.is.a.test.module'] = 'something'

    make_lazy('this.is.a.test.module')

    assert not hasattr(sys.modules['this.is.a.test.module'], '__name__')

    # import the module, then use it
    if hasattr(sys.modules['this.is.a.test.module'], '__name__'):
        pass

    assert sys.modules['this.is.a.test.module'] == 'something'



# Generated at 2022-06-26 02:29:28.038286
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    m = sys.modules.copy()

    try:
        make_lazy('django.http.request')
        assert('django.http.request' in sys.modules)

        import django.http.request
        assert('django.http.request' in sys.modules)

    finally:
        sys.modules = m



# Generated at 2022-06-26 02:29:31.122712
# Unit test for function make_lazy
def test_make_lazy():
    try:
        os
    except NameError:
        raise NameError('Module os not found')
        os = None
    make_lazy(None)
    assert_equals(os, None)



# Generated at 2022-06-26 02:29:34.864115
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    list_0 = None
    non_local_0 = NonLocal(list_0)
    module_path = 'string'
    make_lazy(module_path)
    list_1 = sys.modules
    tup_0 = (module_path, list_1[module_path])
    list_2 = [tup_0]
    list_1 = sys.modules
    tup_1 = (module_path, list_1[module_path])
    list_3 = [tup_1]
    assert list_2 == list_3


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:29:41.546470
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    module_path = 'os'
    make_lazy(module_path)
    non_local_0 = NonLocal(list_0)
    os = None
    non_local_0 = NonLocal(os)
    os = None
    non_local_0 = NonLocal(os)
    os = None
    non_local_0 = NonLocal(os)
    os = None
    non_local_0 = NonLocal(os)
    os = None
    non_local_0 = NonLocal(os)


# Generated at 2022-06-26 02:29:48.593462
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules["os"] = object()
    make_lazy("os")
    assert isinstance(sys.modules["os"], _LazyModuleMarker)
    assert isinstance(sys.modules["os"], ModuleType)
    assert not hasattr(sys.modules["os"], "path")
    path = sys.modules["os"].path
    assert not isinstance(sys.modules["os"], _LazyModuleMarker)
    assert isinstance(path, ModuleType)
    del sys.modules["os"]



# Generated at 2022-06-26 02:29:52.532235
# Unit test for function make_lazy
def test_make_lazy():
    """
Testing function make_lazy. Calling make_lazy gives a LazyModuleMarker.
    """
    mod = make_lazy("test_module")
    assert isinstance(mod, _LazyModuleMarker)


# Generated at 2022-06-26 02:29:57.913769
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)


# Generated at 2022-06-26 02:30:01.315947
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test'] = ModuleType('test')
    make_lazy('test')
    assert isinstance(sys.modules['test'], _LazyModuleMarker)
    sys.modules.pop('test')

# Generated at 2022-06-26 02:30:01.919844
# Unit test for function make_lazy
def test_make_lazy():
    assert True

# Generated at 2022-06-26 02:30:11.146199
# Unit test for function make_lazy

# Generated at 2022-06-26 02:30:19.617013
# Unit test for function make_lazy
def test_make_lazy():
    def make_lazy(module_path):
        sys_modules = sys.modules  # cache in the locals

        # store our 'instance' data in the closure.
        module = NonLocal(None)

        class LazyModule(_LazyModuleMarker):
            def __mro__(self):
                return (LazyModule, ModuleType)

            def __getattribute__(self, attr):
                if module.value is None:
                    del sys_modules[module_path]
                    module.value = __import__(module_path)

                    sys_modules[module_path] = __import__(module_path)

                return getattr(module.value, attr)

        sys_modules[module_path] = LazyModule()

# Generated at 2022-06-26 02:30:28.766268
# Unit test for function make_lazy
def test_make_lazy():
    # Test function make_lazy to ensure the followings:
    # (1) it will import the module if some attribute of the module is accessed.
    # (2) it will not import the module if no attribute of the module is accessed.
    # (3) the modules it imports are the ones with paths passed to it.
    # (4) the modules are being imported only once.

    # create a module to be imported by make_lazy.
    # it is a module that contains a list of numbers.
    import os
    import tempfile

    fd, temp_file_name = tempfile.mkstemp()
    os.close(fd)

    # the number list will be accessed later in order to check (1).
    module_content = 'num_list = [1, 2, 3]'

# Generated at 2022-06-26 02:30:31.517262
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'copy'

    make_lazy(module_path)

    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:30:41.246234
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)
    non_local_0.value = sys.modules
    non_local_0.value = non_local_0.value.pop('platform', None)
    non_local_0.value = [sys.modules.__setitem__]
    non_local_0.value = non_local_0.value[0]
    non_local_0.value('platform', None)
    make_lazy('platform')
    non_local_0.value = sys.modules.platform
    non_local_0.value = type(non_local_0.value)
    # Test with line "make_lazy('platform')"
    assert isinstance(sys.modules.platform, _LazyModuleMarker) is True
    # Test with line "

# Generated at 2022-06-26 02:30:51.331967
# Unit test for function make_lazy
def test_make_lazy():
    l = []

    def update_l(value):
        l.append(value)
        return l

    def test_0():
        sys_modules = sys.modules  # cache in the locals

        # store our 'instance' data in the closure.
        module_0 = NonLocal(None)

        class LazyModule(_LazyModuleMarker):
            """
            A standin for a module to prevent it from being imported
            """
            def __mro__(self):
                """
                Override the __mro__ to fool `isinstance`.
                """
                # We don't use direct subclassing because `ModuleType` has an
                # incompatible metaclass base with object (they are both in c)
                # and we are overridding __getattribute__.
                # By putting a __mro__ method here, we can pass `

# Generated at 2022-06-26 02:31:02.725570
# Unit test for function make_lazy
def test_make_lazy():
    import sys as sys_0
    import collections as collections_0
    for __counter0 in range(13):
        attr_0 = test_make_lazy.__name__
        if (attr_0 == '__getattribute__'):
            if (list_0 is None):
                pass
            return
        if (attr_0 == '__mro__'):
            if (list_0 is None):
                pass
            return
        if (attr_0 == '__getattribute__'):
            if (non_local_0.value is None):
                non_local_0 = NonLocal(collections_0)
            return
        if (attr_0 == '__mro__'):
            if (non_local_0.value is None):
                non_local_0 = NonLocal(collections_0)


# Generated at 2022-06-26 02:31:12.879509
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    assert (not isinstance(sys.modules[__name__], _LazyModuleMarker))
    make_lazy(__name__)
    assert (isinstance(sys.modules[__name__], _LazyModuleMarker))

# Generated at 2022-06-26 02:31:20.107205
# Unit test for function make_lazy
def test_make_lazy():
    # Default test
    make_lazy("lazy_module_test")
    sys_modules = sys.modules
    if "lazy_module_test" in sys_modules:
        if sys_modules["lazy_module_test"].__class__ == "lazy_module_test":
            pass
        else:
            raise Exception("Returned incorrect result")
    else:
        raise Exception("Returned incorrect result")
    sys.modules = sys_modules


# Generated at 2022-06-26 02:31:30.425892
# Unit test for function make_lazy
def test_make_lazy():
    re_0 = NonLocal(None)
    sys_modules_0 = sys.modules
    make_lazy('re')
    temp_0 = __import__('re')
    assert isinstance(temp_0, _LazyModuleMarker)
    del sys_modules_0['re']
    re_0.value = __import__('re')
    assert not isinstance(re_0.value, _LazyModuleMarker)
    sys_modules_0['re'] = __import__('re')

# Call the test functions
test_case_0()
test_make_lazy()

# Generated at 2022-06-26 02:31:34.411926
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('sys')

        # Test that we don't import sys
        import sys
        assert sys.__class__.__name__ == 'LazyModule'
    finally:
        sys.modules.pop('sys')

# Generated at 2022-06-26 02:31:42.721178
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import string
    import random
    import os
    import shutil
    from random import randint
    from os.path import abspath, dirname

    # Import our module to test on
    import test

    # Remove the module if it is already in sys.modules
    if "test" in sys.modules:
        del sys.modules["test"]

    # Load our module to test on
    test.__name__ = 'test'
    module = NonLocal(None)
    module.value = test
    sys.modules["test"] = module.value

    # Mock our module path to be lazy
    test_path = 'test'
    module_file = abspath(test.__file__)
    dir_name = dirname(module_file)
    test_file = abspath(test_path + '.py')
   

# Generated at 2022-06-26 02:31:51.827706
# Unit test for function make_lazy
def test_make_lazy():
    # Call function make_lazy with argument values
    # in order to initialize the type store
    make_lazy("fake_module")

    my_module = sys.modules["fake_module"]
    assert isinstance(my_module, _LazyModuleMarker)

    # Test that it fails before we 'touch' it

# Generated at 2022-06-26 02:32:02.649207
# Unit test for function make_lazy
def test_make_lazy():
    modules_0 = None
    non_local_0 = NonLocal(None)
    # non_local_0 = NonLocal(modules_0)
    def LazyModule_make_lazy_0(self):
        # non_local_0 = NonLocal(modules_0)
        non_local_0 = NonLocal(None)

# Generated at 2022-06-26 02:32:03.583092
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('test')
    assert sys.modules['test']  # is not None

# Generated at 2022-06-26 02:32:14.077890
# Unit test for function make_lazy
def test_make_lazy():
    import sys, os, subprocess

    def _mangle_path(file_name):
        return file_name + "_mangled"

    def _assert_mangled(file_name):
        return os.path.exists(file_name) and os.path.isfile(file_name)

    def _unmangle_path(file_name):
        os.remove(file_name)

    def _assert_not_mangled(file_name):
        return not os.path.exists(file_name)
    
    module_name = "simple_lazy_tests"
    test_module_name = module_name + ".tests"
    
    # not mangled
    assert not _assert_mangled(_mangle_path(test_module_name))

    # mangled

# Generated at 2022-06-26 02:32:23.354903
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import test.test_support

    def test_function(module_path):
        make_lazy(module_path)
        mod = sys.modules[module_path]
        assert not isinstance(mod, ModuleType)
        assert isinstance(mod, _LazyModuleMarker)

        # should not exist until we use it.
        assert not hasattr(mod, '__doc__')

        # now it should exist
        assert mod.__doc__ == 'test module'

        # and now it should be a normal module
        assert isinstance(mod, ModuleType)


    test_function('test.test_support')
    test_function('multiprocessing.process')



# Generated at 2022-06-26 02:32:37.520994
# Unit test for function make_lazy
def test_make_lazy():
    # Test case 1
    make_lazy('lazy_module')
    # Test case 2
    make_lazy('lazy_module')
    # Test case 3
    try:
        make_lazy(None)
    except TypeError as e:
        pass
    # Test case 4
    try:
        make_lazy('')
    except ValueError as e:
        pass

# Testing for function test_case_0

# Generated at 2022-06-26 02:32:41.561595
# Unit test for function make_lazy
def test_make_lazy():
    names = [
        "test.test_lazy_imports.test_case_{}".format(i)
        for i in range(1)
    ]
    for name in names:
        make_lazy(name)


test_make_lazy()

# Generated at 2022-06-26 02:32:43.090496
# Unit test for function make_lazy
def test_make_lazy():
    print("Test make_lazy")
    make_lazy("make_lazy")


# Generated at 2022-06-26 02:32:49.995425
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = ['d', 'h', 'l']
    list_0[0] = list_0
    mod_path = '.'.join(map(lambda s_0: ''.join(s_0), list_0))
    list_0 = sys.modules.copy()
    make_lazy(mod_path)
    # AssertionError: module not found: ._hl
    assert sys.modules[mod_path]
    assert list_0.items() == sys.modules.items()


# Generated at 2022-06-26 02:32:55.311340
# Unit test for function make_lazy
def test_make_lazy():
    # Verify we can't see the value until it is set.
    mod = sys.modules['test_make_lazy']
    with pytest.raises(AttributeError):
        mod.THIS_SHOULD_NOT_BE_THERE_YET
    with pytest.raises(KeyError):
        mod.__dict__

    mod.THIS_SHOULD_NOT_BE_THERE_YET = 'test'

    # Verify that we can see the value after it is set.
    assert mod.THIS_SHOULD_NOT_BE_THERE_YET == 'test'

    assert isinstance(mod, _LazyModuleMarker)



# Generated at 2022-06-26 02:32:58.473771
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = ['aa', 'bb', 'cc']
    non_local_0 = NonLocal(list_0)
    assert(list_0 is non_local_0.value)

test_make_lazy()

# Generated at 2022-06-26 02:33:03.529606
# Unit test for function make_lazy
def test_make_lazy():
    assert(1==1)
    try:
        non_local_0 = NonLocal(list_0)
        make_lazy(non_local_0)
    except:
        # non_local_0 is not a defined name in this module
        assert(1==1)


# Generated at 2022-06-26 02:33:08.373830
# Unit test for function make_lazy
def test_make_lazy():
    from django.conf import settings

    list_0 = None
    non_local_0 = NonLocal(list_0)
    make_lazy(settings.DEFAULT_AUTHENTICATION_BACKENDS)
    non_local_0.value.append("this_is_a_string")

# Generated at 2022-06-26 02:33:15.506149
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)

    list_0 = sys.modules
    del list_0['__builtin__']
    list_0 = sys.modules.popitem()
    list_0 = sys.modules
    del list_0['__builtin__']
    list_0 = sys.modules.popitem()
    list_0 = sys.modules
    del list_0['__builtin__']
    list_0 = sys.modules.popitem()
    list_0 = sys.modules
    del list_0['__builtin__']
    list_0 = sys.modules.popitem()
    list_0 = sys.modules
    del list_0['__builtin__']
    list_0 = sys.modules.popitem()

# Generated at 2022-06-26 02:33:28.519746
# Unit test for function make_lazy
def test_make_lazy():
    import foo.foo
    import foo.bar

    assert foo.foo.starts_with_foo() == True
    assert foo.bar.starts_with_foo() == False

    # The modules where not loaded yet.
    make_lazy('foo.foo')
    make_lazy('foo.bar')

    # We can easily check that the modules are lazy
    assert isinstance(sys.modules['foo.foo'], _LazyModuleMarker)
    assert isinstance(sys.modules['foo.bar'], _LazyModuleMarker)

    # They functions work as expected
    assert foo.foo.starts_with_foo() == True
    assert foo.bar.starts_with_foo() == False

    assert isinstance(sys.modules['foo.foo'], _LazyModuleMarker) == False

# Generated at 2022-06-26 02:33:51.825019
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType
    from collections import OrderedDict
    from .utils import *

    def check_lazy(module_path, original_sys_modules, non_local_0):
        # Get the patched module
        mod = sys.modules[module_path]
        # Check that it's a LazyModule
        assert isinstance(mod, ModuleType)
        # Check it's not in sys.modules
#        assert module_path not in sys.modules
#        assert module_path not in original_sys_modules
        if module_path not in original_sys_modules:
            print('module_path:')
            print(module_path)
            print('original_sys_modules:')
            print(original_sys_modules)
            print('sys.modules:')
            print(sys.modules)
       

# Generated at 2022-06-26 02:33:52.725099
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('os.path')
    test_case_0()
    assert 0


# Generated at 2022-06-26 02:34:04.652932
# Unit test for function make_lazy
def test_make_lazy():
    from os.path import join
    from sys import modules
    from unittest import TestCase
    from . import module_c_0

    class TestLazyModule(TestCase):
        def test_lazy_module(self):
            make_lazy('lazy_module')
            self.assertNotIn('lazy_module', modules)

            lazy_module = modules['lazy_module']
            self.assertTrue(isinstance(lazy_module, LazyModule))
            self.assertEquals(lazy_module.foo, 'foo')

            self.assertEquals(modules['lazy_module.sub_module'],
                              module_c_0)

            lazy_module = modules['lazy_module']
            self.assertTrue(isinstance(lazy_module, LazyModule))
            self.assertEqu

# Generated at 2022-06-26 02:34:12.150786
# Unit test for function make_lazy
def test_make_lazy():
    # Write code here to test make_lazy
    list_0 = ["1", "h", "l", "o", "W", "r", "d"]
    list_1 = ["1", "s", "l", "o", "W", "r", "d"]
    non_local_0 = NonLocal(list_0)
    non_local_1 = NonLocal(list_1)
    make_lazy(non_local_0)
    make_lazy(non_local_1)

test_make_lazy()

# Generated at 2022-06-26 02:34:15.024267
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['test_module'] = None
    make_lazy('test_module')
    import test_module
    assert(isinstance(test_module, _LazyModuleMarker))
    del sys.modules['test_module']

# Generated at 2022-06-26 02:34:21.532829
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)

    assert isinstance(non_local_0, NonLocal)

    list_0 = [1, 2, 3]
    non_local_0.value = list_0
    assert non_local_0.value is list_0

    list_0 = None
    non_local_0.value = list_0
    assert non_local_0.value is list_0

    # non_local_0 uses a closure to store its value,
    # But we will just check it anyways.
    assert id(non_local_0.value) == id(list_0)


if __name__ == '__main__':
    test_case_0()
    test_make_lazy()

# Generated at 2022-06-26 02:34:27.395055
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)
    assert_true(non_local_0.value is None)
    list_0 = [1, 2, 3]
    non_local_0.value = list_0
    assert_true(non_local_0.value is list_0)


# Generated at 2022-06-26 02:34:31.895153
# Unit test for function make_lazy
def test_make_lazy():
    import six
    class NonLocal():
        pass
    nonlocal_obj = NonLocal()
    nonlocal_obj.value = 'this is a test'
    sys.modules['six'] = nonlocal_obj
    result_obj = make_lazy('six')
    assert isinstance(result_obj, NonLocal)
    return result_obj



# Generated at 2022-06-26 02:34:36.611472
# Unit test for function make_lazy
def test_make_lazy():
    list_0 = None
    non_local_0 = NonLocal(list_0)
    assert sys.modules == {}
    some_lazy_module = make_lazy("some_lazy_module")
    assert sys.modules == {"some_lazy_module": some_lazy_module}
    assert "some_lazy_module" in sys.modules

# Generated at 2022-06-26 02:34:38.880663
# Unit test for function make_lazy
def test_make_lazy():
    # First test that make_lazy doesn't modify the module if it is already
    # lazy.
    make_lazy('os')
    # It must be a LazyModule object
    mod = sys.modules['os']
    assert isinstance(mod, _LazyModuleMarker)


# Generated at 2022-06-26 02:35:13.128658
# Unit test for function make_lazy
def test_make_lazy():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:35:22.145589
# Unit test for function make_lazy

# Generated at 2022-06-26 02:35:30.317241
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    list_0 = []
    make_lazy(list_0)
    list_0.append(1)
    print(list_0)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:35:38.099438
# Unit test for function make_lazy
def test_make_lazy():
    import threading
    from inspect import getmodule
    from sys import modules

    from nose.tools import assert_equal

    from pycallgraph.testing import import_pycallgraph_for_testing

    pycallgraph_module = import_pycallgraph_for_testing()
    assert pycallgraph_module

    lazy_module_path = 'pycallgraph.testing'

    make_lazy(lazy_module_path)

    lazy_module = modules[lazy_module_path]
    assert_equal(lazy_module is not None, True)

    assert_equal(
        isinstance(lazy_module, _LazyModuleMarker),
        True,
        msg='Module was imported when it should have been lazy',
    )


# Generated at 2022-06-26 02:35:47.832427
# Unit test for function make_lazy
def test_make_lazy():
    # Must be called from the root of the project.
    if os.path.isfile('example/__init__.py') and os.path.isfile('example/example.py'):
        sys.path.insert(0, '')
        assert 'example' not in sys.modules
        make_lazy('example')
        assert isinstance(sys.modules['example'], _LazyModuleMarker)
        assert 'example.example' not in sys.modules
        imp.find_module('example')
        assert 'example' in sys.modules
        assert isinstance(sys.modules['example'], _LazyModuleMarker)
        assert 'example.example' not in sys.modules
        imp.find_module('example.example')
        assert 'example' in sys.modules
        assert 'example.example' in sys.modules
   

# Generated at 2022-06-26 02:35:57.004585
# Unit test for function make_lazy
def test_make_lazy():
     list_0 = ['0']
     sys.modules['baz'] = list_0
     non_local_0 = NonLocal(list_0)
     make_lazy('baz')
     assert sys.modules['baz'].value is None
     assert isinstance(sys.modules['baz'], _LazyModuleMarker)


if __name__ == '__main__':
    # test_make_lazy()

    # test_case_0()

    list_0 = ['0']
    sys.modules['baz'] = list_0
    non_local_0 = NonLocal(list_0)
    make_lazy('baz')
    assert sys.modules['baz'].value is None
    assert isinstance(sys.modules['baz'], _LazyModuleMarker)