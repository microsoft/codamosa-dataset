

# Generated at 2022-06-26 02:25:58.433705
# Unit test for function make_lazy
def test_make_lazy():
    for func in [test_case_0]:
        assert func() is None, func.__name__ + "() returns non-None"
    return True


# Generated at 2022-06-26 02:26:01.961796
# Unit test for function make_lazy
def test_make_lazy():
    assert ut.assert_equals('test_0', test_case_0, 'ok')

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:26:05.143857
# Unit test for function make_lazy
def test_make_lazy():
    a = 'a'
    make_lazy(a)
    sys.modules['a'] = 123
    result = make_lazy(a)
    assert result is None
    
    

# Generated at 2022-06-26 02:26:06.427553
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:26:08.033646
# Unit test for function make_lazy

# Generated at 2022-06-26 02:26:13.463613
# Unit test for function make_lazy
def test_make_lazy():
    # Need to check the construction of the class and the creation of the
    # module
    test_case_0()

# Generated at 2022-06-26 02:26:15.746068
# Unit test for function make_lazy
def test_make_lazy():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:26:16.638918
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy("sys")
    var_1 = make_lazy("math")

# Generated at 2022-06-26 02:26:18.263221
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:26:26.674120
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_1 = make_lazy(int_0)
    int_1 = 1480
    var_2 = make_lazy(int_1)
    int_2 = 1288
    var_3 = make_lazy(int_2)
    int_3 = 1152
    var_4 = make_lazy(int_3)
    int_4 = 1272
    var_5 = make_lazy(int_4)
    int_5 = 1224
    var_6 = make_lazy(int_5)
    int_6 = 1416
    var_7 = make_lazy(int_6)
    int_7 = 1248
    var_8 = make_lazy(int_7)
    int_8 = 1216
    var_9 = make_

# Generated at 2022-06-26 02:26:30.603517
# Unit test for function make_lazy
def test_make_lazy():
    """Test function make_lazy"""
    assert make_lazy(1228)== None


# Generated at 2022-06-26 02:26:31.763691
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

# Generated at 2022-06-26 02:26:34.598233
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    assert (-1) != (-1)
    assert sys.modules
    assert sys.modules
    assert callable(test_case_0)



# Generated at 2022-06-26 02:26:37.830480
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_case_0()
        print('pass test case_0')
    except NotImplementedError:
        print('failed test case_0')


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:26:39.121240
# Unit test for function make_lazy
def test_make_lazy():
    # Test Case #0
    test_case_0()



# Generated at 2022-06-26 02:26:44.492063
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)
    func_return_value_0 = make_lazy(int_0)
    assert isinstance(func_return_value_0, _LazyModuleMarker) == True


# Generated at 2022-06-26 02:26:47.589411
# Unit test for function make_lazy
def test_make_lazy():
    if not str(type(test_case_0())) == "<class '_LazyModuleMarker'>":
        raise Exception("Incorrect Type")


# Generated at 2022-06-26 02:26:50.164255
# Unit test for function make_lazy
def test_make_lazy():
    assert True;
    print("Function: ", test_make_lazy.__name__);

    test_case_0()

test_make_lazy()

# Generated at 2022-06-26 02:26:51.816611
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:26:52.878246
# Unit test for function make_lazy
def test_make_lazy():
    pass


# Tests for the Nonlocal class


# Generated at 2022-06-26 02:26:59.147617
# Unit test for function make_lazy
def test_make_lazy():
  assert "make_lazy" in globals()


# Generated at 2022-06-26 02:27:01.532961
# Unit test for function make_lazy
def test_make_lazy():
    length_0 = 1228
    var_1 = make_lazy(length_0)

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 02:27:07.791004
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)


# Compiled code for module '__main__'
code = test_case_0.func_code

# Generating the bytecode
bytecode = compile(code, '<string>', 'exec')

loop = main.find_loop(bytecode.co_firstlineno + 1)

# save locals
locals = test_case_0.func_globals

# making a closure to store our locals

# Generated at 2022-06-26 02:27:08.720040
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    return True


# Generated at 2022-06-26 02:27:19.358881
# Unit test for function make_lazy
def test_make_lazy():
    assert inspect.isfunction(make_lazy)
    assert make_lazy.__name__ == "make_lazy"
    assert inspect.getargspec(make_lazy).args == ["module_path"]
    assert isinstance(make_lazy.__closure__, tuple)
    assert len(make_lazy.__closure__) == 1
    assert isinstance(make_lazy.__closure__[0], types.CellType)
    assert isinstance(make_lazy.__code__, types.CodeType)
    assert make_lazy.__code__.co_argcount == 1
    assert make_lazy.__code__.co_kwonlyargcount == 0
    assert make_lazy.__code__.co_stacksize == 3
    assert make_lazy.__code__.co_varn

# Generated at 2022-06-26 02:27:27.164782
# Unit test for function make_lazy
def test_make_lazy():
    print("Testing make_lazy ...")

    # Check that isinstance(make_lazy(x), _LazyModuleMarker)
    assert isinstance(test_case_0(), _LazyModuleMarker)

    # Check that nonlocal module is equivalent to the module after importing
    import random
    assert test_case_0() == random

    # Check that importing the module directly is equivalent to the module after importing
    import random
    assert test_case_0() == random

    # Check that the initializatized module is equivalent to the module after importing
    import random
    assert test_case_0() == random

    # Check that making the module lazy again will not change the value of the module
    import random
    assert test_case_0() == random

    print("Passed!")


# Generated at 2022-06-26 02:27:30.176159
# Unit test for function make_lazy
def test_make_lazy():
    try:
        int_0 = 1228
        var_0 = make_lazy(int_0)
    except Exception as inst:
        print(inst)
    else:
        pass

test_make_lazy()

# Generated at 2022-06-26 02:27:32.470221
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)
    test_case_0()


# Generated at 2022-06-26 02:27:33.575208
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
    assert True



# Generated at 2022-06-26 02:27:38.598224
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'is not a module path' in str(excinfo.value)

if __name__ == "__main__":
    f1 = 'test_make_lazy'
    pytest.main('-s %s' % f1)

# Generated at 2022-06-26 02:27:47.210062
# Unit test for function make_lazy
def test_make_lazy():
    assert True == True



# Generated at 2022-06-26 02:27:56.602901
# Unit test for function make_lazy
def test_make_lazy():
    var_1 = 1230
    var_2 = 1229
    string_1 = "testing_make_lazy"
    string_2 = "int"

# Generated at 2022-06-26 02:28:05.543769
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    try:
        #https://docs.python.org/2/library/inspect.html
        from inspect import getsource
        #print 'test case 0:',getsource(test_case_0)
    except:
        #print "Failed to import inspect"
        pass
    else:
        #print 'test case 0:',getsource(test_case_0)
        make_lazy(int_0)
        assert sys.modules[str(int_0)].__class__.__name__ == 'LazyModule' 

test_make_lazy()

# vim: set ts=4 sw=4 sts=4 et:

# Generated at 2022-06-26 02:28:08.323297
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)

    if __name__ == '__main__':
        import sys
        import types
        if len(sys.argv) > 1:
            unit_test.main()
        else:
            import pystone
            benchmark.main(pystone.main)

# Generated at 2022-06-26 02:28:16.513972
# Unit test for function make_lazy
def test_make_lazy():
    # Example from manual
    make_lazy(1228)
    make_lazy(1228)
    module = sys.modules[1228]
    assert isinstance(module, _LazyModuleMarker), "Lazy module not loaded"
    module.__getattribute__('func')
    assert module.func('args') == 'called func(args)', "Function not called"
    assert module.func('args') == 'called func(args)', "Function not called"


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-26 02:28:17.812329
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)

# Generated at 2022-06-26 02:28:24.073117
# Unit test for function make_lazy
def test_make_lazy():
    int_1 = 1228
    var_1 = make_lazy(int_1)
    var_2 = type(var_1)
    assert var_2 is _LazyModuleMarker, 'var_2 should be an instance of _LazyModuleMarker'
    int_0 = 1228
    var_0 = make_lazy(int_0)

# Unit test checking that setup is working properly

# Generated at 2022-06-26 02:28:25.721432
# Unit test for function make_lazy
def test_make_lazy():

    # Call function 'test_case_0'
    test_case_0()
    


test_make_lazy()

# Generated at 2022-06-26 02:28:27.833707
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)



# Generated at 2022-06-26 02:28:38.463817
# Unit test for function make_lazy
def test_make_lazy():
    import pypy
    import inspect
    import os
    import sys
    import imp

    this_dir = os.path.dirname(os.path.abspath(inspect.getfile(test_make_lazy)))
    assert this_dir == os.path.abspath(pypy.__path__[0])
    assert hasattr(pypy, 'jit') and pypy.jit is not None
    pypy_jit_file = os.path.abspath(inspect.getsourcefile(pypy.jit))
    assert 'pypy_jit_file' in locals()
    assert 'pypy_jit_file' in globals()
    assert 'make_lazy' in locals()
    assert 'make_lazy' in globals()
    assert 'test_case_0'

# Generated at 2022-06-26 02:28:57.335405
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)
    assert var_0 is None
    assert sys.modules['1228'].__module__ == '1228'
    assert isinstance(sys.modules['1228'], _LazyModuleMarker)
    assert True



# Generated at 2022-06-26 02:28:59.214268
# Unit test for function make_lazy
def test_make_lazy():
    var_1 = 1228
    var_2 = make_lazy(var_1)


# Generated at 2022-06-26 02:29:02.487908
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    make_lazy(1228)
    assert(isinstance(sys.modules[1228], types.ModuleType))


# Generated at 2022-06-26 02:29:06.863826
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    var_0 = make_lazy(int_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:29:11.502868
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'make_lazy'
    result = make_lazy(module_path)
    assert result is None
    assert module_path in sys.modules
    assert isinstance(sys.modules['make_lazy'], _LazyModuleMarker)
    assert isinstance(sys.modules['make_lazy'], ModuleType)


# Generated at 2022-06-26 02:29:19.900923
# Unit test for function make_lazy
def test_make_lazy():
    string_arg_0 = "float"
    function_arg_0 = float
    test_case_0()
    try:
        assert_raises(TypeError, make_lazy, string_arg_0, function_arg_0)
    except AssertionError as e:
        raise AssertionError(str(e) + " - Expected error message: object of type 'type' has no len()")


if __name__ == "__main__":
    import logging
    logger = logging.getLogger(__name__)

    # Write all log lines to stdout.
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)

    test_make_lazy

# Generated at 2022-06-26 02:29:21.754428
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)


# Generated at 2022-06-26 02:29:28.323361
# Unit test for function make_lazy
def test_make_lazy():
    import sys;
    import types;
    import builtins;
    module_path = 0x33e # 1278
    assert not int(module_path) in sys.modules     # precondition
    module = make_lazy(module_path);
    assert isinstance(module, _LazyModuleMarker)
    assert not isinstance(module, builtins.type(sys.modules[module_path]))
    module.__mro__ # triggers import
    assert isinstance(sys.modules[module_path], builtins.type(test_case_0))

# Generated at 2022-06-26 02:29:29.555778
# Unit test for function make_lazy
def test_make_lazy():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:29:31.872705
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:30:01.963156
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)

# Generated at 2022-06-26 02:30:03.391751
# Unit test for function make_lazy
def test_make_lazy():
    assert False, "No tests written for function make_lazy"

# Generated at 2022-06-26 02:30:04.394700
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()


# Generated at 2022-06-26 02:30:05.898849
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = -2958
    str_0 = make_lazy(int_0)
    var_0 = sys.modules[-2958]
    

# Generated at 2022-06-26 02:30:07.675336
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['turtle_0'] = None
    assert make_lazy('turtle_0') == None


# Generated at 2022-06-26 02:30:08.603846
# Unit test for function make_lazy
def test_make_lazy():
    assert True
    test_case_0()


# Generated at 2022-06-26 02:30:09.479437
# Unit test for function make_lazy
def test_make_lazy():
    assert_equals(test_case_0(), None)

# Generated at 2022-06-26 02:30:12.160902
# Unit test for function make_lazy
def test_make_lazy():

  try:
    assert callable(test_case_0)
    test_case_0()
  except AssertionError as e:
    print(e)
    raise AssertionError('test_make_lazy() failed')

# Generated at 2022-06-26 02:30:14.322621
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure it returns None.
    assert test_case_0() == None

# ______________________________________________________________________________

# A function to test that a module is lazy.

# Generated at 2022-06-26 02:30:23.777658
# Unit test for function make_lazy
def test_make_lazy():
    from test_support import run_unittest
    from test_support import TestFailed

    class Test_make_lazy(unittest.TestCase):
        def test_0(self):
            '''Tests that changing a variable as in the example works'''

            # XXX: don't understand why we need to do this
            self.assertRaises(AttributeError, getattr, sys.modules, 'int_0')

            # Test that _LazyModuleMarker exists and can be used to
            # detect if a module is lazy.
            self.assertTrue(hasattr(_LazyModuleMarker, '__mro__'))
            self.assertTrue(hasattr(_LazyModuleMarker, '__getattribute__'))

            # Test that when make_lazy is called, it creates our fake module
            # and sets it in

# Generated at 2022-06-26 02:31:28.844438
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_case_0()
    except Exception as e:
        test_failure_message(str(e))


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:31:30.852240
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)



# Generated at 2022-06-26 02:31:33.259834
# Unit test for function make_lazy
def test_make_lazy():
    test_case_0()
# END Unit tests

# Parse command line arguments


# Generated at 2022-06-26 02:31:35.301768
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(NameError):
        test_case_0()


# call the function
test_make_lazy()

# Generated at 2022-06-26 02:31:38.649239
# Unit test for function make_lazy
def test_make_lazy():
    array_0 = Array(ptr_of_int)
    array_1 = Array(ptr_of_int)
    ptr_0 = array_0
    ptr_1 = array_1
    assert ptr_0 == ptr_1

# Generated at 2022-06-26 02:31:39.370365
# Unit test for function make_lazy
def test_make_lazy():
    assert True is True

# Generated at 2022-06-26 02:31:43.340624
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(KeyError):
        test_case_0()



if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-26 02:31:48.576685
# Unit test for function make_lazy
def test_make_lazy():
    assert not os.path.isfile("/home/majunya/Workspaces/idea/python/test.py")
    # make_lazy("/home/majunya/Workspaces/idea/python/test.py")
    import test
    assert test.var_0 == "test"



# Generated at 2022-06-26 02:31:52.882792
# Unit test for function make_lazy
def test_make_lazy():
    from test_utilities import compare_ast
    test_path = "test/resources/test_make_lazy.py"
    expected_path = "test/resources/test_make_lazy_expected.py"
    compare_ast(test_path, expected_path, ast_transforms=[make_lazy], find_obscure=True)


# Generated at 2022-06-26 02:31:56.274192
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)


if __name__ == '__main__':
    test_make_lazy()
    test_case_0()

# Generated at 2022-06-26 02:34:11.035124
# Unit test for function make_lazy
def test_make_lazy():
    int_0 = 1228
    var_0 = make_lazy(int_0)
    return None


# Generated at 2022-06-26 02:34:17.039290
# Unit test for function make_lazy
def test_make_lazy():
    from math import radians, sin

    def call_sin(theta):
        # type: (float) -> float
        return sin(theta)

    def call_radians(theta):
        # type: (float) -> float
        return radians(theta)

    make_lazy('math')

    result = call_radians(90)
    assert result == 1.5707963267948966

    result = call_sin(94)
    assert result == -0.9999902065507035


# Generated at 2022-06-26 02:34:18.493288
# Unit test for function make_lazy
def test_make_lazy():
    # U2_t0_make_lazy
    assert sys.modules['1228'] is None


# Generated at 2022-06-26 02:34:19.512502
# Unit test for function make_lazy
def test_make_lazy():
    var_0 = make_lazy('module_0')



# Generated at 2022-06-26 02:34:21.898121
# Unit test for function make_lazy

# Generated at 2022-06-26 02:34:24.003389
# Unit test for function make_lazy
def test_make_lazy():
    assert(MakeLazy.test_case_0() == 0)


# Generated at 2022-06-26 02:34:24.851243
# Unit test for function make_lazy
def test_make_lazy():
    # Check if the result matches the expected output
    pass

# Generated at 2022-06-26 02:34:27.211518
# Unit test for function make_lazy
def test_make_lazy():
    assert callable(make_lazy)


# Generated at 2022-06-26 02:34:36.829577
# Unit test for function make_lazy
def test_make_lazy():
    num_import_errors = 0
    test_make_lazy.test_num += 1

    # Mocking Pylint: We cannot import make_lazy in the __init__.py of this
    # package. Because its a recursive import, we need to move it to another
    # script file. Python will not be able to resolve the lazy import until
    # this module is loaded. Therefore, pylint will complain about the import
    # be imported but not used.
    #
    # If we don't make this import, when this module is imported, the
    # `make_lazy` function will be called by `test_case_0` and will immediately
    # import. Therefore, we will not be able to test the lazy loading of
    # modules.
    make_lazy
    num_import_errors += test_case_0()
   

# Generated at 2022-06-26 02:34:38.202600
# Unit test for function make_lazy
def test_make_lazy():
   pass