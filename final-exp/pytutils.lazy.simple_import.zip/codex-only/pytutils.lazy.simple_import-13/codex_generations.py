

# Generated at 2022-06-24 02:53:36.789641
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make_lazy function by adding the module to the sys.path,
    then calling `make_lazy` on it, and then testing
    that accessing the module fails. Then, we access a sub module on
    the lazy module, then access the lazy module itself, and retest that
    the module is available now and the sub module is available.
    We then remove the module from the path to prevent re-use of the
    module in the future.
    """
    module_name = 'test_make_lazy'
    try:
        module = __import__(module_name)
        raise Exception('Trying to import module that already exists.')
    except ImportError:
        pass


# Generated at 2022-06-24 02:53:38.081764
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__slots__ == ['value']
    nl = NonLocal(None)
    assert nl.value is None



# Generated at 2022-06-24 02:53:41.232039
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import stat

    if os.name != 'nt':
        make_lazy("os")
        assert os.stat(__file__)[stat.ST_MODE]
    else:
        print("os.name == 'nt', skipping make_lazy tests.")

# Generated at 2022-06-24 02:53:44.121031
# Unit test for function make_lazy
def test_make_lazy():
    import test.test_lazy
    assert test.test_lazy.foo == 42


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:53:55.977016
# Unit test for function make_lazy
def test_make_lazy():
    # We have to manually clear `sys.modules` since we are using internal
    # methods on the `sys` module
    module_path = 'lazy_module_test'
    sys.modules[module_path] = ModuleType(module_path, "lazy_module_test")
    sys.modules[module_path].attr = 'attr'
    make_lazy(module_path)
    assert 'attr' not in sys.modules[module_path].__dict__
    assert 'attr' in getattr(sys.modules[module_path], 'attr')
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert isinstance(sys.modules[module_path], ModuleType)
    assert isinstance(sys.modules[module_path], object)

# Generated at 2022-06-24 02:54:07.378968
# Unit test for function make_lazy
def test_make_lazy():
    class SimpleSpam:
        def foo(self):
            pass

    make_lazy("simple.spam")
    import simple.spam

    assert isinstance(simple.spam, _LazyModuleMarker)
    assert isinstance(simple.spam, ModuleType)
    assert not isinstance(simple.spam, SimpleSpam)

    assert isinstance(simple.spam, _LazyModuleMarker)

    assert str(simple.spam) == '<module \'simple.spam\' (lazy)>'
    assert simple.spam.__name__ == 'simple.spam'
    assert simple.spam.__file__ == '<lazy>'
    assert simple.spam.__path__ == '<lazy>'
    assert simple.spam.__package__ == 'simple'

# Generated at 2022-06-24 02:54:14.630861
# Unit test for function make_lazy
def test_make_lazy():
    import os
    mod = 'make_lazy_test'
    try:
        m = __import__(mod)
        print(m)
        os.path.abspath
    except ImportError:
        assert False

    make_lazy(mod)

    try:
        m = __import__(mod)
        print(m)
        os.path.abspath
    except ImportError:
        assert True

    del sys.modules[mod]

if __name__ == '__main__':
    for f in (test_make_lazy,):
        f()

# Generated at 2022-06-24 02:54:16.441496
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(object(), _LazyModuleMarker) == False


# Generated at 2022-06-24 02:54:23.981237
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test for correct instantiation of class _LazyModuleMarker
    """
    # The following should have no effect.
    test_object = _LazyModuleMarker()
    assert isinstance(test_object, _LazyModuleMarker)


###############################################################################
#
#   Start of tests for function make_lazy.
#   These tests are written in a style that is in line with the project.  The
#   tests are written in a way that correlates to the specification in the
#   PEP.  Also, the comments are in the style that the PEP defines.
#
###############################################################################

# Test that we can create a type LazyModule

# Generated at 2022-06-24 02:54:25.467569
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test():
        x = NonLocal(42)
        print(x.value)

    test()


# Generated at 2022-06-24 02:54:37.072421
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit tests for function make_lazy.
    """
    module_name = 'test_make_lazy_module'
    module_file = 'test_make_lazy_module.py'
    module_path = module_name


# Generated at 2022-06-24 02:54:38.848108
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local = NonLocal(None)
    assert local.value is None

    local = NonLocal(1)
    assert local.value == 1


# Generated at 2022-06-24 02:54:47.931934
# Unit test for function make_lazy
def test_make_lazy():
    """
    When lazy=True, the module is not imported until it is needed.
    When lazy=False, the module is imported as normal.
    """

    # Cleanup
    if "test_make_lazy" in sys.modules:
        del sys.modules["test_make_lazy"]

    # Start test
    import inspect
    make_lazy("test_make_lazy")

    # Make sure the namespace is lazy
    assert "test_make_lazy" in sys.modules
    assert isinstance(sys.modules["test_make_lazy"], _LazyModuleMarker)

    # Load a file
    import test_make_lazy

    # Make sure the module is not lazy anymore
    assert isinstance(sys.modules["test_make_lazy"], ModuleType)

# Generated at 2022-06-24 02:54:51.104425
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test NonLocal class to properly simulate nonlocal keyword
    """
    x = NonLocal(1)
    assert x.value == 1
    x.value = 2
    assert x.value == 2


# Generated at 2022-06-24 02:55:01.268945
# Unit test for function make_lazy
def test_make_lazy():
    """
    This is a unit test.
    """

    sys_modules = sys.modules
    module_path = "my_module"

    class DummyModule(ModuleType):
        """
        A standin for a module to prevent it from being imported
        """
        def __init__(self, module_path):
            super(DummyModule, self).__init__(module_path)
            self.attr_one = 1
            self.attr_two = 'two'

        def methodOne(self):
            """
            Simple method to test
            """
            return self.attr_one

    sys_modules[module_path] = DummyModule(module_path)
    make_lazy(module_path)

    del sys_modules[module_path]
    sys_modules[module_path] = LazyModule()



# Generated at 2022-06-24 02:55:08.314243
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('some.module.path')

    import some.module.path  # NOQA

    assert isinstance(some.module.path, _LazyModuleMarker)
    assert some.module.path.__name__ == 'some.module.path'

    # Accessing attributes should cause a module import
    assert some.module.path.__file__

    # The sys.modules entry should not be a LazyModule any more
    assert not isinstance(some.module.path, _LazyModuleMarker)

if __name__ == '__main__':
    import nose
    nose.run_exit(argv=['nosetests', __file__])

# Generated at 2022-06-24 02:55:13.337299
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _LazyModuleMarker
    LazyModule = _L

# Generated at 2022-06-24 02:55:20.397515
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'sagetest.make_lazy_test'
    make_lazy(module_path)
    import sagetest.make_lazy_test
    assert isinstance(sagetest.make_lazy_test, _LazyModuleMarker)
    assert hasattr(sagetest.make_lazy_test, '__mro__')
    assert hasattr(sagetest.make_lazy_test, '__getattribute__')
    assert hasattr(sagetest.make_lazy_test, '__name__')
    assert hasattr(sagetest.make_lazy_test, '__doc__')
    assert hasattr(sagetest.make_lazy_test, '__file__')

# Generated at 2022-06-24 02:55:23.174087
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    test_value = 1
    assert non_local.value == test_value


# Generated at 2022-06-24 02:55:27.982622
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert(a.value == 3)


# Generated at 2022-06-24 02:55:34.062128
# Unit test for function make_lazy
def test_make_lazy():
    __test__ = {}
    import builtins
    # Builtins module should be loaded
    assert isinstance(builtins, ModuleType)
    assert 'os' not in sys.modules
    # Lazy module module should not be loaded by default
    make_lazy('os')
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    # Accessing os.path should load os module
    assert hasattr(sys.modules['os'], 'path')
    assert isinstance(sys.modules['os'], ModuleType)
    assert isinstance(sys.modules['os'].path, ModuleType)

# Generated at 2022-06-24 02:55:42.601947
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_mod'

    @make_lazy(module_path)
    class test_mod:
        pass

    assert isinstance(test_mod, _LazyModuleMarker)
    assert sys.modules[module_path] is not test_mod
    assert dir(test_mod) == []
    assert test_mod.__dict__ == {}

    # This shouldn't import the module.
    assert test_mod.__name__ == module_path
    assert isinstance(test_mod, ModuleType)
    assert test_mod.__name__ == module_path
    assert sys.modules[module_path] is test_mod

# Generated at 2022-06-24 02:55:43.744493
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker(), object)


# Generated at 2022-06-24 02:55:48.564724
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("tests.lazy_importer.mod")
    __import__("tests.lazy_importer.mod")
    assert isinstance(sys.modules["tests.lazy_importer.mod"], _LazyModuleMarker)

# Generated at 2022-06-24 02:55:49.807098
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import types
    assert isinstance(_LazyModuleMarker(), types.ModuleType)

# Generated at 2022-06-24 02:55:54.383025
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """ Tests the NonLocal class constructor. """
    a = NonLocal(0)
    assert(a.value == 0)
    a.value = 1
    assert(a.value == 1)


# Generated at 2022-06-24 02:56:04.927861
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import edx_lazy_module_loader
    path = '__test_path__'
    edx_lazy_module_loader.make_lazy(path)
    assert path in sys.modules
    assert isinstance(sys.modules[path], edx_lazy_module_loader._LazyModuleMarker)
    assert isinstance(sys.modules[path], edx_lazy_module_loader.LazyModule)
    assert isinstance(sys.modules[path], ModuleType)
    # Use assertTrue instead of assertIs as older python versions don't have assertIs
    assertTrue(path not in globals())

from mock import patch

# Generated at 2022-06-24 02:56:06.446661
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    x.value = 5
    assert x.value == 5


# Generated at 2022-06-24 02:56:10.644132
# Unit test for function make_lazy
def test_make_lazy():
    # Check if lazy module is not imported
    module_name = 'tests.test_lazy.lazy'
    make_lazy(module_name)
    assert module_name not in sys.modules

    # Check if module is loaded inside the lazy module
    from tests.test_lazy import lazy

    assert module_name in sys.modules
    assert lazy == 1

# Generated at 2022-06-24 02:56:11.658231
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('tests.lazy.test_module')



# Generated at 2022-06-24 02:56:12.742898
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assertNonLocal(module_path)
    assertModuleType(module_path)



# Generated at 2022-06-24 02:56:20.069870
# Unit test for function make_lazy
def test_make_lazy():
    """
    Base test case for validating that make_lazy works.
    """

    # let's make 'foo' lazy.
    make_lazy('foo')

    import sys
    import imp

    # make sure that it is there and it is a LazyModule instance.
    assert sys.modules['foo']
    assert isinstance(sys.modules['foo'], _LazyModuleMarker)

    # Now, let's import the module manually, which should have the
    # same effect as accessing an attribute on the LazyModule instance:
    foo = imp.load_module('foo', *imp.find_module('foo'))

    # Since we already imported it manually, the LazyModule should a
    # module object and not a LazyModule instance.
    assert isinstance(sys.modules['foo'], ModuleType)

    # finally,

# Generated at 2022-06-24 02:56:31.742999
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['tests.foo.bar'] = ModuleType('tests.foo.bar')


# Generated at 2022-06-24 02:56:42.008968
# Unit test for function make_lazy
def test_make_lazy():
    # fake module in sys.modules
    sys.modules['log'] = None

    # mark module as lazy
    make_lazy('log')

    # check that module is not imported yet
    assert sys.modules['log'] is not None
    assert sys.modules['log'].__class__.__name__ == 'LazyModule'

    # import module the lazy way
    from log import INFO

    # module should be loaded now
    assert sys.modules['log'] is not None
    assert sys.modules['log'].__class__.__name__ == 'module'

    # check log levels
    assert INFO == 20
    assert hasattr(sys.modules['log'], 'INFO')

    # delete module from sys.modules
    del sys.modules['log']

# Import all the modules defined in Lazy

# Generated at 2022-06-24 02:56:43.240600
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0

# Generated at 2022-06-24 02:56:46.151830
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class TestLazy(_LazyModuleMarker):
        pass
    assert isinstance(TestLazy(), _LazyModuleMarker)


# Generated at 2022-06-24 02:56:49.631879
# Unit test for function make_lazy
def test_make_lazy():
    class Module(object):
        def func(self):
            return 1
    sys.modules['test_module'] = Module()
    make_lazy('test_module')
    module = sys.modules['test_module']
    assert isinstance(module, Module)
    assert module.func() == 1
    assert module is sys.modules['test_module']

# Generated at 2022-06-24 02:56:51.209569
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('os'), _LazyModuleMarker)

# Generated at 2022-06-24 02:56:56.334124
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 02:56:59.783439
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(None, _LazyModuleMarker)
    assert not isinstance(1, _LazyModuleMarker)
    assert not isinstance('str', _LazyModuleMarker)


# Unit tests for constructor of class LazyModule

# Generated at 2022-06-24 02:57:02.847127
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2

# Generated at 2022-06-24 02:57:03.377213
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass

# Generated at 2022-06-24 02:57:06.962687
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert not hasattr(_LazyModuleMarker, '__dict__')
    assert hasattr(_LazyModuleMarker, '__slots__')


# Generated at 2022-06-24 02:57:09.933402
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        foo = NonLocal('foo')
        bar = NonLocal('bar')

        assert(foo.value == 'foo')
        assert(bar.value == 'bar')
    except:
        print('NonLocal constructor test failed')

# Generated at 2022-06-24 02:57:12.256610
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for _LazyModuleMarker constructor
    """
    a = _LazyModuleMarker()


# Generated at 2022-06-24 02:57:16.424981
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(777)
    assert v.value == 777


# Generated at 2022-06-24 02:57:17.451745
# Unit test for constructor of class NonLocal
def test_NonLocal():
   nl = NonLocal(None)
   nl.value = 10
   print(nl.value)



# Generated at 2022-06-24 02:57:27.537757
# Unit test for function make_lazy
def test_make_lazy():
    # make a fake module
    class _test_module(object):
        var = 43

    # add fake module to sys.modules
    sys_modules = sys.modules
    # pylint: disable=unused-variable
    sys_modules['test_module'] = _test_module
    sys_modules = sys.modules

    # mark module as lazy
    make_lazy('test_module')

    # check the new module in sys.modules
    lazy_module = sys_modules['test_module']
    assert lazy_module
    # pylint: disable=no-member
    # pylint: disable=unused-variable
    assert not isinstance(lazy_module, ModuleType)
    _test_module = getattr(sys_modules['test_module'], '_test_module', None)
    assert not _test

# Generated at 2022-06-24 02:57:36.633586
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that our lazy module behaves
    """
    make_lazy("unittest_make_lazy.foo")
    import unittest_make_lazy.foo

    # We can import the module
    assert isinstance(unittest_make_lazy.foo, _LazyModuleMarker)
    # We can not access attributes of the module
    try:
        unittest_make_lazy.foo.bar
        assert False
    except AttributeError:
        pass

    # We can access the module's attributes once we override the module
    unittest_make_lazy.foo.value = 3
    assert unittest_make_lazy.foo.value == 3

# Generated at 2022-06-24 02:57:38.079466
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NON_LOCAL = NonLocal(10)
    assert NON_LOCAL.value == 10


# Generated at 2022-06-24 02:57:39.476109
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
   assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker()))


# Generated at 2022-06-24 02:57:48.115931
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    try:
        make_lazy('ast')
        module_name = 'ast'
        if module_name not in sys.modules:
            assert False
        if module_name in sys.modules:
            assert True
        if isinstance(sys.modules[module_name], _LazyModuleMarker):
            assert True
        if not isinstance(sys.modules[module_name], ModuleType):
            assert False
        try:
            assert sys.modules[module_name].__version__
        except AttributeError:
            assert False
    except:
        assert False
    assert True


if __name__ == '__main__':
    test_make_lazy()
    print('Test passed')

# Generated at 2022-06-24 02:57:52.538998
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-24 02:57:55.165530
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test for the constructor of the class NonLocal
    """
    my_nonlocal = NonLocal(10)
    assert my_nonlocal.value == 10



# Generated at 2022-06-24 02:58:01.736494
# Unit test for function make_lazy
def test_make_lazy():

    # Init problem and make sure unit test can work with Python2
    a = NonLocal(None)

    module_path = 'foo.bar'
    make_lazy(module_path)

    # Check that the module has not been loaded yet
    assert module_path not in sys.modules, "Module has been loaded!"

    # Check that the module has been loaded after getting an attribute
    sys.modules[module_path].test
    assert module_path in sys.modules, "Module has not been loaded!"

    # Check that we can access the module
    assert sys.modules[module_path] == a.value, "Module has not been loaded!"

# Generated at 2022-06-24 02:58:07.029337
# Unit test for function make_lazy
def test_make_lazy():
    import os
    module_path = 'os'
    old_os = sys.modules[module_path]
    del sys.modules[module_path]

    make_lazy(module_path)
    import os

    assert isinstance(os, _LazyModuleMarker)
    assert os.path is not None
    assert os.path is old_os.path




# Generated at 2022-06-24 02:58:08.821487
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:58:19.884803
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import platform

    sys.modules['my.module'] = None
    sys.modules['my.module.platform'] = None
    sys.modules['my.module.os'] = None

    make_lazy('my.module.platform')
    make_lazy('my.module.os')

    from my.module import platform
    from my.module import os

    assert isinstance(platform, _LazyModuleMarker)
    assert isinstance(os, _LazyModuleMarker)

    assert platform.__name__ == 'my.module.platform'
    assert os.__name__ == 'my.module.os'
    assert sys.modules["my.module.platform"] is platform
    assert sys.modules["my.module.os"] is os

    assert os != platform
    assert platform.system != os.system
   

# Generated at 2022-06-24 02:58:24.565655
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Assert that _LazyModuleMarker has no attributes.
    assert isinstance(_LazyModuleMarker, type)
    assert len(dir(_LazyModuleMarker)) == 0

    # Assert that _LazyModuleMarker is not a type.
    assert not isinstance(_LazyModuleMarker, type)


# Generated at 2022-06-24 02:58:26.706745
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(None)
    value.value = 3
    assert value.value == 3

    value = NonLocal(4)
    assert value.value == 4



# Generated at 2022-06-24 02:58:28.329617
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None

# Generated at 2022-06-24 02:58:31.770441
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mm = _LazyModuleMarker()
    assert mm is not None

# Generated at 2022-06-24 02:58:39.698125
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys_modules = sys.modules  # cache in the locals
    module = NonLocal(None)

    # store our 'instance' data in the closure.
    module = NonLocal(None)

    # Run tests that don't use constructed instances of NonLocal
    assert issubclass(_LazyModuleMarker, object)
    assert "_LazyModuleMarker" in repr(_LazyModuleMarker)
    assert "LazyModule" in repr(_LazyModuleMarker.__mro__)
    assert "ModuleType" in repr(_LazyModuleMarker.__mro__)
    assert _LazyModuleMarker() == _LazyModuleMarker()
    assert _LazyModuleMarker() == _LazyModuleMarker.__mro__
    assert _LazyModuleMarker() != object

# Generated at 2022-06-24 02:58:49.040447
# Unit test for function make_lazy
def test_make_lazy():
    """ make_lazy is lazy and works """

    # Create a testing module
    module_name = '__testing_module'
    module_path = module_name + '.py'
    # Create the module file
    module_file = open(module_path, 'w')
    module_file.write("""
message = "I'm so lazy"
""")
    module_file.close()

    # Test if module is loaded
    assert module_name not in sys.modules

    # Make the module lazy
    make_lazy(module_name)

    # Test the lazy module
    assert module_name in sys.modules
    assert sys.modules[module_name]
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)
    assert not hasattr(sys.modules[module_name], 'message')



# Generated at 2022-06-24 02:58:58.466150
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy()

    It is not possible to test the lazy loading with unittest, since
    to use unittest we need to import unittest module
    which will load all modules
    """

    module_name = 'test_lazy_module'
    module_path = 'test.%s' % module_name

    # Create module object
    module = types.ModuleType(module_name)
    sys.modules[module_path] = module

    # add a module attribute
    module.attr = 1

    make_lazy(module_path)
    # Access the module attribute
    assert module.attr == 1



# Generated at 2022-06-24 02:58:59.846488
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:01.591214
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(5)
    assert x.value == 5


# Generated at 2022-06-24 02:59:10.586563
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # First create an instance of the class _LazyModuleMarker
    lazy_marker = _LazyModuleMarker()
    
    # Second, create an instance of the type LazyModule
    lazy_module = make_lazy('os')
    # Make sure that the instance of LazyModule is an instance of
    # _LazyModuleMarker
    assert isinstance(lazy_module, _LazyModuleMarker)
    # Make sure that the instance of _LazyModuleMarker is not an instance
    # of LazyModule
    assert not isinstance(lazy_marker, LazyModule)

# Generated at 2022-06-24 02:59:21.608242
# Unit test for function make_lazy
def test_make_lazy():
    # Check that module not loaded when decorator applies.
    sys.modules['test_make_lazy.foo'] = None
    make_lazy('test_make_lazy.foo')
    assert 'test_make_lazy.foo' not in sys.modules
    # Check that module loads when first attribute is accessed.
    assert isinstance(sys.modules['test_make_lazy.foo'], ModuleType)
    # Check that module loads on first access of attribute.
    sys.modules['test_make_lazy.bar'] = NonLocal(None)
    make_lazy('test_make_lazy.bar')
    sys.modules['test_make_lazy.bar'].foo = None
    assert 'test_make_lazy.bar.foo' in sys.modules

# Generated at 2022-06-24 02:59:30.863813
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules as sys_modules

    # create the module dynamically
    exec('class Device(object):\n    pass\n')
    exec('class Device1(object):\n    pass')
    exec('class Device2(object):\n    pass')
    exec('class Device3(object):\n    def a(self):\n        return 1')
    exec('class Device4(object):\n    def a(self):\n        return 2')
    exec('class Device5(object):\n    def a(self):\n        return 3')
    exec('class Device6(object):\n    def a(self):\n        return 4')

    # test that the module imported normally
    import device_test
    assert 'Device' in device_test.__dict__

    # test that it can be imported lazily


# Generated at 2022-06-24 02:59:32.228436
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = NonLocal('abc')
    assert test_value.value == 'abc'



# Generated at 2022-06-24 02:59:40.916073
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    # Save the system environment
    original_path = sys.path

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a temp python file
    test_file = os.path.join(temp_dir, 'test')
    with open(test_file + '.py', 'w') as f:
        f.write('x = 1')
        f.close()

    # Append the temp directory to the path
    sys.path.append(temp_dir)

    # Create a lazy module
    make_lazy('test')

    # Make sure the module is lazy
    assert isinstance(sys.modules['test'], _LazyModuleMarker)

    # Get the attribute
    x = sys.modules['test'].x
    assert x == 1

    #

# Generated at 2022-06-24 02:59:44.879379
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _LazyModuleMarker(object):
        def __init__(self):
            print("__init__ was called")
    t = _LazyModuleMarker()
    print("Finished")


# Generated at 2022-06-24 02:59:46.242508
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal("nonlocal object")
    assert nonlocal_obj.value == "nonlocal object"



# Generated at 2022-06-24 02:59:50.178264
# Unit test for function make_lazy
def test_make_lazy():
    with pytest.raises(ImportError):
        import foo
    make_lazy('foo')
    foo = sys.modules['foo']
    assert isinstance(foo, _LazyModuleMarker)
    with pytest.raises(AttributeError):
        foo.bar
    with pytest.raises(ImportError):
        foo.bar



# Generated at 2022-06-24 02:59:59.091384
# Unit test for function make_lazy
def test_make_lazy():
    # Test make_lazy by creating a new module and testing it
    import sys
    import os
    import os.path

    mod_name = "edx_toggles_test_lazy"

# Generated at 2022-06-24 03:00:00.041884
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    i = _LazyModuleMarker()

# Generated at 2022-06-24 03:00:02.853091
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print('Running unit test for class _LazyModuleMarker')
    print('Constructor of class _LazyModuleMarker:')
    print(make_lazy('tests.lazy_module_marker_test'))

# Generated at 2022-06-24 03:00:04.715724
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 03:00:06.639179
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('a')
    nl.value = 'b'
    assert nl.value == 'b'



# Generated at 2022-06-24 03:00:09.729980
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A(_LazyModuleMarker):
        pass
    class B(_LazyModuleMarker):
        pass
    a = A()
    b = B()
    assert isinstance(a, A)
    assert isinstance(b, B)

# Generated at 2022-06-24 03:00:11.737573
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test that it can be created
    assert _LazyModuleMarker() is not None

# Unit tests for the LazyModule class

# Generated at 2022-06-24 03:00:15.926143
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value == None


# Generated at 2022-06-24 03:00:22.161420
# Unit test for function make_lazy
def test_make_lazy():
    # Cleanup imports
    if 'lazymod' in sys.modules:
        del sys.modules['lazymod']

    # create lazy module
    make_lazy('lazymod')

    # import
    import lazymod

    # check if object is a LazyModule
    assert isinstance(lazymod, _LazyModuleMarker)
    # NonLocal module is not intialized
    assert lazymod.__dict__['value'] is None

    # fail without NonLocal
    with pytest.raises(KeyError):
        print(lazymod.__dict__['module'])

    # access attribute on lazymod
    lazymod.LazyModule

    # NonLocal module is intialized
    assert lazymod.__dict__['value'] is not None
    assert lazymod.__dict__['value'].__name__

# Generated at 2022-06-24 03:00:31.044872
# Unit test for function make_lazy
def test_make_lazy():
    import types
    testmodule_path = 'tests.unit.test_import'

    def import_testmodule():
        """
        Try to import testmodule
        """
        module = types.ModuleType(testmodule_path)
        sys.modules[testmodule_path] = module
        return __import__(testmodule_path)

    # lazy import
    make_lazy(testmodule_path)
    testmodule = import_testmodule()
    assert not hasattr(testmodule, 'testfunction')

    # try to access an attribute of the lazy module
    testmodule.testfunction()
    module = import_testmodule()
    assert hasattr(module, 'testfunction')

# Generated at 2022-06-24 03:00:34.150956
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    print(a.value)
    a.value = 9
    print(a.value)


# Generated at 2022-06-24 03:00:36.288055
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert type(x) is _LazyModuleMarker
    assert isinstance(x, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:37.753105
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker

# Generated at 2022-06-24 03:00:39.737963
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    y = NonLocal(2)
    assert id(x) == id(y)



# Generated at 2022-06-24 03:00:43.804106
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10

# Generated at 2022-06-24 03:00:49.905094
# Unit test for function make_lazy
def test_make_lazy():
    import types
    import sys

    try:
        make_lazy('django.utils.six')

        six = __import__('django.utils.six')

        print("sys.modules: {!r}".format(sys.modules['django.utils.six']))
        print("six: {!r}".format(six))
        print("isinstance(six, LazyModule): {!r}".format(
            isinstance(six, _LazyModuleMarker)
        ))

        print("six.__getattribute__: {!r}".format(six.__getattribute__('X')))
    finally:
        sys.modules['django.utils.six'] = types.ModuleType('django.utils.six')
        sys.modules['django'] = types.ModuleType('django')

# Generated at 2022-06-24 03:00:51.609979
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(4)
    print(x.value)


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 03:00:54.306542
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 03:01:00.145728
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocalTest(object):
        def __init__(self, A, B):
            self.A = A
            self.B = B

    n1 = NonLocal(1)
    n2 = NonLocal(NonLocalTest(n1, NonLocalTest(n1, n1)))
    assert n2.A == 1
    assert n2.B.A == 1
    assert n2.B.B == 1


# Generated at 2022-06-24 03:01:02.349833
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assertLazyModuleMarker = _LazyModuleMarker
    assert isinstance(assertLazyModuleMarker, types.ClassType)


# Generated at 2022-06-24 03:01:10.458296
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test to check that the make lazy function works
    """
    import importlib
    import os
    import sys

    # we need to clean out anything that may have been left
    # by previous tests.
    module_name = 'knockknock.__test_lazy__'
    module_path = os.path.join(os.path.dirname(__file__), '__test_lazy__.py')

    # try to force the module to be loaded if it already is
    module = sys.modules.get(module_name, None)

    if module is None:
        # first time importin the module
        module = importlib.import_module(module_name)

    else:
        # try to force the module to be reloaded from disk
        reload(module)

        # test that the module was reloaded

# Generated at 2022-06-24 03:01:21.941285
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('initial value')
    assert nl.value == 'initial value'
    nl.value = 'another value'
    assert nl.value == 'another value'


if __name__ == "__main__":
    # Unit tests for function make_lazy
    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)
    os.path

    res = os.listdir('.')
    assert len(res) > 0

    for i in res:
        print(i)

    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)
    os.path
    assert isinstance(os, ModuleType)

    make_lazy('sys')
    assert isinstance(sys, _LazyModuleMarker)
    sys.path

# Generated at 2022-06-24 03:01:28.110844
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    :return:
    """
    non_local = NonLocal(7)

# Generated at 2022-06-24 03:01:33.867928
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    #Test whether the _LazyModuleMarker is instantiable
    assert(_LazyModuleMarker() is not None)
    

# Generated at 2022-06-24 03:01:35.637044
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_test = _LazyModuleMarker()
    assert isinstance(lazy_test, _LazyModuleMarker)


# Generated at 2022-06-24 03:01:37.329410
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)
    assert not isinstance(1, _LazyModuleMarker)



# Generated at 2022-06-24 03:01:39.584150
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NL = NonLocal("NonLocal")
    v = NL.value
    assert v == "NonLocal"

# Generated at 2022-06-24 03:01:41.411653
# Unit test for function make_lazy
def test_make_lazy():
    # Test that make_lazy can be called without error
    make_lazy('z.c')



# Generated at 2022-06-24 03:01:45.130881
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """ a test unit for NonLocal class """
    nonlocal_var = NonLocal(10)
    assert nonlocal_var.value == 10
    nonlocal_var.value = 20
    assert nonlocal_var.value == 20

# Generated at 2022-06-24 03:01:47.530293
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(42)
    assert a.value == 42
    a.value = 1337
    assert a.value == 1337


# Generated at 2022-06-24 03:01:49.225547
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(2)
    x.value = 4
    assert x.value == 4



# Generated at 2022-06-24 03:01:49.865478
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 03:01:53.558220
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10


# Generated at 2022-06-24 03:01:58.101096
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker and
    the __mro__ method inside the LazyModule class
    """
    path = 'test_module'
    make_lazy(path)
    assert isinstance(sys.modules[path], _LazyModuleMarker)
    assert sys.modules[path].__module__ == 'test_module'



# Generated at 2022-06-24 03:01:59.488530
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = 'foo'
    nl = NonLocal(test_value)
    assert nl.value == test_value


# Generated at 2022-06-24 03:02:01.184456
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  obj = _LazyModuleMarker()
  assert obj.__class__.__name__ == "_LazyModuleMarker"


# Generated at 2022-06-24 03:02:09.733764
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the lazy module made by make_lazy.
    """
    import sys
    import os

    # Get the path to our test module.
    test_path = os.path.dirname(__file__)
    test_module_path = os.path.join(test_path, 'test_lazy_module')

    # Make sure the test module is not there
    module_name = os.path.basename(test_module_path)
    assert module_name not in sys.modules

    # Make a lazy version of the module.
    make_lazy(module_name)
    assert sys.modules[module_name]

    # Make sure it's a lazy module
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # Make sure the test module is not imported.
   

# Generated at 2022-06-24 03:02:20.218212
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import lazy_modules.implementation
    except ImportError:
        pytest.skip('Unable to import lazy_modules.implementation, skipping test_make_lazy()')

    from lazy_modules.implementation import make_lazy
    from lazy_modules.implementation import LazyModule
    make_lazy('tests.lazy_modules.like_pandas')
    assert 'tests.lazy_modules.like_pandas' in sys.modules

    # tests.lazy_modules.like_pandas is in sys.modules, but not imported
    import tests.lazy_modules.like_pandas as like_pandas
    assert isinstance(like_pandas, LazyModule)
    assert 'like_pandas' not in sys.modules

# Generated at 2022-06-24 03:02:29.719036
# Unit test for function make_lazy
def test_make_lazy():
    try:
        key = __name__ + '.lazy'
        make_lazy(key)
        mod = sys.modules[key]
        assert not hasattr(sys.modules[key], 'thing')
        assert isinstance(mod, _LazyModuleMarker), 'is not LazyModule'
        assert mod.attr is 1, 'attr is not 1'
        assert mod.thing is 2, 'thing is not 2'
        assert hasattr(mod, 'thing'), 'thing is not set'
        assert mod.other.thing is 3, 'other.thing is not 3'
    finally:
        if key in sys.modules:
            del sys.modules[key]


# Generated at 2022-06-24 03:02:32.059324
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 03:02:34.945403
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test NonLocal __init__
    a = NonLocal("alpha")
    b = NonLocal("beta")
    assert(a.value == "alpha")
    assert(b.value == "beta")


# Generated at 2022-06-24 03:02:43.228328
# Unit test for function make_lazy
def test_make_lazy():
    # Set up the environment for testing
    path = 'django.contrib.staticfiles.storage.base'
    sys.modules[path] = 'dummy'

    # test make_lazy
    make_lazy(path)
    m = sys.modules[path]
    assert m, "Django module is not imported"
    # test lazy module is an instance of LazyModule
    assert isinstance(m, _LazyModuleMarker), \
        "Module imported is not an instance of class LazyModule"

# Generated at 2022-06-24 03:02:54.576195
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure that `make_lazy` has the desired effect on a module and
    it's objects.
    """
    import math
    from pytest import raises

    # The module should not be loaded in this case
    make_lazy('math')
    assert math.__class__.__name__ == 'LazyModule'

    # We should be able to perform an import on it
    # But, the module should be marked lazy
    import math as _math
    assert _math.__name__ == 'math'
    assert isinstance(math, _LazyModuleMarker)

    # After the import, the module should be 'un-marked' as lazy.
    assert isinstance(_math, ModuleType)
    assert not isinstance(_math, _LazyModuleMarker)

    # However, the original module should still be marked lazy.

# Generated at 2022-06-24 03:02:58.893485
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker(), '__mro__'), '__mro__ not found in class'
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker), 'isinstance failed'
    assert isinstance(_LazyModuleMarker(), ModuleType), 'isinstance failed'


# Generated at 2022-06-24 03:02:59.963178
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()


# Generated at 2022-06-24 03:03:10.832514
# Unit test for function make_lazy
def test_make_lazy():
    """
    For unit testing, we can't use the real `sys.modules`. Instead, we'll mock
    it as a normal dict and use `importlib` to do the real work.
    """
    import importlib
    importlib.import_module = importlib.__import__
    try:
        sys.modules = {}

        make_lazy('os')

        # Since `os` is lazy, we should not have imported it
        assert 'os' not in sys.modules

        # Check that we can call the function withouth puking
        assert 'path' in sys.modules['os'].__dict__

        assert 'os' in sys.modules

        # Check that we can call the function withouth puking
        assert sys.modules['os'].path.realpath
    finally:
        sys.modules = sys.modules.copy

# Generated at 2022-06-24 03:03:20.525719
# Unit test for function make_lazy
def test_make_lazy():
    def my_import(name):
        raise ImportError()
    _builtin_import = __import__

    import sys
    sys.modules['django.core.urlresolvers'] = NonLocal(None)
    sys.modules['django.core.urlresolvers'] = make_lazy('django.core.urlresolvers')

    # This will fail for us (and it does normally)
    # because we overrode __import__ with my_import.
    __builtins__['__import__'] = my_import
    with pytest.raises(ImportError):
        import django.core.urlresolvers

    # Now we make it lazy and override __builtins__
    make_lazy('django.core.urlresolvers')
    __builtins__['__import__'] = my_import



# Generated at 2022-06-24 03:03:26.612886
# Unit test for function make_lazy
def test_make_lazy():
    import test_lazy
    assert "test_lazy" in sys.modules
    assert isinstance(sys.modules['test_lazy'], _LazyModuleMarker)

    # Attempt to access attributes from "test_lazy"
    assert test_lazy.thing == "thing"
    assert test_lazy.other_thing == "other_thing"

    # Make sure that the module has been imported fully
    assert isinstance(sys.modules['test_lazy'], ModuleType)