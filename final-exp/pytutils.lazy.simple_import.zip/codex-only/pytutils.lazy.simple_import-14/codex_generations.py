

# Generated at 2022-06-24 02:53:37.920393
# Unit test for function make_lazy
def test_make_lazy():
    # Perform the test with a new sys.modules dict to ensure we aren't
    # messing up the global modules dict
    saved_sysmodules = sys.modules.copy()
    sys.modules = {}

# Generated at 2022-06-24 02:53:39.875308
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f():
        nonlocal_var = NonLocal("hello")
        nonlocal_var.value = "world"
        assert nonlocal_var.value is "world"

    f()



# Generated at 2022-06-24 02:53:41.987069
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('I am NonLocal')

    assert nl.value == 'I am NonLocal'

# Generated at 2022-06-24 02:53:46.907144
# Unit test for function make_lazy
def test_make_lazy():
    if 'make_lazy' in sys.modules:
        del sys.modules['make_lazy']

    make_lazy('make_lazy')
    assert 'make_lazy' in sys.modules
    assert sys.modules['make_lazy'] is not None



# Generated at 2022-06-24 02:53:57.370091
# Unit test for function make_lazy
def test_make_lazy():
    class MyModule(object):
        pass

    class MyParentModule(object):
        MyModule = MyModule

    my_module = MyModule()

    sys.modules['parent.module'] = MyParentModule()

    make_lazy('parent.module.MyModule')

    # for non existing modules, we should get a normal import error
    try:
        import parent.module.MyModule
    except ImportError:
        assert 'parent.module.MyModule' not in sys.modules

    # ensure we have our hook in place
    assert isinstance(sys.modules['parent.module.MyModule'], _LazyModuleMarker)

    # when we start to use an actual attribute, it should import into
    # our namespace
    assert sys.modules['parent.module.MyModule'] is my_module

# Generated at 2022-06-24 02:53:59.366903
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    test constructor of class _LazyModuleMarker
    """
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:54:01.961561
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Use this with legacy Python2, 
    # e.g., with nonlocal keyword, no assignment to nonlocal variable possible
    a = NonLocal(1)
    a.value = 2
    print("Test of class NonLocal", a.value, a.__dict__)
    assert a.value == 2



# Generated at 2022-06-24 02:54:05.510974
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert isinstance(nl, NonLocal)



# Generated at 2022-06-24 02:54:07.041926
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(5)
    assert nonlocal_var.value == 5


# Generated at 2022-06-24 02:54:08.816388
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:54:10.485254
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('test')
    assert nl.value == 'test'


# Generated at 2022-06-24 02:54:20.709596
# Unit test for function make_lazy
def test_make_lazy():
    # Import a module to make sure it exists
    # If this is not done and the module does not exist it will just
    # wait until the module is needed to be created
    import sphinx

    # Make sure that sphinx exists in sys.modules
    assert sphinx in sys.modules

    # Make sure that the new module does not exist in sys.modules
    assert 'jupyter_sphinx' not in sys.modules

    # Mark the new module to be lazy
    make_lazy('jupyter_sphinx')

    # Make sure that the new module exists in sys.modules
    assert 'jupyter_sphinx' in sys.modules

    # Make sure that we are dealing with a lazy module
    new_module = sys.modules['jupyter_sphinx'];

# Generated at 2022-06-24 02:54:22.035442
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:54:23.524657
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'


# Generated at 2022-06-24 02:54:34.944626
# Unit test for function make_lazy
def test_make_lazy():
    # It's a bit duplicating the code of test_importer.py
    # since we are not going to cover test_importer in this test.
    assert _LazyModuleMarker in globals()

    assert 'test_make_lazy' in globals()
    assert 'make_lazy' in globals()
    assert make_lazy not in globals()
    # We need to make sure that `test_make_lazy` is visible
    # for the importer to be able to check for the attribute `test_make_lazy`
    assert 'test_make_lazy' in globals()
    make_lazy('test_make_lazy')
    assert make_lazy in globals()
    assert isinstance(make_lazy, _LazyModuleMarker)

    # We want to make sure that `test

# Generated at 2022-06-24 02:54:35.891950
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()

# Generated at 2022-06-24 02:54:41.388995
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import unittest
    class tests(unittest.TestCase):
        def test_NonLocal_constructor(self):
            import pickle
            nl = NonLocal("Hello World!")
            self.assertEqual(nl.value, "Hello World!")
            with self.assertRaises(AttributeError):
                nl.nothing = "does not exist"
            with self.assertRaises(AttributeError):
                del nl.nothing

    unittest.main(verbosity=2)


# Generated at 2022-06-24 02:54:42.808967
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    x.value = 4
    assert x.value == 4


# Generated at 2022-06-24 02:54:44.247963
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert isinstance(module, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:45.659081
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1


# Generated at 2022-06-24 02:54:47.457487
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import types

    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)
    assert not isinstance(a, types.ModuleType)


# Generated at 2022-06-24 02:54:52.496958
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule:
        pass

    sys.modules['__main__'] = TestModule()

    make_lazy('__main__')
    TestModule.attribute = 123

    import __main__

    assert isinstance(__main__, _LazyModuleMarker)
    assert isinstance(__main__, ModuleType)
    assert hasattr(__main__, 'attribute')
    assert __main__.attribute == 123

# Generated at 2022-06-24 02:54:56.005903
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3

# Generated at 2022-06-24 02:55:00.240909
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()

# Generated at 2022-06-24 02:55:02.173137
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker()

# Unit test of make_lazy

# Generated at 2022-06-24 02:55:04.003826
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value == None
    x.value = 1
    assert x.value == 1


# Generated at 2022-06-24 02:55:05.198911
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal
    """
    nl = NonLoca

# Generated at 2022-06-24 02:55:07.408340
# Unit test for constructor of class NonLocal
def test_NonLocal():
    read = NonLocal(1)
    assert read.value == 1
    read.value = 2
    assert read.value == 2
    read.value = 3
    assert read.value == 3

# Generated at 2022-06-24 02:55:08.613215
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(hasattr(_LazyModuleMarker, '__init__'))

# Generated at 2022-06-24 02:55:11.228368
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test():
        nonlocal_x = NonLocal(None)
        nonlocal_x.value = 1
        assert nonlocal_x.value == 1

    test()


# Generated at 2022-06-24 02:55:12.226964
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with raises(TypeError):
        _LazyModuleMarker()

# Generated at 2022-06-24 02:55:21.455683
# Unit test for function make_lazy
def test_make_lazy():
    def test_module(mod):
        mod.test = None
        mod.test.foo = 1

    mod = None
    # If mod is not a lazy module, this will fail
    make_lazy('test_mod')
    test_module(sys.modules['test_mod'])
    del sys.modules['test_mod']

    # If mod is not a lazy module, this will also fail
    mod = make_lazy('test_mod2')
    test_module(sys.modules['test_mod2'])
    del sys.modules['test_mod2']

    # if mod is not a lazy module, this should definitely fail
    mod = make_lazy('test_mod3')
    test_module(sys.modules['test_mod3'])
    del sys.modules['test_mod3']

    # if we

# Generated at 2022-06-24 02:55:24.047973
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    assert isinstance(lazy, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:27.523383
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-24 02:55:31.399688
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_int = NonLocal(1)
    nonlocal_str = NonLocal('test')
    nonlocal_tuple = NonLocal((1, 2, 3))
    assert nonlocal_int.value == 1
    assert nonlocal_str.value == 'test'
    assert nonlocal_tuple.value == (1, 2, 3)


# Generated at 2022-06-24 02:55:36.282057
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__doc__ == "A marker to indicate a LazyModule type."
        
test__LazyModuleMarker()

# Unit test make_lazy()

# Generated at 2022-06-24 02:55:44.144283
# Unit test for function make_lazy
def test_make_lazy():
    # GIVEN
    # Import a module that does not exist
    MODULE_PATH = 'module.does.not.exist'

    # WHEN
    # Decorate this module as lazy
    make_lazy(MODULE_PATH)

    # THEN
    # Get the module
    mod = sys.modules[MODULE_PATH]

    assert mod  # Make sure it exists

    # Assert that the module is not a `LazyModule` instance
    assert not isinstance(mod, _LazyModuleMarker)

    # Assert that the module is actually a `ModuleType` instance
    assert isinstance(mod, ModuleType)

    # Assert that the module is loaded
    assert mod.__name__ == MODULE_PATH

# Generated at 2022-06-24 02:55:49.957992
# Unit test for function make_lazy
def test_make_lazy():
    import test_lazy_module
    assert isinstance(test_lazy_module, _LazyModuleMarker)
    assert test_lazy_module.foo == 'foo'
    assert isinstance(test_lazy_module, ModuleType)
    assert not isinstance(test_lazy_module, _LazyModuleMarker)



# Generated at 2022-06-24 02:55:54.040570
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(object):
        def __init__(self):
            self.x = NonLocal(1)

    assert Test().x.value == 1


# Generated at 2022-06-24 02:56:00.049590
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # initialization case
    mark = _LazyModuleMarker()
    assert isinstance(mark, _LazyModuleMarker)

test__LazyModuleMarker()


# Generated at 2022-06-24 02:56:04.355663
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(None)
    assert(foo.value == None)

    foo = NonLocal('value')
    assert(foo.value == 'value')


# Generated at 2022-06-24 02:56:07.782810
# Unit test for function make_lazy
def test_make_lazy():
    from . import util
    assert isinstance(util, _LazyModuleMarker)
    assert isinstance(util, ModuleType)

    from .util import assert_equal
    assert_equal(1, 1)

    util.assert_equal(2, 2)



# Generated at 2022-06-24 02:56:12.675971
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value is 10

# Generated at 2022-06-24 02:56:15.017647
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker.
    """
    assert '_LazyModuleMarker' == "_LazyModuleMarker".rstrip('r')



# Generated at 2022-06-24 02:56:17.828552
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test cases for class _LazyModuleMarker
    """
    # Test cases for constructor
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 02:56:18.797824
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:56:24.632482
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['__main__.foo'] = None
    make_lazy('__main__.foo')
    sys.modules['__main__.foo'].bar
    assert sys.modules['__main__.foo'] is not None
    assert sys.modules['__main__.foo'].bar == 42
    del sys.modules['__main__.foo']

# Generated at 2022-06-24 02:56:27.927135
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    # this is expected to return
    assert isinstance(lazy, _LazyModuleMarker)
    # this is not expected to return
    assert not isinstance(lazy, dict)

# Generated at 2022-06-24 02:56:29.216645
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert m is not None


# Generated at 2022-06-24 02:56:33.166921
# Unit test for function make_lazy
def test_make_lazy():
    import os
    make_lazy('os')
    assert sys.modules['os'].__class__.__name__ == 'LazyModule'
    assert os.path.__class__.__name__ == 'module'



# Generated at 2022-06-24 02:56:37.533539
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Return True if the class _LazyModuleMarker is defined.
    Otherwise raise an error.
    """
    try:
        _LazyModuleMarker()
    except:
        return False
    return True


# Generated at 2022-06-24 02:56:45.733371
# Unit test for function make_lazy
def test_make_lazy():
    path = 'non_existing_module'

    # Check if module is already lazy
    if path in sys.modules and isinstance(sys.modules[path], _LazyModuleMarker):
        return

    make_lazy(path)

    assert isinstance(sys.modules[path], _LazyModuleMarker)

    # Make sure that it doesn't really import the module
    assert path not in sys.modules

# Generated at 2022-06-24 02:56:50.133768
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import re
    import pkgutil

    # Check isinstance
    mod = __import__("re")
    assert isinstance(mod, _LazyModuleMarker) == False

    mod = __import__("pkgutil.re")
    assert isinstance(mod, _LazyModuleMarker) == True

    # Check __getattribute__
    mod = __import__("re")
    assert hasattr(mod, "match") == True

    mod = __import__("pkgutil.re")
    assert hasattr(mod, "match") == True


# Test for constructor of class NonLocal

# Generated at 2022-06-24 02:56:54.335692
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    my_mod = _LazyModuleMarker()
    assert issubclass(my_mod.__class__, _LazyModuleMarker)
    assert not isinstance(my_mod, _LazyModuleMarker)

# Generated at 2022-06-24 02:56:56.006817
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(3)
    assert nonlocal_instance.value == 3


# Generated at 2022-06-24 02:56:58.216160
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal('')
    if a.value:
        return False
    return True



# Generated at 2022-06-24 02:57:03.001761
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Init error case, we should raise exception.
    try:
        _LazyModuleMarker()
    except:
        assert True
        return

    assert False



# Generated at 2022-06-24 02:57:09.008966
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mods = set()
    for i in xrange(100):
        module = 'module_name-%.2d' % i
        make_lazy(module)
        lazy_mods.add(module)

    assert lazy_mods == set(sys.modules.keys())
    for i in xrange(100):
        module = 'module_name-%.2d' % i
        assert isinstance(sys.modules[module], _LazyModuleMarker)



# Generated at 2022-06-24 02:57:11.328820
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for _LazyModuleMarker class, it should pass without failures.
    """
    module = modules.Module()
    assert isinstance(module, _LazyModuleMarker) == True


# Generated at 2022-06-24 02:57:12.854545
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert repr(_LazyModuleMarker()) == '<_LazyModuleMarker object at 0x'


# Generated at 2022-06-24 02:57:20.984571
# Unit test for function make_lazy
def test_make_lazy():
    def set_lazy():
        make_lazy("foo.bar")
        assert sys.modules["foo.bar"]
        assert isinstance(sys.modules["foo.bar"], _LazyModuleMarker)

        # mod1 should access the module
        mod1 = __import__("foo.bar")
        assert not isinstance(mod1, _LazyModuleMarker)

        # mod2 should already have been loaded by mod1
        mod2 = __import__("foo.bar")
        assert not isinstance(mod2, _LazyModuleMarker)

        # make_lazy again should not replace the value in sys.modules
        make_lazy("foo.bar")
        assert sys.modules["foo.bar"] is mod2

    # mod1 should be a LazyModule
    set_lazy()

# Generated at 2022-06-24 02:57:22.513990
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(5)

# Generated at 2022-06-24 02:57:24.128686
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    alazy_module = _LazyModuleMarker()
    assert(isinstance(alazy_module, _LazyModuleMarker))



# Generated at 2022-06-24 02:57:25.670828
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import pytest
    with pytest.raises(TypeError):
        test = _LazyModuleMarker()


# Generated at 2022-06-24 02:57:29.046666
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5


# Generated at 2022-06-24 02:57:30.041086
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker

# Generated at 2022-06-24 02:57:31.032483
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass



# Generated at 2022-06-24 02:57:33.047525
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:43.503333
# Unit test for function make_lazy
def test_make_lazy():
    import os, sys
    import nose
    import os.path
    os.chdir(os.path.join(os.path.dirname(__file__), '..', '..'))
    sys.path.insert(0, os.path.abspath("."))
    module = __import__("test.test_make_lazy")
    sys.path.pop(0)
    assert os.path.abspath("test/test_make_lazy.py").lower() == os.path.abspath(module.__file__).lower()
    make_lazy("test.test_make_lazy")
    module = __import__("test.test_make_lazy")
    assert isinstance(module, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:51.632748
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import doctest


# Generated at 2022-06-24 02:58:00.328170
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to ensure `make_lazy` works with basic module loading.
    """
    # Simulate a fresh import of a module
    sys.modules["example"] = NonLocal(None)

    make_lazy("example")

    # The resulting module should be of type LazyModule
    assert isinstance(sys.modules["example"], _LazyModuleMarker)
    # It should be lazy, and not have any attributes
    assert not hasattr(sys.modules["example"], "LazyModule")

    # Once we try to access an attribute on it, it should
    # fully import the original module.
    assert sys.modules["example"].LazyModule

    assert hasattr(sys.modules["example"], "LazyModule")

__all__ = ['make_lazy', '_LazyModuleMarker', 'NonLocal']

# Generated at 2022-06-24 02:58:06.715309
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Testing constructor method of class _LazyModuleMarker
    """

# Generated at 2022-06-24 02:58:08.329738
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(72)
    assert nl.value == 72
    nl.value = 92
    assert nl.value == 92

# Generated at 2022-06-24 02:58:11.879555
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert isinstance(
        lmm,
        _LazyModuleMarker
    )


# Generated at 2022-06-24 02:58:13.339003
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

# Generated at 2022-06-24 02:58:21.698784
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    del sys.modules['test_make_lazy']
    make_lazy('test_make_lazy')

    import test_make_lazy
    assert type(test_make_lazy) == _LazyModuleMarker, \
        "test_make_lazy should be of LazyModule type, but instead is %s" % \
        (str(type(test_make_lazy)))

    assert hasattr(test_make_lazy, 'os'), \
        "LazyModule test_make_lazy should have `os` attribute, but does not"

    assert test_make_lazy.os is os, \
        "test_make_lazy.os should be the same as os, but is not"


# Generated at 2022-06-24 02:58:22.784411
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 02:58:27.081107
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal("LazyModules")

# Generated at 2022-06-24 02:58:28.376407
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(0)


# Generated at 2022-06-24 02:58:35.277302
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(None)
    assert(v.value == None)


# Test for the make_lazy function:
# To make a test for this function, we will create a test module that is lazy.
# It should have a class that has a get_answer() method, and the value is 42.
# The test suite will then allow us to access the function.

# Here's our test module

# Generated at 2022-06-24 02:58:40.765261
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-24 02:58:42.872524
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Constructor
    """
    # Test 1
    obj = _LazyModuleMarker()
    assert isinstance(obj, object)


# Generated at 2022-06-24 02:58:48.579312
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(NonLocal('value') is not None)
    assert(NonLocal('value').value is not None)

# Generated at 2022-06-24 02:58:50.995414
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Testcase for _LazyModuleMarker instances
    """
    a = _LazyModuleMarker()
    b = _LazyModuleMarker()
    assert a != b
    assert a.__class__ == b.__class__


# Generated at 2022-06-24 02:58:58.513394
# Unit test for function make_lazy
def test_make_lazy():
    import os

    # Force python to think that the module hasn't been imported
    if 'os' in sys.modules:
        # Python 3
        del sys.modules['os']
    else:
        # Python 2
        del sys.modules['__main__']

    make_lazy('os')

    module = sys.modules['os']

    assert isinstance(module, _LazyModuleMarker)

    assert module.path is os.path

    module = sys.modules['os']

    assert isinstance(module, ModuleType)

    assert module is os

# Generated at 2022-06-24 02:59:02.467334
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocalTest(object):
        def __init__(self):
            self.x = 1

        def test_nonlocal_constructor(self):
            v = NonLocal(self.x)
            assert v.value == 1

    NonLocalTest().test_nonlocal_constructor()



# Generated at 2022-06-24 02:59:12.790119
# Unit test for function make_lazy
def test_make_lazy():
    # We are in the datadog_checks_dev/datadog_checks/dev directory.
    # This means that when we import the datadog_checks_dev, it
    # should be the datadog_checks/dev folder.
    # A test module is there called `test_module.py`
    module = __import__('datadog_checks_dev.test_module')
    assert module.__name__ == 'datadog_checks_dev.test_module'
    assert module.x == 'some text'

    # We need to make sure that the module is not being imported
    # after we have evicted it from sys to make sure it is truly
    # being loaded lazily.
    del sys.modules['datadog_checks_dev.test_module']

    # Mark this module as lazy
    make_lazy

# Generated at 2022-06-24 02:59:21.094763
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('my.module.path')

    import my.module.path
    assert isinstance(my.module.path, _LazyModuleMarker)
    assert 'rmq.py' not in sys.modules

    # does nothing, if it was a real module, it would be imported
    import my.module.path.rmq

    assert isinstance(my.module.path, ModuleType)
    assert 'rmq.py' in sys.modules



# Generated at 2022-06-24 02:59:23.974730
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    assert x.value == 42


# Generated at 2022-06-24 02:59:24.878143
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert n.value == None
    

# Generated at 2022-06-24 02:59:28.698768
# Unit test for function make_lazy
def test_make_lazy():
    import os
    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)   # lazy marker
    assert isinstance(os, ModuleType)          # also a module
    assert os.__name__ == 'os'                 # true name
    assert os.path.isdir('/')                  # lazy loaded
    import os as os_m                          # make regular module
    assert os is not os_m                      # not the same

# Generated at 2022-06-24 02:59:31.984293
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local_obj = NonLocal('A')
    assert(non_local_obj.value is 'A')


# Generated at 2022-06-24 02:59:33.773683
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(2)
    assert nl.value == 2


# Generated at 2022-06-24 02:59:43.202971
# Unit test for function make_lazy
def test_make_lazy():
    lazy = make_lazy('sys')
    assert 'sys' not in sys.modules
    assert isinstance(sys, _LazyModuleMarker)
    assert isinstance(sys, ModuleType)

    lazy = make_lazy('os')
    assert 'os' not in sys.modules
    assert isinstance(os, _LazyModuleMarker)
    assert isinstance(os, ModuleType)

    lazy = make_lazy('time')
    assert 'time' not in sys.modules
    assert isinstance(time, _LazyModuleMarker)
    assert isinstance(time, ModuleType)

    lazy = make_lazy('logging')
    assert 'logging' not in sys.modules
    assert isinstance(logging, _LazyModuleMarker)
    assert isinstance(logging, ModuleType)


# Generated at 2022-06-24 02:59:45.770545
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    print(a)
    a._LazyModuleMarker__init__
    print(a)



# Generated at 2022-06-24 02:59:51.467051
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1
    x.value = 2
    assert x.value == 2
    try:
        x.fake = 3
    except AttributeError:
        pass
    else:
        raise AssertionError('NonLocal type should have only one attribute')

# Generated at 2022-06-24 02:59:59.572503
# Unit test for function make_lazy
def test_make_lazy():
    __name__ = '__main__' # prevent import from raising an error

    make_lazy('__main__')

    assert not hasattr(sys.modules['__main__'], '__mro__')

    assert not hasattr(sys.modules['__main__'], 'make_lazy')

    # a lazy module should still be a module
    assert isinstance(sys.modules['__main__'], ModuleType)
    assert isinstance(sys.modules['__main__'], _LazyModuleMarker)

    # after accessing an attribute, the module should not be lazy anymore
    sys.modules['__main__'].test_make_lazy
    assert not isinstance(sys.modules['__main__'], _LazyModuleMarker)

# Generated at 2022-06-24 03:00:03.479355
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Create a test for class `NonLocal`
    def test(value):
        nonlocal_obj = NonLocal(value)
        assert value == nonlocal_obj.value

    list_value = [1, 2, 3]
    dict_value = {'key': 'value'}
    test(list_value)
    test(dict_value)    
    


# Generated at 2022-06-24 03:00:06.122537
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker
    assert lazy_module.__class__.__name__ == '_LazyModuleMarker'

test__LazyModuleMarker()


# Generated at 2022-06-24 03:00:07.697375
# Unit test for constructor of class NonLocal
def test_NonLocal():
    testObject = NonLocal([1,2])
    assert testObject.value is not None

test_NonLocal()

# Generated at 2022-06-24 03:00:11.094654
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Bar(object):
        def __init__(self):
            self.z = NonLocal(None)

        def foo(self):
            self.z.value = 10
    b = Bar()
    b.foo()
    assert b.z.value == 10


# Generated at 2022-06-24 03:00:22.307488
# Unit test for function make_lazy
def test_make_lazy():
    import weakref

    # Make sure make_lazy() doesn't cause an import
    make_lazy('__builtin__')
    del sys.modules['__builtin__']
    assert '__builtin__' not in weakref.getweakrefs(sys.modules)

    # Make sure make_lazy() doesn't cause an import for a module that isn't in
    # sys.modules
    make_lazy('this_module_never_existed_and_never_will')
    assert 'this_module_never_existed_and_never_will' not in weakref.getweakrefs(sys.modules)

    # Make sure make_lazy() does import a module that is in sys.modules
    # and that it does the import at the right time.
    import __builtin__

# Generated at 2022-06-24 03:00:25.779721
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Unit test: _LazyModuleMarker")
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:30.559821
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr( _LazyModuleMarker, '__init__' )
    try:
        _LazyModuleMarker()
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 03:00:37.038457
# Unit test for function make_lazy
def test_make_lazy():
    try:
        assert sys.modules.get('lazy') is None
        make_lazy('lazy')
        assert sys.modules.get('lazy') is None
        import lazy
        assert isinstance(lazy, object)
        assert not isinstance(lazy, _LazyModuleMarker)
        assert sys.modules['lazy'] is lazy
    finally:
        if 'lazy' in sys.modules:
            del sys.modules['lazy']

# Generated at 2022-06-24 03:00:40.233684
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert not (issubclass(object, _LazyModuleMarker))
    assert issubclass(LazyModule, object)
    assert issubclass(LazyModule, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:45.587486
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    non_local = NonLocal(10)
    assert non_local.value == 10
    other_value = NonLocal(10)
    assert other_value.value == 10


# Generated at 2022-06-24 03:00:52.919055
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test if make_lazy will properly create a lazy module.
    """
    import tempfile
    import shutil
    import inspect

    # Create the structure of a module.
    module_dir = tempfile.mkdtemp()
    module_path = os.path.join(module_dir, 'module')
    module_file = os.path.join(module_path, '__init__.py')
    os.makedirs(module_path)

    with open(module_file, 'w') as fp:
        fp.write('def some_function():\n'
                 '    """\n'
                 '    Dummy function for unit testing\n'
                 '    """\n'
                 '    pass\n')

    make_lazy(module_path)

    assert module_path not in sys

# Generated at 2022-06-24 03:00:57.388731
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 03:01:03.847335
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from nose.tools import assert_equal
    test_value = 'Test Value'
    nonlocal_value = None
    nonlocal_value = NonLocal(test_value)
    assert_equal(nonlocal_value.value, test_value)

if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
                   exit=False)

# Generated at 2022-06-24 03:01:05.316903
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1


# Generated at 2022-06-24 03:01:12.198141
# Unit test for function make_lazy
def test_make_lazy():
    # define module `test_make_lazy` with a class TestLazy
    # which has func `test_func`
    test_module = sys.modules['test_make_lazy'] = ModuleType('test_make_lazy')
    class TestLazy:
        def __init__(self):
            self.test_var = 10
        def test_func(self):
            return self.test_var
    test_module.TestLazy = TestLazy

    # mark `test_make_lazy` as lazy
    make_lazy('test_make_lazy')

    # Try to access attributes
    # this should import the module `test_make_lazy`
    assert test_module.TestLazy.test_var == 10
    assert test_module.TestLazy().test_func() == 10

    #

# Generated at 2022-06-24 03:01:15.102197
# Unit test for constructor of class NonLocal
def test_NonLocal():
    X = NonLocal(4)

    assert(X.value == 4)

# Generated at 2022-06-24 03:01:18.861982
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("------Unit Test of _LazyModuleMarker.py------")

    _LazyModuleMarker()

    print("------Unit Test Finished------")

if __name__ == "__main__":
    # Test
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:01:20.235059
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_is_instance(_LazyModuleMarker(), ModuleType)



# Generated at 2022-06-24 03:01:29.698885
# Unit test for function make_lazy
def test_make_lazy():
    # simulate two different modules:
    # module A depends on module B
    A = object()
    B = object()
    sys.modules['A'] = A
    sys.modules['B'] = B

    class C(object):
        pass

    # make A and B lazy:
    make_lazy('A')
    make_lazy('B')

    # import A but not B
    _ = __import__('A')

    assert module_is_lazy('A')
    assert module_is_lazy('B')
    assert type(_) is C
    assert module_is_lazy('A')
    assert module_is_lazy('B')



# Generated at 2022-06-24 03:01:38.895756
# Unit test for function make_lazy
def test_make_lazy():
    # Tests that make_lazy.make_lazy has the correct behavior.
    # NOTE: Due to the way that Python imports work, this won't actually work
    # when called on a module directly.
    # In practice, you'll have to have a lazy-imported module, and then run
    # this test on that.
    test_mod = sys.modules['make_lazy']

    # a module that will not be in the sys.modules at this point
    test_mod_path = test_mod.__name__ + '.lazy_test_mod'
    make_lazy(test_mod_path)

    # check that the object is not really a module.
    lazy_mod = sys.modules[test_mod_path]
    assert not isinstance(lazy_mod, ModuleType)

# Generated at 2022-06-24 03:01:40.246383
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('test'), _LazyModuleMarker)

# Generated at 2022-06-24 03:01:46.941397
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy('os')
    assert sys.modules.get('os') is not None
    assert isinstance(sys.modules.get('os'), _LazyModuleMarker)
    assert os is sys.modules.get('os')
    assert os.path.isdir('/')
    assert isinstance(sys.modules.get('os'), ModuleType)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 03:01:48.248574
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = 0
    a = NonLocal(x)
    assert a.value == 0

# Generated at 2022-06-24 03:01:51.365039
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 03:01:54.625408
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:01:57.486543
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('re')
    assert not hasattr(sys.modules['re'], 'compile')
    import re
    assert hasattr(re, 'compile')



# Generated at 2022-06-24 03:02:00.162014
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None
    x.value = 1
    assert x.value == 1

# Generated at 2022-06-24 03:02:01.690179
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert(m is not None)


# Generated at 2022-06-24 03:02:03.320327
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test():
        obj = NonLocal(42)
        return obj.value

    assert test() == 42



# Generated at 2022-06-24 03:02:11.503169
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    from django.test import TestCase

    class ModuleImporterTest(TestCase):
        def setUp(self):
            # Create a temporary directory
            self.test_dir = tempfile.mkdtemp()

            # Save the current sys.path
            self.old_path = sys.path

        def tearDown(self):
            # Delete test directory
            os.rmdir(self.test_dir)

            # Restore old sys.path
            sys.path = self.old_path

        def test_make_lazy(self):
            # Put our test directory first in the Python path.
            sys.path.insert(0, self.test_dir)

            # We'll need to create the module file on-the-fly. To do this, we'll
            # define a function that can create

# Generated at 2022-06-24 03:02:18.856062
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function.

    We want to make sure it is still callable
    and the module actually gets loaded.
    """
    make_lazy('tests.test_lazy')
    import tests.test_lazy  # this should not raise ImportError


if __name__ == "__main__":
    import sys
    import pytest

    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-24 03:02:24.256479
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function.
    """
    # Save the sys.modules because we are mutating it
    sys_modules = sys.modules.copy()
    # We don't actually have access to the module, so this will error
    # if it tries to import it
    try:
        make_lazy("this_module_does_not_exist")
    except:
        sys.modules = sys_modules
        raise
    # Check that the module is created
    assert sys.modules["this_module_does_not_exist"]

    # Check that we can get an attribute off of the lazy load module.
    # If the module didn't import, then the following line would error
    sys.modules["this_module_does_not_exist"].__name__

    # Check that we can still get at the attributes that we set in

# Generated at 2022-06-24 03:02:27.764020
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class C:
        a = 0
        def __init__(self):
            a = NonLocal(4)
            assert(a.value == 4)
            self.a = a.value

    assert(C().a == 4)


# Generated at 2022-06-24 03:02:36.288807
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['my_mod'] = None

    class ObjectWithAttribute(object):
        attribute = None

    # Make sure the module exists in the module cache
    assert 'my_mod' in sys.modules

    # Make sure trying to use the module throws an exception
    try:
        sys.modules['my_mod'].unknown_attribute
        assert False
    except Exception:
        pass

    # Make the module lazy
    make_lazy('my_mod')

    # Make sure that the module becomes lazy
    assert isinstance(sys.modules['my_mod'], _LazyModuleMarker)

    # Make the module real and try to use the module
    sys.modules['my_mod'].ObjectWithAttribute = ObjectWithAttribute
    assert sys.modules['my_mod'].ObjectWithAttribute.attribute is None

    # Make sure that the

# Generated at 2022-06-24 03:02:38.132268
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x=NonLocal(3)
    assert x.value==3


# Generated at 2022-06-24 03:02:42.261338
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    b = NonLocal('b')
    c = NonLocal((1, 2))

    assert a.value == 1
    assert b.value == 'b'
    assert c.value == (1, 2)

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 03:02:44.065716
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1234)
    assert(x.value == 1234)

## Unit test for make_lazy

# Generated at 2022-06-24 03:02:51.229760
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lazy_module_test = _LazyModuleMarker()
    try:
        assert(lazy_module_test.__class__)
    except:
        print("Exception raised")
    return lazy_module_test.__class__
# Testing the make_lasy method

# Generated at 2022-06-24 03:02:55.880085
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, _LazyModuleMarker)


# Test for constructor of class LazyModule

# Generated at 2022-06-24 03:02:57.682733
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(LazyModule(), _LazyModuleMarker)

# Generated at 2022-06-24 03:03:01.577933
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('hello')
    assert(nl.value == 'hello')


# Generated at 2022-06-24 03:03:12.029795
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules

    def f():
        make_lazy('foo')
        assert 'foo' not in sys_modules
        import foo
        assert foo is sys_modules['foo']

        make_lazy('foo.bar')
        assert 'foo.bar' not in sys_modules
        import foo.bar
        assert foo.bar is sys_modules['foo.bar']

        make_lazy('foo.baz.buz')
        assert 'foo.baz.buz' not in sys_modules
        import foo.baz.buz
        assert foo.baz.buz is sys_modules['foo.baz.buz']

        del sys_modules['foo']
        del sys_modules['foo.bar']
        del sys_modules['foo.baz.buz']
        assert 'foo'

# Generated at 2022-06-24 03:03:16.647254
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('Test_Module')
    import Test_Module
    # Check that Test_Module can be imported
    assert Test_Module
    assert isinstance(Test_Module, _LazyModuleMarker)


# Test make_lazy for an attribute of a module

# Generated at 2022-06-24 03:03:23.074921
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    if sys.version_info < (3,):
        m = ModuleType('foo')
        mk = _LazyModuleMarker()
        assert isinstance(m, _LazyModuleMarker) == False
        assert isinstance(mk, _LazyModuleMarker) == True
    else:
        assert _LazyModuleMarker


# Generated at 2022-06-24 03:03:29.127973
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)
