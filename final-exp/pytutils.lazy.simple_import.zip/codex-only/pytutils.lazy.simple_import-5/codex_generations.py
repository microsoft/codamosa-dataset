

# Generated at 2022-06-24 02:53:28.699286
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 02:53:39.580992
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that using make_lazy is equivalent to using the builtin __import__.
    """
    class TestClass(object):
        pass

    class LazyTestClass(TestClass):
        """
        Test class that should be lazy.
        """
        pass

    class TestSubClass(TestClass):
        pass

    class LazyTestSubClass(TestSubClass):
        pass

    make_lazy("test_module")

    import test_module  # noqa
    from types import ModuleType  # noqa

    assert isinstance(test_module, ModuleType)

    assert isinstance(test_module.TestClass, type)
    assert not isinstance(test_module.TestClass, ModuleType)
    assert issubclass(test_module.TestClass, object)


# Generated at 2022-06-24 02:53:45.201603
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    import time
    import shutil
    from multiprocessing import Process
    from multiprocessing.connection import Client

    class TestModule(object):
        """
        A module to test lazy loading
        """
        def __init__(self):
            self.a = 1

    def _write_tmp_module(tmp_dir):
        """
        Writes the temp module
        """
        name = tempfile.mktemp(prefix='_tmp', suffix='.py', dir=tmp_dir)
        mod = os.path.splitext(os.path.basename(name))[0][1:]

# Generated at 2022-06-24 02:53:50.718784
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys.modules.clear()
    try:
        import lazy_loading
        del sys.modules['lazy_loading']
        make_lazy('lazy_loading')
        import lazy_loading
        assert isinstance(lazy_loading, _LazyModuleMarker)
    finally:
        del sys.modules['lazy_loading']

# Generated at 2022-06-24 02:53:54.460230
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(10)
    if non_local.value == 10:
        print("test_NonLocal PASSED")
    else:
        print("test_NonLocal FAILED")
test_NonLocal()


# Generated at 2022-06-24 02:53:56.616614
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker) is True


# Generated at 2022-06-24 02:54:02.658827
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy does not import the specified module until an attribute
    is accessed.
    """
    module_name = "lazy_module"

    # make sure it isn't already there
    if module_name in sys.modules:
        del sys.modules[module_name]

    def module_func():
        """
        This is the function in the module.
        """
        pass

    make_lazy(module_name)

    # make sure it isn't loaded yet
    assert module_name not in sys.modules

    # make sure we can access an attr in the module
    assert getattr(sys.modules[module_name], "module_func") is module_func



# Generated at 2022-06-24 02:54:04.927436
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Should return True if initialization was successful"""
    test_marker = _LazyModuleMarker()
    assert isinstance(test_marker, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:06.149089
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5


# Generated at 2022-06-24 02:54:16.348976
# Unit test for function make_lazy
def test_make_lazy():
    reload(sys)
    sys.setdefaultencoding('utf-8')
    
    lazy_mod = 'fake_module'
    assert lazy_mod not in sys.modules
    
    make_lazy(lazy_mod)
    assert lazy_mod in sys.modules
    assert lazy_mod not in globals()
    assert isinstance(sys.modules[lazy_mod], _LazyModuleMarker)
    assert isinstance(sys.modules[lazy_mod], ModuleType)
    
    # This won't import the module or raise an error
    getattr(sys.modules[lazy_mod], 'FAKE_CONSTANT')
    assert lazy_mod in globals()
    assert lazy_mod in sys.modules
    assert sys.modules[lazy_mod].FAKE_CONSTANT == 1
    

# Generated at 2022-06-24 02:54:17.497885
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LM = _LazyModuleMarker()
    assert issubclass(LM.__class__, object)


# Generated at 2022-06-24 02:54:20.668430
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Verify that mro does not exist
    assert(not hasattr(_LazyModuleMarker, '__mro__'))
    # Verify that mro is defined as a property
    assert(isinstance(_LazyModuleMarker.__mro__, property))
    # Verify that returns (LazyModule, ModuleType)
    assert(_LazyModuleMarker.__mro__ == (LazyModule, ModuleType))

# Generated at 2022-06-24 02:54:21.891533
# Unit test for function make_lazy
def test_make_lazy():
    import tempfile
    import shutil

    mod_path = 'test_make_lazy_mod'

# Generated at 2022-06-24 02:54:25.985153
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('this_is_a_test_of.this_module')

    from this_is_a_test_of import this_module
    from this_is_a_test_of import this_module_2

    # this should be a LazyModule
    assert isinstance(this_module, _LazyModuleMarker)

    # this should be an actual module
    assert not isinstance(this_module_2, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:37.279119
# Unit test for function make_lazy
def test_make_lazy():
    module_path = '__test_module'
    if module_path in sys.modules:
        del sys.modules[module_path]

    lazy_module = make_lazy(module_path)

    # Check that the module is a LazyModule
    assert isinstance(lazy_module, _LazyModuleMarker)

    # Check that the module is not in the sys.modules
    assert module_path not in sys.modules

    # Check that the module is lazy
    try:
        import __test_module
    except ImportError:
        pass

    try:
        getattr(__test_module, 'does_not_exist')
    except AttributeError:
        pass

    # Check that it is imported
    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], ModuleType)



# Generated at 2022-06-24 02:54:45.374985
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('lazy.test')
        import lazy.test
        assert isinstance(lazy.test, _LazyModuleMarker)

        import lazy.test
        assert isinstance(lazy.test, _LazyModuleMarker)

        lazy.test.a = 1
        import lazy.test
        assert lazy.test.a == 1
        assert not isinstance(lazy.test, _LazyModuleMarker)

        make_lazy('lazy.test2')
        import lazy.test2
        lazy.test2.b = 2
        import lazy.test2
        assert lazy.test2.b == 2
        assert not isinstance(lazy.test2, _LazyModuleMarker)

    finally:
        del sys.modules['lazy.test']

# Generated at 2022-06-24 02:54:46.657322
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() != None
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 02:54:49.118048
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal('bar')
    assert(foo.value == 'bar')
    foo.value = 'foobar'
    assert(foo.value == 'foobar')
    return foo


# Generated at 2022-06-24 02:54:51.907004
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test with no assignment
    var = NonLocal(3)
    assert var.value == 3
    # Test with assignment
    var.value = 5
    assert var.value == 5

# Generated at 2022-06-24 02:55:02.244900
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    # Ensure the python version is 2.7.x
    assert sys.version_info[:2] == (2, 7)
    # Remove any tested modules
    for module in ('testmod', 'testmod.submod'):
        if module in sys.modules:
            del sys.modules[module]

    # Lazy module
    make_lazy('testmod')
    assert 'testmod' in sys.modules
    assert isinstance(sys.modules['testmod'], _LazyModuleMarker)

    # Check that the module can be used
    from testmod import submod
    assert 'testmod.submod' in sys.modules
    assert isinstance(sys.modules['testmod.submod'], ModuleType)

# Generated at 2022-06-24 02:55:04.657093
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """Tests if NonLocal is initialized correctly"""
    nl = NonLocal("foo")
    assert(nl.value == "foo")

# Generated at 2022-06-24 02:55:06.907843
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:55:11.155811
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an instance of _LazyModuleMarker
    test = _LazyModuleMarker()
    # Create a ModuleType object
    test2 = ModuleType('test2')

    assert isinstance(test, _LazyModuleMarker)
    assert isinstance(test, ModuleType)
    assert not isinstance(test2, _LazyModuleMarker)

# Tests for function make_lazy

# Generated at 2022-06-24 02:55:17.771241
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()

    try:
        # Check whether exception is raised or not
        # True = No exception
        # False = Exception is raised
        assert lazy_module_marker.__init__()
    except Exception:
        # False if exception is raised
        assert False
    else:
        # True if exception is not raised
        assert True

# Generated at 2022-06-24 02:55:28.455143
# Unit test for function make_lazy
def test_make_lazy():
    """
    This test should be run with a clean sys.modules (not running django tests)
    It must be run from the directory containing this file.
    """
    from contextlib import contextmanager
    from types import ModuleType
    import sys

    ##############
    # Test Setup #
    ##############

    @contextmanager
    def clean_sys_modules():
        """
        Clear the `sys.modules` dictionary to produce a clean environment
        for our testing.

        This is required because when running django tests the
        sys.modules dictionary is filled up with all sorts of
        stuff that we don't want.
        """
        modules_backup = sys.modules.copy()
        sys.modules.clear()
        yield
        sys.modules.clear()
        sys.modules.update(modules_backup)


# Generated at 2022-06-24 02:55:30.533507
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except TypeError:
        pass
    else:
        assert False, 'Error in constructor of class _LazyModuleMarker'

# Generated at 2022-06-24 02:55:34.547860
# Unit test for constructor of class NonLocal
def test_NonLocal():
    scope = NonLocal(None)
    assert scope.value is None
    scope.value = 1
    assert scope.value is 1
    scope.value = 'foo'
    assert scope.value == 'foo'
    assert scope.value != 'bar'
    assert scope.value is not None
    assert scope.value != '1'
    assert scope.value is not 1
    assert scope.value == 'foo'

# Generated at 2022-06-24 02:55:41.453177
# Unit test for function make_lazy
def test_make_lazy():
  # make_lazy
  def inner_func():
    make_lazy('site')
    mod_site = sys.modules['site']
    assert 'site' in sys.modules
    assert isinstance(mod_site, _LazyModuleMarker)
    assert mod_site.__class__.__name__ == 'LazyModule'
    assert 'site' not in sys.modules
    assert isinstance(sys.modules['site'], ModuleType)

  inner_func()
  assert 'site' in sys.modules

# Generated at 2022-06-24 02:55:48.545523
# Unit test for function make_lazy
def test_make_lazy():

    # Test that the module we are about to import does not exist.
    assert 'test_module' not in sys.modules
    test_make_lazy.__module__ = 'test_module'

    make_lazy('test_module')
    # Test that the module was imported as a lazy module
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    assert test_make_lazy.__name__ == 'test_make_lazy'
    assert test_make_lazy.__module__ == 'test_module'

# Generated at 2022-06-24 02:55:55.654144
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import django.test
    from django.core.management.base import BaseCommand

    make_lazy("django.test")
    assert sys.modules["django.test"] is not django.test
    assert isinstance(sys.modules["django.test"], _LazyModuleMarker)
    assert isinstance(sys.modules["django.test"], ModuleType)
    assert isinstance(sys.modules["django.test"], object)

    # Now check to make sure it works
    assert BaseCommand.__subclasses__()[0].__module__ != 'django.test'
    BaseCommand.__subclasses__()[0]  # This should import django.test
    assert BaseCommand.__subclasses__()[0].__module__ == 'django.test'

# Generated at 2022-06-24 02:56:06.305588
# Unit test for function make_lazy
def test_make_lazy():
    import six
    import sys
    import os

    TEST_DIR = os.getcwd()

    sys.path.insert(0, TEST_DIR)

    # Make a test module
    with open(os.path.join(TEST_DIR, 'mytest.py'), 'w') as f:
        f.write('''
        def foo():
            return 'from_mytest'
        ''')

    # Make a test module
    with open(os.path.join(TEST_DIR, 'from_mytest.py'), 'w') as f:
        f.write('''
        def foo():
            return 'from_from_mytest'
        ''')

    # Import the newly created module
    try:
        import mytest
    except ImportError:
        pass

# Generated at 2022-06-24 02:56:11.949257
# Unit test for function make_lazy
def test_make_lazy():
    # Create a module, and then create a lazy version of it.
    import os
    make_lazy(os)
    assert isinstance(os, _LazyModuleMarker)
    assert not isinstance(os, ModuleType)
    # Its different from a normal module.
    assert os is not sys.modules['os']

    # If an attribute is needed, then the lazy module will
    # import the real module
    assert os.path.basename(__file__) == 'test_lazy.py'
    assert os is sys.modules['os']

# Generated at 2022-06-24 02:56:13.616200
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl_obj = NonLocal("lalala")
    assert nl_obj.value == "lalala"


# Generated at 2022-06-24 02:56:14.446522
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-24 02:56:15.742452
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("a")
    assert nl.value == "a"



# Generated at 2022-06-24 02:56:17.660351
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 02:56:18.932215
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(5)
    nonlocal_obj.value = 10


test_NonLocal()

# Generated at 2022-06-24 02:56:20.426798
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 02:56:22.282368
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    try:
        a.__mro__
    except:
        assert False # Incorrect class definition
    assert True # Test Passed

# unit test for function make_lazy

# Generated at 2022-06-24 02:56:29.226148
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # arrange
    module_path = "django.contrib.auth.middleware"
    make_lazy(module_path)
    sys_modules = sys.modules
    # act
    module = sys_modules[module_path]
    # assert
    assert module is not None
    assert isinstance(module, _LazyModuleMarker)


# Generated at 2022-06-24 02:56:40.223835
# Unit test for function make_lazy
def test_make_lazy():
    assert 'tests_django_app.lazy' not in sys.modules
    assert 'tests_django_app.lazy.foo' not in sys.modules
    assert 'tests_django_app.lazy.bar' not in sys.modules

    make_lazy('tests_django_app.lazy')

    assert 'tests_django_app.lazy' in sys.modules
    assert 'tests_django_app.lazy.foo' not in sys.modules
    assert 'tests_django_app.lazy.bar' not in sys.modules
    assert isinstance(sys.modules['tests_django_app.lazy'], _LazyModuleMarker)

    assert sys.modules['tests_django_app.lazy'].baz == 'baz'


# Generated at 2022-06-24 02:56:47.872676
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import tempfile

    module_name = "test_make_lazy"

    # Ensure that the module does not exist yet
    assert module_name not in sys.modules

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py") as f:
        # Write the code for the module
        f.write("""\
            a = 1
        """)
        f.flush()

        # Import the module
        import os.path
        sys.path.insert(0, os.path.dirname(f.name))
        module_path = os.path.splitext(os.path.basename(f.name))[0]

        # Mark the module as lazy
        make_lazy(module_path)

        # Ensure that the module does not exist yet

# Generated at 2022-06-24 02:56:59.509742
# Unit test for function make_lazy

# Generated at 2022-06-24 02:57:04.801324
# Unit test for function make_lazy
def test_make_lazy():

    # You can import the module without importing its child modules
    import django.db as db
    assert db.__name__ == 'django.db'

    # The module is properly imported
    from django.db.models import Model
    assert isinstance(Model, type)

    # The module is properly inherited
    from django.db import models
    assert issubclass(Model, models.Model)



# Generated at 2022-06-24 02:57:09.915409
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5

# Generated at 2022-06-24 02:57:12.256816
# Unit test for constructor of class NonLocal
def test_NonLocal():
    instance = NonLocal(1)
    assert isinstance(instance, NonLocal)
    assert instance.value == 1



# Generated at 2022-06-24 02:57:20.951677
# Unit test for function make_lazy
def test_make_lazy():
    from . import lazy_test_module
    # check that we don't import the module just from importing it
    if '_lazysocket_data' in sys.modules:
        raise AssertionError("A module was imported")

    module_path = '_lazysocket.lazy_test_module'
    make_lazy(module_path)
    if module_path not in sys.modules:
        raise AssertionError("Module was not properly inserted")

    # check that the module was not imported
    if '_lazysocket_data' in sys.modules:
        raise AssertionError("A module was imported")

    # check that we can get attributes off of it
    if lazy_test_module.test != "hello world":
        raise AssertionError("Could not get attribute from lazy module")

    # check that

# Generated at 2022-06-24 02:57:24.571833
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('val')
    try:
        n.value = 'a'
        assert False
    except AttributeError as e:
        # __slots__ needs to be defined so that we can add the attribute value
        pass



# Generated at 2022-06-24 02:57:25.699763
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal(1)
    assert(obj.value == 1)


# Generated at 2022-06-24 02:57:37.338182
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    sys_modules = sys.modules  # cache in the locals
    module_path = 'lib.test_import'
    module = NonLocal(None)

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute__ function.
            return (LazyModule, ModuleType)


# Generated at 2022-06-24 02:57:38.662468
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(None)
    assert foo is not None
    assert foo.value is None

# Generated at 2022-06-24 02:57:41.088657
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Class's __mro__ is mocked.
    """
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 02:57:45.681494
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(12345)
    print(nonlocal_instance)
    print(nonlocal_instance.value)


# Generated at 2022-06-24 02:57:47.418682
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()         # create an instance of this class
    assert marker is not None            # check if marker is None



# Generated at 2022-06-24 02:57:53.995507
# Unit test for constructor of class NonLocal
def test_NonLocal():
    global module
    module = NonLocal("test")
    print("Value of module: " + module.value)
    module.value = "test1"
    print("Value of module: " + module.value)

test_NonLocal()


# Generated at 2022-06-24 02:57:56.125081
# Unit test for constructor of class NonLocal
def test_NonLocal():
    f = NonLocal(3)
    assert f.value == 3


# Generated at 2022-06-24 02:58:05.548055
# Unit test for function make_lazy
def test_make_lazy():
    import imp
    import inspect
    import itertools
    import os
    import pickle
    import py_compile
    import re
    import struct
    import unicodedata
    import zlib

    # Note: we are checking for imp's module type, not the class above.
    def assert_lazy(module_path):
        assert isinstance(sys.modules[module_path], imp.NullImporter)

    def assert_not_lazy(module_path):
        assert not isinstance(sys.modules[module_path], imp.NullImporter)
        assert module_path in sys.modules

    make_lazy('imp')
    assert_lazy('imp')
    import imp

    make_lazy('inspect')
    assert_lazy('inspect')
    import inspect


# Generated at 2022-06-24 02:58:06.284775
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1



# Generated at 2022-06-24 02:58:08.264354
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # if new object is from _LazyModuleMarker to equal True
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker) == True



# Generated at 2022-06-24 02:58:11.835850
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    @Test method NonLocal constructor
    """
    nonlocal_tmp = NonLocal('foo')
    assert nonlocal_tmp.value == 'foo'

# Generated at 2022-06-24 02:58:13.696821
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    assert nl.value == 123



# Generated at 2022-06-24 02:58:22.058515
# Unit test for function make_lazy
def test_make_lazy():
    # Checks that lazy module behaves properly as an actual module
    make_lazy('test_lazy_modules')
    import test_lazy_modules
    assert isinstance(test_lazy_modules, _LazyModuleMarker)
    assert isinstance(test_lazy_modules, ModuleType)
    assert hasattr(test_lazy_modules, '__mro__')
    assert test_lazy_modules.__mro__ == (test_lazy_modules, ModuleType)
    assert not hasattr(test_lazy_modules, 'lazy_module')
    assert test_lazy_modules.__name__ == 'test_lazy_modules'
    assert hasattr(test_lazy_modules, 'lazy_module')

# Generated at 2022-06-24 02:58:25.891097
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker != None

# Generated at 2022-06-24 02:58:28.592032
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except TypeError:
        # _LazyModuleMarker has no ctor, it is a marker class
        pass

# Generated at 2022-06-24 02:58:32.848971
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_obj = _LazyModuleMarker()
    isinstance(test_obj, _LazyModuleMarker)



# Generated at 2022-06-24 02:58:39.792706
# Unit test for function make_lazy
def test_make_lazy():  # pragma: no cover
    import sys
    import warnings

    # Test that a new module is lazy by default
    sys.modules['foobar'] = None
    make_lazy('foobar')
    assert sys.modules['foobar'] is not None
    assert isinstance(sys.modules['foobar'], _LazyModuleMarker)
    assert sys.modules['foobar'].__name__ == 'foobar'

    # Test that we can use the module
    import foobar
    foobar.x = 1
    assert foobar.x == 1

    # Test that we don't have an infinite recursion loop
    del sys.modules['foobar']
    make_lazy('foobar')
    assert sys.modules['foobar'] is not None

# Generated at 2022-06-24 02:58:40.634057
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-24 02:58:42.442479
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('unittest'), ModuleType) is False
    print('test_LazyModuleMarker passed')



# Generated at 2022-06-24 02:58:47.146783
# Unit test for constructor of class NonLocal
def test_NonLocal():

    nl = NonLocal(0)
    assert nl.value == 0

    # nonlocal Statement
    def test():
        x = nl.value

        def inner():
            nonlocal x
            x = 1

        inner()
        return x

    assert test() == 1



# Generated at 2022-06-24 02:58:53.327759
# Unit test for function make_lazy
def test_make_lazy():
    m1 = __import__('multiprocessing')
    assert not isinstance(m1, _LazyModuleMarker)
    assert m1
    make_lazy('multiprocessing')
    m2 = __import__('multiprocessing')
    assert isinstance(m2, _LazyModuleMarker)
    assert not m2
    assert hasattr(m2, 'version')
    m3 = __import__('multiprocessing')
    assert not isinstance(m3, _LazyModuleMarker)
    assert m3
    assert m1 == m3
    assert hasattr(m3, 'version')

# Make the modules lazy.
# We can't directly list them here because the modules may not exist yet.

# Generated at 2022-06-24 02:58:57.970024
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the constructor of class NonLocal
    """
    assert NonLocal(1).value == 1
    assert NonLocal('a').value == 'a'
    assert NonLocal(True).value is True
    assert NonLocal([]).value == []
    assert NonLocal({}).value == {}


# Generated at 2022-06-24 02:58:59.563718
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal("a")
    assert n.value == "a"


# Generated at 2022-06-24 02:59:04.296280
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Foo(_LazyModuleMarker):
        pass
    assert isinstance(Foo(), _LazyModuleMarker) is False
    assert isinstance(Foo(), object) is True
    assert isinstance(Foo(), ModuleType) is False


# Generated at 2022-06-24 02:59:11.526736
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

    sys.modules['lm'] = _LazyModuleMarker()
    # equal to import lm
    assert sys.modules['lm']
    assert isinstance(sys.modules['lm'], _LazyModuleMarker)
    del sys.modules['lm']
    # make sure we can create LazyModuleMarker objects multiple times
    assert _LazyModuleMarker()
    # Clean up the test
    del sys.modules['lm']


# Generated at 2022-06-24 02:59:22.366124
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import os
        make_lazy('os')

        assert not hasattr(os, 'getcwd')
        assert os.path.join('foo', 'bar') == 'foo/bar'
        assert os.getcwd() == os.getcwd()
    finally:
        del sys.modules['os']
        sys.modules['os'] = __import__('os')



# Generated at 2022-06-24 02:59:24.854952
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(42)
    assert foo.value == 42
    foo.value = 43
    assert foo.value == 43


# Generated at 2022-06-24 02:59:32.197836
# Unit test for function make_lazy
def test_make_lazy():
    import inspect
    import os
    import sys

    # create a fake module
    module_name = 'test_module'
    module_path = 'test_module.py'

    # write the module to disk
    with open(module_path, 'w') as test_module:
        module_text = inspect.cleandoc("""\
            import sys

            def hello():
                print('Hello, World!')

            sys.modules[__name__] = locals()
        """)
        test_module.write(module_text)

    # import it (as a lazy module)
    make_lazy(module_name)
    sys.modules[module_name]

    # check that it is a LazyModule
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # check that it hasn

# Generated at 2022-06-24 02:59:35.827787
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Return true if the constructor of class _LazyModuleMarker is
    functioning as expected, otherwise return false.
    """

    module = _LazyModuleMarker()
    assert(isinstance(module, _LazyModuleMarker))

    return True


# Generated at 2022-06-24 02:59:37.109685
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))



# Generated at 2022-06-24 02:59:44.418240
# Unit test for function make_lazy
def test_make_lazy():
    class LazyModule(_LazyModuleMarker):
        def __mro__(self):
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            return None

    module_path = '__my_lazy_module__'
    module = LazyModule()

    sys.modules[module_path] = module
    make_lazy(module_path)

    assert module is not sys.modules[module_path]
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:59:47.466642
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Cls(object):
        def __init__(self):
            self.i = NonLocal(1)

    o = Cls()
    o.i.value = 2
    assert o.i.value == o.i.value


# Generated at 2022-06-24 02:59:53.013447
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert isinstance(nl, NonLocal)

    def test_fn(nl):
        nl.value = 3
        return nl
    assert 3 == test_fn(nl).value

    class TestClass(object):
        def test_fn(self, nl):
            nl.value = 4
            return nl
    assert 4 == TestClass().test_fn(nl).value

    class TestSubClass(TestClass):
        pass
    assert 4 == TestSubClass().test_fn(nl).value

# Generated at 2022-06-24 03:00:01.083571
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys

    t = []

    # we are going to lazy load the module "test_mod" at some point,
    # and keep track of when the module is actually imported
    def importer(name, globals=None, locals=None, fromlist=None):
        if name == "test_mod":
            t.append(1)
        return __import__(name, globals, locals, fromlist)

    # swap out the real import for our little test version
    sys.modules["__builtin__"].__import__ = importer

    # load the module and set an attribute
    make_lazy("test_mod")
    import test_mod  # pylint: disable=unused-variable
    test_mod.x = 20

    # check that the

# Generated at 2022-06-24 03:00:03.918901
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker_instance = _LazyModuleMarker()
    except (AttributeError, TypeError):
        AssertionError()



# Generated at 2022-06-24 03:00:07.910687
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    make_lazy('os.path')
    assert 'os.path' in sys.modules
    from os import path
    assert 'os.path' not in sys.modules
    assert isinstance(path, _LazyModuleMarker)
    assert not isinstance(path, ModuleType)
    assert isinstance(path, ModuleType)
    assert 'os.path' in sys.modules
    assert True


# Generated at 2022-06-24 03:00:09.509176
# Unit test for function make_lazy
def test_make_lazy():
    # import modules for testing
    import tempfile

    # create our module
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-24 03:00:10.776966
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert x.value == 10


# Generated at 2022-06-24 03:00:11.573224
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = 'value'
    n = NonLocal(value)
    if n.value != value:
        raise Exception

# Generated at 2022-06-24 03:00:18.731183
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    module_path = "test"

    class Module():
        def __init__(self):
            self.test = "test"

    sys.modules[module_path] = Module()

    make_lazy(module_path)

    assert not isinstance(sys.modules[module_path], Module)
    assert sys.modules[module_path].test == "test"

# Generated at 2022-06-24 03:00:21.162352
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(TypeError) as _excinfo:
        _LazyModuleMarker()
    assert 'cannot create' in str(_excinfo.value)

# Generated at 2022-06-24 03:00:23.657322
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker().mro() == [_LazyModuleMarker, object])



# Generated at 2022-06-24 03:00:34.861458
# Unit test for function make_lazy
def test_make_lazy():
    """
    Check that make_lazy works properly
    """
    import os
    # Check that normal module import works
    module_path = 'os'
    original_module = __import__(module_path)
    assert original_module is os

    # Check that setting make_lazy works (and does not destroy original)
    make_lazy(module_path)
    new_module = __import__(module_path)
    assert new_module is not os
    assert not isinstance(new_module, _LazyModuleMarker)
    assert isinstance(new_module, ModuleType)

    # Check that the delayed import works
    old_stat = os.stat
    del os
    del sys.modules[module_path]
    new_module = __import__(module_path)
    assert new_module is not os


# Generated at 2022-06-24 03:00:42.823758
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile

    old_modules = sys.modules.copy()

# Generated at 2022-06-24 03:00:45.003094
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    assert nl.value == 123

    nl.value = 321
    assert nl.value == 321


# Generated at 2022-06-24 03:00:48.893297
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class TestNonLocal(object):
        def __init__(self):
            self.var = NonLocal(5)

        def test(self):
            self.var.value += 1
            return self.var.value

    test_nonlocal_obj = TestNonLocal()
    assert test_nonlocal_obj.test() == 6
    assert test_nonlocal_obj.test() == 7


# Generated at 2022-06-24 03:00:50.533950
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(None)
    nonlocal_var.value = 123
    print (nonlocal_var.value)


# Generated at 2022-06-24 03:00:52.485284
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Verify the constructor of NonLocal class.
    """
    test_object = NonLocal(True)
    assert(test_object.value is True)


# Generated at 2022-06-24 03:00:54.334206
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)

# Generated at 2022-06-24 03:01:06.022121
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'lazy_module.tests.test'
    module_path = 'lazy_module.tests.test'

    import os
    import pkgutil
    import inspect
    import lazy_module.tests.test

    # get a code object. This code object is used to construct an empty module
    code = pkgutil.get_code(module_name)

    # a dict to be used as globals
    glob = {}

    # get the module frame
    frame = inspect.currentframe()

    # technically, this is a module, we initialize it with a marker object,
    # which we later swap out with the real module, once an attribute is
    # accessed.
    module = object()

    # Here, we are actually creating the module in the python sys.modules
    # cache.
    sys.modules[module_name]

# Generated at 2022-06-24 03:01:08.189082
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_nonlocal = NonLocal(3)
    assert (test_nonlocal.value == 3)

test_module = make_lazy("test_module")

# Generated at 2022-06-24 03:01:09.196580
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_class = NonLocal(123)
    assert nonlocal_class.value == 123

# Generated at 2022-06-24 03:01:10.691700
# Unit test for constructor of class NonLocal
def test_NonLocal():
    m = NonLocal('new value')
    assert m.value == 'new value'


# Generated at 2022-06-24 03:01:21.528549
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['should_not_be_imported'] = None
    make_lazy('should_not_be_imported')

    # check that __mro__ is correctly overriden
    mod = sys.modules['should_not_be_imported']
    assert isinstance(mod, _LazyModuleMarker)

    # check that the module is not imported until we access an attribute
    mod_counter = []

    class ShouldNotBeImported(object):
        def __init__(self):
            mod_counter.append(1)

    sys.modules['should_not_be_imported'] = ShouldNotBeImported()

    assert not mod_counter

    assert hasattr(mod, '__mro__')
    assert mod_counter



# Generated at 2022-06-24 03:01:31.803800
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('lazy_module')
    mod = sys.modules['lazy_module']

    assert isinstance(mod, _LazyModuleMarker)
    assert 'test_func1' not in dir(mod)

    # test a normal import
    from lazy_module import test_func1

    assert isinstance(mod, _LazyModuleMarker)
    assert 'test_func1' in dir(mod)

    # test an import using getattr
    test_func2 = getattr(sys.modules['lazy_module'], 'test_func2')
    assert test_func1() == 'test_func1'
    assert test_func2() == 'test_func2'

    # test calling a function imported via a getattr
    import lazy_module

# Generated at 2022-06-24 03:01:33.421440
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that we can correctly initialize the class
    """
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)



# Generated at 2022-06-24 03:01:34.197824
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from nose.tools import assert_true

# Generated at 2022-06-24 03:01:35.324357
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)

# Generated at 2022-06-24 03:01:40.863797
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert True, 'Check that constructor of class _LazyModuleMarker works!'


# Generated at 2022-06-24 03:01:43.912428
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert test_marker is not None

# Generated at 2022-06-24 03:01:53.828745
# Unit test for function make_lazy
def test_make_lazy():
    import ast

    # first, flush the cache
    if 'ast' in sys.modules:
        del sys.modules['ast']

    # second, patch the sys_modules, so that we don't pollute the system
    sys_modules = sys.modules
    sys_modules_backup = sys.modules.copy()
    sys.modules = {}

    # now, make sure `ast` is not loaded
    assert 'ast' not in sys.modules


# Generated at 2022-06-24 03:01:57.445219
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    make_lazy("unittest")
    utils = sys.modules['unittest.utils']
    assert isinstance(utils, ModuleType)
    assert not isinstance(utils, _LazyModuleMarker)

# Generated at 2022-06-24 03:02:03.970761
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType

    def mock_import(module_name):
        return sys.modules[module_name]

    # Make sure our fake module is not in the system modules
    assert "test_lazy_module" not in sys.modules

    # Make sure we can import it normally
    import test_lazy_module

    # Verify our debugging functions work properly
    assert isinstance(test_lazy_module, ModuleType)
    assert "test_lazy_function" in dir(test_lazy_module)
    assert not isinstance(test_lazy_module, LazyModule)

    # Mark our module as lazy
    make_lazy("test_lazy_module")

    # Make sure our fake module is in the system modules
    assert "test_lazy_module" in sys.modules

    # Verify

# Generated at 2022-06-24 03:02:04.771761
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(11) 
    assert x.value == 11

# Generated at 2022-06-24 03:02:11.009705
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker(), '__mro__')
    assert not hasattr(_LazyModuleMarker(), '__getattribute__')


# Generated at 2022-06-24 03:02:18.111323
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker), 'not instance'
    assert isinstance(b, _LazyModuleMarker), 'not instance'
    assert a != b, 'same instance'


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:02:20.595846
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')
    import utils.config
    assert(utils.config.get_config()["subprogram_name"]=="extract_info")

# Generated at 2022-06-24 03:02:21.923136
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert isinstance(type("", (object,), dict(__getattribute__=lambda x, y:None)), _LazyModuleMarker)

# Generated at 2022-06-24 03:02:31.777592
# Unit test for function make_lazy
def test_make_lazy():
    import json

    # Remove json from sys.modules
    del sys.modules['json']

    # Mark it as lazy
    make_lazy('json')

    # Get it back from sys.modules
    lazy_json = sys.modules['json']

    # Make sure we have a non-None value
    assert lazy_json is not None

    # Make sure it's not the real module yet
    assert lazy_json.__class__.__mro__[0] != ModuleType

    # Make sure we an access the module after asking for an attribute
    assert hasattr(lazy_json, 'loads')

    # Make sure we've *actually* got the module in sys.modules
    assert sys.modules['json'].__class__.__mro__[0] == ModuleType

# Generated at 2022-06-24 03:02:41.736480
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker.
    """
    if __name__ == '__main__':
        import sys

        if len(sys.argv) > 1 and sys.argv[1] == 'test':
            lazy = _LazyModuleMarker()
            assert type(lazy) == _LazyModuleMarker and isinstance(lazy, _LazyModuleMarker)
            # Run the following line in PyCharm console to test.
            # import xmodule.util.lazy_module;reload(xmodule.util.lazy_module);xmodule.util.lazy_module.test__LazyModuleMarker()

# Generated at 2022-06-24 03:02:43.926376
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("abcd")
    assert nl.value == "abcd"

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 03:02:47.982432
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local_class = NonLocal(1)
    assert non_local_class.value == 1

# Generated at 2022-06-24 03:02:51.054531
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = 1
    m = NonLocal(x)
    assert m.value == 1
    x = 123
    assert m.value == 123
    m.value = 456
    assert x == 456


# Generated at 2022-06-24 03:02:55.528906
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(sys, _LazyModuleMarker)

# Generated at 2022-06-24 03:02:57.731453
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    make_lazy("sys")
    assert(isinstance(sys, _LazyModuleMarker))


# Generated at 2022-06-24 03:03:03.035878
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for make_lazy
    """
    import sys
    sys.modules['non_local'] = None

    from tests.unit.fixtures import make_lazy as lazy, NonLocal
    assert isinstance(lazy, NonLocal)
    assert isinstance(lazy.unit, NonLocal)
    assert isinstance(lazy.unit.fixtures, NonLocal)
    from fixtures import unit, make_lazy as lazy2
    assert isinstance(lazy2, NonLocal)
    assert lazy2.unit == unit
    assert lazy2.unit.fixtures == unit.fixtures

    del sys.modules['non_local']

# Generated at 2022-06-24 03:03:07.078799
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that all attributes of _LazyModuleMarker have a value.
    """
    assert type(_LazyModuleMarker()) == _LazyModuleMarker


# Generated at 2022-06-24 03:03:08.912251
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)

# Generated at 2022-06-24 03:03:14.278414
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test the __mro__ method of the class
    try:
        isinstance(_LazyModuleMarker(), ModuleType)
        assert False
    except TypeError:
        assert True

    try:
        issubclass(_LazyModuleMarker(), ModuleType)
        assert False
    except TypeError:
        assert True

    # Test the __getattribute__ method of the class
    try:
        _LazyModuleMarker()
        assert False
    except TypeError:
        assert True

    try:
        getattr(_LazyModuleMarker(), 'test_attr')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 03:03:18.369292
# Unit test for function make_lazy
def test_make_lazy():
    # The import statement below should invoke make_lazy
    import sys.modules.__fake_lazy__  # noqa

    from sys.modules import __fake_lazy__  # noqa

    # The test fails if an ImportError is raised.
    # The test succeeds if we are able to find the fake module.
    assert '__fake_lazy__' in sys.modules



# Generated at 2022-06-24 03:03:25.732327
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import types
    testVariable = NonLocal(5)
    assert (5 == testVariable.value)
    testVariable.value = 6
    assert (6 == testVariable.value)

    testModule = NonLocal(None)
    assert (None == testModule.value)
    testModule.value = test_NonLocal
    assert (test_NonLocal == testModule.value)
    assert (isinstance(testModule.value, types.ModuleType))
    assert (isinstance(testModule.value, types.FunctionType))
    assert (isinstance(testModule.value, sys.modules['__main__']))
    assert (testModule.value.__name__ == '__main__')


# Generated at 2022-06-24 03:03:32.485658
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import time

    def sleep():
        time.sleep(1)
        sys.modules["test"] = "test"

    # Make sure it isn't already loaded
    assert "test" not in sys.modules

    make_lazy("test")
    start = time.clock()
    import test
    assert test == "test"
    assert time.clock() - start > 1

    start = time.clock()
    import test
    assert test == "test"
    assert time.clock() - start < 1
