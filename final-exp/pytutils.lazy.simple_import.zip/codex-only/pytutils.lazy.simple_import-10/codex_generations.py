

# Generated at 2022-06-24 02:53:27.231498
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Initializing object of class _LazyModuleMarker
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-24 02:53:38.186175
# Unit test for function make_lazy
def test_make_lazy():
    """
    A simple unit test for function make_lazy.

    """
    sys.modules['test_make_lazy'] = None
    make_lazy('test_make_lazy')

    import test_make_lazy

    # the module should be a lazy module
    assert isinstance(test_make_lazy, _LazyModuleMarker)

    # test __mro__ override
    assert isinstance(test_make_lazy, ModuleType)

    assert not hasattr(test_make_lazy, '__mro__')

    # no __mro__ override if being used to subclass
    class TestMakeLazySubclass(test_make_lazy.LazyModule):
        pass


# Generated at 2022-06-24 02:53:44.513028
# Unit test for function make_lazy
def test_make_lazy():
    # set up our test modules
    sys.modules['test_module'] = 42

    # test that module is not lazy
    assert sys.modules['test_module'] == 42

    # make module lazy
    make_lazy('test_module')

    # test that module is now lazy
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)

    # test that module is still lazy (with a different usage of __getattribute__)
    assert 'test_module' in globals() and isinstance(sys.modules['test_module'], _LazyModuleMarker)

    # test that accessing an attr will actually import the module
    sys.modules['test_module'].__file__ == '/path/to/test/module'

    # tear down our test modules
    del sys.modules['test_module']

# Generated at 2022-06-24 02:53:56.018101
# Unit test for function make_lazy
def test_make_lazy():
    mod_name = 'lazy_test'
    mod_path = mod_name.split('.')

    module = sys.modules.get(mod_name)
    if module is not None:
        del sys.modules[mod_name]

    make_lazy(mod_name)

    assert mod_name not in sys.modules
    assert isinstance(sys.modules[mod_name], _LazyModuleMarker)

    value = sys.modules[mod_name].value
    assert value is None

    # Trigger a value lookup for the module
    for m in mod_path:
        sys.modules[mod_name].__getattribute__(m)

    assert mod_name in sys.modules
    assert not isinstance(sys.modules[mod_name], _LazyModuleMarker)
    assert sys.modules[mod_name]

# Generated at 2022-06-24 02:54:07.078484
# Unit test for function make_lazy
def test_make_lazy():
    from datetime import datetime

    # delete datetime from sys.modules so we can test
    del sys.modules['datetime']

    make_lazy('datetime')

    assert 'datetime' not in sys.modules

    # this shouldn't cause importing datetime
    assert isinstance(sys.modules['datetime'], type(sys.modules))

    # this shouldn't cause importing datetime
    assert issubclass(sys.modules['datetime'].date, object)

    # this should cause importing datetime
    assert isinstance(datetime.date(1, 1, 1), datetime.date)

    # make sure we can still import the module
    import datetime

    assert isinstance(datetime.date(1, 1, 1), datetime.date)



# Generated at 2022-06-24 02:54:08.859853
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(3.14)
    assert non_local.value == 3.14


# Generated at 2022-06-24 02:54:10.176657
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3



# Generated at 2022-06-24 02:54:12.789243
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n1 = NonLocal(1)
    print(n1.value)
    print(n1)
    n1.value = 2
    print(n1.value)
    print(n1)


# Generated at 2022-06-24 02:54:22.769733
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the funciton make_lazy
    """
    import cmor_test  # NOQA

    # create a lazy module with make_lazy
    module_path = 'cmor_test'
    make_lazy(module_path)

    # Use isinstance to test if the module is lazy
    assert(isinstance(cmor_test, _LazyModuleMarker))

    # Test if the module is lazy
    try:
        import cmor_test

    except ImportError:
        pass  # Lazy module means that the module is not imported.

    cmor_test.test1()
    # If the module is lazy it would result an ImportError but it does not
    # raise ImportError, so it means that the module is not lazy.



# Generated at 2022-06-24 02:54:25.144737
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # This test is only for making sure the python script works!
    lazy = _LazyModuleMarker()
    assert True

# Generated at 2022-06-24 02:54:33.241846
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    suc = _LazyModuleMarker()
    assert suc.__class__ == _LazyModuleMarker
    suc_ = _LazyModuleMarker()
    suc_ = suc
    assert suc is suc_
    assert suc == suc_
    try:
        suc_ = _LazyModuleMarker.__new__(_LazyModuleMarker)
        suc_ = suc
        raise Exception("Creating a new object of class _LazyModuleMarker should fail.")
    except:
        pass


# Generated at 2022-06-24 02:54:42.175691
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import foo

    t1 = time.time()
    make_lazy('foo')
    foo2 = sys.modules['foo']
    t2 = time.time()

    assert isinstance(foo2, _LazyModuleMarker)
    assert foo2.__name__ == 'foo'
    assert t2 - t1 < 0.002

    t1 = time.time()
    foo3 = sys.modules['foo'].bar
    t2 = time.time()

    assert isinstance(foo3, ModuleType)
    assert foo3.__name__ == 'foo.bar'
    assert not isinstance(foo3, _LazyModuleMarker)
    assert t2 - t1 > 0.1

    t1 = time.time()
    foo4 = sys.modules['foo'].bar
    t2

# Generated at 2022-06-24 02:54:50.431897
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import django.conf

    # test when importing for a second time that the module is already loaded
    try:
        import os
    except:
        pass

    make_lazy('os')

    # The module was already imported so we won't catch the exception
    import os

    # test that the module is not instantiated by default
    make_lazy('django.conf')

    # test that the module is instantiated by django.conf
    try:
        django.conf.settings
    except:
        pass
    else:
        assert False, "Expected an exception on importing django.conf.settings"

    # test that the module is now loaded
    from django.conf import settings

    assert settings, "Expected django.conf.settings to be defined"

# Generated at 2022-06-24 02:54:53.022986
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Check that the __init__ constructor is correctly implemented
    """
    lazy_module = _LazyModuleMarker()
    assert(hasattr(lazy_module, "__init__") == False)


# Generated at 2022-06-24 02:54:55.402070
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:55:03.367043
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # nonlocal keyword only exist in python 3
    from sys import version_info
    if version_info >= (3, 0):
        exec('def test_nonlocal():\n    value = None\n    def tester():\n        nonlocal value\n        value = 1\n    tester()\n    assert value == 1\n')
    else:
        exec('def test_nonlocal():\n    value = None\n    class tester:\n        def tester(self):\n            self.value = 1\n    tester().tester()\n    assert value == 1\n')
test_NonLocal()



# Generated at 2022-06-24 02:55:05.001147
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-24 02:55:12.932138
# Unit test for function make_lazy
def test_make_lazy():
    import site
    import sys
    import os

    bit = os.path.splitext(sys.implementation.cache_tag)[0][2:]
    site_packages_dir = os.path.join(
        os.path.dirname(site.__file__),
        "no-site-packages",
        "lib",
        "python3.5",
        "site-packages",
    )
    mymodule_path = 'mymodule'
    mymodule_file = os.path.join(site_packages_dir, mymodule_path + '.py')

    # Populate the modules cache with a fake module
    # in a location that we can safely remove
    sys.modules[mymodule_path] = sys.modules[__name__]

    # if the test is run as a script, `site` will re-import itself


# Generated at 2022-06-24 02:55:22.804553
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

test__LazyModuleMarker()

import sys
import os
import pkgutil
import importlib

if sys.version_info[:2] < (3, 3):
    import imp

    def _iter_modules(path):
        """
        Backport of pkgutil.walk_packages

        See https://bugs.python.org/issue16673
        """
        for importer, mod_name, ispkg in pkgutil.iter_modules([path]):
            yield mod_name, os.path.join(path, mod_name), ispkg

    def _get_submodules(mod):
        """
        Backport of ModuleSpec.submodules

        See https://bugs.python.org/issue16673
        """

# Generated at 2022-06-24 02:55:27.950313
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonLocal = NonLocal("value")
    assert nonLocal.value == "value"


# Generated at 2022-06-24 02:55:33.297685
# Unit test for function make_lazy
def test_make_lazy():
    """
    A unit test verifying that make_lazy() functions as intended.
    """
    module_path = "make_lazy_test"
    sys.modules[module_path] = (make_lazy(module_path), "INITIAL_VALUE")
    assert sys.modules[module_path] == ("INITIAL_VALUE", )
    sys.modules[module_path] = (make_lazy(module_path), "CHANGED_VALUE")
    assert sys.modules[module_path] == ("CHANGED_VALUE", )

# Generated at 2022-06-24 02:55:41.687872
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy makes a module lazy.
    """
    import os
    import six

    make_lazy('os')

    assert os is not None

    assert isinstance(os, _LazyModuleMarker)

    assert 'os' in sys.modules

    assert sys.modules['os'] is os

    assert os.path is not None

    assert 'os.path' in sys.modules

    assert os.path is sys.modules['os.path']

    assert os.path.join is not None

    assert six.PY2



# Generated at 2022-06-24 02:55:51.693648
# Unit test for function make_lazy
def test_make_lazy():
    # Import modules needed
    import sys
    import importlib
    import select
    # Make sure module is not outdated
    if 'module' not in dir(select):
        raise Exception("The module 'module' was not found in the module 'select'")

    m = select.module
    # Make sure module does not appear in sys.modules
    if m.__name__ in sys.modules:
        raise Exception("The module 'module' was already imported")
    
    # Make sure module can be imported when lazy module is not in use
    importlib.reload(m)

    # Check function 'make_lazy'
    make_lazy("module")

    # Reload m again
    importlib.reload(m)

    # Check if module can still be imported

# Generated at 2022-06-24 02:56:01.635062
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    old_modules = sys.modules.copy()
    module_name = 'temp_for_lazy_loader_testing'
    make_lazy(module_name)

    # Make sure the module is in sys.modules, but has not been imported yet
    assert module_name in sys.modules
    assert module_name not in old_modules

    # Make sure the module is an instance of LazyModule
    assert isinstance(sys.modules[module_name], _LazyModuleMarker)

    # Make sure the function __getattribute__ is called
    assert sys.modules[module_name].__class__ is LazyModule

    # Make sure that we can import a sub module from the lazy module
    assert sys.modules[module_name].LazyModuleSub.__name__ == 'LazyModuleSub'

    # Clean up
   

# Generated at 2022-06-24 02:56:10.793691
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test if making a module lazy prevents it from being imported
    until an attr is needed off of it.
    """

    class MockModuleImport(object):
        """
        A mock object to test LazyModule
        """
        def __init__(self, name, import_okay=True, attr_okay=True):
            self.name = name
            self.import_okay = import_okay
            self.attr_okay = attr_okay

        def __repr__(self):
            return '<MockModuleImport(%r)' % self.name

        def __import__(self, *args):
            return self if self.import_okay else None


# Generated at 2022-06-24 02:56:18.224498
# Unit test for function make_lazy
def test_make_lazy():
    """
    This function is a unit test for function `make_lazy`.
    """

    # The file class_mod is the module with class of the same name `class_mod`.
    # By adding the line
    #
    #     make_lazy(__name__)
    #
    # after the definition of class `class_mod`, we can make it lazy.

    # This is a module we will be importing
    class_mod = __import__('class_mod')

    from class_mod import class_mod
    # Note that class `class_mod` is imported here
    assert isinstance(class_mod, type)

    # First, we make sure this module has not been imported into sys.modules yet.
    import sys
    assert 'class_mod' not in sys.modules

    make_lazy(__name__)

   

# Generated at 2022-06-24 02:56:28.998639
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _LazyModuleMarker(object):
        """
        A marker to indicate a LazyModule type.
        Allows us to check module's with `isinstance(mod, _LazyModuleMarker)`
        to know if the module is lazy.
        """
        def __init__(self, module_path):
            self.module_path = module_path

    class LazyModule(_LazyModuleMarker):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
           

# Generated at 2022-06-24 02:56:34.374888
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for _LazyModuleMarker
    """
    from pandas.core import _LazyModuleMarker
    obj = _LazyModuleMarker()
    assert(isinstance(obj, _LazyModuleMarker))
    assert(obj.__repr__() == '<_LazyModuleMarker()>')


test__LazyModuleMarker()

# Generated at 2022-06-24 02:56:43.251248
# Unit test for function make_lazy
def test_make_lazy():
    init_sys_modules = sys.modules.copy()
    module_path = "foo.bar"

    foo = sys.modules["foo"] = ModuleType("foo")
    bar = foo.bar = ModuleType("foo.bar")
    bar.foobar = "foobar"

    make_lazy(module_path)

    # Make sure the module was added to sys.modules
    assert sys.modules["foo.bar"] is not bar
    assert isinstance(sys.modules["foo.bar"], _LazyModuleMarker)

    # Make sure it's still callable and has the same properties
    assert sys.modules["foo.bar"].foobar == "foobar"

    sys.modules = init_sys_modules

# Generated at 2022-06-24 02:56:46.394623
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    make_lazy('datetime')
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)
    assert datetime.datetime.now()

# Generated at 2022-06-24 02:56:53.070032
# Unit test for function make_lazy
def test_make_lazy():
    # mock the sys module here
    class MockSys:
        modules = {}
    mock_sys = MockSys()
    # create a module that would cause an import error
    # if it were not lazy
    lazy_module = make_lazy('a.b.c.d.e')
    # this line would fail if the module is not lazy
    lazy_module.foo = 'bar'

# Generated at 2022-06-24 02:56:56.319044
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    print(lmm)
    assert lmm is not None


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:57:00.329902
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonl = NonLocal("Hello World!")
    assert isinstance(nonl, NonLocal)
    assert nonl.value == "Hello World!"
    nonl.value = "Goodbye!"
    assert nonl.value == "Goodbye!"
    assert type(nonl.value) == str

# Generated at 2022-06-24 02:57:10.020529
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Ensure that our NonLocal class is working correctly to maintain
    state across multiple function calls.
    """
    def get_nonlocal(nonlocal_var):
        """
        Gets a non-local value from nonlocal_var.
        """
        assert nonlocal_var.value == 20
        nonlocal_var.value = 10

    def set_nonlocal(nonlocal_var):
        """
        Sets a non-local value to nonlocal_var.
        """
        nonlocal_var.value = 20

    nonlocal_var = NonLocal(None)
    assert nonlocal_var.value is None

    set_nonlocal(nonlocal_var)
    get_nonlocal(nonlocal_var)
    assert nonlocal_var.value == 10


# Generated at 2022-06-24 02:57:11.670237
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    assert a.value == 2

# Generated at 2022-06-24 02:57:12.538530
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker() is not None)

# Generated at 2022-06-24 02:57:20.952332
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import site
    import os

    # Ensure the sys module has nothing loaded
    sys_modules = ['version', 'version_info']
    site_modules = ['USER_BASE', 'USER_SITE', 'ENABLE_USER_SITE']
    if not os.name == 'nt':
        sys_modules.extend(['stdin', 'stdout', 'stderr'])
        site_modules.extend(['getsitepackages', 'getuserbase'])

    sys_modules.sort()
    site_modules.sort()

    assert set(sys_modules) == set(sys.modules)
    assert set(site_modules) == set(dir(site))

    def call_keys():
        from sys import modules  # noqa
        return modules.keys()


# Generated at 2022-06-24 02:57:25.356470
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Returns:
        Returns a variable of type NonLocal
    """
    module_marker = _LazyModuleMarker()
    if isinstance(module_marker, _LazyModuleMarker):
        return module_marker
    else:
        print('Not of type _LazyModuleMarker')
        return None



# Generated at 2022-06-24 02:57:37.306171
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test make_lazy works properly.
    """
    import sys

    # Test basic make_lazy.
    def test_basic():
        """
        Test out the basic functionality of make_lazy.
        """
        make_lazy('__builtin__')

        assert isinstance(__builtin__, _LazyModuleMarker)
        assert '__builtin__' in sys.modules

        builtin_func = __builtin__.min

        assert builtin_func([1, 2, 3]) == 1

    test_basic()

    # Test make_lazy with a complex module import.
    def test_complex():
        """
        Make sure that nested modules are properly handled too.
        """
        make_lazy('foo.bar.baz')

        assert 'foo' in sys.modules

# Generated at 2022-06-24 02:57:42.567338
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert isinstance(lmm, _LazyModuleMarker)
    assert isinstance(lmm, ModuleType)
    assert not isinstance(lmm, object)

    import six.moves
    try:
        assert isinstance(six.moves, _LazyModuleMarker)
    except AssertionError:
        print("Six is already imported!")


# Generated at 2022-06-24 02:57:43.833768
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(9)
    assert x.value == 9


# Generated at 2022-06-24 02:57:51.816924
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    module_path = 'a.b.c'
    mod = sys.modules.get(module_path, None)
    assert mod is None

    make_lazy(module_path)
    mod = sys.modules[module_path]
    assert isinstance(mod, _LazyModuleMarker)

    try:
        mod.d()
    except AttributeError:
        pass
    else:
        raise AssertionError("Should not exist")

    try:
        mod.e.f()
    except AttributeError:
        pass
    else:
        raise AssertionError("Should not exist")

    from a.b import c
    import a.b.c

# Generated at 2022-06-24 02:57:56.180556
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(None)
    a = NonLocal(1)
    non_local.value = a
    assert a.value == 1
    assert non_local.value.value == 1
    a.value = 2
    assert non_local.value.value == 2
    non_local.value.value = 3
    assert a.value == 3

# Generated at 2022-06-24 02:57:57.322870
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """ unit test """
    a = _LazyModuleMarker()



# Generated at 2022-06-24 02:57:59.383211
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert issubclass(NonLocal, object)
    assert NonLocal.__slots__ == ['value']
    nl = NonLocal(2)
    assert nl.value == 2

# Generated at 2022-06-24 02:58:01.134479
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	Marker=_LazyModuleMarker()
	assert type(Marker) is _LazyModuleMarker


# Generated at 2022-06-24 02:58:03.884564
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('value')
    assert isinstance(nl, NonLocal)



# Generated at 2022-06-24 02:58:09.177615
# Unit test for function make_lazy
def test_make_lazy():
    class Module(object):
        class SubModule(object):
            pass
    sys.modules['test_make_lazy'] = Module
    sys.modules['test_make_lazy.SubModule'] = Module.SubModule
    make_lazy('test_make_lazy')
    assert len(sys.modules) == 2
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)
    assert isinstance(sys.modules['test_make_lazy.SubModule'], _LazyModuleMarker)

# Generated at 2022-06-24 02:58:12.187038
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert isinstance(test, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:21.366684
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the `make_lazy` function.
    """
    # Test that the module is created lazily.
    make_lazy('jdflkjsdflkjdsf')

    del sys.modules['jdflkjsdflkjdsf']
    del sys.modules[__name__]

    import jdflkjsdflkjdsf as test_mod

    assert isinstance(test_mod, _LazyModuleMarker)
    assert not hasattr(test_mod, '__mro__')
    assert not hasattr(test_mod, '__getattribute__')

    # Trigger the lazy load.
    try:
        test_mod.lkasjdflkjasdf
    except AttributeError:
        pass  # expected

# Generated at 2022-06-24 02:58:23.278375
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10

# Unit tests for make_lazy

# Generated at 2022-06-24 02:58:25.065813
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    NonLocal(sys)
    # assert that it didn't throw

# Generated at 2022-06-24 02:58:36.093049
# Unit test for function make_lazy
def test_make_lazy():
    from ssl import _create_unverified_context

    # remove 'ssl' from sys.modules if it exists
    try:
        del sys.modules['ssl']
    except KeyError:
        pass

    # make sure _create_unverified_context doesn't exist
    # since we deleted the module
    with pytest.raises(AttributeError):
        _create_unverified_context

    # mark ssl as lazy, then get the unverified context
    make_lazy('ssl')
    assert isinstance(sys.modules['ssl'], _LazyModuleMarker)
    _create_unverified_context

    # now make sure we can import it again
    import ssl
    assert ssl
    assert ssl.create_unverified_context

    del sys.modules['ssl']

# Generated at 2022-06-24 02:58:41.390940
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    assert lazy is not None
    assert lazy is not False
    assert lazy is not True


# Generated at 2022-06-24 02:58:42.561594
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(issubclass(_LazyModuleMarker, object))


# Generated at 2022-06-24 02:58:48.427789
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    try:
        make_lazy('os')
        assert isinstance(os, _LazyModuleMarker)
        assert isinstance(os, sys.modules['os'].__class__)
        assert os.path.realpath('/tmp') == '/tmp'
    finally:
        sys.modules['os'] = sys.modules['__old_os']
        del sys.modules['__old_os']

# Generated at 2022-06-24 02:58:50.402064
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object), \
        'Make sure classes be subclass of object'
    assert type(_LazyModuleMarker) is type, \
        'Make sure classes be subclass of object'

# Generated at 2022-06-24 02:58:55.496249
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal1 = NonLocal(1)
    assert nonlocal1.value == 1
    nonlocal1.value = 2
    assert nonlocal1.value == 2


# Generated at 2022-06-24 02:59:00.756189
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class MyNonLocal(object):
        """
        Simulates nonlocal keyword in Python 2
        """
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    def test_non_local():
        nl = MyNonLocal(0)
        assert nl.value == 0

        def test_func():
            nl.value += 1
        test_func()
        assert nl.value == 1

    test_non_local()


# Generated at 2022-06-24 02:59:11.579474
# Unit test for function make_lazy
def test_make_lazy():
    from pytest import raises
    from importlib import reload

    sys_modules = sys.modules

    def has_toplevel_attr():
        return hasattr(sys_modules['test_module'], 'TOPLEVEL_ATTR')

    def has_submodule_attr():
        return hasattr(sys_modules['test_module'].submodule, 'SUBMODULE_ATTR')

    # ensure it's not there
    if 'test_module' in sys_modules:
        del sys_modules['test_module']

    # module is not there, and the attributes are not there either
    assert 'test_module' not in sys_modules
    assert not has_toplevel_attr()
    assert not has_submodule_attr()

    # now let's mark the module lazy
    make_lazy('test_module')

   

# Generated at 2022-06-24 02:59:12.410697
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()



# Generated at 2022-06-24 02:59:19.181088
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(1)
    assert nl1.value == 1

    nl2 = NonLocal(2.1)
    assert nl2.value == 2.1

    nl3 = NonLocal("sss")
    assert nl3.value == "sss"

# Generated at 2022-06-24 02:59:21.622724
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

# Generated at 2022-06-24 02:59:29.533477
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = 'foo'
    number = 1.
    array = []
    class Bar(object):
        pass
    bar = Bar()
    bar.foo = 'bar'
    bar.number = 2.
    bar.array = [1, 2, 3, 4]
    nl_foo = NonLocal(foo)
    nl_number = NonLocal(number)
    nl_array = NonLocal(array)
    nl_bar = NonLocal(bar)
    assert nl_foo.value == foo
    assert nl_number.value == number
    assert nl_array.value == array
    assert nl_bar.value == bar


# Generated at 2022-06-24 02:59:30.327208
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker



# Generated at 2022-06-24 02:59:31.101301
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is None

# Generated at 2022-06-24 02:59:39.811730
# Unit test for function make_lazy
def test_make_lazy():
    import tempfile

    def touch(path):
        open(path, 'a').close()

    # Create a fake module being imported
    temp_dir = tempfile.mkdtemp()
    fake_module_path = os.path.join(temp_dir, 'fake_module.py')
    touch(fake_module_path)

    sys.path.append(temp_dir)

    # Initialize module
    module = os.path.basename(fake_module_path).split('.')[0]

# Generated at 2022-06-24 02:59:41.707270
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)

# Generated at 2022-06-24 02:59:43.704469
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
   _LazyModuleMarker()


# Generated at 2022-06-24 02:59:45.850683
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test create a new _LazyModuleMarker
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker

# Generated at 2022-06-24 02:59:47.735176
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(sys.modules['django.utils.lazy_module'], _LazyModuleMarker)


# Generated at 2022-06-24 02:59:51.605600
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1


# Generated at 2022-06-24 02:59:54.207952
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None
    x = NonLocal(3)
    assert x.value == 3
    x.value = 5
    assert x.value == 5


# Generated at 2022-06-24 02:59:59.030536
# Unit test for constructor of class NonLocal
def test_NonLocal():
	"""
	This function tests the NonLocal class
	"""
	print("\n Unit testing function test_NonLocal()")
	# Creating an instance of class NonLocal with value 1
	nl = NonLocal(1)
	print(nl)		# Expected output: <__main__.NonLocal object at 0x7f0b8446e7b8>
	print(nl.value)		# Expected output: 1



# Generated at 2022-06-24 02:59:59.970724
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    out = _LazyModuleMarker()
    assert isinstance(out, object)


# Generated at 2022-06-24 03:00:06.551869
# Unit test for function make_lazy
def test_make_lazy():
    import lazy_test

    # Make sure our module was marked as lazy
    assert isinstance(lazy_test, _LazyModuleMarker)

    # Remove reference to module so it can be fully importe
    del lazy_test

    # Reimport module to make sure it was fully imported
    import lazy_test

    # Make sure our module is no longer lazy (marked as a LazyModule)
    # but is still a module type
    assert type(lazy_test) is ModuleType
    assert not isinstance(lazy_test, _LazyModuleMarker)

# Generated at 2022-06-24 03:00:09.182064
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mod = _LazyModuleMarker()
    assert isinstance(lazy_mod, _LazyModuleMarker)
    assert not isinstance(lazy_mod, ModuleType)


# Generated at 2022-06-24 03:00:13.947600
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an instance of _LazyModuleMarker
    lazyModuleMarker = _LazyModuleMarker()
    assert isinstance(lazyModuleMarker, _LazyModuleMarker)
    assert isinstance(lazyModuleMarker, object)
    assert lazyModuleMarker.__class__ is _LazyModuleMarker
    assert lazyModuleMarker.__class__.__name__ == '_LazyModuleMarker'


# Generated at 2022-06-24 03:00:16.670780
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(1)
    assert nl1.value == 1

    nl2 = NonLocal("A")
    assert nl2.value == "A"

    nl3 = NonLocal(None)
    assert nl3.value is None


# Generated at 2022-06-24 03:00:22.710652
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    _LazyModuleMarker is a marker to indicate a LazyModule type.
    Allows us to check module's with `isinstance(mod, _LazyModuleMarker)`
    to know if the module is lazy.
    """
    from django.test import TestCase  # pylint: disable=import-error

    class TestClass(_LazyModuleMarker):
        """
        TestClass is a test class used to verify the functionality
        of _LazyModuleMarker
        """
        pass

    test_class = TestClass()

    # check isinstance using the marker _LazyModuleMarker
    self.assertTrue(isinstance(test_class, _LazyModuleMarker))

    # check isinstance using the marker ModuleType
    self.assertFalse(isinstance(test_class, ModuleType))

# Generated at 2022-06-24 03:00:24.280215
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

    def f(x):
        n.value = x
        return n.value

    assert f(2) == 2



# Generated at 2022-06-24 03:00:25.785349
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = type('LazyModuleMarker', (_LazyModuleMarker , object), {})
    lm = LazyModuleMarker()
    assert lm.__mro__



# Generated at 2022-06-24 03:00:30.756038
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = 2
    b = 1

    nonlocal_a = NonLocal(a)
    nonlocal_b = NonLocal(b)

    assert a == nonlocal_a.value
    assert b == nonlocal_b.value



# Generated at 2022-06-24 03:00:40.439956
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules_copy = sys.modules.copy()

    # We have to bind this to a variable or the lambda will always return
    # the last value in the loop.
    mod_path = 'foo'

    # Check that module is not in sys.modules
    not_in_sys_modules = lambda: mod_path not in sys.modules
    assert_true(not_in_sys_modules())

    # Create a LazyModule
    make_lazy(mod_path)

    # Check that it is in sys.modules
    in_sys_modules = lambda: mod_path in sys.modules
    assert_true(in_sys_modules())

    # Check that it's a LazyModule
    is_lazy_module = lambda: isinstance(sys.modules[mod_path], _LazyModuleMarker)
    assert_true

# Generated at 2022-06-24 03:00:44.785330
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert nl.value == 42

    nl.value = 'value'
    assert nl.value == 'value' is not None

# Generated at 2022-06-24 03:00:50.101700
# Unit test for function make_lazy
def test_make_lazy():
    module = 'lazy_loading_tests.mock_modules.unlazy'
    make_lazy(module)

    finder = __import__('lazy_loading_tests.mock_modules')
    mod = finder.mock_modules.unlazy

    # this should be the lazy version
    assert isinstance(mod, _LazyModuleMarker)  # noqa

    # attempts to access should cause it to load
    assert mod.name == 'unlazy'

    # now it should be the real module
    assert isinstance(mod, ModuleType)  # noqa

# Generated at 2022-06-24 03:00:54.464066
# Unit test for function make_lazy
def test_make_lazy():
    assert 'test_make_lazy' not in sys.modules
    make_lazy('test_make_lazy')
    assert type(sys.modules['test_make_lazy']) is _LazyModuleMarker
    class AttributeType(Exception):
        pass
    with pytest.raises(AttributeType):
        sys.modules['test_make_lazy'].foo



# Generated at 2022-06-24 03:01:01.268676
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker(), '__getattribute__'), \
    "getattribute is not defined"
    assert hasattr(_LazyModuleMarker(), '__mro__'), \
    "mro is not defined"
    assert set(_LazyModuleMarker().__mro__()) == {_LazyModuleMarker, ModuleType}, \
    "mro not overridden"

# Generated at 2022-06-24 03:01:03.020839
# Unit test for constructor of class NonLocal
def test_NonLocal():
    s = NonLocal(1)
    assert(s.value == 1)



# Generated at 2022-06-24 03:01:10.909605
# Unit test for function make_lazy
def test_make_lazy():
    def _test():
        """
        Helper function
        """
        sys.modules['my'].__init_called = True
        sys.modules['my'].__name__ = '__test'
        sys.modules['my'] = __import__('__test')

    def _test_lazy():
        """
        Helper function
        """
        make_lazy('my')
        assert not os.path.isfile('my.py')

    sys.modules.clear()
    os.environ.clear()

    test_path = os.getcwd()
    file_path = os.path.join(test_path, 'my.py')

    # Make file for test
    with open(file_path, 'w') as f:
        f.write('')


# Generated at 2022-06-24 03:01:12.120793
# Unit test for constructor of class NonLocal
def test_NonLocal():
    NL = NonLocal(26)
    assert (NL.value == 26)

# Generated at 2022-06-24 03:01:20.505976
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value1 = 0
    test_value2 = 0
    test_nl = NonLocal(0)
    def test_function1():
        test_value1 = test_nl.value + 2
    def test_function2():
        test_value2 = test_nl.value + 3
    test_function1()
    test_function2()
    assert (test_value1 == 2)
    assert (test_value2 == 3)
    assert (test_nl.value == 0)
    return

# Generated at 2022-06-24 03:01:26.845353
# Unit test for function make_lazy
def test_make_lazy():
    from . import test_lazy_import
    assert isinstance(test_lazy_import, _LazyModuleMarker)

    val = test_lazy_import.X.example
    assert val == 'test'

# Generated at 2022-06-24 03:01:28.763198
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 03:01:38.853153
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    A test for constructor of class _LazyModuleMarker
    """
    assert isinstance(object, _LazyModuleMarker) is False
    assert type(object) is _LazyModuleMarker
    try:
        make_lazy("test")
    except:
        assert False
    assert isinstance(sys.modules["test"], _LazyModuleMarker) is True
    assert sys.modules["test"].__mro__()[0] == _LazyModuleMarker
    assert sys.modules["test"].__mro__()[1] == ModuleType
    assert sys.modules["test"].__mro__()[2] == type
    assert  isinstance(sys.modules["test"], ModuleType) is False
    assert sys.modules["test"].__getattribute__("test") is None
# Unit test

# Generated at 2022-06-24 03:01:43.262354
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest

    class Test__LazyModuleMarker(unittest.TestCase):
        def test_constructor(self):
            pass

    unittest.main()

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:01:49.084720
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_equal
    assert_equal(_LazyModuleMarker().__class__.__name__, '_LazyModuleMarker')

# Unit testing for function make_lazy

# Generated at 2022-06-24 03:01:50.390282
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert(x.value == 10)

# Generated at 2022-06-24 03:01:53.322317
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test the class NonLocal
    """
    test_non_local = NonLocal(3)
    test_non_local.value = 4
    assert test_non_local.value == 4

# Generated at 2022-06-24 03:02:01.925092
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure mls.test_make_lazy is not in sys.modules yet
    assert 'mls.test_make_lazy' not in sys.modules
    assert 'mls.test_make_lazy' not in globals()
    # Make mls.test_make_lazy a LazyModule
    make_lazy('mls.test_make_lazy')
    # Make sure mls.test_make_lazy is a LazyModule
    assert isinstance(sys.modules['mls.test_make_lazy'], _LazyModuleMarker)
    # Test that the LazyModule can be accessed as a normal module
    assert sys.modules['mls.test_make_lazy'].make_lazy is make_lazy
    # Make sure mls.test_make_lazy is in sys

# Generated at 2022-06-24 03:02:03.577332
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Created a new NonLocal object
    a = NonLocal(1000)
    assert a.value == 1000



# Generated at 2022-06-24 03:02:04.807468
# Unit test for constructor of class NonLocal
def test_NonLocal():
        test = NonLocal(None)
        assert test.value is None


# Generated at 2022-06-24 03:02:12.534185
# Unit test for function make_lazy
def test_make_lazy():
    with TemporaryDirectory() as d:
        f = os.path.join(d, 'mymodule.py')
        with open(f, 'w') as fh:
            fh.write('xyz = 1\n')
        if sys.version_info[0] == 2:
            # In Python 2, we need to add the directory to the path
            sys.path.append(d)
        else:
            # In Python 3, we need it to be an actual module
            with open(os.path.join(d, '__init__.py'), 'w') as fh:
                fh.write('')
        # This should work
        make_lazy('mymodule')
        assert sys.modules['mymodule'].xyz == 1
        assert 'mymodule' in sys.modules
        # This should work too


# Generated at 2022-06-24 03:02:18.054888
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(5)
    assert nonlocal_obj.value == 5


# Generated at 2022-06-24 03:02:19.081317
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:02:23.099548
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        del NonLocal
    except:
        pass

# Generated at 2022-06-24 03:02:27.620574
# Unit test for function make_lazy
def test_make_lazy():
    "Unit test for make_lazy"
    import os
    sys.modules['os'] = os
    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)
    import os
    assert not isinstance(os, _LazyModuleMarker)
    orig_dir = os.getcwd()



# Generated at 2022-06-24 03:02:29.424477
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 03:02:33.657353
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # type: () -> None
    import zerver.lib.test_classes
    zerver.lib.test_classes.check_class(
        _LazyModuleMarker,
        kwargs={},
        )


# Generated at 2022-06-24 03:02:34.625164
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:02:38.189330
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_var = NonLocal(None)
    my_var.value = 1

# Generated at 2022-06-24 03:02:41.285830
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''
    This function tests the value attribute in the __init__() function of the
    class NonLocal()
    '''
    testVar = NonLocal(5)
    assert testVar.value == 5

# Generated at 2022-06-24 03:02:42.564402
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(4)
    assert n.value == 4


# Generated at 2022-06-24 03:02:44.786709
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Constructor of class _LazyModuleMarker
    a = _LazyModuleMarker()


if __name__ == "__main__":
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:02:54.449099
# Unit test for function make_lazy
def test_make_lazy():

    path = 'my.module'
    module_ = object()

    def _module_loader():
        # Replace the module in sys.modules
        sys.modules[path] = module_

    # make sure the module doesn't exist in sys.modules
    if path in sys.modules:
        del sys.modules[path]

    # mocks
    with patch('sys.modules', sys.modules):
        with patch('__import__', new=_module_loader):
            make_lazy(path)
            # Should be in sys.modules
            assert path in sys.modules
            # Should be a LazyModule
            assert isinstance(sys.modules[path], _LazyModuleMarker)
            # Test that it works.
            assert module_ == sys.modules[path].x

# Generated at 2022-06-24 03:02:59.695774
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    module_path = 'calculations.test.test_lazy_module'

    make_lazy(module_path)

    mod = sys.modules[module_path]

    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)

    assert mod.TEST_STRING == 'test_string'

# Generated at 2022-06-24 03:03:10.691041
# Unit test for function make_lazy
def test_make_lazy():
    mod = 'my_lazy_module'
    make_lazy(mod)
    my_lazy_module = sys.modules[mod]

    # Test that we have a lazy module
    assert isinstance(my_lazy_module, _LazyModuleMarker)

    # Test that we can add attributes to the module __dict__
    my_lazy_module.test1 = 1
    assert my_lazy_module.test1 == 1
    assert 'test1' in dir(my_lazy_module)

    # Test that we can access attributes we add
    my_lazy_module.test2 = 2
    assert my_lazy_module.test2 == 2

    # Test that we can access attributes on the module itself
    assert my_lazy_module.__doc__ is None

    # Test that we get the real

# Generated at 2022-06-24 03:03:19.657965
# Unit test for function make_lazy
def test_make_lazy():
    def test_func(module_path):
        """
        A function to test the importability of a module.
        """
        try:
            mod = __import__(module_path)
        except ImportError:
            return False

        return not isinstance(mod, _LazyModuleMarker)

    assert sys.modules.has_key('__future__')  # make sure we don't break anything.
    assert test_func('__future__')  # make sure we don't break anything.

    make_lazy('foo')
    assert not test_func('foo')

    import foo  # import module normally
    assert test_func('foo')  # make sure the module is importable

# Generated at 2022-06-24 03:03:20.949627
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None
    x.value = 3
    assert x.value == 3

# Generated at 2022-06-24 03:03:25.055500
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    import re
    try:
        make_lazy("re")
        assert re is not None
        assert isinstance(re, _LazyModuleMarker)
        assert "re" in sys_modules
        assert re is sys_modules["re"]
        assert sys.modules["re"] == re
        assert re.__getattribute__("__name__") == "re"
        assert re.__getattribute__("__file__").endswith("re.py")
        assert "re" in globals()
        assert isinstance(re, ModuleType)
    finally:
        del sys_modules["re"]
        sys_modules["re"] = re