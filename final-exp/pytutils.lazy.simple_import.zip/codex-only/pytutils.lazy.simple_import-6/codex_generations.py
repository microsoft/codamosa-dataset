

# Generated at 2022-06-24 02:53:35.602067
# Unit test for function make_lazy
def test_make_lazy():
    import lazypkg
    make_lazy('lazypkg')
    assert not sys.modules.has_key('lazypkg')
    assert isinstance(lazypkg, _LazyModuleMarker)
    assert lazypkg.__name__ == 'lazypkg'
    assert isinstance(lazypkg.module, ModuleType)
    assert lazypkg.module.__name__ == 'lazypkg.module'
    assert sys.modules['lazypkg'] is not lazypkg
    assert sys.modules['lazypkg.module'] is not lazypkg.module

# Generated at 2022-06-24 02:53:40.036944
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from inspect import isclass
    from types import FunctionType
    nl_inst = NonLocal(123)
    assert(nl_inst.value == 123)
    assert(isclass(NonLocal))
    assert(isinstance(NonLocal, type))
    assert(isinstance(nl_inst, NonLocal))
    assert(isinstance(make_lazy, FunctionType))

# Generated at 2022-06-24 02:53:46.444870
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  # test__LazyModuleMarker1
  assert _LazyModuleMarker().__mro__() == (_LazyModuleMarker, object)
  # test__LazyModuleMarker2
  try:
    _LazyModuleMarker().__module__ == '__main__'
  except:
    assert False, 'test__LazyModuleMarker2 failed'
  assert True

# Generated at 2022-06-24 02:53:48.859673
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a == 1

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:53:59.078498
# Unit test for function make_lazy
def test_make_lazy():
    # Create a list of lazy modules, load them and test
    lazy_modules = ['os', 'os.path', 'sys.path', 'shutil', 'shutil.rmtree', 'nonexisting.module']
    lazy_modules_orig = lazy_modules[:]

    for mod in lazy_modules:
        make_lazy(mod)

    for mod in lazy_modules_orig:
        temp_mod = mod
        while True:
            if not '.' in temp_mod:
                break
            temp_mod, _ = temp_mod.split('.', 1)

        assert temp_mod in sys.modules
        assert isinstance(sys.modules[temp_mod], _LazyModuleMarker)

    # Check that we can get attributes off of our lazy modules

# Generated at 2022-06-24 02:54:00.261283
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    #testing the initialization of module
    assert  module



# Generated at 2022-06-24 02:54:04.583392
# Unit test for constructor of class NonLocal
def test_NonLocal():
  import sys
  import os
  from types import ModuleType
  from types import FunctionType
  def foo():
    x = NonLocal(10)
    def bar():
      x._NonLocal__slots__ = () # Modify the attribute of x fails with error
      x.value = 100
    bar()
    print(x.value)
  foo()

# Generated at 2022-06-24 02:54:07.906235
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)

# Generated at 2022-06-24 02:54:10.846002
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    class TestClass(object):
        def __init__(self):
            self.variable = NonLocal(sys.version)

    test = TestClass()
    assert test.variable.value


# Generated at 2022-06-24 02:54:13.408807
# Unit test for function make_lazy
def test_make_lazy():
    import os.path
    module_path = ['os.path']
    make_lazy(module_path[0])
    assert os.path.isdir is None
    os.path.isdir = 5

# Generated at 2022-06-24 02:54:16.409646
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = "test"
    nl.value == "test"


# Generated at 2022-06-24 02:54:19.918909
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:54:27.187782
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    assert module_a not in sys.modules
    assert module_b not in sys.modules
    assert module_c not in sys.modules

    module_a = make_lazy('tests.test_lazy_module.module_a')
    module_b = make_lazy('tests.test_lazy_module.module_b')
    module_c = make_lazy('tests.test_lazy_module.module_c')

    assert isinstance(module_a, _LazyModuleMarker)
    assert isinstance(module_b, _LazyModuleMarker)
    assert isinstance(module_c, _LazyModuleMarker)

    assert module_c.attr_c == 'attr_c'
    assert module_c.attr_a == 'attr_a'

    assert module_b.attr

# Generated at 2022-06-24 02:54:37.482202
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import glob
    import os
    import re
    import unittest

    # This regular expression is used to search the entire output of the
    # "help" command, to find out if our lazy module shows up in the output
    # of the module listing.

    # This is a very simple "unit" test, written to test our function.

    # This is not a real unit test as it does not test only a
    # "unit" (the unit being the function `make_lazy`). But it's
    # what we have for now.
    lazy_module_listing_re = re.compile(r'^\s*LazyTest (\s|$)', re.MULTILINE)

    @make_lazy('LazyTest')
    class LazyTest(object):
        pass


# Generated at 2022-06-24 02:54:39.342307
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    def test():
        mark = _LazyModuleMarker()
        assert mark is not None
    test()

# Generated at 2022-06-24 02:54:42.679691
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    if marker.__class__ != _LazyModuleMarker:
        return False
    return True


# Generated at 2022-06-24 02:54:44.133146
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10


# Generated at 2022-06-24 02:54:52.700333
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import django.utils.lazy
    import django.utils.timezone

    lazy_module = sys.modules['django.utils.lazy']
    timezone_module = sys.modules['django.utils.timezone']

    # Check that sys.modules is set up as expected
    assert lazy_module is django.utils.lazy
    assert timezone_module is django.utils.timezone
    assert not isinstance(lazy_module, _LazyModuleMarker)
    assert isinstance(timezone_module, _LazyModuleMarker)
    assert hasattr(django.utils.lazy, 'make_lazy')
    assert not hasattr(django.utils.timezone, 'make_lazy')

    # Lazy module should not have been imported yet.
    assert module_is

# Generated at 2022-06-24 02:54:56.367882
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:01.667008
# Unit test for function make_lazy
def test_make_lazy():
    try:
        make_lazy('test_make_lazy')
        import test_make_lazy
        assert 'test_make_lazy' in sys.modules
        assert isinstance(test_make_lazy, _LazyModuleMarker)
        assert not isinstance(test_make_lazy, ModuleType)
        assert hasattr(test_make_lazy, 'test_make_lazy')
    finally:
        del sys.modules['test_make_lazy']



# Generated at 2022-06-24 02:55:05.733518
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('django_nose.settings')
    import inspect
    assert inspect.ismodule(sys.modules['django_nose.settings'])
    assert isinstance(sys.modules['django_nose.settings'], _LazyModuleMarker)
    assert sys.modules['django_nose.settings'] is not None



# Generated at 2022-06-24 02:55:11.142878
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    make_lazy('module_path')


# Generated at 2022-06-24 02:55:17.781182
# Unit test for function make_lazy
def test_make_lazy():
    # Test 1 - module already exists
    # This should not be lazy
    try:
        import os
        make_lazy('os')
        assert False
    except KeyError:
        pass

    # Test 2 - module doesn't exist
    import sys
    make_lazy("fake")
    assert sys.modules['fake'] is not None

test_make_lazy()

# Generated at 2022-06-24 02:55:22.943808
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        foo = NonLocal('test')
        assert foo.value == 'test'
    except:
        return False
    return True


# Generated at 2022-06-24 02:55:28.183244
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 1
    assert nl.value == 1


# Generated at 2022-06-24 02:55:30.884915
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test if NonLocal(object) can avoid import the object
    until attribute of the object is called
    """
    module = NonLocal(None)
    assert module.value == None, 'The constructor of NonLocal is not right'



# Generated at 2022-06-24 02:55:36.935532
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(object):
        def __init__(self):
            self.data = NonLocal(1)

    test = Test()
    assert test.data.value == 1

if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-24 02:55:39.723928
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    # Create a module instance
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:41.724204
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_object = _LazyModuleMarker()
    assert type(test_object) == _LazyModuleMarker
    return


# Generated at 2022-06-24 02:55:44.101886
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(None, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:51.253905
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if sys.version_info[0] == 2:
        class test_class(object):
            def __init__(self):
                self.val = NonLocal(None)

            def test_func(self):
                def inner_func():
                    self.test(1)
                return inner_func

            def test(self, num):
                self.val.value = num

            def check(self):
                return self.val.value

        obj = test_class()
        assert obj.check() is None
        obj.test_func()()
        assert obj.check() == 1



# Generated at 2022-06-24 02:55:54.504075
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker == _LazyModuleMarker)
    assert(_LazyModuleMarker != 5)
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))


# Generated at 2022-06-24 02:55:59.790582
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3


# Generated at 2022-06-24 02:56:00.906767
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # No arguments
    m = _LazyModuleMarker()
    assert m is not None


# Generated at 2022-06-24 02:56:05.774372
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value is None
    nl = NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-24 02:56:12.665521
# Unit test for function make_lazy
def test_make_lazy():
    import random
    import six

    # This is the module name we will make lazy
    lazy_module_name = "six.moves.random"
    # This is the real module which is normally imported
    real_module = random

    # We are going to create a fake module object in its place.
    # This is the module object we will create
    fake_module = object()

    # Store a reference to the original state of sys.modules
    orig_modules = dict(six.moves.copy.copy(sys.modules))


# Generated at 2022-06-24 02:56:16.404529
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('fluffy')
    from fluffy import Bunny
    from fluffy.bunny import AngelBunnyException
    assert isinstance(Bunny, _LazyModuleMarker)
    assert isinstance(AngelBunnyException, type)
    assert Bunny.name == 'Fluffy'

# Set up the lazily loaded modules
make_lazy('fluffy')


# Generated at 2022-06-24 02:56:17.439819
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1



# Generated at 2022-06-24 02:56:25.931310
# Unit test for function make_lazy
def test_make_lazy():
    testmod = 'foo.bar'
    # Error raising if module is not found
    try:
        __import__(testmod)
    except ImportError:
        pass
    # Test for a lazy module and instance
    make_lazy(testmod)
    testmod = sys.modules[testmod]
    assert isinstance(testmod, _LazyModuleMarker)
    assert hasattr(testmod, '__name__')
    assert hasattr(testmod, '__file__')
    # Test for lazy module getattr
    testmod.__foo__ = 'bar'
    assert hasattr(testmod, '__foo__')

# Generated at 2022-06-24 02:56:28.052272
# Unit test for constructor of class NonLocal
def test_NonLocal():
    boolean = True
    if boolean:
        i = NonLocal(1)
    i.value += 1
    assert(i.value == 2)

# Generated at 2022-06-24 02:56:32.424620
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(2)
    if a.value != 2:
        print("FAIL: NonLocal constructor failed.")
        print("Expected output: 2")
        print("Actual output: " + str(a.value))
    else:
        print("PASS: NonLocal constructor passed.")


# Generated at 2022-06-24 02:56:34.037660
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(LazyModule(), _LazyModuleMarker)


# Generated at 2022-06-24 02:56:35.906215
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mark = _LazyModuleMarker()

test__LazyModuleMarker()


# Generated at 2022-06-24 02:56:41.560798
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can put a lazymodule in the sys modules.
    """
    def import_foo():
        import foo

    def import_foo_lazy():
        sys.modules['foo'] = make_lazy('foo')

    # The lazy module should not error out.
    import_foo_lazy()
    import_foo()
    import_foo()
    import_foo()

# Generated at 2022-06-24 02:56:48.775449
# Unit test for function make_lazy
def test_make_lazy():
    import xblock
    from xblock import engine
    from xblock.exceptions import NoSuchHandlerError

    assert hasattr(xblock, 'XBlock')
    assert getattr(xblock, 'XBLOCK_VERSION')

    # Mark the xblock module as lazy
    make_lazy('xblock')

    # NoSuchHandlerError should not be present
    assert not hasattr(xblock, 'XBlock')
    assert not hasattr(xblock, 'XBLOCK_VERSION')
    assert hasattr(xblock, 'engine')

    # `XBLOCK_VERSION` is not loaded
    with pytest.raises(AttributeError):
        getattr(xblock, 'XBLOCK_VERSION')

    # `engine` is not loaded
    with pytest.raises(NoSuchHandlerError):
        engine.Handler.load_class

# Generated at 2022-06-24 02:56:50.276896
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModule = _LazyModuleMarker()
    assert lazyModule is not None

# Generated at 2022-06-24 02:57:00.957713
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys
    import os
    import os.path
    import tempfile
    import imp

    # Create a test package
    sys.path.insert(0, tempfile.mkdtemp())
    os.mkdir('test_package')

    # Create  test_package/__init__.py
    with open(os.path.join('test_package', '__init__.py'), 'w') as init:
        print >>init, "def hello_world():\n    print 'Hello world'"

    # Import the test package with __name__ == 'test_package'
    test_package = imp.load_module('test_package',
                *imp.find_module('test_package'))

    # Check that the function is there and works

# Generated at 2022-06-24 02:57:02.331953
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(LazyModule, object)


# Generated at 2022-06-24 02:57:06.875626
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(NonLocal):
        def __init__(self, value=None):
            super(Test, self).__init__(value)

    test = Test()
    assert test.value is None   # value property is a NoneType object
    test.value = "test_string"
    assert test.value is "test_string"



# Generated at 2022-06-24 02:57:15.783098
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to make sure make_lazy is working.
    """
    import sys

    # make sure that we are not accidentally importing the module here.
    assert sys.modules['util'] is not None

    # create the dummy module so that we can test it.
    dummy = sys.modules['dummy'] = ModuleType('dummy')
    dummy.__file__ = '/foo/bar.py'

    with patch('os.path.exists') as exists:
        with patch('os.path.realpath') as realpath:
            exists.return_value = True
            realpath.side_effect = lambda x: x

            # make the module lazy.
            make_lazy('dummy')

            assert sys.modules['dummy'].__file__ == '/foo/bar.py'

            # access a value off of the module

# Generated at 2022-06-24 02:57:17.634591
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    assert isinstance(test, _LazyModuleMarker)

# Testing the module-level function make_lazy

# Generated at 2022-06-24 02:57:27.665301
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    def get_fake_module():
        """
        A fake module to test make_lazy
        """
        return make_lazy('test.fake_dep')


    # Test the fake module
    old_path = sys.path
    fake_path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             'fake_path'))

    sys.path = [fake_path]
    make_lazy('test.fake_dep')

    import test.fake_dep
    assert isinstance(test.fake_dep, _LazyModuleMarker)

    # accessing the module should load the real one
    assert test.fake_dep.__name__ == 'test.fake_dep'

# Generated at 2022-06-24 02:57:29.738653
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(_LazyModuleMarker(), ModuleType)

# Generated at 2022-06-24 02:57:31.077327
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Unit test for constructor of class _LazyModuleMarker")



# Generated at 2022-06-24 02:57:37.852391
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests to make sure the function works
    """
    module_path = '__main__'
    the_module = make_lazy(module_path)
    assert not hasattr(the_module, '__file__')
    assert isinstance(the_module, _LazyModuleMarker)
    assert not hasattr(the_module, '__file__')

    # load the module
    from __main__ import make_lazy

    assert hasattr(the_module, '__file__')
    assert not isinstance(the_module, _LazyModuleMarker)



# Generated at 2022-06-24 02:57:40.379031
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This test will pass if the unit test fails.
    """
    lazy_module = _LazyModuleMarker()
    assert isinstance(lazy_module, ModuleType) is False
    assert isinstance(lazy_module, _LazyModuleMarker) is True

# Generated at 2022-06-24 02:57:41.888487
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local = NonLocal(3)
    assert local.value == 3



# Generated at 2022-06-24 02:57:45.851446
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import datetime

    # Test make_lazy by making datetime lazy.
    assert 'datetime' in sys.modules
    make_lazy('datetime')
    assert 'datetime' in sys.modules
    assert datetime.datetime.now()
    assert 'datetime' in sys.modules

# Generated at 2022-06-24 02:57:50.908700
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function
    """

# Generated at 2022-06-24 02:57:51.768790
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal("foo")
    assert a.value == "foo"

# Generated at 2022-06-24 02:57:57.251559
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest

    class Test__LazyModuleMarker(unittest.TestCase):
        def test__LazyModuleMarker(self):
            try:
                make_lazy('flyingcircus.test_utils')
                from flyingcircus.test_utils import is_lazy
                self.assertTrue(is_lazy('flyingcircus.test_utils'))
            finally:
                del sys.modules['flyingcircus.test_utils']

    unittest.main()

# Generated at 2022-06-24 02:57:59.044297
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_object = NonLocal([])
    my_object.value.append('foo')

    assert my_object.value == ['foo']


# Generated at 2022-06-24 02:58:03.440329
# Unit test for function make_lazy
def test_make_lazy():
    # First, make sure that `object` is not a lazy module.
    assert not isinstance(object, _LazyModuleMarker)

    # Now, patch `object` to be a lazy module to test our function
    # make_lazy
    make_lazy('object')
    assert isinstance(object, _LazyModuleMarker)

    # make sure that we can use the `object` module as expected
    assert hasattr(object, '__doc__')
    assert object.__doc__ == 'The most base type'
    # make sure that the module is no longer a LazyModule
    assert not isinstance(object, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:05.383529
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_lazy = _LazyModuleMarker()
    assert isinstance(test_lazy, _LazyModuleMarker)



# Generated at 2022-06-24 02:58:06.871280
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    a = _LazyModuleMarker()

# Generated at 2022-06-24 02:58:12.952506
# Unit test for function make_lazy
def test_make_lazy():
    """
    If datetime module is lazy, we don't have timezone property in it,
    but can import it.
    """
    make_lazy('datetime')
    import datetime
    try:
        # if datetime is lazy, this statement should be true
        assert not hasattr(datetime, 'timezone')
    finally:
        # restore the old value in sys.modules
        sys.modules['datetime'] = _sys_modules_orig.get('datetime')


_sys_modules_orig = sys.modules.copy()


# Mark the following packages lazy
make_lazy('django')
make_lazy('celery')
make_lazy('celery.app')
make_lazy('celery.app.task')
make_lazy('celery.app.base')

# Generated at 2022-06-24 02:58:15.968737
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    assert _LazyModuleMarker.__name__ != ModuleType.__name__
    print('test__LazyModuleMarker passed')


# Generated at 2022-06-24 02:58:25.302247
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Check if the module is considered internally a subclass of _LazyModuleMarker
    module_path = 'lazy_module_marker_test'
    make_lazy(module_path)

    class MyClass(_LazyModuleMarker):  # noqa
        # This class is required for the test
        pass

    assert isinstance(MyClass(), _LazyModuleMarker)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)



# Generated at 2022-06-24 02:58:26.532173
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert callable(_LazyModuleMarker)


# Generated at 2022-06-24 02:58:28.886286
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    marker = _LazyModuleMarker()
    assert marker is not None

# Generated at 2022-06-24 02:58:37.456903
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from random import randint
    from copy import deepcopy

    for _ in range(1000):
        l = []
        for _ in range(randint(1, 1000)):
            l.append(randint(-1000, 1000))

        L = NonLocal(l)
        l1 = deepcopy(l)
        l = []

        for x in l1:
            l.append(x)

        assert L.value == l1

# Generated at 2022-06-24 02:58:39.725528
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test function to construct a NonLocal
    """
    o = NonLocal(1)
    assert o.value == 1



# Generated at 2022-06-24 02:58:40.923595
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert x is not None


# Generated at 2022-06-24 02:58:48.679861
# Unit test for function make_lazy
def test_make_lazy():
    from inspect import ismodule
    import sys
    import _test_mod
    assert(not ismodule(_test_mod))
    make_lazy("_test_mod")
    assert(not ismodule(_test_mod))
    assert(sys.modules["_test_mod"].__mro__()[1] == ModuleType)
    assert(hasattr(_test_mod, "__file__"))
    # We should now have a real module in our modules dict
    assert(ismodule(sys.modules["_test_mod"]))
    # And we should have a lazy module in our modules dict
    assert(ismodule(_test_mod))


# Generated at 2022-06-24 02:58:50.978970
# Unit test for constructor of class NonLocal
def test_NonLocal():
    number = NonLocal(0)
    assert number.value == 0
    number.value = 1
    assert number.value == 1


# Generated at 2022-06-24 02:59:01.483948
# Unit test for function make_lazy
def test_make_lazy():
    # we're in a function so we can modify sys.modules temporarily
    _original_modules = sys.modules.copy()
    sys.modules.clear()

    # getattr will have to trigger the lazy module
    def import_lazy():
        getattr(lazy, 'foo')

    def load_lazy():
        # load a module that is lazy
        import lazy

    # check that lazy modules work correctly
    assert 'lazy' not in sys.modules
    make_lazy('lazy')
    import_lazy()
    assert 'lazy' in sys.modules

    # modules should still be lazy after import
    assert isinstance(sys.modules['lazy'], _LazyModuleMarker)

    # regression test to ensure that __import__ still works
    load_lazy()

# Generated at 2022-06-24 02:59:12.059834
# Unit test for function make_lazy
def test_make_lazy():
    """Test the lazy module creation"""
    import sys
    import os.path
    import inspect

    test_module_not_in_sys = inspect.getsourcefile(test_make_lazy)
    test_module_not_in_sys = os.path.splitext(test_module_not_in_sys)[0]
    dots_in_module_name = test_module_not_in_sys.replace(os.path.sep, '.')
    assert dots_in_module_name not in sys.modules, \
        "Test module must not be loaded in sys.modules"

    make_lazy(dots_in_module_name)
    assert isinstance(sys.modules[dots_in_module_name], _LazyModuleMarker)

    # must not shadow the real module
    assert os.path

# Generated at 2022-06-24 02:59:21.746495
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    # Test default behavior without make_lazy()
    assert 'django' not in sys.modules, "Django already in sys.modules"

    import django

    assert django is not None
    assert 'django' in sys.modules

    # Test lazy loading
    make_lazy('django')
    assert 'django' in sys.modules
    assert isinstance(sys.modules['django'], ModuleType)

    # Django should still be in the sys.modules cache, just not fully loaded
    from django import get_version
    assert get_version() is not None
    assert isinstance(sys.modules['django'], _LazyModuleMarker)

# Generated at 2022-06-24 02:59:22.845539
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(2)
    assert n.value == 2, "NonLocal should store value"


# Generated at 2022-06-24 02:59:25.981595
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    make_lazy('os')
    assert os.getcwd() == sys.modules['os'].getcwd()
    assert isinstance(sys.modules['os'], _LazyModuleMarker)

# Generated at 2022-06-24 02:59:29.730190
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None and isinstance(marker, object)

# Generated at 2022-06-24 02:59:30.224007
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass

# Generated at 2022-06-24 02:59:36.207159
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import sys
        make_lazy("blah.foo")
        foo = sys.modules["blah.foo"]
        assert(isinstance(foo, _LazyModuleMarker))
        assert(not isinstance(sys.modules["blah.foo"], _LazyModuleMarker))
        assert(foo.__class__.__name__ == "LazyModule")
    except:
        pass
    finally:
        if 'blah.foo' in sys.modules:
            del sys.modules["blah.foo"]

# Generated at 2022-06-24 02:59:38.449363
# Unit test for constructor of class NonLocal
def test_NonLocal():
  a = NonLocal(4)
  assert a.value == 4
  a.value = 5
  assert a.value == 5
  
test_NonLocal()

# Generated at 2022-06-24 02:59:46.431421
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Base(object):
        pass
    class Sub(Base):
        pass
    def mro():
        return (Sub, Base, object)
    Sub.__mro__ = mro
    b = Base()
    assert not isinstance(b, Sub) # Because Sub.__mro__ is mro, not (Sub, Base, object)
    assert not isinstance(b, _LazyModuleMarker)


# Generated at 2022-06-24 02:59:47.298418
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:59:49.576378
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(1)
    assert nonlocal_instance.value == 1
    assert isinstance(nonlocal_instance, NonLocal)


# Generated at 2022-06-24 02:59:55.558522
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = 1
    def test(a):
        v = NonLocal(a)
        assert a == v.value
    test(a)


# Generated at 2022-06-24 02:59:57.452721
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert isinstance(lmm, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:08.780453
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile

    # The dynamic nature of this library makes it a bit hard to test.
    # This test runs make_lazy() on a temporary module in the filesystem
    # and then tries to import it. If it works, the test is "successful".

    # Create a module file
    fd, modpath = tempfile.mkstemp(suffix='.py')
    os.close(fd)
    with open(modpath, 'w') as f:
        f.write('import os\n')
        f.write('def fn_in_mod():\n')
        f.write('    return os.getpid()\n')

    # Create a module name to import
    modname = modpath.replace('/', '.').replace('\\', '.')

# Generated at 2022-06-24 03:00:10.776991
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(type(_LazyModuleMarker()) == _LazyModuleMarker)

# Generated at 2022-06-24 03:00:14.852424
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    assert lazy is not None


# Generated at 2022-06-24 03:00:16.499175
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	marker = _LazyModuleMarker()
	assert marker is not None, "marker cannot be None"


# Generated at 2022-06-24 03:00:23.677305
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import __main__
    import sys
    import types
    from types import ModuleType
    from sys import modules
    from django.utils.importlib import import_module

    from django.contrib.auth.decorators import user_passes_test as _upt
    from django.contrib.auth.decorators import user_passes_test as _upt2

    # test for valid input for constructor
    assert _upt == _upt2

    # test for the built-in identity property (as opposed to the is operator)
    assert _upt is _upt2

    # test if sys.modules[] is set
    assert _upt in sys.modules

    # test if __main__.__dict__ is set
    assert _upt in __main__.__dict__

    # test if module type is of type ModuleType
    assert isinstance

# Generated at 2022-06-24 03:00:34.861958
# Unit test for function make_lazy
def test_make_lazy():
    # make sure it works with a real module import
    import os
    make_lazy('os')
    # Make sure that even though we marked it as 'lazy'
    # it still appears to be a module to the outside world
    assert isinstance(os, ModuleType)
    # Check it's working as expected
    assert os.getpid() == os.getpid()  # this should not fail with an ImportError

    # make sure it works with a fake module import
    make_lazy('fake_module')

    # Make sure that even though we marked it as 'lazy'
    # it still appears to be a module to the outside world
    assert isinstance(fake_module, ModuleType)

    # Check it's working as expected

# Generated at 2022-06-24 03:00:36.582903
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 03:00:43.383526
# Unit test for function make_lazy
def test_make_lazy():

    import imp

    # We don't want to disturb the 'foo' module if its already loaded
    if 'foo' in sys.modules:
        import foo
        mod_one = foo
    else:
        mod_one = imp.new_module('foo')
        mod_one.a = 'a'

    make_lazy('foo')

    # Check that module is not loaded
    import foo
    assert foo is not mod_one

    # Check that 'a' is not avaialble
    try:
        foo.a
        assert False, 'foo.a should not be available'
    except AttributeError:
        pass

    # Check that 'a' is avaialble after import
    mod_two = imp.new_module('foo')
    mod_two.a = 'b'

# Generated at 2022-06-24 03:00:44.347640
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 03:00:45.480522
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker("_LazyModuleMarker")


# Generated at 2022-06-24 03:00:47.438486
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)
    assert isinstance(a, (type, object)) == False


# Generated at 2022-06-24 03:00:51.295397
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(type(a) == _LazyModuleMarker)



# Generated at 2022-06-24 03:00:53.828097
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = None
    nl = NonLocal(test_value)
    nl.value = test_value
    print('Test for class NonLocal passed.')


# Generated at 2022-06-24 03:00:57.175881
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    to_check = _LazyModuleMarker()
    assert(isinstance(to_check, _LazyModuleMarker) == True)

# Generated at 2022-06-24 03:00:58.108089
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    temp = _LazyModuleMarker()

# Generated at 2022-06-24 03:01:07.879537
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import random
    from random import randint
    from random import randrange

    assert isinstance(random, _LazyModuleMarker)
    assert isinstance(randint, _LazyModuleMarker)
    assert isinstance(randrange, _LazyModuleMarker)

    # Try accessing attributes to see if they work
    assert randint._int_to_bytes == 4
    assert randrange.__name__ == 'randrange'

    # Test that our _LazyModuleMarker works when a class is, in fact,
    # a sub class of ModuleType.
    mod = sys.modules['random']
    assert isinstance(mod, _LazyModuleMarker)
    assert isinstance(mod, ModuleType)
    assert mod.__mro__ == (mod, ModuleType)

# Generated at 2022-06-24 03:01:09.407839
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A:
        def __mro__(self):
            return (A, object)
    assert isinstance(A(), _LazyModuleMarker) == False



# Generated at 2022-06-24 03:01:12.415551
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(5)
    assert nonlocal_obj.value == 5
    nonlocal_obj.value = 6
    assert nonlocal_obj.value == 6


# Generated at 2022-06-24 03:01:18.816714
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # store our 'instance' data in the closure.
    counter = NonLocal(0)

    def add_one():
        counter.value += 1

    add_one()
    add_one()
    add_one()
    assert counter.value == 3


if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 03:01:24.027617
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class NonLocalTest(object):
        def __init__(self):
            self.my_value = 5

    nlt = NonLocalTest()
    test_nl = NonLocal(nlt)

    def test_func():
        test_result = NonLocal(None)
        test_result.value = 6

# Generated at 2022-06-24 03:01:31.924131
# Unit test for function make_lazy
def test_make_lazy():
    def test_import(module_path):
        import sys
        assert sys.modules[module_path] is None

    def test_imports(module_path):
        import sys
        for attribute in dir(sys.modules[module_path]):
            assert attribute not in sys.modules

    import sys

    # Sample module with a recursive dependency
    sys.modules['sample_module'] = None
    sys.modules['sample_module2'] = None
    sys.modules['sample_module3'] = None

    make_lazy('sample_module')
    make_lazy('sample_module2')
    make_lazy('sample_module3')

    test_import('sample_module')
    test_import('sample_module2')
    test_import('sample_module3')

    import sample_module
    import sample_module2

# Generated at 2022-06-24 03:01:32.961520
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3



# Generated at 2022-06-24 03:01:36.317217
# Unit test for function make_lazy
def test_make_lazy():
    import xblock.test.tools.modules
    assert isinstance(xblock.test.tools.modules, _LazyModuleMarker)

    from xblock.test.tools.modules import load_test_courses
    assert isinstance(xblock.test.tools.modules, ModuleType)



# Generated at 2022-06-24 03:01:39.105045
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test_NonLocal
    """
    try:
        _ = NonLocal(None)
    except Exception as exc:
        assert False, "test_NonLocal:NonLocal() throws an exception:{0}".format(exc)
    else:
        assert True, "test_NonLocal:NonLocal() passes".format(exc)

# Generated at 2022-06-24 03:01:41.414184
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker) is True


# Generated at 2022-06-24 03:01:45.130637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class TestSubclassing(object):
        pass
    assert not isinstance(TestSubclassing(), _LazyModuleMarker)
    assert not issubclass(TestSubclassing, _LazyModuleMarker)


# Generated at 2022-06-24 03:01:49.371763
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test():
        def __init__(self, value):
            self.value = value

        def get_value(self):
            return self.value


    test = Test(4)
    assert test.get_value() == 4
    test.value = 5
    assert test.get_value() == 5

# Generated at 2022-06-24 03:01:53.562814
# Unit test for constructor of class NonLocal
def test_NonLocal():
    val = NonLocal(2)
    assert val.value == 2
    val.value = "new"
    assert val.value == "new"

# Generated at 2022-06-24 03:01:57.486904
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test module __LazyModuleMarker
    """
    test = _LazyModuleMarker()

# Generated at 2022-06-24 03:01:58.715234
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(5)
    assert nl.value == 5

# Generated at 2022-06-24 03:02:01.993033
# Unit test for function make_lazy
def test_make_lazy():
    assert hasattr(sys.modules['sys'], 'version') is True
    assert isinstance(sys.modules['sys'], ModuleType)

    make_lazy('sys')
    assert hasattr(sys.modules['sys'], 'version') is True
    assert isinstance(sys.modules['sys'], ModuleType)

# Generated at 2022-06-24 03:02:07.730341
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import nose.tools as n
    from itertools import chain


    # Test: __mro__ always returns the same thing
    #
    # A good way to check this is to use `isinstance(mod, _LazyModuleMarker)`
    # since that is the typical usage for this class.
    for i in chain(range(1), range(10)):
        n.assert_equal(
            _LazyModuleMarker().__mro__(),
            (LazyModule, ModuleType),
            )

# Generated at 2022-06-24 03:02:08.599598
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 03:02:10.355473
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 03:02:15.284217
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert isinstance(lazy_module, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:19.419132
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test if make_lazy works as expected.
    """
    make_lazy('test')
    assert 'test' in sys.modules
    assert isinstance(sys.modules['test'], _LazyModuleMarker)
    assert sys.modules['test'].__mro__()[0] == sys.modules['test']
    assert sys.modules['test'].__mro__()[1] == ModuleType



# Generated at 2022-06-24 03:02:31.267451
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can prevent modules from being imported
    """
    import sys
    import random

    kwargs = dict()
    assert 'random' not in sys.modules
    if hasattr(sys, 'getrefcount'):
        kwargs['refcount_sys'] = sys.getrefcount(sys)
        kwargs['refcount_random'] = sys.getrefcount(random)

    make_lazy('random')

    assert 'random' in sys.modules
    assert isinstance(sys.modules['random'], _LazyModuleMarker)

    # the module should not have been imported
    if hasattr(sys, 'getrefcount'):
        assert sys.getrefcount(sys) == kwargs['refcount_sys']

# Generated at 2022-06-24 03:02:42.001784
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import a.b.c.d.e.f.g.h

    class Klass(object):
        def __init__(self):
            self.time = time.time()

    a_b_c_d_e_f_g_h = a.b.c.d.e.f.g.h

    x = time.time()

    make_lazy('a.b.c.d.e.f.g.h')

    y = time.time()

    assert isinstance(a.b.c.d.e.f.g.h, _LazyModuleMarker)
    assert isinstance(a_b_c_d_e_f_g_h, _LazyModuleMarker)
    assert a.b.c.d.e.f.g.h is a_

# Generated at 2022-06-24 03:02:48.301726
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import functools
    a = [0]
    b = [0]
    c = [0]
    def g():
        a[0] += 1
        yield b
    def f():
        c[0] += 1
        for i in g():
            yield i
    f = functools.partial(f, 1, 2)
    def i():
        return f()
    # we cannot import g, f and i here
    globals()['g'] = g
    globals()['f'] = f
    globals()['i'] = i
    d = NonLocal(None)
    def foo():
        d.value = i()
    foo()
    assert a == [1]
    assert c == [1]
    assert d.value == b
    d.value = None

# Generated at 2022-06-24 03:02:51.612165
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # No assertion is needed since the interpreter will fail
    # to create an instance of _LazyModuleMarker and output
    # an AssertionError if it is incorrect.
    _ = _LazyModuleMarker()


# Generated at 2022-06-24 03:02:55.187632
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nolocal = NonLocal("nonLocal value")
    assert nolocal.value == "nonLocal value"


# Generated at 2022-06-24 03:03:02.949012
# Unit test for function make_lazy
def test_make_lazy():
    _load_module = False
    _isinstance = False

    class _LazyModule(object):
        """
        Mock module to make sure it's lazily loaded.
        """
        @classmethod
        def __mro__(cls):
            """
            Override the __mro__ to fool `isinstance`.
            """
            nonlocal _isinstance
            _isinstance = True
            return (LazyModule, ModuleType)

        def __getattribute__(self, attr):
            """
            Override __getattribute__ to hide the implementation details.
            """
            nonlocal _load_module
            _load_module = True
            return super(_LazyModule, self).__getattribute__(attr)


    sys_modules = sys.modules
    make_lazy('tests.lazy')


# Generated at 2022-06-24 03:03:06.995193
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker_instance = _LazyModuleMarker()
    assert isinstance(_LazyModuleMarker_instance, _LazyModuleMarker)


# Generated at 2022-06-24 03:03:08.505939
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test constructor
    non_local = NonLocal(1)
    assert non_local.value == 1

# Generated at 2022-06-24 03:03:10.866093
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker


# Generated at 2022-06-24 03:03:13.117883
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = _LazyModuleMarker()

    assert not isinstance(a, _LazyModuleMarker)
    assert not isinstance(b, _LazyModuleMarker)


# Generated at 2022-06-24 03:03:15.034129
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Basic unit test to check the constructor of class NonLocal
    """
    my_value = 1
    my_show = NonLocal(my_value)
    assert my_show.value == my_value


# Generated at 2022-06-24 03:03:17.133889
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2

# Generated at 2022-06-24 03:03:26.207797
# Unit test for function make_lazy
def test_make_lazy():

    def sub_import():
        """
        Function to import an already imported module
        """
        import sys
        import import_test
        sys.stdout.write(str(import_test))

    def direct_import():
        """
        Function to import a module directly
        """
        import sys
        import import_test
        sys.stdout.write(str(import_test))

    class TestMakeLazy(unittest.TestCase):
        """
        Test case for function make_lazy
        """
        def setUp(self):
            """
            Set up function.
            """
            self.modules = {}
            self.backup = {}

            for mod in sys.modules:
                self.modules[mod] = sys.modules[mod]


# Generated at 2022-06-24 03:03:35.089576
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    class Foo(object):
        pass

    class Bar(object):
        pass

    sys.modules['test.test_make_lazy_foo'] = Foo()
    sys.modules['test.test_make_lazy_bar'] = Bar()
    sys.modules['test.test_make_lazy_imp_error'] = ImportError

    # Make sure it doesn't already exist when we start
    assert 'test.test_make_lazy_lazy' not in sys.modules

    import test.test_make_lazy_foo
    assert test.test_make_lazy_foo.__class__ is Foo

    make_lazy('test.test_make_lazy_lazy')
    import test.test_make_lazy_lazy