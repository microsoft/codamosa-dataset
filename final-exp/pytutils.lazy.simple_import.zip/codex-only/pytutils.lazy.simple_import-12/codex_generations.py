

# Generated at 2022-06-24 02:53:25.591441
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-24 02:53:28.518427
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not hasattr(_LazyModuleMarker, '__mro__')
    assert issubclass(LazyModule, _LazyModuleMarker)
    assert issubclass(LazyModule, ModuleType)


# Generated at 2022-06-24 02:53:31.229473
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = "abc"
    assert nl.value == "abc"


# Generated at 2022-06-24 02:53:33.954214
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 02:53:42.364088
# Unit test for function make_lazy
def test_make_lazy():
    # Mock the sys.modules import.
    sys.modules = {}

    make_lazy('django_hosts.tests.files.no_models')
    from django_hosts.tests.files import no_models

    assert isinstance(no_models, _LazyModuleMarker)
    assert 'no_models' not in sys.modules

    # Test a lazy module is loaded.
    assert no_models.FOO == 'bar'
    assert isinstance(no_models, _LazyModuleMarker)
    assert sys.modules['django_hosts.tests.files.no_models'].FOO == 'bar'
    assert isinstance(sys.modules['django_hosts.tests.files.no_models'], ModuleType)

    # Test a lazy module is only loaded once.
    no_models.BAZ

# Generated at 2022-06-24 02:53:44.072530
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)
    assert n.value == 3

# Generated at 2022-06-24 02:53:48.512398
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy("mymodule"), ModuleType)
    assert isinstance(make_lazy("mymodule"), _LazyModuleMarker)
    assert not isinstance(make_lazy("mymodule"), LazyModule)

# Generated at 2022-06-24 02:53:58.819606
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # Test dot notation
    make_lazy('os.path')
    assert isinstance(os.path, _LazyModuleMarker)
    assert isinstance(os.path, ModuleType)
    assert not isinstance(os.path, builtins.object)

    assert os.path.basename.__module__ == 'ntpath'
    assert os.path.basename.__name__ == 'basename'

    # Test list notation
    make_lazy('[os].path')
    assert isinstance(os.path, _LazyModuleMarker)
    assert isinstance(os.path, ModuleType)
    assert not isinstance(os.path, builtins.object)

    assert os.path.basename.__module

# Generated at 2022-06-24 02:54:00.453488
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:54:03.685316
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import test_lazy_module.tests as t
    make_lazy('test_lazy_module.tests')
    # Only one module should be loaded.
    # As of now it is only two because of unittest
    assert len(sys.modules) == 2
    # This should work even if the module is lazy
    assert t.val == 10


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:54:14.351780
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy("test_make_lazy_module")
    sys.modules["test_make_lazy_module"].__dict__["BAR"] = "bar"
    import test_make_lazy_module
    assert(test_make_lazy_module.BAR == "bar")
    assert(isinstance(test_make_lazy_module, _LazyModuleMarker))

    # Test that the module is brought in on getattr
    # If we do not do this, then the module import
    # will happen on the next getattr, and the unit
    # test will succeed but the main code will fail.
    assert(getattr(test_make_lazy_module, "BAR") == "bar")


# Make lazy a few modules
make_lazy("requests")

# Generated at 2022-06-24 02:54:17.265797
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_attrib = NonLocal(10)
    assert nonlocal_attrib.value == 10

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:54:21.907076
# Unit test for constructor of class NonLocal
def test_NonLocal():
    '''
    This is not a test of make_lazy.
    '''
    l = NonLocal(None)
    assert l.value is None
    l = NonLocal(1)
    assert l.value == 1
    l = NonLocal('abc')
    assert l.value == 'abc'
    test_NonLocal.tested = True


# Generated at 2022-06-24 02:54:23.055205
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)

    assert x.value == 0


# Generated at 2022-06-24 02:54:24.505219
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker(), ModuleType)
    _LazyModuleMarker()

# Generated at 2022-06-24 02:54:31.656171
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule(object):
        def somemethod(self):
            return 'hello'

    modname = 'testmodule'
    sys.modules[modname] = TestModule()
    make_lazy(modname)

    mod = __import__(modname)
    assert isinstance(mod, _LazyModuleMarker), mod

    assert mod.somemethod() == 'hello', mod

    assert modname in sys.modules

# Generated at 2022-06-24 02:54:34.494068
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        assert issubclass(ModuleType, _LazyModuleMarker)
    except:
        raise AssertionError("Unit test for _LazyModuleMarker failed.")

# Generated at 2022-06-24 02:54:37.158031
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    make_lazy('django.utils.decorators')
    assert isinstance(sys.modules['django.utils.decorators'], _LazyModuleMarker)


# Generated at 2022-06-24 02:54:46.704636
# Unit test for function make_lazy
def test_make_lazy():
    '''Test our lazy module implementation'''

    # create a dummy module
    def test_module_func():
        pass

    open('test_lazy_module.py', 'w').write(
        '__all__ = ["test_module_func"]\n'
        'test_module_func = %r' % test_module_func
    )

    sys.path.append(os.getcwd())

# Generated at 2022-06-24 02:54:50.855427
# Unit test for function make_lazy
def test_make_lazy():

    import foo

    assert foo.NOT_LAZY == False
    assert isinstance(foo, _LazyModuleMarker)

    foo.baz()
    assert foo.NOT_LAZY

    assert isinstance(foo, ModuleType)
    assert not isinstance(foo, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:52.278572
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_val = NonLocal(5)
    assert nonlocal_val.value == 5


# Generated at 2022-06-24 02:54:55.401789
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(123)
    assert(value.value == 123)



# Generated at 2022-06-24 02:54:58.542786
# Unit test for constructor of class NonLocal
def test_NonLocal():
    @contextmanager
    def test_context():
        a = NonLocal(0)
        a.value = 1
        yield a

    with test_context() as r:
        assert r.value == 1
    assert r.value == 0



# Generated at 2022-06-24 02:55:06.664487
# Unit test for function make_lazy
def test_make_lazy():
    """
    Confirm that make lazy works.
    """
    import foo
    assert foo.foo == "foo"

    def reset():
        """
        Reset the module.
        """
        del sys.modules['foo']

    reset()
    # Make the module lazy and confirm that an import of the module works
    make_lazy('foo')
    import foo
    assert foo.foo == "foo"

    reset()
    # Import the module and then check that a reset works
    import foo
    assert foo.foo == "foo"
    reset()
    import foo
    assert foo.foo == "foo"

    reset()
    import foo
    del foo.foo
    import foo
    assert foo.foo == "foo"

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:55:09.163095
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(TypeError) as e:
        _LazyModuleMarker()
    assert str(e) == "_LazyModuleMarker(): no constructor defined"


# Generated at 2022-06-24 02:55:10.292139
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()



# Generated at 2022-06-24 02:55:16.125394
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert isinstance(m, _LazyModuleMarker)
    # repr should return a string containing type of m
    assert '_LazyModuleMarker' in repr(m)


# Generated at 2022-06-24 02:55:22.575323
# Unit test for constructor of class NonLocal
def test_NonLocal():
    shared = [None]
    def func():
        shared[0] = NonLocal(0)
        assert shared[0] is None
        shared[0].value = 1
        assert shared[0].value == 1
    func()
    assert shared[0].value == 1

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:55:27.664362
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal(1)
    assert v.value == 1


# Generated at 2022-06-24 02:55:28.723015
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)



# Generated at 2022-06-24 02:55:30.804677
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # create a new module object
    lazy = _LazyModuleMarker()
    # module object is lazy
    assert isinstance(lazy, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:37.276940
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1
    assert NonLocal('a').value == 'a'
    assert NonLocal(()).value == ()
    assert NonLocal((1,)).value == (1,)
    assert NonLocal(None).value is None
    assert NonLocal(object()).value is not None


# Generated at 2022-06-24 02:55:46.601656
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import imp
    import os

    def is_pkgdir(path):
        return os.path.exists(os.path.join(path, '__init__.py'))

    def is_pypath(path):
        return (os.path.exists(path) and
                (is_pkgdir(path) or not path.endswith('.py')))

    def join_path(*args):
        return os.path.join(*args)

    def import_test(test, data):
        def test_import():
            # create package and module test.test
            package = join_path(self.tmpdir, 'test')
            module = join_path(package, 'test.py')
            os.makedirs(package)
            with open(module, 'w') as f:
                f

# Generated at 2022-06-24 02:55:48.088724
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-24 02:55:55.183549
# Unit test for function make_lazy
def test_make_lazy():
    import types

    import sys

    module_path = 'test.test_lazy_module'
    module = sys.modules[module_path] = types.ModuleType(module_path)

    make_lazy(module_path)

    assert module is not sys.modules[module_path], "sys.modules is reused."
    assert sys.modules[module_path] is not None
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert not hasattr(sys.modules[module_path], 'a'), "Module is already imported"
    assert sys.modules[module_path].a == 'a'
    assert sys.modules[module_path] is module, "sys.module is set to the new module"



# Generated at 2022-06-24 02:55:58.729202
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) != _LazyModuleMarker()
    assert str(_LazyModuleMarker())!=_LazyModuleMarker()


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:55:59.985702
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(4)
    assert x.value == 4


# Generated at 2022-06-24 02:56:10.329325
# Unit test for function make_lazy
def test_make_lazy():
    import xml.etree.ElementTree as etree
    import xml.etree.cElementTree as cetree

    if isinstance(cetree, _LazyModuleMarker):
        import pytest
        pytest.skip('cElementTree is lazy on this platform')

    make_lazy('xml.etree.cElementTree')
    assert isinstance(cetree, _LazyModuleMarker)

    # does this work?
    assert etree.Element('a')
    assert isinstance(cetree, _LazyModuleMarker)


# Generated at 2022-06-24 02:56:16.201510
# Unit test for function make_lazy
def test_make_lazy():
    _module = 'lazy_import.tests._test_module'
    assert (_module not in sys.modules)

    make_lazy(_module)

    assert isinstance(sys.modules[_module], _LazyModuleMarker)

    # import the module lazily
    from . import _test_module

    # check the type
    assert isinstance(sys.modules[_module], ModuleType)

    # check the module's attributes
    assert _test_module.value == 1

# Generated at 2022-06-24 02:56:19.115354
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy("os")
    o = sys.modules["os"]
    assert isinstance(o, _LazyModuleMarker)

    # make sure it's using os._name_
    assert o._name_ == "os"

    # make sure it imports when needed
    assert o.name == os.name

# Generated at 2022-06-24 02:56:21.219860
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(10)
    print(nonlocal_value.value)
    if nonlocal_value.value == 10:
        print('OK')

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:56:24.890008
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker is not None


# Generated at 2022-06-24 02:56:26.228855
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10


# Generated at 2022-06-24 02:56:28.411628
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(0)
    assert i.value == 0

    i = NonLocal(1)
    assert i.value == 1



# Generated at 2022-06-24 02:56:29.691677
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('store this')

# Generated at 2022-06-24 02:56:33.288566
# Unit test for constructor of class NonLocal
def test_NonLocal():

    obj = NonLocal(0)
    assert obj.value == 0

    obj.value += 1
    assert obj.value == 1

    obj.value *= 2
    assert obj.value == 2



# Generated at 2022-06-24 02:56:43.283564
# Unit test for function make_lazy
def test_make_lazy():
    import os
    lazy_path = 'lazy_test'
    sys.modules['lazy_test'] = NonLocal(None)

    make_lazy(lazy_path)

    try:
        assert lazy_path in sys.modules
        assert sys.modules[lazy_path] is not None
        assert not isinstance(sys.modules[lazy_path], ModuleType)
        assert not hasattr(sys.modules[lazy_path], 'curdir')
        assert sys.modules[lazy_path].curdir == os.curdir
        assert isinstance(sys.modules[lazy_path], ModuleType)
        assert hasattr(sys.modules[lazy_path], 'curdir')
    finally:
        del sys.modules[lazy_path]


MODULES_TO_LAZY

# Generated at 2022-06-24 02:56:47.590526
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def closure():
        foo = NonLocal(None)
        def inner_func():
            foo.value = 1
            return foo
        return inner_func
    test_func = closure()
    test_foo = test_func()
    assert test_foo.value == 1
    test_foo.value = 2
    assert test_foo.value == 2


# Generated at 2022-06-24 02:56:50.158821
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_val = NonLocal(5)
    assert nonlocal_val.value == 5

test_NonLocal()


# Generated at 2022-06-24 02:56:53.069801
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(10)
    assert n.value == 10
    n.value = 15
    assert n.value == 15


# Generated at 2022-06-24 02:56:55.571761
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(20)
    assert nl.value == 20

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 02:56:58.494446
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test for constructor of class NonLocal
    """
    nl_obj = NonLocal(None)
    assert nl_obj.value is None


# Generated at 2022-06-24 02:57:10.200920
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    from StringIO import StringIO

    old_stdout = sys.stdout
    sys.stdout = StringIO()

    make_lazy('os')

# Generated at 2022-06-24 02:57:17.477267
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy works.
    """
    # clear the current module
    _clear_module(__name__)

    try:
        # Make sure we don't import it when we don't need it.
        make_lazy(__name__)
        assert sys.modules[__name__] is not None
        # try to get an attribute off of it
        sys.modules[__name__].__name__
    finally:
        # make sure we clear the module for other tests
        _clear_module(__name__)



# Generated at 2022-06-24 02:57:20.899555
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test the constructor
    a = NonLocal(1)
    assert(a.value == 1)


# Generated at 2022-06-24 02:57:25.355532
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('_lazy_no_module_')
    import _lazy_no_module_
    assert isinstance(_lazy_no_module_, _LazyModuleMarker)
    del sys.modules['_lazy_no_module_']


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:57:28.463140
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()



# Generated at 2022-06-24 02:57:31.125923
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local_marker = NonLocal(2)
    if not non_local_marker.value == 2 :
        raise Exception("NonLocal constructor is not defined properly")


# Generated at 2022-06-24 02:57:36.177610
# Unit test for function make_lazy
def test_make_lazy():
    def test_func():
        # Make sure module is not loaded
        assert not isinstance(sys.modules["time"], time.__class__)
        assert not isinstance(time, time.__class__)

        # Make sure it behaves like the original module
        assert time.gmtime()

    # Make sure we can reload the lazy module
    test_func()
    reload(time)
    test_func()

# Generated at 2022-06-24 02:57:38.503097
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert nl.value==42

# Generated at 2022-06-24 02:57:40.919453
# Unit test for function make_lazy
def test_make_lazy():
    # test that LazyModule doesn't error when running as a module or script
    if __name__ == '__main__':
        pass


# Generated at 2022-06-24 02:57:45.665537
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(None)
    assert foo.value is None
    foo.value = 10
    assert foo.value == 10


# Generated at 2022-06-24 02:57:47.295637
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1

# Generated at 2022-06-24 02:57:52.228038
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:57:56.143026
# Unit test for function make_lazy
def test_make_lazy():
    """Tests the make_lazy function"""
    make_lazy("_lazy_helper")
    _lazy_helper.called = 0
    import _lazy_helper
    # Check that _lazy_helper is only called once
    assert(_lazy_helper.called == 1)

# Generated at 2022-06-24 02:57:56.973275
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 02:57:57.809077
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:58:07.270289
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests for make_lazy
    """
    test_data = {}
    try:
        make_lazy("a.b.x.y.z")
        import a.b.x.y.z
        test_data["module"] = a.b.x.y.z
    # pylint: disable=broad-except
    except Exception as exception:
        # pylint: enable=broad-except
        test_data["exception_class"] = type(exception)

    make_lazy("a.b.x.y.z")
    import a.b.x.y.z
    test_data["module_2"] = a.b.x.y.z

# Generated at 2022-06-24 02:58:08.549897
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('value')
    assert(nl.value == 'value')


# Generated at 2022-06-24 02:58:14.419761
# Unit test for function make_lazy
def test_make_lazy():
    import package
    assert isinstance(package, _LazyModuleMarker)
    assert not isinstance(package, ModuleType)
    assert not hasattr(package, 'module')
    module = package.module
    assert isinstance(module, ModuleType)
    assert hasattr(module, 'foo')
    assert package.module.foo() == 'foo'

# Generated at 2022-06-24 02:58:16.165592
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    print(module)


# Generated at 2022-06-24 02:58:24.301512
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    assert sys.modules['sys'] != _LazyModuleMarker
    make_lazy('sys')
    assert sys.modules['sys'] == _LazyModuleMarker
    assert isinstance(sys.modules['sys'], _LazyModuleMarker)
    assert isinstance(sys.modules['sys'], ModuleType)
    assert sys.copyright



# Generated at 2022-06-24 02:58:30.133213
# Unit test for function make_lazy
def test_make_lazy():
    def test_import(module_name):
        """
        Import a module and check that it exists.
        """
        assert module_name not in sys.modules
        importlib.import_module(module_name)
        assert module_name in sys.modules

    # Ensure we can import the module after making it lazy.
    # Since the `module` object is a dictionary that is accessed
    # by this module, the import will cause the module to be
    # loaded.
    make_lazy('module')
    test_import('module')

    # This import requires importing a different module than
    # the default module.
    make_lazy('module')
    test_import('module.module')

    # Import an attribute of the module.
    make_lazy('module')
    assert not hasattr(module, 'mod')
    assert module

# Generated at 2022-06-24 02:58:34.264268
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    global a
    try:
        a
    except NameError:
        a = 1
    else:
        a = 2
    assert a == 1
    


# Generated at 2022-06-24 02:58:36.462859
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(int(1))
    assert isinstance(x, NonLocal)
    assert isinstance(x.value, int)
    assert x.value == 1


# Generated at 2022-06-24 02:58:42.830214
# Unit test for function make_lazy
def test_make_lazy():
    try:
        sys.modules['foo']
    except:
        pass

    make_lazy('foo')

    assert isinstance(sys.modules['foo'], _LazyModuleMarker)
    try:
        assert isinstance(sys.modules['foo'], ModuleType)
    except:
        assert False

    assert sys.modules['foo'].__mro__() == (sys.modules['foo'], ModuleType)



# Generated at 2022-06-24 02:58:48.864355
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert str(_LazyModuleMarker) == '_LazyModuleMarker'

# Unit tests for make_lazy()

# Generated at 2022-06-24 02:58:55.174971
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(10)
    assert nonlocal_value.value == 10

# Unit test to make sure LazyModule is not None

# Generated at 2022-06-24 02:58:56.187373
# Unit test for constructor of class NonLocal
def test_NonLocal():
    pass


# Generated at 2022-06-24 02:58:58.083708
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    result = isinstance(sys.modules[__name__], _LazyModuleMarker)
    assert result


# Generated at 2022-06-24 02:58:59.845433
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m=_LazyModuleMarker()
    assert isinstance(m, _LazyModuleMarker)
    assert m is not None


# Generated at 2022-06-24 02:59:01.955265
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl=NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-24 02:59:04.481798
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('Hello')
    assert(nl.value == 'Hello')


# Generated at 2022-06-24 02:59:07.461089
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    if obj:
        print("Test result: success")
    else:
        print("Test result: failure")
    return


# Generated at 2022-06-24 02:59:08.077155
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(ModuleType, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:09.431930
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(57)
    assert x.value == 57

# Generated at 2022-06-24 02:59:19.920051
# Unit test for function make_lazy
def test_make_lazy():
    import mock

    # Mock the sys.modules
    with mock.patch('sys.modules', {}) as sys_modules:
        # Mock the import to raise an ImportError
        with mock.patch('__builtin__.__import__', side_effect=ImportError('No module named test_lazy')) as import_:
            make_lazy('test_lazy')
            test_lazy = sys.modules['test_lazy']

            # test importing
            assert import_.call_count == 0
            assert isinstance(test_lazy, _LazyModuleMarker)

            # test the first import attempt
            assert test_lazy.test_attr1 is None
            assert import_.call_count == 1
            assert isinstance(test_lazy, ModuleType)

            # test second import attempt
            assert test_lazy.test

# Generated at 2022-06-24 02:59:25.294679
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    if isinstance(m,_LazyModuleMarker):
        pass
    else:
        raise Exception("test__LazyModuleMarker failed")


# Generated at 2022-06-24 02:59:31.847127
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the `make_lazy` function decorator works as expected.
    """
    import django
    make_lazy('django')
    assert isinstance(django, _LazyModuleMarker)
    assert isinstance(django, ModuleType)
    assert not hasattr(django, '__version__')
    django.__version__
    assert hasattr(django, '__version__')
    assert isinstance(django, ModuleType)
    assert not isinstance(django, _LazyModuleMarker)
    assert django.__version__ == '1.4-dev'

if __name__ == "__main__":
    import nose
    nose.main()

# Generated at 2022-06-24 02:59:39.680142
# Unit test for function make_lazy
def test_make_lazy():
    """
    Simple test to verify the make_lazy function.
    """
    lazy_mod_name = '__lazy_mod__'
    sys.modules[lazy_mod_name] = None
    make_lazy(lazy_mod_name)

    assert lazy_mod_name in sys.modules
    assert type(sys.modules[lazy_mod_name]) is _LazyModuleMarker

    # If we access an attribute, it should import it
    assert sys.modules[lazy_mod_name].__file__ is not None
    assert type(sys.modules[lazy_mod_name]) is ModuleType

    # Clean up
    del sys.modules[lazy_mod_name]



# Generated at 2022-06-24 02:59:46.580541
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        def __getattribute__(self, attr):
            if "count" not in self.__dict__:
                self.count = 0
            self.count += 1
            return super(A, self).__getattribute__(attr)

    a = A()
    make_lazy("a.b.c")
    a.b.c
    a.b.c
    a.b.c
    assert a.count == 1

# Generated at 2022-06-24 02:59:51.771975
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        m = _LazyModuleMarker()
        print("\033[6;30;42m%s\033[m %s" % ("Passed", "test__LazyModuleMarker()"))
    except Exception as e:
        print("\033[6;30;41m%s\033[m %s" % ("Failed", "test__LazyModuleMarker()"))


# Generated at 2022-06-24 02:59:53.007930
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)
    assert n.value == 3


# Generated at 2022-06-24 02:59:54.602762
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('test')
    assert(nl.value == 'test')


# Generated at 2022-06-24 02:59:59.067887
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test constructor of class _LazyModuleMarker
    """
    a_lazy_module = _LazyModuleMarker()
    try:
        assert isinstance(a_lazy_module, _LazyModuleMarker)
    except AssertionError as e:
        print("Failed to create a _LazyModuleMarker instance")
        raise(e)


# Generated at 2022-06-24 03:00:00.200266
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None
    a.value = 5
    assert a.value == 5


# Generated at 2022-06-24 03:00:01.671423
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = 1
    test = NonLocal(value)
    assert test.value == value

# Generated at 2022-06-24 03:00:03.648798
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:05.547556
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    type = _LazyModuleMarker().__class__.__name__
    assert type == '_LazyModuleMarker', "Type should be _LazyModuleMarker but got %s"%type 
    assert isinstance(_LazyModuleMarker(),_LazyModuleMarker), "Should be instance of _LazyModuleMarker"


# Generated at 2022-06-24 03:00:06.908232
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 03:00:08.818565
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n2 = NonLocal(2)
    assert n2.value == 2, "%s != 2" % n2.value


# Generated at 2022-06-24 03:00:16.733958
# Unit test for function make_lazy
def test_make_lazy():
    # Remove the module if it's in the modules.
    module_path = 'test_imports.make_lazy_test'
    if module_path in sys.modules:
        del sys.modules[module_path]

    # Check the module isn't in the modules.
    assert module_path not in sys.modules

    # Make the module and check the module is in the modules.
    make_lazy(module_path)
    assert module_path in sys.modules

    # Retrieve the module and validate it is a `LazyModule` not a Module.
    module = sys.modules[module_path]
    assert not isinstance(module, ModuleType)
    assert isinstance(module, _LazyModuleMarker)

    # Check that `module` has the magic attribute we want.
    assert module.WHOA == 'a'



# Generated at 2022-06-24 03:00:19.260496
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from subprocess import (
        CalledProcessError
    )

    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

    assert hasattr(CalledProcessError, 'returncode')


# Generated at 2022-06-24 03:00:25.289949
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that the function `make_lazy` works.
    """
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    import os
    import sys

    with TemporaryDirectory() as tmp_dir:
        # Copy the file to the test folder
        copyfile(os.path.join(os.path.dirname(__file__),
                              'test_slow_module.py'),
                              os.path.join(tmp_dir, 'test_module.py'))

        # Add the test folder to sys.path
        sys.path.insert(0, tmp_dir)

        # Add the module to the lazy list
        make_lazy('test_module')

        # Import the module (should be safe now)
        import test_module

        # Test that the module was lazily loaded
        assert test_

# Generated at 2022-06-24 03:00:34.991114
# Unit test for function make_lazy
def test_make_lazy():
    def func_a():
        """
        A function that returns True
        """
        return True

    def func_b():
        """
        A function that returns False
        """
        return False

    import sys
    import sys_module_lazy

    # Make module lazily loaded
    make_lazy('sys_module_lazy')

    # Make sure module is not loaded yet
    assert not hasattr(sys_module_lazy, 'func_a')
    assert not hasattr(sys_module_lazy, 'func_b')
    assert not hasattr(sys_module_lazy, '__name__')
    assert not hasattr(sys_module_lazy, '__doc__')
    assert not hasattr(sys_module_lazy, '__file__')

# Generated at 2022-06-24 03:00:42.170728
# Unit test for function make_lazy
def test_make_lazy():
    """Runs unit tests for make_lazy

    Note: This is intended to be invoked from the command line like this:

        $ python -m edx_lms_extensions.lazy_module test_make_lazy

    """
    import unittest
    import sys

    class TestMakeLazy(unittest.TestCase):

        def setUp(self):
            # Create a fake module that is lazily loaded
            # Attributes of the module are resolved dynamically
            import copy
            self.old_sys_modules = copy.copy(sys.modules)
            self.lazy_module_name = "_temp_lazy_module"
            sys.modules[self.lazy_module_name] = None
            make_lazy(self.lazy_module_name)


# Generated at 2022-06-24 03:00:43.175298
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3

# Generated at 2022-06-24 03:00:44.599698
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  lazy_module_marker = _LazyModuleMarker()
  assert lazy_module_marker != None


# Generated at 2022-06-24 03:00:45.662112
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    temp = _LazyModuleMarker()


# Generated at 2022-06-24 03:00:47.331494
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests if the _LazyModuleMarker works
    """
    assert _LazyModuleMarker()


# Generated at 2022-06-24 03:00:52.363934
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test whether this function succeeds in what it should do.
    """
    class newcls(_LazyModuleMarker):
        pass
    obj = newcls()
    assert(isinstance(obj, ModuleType))
    assert(isinstance(obj, _LazyModuleMarker))


# Generated at 2022-06-24 03:00:54.007382
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _lmm = _LazyModuleMarker()


# Generated at 2022-06-24 03:01:04.438640
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x, y = NonLocal(0), NonLocal(0)
    def test():
        x.value = 1
        y.value = 1
    test()
    assert x.value == y.value == 1


if sys.version_info[0] >= 3:
    def exec_in(code, globs, locs):
        """
        Python 3's exec does not support passing in both globals and locals.
        """
        exec(code, globs)


else:
    def exec_in(code, globs, locs):
        """
        Helper function to run an exec statement in a given globals and locals
        """

# Generated at 2022-06-24 03:01:07.255139
# Unit test for constructor of class NonLocal
def test_NonLocal():
    r = NonLocal(1)

    assert r.value == 1
    r.value = 10
    assert r.value == 10

# Generated at 2022-06-24 03:01:14.884380
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure the module is not loaded until an attribute is requested.
    """
    # Given
    sys.modules['foo'] = NonLocal(None)
    foo = sys.modules['foo']

    # When
    make_lazy('foo')

    # Then
    assert isinstance(foo, ModuleType)
    assert hasattr(foo, '__mro__')
    assert not hasattr(foo, '__path__')
    assert foo is not sys.modules['foo']

    # When given an attribute
    bar = foo.bar

    # Then
    assert bar is sys.modules['foo'].bar

# Generated at 2022-06-24 03:01:20.239073
# Unit test for function make_lazy
def test_make_lazy():
    import unittest

    import django
    make_lazy('django')

    assert isinstance(sys.modules['django'], _LazyModuleMarker)
    assert isinstance(django, _LazyModuleMarker)

    class TestMakeLazy(unittest.TestCase):
        def test_basic(self):
            assert django.get_version() is not None

# Generated at 2022-06-24 03:01:21.166758
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:01:30.772803
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    module_path = 'tests.mod'

    # Make sure our test module is not already imported.
    sys.modules.pop('tests.mod', None)
    assert sys.modules.get('tests.mod') is None

    # We need to put a package in our import path.
    sys.path.append('tests')

    # Mark it as a lazy module
    make_lazy(module_path)

    # Assert that it is in sys.modules
    assert sys.modules.get('tests.mod') is not None

    # Assert the module is lazy.
    assert isinstance(sys.modules.get('tests.mod'), _LazyModuleMarker)

    # Called an attribute from the lazy module.
    sys.modules.get('tests.mod').attr_in_mod

    # Assert that it is no longer

# Generated at 2022-06-24 03:01:34.062587
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Constructor unit test of class _LazyModuleMarker")
    assert _LazyModuleMarker()



# Generated at 2022-06-24 03:01:35.526293
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object), \
        "To inherits from object"


# Generated at 2022-06-24 03:01:41.134114
# Unit test for function make_lazy
def test_make_lazy():  # TODO move to a unit test file
    """
    Basic unit test for the make_lazy function.
    """

    # Reset sys_modules and LazyModule
    sys.modules = {}
    LazyModule = _LazyModuleMarker
    LazyModule.__mro__ = (LazyModule, ModuleType)
    LazyModule.__getattribute__ = lambda self, attr: getattr(sys.modules[module_path], attr)

    LazyModule.__hash__ = ModuleType.__hash__
    LazyModule.__eq__ = ModuleType.__eq__
    LazyModule.__ne__ = ModuleType.__ne__

    # Create lazy module
    module_path = 'test_make_lazy_module'
    make_lazy(module_path)

    assert module_path in sys.modules

# Generated at 2022-06-24 03:01:52.184155
# Unit test for function make_lazy
def test_make_lazy():
    '''
        >>> import sys
        >>> import __builtin__
        >>> import nonlocal_function
        >>> make_lazy("nonlocal_function")
        >>> nonlocal_function.__name__
        'nonlocal_function'
        >>> nonlocal_function.__doc__
        'Module docstring \\n\\n'
        >>> nonlocal_function.__file__
        '/home/mike/src/python/2.7/nonlocal_function.py'
        >>> nonlocal_function.__dict__['__doc__']
        'Module docstring \\n\\n'
        >>> nonlocal_function.__dict__.has_key('__file__')
        False
    '''


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:01:55.894113
# Unit test for function make_lazy
def test_make_lazy():
    # Import to trigger lazy_imports
    import nonlocalize.lazy_imports as lazy_test

    # Access the module to trigger nonlocal state
    print(lazy_test.__name__)

# Generated at 2022-06-24 03:01:57.358401
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(1)
    assert(test.value == 1)

# Generated at 2022-06-24 03:02:04.277304
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 03:02:09.169737
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests our lazy loader implementation.
    """
    module_name = 'test_module'
    module_path = 'tests.test_module'

    class TestModule(object):
        """ A class to use as our 'real' test module """

        def __init__(self, num):
            self.num = num

    module_dict = TestModule.__dict__.copy()

    module = sys.modules[module_path] = TestModule(1)

    # Test our helper function
    make_lazy(module_path)

    # Test to make sure that our module has been lazified (e.g. a lazy class
    # should be returned.
    assert isinstance(module, _LazyModuleMarker)

    # Test to make sure that our module still has all the attributes of the
    # original class

# Generated at 2022-06-24 03:02:10.994828
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 03:02:15.534310
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    # public var value
    assert a.value == 1



# Generated at 2022-06-24 03:02:22.141475
# Unit test for function make_lazy
def test_make_lazy():
    #This test demonstrates the make_lazy function by
    #importing the module dynamically. This module does not need to exist
    #on the path, and should not exist when the test is run.
    import dynamic_import_test
    from nose.tools import assert_false, assert_true
    assert_false(isinstance(dynamic_import_test, _LazyModuleMarker))
    del sys.modules['dynamic_import_test']
    make_lazy('dynamic_import_test')
    assert_true(isinstance(dynamic_import_test, _LazyModuleMarker))
    assert_true(dynamic_import_test.__doc__)
    del sys.modules['dynamic_import_test']
    make_lazy('dynamic_import_test')

# Generated at 2022-06-24 03:02:25.456400
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, _LazyModuleMarker)
    assert isinstance(LazyModule('test'), _LazyModuleMarker)


# Generated at 2022-06-24 03:02:34.720573
# Unit test for function make_lazy
def test_make_lazy():
    try:
        module_path = os.path.dirname(os.path.abspath(__file__))
        mod_exists = os.path.isfile(os.path.join(module_path, "lazy_module.py"))
        assert mod_exists

        if mod_exists:
            make_lazy(module_path + '.lazy_module')
            assert sys.modules[module_path + '.lazy_module'].__name__ == module_path + '.lazy_module'
            assert sys.modules[module_path + '.lazy_module'].foo == 'bar'

    finally:
        sys.modules.pop(module_path + '.lazy_module', None)

# Generated at 2022-06-24 03:02:44.640727
# Unit test for function make_lazy
def test_make_lazy():
    import pickle
    module_path = 'make_lazy.test_make_lazy'
    make_lazy(module_path)
    test_module = sys.modules[module_path]
    assert not isinstance(test_module, ModuleType)
    assert isinstance(test_module, _LazyModuleMarker)
    assert module_path not in sys.modules

    def get_module_attributes(test_module):
        return [ mod_attr for mod_attr in dir(test_module) if not mod_attr.startswith('_')]

    assert len(get_module_attributes(test_module)) == 0
    assert module_path in sys.modules

    # the module should not be pickleable

# Generated at 2022-06-24 03:02:47.739438
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 03:02:55.283289
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    #
    # Test that lazy import is possible.
    #
    old = True

    try:
        del sys.modules['make_lazy_test']
    except KeyError:
        old = False

    module_path = 'make_lazy_test'

    assert module_path not in sys.modules
    make_lazy(module_path)
    assert module_path in sys.modules
    assert not old

    try:
        old_module = sys.modules[module_path]
    except KeyError:
        assert False, 'Could not find python module for make_lazy_test'

    sys.modules[module_path] = 'SERTEST'
    assert sys.modules[module_path] == 'SERTEST'

    #
    # Test that if the module was previously imported,

# Generated at 2022-06-24 03:02:58.548120
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if not sys.version_info[0] > 2:
        # NonLocal class is only for python 3
        return

    nl = NonLocal(4)
    assert nl.value == 4



# Generated at 2022-06-24 03:02:59.648719
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

# Generated at 2022-06-24 03:03:10.030521
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the function `make_lazy`.
    """
    # Create a dummy `test_lazy_module` that raises an exception
    # if `import test_lazy_module` is called in this module.
    make_lazy('test_lazy_module')
    assert test_lazy_module.__class__.__name__ == 'LazyModule'
    # Make sure that the module isn't actually imported.
    # It will raise an exception if `import test_lazy_module` is
    # called - otherwise it will return True.
    _is_lazy =  True
    try:
        import test_lazy_module
    except ImportError:
        _is_lazy = False
    assert _is_lazy == True

# Generated at 2022-06-24 03:03:19.374667
# Unit test for function make_lazy
def test_make_lazy():
    _modules = sys.modules

    _module_name = 'thisisaunitest'
    _module = _modules[_module_name] = ModuleType(_module_name)
    _module.hello = 'world'

    def test_lazy_import():
        make_lazy(_module_name)
        m = __import__(_module_name)
        assert m.hello == 'world'
        assert isinstance(m, _LazyModuleMarker)

    test_lazy_import()

    # Clean up.
    del _modules[_module_name]
    del _module
    del _module_name

del test_make_lazy

# Generated at 2022-06-24 03:03:21.751511
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)
    assert n.value == 3
    assert NonLocal(4).value == 4

# Generated at 2022-06-24 03:03:24.063518
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    value = NonLocal('test')
    assert value.value == 'test'
    assert sys.modules[__name__] == 'test_NonLocal'


# Generated at 2022-06-24 03:03:25.224062
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(100)
    assert x.value == 100

