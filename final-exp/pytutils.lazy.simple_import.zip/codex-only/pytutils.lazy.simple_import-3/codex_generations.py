

# Generated at 2022-06-24 02:53:24.965925
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 02:53:28.162207
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    #takes no arguments as input
    #returns object
    
    assert isinstance(_LazyModuleMarker(), object)
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)




# Generated at 2022-06-24 02:53:38.428281
# Unit test for function make_lazy
def test_make_lazy():

    sys.modules["lazy_mod"] = ModuleType("lazy_mod")

    make_lazy("lazy_mod")

    import lazy_mod
    assert sys.modules["lazy_mod"].__class__.__name__ == "LazyModule"
    assert isinstance(lazy_mod, ModuleType)
    assert not hasattr(lazy_mod, "__getattribute__")
    assert not hasattr(lazy_mod, "__mro__")
    assert isinstance(lazy_mod, _LazyModuleMarker)

    assert hasattr(lazy_mod, "__file__")
    assert not hasattr(lazy_mod, "__file__")
    del sys.modules["lazy_mod"]

# Generated at 2022-06-24 02:53:39.590277
# Unit test for function make_lazy
def test_make_lazy():
    import example
    make_lazy('example')
    assert 'example' not in sys.modules

# Generated at 2022-06-24 02:53:51.552793
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_data = (('foo', 1), ('bar', 2))
    class IsATest(object):
        """
        For testing isinstance()
        """
        foo = 1
        bar = 2

    # __mro__ here is required to fool the isinstance test.
    class LazyModuleIsA(_LazyModuleMarker):
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            return (LazyModuleIsA, IsATest)
    assert LazyModuleIsA()
    assert isinstance(LazyModuleIsA(), IsATest)
    for attr, value in test_data:
        assert getattr(LazyModuleIsA(), attr) == value
    assert issubclass(LazyModuleIsA, IsATest)

    #

# Generated at 2022-06-24 02:53:53.386330
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal('test')
    assert nonlocal_obj.value == 'test'


# Generated at 2022-06-24 02:53:55.855196
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None

    b = NonLocal(1)
    assert b.value == 1

# Generated at 2022-06-24 02:54:02.880219
# Unit test for function make_lazy
def test_make_lazy():
    test_path = 'xblock.test.test_lazy_import'
    test_module = sys.modules[test_path]

    make_lazy(test_path)

    lazy_module = sys.modules[test_path]
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert test_module not in sys.modules.values()

    # Accessing lazy module attributes after the import.
    assert lazy_module.__name__ == test_module.__name__
    assert lazy_module.__mro__ == test_module.__mro__
    assert lazy_module.lazy_string == test_module.lazy_string

    # Accessing them multiple times should still works fine.
    assert lazy_module.__name__ == test_module.__name__
    assert lazy_module.__m

# Generated at 2022-06-24 02:54:07.631318
# Unit test for function make_lazy
def test_make_lazy():
    import struct
    # This test relies on there being a package with a submodule
    # with an attribute/function of the same name.
    make_lazy('struct')
    assert isinstance(struct, _LazyModuleMarker)
    # Accessing the module's attribute should import the module.
    assert struct.pack('d', 1.1) == '\x01\x1f\x85\xebQ\xb8\x1e\t@'

# Generated at 2022-06-24 02:54:12.909150
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure the function works and can be reversed
    make_lazy('re')
    assert isinstance(re, _LazyModuleMarker)
    assert re.compile('x*')
    assert not isinstance(re, _LazyModuleMarker)
    make_lazy('re')
    assert isinstance(re, _LazyModuleMarker)
    make_lazy('re')
    assert isinstance(re, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:14.398657
# Unit test for constructor of class NonLocal
def test_NonLocal():
    pass


# Generated at 2022-06-24 02:54:18.396305
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    # __init__ function sets value of the object to the value provided
    assert (x.value == 10)
    x.value = 20
    assert (x.value == 20)  # Value of object can be changed


# Generated at 2022-06-24 02:54:19.975040
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(1)
    assert nonlocal_.value == 1
    nonlocal_.value = 2
    assert nonlocal_.value == 2


# Generated at 2022-06-24 02:54:27.211752
# Unit test for function make_lazy
def test_make_lazy():
    # Create a few test modules
    import tempfile

    fd, module_file = tempfile.mkstemp(suffix='.py')
    with open(module_file, 'w') as f:
        f.write('test_module_constant = True\n')

    import os
    module_name = os.path.splitext(os.path.basename(module_file))[0]
    test_module = imp.load_source(module_name, module_file)


# Generated at 2022-06-24 02:54:35.446204
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    old_modules = dict(sys.modules)
    try:
        import django.conf
        assert 'django' in sys.modules
        assert 'django.conf' in sys.modules
        make_lazy('django')
        assert 'django' in sys.modules
        assert 'django.conf' not in sys.modules
        import django.conf
        assert 'django.conf' in sys.modules
        assert 'django.conf' not in old_modules
    finally:
        sys.modules = old_modules



# Generated at 2022-06-24 02:54:37.999077
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 'hello'
    assert nl.value == 'hello'
    print('constructor of class NonLocal has passed the unit test.')



# Generated at 2022-06-24 02:54:42.088015
# Unit test for constructor of class NonLocal
def test_NonLocal():

    def func():
        nl = NonLocal('test')
        nl.value = 'test2'
        assert nl.value == 'test2'

    func()

# Generated at 2022-06-24 02:54:50.641551
# Unit test for function make_lazy
def test_make_lazy():
    import socket
    import sys
    import types
    import platform

    is_py3 = sys.version_info >= (3, 0)
    if is_py3:
        return

    make_lazy('socket')

    assert sys.modules['socket'] != socket
    assert isinstance(sys.modules['socket'], types.ModuleType)
    assert sys.modules['socket'] != socket
    assert sys.modules['socket'] != platform
    assert sys.modules['socket'] == sys.modules['socket']
    assert sys.modules['socket'] != sys.modules['platform']
    assert str(sys.modules['socket']) == '<LazyModule socket>'
    assert str(sys.modules['socket']).startswith('<LazyModule socket')
    assert not hasattr(sys.modules['socket'], 'AF_INET')

# Generated at 2022-06-24 02:54:52.666456
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 5
    assert nl.value == 5


# Generated at 2022-06-24 02:55:02.926282
# Unit test for function make_lazy
def test_make_lazy():
    def check_lazy():
        # check that the module isn't imported
        assert module.__name__ not in sys.modules, 'module already imported'
        # check that we can still create a lazy object
        assert isinstance(module.module, _LazyModuleMarker), 'import failed'
        # check the the module path is correct
        assert module.module.__name__ == module.module_path, 'module path incorrectly set'
        # trigger the import, and re-check the checks
        assert module.module.__name__ == module.module_path, 'module path correctly set'
        assert not isinstance(module.module, _LazyModuleMarker), 'import succeeded'
        assert module.module.__name__ in sys.modules, 'module still not imported'

    from importlib import import_module

# Generated at 2022-06-24 02:55:05.522130
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test 1
    assert(_LazyModuleMarker() is not None)
    # Test 2
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))


# Generated at 2022-06-24 02:55:07.005523
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 02:55:08.520372
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()
    assert lazy is not None


# Unit Test for make_lazy

# Generated at 2022-06-24 02:55:11.982028
# Unit test for function make_lazy
def test_make_lazy():
    """
    >>> import sys, re
    >>> make_lazy('re')

    >>> isinstance(sys.modules['re'], _LazyModuleMarker)
    True
    >>> isinstance(sys.modules['re'], re.__class__)
    True
    >>> isinstance(sys.modules['re'], type)
    True
    """

# Generated at 2022-06-24 02:55:19.093125
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import eq_
    from contextlib import nested
    from mock import patch

    with nested(patch.object(sys, 'modules', {}),
                patch.object(sys, 'modules', {})) as (sys_modules, module):
        make_lazy('foo.bar')
        lm = module['foo.bar']
        assert isinstance(lm, _LazyModuleMarker)
        eq_(lm.__mro__(), (_LazyModuleMarker, ModuleType))

# Generated at 2022-06-24 02:55:21.552886
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3


# Generated at 2022-06-24 02:55:23.376281
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert False, "Tests for this class not yet implemented"



# Generated at 2022-06-24 02:55:28.209430
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert isinstance(test_marker, _LazyModuleMarker) == True


# Generated at 2022-06-24 02:55:30.949445
# Unit test for function make_lazy

# Generated at 2022-06-24 02:55:35.021027
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lzm = _LazyModuleMarker()
    assert isinstance(lzm, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:35.600993
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5


# Generated at 2022-06-24 02:55:41.725230
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Not a real unit test, but we want to do an actual test.
    '''
    import redis
    assert redis
    import salt.utils
    assert salt.utils
    assert isinstance(redis, _LazyModuleMarker)
    assert isinstance(salt.utils, _LazyModuleMarker)
    assert not isinstance(object, _LazyModuleMarker)
    import salt
    assert not isinstance(salt, _LazyModuleMarker)



# Generated at 2022-06-24 02:55:43.469946
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModuleMarker = _LazyModuleMarker()
    assert isinstance(lazyModuleMarker, object)



# Generated at 2022-06-24 02:55:47.051328
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # create an instance of NonLocal
    temp = NonLocal(3)
    assert isinstance(temp, NonLocal)


# Generated at 2022-06-24 02:55:49.267405
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_object = NonLocal(55)

# Generated at 2022-06-24 02:55:56.914175
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod1 = _LazyModuleMarker()
    mod2 = _LazyModuleMarker()
    assert(mod1 == mod2)
    assert(mod2 == mod1)

    assert(not (mod1 != mod2))
    assert(not (mod2 != mod1))

    assert(not (mod1 > mod2))
    assert(not (mod1 < mod2))
    assert(mod1 <= mod2)
    assert(mod1 >= mod2)



# Generated at 2022-06-24 02:56:07.170471
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_path = 'tests.base.test_lazy_import.test_make_lazy.my_lazy_module'
    make_lazy(lazy_module_path)

    # LazyModule should be created from make_lazy
    lazy_module = sys.modules[lazy_module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # Accessing an attribute on lazy module should import it
    assert lazy_module.__name__ == 'tests.base.test_lazy_import.test_make_lazy.my_lazy_module'

    # Accessing an attribute on lazy module should not create a new module
    lazy_module2 = sys.modules[lazy_module_path]
    assert lazy_module is lazy_module2

# Generated at 2022-06-24 02:56:14.113884
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
    # Test whether MRO added correctly
    assert _LazyModuleMarker.__mro__ == (_LazyModuleMarker, object)
    # Test whether NonLocal class acts as nonlocal keyword in Python 2
    data = NonLocal(3)
    assert data.value == 3


# Generated at 2022-06-24 02:56:17.145916
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class B(object):
        def __init__(self, val):
            self.val = val

    a = NonLocal(B(1))
    assert a.value == B(1)

# Generated at 2022-06-24 02:56:27.485018
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    import re
    import os
    import sys

    module_name = 'test_make_lazy_module'
    module_path = 'xblock.test.test_make_lazy'
    reload_module = lambda: reload(sys.modules[module_path])

    # Test that lazy module import is working
    make_lazy(module_path)
    module = __import__(module_name)
    assert not hasattr(module, 'name')
    assert module.NAME == 'lazy'
    assert isinstance(module, _LazyModuleMarker)

    # Test that module is still lazy after a reload
    reload_module()
    assert isinstance(module, _LazyModuleMarker)

    # Test that module is lazy after a second reload
    reload_

# Generated at 2022-06-24 02:56:29.529659
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2


# Generated at 2022-06-24 02:56:40.533864
# Unit test for function make_lazy
def test_make_lazy():
    # import test_make_lazy_module to store the module in sys.modules
    import test_make_lazy_module

    module_path = 'test_make_lazy_module'

    # mark the module as lazy after it has been imported
    make_lazy(module_path)

    # delete the reference to the module in this namespace
    del test_make_lazy_module
    import gc
    gc.collect()

    # create a reference to the lazy module and assert that it is a LazyModule
    import test_make_lazy_module
    assert isinstance(test_make_lazy_module, _LazyModuleMarker)

    # access the test_attr on the module and assert that the value is correct
    assert test_make_lazy_module.test_attr == 3

    # the module should now

# Generated at 2022-06-24 02:56:42.092354
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:56:43.325375
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(42)
    assert n.value == 42



# Generated at 2022-06-24 02:56:45.734043
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    tmp = _LazyModuleMarker()
    assert tmp is not None


# Generated at 2022-06-24 02:56:46.834672
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 02:56:54.510104
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test nonlocal keyword in Python 2
    x = 5
    def inner():
        nonlocal x
        x = x + 1
        return x
    assert inner() == 6

    # Test simulated nonlocal keyword in Python 2 with NonLocal class
    y = 5

# Generated at 2022-06-24 02:56:57.776748
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:57:04.196064
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # raises exception test
    try:
        _LazyModuleMarker()
    except TypeError as e:
        assert(str(e) == "Can't instantiate abstract class _LazyModuleMarker with abstract methods __init__")
    except Exception as e:
        assert(False) # raise unexpected exception
    else:
        assert(False) # unexpected, no exception raised



# Generated at 2022-06-24 02:57:06.573200
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import doctest
    try:
        doctest.testmod(verbose=True)
    except:
        print("Failed")



# Generated at 2022-06-24 02:57:14.483689
# Unit test for function make_lazy
def test_make_lazy():
    """
    Makes sure the implementation details of make_lazy are correct.
    We can test this because of the implementation details.
    """

    # Note: we also test the ModuleType isn't in the __mro__.
    assert issubclass(make_lazy("foo"), _LazyModuleMarker)
    assert not issubclass(make_lazy("foo"), ModuleType)


# Insert the core lazily.
# This will prevent a circular import.
make_lazy("sentinel.core.client")

# Insert all of the lazy modules.
for module in (
    "sentinel.daemon",
    "sentinel.logger",
    "sentinel.utils",
):
    make_lazy(module)

# Generated at 2022-06-24 02:57:16.300582
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1
    x = NonLocal('a')
    assert x.value == 'a'


# Generated at 2022-06-24 02:57:18.878085
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'somemodule'
    make_lazy(module_path)
    assert not hasattr(sys.modules[module_path], '__mro__')
    assert issubclass(sys.modules[module_path], _LazyModuleMarker)

# Generated at 2022-06-24 02:57:26.218277
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import tempfile
    import unittest

    class TestMakeLazy(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.path = os.path.join(self.tmpdir, 'unittest_module.py')

# Generated at 2022-06-24 02:57:28.544579
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))
    assert(isinstance(LazyModule(), _LazyModuleMarker))
    assert(isinstance(LazyModule(), ModuleType))

test__LazyModuleMarker()



# Generated at 2022-06-24 02:57:30.818131
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print('Testing _LazyModuleMarker constructor')
    obj = _LazyModuleMarker()
    print(obj)


# Generated at 2022-06-24 02:57:39.783505
# Unit test for function make_lazy
def test_make_lazy():
    # Unit test for function make_lazy
    def assert_is_lazy(mod):
        """
        `mod` should be a lazy module
        """
        assert isinstance(mod, _LazyModuleMarker)
        assert mod.__class__.__name__ == 'LazyModule'

    assert_is_lazy(foo)

    # The module should only get instantiated after a member gets accessed.
    with mock.patch('__builtin__.__import__') as import_:
        assert foo.bar is None
        assert import_.call_count == 1
        assert import_.call_args[0] == ('foo',)
        assert import_.call_args[1] == {'fromlist': ['bar']}

        # Once imported through the lazy object, it should not attempt to
        # reimport the module
        assert foo

# Generated at 2022-06-24 02:57:42.248476
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert x is not None
    print ("test__LazyModuleMarker success")


# Generated at 2022-06-24 02:57:48.273540
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('cStringIO')
    import cStringIO  # import sphinx-doc/sphinx/ext/graphviz.py
    assert isinstance(cStringIO, _LazyModuleMarker)
    # The following will cause the module being actually loaded
    assert 'StringIO' in cStringIO.__dict__
    import cStringIO
    assert not isinstance(cStringIO, _LazyModuleMarker)
    assert 'StringIO' in cStringIO.__dict__

# Generated at 2022-06-24 02:57:51.854085
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5


# Generated at 2022-06-24 02:58:00.177799
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["fake_module"] = None
    try:
        make_lazy("fake_module")
        fake_module = sys.modules["fake_module"]
        assert isinstance(fake_module, _LazyModuleMarker)
        assert fake_module.__name__ == "fake_module"
        with pytest.raises(AttributeError) as excinfo:
            fake_module.some_attribute
        assert 'fake_module' in excinfo.exconly()
        assert 'some_attribute' not in excinfo.exconly()
        assert 'ImportError' in excinfo.exconly()
    finally:
        del sys.modules["fake_module"]

# Generated at 2022-06-24 02:58:03.525681
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test _LazyModuleMarker
    """
    # TODO: Implement
    print("test__LazyModuleMarker has not been implemented")

# Generated at 2022-06-24 02:58:04.793901
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3


# Generated at 2022-06-24 02:58:11.848200
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function
    """
    # First we need to add a fake module to the sys_modules
    sys_modules = sys.modules
    sys_modules['foo.bar'] = sys_modules['__builtins__']

    # Mark the module as lazy
    make_lazy('foo.bar')

    # Assert that the module is now lazy
    assert isinstance(sys_modules['foo.bar'], _LazyModuleMarker)

    # Assert that calling isinstance will work as expected
    assert isinstance(sys_modules['foo.bar'], ModuleType)

    # The module must still be lazy at this point
    assert isinstance(sys_modules['foo.bar'], _LazyModuleMarker)

    # Assert that a method on the module will actually import it

# Generated at 2022-06-24 02:58:13.291738
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert a is not None


# Generated at 2022-06-24 02:58:14.603943
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-24 02:58:25.599117
# Unit test for function make_lazy
def test_make_lazy():
    """Test make_lazy by making a real module,
    a fake module, and then swapping them.
    """
    module_path = '__import_hack.make_lazy'
    module = NonLocal(None)

    class RealModule(object):
        """Module with useful attributes."""
        attr1 = True
        attr2 = True

        def __getattribute__(self, attr):
            """Overriding getattribute so that we can spy on the module."""
            if module.value is None:
                module.value = RealModule()

            return getattr(module.value, attr)

    # replace the module in sys.modules with a module consisting
    # of a fake class so that we can test the lazy module.
    sys.modules[module_path] = RealModule()

    # now make it lazy
   

# Generated at 2022-06-24 02:58:31.892894
# Unit test for function make_lazy
def test_make_lazy():
    def actual_func():
        x = 0
        sys.modules['foo'] = NonLocal(x)
        foo = __import__('foo')
        assert foo.value == 0
        x = 1
        assert foo.value == 1

    mock_func = Mock(wraps=actual_func)
    mock_func()

# Generated at 2022-06-24 02:58:37.694976
# Unit test for function make_lazy
def test_make_lazy():
    x = module = None
    old_sys_modules = sys.modules.copy()

    try:
        make_lazy('lazy_test_module')
        module = __import__('lazy_test_module')
        assert module is not None
        assert isinstance(module, _LazyModuleMarker)

        x = module.x
        assert x is not None
        assert isinstance(module, ModuleType)
    finally:
        # reset the module
        sys.modules.clear()
        sys.modules.update(old_sys_modules)



# Generated at 2022-06-24 02:58:44.568197
# Unit test for function make_lazy
def test_make_lazy():
    """
    >>> import sys
    >>> # Create a new module tree to ensure nothing
    >>> # is loaded before we load it
    >>> make_lazy('test_lazy_module')
    >>> isinstance(sys.modules['test_lazy_module'], _LazyModuleMarker)
    True
    >>> import test_lazy_module
    >>> isinstance(sys.modules['test_lazy_module'], _LazyModuleMarker)
    False
    """
    pass

# Generated at 2022-06-24 02:58:51.543088
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can import a lazy module.
    """
    sys.modules['tests.test_lazy'] = None

    # Mark this module as lazy.
    make_lazy('tests.test_lazy')

    from tests.test_lazy import __version__

    assert sys.modules['tests.test_lazy'].__version__ == __version__

# Generated at 2022-06-24 02:58:55.184072
# Unit test for constructor of class NonLocal
def test_NonLocal():
    target = NonLocal("test")
    assert target.value == "test"


# Generated at 2022-06-24 02:58:58.474484
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class_var = _LazyModuleMarker()
    assert class_var.__mro__()[1] == ModuleType
    assert class_var.__mro__()[0] == _LazyModuleMarker

# Generated at 2022-06-24 02:59:09.600502
# Unit test for function make_lazy
def test_make_lazy():
    import test.test_tools
    import test.test_weakref
    test.test_tools
    test.test_weakref
    reload(test)
    test.test_tools
    test.test_weakref
    assert test.__file__
    assert test.test_tools.__file__
    assert test.test_weakref.__file__
    assert 'test.test_tools' not in sys.modules
    assert 'test.test_weakref' not in sys.modules
    sys.modules['test.test_tools'] = None
    sys.modules['test.test_weakref'] = None
    reload(test)
    print(test.__file__)
    assert test.__file__
    assert test.test_tools.__file__
    assert test.test_weakref.__file__

# Generated at 2022-06-24 02:59:11.490343
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test that when an instance of class NonLocal is created,
    # variables expected to be created are there and are None
    nl1 = NonLocal()
    assert nl1.value is None



# Generated at 2022-06-24 02:59:15.695182
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert isinstance(object, _LazyModuleMarker)


# Generated at 2022-06-24 02:59:16.980793
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lmm = _LazyModuleMarker()
    if lmm:
        print("All good")

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:59:23.873431
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['a.b.c'] = ModuleType('a.b.c')
    sys_modules = sys.modules  # cache in the locals

    module_path = 'a.b.c'
    make_lazy(module_path)

    # Test lazy module created
    assert module_path in sys_modules, "Module %s not found in sys.modules" % module_path
    assert isinstance(sys_modules[module_path], _LazyModuleMarker), "Module %s is not of type LazyModule" % module_path
    assert isinstance(sys_modules[module_path], ModuleType), "Module %s is not of type Module" % module_path

    # Test lazy module functions by access attribute
    sys_modules[module_path].test = 1

# Generated at 2022-06-24 02:59:30.161311
# Unit test for function make_lazy
def test_make_lazy():
    from django.core.management import color
    import django.core.management.color as color_module
    make_lazy("django.core.management.color")

    assert not isinstance(color, color_module.__class__)
    assert isinstance(color, _LazyModuleMarker)

    assert not isinstance(color, color_module.__class__)
    assert isinstance(color, _LazyModuleMarker)
    assert color.COLOR_CODES['bold'] == color_module.COLOR_CODES['bold']
    assert color.COLOR_CODES['no'] == color_module.COLOR_CODES['no']
    assert color.COLOR_STYLES == color_module.COLOR_STYLES
    assert color.supports_color() == color_module.supports_color()

# Generated at 2022-06-24 02:59:38.867382
# Unit test for function make_lazy
def test_make_lazy():
    # Make a dummy folder and python file for testing
    temp = TemporaryDirectory()
    temp_path = temp.name + "/test_data/"
    os.mkdir(temp_path)
    with open(temp_path + "test_file.py", "w") as f:
        f.write("test_var = 1")

    sys.path.insert(0, temp_path)
    assert('test_file' not in sys.modules)

    # Mark test_file module as lazy
    make_lazy("test_file")
    test_file = sys.modules["test_file"]
    assert('test_var' not in dir(test_file))

    # Actually import test_file and make sure test_var is there
    assert(hasattr(test_file, "test_var"))

# Generated at 2022-06-24 02:59:49.370498
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        make_lazy("datadog.api")
        assert "datadog.api" in sys.modules, "sys.modules should have been updated"
        assert isinstance(sys.modules["datadog.api"], _LazyModuleMarker)
        sys.modules["datadog.api"]
    except:
        assert False, "sys.modules should have been updated"

    try:
        make_lazy("datadog.api.resources")
        assert "datadog.api.resources" in sys.modules, "sys.modules should have been updated"
        assert isinstance(sys.modules["datadog.api.resources"], _LazyModuleMarker)
        sys.modules["datadog.api.resources"]
    except:
        assert False, "sys.modules should have been updated"


# Generated at 2022-06-24 02:59:54.767033
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) is _LazyModuleMarker
    assert type(_LazyModuleMarker) is type


# Generated at 2022-06-24 03:00:02.011344
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    # 'make_lazy' should have no __name__ property.
    hasattr(make_lazy, '__name__').should.be.false
    # 'make_lazy' should have no __doc__ property.
    hasattr(make_lazy, '__doc__').should.be.false
    # 'make_lazy' should have no __module__ property.
    hasattr(make_lazy, '__module__').should.be.false
    # 'make_lazy' should have no __file__ property.
    hasattr(make_lazy, '__file__').should.be.false
    # 'make_lazy' should have no __code__ property.
    hasattr(make_lazy, '__code__').should.be.false
    # 'make_lazy' should have

# Generated at 2022-06-24 03:00:05.039399
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker.
    """
    res = _LazyModuleMarker()
    assert isinstance(res, object)

# Unit tests for function make_lazy

# Generated at 2022-06-24 03:00:07.611407
# Unit test for function make_lazy
def test_make_lazy():
    import os

    sys.modules['os'] = None

    make_lazy('os')

    assert isinstance(os, _LazyModuleMarker)
    assert not os._LazyModuleMarker__module_loaded

# Generated at 2022-06-24 03:00:09.001740
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1, "NonLocal(1).value should be 1"
# Found this snippet online, not sure if it works though

# Generated at 2022-06-24 03:00:13.806198
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    def get_module(path):
        import sys
        return sys.modules.get(path, None)

    # Make sure the module we are going to work with is cleared
    del sys.modules['os']

    make_lazy('os')

    # Force os module to be imported
    os.getpid()

    assert(get_module('os') is None)

    assert(sys.modules['os'] is os)

# Generated at 2022-06-24 03:00:16.379975
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    new_marker = _LazyModuleMarker()
    assert type(new_marker) is _LazyModuleMarker

# Generated at 2022-06-24 03:00:23.128610
# Unit test for function make_lazy
def test_make_lazy():
    # See if we can import this module (it should not be importable!)
    try:
        import pyramid.testing  # noqa
    except ImportError:
        pass
    else:
        # The import should have failed
        assert False

    # Marking this module as lazy should make Python think it is imported
    make_lazy('pyramid.testing')

    # This expression should not raise an exception
    isinstance(pyramid.testing, _LazyModuleMarker)

    # Accessing an attribute on the module should import it properly
    assert pyramid.testing.DummyRequest is not None

# Only run module tests if the module isn't being used as a library
if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 03:00:26.936886
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3
    nl.value = 4
    assert nl.value == 4
    nl.value = 5
    assert nl.value == 5



# Generated at 2022-06-24 03:00:28.843160
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)



# Generated at 2022-06-24 03:00:35.389652
# Unit test for function make_lazy
def test_make_lazy():
    test_mod = "lazy_module.lazy_module_tests.lazy_module"
    make_lazy(test_mod)

    if test_mod in sys.modules:
        raise Exception("Module %s shouldn't be in sys.modules" % test_mod)

    import lazy_module.lazy_module_tests.lazy_module

    if test_mod not in sys.modules:
        raise Exception("Module %s should be in sys.modules after import" % test_mod)

# Generated at 2022-06-24 03:00:42.186071
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_make_lazy'

    def check_lazy_module(module):
        assert isinstance(module, _LazyModuleMarker)

    def check_loaded_module(module):
        assert isinstance(module, ModuleType)

    check_lazy_module(sys.modules[module_path])

    make_lazy(module_path)

    check_lazy_module(sys.modules[module_path])

    import test_make_lazy

    check_loaded_module(test_make_lazy)

    # Check that we don't load the module again.
    make_lazy(module_path)

    check_loaded_module(sys.modules[module_path])

# Generated at 2022-06-24 03:00:45.640832
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an instance of _LazyModuleMarker
    marker = _LazyModuleMarker()

    # Check if marker is an instance of _LazyModuleMarker
    assert isinstance(marker, _LazyModuleMarker)

    # Check if marker is an instance of object
    assert isinstance(marker, object)

    # Check if marker is an instance of ModuleType
    assert isinstance(marker, ModuleType) is False


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:00:49.763215
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Test LazyModuleMarker class")

    lazyModuleMarker = _LazyModuleMarker()
    print(" Type(lazyModuleMarker):", type(lazyModuleMarker))
    print("type(_LazyModuleMarker()):", type(_LazyModuleMarker()))
    print("lazyModuleMarker:", lazyModuleMarker)
    print("_LazyModuleMarker():", _LazyModuleMarker())



# Generated at 2022-06-24 03:00:51.538645
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("math")
    assert isinstance(math, _LazyModuleMarker)
    assert math.sqrt(4) == 2

# Generated at 2022-06-24 03:00:52.587388
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(2)
    assert x.value == 2


# Generated at 2022-06-24 03:00:56.120243
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 03:00:57.307058
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(not (_LazyModuleMarker() is None))


# Generated at 2022-06-24 03:01:00.899222
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # In Python 3, the _LazyModuleMarker class does not have an __init__ method
    # the method is added in Python 2
    marker = _LazyModuleMarker()
    assert marker is not None

# Generated at 2022-06-24 03:01:08.480257
# Unit test for function make_lazy
def test_make_lazy():
    import imp
    import os
    import tempfile

    # Create dummy module
    temp_dir = tempfile.mkdtemp()
    module_path = os.path.join(temp_dir, 'test_package')
    f = open(module_path + '.py', 'w')
    f.write("value='test_value'")
    f.close()
    imp.load_source('module_path', module_path + '.py')

    module_to_test = sys.modules[module_path]
    module_instance = module_to_test()

    make_lazy(module_path)

    assert(module_to_test.value == 'test_value')

# Generated at 2022-06-24 03:01:10.563100
# Unit test for function make_lazy
def test_make_lazy():
    from . import lazy_tests
    test_module = lazy_tests
    assert isinstance(test_module, _LazyModuleMarker)
    test_module.lazy_test_func()
    assert not isinstance(test_module, _LazyModuleMarker)



# Generated at 2022-06-24 03:01:14.778849
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        f = NonLocal(module_path)
        assert f.value == module_path
    except:
        raise AssertionError('Failed to test constructor for class NonLocal')


# Generated at 2022-06-24 03:01:24.449664
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import os.path

    make_lazy("os")
    assert isinstance(os, _LazyModuleMarker)
    assert isinstance(os.path, _LazyModuleMarker)

    assert os.path == os.path
    assert os.path is not os.path
    assert os.path == os.path

    try:
        os.path.join("a", "b")
    except AttributeError as e:
        assert False, "Lazy modules should not throw AttributeError"

    import sys
    import sys.path
    assert isinstance(sys, _LazyModuleMarker)
    assert isinstance(sys.path, _LazyModuleMarker)
    assert sys.path == sys.path
    assert sys.path is not sys.path
    assert sys.path == sys.path

# Generated at 2022-06-24 03:01:26.617489
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(None)
    assert foo.value is None


# Generated at 2022-06-24 03:01:30.906503
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Foo(object):
        def __init__(self):
            self.foo = NonLocal(None)
            self.foo.value = 1

    assert Foo().foo.value == 1

# Generated at 2022-06-24 03:01:32.685159
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lm = _LazyModuleMarker()
    assert isinstance(lm, _LazyModuleMarker)


# Generated at 2022-06-24 03:01:37.701900
# Unit test for function make_lazy
def test_make_lazy():
    """
    Checks basic functionality for make_lazy.
    """
    TEST_MODULE_NAME = 'nested.fake_module'
    from nested import fake_module
    assert fake_module.NAME == 'fake_module'
    make_lazy(TEST_MODULE_NAME)
    from nested import fake_module
    assert fake_module.NAME == 'fake_module'
    assert 'nested' in sys.modules and 'fake_module' not in sys.modules['nested'].__dict__

# Generated at 2022-06-24 03:01:45.702542
# Unit test for function make_lazy
def test_make_lazy():
    import time
    import sys

    def delay_import(x):
        time.sleep(1)
        return x + 1

    module_path = 'z.x'
    make_lazy(module_path)
    m = sys.modules[module_path]
    assert m.__name__ == module_path

    assert m.__dict__ == {}
    assert isinstance(m, _LazyModuleMarker)
    m.x = 42
    assert m.x == 42
    assert m.y == 43
    assert m.z == 44

# Generated at 2022-06-24 03:01:48.555991
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
#    global attribute
    a = _LazyModuleMarker()

# Generated at 2022-06-24 03:01:58.027669
# Unit test for constructor of class NonLocal
def test_NonLocal():
    flag = NonLocal(False)
    assert flag
    flag.value = True
    assert flag


if __name__ == '__main__':
    import sys
    sys.path.append('../python')
    from make_lazy import make_lazy

    def test_make_lazy():
        # lazy modules (or modules that act lazy) should not be tracked,
        # until an attribute from them is requested.
        make_lazy('os')
        make_lazy('sys')

        # `os` and `sys` should NOT be in the sys.modules dictionary
        assert 'os' not in sys.modules
        assert 'sys' not in sys.modules

        # go through items to force import
        list(sys.modules.items())

        # now both `os` and `sys` should be in there,
        # and

# Generated at 2022-06-24 03:02:00.573815
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_non_local = NonLocal()
    my_non_local.value = 42
    assert my_non_local.value == 42, "NonLocal constructor does not work properly."

# Generated at 2022-06-24 03:02:02.469356
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_var = NonLocal('LazyModule')
    assert(test_var.value == 'LazyModule')


# Generated at 2022-06-24 03:02:04.390734
# Unit test for constructor of class NonLocal
def test_NonLocal():
    l = NonLocal(None)
    l.value = 'abc'
    assert l.value == 'abc'


# Generated at 2022-06-24 03:02:05.226271
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Tested in make_lazy which uses the NonLocal class
    return

# Generated at 2022-06-24 03:02:08.131318
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create the class instance
    lazyModuleMarker = _LazyModuleMarker()

    # Test that instance has the correct type
    assert(type(lazyModuleMarker) == _LazyModuleMarker)


# Generated at 2022-06-24 03:02:12.055313
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mod = _LazyModuleMarker()
    assert lazy_mod.__doc__ == '\n    A marker to indicate a LazyModule type.\n    Allows us to check module\'s with `isinstance(mod, _LazyModuleMarker)`\n    to know if the module is lazy.\n    '
    assert lazy_mod.__module__ == '_lazy_module'


# Generated at 2022-06-24 03:02:21.612819
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from pandas import tslib
    import sys
    make_lazy('pandas.tslib')
    # this will import it
    from pandas import tslib
    assert 'pandas.tslib' in sys.modules
    assert isinstance(tslib, _LazyModuleMarker)

# Generated at 2022-06-24 03:02:31.731908
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('lazy_module_unit_test_dummy_module', None)
    with open('lazy_module_unit_test_dummy_module.py', 'w') as f:
        f.write('\n'.join([
            "import threading",
            "import os",
            "print('Importing dummy module: %s' % os.getpid())",
            "assert not hasattr(threading.current_thread(), '_lazy_module_test')",
            "threading.current_thread()._lazy_module_test = True",
        ]))


# Generated at 2022-06-24 03:02:34.081397
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert(isinstance(lazy_module, _LazyModuleMarker))



# Generated at 2022-06-24 03:02:35.780796
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 03:02:38.971114
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test if the constructor of _LazyModuleMarker is correct
    """
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker



# Generated at 2022-06-24 03:02:42.730436
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from types import ModuleType
    from .utils import NonLocal
    value = NonLocal(None)
    assert(value.value is None)
    value.value = ModuleType(str("some module name"))
    assert(value.value is not None)


# Generated at 2022-06-24 03:02:44.429537
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_lazy = _LazyModuleMarker()
    assert isinstance(test_lazy, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:54.446188
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_module'] = None

    make_lazy('test_module')

    assert 'test_module' not in sys.modules
    import test_module  # noqa
    assert 'test_module' in sys.modules
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)
    assert not isinstance(sys.modules['test_module'], ModuleType)

    test_module.test_var = None
    test_module.test_func = lambda: None

    assert test_module.__getattribute__('test_var') is None
    assert test_module.__getattribute__('test_func')() is None

    assert test_module.test_var is None
    assert test_module.test_func() is None

# Generated at 2022-06-24 03:03:02.565814
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure that make_lazy actually prevents the import
    sys.modules['_lazy_import_test_make_lazy'] = None
    make_lazy('_lazy_import_test_make_lazy')

    try:
        import _lazy_import_test_make_lazy
        assert False, ("Module _lazy_import_test_make_lazy was "
                       "imported, but it should not have been.")
    except ImportError:
        del sys.modules['_lazy_import_test_make_lazy']

    # Make sure that attributes are properly loaded after the import
    class DummyModule(object):
        def test_attr(self):
            pass

    sys.modules['_lazy_import_test_make_lazy'] = DummyModule()

# Generated at 2022-06-24 03:03:10.547162
# Unit test for function make_lazy
def test_make_lazy():

    @make_lazy('os')
    def func():
        return 'func'

    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert hasattr(sys.modules['os'], '__mro__')
    assert "TypeError: 'NoneType'" not in str(sys.modules['os'].__mro__)

    assert func() == 'func'

    assert not isinstance(sys.modules['os'], _LazyModuleMarker)
    assert not hasattr(sys.modules['os'], '__mro__')

# Generated at 2022-06-24 03:03:14.772076
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    key = 'key'
    value = 'value'
    l = NonLocal(value)
    assert l.value == value



# Generated at 2022-06-24 03:03:20.938145
# Unit test for function make_lazy
def test_make_lazy():
    """
    Example of the module being intialized with the values being
    stored in the closure.
    """
    module_path = "test_make_lazy"

    var = NonLocal(None)

    def test_func():
        if var.value is None:
            print("importing module")
            var.value = 1
        else:
            print("using existing value")
        return var.value

    print("initializing variable")
    print(test_func())
    print("reusing variable")
    print(test_func())
    print("reusing variable")
    print(test_func())


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 03:03:26.597279
# Unit test for function make_lazy
def test_make_lazy():
    import os

    module_path = 'os'
    make_lazy(module_path)
    sys.modules.pop(module_path)
    lazy_module = sys.modules[module_path]
    # lazy module should accept checks with `isinstance`
    assert isinstance(lazy_module, _LazyModuleMarker)
    # lazy module should pass `more` check
    assert issubclass(_LazyModuleMarker, ModuleType)
    # lazy module should pass `is` check
    assert lazy_module is _LazyModuleMarker
    # lazy module should be able to fake out `import *`
    assert 'path' in vars(sys.modules[module_path])
    assert sys.modules[module_path].path == os.path
    # lazy module should be able to fake out `import x`