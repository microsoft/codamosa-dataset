

# Generated at 2022-06-24 02:53:26.456295
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl is not None
    nl.value = 42
    assert nl.value == 42

# Generated at 2022-06-24 02:53:30.456925
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lazy1 = _LazyModuleMarker()
    assert isinstance(lazy1, object)

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:53:33.270331
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(12)
    assert isinstance(x, NonLocal)
    #assert x.value == 12


# Generated at 2022-06-24 02:53:42.113940
# Unit test for function make_lazy
def test_make_lazy():
    # First, we need to make sure that if you don't use make_lazy,
    # importing a module works as expected.
    sys_modules = sys.modules

    try:
        del sys.modules['module_demo']
    except KeyError:
        pass

    module = __import__('module_demo')
    attributes = dir(module)
    test_string = attributes[0]
    assert test_string == 'test_string', 'test_string is not set!'
    assert module.test_string == 'Test String', 'test_string is not set!'
    assert sys.modules['module_demo'] == module, 'Module is not in sys.modules!'
    assert len(sys.modules) == 1, 'sys.modules has too many entries!'

    # Now, we make sure that make_lazy works with no problems.

# Generated at 2022-06-24 02:53:45.035323
# Unit test for function make_lazy
def test_make_lazy():
    class A(object):
        pass

    class B(object):
        pass

    make_lazy('test_make_lazy')

# Generated at 2022-06-24 02:53:48.605778
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mark = _LazyModuleMarker()
    assert mark.__module__ == 'vent.core.lazy'
    assert mark.__name__ == '_LazyModuleMarker'


# Generated at 2022-06-24 02:53:53.142231
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class testValue:
        def __init__(self):
            self.value = None

    test_data = testValue()

    nl = NonLocal(test_data)
    assert nl.value is test_data

    test_data.value = "new"
    assert nl.value.value == "new"

# Generated at 2022-06-24 02:53:59.528709
# Unit test for function make_lazy
def test_make_lazy():
    """
    A unit test for the LazyModule that is created by make_lazy
    """
    try:
        from django.conf.global_settings import DEBUG  # noqa
        lazy_test_failed = True
    except ImportError:
        lazy_test_failed = False

    module_name = 'django.conf.global_settings'
    module_path = '%s.DEBUG' % module_name

    make_lazy(module_name)
    assert DEBUG

    make_lazy(module_path)
    assert DEBUG

# Generated at 2022-06-24 02:54:08.407538
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import imp
    import inspect
    import os
    import re

    # in case path is not relative
    def get_abs_path(relative_path):
        return os.path.normpath(os.path.join(os.path.dirname(__file__), relative_path))
    # path to file containing the code for this function
    this_file = __file__
    # path to file containing the code for NonLocal
    nonlocal_file = get_abs_path("test_lazy_imports.py")
    # path to file containing the code for LazyModule
    lazymodule_file = get_abs_path("test_lazy_imports.py")

    if sys.version_info[0] < 3:
        # load NonLocal class into module
        nonlocal_module = imp.load_source

# Generated at 2022-06-24 02:54:11.136872
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import types
    make_lazy('os')
    assert isinstance(os, types.ModuleType)
    assert isinstance(os, _LazyModuleMarker)
    assert not hasattr(os, 'sep')
    from os import sep
    assert os.sep == os.sep
    assert os.sep == sep

# Generated at 2022-06-24 02:54:17.309055
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal('foo')
    assert nonlocal_object.value == 'foo'

    nonlocal_object.value = 'bar'
    assert nonlocal_object.value == 'bar'

    def callback_function():
        nonlocal_object.value = 'baz'
        return nonlocal_object.value

    assert callback_function() == 'baz'
    assert nonlocal_object.value == 'baz'



# Generated at 2022-06-24 02:54:19.976410
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test constructor of class NonLocal
    This unittest is coded by Digbijay Mishra(UIN-127000148)
    """
    assert NonLocal(5)
    assert repr(NonLocal(5))=="<__main__.NonLocal object at 0x7f56b303e550>"



# Generated at 2022-06-24 02:54:21.462741
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import imp
    # Create a temporary module
    test_name = 'test_lazy_module'

# Generated at 2022-06-24 02:54:22.089832
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print (_LazyModuleMarker())

# Generated at 2022-06-24 02:54:25.465291
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys

    def test():
        # initialize the module
        nonlocal_module = NonLocal(None)
        assert nonlocal_module.value == None

        # initialize the module
        nonlocal_module.value = sys.modules
        assert nonlocal_module.value == sys.modules



# Generated at 2022-06-24 02:54:29.514846
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    >>> local = NonLocal(10)
    >>> local.value
    10
    >>> local.value = 20
    >>> local.value
    20
    """



# Generated at 2022-06-24 02:54:39.115250
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import imp
    import types

    # Create a temporary directory for the module to reside in
    os.system('mkdir /tmp/hi')

    # Write a file to this directory
    f = open('/tmp/hi/__init__.py', 'w')
    f.write( 'LENT = 42\n' )
    f.write( 'def r(): return 3\n' )
    f.close()

    # Remove the module from python's cache
    sys.modules.pop('hi', None)

    import hi  # import the module normally
    assert hi.r() == 3
    assert isinstance(hi, types.ModuleType)

    make_lazy('hi')
    import hi as hi_lazy
    assert hi_lazy.r() == 3

# Generated at 2022-06-24 02:54:42.646672
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Check if the constructor of _LazyModuleMarker works
    m = _LazyModuleMarker()
    assert(isinstance(m, _LazyModuleMarker))


# Generated at 2022-06-24 02:54:44.054346
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-24 02:54:45.445686
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(type(make_lazy('a')), _LazyModuleMarker)


# Generated at 2022-06-24 02:54:46.479672
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(object(), _LazyModuleMarker)

# Generated at 2022-06-24 02:54:54.617922
# Unit test for function make_lazy
def test_make_lazy():
    import unittest2

    from .compat import get_magic_number

    class TestLazy(unittest2.TestCase):
        def test_lazy(self):
            ok = ['test_lazy', '__builtins__', '__file__', '__package__', '__name__', 'unittest2', '__doc__', '__loader__', 'sys']
            sys.modules['lazy_test'] = make_lazy('lazy_test')
            self.assertTrue(sys.modules['lazy_test'])
            self.assertEqual(set(sys.modules['lazy_test'].__dict__.keys()), set(ok))

    def test_make_lazy():
        import unittest2


# Generated at 2022-06-24 02:54:57.783398
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(5)
    assert NonLocal("string")
    assert NonLocal(5).value == 5
    assert NonLocal("string").value == "string"

# Generated at 2022-06-24 02:54:59.648944
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 02:55:05.139383
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1
    x.value = 2
    assert x.value == 2


# Generated at 2022-06-24 02:55:06.368199
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(NonLocal('a char').value == 'a char')


# Generated at 2022-06-24 02:55:07.575829
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:55:09.250147
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert 'NonLocal' in globals()


_DISABLED = '_DISABLED'
_ENABLED = '_ENABLED'
_DEFAULT = '_DEFAULT'
_UNSET = '_UNSET'



# Generated at 2022-06-24 02:55:11.661256
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def validate_nonlocal_constructor(x):
        assert isinstance(x, NonLocal)

    validate_nonlocal_constructor(NonLocal("foo"))



# Generated at 2022-06-24 02:55:18.850680
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Clazz(object):
        def __init__(self):
            self.nonlocal_var1 = None
            self.nonlocal_var2 = NonLocal(self.nonlocal_var1)

        def func1(self):
            self.nonlocal_var2.value = 1
            assert self.nonlocal_var1 == 1

    t = Clazz()
    t.func1()


if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 02:55:23.956859
# Unit test for function make_lazy
def test_make_lazy():
    # Test that the module has been marked as lazy.
    assert not hasattr(urllib, 'FancyURLopener')
    assert isinstance(urllib, _LazyModuleMarker)
    assert hasattr(urllib, 'FancyURLopener')

    # Test that the marker is a valid module
    assert hasattr(urllib, 'quote')

# Generated at 2022-06-24 02:55:31.969209
# Unit test for function make_lazy
def test_make_lazy():
    # Create a dummy module
    mod_name = 'test_lazy_import'
    mod_dir = os.path.dirname(os.path.abspath(__file__))

    mod_file = os.path.join(mod_dir, '{}.py'.format(mod_name))
    # Remove any existing module
    try:
        os.remove(mod_file)
    except OSError:
        pass

    # create module
    with open(mod_file, 'w') as f:
        f.write(
            '''# dummy module
            class Test(object):
                pass'''
        )

    # import dummy module

# Generated at 2022-06-24 02:55:36.134527
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 02:55:38.421110
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModule = _LazyModuleMarker()
    assert isinstance(lazyModule, _LazyModuleMarker)



# Generated at 2022-06-24 02:55:43.626400
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that this class is a marker and nothing more.
    """
    # Create the marker.
    marker = _LazyModuleMarker()

    # Test mro.
    assert marker.__mro__ == (marker.__class__, object)

    # Test that this marker cannot be called.
    assert marker() is TypeError

    # Make sure we can use isinstance on this marker.
    assert isinstance(marker, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:53.289018
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure we can use it to decorate a module
    @make_lazy('unittest')
    def test():
        assert False, 'This should never be reached'

    # Even though the above `test` function exists we still shouldn't import
    # the `unittest` module
    try:
        import unittest
        assert False, 'Should never be reached'
    except ImportError:
        pass

    # Now we try to import test as a module
    import test as a_module

    # Make sure it still doesn't import the module
    try:
        import unittest
        assert False, 'Should never be reached'
    except ImportError:
        pass

    # and make sure we can access a function / class from `unittest`
    assert isinstance(a_module.TestCase, type)

# Generated at 2022-06-24 02:55:57.979358
# Unit test for function make_lazy
def test_make_lazy():
    from django.utils import six

    make_lazy('test_module')
    import test_module

    # Test the lazy import
    assert isinstance(test_module, _LazyModuleMarker)

    # Test that there's a submodule
    assert test_module.submodule

    # Test that it's still a lazy import
    assert isinstance(test_module, _LazyModuleMarker)

    # Test that there's a submodule
    assert test_module.submodule

    # Test that it's not a lazy import anymore
    assert not isinstance(test_module, _LazyModuleMarker)

    # Test that there's a submodule
    assert test_module.submodule

# Generated at 2022-06-24 02:55:58.905400
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(None)



# Generated at 2022-06-24 02:56:09.058781
# Unit test for function make_lazy
def test_make_lazy():
    test_path="../conda/tests/test_make_lazy_module.py"
    sys.path.append(os.path.dirname(test_path))
    make_lazy("test_make_lazy_module")
    import test_make_lazy_module
    print(hasattr(test_make_lazy_module, '__mro__'))
    print(isinstance(test_make_lazy_module, ModuleType))
    print(isinstance(test_make_lazy_module, _LazyModuleMarker))
    def test_set_attr(module, attrname):
        setattr(module, attrname, 1)

    def test_del_attr(module, attrname):
        delattr(module, attrname)

# Generated at 2022-06-24 02:56:15.990654
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    class ClassA(object):
        """
        An empty class to test make_lazy
        """
        pass
    sys.modules["test_module"] = None
    make_lazy("test_module")
    assert hasattr(sys.modules["test_module"], "__getattribute__")
    assert hasattr(sys.modules["test_module"], "__mro__")
    sys.modules["test_module.ClassA"] = ClassA
    assert isinstance(sys.modules["test_module"].ClassA, type)
    del sys.modules["test_module"]
    del sys.modules["test_module.ClassA"]
    del ClassA
test_make_lazy()

# Generated at 2022-06-24 02:56:16.745437
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert obj

# Generated at 2022-06-24 02:56:18.085938
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert isinstance(LazyModuleMarker, _LazyModuleMarker)

# Generated at 2022-06-24 02:56:21.190506
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A(object):
        pass

    a = A()

    assert(isinstance(a, A) == True)
    assert(isinstance(a, _LazyModuleMarker) == False)
    assert(issubclass(A, _LazyModuleMarker) == False)



# Generated at 2022-06-24 02:56:24.078203
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test instantiation
    assert _LazyModuleMarker()



# Generated at 2022-06-24 02:56:25.451415
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert n.value is None


# Generated at 2022-06-24 02:56:28.323311
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal("test")
    assert nonlocal_value.value == "test"
    nonlocal_value.value = "test2"
    assert nonlocal_value.value == "test2"

# Generated at 2022-06-24 02:56:31.041757
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = None
    nl2 = NonLocal(nl)
    assert nl2.value == nl


# Generated at 2022-06-24 02:56:33.467875
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5

# Generated at 2022-06-24 02:56:35.712501
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object), \
        '_LazyModuleMarker must be a subclass of object.'


# Generated at 2022-06-24 02:56:38.939543
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl1 = NonLocal(None)
    assert nl1.value is None
    nl2 = NonLocal(1)
    assert nl2.value == 1

# Generated at 2022-06-24 02:56:46.850142
# Unit test for function make_lazy
def test_make_lazy():
    # Setup
    module_path = 'lazy_import.test_module'
    module_name = 'test_module'
    module = sys.modules[module_path]
    make_lazy(module_path)
    assert isinstance(module, _LazyModuleMarker)
    with pytest.raises(AttributeError):
        test_var = module.test_var

    # Test that it really gets loaded on first use
    assert module.test_var == 'test_value'
    assert module.test_var == 'test_value'
    assert module.test_var == 'test_value'

    # Test that it got loaded into the sys.modules
    assert isinstance(sys.modules[module_path], ModuleType)
    assert isinstance(sys.modules[module_name], ModuleType)

# Generated at 2022-06-24 02:56:50.995967
# Unit test for constructor of class NonLocal
def test_NonLocal():
	_lazy_module_marker = NonLocal(10)

# Generated at 2022-06-24 02:57:01.333993
# Unit test for function make_lazy
def test_make_lazy():
    # To show the function works, we'll create a function in this file
    # and also have a variable that is a function that's in the exact
    # same spot as we'll have in our lazily-loaded module.
    def test_func():
        return 1

    test_func_lazy = None

    make_lazy('make_lazy_test')
    assert isinstance(make_lazy_test, _LazyModuleMarker)
    assert make_lazy_test.test_func is test_func
    assert make_lazy_test.test_func_lazy is test_func_lazy
    assert sys.modules['make_lazy_test'].test_func is test_func

    # Now we'll add the function and make sure it's updated
    # This requires us to actually import the real module
    # and not

# Generated at 2022-06-24 02:57:06.176685
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 02:57:07.790335
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(10)   
    assert(foo.value == 10)


# Generated at 2022-06-24 02:57:16.517967
# Unit test for function make_lazy
def test_make_lazy():
    import pytest

    # Test that we can make a module lazy
    make_lazy('tarantool_queue.lru_cache')

    # Test that we can import a lazy module
    from .lru_cache import get_lru_cache

    # XXX:
    # The following check does not work due to Python issue #5468
    # (https://bugs.python.org/issue5468) in some Python versions.
    #
    # Try to import a module and get it from sys.modules
    # from .lru_cache import get_lru_cache
    # mod = sys.modules['tarantool_queue.lru_cache']
    #
    # assert mod.__class__ is not ModuleType
    # assert not isinstance(mod, ModuleType)
    # assert not isinstance(mod, types.ModuleType)

# Generated at 2022-06-24 02:57:26.903314
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_name = 'lazy_module'
    lazy_module_attribute = 'lazy_module_attribute'
    lazy_module_attribute_value = 'lazy_module_attribute_value'

    # Add lazy module for testing
    sys.modules[lazy_module_name] = 'previous value' # can be anything
    make_lazy(lazy_module_name)

    # Check lazy module is lazy after it is created
    lazy_module = sys.modules[lazy_module_name]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # Check that we did not import the module
    assert lazy_module_name not in sys.modules

    # Check that we can not access any attributes
    with pytest.raises(AttributeError):
        lazy_module.does_not_exist

# Generated at 2022-06-24 02:57:27.787254
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal1 = NonLocal(6)
    print (nonlocal1.value)


# Generated at 2022-06-24 02:57:30.180948
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def test(x):
        nonlocal x
        return x
    y = NonLocal(0)
    assert test(y) == y.value

# Generated at 2022-06-24 02:57:39.240112
# Unit test for function make_lazy
def test_make_lazy():

    # AttributeError should be raised at import time
    import unittest

    try:
        unittest.TestCase.something
        raise Exception('Should have failed')
    except AttributeError:
        pass

    make_lazy('unittest')
    import unittest

    # Should now succeed on access
    unittest.TestCase.something
    unittest = reload(unittest)

    # Should still succeed after reload
    unittest.TestCase.something

# Run unit test
test_make_lazy()

# Mark lazy modules
make_lazy('django')
make_lazy('django.db')
make_lazy('django.db.models')
make_lazy('django.db.models.fields')
make_lazy('django.db.models.sql')


# Generated at 2022-06-24 02:57:40.348788
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()



# Generated at 2022-06-24 02:57:45.508778
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    printer = LazyModuleMarker()

    assert Object.getValue(printer) == None


# Generated at 2022-06-24 02:57:47.462062
# Unit test for function make_lazy
def test_make_lazy():
    m = make_lazy("test.mod")
    m.a = 5
    assert m.a == 5
    assert m.b == 5

# Generated at 2022-06-24 02:57:51.776820
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal(10)
    assert nonlocal_object.value == 10

# Generated at 2022-06-24 02:58:00.192155
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Build a string of all the methods and properties of _LazyModuleMarker
    methods_and_properties = ''.join([str(i) for i in _LazyModuleMarker.__dict__])
    assert('__module__' in methods_and_properties) # __module__ is a special Python property
    # mro_strings will contain the strings of all the elements of the MRO at the time of testing
    mro_strings = [str(i) for i in _LazyModuleMarker.__mro__]
    assert('class _LazyModuleMarker' in mro_strings) # does this class exist?
    assert('object' in mro_strings) # does this class inherit from Python-style object?
    assert(_LazyModuleMarker.__module__ == '__main__')

# Generated at 2022-06-24 02:58:01.017231
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 02:58:03.748442
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, type)
test__LazyModuleMarker()


# Generated at 2022-06-24 02:58:10.717302
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the functionality of the make_lazy function.
    """

    MOD_NAME = "make_lazy_test_module"
    MOD_ATTR = "attribute"

    # Create a module with an attribute.
    mod = types.ModuleType(MOD_NAME)
    setattr(mod, MOD_ATTR, None)
    import sys
    sys.modules[MOD_NAME] = mod

    # Make the module lazy.
    make_lazy(MOD_NAME)

    # Confirm the module is marked.
    assert isinstance(mod, _LazyModuleMarker)

    # Confirm the module is not imported yet.
    assert MOD_NAME not in sys.modules

    m = __import__(MOD_NAME)

    # Confirm that the module has been imported.
    assert MOD_NAME in sys.modules


# Generated at 2022-06-24 02:58:14.227869
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker is type('_LazyModuleMarker', (object,), {})


# Generated at 2022-06-24 02:58:18.091760
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test constructor
    nl = NonLocal(2)
    assert nl.value == 2

    # test __slots__
    try:
        nl.test_slot = 1
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-24 02:58:27.979588
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the lazy module function.
    """
    # To test our lazy module, we'll use the ast module as a stand in.
    ast = module_ast = __import__('ast')

    make_lazy('ast')
    ast_ = sys.modules['ast']

    # Check that the module is lazy
    assert isinstance(ast_, ModuleType)
    assert not isinstance(ast_, (ast.AST, ast.ModuleType))

    # Check that the module has the right attributes
    assert ast_.__name__ == ast.__name__
    assert ast_.__file__ == ast.__file__
    assert ast_.namespace == ['__name__', '__file__']

    # Overwrite our lazy module by importing the actual module.
    # Check that the module is no longer lazy
    __import__('ast')


# Generated at 2022-06-24 02:58:31.892783
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    moduleMarker = _LazyModuleMarker()
    assert moduleMarker != None


# Generated at 2022-06-24 02:58:34.536456
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert isinstance(lazy_module, object)


# Generated at 2022-06-24 02:58:35.825485
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 02:58:41.441473
# Unit test for function make_lazy
def test_make_lazy():
    # setup
    sys.modules['foobar'] = 'test1'
    from foobar import TEST
    assert TEST == 'test2'

    # test lazy module
    make_lazy('foobar')
    from foobar import TEST
    assert TEST == 'test2'
    assert sys.modules['foobar'] != 'test1'

# Generated at 2022-06-24 02:58:45.578696
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import types
    import sys

    mod = _LazyModuleMarker()
    assert isinstance(mod, types.ModuleType)
    assert not isinstance(mod, sys.modules["__builtin__"])


# Generated at 2022-06-24 02:58:49.561755
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for make_lazy functionality
    """
    # Original module entry is not None
    sys.modules['__lazy__'] = 0
    try:
        make_lazy('__lazy__')
        assert sys.modules['__lazy__'] is not None
        assert isinstance(sys.modules['__lazy__'], NonLocal)
    finally:
        del sys.modules['__lazy__']

# Generated at 2022-06-24 02:58:51.151887
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0


# Generated at 2022-06-24 02:58:55.560422
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModule = make_lazy('django.contrib.auth.models')
    assert isinstance(LazyModule, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:02.570194
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run unit test for make_lazy function
    """
    # Since the function is not used by anything else in any other tests,
    # we can get away with testing the function here
    # This will be removed in the future, when this function is used
    # in other tests.

    # Test without any imports
    module_path = 'tests.lazy_loader.test_make_lazy.my_module'
    make_lazy(module_path)
    mod = sys.modules[module_path]

    assert isinstance(mod, _LazyModuleMarker)
    assert 'my_module' not in sys.modules
    # getattr will trigger the import
    assert getattr(mod, 'my_variable') == 'my_value'
    assert 'my_module' in sys.modules
    # once imported, function will

# Generated at 2022-06-24 02:59:05.358888
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    this = _LazyModuleMarker()



# Generated at 2022-06-24 02:59:13.637215
# Unit test for function make_lazy
def test_make_lazy():
    # we need a dummy module to test with
    sys.modules['torch.test_module'] = ModuleType('torch.test_module')
    test_module = sys.modules['torch.test_module']
    test_module.test_attribute = 'test_value'

    # and a lazy version
    make_lazy('torch.test_module')
    lazy_test_module = sys.modules['torch.test_module']
    assert not hasattr(lazy_test_module, 'test_attribute')
    with pytest.raises(AttributeError):
        lazy_test_module.test_attribute
    assert isinstance(lazy_test_module, ModuleType)
    assert not isinstance(lazy_test_module, _LazyModuleMarker)

    # invoking the lazy module gives us the original
    test

# Generated at 2022-06-24 02:59:17.633154
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    return a

# Generated at 2022-06-24 02:59:19.138938
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(10)

# Generated at 2022-06-24 02:59:23.850825
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('sys')
    assert isinstance(sys, _LazyModuleMarker)
    assert sys.path
    assert not isinstance(sys, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:29.017370
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('sys')

    assert isinstance(sys.modules['sys'], _LazyModuleMarker)

    assert sys.version_info.major == 2

    assert not isinstance(sys.modules['sys'], _LazyModuleMarker)


test_make_lazy()

# The next 2 statements are not necessary, but remove the need for circular
# references by the garbage collector. This way we can 'delete' any values
# with names that start with 'temp'.
del sys_modules, test_make_lazy


# this is nice for making lazy our own modules
make_lazy('harpocrates_common.lazy_module')

# Generated at 2022-06-24 02:59:32.408451
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()

# Generated at 2022-06-24 02:59:40.822968
# Unit test for function make_lazy
def test_make_lazy():
    module = 'test_module'
    sys.modules[module] = None
    make_lazy(module)

    test_module = sys.modules[module]
    assert isinstance(test_module, _LazyModuleMarker)
    assert not hasattr(test_module, 'test_attribute')
    assert test_module.__dict__ is {}
    assert not hasattr(sys.modules[module], 'test_attribute')

    test_module.test_attribute = 'foo'
    assert hasattr(test_module, 'test_attribute')
    assert hasattr(sys.modules[module], 'test_attribute')
    assert test_module.test_attribute == 'foo'
    assert sys.modules[module].test_attribute == 'foo'

    del sys.modules[module]

# Generated at 2022-06-24 02:59:41.792499
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-24 02:59:45.018488
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    y = NonLocal(None)
    print(x, y)
    print(x == y ,x is y)
    x = y = 1
    print(x, y)
    print(x == y, x is y)

# test_NonLocal()


# Generated at 2022-06-24 02:59:47.214004
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert LazyModuleMarker
    assert LazyModuleMarker.__class__ == _LazyModuleMarker


# Generated at 2022-06-24 02:59:53.706296
# Unit test for function make_lazy
def test_make_lazy():
    try:
        test_module = 'test.test_lazy_import.test_make_lazy.test_module'
        del sys.modules[test_module]
        import test_make_lazy.test_module

        assert not isinstance(test_make_lazy.test_module, _LazyModuleMarker)

        make_lazy(test_module)

        assert isinstance(test_make_lazy.test_module, _LazyModuleMarker)

        assert test_make_lazy.test_module.__file__.endswith('test_module.py')
    finally:
        del sys.modules[test_module]



# Generated at 2022-06-24 02:59:54.912741
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 02:59:56.851764
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10
    a.value = 20
    assert a.value == 20

# Generated at 2022-06-24 03:00:01.770268
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker is not None


# Generated at 2022-06-24 03:00:04.452084
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print ("\nTesting LazyModule constructor.")
    a = _LazyModuleMarker()
    assert(a!=None)
    print ("\nPassed.")


# Generated at 2022-06-24 03:00:07.285191
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os.path

    def assertLazyModule(module_path):
        assert os.path.exists(module_path)

        module_name = os.path.basename(module_path)[:-3]

        assert module_name in sys.modules
        assert not isinstance(sys.modules[module_name], ModuleType)

    assertLazyModule('pkg.module')

    from pkg.module1 import module1
    assertLazyModule('pkg.module1')
    assertLazyModule('pkg.module')

    assert isinstance(module1, ModuleType)

# Generated at 2022-06-24 03:00:11.052986
# Unit test for function make_lazy
def test_make_lazy():
    mod = "django.contrib.auth"

# Generated at 2022-06-24 03:00:15.852685
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonl=NonLocal(10)
    assert nonl.value==10

# Generated at 2022-06-24 03:00:16.602266
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 03:00:17.849825
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """test__LazyModuleMarker()"""
    _LazyModuleMarker()


# Generated at 2022-06-24 03:00:20.533445
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_raises(TypeError, _LazyModuleMarker)



# Generated at 2022-06-24 03:00:22.339054
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Assert there are no type errors
    try:
        _LazyModuleMarker()
    except TypeError:
        assert False  # Should not reach this point
    

# Generated at 2022-06-24 03:00:23.619121
# Unit test for constructor of class NonLocal
def test_NonLocal():
	pass

#Unit test for make_lazy

# Generated at 2022-06-24 03:00:27.054765
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = [1, 2, 3]
    #print nl.value
    assert nl.value == [1, 2, 3]


# Generated at 2022-06-24 03:00:29.188515
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test : class NonLocal
    """
    foo = NonLocal(10)
    assert(foo.value == 10)



# Generated at 2022-06-24 03:00:30.776536
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal("ABC")
    assert(a.value == "ABC")


# Generated at 2022-06-24 03:00:33.348128
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print(dir(_LazyModuleMarker))


# Generated at 2022-06-24 03:00:36.714686
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("")
    assert nl.value is None



# Generated at 2022-06-24 03:00:38.273874
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert n.value is None
    n.value = 1
    assert n.value == 1
    n.value = None
    assert n.value is None

# Generated at 2022-06-24 03:00:44.770691
# Unit test for function make_lazy
def test_make_lazy():
    raise NotImplementedError()
    # import inspect
    # assert not hasattr(inspect, '_getmodule')
    #
    # make_lazy('inspect')
    # assert isinstance(inspect, ModuleType)
    # assert not hasattr(inspect, '_getmodule')
    #
    # assert inspect._getmodule(test_make_lazy) == sys.modules[__name__]
    #
    # # Check that parent is inspector
    # assert inspect._getmodule(inspect) == inspect

# Generated at 2022-06-24 03:00:52.140301
# Unit test for function make_lazy
def test_make_lazy():
    class TestModule(object):
        def __init__(self, name):
            self.name = name
            self.cache = {}
            self.set_attributes()

        def set_attributes(self):
            self.func = lambda x: x**2

    module_path = 'test_make_lazy_module'
    sys.modules[module_path] = TestModule(module_path)
    test_module = sys.modules[module_path]
    make_lazy(module_path)

    # Check that the module hasn't been imported yet
    assert sys.modules[module_path].cache == {}

    # Access first attribute
    assert sys.modules[module_path].func(2) == 4

    # Check that the module has now been imported

# Generated at 2022-06-24 03:00:55.049744
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy_mod'] = __import__('test_make_lazy_mod')
    make_lazy('test_make_lazy_mod')
    from test_make_lazy_mod import val
    assert val == 2

# Generated at 2022-06-24 03:00:58.896458
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(object):
        def __init__(self):
            self.counter = NonLocal(0)
            self.counter.value = 5
            return

    test = Test()
    assert test.counter.value == 5


# Generated at 2022-06-24 03:01:05.742433
# Unit test for function make_lazy
def test_make_lazy():
    import os

    assert not hasattr(os, 'path')
    assert isinstance(os, _LazyModuleMarker)
    os.path
    assert hasattr(os, 'path')
    assert not isinstance(os, _LazyModuleMarker)


# vim:et:fdm=marker:sts=

# Generated at 2022-06-24 03:01:14.941473
# Unit test for function make_lazy
def test_make_lazy():
    """Check that the make_lazy function works"""
    import importlib
    import os
    import sys
    import tempfile

    test_script = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-24 03:01:23.830391
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import tempfile
    module_dir = tempfile.mkdtemp()
    module_path = os.path.join(module_dir, '__init__.py')
    try:
        with open(module_path, 'w') as f:
            f.write('a = 1\n')
        make_lazy(module_dir)
        module = sys.modules[module_dir]
        assert isinstance(module, _LazyModuleMarker)
        assert 'a' not in sys.modules
        assert module.a == 1
        assert 'a' in sys.modules
    finally:
        os.unlink(module_path)
        os.rmdir(module_dir)

# Generated at 2022-06-24 03:01:31.924497
# Unit test for function make_lazy
def test_make_lazy():
    try:
        mod = sys.modules['test_mod']
    except KeyError:
        mod = None

    # Make it lazy
    make_lazy('test_mod')
    mod = sys.modules['test_mod']
    assert isinstance(mod, _LazyModuleMarker)
    assert mod.__name__ == 'test_mod'
    assert hasattr(mod, '__file__')
    assert hasattr(mod, '__mro__')
    assert not hasattr(mod, 'meow')

    # It becomes non-lazy when accessed
    assert mod.meow() == 'meow'
    mod = sys.modules['test_mod']
    assert not isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-24 03:01:36.432925
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This function tests the constructor of class _LazyModuleMarker
    """
    # Test 1: Testing for normal condition
    try:
        test_lazy_module = _LazyModuleMarker()
    except TypeError:
        assert False

    # Test 2: Testing for multiple instantiation
    try:
        test_lazy_module_2 = _LazyModuleMarker()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 03:01:41.431778
# Unit test for function make_lazy
def test_make_lazy():
    import edx_tensorflow

    make_lazy('edx_tensorflow')

    # try to load it, should load lazily.
    edx_tensorflow.tf.constant(1)

    # check that we now have a regular module in sys.modules
    assert isinstance(edx_tensorflow, ModuleType)



# Generated at 2022-06-24 03:01:49.326274
# Unit test for function make_lazy
def test_make_lazy():
    # Lazy module created
    make_lazy('os')
    assert sys.modules['os']
    assert sys.modules['os'] is not None
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    assert 'os' not in sys.modules
    assert sys.getrefcount(sys.modules['os']) == 2

    # Lazy module access
    assert sys.modules['os'].path
    assert 'os' in sys.modules
    assert sys.getrefcount(sys.modules['os']) == 3

# Generated at 2022-06-24 03:01:54.388997
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Ensuring attributes don't error when accessed
    assert(hasattr(_LazyModuleMarker(), '__mro__'))
    assert(hasattr(_LazyModuleMarker(), '__getattribute__'))
    assert(hasattr(_LazyModuleMarker(), '__name__'))
    assert(hasattr(_LazyModuleMarker(), '__module__'))

test__LazyModuleMarker()

# Generated at 2022-06-24 03:02:02.584635
# Unit test for function make_lazy
def test_make_lazy():
    assert "django.utils._lazymodule_test" not in sys.modules
    make_lazy("django.utils._lazymodule_test")
    assert "django.utils._lazymodule_test" in sys.modules
    mod = sys.modules["django.utils._lazymodule_test"]
    assert isinstance(mod, _LazyModuleMarker)
    assert "attr" not in sys.modules["django.utils._lazymodule_test"].__dict__
    val = mod.attr
    assert "attr" in sys.modules["django.utils._lazymodule_test"].__dict__
    assert val == "test"


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-24 03:02:03.832186
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert bool(_LazyModuleMarker)


# Generated at 2022-06-24 03:02:06.761107
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import six
    lazy_module_marker = _LazyModuleMarker()
    # Make sure that the superclass of lazy_module_marker is object
    assert six.class_mro(lazy_module_marker)[1] is object

# Generated at 2022-06-24 03:02:08.965367
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonLocal = NonLocal(None)
    assert(nonLocal.value is None)
    nonLocal.value = 1
    assert(nonLocal.value is 1)

# Generated at 2022-06-24 03:02:12.868849
# Unit test for function make_lazy
def test_make_lazy():
    class A():
        pass

    make_lazy('test.test_import')
    import test.test_import
    assert(isinstance(test.test_import, _LazyModuleMarker))
    assert(isinstance(test.test_import, ModuleType))
    assert(isinstance(test.test_import, A) == False)
    import test.test_import
    assert(isinstance(test.test_import, ModuleType))
    assert(isinstance(test.test_import, A) == False)

# Generated at 2022-06-24 03:02:18.105258
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-24 03:02:20.028427
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Test(_LazyModuleMarker):
        pass
    assert isinstance(Test(), _LazyModuleMarker)


# Generated at 2022-06-24 03:02:23.327842
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal('Hi!')
    assert non_local.value == 'Hi!'

# Unit tests for make_lazy function

# Generated at 2022-06-24 03:02:30.785809
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the function make_lazy
    """
    module1 = sys.modules.get("import_this")
    if module1 is not None:
        del sys.modules["import_this"]

    make_lazy("import_this")
    module1 = sys.modules.get("import_this")

    assert isinstance(module1, _LazyModuleMarker)
    assert hasattr(module1, "__mro__")
    assert hasattr(module1, "__getattribute__")

    del sys.modules["import_this"]


# Generated at 2022-06-24 03:02:35.740799
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import deps.analysis.lazy_module
    reload(deps.analysis.lazy_module)
    from deps.analysis.lazy_module import _LazyModuleMarker
    lazy_module = _LazyModuleMarker()

    assert(isinstance(lazy_module, _LazyModuleMarker))



# Generated at 2022-06-24 03:02:41.469076
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal("n")
    assert n.value == "n"
    n.value = "c"
    assert n.value == "c"


# Generated at 2022-06-24 03:02:46.493799
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    # As the constructor of class _LazyModuleMarker is None,
    # it is a good idea to test that the __mro__ and __getattribute__
    # methods of its subclass LazyModule are not None.
    # The following code will throw AttributeError if any of
    # the two methods is not implemented.
    try:
        LazyModule.__mro__
        LazyModule.__getattribute__
    except AttributeError:
        assert False

# Generated at 2022-06-24 03:02:47.901251
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 03:02:50.297114
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(None)
    expected = None
    t.value = 3
    actual = t.value
    assert actual == expected


# Generated at 2022-06-24 03:02:55.439195
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    my_object = NonLocal(None)
    assert type(my_object) is NonLocal


# Generated at 2022-06-24 03:02:57.633038
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(5)
    assert nl.value == 5


# Generated at 2022-06-24 03:03:01.375773
# Unit test for constructor of class NonLocal
def test_NonLocal():
    l = NonLocal(5)
    assert l.value == 5

# Generated at 2022-06-24 03:03:03.008836
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    assert a.value == 0


# Generated at 2022-06-24 03:03:06.565336
# Unit test for constructor of class NonLocal
def test_NonLocal():
    v = NonLocal('test')
    assert v.value == 'test'

test_NonLocal()



# Generated at 2022-06-24 03:03:08.712324
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy
    """
    import os.path
    make_lazy("os.path")
    os.path.dirname(".")



# Generated at 2022-06-24 03:03:11.562678
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert isinstance(_LazyModuleMarker(), object)

    # Try to do something that can't be done with a lambda
    (lambda: _LazyModuleMarker()).__name__


# Generated at 2022-06-24 03:03:14.119570
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)

# Generated at 2022-06-24 03:03:21.081586
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for the make_lazy() function.
    """
    # Define a module that depends on a variable defined in the enclosing scope
    test_module_contents = "a = variable"

    # Create the module
    fh, test_module_path = tempfile.mkstemp(".py")
    os.close(fh)

# Generated at 2022-06-24 03:03:24.356379
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test NonLocal class
    """
    non_local = NonLocal(1)

# Generated at 2022-06-24 03:03:26.580218
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert (isinstance(marker, _LazyModuleMarker))
    assert (isinstance(marker, ModuleType))
