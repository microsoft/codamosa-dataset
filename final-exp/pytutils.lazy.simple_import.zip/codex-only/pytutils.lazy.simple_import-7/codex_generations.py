

# Generated at 2022-06-24 02:53:30.086628
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker == type(object)
    print("_LazyModuleMarker is tested successfully!!!")

if __name__ == "__main__":

    # Unit test for constructor of class NonLocal
    try:
        test__LazyModuleMarker()
    except AssertionError as e:
        print("Wrong Answer!")
    else:
        print("Accepted!")

# Generated at 2022-06-24 02:53:40.181781
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy.
    """
    def _test_lazy_import(module_path):
        """
        Test the function make_lazy.
        """
        make_lazy(module_path)
        module = sys.modules[module_path]
        if isinstance(module, _LazyModuleMarker):
            assert not hasattr(module, '__file__')
            assert not hasattr(module, '__path__')
        else:
            assert hasattr(module, '__file__')
            assert hasattr(module, '__path__')

    module_path = 'deeptables.models.preprocess'

    _test_lazy_import(module_path)
    print("Function make_lazy passed.")

# Generated at 2022-06-24 02:53:44.982247
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    print(mod)
    assert isinstance(mod, object)
    assert isinstance(mod, _LazyModuleMarker)
    assert not isinstance(mod, ModuleType)
    assert not isinstance(mod, types.ModuleType)

# Generated at 2022-06-24 02:53:47.331228
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class test(_LazyModuleMarker):
          pass
    assert isinstance(test(), _LazyModuleMarker)

# Generated at 2022-06-24 02:53:49.991539
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_module = _LazyModuleMarker()
    if not isinstance(test_module, _LazyModuleMarker):
        raise RuntimeError('Invalid constructor of _LazyModuleMarker')

# Generated at 2022-06-24 02:53:53.305196
# Unit test for function make_lazy
def test_make_lazy():
    def create_lazy_module_and_import():
        module_path = 'test.test_make_lazy'
        module = sys.modules[module_path]
        assert isinstance(module, _LazyModuleMarker)
        assert module.foo == 'bar'

    # Clear the module from sys.modules or else it won't get replaced.
    module_path = 'test.test_make_lazy'
    sys.modules.pop(module_path, None)
    make_lazy(module_path)
    create_lazy_module_and_import()
    # Module should be in sys.modules after first import.
    module = sys.modules[module_path]
    assert not isinstance(module, _LazyModuleMarker)
    assert module.foo == 'bar'



# Generated at 2022-06-24 02:53:56.615486
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        a = NonLocal('value')
        assert a.value == 'value', 'NonLocal should set value properly!'
    except AttributeError:
        return False

    return True



# Generated at 2022-06-24 02:54:02.163116
# Unit test for function make_lazy
def test_make_lazy():
    import unittest

    class MakeLazyTests(unittest.TestCase):
        def test_func_and_class(self):
            import sys
            import test_make_lazy
            from inspect import isfunction
            from inspect import isclass

# Generated at 2022-06-24 02:54:05.138478
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(12)
    assert a.value == 12


# Generated at 2022-06-24 02:54:09.597552
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
   try:
      a = _LazyModuleMarker()
   except TypeError as e:
      print("Raise error : ", e)
   except Exception as e:
      print("Raise exception : ", e)
   else:
      print("pass test__LazyModuleMarker")


if __name__ == '__main__':
   test__LazyModuleMarker()

# Generated at 2022-06-24 02:54:17.222317
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["test"] = object()
    make_lazy("test")
    assert isinstance(sys.modules["test"], _LazyModuleMarker)
    assert not hasattr(sys.modules["test"], "__mro__")
    assert "test" not in sys.modules
    sys.modules["test"].__mro__()
    assert "test" in sys.modules
    assert not isinstance(sys.modules["test"], _LazyModuleMarker)
    assert hasattr(sys.modules["test"], "__mro__")
    del sys.modules["test"]



# Generated at 2022-06-24 02:54:18.952850
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert(nl.value == None)


# Generated at 2022-06-24 02:54:25.822786
# Unit test for function make_lazy
def test_make_lazy():
    mod_name = "exam_lazy_mod"
    mod_path = "exams.exam_lazy_mod"
    try:
        del sys.modules["exams.exam_lazy_mod"]
    except KeyError:
        pass
    try:
        del sys.modules[mod_name]
    except KeyError:
        pass
    make_lazy(mod_path)
    assert mod_path in sys.modules
    lazy_mod = sys.modules[mod_path]
    assert isinstance(lazy_mod, _LazyModuleMarker)
    assert "foo" not in lazy_mod.__dict__
    assert lazy_mod.foo == "bar"
    assert "foo" in lazy_mod.__dict__


if __name__ == "__main__":
    test_make_

# Generated at 2022-06-24 02:54:28.532889
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:54:29.916289
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)


# Generated at 2022-06-24 02:54:39.377413
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_module'] = None
    make_lazy('test_module')

    # check that the module was marked as lazy
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)

    # check that we can __getattribute__ off the module
    # without importing it
    assert sys.modules['test_module'].__getattribute__

    # check that we can __getattribute__ off the module
    # without importing it
    assert sys.modules['test_module'].__getattribute__

    # check that we can __getattribute__ off the module
    # without importing it
    assert sys.modules['test_module'].__getattribute__

    # check that we can __getattribute__ off the module
    # without importing it
    assert sys.modules['test_module'].__getattribute__

# Generated at 2022-06-24 02:54:43.432645
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1
    assert NonLocal("a").value == "a"
    assert NonLocal(1.0).value == 1.0
    class Foo:
        pass
    assert NonLocal(Foo()).value == Foo()


# Generated at 2022-06-24 02:54:46.962867
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 'test'
    assert nl.value == 'test'

    nl2 = NonLocal(None)
    nl2.value = 'test2'
    assert nl2.value == 'test2'


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:54:48.096280
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5



# Generated at 2022-06-24 02:54:55.792735
# Unit test for function make_lazy
def test_make_lazy():
    # module to import
    test_mod_has_foo_bar = ModuleType('test_mod_has_foo_bar')
    test_mod_has_foo_bar.foo = 1
    test_mod_has_foo_bar.bar = 2

    # module to import before the lazyimport is called.
    test_mod_has_only_bar = ModuleType('test_mod_has_only_bar')
    test_mod_has_only_bar.bar = 2
    sys.modules['test_mod_has_only_bar'] = test_mod_has_only_bar

    # module to import that doesn't have foo or bar
    test_mod_has_only_bing = ModuleType('test_mod_has_only_bing')
    test_mod_has_only_bing.bing = 'bong'

# Generated at 2022-06-24 02:55:00.607930
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    module_path = 'pocshell.utils.test_lazy'
    make_lazy(module_path)

    import pocshell.utils.test_lazy
    assert isinstance(pocshell.utils.test_lazy, _LazyModuleMarker)

    assert pocshell.utils.test_lazy.TEST_LAZY_VARIABLE == 'hello'

# Generated at 2022-06-24 02:55:03.106143
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Because __init__ is not defined in _LazyModuleMarker, by default,
    # the instance of _LazyModuleMarker is initialized with no parameter.
    assert type(_LazyModuleMarker()) == _LazyModuleMarker



# Generated at 2022-06-24 02:55:05.032454
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_value = NonLocal(None)
    nonlocal_value.value = 42
    assert nonlocal_value.value == 42

# Generated at 2022-06-24 02:55:08.602827
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    print(nl.value)
    print(nl.__slots__)
    print(nl.__dict__)
    print(nl.__doc__)
    
test_NonLocal()

# Test of class LazyModule and its instantiation

# Generated at 2022-06-24 02:55:15.444597
# Unit test for function make_lazy
def test_make_lazy():
    def import_hook(name, globals=None, locals=None, fromlist=(), level=0):
        raise ImportError("make_lazy caught the import")

    old_import_hook = sys.meta_path.pop()
    sys.meta_path.append(import_hook)
    try:
        make_lazy("a.b.c")
        assert isinstance(sys.modules["a.b.c"], _LazyModuleMarker)
        assert not hasattr(sys.modules["a.b.c"], "x")
        assert sys.modules["a.b.c"].x == 1
        assert hasattr(sys.modules["a.b.c"], "x")
    finally:
        sys.meta_path.pop()
        sys.meta_path.append(old_import_hook)

# Generated at 2022-06-24 02:55:17.333466
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # When
    x = _LazyModuleMarker()
    # Then
    assert isinstance(x, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:24.907421
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy function works.
    """
    import os
    make_lazy('os')
    # do something with os
    os.path.abspath('.')
    # check that the module is reloaded
    os.path.abspath('.')

    # now check that we don't import the whole module.
    # this should fail if we are not lazy
    import os
    import os.path
    del sys.modules['os.path']
    sys.modules['os'].path()



# Generated at 2022-06-24 02:55:28.100935
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(4)
    assert nl.value == 4


# Generated at 2022-06-24 02:55:29.278779
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Act
    _LazyModuleMarker()


# Generated at 2022-06-24 02:55:36.390256
# Unit test for function make_lazy
def test_make_lazy():
    """ Test make_lazy function
    """
    import pkg_resources

    module_path = 'pkg_resources'
    make_lazy(module_path)

    from pkg_resources import __name__ as pkg_name
    from pkg_resources import __version__ as pkg_version

    assert pkg_name == 'pkg_resources'
    assert pkg_version == pkg_resources.__version__


# Generated at 2022-06-24 02:55:47.015914
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """

# Generated at 2022-06-24 02:55:48.909563
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_var = NonLocal(1)
    assert my_var.value == 1


# Generated at 2022-06-24 02:55:53.913660
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Foo():
        q = NonLocal(9)
        def __init__(self, q):
            self.q = q

    foo = Foo(3)
    assert foo.q == 3
    assert Foo.q.value == 9


# Generated at 2022-06-24 02:56:05.089956
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert repr(_LazyModuleMarker) == "<class '__main__._LazyModuleMarker'>"
    assert str(_LazyModuleMarker) == "<class '__main__._LazyModuleMarker'>"
    assert _LazyModuleMarker.__doc__ == 'A marker to indicate a LazyModule type.\n    Allows us to check module\'s with `isinstance(mod, _LazyModuleMarker)`\n    to know if the module is lazy.'
    setattr(_LazyModuleMarker, '__name__', '_LazyModuleMarker')
    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'
    assert _LazyModuleMarker.__module__ == '__main__'
    assert _LazyModuleMarker.__bases__ == ()

# Generated at 2022-06-24 02:56:07.449089
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:56:13.624265
# Unit test for constructor of class NonLocal
def test_NonLocal():

    # Testing for constructor
    def test_constructor():
        a = NonLocal(5)
        # this_module.a = a

        assert a.value == 5
        # assert this_module.a.value == 5

    test_constructor()

# Generated at 2022-06-24 02:56:16.438587
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    '''
    >>> import types
    >>> d = _LazyModuleMarker()
    >>> isinstance(d, types.ModuleType)
    False
    >>> isinstance(d, _LazyModuleMarker)
    True
    '''



# Generated at 2022-06-24 02:56:22.662241
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    def is_imported(module_path):
        return module_path in sys.modules

    def import_module(module):
        return __import__(module)

    # we don't want to import os.path or os.path.normpath
    assert len(sys.modules) == 0
    assert not is_imported('os.path')
    assert not is_imported('os.path.normpath')
    make_lazy('os.path')

    # Make sure the marker is working to validate isinstance
    assert isinstance(import_module('os.path'), _LazyModuleMarker)

    # Make sure the module is still not imported
    assert len(sys.modules) == 0
    assert not is_imported('os.path')

# Generated at 2022-06-24 02:56:25.406791
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5
    a.value = 6
    assert a.value == 6


# Generated at 2022-06-24 02:56:27.915329
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    lazy_module = _LazyModuleMarker()
    assert lazy_module is not None

# Generated at 2022-06-24 02:56:34.882899
# Unit test for function make_lazy
def test_make_lazy():
    foo = 'pytest_faux_module'
    sys.modules[foo] = None
    make_lazy(foo)
    assert isinstance(sys.modules[foo], _LazyModuleMarker)
    assert not hasattr(sys.modules[foo], '__mro__')
    assert sys.modules[foo].__getattribute__
    assert sys.modules[foo].__getattr__
    assert foo in sys.modules
    assert sys.modules[foo]
    del sys.modules[foo]

# Generated at 2022-06-24 02:56:38.273343
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert nl.value == 10
    nl.value = 42
    assert nl.value == 42


# Generated at 2022-06-24 02:56:46.474216
# Unit test for function make_lazy
def test_make_lazy():
    # Tests that we can set a module to be lazy, import it as if it were not
    # lazy, then later access a value created when it was imported.
    import test_make_lazy.test_module
    make_lazy('test_make_lazy.test_module')
    import test_make_lazy.test_module
    test_make_lazy.test_module.do_something()
    assert test_make_lazy.test_module.something, \
        'Expected something to be set'

# Generated at 2022-06-24 02:56:50.099979
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl is not None
    nl.value = 10
    assert nl.value == 10
    assert nl.value is not None



# Generated at 2022-06-24 02:56:56.131688
# Unit test for function make_lazy
def test_make_lazy():
    import six
    test_sys = sys.modules

    module_name = 'six'
    assert module_name in sys.modules

    make_lazy(module_name)

    # Call module again and make sure it is LazyModule type
    six = sys.modules[module_name]
    assert isinstance(six, _LazyModuleMarker)

    assert sys.modules == test_sys

# Generated at 2022-06-24 02:56:59.314614
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    names = ['x', 'y', 'z']
    for name in names:
        attribute = getattr(_LazyModuleMarker, name)
        assert isinstance(attribute, _LazyModuleMarker)


# Generated at 2022-06-24 02:57:02.880932
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker,_LazyModuleMarker)

# Generated at 2022-06-24 02:57:12.658613
# Unit test for function make_lazy
def test_make_lazy():
    original_modules = sys.modules.copy()

    # Test that it works with the bare minimum
    class FakeMod(ModuleType):
        pass

    FakeMod.__name__ = 'fake_mod'
    sys.modules['fake_mod'] = FakeMod()
    assert isinstance(sys.modules['fake_mod'], _LazyModuleMarker)
    del sys.modules['fake_mod']

    # Test that it works with attributes
    sys.modules['fake_mod'] = FakeMod()
    sys.modules['fake_mod'].foo = 'bar'
    assert isinstance(sys.modules['fake_mod'], _LazyModuleMarker)
    del sys.modules['fake_mod']

    # Test that it works with a submodule
    sys.modules['fake_mod'] = FakeMod()

# Generated at 2022-06-24 02:57:16.616273
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    with pytest.raises(AttributeError):
        _LazyModuleMarker.value


# Generated at 2022-06-24 02:57:21.362521
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from types import ModuleType

    assert 'test_mod_a' not in sys.modules

    mod = make_lazy('test_mod_a')
    assert mod != None

    assert 'test_mod_a' in sys.modules

    # Check if instance was lazy loaded
    assert isinstance(mod, _LazyModuleMarker)

    # Check if instance is also a module
    assert isinstance(mod, ModuleType)

    # Check if an attribute imported
    assert mod.var1 == "module_a_val"



# Generated at 2022-06-24 02:57:22.918120
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker())



# Generated at 2022-06-24 02:57:25.671034
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the constructor of class _LazyModuleMarker
    """
    lmm = _LazyModuleMarker()
    assert isinstance(lmm, _LazyModuleMarker), "Class _LazyModuleMarker doesn't work"


# Generated at 2022-06-24 02:57:29.843871
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if (NonLocal(1).value == 1):
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-24 02:57:31.174652
# Unit test for constructor of class NonLocal
def test_NonLocal():
    marker = NonLocal(8)
    assert marker.value == 8


# Generated at 2022-06-24 02:57:33.190616
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonLocal = NonLocal(3)
    assert nonLocal.value == 3


# Generated at 2022-06-24 02:57:38.789186
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import numpy as np
    assert isinstance(np, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:41.587384
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        NonLoc = NonLocal('not_none')
        assert(NonLoc.value == 'not_none')
    except:
        assert(False)



# Generated at 2022-06-24 02:57:50.228749
# Unit test for function make_lazy
def test_make_lazy():
    assert 'sqlparse' not in sys.modules
    sys.modules['sqlparse'] = 'cached value'

    make_lazy('sqlparse')

    assert isinstance(sys.modules['sqlparse'], _LazyModuleMarker)
    assert sys.modules['sqlparse'].__dict__ == {}

    # Cached value should not be overwritten yet
    assert sys.modules['sqlparse'] == 'cached value'

    # When an attribute is looked up on the module, it should actually
    # import it, and replace the value in sys.modules.
    assert sys.modules['sqlparse'].python_version_tuple == sys.version_info[:3]
    assert 'sqlparse' in sys.modules
    assert isinstance(sys.modules['sqlparse'], ModuleType)

# Generated at 2022-06-24 02:57:53.570743
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("test_module")
    assert sys.modules["test_module"] is not None
    assert isinstance(sys.modules["test_module"], _LazyModuleMarker)

# Generated at 2022-06-24 02:57:58.239305
# Unit test for function make_lazy
def test_make_lazy():
    pdb=make_lazy('pdb')

# Generated at 2022-06-24 02:58:00.256194
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Testing constructor of _LazyModuleMarker
    """
    assert type(_LazyModuleMarker()) == _LazyModuleMarker


# Generated at 2022-06-24 02:58:09.307479
# Unit test for function make_lazy
def test_make_lazy():
    from . import importer

    make_lazy(__package__ + '.importer')

    # Test the function itself
    assert importer.function() == 'function'
    assert importer.function() == 'function'

    # Test the class
    obj = importer.Class()
    assert obj.class_function() == 'function'
    assert obj.class_function() == 'function'

    # Test the instance, which includes a __getattr__ method
    obj2 = importer.Class2()
    assert obj2.function() == 'function'
    assert obj2.function() == 'function'

    # Class with a __init__ that actually does something
    obj3 = importer.Class3(1, 2, 3)
    assert obj3.a == 1
    assert obj3.b == 2

# Generated at 2022-06-24 02:58:14.520832
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(None)
    assert None == nonlocal_obj.value



# Generated at 2022-06-24 02:58:25.524546
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure that we can import a module that we marked as lazy
    make_lazy('os')
    assert isinstance(sys.modules['os'], _LazyModuleMarker)
    import os
    assert os.path.abspath('.') == os.path.abspath('.')

    # Test that we can use decorated modules inside of functions
    def test_function(mod):
        return mod.path.abspath('.')

    make_lazy('os.path')
    assert test_function(sys.modules['os.path']) == test_function(sys.modules['os.path'])

    # Test that we can use decorated modules inside of classes
    class TestClass(object):
        def test_method(self):
            return sys.modules['os.path'].abspath('.')


# Generated at 2022-06-24 02:58:33.634496
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import inspect
    import pytest

    nl1 = NonLocal(1)
    
    assert nl1.value == 1
    assert nl1.__class__.__name__ == 'NonLocal'

    nl2 = NonLocal(2)
    assert nl2.value == 2
    assert nl2.__class__.__name__ == 'NonLocal'

    print('Who am I?', nl1.__class__)


# Generated at 2022-06-24 02:58:39.062632
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import tempfile
    import sys

    def make_dir_and_file(dir_name, file_name, contents):
        # make directory
        os.mkdir(dir_name)

        # make file
        path = os.path.join(dir_name, file_name)
        with open(path, 'w') as f:
            f.write(contents)

        return path

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-24 02:58:40.964348
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    if (x.value == 3):
        return 0
    else:
        return -1


# Generated at 2022-06-24 02:58:47.848560
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('_test_lazy_module')

    # import as normal:
    from _test_lazy_module import test_attribute
    assert test_attribute() == "TEST_ATTRIBUTE_VALUE"

    # import lazily:
    test_module = sys.modules['_test_lazy_module']
    assert test_module.test_attribute() == "TEST_ATTRIBUTE_VALUE"
    assert isinstance(test_module, _LazyModuleMarker)
    assert not isinstance(test_module, ModuleType)

# Generated at 2022-06-24 02:58:53.404358
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the functionality of make_lazy
    """
    import subprocess
    # Remove the module from sys.modules if its already imported.
    if subprocess.__name__ in sys.modules:
        del sys.modules[subprocess.__name__]
    # Mark subprocess lazy
    make_lazy(subprocess.__name__)
    # Test that the marked module is actually lazy.
    assert not hasattr(subprocess, '_active')

    # Import some attribute off of subprocess to load it.
    subprocess.Popen

    # Test that the module has been loaded.
    assert hasattr(subprocess, 'Popen')
    assert hasattr(subprocess, '_active')
    assert subprocess.Popen

# Generated at 2022-06-24 02:58:56.566228
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import types
    it = _LazyModuleMarker
    assert it is not None
    assert it is not types.ModuleType
    assert it is not sys.modules


# Generated at 2022-06-24 02:59:00.699180
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Initialize nl with value
    nl = NonLocal(2)

    # Test assignment of nl.value
    assert nl.value == 2

    # Test that nl can be reassigned
    nl.value = 1
    assert nl.value == 1

    # Test that nl.value can be reassigned
    nl.value = 2
    assert nl.value == 2

# Generated at 2022-06-24 02:59:02.779720
# Unit test for constructor of class NonLocal
def test_NonLocal():
    f = NonLocal(1)
    assert f.value == 1



# Generated at 2022-06-24 02:59:05.458227
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-24 02:59:13.722899
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy().
    """
    old_value = sys.modules.copy()
    print(old_value)
    def test_lazy_function():
        """
        Test if the module is successfully marked as lazy.
        """
        make_lazy('sys')
        assert isinstance(sys, ModuleType)

    def test_lazy_function():
        """
        Test if the module can be imported when attributes are needed.
        """
        try:
            make_lazy('os')
            assert sys
        except AttributeError:
            assert False
        assert isinstance(sys, ModuleType)

    test_lazy_function()
    test_lazy_function()
    assert old_value == sys.modules

if __name__ == '__main__':
    test_make_l

# Generated at 2022-06-24 02:59:22.981489
# Unit test for function make_lazy
def test_make_lazy():
    mod_path = 'make_lazy_test_mod'

    # Non-existent module should return True when calling isinstance
    make_lazy(mod_path)
    mod = sys.modules[mod_path]

    assert isinstance(mod, _LazyModuleMarker)
    assert isinstance(mod, ModuleType)
    assert mod_path in sys.modules

    # Creating the test module
    path = os.path.join(os.path.dirname(__file__), 'make_lazy_test_mod.py')
    test_file = open(path, 'w')
    test_file.write('test_var = 1')
    test_file.close()

    # Should return False when calling isinstance
    import make_lazy_test_mod  # noqa
    make_lazy(mod_path)

# Generated at 2022-06-24 02:59:24.898219
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    test _LazyModuleMarker
    """
    obj = _LazyModuleMarker()
    assert obj


# Generated at 2022-06-24 02:59:28.496233
# Unit test for function make_lazy
def test_make_lazy():
    import six.moves.queue
    make_lazy('six.moves.queue')
    assert isinstance(six.moves.queue, _LazyModuleMarker)

    # Ensure imports and loads work normally

    # Imports work
    from six.moves import queue
    # Loads work
    assert queue.Queue()

# Generated at 2022-06-24 02:59:31.537858
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(3)
    assert value.value == 3


# Generated at 2022-06-24 02:59:33.389751
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(2)
    assert x.value == 2
    x.value += 1
    assert x.value == 3



# Generated at 2022-06-24 02:59:35.995352
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker=_LazyModuleMarker()
    assert isinstance(marker,_LazyModuleMarker)
    assert not isinstance(marker,ModuleType)

# Generated at 2022-06-24 02:59:38.325964
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Check for a class constructor exception.
    try:
        _LazyModuleMarker()
    except:
        assert False, 'Exception during __init__().'
    

# Generated at 2022-06-24 02:59:40.160778
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Checks the constructor of class _LazyModuleMarker.
    """
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 02:59:45.968826
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info[0] == 2:
        make_lazy('{}'.format)
        # Will pass import as function is not used
        from .format import some_function
        pyformat_module = sys.modules[some_function.__module__]
        # Will fail unit test as import is needed
        assert isinstance(pyformat_module, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:47.517203
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_equal(type(_LazyModuleMarker()), _LazyModuleMarker)


# Generated at 2022-06-24 02:59:51.770882
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = LazyModule()
    assert isinstance(test, _LazyModuleMarker)
    assert isinstance(test, ModuleType)
    assert isinstance(test, object)
    assert issubclass(LazyModule, _LazyModuleMarker)
    assert issubclass(LazyModule, ModuleType)
    assert issubclass(LazyModule, object)

# Generated at 2022-06-24 03:00:00.311761
# Unit test for function make_lazy
def test_make_lazy():
    # Test make_lazy in a new context
    # since it uses `sys.modules`
    import os
    import sys
    import tempfile

    sys.modules.pop('test_make_lazy', None)  # Just in case
    sys.modules.pop('test_make_lazy.temp', None)  # Just in case

    fd, path = tempfile.mkstemp()
    proc = os.fdopen(fd, 'w')
    proc.write('temp = "temp"')
    proc.close()

    make_lazy('test_make_lazy.temp')

    from test_make_lazy import temp as inner_temp
    from test_make_lazy import temp as inner_temp2

    assert inner_temp == inner_temp2 == 'temp'
    os.remove(path)




# Generated at 2022-06-24 03:00:05.270769
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # check whether it can construct
    x = NonLocal(None)
    assert isinstance(x, NonLocal), 'NonLocal object is not constructed successfully'
    # check that the initialize value is correct and can be assigned again
    x.value = 'new value'
    assert x.value == 'new value', 'the initialized value of NonLocal is not correct'
    return


# Generated at 2022-06-24 03:00:06.509776
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(None)
    assert n.value is None



# Generated at 2022-06-24 03:00:09.824701
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__ == "_LazyModuleMarker"
    assert _LazyModuleMarker.__doc__ == "A marker to indicate a LazyModule type."
    assert _LazyModuleMarker.__dict__ == {}


# Generated at 2022-06-24 03:00:11.822755
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert(isinstance(lazy_module, object))


# Generated at 2022-06-24 03:00:16.283831
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert m is not None


# Generated at 2022-06-24 03:00:23.516373
# Unit test for function make_lazy
def test_make_lazy():
    # Create a test module to lazyload off of.
    module_path = 'lazyloadtest.foo'
    module = sys.modules[module_path] = ModuleType(module_path)
    module.foo = 'foo'

    # Create the lazy version of the module.
    make_lazy(module_path)

    # Check that it is lazy
    assert isinstance(module, _LazyModuleMarker), 'is lazy'

    # Check that we cannot access the module's members
    # before we actually import the module
    try:
        module.foo
    except AttributeError:
        pass
    else:
        assert False, 'Module is not accessible before import'

    # Check that we can access the module's members
    # after we import the module
    module.foo

# Generated at 2022-06-24 03:00:34.691949
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # This test is mainly for making sure that the isinstance(mod, _LazyModuleMarker) check is working
    # and that we can assert lazy modules.
    import imp
    import os
    import types

    # Create a test module and make it lazy
    file_handle = open("./test_module.py", "w")
    file_handle.write("def func(): return 'foo'\n")
    file_handle.close()

    module_info = imp.find_module('test_module', [os.getcwd()])

    # Sanity
    assert isinstance(module_info[0], types.FileType)

    mod = imp.load_module('test_module', module_info[0], module_info[1], module_info[2])

    # Sanity

# Generated at 2022-06-24 03:00:40.142367
# Unit test for function make_lazy
def test_make_lazy():
    import igor

    assert isinstance(igor, _LazyModuleMarker)
    assert isinstance(igor, ModuleType)
    assert isinstance(igor, object)  # Need to fool isinstance
    assert not hasattr(igor, 'utils')

    igor.utils.get_logger()

    assert hasattr(igor, 'utils')
    assert hasattr(igor, 'utils')
    assert isinstance(igor, ModuleType)
    assert isinstance(igor, object)  # Need to fool isinstance

# Generated at 2022-06-24 03:00:41.733753
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 03:00:48.861535
# Unit test for function make_lazy
def test_make_lazy():
    def mock_import(name):
        import types
        mod = types.ModuleType(name)
        mod.attr = 1
        return mod

    def mock_import_notfound(name):
        raise ImportError

    import sys
    import re

# Generated at 2022-06-24 03:00:51.394832
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Constructor of NonLocal class should set the value
    # of the variable NonLocal.value to the argument
    # passed in
    test_nonlocal = NonLocal(55)
    assert test_nonlocal.value == 55



# Generated at 2022-06-24 03:00:58.660353
# Unit test for function make_lazy
def test_make_lazy():
    import os
    module = make_lazy('os')
    assert os is module
    assert not isinstance(os, _LazyModuleMarker)
    assert isinstance(os, ModuleType)

    assert os.path is None
    assert isinstance(os, _LazyModuleMarker)
    assert isinstance(os, ModuleType)

    assert os.path.abspath is not None
    assert not isinstance(os, _LazyModuleMarker)
    assert isinstance(os, ModuleType)

# Generated at 2022-06-24 03:01:08.409650
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy implemets the lazy import functionality.
    """

    try:
        import test_make_lazy_data
    except ImportError:
        print("test_make_lazy_data.py not found. Please add it to your path")
        raise

    try:
        make_lazy('test_make_lazy_data')

        import test_make_lazy_data as data
        assert isinstance(data, _LazyModuleMarker)

        data.number = 5
        assert test_make_lazy_data.number == 5

        assert not isinstance(test_make_lazy_data, _LazyModuleMarker)
    finally:
        # Clean up sys.modules
        del sys.modules['test_make_lazy_data']

# Generated at 2022-06-24 03:01:11.601791
# Unit test for function make_lazy
def test_make_lazy():
    import this
    module_path = "this"
    make_lazy(module_path)

# Generated at 2022-06-24 03:01:13.830274
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), object))


# Generated at 2022-06-24 03:01:19.467606
# Unit test for constructor of class NonLocal
def test_NonLocal():
    get_val = NonLocal(0)
    get_val.value = 1
    assert get_val.value == 1

# Generated at 2022-06-24 03:01:21.142825
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(2)
    assert nl.value == 2



# Generated at 2022-06-24 03:01:22.721999
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 03:01:30.795920
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    sys.modules['foo'] = None
    make_lazy('foo')

    foo = sys.modules['foo']
    assert foo.__name__ == 'foo'
    assert foo.__doc__ is None
    assert foo.__path__ is None
    assert foo.__file__ is None
    assert foo.__all__ is None
    assert not hasattr(foo, 'os')
    assert not hasattr(foo, 'sys')

    foo.os = os
    assert foo.os is os
    assert hasattr(foo, 'os')

    del sys.modules['foo']

# Generated at 2022-06-24 03:01:33.821330
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(10)
    assert test.value == 10, 'NonLocal should be 10'


# Generated at 2022-06-24 03:01:36.356271
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # create an instance of NonLocal
    nl = NonLocal("str")
    # test __init__ method
    assert nl.value == "str", "incorrect init method"


# Generated at 2022-06-24 03:01:38.267993
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(10)
    assert t.value == 10


# Generated at 2022-06-24 03:01:39.445039
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker()

# Generated at 2022-06-24 03:01:48.747286
# Unit test for function make_lazy
def test_make_lazy():
    def test():
        module_path = "django.core.management"
        # The module should not be imported
        assert(module_path not in sys.modules)
        make_lazy(module_path)
        # The module has been imported
        assert(module_path in sys.modules)
        # The module is lazy
        assert(isinstance(sys.modules[module_path], _LazyModuleMarker))
        # Now we access it
        assert(sys.modules[module_path].VERSION == (1, 6, 5, 'final', 0))

        try:
            del sys.modules[module_path]
        except KeyError:
            pass

    return test

# Generated at 2022-06-24 03:01:50.083541
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()

    assert marker is not None


# Generated at 2022-06-24 03:01:59.401505
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the expected module is created.
    """

    import tempfile
    import shutil
    import atexit

    from distutils.sysconfig import get_python_lib
    from distutils.core import setup

    package_dir = tempfile.mkdtemp()

    setup(name="test_lazy_module",
          version="0.0.0",
          description="A test for lazy modules",
          author="Test Author",
          author_email="test@test.com",
          packages=["test_lazy_module"],
          package_dir={"test_lazy_module": "src"})

    sys.path.append(package_dir)

    test_file_name = os.path.join(package_dir, "src", "test_lazy_module.py")
    submodule_file_name

# Generated at 2022-06-24 03:02:01.394182
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = 314159

    test_nonlocal = NonLocal(test_value)

    assert test_nonlocal.value == test_value



# Generated at 2022-06-24 03:02:09.951634
# Unit test for function make_lazy
def test_make_lazy():
    # create fake modules
    test_m1 = sys.modules.get('m1')
    test_m2 = sys.modules.get('m2')
    sys.modules['m1'] = test_m1 = type('m1', (ModuleType,), {})()
    sys.modules['m2'] = test_m2 = type('m2', (type('m3', (ModuleType,), {}),), {})()

    test_m1.attr = 1
    test_m2.attr = 2

    assert sys.modules.get('m1') is test_m1
    assert sys.modules.get('m2') is test_m2

    # lazy import the module
    make_lazy('m1')
    make_lazy('m2')

    # test that it is a LazyModule
    assert isinstance

# Generated at 2022-06-24 03:02:10.873504
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t=NonLocal(1)
    assert t.value==1

# Generated at 2022-06-24 03:02:21.215326
# Unit test for function make_lazy
def test_make_lazy():
    def lazy_module_loaded_properly(module_path):
        sys.modules.pop(module_path, None)
        make_lazy(module_path)
        mod = sys.modules[module_path]
        assert isinstance(mod, _LazyModuleMarker)
        assert hasattr(mod, 'foo')
        assert mod.foo == 'bar'

    class pkg1(object):
        mod = 'pkg1.mod'
        pkg2 = 'pkg1.pkg2'

    class mod(object):
        foo = 'bar'

    make_lazy(pkg1.mod)
    make_lazy(pkg1.pkg2)
    assert isinstance(sys.modules[pkg1.mod], _LazyModuleMarker)

# Generated at 2022-06-24 03:02:31.454472
# Unit test for function make_lazy
def test_make_lazy():
    import inspect
    import random
    import string


# Generated at 2022-06-24 03:02:32.684580
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(_LazyModuleMarker)


# Generated at 2022-06-24 03:02:34.352290
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """Test case: test__LazyModuleMarker"""
    _LazyModuleMarker()



# Generated at 2022-06-24 03:02:44.400615
# Unit test for function make_lazy
def test_make_lazy():
    global sys  # pull in module-level version
    try:
        import cStringIO
    except ImportError:
        # cStringIO not present. Skip test
        return

    sys_modules = sys.modules  # cache in the locals
    sys_modules_before = dict(sys_modules)

    stderr = sys.stderr  # store module-level global
    sys.modules['sys'].stderr = cStringIO.StringIO()  # hide stderr

    module_path = '__test_make_lazy__'

    module = """
    def f():
        return 'foo'
    """
    module = compile(module, '<string>', 'exec')  # compile module code

    # create a fake module
    sys_modules[module_path] = types.ModuleType(module_path)

   

# Generated at 2022-06-24 03:02:47.407940
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:02:55.132852
# Unit test for function make_lazy
def test_make_lazy():
    assert 'make_lazy' not in sys.modules
    assert sys.modules['make_lazy'] is None
    import make_lazy
    assert isinstance(sys.modules['make_lazy'], _LazyModuleMarker)
    assert sys.modules['make_lazy'].__name__ == 'make_lazy'
    assert sys.modules['make_lazy'].__file__.endswith('make_lazy.pyc')

    reload(make_lazy)
    assert isinstance(sys.modules['make_lazy'], _LazyModuleMarker)
    assert sys.modules['make_lazy'].__name__ == 'make_lazy'
    assert sys.modules['make_lazy'].__file__.endswith('make_lazy.pyc')

# Generated at 2022-06-24 03:03:02.938226
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest
    import sys
    import __main__

    class Test__LazyModuleMarker(unittest.TestCase):
        utility = None

        @classmethod
        def setUpClass(cls):
            cls.utility = _LazyModuleMarker()

        @classmethod
        def tearDownClass(cls):
            pass

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__mro__(self):
            self.assertIsInstance(self.utility, _LazyModuleMarker)

        def test__getattribute__(self):
            self.assertEqual(make_lazy.__name__, "make_lazy")


# Generated at 2022-06-24 03:03:06.250587
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) == _LazyModuleMarker()


# Generated at 2022-06-24 03:03:06.831182
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test = NonLocal(5)
    assert test.value == 5


# Generated at 2022-06-24 03:03:07.708094
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-24 03:03:14.541895
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import __fake_sys_modules__
        sys.modules = __fake_sys_modules__.sys_modules
    except ImportError:
        pass

    if '__fake_sys_modules__' in sys.modules:
        import __fake_sys_modules__
        sys.modules = __fake_sys_modules__.sys_modules
    else:
        import tempfile, atexit
        import sys
        import os

        dirpath = tempfile.mkdtemp()
        os.mkdir(os.path.join(dirpath, '__fake_sys_modules__'))
        open(os.path.join(dirpath, '__init__.py'), 'w').close()
        open(os.path.join(dirpath, '__fake_sys_modules__', '__init__.py'), 'w').close

# Generated at 2022-06-24 03:03:15.354583
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value == 0

# Generated at 2022-06-24 03:03:21.191609
# Unit test for function make_lazy
def test_make_lazy():
    # Create fake modules to test against
    sys.modules["lazy_module"] = "lazy"
    sys.modules["not_lazy_module"] = "not lazy"

    # Test to make sure lazy module imports correctly
    make_lazy("lazy_module")

    assert sys.modules["lazy_module"] == "lazy"
    assert isinstance(sys.modules["lazy_module"], _LazyModuleMarker)

    make_lazy("not_lazy_module")

    assert sys.modules["not_lazy_module"] == "not lazy"
    assert isinstance(sys.modules["not_lazy_module"], _LazyModuleMarker)

    # Test to make sure lazy module imports correctly
    from lazy_module import foo
    from not_lazy_module import bar


# Generated at 2022-06-24 03:03:21.768647
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 03:03:23.124045
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_success(
        _LazyModuleMarker,
        is_class,
        has_attr('__mro__', is_callable)
    )



# Generated at 2022-06-24 03:03:24.668273
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("x")
    nl.value = "y"

    assert nl.value == "y"

# Generated at 2022-06-24 03:03:26.035195
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    print(obj)