

# Generated at 2022-06-24 02:53:28.382030
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a_non_local = NonLocal(None)

# Generated at 2022-06-24 02:53:39.285121
# Unit test for function make_lazy

# Generated at 2022-06-24 02:53:40.394855
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(123)
    y = NonLocal(456)



# Generated at 2022-06-24 02:53:51.501985
# Unit test for function make_lazy
def test_make_lazy():
    # Create a module to import
    # This is required to do this since the the module
    # will not be lazy loaded until `sys.modules` contains
    # the module name
    import pkgutil
    __import__('temp_mod')
    loader = pkgutil.get_loader('temp_mod')
    imp.reload(loader)

    make_lazy('temp_mod')  # Mark the module as lazy
    # import the module and make sure that we still get the
    # pkgutil loader.
    temp_mod = __import__('temp_mod')
    assert isinstance(temp_mod, _LazyModuleMarker)
    assert 'temp_mod' in sys.modules
    del sys.modules['temp_mod'] # clean up

# Generated at 2022-06-24 02:53:54.460151
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker) == True
    assert isinstance(_LazyModuleMarker, _LazyModuleMarker) == False


# Generated at 2022-06-24 02:54:00.719964
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from collections import Counter
    a = NonLocal(Counter())
    assert a.value == Counter()

if __name__ == '__main__':
    # create a module in the current namespace and make it lazy
    this_module = sys.modules[__name__]
    make_lazy(__name__)

    # Test that None is returned, as this module has not been loaded yet
    print(this_module.__doc__)

    # Now force the module to load itself. This should print the doc string
    # of the module, despite that we never imported it in
    print(this_module.__doc__)

# Generated at 2022-06-24 02:54:01.446897
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert isinstance(obj, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:03.465726
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('foo')
    assert 'foo' == nl.value


# Generated at 2022-06-24 02:54:08.107546
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker) == True)
    assert(isinstance(_LazyModuleMarker(), object) == True)
    assert(isinstance(_LazyModuleMarker(), type) == True)
    assert(isinstance(_LazyModuleMarker(), ModuleType) == False)
    assert(isinstance(sys.modules, _LazyModuleMarker) == False)


# Generated at 2022-06-24 02:54:10.351302
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # This test just makes sure the class is declared to guarantee
    # a level of confidence.
    obj = _LazyModuleMarker()


# Generated at 2022-06-24 02:54:14.052385
# Unit test for function make_lazy
def test_make_lazy():
    """
    Check that we can import a lazy module and use it's functionality.
    """
    make_lazy('pysys.constants.version')
    import pysys.constants
    assert pysys.constants.version.V2_1 == '2.1'
    assert pysys.constants.version.V2_0 == '2.0'
    assert isinstance(pysys.constants.version, _LazyModuleMarker)



# Generated at 2022-06-24 02:54:15.175739
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker


# Generated at 2022-06-24 02:54:24.363201
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class TestLazyModule(_LazyModuleMarker):
        def __init__(self, name):
            self.name = name

        def __getattribute__(self, attr):
            return '{}_{}'.format(self.name, attr)

    assert issubclass(TestLazyModule, _LazyModuleMarker)
    assert issubclass(TestLazyModule, type)
    assert issubclass(TestLazyModule, object)
    assert isinstance(TestLazyModule('abc'), TestLazyModule)

    test_lazy_module = TestLazyModule('abc')
    assert test_lazy_module.__mro__ == (TestLazyModule, _LazyModuleMarker, object)

    assert test_lazy_module.name == 'abc_name'
    assert test_lazy_module

# Generated at 2022-06-24 02:54:28.110052
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('abc')
    assert n.value == 'abc'
    n.value = 'xyz'
    assert n.value == 'xyz'


# Generated at 2022-06-24 02:54:32.533114
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        mod = _LazyModuleMarker()
        assert isinstance(mod, _LazyModuleMarker)
    except Exception:
        assert False, 'do not support _LazyModuleMarker constructor'


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:54:37.323995
# Unit test for function make_lazy
def test_make_lazy():
    pkg.foo.bar
    assert isinstance(pkg.foo, ModuleType)

    pkg.new.baz
    assert not isinstance(pkg.new, _LazyModuleMarker)
    assert isinstance(pkg.new, ModuleType)


make_lazy(pkg.__name__ + '.foo')
make_lazy(pkg.__name__ + '.new')

# Generated at 2022-06-24 02:54:39.713516
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = 'test'
    non_local = NonLocal(test_value)
    assert non_local.value == test_value


# Generated at 2022-06-24 02:54:43.370231
# Unit test for function make_lazy
def test_make_lazy():
    import __builtin__

    def test_it():
        # This should fail with an import error if 'os' was not lazy loaded.
        import os
        assert os is not None

    make_lazy('os')
    test_it()



# Generated at 2022-06-24 02:54:45.127963
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("hello")
    nl.value = "world"
    assert(nl.value == "world")


# Generated at 2022-06-24 02:54:47.737077
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This function aims at testing the __init__ function of _LazyModuleMarker
    :return: None
    """
    print("Testing __init__ function of _LazyModuleMarker")
    pass



# Generated at 2022-06-24 02:54:50.566921
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A:
        def __init__(self):
            self.a = 1
    assert(sys.modules[__name__] != A())


# Generated at 2022-06-24 02:54:51.837886
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker), "Did not construct _LazyModuleMarker correctly"

# Generated at 2022-06-24 02:55:02.174702
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    from unittest import TestCase
    import os
    import sys
    import tempfile

    class MakeLazyTest(TestCase):
        """
        Unit test for function make_lazy
        """
        @staticmethod
        def get_module(filename):
            """
            Get module
            """
            # pylint: disable=protected-access
            sys_modules = sys.modules.copy()
            path = os.path.dirname(filename)
            name = os.path.basename(filename).rsplit('.', 1)[0]
            filename = os.path.basename(filename)
            sys.path.insert(0, path)


# Generated at 2022-06-24 02:55:09.008589
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that make_lazy works as expected
    """
    sys.modules['foo'] = None
    try:
        mod = __import__('foo')
        assert not isinstance(mod, _LazyModuleMarker)
        make_lazy('foo')
        mod = __import__('foo')
        assert isinstance(mod, _LazyModuleMarker), type(mod)
        mod.__getattribute__('__module__') == 'foo'
        mod = __import__('foo')
        assert not isinstance(mod, _LazyModuleMarker)
    finally:
        del sys.modules['foo']



# Generated at 2022-06-24 02:55:10.114331
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

# Generated at 2022-06-24 02:55:16.267825
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(object):
        def __init__(self, a):
            pass

    non_local = NonLocal(Test(10))
    assert(non_local.value.__init__.__code__.co_argcount == 2)


# Generated at 2022-06-24 02:55:23.791478
# Unit test for function make_lazy
def test_make_lazy():
    """
    Check that the function make_lazy works as expected
    """
    assert 'lazy_test' not in sys.modules
    assert 'lazy_test' not in locals()
    assert 'lazy_test' not in globals()
    make_lazy('lazy_test')
    assert 'lazy_test' in sys.modules
    assert 'lazy_test' not in locals()
    assert 'lazy_test' not in globals()

# Generated at 2022-06-24 02:55:28.013545
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    actual = _LazyModuleMarker()
    assert isinstance(actual, _LazyModuleMarker)


# Generated at 2022-06-24 02:55:30.118745
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 02:55:33.024103
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:55:43.666978
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    import unittest

    class TestLazyModule(unittest.TestCase):
        def setUp(self):
            sys.modules.clear()
            self.module_path = 'test.module'

        def tearDown(self):
            import sys
            import types
            if 'test' in sys.modules:
                del sys.modules['test']

        def test_fetch_not_imported(self):
            make_lazy(self.module_path)

            self.assertTrue(self.module_path in sys.modules)
            self.assertFalse(self.module_path in types.ModuleType.__subclasses__())

        def test_fetch_attribute(self):
            make_lazy(self.module_path)


# Generated at 2022-06-24 02:55:46.620989
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()


# Generated at 2022-06-24 02:55:47.816845
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 02:55:49.384176
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:55:52.048722
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert a == a



# Generated at 2022-06-24 02:56:04.034630
# Unit test for function make_lazy
def test_make_lazy():
    class DummyModule(object):
        """
        A standin for a module to prevent it from being imported
        """
        pass

    module_path = 'dummy'
    sys_modules = sys.modules  # cache in the locals
    sys_modules[module_path] = DummyModule()

    # Mimic Django's reloading behavior
    # https://docs.djangoproject.com/en/1.3/releases/1.3/#load-order-and-python-s-sys-path-variable

# Generated at 2022-06-24 02:56:10.951433
# Unit test for function make_lazy
def test_make_lazy():
    """
    Mock the system modules table and test lazy loading.
    """
    sys_modules = {
        'test': None,
    }

    module_path = 'test'

    mod = NonLocal(None)
    make_lazy(module_path)
    assert isinstance(sys_modules[module_path], NonLocal)
    assert not mod.value
    try:
        getattr(sys_modules[module_path], 'foo')
        raise AssertionError('getattr should have failed')
    except AttributeError:
        pass

    sys_modules[module_path] = ModuleType('Mock test module')
    make_lazy(module_path)
    assert not mod.value

# Generated at 2022-06-24 02:56:12.849044
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os.path
    make_lazy('os.path')
    assert isinstance(os.path, _LazyModuleMarker)

test__LazyModuleMarker()

# Generated at 2022-06-24 02:56:13.954272
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import test
    reload(test)



# Generated at 2022-06-24 02:56:20.951801
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules.pop('path.to.my.module', None)
    make_lazy('path.to.my.module')
    assert 'path.to.my.module' not in sys.modules
    my_module = sys.modules['path.to.my.module']
    assert isinstance(my_module, _LazyModuleMarker)
    assert not hasattr(my_module, '__all__')
    assert hasattr(my_module, '__name__')
    assert not hasattr(my_module, '__file__')
    assert hasattr(my_module, '__path__')
    assert hasattr(my_module, '__doc__')

    assert 'path.to.my.module' == my_module.__name__
    assert [] == my_module.__path__
    assert None == my

# Generated at 2022-06-24 02:56:28.368047
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(LazyModule, _LazyModuleMarker) == True
    assert LazyModule.__mro__ == (LazyModule, ModuleType)
    assert LazyModule.__mro__[1] == ModuleType
    assert LazyModule.__mro__[0] == LazyModule
    assert LazyModule.__getattribute__ == LazyModule.__getattribute__
    assert LazyModule.__getattribute__ is not None


# Generated at 2022-06-24 02:56:31.085067
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(12)
    assert nl.value == 12
    nl.value = 18
    assert nl.value == 18

# Generated at 2022-06-24 02:56:34.035147
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class T(_LazyModuleMarker):
        def __init__(self):
            self.a = 1

    assert isinstance(T(), _LazyModuleMarker)


# Generated at 2022-06-24 02:56:35.126599
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-24 02:56:35.764817
# Unit test for constructor of class NonLocal
def test_NonLocal():
    pass

# Generated at 2022-06-24 02:56:38.673616
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert(isinstance(test_marker, _LazyModuleMarker))


# Generated at 2022-06-24 02:56:47.484460
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    assert 'dummy' not in sys.modules

    make_lazy('dummy')
    assert 'dummy' in sys.modules
    assert isinstance(sys.modules['dummy'], _LazyModuleMarker)
    assert 'dummy' not in sys.modules
    dummy = sys.modules['dummy']
    assert isinstance(dummy, type)

    dummy.__class__  # import the real module
    assert 'dummy' in sys.modules
    assert not isinstance(sys.modules['dummy'], _LazyModuleMarker)
    assert isinstance(sys.modules['dummy'], type)

    del sys.modules['dummy']

# Generated at 2022-06-24 02:56:58.657051
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    class Module:
        pass
    module_path = 'test.module'

    # Test that the module can be imported after adding it to the
    # sys.modules.
    sys.modules[module_path] = Module()
    assert module_path in sys.modules

    _lazy_path = 'tests.test_module_loading.LazyModule'
    # Test that a lazy module is created.
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Test that the module can be imported after adding it to the
    # sys.modules.
    sys.modules[module_path] = Module()
    assert module_path in sys.modules

# Generated at 2022-06-24 02:57:04.353458
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class test(object):
        def __init__(self, value):
            self.value = value

    test1 = test(1)
    test2 = NonLocal(2)

    assert test1.value == 1
    assert test2.value == 2


# Generated at 2022-06-24 02:57:11.289354
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that we can make a module lazy and then import it
    """
    mod = make_lazy("test_make_lazy")
    mod = importlib.import_module("test_make_lazy")
    assert hasattr(mod, "__mro__")
    assert callable(mod.__mro__)
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:14.941300
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert hasattr(_LazyModuleMarker(), '__mro__')
    assert hasattr(_LazyModuleMarker(), '__getattribute__')

    assert _LazyModuleMarker().__mro__() == (_LazyModuleMarker, ModuleType)


# Generated at 2022-06-24 02:57:16.749222
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert type(_LazyModuleMarker()) == _LazyModuleMarker


if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:57:17.807672
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyMarker = _LazyModuleMarker()
    assert isinstance(lazyMarker, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:23.265901
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    test_var = NonLocal(0)
    assert test_var.value == 0


# Generated at 2022-06-24 02:57:24.579514
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_variable = NonLocal(3)
    assert test_variable.value == 3


# Generated at 2022-06-24 02:57:26.633835
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert(nl.value == 1)
    nl.value = 2
    assert(nl.value == 2)


if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:57:37.442732
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules

    import json
    # Make sure we don't already have json
    assert 'json' not in sys_modules

    # Make sure that the json module is lazy
    make_lazy('json')

    # Make sure that we think that json is lazy
    assert isinstance(sys_modules['json'], _LazyModuleMarker)

    # Make sure that we can use the json module as usual
    j = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}])

    # Make sure that we don't think that json is lazy afterwards
    assert not isinstance(sys_modules['json'], _LazyModuleMarker)

    del sys_modules['json']


# Make sqlite3 lazy
make_lazy('sqlite3')

# Make sure that this

# Generated at 2022-06-24 02:57:38.523244
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    >>> a = _LazyModuleMarker()
    """


# Generated at 2022-06-24 02:57:39.359895
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-24 02:57:42.845031
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _lmm = _LazyModuleMarker()
    assert _lmm is not None, "_LazyModuleMarker() FAILED"


if __name__ == "__main__":
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:57:49.360042
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests satisfiability of function make_lazy
    """
    module_path = "test_module"
    module = __import__(module_path)
    assert not isinstance(sys.modules[module_path], _LazyModuleMarker)
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    module2 = __import__(module_path)
    assert module is module2
    assert not isinstance(sys.modules[module_path], _LazyModuleMarker)



# Generated at 2022-06-24 02:57:52.437817
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()
    assert not _LazyModuleMarker() == 1


# Generated at 2022-06-24 02:57:54.461273
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1


# Generated at 2022-06-24 02:57:56.470944
# Unit test for constructor of class NonLocal
def test_NonLocal():
    mod = NonLocal(1)
    val = 1
    assert mod.value == val


# Generated at 2022-06-24 02:57:58.908460
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = 10

    def _func():
        nonlocal i
        i = 1


    _func()
    return True


if __name__ == '__main__':
    print(test_NonLocal())



# Generated at 2022-06-24 02:58:08.037618
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    # Delcare a new module named 'test_NonLocal'
    make_lazy('test_NonLocal')

    import test_NonLocal as Nonlocal
    # Check the type of the newly created module
    assert(isinstance(Nonlocal, _LazyModuleMarker))

    # The actual module 'test_NonLocal' is not imported yet
    assert(Nonlocal.__getattribute__('value') is None)

    # Access attribute 'a' of the module 'test_NonLocal'
    assert(Nonlocal.a == 1)

    # After we have accessed the module 'test_NonLocal', the value of
    # Nonlocal.__getattribute__('value') is not None any more
    assert(Nonlocal.__getattribute__('value') is not None)



# Generated at 2022-06-24 02:58:09.271612
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 02:58:12.272692
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('ok')
    nl.value = 'default'
    assert nl.value == 'ok'

# Generated at 2022-06-24 02:58:21.405028
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the make_lazy function correctly delays
    the import of a module.
    """
    # Stub out some dummy  methods
    def hi():
        pass

    def bye():
        pass

    # Mock import. ImportModule is called
    # on object assignment, so we'll hook into it.
    real_import = __import__
    import_mock = MagicMock()
    real_import_module = __builtins__['__import__']

    # Stub out import module and make sure it is called
    # when an attribute is accessed.
    def mock_import(name, globals=None, locals=None, fromlist=(), level=0):
        import_mock(name)
        return real_import_module(name, globals, locals, fromlist, level)


# Generated at 2022-06-24 02:58:29.000778
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import copy
    import sys

    class NonLocal(object):
        """
        Simulates nonlocal keyword in Python 2
        """
        __slots__ = ['value']

        def __init__(self, value):
            self.value = value

    class _C(object):
        def __init__(self):
            self._x = NonLocal(5)

        def f(self):
            def g(self):
                self._x += 1
                return self._x

            return g(self)

    c = _C()
    assert c.f() == 6

    class _C(object):
        def __init__(self):
            self._x = NonLocal(5)

        def f(self):
            def g():
                self._x += 1
                return self._x

            return g()


# Generated at 2022-06-24 02:58:37.246280
# Unit test for function make_lazy
def test_make_lazy():
    import submod
    assert make_lazy('submod') == None
    assert isinstance(sys.modules['submod'], _LazyModuleMarker)
    assert sys.modules['submod'] is not None
    assert sys.modules['submod'].foo is not None
    assert sys.modules['submod'].foo() == 'foo'
    assert sys.modules['submod'].foo is not None

# Generated at 2022-06-24 02:58:46.577839
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules["example"] = ExampleModule()
    assert not isinstance(example, _LazyModuleMarker), "the module should not be a LazyModule"

    make_lazy("example")
    assert isinstance(example, _LazyModuleMarker), "the module should be a LazyModule after make_lazy"
    make_lazy("example")  # second call shouldn't do anything
    make_lazy("example")  # third call shouldn't do anything

    example.first_attr()
    assert not isinstance(example, _LazyModuleMarker), "the module should be imported after we access an attribute"


if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-24 02:58:53.366923
# Unit test for function make_lazy
def test_make_lazy():
    import sentry.utils.imports
    sentry.utils.imports.make_lazy('tests.utils.make_lazy_test')
    test = sys.modules['tests.utils.make_lazy_test']
    assert isinstance(test, _LazyModuleMarker)
    assert 'test_var' not in test.__dict__
    assert test.test_var == 'foo'
    assert hasattr(test, 'test_var')
    assert test.__name__ == 'tests.utils.make_lazy_test'
    assert test.__file__.endswith('make_lazy_test.py')  # noqa

# Generated at 2022-06-24 02:58:56.566587
# Unit test for constructor of class NonLocal
def test_NonLocal():
    shared_variable = NonLocal('begin')
    def f():
        shared_variable.value = 'end'

# Generated at 2022-06-24 02:59:05.243931
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import django.urls

    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], LazyModule)
    assert isinstance(sys.modules[module_path], django.urls.LazyModule)
    assert not hasattr(sys.modules[module_path], '__name__')
    assert sys.modules[module_path].LazyURLResolver is django.urls.resolvers.LazyURLResolver
    assert isinstance(sys.modules[module_path].LazyURLResolver, django.urls.resolvers.LazyURLResolver)
    assert sys.modules[module_path].LazyURLPattern is django.urls.resolvers.LazyURLPattern

# Generated at 2022-06-24 02:59:07.290572
# Unit test for constructor of class NonLocal
def test_NonLocal():
    val = NonLocal(3)
    assert val.value == 3
    val.value = 5
    assert val.value == 5
    return True

# Generated at 2022-06-24 02:59:10.061894
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that `make_lazy` correctly imports the module
    """
    try:
        from django.contrib.admin import models
    except ImportError:
        pass

    make_lazy('django.contrib.admin.models')

    import django.contrib.admin.models
    assert django.contrib.admin.models.LogEntry

# Generated at 2022-06-24 02:59:11.088811
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1

# Unit tests for function make_lazy

# Generated at 2022-06-24 02:59:13.369598
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert(lmm is not None)


# Generated at 2022-06-24 02:59:20.942130
# Unit test for function make_lazy
def test_make_lazy():
    import examples.lazy_test
    import sys
    assert not examples.lazy_test.is_imported
    assert isinstance(sys.modules['examples.lazy_test'], _LazyModuleMarker)
    examples.lazy_test.force_imports()
    assert examples.lazy_test.is_imported
    assert not isinstance(sys.modules['examples.lazy_test'], _LazyModuleMarker)

# Generated at 2022-06-24 02:59:25.771216
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test whether the module is marked correctly
    """
    mod_name = 'test_module'
    make_lazy(mod_name)
    assert isinstance(sys.modules[mod_name], _LazyModuleMarker)

# Generated at 2022-06-24 02:59:30.394686
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run a unit test of the make_lazy function.
    """
    import __builtin__
    assert isinstance(__builtin__, _LazyModuleMarker)
    assert not isinstance(__builtin__, ModuleType)
    assert isinstance(__builtin__, _LazyModuleMarker)


# ../../../../setup.py installs this function as a module.
if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:59:32.302375
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test the creation of a nonlocal class
    """
    nonlocal_var = NonLocal('test')
    assert nonlocal_var.value == 'test'



# Generated at 2022-06-24 02:59:40.463958
# Unit test for function make_lazy
def test_make_lazy():
    import time, threading

    def make_time_module_lazy():
        make_lazy('time')

        mod = __import__('time')

        assert isinstance(mod, _LazyModuleMarker)
        assert mod.time() != time.time()

        from time import time
        assert time() == mod.time()

        from time import time
        assert time() == mod.time()

        assert time.time() == mod.time()

    # We'll test that the module is not loaded when we import it
    # If it were, the following call would result in an infinite recursion
    thread = threading.Thread(target=make_time_module_lazy)
    thread.start()
    thread.join()



# Generated at 2022-06-24 02:59:41.791044
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()


# Generated at 2022-06-24 02:59:51.736439
# Unit test for function make_lazy
def test_make_lazy():
    # Set up
    import os
    from django.utils._os import upath

    sample_path = 'django.utils.lazymodule_sample'
    sys_modules = sys.modules

    # Make sure the module we are testing is not in sys.modules
    sys_modules.pop(sample_path, None)

    # Make sure we can import the module normally
    import django.utils.lazymodule_sample
    assert 'lazymodule_sample' in sys_modules
    assert 'lazymodule_sample' in django.utils.__dict__

    # Override the module, making it lazy
    make_lazy(sample_path)
    assert sample_path not in sys_modules
    assert sample_path in django.utils.__dict__

    # Verify the module appears lazy

# Generated at 2022-06-24 02:59:53.806890
# Unit test for function make_lazy
def test_make_lazy():
    # Create an example module
    sys.modules['example'] = 'example'
    make_lazy('example')
    assert sys.modules['example'] != 'example'
    assert sys.modules['example'] != ''
    del sys.modules['example']

# Generated at 2022-06-24 02:59:55.740897
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(1)
    nonlocal_obj.value = 2
    assert nonlocal_obj.value == 2


# Generated at 2022-06-24 02:59:56.974864
# Unit test for constructor of class NonLocal
def test_NonLocal():
    mod = NonLocal(None)
    assert mod



# Generated at 2022-06-24 03:00:05.314038
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    lazy_module = "lazy_module"

    if lazy_module in sys.modules:
        del sys.modules[lazy_module]

    module_contents = {
        "def1": "def1",
        "def2": "def2",
        "__name__": lazy_module,
        "__file__": lazy_module,
        "__path__": lazy_module
    }

    make_lazy(lazy_module)
    lazy_mod = sys.modules.get(lazy_module, None)

    assert isinstance(lazy_mod, _LazyModuleMarker)

    for key, val in module_contents.items():
        setattr(lazy_mod, key, val)


# Generated at 2022-06-24 03:00:07.568894
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() != _LazyModuleMarker()
    assert _LazyModuleMarker() is not _LazyModuleMarker()


# Generated at 2022-06-24 03:00:15.773718
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test valid constructor
    mark = _LazyModuleMarker()
    assert mark is not None
    assert mark is not False

    # Test mro() method
    assert _LazyModuleMarker.__mro__() is not None
    assert len(_LazyModuleMarker.__mro__()) == 2
    assert object in _LazyModuleMarker.__mro__()
    assert ModuleType in _LazyModuleMarker.__mro__()

    # Test getattribute() method
    assert _LazyModuleMarker.__getattribute__(mark, '__mro__') is not None
    assert _LazyModuleMarker.__getattribute__(mark, '__mro__')() is not None
    assert len(_LazyModuleMarker.__getattribute__(mark, '__mro__')()) == 2
   

# Generated at 2022-06-24 03:00:17.667627
# Unit test for constructor of class NonLocal
def test_NonLocal():
    l = NonLocal(10)
    assert l.value == 10
    l.value = 15
    assert l.value == 15

# Generated at 2022-06-24 03:00:20.533093
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal(10)
    assert nonlocal_object.value == 10

# Generated at 2022-06-24 03:00:24.312167
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_module'
    make_lazy(module_path)

    test_mod = sys.modules[module_path]

    assert isinstance(test_mod, _LazyModuleMarker)
    assert 'test_func' not in dir(test_mod)

    test_mod.test_func = lambda: 1

    assert 'test_func' in dir(test_mod)
    assert test_mod.test_func() == 1


# Generated at 2022-06-24 03:00:25.271237
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1, n.value



# Generated at 2022-06-24 03:00:30.482806
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if not hasattr(sys.version_info, 'major') or sys.version_info.major == 2:
        nl = NonLocal(3)
        assert nl.value == 3



# Generated at 2022-06-24 03:00:33.448643
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(10)
    assert(nl.value == 10)



# Generated at 2022-06-24 03:00:36.960376
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test that NonLocal constructor works
    nl = NonLocal(3)
    assert nl.value == 3

# Generated at 2022-06-24 03:00:39.342261
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    tester = _LazyModuleMarker()
    assert isinstance(tester, _LazyModuleMarker)
    assert not isinstance(tester, LazyModule)



# Generated at 2022-06-24 03:00:41.664574
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:00:48.796532
# Unit test for function make_lazy
def test_make_lazy():
    import unittest
    import tempfile
    import shutil
    import os.path

    class TestLazyModule(unittest.TestCase):
        def setUp(self):
            self.root = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.root)

        def test_lazy(self):
            # Setup a dummy module in the file system.
            module_root = os.path.join(self.root, 'test_lazy')
            os.mkdir(module_root)
            with open(os.path.join(module_root, '__init__.py'), 'w') as f:
                f.write('')

            # Force the module to be loaded lazily

# Generated at 2022-06-24 03:00:49.796466
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1


# Generated at 2022-06-24 03:00:52.883136
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test if the constructor of class _LazyModuleMarker runs successfully
    """
    try:
        _LazyModuleMarker()
    except NameError as e:
        assert False, "Failed to create an instance of class _LazyModuleMarker"


test__LazyModuleMarker()


# Generated at 2022-06-24 03:00:56.159564
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:00:57.790860
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(123)
    assert nl.value == 123


# Generated at 2022-06-24 03:01:01.934818
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal([1,2,3])
    assert nonlocal_object.value == [1,2,3]
    nonlocal_object.value = "foo"
    assert nonlocal_object.value == "foo"

# Generated at 2022-06-24 03:01:02.819839
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker, type)


# Generated at 2022-06-24 03:01:09.028647
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'test_module'
    testmodule_name = module_path.split('.')[-1]

    class Test(object):
        pass

    # Set up our testmodule
    testmodule = sys.modules[module_path] = Test()
    testmodule.__name__ = testmodule_name
    testmodule.__file__ = module_path
    make_lazy(module_path)
    assert(isinstance(sys.modules[module_path], _LazyModuleMarker) == True)

    del sys.modules[module_path]



# Generated at 2022-06-24 03:01:11.345349
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker  # constructor to be tested.
    # test if marker is a class
    assert isinstance(marker, type)



# Generated at 2022-06-24 03:01:23.080989
# Unit test for function make_lazy
def test_make_lazy():
    import inspect
    import copy
    import sys

    # Save the original sys.modules
    orig_sys_modules = copy.deepcopy(sys.modules)

    def clear_sys_modules():
        sys.modules = {}

    def restore_sys_modules():
        sys.modules = orig_sys_modules

    # Clear sys.modules and then add a module to it
    clear_sys_modules()
    sys.modules['test.sample'] = 'foo'
    make_lazy('test.sample')

    # Check that sys.modules is still the same
    assert 'test.sample' in sys.modules
    assert sys.modules['test.sample'] == 'foo'

    import test.sample
    assert test.sample.__name__ == 'test.sample'

    # Clear sys.modules again, but this time try importing a module that


# Generated at 2022-06-24 03:01:27.969305
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    assert _LazyModuleMarker.__name__ == "_LazyModuleMarker"
    assert _LazyModuleMarker.__doc__ == "A marker to indicate a LazyModule type."


# Generated at 2022-06-24 03:01:36.832979
# Unit test for function make_lazy
def test_make_lazy():
    assert (__name__ not in sys.modules)  # assert __name__ is not in sys.modules
    make_lazy(__name__)
    assert (isinstance(sys.modules[__name__], _LazyModuleMarker))  # assert sys.modules contains LazyModule instance
    assert ('test_make_lazy' not in dir(sys.modules[__name__]))  # assert test_make_lazy is not in LazyModule instance
    # assert test_make_lazy is in sys.modules[__name__]
    assert ('test_make_lazy' in dir(sys.modules[__name__]))
    del sys.modules[__name__]  # delete sys.modules[__name__] so that it will be imported again

# Generated at 2022-06-24 03:01:38.954430
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    assert x.value == 42, "NonLocal initialization not working"


# Generated at 2022-06-24 03:01:41.413236
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker(), '__mro__')
    assert hasattr(_LazyModuleMarker(), '__getattribute__')


# Generated at 2022-06-24 03:01:44.779100
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lma = _LazyModuleMarker()
    assert lma

# Generated at 2022-06-24 03:01:47.287595
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(8)
    if nl.value == 8:
        return True
    else:
        return False


# Generated at 2022-06-24 03:01:51.152668
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class TestClass(_LazyModuleMarker):
        def test_method(self):
            pass
    test_class = TestClass()
    assert isinstance(test_class, _LazyModuleMarker)

test__LazyModuleMarker()

# Generated at 2022-06-24 03:01:55.561550
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(None)
    assert i.value is None
    i.value = 1
    assert i.value == 1

# Generated at 2022-06-24 03:01:59.400641
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal([])

    def insert_stuff():
        nonlocal_var.value.append("hello")

    insert_stuff()
    assert nonlocal_var.value == ["hello"]
    insert_stuff()
    assert nonlocal_var.value == ["hello", "hello"]

# Generated at 2022-06-24 03:02:01.650111
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    ## input value
    # ModulePath
    target = None
    ## expect/assertion
    assert isinstance(target, _LazyModuleMarker) is False


# Generated at 2022-06-24 03:02:04.304020
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("sys")

    import sys
    import _LazyModuleMarker
    assert isinstance(sys, _LazyModuleMarker.LazyModule)
    assert sys.version is not None

# Generated at 2022-06-24 03:02:06.222079
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal("test")
    # print("Value=", n.value)
    assert n.value == "test"



# Generated at 2022-06-24 03:02:08.729091
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_object = NonLocal([])
    assert nonlocal_object.value == []
    nonlocal_object.value += [1]
    assert nonlocal_object.value == [1]


# Generated at 2022-06-24 03:02:12.024543
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    instance = _LazyModuleMarker()
    assert _LazyModuleMarker is type(instance)
    assert instance == instance
    assert not (instance != instance)
    assert isinstance(instance, _LazyModuleMarker)
    with pytest.raises(TypeError):
        _LazyModuleMarker(None)


# Generated at 2022-06-24 03:02:18.354340
# Unit test for function make_lazy
def test_make_lazy():
    lazymodule = "lazymodule"
    make_lazy(lazymodule)
    import lazymodule
    assert isinstance(lazymodule, _LazyModuleMarker)
    assert lazymodule.attrs.attr1 == 1
    assert lazymodule.attrs.attr2 == 2

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-24 03:02:21.137043
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module_test'] = None
    try:
        make_lazy('lazy_module_test')
        import lazy_module_test
        assert isinstance(lazy_module_test, _LazyModuleMarker)
        # Attribute access should cause the module to load
        lazy_module_test.foo
        assert isinstance(lazy_module_test, ModuleType)
    finally:
        del sys.modules['lazy_module_test']

# Generated at 2022-06-24 03:02:22.784363
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert 10 == a.value

# Generated at 2022-06-24 03:02:33.079795
# Unit test for function make_lazy
def test_make_lazy():
    if os.name == 'nt':
        make_lazy('ctypes.wintypes')
        ctypes = __import__('ctypes')

        # We don't want a bug in make_lazy to prevent the module from loading,
        # so we'll use the real ctypes.wintypes module for this import.
        import ctypes.wintypes

        assert isinstance(ctypes.wintypes, _LazyModuleMarker)

        try:
            # ctypes.wintypes in not loaded yet, so ctypes.wintypes.LPVOID
            # should throw an AttributeError
            ctypes.wintypes.LPVOID
        except AttributeError:
            pass
        else:
            raise AssertionError('ctypes.wintypes was not lazy-loaded.')

        # Now LPVOID is loaded

# Generated at 2022-06-24 03:02:39.154747
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['testmodule'] = None  # clear the module from sys.modules

    make_lazy('testmodule')

    assert 'testmodule' in sys.modules

    assert isinstance(sys.modules['testmodule'], _LazyModuleMarker)

    # Accessing testmodule should cause it to be loaded
    import testmodule

    assert isinstance(sys.modules['testmodule'], ModuleType)
    assert isinstance(testmodule, ModuleType)

# Generated at 2022-06-24 03:02:41.158714
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test for constructor of class NonLocal
    a = NonLocal(1)
    assert a.value == 1

# Generated at 2022-06-24 03:02:45.247099
# Unit test for function make_lazy
def test_make_lazy():
    from django.db import connections

    assert module_is_not_loaded('django.db.backends')

    # first use should import the module.
    assert connections
    assert connections.__class__.__module__ == 'django.db.backends'

    assert module_is_loaded('django.db.backends')

    # second use should not fail as the module is already imported.
    assert connections



# Generated at 2022-06-24 03:02:50.971983
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure to test module make_lazy
    """
    import socket
    import os
    import sys
    sys.modules.pop('socket', None)
    make_lazy('socket')
    import socket

    # Make sure that we can still use it
    socket.gethostbyname('localhost')



# Generated at 2022-06-24 03:03:01.023707
# Unit test for function make_lazy
def test_make_lazy():
    import imp

    # Test that module is created lazily
    def mock_imp_find_module():
        raise ImportError('Cannot find the module')

    find_module_backup = imp.find_module
    imp.find_module = mock_imp_find_module

    module_path = 'modules.test_module'
    make_lazy(module_path)

    test_module = sys.modules[module_path]

    assert isinstance(test_module, _LazyModuleMarker), 'Module is not lazy'

    test_var = test_module.test_var
    assert test_var == 'Hi', 'Module was not imported'

    imp.find_module = find_module_backup

# Generated at 2022-06-24 03:03:09.788505
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test.test_sys_modlues'

    sys.modules[module_path] = None

    make_lazy(module_path)

    # test.test_sys_modules should not have been imported yet
    assert sys.modules[module_path].__class__._LazyModuleMarker__mro__() == \
        (sys.modules[module_path].__class__, ModuleType)

    # force it to be imported
    sys.modules[module_path].foo

    assert sys.modules[module_path].__class__ == ModuleType

    del sys.modules[module_path]

# Generated at 2022-06-24 03:03:17.767002
# Unit test for function make_lazy
def test_make_lazy():
    import importlib

    # We will use sys.modules later to check the result
    sys_modules = sys.modules

    # a simple module to be imported.
    def Module():
        Module.A = 1

    module_path = 'module_path'

    # clear possible previous import
    sys_modules.pop(module_path, None)

    make_lazy(module_path)

    # check if the module has been imported
    assert module_path not in sys_modules

    # check if the module works as expected (after importing)
    from module_path import A
    assert A == 1

    # check if the module has been imported
    assert module_path in sys_modules

# Generated at 2022-06-24 03:03:21.839211
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test if _LazyModuleMarker is a _LazyModule
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)

# Generated at 2022-06-24 03:03:23.125880
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker) == True


# Generated at 2022-06-24 03:03:27.134770
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert x.value == 10

    x.value = 20
    assert x.value == 20

    x = NonLocal("hello")
    assert x.value == "hello"

    x.value = "world"
    assert x.value == "world"

