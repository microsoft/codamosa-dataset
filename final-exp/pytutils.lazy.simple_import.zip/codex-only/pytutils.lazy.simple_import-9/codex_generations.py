

# Generated at 2022-06-24 02:53:37.576853
# Unit test for function make_lazy
def test_make_lazy():
    # It should work with a full module path
    import time
    lazy_time = make_lazy('time')

    assert 'mod' in sys.modules
    assert isinstance(sys.modules['time'], _LazyModuleMarker)
    assert sys.modules['time'] is lazy_time

    # It should work with a relative module path
    import imp
    make_lazy('._imp')

    assert '_imp' in sys.modules
    assert isinstance(sys.modules['_imp'], _LazyModuleMarker)
    assert sys.modules['._imp'] is sys.modules['_imp']

    # The module should be importable
    import _imp
    assert _imp.get_magic() == imp.get_magic()

    # The original module should not be loaded

# Generated at 2022-06-24 02:53:38.483435
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    data = _LazyModuleMarker()


# Generated at 2022-06-24 02:53:40.267716
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    return type(lmm) == _LazyModuleMarker

test__LazyModuleMarker()


# Generated at 2022-06-24 02:53:41.937983
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(sys.modules['eventlet.lazy'], types.ModuleType)

# Generated at 2022-06-24 02:53:43.503858
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert_instance(LazyModule, _LazyModuleMarker)

# Generated at 2022-06-24 02:53:47.584414
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create an instance of _LazyModuleMarker
    lazy_module = _LazyModuleMarker()

    # Check to make sure attrs were set correctly
    assert lazy_module is not None


# Generated at 2022-06-24 02:53:49.049595
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print('Testing constructor of class _LazyModuleMarker')



# Generated at 2022-06-24 02:53:59.180318
# Unit test for function make_lazy
def test_make_lazy():
    import test_module
    import os

    assert sys.modules['test_module'] is test_module

    make_lazy('test_module')

    assert not isinstance(sys.modules['test_module'], ModuleType)
    assert isinstance(sys.modules['test_module'], _LazyModuleMarker)

    # this module is already in `sys.modules`
    test_module
    module = sys.modules['test_module']
    # but this module has not been "imported yet"
    assert module is not test_module
    assert module.__name__ == 'test_module'
    assert module.__file__ == test_module.__file__

    assert module.foo() == 'foo'
    assert module.bar() == 'bar'
    assert module.baz() == 'baz'

    # the module

# Generated at 2022-06-24 02:54:03.477426
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that make_lazy() actually makes a module lazy.
    """
    # Only run the test if coverage is not running (coverage causes a module
    # to be dynmically created)
    if 'coverage' not in sys.modules:
        make_lazy('concurrent')
        assert 'concurrent' not in sys.modules
        import concurrent
        import concurrent.futures
        assert isinstance(concurrent, _LazyModuleMarker)
        assert isinstance(concurrent.futures, _LazyModuleMarker)


# unit test for NonLocal

# Generated at 2022-06-24 02:54:07.496553
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def local_f():
        nl = NonLocal(42)
        assert nl.value == 42
        def nested_f():
            assert nl.value == 42
        nested_f()
    local_f()


# Generated at 2022-06-24 02:54:17.788677
# Unit test for constructor of class _LazyModuleMarker

# Generated at 2022-06-24 02:54:20.623126
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test class _LazyModuleMarker.
    """
    assert _LazyModuleMarker is not None
    assert isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 02:54:21.950361
# Unit test for constructor of class NonLocal
def test_NonLocal():
    ns = NonLocal(123)
    assert ns.value == 123



# Generated at 2022-06-24 02:54:23.730056
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)


# Generated at 2022-06-24 02:54:25.183996
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('y')
    assert n.value == 'y'



# Generated at 2022-06-24 02:54:28.379103
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:54:30.549645
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_marker = _LazyModuleMarker()

    assert(isinstance(lazy_marker, _LazyModuleMarker))

# Generated at 2022-06-24 02:54:31.317192
# Unit test for function make_lazy
def test_make_lazy():
    pass

# Generated at 2022-06-24 02:54:35.213190
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    marker.__dict__["value"] = 100
    assert marker.value == 100
    print("All tests pass")


if __name__ == "__main__":
    test__LazyModuleMarker()
    print("All tests pass")

# Generated at 2022-06-24 02:54:45.632584
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Outer:
        scope = NonLocal('outer scope')
        def __init__(self, v1):
            self.scope = NonLocal(v1) # redefine scope

            class Inner:
                scope = NonLocal('inner scope')
                def __init__(self, v2):
                    self.scope = NonLocal(v2) # redefine scope
                    print('Inner class scope:', self.scope.value)
                    print('Outer class scope:', Outer.scope.value)
                    print('Global scope     :', scope.value)

            self.inner = Inner('inner class scope')

    scope = NonLocal('global scope')
    outer = Outer('outer class scope')
    print('Outer class scope:', outer.scope.value)
    print('Inner class scope:', outer.inner.scope.value)
    print

# Generated at 2022-06-24 02:54:50.462861
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys_modules = sys.modules
    module_path = 'tests.mocklazy'
    assert module_path not in sys_modules

    make_lazy(module_path)

    assert module_path in sys_modules
    assert sys_modules[module_path] is not None
    assert isinstance(sys_modules[module_path], _LazyModuleMarker)

    # an attribute lookup should cause the module to load
    assert sys_modules[module_path].is_loaded is True

    # the module should be in sys.modules
    assert module_path in sys_modules

    # and the module should be the module that was loaded
    assert sys_modules[module_path] is mocklazy
    assert sys_modules[module_path].is_loaded is True

# Generated at 2022-06-24 02:54:52.262370
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert not isinstance(_LazyModuleMarker(), object)


# Generated at 2022-06-24 02:54:56.413885
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal("hello")
    print(nl.value)


if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 02:55:02.784801
# Unit test for function make_lazy
def test_make_lazy():

    make_lazy('__main__.test.foo.bar')

    from test import foo
    import sys

    assert isinstance(foo, _LazyModuleMarker)
    assert 'test.foo.bar' not in sys.modules
    assert hasattr(foo, 'bar')
    assert hasattr(foo.bar, 'baz')
    assert not isinstance(foo, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:04.991068
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    This function tests the constructor of class NonLocal.
    """
    nonlocal_obj = NonLocal(0)
    assert(nonlocal_obj.value == 0)

# Generated at 2022-06-24 02:55:09.520177
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy
    """
    try:
        del sys.modules['tests.lazy_import.test_make_lazy']
        make_lazy('tests.lazy_import.test_make_lazy')
        sys.modules['tests.lazy_import.test_make_lazy'].assertTrue
        assert False
    except AttributeError:
        assert True

# Generated at 2022-06-24 02:55:10.783452
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
   lmm = _LazyModuleMarker()


# Generated at 2022-06-24 02:55:12.125146
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    lmm is not None


# Generated at 2022-06-24 02:55:20.040548
# Unit test for function make_lazy
def test_make_lazy():
    import os

    os_path = os.__name__
    make_lazy(os_path)

    # Ensure os is not in sys.modules
    assert os_path not in sys.modules

    # Ensure the os module is lazy and can be used
    assert os_path in sys.modules
    assert isinstance(sys.modules[os_path], _LazyModuleMarker)
    os.path.abspath("")

    # Ensure os is now in sys.modules
    assert os_path in sys.modules
    assert isinstance(sys.modules[os_path], ModuleType)



# Generated at 2022-06-24 02:55:25.441285
# Unit test for function make_lazy
def test_make_lazy():
    # Check that make_lazy is a noop when called without actual import
    sys_modules = {}
    make_lazy('test_module', sys_modules)
    assert sys_modules['test_module'] is not None
    assert not isinstance(sys_modules['test_module'], _LazyModuleMarker)
    assert sys_modules['test_module'] == sys_modules['test_module']



# Generated at 2022-06-24 02:55:28.336931
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert (isinstance(lmm, _LazyModuleMarker))


# Generated at 2022-06-24 02:55:37.421720
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import time
    import os
    import re
    import pdb

    # Check and clear sys.modules
    sys_modules_keys = sys.modules.keys()
    for item in sys_modules_keys:
        if item.startswith("fs_uae_launcher."):
            del sys.modules[item]

    # Make a new sys.modules object
    sys_modules = {}
    sys.modules = sys_modules

    # Check that all items are removed from sys.modules
    assert sys.modules.keys() == []

    # Import a module and check that it is imported and not lazy
    import fs_uae_launcher
    assert "fs_uae_launcher" in sys.modules
    assert not isinstance(sys_modules["fs_uae_launcher"], _LazyModuleMarker)



# Generated at 2022-06-24 02:55:43.626726
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1

# Generated at 2022-06-24 02:55:49.543466
# Unit test for function make_lazy
def test_make_lazy():
    """
    Module is lazy, and not loaded
    """
    sys.modules["foo"] = None
    make_lazy("foo")
    assert isinstance(sys.modules["foo"], _LazyModuleMarker)

    # The lazily loaded module has the same name
    assert sys.modules["foo"].__name__ == "foo"



# Generated at 2022-06-24 02:55:54.207497
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = a.__mro__()
    assert (b[0] == a)
    assert (b[1] == ModuleType)



# Generated at 2022-06-24 02:55:59.267748
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _LazyModuleMarkerTest(object):
        """
        A marker to indicate a LazyModule type.
        Allows us to check module's with `isinstance(mod, _LazyModuleMarker)`
        to know if the module is lazy.
        """
        pass

    v = _LazyModuleMarkerTest()
    assert isinstance(v, _LazyModuleMarkerTest)

# Generated at 2022-06-24 02:56:00.843905
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 02:56:05.533987
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, object)
    assert isinstance(marker, _LazyModuleMarker)



# Generated at 2022-06-24 02:56:10.402369
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('os')
    # os should not be loaded
    assert 'os' not in sys.modules
    # __mro__ should return ModuleType and LazyModule
    assert sys.modules['os'].__mro__() == (LazyModule, ModuleType)
    # __getattribute__ should load os and return os.getcwd()
    assert sys.modules['os'].getcwd() == os.getcwd()

# Generated at 2022-06-24 02:56:16.074366
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['test_make_lazy'] = None
    make_lazy('test_make_lazy')
    assert 'test_make_lazy' not in sys.modules

    # Still not there, but
    assert isinstance(sys.modules['test_make_lazy'], _LazyModuleMarker)

    # Now it's there!
    hasattr(sys.modules['test_make_lazy'], 'not_there')
    assert 'test_make_lazy' in sys.modules
    assert isinstance(sys.modules['test_make_lazy'], ModuleType)

# Generated at 2022-06-24 02:56:17.501732
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(12)
    assert nl.value == 12
    nl.value = 7
    assert nl.value == 7

# Generated at 2022-06-24 02:56:18.191062
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()

# Generated at 2022-06-24 02:56:19.483807
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert(x.value == 1)


# Generated at 2022-06-24 02:56:25.843694
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test if nonlocal keyword can be obtained by
    creating an object of class NonLocal.
    """
    x = NonLocal(3)
    def foo():
        y = NonLocal(4)
        def bar():
            print(x.value, y.value)
        bar()
    foo()

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 02:56:28.324509
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert isinstance(lazy_module_marker, _LazyModuleMarker)



# Generated at 2022-06-24 02:56:30.386952
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:56:36.649235
# Unit test for function make_lazy
def test_make_lazy():
    import test_package.sub_package.sub_sub_package.subsubsub_package.subsubsubsub_package.module_a.module_b
    assert isinstance(test_package.sub_package.sub_sub_package.subsubsub_package.subsubsubsub_package.module_a.module_b, _LazyModuleMarker)


if __name__ == '__main__':
    import test_package.sub_package.sub_sub_package.subsubsub_package
    test_package.sub_package.sub_sub_package.subsubsub_package.subsubsubsub_package.module_a.module_b.MODULE.test_mod()

# Generated at 2022-06-24 02:56:42.619612
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class DerivedLazyModule(_LazyModuleMarker):
        def __mro__(self):
            return [DerivedLazyModule, _LazyModuleMarker]

    return


if __name__ == '__main__':
    # Demos

    # Original
    import time, datetime
    print(datetime.datetime.now())
    time.sleep(1)
    print(datetime.datetime.now())

    # After
    del sys.modules['datetime']
    make_lazy('datetime')
    import datetime

# Generated at 2022-06-24 02:56:48.152519
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazyModuleMarker1 = _LazyModuleMarker()
    assert isinstance(lazyModuleMarker1, _LazyModuleMarker)

    class MySubClass(_LazyModuleMarker):
        def __init__(self):
            pass

    mySubClass = MySubClass()
    assert isinstance(mySubClass, _LazyModuleMarker)

    class YourSubClass(_LazyModuleMarker):
        def __init__(self):
            pass

    yourSubClass = YourSubClass()
    assert isinstance(yourSubClass, _LazyModuleMarker)



# Generated at 2022-06-24 02:56:55.919990
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test the constructor of class _LazyModuleMarker
    """
    try:
        # We expect this to work
        class TestLazyModuleMarker(_LazyModuleMarker):
            """
            Test constructor of _LazyModuleMarker
            """
            pass
        print("Constructor works: %s" % TestLazyModuleMarker)
    except TypeError:
        # We expect this to fail
        print("Constructor fails: %s" % _LazyModuleMarker)


# Generated at 2022-06-24 02:57:03.456287
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test `make_lazy` with the `test.test_import_lazy.test_make_lazy` module.

    This unit test runs the module and tests that it has been lazy loaded.

    This test must be run by itself.
    """

    assert sys.modules['test.test_import_lazy.test_make_lazy'].__class__ == sys.modules['test.test_context_processors'].LazyModule, 'Test module `test.test_import_lazy.test_make_lazy` is not marked lazy!'

    test_make_lazy = sys.modules['test.test_import_lazy.test_make_lazy']


# Generated at 2022-06-24 02:57:11.253501
# Unit test for function make_lazy
def test_make_lazy():

    # make a test to ensure that the function works
    import time
    import time_lazy_1
    import time_lazy_2
    t0 = time.time()

    # imported module
    getattr(time, 'time')

    # lazy module
    getattr(time_lazy_1, 'time')

    # lazy module with dynamic import blocking
    getattr(time_lazy_2, 'time')
    getattr(time_lazy_2, 'time')

    t1 = time.time()
    assert t1 - t0 < 0.1, 'module loading took too much time.'

# Generated at 2022-06-24 02:57:13.396070
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    check_type(ModuleType, _LazyModuleMarker())
    check_type(ModuleType, _LazyModuleMarker)

import test
test.testmod()

# Generated at 2022-06-24 02:57:17.868320
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def fn(x):
        nonlocal_x = NonLocal(x)
        nonlocal_x.value = 100
        assert nonlocal_x.value == 100
    fn(1)

    def fn(x):
        nonlocal_x = NonLocal(x)
        assert x.value == 2
        x.value = 100
        assert nonlocal_x.value == 100
    fn(NonLocal(2))

# Generated at 2022-06-24 02:57:26.221366
# Unit test for function make_lazy
def test_make_lazy():
    name = 'test.make_lazy'
    dummy_module = sys.modules[name] = ModuleType(name)

    make_lazy(name)

    assert isinstance(dummy_module, _LazyModuleMarker)
    assert isinstance(dummy_module, ModuleType)
    assert dummy_module.__name__ == name
    assert dummy_module.__path__ == name
    assert dummy_module.__package__ == name

    # Remove from sys.modules after testing
    del sys.modules[name]

# Generated at 2022-06-24 02:57:30.635815
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    a = sys.modules.copy()
    make_lazy('tests.lazy_support.make_lazy_testing')
    b = sys.modules
    assert a == b


# Generated at 2022-06-24 02:57:33.768308
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('test'), _LazyModuleMarker)
    assert 1 == 1

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:57:39.779282
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("\nUnit test for constructor of class _LazyModuleMarker")
    lazy_module1 = _LazyModuleMarker()
    assert isinstance(lazy_module1, _LazyModuleMarker) == True
# def test__LazyModuleMarker()


# Generated at 2022-06-24 02:57:44.002302
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(8)
    y = NonLocal("a")
    x.value = 5
    y.value = "b"
    assert x.value == 5
    assert y.value == "b"


if (__name__ == "__main__"):
    test_NonLocal()

# Generated at 2022-06-24 02:57:51.032588
# Unit test for function make_lazy
def test_make_lazy():
    # for testing, only copy the key attributes to a simpler object
    module_path = 'my_module'
    sys_modules = {}
    module = sys_modules[module_path] = {'name': module_path}

    make_lazy(module_path)

    # ensure that a lazy module was created
    lazy_module = sys_modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # ensure that the module is loaded only after an attribute is accessed
    assert module['name'] == module_path
    assert lazy_module.name == module_path


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:57:55.402361
# Unit test for function make_lazy
def test_make_lazy():
    try:
        assert not hasattr(sys.modules, 'time'), 'Lazy module already exists'
        make_lazy('time')
        assert isinstance(sys.modules['time'], _LazyModuleMarker)
        assert getattr(sys.modules['time'], 'time') is time.time
    finally:
        del sys.modules['time']

# Generated at 2022-06-24 02:58:00.343359
# Unit test for function make_lazy
def test_make_lazy():
    import os

    def f():
        os.fake

    def g():
        make_lazy('os')
        os.fake

    # Should raise an exception in f and not in g
    nose.tools.assert_raises(AttributeError, f)

    # Can't use nose.tools.assert_raises since it also checks for exceptions
    # in the test runner itself.
    try:
        g()
    except AttributeError:
        assert False

# Generated at 2022-06-24 02:58:02.600915
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('testvalue')
    assert nl.value == 'testvalue'


# Generated at 2022-06-24 02:58:07.117701
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mod_marker = _LazyModuleMarker()

# Generated at 2022-06-24 02:58:18.367045
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('lazy_test.foo')

    # Verify that the module wasn't imported.
    try:
        __import__('lazy_test.foo')
        assert False, "Module was imported while testing make_lazy!"
    except ImportError:
        pass

    # Verify that the module will import when we access an attribute.
    __import__('lazy_test.foo').bar

    # Verify that the module will only import once.
    __import__('lazy_test.foo').bar
    __import__('lazy_test.foo').bar

    # Verify that the module can be overridden before it gets loaded.
    class Override(object):
        pass

    sys.modules['lazy_test.foo'] = Override

# Generated at 2022-06-24 02:58:26.356263
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var_1 = NonLocal(2)
    var_2 = NonLocal(3)
    test_value = var_1.value
    assert test_value == 2
    var_1.value = 5
    test_value = var_1.value
    assert test_value == 5

    test_value = var_2.value
    assert test_value == 3
    var_1.value = 4
    test_value = var_1.value
    assert test_value == 4

    test_value = var_2.value
    assert test_value == 3



# Generated at 2022-06-24 02:58:36.317564
# Unit test for function make_lazy
def test_make_lazy():
    # Test checks that the module is not loaded until it is accessed
    module_path = "src.systems.lazy"
    make_lazy(module_path)
    # Tests that the module is an instance of _LazyModuleMarker
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    # Tests if the module successfully loads the attributes from the real module
    assert sys.modules[module_path].__name__ == module_path
    # Tests that the module is a again a module type
    assert isinstance(sys.modules[module_path], ModuleType)


if __name__ == "__main__":
    nose.main()

# Generated at 2022-06-24 02:58:47.258806
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules_backup = sys.modules.copy()
    sys.modules['test_lazy'] = None
    def my_import(name):
        if name.startswith('test_lazy'):
            raise ImportError
        return importlib.import_module(name)

    with mock.patch('importlib.import_module', side_effect=my_import):
        make_lazy('test_lazy')
        # Module should be lazily imported by __getattribute__ on
        # attribute lookup
        test_lazy = sys.modules['test_lazy']
        assert isinstance(test_lazy, _LazyModuleMarker)
        with pytest.raises(AttributeError):
            test_lazy.foo
        with pytest.raises(ImportError):
            test_lazy.foo
        sys

# Generated at 2022-06-24 02:58:48.609953
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('detached')
    assert nl.value == 'detached'



# Generated at 2022-06-24 02:58:52.740066
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    make_lazy("os")

    mod = sys.modules["os"]
    assert not hasattr(mod, "stat")

    # load the module again, should be a no-op.
    make_lazy("os")

    assert not hasattr(mod, "stat")

    assert isinstance(mod, ModuleType)
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:55.897160
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from autotest.utils import is_python3
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    if not is_python3():
        assert isinstance(_LazyModuleMarker(), object)

# Generated at 2022-06-24 02:59:00.219428
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy
    """
    module_name = 'tests.lazy_module'
    make_lazy(module_name)

    # Assert that the module has not yet been imported
    assert module_name not in sys.modules

    # Assert that accessing an attribute will import the module
    tests.lazy_module.x
    assert module_name in sys.modules

# Generated at 2022-06-24 02:59:07.195675
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('foo')
    assert not isinstance(sys.modules['foo'], ModuleType)
    sys.modules['foo'].bar = 1
    assert isinstance(sys.modules['foo'], ModuleType)

    try:
        del sys.modules['foo']
    except KeyError:
        pass

    with pytest.raises(KeyError):
        del sys.modules['foo']



# Generated at 2022-06-24 02:59:13.197166
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for make_lazy
    """
    import django.utils.moduleloader
    import django.conf
    make_lazy('django.utils.moduleloader')
    assert not hasattr(django.utils.moduleloader, 'module_loading_utils')
    result = list(django.utils.moduleloader.module_loading_utils.iter_modules('django.conf'))
    assert len(result) > 0
    assert hasattr(django.utils.moduleloader, 'module_loading_utils')

test_make_lazy()

# Generated at 2022-06-24 02:59:22.063496
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for lazy_module
    """
    module_path = 'lazy_module'
    non_lazy_module_path = 'non_lazy_module'
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    getattr(sys.modules[module_path], 'some_attribute')
    assert isinstance(sys.modules[module_path], ModuleType)
    assert sys.modules[module_path] != sys.modules[non_lazy_module_path]
    assert sys.modules[module_path].__name__ == non_lazy_module_path

# Generated at 2022-06-24 02:59:27.142742
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        a = _LazyModuleMarker()
    except Exception as e:
        assert False
    success = True
    try:
        b = _LazyModuleMarker()
        assert a is not b
    except Exception as e:
        success = False
    assert success, "Only one instance of _LazyModuleMarker can be created."



# Generated at 2022-06-24 02:59:27.762358
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(LazyModule(), _LazyModuleMarker)

# Generated at 2022-06-24 02:59:32.533437
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Initialize a _LazyModuleMarker instance
    obj = _LazyModuleMarker()

    assert isinstance(obj, _LazyModuleMarker) # assert that the instance is a _LazyModuleMarker



# Generated at 2022-06-24 02:59:41.173847
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # Make sure we have a fresh sys.modules that doesn't contain our module
    # yet.
    try:
        del sys.modules['test_make_lazy']
    except KeyError:
        pass

    # Import the module without make_lazy
    test_make_lazy_import = __import__('test_make_lazy')

    assert test_make_lazy_import.test_env_var in os.environ

    # Use make_lazy, and make sure the module isn't imported
    make_lazy('test_make_lazy')

    # Get the module
    test_make_lazy_lazy = __import__('test_make_lazy')

    # Ensure the module we got has our new type

# Generated at 2022-06-24 02:59:44.726390
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert_equal(nl.value, 3)
    nl.value = 4
    assert_equal(nl.value, 4)


# Generated at 2022-06-24 02:59:47.645688
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Tests that the slot value is settable and readable, but doesn't
    # have an assignment statement.
    test = NonLocal(5)
    assert test.value == 5
    test.value = 10
    assert test.value == 10



# Generated at 2022-06-24 02:59:57.334689
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from types import ModuleType
    module_path = "sys"
    sys_modules = sys.modules
    module = NonLocal(None)
    sys_modules[module_path] = ModuleType(module_path)

    # Getting the module before assignment
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        getattr(NonLocal, module_path)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Get the module after assignment
    module.value = ModuleType(module_path)
    assert getattr(NonLocal, module_path)


# Generated at 2022-06-24 03:00:04.218581
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'django.utils.module_loading'
    module = sys.modules[module_path]
    if module is None:
        module = __import__(module_path)
    make_lazy(module_path)
    assert isinstance(module, _LazyModuleMarker), \
        "Initialize module path '%s' for test purpose" % module_path
    assert module is LazyModule

    # getattribute will call the actual import
    assert module.get_mod_func(module_path) == (module, module_path)

# Generated at 2022-06-24 03:00:05.534776
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()



# Generated at 2022-06-24 03:00:06.761467
# Unit test for constructor of class NonLocal
def test_NonLocal():
    temp = NonLocal(None)
    print(temp.value)


# Generated at 2022-06-24 03:00:11.527000
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules['test_make_lazy'] = None
    make_lazy('test_make_lazy')
    test_make_lazy = sys.modules['test_make_lazy']
    assert test_make_lazy is not None
    assert isinstance(test_make_lazy, _LazyModuleMarker)
    del sys.modules['test_make_lazy']



# Generated at 2022-06-24 03:00:22.079939
# Unit test for function make_lazy
def test_make_lazy():

    # Importing a module that is not lazily loaded
    import sys
    import test_make_lazy_mod

    assert sys.modules['test_make_lazy_mod'] is test_make_lazy_mod

    # Verify that importing a lazy module does not cause it to be loaded
    make_lazy('test_make_lazy_mod')
    import test_make_lazy_mod
    assert isinstance(test_make_lazy_mod, _LazyModuleMarker)

    # Verify that accessing an attribute of a lazy module causes it to be loaded
    assert test_make_lazy_mod.attr == 'attr'
    assert sys.modules['test_make_lazy_mod'] is not test_make_lazy_mod

test_make_lazy()

# Generated at 2022-06-24 03:00:24.075449
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    a.value = 1
    assert a.value == 1


# Generated at 2022-06-24 03:00:29.326719
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test that NonLocal works as expected.
    """

    def inner():
        """
        An inner function.

        @return: the value of the variable
        """
        nonlocal_obj = NonLocal('foo')
        nonlocal_obj.value = 'bar'
        return nonlocal_obj.value

    assert inner() == 'bar'



# Generated at 2022-06-24 03:00:31.479261
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(4)
    assert a.value == 4
    a.value = 5
    assert a.value == 5


# Generated at 2022-06-24 03:00:34.488686
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(3)
    assert nl.value == 3

# Test for constructor of class LazyModule

# Generated at 2022-06-24 03:00:35.642972
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1

# Generated at 2022-06-24 03:00:36.646971
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 03:00:43.432283
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['_test_make_lazy'] = None

    make_lazy('_test_make_lazy')

    import _test_make_lazy
    assert isinstance(_test_make_lazy, _LazyModuleMarker)
    assert not hasattr(_test_make_lazy, 'foo')


    # Perform the actual import in a different file so not to pollute our namespace.
    subprocess.call(['python', '-c', 'import _test_make_lazy; _test_make_lazy.foo = 1'])

    reload(_test_make_lazy)
    assert hasattr(_test_make_lazy, 'foo')
    assert _test_make_lazy.foo == 1

    # Cleanup
    sys.modules.pop('_test_make_lazy', None)

# Generated at 2022-06-24 03:00:49.651268
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    from nose.tools import nottest

    if sys.version_info < (3, 3):
        @nottest
        def test_nonlocal():
            import sys
            import os
            import contextlib

            assert '_lazy_test' not in sys.modules
            module = NonLocal(None)

            def test():
                assert module.value is None

                def inner():
                    nonlocal module
                    module.value = 'foo'

                inner()
                assert module.value is 'foo'

            test()
            assert module.value is None

        test_nonlocal()

    assert '_lazy_test' not in sys.modules

    make_lazy('_lazy_test')
    import _lazy_test

    assert isinstance(_lazy_test, _LazyModuleMarker)

# Generated at 2022-06-24 03:00:54.957635
# Unit test for function make_lazy
def test_make_lazy():
    import tempfile
    import os

    mod = open('test_mod.py', 'w')
    mod.write('a=5')
    mod.close()

    make_lazy('test_mod')
    assert set(sys.modules) == set(['test_mod'])
    try:
        assert isinstance(sys.modules['test_mod'], _LazyModuleMarker)
        assert not isinstance(sys.modules['test_mod'], ModuleType)
    finally:
        os.unlink('test_mod.py')

# Generated at 2022-06-24 03:00:58.210454
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    assert nl.value != 2

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 03:01:08.304957
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from types import ModuleType
    import sys

    module_path = 'local.test_module'

    sys_modules = sys.modules  # cache in the locals

    # store our 'instance' data in the closure.
    module = NonLocal(None)

    class LazyModule(ModuleType):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are overridding __getattribute__.
            # By putting a __mro__ method here, we can pass `isinstance`
            # checks without ever invoking our __getattribute

# Generated at 2022-06-24 03:01:13.913859
# Unit test for function make_lazy
def test_make_lazy():
    """
    Run unit tests for make_lazy()
    """
    class AttrSetter(object):
        """
        Override `__setattr__` so we can track what attr/values are set.
        """
        def __init__(self):
            self.__attrs = {}
            self.__getattribute__ = super(AttrSetter, self).__getattribute__

        def __setattr__(self, name, value):
            """
            This is called on any attribute assignment.
            """
            self.__attrs[name] = value
            super(AttrSetter, self).__setattr__(name, value)

        def get_attrs(self):
            """
            Return a dict of { attr: value } set.
            """
            return self.__attrs


# Generated at 2022-06-24 03:01:16.468425
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'os'
    make_lazy(module_path)
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)


# Generated at 2022-06-24 03:01:19.863878
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    b = NonLocal(a)
    c = NonLocal(b)
    assert a.value == 1
    assert b.value == a
    assert c.value == b

# Generated at 2022-06-24 03:01:24.815010
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x, y, z = 10, 20, 30
    def test_method():
        a = NonLocal(x)
        def test_method1():
            a.value += 1
            b = NonLocal(y)
            def test_method2():
                a.value += b.value
                c = NonLocal(z)
            test_method2()
            print(a.value)
        test_method1()
    test_method()


# Generated at 2022-06-24 03:01:27.780797
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    module_path = '__test_make_lazy__'
    module = sys.modules[module_path] = ModuleType('__test_make_lazy__')
    assert not isinstance(module, _LazyModuleMarker)
    make_lazy(module_path)
    assert isinstance(module, _LazyModuleMarker)

# Generated at 2022-06-24 03:01:30.456671
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value == 0



# Generated at 2022-06-24 03:01:35.479046
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that the implementation of make_lazy works.
    """
    import os

    # first try to import without make_lazy
    assert os.path is not None

    # now make os lazy, and import it again.
    make_lazy('os')
    assert os.path is not None
    assert isinstance(os, _LazyModuleMarker)

    # make sure the module doesn't get imported again
    make_lazy('os')
    assert os.path is not None

# Generated at 2022-06-24 03:01:41.137228
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test creating of NonLocal
    """
    test_value = NonLocal("test")
    assert test_value.value == "test"


# Generated at 2022-06-24 03:01:43.755364
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(callable(_LazyModuleMarker))


# Unit tests for constructor of class LazyModule

# Generated at 2022-06-24 03:01:47.333036
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test that creates a _LazyModuleMarker object
    """
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)

test__LazyModuleMarker()


# Generated at 2022-06-24 03:01:49.783436
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_mod = make_lazy('test')
    assert isinstance(lazy_mod, _LazyModuleMarker)

test__LazyModuleMarker()

# Generated at 2022-06-24 03:01:52.097538
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker() is not None



# Generated at 2022-06-24 03:01:53.284181
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal('some value')
    assert obj.value == 'some value'

# Generated at 2022-06-24 03:02:01.883841
# Unit test for function make_lazy
def test_make_lazy():
    # create a dummy module with an attribute
    class TestModule(object):
        val = 1

    # do an import and assert that we have a module
    import pkg_resources
    module_path = 'pkg_resources.test'
    sys.modules[module_path] = TestModule()
    assert isinstance(pkg_resources.test, TestModule)
    assert pkg_resources.test.val == 1

    # make it lazy loaded
    before = sys.modules.keys()
    make_lazy(module_path)
    after = sys.modules.keys()
    assert_equal(before, after)

    # assert that it's not loaded yet
    assert isinstance(pkg_resources.test, _LazyModuleMarker)
    assert not hasattr(pkg_resources.test, 'val')

    # do an attribute lookup and assert

# Generated at 2022-06-24 03:02:04.218391
# Unit test for constructor of class NonLocal
def test_NonLocal():

    class foo(object):
        value = None

        def __init__(self):
            self.value = NonLocal(42)

    assert foo().value.value == 42

# Generated at 2022-06-24 03:02:05.798951
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal('object')
    assert(nonlocal_obj.value == 'object')


# Generated at 2022-06-24 03:02:08.992986
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Name : test__LazyModuleMarker
    Description : Test if the constructor of _LazyModuleMarker is working
    """
    lazymodule = _LazyModuleMarker()
    assert lazymodule



# Generated at 2022-06-24 03:02:10.871486
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert isinstance(module, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:15.996598
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal(5)
    assert nonlocal_var.value == 5

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 03:02:17.771414
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)



# Generated at 2022-06-24 03:02:19.991994
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test = _LazyModuleMarker()
    isinstance(test, _LazyModuleMarker)
    assert isinstance(test, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:25.120302
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    A method to test the constructor of class _LazyModuleMarker
    """
    # Call the constructor
    marker = _LazyModuleMarker()
    # Check the type of the returned attribute
    assert type(marker).__name__ == "_LazyModuleMarker"


# Generated at 2022-06-24 03:02:35.874437
# Unit test for function make_lazy
def test_make_lazy():

    def _test(module_path):
        make_lazy(module_path)

        # We can call `isinstance` and `issubclass` to inspect the module.
        assert isinstance(sys.modules[module_path], _LazyModuleMarker)
        assert issubclass(sys.modules[module_path], ModuleType)

        # Check that it can be used like a module type.
        assert issubclass(sys.modules[module_path], ModuleType)
        assert sys.modules[module_path].__doc__ is None
        assert sys.modules[module_path].__name__ == module_path

        # Check that it can be used like an instance of a module.
        assert sys.modules[module_path].__doc__ == object.__doc__

    _test('os')
    _test('sys')
    _

# Generated at 2022-06-24 03:02:37.891775
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert a

# Generated at 2022-06-24 03:02:39.921991
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    nl.value = 2
    assert nl.value == 2


# Generated at 2022-06-24 03:02:41.489914
# Unit test for constructor of class NonLocal
def test_NonLocal():
    my_NonLocal_obj = NonLocal(10)
    assert(my_NonLocal_obj.value == 10)

# Generated at 2022-06-24 03:02:45.217961
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class N(NonLocal):
        def __init__(self):
            super(N, self).__init__(value = 1)
            self.value = 2
    n = N()

# Generated at 2022-06-24 03:02:51.307430
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['lazy_module'] = None
    make_lazy('lazy_module')
    module = sys.modules['lazy_module']
    assert isinstance(module, _LazyModuleMarker)
    assert module.__name__ == 'lazy_module'

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 03:02:54.412889
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_ = NonLocal(42)
    assert nonlocal_.value == 42

# Generated at 2022-06-24 03:02:55.738785
# Unit test for constructor of class NonLocal
def test_NonLocal():
    m = NonLocal(3)
    assert m.value == 3

# Generated at 2022-06-24 03:02:58.316830
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3
    a.value = 4
    assert a.value == 4



# Generated at 2022-06-24 03:02:59.995458
# Unit test for constructor of class NonLocal
def test_NonLocal():
    name = NonLocal('name')
    name_value = name.value
    assert name_value == 'name'


# Generated at 2022-06-24 03:03:01.077812
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:03:06.589173
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from sys import version_info
    if version_info.major == 3:
        nl = NonLocal(10)
        assert nl.value == 10
    else:
        import pytest
        pytest.skip('Skipped in Python2 for lack of nonlocal')


# Generated at 2022-06-24 03:03:08.090664
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj1 = NonLocal("abc")
    obj2 = NonLocal("def")
    assert obj1.value == "abc"
    assert obj2.value == "def"


# Generated at 2022-06-24 03:03:08.949269
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()


# Generated at 2022-06-24 03:03:09.787828
# Unit test for constructor of class NonLocal
def test_NonLocal():
    return NonLocal(2)


# Generated at 2022-06-24 03:03:14.274317
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal('test').value == 'test'



# Generated at 2022-06-24 03:03:21.171226
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    # Test make_lazy
    module_path = 'unittest'

    # Check that the unittest module does not exist in sys.modules
    assert module_path not in sys.modules

    # Mark the unittest module as lazy
    make_lazy(module_path)

    # Check that the unittest module now exists in sys.modules
    assert module_path in sys.modules

    # Check the unittest module has the correct type
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Check that trying to access a module attribute fails
    with pytest.raises(AttributeError):
        sys.modules[module_path].this_attribute_does_not_exist

    # Check that the unittest module has been

# Generated at 2022-06-24 03:03:22.337575
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert hasattr(_LazyModuleMarker, '__getattribute__')
    assert hasattr(_LazyModuleMarker, '__mro__')

# Generated at 2022-06-24 03:03:23.475464
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(10)
    assert foo.value == 10
    foo.value = 20
    assert foo.value == 20


# Generated at 2022-06-24 03:03:24.988089
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)


# Generated at 2022-06-24 03:03:30.090345
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the function make_lazy
    """

    make_lazy(module_path="scoop.utils.lazymodule")

    import scoop.utils.lazymodule
    assert isinstance(scoop.utils.lazymodule, _LazyModuleMarker)
    assert not isinstance(scoop.utils.lazymodule, ModuleType)

    assert scoop.utils.lazymodule.__name__ == "scoop.utils.lazymodule"