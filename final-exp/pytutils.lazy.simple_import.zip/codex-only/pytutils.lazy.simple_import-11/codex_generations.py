

# Generated at 2022-06-24 02:53:38.217984
# Unit test for function make_lazy
def test_make_lazy():
    try:
        sys.modules['my.module']
    except KeyError:
        pass
    else:
        del sys.modules['my.module']

    make_lazy('my.module')

    assert isinstance(sys.modules['my.module'], _LazyModuleMarker)

    module = sys.modules['my.module']
    assert not hasattr(module, '__file__')
    assert not hasattr(module, '__name__')
    assert not hasattr(module, '__path__')
    assert not hasattr(module, '__package__')
    assert not hasattr(module, '__loader__')

    # After accessing an attribute, it should be a real module
    module.attr = 'value'
    assert not isinstance(sys.modules['my.module'], _LazyModuleMarker)


# Generated at 2022-06-24 02:53:39.375508
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(20)
    assert non_local.value == 20


# Generated at 2022-06-24 02:53:45.109497
# Unit test for function make_lazy
def test_make_lazy():
    # Mock out the module for testing
    sys.modules['make_lazy_test_module'] = None

    make_lazy('make_lazy_test_module')

    # Check that we can do a normal import
    from make_lazy_test_module import hello
    assert hello == 'Hello World!'

    # Mock this module call
    sys.modules['make_lazy_test_module'] = None

    # Check that we have a lazy module
    assert isinstance(sys.modules['make_lazy_test_module'], _LazyModuleMarker)

    # Check that we can do an import from a lazy module
    from make_lazy_test_module import hello
    assert hello == 'Hello World!'


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:53:47.475772
# Unit test for constructor of class NonLocal
def test_NonLocal():
	x = NonLocal(3)
	assert x.value == 3, "NonLocal value not initialized correctly"


# Generated at 2022-06-24 02:53:51.648410
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import unittest
    class TestNonLocal(unittest.TestCase):
        def test_constructor(self):
            nl = NonLocal("value")
            self.assertEqual("value", nl.value)

    unittest.main()


# Generated at 2022-06-24 02:53:56.575317
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that `make_lazy` works.
    """
    make_lazy('django.foo.bar')
    import django.foo.bar
    assert not django.foo.bar.__module__
    assert django.foo.bar.__class__.__name__ == 'LazyModule'



# Generated at 2022-06-24 02:53:59.008297
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0
    x.value = 1
    assert x.value == 1

if __name__ == "__main__":
    test_NonLocal()

# Generated at 2022-06-24 02:54:05.054697
# Unit test for function make_lazy
def test_make_lazy():
    test_module_name = 'test_module_name'
    sys_modules = sys.modules
    make_lazy(test_module_name)
    assert test_module_name not in sys_modules
    assert isinstance(sys_modules.get(test_module_name), _LazyModuleMarker)

    from test_module_name import Foo
    assert Foo().bar() == 'bar'
    assert test_module_name in sys_modules



# Generated at 2022-06-24 02:54:09.174898
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest

    class _TestCase(unittest.TestCase):
        def runTest(self):
            self.assertTrue(isinstance(_LazyModuleMarker, type))

    suite = unittest.TestSuite([_TestCase()])

    unittest.TextTestRunner().run(suite)


# Generated at 2022-06-24 02:54:19.375205
# Unit test for function make_lazy
def test_make_lazy():
    # pylint: disable=unused-variable,unused-import
    import sys  # noqa
    import django
    import django.conf
    import django.db.models
    import django.db.models.fields
    import django.db.models.fields.related
    import django.contrib.humanize
    import django.contrib.humanize.templatetags.humanize
    import django.contrib.auth
    import django.contrib.auth.views
    import django.contrib.auth.decorators
    import django.contrib.auth.hashers
    import django.contrib.admin
    import django.contrib.admin.views
    import django.contrib.admin.options
    import django.contrib.admin.sites

# Generated at 2022-06-24 02:54:20.934391
# Unit test for constructor of class NonLocal
def test_NonLocal():

    # Create an instance of NonLocal
    nl = NonLocal(0)

    # Check if value is set correctly
    assert nl.value == 0


# Generated at 2022-06-24 02:54:21.906903
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal('test')



# Generated at 2022-06-24 02:54:28.121090
# Unit test for function make_lazy
def test_make_lazy():
    import imp
    filename = 'does_not_exist'
    with open(filename, 'w+') as f:
        f.write('a = 1')

    base_module = imp.load_source('base_module', filename)
    assert base_module.a == 1
    os.remove(filename)

    make_lazy('base_module')
    assert isinstance(base_module, ModuleType)
    assert isinstance(base_module, _LazyModuleMarker)
    assert not hasattr(base_module, 'a')

    # Now trigger the actual import
    assert base_module.a == 1

    # Now it has the module
    assert isinstance(base_module, ModuleType)
    assert not isinstance(base_module, _LazyModuleMarker)
    assert hasattr(base_module, 'a')

# Generated at 2022-06-24 02:54:38.045656
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Test that a new class instantiation 
    # is possible and if it has correct members
    nl = NonLocal(False)
    assert 'value' in nl.__slots__
    assert not nl.value


if __name__ == '__main__':
    global path_to_lazy_module
    path_to_lazy_module = 'lazy'

    # Unit test for the 'make_lazy' function
    # First make lazy our module
    make_lazy(path_to_lazy_module)

    # Make sure that the module is not loaded yet
    assert path_to_lazy_module not in sys.modules

    # Run normal tests in the below
    import lazy # this will create a new module and load
    assert lazy._return_int() == 1

    # Now run our tests
   

# Generated at 2022-06-24 02:54:42.458356
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert type(LazyModuleMarker) is _LazyModuleMarker
    assert isinstance(LazyModuleMarker, _LazyModuleMarker)

# Generated at 2022-06-24 02:54:43.523281
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal([])

make_lazy('lazy')

# Generated at 2022-06-24 02:54:45.264836
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert isinstance(module, _LazyModuleMarker) is True


# Generated at 2022-06-24 02:54:46.364020
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(20)
    assert a.value == 20


# Generated at 2022-06-24 02:54:54.509197
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('import_redirect.pylazy')

    import import_redirect.pylazy
    # Check that it is marked as lazy
    assert isinstance(import_redirect.pylazy, _LazyModuleMarker)

    assert import_redirect.pylazy.__name__ == 'pylazy'
    assert import_redirect.pylazy.__file__ == 'pylazy.py'
    assert import_redirect.pylazy.__path__ == ['pylazy.py']

    # Importing again the module doesn't work
    import import_redirect.pylazy as pylazy
    assert pylazy.__name__ == 'pylazy'
    assert pylazy.__file__ == 'pylazy.py'

# Generated at 2022-06-24 02:54:59.764484
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Create and test class _LazyModuleMarker
    """
    value = _LazyModuleMarker()
    try:
        msg = "test__LazyModuleMarker: Fail"
        assert isinstance(value, object), msg
        print(msg + ": Pass")
    except AssertionError as e:
        print(e)



# Generated at 2022-06-24 02:55:05.381249
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('dummy_module')
    from dummy_module import something
    assert something == 1


if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 02:55:13.191725
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import sys
    import unittest
    from types import ModuleType

    class TestCase(unittest.TestCase):
        """
        Unit test for function make_lazy
        """
        def setUp(self):
            """
            Unit test for function make_lazy
            """
            if 'make_lazy_test_package' in sys.modules:
                del sys.modules['make_lazy_test_package']

            # create a package

# Generated at 2022-06-24 02:55:15.950248
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1
    assert nl.value == getattr(nl, 'value')
    nl.value = 2
    assert nl.value == 2
    assert nl.value == getattr(nl, 'value')
    setattr(nl, 'value', 3)
    assert nl.value == 3
    assert nl.value == getattr(nl, 'value')



# Generated at 2022-06-24 02:55:21.768163
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert type(a) == _LazyModuleMarker


if __name__ == '__main__':
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:55:24.628767
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        m = _LazyModuleMarker()
    except TypeError:
        pass

if __name__ == "__main__":
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:55:27.023029
# Unit test for constructor of class NonLocal
def test_NonLocal():
    __test_val = 10
    nl = NonLocal(__test_val)
    assert nl.value == __test_val
    nl.value = 15
    assert nl.value == 15
    assert __test_val == 10


# Generated at 2022-06-24 02:55:34.576020
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import os
    import platform

    def create_file(path):
        if os.path.isfile(path):
            os.remove(path)
        with open(path, 'w') as f:
            f.write('\n')
            f.close()

    test_path = os.path.join('.', 'test_NonLocal')
    create_file(test_path)
    r_path = os.path.join('.', 'test_NonLocal_2')
    create_file(r_path)

    m = NonLocal(test_path)
    print(m.value)
    print(os.path.isfile(m.value))
    m.value = r_path
    print(m.value)
    print(os.path.isfile(m.value))

# Generated at 2022-06-24 02:55:35.395479
# Unit test for constructor of class NonLocal
def test_NonLocal():
    instance = NonLocal(10)
    assert instance.value == 10


# Generated at 2022-06-24 02:55:46.168996
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure function make_lazy works as expected.
    """
    import sys
    # mock the modules folder
    sys.modules['module'] = mod = object()
    # check if module still exists
    assert 'module' in sys.modules
    make_lazy('module')
    # check if module exists after call of make_lazy
    assert 'module' not in sys.modules


# keep the real curses module around as this was causing
# issues with migrate and other tools.
_real_curses = __import__('curses')

make_lazy('curses')


# Generated at 2022-06-24 02:55:47.360276
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5



# Generated at 2022-06-24 02:55:55.126430
# Unit test for function make_lazy
def test_make_lazy():
    assert "test" not in sys.modules

    import edx_toggles.toggles.test
    assert sys.modules["edx_toggles.toggles.test"]
    assert isinstance(edx_toggles.toggles.test, ModuleType)  # pylint: disable=unsubscriptable-object

    make_lazy("edx_toggles.toggles.test")

    assert isinstance(edx_toggles.toggles.test, _LazyModuleMarker)
    assert not hasattr(edx_toggles.toggles.test, "SampleToggle")
    assert sys.modules["edx_toggles.toggles.test"]
    assert "test" in sys.modules

    toggle = edx_toggles.toggles.test.SampleToggle()

    assert isinstance(toggle, object)
   

# Generated at 2022-06-24 02:55:59.507426
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()

# Generated at 2022-06-24 02:56:09.930728
# Unit test for function make_lazy
def test_make_lazy():
    m = sys.modules.copy()  # copy the module dict
    import m1
    test_cases = [
        ('.m1', m1.a, 'm1.a = 1'),
        ('.m1.m2', m1.m2.b, 'm1.m2.b = 2'),
        ('.m1.m3', m1.m3.c, 'm1.m3.c = 3'),
    ]
    for path, lazy_module, expected in test_cases:
        make_lazy(path)
        assert not repr(m1.m2).startswith('<module'), repr(m1.m2)
        assert repr(lazy_module) == expected, repr(lazy_module)
    # Test the make_lazy function
    assert lazy_module.a == 1

# Generated at 2022-06-24 02:56:13.090315
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert nl.value == 42
    nl.value = 43
    assert nl.value == 43



# Generated at 2022-06-24 02:56:15.404299
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1
    n.value = 2
    assert n.value == 2
    n.value = 3
    assert n.value == 3


# Generated at 2022-06-24 02:56:17.047103
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert isinstance(marker, _LazyModuleMarker)



# Generated at 2022-06-24 02:56:18.360948
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal("value")
    assert obj.value == "value"



# Generated at 2022-06-24 02:56:20.813996
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test `make_lazy` helper function
    """
    import __main__
    make_lazy('__main__')
    assert isinstance(__main__, _LazyModuleMarker)
    sys.modules['__main__'].__file__

# Generated at 2022-06-24 02:56:25.537518
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import datetime
    assert datetime
    make_lazy('datetime')
    # Importing datetime again shouldn't work now without make_lazy() knowing
    try:
        import datetime
        assert False, 'Importing datetime again should have failed.'
    except ImportError:
        pass
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)
    assert sys.modules['datetime'].datetime is datetime.datetime
    assert sys.modules['datetime'].datetime.now()
    # Following import should work now because make_lazy() already imported
    # datetime module
    assert datetime


# Generated at 2022-06-24 02:56:31.686199
# Unit test for function make_lazy
def test_make_lazy():
    import unittest2 as unittest
    import os
    import sys

    foo_file_path = os.path.abspath(__file__)
    dir_path, _ = os.path.split(foo_file_path)
    foo_module_path = os.path.join(dir_path, 'foo')

    make_lazy(foo_module_path)
    foo_module = sys.modules[foo_module_path]

    class TestFunctions(unittest.TestCase):
        def test_if_foo_module_is_lazy_module(self):
            self.assertTrue(isinstance(foo_module, _LazyModuleMarker))


# Generated at 2022-06-24 02:56:34.236791
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        nonlocal_var = NonLocal(1)
        assert nonlocal_var.value == 1
    except Exception as ex:
        print(ex)
        return False

    return True


# Generated at 2022-06-24 02:56:37.532992
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5
    n.value = 3
    assert n.value == 3

# Generated at 2022-06-24 02:56:40.925346
# Unit test for constructor of class NonLocal
def test_NonLocal():
    return NonLocal(1)

# Generated at 2022-06-24 02:56:43.819142
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest
    class Test__LazyModuleMarker(unittest.TestCase):
        def test_basic(self):
            _LazyModuleMarker()
    unittest.main(module=__name__)


# Generated at 2022-06-24 02:56:52.194587
# Unit test for function make_lazy
def test_make_lazy():
    os = sys.modules['os']
    assert not isinstance(os, _LazyModuleMarker)
    make_lazy('os')
    assert isinstance(os, _LazyModuleMarker)
    assert 'path' not in os.__dict__
    assert os.path == sys.modules['os'].path

    # Test that we cannot access 'path' without triggering the import
    mod = sys.modules['os']
    del sys.modules['os']

    assert 'path' not in mod.__dict__
    assert mod.path == sys.modules['os'].path



# Generated at 2022-06-24 02:56:56.570453
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print("Test for constructor of class _LazyModuleMarker")
    wms = _LazyModuleMarker()
    assert(isinstance(wms, _LazyModuleMarker))


# Generated at 2022-06-24 02:56:59.031054
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert (type(a) == _LazyModuleMarker)


# Generated at 2022-06-24 02:57:10.546507
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that make_lazy does not import until a property is
    requested from the module.
    """
    import importlib

    module_path = 'tests.test_utils.lazy_module'

    # verify that the module does not exist
    # and that importlib does not know about it
    assert module_path not in sys.modules
    assert not hasattr(importlib.import_module(module_path), '__spec__')

    make_lazy(module_path)
    assert module_path in sys.modules

    # run the compiler to cache the module in importlib.
    # The module is being cached as the result of an import
    # even thought the module has not been loaded.
    compile('import {}'.format(module_path), '<string>', 'exec')

# Generated at 2022-06-24 02:57:11.505139
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 02:57:12.697432
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() != _LazyModuleMarker()


# Generated at 2022-06-24 02:57:14.775197
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:57:16.327809
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import pytest
    import sys
    import os
    import example_module
    mymod = example_module


# Generated at 2022-06-24 02:57:17.846117
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test constructor of class NonLocal
    """
    var = NonLocal(3)
    assert var.value == 3



# Generated at 2022-06-24 02:57:27.805628
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test of module `make_lazy`.
    """
    import test_make_lazy_submodule.submodule
    assert not isinstance(test_make_lazy_submodule, _LazyModuleMarker)
    assert sys.modules['test_make_lazy_submodule'] != _LazyModuleMarker

    make_lazy('test_make_lazy_submodule')

    assert isinstance(test_make_lazy_submodule, _LazyModuleMarker)
    assert not isinstance(test_make_lazy_submodule.submodule, _LazyModuleMarker)

    # check the LazyModule loads correctly
    assert test_make_lazy_submodule.submodule.subsubmodule.subsubsubmodule.subsubsubsubmodule.x + 4 == 4

# Generated at 2022-06-24 02:57:31.703184
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Initialize a lazy module
    make_lazy('queue')
    # Get the module
    queue = sys.modules['queue']
    # Check if it's a LazyModule
    assert isinstance(queue, _LazyModuleMarker)


# Generated at 2022-06-24 02:57:33.986422
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if sys.version_info < (3, ):
        n = NonLocal(42)
        assert n.value == 42


# Generated at 2022-06-24 02:57:38.829070
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()

# Generated at 2022-06-24 02:57:42.289191
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['testmodule'] = None
    make_lazy('testmodule')
    assert isinstance(sys.modules['testmodule'], _LazyModuleMarker)
    from testmodule import test_attribute
    assert test_attribute == 'foo'

# Generated at 2022-06-24 02:57:43.236927
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 02:57:52.796966
# Unit test for function make_lazy
def test_make_lazy():
    import types, sys

    # import a module
    make_lazy('os')
    lazy_mod = sys.modules['os']
    assert isinstance(lazy_mod, types.ModuleType)
    assert isinstance(lazy_mod, _LazyModuleMarker)

    # lazy_mod is expected to be missing data from os
    assert not hasattr(lazy_mod, 'path')

    # data is not loaded until it is needed
    os_mod = sys.modules['os']
    assert hasattr(os_mod, 'path')
    assert lazy_mod is os_mod

    # make sure the data is imported correctly
    assert hasattr(os_mod, 'path')
    assert os_mod is not None
    assert os_mod.path is not None
    assert os_mod.path == '/'
    assert os

# Generated at 2022-06-24 02:57:55.122953
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test for constructor
    lazy_module_marker = _LazyModuleMarker()
    lazy_module_marker


# Generated at 2022-06-24 02:58:04.585991
# Unit test for function make_lazy
def test_make_lazy():
    # If pytest is installed, then we can test this function.
    # https://docs.pytest.org/en/latest/goodpractices.html#integrating-with-distutils-python-setup-py-test
    try:
        import py
        import _pytest.assertion
    except ImportError:
        return

    import_target = 'pytest'

    if import_target not in sys.modules:
        make_lazy(import_target)

    if import_target in sys.modules:
        pytest_module = sys.modules[import_target]
    else:
        pytest_module = __import__(import_target)

    # We should be able to import this without importing pytest.
    import pytest._code

    # This will fail if we also imported pytest.
    _pytest.assertion

# Generated at 2022-06-24 02:58:07.188525
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class MockClass(object):
        def __init__(self, value):
            self.__value = value
        def __mro__(self):
            return (self, )
    mockInstance = MockClass('value')
    mockInstance.__class__ = _LazyModuleMarker
    assert isinstance(mockInstance, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:13.644994
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # LazyModuleMarker_object is an instance of _LazyModuleMarker
    LazyModuleMarker_object = _LazyModuleMarker()
    # test if the constructor returns a _LazyModuleMarker object
    assert isinstance(LazyModuleMarker_object, _LazyModuleMarker)



# Generated at 2022-06-24 02:58:15.710100
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor
    """
    assert isinstance(NonLocal('value'), NonLocal)


# Generated at 2022-06-24 02:58:18.169070
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Test for NonLocal class
    """
    nonLocalObj = NonLocal('NonLocalTest')
    assert nonLocalObj.value == 'NonLocalTest'

# Generated at 2022-06-24 02:58:20.835628
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None

# Generated at 2022-06-24 02:58:28.721380
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy decorator on a module.
    """
    import sys
    import test_make_lazy, test_make_lazy.test_const


# Generated at 2022-06-24 02:58:32.130173
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value is None


# Generated at 2022-06-24 02:58:38.047901
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    persist = _LazyModuleMarker()
    print(persist)


if __name__ == '__main__':
    # Python 3.x:
    #   TypeError: __init__() takes 1 positional argument but 2 were given
    # test__LazyModuleMarker()

    # Python 2.7:
    #   TypeError: __init__() takes exactly 1 argument (2 given)
    # test__LazyModuleMarker()

    # Python 2.7:
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:58:47.702172
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to make sure that lazy loading a module works as expected.
    """
    # Note: we must use a test.module under a nested module to match
    # how the autodiscovery nesting works.
    module_path = 'django.tests.lazy_loading.test.module'

    make_lazy(module_path)

    module = sys.modules[module_path]
    assert isinstance(module, ModuleType)
    assert isinstance(module, _LazyModuleMarker)

    assert module.attribute == "value"
    assert module.submodule.subattribute == "subvalue"

    # make sure we didn't accidentally import a non-lazy module
    assert module.attribute != "value"

    # make sure the module is lazy
    assert module.submodule.subattribute == "subvalue"

# Generated at 2022-06-24 02:58:48.456284
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(5).value == 5

# Generated at 2022-06-24 02:58:52.820721
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Should not throw TypeError: Error when calling the metaclass bases
    # metaclass conflict: the metaclass of a derived class must be a (non-strict)
    # subclass of the metaclasses of all its bases
    class Foo(_LazyModuleMarker):
        pass

    assert isinstance(Foo(), _LazyModuleMarker)
    assert issubclass(Foo, _LazyModuleMarker)


# Generated at 2022-06-24 02:58:53.797050
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert isinstance(obj, _LazyModuleMarker)


# Generated at 2022-06-24 02:58:56.037280
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['foo.bar'] = None
    with pytest.raises(ImportError) as ie:
        from foo.bar import baz
    assert 'foo.bar' in str(ie)
    make_lazy('foo.bar')
    from foo.bar import baz
    assert baz == 'baz'



# Generated at 2022-06-24 02:58:59.803421
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Expected output
    expected = ["__init__", 1]

    # Actual output
    actual = []

    obj = NonLocal(1)

    # Get nonlocal variable's value
    actual.append(obj.__init__.__name__)
    actual.append(obj.value)

    # Compare expected with actual output
    assert expected == actual

# Generated at 2022-06-24 02:59:11.011141
# Unit test for function make_lazy
def test_make_lazy():
    def _lazy_module(mode, module_path):
        """
        Returns True or False if module is lazy based on the mode.
        """
        if mode is True:
            return isinstance(sys.modules[module_path], _LazyModuleMarker)
        else:
            return not isinstance(sys.modules[module_path], _LazyModuleMarker)

    # If a module does not exist, it should be a lazy module
    assert _lazy_module(True, 'test.test_make_lazy_doesntexist')

    # If we create a lazy module, then it should be lazy.
    make_lazy('test.test_make_lazy_doesntexist')
    assert _lazy_module(True, 'test.test_make_lazy_doesntexist')

    # If we move a non

# Generated at 2022-06-24 02:59:15.624437
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_true

    lazy_module = _LazyModuleMarker()
    assert_true(isinstance(lazy_module, _LazyModuleMarker))

# Generated at 2022-06-24 02:59:16.511596
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(17)

# Generated at 2022-06-24 02:59:20.927030
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = "test.test_lazy"
    assert module_path not in sys.modules
    make_lazy(module_path)
    assert module_path in sys.modules
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert not isinstance(sys.modules[module_path], ModuleType)



# Generated at 2022-06-24 02:59:25.771234
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy
    """
    import lazymodules.test
    assert isinstance(lazymodules.test, _LazyModuleMarker)

    assert lazymodules.test.Attribute == 'Some Value'

# Generated at 2022-06-24 02:59:29.902347
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert lazy_module is not None

test__LazyModuleMarker()

# Generated at 2022-06-24 02:59:36.562517
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker, type)
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert isinstance(_LazyModuleMarker, object)
    assert isinstance(type, type)
    assert isinstance(type, object)
    assert not isinstance(object, type)
    assert isinstance(_LazyModuleMarker, object)
    assert isinstance(ModuleType, type)
    assert isinstance(ModuleType, object)
    assert isinstance(ModuleType, ModuleType)
    assert isinstance(ModuleType, _LazyModuleMarker)


# Generated at 2022-06-24 02:59:38.448805
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 02:59:39.268933
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(None)
    assert a.value == None


# Generated at 2022-06-24 02:59:43.387437
# Unit test for constructor of class NonLocal
def test_NonLocal():
    stack = []
    def foo():
        nlvar = NonLocal(stack)
        def bar():
            nlvar.value.append(1)
        bar()
    foo()
    assert(stack == [1])

# Generated at 2022-06-24 02:59:44.879176
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(LazyModule, _LazyModuleMarker)


# Generated at 2022-06-24 02:59:50.137691
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_var = NonLocal("hello")

    # Check that NonLocal's __init__ works
    assert nonlocal_var.value == "hello"
    assert nonlocal_var.value != "world"

    # Check that NonLocal can be used in a function
    def test():
        nonlocal_var.value = 'world'
        assert nonlocal_var.value == "world"

    test()
    assert nonlocal_var.value == "world"



# Generated at 2022-06-24 02:59:56.493893
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    # __mro__ member has not been overriden
    assert x.__mro__ == (object,)
    # __getattribute__ member has not been overriden
    assert x.__getattribute__ == object.__getattribute__



# Generated at 2022-06-24 03:00:03.878085
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    import django
    django_path = 'django'
    make_lazy(django_path)

    # type check on lazy module
    assert isinstance(sys.modules[django_path], _LazyModuleMarker)

    # This should not import
    assert django.VERSION is None
    assert not hasattr(django, 'settings')

    # This should import
    assert sys.modules[django_path].VERSION



# Generated at 2022-06-24 03:00:07.191801
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal("Python")
    assert a.value == "Python"
    assert a.__class__ == NonLocal
    # __init__ runs once, but just in case
    a = NonLocal("Java")
    assert a.value == "Java"



# Generated at 2022-06-24 03:00:16.637775
# Unit test for function make_lazy
def test_make_lazy():
    """
    Make sure make_lazy works as expected.
    """
    # Make a test module
    module_name = 'test_module'
    module_path = 'django_mysql.test_utils.' + module_name
    module_path_as_module = __name__ + '.' + module_name
    module_value = 42
    module = ModuleType(module_name)
    module.test_value = module_value
    sys.modules[module_path_as_module] = module

    # Mark it lazy
    make_lazy(module_path)

    # Check that the module hasn't been imported yet
    assert sys.modules[module_name] is not module

    # Check that importing it works as expected
    import django_mysql.test_utils.test_module

# Generated at 2022-06-24 03:00:17.633562
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(True)
    assert x.value is True


# Generated at 2022-06-24 03:00:27.493196
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # class _LazyModuleMarker is tested by testing the functionality of
    # make_lazy(a) and class LazyModule, where the LazyModule class is defined
    # in make_lazy(a)

    # before making the module lazy
    import abc
    assert isinstance(abc, ModuleType)
    assert not isinstance(abc, _LazyModuleMarker)

    # after making the module lazy
    make_lazy("abc")
    from abc import ABC
    assert isinstance(abc, _LazyModuleMarker)
    assert isinstance(abc, ModuleType)
    assert isinstance(ABC, type)

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 03:00:29.770764
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()
    assert(True)


# Generated at 2022-06-24 03:00:40.329664
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import types

    module_path = os.path.abspath(__file__)
    assert(module_path in sys.modules)

    # module is loaded
    assert(sys.modules[module_path] is this_module)
    assert(isinstance(sys.modules[module_path], types.ModuleType))

    make_lazy(module_path)
    assert(isinstance(sys.modules[module_path], _LazyModuleMarker))
    assert(sys.modules[module_path] is not this_module)

    # module has not been loaded
    assert(getattr(this_module, "__name__", None) is None)

    # module should have been loaded
    assert(sys.modules[module_path] is this_module)

# Generated at 2022-06-24 03:00:45.759513
# Unit test for function make_lazy
def test_make_lazy():
    import imp
    with open('test_make_lazy.py', 'w') as fd:
        fd.write('test_make_lazy_var="hello world"')
    imp.load_source('test_make_lazy', 'test_make_lazy.py')
    assert('test_make_lazy' in sys.modules)
    assert(sys.modules['test_make_lazy'].test_make_lazy_var == 'hello world')
    # Now, let's make the module lazy.
    make_lazy('test_make_lazy')
    assert(sys.modules['test_make_lazy'].test_make_lazy_var == 'hello world')
    os.unlink('test_make_lazy.py')
    del sys.modules['test_make_lazy']

# Generated at 2022-06-24 03:00:53.043783
# Unit test for function make_lazy
def test_make_lazy():
    import foo
    import bar
    import baz

    #test_make_lazy

    # check that we can import foo without actually loading the module
    foo.foo_function()
    foo_var = foo.foo_var

    # check that we can import bar, foo has already been loaded
    bar.bar_function()
    bar_var = bar.bar_var

    # check that we can import baz and that it is not left dangling
    baz.baz_function()
    baz_var = baz.baz_var

    #test_make_lazy

# Generated at 2022-06-24 03:01:00.060349
# Unit test for function make_lazy
def test_make_lazy():
    import django.db
    assert not isinstance(sys.modules['django.db'], _LazyModuleMarker)
    make_lazy('django.db')
    assert isinstance(sys.modules['django.db'], _LazyModuleMarker)
    import django.db
    assert isinstance(sys.modules['django.db'], _LazyModuleMarker)
    assert isinstance(django.db, ModuleType)

# Generated at 2022-06-24 03:01:05.096088
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1
    assert NonLocal(None).value == None
    assert NonLocal('hello').value == 'hello'


# Generated at 2022-06-24 03:01:09.556671
# Unit test for function make_lazy
def test_make_lazy():
    import test_lazy
    from types import ModuleType
    assert isinstance(test_lazy, _LazyModuleMarker)
    assert not isinstance(test_lazy, ModuleType)
    assert hasattr(test_lazy, '__mro__')
    assert not isinstance(test_lazy, ModuleType)
    test_lazy.a
    assert isinstance(test_lazy, ModuleType)

# Generated at 2022-06-24 03:01:10.929363
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)

# Generated at 2022-06-24 03:01:14.724956
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # test to check the module can be imported
    mod = ModuleType('mod1')
    assert(isinstance(mod, _LazyModuleMarker))


# Generated at 2022-06-24 03:01:16.169545
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10

# Generated at 2022-06-24 03:01:25.164390
# Unit test for function make_lazy
def test_make_lazy():
    global test_make_lazy_mod

# Generated at 2022-06-24 03:01:27.359637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	module_mark=_LazyModuleMarker()

# Generated at 2022-06-24 03:01:30.207041
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker is not None


# Generated at 2022-06-24 03:01:32.862339
# Unit test for function make_lazy
def test_make_lazy():
    sys.path.insert(0,"./")
    make_lazy("test_module")

    try:
        import test_module
    except ImportError:
        raise AssertionError("ImportError raised where no error should be raised")

# Generated at 2022-06-24 03:01:34.554999
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1)
    assert NonLocal(None)
    assert NonLocal(1).value == 1
    assert NonLocal(None).value is None

# Generated at 2022-06-24 03:01:37.985907
# Unit test for function make_lazy
def test_make_lazy():
    import subprocess
    assert subprocess is not None
    make_lazy('subprocess')
    assert isinstance(subprocess, _LazyModuleMarker)
    subprocess.Popen
    assert not isinstance(subprocess, _LazyModuleMarker)
    assert len(subprocess.__all__) > 10


# Generated at 2022-06-24 03:01:43.410880
# Unit test for function make_lazy
def test_make_lazy():
    non_local = NonLocal(None)
    sys_modules = sys.modules
    sys_modules["test.lazy"] = non_local
    make_lazy("test.lazy")
    assert isinstance(sys_modules["test.lazy"], _LazyModuleMarker)
    assert sys_modules["test.lazy"] is not non_local

# Generated at 2022-06-24 03:01:46.197127
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['my_lazy_module'] = None

    make_lazy('my_lazy_module')

# Generated at 2022-06-24 03:01:47.190054
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass



# Generated at 2022-06-24 03:01:48.469321
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3

# Generated at 2022-06-24 03:01:57.953424
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test to ensure that attribute lookup on a lazy module forces the import
    """
    # add a fake module to sys.modules to start
    sys_modules = sys.modules  # cache in the locals

    sys_modules['test.test_make_lazy'] = ModuleType('test.test_make_lazy')

    # now make the module lazy!
    make_lazy('test.test_make_lazy')

    # If we are here, we have the lazy module!
    # lets see if we can get an attribute off of it.
    from test import test_make_lazy
    getattr(test_make_lazy, 'test_make_lazy')

    assert True

    # cleanup
    del sys_modules['test.test_make_lazy']



# Generated at 2022-06-24 03:02:03.601806
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Check if parent class have been set correctly
    assert issubclass(_LazyModuleMarker, object)
    # Check if no attributes have been created
    assert len(_LazyModuleMarker.__slots__) == 0
    print('Testing constructing _LazyModuleMarker - OK')


# Generated at 2022-06-24 03:02:04.534281
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	x = _LazyModuleMarker()
	assert(isinstance(x,_LazyModuleMarker))

# Generated at 2022-06-24 03:02:06.992693
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests if class _LazyModuleMarker is constructed
    """
    try:
        lazy_obj = _LazyModuleMarker()
    except NameError:
        assert False, "Class _LazyModuleMarker is not defined"
    except TypeError:
        assert False, "Class _LazyModuleMarker is not instantiated"


# Generated at 2022-06-24 03:02:10.562228
# Unit test for function make_lazy
def test_make_lazy():
    from .test_app3.app3 import app3
    from .test_app3.app3.urls import urlpatterns
    from .test_app3.app3.models import Book
    from .test_app3.app3.views import home
    make_lazy("app3.app3")
    from .app3 import app3
    from .app3.urls import urlpatterns
    from .app3.models import Book
    from .app3.views import home
    del sys.modules["app3.app3"]
    assert "app3.app3" not in sys.modules



# Generated at 2022-06-24 03:02:16.294797
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    #obj.__class__ is _LazyModuleMarker
    assert obj.__class__ is _LazyModuleMarker
    #obj is not None
    assert obj is not None


# Generated at 2022-06-24 03:02:22.489874
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import errno
    import os.path
    import shutil
    try:
        os.mkdir('./testmod')
    except OSError as error:
        if error.errno != errno.EEXIST:
            raise

    with open('./testmod/__init__.py', 'w') as fp:
        fp.write('"""\nThis module is a placeholder for testing.\n"""\n')

    with open('./testmod/testmod.py', 'w') as fp:
        fp.write('SOME_VAR = 5\n')

    make_lazy('testmod.testmod')

    import testmod.testmod

    assert sys.modules['testmod.testmod'].SOME_VAR == 5

# Generated at 2022-06-24 03:02:27.324737
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
	marker = _LazyModuleMarker()
	assert(isinstance(marker, _LazyModuleMarker))
	assert(_LazyModuleMarker.__name__ == "_LazyModuleMarker")
	print("Constructor of class _LazyModuleMarker successful")
	print("all unit tests in _LazyModuleMarker are successful")


# Generated at 2022-06-24 03:02:33.289333
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    ModuleMarker = _LazyModuleMarker()
    assert isinstance(ModuleMarker, object)

# Unit Test for make_lazy

# Generated at 2022-06-24 03:02:43.545127
# Unit test for function make_lazy
def test_make_lazy():
    class DummyModule(object):
        pass

    module_path = 'test_module_path'
    module = DummyModule()
    module.attr1 = 1
    module.attr2 = 2
    module.attr3 = 3

    sys.modules[module_path] = module

    another_module = sys.modules[module_path]

    assert another_module.attr1 == 1
    assert another_module.attr2 == 2
    assert another_module.attr3 == 3

    del sys.modules[module_path]

    make_lazy(module_path)

    another_module = sys.modules[module_path]

    assert not isinstance(another_module, DummyModule)

    assert another_module.attr1 == 1
    assert isinstance(another_module, DummyModule)
    assert another_module.attr

# Generated at 2022-06-24 03:02:49.906958
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    if isinstance(lmm, _LazyModuleMarker):
        print("Instance lmm has been created successfully.")
    else:
        print("Instance lmm has not been created successfully.")

# Generated at 2022-06-24 03:02:55.267195
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5
    n.value = 10
    assert n.value == 10


# Generated at 2022-06-24 03:02:58.187873
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(100)

# Generated at 2022-06-24 03:02:59.045018
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()

# Generated at 2022-06-24 03:03:01.473127
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert(NonLocal(2).value == 2)


# Generated at 2022-06-24 03:03:04.577532
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from NonLocal import NonLocal
    value = NonLocal(None)
    print(value.value)

# Generated at 2022-06-24 03:03:11.174473
# Unit test for function make_lazy
def test_make_lazy():
    try:
        raise TryLater
    except NameError:
        pass

    # Non-local
    error_raise = None
    try:
        raise TryLater
    except NameError as e:
        error_raise = e

    assert error_raise is not None
    assert error_raise.message == "name 'TryLater' is not defined"

    # Local
    error_local = None
    try:
        local_TryLater
    except NameError as e:
        error_local = e

    assert error_local is not None
    assert error_local.message == "name 'local_TryLater' is not defined"

    # Lazy
    error_lazy = None
    try:
        lazy_TryLater
    except NameError as e:
        error_lazy = e

    assert error_lazy == None

    make

# Generated at 2022-06-24 03:03:17.462304
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Given
    class TestClass(object):
        def __init__(self):
            self.a = NonLocal(1)

        def test(self):
            self.a.value = 2
            return self.a

    # When
    test_class = TestClass()

    # Then
    assert test_class.a.value == 1
    assert test_class.test().value == 2

# Generated at 2022-06-24 03:03:23.181421
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test to check that the LazyModule actually works as expected.
    """
    import math

    make_lazy('math')
    assert sys.modules.get('math') is not math

    assert abs(-1) == math.abs(-1)
    assert sys.modules.get('math') is math

# Generated at 2022-06-24 03:03:24.382254
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert m != None


# Generated at 2022-06-24 03:03:25.632246
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def fn_with_NonLocal():
        test_value = NonLocal(1000)
        return test_value.value

    assert fn_with_NonLocal() == 1000



# Generated at 2022-06-24 03:03:30.594980
# Unit test for function make_lazy
def test_make_lazy():
    import sys

    # Import test_module.
    import test_module
    assert test_module.test == "test_module"
    assert not isinstance(test_module, _LazyModuleMarker)
    assert test_module in sys.modules

    # Make test_module lazy.
    make_lazy("test_module")
    import test_module
    assert isinstance(test_module, _LazyModuleMarker)
    assert test_module in sys.modules

    # Import test_module.test_lazy_module.
    import test_module.test_lazy_module
    assert test_module.test_lazy_module.test == "lazy_module"
    assert not isinstance(test_module.test_lazy_module, _LazyModuleMarker)
    assert test_module.test_lazy_