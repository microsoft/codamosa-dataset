

# Generated at 2022-06-24 02:53:27.002601
# Unit test for function make_lazy
def test_make_lazy():
    import os

    try:
        import stat
    except ImportError:
        make_lazy('stat')

    assert os.stat is stat, "test_make_lazy failed!"

test_make_lazy()

# Generated at 2022-06-24 02:53:33.405101
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'test_lazy'
    make_lazy(module_path)
    lazy_module = sys.modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)

    # The real import should happen when we actually ask for an attribute
    lazy_module.foo = 23
    assert lazy_module.foo == 23
    assert sys.modules[module_path] == lazy_module

# Generated at 2022-06-24 02:53:39.177697
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(7)
    b = NonLocal(a)
    assert a.value == 7
    assert b.value == a
    try:
        a = NonLocal(7)
        a.value = 8
        assert False
    except AttributeError:
        pass
    try:
        a = NonLocal(7)
        del a.value
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-24 02:53:40.180846
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(5)
    assert non_local.value == 5

# Generated at 2022-06-24 02:53:52.349925
# Unit test for function make_lazy
def test_make_lazy():
    """
    This is a unit test to validate that make_lazy works as expected.
    """
    import sys
    import os
    import tests.common.sample_module

    og_sample_module = tests.common.sample_module
    sample_module_path = 'tests.common.sample_module'

    # Clear out the cache
    sys.modules.pop(sample_module_path)

    # Should be reloaded if imported
    os.remove(tests.common.sample_module.__file__)

    # Mark sample_module as lazy
    make_lazy(sample_module_path)

    assert sample_module_path in sys.modules
    assert isinstance(sys.modules[sample_module_path], _LazyModuleMarker)

    # Access the module and make sure we load it
    assert og_sample_

# Generated at 2022-06-24 02:53:56.782602
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import random

    def foo():
        n = NonLocal(random.randint(0, 1000))

        def bar():
            n.value = n.value + 1
            return n.value

        return bar

    x, y, z = foo(), foo(), foo()
    assert x() == y() == z()

# Generated at 2022-06-24 02:53:58.594509
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module = _LazyModuleMarker()
    assert isinstance(lazy_module, _LazyModuleMarker)


# Generated at 2022-06-24 02:54:03.542979
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy("os")

    assert os.path.exists("os")
    assert isinstance(os, _LazyModuleMarker)
    assert hasattr(os, "path")
    assert "path" not in os.__dict__

    assert sys.modules["os"] is os

# Generated at 2022-06-24 02:54:07.937581
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal('nonlocal')
    assert t.value == 'nonlocal'


if __name__ == '__main__':
    test_NonLocal()
    make_lazy('re')
    print(re.findall('hello', 'hello world'))

# Generated at 2022-06-24 02:54:18.235102
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure we can make a module lazy, and that it works as expected.
    """
    import sys
    import os

    # Make sure sys.modules is clean before we start.
    assert b'lazy_test' not in sys.modules

    make_lazy('lazy_test')

    # Import the lazy module.
    import lazy_test

    # Make sure the module is lazy (and not an actual module).
    assert isinstance(lazy_test, _LazyModuleMarker)
    assert isinstance(lazy_test, ModuleType)

    # Make sure the module is not actually in sys.modules yet.
    assert b'lazy_test' not in sys.modules

    # Adding an attribute to the lazy module will force import it.
    lazy_test.foo = 'bar'

    # Make sure the module is actually

# Generated at 2022-06-24 02:54:20.665858
# Unit test for function make_lazy
def test_make_lazy():
    import math
    make_lazy('math')
    assert not isinstance(math, _LazyModuleMarker)
    assert math.pi == 3.141592653589793

# Generated at 2022-06-24 02:54:27.574194
# Unit test for function make_lazy
def test_make_lazy():
    """This function is a unit test for function make_lazy."""
    def is_lazy_module(module):
        """
        Returns True for a LazyModule else returns False
        """
        return isinstance(module, _LazyModuleMarker)

    import os
    import djcelery
    import djcelery.tests

    assert is_lazy_module(djcelery)

    assert 'TEST_BROKER_URL' in dir(djcelery.tests)

    make_lazy('djcelery.tests')
    assert is_lazy_module(djcelery.tests)

    assert 'TEST_BROKER_URL' not in dir(djcelery.tests)
    assert 'TEST_BROKER_URL' in dir(djcelery.tests)

# Generated at 2022-06-24 02:54:31.940837
# Unit test for function make_lazy
def test_make_lazy():
    module_name = 'os'
    make_lazy(module_name)
    assert module_name in sys.modules
    mod = sys.modules[module_name]
    assert not isinstance(mod, ModuleType)
    assert hasattr(mod, 'system')
    assert isinstance(mod, ModuleType)

# Generated at 2022-06-24 02:54:34.395765
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    title("test__LazyModuleMarker")
    lazy_module_marker_object = _LazyModuleMarker()


# Generated at 2022-06-24 02:54:42.862488
# Unit test for function make_lazy
def test_make_lazy():
    # List of module names
    module_names = ['test_1', 'test_2']

    # List of modules
    module_list = []
    for name in module_names:
        module_list.append(LazyImport(name))

    for i in range(0, len(module_list)):
        # Check if the module is a LazyModule
        assert(isinstance(module_list[i], _LazyModuleMarker))
        # Check if the modules are different
        assert(id(module_list[i]) != id(module_list[i-1]))
        print(id(module_list[i]))

    # Check whether the module is loaded
    assert('test_1' in sys.modules)
    assert('test_2' in sys.modules)
    # Check if the module is a LazyModule

# Generated at 2022-06-24 02:54:51.574504
# Unit test for function make_lazy
def test_make_lazy():
    # separate sys.modules for this test
    sys.modules = sys.modules.copy()

    make_lazy('__module_a')

    assert sys.modules['__module_a'].__class__ == NonLocal
    assert sys.modules['__module_a'].value == None

    # test the isinstance check
    assert isinstance(sys.modules['__module_a'], ModuleType)
    assert isinstance(sys.modules['__module_a'], _LazyModuleMarker)

    # test that __mro__ returns the right tuple
    assert sys.modules['__module_a'].__mro__() == (NonLocal, ModuleType)

    # call the getattribute function
    sys.modules['__module_a'].test

    # make sure the module is actually loaded

# Generated at 2022-06-24 02:54:55.706622
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test that _LazyModuleMarker is initialized correctly
    """
    lazy_module = _LazyModuleMarker()
    assert lazy_module is not None

# Generated at 2022-06-24 02:54:56.965691
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    return True


# Generated at 2022-06-24 02:54:59.532203
# Unit test for constructor of class NonLocal

# Generated at 2022-06-24 02:55:09.463592
# Unit test for function make_lazy
def test_make_lazy():
    # Create a dummy module
    module = {'__name__': __name__ + '.test'}
    # Mangle sys.module
    sys.modules[__name__ + '.test'] = module

    # Make the dummy module lazy
    make_lazy(__name__ + '.test')
    # Ensure that the module is lazy
    assert isinstance(sys.modules[__name__ + '.test'], _LazyModuleMarker)

    # __name__ is still in the module
    assert '__name__' in dir(module)
    # But __name__ is not in the sys.modules[...].__dict__
    assert '__name__' not in dir(sys.modules[__name__ + '.test'])

    # Clean up
    del sys.modules[__name__ + '.test']

# Generated at 2022-06-24 02:55:16.691171
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure that the `make_lazy` function works.
    """
    import time
    import sys

    def long_module():
        time.sleep(1)
        return True

    sys.modules['long_module'] = long_module

    # lazy module should not take a long time
    start = time.time()
    make_lazy('long_module')
    end = time.time()

    assert end - start < 0.1

    # lazy module should be identical to the real version if it's imported
    assert sys.modules['long_module']() is True
    assert sys.modules['long_module'].__class__ is not long_module

    # and it should be fast now :)
    start = time.time()
    assert sys.modules['long_module']() is True
    end = time.time()



# Generated at 2022-06-24 02:55:22.576875
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("os.path")
    assert isinstance(os.path, _LazyModuleMarker)

    from os.path import join
    assert isinstance(os.path, ModuleType)
    assert join("a", "b") == "a/b"

# Generated at 2022-06-24 02:55:31.654350
# Unit test for function make_lazy
def test_make_lazy():
    from tests.test_utils import _TestModule
    module_path = 'test_module'
    make_lazy(module_path)
    try:
        # At this point the test module should not be in sys.modules
        assert module_path not in sys.modules

        # Importing should not do anything
        __import__(module_path)

        # And still not be in sys.modules
        assert module_path not in sys.modules

        # At this point accessing module_path should cause it to be imported
        # and put in sys.modules
        assert isinstance(sys.modules[module_path], _TestModule)
    finally:
        if module_path in sys.modules:
            del sys.modules[module_path]



# Generated at 2022-06-24 02:55:41.801431
# Unit test for function make_lazy
def test_make_lazy():
    import os.path
    import os
    # Run test if os.path has not yet been imported
    assert isinstance(os.path, _LazyModuleMarker) is False
    make_lazy('os.path')
    assert isinstance(os.path, _LazyModuleMarker) is True
    # Get a submodule of os.path to make sure that it is still lazy
    assert isinstance(os.path.join, _LazyModuleMarker) is True
    assert os.path.join
    # Check that we can still import os.path manually and it is no longer lazy
    assert isinstance(__import__('os.path'), _LazyModuleMarker) is False



# Generated at 2022-06-24 02:55:43.866121
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(isinstance(_LazyModuleMarker(), _LazyModuleMarker))
    assert(not isinstance(_LazyModuleMarker(), ModuleType))


# Generated at 2022-06-24 02:55:50.356354
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert issubclass(x.__class__, object)
    # TODO: Fix this test
    # assert isinstance(x, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:51.862615
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class BLA(_LazyModuleMarker):
        pass

    assert issubclass(BLA, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:54.039479
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from . import _LazyModuleMarker
    _LazyModuleMarker()


# Generated at 2022-06-24 02:56:02.058431
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test to test function make_lazy.
    """
    class MyLazyModule:
        loaded = None
        @staticmethod
        def init():
            MyLazyModule.loaded = True

    sys.modules['my_lazy_module'] = MyLazyModule()

    make_lazy('my_lazy_module')

    assert isinstance(sys.modules['my_lazy_module'], _LazyModuleMarker)
    assert MyLazyModule.loaded is None

    sys.modules['my_lazy_module'].init()

    assert MyLazyModule.loaded is True

# Generated at 2022-06-24 02:56:07.202735
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    make_lazy('os.path.walk')
    assert sys.modules['os.path.walk'] is not None
    import os.path
    os.path.walk
    assert sys.modules['os.path.walk'] == __import__('os.path.walk')

# Generated at 2022-06-24 02:56:17.780401
# Unit test for function make_lazy
def test_make_lazy():
    def _test(module_path):
        import sys
        import imp
        import types

        imp.reload(sys)
        make_lazy(module_path)
        assert isinstance(sys.modules[module_path], types.ModuleType)
        assert sys.modules[module_path].__name__ == module_path

        foo = getattr(sys.modules[module_path], 'foo')
        assert foo == 'bar'
        assert isinstance(sys.modules[module_path], types.ModuleType)
        assert sys.modules[module_path].__name__ == module_path

    def test(module_path):
        _test(module_path)
        del sys.modules[module_path]
        import sys
        import types

        _test(module_path)
        del sys.modules[module_path]


# Generated at 2022-06-24 02:56:18.798039
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(0)
    assert n.value==0 


# Generated at 2022-06-24 02:56:25.034085
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    sys.path.append("../lib/python2.7/site-packages/")
    import pytest
    with pytest.raises(TypeError):
        a = NonLocal("test")
        b = NonLocal("test")
        b = a
        c = NonLocal("test")
        c = NonLocal("test")


# Generated at 2022-06-24 02:56:27.199439
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    LazyModuleMarker = _LazyModuleMarker()
    assert isinstance(LazyModuleMarker, object)


# Generated at 2022-06-24 02:56:38.393593
# Unit test for function make_lazy
def test_make_lazy():
    """
    A test to ensure that the lazily loaded module is pass `isinstance`
    checks.
    """
    import sys

    LAZY_MODULE_PATH = 'my_lazy_module'

    # We create a module that we can import to simulate
    # a Python module that we can load.
    class MyModule(ModuleType):
        pass

    orig_mod = MyModule('my_lazy_module')
    orig_mod.__file__ = 'fake_file'
    orig_mod.__path__ = ['fake_path']
    orig_mod.__name__ = 'my_lazy_module'
    orig_mod.__loader__ = None

    # we can't use globals() here because we are inside a function
    # and it's scope doesn't include '__name__'.

# Generated at 2022-06-24 02:56:43.891838
# Unit test for function make_lazy
def test_make_lazy():
    import tests
    import tests.lazy
    make_lazy("tests.lazy")
    assert "tests.lazy" in sys.modules

    # The module should not be loaded until accessed
    assert not hasattr(tests.lazy, "xyz")
    assert isinstance(tests.lazy, _LazyModuleMarker)

    assert isinstance(tests.lazy, ModuleType)
    assert hasattr(tests.lazy, "xyz")

    # Check that the module has been cached
    

# Generated at 2022-06-24 02:56:47.258224
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Tests the constructor of class _LazyModuleMarker
    """
    # Since the constructor of class _LazyModuleMarker is __init__,
    # and it doesnt return anything, just test for pass.
    _LazyModuleMarker()
    assert True


# Generated at 2022-06-24 02:56:54.466200
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import builtins
    sys.modules['builtins']=builtins
    # construct class _LazyModuleMarker
    lazymarker_instance=_LazyModuleMarker()
    # check if the class constructor is correct
    assert isinstance(lazymarker_instance, builtins.type)
    assert lazymarker_instance.__class__.__name__ == "_LazyModuleMarker"

# Generated at 2022-06-24 02:57:02.888128
# Unit test for function make_lazy
def test_make_lazy():
    def verify_module(_lazymodule):
        assert isinstance(_lazymodule, _LazyModuleMarker)
        assert _lazymodule.__name__ == 'my_lazymodule'
        assert not hasattr(_lazymodule, '__mro__')

    # Monkey patch sys.modules to test the function
    _sys_modules = sys.modules
    try:
        sys.modules = dict()
        import my_lazymodule
        verify_module(my_lazymodule)
    finally:
        sys.modules = _sys_modules
        del _sys_modules


# Generated at 2022-06-24 02:57:12.010295
# Unit test for function make_lazy
def test_make_lazy():
    import pkgutil

    def module_exists(module_path):
        """
        Check if module exists without importing.
        """
        return module_path in sys.modules or \
            pkgutil.find_loader(module_path) is not None

    # noinspection PyUnresolvedReferences
    module_path = 'mark_utils.test_lazy_import.make_lazy_test'
    assert not module_exists(module_path)

    make_lazy(module_path)
    mod = sys.modules[module_path]
    assert isinstance(mod, _LazyModuleMarker)

    # noinspection PyStatementEffect
    mod.foo
    assert module_exists(module_path)



# Generated at 2022-06-24 02:57:16.748056
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    #Unit test 1
    lazy = _LazyModuleMarker()
    assert isinstance(lazy, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:18.429704
# Unit test for function make_lazy
def test_make_lazy():
    sys_modules = sys.modules
    sys_modules['foo'] = None
    make_lazy('foo')
    assert isinstance(sys_modules['foo'], _LazyModuleMarker)

# Generated at 2022-06-24 02:57:23.777760
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import sys
    import six
    a = NonLocal(12)
    b = NonLocal(15)
    assert a.value == 12
    assert b.value == 15



# Generated at 2022-06-24 02:57:24.791257
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(5)
    assert value.value == 5


# Generated at 2022-06-24 02:57:26.244968
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(isinstance(a, _LazyModuleMarker))


# Generated at 2022-06-24 02:57:27.187338
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1


# Generated at 2022-06-24 02:57:32.998798
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test 1:
    #   Initialize class _LazyModuleMarker
    #   Expected:
    #       _LazyModuleMarker()
    class test_class(_LazyModuleMarker):
        def __init__(self):
            pass

    test1 = test_class()
    assert isinstance(test1, _LazyModuleMarker)



# Generated at 2022-06-24 02:57:39.720948
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test(object):
        def __init__(self):
            self.value = NonLocal(None)
        def test(self):
            self.value.value = 1
            assert self.value.value == 1
    t = Test()
    t.test()


# Generated at 2022-06-24 02:57:41.546014
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()
    assert(True)



# Generated at 2022-06-24 02:57:45.434004
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marked_module = _LazyModuleMarker()



# Generated at 2022-06-24 02:57:47.378337
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test constructor of class _LazyModuleMarker
    """

    assert _LazyModuleMarker()


# Generated at 2022-06-24 02:57:52.481810
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # noinspection PyArgumentList
    m = _LazyModuleMarker()
    assert isinstance(m, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:54.797925
# Unit test for constructor of class NonLocal
def test_NonLocal():
    notLocal = NonLocal(1)
    assert notLocal.value == 1
    notLocal.value = 2
    assert notLocal.value == 2

# Generated at 2022-06-24 02:58:02.323048
# Unit test for function make_lazy

# Generated at 2022-06-24 02:58:11.361791
# Unit test for function make_lazy
def test_make_lazy():
    """
    Check if lazy loading of module works
    """
    # Cache sys modules
    sys_modules = sys.modules

    # Check if an exception is raised if the module is not loaded
    try:
        make_lazy('tests.dummy')
    except AttributeError:
        pass
    else:
        raise RuntimeError("Lazy module import failed")

    # Check if the mod module is lazy
    assert isinstance(sys_modules['tests.dummy'], _LazyModuleMarker)

    # Check if module is loaded once attr is accessed
    __import__('tests.dummy')
    assert 'tests.dummy' in sys_modules

    # Cleanup by deleting the module if it exists
    if 'tests.dummy' in sys_modules:
        del sys_modules['tests.dummy']

# Generated at 2022-06-24 02:58:15.178014
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create object of type _LazyModuleMarker
    lazy_module = _LazyModuleMarker()
    # Check if isinstance with type _LazyModuleMarker
    assert isinstance(lazy_module, _LazyModuleMarker)


# Generated at 2022-06-24 02:58:17.133074
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal('test value')
    assert t.value == 'test value'



# Generated at 2022-06-24 02:58:21.128950
# Unit test for constructor of class NonLocal
def test_NonLocal():
    val = 1
    a = NonLocal(val)
    assert a.value == 1


# Generated at 2022-06-24 02:58:22.983515
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('os'), _LazyModuleMarker)


# Generated at 2022-06-24 02:58:31.107785
# Unit test for function make_lazy
def test_make_lazy():
    def mock_import(module_path):
        """Mock an importer"""
        module_data = {
            'lazy_module': 'lazy_module',
            'lazy_module.submodule': 'submodule',
            'lazy_module.submodule.subsubmodule': 'subsubmodule',
        }
        return module_data[module_path]

    def _test_lazy_module(module_path):
        """
        A helper routine that does the testing for a single module_path.
        """
        make_lazy(module_path)
        lazy_module = sys.modules[module_path]

        # Check if lazy_module is of instance of LazyModule
        assert isinstance(lazy_module, _LazyModuleMarker)
        # Check if the lazy module has attribute 'submodule'


# Generated at 2022-06-24 02:58:33.577839
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(a)


# Generated at 2022-06-24 02:58:35.475947
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Should successfully instantiate the _LazyModuleMarker class
    LazyModule = _LazyModuleMarker()
    assert LazyModule

# Generated at 2022-06-24 02:58:43.936472
# Unit test for function make_lazy
def test_make_lazy():
    # Create a dummy module for testing
    import os
    import pathlib
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    module_name = 'lazymodule'
    module_path = os.path.join(temp_dir.name, f'{module_name}.py')
    module_path = os.path.abspath(module_path)
    pathlib.Path(module_path).touch()

    # Write a temporary module

# Generated at 2022-06-24 02:58:51.248192
# Unit test for constructor of class NonLocal
def test_NonLocal():
    glob = "Global"
    result = None
    def has_nonlocal():
        glob = "Has nonlocal"
        a = NonLocal(glob)
        def inner_func():
            nonlocal a
            result = a.value
        inner_func()
        return result
    assert has_nonlocal() == "Has nonlocal"


# Generated at 2022-06-24 02:59:01.495353
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test lazily loading a module
    """
    import os
    import tempfile

    path = os.path.join(tempfile.tempdir, 'testmodule.py')

    with open(path, 'w') as f:
        f.write('a = 1\n')

    import_path = os.path.basename(path)[:-3]
    make_lazy(import_path)

    # now prove it's lazy (this will fail if it's not lazy)
    import testmodule

# Generated at 2022-06-24 02:59:05.498808
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Non-regression test for _LazyModuleMarker constructor.
    """
    x = _LazyModuleMarker()
    assert x



# Generated at 2022-06-24 02:59:13.750120
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests make_lazy function implementation.
    """
    # Initial empty list, will fill it with the members of sys.modules later
    modules_list = []

    # Create the module. Just a dumb function
    def lazy_module():
        return True

    # Make the module lazy
    make_lazy("test_module")

    # Get the modules
    for name, module in sys.modules.items():
        # Check if we have the test module
        if name == "test_module":
            # Check if the module we have and the module we created are the same
            assert (sys.modules["test_module"] == lazy_module) is False

            # Check if the sys.module is a placeholder
            assert (sys.modules["test_module"] == ModuleType) is False

            # Check if the sys.module is an instance of L

# Generated at 2022-06-24 02:59:16.999490
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(make_lazy('sys'), _LazyModuleMarker) # assert sys is a LazyModule


# Generated at 2022-06-24 02:59:18.215445
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(2)
    assert t.value == 2


# Generated at 2022-06-24 02:59:21.227358
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # type: () -> None
    test_obj = NonLocal(None)

    assert isinstance(test_obj, NonLocal)
    assert test_obj.value is None

# Simple unit test for the `make_lazy` function.

# Generated at 2022-06-24 02:59:26.465763
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class Test:
        def __init__(self):
            self.value = NonLocal(None)
            self.value.value = "test"

        def get_value(self):
            return self.value.value

    test = Test()
    assert test.get_value() == "test"

# Generated at 2022-06-24 02:59:36.942957
# Unit test for function make_lazy
def test_make_lazy():
    """Unit test for function make_lazy"""
    import random
    random.seed(42)
    import django
    import datetime
    import sys
    import types
    import os
    reload(sys)

    # Import some modules we can abuse for testing.
    # We will be modifying the modules in various ways
    # so want to be sure we are not testing things
    # that effect the behavior of the system in other ways
    import datetime
    import django
    import json

    # Get the module paths we will be testing with
    # We will later delete the modules from `sys.modules`
    # and test that the namespaces are properly refetched
    # from the files.
    datetime_path = datetime.__name__
    django_path = django.__name__
    json_path = json.__name

# Generated at 2022-06-24 02:59:46.048249
# Unit test for function make_lazy
def test_make_lazy():
    # import to make sure we're not blowing up by importing.
    make_lazy('threading')
    make_lazy('weird.path.that.doesnt.exist')
    assert 'threading' in sys.modules
    assert 'weird.path.that.doesnt.exist' in sys.modules
    assert isinstance(sys.modules['threading'], _LazyModuleMarker)
    assert isinstance(sys.modules['weird.path.that.doesnt.exist'], _LazyModuleMarker)
    # We do import on first attribute request.
    assert sys.modules['threading'].Lock
    assert isinstance(sys.modules['threading'], ModuleType)
    # The weird one should still be a _LazyModuleMarker because it
    # doesn't exist.

# Generated at 2022-06-24 02:59:49.658823
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
        print("Unit test for constructor of class _LazyModuleMarker: Passed")
    except AssertionError:
        print("Unit test for constructor of class _LazyModuleMarker: Failed")
        

# Generated at 2022-06-24 02:59:57.956413
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests the make_lazy function
    """
    import sys
    assert "write_lazy_module" not in sys.modules

    from . import write_lazy_module

    # The 'write_lazy_module' module is now in the sys.modules cache,
    # but it has not been imported because it has been marked as lazy.
    assert "write_lazy_module" in sys.modules
    assert sys.modules["write_lazy_module"] is not None

    # This should trigger an import of the above module.
    assert write_lazy_module.answer == 42

# Generated at 2022-06-24 03:00:01.094862
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    # x.value == 1
    assert x.value == 1


# Generated at 2022-06-24 03:00:02.166963
# Unit test for function make_lazy
def test_make_lazy():
    raise NotImplementedError

# Generated at 2022-06-24 03:00:04.207865
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal('a')
    a.value = 'b'
    assert a.value == 'b'

# Generated at 2022-06-24 03:00:07.148321
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class A(object):
        def __init__(self):
            self.a = NonLocal(123)

        def get_a(self):
            return self.a.value
    a = A()
    assert a.get_a() == 123

# Generated at 2022-06-24 03:00:08.742973
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    

# Generated at 2022-06-24 03:00:12.712662
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'tests.test_module'
    make_lazy(module_path)
    test_module = sys.modules[module_path]

    assert not hasattr(test_module, 'test_value')
    assert test_module.test_value == 1
    assert isinstance(test_module, _LazyModuleMarker)

# Generated at 2022-06-24 03:00:18.853391
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import os
        del os
        raise Exception('The module os should still exist')
    except ImportError:
        pass

    sys.modules['os'] = _LazyModuleMarker()
    make_lazy('os')
    assert not 'os' in sys.modules

    import os
    assert os.path.dirname(__file__)
    assert os in sys.modules

# Generated at 2022-06-24 03:00:24.112365
# Unit test for function make_lazy
def test_make_lazy():
    from os import sys, path

    # Create a dummy module and make sure it can be imported and everything
    # works.
    sys.modules['test_module'] = ModuleType('test_module')
    test_module = __import__('test_module')
    test_module.hello = 'world'

    # Make it lazy
    make_lazy('test_module')

    # verify the module isn't actually loaded
    assert 'test_module' not in sys.modules

    # import the module
    test_module = __import__('test_module')

    # verify we can get the attribute off of it
    assert test_module.hello == 'world'



# Generated at 2022-06-24 03:00:27.017037
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        my_var = _LazyModuleMarker()
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-24 03:00:34.649082
# Unit test for function make_lazy
def test_make_lazy():

    import lazy_module_1
    import lazy_module_2

    assert isinstance(lazy_module_1, _LazyModuleMarker)
    assert isinstance(lazy_module_2, _LazyModuleMarker)

    assert not hasattr(lazy_module_1, '__mro__')
    assert not hasattr(lazy_module_2, '__mro__')

    has_mro = hasattr(lazy_module_1, '__getattribute__')
    assert has_mro

    assert lazy_module_1.name
    assert not has_mro

    assert lazy_module_1.__name__ == 'lazy_module_1'
    assert lazy_module_2.__name__ == 'lazy_module_2'


# Define unit test function

# Generated at 2022-06-24 03:00:37.077517
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    The constructor of class _LazyModuleMarker should return an object
    """
    marker_sample = _LazyModuleMarker()
    assert type(marker_sample) is object


# Generated at 2022-06-24 03:00:38.250865
# Unit test for constructor of class NonLocal
def test_NonLocal():
    t = NonLocal(None)
    assert t.value == None

# Generated at 2022-06-24 03:00:47.404034
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class _LazyModuleMarkerTest(object):
        """
        A marker to indicate a LazyModule type.
        Allows us to check module's with `isinstance(mod, _LazyModuleMarker)`
        to know if the module is lazy.
        """
        pass

    assert(isinstance(_LazyModuleMarkerTest, object))

    # Unit test for method __mro__ of class LazyModule
    class LazyModuleTest(object):
        """
        A standin for a module to prevent it from being imported
        """
        def __mro__(self):
            """
            Override the __mro__ to fool `isinstance`.
            """
            # We don't use direct subclassing because `ModuleType` has an
            # incompatible metaclass base with object (they are both in c)
            # and we are

# Generated at 2022-06-24 03:00:51.945736
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def sum(x):
        sum = NonLocal(0)
        for i in range(x):
            sum.value += i
        return sum.value

    assert sum(0) == 0
    assert sum(10) == 45


# Generated at 2022-06-24 03:00:59.763714
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that make_lazy returns the same module when importing
    """
    import sys
    import pytest
    sys.modules['temp_a'] = None
    make_lazy('temp_a')
    temp_a1 = __import__('temp_a')
    temp_a2 = __import__('temp_a')
    assert(temp_a1 is temp_a2)
    sys.modules.__delitem__('temp_a')
    del sys.modules['temp_a']



# Generated at 2022-06-24 03:01:08.671452
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from tempfile import NamedTemporaryFile as NTF
    from random import Random

    r = Random(42)
    with NTF(delete=False) as file:
        r.seed(43)
        file.write(str(r.randint(0, 100000)))
        file.write('\n')
        file.write(str(r.randint(0, 100000)))
        file.write('\n')
    sys.modules['__main__'] = ModuleType('__main__')
    sys.modules['__main__'].__file__ = file.name
    NonLocal(None).__init__(42)

# Generated at 2022-06-24 03:01:12.825540
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    import os.path
    from os.path import join as pjoin
    from os import remove

    from os import curdir, pardir

    # Override os.path.abspath to allow mocking
    def abspath(path):
        return pjoin(curdir, path)

    sys.modules['os.path'] = types.ModuleType('os.path')
    os_path = sys.modules['os.path']
    os_path.abspath = abspath
    os_path.join = pjoin
    os_path.exists = os.path.exists
    # fake join to prevent mtime checking
    sys.modules['os.path.join'] = pjoin
    sys.modules['os.path.abspath'] = abspath
    # make sure we don't delete anything


# Generated at 2022-06-24 03:01:24.027637
# Unit test for function make_lazy
def test_make_lazy():
    # Make sure the function is callable
    make_lazy('')
    make_lazy('test')

    # Setup the test module
    __import__('test_lazymodulehelper')
    test_module = sys.modules['test_lazymodulehelper']

    # Make sure that the module is not lazy
    assert(isinstance(test_module, ModuleType))
    assert(not isinstance(test_module, _LazyModuleMarker))

    # Make the module lazy
    make_lazy('test_lazymodulehelper')
    test_module = reload(test_module)
    assert(isinstance(test_module, _LazyModuleMarker))

    # Assert that accessing the module directly works
    assert(test_module.__name__ is not None)

    # Assert

# Generated at 2022-06-24 03:01:25.938889
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy = _LazyModuleMarker
    assert isinstance(lazy, type)



# Generated at 2022-06-24 03:01:36.621791
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test function make_lazy.
    """
    make_lazy("test_module")
    import test_module
    assert isinstance(test_module, _LazyModuleMarker)

    # test_module should not be loaded from memory yet.
    assert sys.modules["test_module"] is not None
    assert test_module.__name__ is None
    assert test_module.__file__ is None
    assert test_module.__doc__ is None
    assert test_module.__package__ is None
    assert test_module.__spec__ is None

    # Test by accessing a sub-module test_module.sub_module.
    assert test_module.sub_module.__name__ == "test_module.sub_module"

# Generated at 2022-06-24 03:01:38.953168
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-24 03:01:47.574400
# Unit test for function make_lazy
def test_make_lazy():
    mod_path = 'os.path'
    import os.path

    make_lazy(mod_path)
    lazy_mod = sys.modules[mod_path]

    # Make sure `__mro__` works and `isinstance`
    assert(not isinstance(lazy_mod, ModuleType))
    assert(isinstance(lazy_mod, _LazyModuleMarker))

    # Make sure `getattr` works
    import os.path
    assert(lazy_mod.join('dev', 'null') == os.path.join('dev', 'null'))

    del sys.modules[mod_path]

# Generated at 2022-06-24 03:01:53.397823
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class test_module(object):
        def __init__(self):
            self.lazymodule_marker = _LazyModuleMarker()
    testgetattr = test_module()
    # Unit test for non-lazy case
    assert not isinstance(testgetattr, _LazyModuleMarker)
    # Unit test for lazy case
    assert isinstance(testgetattr.lazymodule_marker, _LazyModuleMarker)
test__LazyModuleMarker()



# Generated at 2022-06-24 03:01:55.348933
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert not isinstance(ModuleType, _LazyModuleMarker)
    assert not isinstance(object, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:03.220793
# Unit test for function make_lazy
def test_make_lazy():
    """
    Encode the test in the docstring.
    """
    from importlib import import_module
    # test that it works for normal imports.
    make_lazy('sys')
    assert sys is import_module('sys')
    # test that it stays imported after lazy loading
    make_lazy('sys')
    assert sys is import_module('sys')
    # test that it works for submodules
    os = sys.os
    make_lazy('sys.os')
    assert sys.os is import_module('sys.os')
    assert os is not sys.os
    # test that the lazy module behaves correctly
    make_lazy('sys.os')
    lazy_os = sys.os
    assert isinstance(lazy_os, ModuleType)

# Generated at 2022-06-24 03:02:05.140023
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(10)
    assert x.value == 10
    x.value = 30
    assert x.value == 30



# Generated at 2022-06-24 03:02:12.539319
# Unit test for function make_lazy
def test_make_lazy():
    import tests.lazy.test_module as test_module
    assert hasattr(test_module, 'Foo')

    make_lazy('tests.lazy.test_module')
    # Test that the module still exists in sys.modules
    from tests.lazy import test_module

    assert hasattr(test_module, 'Foo')
    assert isinstance(test_module, _LazyModuleMarker)
    assert not isinstance(test_module, ModuleType)
    assert not isinstance(test_module, type(sys))

    # Test that accessing a class works.
    assert test_module.Foo is not None
    assert test_module.Foo.bar is not None

    # Test that accessing a function works.
    assert isinstance(test_module.something_fun(), str)

# Generated at 2022-06-24 03:02:22.849262
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules["lazy_module"] = None
    make_lazy("lazy_module")

    assert not isinstance(sys.modules["lazy_module"], LazyModule)

    import lazy_module
    assert isinstance(lazy_module, LazyModule)

    assert hasattr(lazy_module, 'attr')
    assert not getattr(lazy_module, 'attr', None)
    lazy_module.attr = "value"
    assert getattr(lazy_module, 'attr') == "value"

    assert getattr(sys.modules["lazy_module"], 'attr') == "value"

    import lazy_module
    assert getattr(lazy_module, 'attr') == "value"



# Generated at 2022-06-24 03:02:24.077838
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1


# Generated at 2022-06-24 03:02:26.119008
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None
    x.value = 7
    assert x.value == 7


# Generated at 2022-06-24 03:02:28.075461
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_test_attr = NonLocal(1)
    assert nonlocal_test_attr.value == 1

# Generated at 2022-06-24 03:02:31.218507
# Unit test for constructor of class NonLocal
def test_NonLocal():
    o = NonLocal(None)
    o.value = 10
    if o.value != 10: raise RuntimeError("NonLocal")
    if o.value != 10: raise RuntimeError("NonLocal")



# Generated at 2022-06-24 03:02:41.915152
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import inspect

    # save the old module
    original_os = sys.modules['os']

    # test make_lazy
    make_lazy('os')

    assert 'os' in sys.modules, \
        "make_lazy failed to add os to sys.modules"

    # test sys.modules['os'] is a lazy module
    assert isinstance(sys.modules['os'], _LazyModuleMarker), \
        "make_lazy failed to make os a lazy module"

    # test that getattr causes the lazy module to import
    os_getcwd = inspect.getsource(os.getcwd)
    assert os_getcwd == inspect.getsource(sys.modules['os'].getcwd), \
        "lazy module failed to import"

    # test that a

# Generated at 2022-06-24 03:02:48.261318
# Unit test for function make_lazy
def test_make_lazy():
    #  test setup:
    import sys
    import copy
    from distutils.util import get_platform
    from distutils.sysconfig import get_python_lib

    path = copy.copy(sys.path)

# Generated at 2022-06-24 03:02:50.300644
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal(1)
    assert non_local.value == 1


# Generated at 2022-06-24 03:02:59.390486
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import builtins
    try:
        __builtins__
    except NameError:
        builtins = __builtins__

    class X(_LazyModuleMarker):
        pass

    x = X()
    assert isinstance(x, X)
    assert isinstance(x, _LazyModuleMarker)
    assert isinstance(x, object)
    assert isinstance(x, builtins.object)
    assert not isinstance(x, object)
    assert not isinstance(x, builtins.object)
    return x

# Generated at 2022-06-24 03:03:09.944051
# Unit test for function make_lazy
def test_make_lazy():
    import pytest

    lazy_module = "django_jinja_markdown.markdown"

    make_lazy(lazy_module)

    # Test that our module is not initialized yet
    assert sys.modules[lazy_module].value is None

    # Test that we can get an attribute off of the module
    assert isinstance(markdown, _LazyModuleMarker)

    # Test that our module is now initialized
    assert isinstance(sys.modules[lazy_module].value, ModuleType)
    assert sys.modules[lazy_module].value is markdown

    # Make sure that modules that have already been imported are not lazy
    with pytest.raises(AssertionError):
        make_lazy("django_jinja_markdown.lazy_load")

# Generated at 2022-06-24 03:03:13.971555
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()

# Generated at 2022-06-24 03:03:15.097995
# Unit test for constructor of class NonLocal
def test_NonLocal():
    y = NonLocal(3)
    print(y.value)


# Generated at 2022-06-24 03:03:21.589683
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'X.Y'

    try:
        import X.Y
    except ImportError:
        pass
    del sys.modules['X']
    del sys.modules['X.Y']

    class LazyModule(_LazyModuleMarker):
        pass

    sys.modules['X'] = LazyModule()
    sys.modules['X.Y'] = LazyModule()

    make_lazy('X.Y')

    assert isinstance(sys.modules['X.Y'], LazyModule)
    assert isinstance(sys.modules['X'], LazyModule)

    import X
    import X.Y

    # We couldn't import X.Y because it was LazyModule
    assert not isinstance(X.Y, LazyModule)

    # X was a LazyModule, but we imported X, so X.

# Generated at 2022-06-24 03:03:22.537620
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 03:03:24.422166
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  test = _LazyModuleMarker()
  assert(isinstance(test, _LazyModuleMarker))
