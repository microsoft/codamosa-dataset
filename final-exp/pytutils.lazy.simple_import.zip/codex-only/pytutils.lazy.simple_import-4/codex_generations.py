

# Generated at 2022-06-24 02:53:28.604695
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Arrange
    temp_obj = _LazyModuleMarker()
    # Act
    # Assert
 

# Generated at 2022-06-24 02:53:30.135347
# Unit test for constructor of class NonLocal
def test_NonLocal():
    marker = NonLocal(41)
    assert marker.value == 41



# Generated at 2022-06-24 02:53:32.280075
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    a.value = 2
    assert a.value == 2

# Generated at 2022-06-24 02:53:34.148641
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_test = NonLocal(2)
    assert nonlocal_test.value == 2

# Generated at 2022-06-24 02:53:36.333262
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Assert the constructor of class _LazyModuleMarker is implemented
    correctly.
    """
    assert isinstance(_LazyModuleMarker(), object)



# Generated at 2022-06-24 02:53:39.963266
# Unit test for function make_lazy
def test_make_lazy():
    import os
    path = os.path
    del os
    make_lazy('os')

    assert isinstance(os, _LazyModuleMarker)
    # this should not trigger an import of the os module
    assert not hasattr(os, 'path')

    assert os.path is path

# Generated at 2022-06-24 02:53:41.326847
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal(1).value == 1

# Generated at 2022-06-24 02:53:43.698629
# Unit test for constructor of class NonLocal
def test_NonLocal():
    o = NonLocal(5)
    assert o.value == 5
    o.value = 10
    assert o.value == 10


# Generated at 2022-06-24 02:53:46.764637
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test normal case
    result = _LazyModuleMarker()
    assert isinstance(result, _LazyModuleMarker)



# Generated at 2022-06-24 02:53:48.809775
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_obj = _LazyModuleMarker()
    assert(isinstance(test_obj, _LazyModuleMarker))

# Generated at 2022-06-24 02:53:50.572583
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1


# Generated at 2022-06-24 02:53:53.241539
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test for successful construction of _LazyModuleMarker
    a = _LazyModuleMarker()
    assert isinstance(a, _LazyModuleMarker)


# Generated at 2022-06-24 02:53:54.950738
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, ModuleType) == False



# Generated at 2022-06-24 02:53:58.322902
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    b = NonLocal("luhan")
    assert b.value == "luhan"
    c = NonLocal(NonLocal("qiyu"))
    assert c.value.value == "qiyu"


# Generated at 2022-06-24 02:54:04.885193
# Unit test for function make_lazy
def test_make_lazy():

    class C:
        def method(self):
            return 'method'

    make_lazy('cabal.test.C')
    import cabal.test.C as C2

    assert isinstance(C2, _LazyModuleMarker), 'Unable to make lazy'
    c = C2.C()
    assert C2.C is C
    assert C2.C.method is C.method
    assert c.method() == 'method'

# Generated at 2022-06-24 02:54:06.837020
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('_lazy_module')

    from _lazy_module import test
    assert test() == 'test'

# Generated at 2022-06-24 02:54:17.090222
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from functools import reduce
    from fractions import Fraction
    from operator import add, mul
    from random import randint, choice
    from string import ascii_lowercase
    from random import sample
    values = [randint(1, 99) for _ in range(2**4)]
    s = sample(values, len(values))
    values = [Fraction(a, b) for a, b in zip(sample(values, len(values)),
                                             sample(values, len(values)))]
    variables = dict(zip(list(ascii_lowercase), values))
    # Summation of values
    c_sum = reduce(add, values)
    # Product of values
    c_product = reduce(mul, values)
    # Name of a randomly picked value

# Generated at 2022-06-24 02:54:17.742796
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1



# Generated at 2022-06-24 02:54:19.105718
# Unit test for constructor of class NonLocal
def test_NonLocal():
    if not sys.version_info >= (3, 0):
        return
    # Test for NonLocal constructor
    assert NonLocal(1)


# Generated at 2022-06-24 02:54:26.732964
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Logging
    logger = logging.getLogger(__name__)
    logger.info("Testing '_LazyModuleMarker' class...")
    # Test if the superclass of class object is object
    superclass = object
    logger.info("\tThe superclass of class object is 'object'")
    # Test if the superclass of _LazyModuleMarker class is the same as
    # the superclass of class object
    if _LazyModuleMarker.__mro__[1] == superclass:
        logger.info("\tThe superclass of '_LazyModuleMarker' class is the same as the superclass of class object")
    else:
        logger.info("\tThe superclass of '_LazyModuleMarker' class is different with the superclass of class object")
    # Test the number of super

# Generated at 2022-06-24 02:54:28.378095
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-24 02:54:30.160743
# Unit test for constructor of class NonLocal
def test_NonLocal():
    _nonlocal = NonLocal(0)
    assert(_nonlocal.value == 0)



# Generated at 2022-06-24 02:54:32.568973
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


# Generated at 2022-06-24 02:54:35.996883
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Without parameters
    try:
        m = _LazyModuleMarker()
        assert isinstance(m, _LazyModuleMarker)
    except:
        assert False, "_LazyModuleMarker constructor without parameters failed"


# Generated at 2022-06-24 02:54:39.073930
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Test for function make_lazy
    '''
    assert 'test' not in sys.modules
    make_lazy("test")
    assert 'test' in sys.modules
    # pylint: disable=pointless-statement
    test

# Generated at 2022-06-24 02:54:42.078398
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(value=1)
    assert nonlocal_obj.value == 1

# Generated at 2022-06-24 02:54:45.626872
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_equal
    from nose.tools import assert_true
    from nose.tools import assert_false

    lm = _LazyModuleMarker()
    assert_true(isinstance(lm, _LazyModuleMarker))
    assert_false(isinstance(lm, object))


# Generated at 2022-06-24 02:54:46.964161
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('os')

    from os import path as os_path
    os_path.sep

# Generated at 2022-06-24 02:54:48.430843
# Unit test for constructor of class NonLocal
def test_NonLocal():
    obj = NonLocal(0)
    obj.value += 1
    assert obj.value == 1

# Generated at 2022-06-24 02:54:55.792372
# Unit test for function make_lazy
def test_make_lazy():
    syspath = sys.path
    try:
        sys.path = [os.path.dirname(__file__)]
        mod = 'test_lazy_module'
        try:
            make_lazy(mod)
            assert not module_is_imported(mod), \
                "module should not be imported after make_lazy"
            import test_lazy_module
            assert module_is_imported(mod),\
                "module should be imported after importing it"
            import test_lazy_module as mod2
            assert module_is_imported(mod), \
                "module should be imported after importing it as another name"
        finally:
            imp.reload(sys)
    finally:
        sys.path = syspath



# Generated at 2022-06-24 02:55:05.055295
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'example_module'
    make_lazy(module_path)
    module = sys.modules[module_path]

    # Verify our types
    assert isinstance(module, _LazyModuleMarker)
    assert not isinstance(module, ModuleType)

    # Should not have been imported yet
    with pytest.raises(AttributeError):
        module.example_attr

    # Patch the example module
    example_module = ModuleType(module_path)
    example_module.example_attr = 'example_value'
    sys.modules[module_path] = example_module

    # Should now be real
    assert module.example_attr == 'example_value'
    assert isinstance(module, ModuleType)
    assert not isinstance(module, _LazyModuleMarker)



# Generated at 2022-06-24 02:55:06.278309
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('value')
    return n.value



# Generated at 2022-06-24 02:55:13.861501
# Unit test for function make_lazy
def test_make_lazy():
    if os.name == 'nt':
        from tempfile import _TemporaryFileWrapper
    else:
        from tempfile import _TemporaryFileWrapper
    _, test_filename = tempfile.mkstemp()
    test_filename = test_filename.replace('\\', '\\\\')

    with open(test_filename, 'w') as f:
        f.write('test_value = 5')

    sys.path.append('.')
    make_lazy('test_lazy_module')
    import test_lazy_module
    assert test_lazy_module.test_value == 5
    reload(test_lazy_module)
    assert test_lazy_module.test_value == 5

    os.remove(test_filename)

if __name__ == '__main__':
    test_make_l

# Generated at 2022-06-24 02:55:21.274258
# Unit test for function make_lazy
def test_make_lazy():
    assert isinstance(sys.modules['django.utils.translation.trans_real'], _LazyModuleMarker)

    trans_real = sys.modules['django.utils.translation.trans_real']

    assert hasattr(trans_real, '__mro__')
    assert not hasattr(trans_real, '__getattribute__')

    assert not hasattr(trans_real, 'gettext')

    # Trigger an attribute load to import the module for real.
    gettext = trans_real.gettext

    # Check that the module is imported as a regular module
    assert isinstance(gettext, types.FunctionType)

    # Check that the module is now correctly registered.
    assert isinstance(sys.modules['django.utils.translation.trans_real'], ModuleType)



# Generated at 2022-06-24 02:55:29.760380
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verifies that make_lazy works as expected.
    """
    import test_lazy as not_lazy_module
    assert isinstance(not_lazy_module, ModuleType)
    assert not isinstance(not_lazy_module, _LazyModuleMarker)

    make_lazy('test_lazy')

    import test_lazy as lazy_module
    assert isinstance(lazy_module, ModuleType)
    assert isinstance(lazy_module, _LazyModuleMarker)

    # Verify that the module isn't loaded yet
    assert not ('test_lazy' in sys.modules)

    # Verify that accessing an attribute on the module triggers loading
    assert lazy_module.x == 5
    assert ('test_lazy' in sys.modules)

    # Verify that the lazy module is no longer a

# Generated at 2022-06-24 02:55:36.399444
# Unit test for function make_lazy
def test_make_lazy():
    import os

    assert not isinstance(os, _LazyModuleMarker)

    make_lazy(os.__name__)
    assert os.__name__ == 'os'
    assert isinstance(os, _LazyModuleMarker)

    # os module is still lazy, it is not imported
    assert not (hasattr(os, 'path') or hasattr(os, 'sep'))

    # os module is loaded on the fly
    assert os.path.__name__ == 'os.path'
    assert isinstance(os.path, ModuleType)
    assert 'os.path' in sys.modules
    assert os.sep == '/'
    assert not isinstance(os.path, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:42.560151
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__new__.__doc__ == \
        'Create and return a new object.  See help(type) for accurate signature.', \
        '__new__ method not defined or incorrectly defined on class'

    assert _LazyModuleMarker().__init__.__doc__ == \
        'Initialize self.  See help(type(self)) for accurate signature.', \
        '__init__ method not defined or incorrectly defined on class'

    # Check if __init__ has been overridden in _LazyModuleMarker class, which
    # shouldn't be the case
    assert _LazyModuleMarker.__init__.__func__ == object.__init__.__func__, \
        '__init__ method has been overridden in _LazyModuleMarker class'
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------




# Generated at 2022-06-24 02:55:44.021221
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal('foo')
    assert nl.value == 'foo'


# Generated at 2022-06-24 02:55:50.910798
# Unit test for function make_lazy
def test_make_lazy():
    # Test that we can import a module that is not yet made lazy
    import datetime

    # Remove the module to simulate a non-lazy import
    del sys.modules['datetime']

    # Make lazy
    make_lazy('datetime')

    # Test that we have a lazymodule at this path
    assert isinstance(sys.modules['datetime'], _LazyModuleMarker)

    # Test that module gets imported after an attribute is accessed
    from datetime import datetime
    assert sys.modules['datetime'] == datetime



# Generated at 2022-06-24 02:55:54.165744
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal('foo')
    assert foo.value == 'foo'
    foo.value = 'bar'
    assert foo.value == 'bar'


# Generated at 2022-06-24 02:55:56.356206
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test__LazyModuleMarker._LazyModuleMarker_test_instance = _LazyModuleMarker()


# Generated at 2022-06-24 02:56:06.689703
# Unit test for function make_lazy
def test_make_lazy():
    return None

# These pylint directives quiet some pylint warnings.
# pylint: disable=W0622,W0613,W0603
import requests
make_lazy(requests.__name__)
# pylint: enable=W0622,W0613,W0603


from requests.auth import HTTPBasicAuth  # noqa
from requests.auth import HTTPDigestAuth  # noqa
from requests.auth import HTTPProxyAuth  # noqa
from requests.auth import AuthBase  # noqa
from requests.auth import _basic_auth_str  # noqa
from requests.auth import _digest_auth_str  # noqa
from requests.auth import _handle_401  # noqa
from requests.cookies import cookiejar_from_dict  # noqa
from requests.cookies import dict

# Generated at 2022-06-24 02:56:08.110254
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(LazyModule, _LazyModuleMarker)


# Generated at 2022-06-24 02:56:17.818423
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import warnings

    path = os.path.dirname(__file__)

# Generated at 2022-06-24 02:56:23.541328
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test for function make_lazy
    """
    # create a fake module
    test_module = 'test_module'

    # add the module to sys.modules
    test_module_instance = sys.modules[test_module] = 'test_module'

    # make the module lazy
    make_lazy(test_module)

    # get the module
    new_test_module = sys.modules[test_module]

    # check that the type of the new module is LazyModule
    assert isinstance(new_test_module, _LazyModuleMarker)

    # make sure that a new module does not have the same module as the original
    assert new_test_module is not test_module_instance

    # make sure the submodule still works
    assert sys.modules[test_module].foo is None

    # set

# Generated at 2022-06-24 02:56:29.423967
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    lazy_module_marker = _LazyModuleMarker()
    # test if _LazyModuleMarker has been created
    assert isinstance(lazy_module_marker, _LazyModuleMarker)
    # test if _LazyModuleMarker is not an instance of object (as it is not intended)
    assert not isinstance(lazy_module_marker, object)


# Generated at 2022-06-24 02:56:31.426700
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5


# Generated at 2022-06-24 02:56:33.493008
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1



# Generated at 2022-06-24 02:56:43.486508
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the make_lazy function works as expected.
    """
    import sys
    old_modules = list(sys.modules.keys())
    make_lazy('test_lazy')
    import test_lazy
    assert isinstance(test_lazy, _LazyModuleMarker)

    # Make sure nothing else was imported.
    new_modules = [k for k in sys.modules.keys() if k not in old_modules]
    assert new_modules == ['test_lazy']

    # Make sure test_lazy gets the lazy module
    # have to do a separate import here because pytest does some internal
    # importing that makes the test not work in this function.
    import test_lozenge
    import test_lazy as test_lazy_real
    assert test_lozenge.test_l

# Generated at 2022-06-24 02:56:45.285467
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    
    

# Generated at 2022-06-24 02:56:46.616757
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Dummy test for function make_lazy
    '''
    assert True



# Generated at 2022-06-24 02:56:49.870318
# Unit test for constructor of class NonLocal
def test_NonLocal():
    lm = NonLocal({})
    lm.value.update({"a":1})
    assert lm.value == {"a":1}


# Generated at 2022-06-24 02:56:51.396702
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 02:56:56.344130
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module_path = 'test'
    make_lazy(module_path)
    object = sys.modules[module_path]
    assert isinstance(object, _LazyModuleMarker)

# Generated at 2022-06-24 02:56:57.776374
# Unit test for constructor of class NonLocal
def test_NonLocal():
    foo = NonLocal(5)
    assert foo.value == 5


# Generated at 2022-06-24 02:57:06.768333
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test that the `make_lazy` function does what it's supposed to.
    """
    import sys
    import types

    assert 'simple_lazy.test_lazy' not in sys.modules

    try:
        make_lazy('simple_lazy.test_lazy')
        assert 'simple_lazy.test_lazy' in sys.modules
        assert isinstance(sys.modules['simple_lazy.test_lazy'],
                          _LazyModuleMarker)

        from simple_lazy.test_lazy import hello
        assert hello == 'hello'

        assert isinstance(sys.modules['simple_lazy.test_lazy'], types.ModuleType)

    finally:
        del sys.modules['simple_lazy.test_lazy']


# Generated at 2022-06-24 02:57:08.383070
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker.__name__ == '_LazyModuleMarker'


# Generated at 2022-06-24 02:57:09.602114
# Unit test for constructor of class NonLocal
def test_NonLocal():
    ok_(isinstance(NonLocal(5), NonLocal))


# Generated at 2022-06-24 02:57:18.946571
# Unit test for function make_lazy
def test_make_lazy():
    if not hasattr(sys, 'getrefcount'):
        return
    sys.modules['test'] = test

# Generated at 2022-06-24 02:57:23.058259
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = _LazyModuleMarker()


# Generated at 2022-06-24 02:57:24.379286
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3
    print('Test complete')


# Generated at 2022-06-24 02:57:29.410869
# Unit test for function make_lazy
def test_make_lazy():
    import django.utils.simplejson as json
    import django.core.files.utils as file_utils
    import django.utils.importlib as importlib
    import django.core.serializers.python as python_serializers

    make_lazy('django.utils.simplejson')
    make_lazy('django.core.files.utils')
    make_lazy('django.utils.importlib')
    make_lazy('django.core.serializers.python')

    # make sure we did the right thing
    assert isinstance(json, _LazyModuleMarker)
    assert isinstance(file_utils, _LazyModuleMarker)
    assert isinstance(importlib, _LazyModuleMarker)
    assert isinstance(python_serializers, _LazyModuleMarker)

    # make

# Generated at 2022-06-24 02:57:32.993699
# Unit test for function make_lazy
def test_make_lazy():

    import datetime
    make_lazy('datetime')

    assert isinstance(datetime, _LazyModuleMarker)

    from datetime import date
    assert isinstance(datetime, ModuleType)

    from datetime import date
    pass

# Generated at 2022-06-24 02:57:43.503206
# Unit test for function make_lazy
def test_make_lazy():
    assert len(sys.modules) == 0
    make_lazy('io')
    assert len(sys.modules) == 1

    mod = sys.modules['io']
    assert isinstance(mod, _LazyModuleMarker)
    assert len(sys.modules) == 1

    # Make sure we don't import io until you access an attribute.
    assert len(sys.modules) == 1
    mod.StringIO
    assert len(sys.modules) == 2

    # Make sure we don't import io twice.
    assert len(sys.modules) == 2
    mod.StringIO
    assert len(sys.modules) == 2

    # Make sure that once a module is lazy imported, we can
    # see it in sys.modules.
    mod = sys.modules['io']
    assert isinstance(mod, ModuleType)

# Generated at 2022-06-24 02:57:46.436464
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(_LazyModuleMarker, object)
    marker = _LazyModuleMarker()
    assert isinstance(marker, object)
    assert isinstance(marker, _LazyModuleMarker)

# Generated at 2022-06-24 02:57:55.841590
# Unit test for function make_lazy
def test_make_lazy():
    try:
        import sphinx.ext.graphviz
    except ImportError:
        pass  # We need graphviz to run this test
    else:
        import sphinx
        import sphinx.ext

        graphviz_module = 'sphinx.ext.graphviz'
        assert isinstance(sphinx.ext.graphviz, ModuleType)

        old_module = sys.modules[graphviz_module]
        del sys.modules[graphviz_module]

        make_lazy(graphviz_module)
        assert isinstance(graphviz, _LazyModuleMarker)

        graphviz
        assert isinstance(graphviz, ModuleType)

        # Clean up import cache
        del sys.modules[graphviz_module]

# Generated at 2022-06-24 02:58:05.271033
# Unit test for function make_lazy
def test_make_lazy():
    # Local modules should not override the LazyModule
    import py
    make_lazy('py')
    assert(isinstance(py, _LazyModuleMarker))
    import pytest
    make_lazy('pytest')
    assert(isinstance(pytest, _LazyModuleMarker))

    # If the module is not yet present,
    # then the LazyModule should be imported
    make_lazy('time')
    import time
    assert(isinstance(time, _LazyModuleMarker))
    time.sleep(2)

    # If a module is present and does not have an attribute,
    # then the LazyModule should be loaded.
    make_lazy('test_lazyimport')
    import test_lazyimport
    assert(isinstance(test_lazyimport, _LazyModuleMarker))

# Generated at 2022-06-24 02:58:08.044971
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    myLazyModuleMarker = _LazyModuleMarker()
    assert isinstance(myLazyModuleMarker, _LazyModuleMarker)


# Generated at 2022-06-24 02:58:10.733122
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1



# Generated at 2022-06-24 02:58:20.852023
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class MyClass(object):
        def __init__(self):
            self.my_var = NonLocal(None)

        def setter(self, val):
            self.my_var.value = val

        def getter(self):
            return self.my_var.value


    a = MyClass()
    a.setter(1)
    assert(a.getter() == 1)  # test case 1

    a = MyClass()
    a.setter("Test nonlocal")
    assert(a.getter() == "Test nonlocal")  # test case 2

    a = MyClass()
    a.setter(set(range(0, 10)))
    assert(a.getter() == set(range(0, 10)))  # test case 3

# Generated at 2022-06-24 02:58:22.347559
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(1)
    assert n.value == 1

# Generated at 2022-06-24 02:58:30.473022
# Unit test for function make_lazy
def test_make_lazy():
    import django.db.backends.mysql
    assert not isinstance(django.db.backends.mysql, _LazyModuleMarker)

    make_lazy('django.db.backends.mysql')
    assert isinstance(django.db.backends.mysql, _LazyModuleMarker)

    # django.db.backends.mysql.DatabaseOperations is not available initially
    from django.db.backends import mysql as mysqlimpl
    assert isinstance(django.db.backends.mysql, _LazyModuleMarker)
    assert not isinstance(mysqlimpl, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:39.275298
# Unit test for function make_lazy
def test_make_lazy():
    """
    Ensure the make_lazy function works as expected.
    """
    # Add a test module
    make_lazy('cherrypy.test.test_lazy_imports')
    import cherrypy.test  # noqa: F401
    assert not hasattr(cherrypy.test, 'test_lazy_imports')

    # Trigger it to be imported
    assert hasattr(cherrypy.test, 'test_lazy_imports')

    # Ensure it was fully imported
    assert hasattr(cherrypy.test.test_lazy_imports, 'test_lazy_imports')

    # Remove our test module
    del sys.modules['cherrypy.test.test_lazy_imports']

# Generated at 2022-06-24 02:58:40.559453
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(3)
    assert n.value == 3

# Generated at 2022-06-24 02:58:49.204005
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verify that make_lazy properly replaces the module with a lazy version.
    """
    module_path = 'django.utils.decorators'

    module = sys.modules[module_path]
    assert isinstance(module, ModuleType)
    assert not isinstance(module, _LazyModuleMarker)

    make_lazy(module_path)

    assert module_path not in sys.modules

    lazy_module = sys.modules[module_path]
    assert isinstance(lazy_module, _LazyModuleMarker)
    assert not isinstance(lazy_module, ModuleType)

    # make sure that accessing an attribute triggers the real import
    assert isinstance(lazy_module.available_attrs, ModuleType)

# Generated at 2022-06-24 02:58:50.372369
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    nl.value = 3
    assert(nl.value == 3)



# Generated at 2022-06-24 02:58:56.180149
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    make_lazy('datetime')
    assert not hasattr(datetime, 'datetime')
    assert isinstance(datetime, _LazyModuleMarker)
    assert hasattr(datetime, 'datetime')
    assert datetime.datetime.now()

# Generated at 2022-06-24 02:58:58.645975
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert(a is not None)

if __name__ == '__main__':
    test__LazyModuleMarker()

# Generated at 2022-06-24 02:59:05.312255
# Unit test for function make_lazy
def test_make_lazy():
    """
    Basic testing of module make_lazy
    """
    import pymongo
    make_lazy('pymongo')
    import pymongo
    assert isinstance(pymongo, _LazyModuleMarker), \
        "LazyModule not set to pymongo module"
    assert pymongo.errors is not None, \
        "pymongo.errors not imported when accessed"

# Generated at 2022-06-24 02:59:08.968343
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Define a class that subclasses _LazyModuleMarker
    class Foo():
        pass
    # Check that isinstance for a class that inherits from _LazyModuleMarker
    # is true
    assert(isinstance(Foo(), _LazyModuleMarker))

# Generated at 2022-06-24 02:59:10.004993
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('foo')
    assert n.value == 'foo'

# Generated at 2022-06-24 02:59:11.887867
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value is None
    nl = NonLocal('some value')
    assert nl.value is not None


# Generated at 2022-06-24 02:59:19.920374
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Tests the NonLocal class
    """
    class testNonLocal(object):
        def __init__(self):
            """
            The constructor
            """
            self.x = NonLocal('global')

        def test(self, x):
            """
            The test method
            """
            self.x.value = x

    x = testNonLocal()
    assert x.x.value == 'global'
    x.test('local')
    assert x.x.value == 'local'

# Generated at 2022-06-24 02:59:29.404647
# Unit test for function make_lazy
def test_make_lazy():
    def run_test(module_path):
        sys.modules[module_path] = None  # clear it, if it exists
        make_lazy(module_path)

        module = sys.modules[module_path]
        assert isinstance(module, _LazyModuleMarker)     # it's a LazyModule

        module = __import__(module_path)
        assert module is sys.modules[module_path]        # it's an import

    # make sure it works cross platform
    run_test('os.path')
    run_test('os')
    run_test('os.path')
    run_test('sys')
    run_test('sys.stdout')

# Generated at 2022-06-24 02:59:36.730911
# Unit test for constructor of class NonLocal
def test_NonLocal():

    def f():
        x = NonLocal("apple")
        def g():
            assert x == 'apple'
            x = NonLocal("orange")
        g()

    if sys.version_info[0] > 2:
        # Python 3 allows for nonlocal keyword (see above)
        # This means that this unit test does not apply
        return

    # Execute function f in a new frame to ensure that x gets
    # accessed from a frame other than f
    frame = inspect.currentframe().f_back
    frame.f_globals['f'] = f
    exec("f()", frame.f_globals, frame.f_locals)

# Generated at 2022-06-24 02:59:37.960151
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    obj = _LazyModuleMarker()
    assert isinstance(obj, _LazyModuleMarker) is True

# Generated at 2022-06-24 02:59:47.666260
# Unit test for function make_lazy
def test_make_lazy():
    import types

    import example_mod
    import example_mod.deeper_mod
    import example_mod.deeper_mod.deepest_mod

    # Make every module lazy
    make_lazy("example_mod")
    make_lazy("example_mod.deeper_mod")
    make_lazy("example_mod.deeper_mod.deepest_mod")

    assert not isinstance(example_mod, types.ModuleType)
    assert not isinstance(example_mod.deeper_mod, types.ModuleType)
    assert not isinstance(example_mod.deeper_mod.deepest_mod, types.ModuleType)

# Generated at 2022-06-24 02:59:49.576887
# Unit test for constructor of class NonLocal
def test_NonLocal():
    test_value = 1
    test_obj = NonLocal(test_value)
    assert test_obj.value == test_value


# Generated at 2022-06-24 02:59:54.566311
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_variable = NonLocal('test')
    assert nonlocal_variable.value == 'test'

# Generated at 2022-06-24 03:00:00.777099
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    # Test lazy module creation
    make_lazy("os")
    assert not isinstance(sys.modules["os"], ModuleType)
    assert isinstance(sys.modules["os"], _LazyModuleMarker)

    assert sys.modules["os"].sep == os.sep
    assert isinstance(sys.modules["os"], ModuleType)

    # Test that repeated calls to make_lazy don't break anything
    make_lazy("os")
    assert isinstance(sys.modules["os"], ModuleType)
    assert not isinstance(sys.modules["os"], _LazyModuleMarker)

# Generated at 2022-06-24 03:00:02.126088
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert(~hasattr(_LazyModuleMarker, '__init__'))

# Generated at 2022-06-24 03:00:03.786449
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal('test')
    assert n.value == 'test'



# Generated at 2022-06-24 03:00:05.393287
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker().__class__ == _LazyModuleMarker


# Generated at 2022-06-24 03:00:13.947587
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'my.lazy.module'
    sys.modules[module_path] = object()
    import my.lazy.module as mod
    make_lazy(module_path)

    if hasattr(mod, 'lazy'):
        raise AssertionError('Original module should not have lazy attribute')

    mod.lazy = 'test_attribute'

    if hasattr(mod, 'lazy') is False:
        raise AssertionError('Lazy module does not have lazy attribute')

    if isinstance(mod, ModuleType) is False:
        raise AssertionError('Lazy module is not a `ModuleType`')

    if isinstance(mod, _LazyModuleMarker) is False:
        raise AssertionError('Lazy module is not a `_LazyModuleMarker`')


# Generated at 2022-06-24 03:00:15.484982
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert(lazy_module_marker)



# Generated at 2022-06-24 03:00:17.602718
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()
    assert isinstance(m, _LazyModuleMarker)



# Generated at 2022-06-24 03:00:24.633654
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # test singleton
    a = NonLocal('a')
    b = NonLocal('b')
    assert a != b

    # test slots
    a.value = 'x'
    try:
        a.z = 'z'
    except:
        pass
    else:
        raise Exception('a.z should raise Exception')

    # test __init__
    assert a.value == 'x'
    assert b.value == 'b'



# Generated at 2022-06-24 03:00:27.969173
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import sys
    import types
    lazyModule = _LazyModuleMarker()
    assert(isinstance(lazyModule, types.ModuleType))
    assert sys.modules["lazyModule"] == "lazyModule"


# Generated at 2022-06-24 03:00:36.765712
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test of function make_lazy
    """
    module_path = 'hmmlearn.utils'
    module = sys.modules[module_path]
    assert not isinstance(module, _LazyModuleMarker)

    make_lazy(module_path)
    module = sys.modules[module_path]
    assert isinstance(module, _LazyModuleMarker)

    from hmmlearn.utils import log_multivariate_normal_density
    module = sys.modules[module_path]
    assert not isinstance(module, _LazyModuleMarker)

if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 03:00:41.165386
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert(nl.value == 42)

if __name__ == '__main__':
    import sys
    make_lazy('foo')
    f = sys.modules['foo']
    assert(isinstance(f, _LazyModuleMarker))
    import os
    os.path
    assert(not isinstance(f, _LazyModuleMarker))
    print("Tests pass!")

# Generated at 2022-06-24 03:00:41.962267
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(100)
    assert a.value == 100


# Generated at 2022-06-24 03:00:43.500353
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Test case 1: constructor of class _LazyModuleMarker
    m = _LazyModuleMarker()
    assert m is not None


# Generated at 2022-06-24 03:00:45.420868
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
    assert issubclass(_LazyModuleMarker, _LazyModuleMarker)


# Generated at 2022-06-24 03:00:52.754201
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test constructor of class _LazyModuleMarker
    """
    assert _LazyModuleMarker()

test__LazyModuleMarker()

"""
The following code is modified from the original source in the following ways:
    1. The original assert_raises_regex is renamed to assert_raises_regexp
    2. The original 'regex' argument is renamed to 'regexp'
    3. assert_raises_regexp is modified to accept option __exact__ argument for
       controlling the exactness of matching exception message.

This is done to make the assert compatible with both python2 and 3.
TODO : modify the code so that there is no need for hack around.
"""

# Regular expression pattern to match valid Python identifiers
#
# Identifiers are defined very loosely here, we are just trying to be able

# Generated at 2022-06-24 03:00:56.310362
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None


# Generated at 2022-06-24 03:00:58.174947
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  marker = _LazyModuleMarker()
  assert marker
  assert isinstance(marker, _LazyModuleMarker)


# Generated at 2022-06-24 03:01:01.222713
# Unit test for constructor of class NonLocal
def test_NonLocal():
    "Unit test for constructor of class NonLocal"
    nl = NonLocal("test")
    assert nl.value == "test"


# Generated at 2022-06-24 03:01:03.311175
# Unit test for constructor of class NonLocal
def test_NonLocal():
    non_local = NonLocal('non_local')
    assert non_local.value == 'non_local'


# Generated at 2022-06-24 03:01:05.438148
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonLocal = NonLocal("this is the value")
    assert nonLocal.value == "this is the value"


# Generated at 2022-06-24 03:01:10.572613
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import inspect

    # First we assert that we haven't loaded the module yet
    assert inspect.getmodule(make_lazy) is None

    # Mark that this module should not be imported until an
    # attribute is needed off of it.
    make_lazy(__name__)

    # We assert that it's LazyModule now
    assert isinstance(sys.modules[__name__], _LazyModuleMarker)

    # And now __module__ should be loaded
    assert isinstance(sys.modules[__name__], ModuleType)

# Generated at 2022-06-24 03:01:11.834120
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3

# Generated at 2022-06-24 03:01:19.385039
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make lazy function
    """
    # Given
    make_lazy('test_mod')

    # When
    mod = sys.modules['test_mod']

    # Then
    assert mod is not None
    assert mod is not None
    assert isinstance(mod, _LazyModuleMarker)  # Should be able to be lazy
    assert sys.modules['test_mod'] is not None


# Generated at 2022-06-24 03:01:20.702271
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    m = _LazyModuleMarker()

# Generated at 2022-06-24 03:01:22.648231
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for the constructor of class _LazyModuleMarker
    """
    _LazyModuleMarker()

# Generated at 2022-06-24 03:01:29.377751
# Unit test for function make_lazy
def test_make_lazy():
    import foo
    assert isinstance(foo, _LazyModuleMarker)
    assert foo.x == 1
    assert foo.y == 2


if __name__ == '__main__':
    make_lazy('foo')

    from foo import x
    assert x == 1

    from foo import y
    assert y == 2

    test_make_lazy()

# Generated at 2022-06-24 03:01:34.214393
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(42)
    assert nl.value == 42
"""
Unittest for the class LazyModule
"""
import unittest

# Generated at 2022-06-24 03:01:35.363333
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()


# Generated at 2022-06-24 03:01:38.566348
# Unit test for function make_lazy
def test_make_lazy():
    """
    Unit test for function make_lazy.
    """
    try:
        import this_does_not_exist
        assert False, 'this_does_not_exist module does not exist'
    except ImportError:
        pass

    make_lazy('this_does_not_exist')
    import this_does_not_exist

# Generated at 2022-06-24 03:01:40.026578
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(5)
    assert a.value == 5



# Generated at 2022-06-24 03:01:46.297359
# Unit test for function make_lazy
def test_make_lazy():
    m = sys.modules['__main__']
    m.mod = 'module'
    m.mod_attr = 'attr'
    make_lazy('mod')
    assert sys.modules['mod'] is not None
    assert sys.modules['mod'].mod_attr == 'attr'
    assert sys.modules['mod'].__class__ is not ModuleType
    assert sys.modules['mod'] is m.mod

# Generated at 2022-06-24 03:01:55.697812
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verifies that make_lazy works as intended.
    """
    module_name = 'testmod'

    def get_module():
        """
        Get the module with a name
        """
        return sys.modules[module_name]

    import os
    make_lazy(module_name)

    assert get_module() is not None
    assert not isinstance(get_module(), ModuleType)

    try:
        os.path.isdir(get_module())
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError was expected')

    assert get_module() is not None
    assert get_module().__file__.endswith('.pyc') or get_module().__file__.endswith('.py')

# Generated at 2022-06-24 03:01:58.557089
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("pysigset._common")

    from pysigset._common import *  # noqa

    assert isinstance(pysigset._common, _LazyModuleMarker)  # noqa

# Generated at 2022-06-24 03:02:00.029951
# Unit test for constructor of class NonLocal
def test_NonLocal():
    i = NonLocal(3)
    assert i.value == 3
    pass


# Generated at 2022-06-24 03:02:03.213735
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    "Unit test for constructor of class _LazyModuleMarker"
    _lazy_module_marker = _LazyModuleMarker()
    assert isinstance(_lazy_module_marker, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:04.047904
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(1)
    assert nl.value == 1


# Generated at 2022-06-24 03:02:08.971253
# Unit test for function make_lazy
def test_make_lazy():
    test_module_path = "make_lazy_test"
    test_module = ModuleType(test_module_path)
    test_module.test_value = "hello"
    sys.modules[test_module_path] = test_module

    make_lazy(test_module_path)
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)
    assert sys.modules[test_module_path].__mro__() == (
        sys.modules[test_module_path].__class__, object, object
    )

    del sys.modules[test_module_path]
    assert test_module_path not in sys.modules
    assert sys.modules[test_module_path].test_value == "hello"

# Generated at 2022-06-24 03:02:09.694139
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)



# Generated at 2022-06-24 03:02:10.674753
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value is None


# Generated at 2022-06-24 03:02:17.292206
# Unit test for constructor of class NonLocal
def test_NonLocal():
    testset = [('def', lambda: print("hello")),
               ('if', lambda: print("hello")),
               ('while', lambda: print("hello"))]
    for test in testset:
        x = NonLocal("test")
        x.value = test[0]
        assert x.value == test[0]


# Generated at 2022-06-24 03:02:23.853722
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys

    from copy import copy

    os.environ['LAZY_MODULE_IMPORT'] = "1"

    make_lazy('test.test_lazy')
    mod = sys.modules['test.test_lazy']
    assert mod is not None
    assert isinstance(mod, _LazyModuleMarker)

    # Try a simple attribute lookup.
    assert hasattr(mod, '__file__') is False
    assert isinstance(mod, ModuleType)

    # Make sure that the module is actually available after
    # the attribute is retrieved.
    assert hasattr(mod, '__file__') is True
    assert hasattr(mod, '__name__') is True
    assert isinstance(mod, ModuleType)

    # Make sure that the module is only loaded once
    mod2 = sys

# Generated at 2022-06-24 03:02:33.672127
# Unit test for function make_lazy
def test_make_lazy():
    import __main__
    import matplotlib

    make_lazy('matplotlib.testing')

    assert isinstance(matplotlib.testing, _LazyModuleMarker)
    assert not hasattr(matplotlib, 'testing')
    assert not hasattr(__main__, 'testing')

    matplotlib.testing.assert_str_equal('a', 'a')

    assert hasattr(matplotlib, 'testing')
    assert hasattr(__main__, 'testing')
    assert __main__.testing is matplotlib.testing


# If we are running this file as a script, perform the unit tests.
if __name__ == '__main__':
    test_make_lazy()

# Generated at 2022-06-24 03:02:36.888139
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    try:
        _LazyModuleMarker()  # Raises exception
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-24 03:02:44.333726
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests that LazyModule behaves as expected.
    """
    import traceback
    make_lazy('os')

    assert isinstance(os, _LazyModuleMarker)

    try:
        os.sys
    except:
        # We shouldn't have any ProxiedModule exceptions because
        # the module should be loaded before the exception is raised.
        assert False
        # We should have ImportError printed to sys.stderr
        # TODO: Figure out how to get the stdout from here.
        # import sys
        # sys.stderr.write('ERROR' + traceback.format_exc())

# Generated at 2022-06-24 03:02:49.912566
# Unit test for constructor of class NonLocal
def test_NonLocal():
    local_var = NonLocal(None)
    local_var.value = 1
    print(local_var.value)
    assert local_var.value == 1

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 03:03:01.718579
# Unit test for function make_lazy
def test_make_lazy():
    def assert_is_lazy(mod):
        assert isinstance(mod, _LazyModuleMarker)

    make_lazy('os')
    assert_is_lazy(os)
    assert not isinstance(os, LazyModule)

    import os
    assert not isinstance(os, _LazyModuleMarker)
    make_lazy('os')
    assert_is_lazy(os)

    make_lazy('django.db.backends.base.base')
    assert_is_lazy(django.db.backends.base.base)
    assert not isinstance(django.db.backends.base.base, LazyModule)

    import django.db.backends.base.base

# Generated at 2022-06-24 03:03:03.364537
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
  lazymodule = _LazyModuleMarker()
  assert lazymodule



# Generated at 2022-06-24 03:03:07.992683
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(3)
    assert a.value == 3

# Generated at 2022-06-24 03:03:12.542286
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest

    class _test_LazyModuleMarker(unittest.TestCase):
        def test_constructor(_self):
            assert (isinstance(_LazyModuleMarker(), _LazyModuleMarker)), "Constructor of _LazyModuleMarker does not work"

    test_instance = _test_LazyModuleMarker()
    test_instance.test_constructor(_self = test_instance)

# Unit tests for class LazyModule

# Generated at 2022-06-24 03:03:16.075367
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('spam')
    assert sys.modules['spam'] is not None
    assert isinstance(sys.modules['spam'], _LazyModuleMarker)
    assert not hasattr(sys.modules['spam'], 'key')

# Generated at 2022-06-24 03:03:21.390705
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    This unit test will check if the constructor of _LazyModuleMarker
    is correct or not.
    """
    import sys

    sys.path = ['', '/usr/lib/python2.7', '/usr/lib/python2.7/plat-x86_64-linux-gnu', '/usr/lib/python2.7/lib-tk', '/usr/lib/python2.7/lib-old', '/usr/lib/python2.7/lib-dynload', '/home/nancy/.local/lib/python2.7/site-packages', '/usr/local/lib/python2.7/dist-packages', '/usr/lib/python2.7/dist-packages']
    module_path = 'test'
    make_lazy(module_path)
    import test

# Generated at 2022-06-24 03:03:22.926570
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(1)
    assert a.value == 1


# Generated at 2022-06-24 03:03:26.513932
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class TestNonLocal(unittest.TestCase):
        def test_get_value(self):
            nl = NonLocal('a')
            self.assertEqual(nl.value, 'a')

    unittest.main(argv=['TestNonLocal'])


# Generated at 2022-06-24 03:03:33.735451
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("tests.lazy")
    assert not hasattr(sys.modules["tests.lazy"], "lazy_method")
    # Accessing an attribute on the lazy module should cause that module to
    # get imported
    sys.modules["tests.lazy"].lazy_method()
    assert hasattr(sys.modules["tests.lazy"], "lazy_method")

    assert "tests.lazy" not in sys.modules
    sys.modules["tests.lazy"].lazy_method()
    assert "tests.lazy" in sys.modules