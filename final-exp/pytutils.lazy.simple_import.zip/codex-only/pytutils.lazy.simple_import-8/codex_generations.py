

# Generated at 2022-06-24 02:53:28.699588
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_obj = NonLocal(1)
    nonlocal_obj.value = 2
    assert nonlocal_obj.value == 2

# Generated at 2022-06-24 02:53:33.321734
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # tests isinstance from _LazyModuleMarker
    # instantiate LazyModule
    lazmod = make_lazy('app')
    # test creation of _LazyModuleMarker instance
    assert isinstance(lazmod, _LazyModuleMarker)


# Generated at 2022-06-24 02:53:42.114153
# Unit test for function make_lazy
def test_make_lazy():
    # Test to see if the module is lazily loaded
    import test.make_lazy_test

    class TestModule(ModuleType):
        def __init__(self, *args, **kwargs):
            raise ImportError("Test module failed.")

        def getfoo(self):
            return 'test'

        def __getattr__(self, attr):
            return self.getfoo()

    # Test with a non-existing module
    sys.modules['test.make_lazy_test'] = TestModule()
    try:
        make_lazy('test.make_lazy_test')
    except ImportError:
        pass
    finally:
        if 'test.make_lazy_test' in sys.modules:
            del sys.modules['test.make_lazy_test']

    # Test with an existing module
   

# Generated at 2022-06-24 02:53:47.984385
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    >>> nl = NonLocal(42)
    >>> nl.value
    42
    >>> nl
    <NonLocal object at ...>
    >>> nl.value = 43
    >>> nl.value
    43
    >>> nl
    <NonLocal object at ...>
    """
    pass



# Generated at 2022-06-24 02:53:49.851102
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()
    assert marker is not None
    assert marker is marker



# Generated at 2022-06-24 02:53:52.459225
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(10)
    assert a.value == 10
    a.value = 100
    assert a.value == 100


# Generated at 2022-06-24 02:54:01.133682
# Unit test for function make_lazy
def test_make_lazy():
    class TestClass:
        pass

    class TestSubclass(TestClass):
        pass

    test_module_path = 'testmod'

    make_lazy(test_module_path)

    assert test_module_path in sys.modules
    assert isinstance(sys.modules[test_module_path], _LazyModuleMarker)

    # Test we can actually lazily load a module
    import testmod
    assert testmod.TestClass == TestClass
    assert isinstance(testmod.TestClass(), TestClass)

    assert testmod.TestSubclass == TestSubclass
    assert isinstance(testmod.TestSubclass(), TestSubclass)
    assert isinstance(testmod.TestSubclass(), TestClass)

    # Test we don't reimport the module
    from testmod import TestClass

# Generated at 2022-06-24 02:54:02.075638
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    pass


# Generated at 2022-06-24 02:54:05.137914
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(3)
    assert x.value == 3



# Generated at 2022-06-24 02:54:07.331718
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value == None
    nl.value = 1
    assert nl.value == 1


# Generated at 2022-06-24 02:54:17.619236
# Unit test for function make_lazy
def test_make_lazy():
    # Create some modules for our tests
    sys.modules['example.lazy1'] = None
    sys.modules['example.lazy2'] = None

    # Mark both of them as lazy
    make_lazy('example.lazy1')
    make_lazy('example.lazy2')

    assert 'example.lazy1' in sys.modules
    assert 'example.lazy2' in sys.modules

    # The lazy modules are subclasses of the ModuleType class
    assert issubclass(sys.modules['example.lazy1'], ModuleType)
    assert issubclass(sys.modules['example.lazy2'], ModuleType)

    # The lazy modules have the _LazyModuleMarker class
    assert isinstance(sys.modules['example.lazy1'], _LazyModuleMarker)
    assert isinstance

# Generated at 2022-06-24 02:54:19.196255
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    The constructor of class NonLocal should assign a value to
    the attribute value.
    """
    nl = NonLocal(1)
    assert nl.value == 1

# Generated at 2022-06-24 02:54:25.205244
# Unit test for function make_lazy
def test_make_lazy():
    m = "some_module_to_not_import_now"
    make_lazy(m)

    module = sys.modules[m]
    assert isinstance(module, _LazyModuleMarker)

    # No actual import has happened
    try:
        import importlib
        assert m not in importlib.import_module.cache
    except Exception:
        pass

    module.foo = "bar"
    assert module.foo == "bar"
    assert module is sys.modules[m]

if __name__ == "__main__":
    test_make_lazy()

# Generated at 2022-06-24 02:54:36.823896
# Unit test for function make_lazy
def test_make_lazy():
    '''
    Assert that the module is not imported until accessing an attribute in it.
    '''
    module_to_import = 'lazyload.tests.lazy_module'
    import sys
    make_lazy(module_to_import)

    # Assert that the module has not been loaded into sys.modules yet.
    assert module_to_import not in sys.modules

    # Accessing the module will cause it to load.
    # The module itself has already been loaded, so accessing it is fine.
    from lazyload.tests import lazy_module
    assert isinstance(lazy_module, ModuleType)

    assert module_to_import in sys.modules

    # Importing the module again will not load it again
    import lazyload.tests.lazy_module
    assert lazyload.tests.lazy_module is lazy_

# Generated at 2022-06-24 02:54:38.922255
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mod = _LazyModuleMarker()
    assert isinstance(mod, _LazyModuleMarker)
    assert isinstance(mod, ModuleType)



# Generated at 2022-06-24 02:54:47.923395
# Unit test for function make_lazy
def test_make_lazy():
    import os
    import sys
    import unittest

    class Module(object):
        def __init__(self, path):
            self.path = path
            sys.modules[path] = self

        def __getattribute__(self, attr):
            if attr == 'path':
                return super(Module, self).__getattribute__(attr)

            return 'loaded: %s' % self.path


# Generated at 2022-06-24 02:54:55.688709
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the make_lazy function
    """
    import six

    # clear out sys.modules so we can control the import
    sys.modules.pop('lazy_module_test', None)

    # Setup the fake module
    module = ModuleType('lazy_module_test')

    module.Foo = 'bar'

    sys.modules['lazy_module_test'] = module

    make_lazy('lazy_module_test')
    assert isinstance(module, _LazyModuleMarker)

    lazy_module = sys.modules['lazy_module_test']

    assert isinstance(lazy_module, _LazyModuleMarker)
    assert lazy_module.Foo == 'bar'

    # Check to make sure this works with modules that are not at the top level

# Generated at 2022-06-24 02:55:00.827912
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import random
    # random.choice(): Return a random element from the non-empty sequence seq.
    # When seq is empty, raises IndexError.
    s = ['pass','fail']
    r = random.choice(s)
    # r = 'pass'
    if r == 'pass':
        print('Constructor of class _LazyModuleMarker works!')
    else:
        print('Constructor of class _LazyModuleMarker does not work!')


# Generated at 2022-06-24 02:55:02.174609
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    tst = _LazyModuleMarker()
    assert tst != None


# Generated at 2022-06-24 02:55:03.252015
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    marker = _LazyModuleMarker()



# Generated at 2022-06-24 02:55:09.522245
# Unit test for function make_lazy
def test_make_lazy():
    def test_func():
        make_lazy('os')
        os.name is None

    success = False
    try:
        test_func()
    except (AttributeError, TypeError):
        success = True

    # Assert if we were able to import os without it being imported and called.
    assert success is True

    success = False
    try:
        os.name
    except (AttributeError, TypeError):
        success = True

    # Assert that now that we have tried to import os and use it,
    # we will get an error.
    assert success is True

# Generated at 2022-06-24 02:55:11.088931
# Unit test for constructor of class NonLocal
def test_NonLocal():
    testdata = NonLocal(5)
    assert testdata.value == 5, 'Value of NonLocal is not correctly assigned'

# Generated at 2022-06-24 02:55:16.714916
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from nose.tools import assert_true
    from .modules import _LazyModuleMarker
    a = _LazyModuleMarker()
    assert_true(isinstance(a, _LazyModuleMarker))


# Generated at 2022-06-24 02:55:21.415956
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class Module(_LazyModuleMarker):
        pass
    mod = Module()
    assert mod
    assert isinstance(mod, _LazyModuleMarker)

# Generated at 2022-06-24 02:55:24.111148
# Unit test for constructor of class NonLocal
def test_NonLocal():
    print("Testing NonLocal constructor: NonLocal(value)")
    m = NonLocal(1)
    print("m.value = 1")
    print("Testing if m actually is a container of value 1")
    assert m.value == 1
    print("Success!")
    

# Generated at 2022-06-24 02:55:31.150944
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy("test_make_lazy.test_module")
    import test_make_lazy.test_module
    assert not isinstance(test_make_lazy.test_module, _LazyModuleMarker)
    sys.modules["test_make_lazy.test_module"] = _LazyModuleMarker()
    assert isinstance(test_make_lazy.test_module, _LazyModuleMarker)
    assert "test_module" in test_make_lazy.__dict__
    assert hasattr(test_make_lazy.test_module, "myvar")
    assert test_make_lazy.test_module.myvar == 42
    assert "test_module" in test_make_lazy.__dict__

# Generated at 2022-06-24 02:55:36.552677
# Unit test for constructor of class NonLocal
def test_NonLocal():
    import exceptions
    # test with different input
    for i in [1, 'a', [1, 2, 3], [[1, 2], [2, 3], [3, 4]]]:
        nl = NonLocal(i)
        # test when assigning to it
        try:
            nl.value = 5
        except exceptions.AttributeError:
            pass

# Generated at 2022-06-24 02:55:47.130975
# Unit test for function make_lazy

# Generated at 2022-06-24 02:55:51.992959
# Unit test for function make_lazy
def test_make_lazy():
    from sys import modules
    make_lazy('never_gonna_make_you_lazy')
    from never_gonna_make_you_lazy import MakeYouLazy
    MakeYouLazy()
    assert 'never_gonna_make_you_lazy' not in modules


# Generated at 2022-06-24 02:55:55.672120
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    if hasattr(sys,"version_info") and sys.version_info[0] > 2:
        return hasattr(sys, '_getframe')
    else:
        return not hasattr(sys, '_getframe')


# Generated at 2022-06-24 02:55:57.436220
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    print(_LazyModuleMarker)
    assert type(_LazyModuleMarker) is type


# Generated at 2022-06-24 02:56:06.946259
# Unit test for function make_lazy
def test_make_lazy():
    sys.modules['mod'] = None

    make_lazy('mod')

    # Assert that `sys.modules['mod']` is a LazyModule

# Generated at 2022-06-24 02:56:14.736991
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import platform
    import sys
    import warnings

    # try to import the module normally
    with warnings.catch_warnings(record=True) as w:
        # Warning: importing ModuleNotFoundError
        # will produce a warning message because
        # ModuleNotFoundError is a LazyModule
        make_lazy('builtins')

    assert issubclass(builtins.ModuleNotFoundError, builtins.Exception)
    assert issubclass(builtins.ModuleNotFoundError, _LazyModuleMarker)

    assert issubclass(ModuleNotFoundError, Exception)
    assert issubclass(ModuleNotFoundError, _LazyModuleMarker)
    assert isinstance(ModuleNotFoundError, ModuleType)
    assert not isinstance(ModuleNotFoundError, platform.ModuleType)



# Generated at 2022-06-24 02:56:17.803918
# Unit test for constructor of class NonLocal
def test_NonLocal():
    n = NonLocal(5)
    assert n.value == 5


# Guard against mocking of `sys.modules` by using a closure.
sys_modules = sys.modules

# Mark a few modules as lazy
make_lazy('logging')
make_lazy('django.db.models')

# Generated at 2022-06-24 02:56:21.008133
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    test_NonLocal:
    Create an instance of NonLocal with a given value and check attribute
    value is the same as the value passed to constructor.
    """
    nl = NonLocal(123)
    assert nl.value == 123


# Generated at 2022-06-24 02:56:25.024060
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    Unit test for constructor of class NonLocal
    """
    assert hasattr(NonLocal, 'value'), 'Missing attribute `value`'


# Generated at 2022-06-24 02:56:35.369826
# Unit test for function make_lazy
def test_make_lazy():
    """
    Tests if module is actually lazy by ensuring that if make_lazy is called
    on a module, it doesn't get imported until needed.
    """

    def mock_test():
        """
        This mocks out the __name__ variable so we can test it
        """
        __name__ = 'foo.bar'
        try:
            raise Exception("This module should not have been imported yet!")
        except Exception as e:
            assert False, str(e)
            raise e

    __name__ = '__main__'
    make_lazy('foo.bar')

    import foo.bar
    foo.bar = mock_test  # replace module with our mock test function


# Generated at 2022-06-24 02:56:44.767359
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_lazy
    assert make_

# Generated at 2022-06-24 02:56:56.007190
# Unit test for function make_lazy
def test_make_lazy():
    """
    This function only tests the make_lazy function.
    """
    from os import getcwd

    assert getcwd not in sys.modules
    make_lazy('os.getcwd')
    assert getcwd in sys.modules
    assert not isinstance(getcwd, types.FunctionType)
    assert isinstance(getcwd, _LazyModuleMarker)
    assert getcwd.__name__ == 'getcwd'

    import os
    from shutil import rmtree

    assert os in sys.modules
    assert rmtree not in sys.modules
    make_lazy('shutil.rmtree')
    assert os in sys.modules
    assert rmtree in sys.modules
    assert not isinstance(rmtree, types.FunctionType)

# Generated at 2022-06-24 02:57:03.126946
# Unit test for function make_lazy
def test_make_lazy():
    # Pre-create a mocked module to import
    class RealModule(object):
        pass

    module_path = 'fake-module-123'
    sys.modules[module_path] = RealModule()
    make_lazy(module_path)
    # Verify we can import the newly created lazy module
    lazy_module = importlib.import_module(module_path)
    assert isinstance(lazy_module, _LazyModuleMarker)
    # Verify importing a lazy module does not import the real module
    assert lazy_module is not RealModule
    # Verify attribute-access imports the real module
    assert lazy_module.thing is RealModule
    # Verify the real module is being used on subsequent accesses
    assert lazy_module.thing2 is RealModule

# Generated at 2022-06-24 02:57:05.282433
# Unit test for constructor of class NonLocal
def test_NonLocal():
    tes = NonLocal(5)
    assert tes.value == 5


# Generated at 2022-06-24 02:57:14.256991
# Unit test for function make_lazy
def test_make_lazy():
    def test_module_import():
        import test_module
        return test_module.a

    def lazy_module_import():
        import lazymodule
        return lazymodule.a

    if 'lazymodule' in sys.modules:
        del sys.modules['lazymodule']

    if 'test_module' in sys.modules:
        del sys.modules['test_module']

    test_module = make_lazy('test_module')
    import test_module

    assert isinstance(test_module, _LazyModuleMarker)

    assert test_module_import() == 1
    assert test_module.a == 1

    assert lazy_module_import() == 1
    assert test_module.a == 1


# The lazy modules
make_lazy('libxml2')
make_lazy('lxml._elementpath')

# Generated at 2022-06-24 02:57:24.837330
# Unit test for function make_lazy
def test_make_lazy():
    module_path = 'django.db'

    # Check if module is already loaded (due to previous test)
    if module_path in sys.modules:
        del sys.modules[module_path]

    # Check if module is not loaded
    assert module_path not in sys.modules

    # Load and check module
    make_lazy(module_path)
    assert module_path in sys.modules

    # Check module is lazy and has correct type
    assert isinstance(sys.modules[module_path], _LazyModuleMarker)

    # Access module's attribute and check it's loaded
    sys.modules[module_path].Error
    assert module_path in sys.modules
    assert not isinstance(sys.modules[module_path], _LazyModuleMarker)

# Generated at 2022-06-24 02:57:25.938007
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    x.value = 4
    assert x.value == 4

# Generated at 2022-06-24 02:57:27.339367
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def foo():
        bar = NonLocal(None)
        bar.value = 1
        return bar

    assert foo().value == 1

# Generated at 2022-06-24 02:57:29.039030
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_instance = NonLocal(10)
    print(nonlocal_instance.value)
    nonlocal_instance.value = 100
    print(nonlocal_instance.value)


# Generated at 2022-06-24 02:57:30.411617
# Unit test for constructor of class NonLocal
def test_NonLocal():
    fx = NonLocal("foo")
    assert fx.value == "foo"

# Generated at 2022-06-24 02:57:33.900630
# Unit test for constructor of class NonLocal
def test_NonLocal():
    """
    A test for constructor of class NonLocal
    """
    nonlocal_instance = NonLocal(5)
    assert nonlocal_instance.value == 5

if __name__ == '__main__':
    test_NonLocal()

# Generated at 2022-06-24 02:57:43.543080
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal.__init__.__doc__ == '''
    Simulates nonlocal keyword in Python 2
    '''.strip()
    assert NonLocal.__slots__ == ['value']
    assert NonLocal(0) == NonLocal(0)
    assert NonLocal(0) != 0
    assert NonLocal(0).value == 0

if __name__ == '__main__':
    # Unit test for constructor of class NonLocal
    test_NonLocal()

    # Unit test for make_lazy
    sys.modules = {}
    py2 = 'py2'
    py3 = 'py3'
    bool_ = 'bool'
    py2_and_py3 = 'py2_and_py3'
    zero = 0
    one = 1
    two = 2
    three = 3
    four = 4
   

# Generated at 2022-06-24 02:57:51.632547
# Unit test for function make_lazy
def test_make_lazy():
    # Clear sys.modules
    sys.modules = {}
    LONE_MODULE = '__lone__'
    make_lazy(LONE_MODULE)

    # Make sure that the module was added
    assert LONE_MODULE in sys.modules
    lone_module = sys.modules[LONE_MODULE]

    # Make sure that it is a LazyModule
    assert isinstance(lone_module, _LazyModuleMarker)

    # Mock out the lone module
    lone_module.attribute = 'value'

    # Make sure that we can access the attribute
    assert lone_module.attribute == 'value'

    # Make sure that it is now imported properly
    assert lone_module is sys.modules[LONE_MODULE]

    # Make sure that it is not a lazy module anymore

# Generated at 2022-06-24 02:57:53.667744
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    mm = _LazyModuleMarker()
    assert isinstance(mm, _LazyModuleMarker)


# Generated at 2022-06-24 02:57:58.861246
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os

    # make sure that the sys.modules cache is empty
    assert len(sys.modules) == 0

    module_name = "foo"
    module_path = "foo"

    # Create the module code

# Generated at 2022-06-24 02:58:02.957768
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class NotLazyModule():
        pass
    not_lazy_module = NotLazyModule()
    assert not isinstance(not_lazy_module, _LazyModuleMarker)
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)


# Generated at 2022-06-24 02:58:04.244100
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(0)
    assert x.value == 0


# Generated at 2022-06-24 02:58:07.377132
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nonlocal_a = NonLocal(None)
    nonlocal_a.value = "Test"
    nonlocal_b = NonLocal(None)
    # nonlocal_b still hasn't been initialised
    nonlocal_b.value = "Test2"


# Generated at 2022-06-24 02:58:09.332464
# Unit test for constructor of class NonLocal
def test_NonLocal():
    try:
        x = NonLocal(2)
        assert x.value == 2
    except AssertionError:
        print("AssertionError: test_NonLocal")



# Generated at 2022-06-24 02:58:14.321903
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(42)
    print(x.value)
    print('test_NonLocal() - ok')
#test_NonLocal()

# Generated at 2022-06-24 02:58:21.151679
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os.path
    import tempfile

    path = os.path.join(tempfile.gettempdir(), 'test_make_lazy.py')
    try:
        with open(path, 'a') as f:
            f.write('cat = 5')

        mod = sys.modules.copy()
        make_lazy('test_make_lazy')
        sys.modules = mod
        sys.modules['test_make_lazy'].other

        assert False
    except AttributeError:
        pass
    finally:
        os.unlink(path)



# Generated at 2022-06-24 02:58:28.694863
# Unit test for function make_lazy
def test_make_lazy():
    lazy_module_name = 'random_module_name'
    make_lazy(lazy_module_name)

    import sys
    assert isinstance(sys.modules[lazy_module_name], _LazyModuleMarker)

    # Assert that direct import doesn't work
    with pytest.raises(ImportError):
        __import__(lazy_module_name)

    # Direct import still doesn't work
    with pytest.raises(ImportError):
        __import__(lazy_module_name)

    # Assert that accessing an attribute works
    sys.modules[lazy_module_name].stdout

    # Assert that accessing another attribute works
    sys.modules[lazy_module_name].stdout

# End of unit test

# Generated at 2022-06-24 02:58:31.810869
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    assert True

# Generated at 2022-06-24 02:58:39.697696
# Unit test for function make_lazy
def test_make_lazy():
    reload(sys)
    sys.setdefaultencoding('utf-8')
    from pyzmail.message import Message
    from pyzmail.parse import Parser
    from pyzmail.factory import message_from_string
    from pyzmail.generator import MessageGenerator
    from pyzmail.__main__ import main

    make_lazy('pyzmail.message')
    make_lazy('pyzmail.parse')
    make_lazy('pyzmail.factory')
    make_lazy('pyzmail.generator')
    make_lazy('pyzmail.__main__')
    make_lazy('pyzmail._compat')

    assert isinstance(Message, _LazyModuleMarker)
    assert isinstance(Parser, _LazyModuleMarker)

# Generated at 2022-06-24 02:58:49.040564
# Unit test for function make_lazy
def test_make_lazy():
    def run_tests():
        import datetime
        assert isinstance(datetime, _LazyModuleMarker)
        initialize_datetime(datetime)
        assert isinstance(datetime, ModuleType)
        assert hasattr(datetime, "timedelta")
        assert hasattr(datetime, "date")
        from datetime import timedelta
        from datetime import date

    def initialize_datetime(datetime):
        # Rather than actually import datetime, we can trigger the import
        # by checking for an attribute.  This ensures the tests will actually
        # fail if something is wrong
        assert hasattr(datetime, "timedelta")

    make_lazy("datetime")
    run_tests()
    from datetime import timedelta
    from datetime import date
    run_tests()

# Generated at 2022-06-24 02:58:59.328908
# Unit test for function make_lazy
def test_make_lazy():
    import pprint
    # This import should work
    from corehq.util.test_utils import unit_testing_only
    lazy_modules = [
        'mock',
        'django.utils.translation',
        'django.utils.functional',
        'django.utils.html',
        'django.utils.encoding',
        'django.utils.safestring',
        'django.utils.text',
    ]
    for module in lazy_modules:
        make_lazy(module)
        # pdb.set_trace()

# Generated at 2022-06-24 02:59:01.277358
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    x = _LazyModuleMarker()
    assert isinstance(x, _LazyModuleMarker)


# Generated at 2022-06-24 02:59:07.150721
# Unit test for function make_lazy
def test_make_lazy():
    import six.moves
    assert isinstance(six.moves, _LazyModuleMarker)
    assert hasattr(six.moves, 'queue')
    assert six.moves.queue is queue


if hasattr(__import__, 'lazy'):
    make_lazy = __import__.lazy.make_lazy

# Generated at 2022-06-24 02:59:14.635173
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    sys.modules.pop('lazy_test_module', None)

    make_lazy('lazy_test_module')
    assert not hasattr(sys.modules['lazy_test_module'], 'TEST_ATTR')
    assert not hasattr(sys.modules['lazy_test_module'], 'TEST_ATTR_2')
    assert sys.modules['lazy_test_module'] is not None

    import lazy_test_module
    assert lazy_test_module.TEST_ATTR == 'test_string'
    assert lazy_test_module.TEST_ATTR_2 == 'test_string_2'
    assert sys.modules['lazy_test_module'] is not None


# Global module name
_MODULE_NAME_GLOBAL = 'ssm_cache'




# Generated at 2022-06-24 02:59:18.136580
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy(module_path='lazy')
    from lazy import attr
    assert attr == 123

# Generated at 2022-06-24 02:59:22.392507
# Unit test for function make_lazy
def test_make_lazy():
    mod_path = 'test_mod'

    # Test that lazy modules are lazy
    make_lazy(mod_path)
    mod = __import__(mod_path)
    assert(isinstance(mod, _LazyModuleMarker))

    # Test that the module was really loaded, and that it has the expected
    # data
    attr = mod.some_attr
    assert(attr == 'some value')

# Generated at 2022-06-24 02:59:24.856334
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1
    x.value = 2
    assert x.value == 2


# Generated at 2022-06-24 02:59:25.732759
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert issubclass(LazyModule, _LazyModuleMarker)

# Generated at 2022-06-24 02:59:30.932648
# Unit test for function make_lazy
def test_make_lazy():
    import os

    make_lazy('os')
    assert isinstance(sys.modules['os'], _LazyModuleMarker)

    assert sys.modules['os'] is not os
    assert sys.modules['os'].path is os.path
    assert sys.modules['os'] is os

    import errno
    assert isinstance(sys.modules['errno'], _LazyModuleMarker)
    assert sys.modules['errno'].EEXIST is errno.EEXIST
    assert sys.modules['errno'] is errno

# Generated at 2022-06-24 02:59:32.597606
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lazy_module_marker = _LazyModuleMarker()
    assert lazy_module_marker is not None


# Generated at 2022-06-24 02:59:33.818197
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()



# Generated at 2022-06-24 02:59:41.778096
# Unit test for function make_lazy
def test_make_lazy():
    """
    Verify that `make_lazy` works correctly on modules.
    """
    # Make sure the module does not pre-exist
    import sys
    assert "test_make_lazy_module" not in sys.modules

    # Make sure `make_lazy` works on new modules
    import types
    assert not isinstance(sys.modules["test_make_lazy_module"], types.ModuleType)
    assert isinstance(sys.modules["test_make_lazy_module"], _LazyModuleMarker)

    # Make sure __mro__ is overriden
    assert isinstance(sys.modules["test_make_lazy_module"], ModuleType)

    # Make sure the actual module is loaded when an attribute is
    # dereferenced
    assert sys.modules["test_make_lazy_module"].__name

# Generated at 2022-06-24 02:59:51.741518
# Unit test for function make_lazy
def test_make_lazy():
    # Test sys.modules is updated
    # Test that module that has been lazy loaded returns same
    # object from sys.modules as the module being loaded
    # Test that the lazy module's attributes are the same as
    # the module being loaded
    assert 'unittest_lazy_module' not in sys.modules

    make_lazy('unittest_lazy_module')

    assert 'unittest_lazy_module' in sys.modules

    mod = sys.modules['unittest_lazy_module']
    assert isinstance(mod, _LazyModuleMarker)
    mod.test = 'test_1'

    assert 'test' in mod.__dict__
    assert mod.__dict__['test'] == 'test_1'

    mod = sys.modules['unittest_lazy_module']

# Generated at 2022-06-24 02:59:53.686822
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    _LazyModuleMarker : constructor
    """
    marker = _LazyModuleMarker()
    return marker



# Generated at 2022-06-24 02:59:54.951583
# Unit test for constructor of class NonLocal
def test_NonLocal():
    m = NonLocal(2)
    assert m.value == 2



# Generated at 2022-06-24 03:00:02.092853
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import types
    assert 'import_all_the_things' not in sys.modules
    make_lazy('import_all_the_things')
    assert 'import_all_the_things' in sys.modules
    assert isinstance(sys.modules['import_all_the_things'], types.ModuleType)
    assert not isinstance(sys.modules['import_all_the_things'], LazyModule)

    # ensure that we are lazy
    assert sys.modules['import_all_the_things'].module is None
    assert sys.modules['import_all_the_things'].module is None

    # import the regular module
    __import__('import_all_the_things')
    assert not isinstance(sys.modules['import_all_the_things'], LazyModule)

# Generated at 2022-06-24 03:00:05.479736
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # Create a class instance of _LazyModuleMarker
    obj = _LazyModuleMarker()
    # Check whether the class instance has attribute __mro__
    assert(hasattr(obj, "__mro__"))
    

# Generated at 2022-06-24 03:00:14.010676
# Unit test for function make_lazy
def test_make_lazy():
    """Test for function make_lazy"""
    # Test for correct handling of module import and module attributes
    import_test = NonLocal(True)
    def module_test_fn(x):
        assert import_test.value
        import_test.value = False
        assert x == 10
        return 5

    make_lazy('test_module')
    import test_module
    test_module.test_fn = module_test_fn
    assert test_module.test_fn(10) == 5
    assert not import_test.value

    # Test for correct handling of submodule import and submodule attributes
    import_test.value = True
    def submodule_test_fn(x):
        assert import_test.value
        import_test.value = False
        assert x == 10
        return 5


# Generated at 2022-06-24 03:00:17.534777
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    from pdtools.lib.exceptions import PDToolsProgrammingError
    from pdtools.lib.validators import ensure_isinstance_or_raise
    ensure_isinstance_or_raise(_LazyModuleMarker(), _LazyModuleMarker, PDToolsProgrammingError)
    ensure_isinstance_or_raise(_LazyModuleMarker(), object, PDToolsProgrammingError)



# Generated at 2022-06-24 03:00:26.481854
# Unit test for function make_lazy
def test_make_lazy():
    def intercept_import(name, globals, locals, fromlist, level):
        raise ImportError('No it!')

    module_path = 'flask.ext.mail'

    sys_modules = sys.modules
    sys.modules = {}
    sys.modules['flask.ext.mail'] = None

    sys.meta_path.append(intercept_import)

    make_lazy(module_path)

    sys.meta_path.remove(intercept_import)

    assert isinstance(sys.modules[module_path], _LazyModuleMarker)
    assert hasattr(sys.modules[module_path], 'Mail')

    sys.modules = sys_modules

# Generated at 2022-06-24 03:00:30.694443
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Unit test for constructor of class _LazyModuleMarker
    """
    assert_raises(TypeError, _LazyModuleMarker)



# Generated at 2022-06-24 03:00:39.940006
# Unit test for function make_lazy
def test_make_lazy():
    module_path = '__make_lazy_test__'
    module = sys.modules[module_path] = object()
    make_lazy(module_path)
    try:
        assert isinstance(module, _LazyModuleMarker)
        assert '__make_lazy_test__' in sys.modules
        assert 'foo' not in sys.modules[module_path].__dict__
        sys.modules[module_path].foo = 'bar'
        assert 'foo' in sys.modules[module_path].__dict__
        assert sys.modules[module_path].foo == 'bar'
    except AssertionError:
        del sys.modules[module_path]
        raise
    finally:
        del sys.modules[module_path]

# Generated at 2022-06-24 03:00:45.016384
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    # All instances of _LazyModuleMarker have the same __mro__
    mro = _LazyModuleMarker.__mro__()
    assert mro == (LazyModule, ModuleType)



# Generated at 2022-06-24 03:00:46.122801
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(None)
    assert x.value == None


# Generated at 2022-06-24 03:00:51.434844
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Test for _LazyModuleMarker
    
    """
    assert isinstance( _LazyModuleMarker(), _LazyModuleMarker)



# Generated at 2022-06-24 03:01:01.194593
# Unit test for function make_lazy
def test_make_lazy():
    def assert_is_lazy(module):
        """
        Ensure that the module is lazy (is an instance of a LazyModule)
        """
        assert isinstance(module, _LazyModuleMarker)

    def assert_is_not_lazy(module):
        """
        Ensure that the module is not lazy
        """
        assert not isinstance(module, _LazyModuleMarker)

    assert_is_not_lazy(sys.modules.get("foo_bar.baz", None))

    mod_path = "foo_bar.baz"
    make_lazy(mod_path)
    assert_is_lazy(sys.modules.get(mod_path))

    mod = __import__(mod_path)
    assert_is_not_lazy(mod)

    assert_is_not_l

# Generated at 2022-06-24 03:01:09.753237
# Unit test for function make_lazy
def test_make_lazy():
    """
    Test the functionality of make_lazy
    """
    path = 'edx_lms_xblock.test_utils.test_lazy_imports.test_obj'
    test_obj = ModuleType('test_obj')
    test_obj.name = 'test_obj'
    sys.modules[path] = test_obj

    # Test that a module is normally imported
    from edx_lms_xblock.test_utils.test_lazy_imports import test_obj
    assert test_obj.name == 'test_obj'

    # Mark the module as lazy
    make_lazy(path)

    # Test that after marking it as lazy, it is not imported
    from edx_lms_xblock.test_utils.test_lazy_imports import test_obj
    assert test_obj

# Generated at 2022-06-24 03:01:16.482888
# Unit test for function make_lazy
def test_make_lazy():
    make_lazy('my_test_module')
    mod = sys.modules['my_test_module']
    assert isinstance(mod, _LazyModuleMarker)
    assert not hasattr(mod, '__mro__')
    assert not hasattr(mod, '__file__')

    # accessing an attribute should cause the module to be loaded.
    assert hasattr(mod, '__loader__')
    assert isinstance(mod, ModuleType)

# Generated at 2022-06-24 03:01:18.715522
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal(0)
    a.value = 1
    assert a.value == 1


# Generated at 2022-06-24 03:01:21.858208
# Unit test for constructor of class NonLocal
def test_NonLocal():
    class A(object):
        def __init__(self, value):
            self.value = value

    a = A(5)

    b = NonLocal(a)

    assert b.value == 5, "B did not assign value properly"

# Generated at 2022-06-24 03:01:26.125890
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), object)

# Generated at 2022-06-24 03:01:36.656361
# Unit test for constructor of class NonLocal
def test_NonLocal():
    value = NonLocal(42)

# Generated at 2022-06-24 03:01:44.692005
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import os

    try:
        make_lazy(os.getpid())
        assert False, 'module imports should fail, but didn\'t'
    except Exception as ex:
        print(ex)

    class A(object):
        pass

    class B(object):
        def __mro__(self):
            return (B, A)

    class C(object):
        pass

    b = B()
    c = C()
    print(isinstance(b, A))
    print(isinstance(a, _LazyModuleMarker))

# Generated at 2022-06-24 03:01:46.798230
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    lmm = _LazyModuleMarker()
    assert isinstance(lmm, _LazyModuleMarker)

# Generated at 2022-06-24 03:01:49.996792
# Unit test for constructor of class NonLocal
def test_NonLocal():
    from unittest import TestCase, main

    class NonLocalTest(TestCase):

        def test_nonlocal(self):
            test = NonLocal(1)
            self.assertEquals(test.value, 1)

    main()


# Generated at 2022-06-24 03:01:51.612606
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1

# Generated at 2022-06-24 03:02:00.285111
# Unit test for function make_lazy
def test_make_lazy():
    # We will put our test code into a module
    import sys
    import os
    import numpy
    import inspect

    # Create our module
    def make_test_module():
        module_contents = inspect.getsource(test_make_lazy)
        module_name = 'test_make_lazy_module'

        # Add a __all__ statement to the module to prevent `import *` from
        # importing all the unit tests.
        test_all_str = '__all__ = ["__all__", "make_test_module"]'

        # Create the test module on disk.
        with open('{}.py'.format(module_name), 'w') as module_file:
            module_file.write('{}\n{}'.format(test_all_str, module_contents))

        return module_name



# Generated at 2022-06-24 03:02:03.207932
# Unit test for constructor of class NonLocal
def test_NonLocal():
    nl = NonLocal(None)
    assert nl.value == None
    # Overwrite the value
    nl.value = 1
    assert nl.value == 1



# Generated at 2022-06-24 03:02:03.700667
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    _LazyModuleMarker()

# Generated at 2022-06-24 03:02:11.786005
# Unit test for function make_lazy
def test_make_lazy():
    if sys.version_info[:2] == (2, 6):
        return  # Python 2.6 doesn't have `inspect.getsourcelines`

    # We can't use something like `import inspect; getframe = inspect.currentframe`
    # Because currentframe uses itself internally, so we get infinite recursion.
    # So instead, we're going to just do the raw eval equivalent.
    getframe = eval("lambda: sys._getframe(2)")

    import inspect

    frame = getframe()
    source = inspect.getsourcelines(frame)

    # We want to build the module that the above source will generate.
    # In order to do that, we need to evaluate it.
    module = ModuleType("module_eval")
    exec(source[0], module.__dict__)

    # If we're in a namespace package,

# Generated at 2022-06-24 03:02:15.691587
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-24 03:02:19.487871
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    a = _LazyModuleMarker()
    b = _LazyModuleMarker()
    assert(a is a)
    assert(b is b)
    assert(a is not b)
    assert(type(a) is type(b))
    assert(_LazyModuleMarker is type(a))
    assert(a == b)
    assert(a != None)
# Test __init__ method in class NonLocal

# Generated at 2022-06-24 03:02:23.980714
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    """
    Constructor for class _LazyModuleMarker.
    """
    lazy_module_marker = _LazyModuleMarker()
    print (lazy_module_marker)


# Generated at 2022-06-24 03:02:28.577174
# Unit test for constructor of class NonLocal
def test_NonLocal():
    assert NonLocal
    assert 'value' in NonLocal.__slots__

# Generated at 2022-06-24 03:02:31.730276
# Unit test for constructor of class NonLocal
def test_NonLocal():
    var = NonLocal(1)
    var_value = var.value
    var.value = 2
    var_value_next = var.value
    assert var_value == 1 and var_value_next == 2


# Generated at 2022-06-24 03:02:39.563546
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    import unittest, sys
    this_mod = sys.modules[__name__]
    # print 'dir(this_mod):'
    # print dir(this_mod)
    # print 'dir(this_mod):'
    # print dir(this_mod)
    class Test(unittest.TestCase):
        def test1(self):
            # print 'type(this_mod):'
            # print type(this_mod)
            self.assertTrue(type(this_mod) is _LazyModuleMarker)
    unittest.main()


# end of file

# Generated at 2022-06-24 03:02:41.915550
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    test_marker = _LazyModuleMarker()
    assert isinstance(test_marker, _LazyModuleMarker)


# Generated at 2022-06-24 03:02:45.583686
# Unit test for function make_lazy
def test_make_lazy():
    import sys
    import os
    import glob
    import unittest

    class TestMakeLazy(unittest.TestCase):
        def setUp(self):
            # Create a fresh sys.modules
            self._sys_modules = sys.modules
            sys.modules = {}
            # Create a fake module
            self.filename = os.path.join(tempfile.gettempdir(), 'test.py')
            content = '''
            class A:
                def __init__(self):
                    self.name = 'some function'
            '''
            with open(self.filename, 'w') as file_:
                file_.write(content)

        def tearDown(self):
            for file_ in glob.glob(self.filename[:-4] + '*'):
                os.remove(file_)
            sys

# Generated at 2022-06-24 03:02:47.487313
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker()


# Generated at 2022-06-24 03:02:48.882237
# Unit test for constructor of class NonLocal
def test_NonLocal():
    x = NonLocal(1)
    assert x.value == 1


# Generated at 2022-06-24 03:02:50.084426
# Unit test for constructor of class NonLocal
def test_NonLocal():
    a = NonLocal("some string")
    assert(a.value == "some string")

# Unit tests for the constructor of class LazyModule

# Generated at 2022-06-24 03:03:01.718158
# Unit test for function make_lazy
def test_make_lazy():
    import datetime
    from datetime import date
    from datetime import time
    from datetime import datetime, timedelta
    from datetime import tzinfo
    from datetime import _divide_and_round

    import datetime, sys

    make_lazy('datetime')

# Generated at 2022-06-24 03:03:05.465499
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    module = ModuleType('test')
    assert not isinstance(module, _LazyModuleMarker)

# Generated at 2022-06-24 03:03:13.122364
# Unit test for function make_lazy
def test_make_lazy():
    # Prevent `foo` from being imported by make_lazy
    make_lazy("foo")

    # `foo` is not in sys.modules, since it has not been imported yet
    assert "foo" not in sys.modules

    # Create an istance of the module 'foo'
    foo = sys.modules["foo"]

    # 'foo' is an instance of LazyModule
    assert isinstance(foo, _LazyModuleMarker)

    # Let's make sure that the function make_lazy has worked
    # i.e. 'foo' is not in sys.modules
    assert "foo" not in sys.modules

    # Call an attribute of the module 'foo'
    foo.attr

    # 'foo' is now in sys.modules
    assert "foo" in sys.modules



# Generated at 2022-06-24 03:03:13.980010
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert _LazyModuleMarker() is not None


# Generated at 2022-06-24 03:03:19.517586
# Unit test for constructor of class NonLocal
def test_NonLocal():
    # Tests a value of 1.
    assert NonLocal(1).value == 1
    assert NonLocal([1, 2]).value == [1, 2]
    # Tests a value of 0.
    assert NonLocal(0).value == 0
    # Tests a value of None.
    assert NonLocal(None).value == None
    assert NonLocal(None).value == NonLocal(None).value
    # Tests using an argument which is not of a type that is supported by the constructor.
    assert NonLocal('test').value == 'test'
    assert NonLocal('test').value == NonLocal('test').value

# Generated at 2022-06-24 03:03:22.993073
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    class A(object):
        def __init__(self, a):
            self.a = a

        def __mro__(self):
            return (A, _LazyModuleMarker)

        def __getattribute__(self, attr):
            return super(A, self).__getattribute__(attr)

    assert isinstance(A(1), _LazyModuleMarker)
    assert not isinstance(A(1), object)
    assert not isinstance(A(1), ModuleType)


# Generated at 2022-06-24 03:03:25.186459
# Unit test for constructor of class NonLocal
def test_NonLocal():
    def f():
        x = NonLocal(3)
        def g():
            def h():
                print(x.value)
            h()
        g()
    f()

# Generated at 2022-06-24 03:03:26.747138
# Unit test for constructor of class _LazyModuleMarker
def test__LazyModuleMarker():
    assert isinstance(_LazyModuleMarker(), _LazyModuleMarker)
