

# Generated at 2022-06-21 16:45:45.119356
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('ru')
    assert text.swear_word() == 'хуй'

# Generated at 2022-06-21 16:45:46.740846
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    text = t.title()
    for i in range(len(t._data['text'])):
        assert text != t._data['text'][i]

# Generated at 2022-06-21 16:45:51.219618
# Unit test for method text of class Text
def test_Text_text():

    import mimesis
    t = mimesis.Text()
    t.text()
    assert isinstance(t.text(), str)
    assert isinstance(t.text(quantity=10), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.title(), str)


# Generated at 2022-06-21 16:45:52.503331
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    assert type(txt.color()) == str

# Generated at 2022-06-21 16:46:01.571097
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text"""
    # Создание объекта класса Text
    text_obj = Text()
    # Генерация списка слов
    text_obj_words = text_obj.words(quantity=5)
    # Проверка длины списка
    assert len(text_obj_words) == 5
    # Проверка типа элементов списка
    assert isinstance(text_obj_words[0], str)
    # Проверка

# Generated at 2022-06-21 16:46:03.191258
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']


# Generated at 2022-06-21 16:46:06.075763
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    a = text.color()
    b = text.color()
    c = text.color()
    assert 1==1


# Generated at 2022-06-21 16:46:06.596634
# Unit test for method color of class Text
def test_Text_color():
    pass

# Generated at 2022-06-21 16:46:13.174214
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text(seed=0).swear_word() == "Damn"
    assert Text(seed=1).swear_word() == "Damn"
    assert Text(seed=2).swear_word() == "Crap"
    assert Text(seed=3).swear_word() == "Shit"
    assert Text(seed=4).swear_word() == "Bastard"
    assert Text(seed=5).swear_word() == "Nigga"
    assert Text(seed=6).swear_word() == "Damn"
    assert Text(seed=7).swear_word() == "Crap"
    assert Text(seed=8).swear_word() == "Damn"
    assert Text(seed=9).swear_word() == "Hell"
    assert Text(seed=10).swear_word

# Generated at 2022-06-21 16:46:15.685816
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert t.color() != None


# Generated at 2022-06-21 16:47:54.633458
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() in SAFE_COLORS

# Generated at 2022-06-21 16:47:58.931505
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.text import Text
    text = Text(locale=Locale.RU)
    assert text.swear_word() in text._data.get('words').get('bad')



# Generated at 2022-06-21 16:48:00.678181
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']



# Generated at 2022-06-21 16:48:02.957671
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() == "No"

# Generated at 2022-06-21 16:48:07.509626
# Unit test for method word of class Text
def test_Text_word():
    # create object of class Text
    a = Text()
    # create empty list
    list = []
    # add word of each iteration to list
    for i in range(1, 11):
        list.append(a.word())
    # check whether list is true or not
    assert (list == ['treat', 'treat', 'treat', 'treat', 'treat', 'treat', 'treat', 'treat', 'treat', 'treat'])


# Generated at 2022-06-21 16:48:10.912681
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    txt = Text('en')
    result = txt.level()
    assert isinstance(result, str)
    assert len(result) == 7


# Generated at 2022-06-21 16:48:19.164780
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class SeedText"""
    a = Text(seed=1234)
    b = Text(seed=1234)
    c = np.arange(1, 11)
    for i in range(10):
        print(a.words(), b.words(), sep='\t')
    print(a.words(quantity=c[0]), b.words(quantity=c[1]), sep='\t')
    print(a.words(quantity=c[2]), b.words(quantity=c[3]), sep='\t')
    print(a.words(quantity=c[4]), b.words(quantity=c[5]), sep='\t')


# Generated at 2022-06-21 16:48:20.536890
# Unit test for method quote of class Text
def test_Text_quote():
    test = Text()
    result = test.quote()
    assert result != None


# Generated at 2022-06-21 16:48:22.053361
# Unit test for method color of class Text
def test_Text_color():
    # Arrange
    t = Text()

    # Act
    c = t.color()

    # Assert
    assert isinstance(c, str)

# Generated at 2022-06-21 16:48:26.506847
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level1 = text.level()
    level2 = text.level()
    assert level1 and level2 and level1 != level2, "Fail generate levels"


# Generated at 2022-06-21 16:49:02.640998
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(seed=0)
    print(text.sentence())
    # Output:
    # 该公司无法保证系统操作，还将继续为客户提供产品和服务


# Generated at 2022-06-21 16:49:04.946345
# Unit test for method text of class Text
def test_Text_text():
    obj = Text()
    objs = [obj.text() for i in range(5)]
    assert all(isinstance(i, str) for i in objs)



# Generated at 2022-06-21 16:49:06.705202
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    t = Text()
    assert len(t.text()) > 0


# Generated at 2022-06-21 16:49:08.424263
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Create object of class Text
    t = Text('pt-br')
    # Call method sentence
    print(t.sentence())


# Generated at 2022-06-21 16:49:09.767734
# Unit test for method text of class Text
def test_Text_text():
    """ Test method text. """
    # Test case - 1
    # Test case - 2

    print()



# Generated at 2022-06-21 16:49:11.531988
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word.isalpha()

# Generated at 2022-06-21 16:49:15.490566
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text('id')
    assert t.swear_word() in t._data['words']['bad']

# Generated at 2022-06-21 16:49:18.442789
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    text.seed(0)
    assert text.answer() == 'Yes'
    text.seed(1)
    assert text.answer() == 'No'
    text.seed(2)
    assert text.answer() == 'No'


# Generated at 2022-06-21 16:49:19.643780
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['No', 'Yes', 'I don\'t know']

# Generated at 2022-06-21 16:49:20.692362
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5

