

# Generated at 2022-06-21 16:44:55.634052
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


# Generated at 2022-06-21 16:44:59.826749
# Unit test for method text of class Text
def test_Text_text():
    """ Unit test for method text of class Text """
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    _en = Text(Language.ENGLISH)
    _ru = Text(Language.RUSSIAN)
    _es = Text(Language.SPANISH)

    assert _en.text()
    assert _ru.text()
    assert _es.text()

# Generated at 2022-06-21 16:45:01.067439
# Unit test for method sentence of class Text
def test_Text_sentence():
    u = Text()
    for i in range(0,10):
        print(u.sentence())


# Generated at 2022-06-21 16:45:02.703042
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color(safe=True)
    print(rgb_color)


# Generated at 2022-06-21 16:45:04.717990
# Unit test for method color of class Text
def test_Text_color():
    x = Text('en')
    y = x.color()
    assert y in x._data['color']

# Generated at 2022-06-21 16:45:06.769555
# Unit test for method color of class Text
def test_Text_color():
    color = Text()
    assert color.color()


# Generated at 2022-06-21 16:45:08.617812
# Unit test for method answer of class Text
def test_Text_answer():

    text = Text('en')
    answer = text.answer()
    assert isinstance(answer, str)



# Generated at 2022-06-21 16:45:11.282476
# Unit test for method level of class Text
def test_Text_level():
    """Test level method."""
    t = Text()
    d = Text()
    assert t.level() == d.level()

# Generated at 2022-06-21 16:45:14.002846
# Unit test for method level of class Text
def test_Text_level():
    generator = Text('zh')
    levels = ['危险', '非常危险', '致命', '紧急']
    assert generator.level() in levels

# Generated at 2022-06-21 16:45:19.259267
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Language
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import Text

    print("Unit test for method words of class Text")
    print('-' * 20)

    russian = RussiaSpecProvider()
    text = Text(language=Language.RU)
    print("Random Russian word: {}".format(russian.word()))
    print("Generate list of Russian words: {}".format(text.words()))


# Generated at 2022-06-21 16:47:05.948885
# Unit test for method words of class Text
def test_Text_words():
    import random
    t = Text(random)
    result = t.words()
    assert type(result) == list



# Generated at 2022-06-21 16:47:11.012813
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.mimesis import Mimesis
    from mimesis.providers import Person

    mimesis = Mimesis(locale='en')
    person = Person('en')
    url = mimesis.internet.url()
    
    for i in range(5):
        print(mimesis.text.sentence())
        
    for i in range(5):
        print(mimesis.text.title())


# Generated at 2022-06-21 16:47:12.356757
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.text() == "Hey, you passed in the right arguments."



# Generated at 2022-06-21 16:47:14.904973
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert (t.title() is not None)


# Generated at 2022-06-21 16:47:16.497904
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    assert len(provider.sentence()) >= 10

# Generated at 2022-06-21 16:47:21.707617
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert len(t.text(1).split(' ')) == 1
    assert len(t.text(2).split(' ')) == 2
    assert len(t.text(3).split(' ')) == 3
    assert len(t.text(4).split(' ')) == 4
    assert len(t.text(5).split(' ')) == 5
    assert len(t.text().split(' ')) == 5


# Generated at 2022-06-21 16:47:25.068956
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test rgb_color method."""
    t = Text()
    res = t.rgb_color(safe=True)
    # res = t.hex_color(safe=True)
    # res = t.rgb_color(safe=False)
    assert res in SAFE_COLORS

# Generated at 2022-06-21 16:47:25.666213
# Unit test for constructor of class Text
def test_Text():
    text = Text()

# Generated at 2022-06-21 16:47:28.865588
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    text = Text()
    assert len(text.alphabet()) == len(text.alphabet(lower_case=True))


# Generated at 2022-06-21 16:47:30.389646
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text().hex_color(safe = True) in SAFE_COLORS

# Generated at 2022-06-21 16:53:47.843719
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text('tr')
    assert len(text.sentence() )> 0

# Generated at 2022-06-21 16:53:49.345809
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    for i in range(4):
        assert isinstance(t.word(), str)


# Generated at 2022-06-21 16:53:52.917276
# Unit test for method quote of class Text
def test_Text_quote():
    """Test text.quote() function."""
    t = Text()
    quote = t.quote()
    assert type(quote) is str


# Generated at 2022-06-21 16:53:53.737483
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert (t is not None)

# Generated at 2022-06-21 16:53:58.256519
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import RussiaSpecProvider
    ru_spec = RussiaSpecProvider()
    ru_spec_text = ru_spec.text
    ru_spec_text_color = ru_spec_text.color()
    assert ru_spec_text_color != ''
    assert ru_spec_text_color != ru_spec_text.color()
    return ru_spec_text_color


# Generated at 2022-06-21 16:54:01.684628
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    assert len(text.quote()) > 10
    assert isinstance(text.quote(), str)


# Generated at 2022-06-21 16:54:05.546900
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    result = text.rgb_color()
    assert isinstance(result, tuple)
    for element in result:
        assert isinstance(element, int)
        assert element >= 0 and element <= 255

    text = Text(seed=1)
    result = text.rgb_color()
    assert result == (226, 17, 92)


# Generated at 2022-06-21 16:54:07.064559
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    provider = Text()
    assert isinstance(provider.swear_word(), str)

# Generated at 2022-06-21 16:54:13.821857
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    from mimesis.providers.text import Text
    t = Text()
    alpha = t.alphabet()
    assert len(alpha) == 26

    alpha = t.alphabet(lower_case=True)
    assert len(alpha) == 26

    alpha = t.alphabet(lower_case=Case.LOWER)
    assert len(alpha) == 26

    alpha = t.alphabet(lower_case=Case.UPPER)
    assert len(alpha) == 26



# Generated at 2022-06-21 16:54:16.874963
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words'].get('bad')
