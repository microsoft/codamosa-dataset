

# Generated at 2022-06-21 16:44:42.864867
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(), str)


# Generated at 2022-06-21 16:44:44.066410
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)


# Generated at 2022-06-21 16:44:45.573127
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text"""
    text = Text()
    assert text.word()



# Generated at 2022-06-21 16:44:46.816034
# Unit test for method answer of class Text
def test_Text_answer():
    for i in range(1000):
        assert Text().answer()

# Generated at 2022-06-21 16:44:48.497020
# Unit test for constructor of class Text
def test_Text():
    t = Text('en')
    assert t.__class__.__name__ == 'Text'



# Generated at 2022-06-21 16:44:50.881961
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())


# Generated at 2022-06-21 16:44:54.369769
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    print(text.color())
    print(text.hex_color())
    print(text.rgb_color())
    print(text.color())
    print(text.color())



# Generated at 2022-06-21 16:44:56.229405
# Unit test for method title of class Text
def test_Text_title():
    for _ in range(10):
        t = Text()
        res = t.title()
        assert len(res) > 2


# Generated at 2022-06-21 16:44:57.883997
# Unit test for method text of class Text
def test_Text_text():
    from . import text
    t = text.Text()
    assert len(t.text(1).split(" "))==4
    assert len(t.text(2).split(" "))==9


# Generated at 2022-06-21 16:45:00.069644
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    s = 'The quick brown fox jumps over the lazy dog.'
    assert type(text.word()) == str

# Generated at 2022-06-21 16:45:14.275401
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    class CustomProvider(RussiaSpecProvider):
        """Custom provider for unit test."""
        class Meta:
            """Class for metadata."""
            name = 'text_test'

    text = Text(CustomProvider)
    words = text.words()
    assert len(words) == 5



# Generated at 2022-06-21 16:45:18.267815
# Unit test for method answer of class Text
def test_Text_answer():
    def test_answer(locale):
        provider = Text(locale=locale)
        for i in range(100):
            answer = provider.answer()
            assert answer in answers
    answers = ['Yes', 'No', 'Maybe', 'Never', 'Definitely']
    locales = ['en', 'ru', 'uk']
    for loc in locales:
        test_answer(loc)

# Generated at 2022-06-21 16:45:19.424066
# Unit test for method level of class Text
def test_Text_level():
    assert Text().level() == 'critical'


# Generated at 2022-06-21 16:45:22.676937
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Create an instance of Text
    t = Text()
    t.rgb_color()
    res = (252, 85, 32)
    assert t.rgb_color() == res
    print('Test Text.rgb_color is OK')


# Generated at 2022-06-21 16:45:25.014054
# Unit test for method word of class Text
def test_Text_word():
    pass_word: str
    for i in range(5):
        pass_word = Word.word()
        print(pass_word)
        print(type(pass_word))
    assert pass_word == "gamelan"


# Generated at 2022-06-21 16:45:28.751326
# Unit test for method answer of class Text
def test_Text_answer():
    # Arrange
    text = Text()

    # Act
    result = text.answer()

    # Assert
    assert len(result) > 1

# Generated at 2022-06-21 16:45:30.020329
# Unit test for method quote of class Text
def test_Text_quote():
    t=Text()
    assert t.quote() != ""


# Generated at 2022-06-21 16:45:32.441374
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    text.locale = 'en'

    t = text.title()
    print(t)

    assert t != ''


# Generated at 2022-06-21 16:45:36.923546
# Unit test for method sentence of class Text
def test_Text_sentence():
    print("\n--- test_Text_sentence ---")
    text = Text()
    print(text.sentence())
    print(text.sentence())
    print(text.sentence())
    print(text.sentence())
    print(text.sentence())


# Generated at 2022-06-21 16:45:39.282748
# Unit test for method text of class Text
def test_Text_text():
    c = Text()
    text = c.text(quantity=1)
    assert text.lower() in c._data['text']

# Generated at 2022-06-21 16:46:01.307252
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.exceptions import NonEnumerableError

    # Initialize object
    t = Text(Locale.EN)

    # Call method
    result = t.word()

    # Check for possible exceptions
    t.word(quantity=0)
    t.word(quantity=-1)

    # Check result
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-21 16:46:02.136406
# Unit test for method word of class Text
def test_Text_word():
    a = Text()
    print(a.answer())


# Generated at 2022-06-21 16:46:03.650843
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sentence = t.sentence()
    assert sentence in t._data['text']


# Generated at 2022-06-21 16:46:12.143220
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=123)
    assert text.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    assert text.alphabet(lower_case=False) == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert text

# Generated at 2022-06-21 16:46:13.431228
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == 'Music'


# Generated at 2022-06-21 16:46:15.690302
# Unit test for method sentence of class Text
def test_Text_sentence():
    obj = Text()
    for _ in range(1000):
        assert isinstance(obj.sentence(), str)

# Generated at 2022-06-21 16:46:18.863691
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import Color
    from mimesis.builtins import RussianSpecProvider
    rus = RussianSpecProvider(seed=42)
    color = rus.text.rgb_color(safe=True)
    assert color == Color.blue_caribbean

# Generated at 2022-06-21 16:46:22.885418
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    rgb_color_tuple = t.rgb_color()
    result = True
    for value in rgb_color_tuple:
        if 0 <= value <= 255:
            result = result and True
        else:
            result = result and False
    print('Unit test for method rgb_color of class Text', result)


# Generated at 2022-06-21 16:46:33.714584
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # Define Text instance
    text = Text()

    # Define expected result

# Generated at 2022-06-21 16:46:35.240731
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert isinstance(t.title(), str)


# Generated at 2022-06-21 16:48:24.631797
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    x = Text(seed=1)
    assert x.hex_color() == '#d8346b'



# Generated at 2022-06-21 16:48:26.247815
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    import pprint
    pprint.pprint(text.words(quantity=20))
    # print(text.words(quantity=20))


# Generated at 2022-06-21 16:48:27.077411
# Unit test for method text of class Text
def test_Text_text():
    text = Text('en')
    result = text.text()
    assert result



# Generated at 2022-06-21 16:48:28.862466
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text"""
    text = Text()
    assert len(text.alphabet()) == len(text.alphabet(True))


# Generated at 2022-06-21 16:48:30.514449
# Unit test for method words of class Text
def test_Text_words():
    s = Text().words(quantity=5)
    assert len(s) == 5, "test_Text_words failed"

# Generated at 2022-06-21 16:48:31.954492
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in ['low', 'medium', 'high', 'critical']
    

# Generated at 2022-06-21 16:48:39.333926
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Languages
    from mimesis.localization import get_localizer
    l = get_localizer(Languages.RUSSIAN)
    t = Text(localizer=l)
    assert t.level() in \
           ['Срочный', 'Опасный', 'Фатальный', 'Стандартный', 'Аварийный']


# Generated at 2022-06-21 16:48:41.513323
# Unit test for method text of class Text
def test_Text_text():
    txt_obj = Text()
    # print(txt_obj.text())
    assert txt_obj.text() is not None


# Generated at 2022-06-21 16:48:45.424626
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text of class Text."""
    text = Text()
    assert isinstance(text.text(), str)
    assert isinstance(text.text(quantity=1), str)
    assert isinstance(text.text(quantity=10), str)


# Generated at 2022-06-21 16:48:51.846623
# Unit test for constructor of class Text
def test_Text():
    t = Text('en')
    assert t._data['alphabet']['lowercase'] == [
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
    ]