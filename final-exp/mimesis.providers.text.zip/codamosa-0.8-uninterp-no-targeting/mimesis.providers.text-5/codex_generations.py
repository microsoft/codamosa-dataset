

# Generated at 2022-06-21 16:44:52.723445
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # set seed for repetition
    import mimesis
    seed = 42

    # set seed for test
    const.SEED = seed
    generator = mimesis.Text()

    # if safe is false it should return a random tuple
    assert generator.rgb_color(False) == (34, 57, 15)

    # if safe is False it should return a random tuple
    assert generator.rgb_color(True) == (250, 182, 16)

# Generated at 2022-06-21 16:44:55.300471
# Unit test for constructor of class Text
def test_Text():
    # Test_1
    txt = Text()
    assert txt._datafile == 'text.json'
    assert txt._all_data == {}
    assert txt._data == {}
    

# Generated at 2022-06-21 16:44:57.135325
# Unit test for method color of class Text
def test_Text_color():
    ans = Text().color()
    print(ans)


if __name__ == '__main__':
    test_Text_color()

# Generated at 2022-06-21 16:44:58.533663
# Unit test for method level of class Text
def test_Text_level():

    text = Text(seed=0)
    level = text.level()
    assert level == 'critical'

# Generated at 2022-06-21 16:45:00.950496
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    length = text.random.randint(1,10)
    result = text.words(quantity=length)
    assert len(result) == length


# Generated at 2022-06-21 16:45:02.981886
# Unit test for method sentence of class Text
def test_Text_sentence():
    if type(Text.sentence()) != str:
        raise AssertionError(
            f"{type(Text.sentence())} != str")
    elif not Text.sentence():
        raise AssertionError("Empty string")


# Generated at 2022-06-21 16:45:04.633158
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    text.words(quantity=5)

# Generated at 2022-06-21 16:45:08.366402
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Color
    from mimesis.text import Text
    t = Text('en')
    for _ in range(10):
        assert t.color() in Color.SAFE_COLORS

# Generated at 2022-06-21 16:45:11.076189
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    result = text.swear_word()
    print(result)
    assert len(result) > 0


# Generated at 2022-06-21 16:45:17.615388
# Unit test for method color of class Text
def test_Text_color():
    import random
    import pytest
    from mimesis.builtins import Text
    from mimesis.enums import Color
    from mimesis.providers.text import ColorProvider
    from tests.common import (
        get_fixture,
    )

    t = Text(seed=1)
    c = ColorProvider(seed=1)
    color_list = list(Color)
    another_colors = get_fixture('data/color.json')

    assert t.color() == 'Moss Green'
    assert t.color() in color_list
    assert t.color() in another_colors

# Generated at 2022-06-21 16:45:33.092485
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Localization
    from mimesis.builtins import Text
    t = Text(localization=Localization.EN)
    for _ in range(10):
        level = t.level()
        print(level)
        assert t.level() == level


# Generated at 2022-06-21 16:45:42.530628
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test method alphabet of class Text."""
    from mimesis.enums import Locales
    from mimesis.providers.text import Text

    # Check upper case letters
    t = Text('ru')
    uc_alpha = t.alphabet()
    for letter in uc_alpha:
        assert letter.isupper()

    # Check lower case letters
    t = Text('ru')
    lc_alpha = t.alphabet(True)
    for letter in lc_alpha:
        assert letter.islower()

    # Test locale
    t = Text('en')
    assert Locales.ENGLISH in t._data['alphabet']
    t._data['alphabet'][Locales.ENGLISH]


# Generated at 2022-06-21 16:45:43.422686
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.color())
    print(t.text())

# Generated at 2022-06-21 16:45:44.607595
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert type(Text().rgb_color()) == tuple

# Generated at 2022-06-21 16:45:46.799058
# Unit test for method quote of class Text
def test_Text_quote():
    # Instance data
    text = Text('it')
    # Generate 200 quotes text
    #for _ in range(200):
    #    print(text.quote())
    assert 'Generate random quote' == "Generate random quote"




# Generated at 2022-06-21 16:45:47.804877
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-21 16:45:48.832746
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert type(t.text()) is str


# Generated at 2022-06-21 16:45:54.029040
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import en
    a = Text(locale='ru')
    b = Text(locale='en')
    r = RussianSpecProvider(seed=Seed(18))
    x = r.person(gender=Gender.FEMALE)
    assert x.full_name() == 'Светлана Семенова'
    assert a.words(quantity=10) != b.words(quantity=10)
    assert a.word() != b.word()
    assert a.text(quantity=30) != b.text(quantity=30)
   

# Generated at 2022-06-21 16:45:56.093094
# Unit test for method title of class Text
def test_Text_title():
    obj = Text('en')
    ans = obj.title()
    assert ans


# Generated at 2022-06-21 16:45:57.687507
# Unit test for method color of class Text
def test_Text_color():
    color = Text(seed=3).color()
    assert color == 'Blue'


# Generated at 2022-06-21 16:46:23.847371
# Unit test for method answer of class Text
def test_Text_answer():
    for i in range(100):
        assert isinstance(Text().answer(), str), 'Failed'


# Generated at 2022-06-21 16:46:26.147315
# Unit test for method title of class Text
def test_Text_title():
    """Title test."""
    t = Text()
    assert type(t.title()) == str

# Generated at 2022-06-21 16:46:28.068701
# Unit test for method quote of class Text
def test_Text_quote():

    text = Text(seed=0)
    assert text.quote() == "The greatest thing..."


# Generated at 2022-06-21 16:46:29.373497
# Unit test for method color of class Text
def test_Text_color():
    result = Text().color()
    # print(result)


# Generated at 2022-06-21 16:46:31.229215
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text()
    assert provider.answer() != provider.answer()

# Generated at 2022-06-21 16:46:33.903219
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # For instance, test for German locale
    text = Text('de')

    for i in range(50):
        color = text.hex_color()
        assert(color.startswith('#'))


# Generated at 2022-06-21 16:46:36.134454
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert isinstance(text.answer(), str)
    assert len(text.answer()) > 0


# Generated at 2022-06-21 16:46:41.477335
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print("Color: ", t.color())
    print("Answer: ", t.answer())
    print("Alphabet: ", t.alphabet())
    print("Level: ", t.level())
    print("RGBColor: ", t.rgb_color())
    print("HexColor: ", t.hex_color())
    print("Quote: ", t.quote())
    print("Word: ", t.word())
    print("SwearWord: ", t.swear_word())
    print("Text: ", t.text())
    print("Sentence: ", t.sentence())
    print("Title: ", t.title())
    print("Words: ", t.words())

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-21 16:46:44.294395
# Unit test for method text of class Text
def test_Text_text():
    for _ in range(100):
        text = Text().text(quantity=10)
        #  print(text)
        assert text is not None
        assert isinstance(text, str)


# Generated at 2022-06-21 16:46:49.188442
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(), str)
    print(t.word())