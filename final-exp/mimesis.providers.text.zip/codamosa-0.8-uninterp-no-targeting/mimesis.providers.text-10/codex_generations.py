

# Generated at 2022-06-21 16:45:00.073563
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorScheme

    text = Text('en')
    assert text.rgb_color(safe=True) == (33, 150, 243)
    assert text.rgb_color(safe=ColorScheme.LIGHT) == (252, 85, 32)
    assert text.rgb_color(safe=ColorScheme.DARK) == (0, 151, 136)

    assert len(text.rgb_color()) == 3
    assert isinstance(text.rgb_color(), tuple)

# Generated at 2022-06-21 16:45:03.827589
# Unit test for method level of class Text
def test_Text_level():
    """Test method level of class Text."""
    txt = Text()
    level = txt.level()
    print(txt._data['level'][0])
    print(level)
    assert txt._data['level'][0] == "critical"
    assert level in txt._data['level']


# Generated at 2022-06-21 16:45:07.045522
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    text = Text('en')
    result = text.sentence()
    assert result is not None

# Generated at 2022-06-21 16:45:15.349554
# Unit test for method color of class Text
def test_Text_color():
    import sys
    import os
    import unittest
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    class TestText(unittest.TestCase):
        def setUp(self):
            self.t = Text("en")

        def tearDown(self):
            pass

        def test_color(self):
            self.assertIsInstance(self.t.color(), str)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 16:45:17.039278
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color(
        safe=False
    )) == 7


# Generated at 2022-06-21 16:45:24.899780
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    x = [text.color() for i in range(100)]
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())
    assert x.count(text.color()) == x.count(text.color())

# Generated at 2022-06-21 16:45:28.369118
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    assert Text().text() == Text().text()



# Generated at 2022-06-21 16:45:30.021441
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-21 16:45:31.664307
# Unit test for method text of class Text
def test_Text_text():
    data = Text()
    answer = data.text()
    print(answer)


# Generated at 2022-06-21 16:45:39.185257
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    instance = Text()
    assert isinstance(instance._hex_to_rgb('#ffffff'), tuple)
    assert instance._hex_to_rgb('#ffffff') == (255, 255, 255)
    assert len(instance.hex_color(safe=False)) == 7
    assert len(instance.hex_color(safe=True)) == 7
    assert isinstance(instance.hex_color(safe=False), str)
    assert isinstance(instance.hex_color(safe=True), str)


# Generated at 2022-06-21 16:45:57.348813
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    print(title)


# Generated at 2022-06-21 16:45:59.170877
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    assert not alpha
    alpha = text.alphabet(lower_case=True)
    assert not alpha


# Generated at 2022-06-21 16:46:01.767149
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    word = t.words()
    assert isinstance(word, list)


# Generated at 2022-06-21 16:46:03.940303
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    c = Text()
    assert isinstance(c.rgb_color(), tuple)
    assert isinstance(c.rgb_color(True), tuple)


# Generated at 2022-06-21 16:46:05.716641
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())

# Generated at 2022-06-21 16:46:07.777489
# Unit test for method words of class Text
def test_Text_words():
    import doctest
    doctest.testmod(extraglobs={'t': Text()})


# Generated at 2022-06-21 16:46:11.839274
# Unit test for constructor of class Text
def test_Text():
    t = Text(locale='en')
    ab = t.alphabet()
    print(t.sentence())
    print(t.words())
    print(t.level())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())


if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-21 16:46:13.255353
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert isinstance(text.color(), str)


# Generated at 2022-06-21 16:46:16.610911
# Unit test for method text of class Text
def test_Text_text():
    obj = Text()
    assert isinstance(obj.text(), str)
    assert isinstance(obj.text(quantity=1), str)
    assert isinstance(obj.text(quantity=10), str)



# Generated at 2022-06-21 16:46:17.526622
# Unit test for method word of class Text
def test_Text_word():
    assert len(Text().word()) > 0

# Generated at 2022-06-21 16:47:01.136154
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    x = t.word()
    assert x in ['Science', 'Network', 'God', 'Octopus', 'Love']
    return x


# Generated at 2022-06-21 16:47:06.098020
# Unit test for method words of class Text
def test_Text_words():
    # Fake instance of Text class
    fake_text = Text("en")

    # Used to check if method words returns valid data
    valid_result = True

    # Call method words
    for _ in range(100):
        fake_text.words()

        # If words method returns None , then result is not valid
        if fake_text is None:
            valid_result = False

    return valid_result


# Generated at 2022-06-21 16:47:09.742934
# Unit test for constructor of class Text
def test_Text():
    """Test Text constructor for the correct initialization."""
    t = Text()
    assert hasattr(t, '_data')
    assert hasattr(t, 'seed')
    assert hasattr(t, 'random')
    assert hasattr(t, 'datetime')
    assert hasattr(t, 'provider')



# Generated at 2022-06-21 16:47:11.347263
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    for i in range(10):
        result = t.title()
        assert len(result) > 0
    



# Generated at 2022-06-21 16:47:14.035914
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-21 16:47:15.275822
# Unit test for method level of class Text
def test_Text_level():
    answer = Text().level()
    assert answer
    assert isinstance(answer, str)

# Generated at 2022-06-21 16:47:17.077826
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-21 16:47:18.931582
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-21 16:47:20.069038
# Unit test for constructor of class Text
def test_Text():
    assert Text._meta.name=='text'



# Generated at 2022-06-21 16:47:25.029440
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    dp = Text()
    rgb = dp.rgb_color()
    assert len(rgb) == 3
    assert isinstance(rgb[0], int)
    assert isinstance(rgb[1], int)
    assert isinstance(rgb[2], int)