

# Generated at 2022-06-21 16:44:45.192443
# Unit test for constructor of class Text
def test_Text():
    return Text()

# Generated at 2022-06-21 16:44:46.970284
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    sentence = provider.sentence()
    assert isinstance(sentence, str)

# Generated at 2022-06-21 16:44:51.313555
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    ans = t.rgb_color(safe=True)
    assert len(ans) == 3
    assert isinstance(ans, tuple)
    assert isinstance(ans[0], int)
    assert isinstance(ans[1], int)
    assert isinstance(ans[2], int)


# Generated at 2022-06-21 16:44:52.910352
# Unit test for method title of class Text
def test_Text_title():
    txt = Text('en')
    assert txt.title()


# Generated at 2022-06-21 16:44:59.827917
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider(seed=42)

    # Test for standard RGB tuple
    assert Text(seed=42).rgb_color() == (93, 207, 61)
    # Test for russian locale
    assert rus.text.rgb_color() == (8, 171, 237)
    # Test for safe RGB tuple
    assert Text(seed=42).rgb_color(safe=True) == (255, 255, 255)
    # Test for safe RGB tuple and russian locale
    assert rus.text.rgb_color(safe=True) == (133, 193, 233)


# Generated at 2022-06-21 16:45:01.738436
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale

    _t = Text(Locale.EN)
    assert isinstance(_t.level(), str)


# Generated at 2022-06-21 16:45:03.258877
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    Text(Locale.EN).swear_word()

# Generated at 2022-06-21 16:45:07.089420
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Method test."""
    text = Text(seed=1)
    print('Text.swear_word(): ', text.swear_word())
    # Result: Text.swear_word():  Damn


# Generated at 2022-06-21 16:45:14.838353
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.alphabet(lower_case=True))
    print(t.level())
    print(t.text())
    print(t.sentence())
    print(t.title())
    print(t.words())
    print(t.word())
    print(t.swear_word())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-21 16:45:16.717092
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert isinstance(words, list)
    assert len(words) == 5


# Generated at 2022-06-21 16:45:39.795891
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    result = t.color()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:45:41.302216
# Unit test for constructor of class Text
def test_Text():
    a = Text("seed")
    assert a, "This method must return something"


# Generated at 2022-06-21 16:45:45.755300
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for hex_color."""
    t = Text()
    s = t.hex_color()
    assert isinstance(s, str)


# Generated at 2022-06-21 16:45:52.240475
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.localization import Data
    from mimesis.providers.datetime import Datetime
    import csv
    import os
    from mimesis.builtins import Text

    File_name = r"C:\Users\71151\PycharmProjects\Asistent\test_Text_swear_word.csv"
    file_exists = os.path.exists(File_name)
    with open(File_name,'a+') as f:
        writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        Text_0 = Text(seed=10)
        for j in range(10):
            swear_word_list = []

# Generated at 2022-06-21 16:45:56.964211
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Locale
    from mimesis.data import QUOTES
    t = Text(locale=Locale.EN)
    quote = t.quote()
    assert quote in QUOTES
    assert isinstance(quote, str)


# Generated at 2022-06-21 16:45:58.924836
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    text_gen = Text()
    title = text_gen.title()
    # print(title)



# Generated at 2022-06-21 16:46:09.651509
# Unit test for method text of class Text
def test_Text_text():
    sample = Text('en')
    print(sample.text())

# # Unit test for method title of class Text
# def test_Text_title():
#     sample = Text('en')
#     print(sample.title())

# # Unit test for method quote of class Text
# def test_Text_quote():
#     sample = Text('en')
#     print(sample.quote())

# # Unit test for method sentence of class Text
# def test_Text_sentence():
#     sample = Text('en')
#     print(sample.sentence())

# # Unit test for method color of class Text
# def test_Text_color():
#     sample = Text('en')
#     print(sample.color())

# # Unit test for method hex_color of class Text
# def test_Text_hex_color():


# Generated at 2022-06-21 16:46:11.559307
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert type(text.level()) is str


# Generated at 2022-06-21 16:46:18.404090
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locales
    from mimesis.providers.generic import Generic

    t = Text(local = Locales.EN)
    g = Generic(local = Locales.EN)
    print(t.color())
    print(g.color_name())
    print()
    t = Text(local = Locales.RU)
    g = Generic(local = Locales.RU)
    print(t.color())
    print(g.color_name())
    print()



# Generated at 2022-06-21 16:46:20.122151
# Unit test for constructor of class Text
def test_Text():
    text_instance = Text('en')
    assert isinstance(text_instance, Text)
