

# Generated at 2022-06-21 16:44:43.215595
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color(safe=True))

    # Unit test for method rgb_color of class Text

# Generated at 2022-06-21 16:44:45.225003
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    s = Text()

    for _ in range(10):
        r = s.hex_color()
        assert isinstance(r, str)


# Generated at 2022-06-21 16:44:46.713939
# Unit test for method word of class Text
def test_Text_word():
    text = Text('ru')
    print(text.word())


# Generated at 2022-06-21 16:44:50.096185
# Unit test for method level of class Text
def test_Text_level():
    print(Text.level())
    # print(Text.level())
    print(Text.level())
    print(Text.level())


# Generated at 2022-06-21 16:44:51.759510
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    provider = Text()
    assert type(provider.hex_color()) == str

# Generated at 2022-06-21 16:44:53.237228
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    t.quote()

# Generated at 2022-06-21 16:44:55.135277
# Unit test for method text of class Text
def test_Text_text():
    provider = Text('en')
    answer = provider.text(12)
    assert isinstance(answer, str)
    assert len(answer) > 0

# Generated at 2022-06-21 16:44:55.996939
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-21 16:44:57.667478
# Unit test for constructor of class Text
def test_Text():
    Text(seed=123)
    Text(seed=123).locale
    text = Text(seed=123, locale='ru')
    assert text.locale == 'ru'


# Generated at 2022-06-21 16:44:58.460529
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != None


# Generated at 2022-06-21 16:45:17.274213
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in ['critical', 'danger', 'dangerous', 'minor', 'safe', 'warning']


# Generated at 2022-06-21 16:45:23.560844
# Unit test for method color of class Text
def test_Text_color():
    x = Text()
    a = 'Which color is an apple?'
    ans = 'Red'
    ques = [a+'\n'+x.color()+'\n','\n'+a+' '+x.color()+'\n','\n'+a+'\n'+x.color()+'\n','\n'+a+' '+x.color()+'\n']
    for b in ques:
        if b.lower().startswith(a.lower()+(x.color()).lower()):
            print(b)


# Generated at 2022-06-21 16:45:27.551499
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    s = t.sentence()
    assert type(s) == str


# Generated at 2022-06-21 16:45:28.981715
# Unit test for method text of class Text
def test_Text_text():
    test=Text()
    assert type(test.text()) == str


# Generated at 2022-06-21 16:45:30.769871
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-21 16:45:33.015786
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    txt_obj = Text()
    alpha = txt_obj.alphabet()
    assert len(alpha) == 26
    assert 'A' in alpha


# Generated at 2022-06-21 16:45:34.722728
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert tuple == type(text.rgb_color(safe=True))



# Generated at 2022-06-21 16:45:42.383241
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    from mimesis.providers.text import Text
    from mimesis.enums import Language

    print("test_Text_title()")
    print("============================")
    #get text provider

    #get random title
    t = Text(Language.ENGLISH)
    print("Random title:")
    print(t.title())
    print("============================")
    #text = Text(locale='ru')
    #text = Text(language='en')


# Generated at 2022-06-21 16:45:43.954455
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert t.hex_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-21 16:45:45.797754
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    bad_word = text.swear_word()
    print(bad_word)


# Generated at 2022-06-21 16:48:08.072052
# Unit test for method color of class Text
def test_Text_color():
    import mimesis
    text = mimesis.Text()
    print(text.color())


# Generated at 2022-06-21 16:48:10.584228
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) > 0


# Generated at 2022-06-21 16:48:11.570866
# Unit test for method level of class Text
def test_Text_level():
    Text().level()


# Generated at 2022-06-21 16:48:13.448717
# Unit test for method text of class Text
def test_Text_text():
    '''
    test_Text_text
    '''
    text = Text()
    actual = text.text()
    assert type(actual) is str

# Generated at 2022-06-21 16:48:19.157343
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    t = Text()
    res = t.quote()
    assert res is not None
    assert res != ""
    t = Text(gender=Gender.FEMALE)
    res = t.quote()
    assert res is not None
    assert res != ""
    t = Text(gender=Gender.MALE)
    res = t.quote()
    assert res is not None
    assert res != ""

# Generated at 2022-06-21 16:48:20.842447
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    answer = Text(seed=3).swear_word()
    right_answer = 'damn'
    return 'OK' if answer == right_answer else answer


# Generated at 2022-06-21 16:48:22.376781
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    # print(t.sentence())
    text = t.sentence()
    assert(len(text) > 0)

# Generated at 2022-06-21 16:48:23.903689
# Unit test for method level of class Text
def test_Text_level():
    """Test method _level of class Text"""
    t = Text()
    {
        'level' : t.level(),
    }


# Generated at 2022-06-21 16:48:25.082360
# Unit test for method swear_word of class Text
def test_Text_swear_word():
  a = Text()
  w = a.swear_word()
  print(w)
  assert w


# Generated at 2022-06-21 16:48:26.695049
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert type(t.title()) == str
