

# Generated at 2022-06-21 16:44:44.350542
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=12345)
    t.rgb_color()

# Generated at 2022-06-21 16:44:48.496602
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()

    # lower_case=True
    assert t.alphabet(lower_case=True) == list('abcdefghijklmnopqrstuvwxyz')

    # lower_case=False
    assert t.alphabet(lower_case=False) == list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')


# Generated at 2022-06-21 16:44:56.187086
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    # print(t.rgb_color(safe=False))
    assert isinstance(t.rgb_color(safe=False),tuple)
    assert len(t.rgb_color(safe=False)) == 3
    assert isinstance(t.rgb_color(safe=False)[0],int)
    assert isinstance(t.rgb_color(safe=False)[1],int)
    assert isinstance(t.rgb_color(safe=False)[2],int)



# Generated at 2022-06-21 16:44:57.639867
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    for _ in range(100):
        assert t.word()


# Generated at 2022-06-21 16:44:58.771243
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert len(Text().alphabet()) == 26


# Generated at 2022-06-21 16:45:00.826597
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    colorList = [text.color() for i in range(100)]
    assert len(set(colorList)) == 100

# Generated at 2022-06-21 16:45:02.192989
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-21 16:45:04.127889
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis import Text
    t = Text('ja')
    # t.sentence()


# Generated at 2022-06-21 16:45:07.729408
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test for method swear_word of class Text."""
    text = Text('en')

    result = text.swear_word()

    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-21 16:45:08.368894
# Unit test for method level of class Text
def test_Text_level():
    assert Text().level()

# Generated at 2022-06-21 16:45:17.482087
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=12345)
    t.set_language('en')
    assert t.color() is not None


# Generated at 2022-06-21 16:45:19.523938
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.providers.text import Text
    t = Text()
    for _ in range(10):
        assert t.hex_color()


# Generated at 2022-06-21 16:45:21.224137
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    s = t.level()
    assert type(s) is str
    assert len(s) > 0


# Generated at 2022-06-21 16:45:27.662374
# Unit test for method color of class Text
def test_Text_color():
    t = Text('en')

# Generated at 2022-06-21 16:45:29.778286
# Unit test for method answer of class Text
def test_Text_answer():
    """Test method answer of class Text"""
    text = Text()
    answer = text.answer()
    assert answer in ['Yes', 'No']

# Generated at 2022-06-21 16:45:31.143156
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.answer())


# Generated at 2022-06-21 16:45:35.779627
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    from mimesis import Text
    t = Text()
    for _ in range(20):
        assert isinstance(t.rgb_color(), tuple)
        assert len(t.rgb_color()) == 3
        for c in t.rgb_color():
            assert c <= 255 and c >= 0

# Generated at 2022-06-21 16:45:40.499151
# Unit test for method words of class Text
def test_Text_words():
    result_1 = Text().words()
    length_1 = len(result_1)
    assert length_1 == 5
    result_2 = Text().words(8)
    length_2 = len(result_2)
    assert length_2 == 8





# Generated at 2022-06-21 16:45:41.840914
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    temp = Text()
    a = temp.rgb_color()
    assert isinstance(a, tuple)

# Generated at 2022-06-21 16:45:43.083301
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    p = t.quote()
    assert isinstance(p, str)

# Generated at 2022-06-21 16:46:02.498967
# Unit test for method title of class Text
def test_Text_title():
    a = Text()
    print(a.title())
    print(a.sentence())
    print(a.text())


# Generated at 2022-06-21 16:46:08.677303
# Unit test for method words of class Text
def test_Text_words():
    # Тестируем генерацию
    text = Text()
    result = text.words(3)
    # Проверяем соответствие результата с тем, что ожидаем
    assert result == ['project', 'ear', 'wire']


# Generated at 2022-06-21 16:46:11.382751
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    result = t.quote()
    print(result)

    # assert isinstance(result, str)
    # assert len(result) > 1

if __name__ == "__main__":
    test_Text_quote()

# Generated at 2022-06-21 16:46:14.338989
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    provider = Text()
    alphabet = provider.alphabet()
    assert (isinstance(alphabet, list))
    alphabet2 = provider.alphabet()
    assert (isinstance(alphabet2, list))



# Generated at 2022-06-21 16:46:16.205880
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None



# Generated at 2022-06-21 16:46:17.718003
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    result = text.word()
    assert len(result)>=5


# Generated at 2022-06-21 16:46:19.224503
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    t.level()
    t.level()
    t.level()



# Generated at 2022-06-21 16:46:21.380537
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    list_of_words = t.words()
    assert isinstance(list_of_words, list)
    assert len(list_of_words) == 5

# Generated at 2022-06-21 16:46:23.036412
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())

if __name__ == '__main__':
    test_Text_answer()

# Generated at 2022-06-21 16:46:33.799200
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis import Text
    from mimesis.providers.datetime.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.misc.misc import Misc
    from mimesis.providers.network.network import Network
    from mimesis.providers.numbers.numbers import Numbers
    from mimesis.providers.person.person import Person
    from mimesis.providers.person.profile import Profile
    from mimesis.providers.person.useragent import UserAgent

    t = Text(seed=2)
    print("test_Text_rgb_color:")
    print("\t", t.rgb_color(safe=False))
    print("\t", t.rgb_color(safe=True))
