

# Generated at 2022-06-21 16:44:44.454292
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.words(quantity=3), list) is True
    assert isinstance(text.words(quantity=3)[0], str) is True
    assert isinstance(text.words(quantity=3)[1], str) is True
    assert isinstance(text.words(quantity=3)[2], str) is True

    assert text.words(quantity=3)[0] != text.words(quantity=3)[1]
    assert text.words(quantity=3)[1] != text.words(quantity=3)[2]
    assert text.words(quantity=3)[0] != text.words(quantity=3)[2]


# Generated at 2022-06-21 16:44:45.606349
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert isinstance(text.title(), str)


# Generated at 2022-06-21 16:44:46.870343
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote == 'Bond... James Bond.'

# Generated at 2022-06-21 16:44:50.748543
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Answer
    from mimesis.enums import Language
    for lang in Language:
        text = Text(lang)
        answer = text.answer()
        assert answer in Answer
        assert text.answer() in Answer
        assert text.answer() in Answer

# Generated at 2022-06-21 16:44:51.999226
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text()

# Generated at 2022-06-21 16:44:54.078075
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    res = text.rgb_color()
    for i in res:
        assert i >= 0
        assert i <= 255

# Generated at 2022-06-21 16:44:57.866409
# Unit test for method quote of class Text
def test_Text_quote():
    """Method for testing method quote."""
    from mimesis.builtins.text import Text
    text = Text()
    result = text.quote()
    assert result in ['I am Iron Man.', 'Hasta la vista, baby.',
                      'Bond... James Bond.', 'Say hello to my little friend!']


# Generated at 2022-06-21 16:45:00.328074
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    #without correct param
    assert len(Text().hex_color()) == 7
    #with correct param
    assert len(Text().hex_color(safe=True)) == 7


# Generated at 2022-06-21 16:45:02.741584
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    t = Text(locale=Locale.RUSSIAN)
    # print(t.swear_word())
    pass



# Generated at 2022-06-21 16:45:04.363616
# Unit test for method level of class Text
def test_Text_level():
    print("Text.level(): ", Text().level())



# Generated at 2022-06-21 16:45:21.630025
# Unit test for method answer of class Text
def test_Text_answer():
    t =  Text()
    answer = t.answer()
    assert bool(answer) is True


# Generated at 2022-06-21 16:45:23.453258
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    alph = list(Text('en').alphabet())
    assert len(alph) == 26


# Generated at 2022-06-21 16:45:27.002250
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert len(t.title()) > 0



# Generated at 2022-06-21 16:45:28.934048
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert len(word) > 0


# Generated at 2022-06-21 16:45:32.797741
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis import Text
    txt = Text()
    assert isinstance(txt.rgb_color(), tuple)
    assert isinstance(txt.rgb_color(safe=False), tuple)
    assert isinstance(txt.rgb_color(safe=True), tuple)



# Generated at 2022-06-21 16:45:37.616634
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.enums import Locale
    text = Text(Locale.EN)
    text.quote()
    text = Text(Locale.GR)
    text.quote()

# Generated at 2022-06-21 16:45:41.405875
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale
    from mimesis.builtins import Text
    text_1 = Text(Locale.ENGLISH)
    text_2 = Text(Locale.RUSSIAN)
    print(text_1.word())
    print(text_2.word())


# Generated at 2022-06-21 16:45:44.834543
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=8)
    assert t.color() == 'Gray'

# Generated at 2022-06-21 16:45:46.526232
# Unit test for method title of class Text
def test_Text_title():
    res = Text().title()
    assert isinstance(res, str) and len(res.strip()) > 0


# Generated at 2022-06-21 16:45:47.618148
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() is not None

# Generated at 2022-06-21 16:48:42.614103
# Unit test for method text of class Text
def test_Text_text():
    text_object = Text()
    
    # test the method text
    result = text_object.text()
    print(result)
    assert(type(result) == str)
    

# Generated at 2022-06-21 16:48:43.277624
# Unit test for method words of class Text
def test_Text_words():
    Text()

# Generated at 2022-06-21 16:48:45.791529
# Unit test for method sentence of class Text
def test_Text_sentence():
    import random
    random.seed(2)
    text = Text(random)
    sentence = text.sentence()
    assert sentence == "Необходимо проверить всю входящую и исходящую переписку."
    

# Generated at 2022-06-21 16:48:46.987412
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    t.level()


# Generated at 2022-06-21 16:48:48.094604
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(), str)

# Generated at 2022-06-21 16:48:49.212765
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())


# Generated at 2022-06-21 16:48:50.257894
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert text.sentence() != ''



# Generated at 2022-06-21 16:48:52.858085
# Unit test for method words of class Text
def test_Text_words():
    """Test Text.words method."""
    test_obj = Text()
    assert len(test_obj.words(quantity=10)) == 10


# Generated at 2022-06-21 16:48:56.101144
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.random.choice(text._data['text'])
    assert sentence == text.sentence()

# Generated at 2022-06-21 16:49:00.531261
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert isinstance(t.words(quantity=3), List)
