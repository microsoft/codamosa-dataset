

# Generated at 2022-06-21 16:44:52.582367
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    t = Text()
    result = t.level()
    assert result in t._data['level']


# Generated at 2022-06-21 16:44:55.792111
# Unit test for method words of class Text
def test_Text_words():
    t = Text(locale='en')
    assert type(t.words()) == list
    assert len(t.words()) == 5
    assert type(t.words(quantity=10)) == list
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-21 16:44:57.601744
# Unit test for method text of class Text
def test_Text_text():
    """Test text method."""
    t = Text()
    i = t.text()
    assert type(i) is str


# Generated at 2022-06-21 16:44:58.423329
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())

# Generated at 2022-06-21 16:44:59.791416
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print('Text.alphabet: ', text.alphabet())


# Generated at 2022-06-21 16:45:01.038358
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert isinstance(color, str)


# Generated at 2022-06-21 16:45:01.932539
# Unit test for constructor of class Text
def test_Text():
    text = Text()

    assert text is not None


# Generated at 2022-06-21 16:45:05.782183
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    safe = text.rgb_color(safe=True)
    normal = text.rgb_color()
    assert safe in SAFE_COLORS
    assert normal not in SAFE_COLORS


# Generated at 2022-06-21 16:45:07.729369
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    assert result != None and result != ''


# Generated at 2022-06-21 16:45:09.610781
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word()

# Generated at 2022-06-21 16:45:41.225255
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    t = Text()
    hex_color = t.hex_color()
    assert isinstance(hex_color, str)
    assert hex_color.startswith('#')
    assert len(hex_color) == 7


# Generated at 2022-06-21 16:45:46.016497
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Gender
    from mimesis.builtins import Text
    from datetime import datetime

    x = Text()
    x.level()
    x.level()


# Generated at 2022-06-21 16:45:48.561537
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Test
    t = Text()
    hex_color = t.hex_color()
    assert type(hex_color) == str
    assert len(hex_color) == 7
    assert hex_color[0] == '#'


# Generated at 2022-06-21 16:45:50.696904
# Unit test for method color of class Text
def test_Text_color():
    t = Text('en')
    x = t.color()
    assert x in SAFE_COLORS

# Generated at 2022-06-21 16:45:55.004268
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    l = t.level()
    assert isinstance(l, str) is True
    assert len(l) > 0
    print(l)
    assert l in ['critical', 'error', 'info', 'warning', 'offset']


# Generated at 2022-06-21 16:45:56.431973
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() == (252, 85, 32)


# Generated at 2022-06-21 16:45:58.793183
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test the method Text.rgb_color()."""
    from mimesis.providers.text import Text
    text = Text()
    assert text.rgb_color(safe=False)


# Generated at 2022-06-21 16:46:01.007760
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert type(t.level()) == str


# Generated at 2022-06-21 16:46:08.559618
# Unit test for method sentence of class Text
def test_Text_sentence():
    ctx = Text()
    sentence = ctx.sentence()
    assert sentence != None
    assert sentence != ''
    assert sentence != ' '
    assert sentence != '  '
    assert sentence != '   '
    assert sentence != '    '
    assert sentence != '     '
    assert sentence != '      '
    assert sentence != '       '
    assert sentence != '        '
    assert sentence != '         '
    assert sentence != '          '
    assert sentence != '           '
    assert sentence != '            '
    assert sentence != '             '
    assert sentence != '              '

# Generated at 2022-06-21 16:46:11.741462
# Unit test for method word of class Text
def test_Text_word():
    txt = Text()
    int_random ,int_random2 = txt.random.randint(1,10), txt.random.randint(1,10) 
    word = txt.word()
    assert type(word) == str
    assert len(word) >= int_random and len(word) <= int_random2
