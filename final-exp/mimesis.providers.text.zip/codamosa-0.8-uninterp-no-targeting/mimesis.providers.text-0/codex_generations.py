

# Generated at 2022-06-21 16:44:52.494474
# Unit test for method title of class Text
def test_Text_title():
    myText = Text("ru")
    print("Проверка метода Text.title() = ", myText.title())


# Generated at 2022-06-21 16:44:55.380157
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text
    t = Text()
    r = t.word()
    assert isinstance(r, str)
    assert isinstance(t.word(), str)
    assert t.word()
    assert t.word()

# Generated at 2022-06-21 16:45:00.694631
# Unit test for method words of class Text
def test_Text_words():
    # результат работы метода words() должен быть типа (list)
    assert isinstance(Text.words(), list)
    # длина результата работы метода words() должна быть 0
    assert len(Text.words()) == 5


# Generated at 2022-06-21 16:45:01.773630
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    # print(text.title())


# Generated at 2022-06-21 16:45:05.267599
# Unit test for constructor of class Text
def test_Text():
    fav_word = 'science'
    t = Text(seed = fav_word)
    assert t.seed == fav_word
    assert t.random.getstate() == ('MT19937', (0, 624, 397, 4294967296, 686,
                                  2705311269, 1, 0, 0, 0, 0, 20389, 1, 0),
                           None, None, None)
    assert t._datafile == 'text.json'

# Generated at 2022-06-21 16:45:10.441829
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    words = ['science', 'network', 'god', 'octopus', 'love']
    for i, word in enumerate(words):
        t = Text(seed=i, locale='fr')
        assert word == t.word()


# Generated at 2022-06-21 16:45:12.551539
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    ans = t.answer()
    assert True if ans in t._data['answers'] else False


# Generated at 2022-06-21 16:45:14.028779
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.meta.provider == 'text'


# Generated at 2022-06-21 16:45:15.413306
# Unit test for constructor of class Text
def test_Text():
    p = Text()

    assert p.seed is not None


# Generated at 2022-06-21 16:45:16.788407
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale
    txt = Text(locale=Locale.ENGLISH)
    result = txt.text()
    assert result is not None


# Generated at 2022-06-21 16:45:38.792678
# Unit test for method word of class Text
def test_Text_word():
    """Проверка метода word класса Text."""
    from mimesis.enums import Gender
    from mimesis.datetime import Datetime
    dt = Datetime('ru').datetime
    x = Text('ru').word()

# Generated at 2022-06-21 16:45:40.583833
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result in ['critical', 'warning', 'success', 'info']

# Generated at 2022-06-21 16:45:41.938643
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    val = t.alphabet()
    assert len(val) > 0


# Generated at 2022-06-21 16:45:42.877976
# Unit test for method answer of class Text
def test_Text_answer():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 16:45:44.909989
# Unit test for method level of class Text
def test_Text_level():
    x = Text()
    x.level()


# Generated at 2022-06-21 16:45:47.812428
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    safe = text.rgb_color(safe=True)
    all = text.rgb_color(safe=False)
    assert isinstance(safe, tuple)
    assert isinstance(all, tuple)
    print(safe, all)


# Generated at 2022-06-21 16:45:58.150248
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-21 16:46:09.284520
# Unit test for method level of class Text
def test_Text_level():
    # Создаем объект класса Text, в котором должен быть язык 'ru'.
    t = Text(locale='ru')
    # Проверяем что возвращает данная функция.
    assert t.level() in ['базовый', 'низкий', 'средний', 'высокий', 'критический']


# Generated at 2022-06-21 16:46:13.104313
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """To test the hex_color method of class Text"""
    text = Text()
    hex_color = text.hex_color(safe=True)
    assert len(hex_color) == 7


# Generated at 2022-06-21 16:46:22.333911
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Language
    from mimesis.localization import DEFAULT_LOCALE_CODE
    from mimesis.providers.text import Text

    text1 = Text(language=Language.RU)
    assert text1.title() != text1.title()
    assert text1._get_locale() == DEFAULT_LOCALE_CODE

    text2 = Text(language=Language.RU, seed=42)
    assert text2.title() != text2.title()

    text3 = Text(seed=42)
    assert text3.title() != text3.title()
    assert text3._get_locale() == DEFAULT_LOCALE_CODE

    text4 = Text()
    assert text4.title() != text4.title()

# Generated at 2022-06-21 16:46:52.918524
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != ''

# Generated at 2022-06-21 16:46:54.593411
# Unit test for method color of class Text
def test_Text_color():
    text_class = Text()
    print(text_class.color())


# Generated at 2022-06-21 16:46:59.756154
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    text.seed(0)
    text.answer() == 'No'
    text.text(5)
    text.words(5)
    text.quote()
    text.title()
    text.sentence()
    text.word()
    text.swear_word()
    text.level()
    text.rgb_color()
    text.hex_color()
    text.color()
    text.alphabet()
    text.alphabet(lower_case=True)
    assert text.answer() == 'No'

# Generated at 2022-06-21 16:47:03.830107
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.providers.text import Text
    from mimesis.enums import Languages
    t = Text(language=Languages.ENGLISH)
    for _ in range(5):
        print(t.quote())


# Generated at 2022-06-21 16:47:05.447159
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    s = t.word()
    assert isinstance(s, str) == True

# Generated at 2022-06-21 16:47:06.575278
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in ['Yes', 'No', 'maybe']

# Generated at 2022-06-21 16:47:09.042597
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Gender
    text = Text('zh')
    text_en = Text('en')
    assert text.answer() != text_en.answer()




# Generated at 2022-06-21 16:47:13.116426
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""

    from mimesis.builtins import Text
    from mimesis.enums import Locale
    from mimesis.providers.base import BaseDataProvider

    locale = Locale.get_locale(locale='en')
    text = Text(locale=locale)
    assert isinstance(text, BaseDataProvider)
    assert text.seed is not None
    assert text.seed is not None
    result = text.swear_word()
    assert result is not None



# Generated at 2022-06-21 16:47:15.322542
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    assert type(txt.sentence()) == str


# Generated at 2022-06-21 16:47:16.718753
# Unit test for method word of class Text
def test_Text_word():
    t = Text('en')
    print(t.word())