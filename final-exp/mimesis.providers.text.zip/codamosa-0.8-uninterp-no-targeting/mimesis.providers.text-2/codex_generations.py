

# Generated at 2022-06-21 16:48:03.760539
# Unit test for method level of class Text
def test_Text_level():
    Text().level()


# Generated at 2022-06-21 16:48:07.054153
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Locale
    from mimesis.builtins import Locales
    locale_obj = Locales(Locale.EN)
    text_obj = Text(locale_obj)
    print(text_obj.alphabet())


# Generated at 2022-06-21 16:48:08.611223
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    text.text(quantity=1)


# Generated at 2022-06-21 16:48:11.810790
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    assert Text().quote() != ''

# Generated at 2022-06-21 16:48:15.170113
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test case for method alphabet of class Text."""
    from mimesis.enums import Languages

    alphabet = Text(Languages.EN).alphabet()
    assert isinstance(alphabet, list)



# Generated at 2022-06-21 16:48:19.180904
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    for _ in range(10):
        print(text.hex_color())
        print(text.hex_color(safe=True))
        print()


# Generated at 2022-06-21 16:48:21.831050
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    text.set_seed(1)
    assert text.sentence()
    assert text.word()
    assert text.title()
    assert text.words()
    assert text.quote()
    assert text.answer()

# Generated at 2022-06-21 16:48:23.915140
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussiaSpecProvider
    random = RussiaSpecProvider()
    for _ in range(5):
        print(random.text.sentence())


# Generated at 2022-06-21 16:48:27.358711
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    for i in range(10):
        color = Text().hex_color()
        assert len(color) == 7 and color.startswith('#')

# Generated at 2022-06-21 16:48:29.708990
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text('en')
    a = t.hex_color()
    assert len(a) == 7 and a[0] == '#'
    a = t.hex_color(True)
    assert a in SAFE_COLORS

# Generated at 2022-06-21 16:51:29.087383
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed = 0)
    assert t.swear_word() == 'Damn'

#test_Text_swear_word()


# Generated at 2022-06-21 16:51:32.569360
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from mimesis.data import NORMAL_LEVELS

    text_provider = Text(Locale.EN)
    result = text_provider.level()
    assert result in NORMAL_LEVELS


# Generated at 2022-06-21 16:51:33.592136
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())


# Generated at 2022-06-21 16:51:37.822312
# Unit test for method word of class Text
def test_Text_word():
    print("Start Unit test for method word of class Text\n")
    word = Text().word()
    print("Text().word() = '{}'".format(word))
    assert type(word) is str
    assert word != ''
    print("\nFinish Unit test for method word of class Text")


# Generated at 2022-06-21 16:51:39.891982
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test the method sentence."""

    text = Text(seed=1)
    assert text.sentence() == 'We would like to welcome you to our homepage'


# Generated at 2022-06-21 16:51:43.173305
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=12345)
    assert text.level() == 'high'
    assert 'level' in text.provider_data


# Generated at 2022-06-21 16:51:46.413774
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()

    pattern = r'^#[0-9a-f]{6}$'
    data_list = [text.hex_color() for _ in range(1000)]
    for data in data_list:
        assert re.match(pattern, data)



# Generated at 2022-06-21 16:51:47.182507
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    print(Text().hex_color())


# Generated at 2022-06-21 16:51:49.809276
# Unit test for method color of class Text
def test_Text_color():
    a = Text(seed=2333)
    assert a.color() == 'Brown'
    assert a.color() == 'Green'
    assert a.color() == 'Red'
    assert a.color() == 'Brown'
    assert a.color() == 'Yellow'


# Generated at 2022-06-21 16:51:51.269364
# Unit test for method level of class Text
def test_Text_level():
    s = Text()
    assert s.level() in ['critical', 'ok', 'danger', 'warning', 'safe']
