

# Generated at 2022-06-21 16:44:38.308387
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert len(Text.alphabet()) >= 26
    assert len(Text.alphabet(lower_case=True)) >= 26


# Generated at 2022-06-21 16:44:38.910481
# Unit test for method word of class Text
def test_Text_word():
    print(Text().word())



# Generated at 2022-06-21 16:44:42.699107
# Unit test for method quote of class Text
def test_Text_quote():
    """Test method quote of class Text.
    This method tests if the class Text is returning a string.
    """
    assert isinstance(Text().quote(), str)


# Generated at 2022-06-21 16:44:44.892130
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    
    t = Text()
    print(t.rgb_color(True))
    print(t.rgb_color())

# Generated at 2022-06-21 16:44:45.978360
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert type(t.text()) == str


# Generated at 2022-06-21 16:44:47.342727
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text()
    assert txt.quote() != None, 'O teste falhou'


# Generated at 2022-06-21 16:44:49.009601
# Unit test for constructor of class Text
def test_Text():
    try:
        text = Text('ru')
    except Exception as exc:
        print(exc)
        return False
    return True


# Generated at 2022-06-21 16:44:50.928706
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color()


# Generated at 2022-06-21 16:44:53.031382
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_provider = Text()
    assert isinstance(text_provider.sentence(), str)


# Generated at 2022-06-21 16:45:00.981952
# Unit test for method rgb_color of class Text

# Generated at 2022-06-21 16:46:22.976084
# Unit test for method quote of class Text
def test_Text_quote():
    """Tests for Text's method quote
    """
    a = Text()
    for _ in range(10):
        print(a.quote())


# Generated at 2022-06-21 16:46:27.950784
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    assert isinstance(text.words(), list)
    assert isinstance(text.words(quantity=1)[0], str)
    assert text.words(quantity=1)[0] in text._data['words'].get('normal')

# Generated at 2022-06-21 16:46:30.360420
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert result is not None


# Generated at 2022-06-21 16:46:32.700083
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Language
    text = Text(Language.EN, seed=1337)
    t = text.title()
    assert t == 'The world'
test_Text_title()

# Generated at 2022-06-21 16:46:36.237627
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color(safe=True)
    assert len(hex_color) == 7
    assert hex_color[0] == '#'
    assert len(hex_color[1:]) == 6

# Generated at 2022-06-21 16:46:37.590764
# Unit test for method level of class Text
def test_Text_level():
    """Test Text class level method."""
    t = Text()
    assert len(t.level()) > 0

# Generated at 2022-06-21 16:46:40.910760
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'
    assert text.__doc__ is not None


# Generated at 2022-06-21 16:46:44.105160
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    for i in range(100):
        #Test for method rgb_color
        result = Text().rgb_color()
        assert type(result) is tuple
        assert len(result)==3

# Generated at 2022-06-21 16:46:49.188470
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    nums = 100
    t = Text(language=Language.EN)
    for _ in range(nums):
        color = t.color()
        # assert isinstance(color, str)
        assert 0 < len(color) <= 20

# Generated at 2022-06-21 16:46:50.692105
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    test_str = t.hex_color()
    assert len(test_str) == 7 and test_str[0] == '#'


# Generated at 2022-06-21 16:47:08.820222
# Unit test for method level of class Text
def test_Text_level():
    unit = Text()
    unit.level()


# Generated at 2022-06-21 16:47:11.027619
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Function for testing"""
    text = Text()
    swear_word = text.swear_word()
    assert len(swear_word) > 0

# Generated at 2022-06-21 16:47:13.692316
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Return safe RGB tuple."""
    t = Text()
    _ = t.rgb_color(True)


# Generated at 2022-06-21 16:47:15.069946
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None


# Generated at 2022-06-21 16:47:17.880546
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for hex color.

    :return: None
    """
    t = Text('en')
    for i in range(10):
        assert isinstance(t.hex_color(), str)


# Generated at 2022-06-21 16:47:20.412416
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Locale
    text = Text(locale = Locale.RUSSIAN)
    #print(text.quote())


# Generated at 2022-06-21 16:47:21.541554
# Unit test for method words of class Text
def test_Text_words():
    assert Text().words(quantity=4)



# Generated at 2022-06-21 16:47:22.583675
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-21 16:47:25.477517
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.providers.text import Text
    txt = Text()
    text = txt.sentence()
    assert(isinstance(text, str))


# Generated at 2022-06-21 16:47:26.561229
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass


# Generated at 2022-06-21 16:48:41.575258
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-21 16:48:44.176447
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text(seed=12345)
    result = provider.quote()
    assert result == 'Bond... James Bond.'


# Generated at 2022-06-21 16:48:45.356607
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    expected_result = ['Damn', 'Shit', 'Fuck']
    text = Text()
    result = text.swear_word()
    assert result in expected_result

# Generated at 2022-06-21 16:48:46.016787
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert isinstance(text.answer(), str)

# Generated at 2022-06-21 16:48:47.930458
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() == 'Blue'
    assert t.color() == 'Black'
    assert t.color() == 'Green'


# Generated at 2022-06-21 16:48:49.184089
# Unit test for method words of class Text
def test_Text_words():
    
    text = Text()
    assert len(text.words(quantity = 7)) == 7
    

# Generated at 2022-06-21 16:48:53.728833
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert Text().alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-21 16:48:55.884456
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert type(text.answer()) == str


# Generated at 2022-06-21 16:49:04.602901
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    t = Text('zh_CN', seed=32355)
    assert t.words(2) == ['弟弟', '轮胎']
    per = Person('zh_CN', seed=32355)
    assert t.words(5) == ['披萨', '女人', per.name(gender=Gender.FEMALE), '交叉', '披萨']


# Generated at 2022-06-21 16:49:06.668127
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Created instance of class Text
    t = Text()

    # Generate 5 sentences
    for i in range(5):
        print(i, t.sentence())
