

# Generated at 2022-06-21 16:45:00.016199
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() != Text().sentence()

# Generated at 2022-06-21 16:45:00.728314
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title()


# Generated at 2022-06-21 16:45:02.635298
# Unit test for method answer of class Text
def test_Text_answer():
    """Test method answer of class Text."""
    text = Text()
    result = text.answer()
    assert result in text.answers()




# Generated at 2022-06-21 16:45:04.891968
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())



# Generated at 2022-06-21 16:45:09.696322
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    generator = Text(seed=123)

    assert generator.hex_color() == "#ae9f45"
    assert generator.hex_color(safe=True) == "#8E44AD"


# Generated at 2022-06-21 16:45:13.059474
# Unit test for method level of class Text
def test_Text_level():
    """Tests class Level"""
    t = Text()
    e = t.level()
    assert t.level() in ['безопасный', 'опасный']


# Generated at 2022-06-21 16:45:15.414080
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    for i in range(100):
        assert t.level() in ["critical", "danger", "warning", "success"]


# Generated at 2022-06-21 16:45:16.274931
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    assert  len(alpha) == 26


# Generated at 2022-06-21 16:45:17.185747
# Unit test for method level of class Text
def test_Text_level():
	former = Text()
	assert former.level() in former._data['level']
    

# Generated at 2022-06-21 16:45:18.266024
# Unit test for method quote of class Text
def test_Text_quote():
  txt = Text()
  txt.quote()

  # txt.word()

# Generated at 2022-06-21 16:46:27.662995
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.answer())

# Generated at 2022-06-21 16:46:29.334959
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    dut = Text(seed=10)
    assert dut.swear_word() == 'Damn'

# Generated at 2022-06-21 16:46:32.401850
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert re.match(r'^#[0-9a-fA-F]{6}$', Text().hex_color())
    assert Text().hex_color() in SAFE_COLORS

# Generated at 2022-06-21 16:46:33.528715
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-21 16:46:36.123062
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for Text.rgb_color()."""
    t = Text()
    rgb = t.rgb_color()
    assert type(rgb) == tuple


# Generated at 2022-06-21 16:46:38.022309
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test the method swear_word of class Text."""
    text = Text(seed=1)
    assert text.swear_word() == 'ass'