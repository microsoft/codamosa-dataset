

# Generated at 2022-06-21 16:47:22.247711
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
  text = Text()
  result = text.rgb_color()
  assert result != False


# Generated at 2022-06-21 16:47:25.816893
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in ['Red', 'Blue', 'Green', 'Yellow', 'Black', 'Pink', 'Purple', 'Gray', 'Orange', 'Cyan']


# Generated at 2022-06-21 16:47:28.966172
# Unit test for method words of class Text
def test_Text_words():
    """Test for class Text.
    Test for method words.
    """
    text = Text()
    result = text.words(10)
    assert len(result) == 10


# Generated at 2022-06-21 16:47:30.744789
# Unit test for method level of class Text
def test_Text_level():
    text = Text("en")
    text.level()   # What is the level?


# Generated at 2022-06-21 16:47:32.846898
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level() of class Text
    """
    text = Text()
    res = text.level()
    assert res in text._data['level']

# Generated at 2022-06-21 16:47:34.153229
# Unit test for method sentence of class Text
def test_Text_sentence():
    _sentence = Text().sentence()
    assert(len(_sentence) > 1)

# Generated at 2022-06-21 16:47:35.785494
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    levels = text.level()
    assert levels in ['critical', 'medium', 'low']

# Generated at 2022-06-21 16:47:44.790645
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.hex_color())
    print(t.hex_color(safe=True))
    print(t.random.choice(SAFE_COLORS))
    print(t.rgb_color())
    print(t.rgb_color(safe=True))
    print(t.random.choice(t._data['quotes']))
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())
    print(t.quote())

# Generated at 2022-06-21 16:47:47.318012
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    for _ in range(10):
        assert t.level() in ['critical', 'high', 'medium', 'low', 'info']

# Generated at 2022-06-21 16:47:48.663348
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert len(t.sentence()) > 0


# Generated at 2022-06-21 16:49:03.510122
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text(seed=1234)
    # lowercase
    assert t.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'
    # uppercase
    assert t.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-21 16:49:08.706698
# Unit test for method quote of class Text
def test_Text_quote():
    assert (Text.quote() in [
        "In brightest day, in blackest night.",
        "No evil shall escape my sight.",
        "Let those who worship evil's might.",
        "Beware my power—Green Lantern's light!"
    ])
    assert (Text.quote() not in [
        "In brightest day, in blackest night.",
        "No evil shall escape my sight.",
        "Let those who worship evil's might.",
        "Beware my power—Green Lantern's light!"
    ])



# Generated at 2022-06-21 16:49:10.192686
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    obj = Text()
    result = obj.alphabet(lower_case=True)
    assert isinstance(result, list) == True


# Generated at 2022-06-21 16:49:15.350239
# Unit test for method color of class Text
def test_Text_color():
    for i in range(10):
        color = Text().color()
        assert isinstance(color, str)
        assert 0 < len(color) <= 20


# Generated at 2022-06-21 16:49:21.933395
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import RussiaSpecProvider

    text = Text(RussiaSpecProvider)
    rgb = text.rgb_color()
    assert rgb is not None
    assert isinstance(rgb, tuple)
    assert len(rgb) == 3
    assert rgb[0] in range(0, 255)
    assert rgb[1] in range(0, 255)
    assert rgb[2] in range(0, 255)

    rgb = text.rgb_color(safe=True)
    assert rgb is not None
    assert isinstance(rgb, tuple)
    assert len(rgb) == 3
    assert rgb[0] in range(0, 255)
    assert rgb[1] in range(0, 255)
    assert rgb[2] in range(0, 255)
    

# Generated at 2022-06-21 16:49:23.033999
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()

    sentence = text.sentence()

    assert sentence is not None


# Generated at 2022-06-21 16:49:26.128544
# Unit test for method title of class Text
def test_Text_title():
    title = Text().title()
    assert title != '', 'Title is empty string.'
    assert isinstance(title, str), 'Title is not a string.'


# Generated at 2022-06-21 16:49:28.253945
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for Text.color()."""
    text = Text()
    result = text.color()

    print(result)
    assert result

    print('test_Text_color - ok')



# Generated at 2022-06-21 16:49:30.319291
# Unit test for method title of class Text
def test_Text_title():
	a = Text(seed=42).title()
	b = 'Internet'
	assert a == b


# Generated at 2022-06-21 16:49:31.987507
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(),str)
    print('word:',t.word())