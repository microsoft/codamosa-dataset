

# Generated at 2022-06-21 16:49:32.425242
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    print(text.swear_word())

# Generated at 2022-06-21 16:49:37.049205
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    for i in range(0, 5):
        word = t.word()
        #if word in words:
        #    print("Word already exist!")
        #    break
        #else:
        #    words.append(word)
        print(word)

# Generated at 2022-06-21 16:49:39.569417
# Unit test for method word of class Text
def test_Text_word():
    """Test method word of class Text."""
    text = Text()
    assert text.word() in text._data['words'].get('normal')


# Generated at 2022-06-21 16:49:41.653892
# Unit test for method text of class Text
def test_Text_text():
    pass

# Generated at 2022-06-21 16:49:43.993888
# Unit test for method title of class Text
def test_Text_title():
    data = Text("en")
    assert(data.title() in data._data['text'])

# Generated at 2022-06-21 16:49:48.914563
# Unit test for method color of class Text
def test_Text_color():
    """Test method color of class Text."""
    text = Text()
    assert type(text.color()) is str


# Generated at 2022-06-21 16:49:52.007148
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    res = text.text()
    print('Text: ' + str(res))
    assert isinstance(res, str)

# Generated at 2022-06-21 16:49:57.725811
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text(seed=12345)
    sent = t.sentence()
    assert sent == "illum nihil omnis non et repudiandae excepturi blanditiis"

    t = Text(seed=12345)
    sent = t.sentence()
    assert sent == "illum nihil omnis non et repudiandae excepturi blanditiis"

    t = Text(seed=12345)
    sent = t.sentence()
    assert sent == "illum nihil omnis non et repudiandae excepturi blanditiis"


# Generated at 2022-06-21 16:50:01.291737
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert isinstance(text.alphabet(), list)


# Generated at 2022-06-21 16:50:03.262061
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    alphabet = Text.alphabet()
    assert alphabet is not None
