

# Generated at 2022-06-23 21:51:28.215314
# Unit test for method text of class Text
def test_Text_text():
    text=Text()
    a=text.text()
    print(a)

# Generated at 2022-06-23 21:51:33.409087
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    quantity = 100
    word_list = text.words(quantity=quantity)
    assert len(word_list) == quantity
    assert type(word_list) == list
    assert type(word_list[0]) == str
    print(word_list)



# Generated at 2022-06-23 21:51:41.053896
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.builtins import Text as Text_en
    from mimesis.builtins import Text as Text_ru

    test_text = Text_en(Locale.ENGLISH)
    title_en = test_text.title()
    assert isinstance(title_en, str)
    assert title_en.isupper()

    test_text_ru = Text_ru(Locale.RUSSIAN)
    title_ru = test_text_ru.title()
    assert isinstance(title_ru, str)
    assert title_ru.isupper()


# Generated at 2022-06-23 21:51:43.406221
# Unit test for method color of class Text
def test_Text_color():
	text = Text()
	print(text.color())

# Generated at 2022-06-23 21:51:45.164604
# Unit test for method level of class Text
def test_Text_level():
	t = Text()
	level = t.level()
	print(level)
	

# Generated at 2022-06-23 21:51:48.448908
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Arrange
    # Act
    for _ in range(100):
        result = Text().hex_color()
        # Assert
        assert len(result) == 7 and result.startswith('#')


# Generated at 2022-06-23 21:51:52.007483
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text
    from mimesis.enums import Gender
    t = Text()
    print(t.words(quantity=3))
    print(t.words(quantity=3))
    print(t.words(quantity=3))


# Generated at 2022-06-23 21:51:54.115882
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert(answer in ['Yes', 'No'])


# Generated at 2022-06-23 21:51:59.284616
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    items = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert Text().alphabet() == items


# Generated at 2022-06-23 21:52:01.436041
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    import random
    data = Text(random=random)
    result = data.rgb_color()
    assert result

# Generated at 2022-06-23 21:52:04.311927
# Unit test for method word of class Text
def test_Text_word():
    text_provider = Text()
    w = text_provider.word()
    # print("random word: %s" % w)
    

# Generated at 2022-06-23 21:52:07.912616
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t_text = Text()
    color_text = t_text.rgb_color()
    print(color_text)

if __name__ == "__main__":
    test_Text_rgb_color()

# Generated at 2022-06-23 21:52:11.105553
# Unit test for method alphabet of class Text
def test_Text_alphabet():

    t = Text()
    result = t.alphabet(lower_case=False)
    assert result is not None
    

# Generated at 2022-06-23 21:52:13.414495
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locale

    text = Text(locale=Locale.EN)
    sentence = text.sentence()
    assert sentence

# Generated at 2022-06-23 21:52:15.666381
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text
    word1 = Text().word()
    word2 = Text().word()
    assert word1 != word2


# Generated at 2022-06-23 21:52:18.607788
# Unit test for method answer of class Text
def test_Text_answer():
    txt = Text()
    assert txt.answer() in txt._data['answers']


# Generated at 2022-06-23 21:52:24.736481
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from mimesis.text import Text
    t = Text(seed=1)
    empty_tuple = ()
    assert t.rgb_color(safe=False) != empty_tuple
    assert t.rgb_color(safe=False) != t.rgb_color(safe=False)
    assert t.rgb_color() == t.rgb_color(safe=True)


# Generated at 2022-06-23 21:52:27.263554
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text."""
    text = Text()
    print("Text.color() -> {}".format(text.color()))


# Generated at 2022-06-23 21:52:29.348539
# Unit test for constructor of class Text
def test_Text():
    text = Text(seed=123)
    #result = text.answer()
    #print(result)
    res = text.quo

# Generated at 2022-06-23 21:52:31.733782
# Unit test for method title of class Text
def test_Text_title():
	t = Text()
	print("The random title: ",t.title())
	pass


# Generated at 2022-06-23 21:52:38.495684
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.alphabet(lower_case=True) == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n",
                                              "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    assert text.text() == "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut " \
                          "labore et dolore magna aliqua."
    assert text.quote() == "I'm the king of the world!"
    assert text.level() == "critical"

# Generated at 2022-06-23 21:52:40.289236
# Unit test for method word of class Text
def test_Text_word():
    # Makes sure method word returns word.
    assert len(Text().word()) > 2


# Generated at 2022-06-23 21:52:43.562279
# Unit test for method quote of class Text
def test_Text_quote():
    """Test for method quote of class Text.
    """
    from mimesis import Text
    from mimesis.enums import Locale
    text = Text(Locale.EN)
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-23 21:52:46.702120
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    answer = text.answer()
    assert answer == 'Yes' or answer == 'No'

# Generated at 2022-06-23 21:52:48.401422
# Unit test for method answer of class Text
def test_Text_answer():
    for i in range(10):
        assert Text().answer() in ['Yes', 'No']

# Generated at 2022-06-23 21:52:50.090415
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text"""
    # result = Text(seed=123456789).level()
    result = Text().level()
    assert result == 'critical'


# Generated at 2022-06-23 21:52:52.155392
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in ["Shit", "Damn", "Fuck", "Ass", "Hell"]

# Generated at 2022-06-23 21:53:00.825247
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert isinstance(t.hex_color(), str)
    assert isinstance(t.hex_color(safe=True), str)
    assert t.hex_color().startswith('#')
    assert t.hex_color(safe=True).startswith('#')
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7
    assert t.hex_color() in SAFE_COLORS
    assert t.hex_color(safe=True) in SAFE_COLORS



# Generated at 2022-06-23 21:53:02.760723
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert text.words() == ['world', 'ask', 'car', 'room', 'company']

# Generated at 2022-06-23 21:53:05.999842
# Unit test for method word of class Text
def test_Text_word():
    """Method for testing Text class."""
    x = Text()
    e = x.word()
    print(e)
    assert type(e) is str


# Generated at 2022-06-23 21:53:07.722754
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert len(answer) > 0


# Generated at 2022-06-23 21:53:10.168173
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert type(t.alphabet()) == list
    assert type(t.alphabet(lower_case=True)) == list


# Generated at 2022-06-23 21:53:11.009081
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']

# Generated at 2022-06-23 21:53:14.897995
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print("\n--- Method: test_Text_quote() ---")
    print("Returned Value: ", t.quote())
    print("Expected Value: A quote")


# Generated at 2022-06-23 21:53:23.430431
# Unit test for constructor of class Text
def test_Text():
    # Initialize class
    text = Text()
    assert text.word()
    assert text.words()
    assert text.sentence()
    assert text.title()
    assert text.text()

    assert text.alphabet()
    assert text.alphabet(lower_case=True)

    assert text.level()

    assert text.swear_word()
    assert text.quote()
    assert text.color()

    assert text.hex_color()
    assert text.hex_color(safe=True)

    assert text.rgb_color()
    assert text.rgb_color(safe=True)

    assert text.answer()

# Generated at 2022-06-23 21:53:24.953056
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    a = t.color()
    assert a in t._data['color']

# Generated at 2022-06-23 21:53:26.356446
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())

# Generated at 2022-06-23 21:53:27.112969
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print("color()-->", t.color())


# Generated at 2022-06-23 21:53:34.235319
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.color()
    assert t.quote()
    assert t.level()
    assert t.word()
    assert t.swear_word()
    assert t.hex_color()
    assert t.rgb_color()
    assert t.words()
    
if __name__ == '__main__':
    # get the current tool to test
    test_Text()

# Generated at 2022-06-23 21:53:36.384547
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    # check if it returns a string
    assert isinstance(t.answer(), str)


# Generated at 2022-06-23 21:53:38.446265
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis import Text
    text = Text('en')
    assert text.answer() in ["Yes", "May be", "No", "No way"]

# Generated at 2022-06-23 21:53:41.270031
# Unit test for method title of class Text
def test_Text_title():
    import pytest
    from mimesis.providers.text import Text

    text = Text()
    title = text.title()
    assert len(title) > 0
    assert title[0].isupper()
    assert title[-1] == '.'

# Generated at 2022-06-23 21:53:48.956816
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    from mimesis.builtins import Text

    text = Text('en')
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.alphabet(lower_case=False), list)
    text.set_case(Case.LOWER)
    assert isinstance(text.alphabet(), list)
    text.set_case(Case.UPPER)
    assert isinstance(text.alphabet(), list)

# Generated at 2022-06-23 21:53:51.384168
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    test_val = text.hex_color()
    print(test_val)


# Generated at 2022-06-23 21:53:54.037173
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    t = Text()
    assert t.level() in ['critical', 'danger', 'alert', 'warning']

# Generated at 2022-06-23 21:53:56.138820
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    if alpha == None:
        assert False
    else:
        assert True


# Generated at 2022-06-23 21:53:58.777101
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Test a random RGB tuple
    t = Text()
    t.rgb_color()  # (252, 85, 32)
    # Test a random safe RGB tuple
    t.rgb_color(safe=True)  # (41, 128, 185)

# Generated at 2022-06-23 21:54:01.363079
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t.locale, str)
    assert isinstance(t.random, int)

# Generated at 2022-06-23 21:54:02.156663
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() is not None
    assert t.color() != ''

# Generated at 2022-06-23 21:54:03.879209
# Unit test for method level of class Text
def test_Text_level():
    """
    Test level method of class Text.
    """
    assert isinstance(Text.level(),str)


# Generated at 2022-06-23 21:54:08.261198
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert (type(t.text()) == str)
    assert 1 <= len(t.text().split(" ")) <= 5
    assert (type(t.text(2)) == str)
    assert 1 <= len(t.text(2).split(" ")) <= 2
    assert (type(t.text(10)) == str)
    assert 1 <= len(t.text(10).split(" ")) <= 10


# Generated at 2022-06-23 21:54:09.816462
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() == "Bond… James Bond."

# Generated at 2022-06-23 21:54:12.952982
# Unit test for constructor of class Text
def test_Text():
    text1 = Text()
    text2 = Text()
    lst = [text1.text(), text2.text()]
    assert lst[0] != lst[1]


# Generated at 2022-06-23 21:54:14.618133
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    Text._hex_to_rgb(Text().hex_color())\
        == Text().rgb_color()

# Generated at 2022-06-23 21:54:16.560843
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text('en')
    assert t.hex_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-23 21:54:17.708260
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    assert x != None, "Creation of Text failed"


# Generated at 2022-06-23 21:54:19.900125
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    w = t.word()
    assert w in t._data['words']['normal'], "Word not in words list"

# Generated at 2022-06-23 21:54:22.158491
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)

# Generated at 2022-06-23 21:54:24.233686
# Unit test for method answer of class Text
def test_Text_answer():
    obj = Text()
    result = obj.answer()
    assert (type(result) == str)


# Generated at 2022-06-23 21:54:27.059354
# Unit test for method answer of class Text
def test_Text_answer():
    # init an instance
    provider = Text(seed=1)
    # test the method
    result = provider.answer()
    # check result
    assert result == 'Yes'
    

# Generated at 2022-06-23 21:54:29.157891
# Unit test for method word of class Text
def test_Text_word():
    # this test has been removed for now
    return
    text = Text()
    for _ in range(20):
        assert text.word() in text._data['words'].get('normal')

# Generated at 2022-06-23 21:54:32.554974
# Unit test for method answer of class Text
def test_Text_answer():
    # The use of the method being tested is quite simple, just getting a random 
    # answer in the current language, so a unit test with a single run is 
    # enough. If any new answers are added to the corresponding json file, the 
    # unit test can be updated.
    text = Text()
    result = text.answer()
    print(result)


# Generated at 2022-06-23 21:54:44.104752
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=1)
    assert t.rgb_color(safe=False) == (177, 202, 255)
    assert t.rgb_color(safe=True) == (127, 205, 187)
    assert t.rgb_color(safe=False) == (11, 130, 155)
    assert t.rgb_color(safe=True) == (82, 179, 217)
    assert t.rgb_color(safe=False) == (124, 13, 72)
    assert t.rgb_color(safe=True) == (189, 195, 199)
    assert t.rgb_color(safe=False) == (39, 70, 29)
    assert t.rgb_color(safe=True) == (142, 36, 170)
    assert t.rgb_color(safe=False)

# Generated at 2022-06-23 21:54:45.343065
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=1)
    print(t.rgb_color(safe=True))


# Generated at 2022-06-23 21:54:48.271321
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale
    from mimesis.localization import localization

    localization(locale=Locale.EN)

    text = Text()
    a = text.text()
    assert len(a) == 5



# Generated at 2022-06-23 21:54:49.317557
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text.answer() in Text._data['answers']


# Generated at 2022-06-23 21:54:52.064304
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert isinstance(t.answer(), str)


# Generated at 2022-06-23 21:54:53.767035
# Unit test for method word of class Text
def test_Text_word():
    for i in range(0, 100):
        assert(len(Text(i).word()) >= 1)


# Generated at 2022-06-23 21:54:55.592212
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    test = Text()
    swear_words = []
    for i in range(20):
        sw = test.swear_word()
        swear_words.append(sw)
        print(sw)

    assert True


# Generated at 2022-06-23 21:54:56.597510
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert len(t.color()) >= 1


# Generated at 2022-06-23 21:54:59.472422
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert type(t.rgb_color()) == tuple
    assert len(t.rgb_color()) == 3
    assert type(t.rgb_color(safe=True)) == tuple
    assert len(t.rgb_color(safe=True)) == 3


# Generated at 2022-06-23 21:55:01.121371
# Unit test for method answer of class Text
def test_Text_answer():
    txt = Text()
    assert type(txt.answer()) == str


# Generated at 2022-06-23 21:55:02.892312
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in ['Yes', 'No', 'Maybe']

# Generated at 2022-06-23 21:55:13.084920
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale
    from mimesis.localization import Localization
    # Create instance of class Text
    text = Text(locale=Locale.ENGLISH.value)
    word = text.word()
    assert (type(word) == str)
    assert (len(word) > 0)
    assert (word.isalpha())
    assert (word.lower() == word)
    # Create instance of class Text with German locale
    text = Text(locale=Locale.GERMAN.value)
    word = text.word()
    assert (type(word) == str)
    assert (len(word) > 0)
    assert (word.isalpha())
    assert (word.lower() == word)
    # Create instance of class Text with Russian locale

# Generated at 2022-06-23 21:55:14.149410
# Unit test for method quote of class Text
def test_Text_quote():

    text = Text("de")
    text.quote()

# Generated at 2022-06-23 21:55:17.003230
# Unit test for method title of class Text
def test_Text_title():
    txt = Text()
    assert isinstance(txt.title(), str)
    assert txt.title() is not ""
    assert txt.title() is not None
    assert txt.title() in txt._data['text']


# Generated at 2022-06-23 21:55:17.879443
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert "critical" in t.level()


# Generated at 2022-06-23 21:55:19.191938
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    text.swear_word()


# Generated at 2022-06-23 21:55:20.783799
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    for j in range(5):
        assert t.text()


# Generated at 2022-06-23 21:55:22.036434
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text.sentence())


# Generated at 2022-06-23 21:55:23.215168
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text()



# Generated at 2022-06-23 21:55:24.596906
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    text.answer()
    assert True

# Generated at 2022-06-23 21:55:25.670967
# Unit test for method level of class Text
def test_Text_level():
    print(Text().level())

# Generated at 2022-06-23 21:55:27.861711
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert isinstance(Text().hex_color(), str)


# Generated at 2022-06-23 21:55:38.809588
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    # Assert method text
    assert x.text(3) == 'Praesent arcu libero, luctus ut, accumsan in, dapibus'
    # Assert method title
    assert x.title() == 'Curabitur scelerisque purus in vulputate velit scelerisque.'
    # Assert method quote
    assert x.quote() == '"Great men are not born great, they grow great... "'
    # Assert method color
    assert x.color() == 'white'
    # Assert method hex_color
    assert x.hex_color(True) == '#1abc9c'
    # Assert method hex_color
    assert x.hex_color(False) == '#6918b4'
    # Assert method rgb_color

# Generated at 2022-06-23 21:55:44.306501
# Unit test for method text of class Text
def test_Text_text():
    text_provider = Text(seed=1)
    res = text_provider.text()
    assert res
    assert res is not None
    text_provider = Text(seed=1)
    res = text_provider.text(10)
    assert res
    assert res is not None


# Generated at 2022-06-23 21:55:46.696395
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert len(Text().swear_word()) > 2


# Generated at 2022-06-23 21:55:48.606744
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    txt = Text()
    txt.swear_word()
    pass

# Generated at 2022-06-23 21:55:50.482040
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color(True) in SAFE_COLORS


# Generated at 2022-06-23 21:55:53.218887
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import Text
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color == text.rgb_color()

# Generated at 2022-06-23 21:55:54.754278
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    print(t.swear_word())

# Generated at 2022-06-23 21:55:57.054071
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().get_localized_provider('en-US').sentence() in Text().get_localized_provider('en-US')._data['text']

# Generated at 2022-06-23 21:55:58.424915
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # TODO
    print("Test Text.alphabet()")


# Generated at 2022-06-23 21:56:01.470453
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Language
    t = Text(Language.ENGLISH)
    test_Text_alphabet.test_data = t.alphabet()
    assert len(test_Text_alphabet.test_data) > 0



# Generated at 2022-06-23 21:56:07.700180
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test the method hex_color of class Text."""
    text = Text()
    res = text.hex_color()
    color = '#' + res[1:]
    assert len(res) == 7
    assert res[0] == '#'
    assert int(color, 16) >= 0x000000
    assert int(color, 16) <= 0xffffff

# Generated at 2022-06-23 21:56:12.291535
# Unit test for method color of class Text
def test_Text_color():
    # Case: english locale, random color
    text_english = Text(locale="en")
    color_English = text_english.color()
    assert color_English in text_english._data['color']
    assert isinstance(color_English, str)
    assert len(color_English) > 0


# Generated at 2022-06-23 21:56:13.555065
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26


# Generated at 2022-06-23 21:56:15.341705
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    data = Text()
    alphabet = data.alphabet(lower_case = True)
    assert isinstance(alphabet, list)

# Generated at 2022-06-23 21:56:17.126129
# Unit test for method title of class Text
def test_Text_title():
    address = Text()
    s = address.title() 
    print(s)


# Generated at 2022-06-23 21:56:18.585274
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() == "Bond... James Bond."


# Generated at 2022-06-23 21:56:24.215067
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    from mimesis.random import Mimesis
    t = Text(Mimesis(Language.UKRAINIAN))
    a = t.color()
    print(a)
    assert a in t._data["color"]


# Generated at 2022-06-23 21:56:26.163597
# Unit test for method words of class Text
def test_Text_words():
    print(Text().words(5))
# Output ['science', 'network', 'god', 'octopus', 'love']

# Generated at 2022-06-23 21:56:28.324800
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() != ''

# Generated at 2022-06-23 21:56:30.175173
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data["quotes"]

# Generated at 2022-06-23 21:56:34.651904
# Unit test for method text of class Text
def test_Text_text():
    foo = Text(seed=123)

    # Test with default value
    bar = foo.text()
    assert bar == 'I am ordinary tools gods giant.'

    # Test with custom quantity
    assert foo.text(quantity=3) == 'I am ordinary tools gods giant. I am ordinary tools gods giant. I am ordinary tools gods giant.'

# Generated at 2022-06-23 21:56:36.630837
# Unit test for method words of class Text
def test_Text_words():
    words_list = Text().words(quantity=3)
    print(words_list)
    assert len(words_list) == 3


# Generated at 2022-06-23 21:56:38.103627
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert result is not None


# Generated at 2022-06-23 21:56:40.137838
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    n = t.rgb_color()
    assert n == (1, 3, 8)


# Generated at 2022-06-23 21:56:42.168827
# Unit test for method text of class Text
def test_Text_text():
    text_ptbr = Text.provider('pt-BR')
    text_ptbr.text(quantity=10)

# Generated at 2022-06-23 21:56:45.469209
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text
    text = Text()
    for i in range(0, 10):
        print(text.word())


# Generated at 2022-06-23 21:56:47.500356
# Unit test for method level of class Text
def test_Text_level():
    text_provider = Text()
    level = text_provider.level()
    assert level in ['critical','exceptional','good','nearly','no','ok']


# Generated at 2022-06-23 21:56:52.247255
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from mimesis.typing import Color

    text = Text('en')
    color1 = text.rgb_color(safe=True)
    color2 = text.rgb_color(safe=False)

    assert isinstance(color1, tuple)
    assert isinstance(color2, tuple)
    assert Color.rgb(rgb=color1) == color1
    assert Color.rgb(rgb=color2) == color2

    assert Text('en').rgb_color(safe=True) in ColorType.SAFE_COLORS


# Generated at 2022-06-23 21:57:02.207121
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    from mimesis.enums import SpecialChar
    from mimesis.enums import UpperCase
    tester = Text()
    assert type(tester.alphabet(lower_case=True)) == list
    assert type(tester.alphabet(lower_case=False)) == list
    assert type(tester.alphabet(lower_case=True)/
                tester.alphabet(lower_case=False)) == list
    assert type(tester.alphabet(lower_case=True)/
                tester.alphabet(lower_case=False)/
                tester.alphabet(lower_case=True)) == list
    assert tester.alphabet(lower_case=True) == list(map(chr, range(97, 123)))

# Generated at 2022-06-23 21:57:04.360197
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert type(text.sentence()) == str
    assert len(text.sentence()) > 0


# Generated at 2022-06-23 21:57:08.170390
# Unit test for method text of class Text
def test_Text_text():
    import random
    text_verifier = Text(random.seed(1))
    assert text_verifier.text() == 'aaaaaa abcd efghij klmn opq rstuv wxyz'
    assert text_verifier.text(0) == ''
    assert text_verifier.text(None) == ''


# Generated at 2022-06-23 21:57:19.190669
# Unit test for constructor of class Text
def test_Text():
    import io
    import sys
    import unittest

    from mimesis.enums import Gender
    from mimesis.data import CATEGORIES
    from mimesis.enums import Locale

    from .dataprovider import get_operator

    from .dataprovider import TestCase, get_provider

    base_url = 'https://raw.githubusercontent.com/lk-geimfari/mimesis/' \
               'master/mimesis/data/'
    file_path = '{base_url}{language_code}/{category}.json'
    CATEGORIES['bible'] = 'https://raw.githubusercontent.com/ikayz/mimesis/' \
                          'master/mimesis/data/bible.json'


# Generated at 2022-06-23 21:57:21.609197
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    ans = t.word()
    assert isinstance(ans, str)
    assert len(ans) > 0


# Generated at 2022-06-23 21:57:25.044226
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Locales
    from mimesis.providers.text import Text
    prov = Text(Locales.EN)
    ans = prov.answer()
    assert isinstance(ans, (str))


# Generated at 2022-06-23 21:57:26.236042
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level()
    # assert t.level()

# Generated at 2022-06-23 21:57:28.446308
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text_generated = text.text()
    print(text_generated)


# Generated at 2022-06-23 21:57:31.560517
# Unit test for constructor of class Text
def test_Text():
    test = Text()
    #print(test.answer())
    print(test.swear_word())
    #print(test.quotes())
    #print(test.words(10))
    #print(test.word())
    #print(test.quote())
    #print(test.color())
    #print(test.hex_color())
    #print(test.rgb_color())
    #print(test.level())
    #print(test.text(10))

if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-23 21:57:34.270119
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    text_answers = text.answer()
    assert text_answers == 'yes' or 'no'

# Generated at 2022-06-23 21:57:37.068943
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    text = Text()
    assert text.sentence() == text.text(1)

# Generated at 2022-06-23 21:57:38.004664
# Unit test for method level of class Text
def test_Text_level():
    test = Text()
    output = test.level()
    print(output)

# Generated at 2022-06-23 21:57:40.340706
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    color = Text(seed=12345).color()
    assert color == 'Red'

# Generated at 2022-06-23 21:57:41.889916
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)


# Generated at 2022-06-23 21:57:43.909729
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data["level"]


# Generated at 2022-06-23 21:57:50.820696
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    from mimesis.builtins import Text
    from mimesis.enums import Quality
    from mimesis.exceptions import NonEnumerableError

    t = Text()
    t.seed(4)
    assert t.text() == 'I am the very model of a modern Major-General'
    assert t.text(quality=Quality.MEDIUM) == 'I am the very model of a modern Major-General'
    assert t.text(quantity=10) == 'I am the very model of a modern Major-General I am the very model of a modern Major-General I am the very model of a modern Major-General I am the very model of a modern Major-General I am the very model of a modern Major-General'

# Generated at 2022-06-23 21:57:51.782680
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    t.word()

# Generated at 2022-06-23 21:57:52.739262
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    text.rgb_color()

# Generated at 2022-06-23 21:57:57.288944
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level."""
    from mimesis.enums import Level
    from mimesis.builtins import EN
    actual = EN('text').level()
    assert actual in Level.__members__


# Generated at 2022-06-23 21:58:00.869851
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text('en')
    text1 = Text('es')
    text2 = Text('ru')
    print(text.sentence())
    print(text1.sentence())
    print(text2.sentence())


# Generated at 2022-06-23 21:58:02.027768
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote() == "Bond... James Bond."

# Generated at 2022-06-23 21:58:05.157095
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    t = Text()
    text = t.text()
    #print(text)


# Generated at 2022-06-23 21:58:07.304689
# Unit test for method level of class Text
def test_Text_level():
    """Test for method level"""
    text = Text(seed=0)
    assert text.level() == "critical"


# Generated at 2022-06-23 21:58:08.590038
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() in t._data['text']

# Generated at 2022-06-23 21:58:10.456004
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.providers.text import Text
    test_text=Text('zh')
    a=test_text.quote()
    print(a)

# Generated at 2022-06-23 21:58:13.845736
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Language
    from mimesis.data import SAFE_COLORS
    from mimesis.providers.text import Text
    _sentence = "Dogs bark"
    t = Text(Language.EN.value)
    assert t.sentence() in _sentence

# Generated at 2022-06-23 21:58:16.207713
# Unit test for method color of class Text
def test_Text_color():
    """Check if color is not Empty"""
    t = Text()
    assert t.color() != ""

# Generated at 2022-06-23 21:58:26.316567
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    provider = Text()
    for _ in range(10):
        print(provider.text())

    provider = Text('ru')
    for _ in range(10):
        print(provider.text())

    provider = Text('ru')
    for _ in range(10):
        print(provider.text())

    provider = Text('en', gender=Gender.FEMALE)
    dt = Datetime()
    dt.timezone = 'Asia/Yekaterinburg'
    startDate = dt.date()
    endDate = dt.date_after(startDate)
    date = dt.date(startDate, endDate)


# Generated at 2022-06-23 21:58:29.258720
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    sentence = txt.sentence()
    assert isinstance(sentence, str)
    assert len(sentence.split()) >= 3


# Generated at 2022-06-23 21:58:38.369676
# Unit test for constructor of class Text
def test_Text():
    text = Text(seed=1)
    assert text.hex_color() == '#ac7d85'

    text = Text(seed=1)
    assert text.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K',
                               'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
                               'W', 'X', 'Y', 'Z']

    text = Text(seed=1)

# Generated at 2022-06-23 21:58:41.606560
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = Text().hex_color()
    assert isinstance(result, str)
    assert len(result) == 7
    result = Text().hex_color(safe=True)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:58:45.844235
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.builtins import Text
    text = Text()
    for i in range(5):
        assert len(text.text()) > 1
        assert len(text.text(10)) > 1


# Generated at 2022-06-23 21:58:53.909390
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Set the language to Russian
    t = Text(locale='ru')
    safe_color = t.hex_color(safe=True)
    assert len(safe_color) == 7

    # Set the language to English
    t = Text()
    safe_color = t.hex_color(safe=True)
    assert len(safe_color) == 7

    # Return a random hex color
    safe_color = t.hex_color()

    # Set the language to Russian
    t = Text(locale='ru')
    safe_color = t.hex_color()


# Generated at 2022-06-23 21:58:54.952228
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    result = t.sentence()
    print(result)


# Generated at 2022-06-23 21:58:58.382519
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    t = Text()
    for _ in range(100):
        assert len(t.sentence()) > 1

# Generated at 2022-06-23 21:58:59.333389
# Unit test for method title of class Text
def test_Text_title():
    t = Text()

    assert t.title() != ''

# Generated at 2022-06-23 21:59:01.674116
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=1)
    assert text.swear_word() == 'Churn'

test_Text_swear_word()

# Generated at 2022-06-23 21:59:08.442572
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    russian = RussiaSpecProvider(gender=Gender.FEMALE)

    assert russian.text.quote() == '"Чем больше тебя знают, тем ненавидят больше."'
    assert russian.text.quote() == '"Кровавые слезы, разлитые за Россию, все смыть не смогут."'

# Generated at 2022-06-23 21:59:13.877825
# Unit test for method quote of class Text
def test_Text_quote():
    # Create an instance of Text
    t = Text()
    # Get the quote
    q = t.quote()
    # Print the quote
    print(q)
    # Create an second instance of Text
    t2 = Text()
    # Get the quote again
    q2 = t2.quote()
    # Print the quote
    print(q2)
    # Check that the quotes are different
    assert q != q2



# Generated at 2022-06-23 21:59:20.451489
# Unit test for method title of class Text
def test_Text_title():
    print('Testing Text class method title ... ', end='')
    # Test 1
    text = Text(seed=0)
    str1 = text.title()
    assert str1 == 'Omnis et similique voluptatum.'
    text = Text(seed=0)
    str1 = text.title()
    assert str1 == 'Omnis et similique voluptatum.'
    # Test 2
    text = Text(seed=1)
    str2 = text.title()
    assert str2 != 'Omnis et similique voluptatum.'
    text = Text(seed=1)
    str2 = text.title()
    assert str2 != 'Omnis et similique voluptatum.'
    assert str1 != str2
    # Test 3
    text = Text(seed=0)
    str3

# Generated at 2022-06-23 21:59:23.969338
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    obj = Text('en')
    n = 1
    cnt = 0
    while (cnt < n):
        swear_word = obj.swear_word()
        print(swear_word)
        cnt += 1

if __name__ == "__main__":
    test_Text_swear_word()
    pass

# Generated at 2022-06-23 21:59:26.306206
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    data = text.level()
    assert data in ['critical', 'minor']


# Generated at 2022-06-23 21:59:27.433378
# Unit test for method text of class Text
def test_Text_text():
    pass


# Generated at 2022-06-23 21:59:31.972999
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj is not None
    assert obj.seed is not None
    assert obj._data is not None
    assert obj.locale is not None
    assert obj.random is not None
    assert obj._datafile is not None


# Generated at 2022-06-23 21:59:35.210918
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    from mimesis.builtins import England

    eng = England()
    print(eng.text.alphabet())
    print(eng.text.alphabet(lower_case=False))
    print(eng.text.alphabet(lower_case=Case.LOWER))

# Generated at 2022-06-23 21:59:37.079319
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert len(text.color()) > 0


# Generated at 2022-06-23 21:59:38.991089
# Unit test for method words of class Text
def test_Text_words():
    x = Text(seed=123)
    assert x.words() == ['science', 'network', 'god', 'octopus', 'love']


# Generated at 2022-06-23 21:59:42.951535
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Declare a instance of class Text that has method hex_color
    a = Text()
    # Call method hex_color of class Text
    hex_color = a.hex_color()
    # Check if the length of hex_color is 7
    assert len(hex_color) == 7
    # Check if hex_color is start with "#"
    assert hex_color.startswith("#")


# Generated at 2022-06-23 21:59:44.703252
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    text = Text()
    result = text.hex_color()
    assert type(result) == str
    assert len(result) == 7


# Generated at 2022-06-23 21:59:46.467731
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(1), str)


# Generated at 2022-06-23 21:59:49.738099
# Unit test for method word of class Text
def test_Text_word():
    t = Text(seed=1)
    assert t.word() == 'sky'

# Generated at 2022-06-23 21:59:59.031780
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.currency import Currency
    import random

    my_random = random.Random()
    # my_random.seed(SEED)
    text = Text(my_random)
    inter = Internet(my_random)
    person = Person(my_random)
    date = DateTime(my_random)
    currency = Currency(my_random)
    address = Address(my_random)

    i = 0
    while i < NUMBER_OF_ITERATIONS:

        male = text.random.choice([True, False])


# Generated at 2022-06-23 22:00:00.062666
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    if not text.answer():
        return False
    return True


# Generated at 2022-06-23 22:00:02.787106
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text

    t = Text('en')
    # assert t.quote() in t._data['quotes']


# Generated at 2022-06-23 22:00:05.071925
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    if isinstance(quote, str):
        assert True
    else:
        assert False

# Generated at 2022-06-23 22:00:07.378082
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words_list = text.words()
    assert len(words_list) == 5


# Generated at 2022-06-23 22:00:08.338805
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())

# Generated at 2022-06-23 22:00:10.396105
# Unit test for method quote of class Text
def test_Text_quote():
    text_ = Text(seed=42)
    assert text_.quote() == '"Bond... James Bond."'

# Generated at 2022-06-23 22:00:13.128900
# Unit test for constructor of class Text
def test_Text():
    from mimesis import Text
    t = Text('en')
    print(t.text())
    print(t.level())
    print(t.alphabet())


# Generated at 2022-06-23 22:00:14.276694
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word()

# Generated at 2022-06-23 22:00:17.172942
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.answer())
    print(t.hex_color())
    print(t.rgb_color())

test_Text()

# Generated at 2022-06-23 22:00:19.381892
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    expected = text.random.choice(text._data['color'])
    assert text.color() == expected


# Generated at 2022-06-23 22:00:21.477850
# Unit test for method quote of class Text
def test_Text_quote():
    temp = Text(seed=0)
    result = temp.quote()
    assert result == 'My name is Bond, James Bond.'



# Generated at 2022-06-23 22:00:22.750738
# Unit test for constructor of class Text
def test_Text():
    text = Text('en')
    assert text.language == 'en'

# Generated at 2022-06-23 22:00:25.209604
# Unit test for method level of class Text
def test_Text_level():
    locale = 'en'
    test_text=Text(locale)
    assert test_text.level() in ['low','medium','high','critical'], 'error in method level'


# Generated at 2022-06-23 22:00:30.574189
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    t = Text()
    assert type(t.hex_color()) is str
    assert len(t.hex_color()) is 7
    assert t.hex_color()[0] is '#'


# Generated at 2022-06-23 22:00:40.907886
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""

# Generated at 2022-06-23 22:00:49.837024
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    from mimesis.enums import ColorScheme

    text = Text('en')
    color = text.rgb_color()
    assert isinstance(color, tuple)
    for i in color:
        assert isinstance(i, int) and 0 <= i <= 255

    color = text.rgb_color(True)
    assert isinstance(color, tuple)
    for i in color:
        assert isinstance(i, int) and 0 <= i <= 255

    color = text.rgb_color(ColorScheme.SAFE)
    assert isinstance(color, tuple)
    for i in color:
        assert isinstance(i, int) and 0 <= i <= 255

# Generated at 2022-06-23 22:00:53.581809
# Unit test for method words of class Text
def test_Text_words():
    test_instance = Text()
    test_instance.reset_seed()
    assert test_instance.words() == ['science', 'network', 'god', 'octopus', 'love']

# Generated at 2022-06-23 22:00:56.258802
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    x = Text()
    a = x.alphabet()
    assert a != None
    print("The alphabet : {}".format(a))


# Generated at 2022-06-23 22:00:57.393009
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text().sentence())

# Generated at 2022-06-23 22:00:59.356413
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-23 22:01:02.000888
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in [
        'info',
        'success',
        'warning',
        'danger',
        'critical',
        'alert']

test_Text_level()


# Generated at 2022-06-23 22:01:08.804072
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    for _ in range(100):
        rgb = Text(seed=12345).rgb_color(safe=True)
        assert isinstance(rgb, tuple)
        assert len(rgb) == 3
        assert isinstance(rgb[0], int)
        assert isinstance(rgb[1], int)
        assert isinstance(rgb[2], int)
        assert rgb[0] <= 255
        assert rgb[1] <= 255
        assert rgb[2] <= 255


# Generated at 2022-06-23 22:01:10.287214
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert isinstance(text.hex_color(True), str)


# Generated at 2022-06-23 22:01:14.437744
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text of class Text.

    :return: True if test passed, False if failed.
    """
    text = Text()
    result = text.text()
    assert isinstance(result, str)



# Generated at 2022-06-23 22:01:18.201052
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alphabet = t.alphabet()
    assert isinstance(alphabet, list)

    alphabet_lowercase = t.alphabet(lower_case=True)
    assert isinstance(alphabet_lowercase, list)


# Generated at 2022-06-23 22:01:20.654961
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unittest function for Text.swear_word."""
    text = Text()
    assert isinstance(text.swear_word(), str)


# Generated at 2022-06-23 22:01:22.436246
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    result = t.title()
    print(result)

test_Text_title()

# Generated at 2022-06-23 22:01:27.897802
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text."""
    text = Text()
    assert isinstance(text.text(5), str)
    assert isinstance(text.text(5), str)
    assert isinstance(text.text(5), str)
    assert isinstance(text.text(5), str)
    assert isinstance(text.text(5), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.text(), str)
