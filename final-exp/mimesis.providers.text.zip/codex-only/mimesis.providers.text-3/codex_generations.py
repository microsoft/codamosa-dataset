

# Generated at 2022-06-23 21:51:39.226536
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.alphabet(True))
    print(text.alphabet(False))
    print(text.level())
    print(text.text(2))
    print(text.sentence())
    print(text.title())
    print(text.words(10))
    print(text.word())
    print(text.swear_word())
    print(text.quote())
    print(text.color())
    print(text.hex_color())
    print(text.hex_color(safe=True))
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    print(text.answer())

# test_Text()

# Generated at 2022-06-23 21:51:49.017219
# Unit test for constructor of class Text
def test_Text():
    # Test for constructor
    t = Text()
    assert t is not None
    assert len(t.alphabet()) == 50
    assert len(t.alphabet(lower_case=True)) == 50
    assert t.level() is not None
    assert len(t.text(quantity=1)) > 1
    assert len(t.sentence()) > 1
    assert len(t.words()) == 5
    assert len(t.words(quantity=1)) == 1
    assert len(t.word()) > 0
    assert len(t.swear_word()) > 0
    assert len(t.quote()) > 1
    assert len(t.color()) > 1
    assert len(t.answer()) > 0

# Generated at 2022-06-23 21:51:51.054545
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=42)
    expected_output = 'Blue'
    assert t.color() == expected_output


# Generated at 2022-06-23 21:51:54.607992
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    # TODO: one day
    t = Text()
    assert t.text() == 'This is a test'
    assert len(t.text(2)) == 40
    assert len(t.text(10)) == 200


# Generated at 2022-06-23 21:51:57.796567
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale

    provider = Text(locale=Locale.EN)
    word = provider.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-23 21:52:03.528406
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import DataFields

    text = Text()
    # hex color by default is random color
    print(text.hex_color())
    # hex color not by default is random color
    print(text.hex_color(safe=False))
    # hex color by default is safe Flat UI color
    print(text.hex_color(safe=True))


# Generated at 2022-06-23 21:52:10.190382
# Unit test for method sentence of class Text
def test_Text_sentence():
    from random import seed
    from mimesis.providers.text import Text
    text = Text("zh_CN", seed=123456)
    assert text.sentence() == "完全相同的表达式，解释器会根据不同的语境，给出不同的解释。"



# Generated at 2022-06-23 21:52:12.597988
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert (t.rgb_color() == (252, 85, 32))

# Generated at 2022-06-23 21:52:14.142809
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    print(text.words())


# Generated at 2022-06-23 21:52:17.892115
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # Test for method alphabet of class Text

    text = Text('en')
    result = text.alphabet()
    assert result == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    result = text.alphabet(lower_case=True)
    assert result == 'abcdefghijklmnopqrstuvwxyz'



# Generated at 2022-06-23 21:52:22.438208
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import DataField
    from mimesis.schema import Field, Schema

    text = Text('en')

    sentence = 'A {color} car drove to church.'

    schema = Schema(
        Field('color', DataField.TEXT_COLOR)
    )
    assert schema.create(text) in text._data['color']

# Generated at 2022-06-23 21:52:29.072939
# Unit test for constructor of class Text
def test_Text():
    assert len(Text().alphabet()) == 26
    assert Text().level() in ['low', 'medium', 'high', 'critical']
    assert len(Text().sentence()) == 1
    assert len(Text().words()) == 5
    assert len(Text().quote()) == 1
    assert len(Text().color()) == 1
    assert len(Text().hex_color()) == 7
    assert len(Text().rgb_color()) == 3
    assert len(Text().answer()) == 1
    
Text().test_Text()


# Generated at 2022-06-23 21:52:34.857083
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    x = Text('en')
    # Working
    for _ in range(100):
        result = x.rgb_color()
        assert len(result) == 3
        assert isinstance(result, tuple)
        assert result[0] >= 0 and result[0] <= 255
        assert result[1] >= 0 and result[1] <= 255
        assert result[2] >= 0 and result[2] <= 255


# Generated at 2022-06-23 21:52:39.670117
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Gender
    t = Text(locale='ru')
    result = t.level()
    expected = ['critical', 'low', 'high', 'normal']
    assert result in expected or result.capitalize() in expected
    assert t.level() in expected

# Generated at 2022-06-23 21:52:41.828782
# Unit test for method title of class Text
def test_Text_title():
    test_text = Text()
    test_title = test_text.title()
    assert test_title != ''


# Generated at 2022-06-23 21:52:43.537429
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)

# Generated at 2022-06-23 21:52:47.771393
# Unit test for method words of class Text
def test_Text_words():
    t = Text('en')
    mylst = t.words()
    assert (mylst != [])
    #print(mylst)


# Generated at 2022-06-23 21:52:59.739855
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ""
    assert sentence != " "
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ""
    assert sentence != " "
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ""
    assert sentence != " "
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ""
    assert sentence != " "
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ""


# Generated at 2022-06-23 21:53:02.118606
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title = t.title()
    assert title is not None
    assert title !=""


# Generated at 2022-06-23 21:53:03.502657
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    t.quote()


# Generated at 2022-06-23 21:53:07.067192
# Unit test for method level of class Text
def test_Text_level():
    print('Text: test_Text_level')
    t = Text()
    res = t.level()
    assert isinstance(res, str)
    print(f'{res} -> OK')


# Generated at 2022-06-23 21:53:08.777452
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7


# Generated at 2022-06-23 21:53:10.841607
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert isinstance(result, str)
    assert ' ' in result


# Generated at 2022-06-23 21:53:12.946643
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text.

    :return:
    """
    t = Text()
    ans = t.answer()
    print(ans)

# Generated at 2022-06-23 21:53:15.917212
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()

    print(level)


# Generated at 2022-06-23 21:53:20.369005
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    t = Text()
    assert len(t.hex_color()) == 7
    assert t.hex_color()[0] == "#"
assert test_Text_hex_color()


# Generated at 2022-06-23 21:53:21.149195
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence()

# Generated at 2022-06-23 21:53:26.295071
# Unit test for method level of class Text
def test_Text_level():
    # Test method level of class Text
    string = "Test method level of class Text"
    print(string)
    text_object = Text()
    random_level = text_object.level()
    list_of_level = ["primary", "secondary", "success", "danger",
                     "warning", "info", "light", "dark"]
    # Assert method level return value of object text_object
    assert random_level in list_of_level
    print("Test completed successfully")


# Generated at 2022-06-23 21:53:28.423136
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)
    return sentence is not None

# Generated at 2022-06-23 21:53:31.275153
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    lst = Text().alphabet(lower_case=True)
    assert len(lst) == 26
    assert isinstance(lst[0], str)


# Generated at 2022-06-23 21:53:41.155336
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.builtins import Text
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # without parameters
    assert len(Text().text(quantity=1).split()) <= 80
    assert len(Text().text(quantity=2).split()) <= 160
    assert len(Text().text(quantity=3).split()) <= 240

    # with the same quantity of sentences
    t1 = Text(seed=43)
    t2 = Text(seed=43)

    assert t1.text(quantity=1) == t2.text(quantity=1)
    assert t1.text(quantity=2) == t2.text(quantity=2)
    assert t1.text(quantity=3) == t2.text(quantity=3)

    #

# Generated at 2022-06-23 21:53:43.018024
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """ Test method Text.hex_color of class Text """
    assert len(Text().hex_color()) == 7
    assert len(Text().hex_color(safe=True)) == 7

# Generated at 2022-06-23 21:53:44.966143
# Unit test for method title of class Text
def test_Text_title():
    """test_Text_title"""
    text = Text('en')
    title = text.title()
    assert title is not None


# Generated at 2022-06-23 21:53:50.334591
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    locale = 'en'
    provider = Text(locale)
    rgb_color = provider.rgb_color()
    assert type(rgb_color) is tuple and len(rgb_color) == 3 and \
        all([isinstance(x, int) for x in rgb_color])


# Generated at 2022-06-23 21:53:52.306695
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text(locale='en')
    print(provider.answer())

# Generated at 2022-06-23 21:54:00.587675
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color."""
    from random import Random
    random = Random(123)
    text = Text(random)

    colors = text.color()
    assert colors == 'Red'
    colors = text.color()
    assert colors == 'Lime'
    colors = text.color()
    assert colors == 'Blue'
    colors = text.color()
    assert colors == 'Silver'
    colors = text.color()
    assert colors == 'Black'
    colors = text.color()
    assert colors == 'Yellow'
    colors = text.color()
    assert colors == 'Maroon'
    colors = text.color()
    assert colors == 'Olive'
    colors = text.color()
    assert colors == 'Green'
    colors = text.color()
    assert colors == 'Purple'
    colors = text

# Generated at 2022-06-23 21:54:06.467436
# Unit test for constructor of class Text
def test_Text():
    # TODO: add test
    print("testing Text class")
    print()
    t1 = Text()
    print(t1.sentence())
    print()
    for x in range(5):
        print(t1.color())
    print()
    for x in range(5):
        print(t1.quote())
    print()
    print(t1.alphabet())
    print()
    print(t1.alphabet(lower_case=True))

# Generated at 2022-06-23 21:54:08.146369
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    result = t.sentence()
    assert result

# Generated at 2022-06-23 21:54:10.140046
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())
    assert isinstance(t.answer(), str)


# Generated at 2022-06-23 21:54:12.688917
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text

    t = Text('es')
    assert type(t.word()) == str
    assert t.word().lower() in t._data['words']['normal']


# Generated at 2022-06-23 21:54:14.619574
# Unit test for method color of class Text
def test_Text_color():
    text = Text('sl')
    color = text.color()
    assert isinstance(color, str)
    assert len(color) > 0


# Generated at 2022-06-23 21:54:22.613858
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    assert x.answer() in x._data['answers']
    assert x.answer() != 'answer'
    assert x.color() in x._data['color']
    assert x.color() != 'color'
    assert x.hex_color(safe=False) != 'hex_color'
    assert x.rgb_color(safe=True) in SAFE_COLORS
    assert x.rgb_color(safe=False) != 'rgb_color'
    assert x.leve() in x._data['level']
    assert x.level() != 'level'
    assert x.quote() in x._data['quotes']
    assert x.quote() != 'quote'
    assert x.sentence() in x._data['text']
    assert x.sentence() != 'sentence'
   

# Generated at 2022-06-23 21:54:25.714699
# Unit test for method text of class Text
def test_Text_text():
    txt = Text()
    txt.clear_cache()
    assert txt.text() in ['text', 'text text', 'text text text', 'text text text text', 'text text text text text']


# Generated at 2022-06-23 21:54:29.268462
# Unit test for method level of class Text
def test_Text_level():
    from pprint import pprint
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    # Initialize class with locale
    t = Text(Locale.EN)

    for i in range(4):
        pprint(t.level())


# Generated at 2022-06-23 21:54:34.109260
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    import requests
    import json
    import os
    test_data = requests.get('https://raw.githubusercontent.com/zoujl/mimesis/master/mimesis/data/text.json').json()
    # print(test_data)
    # test_data = json.loads(a)
    # print(test_data)
    test_word = t._data['words']['normal']
    # print(test_word)
    test_word1 = t.random.choice(test_word)
    # print(test_word1)
    assert test_word1 in test_word

# Generated at 2022-06-23 21:54:38.164321
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    r = t._words(quantity=5)
    assert len(r) == 5
    assert isinstance(r, list)
    assert isinstance(r[0], str)


# Generated at 2022-06-23 21:54:40.838131
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.builtins import RussianSpecProvider

    a = Text(seed=123)
    b = RussianSpecProvider(seed=123)

    assert a.quote() == '"Bond... James Bond."'
    assert b.text.quote() == '"Зверинецкий, а зверинецкий..."'


# Generated at 2022-06-23 21:54:42.887673
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    results = get_results(Text().words)
    assert type(results) == list


# Generated at 2022-06-23 21:54:44.628927
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert isinstance(answer, str)



# Generated at 2022-06-23 21:54:46.847139
# Unit test for method level of class Text
def test_Text_level():
    data = [
        'Level'
    ]
    t = Text()
    r = t.level()
    if r not in data:
        raise AssertionError


# Generated at 2022-06-23 21:54:55.395398
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t1 = Text()
    t2 = Text()
    t3 = Text(safe=True)
    assert isinstance(t1.hex_color(), str)
    assert isinstance(t2.hex_color(), str)
    assert isinstance(t3.hex_color(), str)
    assert t1.hex_color() != t2.hex_color()
    assert t2.hex_color() != t3.hex_color()
    assert t1.hex_color() != t3.hex_color()
    print("Passed unit test for method hex_color of class Text\n")


# Generated at 2022-06-23 21:54:56.867023
# Unit test for method title of class Text
def test_Text_title():
    text = Text('en')
    result = text.title()
    print(result)



# Generated at 2022-06-23 21:54:58.513188
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    answer = t.alphabet(True)
    if isinstance(answer, list) and len(answer) == 26:
        return True

# Generated at 2022-06-23 21:55:08.470920
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    from mimesis.enums import Locale
    from mimesis.localization import DEFAULT_LOCALE

    t = Text(seed=42)
    level = t.level()
    assert level == 'critical'
    assert type(level) is str
    # test localized level
    t = Text(seed=42, locale=Locale.RU)
    levels = t.level()
    assert levels == 'критический'
    # test localized level
    t = Text(seed=42, locale=DEFAULT_LOCALE)
    levels = t.level()
    assert levels == 'critical'



# Generated at 2022-06-23 21:55:11.687410
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    t = Text(language=Language.RU)
    assert t.color() == 'Красный'

# Generated at 2022-06-23 21:55:13.558525
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() != ''

# Generated at 2022-06-23 21:55:14.705534
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    print(t.title())

# Generated at 2022-06-23 21:55:23.653104
# Unit test for method quote of class Text

# Generated at 2022-06-23 21:55:27.639245
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print('Test alphabet method of Text class')
    text = Text()
    alphabet = text.alphabet()
    print(alphabet)
    assert alphabet is not None
    assert isinstance(alphabet, list)


# Generated at 2022-06-23 21:55:32.497471
# Unit test for method color of class Text
def test_Text_color():
    text = Text()

    # Unit test for default
    color = text.color()
    assert color != None
    try:
        assert (isinstance(color, str) == True)
    except:
        print(colored("Your function didn't return a string", 'red'))

# Generated at 2022-06-23 21:55:34.705828
# Unit test for method words of class Text
def test_Text_words():
    print('Text_words:')
    text = Text()
    words = text.words(10)
    print(words)



# Generated at 2022-06-23 21:55:38.122491
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    for i in range(1, 5):
        hex_color = text.hex_color(safe=True)
        assert len(hex_color) == 7
    print("Text.hex_color is OK!")



# Generated at 2022-06-23 21:55:40.785229
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text
    text = Text()
    print(text.quote())


# Generated at 2022-06-23 21:55:42.140660
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    result = text.text()
    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-23 21:55:44.092317
# Unit test for method color of class Text
def test_Text_color():
    t = Text("en")
    print(t.color())

# Generated at 2022-06-23 21:55:55.983534
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.providers.text import Text
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    text = Text('ru')

    text.add_provider(Person(RussiaSpecProvider, 'ru'))
    text.add_provider(RussiaSpecProvider)


# Generated at 2022-06-23 21:55:58.074516
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Level
    t = Text()
    assert type(t.level()) == str
    assert t.level() in Level.__members__

# Generated at 2022-06-23 21:56:01.658075
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    text = Text(seed=12345)
    s = text.word()
    assert s == 'science'
    text = Text(seed=12345)
    s = text.word()
    assert s == 'science'


# Generated at 2022-06-23 21:56:06.125899
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed=1)
    assert t.swear_word() == 'God'
    assert t.swear_word() == 'Fuck'
    assert t.swear_word() == 'Damn'
    

# Generated at 2022-06-23 21:56:08.624571
# Unit test for method words of class Text
def test_Text_words():
    text = Text(seed=29)
    assert text.words(quantity=1) == ['octopus']
    assert text.words(quantity=2) == ['love', 'network']
    assert text.words(quantity=3) == ['god', 'science', 'science']
    assert text.words(quantity=4) == ['science', 'network', 'octopus', 'love']

# Generated at 2022-06-23 21:56:11.198188
# Unit test for method text of class Text
def test_Text_text():
    txt = Text()
    print(txt.text())
    print(txt.text(2))
    print(txt.text(3))
    print(txt.text(4))
    print(txt.text(5))


# Generated at 2022-06-23 21:56:13.555230
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    from mimesis.builtins import Text

    t = Text()
    assert t.answer()


# Generated at 2022-06-23 21:56:14.848194
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    c = t.color()
    assert (c)

# Generated at 2022-06-23 21:56:16.982064
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    assert type(txt.color()) == str
    assert len(txt.color()) > 0



# Generated at 2022-06-23 21:56:18.353255
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text('en')
    print(t.hex_color())

# Generated at 2022-06-23 21:56:20.801907
# Unit test for method rgb_color of class Text
def test_Text_rgb_color(): 
    c1 = Text.rgb_color(safe=True)
    c2 = Text.rgb_color(safe=True)
    assert(c1==c2)

# Generated at 2022-06-23 21:56:26.706622
# Unit test for method quote of class Text
def test_Text_quote():
    print(Text().quote())
    print(Text().title())
    print(Text().words())
    print(Text().word())
    print(Text().swear_word())
    print(Text().alphabet(lower_case=False))
    print(Text().level())
    print(Text().text())
    print(Text().sentence())
    print(Text().answer())
    print(Text().color())



# Generated at 2022-06-23 21:56:29.960817
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    obj = Text(seed=0)
    print(obj.swear_word())


# Generated at 2022-06-23 21:56:31.403812
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert isinstance(t.answer(), str)


# Generated at 2022-06-23 21:56:33.113519
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    for _ in range(3):
        assert text.sentence()


# Generated at 2022-06-23 21:56:35.944660
# Unit test for method color of class Text
def test_Text_color():
    import random
    x = random.randint(1, 255)
    while x == 0:
        x = random.randint(1, 255)
    print(x)
    assert x != 0


# Generated at 2022-06-23 21:56:40.138296
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locale
    import fake as f
    text_es = f.Text(locale=Locale.SPANISH)
    text_en = f.Text(locale=Locale.ENGLISH)
    assert text_es.color() in text_es.data['color']
    assert text_en.color() in text_en.data['color']

# Generated at 2022-06-23 21:56:46.130256
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text

    # create object class Text
    text = Text(gender=Gender.FEMALE)

    # create expected quote
    expected_quote = "What are you doing here?"

    # check if quote is the same
    assert text.quote() == expected_quote


# Generated at 2022-06-23 21:56:49.869199
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """
    Unit test for method alphabet of class Text

    :return: nothing
    """
    alph = Text().alphabet(lower_case=False)
    assert alph is not None and isinstance(alph, list)
    assert alph != []


# Generated at 2022-06-23 21:56:51.022517
# Unit test for constructor of class Text
def test_Text():
    # Create object
    t = Text()

    assert isinstance(t, Text)
    assert isinstance(t, BaseDataProvider)


# Generated at 2022-06-23 21:56:57.298551
# Unit test for method text of class Text
def test_Text_text():
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()

    assert text_1.text() != text_2.text()
    assert text_2.text() != text_3.text()
    assert text_3.text() != text_4.text()
    assert text_4.text() != text_5.text()


# Generated at 2022-06-23 21:57:01.518100
# Unit test for constructor of class Text
def test_Text():
    for i in range (10):
        t = Text(seed = i)
        print(t.locale)
        print(t.swear_word())
        print(t.word())
        print(t.level())
        print(t.text())
        print(t.alphabet(lower_case = True))


# Generated at 2022-06-23 21:57:04.020781
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """ Test method alphabet of class Text. """

    x = Text()
    x.alphabet()
    print("Method 'alphabet' passed unit test successfully!")


# Generated at 2022-06-23 21:57:06.692449
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text"""
    text = Text()
    wordList = text.words(10)
    assert len(wordList) == 10


# Generated at 2022-06-23 21:57:07.952547
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert isinstance(text.quote(), str)

# Generated at 2022-06-23 21:57:12.956422
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text(seed=123456789)
    for i in range(50):
        assert len(text.rgb_color()) == 3
        assert len(text.rgb_color(safe=True)) == 3
        assert type(text.rgb_color()) == tuple
        assert type(text.rgb_color(safe=True)) == tuple


# Generated at 2022-06-23 21:57:14.558772
# Unit test for method words of class Text
def test_Text_words():
    # Testing Code
    pass

# Generated at 2022-06-23 21:57:16.513703
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text(seed=123)
    assert x.swear_word() == 'Fuck'

# Generated at 2022-06-23 21:57:17.916228
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())


# Generated at 2022-06-23 21:57:20.476625
# Unit test for method level of class Text
def test_Text_level():
    from typing import c
    from mimesis.enums import Gender
    level = c.Text().level()
    print(level)
    # assert level == 'critical'

# Generated at 2022-06-23 21:57:25.004833
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=42)
    alphabet = text.alphabet()

    assert alphabet == 'BCDFGHJKLMNPQRSTVXZWY'
    assert text.alphabet(lower_case=True) == 'bcdfghjklmnpqrstvxzwy'

# Generated at 2022-06-23 21:57:26.497579
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    my_obj = Text()
    assert len(my_obj.alphabet()) > 0


# Generated at 2022-06-23 21:57:30.074891
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for RGB color."""
    text = Text()
    result = text.rgb_color()
    assert isinstance(result, tuple)
    assert len(result) == 3

# Generated at 2022-06-23 21:57:31.117679
# Unit test for method text of class Text
def test_Text_text():
    """Test Text.text method."""
    assert 'science' in Text().text()


# Generated at 2022-06-23 21:57:34.197455
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert text.alphabet(False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert text.alphabet(True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 21:57:46.136880
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Locale
    from mimesis.data import PI_NUMBERS
    from mimesis.data import SAFE_COLORS
    from mimesis.data import LETTERS
    from mimesis.data import LEVELS
    from mimesis.data import TEXT
    from mimesis.data import WORDS
    from mimesis.data import QUOTES
    from mimesis.data import COLORS
    from mimesis.data import ANSWERS

    provider = Text(seed=42)
    assert provider.seed == 42
    assert provider.__class__.__name__ == 'Text'
    assert provider.__class__.Meta.name == 'text'
    assert provider.localization == Locale.EN

    assert provider.pi == PI_NUMBERS
    assert provider.safe_

# Generated at 2022-06-23 21:57:47.893788
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    assert type(text.quote()) == str


# Generated at 2022-06-23 21:57:50.947287
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.providers.text import Text
    t = Text()
    print(t.quote())


# Generated at 2022-06-23 21:57:58.037391
# Unit test for constructor of class Text
def test_Text():
    from mimesis import __version__
    from mimesis import Text

    text = Text("nl")
    assert text
    assert __version__ == text.Meta.version
    assert isinstance(text.title(), str)
    assert isinstance(text.words(), list)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.answer(), str)
    assert isinstance(text.swear_word(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.color(), str)
    assert isinstance(text.word(), str)
    assert isinstance(text.words(), list)
    assert isinstance(text.text(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance

# Generated at 2022-06-23 21:57:58.998340
# Unit test for method answer of class Text
def test_Text_answer():
    # Call method answer of class Text
    instance = Text()
    print(instance.answer())


# Generated at 2022-06-23 21:58:02.339793
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """
    Test method .rgb_color() of class Text()
    """
    text = Text()

    rgb_tuple = text.rgb_color()
    print(rgb_tuple)

# Generated at 2022-06-23 21:58:06.099157
# Unit test for method title of class Text
def test_Text_title():
    from .test_helper import build_sample
    text_provider = Text(build_sample('en-US'))
    t = text_provider.title()
    assert type(t) == str
    assert len(t) > 0



# Generated at 2022-06-23 21:58:08.799359
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    for _ in range(100):
        test_answer = t.answer()
        assert ' ' not in test_answer
        assert type(test_answer) is str


# Generated at 2022-06-23 21:58:10.964510
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    hex_color = Text().hex_color(safe=True)
    assert type(hex_color) is str
    assert hex_color in SAFE_COLORS


# Generated at 2022-06-23 21:58:12.504282
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result == 'critical'


# Generated at 2022-06-23 21:58:15.085420
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text(seed=1234567890)
    assert txt.quote() == "It's a cookbook!"


# Generated at 2022-06-23 21:58:17.910538
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for function swear_word of class Text"""
    text = Text(seed=123)
    assert text.swear_word() == 'гавно'

# Generated at 2022-06-23 21:58:20.238116
# Unit test for method color of class Text
def test_Text_color():
    provider = Text(seed=123)

    # color() should be 'White'.
    assert provider.color() == 'White'


# Generated at 2022-06-23 21:58:22.174274
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for Text.title()."""
    assert Text().title()


# Generated at 2022-06-23 21:58:23.215750
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() is not None


# Generated at 2022-06-23 21:58:26.623703
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence != None
    assert isinstance(sentence, str)
    assert sentence != ''


# Generated at 2022-06-23 21:58:36.845296
# Unit test for method answer of class Text
def test_Text_answer():
    generator = Text()
    answer = generator.answer()
    assert isinstance(answer, str) == True
    assert len(answer) > 0
    assert answer in ["Yes", "No", "Maybe", "Of course", "Of course not", "I don’t know", "Never", "Always", "Sometimes", "Naturally", "Naturally not", "Definitely", "Impossible", "Obviously", "I hope so", "Never in your life", "Always in your life", "Maybe in your life", "I don’t believe this", "I don’t believe this", "I don’t know", "I don’t care about this", "I don’t know about this", "I don’t care", "I don’t want to say about this", "What kind of question is that?"]


# Generated at 2022-06-23 21:58:48.161735
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    r = Text(seed=1234567890)
    assert r.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
                                           'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

# Generated at 2022-06-23 21:58:50.934404
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider(gender=Gender.MALE)
    ru.text.words()

# Generated at 2022-06-23 21:58:57.366953
# Unit test for method text of class Text
def test_Text_text():
    from random import randint
    from random import seed
    seed(0)
    data = Text(seed=0)
    result = data.text()
    assert result == 'Wisdom is what is left after we have run out of'
    result = data.text(quantity=3)
    assert result == 'Wisdom is what is left after we have run out of personal opinions.'
    result = data.text()
    assert result == 'The only true wisdom is in knowing you know nothing.'


# Generated at 2022-06-23 21:59:06.448580
# Unit test for constructor of class Text
def test_Text():
    test = Text()
    print(test.alphabet())
    print(test.alphabet(lower_case=True))
    print(test.level())
    print(test.text())
    print(test.text(quantity=2))
    print(test.sentence())
    print(test.title())
    print(test.words())
    print(test.words(quantity=2))
    print(test.word())
    print(test.swear_word())
    print(test.quote())
    print(test.color())
    print(test.hex_color())
    print(test.hex_color(safe=True))
    print(test.rgb_color())
    print(test.rgb_color(safe=True))
    print(test.answer())

# Generated at 2022-06-23 21:59:08.329560
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    s = t.text()
    assert (isinstance(s, str))


# Generated at 2022-06-23 21:59:10.899946
# Unit test for method words of class Text
def test_Text_words(): 
    from mimesis.builtins import Text 
    
    d = Text()
    print(d.words())
    print(d.word())


# Generated at 2022-06-23 21:59:12.793903
# Unit test for method title of class Text
def test_Text_title():
    """This test is for method Text.title"""
    t = Text()
    assert type(t.title()) == str


# Generated at 2022-06-23 21:59:17.079002
# Unit test for method color of class Text
def test_Text_color():
    # Assert the humanized color of color
    from mimesis.enums import Color
    from mimesis.providers.text import Text
    t = Text(locale='en')
    color = t.color()
    # Check if the color is in the Color enum
    assert color in Color.names()



# Generated at 2022-06-23 21:59:18.414860
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() == 'AliceBlue'



# Generated at 2022-06-23 21:59:20.127624
# Unit test for method color of class Text
def test_Text_color():
    txt = Text('es')
    assert txt.color() in txt._data['color']


# Generated at 2022-06-23 21:59:27.089795
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test for method alphabet of class Text."""
    # Setup
    text_provider = Text('ru')
    alphabet = [
        'А', 'Б', 'В',
        'Г', 'Д', 'Е',
        'Ё', 'Ж', 'З',
        'И', 'Й', 'К',
        'Л', 'М', 'Н',
        'О', 'П', 'Р',
        'С', 'Т', 'У',
        'Ф', 'Х', 'Ц',
        'Ч', 'Ш', 'Щ',
        'Ъ', 'Ы', 'Ь',
        'Э', 'Ю', 'Я',
    ]
    # Assert
    assert text_prov

# Generated at 2022-06-23 21:59:31.390371
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert text.hex_color().startswith('#')
    assert text.hex_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-23 21:59:33.340756
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    # Get a random sentence from text
    assert len(t.sentence()) > 0


# Generated at 2022-06-23 21:59:38.085248
# Unit test for method words of class Text
def test_Text_words():
    # Init
    text = Text()

    # Get
    word1 = text.words(1)[0]
    # Normal words
    assert word1 in text._data['words']['normal']
    # Not Bad words
    assert word1 not in text._data['words']['bad']

    # Get
    word2 = text.words(1)[0]
    # Normal words
    assert word2 in text._data['words']['normal']
    # Not Bad words
    assert word2 not in text._data['words']['bad']



# Generated at 2022-06-23 21:59:39.443796
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Language
    text = Text(language=Language.EN, seed=123)
    assert text.answer() == 'No'

# Generated at 2022-06-23 21:59:44.945469
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    locale = 'en'
    t = Text(locale=locale)
    assert type(t.alphabet()) == list
    t = Text(locale=locale)
    assert type(t.alphabet(lower_case=True)) == list


# Generated at 2022-06-23 21:59:51.343216
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider

    t_ru = Text(locale=Locale.RU)
    t_en = Text(locale=Locale.EN)
    t_uk = Text(locale=Locale.UK)

    assert isinstance(RussiaSpecProvider(seed=123).swear_word(), str)
    assert isinstance(t_ru.swear_word(), str)
    assert isinstance(t_en.swear_word(), str)
    assert isinstance(t_uk.swear_word(), str)

# Generated at 2022-06-23 21:59:55.683057
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.builtins import Text

    t = Text(Locale.RU)
    res = t.swear_word()
    assert isinstance(res, str)
    assert len(res) > 0
    assert res != t.swear_word()


# Generated at 2022-06-23 21:59:58.844940
# Unit test for method quote of class Text
def test_Text_quote():
    # Instance of class Text
    t = Text()
    # Get a random quote from text.json
    s = t.quote()

    assert s is not None
    assert isinstance(s, str)
    assert len(s) > 0


# Generated at 2022-06-23 21:59:59.861992
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text("en")
    ans = text.sentence()
    print(ans)

# Generated at 2022-06-23 22:00:02.816982
# Unit test for method word of class Text
def test_Text_word():
    import random
    from mimesis.enums import Gender
    random.seed(0)
    t = Text('en')
    assert t.word() == 'science'
    assert t.word() == 'science'
    assert t.word() == 'science'
    assert t.word() == 'science'
    assert t.word() == 'science'

# Generated at 2022-06-23 22:00:07.529592
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for method rgb_color of class Text
    :return: None
    :rtype: None
    """
    text = Text()
    rgb_color = text.rgb_color()
    assert(len(rgb_color) == 3)
    for i in rgb_color:
        assert(i >= 0 and i <= 255)

# Generated at 2022-06-23 22:00:08.931152
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert text.alphabet() != None


# Generated at 2022-06-23 22:00:11.780525
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() in t._data['text']

if __name__ == '__main__':
    test_Text_text()

# Generated at 2022-06-23 22:00:14.671184
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sentence = t.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ''


# Generated at 2022-06-23 22:00:24.422295
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    print("class Text with locale=en_GB")
    print("alphabet", x.alphabet())
    print("alphabet_lower", x.alphabet(lower_case=True))
    print("level", x.level())
    print("text", x.text())
    print("sentence", x.sentence())
    print("title", x.title())
    print("words", x.words())
    print("words", x.words(quantity=20))
    print("word", x.word())
    print("swear_word", x.swear_word())
    print("quote", x.quote())
    print("color", x.color())
    print("hex_color", x.hex_color())
    print("hex_color(safe)", x.hex_color(safe=True))
   

# Generated at 2022-06-23 22:00:26.143102
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert isinstance(text.color(), str)
    assert text.color() in text._data['color']


# Generated at 2022-06-23 22:00:29.475119
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=3)
    sample = ['critical', 'normal', 'high', 'low', 'medium', 'high']
    assert text.level() in sample

# Generated at 2022-06-23 22:00:32.584096
# Unit test for constructor of class Text
def test_Text():
    _ = Text()
    assert _._datafile == 'text.json'
    assert _.Meta.name == 'text'



# Generated at 2022-06-23 22:00:34.674630
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())

if __name__ == '__main__':
    test_Text_quote()

# Generated at 2022-06-23 22:00:36.004052
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3

# Generated at 2022-06-23 22:00:44.741269
# Unit test for constructor of class Text
def test_Text():
    """Test all functions of class Text."""
    t = Text()

    alph = t.alphabet()
    assert len(alph) == 26

    s = t.level()
    assert isinstance(s, str)

    s = t.text(quantity=1)
    assert isinstance(s, str)

    s = t.title()
    assert isinstance(s, str)

    l = t.words()
    assert isinstance(l, list)

    s = t.word()
    assert isinstance(s, str)

    sw = t.swear_word()
    assert isinstance(sw, str)

    s = t.quote()
    assert isinstance(s, str)

    s = t.color()
    assert isinstance(s, str)


# Generated at 2022-06-23 22:00:46.435602
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.builtins import RussianSpecProvider

    text = Text(RussianSpecProvider)
    text.title()

# Generated at 2022-06-23 22:00:52.590556
# Unit test for method text of class Text
def test_Text_text():
    def get_text(quantity, data):
        text = ''
        for _ in range(quantity):
            text += ' ' + data.random.choice(text._data['text'])
        return text.strip()
    # Create object Text
    text = Text()
    # Variable for store real result
    true_result = get_text(5, text)
    # Testing method text
    result = text.text()
    # Condition check
    assert true_result == result


# Generated at 2022-06-23 22:00:55.914237
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    tmp = Text()
    tmp.random.seed(1)
    res = tmp.swear_word()
    assert res == "Damn"

# Generated at 2022-06-23 22:00:57.445928
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() is not None


# Generated at 2022-06-23 22:00:59.354847
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    for i in range(10):
        assert len(t.swear_word()) > 0

# Generated at 2022-06-23 22:01:00.276627
# Unit test for method sentence of class Text
def test_Text_sentence():
    return Text().sentence()


# Generated at 2022-06-23 22:01:03.677947
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locales
    from mimesis.providers.text import Text
    t = Text()
    level = t.level()
    assert level in ["critical", "error", "normal", "warning"]


# Generated at 2022-06-23 22:01:05.343636
# Unit test for method title of class Text
def test_Text_title():
  text=Text()
  print(text.title())


# Generated at 2022-06-23 22:01:07.137785
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in t._data['level']



# Generated at 2022-06-23 22:01:08.884173
# Unit test for method sentence of class Text
def test_Text_sentence():
    obj = Text(seed=123)
    assert obj.sentence() == 'Lorem ipsum dolor sit amet'


# Generated at 2022-06-23 22:01:12.746738
# Unit test for method text of class Text
def test_Text_text():
    provider = Text()
    text = provider.text(1)
    assert isinstance(text, str)
    assert len(text.split(" ")) >= 5
    assert len(text.split(" ")) <= 30


# Generated at 2022-06-23 22:01:17.131732
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() is not None
    assert t.text() != t.text()
    assert isinstance(t.text(), str)
    assert t.text(quantity=0).strip() == ''
    assert t.text(quantity=1) == t.sentence()


# Generated at 2022-06-23 22:01:19.230127
# Unit test for method color of class Text
def test_Text_color():
	data = Text()
	list = ['Orange','Violet','Black','Red','Yellow']
	assert data.color() in list


# Generated at 2022-06-23 22:01:22.998074
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Lazy, Locale
    from mimesis.providers.text import Text
    from mimesis.seed import Seed
    a=Text()
    while True:
        print(a.rgb_color())
        print(a.hex_color())

# Generated at 2022-06-23 22:01:24.103377
# Unit test for method word of class Text
def test_Text_word():
    # If a word is a string
    assert(isinstance(Text().word(), str))

# Generated at 2022-06-23 22:01:27.690889
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text(seed=123)
    assert text.rgb_color() == (228, 27, 41)
    assert text.rgb_color(safe=True) == (52, 73, 94)


# Generated at 2022-06-23 22:01:28.939850
# Unit test for method quote of class Text
def test_Text_quote():
    string = Text().quote()
    assert len(string) > 1

# Generated at 2022-06-23 22:01:30.770617
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert len(text.word()) > 1
