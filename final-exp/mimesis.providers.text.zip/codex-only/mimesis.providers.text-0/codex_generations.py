

# Generated at 2022-06-23 21:51:38.178877
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person

    text_provider = Text()
    person_provider = Person(gender=Gender.MALE)
    BaseProvider.register(Person, person_provider)

    result = text_provider.sentence()
    assert isinstance(result, str)
    result = text_provider.sentence(placeholder_types={'<first_name>': 'person.first_name'})
    assert isinstance(result, str)
    assert ('<first_name>' in result) or ('<firstname>' in result)
    assert ('<last_name>' in result) or ('<lastname>' in result)

# Generated at 2022-06-23 21:51:39.135975
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    pass


# Generated at 2022-06-23 21:51:41.037773
# Unit test for constructor of class Text
def test_Text():
    # Create a instance of class Text
    t = Text()
    assert t is not None
    assert isinstance(t, Text)


# Generated at 2022-06-23 21:51:44.515120
# Unit test for method level of class Text
def test_Text_level():
    from mimesis import Text
    txt = Text('en')
    assert txt.level() in txt._data['level']



# Generated at 2022-06-23 21:51:47.076431
# Unit test for method word of class Text
def test_Text_word():
    # GIVEN
    mytext = Text('en')

    # WHEN
    a = mytext.word()

    # THEN
    assert len(a) > 0



# Generated at 2022-06-23 21:51:48.067902
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    text.quote()

# Generated at 2022-06-23 21:51:49.803205
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    result = text.quote()
    assert(result)


# Generated at 2022-06-23 21:51:54.439236
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from pprint import pprint
    from mimesis.providers.text import Text
    t = Text()
    for i in range(10):
        #print(t.rgb_color(safe=False))
        pprint(t.rgb_color(safe=True))

if __name__ == '__main__':
    test_Text_rgb_color()

# Generated at 2022-06-23 21:51:58.006906
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    from mimesis.providers.text import Text
    from mimesis.enums import Languages
    import random
    t = Text(random.choice([lang.name for lang in Languages]))
    t.answer()


# Generated at 2022-06-23 21:52:00.878689
# Unit test for constructor of class Text
def test_Text():
	# Create an instance of class Text
	data = Text(seed=42)
	# Check that the attribute `data` is not `None`
	assert data is not None

# Generated at 2022-06-23 21:52:02.974871
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    result = t.quote()
    assert result.values()


# Generated at 2022-06-23 21:52:14.697234
# Unit test for method word of class Text
def test_Text_word():
    # run the test in order to generate correct answer
    # check Text.word()'s answer with the pre-generated answer
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    test_text = Text()
    test_answer = 'Test'
    assert test_text.word() in test_answer
    assert test_text.word(gender=Gender.MALE) in test_answer
    assert test_text.word(gender=Gender.FEMALE) in test_answer
    assert test_text.word(gender=Gender.NEUTRAL) in test_answer
    assert test_text.word(gender=Gender.MALE.value) in test_answer
    assert test_text.word(gender=Gender.FEMALE.value) in test_answer

# Generated at 2022-06-23 21:52:18.653752
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    text = Text()
    assert len(text.title()) != 0


# Generated at 2022-06-23 21:52:20.044823
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert type(text.swear_word()) == str
    assert len(text.swear_word()) > 0
    

# Generated at 2022-06-23 21:52:21.716860
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    expected_result = "#b74572"
    for i in range(len(expected_result)):
        assert expected_result[i] == t.hex_color()[i]

# Generated at 2022-06-23 21:52:23.524767
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Generate a hex color"""
    from mimesis.enums import Color

    provider = Text(seed=48699)
    for color in Color:
        print(provider.hex_color(safe=color.value))


# Generated at 2022-06-23 21:52:28.304696
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale
    txt = Text(Locale.EN)
    assert txt.text() == "Science is the century-old endeavor to bring together by means of systematic thought the perceptible phenomena of this world into as thorough-going an association as possible. To put it boldly, it is the attempt at the posterior reconstruction of existence by the process of conceptualization."

# Generated at 2022-06-23 21:52:29.782944
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert isinstance(t.color(), str)

# Generated at 2022-06-23 21:52:30.897898
# Unit test for method color of class Text
def test_Text_color():
    generator = Text()
    color = generator.color()
    assert color != ""

# Generated at 2022-06-23 21:52:32.689082
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    result = t.swear_word()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:52:34.226288
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(), str)

# Generated at 2022-06-23 21:52:40.240421
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locales
    from mimesis.providers.text import Text
    from mimesis.types import Seed
    t = Text(seed=Seed(123))
    s = t.word()

    assert s != t.word()
    assert t.word() != t.word()
    assert t.word() != t.word()


# Generated at 2022-06-23 21:52:41.953330
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    print(title)


# Generated at 2022-06-23 21:52:43.537229
# Unit test for method quote of class Text
def test_Text_quote():
    obj = Text()
    obj.quote()


# Generated at 2022-06-23 21:52:49.396899
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert 'swear_word' in dir(Text)
    assert callable(Text.swear_word)
    assert isinstance(Text.swear_word, types.MethodType)
    assert isinstance(Text().swear_word(), str)
    assert bool(Text().swear_word())


# Generated at 2022-06-23 21:52:51.414641
# Unit test for method sentence of class Text
def test_Text_sentence():
    for i in range(10):
        print(Text().sentence())



# Generated at 2022-06-23 21:52:57.583464
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    # print(t.alphabet())
    print(t.level())
    print(t.text())
    print(t.words())
    print(t.swear_word())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())

#test_Text()

# Generated at 2022-06-23 21:53:01.438525
# Unit test for method words of class Text
def test_Text_words():
    text=Text()
    word=text.words()
    assert isinstance(word,list)
    assert len(word)==5
    assert isinstance(word[0],str)
    assert len(word[0])>0

# Generated at 2022-06-23 21:53:04.353848
# Unit test for method quote of class Text
def test_Text_quote():
    import random
    t = Text(random.Random())
    print(t.quote())
    print(t.quote())

# Generated at 2022-06-23 21:53:12.561238
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text(seed=123)
    res = t.alphabet()
    assert res == ['А', 'Б', 'В', 'Г', 'Ґ',
                   'Д', 'Е', 'Є', 'Ж', 'З',
                   'И', 'І', 'Ї', 'Й', 'К',
                   'Л', 'М', 'Н', 'О', 'П',
                   'Р', 'С', 'Т', 'У', 'Ф',
                   'Х', 'Ц', 'Ч', 'Ш', 'Щ',
                   'Ю', 'Я']



# Generated at 2022-06-23 21:53:15.808956
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    text.hex_color()
    text.hex_color(safe=True)

# Generated at 2022-06-23 21:53:16.678039
# Unit test for method color of class Text
def test_Text_color():
	pass

# Generated at 2022-06-23 21:53:19.383600
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(*data["locales"])
    assert text.answer() in data["text"]["answers"]


# Generated at 2022-06-23 21:53:21.111468
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    print(word)



# Generated at 2022-06-23 21:53:24.624480
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # This method doesn't take a random seed, so we just test that it
    # determines a hex string.
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7 and any(c in "0123456789ABCDEF" for c in hex_color[1:])

# Generated at 2022-06-23 21:53:27.142771
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sen = t.sentence()
    assert(isinstance(sen,str))
    assert(len(sen.split(" ")) >= 5)

# Generated at 2022-06-23 21:53:29.800707
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert isinstance(t.quote(), str)

# Generated at 2022-06-23 21:53:39.612387
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    t = Text()
    human = Person('en')
    address = Address('en')

    for _ in range(10):
        sentence = t.sentence()
        assert sentence == t.sentence()

        assert sentence.startswith('Lorem') or sentence.startswith('Ipsum')
        assert sentence.endswith('.')

        assert t.sentence() != t.text()

        assert t.sentence() == t.title()

        assert t.sentence() != human.full_name(gender=Gender.FEMALE)

        assert t.sentence() != address.address()


# Generated at 2022-06-23 21:53:41.035136
# Unit test for method title of class Text
def test_Text_title():
    text = Text('en')
    title = text.title()
    assert title == 'You can do it.'



# Generated at 2022-06-23 21:53:43.298042
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    print(text.level())

# Generated at 2022-06-23 21:53:47.572978
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text.

    GIVEN to the method an instance of the class Text
    WHEN the method quote is called
    THEN the function will return a string
    """
    data = Text("en")
    assert isinstance(data.quote(), str)

# Generated at 2022-06-23 21:53:49.718866
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text().hex_color()
    assert len(color) > 0, "Invalid format of color"


# Generated at 2022-06-23 21:53:52.251304
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    color = t.hex_color()
    assert(len(color) == 7)
    assert(color[0] == '#')
    assert(color[1:].isalnum())

    color = t.hex_color(safe=True)
    assert(color in SAFE_COLORS)
    
test_Text_hex_color()

# Generated at 2022-06-23 21:53:53.440721
# Unit test for method title of class Text
def test_Text_title():
    abc = Text()
    print(abc.title())

# Generated at 2022-06-23 21:53:55.983859
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(locale='en')
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-23 21:53:57.431330
# Unit test for method answer of class Text
def test_Text_answer():
    t1 = Text()
    assert  t1.answer() in ['Yes', 'No', 'Maybe']


# Generated at 2022-06-23 21:54:00.590421
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    color = t.rgb_color()
    assert isinstance(color, tuple)
    assert len(color) == 3
    assert 0 <= color[0] <= 255
    assert 0 <= color[1] <= 255
    assert 0 <= color[2] <= 255
    print(color)

# Generated at 2022-06-23 21:54:02.361725
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert len(text.sentence()) > 0

# Generated at 2022-06-23 21:54:04.079180
# Unit test for method text of class Text
def test_Text_text():
    text_provider = Text()
    result = text_provider.text()
    assert result



# Generated at 2022-06-23 21:54:07.071148
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Language
    from mimesis.localization import English
    from mimesis.text import Text
    text = Text(language=Language.EN, localization=English())
    result = text.word()
    assert result == 'science'

# Generated at 2022-06-23 21:54:10.886341
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear = text.swear_word()
    assert swear in ['блядь', 'блядть', 'одна жопа', 'гавно']


# Generated at 2022-06-23 21:54:12.689203
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    text = Text()
    answer = text.title()
    assert isinstance(answer, str)


# Generated at 2022-06-23 21:54:14.484168
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    t = text.sentence()
    assert isinstance(t, str)


# Generated at 2022-06-23 21:54:16.425315
# Unit test for method words of class Text
def test_Text_words():
    assert len(Text.words()) == 5
    assert len(Text.words(quantity=7)) == 7


# Generated at 2022-06-23 21:54:18.438708
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level_list = ['low', 'moderate', 'high', 'critical']
    level = text.level()
    assert level in level_list


# Generated at 2022-06-23 21:54:20.011439
# Unit test for method title of class Text
def test_Text_title():
    text = Text(locale="en")
    print(text.title())
    print(text.title())


# Generated at 2022-06-23 21:54:21.753776
# Unit test for method title of class Text
def test_Text_title():
    text = Text("en")
    text.title()

# Generated at 2022-06-23 21:54:22.986341
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())

# Generated at 2022-06-23 21:54:25.282020
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.providers.text import Text
    text = Text()
    assert (len(text.word()) > 1)


# Generated at 2022-06-23 21:54:27.313057
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(locale='en')
    value = text.quote()
    assert value != ""
    assert type(value) == str

# Generated at 2022-06-23 21:54:28.648061
# Unit test for method words of class Text
def test_Text_words():
    t = Text(seed=0)
    assert t.words() == ['race', 'garden', 'index', 'virus',
                         'egg']

# Generated at 2022-06-23 21:54:29.387273
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote()


# Generated at 2022-06-23 21:54:31.139800
# Unit test for method quote of class Text
def test_Text_quote():
    cls=Text()
    result=cls.quote()
    print(result)


if __name__ == "__main__":
    test_Text_quote()

# Generated at 2022-06-23 21:54:32.087296
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text()
    result = provider.quote()
    assert result is not None

# Generated at 2022-06-23 21:54:42.320016
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Class Text unit test method 'rgb_color'."""
    t = Text(seed=12345)
    g = Text(seed=12345)
    assert t.rgb_color() == g.rgb_color()
    assert t.rgb_color() == (58, 164, 201)
    assert t.rgb_color(safe=True) == g.rgb_color(safe=True)
    assert t.rgb_color(safe=True) == (210, 48, 210)
    assert t.rgb_color(safe=False) == g.rgb_color(safe=False)
    assert t.rgb_color(safe=False) == (58, 164, 201)

# Generated at 2022-06-23 21:54:45.758651
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # import mimesis
    # t = mimesis.Text('es')
    text = Text('es')
    assert text.swear_word() == 'Mierda'
    assert text.swear_word() == 'Puto'



# Generated at 2022-06-23 21:54:46.980031
# Unit test for method word of class Text
def test_Text_word():
    print(Text.word())


# Generated at 2022-06-23 21:54:48.307037
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert isinstance(color, str) and len(color) > 0

# Generated at 2022-06-23 21:54:49.352240
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    result = text.sentence()
    assert result

# Generated at 2022-06-23 21:54:59.427200
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.hex_color())
    print(t.hex_color())
    print(t.hex_color())
    print(t.hex_color())
    print(t.word())
    print(t.word())
    print(t.word())
    print(t.word())
    print(t.word())
    print(t.word())
    print(t.title())
    print(t.title())
    print(t.title())
    print(t.title())
    print(t.title())
    print(t.title())
    print(t.alphabet())
    print(t.alphabet())
    print(t.alphabet())
    print(t.alphabet())
    print(t.answer())
    print(t.answer())

# Generated at 2022-06-23 21:55:06.540561
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    from mimesis.enums import Gender
    from mimesis.localization import FR
    from mimesis.providers.text.en import Text as EnText

    t = Text('en')
    et = EnText(gender=Gender.MALE)
    assert t.quote() == et.quote()
    assert t.quote() != Text('fr', seed=42).quote()
    assert t.quote() != Text(FR, seed=42).quote()


# Generated at 2022-06-23 21:55:13.189187
# Unit test for method title of class Text
def test_Text_title():
    # lang: en
    t = Text(locale='en')
    assert isinstance(t.title(), str)
    # lang: ru
    t = Text(locale='ru')
    assert isinstance(t.title(), str)
    # lang: uk
    t = Text(locale='uk')
    assert isinstance(t.title(), str)
    # lang: etc
    t = Text(locale=None)
    assert isinstance(t.title(), str)


# Generated at 2022-06-23 21:55:17.024328
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color(safe=False)
    assert type(rgb) is tuple
    assert len(rgb) == 3
    for i in rgb:
        assert type(i) is int
        assert 0 <= i <= 255

# Generated at 2022-06-23 21:55:18.040372
# Unit test for method color of class Text
def test_Text_color():

    t = Text()
    print(t.color())

# Generated at 2022-06-23 21:55:19.377864
# Unit test for method answer of class Text
def test_Text_answer():
    p = Text()

    assert isinstance(p.answer(), str)



# Generated at 2022-06-23 21:55:22.699401
# Unit test for method quote of class Text
def test_Text_quote():
    """
    Testing method quote of class Text to check whether it's working fine or not
    """
    from mimesis.enums import Gender
    from mimesis import Text, Person

    text = Text()
    person = Person(Gender.MALE, text.locale)
    # print(text.quote())
    assert isinstance(text.quote(), str)
    assert text.quote() != None
    assert len(text.quote()) != 0
    assert text.quote() != person.quote()


# Generated at 2022-06-23 21:55:25.442919
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    provider = Text()
    result = provider.alphabet()
    assert len(result) == 27, "The length of the alphabet is not 27"



# Generated at 2022-06-23 21:55:28.610310
# Unit test for method text of class Text
def test_Text_text():
    data = Text()
    test = data.text()
    assert len(str(test)) > 5

# Generated at 2022-06-23 21:55:30.655405
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alphabet = t.alphabet()
    assert t != alphabet



# Generated at 2022-06-23 21:55:34.220745
# Unit test for constructor of class Text
def test_Text():

    locale = 'foo'
    seed = 'bar'
    t = Text(locale, seed)
    assert t._datafile =='text.json'
    assert t.locale == locale
    assert t.seed == seed



# Generated at 2022-06-23 21:55:35.277498
# Unit test for method level of class Text
def test_Text_level():
      print(Text().level())



# Generated at 2022-06-23 21:55:37.509863
# Unit test for method color of class Text
def test_Text_color():
    # Create an instance of Text
    t = Text()
    # Use method color
    s = t.color()
    assert type(s) == str

# Generated at 2022-06-23 21:55:40.660954
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    output = text.title()
    assert output == 'Not another cereal killer'


# Generated at 2022-06-23 21:55:45.081093
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """ Test if method hex_color returns valid hex color. """
    text = Text()

    hex_color = text.hex_color()
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color.startswith('#')

# Generated at 2022-06-23 21:55:48.498967
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-23 21:55:50.381129
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    r = Text()
    r.rgb_color(safe=True)

test_Text_rgb_color()

# Generated at 2022-06-23 21:55:52.502353
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    test = t.level()
    assert test != None


# Generated at 2022-06-23 21:55:55.041523
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale

    test_obj = Text(locale=Locale.EN)
    data = test_obj.level()

    assert data



# Generated at 2022-06-23 21:55:56.815159
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert type(t.swear_word()) == str


# Generated at 2022-06-23 21:55:58.231453
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert isinstance(text.sentence,str)

# Generated at 2022-06-23 21:56:02.832386
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import Color
    from mimesis.builtins import Text
    t = Text()
    color = t.rgb_color(safe=False)
    assert isinstance(color, tuple)
    for item in color:
        assert isinstance(item, int)
        assert 0 <= item < 256
    safe_color = t.rgb_color(safe=True)
    assert safe_color in Color.SAFE_RGB_COLORS
test_Text_rgb_color()


# Generated at 2022-06-23 21:56:05.559439
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider(gender = Gender.MALE)
    print(rsp.text.words())

# Generated at 2022-06-23 21:56:07.593444
# Unit test for method sentence of class Text
def test_Text_sentence():
    text1 = Text()
    result = text1.sentence()
    print(result)


# Generated at 2022-06-23 21:56:09.949389
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert isinstance(text.provider, Text)


# Generated at 2022-06-23 21:56:11.075278
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert len(t.swear_word()) > 0

# Generated at 2022-06-23 21:56:12.669048
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    r = t.rgb_color()
    assert len(r) == 3

# Generated at 2022-06-23 21:56:21.016376
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert (text.alphabet(), [])
    assert (text.alphabet(lower_case=True), [])
    assert (text.level(), '')
    assert (text.text(), '')
    assert (text.sentence(), '')
    assert (text.title(), '')
    assert (text.words(), [])
    assert (text.word(), '')
    assert (text.swear_word(), '')
    assert (text.quote(), '')
    assert (text.color(), '')
    assert (text.hex_color(), '')
    assert (text.rgb_color(), (None, None, None))
    assert (text.answer(), '')

# Generated at 2022-06-23 21:56:23.189073
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text
    text = Text()
    words = text.words()
    assert words



# Generated at 2022-06-23 21:56:24.276331
# Unit test for method words of class Text
def test_Text_words():
    assert Text().words() != None



# Generated at 2022-06-23 21:56:25.591890
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert len(t.quote()) > 0


# Generated at 2022-06-23 21:56:28.202160
# Unit test for method level of class Text
def test_Text_level():
    # GIVEN
    t = Text()
    # WHEN
    level = t.level()
    # THEN
    assert isinstance(level, str)
    assert level


# Generated at 2022-06-23 21:56:31.267762
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    global text
    text = Text('en')
    assert 0 <= text.random.randint(0x000000, 0xffffff) <= 0xffffff


# Generated at 2022-06-23 21:56:35.580197
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in [
        'Yes', 'No', 'Maybe', 'Probably', 'Yep', 'Nope', 'I *think* so',
        'Not sure', 'I hope so', 'I hope not', 'Always', 'Never',
        'I am not sure', 'I don\'t know'
    ]


# Generated at 2022-06-23 21:56:36.989383
# Unit test for method answer of class Text
def test_Text_answer():
    print("\n# Unit test method Text.answer()")
    text = Text()
    print("answer: ", text.answer())


# Generated at 2022-06-23 21:56:39.898913
# Unit test for method words of class Text
def test_Text_words():
	
	# generate a list of words
	list_of_words = Text().words(quantity=2)

	# print list_of_words
	print(list_of_words)


# Generated at 2022-06-23 21:56:41.877790
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:56:51.750750
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.alphabet(lower_case=False))
    print(text.alphabet(lower_case=True))
    print(text.level())
    print(text.text(quantity=5))
    print(text.sentence())
    print(text.title())
    print(text.words(quantity=5))
    print(text.word())
    print(text.swear_word())
    print(text.quote())
    print(text.color())
    print(text.hex_color())
    print(text.hex_color(safe=True))
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    print(text.answer())


# Generated at 2022-06-23 21:56:55.598587
# Unit test for method quote of class Text
def test_Text_quote():
    # Set a seed for repeatable results
    # Set a seed for repeatable results
    t = Text(seed = 1)

    # Get a random quote
    assert t.quote() == "You took the words right out of my mouth."


# Generated at 2022-06-23 21:56:57.345908
# Unit test for method words of class Text
def test_Text_words():
    t = Text(0)
    result = t.words(5)

    assert len(result) == 5

# Generated at 2022-06-23 21:56:58.311633
# Unit test for constructor of class Text
def test_Text():
    text = Text()



# Generated at 2022-06-23 21:57:01.433163
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    for i in range(100):
        quote = t.quote()
        assert isinstance(quote, str)
        assert quote.startswith('"')
        assert quote.endswith('"')


# Generated at 2022-06-23 21:57:03.536614
# Unit test for method word of class Text
def test_Text_word():
    """
    Unit test for method word of class Text
    """
    text = Text()
    single_word = text.word()
    print(single_word)

# Generated at 2022-06-23 21:57:05.005442
# Unit test for constructor of class Text
def test_Text():
    result = Text()
    assert result.__class__.__name__ == 'Text'

# Generated at 2022-06-23 21:57:06.357209
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    print(text.level())

# Generated at 2022-06-23 21:57:07.953007
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text
    a = Text('en')
    assert isinstance(a.quote(), str)

# Generated at 2022-06-23 21:57:12.956460
# Unit test for method answer of class Text
def test_Text_answer():
    print("Testing method answer of class Text")
    from mimesis.builtins import Text
    text = Text()
    answers_list = ['No', 'Yes', 'Maybe', 'It is hard to answer', 'Of course']
    for i in range(100):
        assert(text.answer() in answers_list)
test_Text_answer()


# Generated at 2022-06-23 21:57:17.157623
# Unit test for method quote of class Text
def test_Text_quote():
    import pytest
    t = Text()
    assert isinstance(t.quote(), str), "Invalid return value"
    assert t.quote() in t._data['quotes'], "Quote not in quotes"
#

# Generated at 2022-06-23 21:57:18.514124
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)

# Generated at 2022-06-23 21:57:24.338205
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import Text
    from mimesis.enums import Safe
    from pprint import pprint

    t = Text()
    len(t.rgb_color()) == 3
    len(t.rgb_color(safe=True)) == 3
    pprint(t.rgb_color())
    pprint(t.rgb_color(safe=True))


# Generated at 2022-06-23 21:57:27.121837
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    for i in range(5):
        word = text.word()
        assert isinstance(word, str) == True
        assert len(word) != 0

# Generated at 2022-06-23 21:57:29.294277
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    # Test 1
    assert len(t.rgb_color()) == 3


# Generated at 2022-06-23 21:57:31.196309
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    data = text.level()
    print(data)


# Generated at 2022-06-23 21:57:33.643107
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    result = text.answer()
    assert result

# Generated at 2022-06-23 21:57:37.650348
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    import ipdb; ipdb.set_trace()
    answer = txt.answer()
    print(answer)

if __name__ == '__main__':
    # test_Text()
    pass

# Generated at 2022-06-23 21:57:40.022291
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """
    Unit test for method swear_word of class Text.
    """
    text = Text()
    print(text.swear_word())

# Generated at 2022-06-23 21:57:42.057722
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    result = text.word()
    assert result
    assert isinstance(result, str)


# Generated at 2022-06-23 21:57:44.483552
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color())
    print(t.hex_color(safe=True))


# Generated at 2022-06-23 21:57:47.385286
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locale
    t = Text(locale=Locale.EN)
    text = t.sentence()
    print(text)


# Generated at 2022-06-23 21:57:49.936111
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    this_test=Text()
    hex_color_test=this_test.hex_color()
    assert len(hex_color_test)==7

# Generated at 2022-06-23 21:57:52.655244
# Unit test for method level of class Text
def test_Text_level():
    # Get the value for level method of class Text
    result = Text.Meta.level()
    assert result != None


# Generated at 2022-06-23 21:57:55.550449
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    words = t.words(quantity=5)
    word = t.word()
    assert len(words) >=5 and isinstance(words, list)
    assert type(word) == str
    print(words, word)


# Generated at 2022-06-23 21:57:57.753858
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    t.seed(1)
    assert t.level() == "critical"

# Generated at 2022-06-23 21:58:02.706564
# Unit test for method words of class Text
def test_Text_words():
    """Test words."""
    text = Text()
    assert len(text.words(quantity=0)) == 0
    assert len(text.words(quantity=5)) == 5
    assert len(text.words(quantity=10)) == 10
    assert len(text.words(quantity=-1)) == 5



# Generated at 2022-06-23 21:58:05.778202
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    s = t.hex_color(safe=True)
    ss = t.hex_color(safe=False)
    print(s)
    print(ss)


# Generated at 2022-06-23 21:58:09.199714
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    for _ in range(150):
        assert len(text.hex_color()) == 7
        assert text.hex_color().startswith('#')
        assert int(text.hex_color()[1:], 16) <= 0xffffff

# Generated at 2022-06-23 21:58:10.024589
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence()

# Generated at 2022-06-23 21:58:13.897802
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for method rgb_color of class Text."""
    from mimesis.enums import Color as ColorEnum
    t = Text('en')
    t.seed(210)
    assert (t.rgb_color() == (252, 85, 32))
    a=t.rgb_color(safe=True)
    assert a in ColorEnum.FLAT_UI_COLORS


# Generated at 2022-06-23 21:58:15.868765
# Unit test for method text of class Text
def test_Text_text():
    """Test method text of class Text."""
    # TODO: add unit tests
    pass

# Generated at 2022-06-23 21:58:20.045501
# Unit test for constructor of class Text
def test_Text():
    import time
    import numpy as np
    from mimesis.enums import Gender
    t = Text(seed=time.time())
    assert  t.random.randint(0,1000) == t.random.randint(0,1000)


# Generated at 2022-06-23 21:58:23.507044
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from .text import Text # import class
    # init class
    t = Text()
    # run method
    result = t.rgb_color(safe = True)
    print(result) # print result
test_Text_rgb_color()

# Generated at 2022-06-23 21:58:29.961470
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3 and t.rgb_color()[0] >= 0 and t.rgb_color()[0] <= 255 and t.rgb_color()[1] >= 0 \
           and t.rgb_color()[1] <= 255 and t.rgb_color()[2] >= 0 and t.rgb_color()[2] <= 255

# Generated at 2022-06-23 21:58:32.523745
# Unit test for method answer of class Text
def test_Text_answer():
    txt = Text()
    random_answer = txt.answer()
    return random_answer in ['Yes', 'No', 'Maybe', 'Nope']

# Generated at 2022-06-23 21:58:36.630557
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert len(text.alphabet()) == 26
    assert text.level() == "danger"
    assert text.text(1) is not ""
    assert text.sentence() is not ""
    assert text.title() is not ""
    assert len(text.words()) == 5
    assert text.word() is not ""
    assert text.swear_word() is not ""
    assert text.quote() is not ""
    assert text.color() is not ""
    assert text.hex_color() is not ""
    assert text.rgb_color() is not ""
    assert text.answer() is not ""

# Generated at 2022-06-23 21:58:39.001068
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(locale='en')
    result = text.swear_word()

    assert isinstance(result, str)
    # assert result in text.words().get('bad')

# Generated at 2022-06-23 21:58:41.891114
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    print(text.hex_color())
    print(text.hex_color(safe=True))

if __name__ == "__main__":
    test_Text_hex_color()

# Generated at 2022-06-23 21:58:45.755042
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    txt = Text()
    res = txt.text()
    assert(isinstance(res, str))
    

# Generated at 2022-06-23 21:58:46.853734
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert "This is a sentence" == Text.sentence()

# Generated at 2022-06-23 21:58:55.469328
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Locale
    from mimesis.builtins import Text
    t = Text(Locale.EN)
    n = t.answer()
    assert n in ["Yes", "No", "Maybe", "Probably", "Certainly not",
                 "Absolutely", "Certainly", "Not at all", "Probably not",
                 "I doubt it", "I hope so", "I hope not", "Never", "Possibly",
                 "Impossible", "In your dreams!", "I don't think so",
                 "It cannot be", "Not likely", "Unlikely", "Unlikely",
                 "Unlikely", "Unlikely", "Unlikely"]


# Generated at 2022-06-23 21:58:58.286465
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    mt = Text()
    a = mt.alphabet()
    assert isinstance(a, list)


# Generated at 2022-06-23 21:58:59.958753
# Unit test for method words of class Text
def test_Text_words():
  Text().words(quantity=5) == ['science', 'network', 'god', 'octopus', 'love']

# Generated at 2022-06-23 21:59:03.330428
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test of method hex_color of class Text.
    """
    text = Text()
    result = text.hex_color()
    print('hex_color() =', result)
    assert isinstance(result, str)
    assert len(result) == 7
    assert result.startswith('#')
    assert all(char in '0123456789abcdef' for char in result[1:])


# Generated at 2022-06-23 21:59:04.529834
# Unit test for method sentence of class Text
def test_Text_sentence():
    result = Text().sentence()
    print(result)


# Generated at 2022-06-23 21:59:06.230440
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result in ['low', 'normal', 'high', 'critical']


# Generated at 2022-06-23 21:59:08.582468
# Unit test for method text of class Text
def test_Text_text():
    print("Unit test for method text of class Text")
    result = Text().text()
    print("result: ", result)
    assert Text().text() != ''

# Generated at 2022-06-23 21:59:11.161552
# Unit test for method word of class Text
def test_Text_word():
    print(Text().word())
    print(Text().word())
    print(Text().word())
    print(Text().word())
    print(Text().word())


# Generated at 2022-06-23 21:59:12.714716
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    text.color()


# Generated at 2022-06-23 21:59:14.100795
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test Text.sentence."""
    assert Text().sentence()

# Generated at 2022-06-23 21:59:19.870551
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    a = Text
    dict = {}
    for i in range(1000):
        temp = a().hex_color()
        if temp not in dict:
            dict[temp] = 1
        else:
            dict[temp] += 1
    total = 0
    for _, v in dict.items():
        total += v
    if total == 1000:
        print(True)
        return True
    else:
        print(False)
        return False


# Generated at 2022-06-23 21:59:24.877481
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    seed(1)
    text = Text()
    swear_word = text.swear_word()

# Generated at 2022-06-23 21:59:26.774376
# Unit test for method quote of class Text
def test_Text_quote():
    # TODO: Add unit test for method quote of class Text
    pass

# Generated at 2022-06-23 21:59:30.394096
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    result = text.color()
    print(result)
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:59:33.099674
# Unit test for method quote of class Text
def test_Text_quote():
    t1 = Text()
    t2 = Text()
    q1 = t1.quote()
    q2 = t2.quote()
    assert (q1 != q2)


# Generated at 2022-06-23 21:59:35.278555
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    result = text.words(quantity=5)
    assert isinstance(result, list)
    assert result == ['love', 'offense', 'god', 'fox', 'coffee']

# Generated at 2022-06-23 21:59:37.858831
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answers = ['Yes', 'No', 'Maybe']
    answer = text.answer()
    assert answer in answers

# Generated at 2022-06-23 21:59:39.391474
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import Text as T
    assert type(T.sentence()) == str


# Generated at 2022-06-23 21:59:43.252715
# Unit test for constructor of class Text
def test_Text():
    t = Text(seed=123)
    assert t.hex_color() == '#8130d6'
    assert t.level() == 'warning'
    assert t.rgb_color() == (129,48,214)

# Generated at 2022-06-23 21:59:43.897343
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    print(text.words())

# Generated at 2022-06-23 21:59:44.971327
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:59:45.795391
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(), str)

# Generated at 2022-06-23 21:59:48.299397
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) == 2
    assert isinstance(text.answer(), str)

# Generated at 2022-06-23 21:59:49.546048
# Unit test for method word of class Text
def test_Text_word():
    provider = Text()
    print(provider.word())



# Generated at 2022-06-23 21:59:50.932824
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    print(text.answer())


# Generated at 2022-06-23 21:59:56.727558
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Create a Text object and test method rgb_color."""
    from mimesis.enums import Color
    from mimesis.typing import Union

    text_g = Text('en')
    text_g.seed(3)
    result = text_g.rgb_color()
    assert isinstance(result, tuple)
    assert len(result) == 3
    for item in result:
        assert isinstance(item, int)
        assert item < 256



# Generated at 2022-06-23 21:59:58.641047
# Unit test for method level of class Text
def test_Text_level():
    print("\nTesting Text_level()...\n")
    for _ in range (5):
        print("Generating level of danger...", Text().level())

# Generated at 2022-06-23 21:59:59.929281
# Unit test for method words of class Text
def test_Text_words():
    import random
    import attribute_generator

    random.seed(10)
    attribute_generator.text.words()

# Generated at 2022-06-23 22:00:00.988425
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert isinstance(t.rgb_color(), tuple)

# Generated at 2022-06-23 22:00:06.728073
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    obj = Text()
    rgb_color = obj.rgb_color()
    print(rgb_color)
    rgb_color = obj.rgb_color(safe=True)
    print(rgb_color)

if __name__ == "__main__":
    test_Text_rgb_color()

# Generated at 2022-06-23 22:00:12.489244
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""

    from mimesis.enums import InputData
    from mimesis.providers.text import Text

    t = Text('en')

    for color in SAFE_COLORS:
        assert color == t.hex_color(True)

    for _ in range(1000):
        assert t.hex_color(False) in InputData.HEX_COLOR.value

# Generated at 2022-06-23 22:00:13.524621
# Unit test for method words of class Text
def test_Text_words():
    pass


# Generated at 2022-06-23 22:00:15.157492
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    print(t.level())


# Generated at 2022-06-23 22:00:24.801475
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender

# Generated at 2022-06-23 22:00:30.125973
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    a = t.rgb_color(safe=True)
    print('rgb_color(safe=True)=', a)
    a = t.rgb_color(safe=False)
    print('rgb_color(safe=False)=', a)

# Generated at 2022-06-23 22:00:33.283541
# Unit test for method quote of class Text
def test_Text_quote():
    """This function will test the method quote() for class Text."""
    tp = Text()
    quote = tp.quote()
    print(quote)
    assert quote != None

# Generated at 2022-06-23 22:00:35.362275
# Unit test for method answer of class Text
def test_Text_answer():
    """Test answer of Text class."""
    text = Text()
    assert text.answer() in ["yes", "no"]



# Generated at 2022-06-23 22:00:37.088070
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    # Assert that type is str
    assert isinstance(text.word(), str)


# Generated at 2022-06-23 22:00:39.109982
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    quote = t.quote()

    assert(len(quote) > 0)
    assert(quote != "")
    assert(quote != " ")
    assert(quote != None)


# Generated at 2022-06-23 22:00:42.963399
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert '#' in text.hex_color()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=False)) == 7
    assert text.hex_color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 22:00:45.655820
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    assert Text().alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 22:00:47.372882
# Unit test for method level of class Text
def test_Text_level():
    from pprint import pprint

    t = Text(seed=1)
    pprint(t.level())

# Generated at 2022-06-23 22:00:48.722819
# Unit test for method words of class Text
def test_Text_words():
    text_provider = Text()
    print(text_provider.words())

# Generated at 2022-06-23 22:00:50.336253
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print("Text.word() : ", text.word())


# Generated at 2022-06-23 22:01:01.748120
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    out_puts = []
    for _ in range(10):
        out_puts.append(t.text())

# Generated at 2022-06-23 22:01:03.021279
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() != Text().sentence()

# Generated at 2022-06-23 22:01:05.113478
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert t.words(quantity=2) != t.words(quantity=2)

# Generated at 2022-06-23 22:01:09.009660
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorMode
    t = Text('en')
    ex1 = t.rgb_color()
    assert len(ex1) == 3
    ex2 = t.rgb_color(safe=ColorMode.SAFE)
    assert ex2 in SAFE_COLORS

# Generated at 2022-06-23 22:01:11.973356
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    ru = RussiaSpecProvider(gender=Gender.FEMALE)
    # Providers have not the same data
    assert ru.text.color() != ru.text.color()

# Generated at 2022-06-23 22:01:22.065725
# Unit test for constructor of class Text
def test_Text():
    text = Text()

    assert isinstance(text, Text)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.color(), str)
    assert isinstance(text.level(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.word(), str)
    assert isinstance(text.word(), str)
    assert isinstance(text.words(), list)
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.text(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.title(), str)
    assert isinstance(text.answer(), str)


if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-23 22:01:23.710640
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    swear_word = text.swear_word()

    print(swear_word)
    # assert(swear_word == [])


# Generated at 2022-06-23 22:01:26.263043
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer == '2' or answer == 'Yes'

# Generated at 2022-06-23 22:01:29.276185
# Unit test for method answer of class Text
def test_Text_answer():
    test_1 = Text()
    test_2 = Text()
    test_1.seed(1)
    test_2.seed(1)
    assert test_1.answer() == test_2.answer()
    