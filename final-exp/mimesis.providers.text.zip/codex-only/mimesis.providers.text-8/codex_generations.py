

# Generated at 2022-06-23 21:51:31.580823
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    assert Text().answer() in Text()._data['answers']


# Generated at 2022-06-23 21:51:33.686116
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis import Text
    text = Text('en')
    a = text.rgb_color()
    assert a == (239, 125, 30)

# Generated at 2022-06-23 21:51:34.691547
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None

# Generated at 2022-06-23 21:51:36.221327
# Unit test for method word of class Text
def test_Text_word():
    type = Text(seed = 1)
    assert type.word() == "science"

# Generated at 2022-06-23 21:51:38.039319
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    assert type(text.swear_word()) == str

# Generated at 2022-06-23 21:51:39.692718
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:51:41.258354
# Unit test for method alphabet of class Text
def test_Text_alphabet():

    assert Text().alphabet()
    assert Text().alphabet(lower_case=True)


# Generated at 2022-06-23 21:51:44.839865
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())
    print(type(t.rgb_color()))


# Generated at 2022-06-23 21:51:53.748194
# Unit test for method level of class Text
def test_Text_level():
    from mimesis import Text
    import pandas as pd
    import numpy as np
    text=Text('ru')
    text_1=[]
    for i in range(100):
        text_1.append(text.level())
    df_1=pd.DataFrame(text_1)
    df_2=df_1[0].value_counts()
    df_3=df_2.sort_values().reset_index()
    df_3.columns=['level','count']
    df_3['prcnt']=np.round((df_3['count']/sum(df_3['count'])*100).astype(np.dtype(float)),2)
    print(df_3)
    

# Generated at 2022-06-23 21:51:54.630585
# Unit test for method level of class Text
def test_Text_level():
    Text.level()


# Generated at 2022-06-23 21:51:55.992817
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert len(t.word()) >= 1


# Generated at 2022-06-23 21:51:57.332474
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text("zh")
    print(t.alphabet(True))

# Generated at 2022-06-23 21:51:59.936304
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    text_gen = Text()

    assert text_gen.level() == 'critical'

# Generated at 2022-06-23 21:52:02.834448
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_alphabet = Text(locale='en')
    random_alphabet = text_alphabet.alphabet()
    # print(random_alphabet)


# Generated at 2022-06-23 21:52:07.288989
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    from mimesis.enums import Language
    from mimesis.localization import _
    text = Text(Language.EN)
    for _ in range(10):
        print(text.sentence())


# Generated at 2022-06-23 21:52:17.461833
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text"""
    text = Text()
    colors = []
    # Generate 100 colors
    for _ in range(100):
        colors.append(text.hex_color())
    # Check colors

# Generated at 2022-06-23 21:52:18.556724
# Unit test for method level of class Text
def test_Text_level():
    text_lvl = Text().level()
    assert len(text_lvl) > 3


# Generated at 2022-06-23 21:52:20.342631
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:52:21.163729
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert text.rgb_color()


# Generated at 2022-06-23 21:52:23.316647
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    if t.quote() == None:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:52:30.463481
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Test 1:
    #   safe -> True
    #   expected -> safe hex color
    safe_color = Text(seed=12345).hex_color(safe=True)
    safe_color_expected = '#468966'
    assert safe_color == safe_color_expected

    # Test 2:
    #   safe -> False
    #   expected -> ANY hex color
    any_color = Text(seed=12345).hex_color(safe=False)
    any_color_expected = '#6b4040'
    assert any_color == any_color_expected



# Generated at 2022-06-23 21:52:33.625079
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locale

    t = Text(locale=Locale.EN)
    sentence = t.sentence()
    #print(sentence)
    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:52:36.585177
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert len(text.word()) > 0
    assert type(text.word()) is str
    

# Generated at 2022-06-23 21:52:45.377640
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    locale = 'en'
    seed = 0
    text = Text(locale, seed)
    assert 0 <= text.alphabet().index('A') < 26
    assert 0 <= text.alphabet().index('B') < 26
    assert 0 <= text.alphabet().index('C') < 26
    assert 0 <= text.alphabet().index('D') < 26
    assert 0 <= text.alphabet().index('E') < 26
    assert 0 <= text.alphabet().index('F') < 26
    assert 0 <= text.alphabet().index('G') < 26
    assert 0 <= text.alphabet().index('H') < 26
    assert 0 <= text.alphabet().index('I') < 26
    assert 0 <= text.alphabet().index('J') < 26
    assert 0 <= text.alphabet().index('K') < 26


# Generated at 2022-06-23 21:52:46.373938
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in ['critical', 'low', 'medium', 'high']

# Generated at 2022-06-23 21:52:48.910582
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import Text
    text = Text()
    sentence = text.sentence()
    assert sentence is not None


# Generated at 2022-06-23 21:52:52.472250
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    print(swear_word)

if __name__ == '__main__':
    test_Text_swear_word()

# Generated at 2022-06-23 21:52:55.402432
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale

    t = Text(locale=Locale.EN)
    assert len(t.level()) == 7

# Generated at 2022-06-23 21:53:00.856511
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.enums import Gender
    from mimesis.providers.text import Text

    t = Text(locale=Locale.EN)
    t._data['words']['bad'] = ["Devil's"]
    assert t.swear_word() == "Devil's"

# Generated at 2022-06-23 21:53:02.371572
# Unit test for method title of class Text
def test_Text_title():
    pt = Text(locale='pt-br')
    assert pt.title()

# Generated at 2022-06-23 21:53:12.447285
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    # Case.MIXED
    assert Text('en').alphabet(lower_case=False) == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                                                     'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    # Case.UPPER

# Generated at 2022-06-23 21:53:16.351193
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    g = Text(seed=12345)
    assert g.rgb_color() == (130, 99, 136)


# Generated at 2022-06-23 21:53:17.914795
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text."""
    pass



# Generated at 2022-06-23 21:53:20.090197
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test Text.answer."""
    text = Text()
    assert isinstance(text.answer(), str)

# Generated at 2022-06-23 21:53:25.654956
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    result = text.rgb_color()
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert isinstance(result[0], int)
    assert isinstance(result[1], int)
    assert isinstance(result[2], int)
    assert result[0] >= 0
    assert result[1] >= 0
    assert result[2] >= 0
    assert result[0] <= 255
    assert result[1] <= 255
    assert result[2] <= 255


# Generated at 2022-06-23 21:53:27.049762
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text()
    temp = x.swear_word()

# Generated at 2022-06-23 21:53:28.724629
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() != ''
    assert t.text(1) != ''


# Generated at 2022-06-23 21:53:30.450685
# Unit test for method sentence of class Text
def test_Text_sentence():
    test = Text()
    print(test.sentence())


# Generated at 2022-06-23 21:53:33.282407
# Unit test for method color of class Text
def test_Text_color():
    for i in range(1):
        t = Text()
        col = t.color()
    return col



# Generated at 2022-06-23 21:53:34.340757
# Unit test for method text of class Text
def test_Text_text():
    assert len(Text().text()) > 0

# Generated at 2022-06-23 21:53:36.799443
# Unit test for method color of class Text
def test_Text_color():

    Example = Text()

    list_colors = ["Blue", "Red"]

    assert Example.color() == "Blue" or Example.color() == "Red"


# Generated at 2022-06-23 21:53:38.132015
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert 'text' == text.word()


# Generated at 2022-06-23 21:53:39.404678
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() is not None

# Generated at 2022-06-23 21:53:40.747408
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    print("hex_color = " + hex_color)


# Generated at 2022-06-23 21:53:43.559698
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import Color
    t = Text()
    print(t.rgb_color(safe=True))
    print(t.rgb_color(safe=False))
    print(t.rgb_color(safe=Color.SAFE))
    print(t.rgb_color(safe=Color.NOT_SAFE))


# Generated at 2022-06-23 21:53:53.586552
# Unit test for method word of class Text
def test_Text_word():
    import pytest
    from mimesis.enums import Locale

    lang = Locale.EN

    @pytest.mark.parametrize('seed', range(0, 10))
    def test_with_explicit_seed(seed):
        text = Text(lang, seed)
        result = text.word()
        assert isinstance(result, str)

    @pytest.mark.parametrize('seed', range(0, 10))
    def test_with_random_seed(seed):
        text = Text(lang)
        result = text.word()
        assert isinstance(result, str)


# Generated at 2022-06-23 21:53:55.392042
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    y = x.text()
    assert type(y) == str




# Generated at 2022-06-23 21:53:59.302914
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=123)
    assert t.rgb_color() == (56, 61, 31)
    assert t.rgb_color() == (61, 59, 46)
    assert t.rgb_color(safe = True) == (39, 174, 96)


# Generated at 2022-06-23 21:54:02.078542
# Unit test for method word of class Text
def test_Text_word():
    t = Text(10)
    w = t.word()
    assert w in t._data['words']['normal']

# Generated at 2022-06-23 21:54:03.513339
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() is not None

# Generated at 2022-06-23 21:54:04.308276
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() == 'Hello world!'

# Generated at 2022-06-23 21:54:11.096615
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.text() != ''
    assert t.title() != ''
    assert t.words() != []
    assert t.word() != ''
    assert t.swear_word() != ''
    assert t.hex_color() != ''
    assert t.rgb_color() != ()
    assert t.color() != ''

# Generated at 2022-06-23 21:54:12.953017
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    provider = Text()
    assert not ' ' in provider.sentence()

# Generated at 2022-06-23 21:54:14.783003
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() == 'Damn'


# Generated at 2022-06-23 21:54:15.648459
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t


# Generated at 2022-06-23 21:54:16.550707
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    t.answer()

# Generated at 2022-06-23 21:54:18.497135
# Unit test for method hex_color of class Text
def test_Text_hex_color():
  text_obj = Text()
  assert len(text_obj.hex_color()) == 7
  assert text_obj.hex_color()[0] == "#"

# Generated at 2022-06-23 21:54:24.409244
# Unit test for method quote of class Text
def test_Text_quote():
    s = Text(seed=1)
    assert s.quote() == "Никто не знает что такое боль до тех пор, пока не становится родителем"


# Generated at 2022-06-23 21:54:27.224217
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    l = t.level()
    if l in t._data['level']:
        print('ok')
    else:
        print('not ok')


# Generated at 2022-06-23 21:54:30.761348
# Unit test for method words of class Text
def test_Text_words():
    print("--- Unit test for method words of class Text ---")
    text_obj = Text()
    assert type(text_obj.words()) is list
    assert len(text_obj.words()) == 5
    assert text_obj.words(quantity=2) == text_obj.words(2)
    print("OK")



# Generated at 2022-06-23 21:54:35.660074
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    text = Text('ru')
    text.words(5)

    text2 = Text('en')
    text2.words(5)


# Generated at 2022-06-23 21:54:38.597996
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-23 21:54:39.885161
# Unit test for method level of class Text
def test_Text_level():
    text = Text('en')
    assert isinstance(text.level(), str)
    assert text.level() in text._data['level']

# Generated at 2022-06-23 21:54:40.996362
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t=Text()
    t.rgb_color()

# Generated at 2022-06-23 21:54:43.903770
# Unit test for method color of class Text
def test_Text_color():
    # obj = Text()
    # result = obj.color()
    # print(result)
    # assert result
    pass

if __name__ == "__main__":
    test_Text_color()

# Generated at 2022-06-23 21:54:45.084230
# Unit test for method level of class Text
def test_Text_level():
    x = Text('en')
    print(x.level())



# Generated at 2022-06-23 21:54:46.281873
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())



# Generated at 2022-06-23 21:54:48.085562
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(seed=10)
    result = text.sentence()
    assert(result=='Provides data related to text.')

# Generated at 2022-06-23 21:54:51.611032
# Unit test for method title of class Text
def test_Text_title():
    locale = 'ru'
    t = Text(locale)
    #print(t.title())
    assert isinstance(t.title(), str)


# Generated at 2022-06-23 21:54:53.684892
# Unit test for method text of class Text
def test_Text_text():
    # Setup
    text = Text()
    # Exercise
    # Verify
    assert len(text.text()) > 0


# Generated at 2022-06-23 21:54:54.586201
# Unit test for method answer of class Text
def test_Text_answer():
    """Test method answer of class Text."""
    text = Text()
    assert text.answer() in text._data['answers']

# Generated at 2022-06-23 21:54:56.422372
# Unit test for constructor of class Text
def test_Text():
   t = Text()
   assert t.__class__.__name__ == 'Text'
   assert isinstance(t, Text)


# Generated at 2022-06-23 21:54:57.709537
# Unit test for method swear_word of class Text
def test_Text_swear_word():
  print(Text().swear_word())


# Generated at 2022-06-23 21:55:00.195148
# Unit test for method text of class Text
def test_Text_text():
    """Test method text of class Text."""
    import doctest

    doctest.testmod(extraglobs={'text': Text()})

# Generated at 2022-06-23 21:55:03.067944
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(seed=1234567)
    ans = text.sentence()
    print('Testing method sentence of class Text: ', ans)


# Generated at 2022-06-23 21:55:05.763728
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test that method 'alphabet' in class Text must return the list
    of letters of the alphabet
    """
    assert isinstance(Text().alphabet(), list)

# Generated at 2022-06-23 21:55:08.278294
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() == (225, 236, 81)

# Generated at 2022-06-23 21:55:11.530008
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Initializes a new instance of the class Text.
    text = Text()

    # Gets a random sentence.
    sentence = text.sentence()

    # Assert isinstance sentence of str
    assert isinstance(sentence, str)



# Generated at 2022-06-23 21:55:15.482185
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    for i in range(10):
        color = t.hex_color()
        # print(color)

        safe = t.hex_color(safe=True)
        # print(safe)


# Generated at 2022-06-23 21:55:21.362767
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.random.rand("\d{4}-\d{4}-\d{4}-\d{4}"))
    print(text.random.rand("\d{4}-\d{4}-\d{4}-\d{4}"))
    print(text.random.rand("\d{4}-\d{4}-\d{4}-\d{4}"))
    print(text.random.rand("\d{4}-\d{4}-\d{4}-\d{4}"))
    print(text.random.rand("\d{4}-\d{4}-\d{4}-\d{4}"))

# Generated at 2022-06-23 21:55:32.704215
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'] == t.alphabet(lower_case = True)
    assert ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'] == t.alphabet()


# Generated at 2022-06-23 21:55:34.168419
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    text.level()


# Generated at 2022-06-23 21:55:37.333535
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    result = t.text(quantity=1)
    assert(result in t._data['text'])
    result = t.text()
    assert(result)


# Generated at 2022-06-23 21:55:39.487855
# Unit test for method answer of class Text
def test_Text_answer():
    p = Text()
    answer = p.answer()
    assert type(answer) == str
    assert answer in p._data['answers']


# Generated at 2022-06-23 21:55:41.400171
# Unit test for method title of class Text
def test_Text_title():
    value = Text().title()
    assert value.isalpha()


# Generated at 2022-06-23 21:55:44.138613
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    sentence = txt.sentence()
    text = txt.text()

    assert sentence in text

# Generated at 2022-06-23 21:55:49.503727
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    result = Text(locale='en').alphabet()
    assert result is not None
    assert type(result) == list
    result = Text(locale='ru').alphabet()
    assert result is not None
    assert type(result) == list



# Generated at 2022-06-23 21:55:51.512746
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert len(t.title()) > 0
    assert isinstance(t.title(), str)

# Generated at 2022-06-23 21:55:55.565724
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    print(a.words(5))
    print(a.word())
    print(a.quote())
    print(a.color())
    print(a.hex_color())
    print(a.rgb_color())
    print(a.answer())

# Generated at 2022-06-23 21:55:56.178867
# Unit test for method color of class Text
def test_Text_color():
    print(Text.color())


# Generated at 2022-06-23 21:56:00.360746
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    data = t.level()
    assert data in [
        'minor',
        'major',
        'critical',
        'normal',
        'high',
        'middle',
        'low',
        'maximum',
        'minimum',
        'severe',
        ]


# Generated at 2022-06-23 21:56:01.787563
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    color = txt.color()
    print(color)

# Generated at 2022-06-23 21:56:04.424170
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in t._data['level']


# Generated at 2022-06-23 21:56:06.457615
# Unit test for method level of class Text
def test_Text_level():
    print('method level...')
    t = Text()
    assert t.level() == 'critical'


# Generated at 2022-06-23 21:56:07.591903
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() != ""


# Generated at 2022-06-23 21:56:09.948214
# Unit test for method title of class Text
def test_Text_title():
    provider = Text()
    result = provider.title()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:56:11.930564
# Unit test for method color of class Text
def test_Text_color():
    tx = Text()
    assert tx.color() in tx._data['color']


# Generated at 2022-06-23 21:56:13.561249
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert type(text.alphabet(lower_case=True)) == list



# Generated at 2022-06-23 21:56:15.304423
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    t.title()
    assert t.seed is not None



# Generated at 2022-06-23 21:56:17.079464
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())
    print(text.quote())


# Generated at 2022-06-23 21:56:18.820040
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    random = Random()
    text = Text(random)
    # print(text.rgb_color())



# Generated at 2022-06-23 21:56:24.852504
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    from mimesis import Text
    t = Text()
    actual = t.alphabet()
    assert actual == [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
        'W', 'X', 'Y', 'Z'
    ]



# Generated at 2022-06-23 21:56:26.854253
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    res = t.title()
    print(res)


# Generated at 2022-06-23 21:56:35.683802
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я']


# Generated at 2022-06-23 21:56:37.886488
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale

    t = Text(Locale.VIETNAMESE)
    assert len(t.level()) != 0
    

# Generated at 2022-06-23 21:56:39.694336
# Unit test for method level of class Text
def test_Text_level():
    tl = Text()
    assert isinstance(tl.level(), str)


# Generated at 2022-06-23 21:56:42.571056
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test Text.sentence

    :return:
    """
    result = Text().sentence()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:56:46.230103
# Unit test for method color of class Text
def test_Text_color():
    assert Text().color() in ["Red", "Blue", "Green", "Yellow", "White", "Black", "Orange", "Purple", "Pink", "Brown", "Grey", "Cyan", "Violet"]


# Generated at 2022-06-23 21:56:48.136447
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    w = Text()
    r = w.swear_word()
    assert r != ""


# Generated at 2022-06-23 21:56:51.659422
# Unit test for method quote of class Text
def test_Text_quote():
    class Text(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._datafile = 'text.json'
            self._pull(self._datafile)

    assert len(Text().quote()) > 0


# Generated at 2022-06-23 21:56:56.216852
# Unit test for method color of class Text
def test_Text_color():
    from mimesis import Text
    from pytest import raises
    from mimesis.enums import Locale

    with raises(ValueError):
        Text(Locale.EN).color('white')
    assert Text(Locale.EN).color(True) == '#636c72'



# Generated at 2022-06-23 21:56:59.826715
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text.list_of('color')
    assert len(color) > 0


# Generated at 2022-06-23 21:57:01.245289
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    print(title)

# Generated at 2022-06-23 21:57:05.028313
# Unit test for method text of class Text
def test_Text_text():
    print('Run unit test of "text" method in class "Text"')
    text = Text()
    print("One random sentence: ")
    print(text.text())
    print("5 random sentences: ")
    print(text.text(5))


# Generated at 2022-06-23 21:57:06.775679
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)


# Generated at 2022-06-23 21:57:08.031789
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    for _ in range(5):
        print(Text().swear_word())

# Generated at 2022-06-23 21:57:09.698677
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    txt = Text()
    result = txt.hex_color()
    assert result is not None


# Generated at 2022-06-23 21:57:12.058745
# Unit test for method word of class Text
def test_Text_word():
    d = Text()
    print("The word '{}' is generated by method word of class Text.".format(d.word()))

# Generated at 2022-06-23 21:57:23.621712
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    import json
    import os
    import unittest

    data = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                     'data/'))
    file_path = os.path.join(data, 'text.json')
    file_path = os.path.normpath(file_path)

    class TestText(unittest.TestCase):
        def setUp(self) -> None:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)

            self.txt = Text(Locale.EN)

        def test_level(self):
            result = self.txt.level

# Generated at 2022-06-23 21:57:25.781285
# Unit test for method word of class Text
def test_Text_word():
    """
    Test for the method word of class Text.
    """
    result = Text().word()
    assert result in Text()._data['words'].get('normal'), "Can't get a random word"


# Generated at 2022-06-23 21:57:29.134435
# Unit test for method level of class Text
def test_Text_level():
    level = Text().level()
    assert level in ['critical', 'danger', 'warning', 'notice', 'info']


# Generated at 2022-06-23 21:57:31.057671
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote() == 'Life is like a box of chocolates.'


# Generated at 2022-06-23 21:57:34.680737
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    for i in range(0,10):
        color = text.color()
        assert(color is not None)
        assert(isinstance(color, str))


# Generated at 2022-06-23 21:57:36.330578
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert isinstance(t.color(), str)


# Generated at 2022-06-23 21:57:39.373018
# Unit test for method level of class Text
def test_Text_level():
    # case 1
    result = Text(seed=1).level()
    assert  isinstance(result, str)
    assert  result == 'critical'


# Generated at 2022-06-23 21:57:41.779518
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    t = Text()
    assert type(t.word()) is str


# Generated at 2022-06-23 21:57:44.295679
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(), str)
    assert len(t.text(0)) == 0



# Generated at 2022-06-23 21:57:46.613511
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert len(text.title()) == 5 # output should be one word, 5 letters long

# Generated at 2022-06-23 21:57:52.291524
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=123)
    assert t.rgb_color() == (114, 86, 148)
    assert t.rgb_color() == (36, 109, 8)
    assert t.rgb_color(safe=True) == (230, 90, 103)
    assert t.rgb_color(safe=True) == (255, 92, 95)

# Generated at 2022-06-23 21:57:53.855733
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    print(text.hex_color())
    print(text.hex_color(safe=True))

# Generated at 2022-06-23 21:57:57.136035
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t=Text()
    assert t.swear_word() in ['Damn','Crap','Shit']


# Generated at 2022-06-23 21:57:59.040673
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert a.seed is not None
    assert a.locale is not None

# Generated at 2022-06-23 21:58:02.340039
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text"""
    from mimesis import Text
    t = Text()
    data = t.word()
    assert not data.isnumeric()


# Generated at 2022-06-23 21:58:04.673205
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert isinstance(color, str)
    assert color in t._data['color']

# Generated at 2022-06-23 21:58:07.580654
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    a = t.alphabet(lower_case = True)
    print(a)
    print(type(a))
    print(len(a))


# Generated at 2022-06-23 21:58:10.863941
# Unit test for method title of class Text
def test_Text_title():
    # Arrange
    locale = 'en'
    text = Text(locale=locale)
    # Act
    result = text.title()
    # Assert
    assert isinstance(result, str) == True
    assert len(result.split()) > 0


# Generated at 2022-06-23 21:58:12.707433
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text("en")
    s = t.sentence()
    print(s)
    assert type(s) == str


# Generated at 2022-06-23 21:58:23.593471
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alpha = t.alphabet()
    assert alpha == [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
        'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
    ]
    alpha = t.alphabet(lower_case=True)

# Generated at 2022-06-23 21:58:26.721758
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_japanese = Text('ja')
    text_russian = Text('ru')
    text_japanese.sentence()
    text_russian.sentence()

# Generated at 2022-06-23 21:58:36.919108
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    r = RussianSpecProvider()
    assert isinstance(r.text.sentence(), str)
    assert len(r.text.sentence()) > 0
    p = Person('ru')
    a = Address('ru')
    i = Internet('ru')
    assert r.text.sentence().startswith(r.text.words(quantity=1)[0])
    assert r.text.sentence().endswith(r.text.word())
    assert r.text.sentence().count(' ') > 1

# Generated at 2022-06-23 21:58:48.265172
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    # Генератор нам возвращает color в формате RGB, проверим что он возвращает именно 3 цифры типа int в одном кортеже
    color = text.rgb_color()
    assert isinstance(color, tuple) and len(color) == 3 and all(isinstance(item, int) for item in color)
    # Генератор при saf=True возвращает цвет

# Generated at 2022-06-23 21:58:49.327595
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print(Text().swear_word())

# Generated at 2022-06-23 21:58:52.454416
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    sentence = provider.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert sentence != ''


# Generated at 2022-06-23 21:58:54.277243
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    w = t.word()
    assert w in t._data['words']['normal']

# Generated at 2022-06-23 21:58:56.265102
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    for i in range(10):
        print(Text.rgb_color(False))
test_Text_rgb_color()

# Generated at 2022-06-23 21:58:58.382821
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text('it')
    print(t.answer())



# Generated at 2022-06-23 21:59:07.194544
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
    'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 
    'X', 'Y', 'Z']
    assert Text().alphabet(True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 
    'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
    'w', 'x', 'y', 'z']


# Generated at 2022-06-23 21:59:16.558921
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis import __version__
    from mimesis.providers.text import Text
    from mimesis.builtins import RussiaSpecProvider
    provider = Text()
    russian_provider = Text(localizer=RussiaSpecProvider)

    assert (provider.alphabet()) == ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')

# Generated at 2022-06-23 21:59:19.041869
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text()
    assert type(text.text()) is str
    assert text.text(quantity=1)


# Generated at 2022-06-23 21:59:21.430094
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    test_hex_list = []
    for i in range(100):
        a = Text()
        b = a.hex_color()
        # print(b)
        test_hex_list.append(b)
    return test_hex_list

# Generated at 2022-06-23 21:59:22.826231
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=5)
    print(words)


# Generated at 2022-06-23 21:59:32.300992
# Unit test for method answer of class Text
def test_Text_answer():
    # Initialize the class and define the attributes
    text = Text('en')
    text.current_locale = 'en'
    data = {
        'answers': [
            'No', 'Yes', 'Maybe', 'You never know', 'Fuck yeah!',
            'Good luck with that', 'Try again', 'It\'s a trap'
        ]
    }
    text.settings = data
    text.random = MagicMock(return_value="No")
    # Call the method and test the result
    assert text.answer() == "No"


# Generated at 2022-06-23 21:59:41.021256
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text(seed=123456789)
    alphabet = t.alphabet()
    assert alphabet == 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    t.set_locale('en')
    alphabet = t.alphabet(True)
    assert alphabet == 'abcdefghijklmnopqrstuvwxyz'
    alphabet = t.alphabet(False)
    assert alphabet == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-23 21:59:43.208385
# Unit test for method word of class Text
def test_Text_word():
    assert len(Text('hu').word()) > 0



# Generated at 2022-06-23 21:59:45.324054
# Unit test for method text of class Text
def test_Text_text():
    obj = Text()
    obj.text()


# Generated at 2022-06-23 21:59:46.699904
# Unit test for method sentence of class Text
def test_Text_sentence():
    word = Text().sentence()
    assert word
    assert isinstance(word, str)

# Generated at 2022-06-23 21:59:48.665722
# Unit test for method words of class Text
def test_Text_words():
    for i in range(1, 2):
        t = Text()
        assert len(t.words(i)) == i


# Generated at 2022-06-23 21:59:50.884840
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert type(result) == str



# Generated at 2022-06-23 21:59:54.038391
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """ Unit Testing for rgb_color method"""
    from mimesis.builtins import Text
    random_object = Text('en')
    test1 = random_object.rgb_color()
    print(type(test1))
    print(test1)

# Generated at 2022-06-23 21:59:55.772498
# Unit test for method title of class Text
def test_Text_title():
    """Method that test method title of class Text."""
    txt = Text()
    assert len(txt.title()) != 0

# Generated at 2022-06-23 21:59:57.077329
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print("Color: ", t.color())


# Generated at 2022-06-23 21:59:59.885457
# Unit test for method title of class Text
def test_Text_title():
    # Initialise the class
    text = Text()
    
    # Generate random title
    t = text.title()
    
    # Assert that t is a string
    assert type(t) == str



# Generated at 2022-06-23 22:00:02.145866
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.builtins import Text
    from mimesis.enums import Locale

    en = Text()
    ru = Text(Locale.RU)

    assert len(en.title()) > 0
    assert len(ru.title()) > 0

# Generated at 2022-06-23 22:00:06.628953
# Unit test for method quote of class Text
def test_Text_quote():
    class type_class(object):
        text = Text
    text = type_class.text
    def in_text(x):
        t = text.quote(text)
        if x in t:
            return True
        else:
            return False
    assert in_text('Bye')


# Generated at 2022-06-23 22:00:11.830120
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    print(alpha)
    assert alpha == 'abcdefghijklmnopqrstuvwxyz'

    alpha = text.alphabet(lower_case=True)
    print(alpha)
    assert alpha == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 22:00:13.787292
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert text.provider == 'text'

# Generated at 2022-06-23 22:00:15.750597
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in ['easy', 'normal', 'hard', 'critical']

# Generated at 2022-06-23 22:00:16.924731
# Unit test for method quote of class Text
def test_Text_quote():   
    assert Text().quote() is not None 


# Generated at 2022-06-23 22:00:19.117172
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    seed = 0
    text = Text(seed=seed)
    s = text.swear_word()
    assert s == 'foda'

# Generated at 2022-06-23 22:00:21.592513
# Unit test for method color of class Text
def test_Text_color():
    # t = Text(seed=456)
    s = Text()
    print(s.color())
    print(s.color())
    print(s.color())


# Generated at 2022-06-23 22:00:23.330731
# Unit test for method level of class Text
def test_Text_level():
    color = Text()
    result = color.level()
    assert result in color._data['level']

# Generated at 2022-06-23 22:00:24.571521
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote != None


# Generated at 2022-06-23 22:00:27.151712
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-23 22:00:31.387023
# Unit test for method word of class Text
def test_Text_word():
    print("test Text_word")
    text_word = Text()
    print(text_word.word())
    print(text_word.word())
    print(text_word.word())


# Generated at 2022-06-23 22:00:33.889966
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Initialize the test Object
    TextTestClass = Text()
    Text_result = TextTestClass.sentence()
    assert type(Text_result)==str


# Generated at 2022-06-23 22:00:35.957882
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in ['critical', 'high', 'low', 'medium']


# Generated at 2022-06-23 22:00:39.422726
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method Text.hex_color."""
    from mimesis.providers.text import Text
    t = Text()
    color = t.hex_color()
    assert isinstance(color, str)
    assert len(color) == 7

# Generated at 2022-06-23 22:00:41.786126
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    ans = t.answer()
    assert ans in t._data['answers']


# Generated at 2022-06-23 22:00:43.776157
# Unit test for method title of class Text
def test_Text_title():
  text = Text()
  title = text.title()
  print(title)


# Generated at 2022-06-23 22:00:48.014498
# Unit test for method answer of class Text
def test_Text_answer():
    from random import seed
    from mimesis.enums import Locale
    from mimesis.builtins import Text

    seed(2)

    text = Text(Locale.RU)
    assert text.answer() == 'Да'

    text = Text(Locale.EN)
    assert text.answer() == 'No'

# Generated at 2022-06-23 22:00:50.729267
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    str = t.sentence()
    assert len(str) > 0

if __name__ == '__main__':
    t = Text()
    print(t.sentence())

# Generated at 2022-06-23 22:00:52.511306
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print (t.rgb_color())


# Generated at 2022-06-23 22:00:55.112489
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    assert text.answer() in ['Yes', 'No']


# Generated at 2022-06-23 22:00:56.842975
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert len(Text.sentence()) > 0


# Generated at 2022-06-23 22:00:59.566218
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    for i in range(100):
        r = t.color()
        assert isinstance(r, str)
        assert len(r) > 0


# Generated at 2022-06-23 22:01:00.993277
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    res = t.word()
    assert(res)

# Generated at 2022-06-23 22:01:03.720661
# Unit test for method word of class Text
def test_Text_word():
    # without numbers
    assert (len(Text().word()) > 0)
    # with numbers
    assert (len(Text().word(True)) > 0)


# Generated at 2022-06-23 22:01:05.391917
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    text.sentence()


# Generated at 2022-06-23 22:01:07.533205
# Unit test for method color of class Text
def test_Text_color():

    text = Text(random_state=0)

    for _ in range(20):
        color = text.color()
        assert color



# Generated at 2022-06-23 22:01:09.780952
# Unit test for method word of class Text
def test_Text_word():
    '''Get a random word.'''
    text = Text('en')
    word = text.word()
    assert word in text._data['words']['normal']


# Generated at 2022-06-23 22:01:12.282657
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert isinstance(text.alphabet(), list)

# Generated at 2022-06-23 22:01:14.228978
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Check method swear_word."""
    text = Text('en')
    assert 'Damn' == text.swear_word()


# Generated at 2022-06-23 22:01:17.262969
# Unit test for method quote of class Text
def test_Text_quote():
    # type: () -> None
    """Test for method quote of class Text."""
    text = Text()
    result = text.quote()
    assert result in text._data['quotes']

# Generated at 2022-06-23 22:01:20.123131
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet.

    :return: None.
    """
    t = Text()
    print("GOT: {0}".format(t.alphabet()))


# Generated at 2022-06-23 22:01:21.940122
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(locale="es")
    sentence = text.sentence()
    assert sentence in text._data["text"]

# Generated at 2022-06-23 22:01:24.937604
# Unit test for method text of class Text
def test_Text_text():
    # Create instance of class Text
    text = Text()
    # Add text
    text.add_provider('text', {
        'text': ['Hello', 'world', '!']
    })
    # Check
    assert text.text() == 'Hello world !'

# Generated at 2022-06-23 22:01:28.010263
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']
    assert t.rgb_color() in t._data['rgb_colors']


# Generated at 2022-06-23 22:01:31.167924
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    rs = RussiaSpecProvider(seed=4)
    assert rs.text.level() == "low"
