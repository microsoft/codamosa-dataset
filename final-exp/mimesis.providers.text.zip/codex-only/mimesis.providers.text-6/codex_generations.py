

# Generated at 2022-06-23 21:51:31.766724
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() == (214, 60, 66)
    assert Text().rgb_color(safe=True) == (33, 150, 243)

# Generated at 2022-06-23 21:51:33.547053
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    result = text.rgb_color()
    assert len(result) == 3

# Generated at 2022-06-23 21:51:34.909285
# Unit test for method text of class Text
def test_Text_text():
    text = Text().text()
    assert text is not None


# Generated at 2022-06-23 21:51:36.870465
# Unit test for method color of class Text
def test_Text_color():
    a = Text()
    b = a.color()
    assert isinstance(b, str)


# Generated at 2022-06-23 21:51:38.299738
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(seed=12345)
    text.sentence()
    res = 'The age is 0'
    assert res == text.sentence()


# Generated at 2022-06-23 21:51:39.270473
# Unit test for method word of class Text
def test_Text_word():
    return Text(seed=123).word()

# Generated at 2022-06-23 21:51:40.159066
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert len(Text().swear_word()) > 0

# Generated at 2022-06-23 21:51:45.072699
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Check if `swear_word` method works correctly."""
    # Arrange
    # Act
    text = Text()
    result = text.swear_word()

    # Assert
    assert isinstance(result, str)
    assert len(result) > 2

# Generated at 2022-06-23 21:51:46.112651
# Unit test for method title of class Text
def test_Text_title():
    assert Text.title() == 'Text.title'

# Generated at 2022-06-23 21:51:50.834299
# Unit test for constructor of class Text
def test_Text():
    assert len(Text(['en']).alphabet())==26
    assert len(Text(['en']).alphabet(lower_case=True))==26
    assert len(Text(['en']).words()) == 5
    assert len(Text(['en']).words(quantity=2)) == 2
    assert len(Text(['en']).text()) != 0

# Generated at 2022-06-23 21:51:52.916840
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    t = Text()
    assert isinstance(t.rgb_color(), tuple)

# Generated at 2022-06-23 21:51:54.240311
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() == t.text()



# Generated at 2022-06-23 21:51:56.996625
# Unit test for method quote of class Text
def test_Text_quote():
    test = Text()
    result = test.quote()
    print(result)
    assert result is not None
    assert result is not ''
    assert isinstance(result, str) is True
    

# Generated at 2022-06-23 21:51:59.984885
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet(lower_case=False)) == 26
    assert len(t.alphabet(lower_case=True)) == 26

# Generated at 2022-06-23 21:52:04.166090
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text('en')
    test1 = text.hex_color()
    test2 = text.hex_color(safe=True)
    test3 = text.hex_color(safe=False)
    assert test1 == test3
    assert test2 in SAFE_COLORS

# Generated at 2022-06-23 21:52:13.918648
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()

    hex_color_all = text.hex_color()
    assert len(hex_color_all) == 7
    assert isinstance(hex_color_all, str)
    assert hex_color_all[0] == '#'

    hex_color_safe = text.hex_color(safe=True)
    assert len(hex_color_safe) == 7
    assert isinstance(hex_color_safe, str)
    assert hex_color_safe[0] == '#'

    assert '#' in hex_color_safe
    assert hex_color_safe in SAFE_COLORS


# Generated at 2022-06-23 21:52:16.719420
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender, Locale
    from mimesis.builtins import Text
    text = Text(Gender.FEMALE, locale=Locale.CZECH)
    print(text.quote())


# Generated at 2022-06-23 21:52:22.868158
# Unit test for method words of class Text
def test_Text_words():
    a = Text()
    words = a.words(quantity=5)
    #test if length of words is 5
    assert len(words) == 5, "test_Text_words: fail"
    #test if all words in list
    all_words = True
    for w in words:
        if w not in a._data['words'].get('normal'):
            all_words = False
    assert all_words, "test_Text_words: fail"


# Generated at 2022-06-23 21:52:27.491061
# Unit test for method words of class Text
def test_Text_words():
    """Method to test Text.words

    Args:
    --
    Returns:
    --
    """
    a = Text()
    b = a.words(quantity=5)
    c = a.words(quantity=10)
    assert (len(b) == 5)
    assert (len(c) == 10)


# Generated at 2022-06-23 21:52:32.247164
# Unit test for method text of class Text
def test_Text_text():
    p = Text(seed=9899)
    t = p.text(4)
    assert t == 'El tiempo y el espacio, distinguir posición y movimiento, y ' \
                'demás conceptos que pertenecen al encuadre de la física '

# Generated at 2022-06-23 21:52:33.624914
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    edit = Text()
    assert edit.word() != edit.swear_word()

# Generated at 2022-06-23 21:52:37.288996
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    print(f"\ntext.words(quantity = 8) : {text.words(quantity = 8)}")


# Generated at 2022-06-23 21:52:40.001712
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    ans = t.answer()
    if ans in t._data['answers']:
        return True
    return False


# Generated at 2022-06-23 21:52:41.744888
# Unit test for method words of class Text
def test_Text_words():
    text = Text(locale='en')
    print(text.words(quantity=10))

# Generated at 2022-06-23 21:52:43.537633
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert(t.hex_color(False))


# Generated at 2022-06-23 21:52:49.937279
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    class Test:
        def test_bool(self, lower_case=None):
            t = Text()
            data = t.alphabet(lower_case)
            assert type(data) == list
            assert len(data) > 0
    Test().test_bool()
    Test().test_bool(lower_case=True)


# Generated at 2022-06-23 21:52:52.212225
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert isinstance(Text.rgb_color(), Tuple)
    assert len(Text.rgb_color()) == 3

# Generated at 2022-06-23 21:52:53.565227
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)

# Generated at 2022-06-23 21:52:57.067253
# Unit test for method title of class Text
def test_Text_title():
    text_instance = Text()
    title = text_instance.title()
    assert isinstance(title, str)
    assert len(title.split(' ')) > 1


# Generated at 2022-06-23 21:52:58.882993
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    a = Text()
    result = a.alphabet()
    assert len(result) == 26

# Generated at 2022-06-23 21:53:01.530673
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    data = Text()
    rgb = data.rgb_color()
    assert len(rgb) == 3


# Generated at 2022-06-23 21:53:05.666935
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Localization
    from mimesis.providers.misc import Misc

    t = Text(localization=Localization.RU)
    assert isinstance(t, Text) == True


# Generated at 2022-06-23 21:53:06.650580
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text()


# Generated at 2022-06-23 21:53:08.004466
# Unit test for method level of class Text
def test_Text_level():
    data = Text(seed=1).level()
    assert data == 'critical'

# Generated at 2022-06-23 21:53:09.707524
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert isinstance(text.alphabet(), list)


# Generated at 2022-06-23 21:53:11.371035
# Unit test for method level of class Text
def test_Text_level():
    """Test for method level of class Text."""
    t = Text()
    print(t.level())

# Generated at 2022-06-23 21:53:12.812938
# Unit test for method title of class Text
def test_Text_title():
    x = Text(seed=42)
    assert x.title() == 'Eius labore omnis'


# Generated at 2022-06-23 21:53:17.026135
# Unit test for method word of class Text
def test_Text_word():
    test_text = Text()
    test_word = test_text.word()
    print(f"Test Text Word: {test_word}")



# Generated at 2022-06-23 21:53:19.287243
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    print(t.text())
    print(t.text(2))


# Generated at 2022-06-23 21:53:21.022093
# Unit test for method words of class Text
def test_Text_words():
	process = Text()
	result = process.words()
	assert isinstance(result, list)


# Generated at 2022-06-23 21:53:23.554478
# Unit test for method word of class Text
def test_Text_word():
    import re
    t = Text()
    r_list = t.words(100)
    for r in r_list:
        assert re.match(r'^\w{4,}$', r)

# Generated at 2022-06-23 21:53:25.472653
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    s = t.words(3)
    assert len(s) == 3
    assert ' ' not in s


# Generated at 2022-06-23 21:53:28.011696
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print (t.quote())
    print (t.quote())
    print (t.quote())
    print (t.quote())



# Generated at 2022-06-23 21:53:31.063477
# Unit test for method title of class Text
def test_Text_title():
    t=Text(seed=42)
    assert t.title() == "Dignissim a torquent tincidunt senectus"
    return


# Generated at 2022-06-23 21:53:33.784050
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text.answer() in ["ja", "nein", "вранье", "да", "нет"]

# Generated at 2022-06-23 21:53:36.661749
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test method hex_color of class Text."""
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7
    assert hex_color.startswith('#')

# Generated at 2022-06-23 21:53:38.710462
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    text = Text()
    #TODO
    assert text.answer() != ""

# Generated at 2022-06-23 21:53:40.884795
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    l = []
    for i in range(100):
        l.append(t.title())
    assert len(l) == len(set(l))

# Generated at 2022-06-23 21:53:47.096490
# Unit test for constructor of class Text
def test_Text():
    # Get a instance of Text.
    provider = Text()

    # Check additional attributes.
    assert hasattr(provider, 'zh')

    # Check the default locale.
    assert provider.locale == 'en'

    # Check the Chinese language.
    provider.set_locale('zh')
    assert provider.locale == 'zh'



# Generated at 2022-06-23 21:53:49.230161
# Unit test for method words of class Text
def test_Text_words():
    #assert(Text().words() != None)
    #print(Text().words())
    pass

# Generated at 2022-06-23 21:53:52.705993
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words = t.words()
    assert len(words) == 5
    assert all(isinstance(x, str) for x in words)
    

# Generated at 2022-06-23 21:53:56.849909
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=123)
    assert t.color() == 'Red'
    assert t.color() == 'Green'
    assert t.color() == 'Yellow'
    assert t.color() == 'White'
    assert t.color() == 'Gray'



# Generated at 2022-06-23 21:54:00.389313
# Unit test for method title of class Text
def test_Text_title():
    pass
    '''
    t = Text('en')
    for _ in range(10):
        print(t.title())
    '''

# Generated at 2022-06-23 21:54:03.037157
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert isinstance(text.word(),str)
    print("test for method word of class Text: OK")


# Generated at 2022-06-23 21:54:06.875208
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import DataField

    t = Text('en', DataField.ENGLISH)
    for _ in range(10):
        assert isinstance(t.rgb_color(), tuple)
        assert t.rgb_color()
        assert isinstance(t.rgb_color(safe=True), tuple)



# Generated at 2022-06-23 21:54:09.914188
# Unit test for method title of class Text
def test_Text_title():
    text = Text(__file__)
    #print("title = "+text.title())
    print("title = "+text.sentence())
    print("title = "+text.words())
    print("title = "+text.color())
    print("text = "+text.text())


if __name__ == "__main__":
    test_Text_title()

# Generated at 2022-06-23 21:54:11.246643
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() is not None

# Generated at 2022-06-23 21:54:12.224979
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text("ru")
    assert (len(t.sentence()) > 1)

# Generated at 2022-06-23 21:54:15.023550
# Unit test for method quote of class Text
def test_Text_quote():
    """Test for method quote of Class Text.
    """
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    a=Text(Language.TR)
    assert Text(Language.TR).quote() == 'Kapılar kilitli.'

# Generated at 2022-06-23 21:54:15.926110
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    text.sentence()

# Generated at 2022-06-23 21:54:19.300586
# Unit test for method word of class Text
def test_Text_word():
    """Unit test."""
    text_tool = Text()
    word = text_tool.word()
    assert isinstance(word, str)
    assert len(word) >= 2
    assert len(word) <= 15
    assert isinstance(text_tool.word(), str)


# Generated at 2022-06-23 21:54:21.753969
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert isinstance(text.sentence(), str)


# Generated at 2022-06-23 21:54:23.906800
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    a = text.answer()
    assert type(a) == str


# Generated at 2022-06-23 21:54:26.374496
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis import Text
    t = Text()
    print(t.rgb_color())
    print(t.rgb_color(1))


# Generated at 2022-06-23 21:54:27.638462
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)

# Generated at 2022-06-23 21:54:29.683048
# Unit test for method answer of class Text
def test_Text_answer():
    '''
    The method test_Text_answer() is unit test for the method answer of class Text

    :return:
    '''
    text = Text()
    print(text.answer())

# Generated at 2022-06-23 21:54:30.725606
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() == "fudge"

# Generated at 2022-06-23 21:54:42.097271
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text(seed=0)
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
                            'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
                                           'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

#

# Generated at 2022-06-23 21:54:46.242628
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    # safe = False
    print('t.hex_color():  ', t.hex_color())
    # safe = True
    print('t.hex_color(safe=True):  ', t.hex_color(safe=True))

test_Text_hex_color()
print('\n')



# Generated at 2022-06-23 21:54:48.049217
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=1)
    assert text.swear_word() == "son of a bitch"


# Generated at 2022-06-23 21:54:49.355894
# Unit test for method text of class Text
def test_Text_text():
    text = Text()

    assert text.text() is not None


# Generated at 2022-06-23 21:54:50.418768
# Unit test for method level of class Text
def test_Text_level():
    """Test checking method level of class Text."""
    assert Text().level() != None

# Generated at 2022-06-23 21:54:53.936110
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text as TextProvider
    s = {'en': "science", 'ru': "наука"}
    for i in s:
        t = TextProvider(i)
        assert isinstance(t.word(), str), 'The result must be a string'
        assert t.word() == s[i], 'The result should be {}'.format(s[i])



# Generated at 2022-06-23 21:54:55.368410
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_a = Text('en')
    text_rgb_a = text_a.rgb_color()
    assert text_rgb_a in list(range(0, 256))

# Generated at 2022-06-23 21:55:05.307078
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text(locale='en')  
    sentencelist = []
    for _ in range(1000):
        sentence = provider.sentence().lower()
        if "i " in sentence:
            sentencelist.append(sentence)
    assert any("i am" in sentence for sentence in sentencelist)
    assert any("i will" in sentence for sentence in sentencelist)
    assert any("i do" in sentence for sentence in sentencelist)
    assert any("i like" in sentence for sentence in sentencelist)
    assert any("i love" in sentence for sentence in sentencelist)
    assert any("i can" in sentence for sentence in sentencelist)
    assert any("i don" in sentence for sentence in sentencelist)
    assert any("i don't" in sentence for sentence in sentencelist)

# Generated at 2022-06-23 21:55:06.944245
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=42)
    assert t.color() == 'purple'


# Generated at 2022-06-23 21:55:08.966026
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence().endswith('.')


# Generated at 2022-06-23 21:55:11.137568
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale
    t = Text(Locale.EN)
    print(t.text(10))


# Generated at 2022-06-23 21:55:13.189166
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test for sentence() method of Text class."""
    text = Text('en')
    sentence = text.sentence()
    assert isinstance(sentence, str)



# Generated at 2022-06-23 21:55:16.586062
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    if isinstance(text.hex_color(), str):
        print('unit test of method alphabet of class Text: pass')
    else:
        print('unit test of method alphabet of class Text: fail')

# Generated at 2022-06-23 21:55:21.402118
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert len(alphabet) == 26
    assert alphabet[0] == "A"
    assert alphabet[25] == "Z"

    alphabet = text.alphabet(lower_case=True)
    assert len(alphabet) == 26
    assert alphabet[0] == "a"
    assert alphabet[25] == "z"


# Generated at 2022-06-23 21:55:22.559355
# Unit test for method quote of class Text
def test_Text_quote():
    obj = Text()
    assert isinstance(obj.quote(), str)


# Generated at 2022-06-23 21:55:24.022816
# Unit test for method title of class Text
def test_Text_title():
    provider = Text()
    title = provider.title()
    assert len(title) > 5

# Generated at 2022-06-23 21:55:25.888018
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert len(text.level()) > 0
    assert isinstance(text.level(), str)
    assert len(set(text.level() for _ in range(100))) > 1

# Generated at 2022-06-23 21:55:30.158778
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    result = t.level()
    assert result in ['critical', 'high', 'medium', 'low', 'safe']

# Generated at 2022-06-23 21:55:37.420741
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from .enums import Gender
    from .person import Person
    test_person = Person(Locale.ENGLISH)
    text_person = Text(locale=Locale.ENGLISH)
    # test_Text_swear_word
    last_name = test_person.last_name(gender=Gender.MALE)
    # test_Text_swear_word
    swear_word = text_person.swear_word()
    assert last_name != swear_word



# Generated at 2022-06-23 21:55:41.255962
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of Text class."""
    bad_words = ['bad', 'badass', 'badly', 'bitch', 'chain', 'damn',
                 'death', 'fuck', 'hate', 'hell', 'piss', 'shoot',
                 'shit', 'wrong', 'wrongly']
    assert Text().swear_word() in bad_words


# Generated at 2022-06-23 21:55:44.046919
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color())
    print(t.hex_color(safe=True))


# Generated at 2022-06-23 21:55:45.507934
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    txt = Text()
    assert txt.swear_word()

# Generated at 2022-06-23 21:55:49.504303
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert isinstance(words, list)
    for word in words:
        assert isinstance(word, str)

# Generated at 2022-06-23 21:55:52.820925
# Unit test for method words of class Text
def test_Text_words():
    # Create Text object
    text = Text()

    # Create Variable
    result = text.words(quantity=10)

    # Check result
    assert type(result) is list


# Generated at 2022-06-23 21:55:55.088992
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    text = txt.sentence()
    print(text)
# function test_Text_sentence


# Generated at 2022-06-23 21:55:56.865052
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(quantity=10)) == 10
    return True


# Generated at 2022-06-23 21:55:59.795343
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('en')
    alpha = text.alphabet()
    assert isinstance(alpha, list)
    assert all(isinstance(item, str) for item in alpha)


# Generated at 2022-06-23 21:56:01.527406
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() in ['damn', 'shit', 'fuck', 'asshole', 'bastard']

# Generated at 2022-06-23 21:56:04.137354
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert type(sentence) == str

# Generated at 2022-06-23 21:56:06.643522
# Unit test for method color of class Text
def test_Text_color():
    x = Text()
    y = x.color()
    assert True if y in x._data['color'] else False


# Generated at 2022-06-23 21:56:09.522383
# Unit test for constructor of class Text
def test_Text():
    f = Text()
    print(f.hex_color())
    # print(f.answer())
    print(f.text())
    print(f.word())

# Generated at 2022-06-23 21:56:14.730113
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_ru = Text('ru')
    alphabet_ru = text_ru.alphabet()
    assert alphabet_ru is not None
    assert len(alphabet_ru) == 32

    alphabet_en = text_ru.alphabet(lower_case=True)
    assert alphabet_en is not None
    assert len(alphabet_en) == 32

# Generated at 2022-06-23 21:56:16.833565
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word."""
    text = Text()
    word = text.word()
    assert len(word) > 0


# Generated at 2022-06-23 21:56:18.591573
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in [x for x in text._data['answers']]

# Generated at 2022-06-23 21:56:21.482538
# Unit test for method title of class Text
def test_Text_title():
    txt = Text()
    s = txt.title()
    assert isinstance(s, str)
    assert s != ''


# Generated at 2022-06-23 21:56:23.590471
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t1 = Text()
    assert isinstance(t1.hex_color(), str)


# Generated at 2022-06-23 21:56:26.419055
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    t = Text()
    s = t.sentence()
    assert isinstance(s, str)
    # print(s)

# Generated at 2022-06-23 21:56:29.434891
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(seed=1)
    assert text.answer() == 'No'



# Generated at 2022-06-23 21:56:31.356624
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() == 'I was wondering why the ball was getting bigger. Then it hit me.'

# Generated at 2022-06-23 21:56:35.001869
# Unit test for method text of class Text
def test_Text_text():
    from providers import text
    textProvider = text.Text()
    first_text = textProvider.text()
    second_text = textProvider.text()
    assert first_text != second_text


# Generated at 2022-06-23 21:56:36.140307
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print()
    print(t.hex_color())


# Generated at 2022-06-23 21:56:37.474268
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert(text.word() == "fear")


# Generated at 2022-06-23 21:56:40.826739
# Unit test for method word of class Text
def test_Text_word():
    pass
    # from mimesis.enums import Gender
    # from mimesis.builtins import RussiaSpecProvider
    # rus_pro = RussiaSpecProvider(gender=Gender.MALE)
    # print(rus_pro.Text.word())


# Generated at 2022-06-23 21:56:43.449481
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert len(text.word()) > 0
    assert text.word() == 'Science'


# Generated at 2022-06-23 21:56:45.469636
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())


# Generated at 2022-06-23 21:56:48.445868
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    txt = Text()
    color = txt.rgb_color(safe=False)
    assert len(color) == 3, "rgb_color не возвращает tuple, найди косяк"


# Generated at 2022-06-23 21:56:50.534256
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert '#' in hex_color


# Generated at 2022-06-23 21:56:52.448411
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    result = t.sentence()
    assert result is not None

# Generated at 2022-06-23 21:56:54.998474
# Unit test for method level of class Text
def test_Text_level():
    import mimesis
    text = mimesis.Text()
    assert 'critical' in text.level()


# Generated at 2022-06-23 21:56:56.076321
# Unit test for method quote of class Text
def test_Text_quote():
    for i in range(1000):
        print(Text().quote())

# Generated at 2022-06-23 21:57:04.928627
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text)
    assert t.__doc__ is not None
    assert t.__init__.__doc__ is not None
    assert t.alphabet.__doc__ is not None
    assert t.level.__doc__ is not None
    assert t.text.__doc__ is not None
    assert t.sentence.__doc__ is not None
    assert t.title.__doc__ is not None
    assert t.words.__doc__ is not None
    assert t.word.__doc__ is not None
    assert t.swear_word.__doc__ is not None
    assert t.quote.__doc__ is not None
    assert t.color.__doc__ is not None
    assert t._hex_to_rgb.__doc__ is not None

# Generated at 2022-06-23 21:57:12.574487
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import mimesis
    # Create the instance
    text = mimesis.Text()
    # Get a random swear word
    swear_word = text.swear_word()
    # Print the result
    print(swear_word)
    # Get a random quote
    quote = text.quote()
    # Print the result
    print(quote)
    # Get a random color
    color = text.color()
    # Print the result
    print(color)
    # Generate a random hex color
    hex_color = text.hex_color()
    # Print the result
    print(hex_color)
    # Get a random answer
    answer = text.answer()
    # Print the result
    print(answer)

if __name__ == '__main__':
    test_Text_swear_word()

# Generated at 2022-06-23 21:57:15.054312
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    res = t.swear_word()
    pass


# Generated at 2022-06-23 21:57:23.532187
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for method rgb_color of class Text"""
    print("Testing method rgb_color of class Text")
    print("*"*80)
    print("Test without providing any parameter.")
    print(Text().rgb_color())
    print("*"*80)
    print("Test providing parameter safe to False.")
    print(Text().rgb_color(False))
    print("*"*80)
    print("Test providing parameter safe to True.")
    print(Text().rgb_color(True))
    print("*"*80)
    print("Testing Completed for method rgb_color of class Text")


# Generated at 2022-06-23 21:57:25.607072
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    text = Text(locale=Locale.EN)
    result = text.swear_word()
    print(result)


# Generated at 2022-06-23 21:57:29.624295
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    for i in range(0, 1):
        print(t.hex_color())
        print(t.hex_color(safe=True))


# Generated at 2022-06-23 21:57:32.239765
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print('EN:', text.alphabet())
    print('EN lowercase:', text.alphabet(lower_case=True))


# Generated at 2022-06-23 21:57:38.168807
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale, Gender
    text = Text(locale=Locale.ENGLISH)
    assert len(text.text()) == 24
    assert len(text.text(quantity=1)) == 11
    assert len(text.text(quantity=2)) == 23
    assert len(text.text(quantity=5)) == 55
    assert len(text.title()) == 11
    assert len(text.title(quantity=1)) == 11
    assert len(text.quote()) == 45
    assert len(text.level()) == 7
    assert len(text.word()) == 5
    assert len(text.hex_color()) == 7
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3

# Generated at 2022-06-23 21:57:44.132981
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for Text hex_color method."""
    t = Text()
    hc = t.hex_color()
    assert len(hc) == 7
    assert hc[0] == '#'
    assert hc[1:].isalnum()
    assert hc.islower()

    for _ in range(0, 100):
        assert t.hex_color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 21:57:46.451053
# Unit test for method text of class Text
def test_Text_text():
    provider = Text()
    text = provider.text()
    assert isinstance(text, str)

# Generated at 2022-06-23 21:57:47.372006
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print(Text().swear_word())

# Generated at 2022-06-23 21:57:48.610978
# Unit test for method words of class Text
def test_Text_words():
    Text().words(quantity=5)

# Generated at 2022-06-23 21:57:51.871753
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alphabet = t.alphabet()
    assert len(alphabet) == 26, "The length of alphabet is not 26"


# Generated at 2022-06-23 21:57:52.823588
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t != None

# Generated at 2022-06-23 21:57:57.084053
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert(len(text.alphabet(lower_case = False)) == 26)
    assert(len(text.alphabet(lower_case = True)) == 26)
    assert(text.alphabet(lower_case = False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert(text.alphabet(lower_case = True) == 'abcdefghijklmnopqrstuvwxyz')


# Generated at 2022-06-23 21:57:59.449692
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis import Text
    t = Text()
    result = t.hex_color(safe=True)
    assert result in SAFE_COLORS

# Generated at 2022-06-23 21:58:00.922489
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert type(text.swear_word()) == str

# Generated at 2022-06-23 21:58:05.815779
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.localization import US

    text = Text(locale=US)
    for i in range(0, 50):
        color = text.rgb_color()
        assert isinstance(color, tuple)
        assert len(color) == 3
        assert color[0] <= 255 and color[1] <= 255 and color[2] <= 255

# Generated at 2022-06-23 21:58:07.141590
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text)


# Generated at 2022-06-23 21:58:09.778882
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for text of class Text."""
    from mimesis.enums import Language
    t = Text(Language.ENGLISH)
    # print(t.text())


# Generated at 2022-06-23 21:58:12.748247
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet."""
    text = Text()
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.alphabet(lower_case=True), list)
    assert isinstance(text.alphabet(lower_case=False), list)


# Generated at 2022-06-23 21:58:15.733476
# Unit test for method color of class Text
def test_Text_color():
    print('\n\nColor')
    fr = Text('fr')
    print(fr.color())
    print(fr.color())
    print(fr.color())



# Generated at 2022-06-23 21:58:18.924665
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() in ('Bitch', 'Fu', 'Fuck', 'Fuck you', 'Gosh', 'Shit', 'Suck ass', 'Suck my dick', 'Suck my dick', 'Suck my')

# Generated at 2022-06-23 21:58:20.733835
# Unit test for method color of class Text
def test_Text_color():
    i = 0
    count = 1000
    while i < count:
        s = Text(seed=i)
        assert s.color() is not None
        i = i + 1


# Generated at 2022-06-23 21:58:24.950835
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t1 = Text(seed=1234)
    alphabet_1 = t1.alphabet()
    alphabet_2 = t1.alphabet(lower_case=True)
    assert alphabet_1 == 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    assert alphabet_2 == 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'


# Generated at 2022-06-23 21:58:26.352035
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text('en').sentence())
    return True


# Generated at 2022-06-23 21:58:28.147711
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None


# Generated at 2022-06-23 21:58:30.869691
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    text = Text()
    assert len(text.swear_word()) > 0

# Generated at 2022-06-23 21:58:33.823306
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Create a Text instance
    t = Text()

    swear_word = t.swear_word()

    assert isinstance(swear_word, str)
    assert swear_word != ''



# Generated at 2022-06-23 21:58:35.136260
# Unit test for method text of class Text
def test_Text_text():
    """Test method Text.text"""
    text = Text()
    words = text.text(quantity=11)
    assert len(words.split()) == 11

# Generated at 2022-06-23 21:58:37.036349
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    text = Text()
    assert isinstance(text.text(), str)
    assert text.text().endswith('.')
    assert text.text().startswith(' ')


# Generated at 2022-06-23 21:58:39.221885
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    t = Text()
    x = t.sentence()
    assert x


# Generated at 2022-06-23 21:58:41.743592
# Unit test for method text of class Text
def test_Text_text():
    from mimesis import Generic
    t = Text("en")
    print(t.text())
    print(t.text(3))
    print(t.text(1))

# Generated at 2022-06-23 21:58:44.182048
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert len(t.word()) >= 5


# Generated at 2022-06-23 21:58:46.079586
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    result = text.quote()
    assert type(result) == str


# Generated at 2022-06-23 21:58:48.458598
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in text._data['answers']


# Generated at 2022-06-23 21:58:50.781467
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=1)
    actual = t.rgb_color()
    expected = (203, 74, 31)
    assert actual == expected

# Generated at 2022-06-23 21:58:53.012132
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text(seed=0).hex_color()

    assert color == '#bb39ff'


# Generated at 2022-06-23 21:58:54.268627
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in getattr(t, "data")["level"]

# Generated at 2022-06-23 21:58:55.599356
# Unit test for method text of class Text
def test_Text_text():
    a = Text()
    assert(a.text()!="")

# Generated at 2022-06-23 21:58:59.871136
# Unit test for method color of class Text
def test_Text_color():
    """Test method color of class Text using a custom seed, and compare the value with the expected result.
        Should return Blue.
    """
    t = Text(seed=1)
    assert t.color() == "Blue"


# Generated at 2022-06-23 21:59:01.462993
# Unit test for method level of class Text
def test_Text_level():
    level = Text().level()
    print(level)


# Generated at 2022-06-23 21:59:04.544193
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    t = Text()
    assert t.swear_word() in t._data['words']['bad']
    assert t.swear_word() in t._data['words']['bad']
    assert t.swear_word() in t._data['words']['bad']


# Generated at 2022-06-23 21:59:06.970225
# Unit test for constructor of class Text
def test_Text():
    assert Text('en').title() != ''
    assert Text('en').text() != ''
    assert Text('en').sentence() != ''
    assert Text('en').words() != ''
    assert Text('en').alphabet() != ''


# Generated at 2022-06-23 21:59:07.618655
# Unit test for method level of class Text
def test_Text_level():
    pass

# Generated at 2022-06-23 21:59:08.899580
# Unit test for method quote of class Text
def test_Text_quote():
    # print(Text().quote())
    pass


# Generated at 2022-06-23 21:59:12.754597
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    print(rgb)
    assert len(rgb) == 3
    assert type(rgb[0]) == int
    assert type(rgb[1]) == int
    assert type(rgb[2]) == int



# Generated at 2022-06-23 21:59:14.149486
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert(len(text.rgb_color()) == 3)

# Generated at 2022-06-23 21:59:20.772739
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text
    from mimesis.enums import Gender
    from mimesis.localization import RussianSpecProvider
    from mimesis.typing import Seed

    seed = Seed.create_seed()

    txt = Text()
    txt_ru = Text(localization=RussianSpecProvider)

    for x in range(1):
        print(
            f'{txt.word()} \t{txt.word()} \t{txt.word()}'
        )
        print(
            f'{txt_ru.word()} \t{txt_ru.word()} \t{txt_ru.word()}'
        )

# Generated at 2022-06-23 21:59:22.572382
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text(seed=123)

# Generated at 2022-06-23 21:59:25.730264
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    list_words = text.words(quantity=5)
    assert len(list_words) == 5

# Generated at 2022-06-23 21:59:29.924452
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    class_ = Text()
    assert isinstance(class_.swear_word(), str)
    assert class_.swear_word() in class_._data['words'].get('bad')


# Generated at 2022-06-23 21:59:31.586857
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locales
    from mimesis.providers.text import Text
    t = Text(Locales.ENGLISH)
    for _ in range(100):
        assert isinstance(t.sentence(), str)


# Generated at 2022-06-23 21:59:33.498314
# Unit test for method level of class Text
def test_Text_level():
    text = Text('no')
    assert text.level() in ['critical', 'danger', 'high', 'normal']


# Generated at 2022-06-23 21:59:35.823368
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from random import random
    p = Text('en')
    for i in range(100):
        print(p.title())
        print(i)

# Generated at 2022-06-23 21:59:41.205083
# Unit test for constructor of class Text
def test_Text():
    # Arrange
    text = Text()
    # Act
    assert text.words()
    assert text.sentence()
    assert text.title()
    assert text.word()
    assert text.swear_word()
    assert text.quote()
    assert text.color()
    assert text.hex_color()
    assert text.rgb_color()
    assert text.answer()
    assert text.alphabet()

# Generated at 2022-06-23 21:59:48.230474
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text('zh')
    assert t.alphabet() == [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
        'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    ]


# Generated at 2022-06-23 21:59:49.775598
# Unit test for method word of class Text
def test_Text_word():
    TextTest = Text()
    print("Word: " + TextTest.word())


# Generated at 2022-06-23 21:59:52.158504
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Creating a Text object
    text = Text()

    # Create a sentence
    sentence = text.sentence()

    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:59:54.299404
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    a = Text()
    #print(a.hex_color())
    #print(a.hex_color(safe=True))


# Generated at 2022-06-23 21:59:55.962655
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text().hex_color(safe=True) in SAFE_COLORS
    assert (len(Text().hex_color()) == 7
            and Text().hex_color().startswith('#'))


# Generated at 2022-06-23 21:59:58.955519
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())  # Prints: (79, 72, 200)
    print(t.rgb_color(safe=True))  # Prints: (255, 87, 34)

# Generated at 2022-06-23 22:00:01.012387
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text('en')
    t.rgb_color()
    t.rgb_color(safe=True)
    t.rgb_color(safe=False)


# Generated at 2022-06-23 22:00:03.316733
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert_is_instance(level, str)
    assert_true(level in text._data['level'])


# Generated at 2022-06-23 22:00:04.649473
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    print(text.hex_color())


# Generated at 2022-06-23 22:00:06.575741
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text = text.text()
    #print("Text: text=" + text)


# Generated at 2022-06-23 22:00:08.381871
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    result = t.swear_word()
    print(result)


# Generated at 2022-06-23 22:00:09.466697
# Unit test for method color of class Text
def test_Text_color():
    text_obj = Text()
    color = text_obj.color()
    assert color in text_obj._data['color']

# Generated at 2022-06-23 22:00:12.882252
# Unit test for method level of class Text
def test_Text_level():
    """Test method level of class Text."""
    text = Text()
    level = text.level()
    assert type(level) == str
    assert len(level) > 0


# Generated at 2022-06-23 22:00:15.751325
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import Text
    text = Text()
    for _ in range(10):
        print(text.sentence())


# Generated at 2022-06-23 22:00:18.107671
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert len(Text().hex_color(safe=False)) == 7
    assert len(Text().hex_color(safe=True)) == 7

# Generated at 2022-06-23 22:00:19.105017
# Unit test for method answer of class Text
def test_Text_answer():
    x = Text()
    print(x.answer())

# Generated at 2022-06-23 22:00:27.323244
# Unit test for method quote of class Text
def test_Text_quote():
    """Test method quote of class Text"""
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins.text import Text

    t = Text(gender=Gender.FEMALE, locale='en')
    print(t.quote())

    r = Text(locale='ru')
    print(r.quote())

    text = Text(seed=42)
    assert text.quote() == "Bond... James Bond."
    assert text.quote() == "Bond... James Bond."
    assert text.quote() == "Bond... James Bond."

    Text(seed=42)
    Text(seed=42)

    u = Text(locale='uk')
    assert u.quote() == "Bond... James Bond."

    text = Text(seed=42)


# Generated at 2022-06-23 22:00:30.125284
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    text = Text(seed=1)
    assert text.answer() == 'Não'

# Generated at 2022-06-23 22:00:31.314954
# Unit test for method level of class Text
def test_Text_level():
    # pylint: disable=no-member
    assert len(Text().level()) > 0

# Generated at 2022-06-23 22:00:33.844857
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Language
    t = Text(Language.ENGLISH)
    lev = t.level()
    assert lev in t._data['level']


# Generated at 2022-06-23 22:00:35.542951
# Unit test for method word of class Text
def test_Text_word():
    for i in range(1000):
        assert len(Text().word()) > 0


# Generated at 2022-06-23 22:00:44.443688
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    txt = Text()
    # The name of class should be the same with file name
    assert txt.__class__.__name__ == 'Text'
    # The name of method should be the same with function name
    assert txt.rgb_color.__name__ == test_Text_rgb_color.__name__
    assert len(txt.rgb_color()) == 3
    assert txt.rgb_color()[0] in list(range(0,256))
    assert txt.rgb_color()[1] in list(range(0,256))
    assert txt.rgb_color()[2] in list(range(0,256))
    assert len(txt.rgb_color(safe=True)) == 3

# Generated at 2022-06-23 22:00:46.872062
# Unit test for method level of class Text
def test_Text_level():
    """Test method level of class Text."""
    t = Text()
    level = t.level()
    assert level in t._data['level']


# Generated at 2022-06-23 22:00:48.190201
# Unit test for method quote of class Text
def test_Text_quote():
    result = Text().quote()
    print(result)


# Generated at 2022-06-23 22:00:50.209412
# Unit test for method color of class Text
def test_Text_color():
    from . import text
    t = text.Text()
    ans = t.color()
    print(ans)



# Generated at 2022-06-23 22:00:55.817630
# Unit test for constructor of class Text
def test_Text():
    """Testing constructor of class Text"""
    text = Text()
    text1 = Text()
    assert text.__class__ == text1.__class__
    assert text.seed == text1.seed
    assert text.data == text1.data


# Generated at 2022-06-23 22:00:59.426593
# Unit test for method quote of class Text
def test_Text_quote():
    """
    method quote of class Text
    """
    text = Text()
    quote = text.quote()
    print("quote:", quote)
    assert isinstance(quote, str) and len(quote) <= 140
    

# Generated at 2022-06-23 22:01:01.813581
# Unit test for method words of class Text
def test_Text_words():
    t = Text(seed=123)

    words = ['science', 'network', 'god', 'octopus', 'love']

    assert t.words(quantity=5) == words


# Generated at 2022-06-23 22:01:04.507861
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    t = Text()
    assert len(t.words(2)) == 2



# Generated at 2022-06-23 22:01:07.094037
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    print(text.text())
    print(text.text(quantity=2))
    print(text.text(quantity=7))


# Generated at 2022-06-23 22:01:09.049549
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    m = Text()
    expected_type = list
    result = m.alphabet()
    assert type(result) is expected_type


# Generated at 2022-06-23 22:01:15.839990
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    b = "abcdefghijklmnopqrstuvwxyz"
    c = ['l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    assert t.alphabet(lower_case=True) == b
    assert t.alphabet() == a
    assert t.level() in c
    assert t.text() in ["It seems to be true.", 'I do not know what to say.']
    assert t.sentence() in ["It seems to be true.", 'I do not know what to say.']

# Generated at 2022-06-23 22:01:25.092348
# Unit test for method title of class Text
def test_Text_title():
    from mimesis import Text
    from mimesis.builtins import UnitedStatesSpecProvider
    from mimesis.enums import Gender, Locale

    r = Text()

    print(r.title())
    print(r.title('en'))

    # Change locale for current instance
    r.set_locale(Locale.RU)
    print(r.title())

    # Create a new instance
    ru = Text(locale='ru')
    print(ru.title())

    # Create a new instance
    ru = Text(locale=Locale.RU)
    print(ru.title())

    # Create a new instance with seed
    ru = Text(locale='ru', seed=10)
    ru.seed = None
    print(ru.title())
    print(ru.title())

    # Create a

# Generated at 2022-06-23 22:01:34.202893
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    data = Text()
    assert data.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert data.alphabet(True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
