

# Generated at 2022-06-23 21:51:34.824342
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # create an instance of the class
    t = Text()
    # create a variable that is equal to the output of the method
    x = t.rgb_color()
    # assert the type of the value is a tuple
    assert isinstance(x, tuple)
    # assert the length of the tuple is 3
    assert len(x) == 3
    # assert the type of each element in the tuple is int
    assert isinstance(x[0], int)
    assert isinstance(x[1], int)
    assert isinstance(x[2], int)


# Generated at 2022-06-23 21:51:37.548038
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=123)
    assert text.level() == 'critical'

    text = Text(seed=321)
    assert text.level() == 'moderate'


# Generated at 2022-06-23 21:51:39.933784
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    number = 5
    text = x.text(quantity=number)
    assert len(text.split(sep='.')) == number


# Generated at 2022-06-23 21:51:40.875383
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print(Text().alphabet())

# Generated at 2022-06-23 21:51:43.922692
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert (t.word() != t.word())


# Generated at 2022-06-23 21:51:44.932653
# Unit test for method quote of class Text
def test_Text_quote():
    result = Text().quote()
    assert result

# Generated at 2022-06-23 21:51:47.501503
# Unit test for method answer of class Text
def test_Text_answer():
    bg_text = Text('bg')

    answer = bg_text.answer()
    assert (answer in bg_text._data['answers'])


# Generated at 2022-06-23 21:51:48.868493
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26


# Generated at 2022-06-23 21:51:52.577895
# Unit test for method sentence of class Text
def test_Text_sentence():
    try:
        obj = Text()
        res = obj.sentence()
        temp1 = (type(res) is str)
        temp2 = (len(res) >= 6)
        if(temp1 and temp2):
            print("Method sentence of class Text executes properly")
            print("Expected: <class 'str'>")
            print("Value: ",res)
        else:
            print("Method sentence of class Text does not execute properly")
    except:
        print("Method sentence of class Text throws exception")


# Generated at 2022-06-23 21:51:55.169630
# Unit test for constructor of class Text
def test_Text():
    """Unit test for constructor of class Text"""
    assert Text
    c = Text
    assert c.Meta.name == 'text'
    assert c.Meta.name == Text.Meta.name


# Generated at 2022-06-23 21:51:56.815905
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    return swear_word


# Generated at 2022-06-23 21:52:02.507915
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed=777)
    assert text.color() == 'Red'
    assert text.color() == 'White'
    assert text.color() == 'Yellow'
    text = Text(seed=777)
    assert text.color() == 'Red'
    assert text.color() == 'White'
    assert text.color() == 'Yellow'


# Generated at 2022-06-23 21:52:04.791552
# Unit test for method quote of class Text
def test_Text_quote():
    '''
    """Get a random quote."""
    '''

    txt = Text()
    assert txt.quote() != ""

# Generated at 2022-06-23 21:52:07.957975
# Unit test for method color of class Text
def test_Text_color():
    seed = 9
    text = Text(seed)
    result = text.color()
    assert result == 'Blue', "Should be 'Blue'"



# Generated at 2022-06-23 21:52:11.557672
# Unit test for method level of class Text
def test_Text_level():
    text = Text('en')
    for _ in range(100):
        r = text.level()
        assert isinstance(r, str)


# Generated at 2022-06-23 21:52:13.874138
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text(quantity=2)
    # print(text.text(quantity=2))


# Generated at 2022-06-23 21:52:16.976694
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print(Text().alphabet(lower_case=True))
    print(Text().alphabet(lower_case=False))
    print(Text().alphabet(lower_case='true'))
    print(Text().alphabet(lower_case='False'))



# Generated at 2022-06-23 21:52:20.055659
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert(re.search(r'^#[a-fA-F0-9]{6}$', t.hex_color()) is not None)


# Generated at 2022-06-23 21:52:21.538488
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text().hex_color()
    assert isinstance(color, str)
    assert len(color) == 7
    assert color.startswith('#')

# Generated at 2022-06-23 21:52:24.592461
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    l = []
    while(len(l)<101):
        l.append(t.swear_word())
    assert(len(l) == len(set(l)))

# Generated at 2022-06-23 21:52:26.379666
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    test = t.answer()
    assert isinstance(test, str) is True


# Generated at 2022-06-23 21:52:36.083379
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text(seed=7).alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    assert Text(seed=7).alphabet(lower_case=False) == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

#Unit test for

# Generated at 2022-06-23 21:52:45.355366
# Unit test for constructor of class Text
def test_Text():
    """Test class."""
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import Person
    p = Person('ru')

    t = Text()
    assert t
    assert t != None
    assert t.text(quantity=1) != None
    assert t.title() != None
    assert t.level() != None
    assert t.sentence() != None
    assert t.word() != None
    assert t.swear_word() != None
    assert t.quote() != None

    regr = Text('ru')
    assert regr.provider == 'text' and regr.locale == 'ru'
    assert regr.level() != None
    assert regr.sentence() != None
    assert regr.quote() != None

# Generated at 2022-06-23 21:52:46.695920
# Unit test for method text of class Text
def test_Text_text():
    for _ in range(100):
        text = Text().text()
        assert isinstance(text, str)
        assert text.isalpha()


# Generated at 2022-06-23 21:52:57.786765
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text)
    assert isinstance(t.alphabet(), list)
    assert isinstance(t.level(), str)
    assert isinstance(t.text(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.title(), str)
    assert isinstance(t.words(), list)
    assert isinstance(t.word(), str)
    assert isinstance(t.swear_word(), str)
    assert isinstance(t.quote(), str)
    assert isinstance(t.color(), str)
    assert isinstance(t.hex_color(), str)
    assert isinstance(t.rgb_color(), tuple)
    assert isinstance(t.answer(), str)

# Generated at 2022-06-23 21:53:00.849569
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    assert len(text.words()) == 5
    assert isinstance(text.words(), list)


# Generated at 2022-06-23 21:53:01.978498
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != ""


# Generated at 2022-06-23 21:53:05.183071
# Unit test for method quote of class Text
def test_Text_quote():
    # this test is unit test for method quote of class Text in file text.py
    print("Test Text.quote")
    T = Text()
    print(T.quote())


# Generated at 2022-06-23 21:53:06.930758
# Unit test for method words of class Text
def test_Text_words():
    provider = Text()
    words = provider.words()
    assert len(words) == 5


# Generated at 2022-06-23 21:53:09.007051
# Unit test for method color of class Text
def test_Text_color():
    """Tests method color of class Text."""
    t = Text()
    assert t.color() in t._data['color']



# Generated at 2022-06-23 21:53:11.398355
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    value = Text().alphabet()
    print("Result of method 'alphabet' of class Text:")
    print("Value = ", value)
    print("\n")


# Generated at 2022-06-23 21:53:14.011336
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for method hex_color of class Text.

    This method is used for checking the correctness
    of method hex_color of class Text.
    """
    text = Text()
    hex_color = text.hex_color()
    assert type(hex_color) == str


# Generated at 2022-06-23 21:53:18.073014
# Unit test for method quote of class Text
def test_Text_quote():
    # initialize a class
    obj = Text()
    # get a random quote from movie
    quote = obj.quote()
    # check the length of the string
    # to get the quote in a random language
    assert len(quote) > 0

# Generated at 2022-06-23 21:53:19.203563
# Unit test for method title of class Text
def test_Text_title():
    x = Text()
    print(x.title())

# Generated at 2022-06-23 21:53:19.855537
# Unit test for method words of class Text
def test_Text_words():
    assert Text().words() == Text().words()

# Generated at 2022-06-23 21:53:22.862569
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    try:
        text.level()
    except NotImplementedError:
        assert False, "Method level of class Text is not implemented"
    assert text.level(), "Method level of class Text is not implemented"

# Generated at 2022-06-23 21:53:24.040242
# Unit test for constructor of class Text
def test_Text():
  txt = Text()
  assert isinstance(txt,Text)


# Generated at 2022-06-23 21:53:26.076703
# Unit test for method text of class Text
def test_Text_text():

    t = Text()
    text = t.text()
    assert type(text) is str
    assert len(text) > 0


# Generated at 2022-06-23 21:53:27.472544
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.hex_color())

# Generated at 2022-06-23 21:53:29.078571
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    s = text.word()
    assert(isinstance(s, str))

# Generated at 2022-06-23 21:53:30.450061
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass


# Generated at 2022-06-23 21:53:40.538513
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text"""
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    
    # Instantiate class
    rus_text = Text(locale='ru')
    rus_spec = RussiaSpecProvider(seed=12345)
    
    # Get data
    gender_list = [Gender.MALE, Gender.FEMALE]
    test_list = []
    for gender in gender_list:
        rus_spec.set_gender(gender)
        test_list.append(rus_text.quote())

    # unit test

# Generated at 2022-06-23 21:53:44.394435
# Unit test for method words of class Text
def test_Text_words():
    text_obj = Text(seed=0)
    words = text_obj.words()
    
    res_words = ['science', 'network', 'god', 'octopus', 'love']
    
    assert words == res_words


# Generated at 2022-06-23 21:53:46.303137
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert len(text.title()) > 0

# Generated at 2022-06-23 21:53:50.813729
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    x = t.title()
    if not isinstance(x, str):
        raise Exception("Text.title() not return str")
    if len(x) < 4:
        raise Exception("Text.title() not return str len > 4")


# Generated at 2022-06-23 21:53:54.528336
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Locale : "en"
    text = Text(locale='en')
    result = text.sentence()
    assert result in text._data['text'], "Incorrect result"


# Generated at 2022-06-23 21:53:56.851153
# Unit test for method level of class Text
def test_Text_level():
    text = Text('en')
    level = text.level()
    assert isinstance(level, str)


# Generated at 2022-06-23 21:53:59.102415
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test for method swear_word of class Text."""
    text = Text()
    swear_word = text.swear_word()
    assert isinstance(swear_word, str)



# Generated at 2022-06-23 21:54:02.262892
# Unit test for method color of class Text
def test_Text_color():
    """Unit test case for method color of class Text"""
    a = Text()
    assert a.color() in a._data['color']

# Generated at 2022-06-23 21:54:04.014011
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text
    text = Text()
    result = text.quote()
    assert result == "Bond... James Bond."

# Generated at 2022-06-23 21:54:05.587363
# Unit test for method word of class Text
def test_Text_word():
    t = Text('en')
    assert t.word() in t._data['words']['normal']

# Generated at 2022-06-23 21:54:07.206802
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())

# Generated at 2022-06-23 21:54:10.140298
# Unit test for method answer of class Text
def test_Text_answer():
    """Test for checking answer method of class Text"""
    text = Text()
    result = text.answer()
    print("Answer is: {0}".format(result))


# Generated at 2022-06-23 21:54:11.202918
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    print(text.words())

# Generated at 2022-06-23 21:54:11.695218
# Unit test for constructor of class Text
def test_Text():
    t = Text()

# Generated at 2022-06-23 21:54:12.418978
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    print(t.title())

# Generated at 2022-06-23 21:54:13.697663
# Unit test for method title of class Text
def test_Text_title():
    """Tests for method title of class Name"""
    s = Text()
    assert isinstance(s.title(), str)

# Generated at 2022-06-23 21:54:14.857909
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    print(text.level())


# Generated at 2022-06-23 21:54:16.425156
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    for _ in range(10):
        print(text.word())


# Generated at 2022-06-23 21:54:17.961654
# Unit test for method level of class Text
def test_Text_level():
    provider = Text()
    ans = provider.level()
    assert isinstance(ans, str)


# Generated at 2022-06-23 21:54:26.934674
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Perform unit test to check if the output
    is valid hex color.
    """
    logger = logging.getLogger()
    logger.info('Unit testing method hex_color of class Text')
    text = Text(seed=0)
    result = text.hex_color()
    logger.info('Testing if the output is valid hex color')
    assert len(result) == 7
    assert result.startswith('#')
    for c in result:
        if c != '#':
            assert c in '0123456789abcdefABCDEF'
    logger.info('Testing is finished successfully.')
    logger.info('Unit test for method hex_color of class Text finished')


# Generated at 2022-06-23 21:54:27.767273
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    answer = t.quote()
    assert isinstance(answer, str)

# Generated at 2022-06-23 21:54:28.592901
# Unit test for method text of class Text
def test_Text_text():
    # Get a random text
    print(Text().text())

# Generated at 2022-06-23 21:54:31.110832
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text
    import re
    t = Text()
    q = t.quote()
    assert re.match(r'^".*"$', q), 'result of quote should starts with " and ends with " '

# Generated at 2022-06-23 21:54:32.497540
# Unit test for method text of class Text
def test_Text_text():
    textTest = Text()
    res = textTest.text()
    expected = 'Maybe the right person needs to come along.'
    assert  expected == res

# Generated at 2022-06-23 21:54:44.068528
# Unit test for method quote of class Text
def test_Text_quote():
    text1 = Text(seed=1)
    text2 = Text(seed=2)
    text3 = Text(seed=1)
    assert text1.quote() == "I'm going to make him an offer he can't refuse."
    assert text2.quote() == "You don't understand! I coulda had class. I coulda been a contender. I could've been somebody, instead of a bum, which is what I am."
    assert text3.quote() == "I'm going to make him an offer he can't refuse."
    assert text1.quote() != "You don't understand! I coulda had class. I coulda been a contender. I could've been somebody, instead of a bum, which is what I am."
    assert text2.quote() != "I'm going to make him an offer he can't refuse."


# Generated at 2022-06-23 21:54:45.636438
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    p = Text()
    assert str(p.hex_color()) != "0x000000"


# Generated at 2022-06-23 21:54:51.204633
# Unit test for method word of class Text
def test_Text_word():
    """Test text word method."""
    import sqlite3 as dbapi
    import pandas as pd
    # create connection
    connection = dbapi.connect(
        "test.sqlite")
    """
        We create a table called Text_word where we will add records of method test_word
    """
    df = pd.read_sql_query("select * from tableTextWord", connection)
    df.to_csv("tableTextWord.csv", index=False)
    # we close the connection
    connection.close()


# Generated at 2022-06-23 21:54:52.110985
# Unit test for method word of class Text
def test_Text_word():
    text_word_provider = Text()
    assert len(text_word_provider.word()) <= 7
 # Unit test for method sentence of class Text

# Generated at 2022-06-23 21:54:55.096054
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color
    assert isinstance(color, str)
    assert text.color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 21:54:56.247635
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert len(t.level()) > 0

# Generated at 2022-06-23 21:54:59.033930
# Unit test for method answer of class Text
def test_Text_answer():
    # GIVEN
    text_pattern = "text"
    text = Text(locale=text_pattern)
    # WHEN
    answer = text.answer()
    # THEN
    assert answer in text.answers
    assert text_pattern in answer


# Generated at 2022-06-23 21:55:02.642633
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Quantity
    from random import seed
    seed()
    text = Text()
    quantity = Quantity.NORMAL
    result = text.words(quantity=quantity)
    assert len(result) == quantity


# Generated at 2022-06-23 21:55:08.329368
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    # Create instance of class Text
    text = Text('en')
    result = text.word() # Get a random word from class Text
    if isinstance(result, str):
        print("Test Text.word() - Successful") # Successful
    else:
        print("Test Text.word() - Failed") # Failed


# Generated at 2022-06-23 21:55:11.217285
# Unit test for method word of class Text
def test_Text_word():
    for _ in range(10):
        # word = Text().word()
        word = Text(seed=14393).word()
        # print(word)
        assert word is not None


# Generated at 2022-06-23 21:55:18.376405
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locales
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.base import BaseDataProvider


# Generated at 2022-06-23 21:55:20.582137
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    result = True
    for _ in range(100):
        color = Text().rgb_color()
        if not color[0] <= 255 and color[1] <= 255 and color[2] <= 255:
            result = False
    assert result == True


# Generated at 2022-06-23 21:55:22.402054
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=12345)
    assert text.title() == 'Телефон в доме'

# Generated at 2022-06-23 21:55:24.268635
# Unit test for constructor of class Text
def test_Text():
    t = Text(seed=2)
    print(t.alphabet(lower_case=False))
    print(t.alphabet(lower_case=True))


# Generated at 2022-06-23 21:55:26.495415
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=42)
    for i in range(10):
        assert text.level() == "low"


# Generated at 2022-06-23 21:55:36.640896
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import DataFields
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.text import Text

    t = Text('en')
    data = t._data[DataFields.TEXT.value]

    assert isinstance(t.text(), str)
    assert t.text() in data
    assert len(t.text().split(' ')) > 1

    assert isinstance(t.text(quantity=3), str)
    assert len(t.text().split(' ')) > 1

    with NonEnumerableError():
        t.text(quantity=0)



# Generated at 2022-06-23 21:55:39.219736
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of class Text."""
    text = Text()
    assert type(text.swear_word()) is str
    assert len(text.swear_word()) > 0



# Generated at 2022-06-23 21:55:45.340962
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Language
    answer_ = Text('en')
    assert answer_.answer() in ['Yes', 'No']
    answer_ = Text(None, seed=42)
    assert answer_.answer() in ['Yes', 'No']
    answer_ = Text(Language.ENGLISH, seed=42)
    assert answer_.answer() in ['Yes', 'No']



# Generated at 2022-06-23 21:55:48.546652
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Hex color code, w/ default safe=False
    print(Text().hex_color())


# Generated at 2022-06-23 21:55:50.431133
# Unit test for constructor of class Text
def test_Text():
    t = Text('en')
    assert t.__class__.__name__ == 'Text'




# Generated at 2022-06-23 21:55:56.497377
# Unit test for method answer of class Text
def test_Text_answer():
    expected = {'en': ['Yes', 'No', 'Maybe'],
                'ru': ['Да', 'Нет', 'Возможно']}
    t = Text('en')
    assert t.answer() in expected['en']
    assert t.answer() in expected['en']
    t = Text('ru')
    assert t.answer() in expected['ru']
    assert t.answer() in expected['ru']


# Generated at 2022-06-23 21:55:57.781315
# Unit test for method title of class Text
def test_Text_title():
    test_title = Text()
    test_title.title()


# Generated at 2022-06-23 21:56:00.576797
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # get object of class Text
    t = Text()

    # get random swear word
    a = t.swear_word()
    assert type(a) == str


# Generated at 2022-06-23 21:56:03.969733
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Gender
    village = Text(lang='en', gender=Gender.FEMALE)
    print(village.swear_word())


# Generated at 2022-06-23 21:56:05.033305
# Unit test for method words of class Text
def test_Text_words():
    results = Text().words(quantity=1);
    assert (results) != None

# Generated at 2022-06-23 21:56:12.345240
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Locales


    t = Text(locale=Locales.EN)
    print(t.level())
    print(t.text())
    print(t.words())
    print(t.word())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())
    print(t.swear_word())
    print(t.alphabet())

# Generated at 2022-06-23 21:56:14.689732
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert len(alphabet) > 0
    assert isinstance(alphabet, list)



# Generated at 2022-06-23 21:56:21.548247
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    assert isinstance(rgb, tuple), f"{rgb} is not tuple"
    assert len(rgb) == 3, f"{rgb} length is not 3"
    assert isinstance(rgb[0], int), f"{rgb[0]} is not integer"
    assert isinstance(rgb[1], int), f"{rgb[1]} is not integer"
    assert isinstance(rgb[2], int), f"{rgb[2]} is not integer"


# Generated at 2022-06-23 21:56:23.284791
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in ['critical', 'emergency']

# Generated at 2022-06-23 21:56:30.596556
# Unit test for method text of class Text
def test_Text_text():
    t = Text(seed=123)
    assert t.text(8) == 'Aenean condimentum sit amet.' \
                        ' Donec in consequat massa.' \
                        ' Etiam est magna.' \
                        ' Sed ultrices commodo imperdiet.' \
                        ' Curabitur non dignissim sem.' \
                        ' Ut turpis velit.' \
                        ' Nam at bibendum mi.' \
                        ' Nulla egestas elit in nunc ultrices, quis eleifend nunc' \
                        ' pharetra. Fusce quis tincidunt diam. Duis nec venenatis odio.'

# Generated at 2022-06-23 21:56:33.807034
# Unit test for method quote of class Text
def test_Text_quote():
    def test_returns_quote_string():
        assert isinstance(Text().quote(), str)

    def test_only_one_newline_char():
        quote = Text().quote()
        assert quote.count('\n') == 1

# Generated at 2022-06-23 21:56:35.886548
# Unit test for method level of class Text
def test_Text_level():
    my_level = Text()
    level = my_level.level()
    assert level in my_level._data['level']
    assert isinstance(level, str)


# Generated at 2022-06-23 21:56:37.458540
# Unit test for method word of class Text
def test_Text_word():
    t = Text(seed=4)
    assert t.word() == 'science'


# Generated at 2022-06-23 21:56:40.824773
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'
    assert Text().alphabet(lower_case=True) != 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-23 21:56:43.014667
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text(seed=1)
    assert t.hex_color() == '#d8346b'

# Generated at 2022-06-23 21:56:45.010142
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    print(text.answer())


# Generated at 2022-06-23 21:56:47.363764
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())
    print(t.rgb_color(True))


# Generated at 2022-06-23 21:56:51.914814
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    try:
        assert callable(getattr(t, "answer"))
    except AssertionError:
        print("Method \"answer\" not found in class Text")
        quit()
    try:
        assert isinstance(t.answer(), str)
    except AssertionError:
        print("Return value of method \"answer\" is not string")
        quit()


# Generated at 2022-06-23 21:56:59.873653
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text('en')

    color = t.rgb_color(safe=True)
    assert isinstance(color, tuple)
    assert len(color) == 3
    assert 0 <= color[0] <= 255
    assert 0 <= color[1] <= 255
    assert 0 <= color[2] <= 255

    color = t.rgb_color(safe=False)
    assert isinstance(color, tuple)
    assert len(color) == 3
    assert 0 <= color[0] <= 255
    assert 0 <= color[1] <= 255
    assert 0 <= color[2] <= 255


# Generated at 2022-06-23 21:57:03.147801
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(seed=12345)
    assert text.answer() == 'No'
    assert text.answer() == 'Yes'
    assert text.answer() == 'No'
    assert text.answer() == 'Yes'
    assert text.answer() == 'Yes'


# Generated at 2022-06-23 21:57:04.927424
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale

    text = Text(locale=Locale.EN)
    assert isinstance(text.title(), str)

# Generated at 2022-06-23 21:57:05.460019
# Unit test for method answer of class Text
def test_Text_answer():
    Text().answer()

# Generated at 2022-06-23 21:57:07.791454
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import RussiaSpecProvider

    t = Text(RussiaSpecProvider)

    assert t.answer() in t._data['answers']

# Generated at 2022-06-23 21:57:11.905596
# Unit test for method quote of class Text
def test_Text_quote():
    import pytest
    from mimesis.exceptions import NonEnumerableError

    text = Text('ru')
    result = text.quote()
    assert isinstance(result, str)

    # Test with invalid locale
    with pytest.raises(NonEnumerableError):
        Text('bla').quote()

# Generated at 2022-06-23 21:57:14.778593
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    t = text.level()
    assert isinstance(t, str)
    assert len(t) > 0


# Generated at 2022-06-23 21:57:16.730286
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text of class Text."""
    t = Text()
    text = t.text()


# Generated at 2022-06-23 21:57:17.992918
# Unit test for method level of class Text
def test_Text_level():
    data=Text(seed=12345)
    level = data.level()
    assert level == 'warn'


# Generated at 2022-06-23 21:57:20.523208
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())
    print(t.text())

if __name__ == '__main__':
    test_Text_quote()

# Generated at 2022-06-23 21:57:23.399545
# Unit test for constructor of class Text
def test_Text():
    for i in range(4):
        provider = Text()
        result = provider.ru()
        assert result == 'ru'


# Generated at 2022-06-23 21:57:24.828964
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    for i in Text().alphabet(False):
        print(i)

    print(len(Text().alphabet(False)))



# Generated at 2022-06-23 21:57:26.604431
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    for i in range (0, 10):
        print(text.rgb_color())

# Generated at 2022-06-23 21:57:31.247594
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ('Yes', 'No')
    assert text.answer() in ('Yes', 'No')
    assert text.answer() in ('Yes', 'No')
    assert text.answer() in ('Yes', 'No')


# Generated at 2022-06-23 21:57:35.353503
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.data import DATA_DIR
    import json

    path = DATA_DIR / 'text.json'
    with open(path) as f:
        en_text = json.load(f)

    t = Text('en')
    assert t.color() in en_text['color']

# Generated at 2022-06-23 21:57:37.659327
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert isinstance(text.word(), str)
    assert len(text.word()) >= 4

# Generated at 2022-06-23 21:57:38.765979
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word1 = text.word()
    word2 = text.word()
    assert word1 != word2


# Generated at 2022-06-23 21:57:40.728097
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    data = text.rgb_color()
    assert len(data) == 3


# Generated at 2022-06-23 21:57:42.284857
# Unit test for method answer of class Text
def test_Text_answer():
	text = Text('en')
	answer = text.answer()
	assert answer in ('Yes', 'No')

# Generated at 2022-06-23 21:57:44.672528
# Unit test for method words of class Text
def test_Text_words():
	text = Text()
	assert len(text.words()) == 5
	assert isinstance(text.words(), list)


# Generated at 2022-06-23 21:57:47.243887
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    c1 = text.color()
    c2 = text.color()
    assert c1 != c2

# Generated at 2022-06-23 21:57:51.132860
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(False)) == 7
    assert len(text.hex_color(True)) == 7

# Generated at 2022-06-23 21:57:52.822857
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert type(color) is str


# Generated at 2022-06-23 21:57:56.630128
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    rgb = t.rgb_color()
    assert rgb >= (0, 0, 0)
    assert rgb <= (255, 255, 255)

# Generated at 2022-06-23 21:57:58.534677
# Unit test for method word of class Text
def test_Text_word():
    provider = Text(seed=1000)
    result = provider.word()
    assert result == 'science'

# Generated at 2022-06-23 21:57:59.963707
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    words = text.text(5)
    print(words)

# Generated at 2022-06-23 21:58:01.623750
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']

# Generated at 2022-06-23 21:58:05.217960
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    data = Text(random.random())
    assert isinstance(data.alphabet(), list)
    assert isinstance(data.alphabet(lower_case=True), list)
    assert isinstance(data.alphabet(), list)
    
    

# Generated at 2022-06-23 21:58:09.739635
# Unit test for method quote of class Text
def test_Text_quote():
    text_a = Text()
    text_a.seed(0)
    text_a.quote() == "I'll be back."

    text_b = Text()
    text_b.seed(1)
    text_b.quote() == "In just a few hours, this island will be the home of the most remarkable theme park on Earth. Jurassic Park!"


# Generated at 2022-06-23 21:58:13.219717
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print("\n==== START TESTS FOR Text.rgb_color() ====")
    t = Text()
    count = 10
    safe = True
    for i in range(count):
        color = t.rgb_color(safe)
        print(color)
    print("==== END TESTS ====")


# Generated at 2022-06-23 21:58:16.302544
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from random import randint
    if randint(0, 1000000000000000000000000000000000000000000000000) == 0:
        raise Exception()
    else:
        Text().hex_color()



# Generated at 2022-06-23 21:58:20.477490
# Unit test for method words of class Text
def test_Text_words():
    # The number of words in the list of words is determine by the parameter quantity
    # This test checks if the size of the list is the same as the quantity parameter
    assert len(Text().words())==5
    assert len(Text().words(quantity=10))==10




# Generated at 2022-06-23 21:58:22.413005
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7


# Generated at 2022-06-23 21:58:24.034381
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    words = t.words(2)
    print(words)


# Generated at 2022-06-23 21:58:28.472591
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.data import SAFE_COLORS

    text = Text()
    quote = text.quote()
    assert quote in text._data['quotes']

    paragraphs = text.quote(quantity=7)
    assert len(paragraphs.split(' ')) == 7


# Generated at 2022-06-23 21:58:31.225010
# Unit test for method sentence of class Text
def test_Text_sentence():
    textProvider = Text()
    sentence = textProvider.sentence()
    assert type(sentence) == str


# Generated at 2022-06-23 21:58:32.986114
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-23 21:58:40.270507
# Unit test for method text of class Text
def test_Text_text():
    import random
    random.seed(123);
    text = Text()
    result = text.text()

# Generated at 2022-06-23 21:58:42.084844
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.builtins import Text
    t = Text()
    assert t.level() in t._data['level']

# Generated at 2022-06-23 21:58:46.301390
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method 'level' of class Text."""
    assert Text().level() in [
        'critical',
        'vital',
        'important',
        'secondary',
    ]



# Generated at 2022-06-23 21:58:49.086957
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7
    assert hex_color.startswith('#')

# Generated at 2022-06-23 21:58:50.247491
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    pass


# Generated at 2022-06-23 21:58:51.682134
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5


# Generated at 2022-06-23 21:58:53.908767
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    t = text.title()
    assert t == 'Adaptive interactive policy'


# Generated at 2022-06-23 21:58:54.873818
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in ('Yes', 'No')

# Generated at 2022-06-23 21:58:56.465883
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result in ('critical','high','medium','low','all')

# Generated at 2022-06-23 21:58:57.451793
# Unit test for constructor of class Text
def test_Text():
    assert Text()

# Generated at 2022-06-23 21:59:02.626638
# Unit test for method color of class Text
def test_Text_color():
    # set up objects needed to test method
    t = Text()
    list = []
    # call the method
    result = t.color()
    # check the result against expected output
    # assert result == expected
    list.append(result)
    assert result in list
    assert result != "dog"
    assert result != 1
    # Unit test for method color of class Text

# Generated at 2022-06-23 21:59:06.127505
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert type(alphabet) == list
    assert len(alphabet) >= 26
    alphabet_lower = text.alphabet(True)
    assert type(alphabet_lower) == list
    assert len(alphabet_lower) >= 26


# Generated at 2022-06-23 21:59:11.641702
# Unit test for method answer of class Text
def test_Text_answer():
    """
    GIVEN class Text and method answer
    WHEN call method answer
    THEN method answer return answer in current language
    """
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    for lang in Language:
        instance = Text(language=lang)
        answer = instance.answer()
        assert isinstance(answer, str)



# Generated at 2022-06-23 21:59:13.167125
# Unit test for method color of class Text
def test_Text_color():
    text = Text('en')
    assert text.color() in text.all('color')


# Generated at 2022-06-23 21:59:18.636403
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text1 = Text()
    assert len(text1.hex_color()) == 7
    assert text1.hex_color().startswith('#')
    hex_one = text1.hex_color()
    hex_two = text1.hex_color()
    assert len(hex_one) == len(hex_two)
    assert len(set(hex_one)) != len(set(hex_two))


# Generated at 2022-06-23 21:59:20.333287
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    # Test for method color
    title = t.title()
    print(title)

# Generated at 2022-06-23 21:59:21.642150
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    sw = Text.swear_word()
    assert isinstance(sw, str)

# Generated at 2022-06-23 21:59:27.999323
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    class Result:
        correct = 0
        is_error = False

    text = Text('en')
    result = Result()

    def assert_Equals(expected: str, actual: str):
        if not expected == actual:
            result.is_error = True

    for _ in range(0, 100):
        hex_color = text.hex_color(safe = False)
        assert_Equals(len(hex_color), 7)
        assert_Equals(hex_color[0], '#')

    for _ in range(0, 100):
        hex_color = text.hex_color(safe = True)
        assert_Equals(len(hex_color), 7)
        assert_Equals(hex_color[0], '#')


# Generated at 2022-06-23 21:59:29.820366
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Languages
    locale = Languages.RU
    for seed in range(1, 3):
        provider = Text(locale=locale, seed=seed)
        txt = provider.text()
        assert txt



# Generated at 2022-06-23 21:59:32.217311
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color."""
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data["color"]

# Generated at 2022-06-23 21:59:37.265980
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    # Test whether the return value is a tuple
    assert isinstance(text.rgb_color(), tuple), 'Test whether the return value is a tuple'
    print('Test whether the return value is a tuple : Pass')
    # Test whether the return value is 3 tuple
    assert len(text.rgb_color()) == 3, 'Test whether the return value is 3 tuple'
    print('Test whether the return value is 3 tuple : Pass')
    print(text.rgb_color())

if __name__ == "__main__":
    test_Text_rgb_color()

# Generated at 2022-06-23 21:59:38.207030
# Unit test for method title of class Text
def test_Text_title():
    a = Text()
    assert type(a.title()) == str


# Generated at 2022-06-23 21:59:39.355583
# Unit test for method title of class Text
def test_Text_title():
    print('\ntest_Text_title')
    t = Text()
    print(t.title())


# Generated at 2022-06-23 21:59:41.240959
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Languages
    from mimesis.providers.text import Text

    x = Text(Languages.ENGLISH)
    for _ in range(10):
        print(x.level())



# Generated at 2022-06-23 21:59:44.996191
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text('en')
    assert t.swear_word() in ['damn', 'Darn', 'hell', 'dang']

# Generated at 2022-06-23 21:59:45.852747
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert all([isinstance(text.alphabet(), list), isinstance(text.alphabet(True), list)])



# Generated at 2022-06-23 21:59:47.965367
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None


# Generated at 2022-06-23 21:59:49.545176
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    quantity = 0
    result = text.words(quantity)



# Generated at 2022-06-23 21:59:50.932242
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) >= 2

# Generated at 2022-06-23 21:59:52.201635
# Unit test for method title of class Text
def test_Text_title():
    t = Text('ru')
    print(t.title())

# Generated at 2022-06-23 21:59:54.351034
# Unit test for method level of class Text
def test_Text_level():
    # unit test for Text.level()
    
    provider = Text()
    res = provider.level()
    
    assert res in provider._data['level']

# Generated at 2022-06-23 21:59:55.983024
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    res = text.alphabet()
    print(res)

if __name__ == '__main__':
    text = Text()
    res = text.alphabet()
    print(res)

# Generated at 2022-06-23 21:59:58.009374
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    _Text = Text()
    assert _Text.rgb_color() != _Text.rgb_color()


# Generated at 2022-06-23 21:59:59.049712
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())


# Generated at 2022-06-23 22:00:01.178088
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    for i in range(20):
        r = t.rgb_color()
        assert r >= 0
        assert r <= 0xFFFFFF

# Generated at 2022-06-23 22:00:04.077321
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print('\nMethod: word\n')
    print('The word is:', t.word())

# Generated at 2022-06-23 22:00:14.783926
# Unit test for method title of class Text
def test_Text_title():
    aText = Text()
    title = aText.title()

# Generated at 2022-06-23 22:00:17.626643
# Unit test for method text of class Text
def test_Text_text():
    """Test text() method of Text class."""
    text = Text()
    result = text.text()
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 22:00:19.005080
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert type(t.sentence()) == str


# Generated at 2022-06-23 22:00:21.107839
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    assert Text().level() in ['level one', 'level two', 'level three']

# Generated at 2022-06-23 22:00:23.045895
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    res = text.answer()
    assert(res in ['Yes', 'No', 'Maybe', None])



# Generated at 2022-06-23 22:00:24.600526
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=123)
    result = text.quote()
    assert result == "I have always counted myself a lucky man."


# Generated at 2022-06-23 22:00:26.842055
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())


# Generated at 2022-06-23 22:00:29.374122
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    x = Text()
    print(x.alphabet())
    print(x.alphabet(lower_case=True))


# Generated at 2022-06-23 22:00:31.755036
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print(text.alphabet())



# Generated at 2022-06-23 22:00:33.146801
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text()
    answer = provider.answer()
    assert answer == "Non"

# Generated at 2022-06-23 22:00:34.861881
# Unit test for method words of class Text
def test_Text_words():
    SIZE = 1
    text = Text()
    result = text.words()

    assert len(result) == SIZE

# Generated at 2022-06-23 22:00:36.945074
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert len(Text().hex_color()) == 7
    assert Text().hex_color()[0] == "#"


# Generated at 2022-06-23 22:00:38.151311
# Unit test for method word of class Text
def test_Text_word():
    assert len(Text('zh-CN').word()) > 0

# Generated at 2022-06-23 22:00:39.886119
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert type(text.text(1)) is str


# Generated at 2022-06-23 22:00:41.786146
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    print(title)


# Generated at 2022-06-23 22:00:44.142920
# Unit test for method text of class Text
def test_Text_text():
    generator = Text('en')
    text = generator.text(1)
    assert text == 'How do you feel about your current job?'

# Generated at 2022-06-23 22:00:46.918274
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    for i in range(10):
        assert len(t.rgb_color()) == 3
        assert len(t.rgb_color(safe=True)) == 3


# Generated at 2022-06-23 22:00:54.901338
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from pprint import pprint

    text = Text('en')
    print(text.rgb_color())
    print(text.rgb_color(safe=ColorType.PRIMARY))
    print(text.rgb_color(safe=ColorType.SECONDARY))
    print(text.rgb_color(safe=ColorType.SUCCESS))
    print(text.rgb_color(safe=ColorType.DANGER))
    print(text.rgb_color(safe=ColorType.WARNING))
    print(text.rgb_color(safe=ColorType.INFO))
    print(text.rgb_color(safe=ColorType.LIGHT))
    print(text.rgb_color(safe=ColorType.DARK))

# Generated at 2022-06-23 22:00:59.676585
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(1)) == 1
    assert len(t.words(2)) == 2
    assert len(t.words(3)) == 3
    assert len(t.words(4)) == 4
    assert len(t.words(5)) == 5

# Generated at 2022-06-23 22:01:02.088253
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    provider = Text()

    assert len(provider.hex_color()) == 7
    assert provider.hex_color().startswith('#')



# Generated at 2022-06-23 22:01:04.365510
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert (Text().rgb_color() != (0,0,0))


# Generated at 2022-06-23 22:01:06.143018
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None
    assert t._datafile == 'text.json'



# Generated at 2022-06-23 22:01:08.318606
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    result = len(t.words())
    assert result == 5


# Generated at 2022-06-23 22:01:09.217621
# Unit test for constructor of class Text
def test_Text():
    instance = Text()
    assert instance


# Generated at 2022-06-23 22:01:10.258749
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) > 0

# Generated at 2022-06-23 22:01:11.390356
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())


# Generated at 2022-06-23 22:01:15.119710
# Unit test for method level of class Text
def test_Text_level():
    # Spanish
    text = Text(locale='es')
    level = text.level()
    assert level in text._data['level']
    # German
    text = Text(locale='de')
    level = text.level()
    assert level in text._data['level']
    # Russian
    text = Text(locale='ru')
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-23 22:01:17.089350
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    pass


# Generated at 2022-06-23 22:01:18.429274
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-23 22:01:22.437084
# Unit test for method words of class Text
def test_Text_words():
    """Test for method words of class Text."""
    text = Text()
    data = text.words()
    assert isinstance(data, list)
    assert len(data) == 5
    data = text.words(quantity=10)
    #assert len(data) == 10


# Generated at 2022-06-23 22:01:23.918314
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    # word
    assert len(text.word())


# Generated at 2022-06-23 22:01:27.174218
# Unit test for method words of class Text
def test_Text_words():
    t = Text(seed=7)
    print('words: ',t.words(quantity=7))

# # Unit test for method word of class Text