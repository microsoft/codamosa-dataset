

# Generated at 2022-06-23 21:51:31.625995
# Unit test for method text of class Text
def test_Text_text():
    """Unit testing for the method text of class Text."""



# Generated at 2022-06-23 21:51:41.130499
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis import Generic
    from mimesis.enums import ColorNames
    from mimesis.exceptions import NonEnumerableError

    txt = Text()
    g = Generic('en')

    hex_safe = txt.hex_color(safe=True)
    hex_random = txt.hex_color()

    # Check that hex color starts with "#".
    assert hex_safe.startswith('#')
    assert hex_random.startswith('#')

    # Check that hex color contains six characters.
    assert len(hex_safe) == 7
    assert len(hex_random) == 7

    # Safe color should be in ColorNames Enum.
    assert any(hex_safe == color.value for color in ColorNames)

    # Check that random hex color is not in ColorNames Enum.

# Generated at 2022-06-23 21:51:45.019884
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.providers.text import Text
    t = Text('en')
    for i in range(10):
        print(t.hex_color())

# Generated at 2022-06-23 21:51:54.556527
# Unit test for method text of class Text
def test_Text_text():
    import datetime
    import uuid
    from mimesis.enums import Gender

    t = Text(seed = datetime.datetime.now())
    assert t.text() != t.text()

    t = Text(seed = 0)
    assert t.text() == t.text()

    t = Text(seed = 'test')
    assert t.text() == t.text()

    t = Text(seed = b'test')
    assert t.text() == t.text()

    t = Text(seed = [1,2,3])
    assert t.text() == t.text()

    t = Text(seed = 1.5)
    assert t.text() == t.text()

    t = Text(seed = uuid.uuid4())
    assert t.text() == t.text()


# Generated at 2022-06-23 21:51:56.256366
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text()
    assert type(text) == str


# Generated at 2022-06-23 21:51:58.006568
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)

# Generated at 2022-06-23 21:51:59.475699
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    alpha = Text().alphabet(True)
    assert alpha


# Generated at 2022-06-23 21:52:11.661019
# Unit test for method sentence of class Text

# Generated at 2022-06-23 21:52:22.257533
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test case: test_Text_hex_color"""
    text = Text()
    actual = text.hex_color()
    expected = '#'
    assert actual[0] == expected, "Wrong value"
    actual = text.hex_color()
    expected = '#'
    assert actual[0] == expected, "Wrong value"
    actual = text.hex_color()
    expected = '#'
    assert actual[0] == expected, "Wrong value"
    actual = text.hex_color()
    expected = '#'
    assert actual[0] == expected, "Wrong value"
    actual = text.hex_color()
    expected = '#'
    assert actual[0] == expected, "Wrong value"
    actual = text.hex_color()
    expected = '#'

# Generated at 2022-06-23 21:52:31.386177
# Unit test for method answer of class Text
def test_Text_answer():
    """Test for method answer of class Text."""
    from mimesis.enums import Locale
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider

    pr1 = Text(locale=Locale.RU)
    pr2 = Text(locale=Locale.EN)

    result1 = pr1.answer()
    result2 = pr2.answer()

    assert isinstance(result1, str)
    assert isinstance(result2, str)

    class TestClass(RussiaSpecProvider):
        """Class for testing the non-enumerable class."""

        def __init__(self, seed: int = None, formatter=None):
            super().__init__(seed=seed, formatter=formatter)

# Generated at 2022-06-23 21:52:32.774798
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert isinstance(t.quote(), str)

# Generated at 2022-06-23 21:52:41.281202
# Unit test for method color of class Text
def test_Text_color():
    from .text import Text
    from .enums import Gender
    from .generic import Generic
    from .science import Science
    from .utils import reify


    class UnitTest(Generic, Science, Text):
        @reify
        def locales(self):
            return ['en-GB']

        @reify
        def genders(self):
            return Gender

        def __init__(self, seed=None):
            super().__init__(seed=seed)

    text = UnitTest(seed=0)

    color = text.color()
    assert color == "red"

# Generated at 2022-06-23 21:52:45.390258
# Unit test for method word of class Text
def test_Text_word():
    t = Text('en')
    w = t.word()
    # Check that word is part of wordlist
    assert w in t._data['words'].get('normal')

# Generated at 2022-06-23 21:52:46.901808
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locales
    from mimesis.builtins import Text
    random_text = Text(Locales.EN)
    assert random_text.title() == 'The science'


# Generated at 2022-06-23 21:52:53.520608
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    text.alphabet() == ['A', 'B', 'C', 'D',
                        'E', 'F', 'G', 'H',
                        'I', 'J', 'K', 'L',
                        'M', 'N', 'O', 'P',
                        'Q', 'R', 'S', 'T',
                        'U', 'V', 'W', 'X',
                        'Y', 'Z']


# Generated at 2022-06-23 21:52:56.085323
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    n = text.quote()
    assert type(n) == str


# Generated at 2022-06-23 21:52:57.987225
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Locales
    text = Text(Locales.EN)
    print(text.answer())

# Generated at 2022-06-23 21:53:01.052455
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    res = t.sentence()
    assert isinstance(res, str)
    assert len(res) > 0
    

# Generated at 2022-06-23 21:53:06.370456
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    for i in range(10):
        assert len(t.hex_color()) == 7
        assert len(t.hex_color(safe=True)) == 7
        assert t.hex_color()[0] == '#'
        assert t.hex_color(safe=True)[0] == '#'


# Generated at 2022-06-23 21:53:09.939154
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    for _ in range(100):
        result = t.rgb_color()
        assert len(result) == 3
        for value in result:
            assert type(value) == int
            assert 0 <= value <= 255


# Generated at 2022-06-23 21:53:11.230243
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert isinstance(text.title(), str)


# Generated at 2022-06-23 21:53:13.623813
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    color = text.hex_color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:53:15.969573
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    color = text.rgb_color()
    assert len(color) == 3

# Generated at 2022-06-23 21:53:19.622934
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Color

    t = Text(RussiaSpecProvider)
    color = t.color()
    assert color in Color.values

# Generated at 2022-06-23 21:53:23.304118
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locales
    from mimesis.builtins import Text

    t = Text(locale=Locales.EN)
    levels = t.level()

    assert levels in ['critical', 'warning', 'normal', 'debug', 'info', 'success']



# Generated at 2022-06-23 21:53:25.557098
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words_list = t.words(quantity=10)
    assert len(words_list) == 10

    # Unit test for method word of class Text

# Generated at 2022-06-23 21:53:27.003379
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert type(t.level())

# Generated at 2022-06-23 21:53:28.684130
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text("tr")
    assert text.answer() in text._data['answers']



# Generated at 2022-06-23 21:53:32.354239
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text.
    :return: None
    """
    t = Text()
    rgb = t.rgb_color()
    assert type(rgb) == tuple

# Generated at 2022-06-23 21:53:33.524663
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    t.hex_color()

# Generated at 2022-06-23 21:53:34.543135
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.answer())

# Generated at 2022-06-23 21:53:35.157275
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    text.words()

# Generated at 2022-06-23 21:53:35.786239
# Unit test for method text of class Text
def test_Text_text():
    pass


# Generated at 2022-06-23 21:53:43.566668
# Unit test for constructor of class Text
def test_Text():
    t = Text()

    assert t is not None
    assert t.provider is not None
    assert t.random is not None
    assert t.datetime is not None
    assert t.meta is not None
    assert t.locales is not None
    assert t._data is not None
    assert t._data.get('language') is not None
    assert t._data.get('alphabet') is not None
    assert t._data.get('level') is not None
    assert t._data.get('text') is not None
    assert t._data.get('words') is not None
    assert t._data.get('quotes') is not None
    assert t._data.get('color') is not None
    assert t._data.get('answers') is not None


# Generated at 2022-06-23 21:53:46.623666
# Unit test for method color of class Text
def test_Text_color():
    # GIVEN
    provider = Text()

    # WHEN
    result = provider.color()

    # THEN
    assert isinstance(result, str) and result != ''


# Generated at 2022-06-23 21:53:48.347607
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-23 21:53:49.015446
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass

# Generated at 2022-06-23 21:53:51.493553
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print('Class Text, method word: ', t.word())


test_Text_word()

# Generated at 2022-06-23 21:53:59.664567
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.answer() in ['Yes', 'No']
    assert text.color() in ['Black', 'White', 'Red', 'Green', 'Blue']
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.sentence(), str)
    assert len(text.swear_word()) > 1
    assert len(text.text()) > 1
    assert isinstance(text.title(), str)
    assert len(text.word()) > 1
    assert len(text.words()) > 1

# Generated at 2022-06-23 21:54:01.977593
# Unit test for method answer of class Text
def test_Text_answer():
    ans = Text()
    assert ans.answer() in ['Yes', 'No']

# Generated at 2022-06-23 21:54:03.735365
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None
    assert text.seed is not None
    assert text.locale is not None


# Generated at 2022-06-23 21:54:13.764462
# Unit test for constructor of class Text
def test_Text():
    import unittest
    class my_test(unittest.TestCase):
        def setUp(self):
            self.t = Text('en')
        def test_color(self):
            self.assertEqual(self.t.color() in SAFE_COLORS, True)
        def test_hex_color(self):
            self.assertEqual(self.t.hex_color(True) in SAFE_COLORS, True)
        def test_rgb_color(self):
            self.assertEqual(len(self.t.rgb_color(True)), 3)
    unittest.main()

# Generated at 2022-06-23 21:54:17.626143
# Unit test for method quote of class Text
def test_Text_quote():
    """
    Unit test for method quote of class Text

    Test Cases:
    1) test_get_random_quote()
    """
    print("testing  method quote of class Text")
    t = Text()
    print(t.quote())
    return

if __name__ == "__main__":
    test_Text_quote()

# Generated at 2022-06-23 21:54:23.397096
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """ Unit test for method swear_word of class Text
    """
    my_text = Text()
    my_swear_word = my_text.swear_word()
    print(f"The swear word is {my_swear_word}")

    assert my_swear_word != None
    assert type(my_swear_word) == str
    assert len(my_swear_word) > 1


# Generated at 2022-06-23 21:54:24.733642
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert isinstance(t.answer(), str)

# Generated at 2022-06-23 21:54:26.459195
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer1 = text.answer()
    assert answer1 is not None


# Generated at 2022-06-23 21:54:29.536005
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locale
    from mimesis.text import Text
    t = Text(Locale.ENGLISH)
    print(t.sentence())
    # assert t.sentence() == 'cannot burn fuse'



# Generated at 2022-06-23 21:54:30.908335
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    r = t.alphabet()
    assert isinstance(r, list)


# Generated at 2022-06-23 21:54:31.883610
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    str = t.answer()
    assert 'No' == str

# Generated at 2022-06-23 21:54:32.460809
# Unit test for method word of class Text
def test_Text_word():
    assert Text().word()

# Generated at 2022-06-23 21:54:34.307135
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in ["critical","danger"]


# Generated at 2022-06-23 21:54:37.348008
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert title is not None and len( title ) > 0
    #print('title: ', title )



# Generated at 2022-06-23 21:54:42.098739
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    a = Text(seed=0)
    b = Text(seed=0)
    assert a.hex_color() == '#c6aafd'
    assert b.hex_color(safe=True) == '#9b59b6'


# Generated at 2022-06-23 21:54:45.248760
# Unit test for method words of class Text
def test_Text_words():
    t = Text('en')
    result = t.words()

    #Should return a list of 5 random words
    assert isinstance(result, list) and len(result) == 5 and isinstance(result[0], str)


# Generated at 2022-06-23 21:54:47.293546
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.text import Text
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-23 21:54:48.136988
# Unit test for method words of class Text
def test_Text_words():
    print(Text.Text().words())

# Generated at 2022-06-23 21:54:53.602360
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(1)) == 1
    assert len(t.words(2)) == 2
    assert len(t.words(3)) == 3
    assert len(t.words(4)) == 4
    assert len(t.words(5)) == 5
    assert len(t.words()) == 5


# Generated at 2022-06-23 21:54:55.476633
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-23 21:54:56.866931
# Unit test for constructor of class Text
def test_Text():
    # get text class
    my_text = Text()
    words = my_text.words()
    print(words)

# Generated at 2022-06-23 21:54:58.030328
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert len(text.level()) > 0

# Generated at 2022-06-23 21:55:02.795181
# Unit test for constructor of class Text
def test_Text():
    m = Text()
    assert m.provider == 'text'
    assert m.__name__ == 'Mimesis (text)'
    assert m.__version__ == '0.0.1'
    assert m.__package__ == 'mimesis.data'

# Unit test to check method alphabet()

# Generated at 2022-06-23 21:55:04.718853
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(quantity=6)) == 6

# Generated at 2022-06-23 21:55:09.405271
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    result = text.alphabet()
    assert isinstance(result, list)
    assert len(result) == 26
    result = text.alphabet(lower_case=True)
    assert isinstance(result, list)
    assert len(result) == 26



# Generated at 2022-06-23 21:55:11.565599
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert isinstance(t.level(), str)
    assert t.level() in t._data['level']


# Generated at 2022-06-23 21:55:14.841415
# Unit test for method title of class Text
def test_Text_title():
    # Create a instance of class Text
    text = Text()
    # Get a random title
    t = text.title()
    # Output
    print(t)


# Generated at 2022-06-23 21:55:18.866003
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t1 = Text()
    t2 = Text()
    t3 = Text()
    assert t1.hex_color() == '#9d8b2c'
    assert t2.hex_color() == '#2ddcc2'
    assert t3.hex_color() == '#17b061'

# Generated at 2022-06-23 21:55:21.480301
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    for i in range(10):
        text = Text(Locale.CHINESE)
        print(text.level())

# Generated at 2022-06-23 21:55:22.716326
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.builtins import EN
    return EN.Text().swear_word()

# Generated at 2022-06-23 21:55:27.220265
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert len(Text().alphabet(True)) == 26
    assert Text().alphabet(True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 21:55:30.310548
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert isinstance(t.swear_word(), str)


# Generated at 2022-06-23 21:55:34.656794
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text._rgb_color(safe=True)
    assert isinstance(rgb_color, tuple), "Not a valid data type"
    assert len(rgb_color) == 3, "Not a valid data type"
    print(rgb_color)


# Generated at 2022-06-23 21:55:37.022291
# Unit test for method word of class Text
def test_Text_word():
    a = Text()
    b = a.word()
    c = b.split(' ')
    assert len(c) == 1


# Generated at 2022-06-23 21:55:45.736929
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # An English alphabet
    data = Text('en')
    assert len(data.alphabet()) == 26, "Number of English letters is 26"
    assert len(data.alphabet(lower_case=True)) == 26, "Number is the same"

    # A Cyrillic alphabet
    data = Text('ru')
    assert len(data.alphabet()) == 33, "Number of Russian letters is 33"
    assert len(data.alphabet(lower_case=True)) == 33, "Number is the same"


# Generated at 2022-06-23 21:55:48.711666
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() == Text().text() and Text().text() != Text().text()


# Generated at 2022-06-23 21:55:51.563548
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=123)
    answer = text.quote()
    assert answer == 'I\'m going to make him an offer he can\'t refuse.'


# Generated at 2022-06-23 21:55:51.981303
# Unit test for constructor of class Text
def test_Text():
    assert Text()

# Generated at 2022-06-23 21:55:53.809437
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-23 21:55:54.421646
# Unit test for method sentence of class Text
def test_Text_sentence():
    pass

# Generated at 2022-06-23 21:55:56.672727
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    answer = text.answer()
    assert answer in ['Нет', 'Да']

# Generated at 2022-06-23 21:55:59.254253
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    result = text.swear_word()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:56:01.580183
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    text = Text(Locale.EN)
    assert isinstance(text.title(), str)

# Generated at 2022-06-23 21:56:13.918850
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.text import Text
    for _ in range(5):
        person = Person('es')
        text = Text('es')
        assert not person.full_name() in text.quote()
        assert not person.occupation() in text.quote()
        assert not str(person.age()) in text.quote()
        assert not str(person.birthday()) in text.quote()
        assert not person.blood_type() in text.quote()
        assert not person.gender(gender=Gender.FEMALE) in text.quote()
        assert not person.gender(gender=Gender.MALE) in text.quote()
        assert not person.gender(gender=Gender.NOT_KNOWN) in text.quote()

# Generated at 2022-06-23 21:56:21.183521
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    # Initiate class
    text = Text(seed=0)
    # Call method under test
    alphabet = text.alphabet()
    # Method under test should return a list of length 26
    assert isinstance(alphabet, list)
    assert len(alphabet) == 26

    # Test locale
    text = Text(seed=0, locale=Locale.RU)
    alphabet = text.alphabet()
    assert isinstance(alphabet, list)
    assert len(alphabet) == 33



# Generated at 2022-06-23 21:56:30.699593
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import mimesis
    t = mimesis.Text()

# Generated at 2022-06-23 21:56:32.439801
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text('ru')
    print(t.swear_word())


# Generated at 2022-06-23 21:56:34.165189
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    testObj = Text.swear_word()
    print(testObj)



# Generated at 2022-06-23 21:56:35.813680
# Unit test for method answer of class Text
def test_Text_answer():
    pt = Text()

    answer = pt.answer()

    assert isinstance(answer, str)


# Generated at 2022-06-23 21:56:37.379594
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    q = t.quote()
    assert q in t._data['quotes']

# Generated at 2022-06-23 21:56:39.617025
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']


# Generated at 2022-06-23 21:56:40.623118
# Unit test for method quote of class Text
def test_Text_quote():
    Text().quote()
    

# Generated at 2022-06-23 21:56:43.235373
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    print(t.alphabet(False))
    print(t.alphabet(True))


# Generated at 2022-06-23 21:56:46.027072
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.alphabet(True), list)


# Generated at 2022-06-23 21:56:48.335580
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    for x in range(0, 10):
        ans = t.quote().strip()
        assert ans != ''



# Generated at 2022-06-23 21:56:50.749024
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sentence = t.sentence()
    if sentence is None:
        raise Exception('sentence is None')
    print(sentence)


# Generated at 2022-06-23 21:56:54.351137
# Unit test for method quote of class Text
def test_Text_quote():
    """Test for method quote of class Text."""
    from mimesis.enums import Locale

    t = Text(locale=Locale.EN)

    assert len(t.quote()) > 0



# Generated at 2022-06-23 21:56:56.309552
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text"""
    print(Text().swear_word())


# Generated at 2022-06-23 21:56:56.962380
# Unit test for method words of class Text
def test_Text_words():
	pass


# Generated at 2022-06-23 21:56:58.138980
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text()
    example = provider.quote()
    assert len(example) > 0


# Generated at 2022-06-23 21:57:02.550820
# Unit test for method words of class Text
def test_Text_words():
    import os
    import mimesis
    import json

    text_data_dir = os.path.join(os.path.dirname(mimesis.__file__), 'data')
    text_data_path = os.path.join(text_data_dir, 'text.json')

    with open(text_data_path, 'r', encoding='utf-8') as file:
        data = json.load(file)

    words = data['words']['normal']

    generator = mimesis.Generic('en')
    words_list = generator.text.words(quantity=5)

    assert len(words_list) == 5

    for word in words_list:
        assert word in words

# Generated at 2022-06-23 21:57:03.289882
# Unit test for method text of class Text
def test_Text_text():
    pass

# Generated at 2022-06-23 21:57:05.819090
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert len(Text().hex_color(safe=False)) == 7
    assert Text().hex_color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 21:57:07.073010
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())


# Generated at 2022-06-23 21:57:09.603024
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.builtins import US
    text_data = Text(US)

    assert(isinstance(text_data.alphabet(), list))
    assert(text_data.alphabet())


# Generated at 2022-06-23 21:57:15.921680
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert t.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert len(t.alphabet(lower_case=True)) == 26
    assert t.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 21:57:20.104204
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    ''' Test method Text.rgb_color()
    '''
    t = Text()
    # print("\nRGB color tuple:", t.rgb_color())
    assert len(t.rgb_color()) == 3
    assert len(str(t.rgb_color())) == 11


# Generated at 2022-06-23 21:57:22.677573
# Unit test for constructor of class Text
def test_Text():
    print("Constructor test")
    t = Text()
    assert isinstance(t, Text)


# Generated at 2022-06-23 21:57:24.589006
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis import Text
    t=Text()
    assert isinstance(t.sentence(), str)


# Generated at 2022-06-23 21:57:29.043896
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    text = Text('en', gender=Gender.MALE)
    data = text.quote()
    # print(data)
    assert isinstance(data, str) and len(data)>0


# Generated at 2022-06-23 21:57:31.518169
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert "#d8346b" == hex_color


# Generated at 2022-06-23 21:57:35.972591
# Unit test for constructor of class Text
def test_Text():
    n = Text()
    n.seed(0)
    n.text(quantity=2)
    assert n.text(quantity=2) == 'The Bond films are the longest-running film series in history, having been in on-going production from 1962 to the present (with a six-year hiatus between 1989 and 1995). In that time Eon Productions has produced 24 films, most of them at Pinewood Studios.'


# Generated at 2022-06-23 21:57:43.910069
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    dic = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert len(t.alphabet(lower_case=False)) == len(dic)
    assert t.alphabet(lower_case=False) == dic


# Generated at 2022-06-23 21:57:45.185405
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    provider = Text()
    assert not provider.hex_color().startswith('#')

## Unit test for method rgb_color of class Text

# Generated at 2022-06-23 21:57:47.422480
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    result = text.words()
    assert result is not None
    assert isinstance(result, list)
    assert result != []

# Generated at 2022-06-23 21:57:49.935907
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=20000)
    assert text.text(quantity=5) == "Science network god octopus love."

# Generated at 2022-06-23 21:57:51.917402
# Unit test for method color of class Text
def test_Text_color():
    s = Text(seed=984)
    assert s.color() == "red"

# Generated at 2022-06-23 21:57:58.566822
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.providers.text import Text
    from mimesis.enums import PersonGender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.localization import RU
    from mimesis.exceptions import UnsupportedLanguageError
    from mimesis.locales import get_locale
    from mimesis.builtins import UnitedStatesSpecProvider
    from mimesis.exceptions import ProviderNotFoundError
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Language
    from mimesis.exceptions import FieldValueNotFoundError
    from mimesis.builtins import Person
    from mimesis.builtins import GermanySpecProvider
    from mimesis.builtins import FranceSpecProvider
    from mimesis.builtins import SpainSpecProvider

# Generated at 2022-06-23 21:58:01.409877
# Unit test for method color of class Text
def test_Text_color():
    # Init and generate color
    text = Text(locale='ru')
    color = text.color()
    # Check if color correspond to standart
    assert color in text._data['color']

# Generated at 2022-06-23 21:58:04.229392
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Initialize an object of class Text
    text = Text()
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)

# Generated at 2022-06-23 21:58:05.250679
# Unit test for method title of class Text
def test_Text_title():
    assert Text.title() != ''

# Generated at 2022-06-23 21:58:13.555838
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider,  Text
    t = Text(locale='ru')
    t1 = Text()
    assert t.text(5) == t1.text(5)
    for _ in range(100):
        assert t.text(1) != t.text(2)
        assert isinstance(t.text(1), str)
        assert len(t.text(1)) > 0
    t2 =  Text(seed=123456)
    assert 'Подорожание цен на основные продукты' == t2.text(1)



# Generated at 2022-06-23 21:58:18.125690
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=123)
    assert t.color() == 'red'
    assert t.color() == 'green'
    assert t.color() == 'red'
    assert t.color() == 'blue'
    assert t.color() == 'orange'


# Generated at 2022-06-23 21:58:21.782786
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()
    hex_color = provider.hex_color()
    assert len(hex_color) == 7 and hex_color[0] == '#'
    assert provider.color() in provider._data['color']


# Generated at 2022-06-23 21:58:22.853982
# Unit test for method quote of class Text
def test_Text_quote():
    Text().quote()


# Generated at 2022-06-23 21:58:26.097228
# Unit test for method quote of class Text
def test_Text_quote():
    """Test for class Text method quote."""
    text = Text()
    quote = text.quote()
    assert quote


# Generated at 2022-06-23 21:58:36.388247
# Unit test for method text of class Text
def test_Text_text():
    # Given
    text = Text(seed=1)

# Generated at 2022-06-23 21:58:38.056685
# Unit test for method quote of class Text
def test_Text_quote():
    print("Test for method quote of class Text")
    for i in range(10):
        print(Text().quote())


# Generated at 2022-06-23 21:58:40.604815
# Unit test for method alphabet of class Text
def test_Text_alphabet():

    result = set(Text().alphabet())
    assert len(result) == 26
    assert 'a' in result
    assert 'b' in result


# Generated at 2022-06-23 21:58:45.613487
# Unit test for method word of class Text
def test_Text_word():
    # Arrange
    text = Text('en')
    # Act
    result = text.word()
    # Assert
    print(result)

if __name__ == '__main__':
    test_Text_word()
    print (Text.seed())

# Generated at 2022-06-23 21:58:46.701099
# Unit test for method word of class Text
def test_Text_word():
    assert Text().word() != ''


# Generated at 2022-06-23 21:58:48.162773
# Unit test for method text of class Text
def test_Text_text():
    txt = Text()
    res = txt.text()
    assert not res

# Generated at 2022-06-23 21:58:49.615674
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())


# Generated at 2022-06-23 21:58:51.176614
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert isinstance(text.title(), str)


# Generated at 2022-06-23 21:58:55.939270
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    import mimesis
    t = mimesis.Text()
    result = t.alphabet(lower_case=False)
    print(result)
    assert isinstance(result, list)
    result = t.alphabet(lower_case=True)
    print(result)
    assert isinstance(result, list)


# Generated at 2022-06-23 21:58:59.010656
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    t = Text()
    assert type(t.quote()) == str and t.quote() != ''

# Generated at 2022-06-23 21:59:00.478431
# Unit test for method text of class Text
def test_Text_text():
    result = Text().text()
    assert type(result) is str


# Generated at 2022-06-23 21:59:02.052800
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    text.alphabet()


# Generated at 2022-06-23 21:59:02.967359
# Unit test for method text of class Text
def test_Text_text():
    for i in range(10):
        print(Text().text())


# Generated at 2022-06-23 21:59:03.946749
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() == "Lorem"


# Generated at 2022-06-23 21:59:05.133745
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    r = t.quote()

    assert type(r) is str

# Generated at 2022-06-23 21:59:08.021767
# Unit test for method level of class Text
def test_Text_level():
    text = Text('en')
    level = text.level()
    assert isinstance(level, str)
    assert level in text.level



# Generated at 2022-06-23 21:59:09.287228
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    ans = text.word()
    assert type(ans) == str
    assert len(ans) > 0

# Generated at 2022-06-23 21:59:11.024442
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() == 'Laborum et excepteur ea dolore est reprehenderit.'

# Generated at 2022-06-23 21:59:12.917407
# Unit test for method words of class Text
def test_Text_words():
    obj = Text('en')
    words = obj.words(5)
    assert len(words) == 5
    assert isinstance(words, list)

# Generated at 2022-06-23 21:59:14.667080
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    u = text.answer()
    assert u != None


# Generated at 2022-06-23 21:59:17.825888
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    answer1 = Text.sentence(Locale.EN)
    print('The sentence is:',answer1)


# Generated at 2022-06-23 21:59:18.809417
# Unit test for method title of class Text
def test_Text_title():
    return Text().title()


# Generated at 2022-06-23 21:59:20.818953
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    c = t.color()
    print(c)
    assert isinstance(c,str) 


# Generated at 2022-06-23 21:59:22.804262
# Unit test for method quote of class Text
def test_Text_quote():
    t=Text()
    assert len(t.quote)>5

if __name__ == '__main__':
    t=Text()
    print(t.quote())

# Generated at 2022-06-23 21:59:26.159104
# Unit test for method swear_word of class Text
def test_Text_swear_word():
  text = Text('en')
  swear_word = text.swear_word()
  assert swear_word != None


# Generated at 2022-06-23 21:59:29.924290
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    from pprint import pprint
    text = Text('en')
    pprint(text.rgb_color())

# Generated at 2022-06-23 21:59:31.069577
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    assert(x.text() != '')
    assert(isinstance(x.text(), str))



# Generated at 2022-06-23 21:59:33.378056
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text
    print ("")
    text = Text('en')
    for x in range(0, 3):
        print (text.words(3))



# Generated at 2022-06-23 21:59:35.278173
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert isinstance(alphabet, list)
    assert len(alphabet) > 4


# Generated at 2022-06-23 21:59:40.147531
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    r = t.rgb_color()
    print(r)
    assert r == (255, 0, 0), 'Result does not match the expectation'
    r = t.rgb_color(safe=True)
    print(r)
    assert r == (189, 195, 199), 'Result does not match the expectation'
    

# Generated at 2022-06-23 21:59:43.252538
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    for i in range(50):
        rgb = Text(_seed=i).rgb_color(safe=True)
        assert rgb in SAFE_COLORS

# Generated at 2022-06-23 21:59:45.214852
# Unit test for constructor of class Text
def test_Text():
    # Initialize class Text and create a variable
    from mimesis.providers.text import Text
    text = Text()
    # The variable should be equal to 'English', instead got 'French'
    assert text.locale == 'English', 'The variable did not match current locale.'
    # The variable should be equal to 'text', instead got None
    assert text._provider_name == 'text', 'The variable was not initialized.'

# Generated at 2022-06-23 21:59:47.268141
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed=123)
    print('t.swear_word() =', t.swear_word())

# Generated at 2022-06-23 21:59:49.547084
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    text = Text('en')
    assert (isinstance(text.words(quantity=10), list))


# Generated at 2022-06-23 21:59:52.709645
# Unit test for method word of class Text
def test_Text_word():
    """Test the method word of class Text"""
    class_para = {"seed": 10}
    text_instance = Text(**class_para)
    result = text_instance.word()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:59:55.273043
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str) == True
    assert len(sentence) > 0


# Generated at 2022-06-23 21:59:56.582697
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text('en')
    print(text.sentence())

# Generated at 2022-06-23 21:59:58.119214
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-23 22:00:04.552647
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()

# Generated at 2022-06-23 22:00:08.426392
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test for method alphabet of class Text."""
    text = Text()
    lower = text.alphabet(True)
    upper = text.alphabet(False)
    assert isinstance(lower, list)
    assert isinstance(upper, list)


# Generated at 2022-06-23 22:00:10.922028
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)

test_Text_word()


# Generated at 2022-06-23 22:00:14.200973
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()

    swear_word = text.swear_word()
    assert isinstance(swear_word, str)

    # print(swear_word)

# Generated at 2022-06-23 22:00:17.522561
# Unit test for method word of class Text
def test_Text_word():
    for seed in [0, 10, 24, 42, 100]:
        text = Text(seed=seed)
        for _ in range(10):
            print(text.word())


# Generated at 2022-06-23 22:00:26.383887
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender, Person
    from mimesis.localization import english
    text = Text('en')
    text.sentence()
    text.seed(0)
    assert text.sentence() == 'A nice person.'
    text.seed(None)
    text.text(1)
    text.seed(None)
    text.words(quantity=1)
    text.seed()
    text.word()
    text.seed(None)
    text.quote()
    text.seed(None)
    text.color()
    text.seed(None)
    text.hex_color()
    text.seed(None)
    text.rgb_color()
    text.seed(None)
    Person.full_name(text, Gender.MALE, english)

# Generated at 2022-06-23 22:00:28.470911
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed=0)
    assert t.swear_word() == 'Damn'


# Generated at 2022-06-23 22:00:32.197830
# Unit test for method sentence of class Text
def test_Text_sentence():
    data_provider = Text()
    result = data_provider.sentence()
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-23 22:00:34.677470
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    text = Text(locale=Locale.ITALIAN)
    assert len(text.title()) > 0, "Title does not work"

# Generated at 2022-06-23 22:00:36.101053
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    t.randomize()
    assert t.random.randint(1, 10) < 10
    assert t.random.randint(1, 10) > 0


# Generated at 2022-06-23 22:00:38.451153
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    res = t.title()
    assert isinstance(res, str)
    assert len(res) > 6


# Generated at 2022-06-23 22:00:40.982382
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locale

    x = Text(Locale.ENGLISH)
    text = x.word()
    assert text is not None


# Generated at 2022-06-23 22:00:44.798755
# Unit test for method quote of class Text
def test_Text_quote():
    """Function to test the method quote."""
    from mimesis.enums import Locale
    text = Text(Locale.EN)
    result = text.quote()
    assert ' ' in result
    assert len(result) > 6
    assert '"' in result


# Generated at 2022-06-23 22:00:46.487504
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text(seed=555)
    assert t.answer() == 'No'

# Generated at 2022-06-23 22:00:48.561320
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Arrange
    expected_result = 0
    # Act
    result = Text().sentence()
    # Assert
    assert result == expected_result

# Generated at 2022-06-23 22:00:50.520387
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    result = t.sentence()
    result2 = t.text(1)
    assert result == result2

# Generated at 2022-06-23 22:00:55.963918
# Unit test for constructor of class Text
def test_Text():
    a=Text()
    print(a.word())
    print(a.text())
    print(a.text(10))
    print(a.alphabet(True))
    print(a.alphabet())
    print(a.level())
    print(a.swear_word())
    print(a.color())
    print(a.quote())
    print(a.hex_color())
    print(a.rgb_color())
    print(a.rgb_color(True))
    print(a.hex_color(True))
    print(a.answer())
    print(a.words())
    print(a.words(10))

# Generated at 2022-06-23 22:00:58.424865
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    t = Text()
    assert t.quote() in t._data['quotes']


# Generated at 2022-06-23 22:01:00.467977
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    sw = Text(locale='en').swear_word()
    assert sw != ''
    print(sw)


# Generated at 2022-06-23 22:01:01.371357
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    print(text.level())

# Generated at 2022-06-23 22:01:03.346936
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words(2)) == 2


# Generated at 2022-06-23 22:01:12.382788
# Unit test for constructor of class Text
def test_Text():
    text = Text('en')
    # testing to get a hex color
    hex_color = text.hex_color()
    # testing if a hex color is string
    assert type(hex_color) == str
    # testing to get a color
    color = text.color()
    # testing if color is string
    assert type(color) == str
    # testing to get a level
    level = Text.level()
    # testing if level is string
    assert type(level) == str
    # testing to get a quote
    quote = text.quote()
    # testing if quote is string
    assert type(quote) == str
    # testing to get a sentence
    sentence = text.sentence()
    # testing if sentence is string
    assert type(sentence) == str
    # testing to get a title
    title = text.title()

# Generated at 2022-06-23 22:01:19.814607
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import Text
    from mimesis.enums import Gender
    from mimesis.providers import Person

    #Create person
    person = Person('en')

    #Create text
    text = Text('en')

    #Creating the template
    template = text.sentence()

    #Replacing all the {} in the template with information
    template = template.format(
        name = person.full_name(gender=Gender.FEMALE),
        number = person.telephone()
    )

    #Printing the template
    print(template)

# Generated at 2022-06-23 22:01:24.256590
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test method hex_color of class Text."""
    import pytest
    from mimesis.builtins import Text as t

    text = t('en')
    result = text.hex_color()

    assert type(result) == str
    assert len(result) == 7
    assert result.startswith('#')

    with pytest.raises(TypeError):
        text.hex_color(safe=1)



# Generated at 2022-06-23 22:01:29.235675
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#ff1a80'
    assert t.hex_color(safe=False) == '#ba74ee'
    assert t.hex_color(safe=True) == '#1abc9c'
    assert t.hex_color(safe=True) == '#16a085'

# Generated at 2022-06-23 22:01:31.359180
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=4455)
    assert text.title() == "Ut labore."
