

# Generated at 2022-06-23 21:51:27.495364
# Unit test for method sentence of class Text
def test_Text_sentence():
    result = Text().sentence()
    print(result)


# Generated at 2022-06-23 21:51:31.297006
# Unit test for method word of class Text
def test_Text_word():
    t = Text("en")
    w = t.word()
    assert (w != "") and (w.isalpha())


# Generated at 2022-06-23 21:51:32.658924
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert len(text.swear_word()) > 0

# Generated at 2022-06-23 21:51:34.780085
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    sw_words = t.swear_word()
    assert isinstance(sw_words, str)


# Generated at 2022-06-23 21:51:37.898261
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text()
    result = provider.quote().split(' - ')
    assert len(result) == 2
    assert len(result[0]) != 0
    assert len(result[1]) != 0


# Generated at 2022-06-23 21:51:39.893856
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print('Testing method swear_word of class Text')
    assert Text().swear_word() == 'Damn'


# Generated at 2022-06-23 21:51:41.154615
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())


# Generated at 2022-06-23 21:51:45.072730
# Unit test for method color of class Text
def test_Text_color():
    # Create instance of class Text
    text = Text()
    # Run method color
    result = text.color()
    assert result in text._data['color']


# Generated at 2022-06-23 21:51:46.113581
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    return True


# Generated at 2022-06-23 21:51:48.254521
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    t_title = t.title()
    print('t_title: ', t_title)


# Generated at 2022-06-23 21:51:56.444807
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from mimesis.data import SAFE_COLORS
    text = Text('ru')  # type: Text
    color = text.rgb_color()  # type: Tuple[int, int, int]
    assert isinstance(color, tuple)
    assert len(color) == 3
    assert isinstance(color[0], int)
    assert isinstance(color[1], int)
    assert isinstance(color[2], int)
    assert all(x in range(0, 256) for x in color)
    color_type = text.random.choice(ColorType)  # type: ColorType
    color = text.rgb_color(safe=color_type)
    assert isinstance(color, tuple)
    assert len(color) == 3

# Generated at 2022-06-23 21:51:58.719609
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert len(sentence) > 0, 'Error sentence'


# Generated at 2022-06-23 21:52:00.481666
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    assert(x.provider == 'text')


# Generated at 2022-06-23 21:52:02.226948
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())



# Generated at 2022-06-23 21:52:07.045753
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text()
    result = provider.rgb_color()
    test1 = len(result) == 3
    test2 = isinstance(result[0], int) and isinstance(result[1], int) and \
        isinstance(result[2], int)
    assert test1 and test2

# Generated at 2022-06-23 21:52:08.846969
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=950)
    for num in range(10):
        print(text.quote())

# Generated at 2022-06-23 21:52:12.404616
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    result = t.title()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:52:14.981575
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence()) # 'Peaceful.'
    print(t.random.choice(t._data['text']))


# Generated at 2022-06-23 21:52:18.712177
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for class Text."""
    for i in range(100):
        x = Text().answer()
        assert x



# Generated at 2022-06-23 21:52:20.481812
# Unit test for method title of class Text
def test_Text_title():
  text = Text()
  print(text.title())
test_Text_title()


# Generated at 2022-06-23 21:52:22.211622
# Unit test for method title of class Text
def test_Text_title():
    ans = Text()
    t= ans.title()
    print(t)


# Generated at 2022-06-23 21:52:23.695367
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    res = Text().swear_word()
    assert (res != "")

# Generated at 2022-06-23 21:52:28.098739
# Unit test for method word of class Text
def test_Text_word():
    import json
    import os
    with open(os.path.join(os.path.curdir, 'mimesis/data/en/text.json')) as f:
        data = json.load(f)
    assert(Text(locale='en').word() in data['words']['normal'])


# Generated at 2022-06-23 21:52:30.508593
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    expected = text.quote()
    assert expected is not None


# Generated at 2022-06-23 21:52:33.059071
# Unit test for constructor of class Text
def test_Text():
    print(Text.__doc__)
    text = Text()
    print(text)
    print(repr(text))
    print(str(text))


# Generated at 2022-06-23 21:52:35.035371
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-23 21:52:41.442807
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text(seed=123) # инициализируем класс Text с заданным seed
    assert t.sentence() == 'Toaster' # проверяем работу метода sentence класса Text


# Generated at 2022-06-23 21:52:52.422643
# Unit test for method answer of class Text
def test_Text_answer():
    """Test answers for different locales.
    """
    result = Text(locale='ru').answer()
    # Test Russian
    assert result in {
        'Да',
        'Нет',
        'Возможно'
    }, f'Неправильное значение {result!r}'
    # Test English
    result = Text(locale='en').answer()
    assert result in {
        'Yes',
        'No',
        'May be'
    }, f'Wrong value {result!r}'

# Generated at 2022-06-23 21:52:53.784597
# Unit test for constructor of class Text
def test_Text():
    text = Text('he-IL')
    assert text



# Generated at 2022-06-23 21:53:06.045562
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import Color
    from mimesis.providers.text import Text
    t = Text()
    # test for safe color
    for _ in range(0, 100):
        hex_safe_color = t.hex_color(True)
        if hex_safe_color not in Color.__members__:
            print("error, not safe color:", hex_safe_color)
    # test for no-safe color
    for _ in range(0, 100):
        hex_no_safe_color = t.hex_color()
        rgb_no_safe_color = t._hex_to_rgb(hex_no_safe_color)
        if rgb_no_safe_color not in Color.__members__:
            print("error, not safe color:", hex_no_safe_color)

#

# Generated at 2022-06-23 21:53:08.137654
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text()
    rgb_color = provider.rgb_color()
    print(rgb_color)


# Generated at 2022-06-23 21:53:10.584073
# Unit test for method text of class Text
def test_Text_text():
    """Test Text.text() method."""
    text = Text()
    ret = text.text()
    assert isinstance(ret, str)
    assert ret


# Generated at 2022-06-23 21:53:22.032638
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Assert that the class Text has attribute rgb_color
    assert Text().has_method('rgb_color')

    # Assert that the method rgb_color is not static
    assert not Text().is_static_method('Answer')

    # Assert that the method rgb_color is an instance method
    assert Text().is_instance_method('rgb_color')

    # Assert that the method rgb_color is a public method
    assert Text().is_public_method('rgb_color')

    # Assert that the method rgb_color is not a base method
    assert not Text().is_base_method('rgb_color')

    # Assert the generated RGB color tuple is within the red, green, blue
    # range 0-255

# Generated at 2022-06-23 21:53:24.545224
# Unit test for method words of class Text
def test_Text_words():
    words_list = Text().words(quantity=4)
    expected = 4
    assert len(words_list) == expected, \
        f'Expected {expected}, but got {len(words_list)}'


# Generated at 2022-06-23 21:53:32.485228
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    result = t.alphabet()
    assert len(result) == 26
    assert result == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K',
                      'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
                      'W', 'X', 'Y', 'Z']
    result = t.alphabet(True)
    assert len(result) == 26

# Generated at 2022-06-23 21:53:34.492226
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = Text.hex_color()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:53:36.258132
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert(sentence is not None)


# Generated at 2022-06-23 21:53:38.305546
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    generator = Text("en")
    
    assert generator.swear_word() in generator._data['words']['bad']


# Generated at 2022-06-23 21:53:40.218272
# Unit test for method level of class Text
def test_Text_level():
    print("test_Text_level")
    t = Text()

    level = t.level()
    assert level in t._data['level']

# Generated at 2022-06-23 21:53:42.888283
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(), str)
    assert isinstance(t.text(quantity=3), str)

# Generated at 2022-06-23 21:53:44.477981
# Unit test for method words of class Text
def test_Text_words():
    t = Text(seed=123)

    assert t.words(quantity=1) == ['science']


# Generated at 2022-06-23 21:53:45.893623
# Unit test for method quote of class Text
def test_Text_quote():
    tea = Text()
    assert tea.quote() != None

# Generated at 2022-06-23 21:53:50.922420
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text.

    :return: None
    """
    text = Text()
    result = text.words(quantity=5)

    assert len(result) == 5
    assert isinstance(result, list)

if __name__ == '__main__':
    test_Text_words()

# Generated at 2022-06-23 21:53:53.917212
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    provider = Text()
    print(provider.alphabet())
    print(provider.alphabet(lower_case=True))


# Generated at 2022-06-23 21:53:54.979532
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    t.word()
    pass

# Generated at 2022-06-23 21:54:04.241460
# Unit test for method title of class Text
def test_Text_title():
    c = Text()
    print(c.title())
    print(c.digit())
    print(c.digit(as_string=True))
    print(c.digit(padding=True))
    print(c.digit(padding=True, as_string=True))
    print(c.numerify('###-###-###'))
    print(c.serialize('###-###-###', as_string=True))
    print(c.serialize('###-###-###'))
    print(c.hex_color())
    print(c.hex_color(safe=True))
    print(c.rgb_color())
    print(c.rgb_color(safe=True))



# Generated at 2022-06-23 21:54:10.672431
# Unit test for method text of class Text
def test_Text_text():
    text = Text('en')
    q = text.text()
    assert isinstance(q, str)
    q = text.text(quantity=1)
    assert isinstance(q, str)
    q = text.text(quantity=1)
    assert isinstance(q, str)



# Generated at 2022-06-23 21:54:14.145460
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    for i in range(10):
        hex_color = text.hex_color()
        rgb_color = text.hex_to_rgb(hex_color)
        print(hex_color, rgb_color)


# Generated at 2022-06-23 21:54:17.719675
# Unit test for method quote of class Text
def test_Text_quote():
    
    obj = Text()
    results = []
    for i in range(10):
        result = obj.quote()
        print(result)
        assert(result in obj._data['quotes'])
        results.append(result)

    assert(len(results) == len(set(results)))

# Generated at 2022-06-23 21:54:19.755242
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Initialize
    text = Text()
    # Call method sentence
    text_sentence = text.sentence()
    # Test
    assert isinstance(text_sentence, str)


# Generated at 2022-06-23 21:54:21.519416
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert isinstance(text.hex_color(), str)

# Generated at 2022-06-23 21:54:23.671776
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    provider = Text()
    assert provider.hex_color() == '#8be3db'


# Generated at 2022-06-23 21:54:31.917277
# Unit test for method quote of class Text
def test_Text_quote():
    from . import random
    from . import text
    from . import datetime

    class TestText:
        """Class for testing Text."""

        def test_random_quote(self):
            for i in range(10):
                quote = text.quote()
                assert quote is not None, \
                    'Quote is null'

        def test_fixed_quote(self):
            seed = random.seed.generator(seed=42)
            random.seed.set(seed)
            provider = text.Text(
                locale='en', seed=seed)
            quote = provider.quote()

# Generated at 2022-06-23 21:54:32.749117
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert isinstance(Text().rgb_color(), tuple)

# Generated at 2022-06-23 21:54:37.454465
# Unit test for method level of class Text
def test_Text_level():
    class TestText(Text):
        class Meta:
            locales = ['ru']

    text = TestText()
    assert text.level() in ("Критический", "Высокий", "Низкий")


# Generated at 2022-06-23 21:54:38.101409
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())

# Generated at 2022-06-23 21:54:42.965482
# Unit test for method title of class Text
def test_Text_title():

    class MyTest:

        def __init__(self, language = 'en'):
            self.text = Text(language = language)
            
    mytext = MyTest()

    if mytext.text.title() in mytext.text._data['text']:
        print('Passed')
    else:
        print('Failed')


# Generated at 2022-06-23 21:54:44.710617
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    print(rgb)

# Generated at 2022-06-23 21:54:51.529942
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text(seed=13).alphabet() == ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё',
                                        'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М',
                                        'Н', 'О', 'П', 'Р', 'С', 'Т', 'У',
                                        'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ',
                                        'Ы', 'Ь', 'Э', 'Ю', 'Я']


# Generated at 2022-06-23 21:54:57.888405
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    #print(t.rgb_color())
    #print(t.rgb_color())
    #print(t.rgb_color())
    #print(t.rgb_color())
    #print(t.rgb_color(True))
    #print(t.rgb_color(True))
    #print(t.rgb_color(True))
    #print(t.rgb_color(True))
    return t.rgb_color()


# Generated at 2022-06-23 21:54:59.654491
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() in text._data['color']

# Generated at 2022-06-23 21:55:02.846241
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.words(), list)
    assert len(text.words()) == 5
    assert all(isinstance(word, str) for word in text.words())


# Generated at 2022-06-23 21:55:05.881759
# Unit test for method word of class Text
def test_Text_word():
    # GIVEN
    word_provider = Text()
    
    # WHEN
    word = word_provider.word()
    # THEN
    assert len(word) > 0


# Generated at 2022-06-23 21:55:07.751255
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print(text.alphabet())


# Generated at 2022-06-23 21:55:10.095634
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text."""
    t = Text()
    text = t.text(quantity=1)
    assert text in t._data['text']

# Generated at 2022-06-23 21:55:11.050231
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    t.word()

# Generated at 2022-06-23 21:55:12.534374
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    for _ in range(100):
        assert len(t.word()) >= 4

# Generated at 2022-06-23 21:55:13.423589
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass



# Generated at 2022-06-23 21:55:16.020767
# Unit test for method color of class Text
def test_Text_color():
	# Init data
	text = Text()
	# Do test
	c = text.color()
	# Assert result
	assert isinstance(c, str)


# Generated at 2022-06-23 21:55:19.236756
# Unit test for method quote of class Text
def test_Text_quote():
    """Testing method quote of class Text."""
    t = Text(seed=1)
    answer = t.quote()
    expected_answer = 'The Force will be with you. Always.'
    assert answer == expected_answer

# Generated at 2022-06-23 21:55:21.480521
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.providers.text import Text
    instance = Text()
    result = instance.words()
    assert isinstance(result, list)
    

# Generated at 2022-06-23 21:55:24.359314
# Unit test for method words of class Text
def test_Text_words():
    # Init
    t = Text(seed=0)
    # Test
    for i in range(0, 10):
        assert len(t.words(quantity=i)) == i


# Generated at 2022-06-23 21:55:27.219626
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text(_seed=1)
    my_hex = text.hex_color()
    assert my_hex == '#f2ed19'


# Generated at 2022-06-23 21:55:31.117659
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3


# Generated at 2022-06-23 21:55:35.093373
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test for method Text.sentence."""
    from mimesis import Text
    t = Text()
    result = t.sentence()
    assert len(result) > 0
    assert ' ' in result
    assert result[0].isupper()


# Generated at 2022-06-23 21:55:36.005337
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    t.word()

# Generated at 2022-06-23 21:55:37.376513
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text("en")
    print("You are a", t.swear_word())

# Generated at 2022-06-23 21:55:38.915300
# Unit test for constructor of class Text
def test_Text():
    # initialization of the class
    text = Text()
    # check if the object created in None
    assert text is not None

# Generated at 2022-06-23 21:55:41.400373
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    answer = text.quote()
    assert len(answer) > 0  


# Generated at 2022-06-23 21:55:44.783218
# Unit test for method text of class Text
def test_Text_text():
	# Create text object
	text = Text()
	# Get text
	t = text.text()
	# Test
	assert t is not None
	assert isinstance(t, str)
	assert len(t) > 0

# Generated at 2022-06-23 21:55:46.847775
# Unit test for method level of class Text
def test_Text_level():
    print(Text().level())


# Generated at 2022-06-23 21:55:49.192281
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() == (223, 19, 127)

# Generated at 2022-06-23 21:55:52.903800
# Unit test for method answer of class Text
def test_Text_answer():
    try:
        _ = Text(seed=12345).answer()
    except:
        raise RuntimeError("Method 'Text.answer' is test failed.")
    else:
        print("Method 'Text.answer' is test passed.")


# Generated at 2022-06-23 21:55:54.369571
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text) == True

# Generated at 2022-06-23 21:55:56.147920
# Unit test for method title of class Text
def test_Text_title():
    a = Text.title(Text())
    assert isinstance(a, str)


# Generated at 2022-06-23 21:55:57.939136
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    # print(rgb_color())
    # print(rgb_color(safe=True))

# Generated at 2022-06-23 21:56:01.632481
# Unit test for method text of class Text
def test_Text_text():
    print('> test_Text_text()')
    with Text() as t:
        print(t.text())
        print(t.text(quantity=3))
        print(t.text(quantity=3))
    print('> test_Text_text() done')


# Generated at 2022-06-23 21:56:06.977869
# Unit test for method words of class Text
def test_Text_words():
    text = Text()

    words_list = text.words(quantity = 10)

    assert len(words_list) == 10

    assert isinstance(words_list, list)

    for word in words_list:
        assert isinstance(word, str)

    # Unit test for method word of class Text

# Generated at 2022-06-23 21:56:09.857064
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != Text().text()
    assert Text().text(1) != Text().text(1)
    assert Text().text() != Text().text(1)

# Generated at 2022-06-23 21:56:14.327206
# Unit test for method text of class Text
def test_Text_text():
    """Test for method text."""
    t = Text()
    text = t.text()
    assert isinstance(text, str)

    for i in range(1, 10):
        text = t.text(i)
        assert isinstance(text, str)



# Generated at 2022-06-23 21:56:23.492431
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t.alphabet(), list)
    assert isinstance(t.level(), str)
    assert isinstance(t.text(), str)
    assert isinstance(t.title(), str)
    assert isinstance(t.words(), list)
    assert isinstance(t.word(), str)
    assert isinstance(t.swear_word(), str)
    assert isinstance(t.quote(), str)
    assert isinstance(t.color(), str)
    assert isinstance(t.hex_color(), str)
    assert isinstance(t.rgb_color(), tuple)
    assert isinstance(t.answer(), str)
    assert isinstance(t.alphabet(lower_case=True), list)
    assert isinstance(t.text(quantity=2), str)
    assert isinstance

# Generated at 2022-06-23 21:56:25.303845
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    answer = t.answer()
    assert answer in t._data['answers']

# Generated at 2022-06-23 21:56:26.953764
# Unit test for method sentence of class Text
def test_Text_sentence():
    x = Text.sentence()
    assert type(x) == str


# Generated at 2022-06-23 21:56:30.358824
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    res = text.level()
    assert res is not None
    assert res in text._data['level']


# Generated at 2022-06-23 21:56:31.356063
# Unit test for method text of class Text
def test_Text_text():
    return Text().text()


# Generated at 2022-06-23 21:56:32.706856
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5


# Generated at 2022-06-23 21:56:35.207861
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text.
    """
    t = Text('en')
    assert t.color() in t._data['color']


# Generated at 2022-06-23 21:56:36.469849
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No']

# Generated at 2022-06-23 21:56:41.208503
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.builtins import RussiaSpecProvider
    # print("\n========== start test_Text_alphabet ==========")
    t1 = Text(selloc="ru")
    # print("\n========== t1.alphabet(False)=",t1.alphabet(False),'==========')
    # print("\n========== t1.alphabet(True)=",t1.alphabet(True),'==========')
    

# Generated at 2022-06-23 21:56:43.393617
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of class Text."""
    assert Text().swear_word() != ''

# Generated at 2022-06-23 21:56:45.420129
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert(Text().sentence() in Text()._data['text'])


# Generated at 2022-06-23 21:56:53.356187
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert isinstance(t.answer(), str)


if __name__ == '__main__':
    
    x = Text()
    print(x.quote()) # Get a random quote.
    print(x.title()) # Get a random title.
    print(x.text()) # Generate the text.
    print(x.words(10)) # Generate lis of the random words.
    print(x.word()) # Get a random word.
    print(x.swear_word()) # Get a random swear word.
    print(x.color()) # Get a random name of color.
    print(x.hex_color()) # Generate a random hex color.
    print(x.rgb_color()) # Generate a random rgb color tuple.
    print(x.answer()) # Get a random answer in

# Generated at 2022-06-23 21:56:55.832331
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    t = Text()
    t.seed(0)

    assert t.answer() == 'No'

# Generated at 2022-06-23 21:56:56.740397
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    text.answer()


# Generated at 2022-06-23 21:56:58.800997
# Unit test for method words of class Text
def test_Text_words():
    txt = Text()
    result = txt.words(5)
    print(result)
    assert len(result) == 5


# Generated at 2022-06-23 21:57:01.852206
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=12345678)
    assert text.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
                               'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                               'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']


# Generated at 2022-06-23 21:57:04.981522
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print(text.alphabet())
    print(text.alphabet(lower_case=True))
    print(text.alphabet(lower_case=False))


# Generated at 2022-06-23 21:57:06.354686
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj is not None

# Generated at 2022-06-23 21:57:07.621944
# Unit test for method quote of class Text
def test_Text_quote():
    my_gen = Text()
    assert len(my_gen.quote()) > 0

# Generated at 2022-06-23 21:57:08.832737
# Unit test for method words of class Text
def test_Text_words():
    x = Text()
    print(x.words(5))


# Generated at 2022-06-23 21:57:11.958845
# Unit test for method swear_word of class Text
def test_Text_swear_word():
	#try:
		words = Text().swear_word()
		assert len(words.split()) == 1
	#except:
		#assert False

#Unit test for method text of class Text

# Generated at 2022-06-23 21:57:15.705638
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(1), str)
    assert isinstance(text.text(10), str)
    assert isinstance(text.text(100), str)

# Generated at 2022-06-23 21:57:18.368605
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    abc = text.alphabet()
    length = len(abc)
    assert type(abc) is list and length == 26


# Generated at 2022-06-23 21:57:20.523695
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    s = Text()
    result = s.hex_color()
    assert isinstance(result, str)
    assert len(result) == 7


# Generated at 2022-06-23 21:57:23.038949
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    for _ in range(10):
        sentence = t.sentence()
        assert sentence is not None

# Generated at 2022-06-23 21:57:24.259131
# Unit test for method quote of class Text
def test_Text_quote():
    x=Text(unique=True)
    print(x.quote())

# Generated at 2022-06-23 21:57:25.440386
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']

# Generated at 2022-06-23 21:57:28.903801
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    x.set_seed(1)
    assert Text().text(5) == 'Crazy people who say this, thank you for your voices.'
    assert x.text(5) == 'Just give me your new ideas and I will do the rest.'
    assert x.text(5) == 'Just give me your new ideas and I will do the rest.'


# Generated at 2022-06-23 21:57:31.423853
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)

# Generated at 2022-06-23 21:57:38.127093
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test the output of the method hex_color of the class Text."""
    from mimesis.mimesis import Mimesis
    from mimesis.exceptions import NonExistentLocaleError

    mimesis = Mimesis()
    try:
        text_instance = Text(locale='zz')
    except NonExistentLocaleError:
        text_instance = Text(locale='en')

    # 1. Default
    result = text_instance.hex_color()
    assert len(result) == 7
    assert result.startswith('#')

    # 2. With safe
    result = text_instance.hex_color(safe=True)
    assert result in SAFE_COLORS

    # 3. Wrapper
    result = mimesis.text.hex_color()
    assert len(result) == 7


# Generated at 2022-06-23 21:57:46.899174
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(quantity=1), str)
    assert len(t.text(quantity=1).split(' ')) == 1
    assert len(t.text(quantity=2).split(' ')) == 2
    assert len(t.text(quantity=3).split(' ')) == 3
    assert isinstance(t.text(quantity=3).split(' '), list)
    assert isinstance(t.text(quantity=3), str)
    assert isinstance(t.text(quantity=3).split(' '), list)

# Generated at 2022-06-23 21:57:49.333680
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert type(color) == str and len(color) > 0


# Generated at 2022-06-23 21:57:57.555689
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.builtins import Text
    from typing import List
    from pprint import pprint
    from random import choice

    
    
    
    
    
    

    
    
    
    
    
    text = Text()
    pprint(text.paragraphs(quantity=3))
    
    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    
    # text.text(quantity=5)
    
    
    
    
    
    
    
    # text.text(quantity=choice(range(

# Generated at 2022-06-23 21:57:59.860747
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test for the method swear_word"""
    text = Text()
    assert isinstance(text.swear_word(),str)

# Generated at 2022-06-23 21:58:03.585821
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    lst = t.words()
    assert type(lst) is list
    assert len(lst) is 5
    assert type(lst[0]) is str
    print("Test OK", lst)


# Generated at 2022-06-23 21:58:05.433979
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert len(title) > 1


# Generated at 2022-06-23 21:58:06.698295
# Unit test for method words of class Text
def test_Text_words():
    for i in range(100):
        assert len(Text().words()) == 5

# Generated at 2022-06-23 21:58:13.954596
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.alphabet(lower_case=True), list)
    assert isinstance(text.color(), str)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.rgb_color(safe=True), tuple)
    assert isinstance(text.level(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.title(), str)
    assert isinstance(text.word(), str)
    assert isinstance(text.words(), list)

# Generated at 2022-06-23 21:58:17.142154
# Unit test for method words of class Text
def test_Text_words():
    words = Text(seed=1).words(quantity=5)
    assert words == ['science', 'network', 'god', 'octopus', 'love']


# Generated at 2022-06-23 21:58:19.589723
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ["No", "Yes", "Нет", "Да"]


# Generated at 2022-06-23 21:58:20.705743
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())

# Generated at 2022-06-23 21:58:23.713050
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    word_list = text.words(5)
    words = ["science", "network", "god", "octopus", "love"]
    assert word_list == words


# Generated at 2022-06-23 21:58:25.906128
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    color = t.rgb_color()
    assert len(color) == 3



# Generated at 2022-06-23 21:58:26.981454
# Unit test for method color of class Text
def test_Text_color():

    result = Text.color()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:58:30.443901
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    assert txt.seed is not None
    assert txt.random_seed == txt.seed
    assert txt.random.seed == txt.seed


# Generated at 2022-06-23 21:58:32.239369
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text()
    assert len(text) > 0


# Generated at 2022-06-23 21:58:33.223684
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    ans = text.sentence()
    print(ans)


# Generated at 2022-06-23 21:58:36.682083
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.title())
    print(text.color())
    print(text.hex_color())
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    print(text.quote())


# Generated at 2022-06-23 21:58:38.739455
# Unit test for method word of class Text
def test_Text_word():
    obj = Text()
    result = obj.word()
    assert isinstance(result, str) or result == ''


# Generated at 2022-06-23 21:58:40.844121
# Unit test for method word of class Text
def test_Text_word():
    x = Text()
    print(x.word())
    print("*"*20)
    print(x.swear_word())

# Generated at 2022-06-23 21:58:41.840816
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass


# Generated at 2022-06-23 21:58:44.894660
# Unit test for method title of class Text
def test_Text_title():
    txt = Text('en')
    result = txt.title()
    print(result)


# Generated at 2022-06-23 21:58:46.753454
# Unit test for method color of class Text
def test_Text_color():
    obj = Text("en")
    assert obj.color() in obj._data['color']

# Generated at 2022-06-23 21:58:50.340344
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Language

    t = Text(Language.ENGLISH)
    for i in range(10):
        answer = t.answer()
        print("n.{} answer: {}".format(i, answer))


# Generated at 2022-06-23 21:58:54.139422
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # Write unit test for method alphabet of class Text.
    print('Executing unit test for method alphabet of class Text...')
    print('Not implemented yet')
    print('Executing unit test for method alphabet of class Text completed')


# Generated at 2022-06-23 21:58:55.468668
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None

# Generated at 2022-06-23 21:58:56.665638
# Unit test for method answer of class Text
def test_Text_answer():
    # Test for method answer of class Text
    pass


# Generated at 2022-06-23 21:58:59.152489
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() == ()
    assert Text(safe=True).rgb_color() == ()



# Generated at 2022-06-23 21:59:02.343298
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.builtins import Text
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-23 21:59:04.657072
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text('en')
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3


# Generated at 2022-06-23 21:59:05.639864
# Unit test for method level of class Text
def test_Text_level():
    tr = Text('tr')
    print(tr.level())


# Generated at 2022-06-23 21:59:08.155920
# Unit test for method text of class Text
def test_Text_text():
    try:
        text = Text()
        text.text()
    except :
        pass


# Generated at 2022-06-23 21:59:09.915492
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(), str) is True


# Generated at 2022-06-23 21:59:16.575635
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    obj = Text()
    assert len(obj.alphabet(lower_case=True)) == 26
    assert len(obj.alphabet(lower_case=False)) == 26
    assert obj.alphabet(lower_case=True)[0] == 'a'
    assert obj.alphabet(lower_case=False)[0] == 'A'
    assert obj.alphabet(lower_case=True)[1] == 'b'
    assert obj.alphabet(lower_case=False)[1] == 'B'
    assert obj.alphabet(lower_case=True)[2] == 'c'
    assert obj.alphabet(lower_case=False)[2] == 'C'

# Generated at 2022-06-23 21:59:17.889258
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())


# Generated at 2022-06-23 21:59:19.570959
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence().__class__ == str


# Generated at 2022-06-23 21:59:24.758586
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    class Text(BaseDataProvider):
        class Meta:
            name = 'text'

    t = Text(locale='ru')
    assert t.alphabet() == ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я']

# Generated at 2022-06-23 21:59:27.157262
# Unit test for method sentence of class Text
def test_Text_sentence():
    r = Text().sentence()
    assert isinstance(r, str)
    assert 0 < len(r) <= 400

# Generated at 2022-06-23 21:59:29.084283
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() == 'Assignment'

# Generated at 2022-06-23 21:59:31.293651
# Unit test for method word of class Text
def test_Text_word():
    print(Text().word())
    print(Text().word())
    print(Text().word())
    print(Text().word())


# Generated at 2022-06-23 21:59:33.259979
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    # sentence: 'Go.'
    assert (len(text.sentence()) > 200)


# Generated at 2022-06-23 21:59:34.634842
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert isinstance(answer, str)


# Generated at 2022-06-23 21:59:35.602296
# Unit test for constructor of class Text
def test_Text():
    """Test constructor of class Text."""
    t = Text()
    assert t is not None

# Generated at 2022-06-23 21:59:38.449286
# Unit test for constructor of class Text
def test_Text():
    try:
        text = Text()
        assert text.__class__.__name__ == 'Text'
    except Exception as e:
        print(e)
        

# Generated at 2022-06-23 21:59:41.264305
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T'
        , 'U', 'V', 'W', 'X', 'Y', 'Z']


# Generated at 2022-06-23 21:59:43.638151
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    provider = Text()
    word = provider.swear_word()
    assert word != ''

# Generated at 2022-06-23 21:59:47.739381
# Unit test for method word of class Text
def test_Text_word():
    t = Text(seed=0)
    assert t.word() == 'science'
    assert t.word() == 'network'
    assert t.word() == 'god'
    assert t.word() == 'octopus'
    assert t.word() == 'love'
    return

# Generated at 2022-06-23 21:59:49.943002
# Unit test for method words of class Text
def test_Text_words():
    temp = Text()
    assert len(temp.words())==5

# Generated at 2022-06-23 21:59:54.252119
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import ColorName
    from mimesis.builtins import Text
    from mimesis.data import SAFE_COLORS

    text = Text()
    # normal case
    assert text.hex_color() != None
    assert text.hex_color(safe = True) in SAFE_COLORS



# Generated at 2022-06-23 22:00:02.971098
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.misc import Misc
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.payment import Payment
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.personal import Personal
    from mimesis.providers.business import Business
    from mimesis.providers.numbers import Numbers
    
    person = Person('en')
    address = Address('en')
    internet = Internet('en')
    misc = Misc('en')
    phone = Phone

# Generated at 2022-06-23 22:00:06.820131
# Unit test for method words of class Text
def test_Text_words():
    text = Text
    words = text.words
    text.seed(0)
    text_words = words(quantity=5)
    print(text_words)
    assert text_words == ['science', 'network', 'god', 'octopus', 'love']


# Generated at 2022-06-23 22:00:09.396424
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    print("Default API use")
    t1 = Text()
    print("t1.hex_color()",t1.hex_color())
    

# Generated at 2022-06-23 22:00:19.571005
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Default safe=False
    text = Text("en")
    hex_color = text.hex_color()
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color.startswith("#")
    assert int(hex_color[1:3], 16) >= 16
    assert int(hex_color[3:5], 16) >= 16
    assert int(hex_color[5:7], 16) >= 16
    # safe=True
    hex_color = text.hex_color(safe=True)
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color in SAFE_COLORS


# Generated at 2022-06-23 22:00:21.023426
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text().hex_color() in ['#d8346b', '#61b3d3']

# Generated at 2022-06-23 22:00:23.687835
# Unit test for method text of class Text
def test_Text_text():
    # Arrange
    from mimesis.builtins import Text as Txt
    text = Txt('en')
    # Act
    # Assert
    assert len(text.text()) > 5


# Generated at 2022-06-23 22:00:25.755526
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=0)
    result = text.title()
    assert result == "Anim iste doloremque molestias deserunt dolor."


# Generated at 2022-06-23 22:00:26.510207
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj


# Generated at 2022-06-23 22:00:29.527615
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    alphabet = Text.alphabet()
    assert type(alphabet) is list
    assert len(alphabet) > 0
    assert type(alphabet[0]) is str


# Generated at 2022-06-23 22:00:34.123081
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    t = Text(Locale.EN)
    assert t.color() in ['Yellow', 'Orange', 'Pink', 'Brown', 'Red',]


# Generated at 2022-06-23 22:00:37.921975
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(True)) == 26
    assert 'А' in t.alphabet()
    assert 'а' in t.alphabet(True)


# Generated at 2022-06-23 22:00:39.284738
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != ''
    assert len(Text().text()) >= 20

# Generated at 2022-06-23 22:00:41.230182
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert(isinstance(color, str))
    assert(color != ' ')

# Generated at 2022-06-23 22:00:43.539127
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    res = t.answer()
    assert res in t._data['answers']



# Generated at 2022-06-23 22:00:45.573142
# Unit test for method words of class Text
def test_Text_words():
    t = Text(seed=123)
    assert t.words() == ['europe', 'flags', 'apps', 'browser', 'google']


# Generated at 2022-06-23 22:00:49.198478
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Expected result
    expected = 'And what do we have here?'
    # Initialize class Text
    text = Text(seed=0)
    # Actual result
    actual = text.sentence()
    # Compare results
    assert expected == actual


# Generated at 2022-06-23 22:00:50.087540
# Unit test for method word of class Text
def test_Text_word():
    texts = Text()
    print(texts.word())

# Generated at 2022-06-23 22:00:54.406684
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7

# Unit tests for method word of class Text

# Generated at 2022-06-23 22:00:56.257400
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert isinstance(t.word(),str)

# Generated at 2022-06-23 22:01:01.676581
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorCode
    from mimesis.providers.text import Text
    text = Text('en')
    result = text.rgb_color(safe=True)
    assert result[0] >= 0 and result[0] <= 255
    assert result[1] >= 0 and result[1] <= 255
    assert result[2] >= 0 and result[2] <= 255
    assert result in ColorCode.RGB.value

# Generated at 2022-06-23 22:01:04.761491
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    for i in range(100):
        w = t.word()
        assert type(w) == str
        assert len(w) > 0


# Generated at 2022-06-23 22:01:06.143480
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert len(text.sentence()) != 0


# Generated at 2022-06-23 22:01:07.787735
# Unit test for method level of class Text
def test_Text_level():
    provider = Text()
    result = provider.level()
    assert result not in ["",[],[()],(),{}]

# Generated at 2022-06-23 22:01:10.325622
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print('Testing method alphabet of class Text')
    for _ in range(10):
        text = Text()
        print(text.alphabet())
        print(text.alphabet(lower_case=True))


# Generated at 2022-06-23 22:01:14.837937
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text"""
    from mimesis.enums import Locale
    from mimesis.enums import Language
    from mimesis.builtins import Text
    print(Text(Locale.es, Language.en).answer())


# Generated at 2022-06-23 22:01:17.499509
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert type(text.rgb_color()) == tuple
    assert len(text.rgb_color()) == 3

# Generated at 2022-06-23 22:01:18.857221
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert(type(t.title()) == str)

# Generated at 2022-06-23 22:01:20.575521
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print('Input lower true: ' + str(Text().alphabet(lower_case=True)))


# Generated at 2022-06-23 22:01:23.188257
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    r = Text()
    rr = r.hex_color()
    assert len(rr) == 7 and rr[0] == '#'


# Generated at 2022-06-23 22:01:26.258916
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    cnt = 0
    while cnt < 5:
        cnt += 1
        print(Text().swear_word())
