

# Generated at 2022-06-23 21:51:35.691085
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Locale

    t = Text()
    assert t._data['level'] == ['critical', 'low', 'medium', 'high', 'safe']
    t.reset_seed()

    t2 = Text(seed=42, locale=Locale.PT_BR)
    assert t2._data['level'] == ['critico', 'baixo', 'medio', 'alto', 'seguro']
    t2.reset_seed()


# Generated at 2022-06-23 21:51:40.746349
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    words = text.words(quantity=5)
    words_random_1 = text.random.choice(words)
    words_random_2 = text.random.choice(words)
    assert len(words) == 5
    assert words[0] != words[1]
    assert words_random_1 != words_random_2

# Generated at 2022-06-23 21:51:46.893302
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('en')
    for alphabet in text.alphabet(lower_case=True):
        assert alphabet in "abcdefghijklmnopqrstuvwxyz"

    for alphabet in text.alphabet(lower_case=False):
        assert alphabet in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


# Generated at 2022-06-23 21:51:51.182926
# Unit test for constructor of class Text
def test_Text():
    # Default constructor without any parameters
    text = Text()
    assert isinstance(text, Text), 'Default constructor should return Text object'

    # Constructor with parameters as (locale, seed)
    text = Text(seed=10, locale='Da')
    assert isinstance(text, Text), 'local constructor should return Text object'


# Generated at 2022-06-23 21:51:52.679427
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    t.alphabet(lower_case=True)


# Generated at 2022-06-23 21:51:55.818763
# Unit test for method words of class Text
def test_Text_words():
    words = Text(seed = 12345).words(quantity = 10)
    assert words == ['charisma', 'wrist', 'cautious', 'shoes', 'feet', 'feet', 'eggs', 'network', 'science', 'science']
    words = Text(seed = 54321).words(quantity = 10)
    assert words == ['soccer', 'soccer', 'network', 'science', 'volume', 'shoes', 'science', 'network', 'god', 'military']


# Generated at 2022-06-23 21:51:59.179671
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from mimesis.builtins import Text
    l = Text(Locale.EN)
    assert l.level() in ['critical', 'high', 'medium', 'low', 'dangerous']

# Generated at 2022-06-23 21:52:01.384460
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    your_text = text.text()
    assert your_text != ""


# Generated at 2022-06-23 21:52:05.087060
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    txt = Text()
    assert txt.rgb_color() in [(252, 85, 32), (214, 52, 107), (0, 0, 0), (255, 255, 255), (242, 255, 0)]


# Generated at 2022-06-23 21:52:07.453986
# Unit test for method words of class Text
def test_Text_words():
    for i in range(10):
        x = Text().words()
        print(x)


# Generated at 2022-06-23 21:52:08.590689
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text('en')
    assert text.answer() in ['Yes', 'No', 'Perhaps', 'Don\'t know']



# Generated at 2022-06-23 21:52:10.341333
# Unit test for method color of class Text
def test_Text_color():
    """Test box code."""
    color = Text().color()
    assert color != None

# Generated at 2022-06-23 21:52:13.597875
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    res = t.answer()
    assert len(res) > 0
    assert isinstance(res, str)
    assert res in t._data['answers']

# Generated at 2022-06-23 21:52:19.181706
# Unit test for constructor of class Text
def test_Text():
    # Without initialization of class Text
    with pytest.raises(TypeError) as excinfo:
        Text()
    assert '__init__() missing 1 required positional argument' in str(excinfo.value)
    # With initialization of class Text
    text = Text('ru')
    assert text is not None


# Generated at 2022-06-23 21:52:22.438139
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text."""
    text = Text('en')
    t = text.color()
    assert isinstance(t, str)
    assert t in ('Red', 'Green', 'Yellow', 'Gray')


# Generated at 2022-06-23 21:52:24.370019
# Unit test for method sentence of class Text
def test_Text_sentence():
    test_method = Text()
    assert type(test_method.sentence()) == str


# Generated at 2022-06-23 21:52:26.571269
# Unit test for method color of class Text
def test_Text_color():
    """Test method color of class Text."""
    text = Text('en')
    color = text.color()
    assert isinstance(color, str)

# Generated at 2022-06-23 21:52:28.684310
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    for _ in range(0, 100):
        assert text.quote()


# Generated at 2022-06-23 21:52:31.081904
# Unit test for method title of class Text
def test_Text_title():
    t1 = Text(seed=1337)
    ans = t1.title()

    assert ans == "Kitten"

# Generated at 2022-06-23 21:52:33.446105
# Unit test for method words of class Text
def test_Text_words():
    assert Text().words(quantity=10) == ['science', 'network', 'god', 'octopus', 'love', 'eat', 'dog', 'cat', 'germany', 'website']

# Generated at 2022-06-23 21:52:35.035139
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-23 21:52:44.947784
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    alpha = Text("en").alphabet(lower_case=True)
    assert len(alpha) == 26
    assert alpha == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    alpha = Text("en").alphabet(lower_case=False)
    assert len(alpha) == 26

# Generated at 2022-06-23 21:52:46.984217
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())


# Generated at 2022-06-23 21:52:49.062727
# Unit test for method answer of class Text
def test_Text_answer():
    print("Test Text.answer()")

    data = Text().answer()
    print(data)


# Generated at 2022-06-23 21:52:53.062489
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    text = Text(locale=Locale.GERMANY)
    for x in range(50):
        print(x+1, text.swear_word())


# Generated at 2022-06-23 21:52:56.478332
# Unit test for method words of class Text
def test_Text_words():
    t = Text('en')
    w = t.words(1)
    assert len(w) == 1

    w = t.words(100)
    assert len(w) == 100

# Generated at 2022-06-23 21:52:58.735837
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    s = t.text(quantity=1)
    assert s not in ('', [], (), {})

# Generated at 2022-06-23 21:53:01.003341
# Unit test for method color of class Text
def test_Text_color():
    for i in range(0,len(Text().color())):
        assert Text().color()[i]
    return

# Generated at 2022-06-23 21:53:02.517261
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert not sentence

# Generated at 2022-06-23 21:53:04.946591
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result in text._data['level']


# Generated at 2022-06-23 21:53:06.741456
# Unit test for method words of class Text
def test_Text_words():
    words_list = self.words()
    assert self.random.choice(words_list) in words_list

# Generated at 2022-06-23 21:53:09.242968
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.builtins import Text
    txt = Text(seed=777)
    result1 = txt.alphabet(lower_case=False)
    assert len(result1) == 26

    result2 = txt.alphabet(lower_case=True)
    assert len(result2) == 26

#Unit test for method level of class Text

# Generated at 2022-06-23 21:53:11.273626
# Unit test for method words of class Text
def test_Text_words():
    x = Text()
    assert len(x.words()) == 5
    assert len(x.words(1)) == 1


# Generated at 2022-06-23 21:53:12.741909
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in ("Yes", "No", "Maybe")

# Generated at 2022-06-23 21:53:15.915863
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-23 21:53:17.189615
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert t.title()

# Generated at 2022-06-23 21:53:19.430864
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert isinstance(text.swear_word(), str)


# Generated at 2022-06-23 21:53:21.450343
# Unit test for method color of class Text
def test_Text_color():
    text = Text()

    liste_string = []
    for _ in range(100):
        color = text.color()
        liste_string.append(color)
    for color in text._data['color']:
        assert color in liste_string

# Generated at 2022-06-23 21:53:27.974495
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Locales
    from mimesis.providers.date import Datetime
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet

    t = Text(locale=Locales.EN)
    text = t.text(quantity=1)
    print('Text: ' + text)

    w = Text(locale=Locales.DE)
    words = w.words(quantity=3)
    print('Words: ' + str(words))

    text = Text(locale=Locales.RU)
    print('Sentence: ' + text.sentence())

    text = Text(locale=Locales.DE)
    print('Title: ' + text.title())

    text = Text(locale=Locales.RU)
   

# Generated at 2022-06-23 21:53:31.083052
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    lang = Text(seed=0)
    assert lang.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'
    assert lang.alphabet(lower_case=False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'



# Generated at 2022-06-23 21:53:33.431932
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    a = t.sentence()
    print(a)


# Generated at 2022-06-23 21:53:35.654217
# Unit test for method quote of class Text
def test_Text_quote():
    loc = 'sk'
    text = Text(loc)
    test = text.quote()
    assert test in Text(loc)._data['quotes']

# Generated at 2022-06-23 21:53:36.326549
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print('\n',Text.swear_word())

# Generated at 2022-06-23 21:53:44.119183
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locales
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import DEUSpecProvider
    from mimesis.builtins import UKSpecProvider

    locale = RussiaSpecProvider.Meta.locales[0]
    r = Text(locale, seed=8)
    d = Text(locale, seed=8)
    assert r.level() == d.level()
    assert isinstance(r.level(), str)

    locale = DEUSpecProvider.Meta.locales[0]
    r = Text(locale, seed=8)
    d = Text(locale, seed=8)
    assert r.level() == d.level()
    assert isinstance(r.level(), str)

    locale

# Generated at 2022-06-23 21:53:46.419397
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3

# Generated at 2022-06-23 21:53:48.120509
# Unit test for method level of class Text
def test_Text_level():
    result = Text().level()
    assert result in ['critical']

# Generated at 2022-06-23 21:53:50.707244
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    t = Text()
    print(t.alphabet(lower_case=True))


# Generated at 2022-06-23 21:53:55.561862
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_provider = Text('en')
    for i in range(3):
        print(text_provider.rgb_color(safe=False))
    print('\n')
    for i in range(3):
        print(text_provider.rgb_color(safe=True))


# Generated at 2022-06-23 21:53:57.051174
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']


# Generated at 2022-06-23 21:53:57.920754
# Unit test for constructor of class Text
def test_Text():
    Text(locale='en')


# Generated at 2022-06-23 21:54:02.545139
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text.hex_color(Text())
    assert len(color) == 7

    color = Text.hex_color(Text(), safe = True)
    assert color in SAFE_COLORS



# Generated at 2022-06-23 21:54:03.513769
# Unit test for constructor of class Text
def test_Text():
    t = Text()


# Generated at 2022-06-23 21:54:04.308324
# Unit test for constructor of class Text
def test_Text():
    text = Text("en")


# Generated at 2022-06-23 21:54:09.822291
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test that swear_word method of class Text return a random swear word."""
    text = Text(seed=123)
    swear_word = text.swear_word()
    assert swear_word == 'Хуйня'


# Generated at 2022-06-23 21:54:11.179894
# Unit test for method color of class Text
def test_Text_color():
    assert Text().color() in Text()._data['color']

# Generated at 2022-06-23 21:54:12.161027
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())


# Generated at 2022-06-23 21:54:14.657477
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Languages
    from mimesis.providers.text import Text
    text = Text(Languages.RUSSIAN)
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-23 21:54:16.549595
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text()
    for i in range(0, 5):
        provider.seed(i)
        assert provider.answer() in ["No", "Yes"]

# Generated at 2022-06-23 21:54:17.986117
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    color = txt.color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:54:21.948149
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import __version__, __api_version__, __locales__
    from mimesis.providers.text import Text
    text = Text()
    # import pdb; pdb.set_trace()
    result = text.words(quantity=5)
    assert len(result) == 5
    assert isinstance(result, list)


# Generated at 2022-06-23 21:54:30.977803
# Unit test for method word of class Text
def test_Text_word():
    t = Text(seed=42)
    assert t.word() == 'Science'
    assert t.word(seed=0) == 'science'
    assert t.word(seed=1) == 'network'
    assert t.word(seed=2) == 'god'
    assert t.word(seed=3) == 'octopus'
    assert t.word(seed=4) == 'love'
    assert t.word(seed=5) == 'appetite'
    assert t.word(seed=6) == 'perfect'
    assert t.word(seed=7) == 'healthy'
    assert t.word(seed=8) == 'satisfied'
    assert t.word(seed=9) == 'imaginary'
    assert t.word(seed=10) == 'bored'

# Generated at 2022-06-23 21:54:33.114003
# Unit test for method title of class Text
def test_Text_title():
    provider = Text()
    title = provider.title()
    assert provider.text(quantity=1) == title


# Generated at 2022-06-23 21:54:35.113880
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    for _ in range(0, 10):
        print(text.text())


# Generated at 2022-06-23 21:54:38.806289
# Unit test for method word of class Text
def test_Text_word():
    """Test for method word of class Text"""
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-23 21:54:42.794500
# Unit test for method answer of class Text
def test_Text_answer():
    # Set up
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    t = Text()

    # Exercise
    result = t.answer()

    # Verify
    assert result in t._data['answers']


# Generated at 2022-06-23 21:54:45.747322
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test method alphabet of class Text"""
    locale = 'en'
    t = Text(locale)
    assert 'az' in t.alphabet()
    assert 'AZ' in t.alphabet()

    locale = 'ru'
    t = Text(locale)
    assert 'ая' in t.alphabet()
    assert 'АЯ' in t.alphabet()


# Generated at 2022-06-23 21:54:48.376340
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=4)
    assert len(words) == 4
    for word in words:
        assert isinstance(word, str)


# Generated at 2022-06-23 21:54:55.229841
# Unit test for method quote of class Text
def test_Text_quote():
    t1 = Text(seed=0)
    assert t1.quote() == '"Bond... James Bond."', \
        "The quote isn't suitable for English"

    t2 = Text(seed=0, locale='ru')
    assert t2.quote() == '«Кто здесь?»', \
        "The quote isn't suitable for Russian"



# Generated at 2022-06-23 21:54:57.735797
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import DataField

    print(Text().alphabet(DataField.LOWERCASE))
    print(Text().alphabet(DataField.UPPERCASE))
    print(Text().alphabet())


# Generated at 2022-06-23 21:54:59.835268
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    for _ in range(50):
        assert text.sentence()


# Generated at 2022-06-23 21:55:02.287734
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words(quantity=4)) != len(t.words(quantity=4))


# Generated at 2022-06-23 21:55:03.850061
# Unit test for constructor of class Text
def test_Text():
    # Test Text
    assert Text('en').level() in ['critical', 'normal']

# Generated at 2022-06-23 21:55:06.641522
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    # t.random.seed(1135)
    assert t.level() == 'critical'
    assert t.level() == 'critical'
    assert t.level() == 'critical'

# Generated at 2022-06-23 21:55:13.505496
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.text import Text

    text = Text(RussiaSpecProvider(gender=Gender.FEMALE))
    for _ in range(10):
        assert text.color() in ['Коричневый', 'Серый', 'Черный', 'Белый', 'Розовый']


# Generated at 2022-06-23 21:55:22.840011
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Locales
    from mimesis.providers.text import Text
    assert Text(Locales.EN).word() == 'Science'
    assert Text(Locales.RU).word() == 'Счастье'
    assert Text(Locales.DE).word() == 'Computer'
    assert Text(Locales.IT).word() == 'Amare'
    assert Text(Locales.ES).word() == 'Entretenimiento'
    assert Text(Locales.FR).word() == 'Vie'
    assert Text(Locales.ZH).word() == '探索'
    assert Text(Locales.JA).word() == '道楽'
    assert Text(Locales.KO).word() == '여름'

# Generated at 2022-06-23 21:55:34.756961
# Unit test for method color of class Text
def test_Text_color():
    x=Text.color(Text)
    assert x == 'Red' or x == 'Green' or x == 'Blue' or x == 'Red' or x == 'Green' or x == 'Blue' or x == 'Red' or x == 'Green' or x == 'Blue' or x == 'Blue' or x == 'Yellow' or x == 'Pink' or x == 'Green' or x == 'Blue' or x == 'Blue' or x == 'Yellow' or x == 'Pink' or x == 'Green' or x == 'Blue' or x == 'Blue' or x == 'Yellow' or x == 'Pink' or x == 'Green' or x == 'Blue' or x == 'Blue' or x == 'Yellow' or x == 'Pink' or x == 'Green' or x == 'Blue' or x == 'Blue' or x == 'Yellow' or x

# Generated at 2022-06-23 21:55:41.386684
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender

    text = Text()
    generated_text = text.sentence()

    assert isinstance(generated_text, str)

    text = Text(Gender.MALE)
    generated_text = text.sentence()
    assert isinstance(generated_text, str)

    text = Text(Gender.FEMALE)
    generated_text = text.sentence()
    assert isinstance(generated_text, str)

    text = Text(Gender.NEUTRAL)
    generated_text = text.sentence()
    assert isinstance(generated_text, str)


# Generated at 2022-06-23 21:55:43.776302
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(seed=123)
    assert text.answer() is 'Yes'



# Generated at 2022-06-23 21:55:46.948700
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert type(title) == str
    assert len(title) > 2


# Generated at 2022-06-23 21:55:48.926806
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    t.rgb_color()


# Generated at 2022-06-23 21:55:50.381245
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert type(text.sentence()) == str


# Generated at 2022-06-23 21:55:53.519050
# Unit test for method title of class Text
def test_Text_title():
    print("Test case: title")
    text = Text()
    print("\toutput:", text.title())

    # Result should be string
    assert type(text.title()) is str


# Generated at 2022-06-23 21:55:56.095210
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis import Text
    my_text = Text('en')
    print(my_text.alphabet(True))
    print(my_text.alphabet())


# Generated at 2022-06-23 21:55:57.891017
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert not text.answer()
    assert text.answer()


# Generated at 2022-06-23 21:55:58.910559
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert(text.quote())

# Generated at 2022-06-23 21:56:00.946986
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    text = Text()
    assert isinstance(text.swear_word(), str)

# Generated at 2022-06-23 21:56:10.676672
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text.alphabet()
    assert t == ['A','B','C','D','E','F','G','H','I','J','K','L','M','N',
                 'O','P','Q','R','S','T','U','V','W','X','Y','Z']
    t = Text.alphabet(lower_case=True)
    assert t == ['a','b','c','d','e','f','g','h','i','j','k','l','m','n',
                 'o','p','q','r','s','t','u','v','w', 'x', 'y', 'z']


# Generated at 2022-06-23 21:56:11.769743
# Unit test for method color of class Text
def test_Text_color():
    Text().color()


# Generated at 2022-06-23 21:56:13.179932
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text(1) !=""


# Generated at 2022-06-23 21:56:14.466245
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    txt = Text()
    txt.alphabet()



# Generated at 2022-06-23 21:56:16.959374
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    result = t.color()
    assert isinstance(result, str)
    assert result in t._data['color']


# Generated at 2022-06-23 21:56:20.357891
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(locale='ru')
    swear_word_list = set()
    for _ in range(1000):
        swear_word = t.swear_word()
        assert swear_word not in swear_word_list
        swear_word_list.add(swear_word)
    assert len(swear_word_list) > 1

# Generated at 2022-06-23 21:56:23.727415
# Unit test for method words of class Text
def test_Text_words():
    c = Text()
    m = c.words(quantity=1)
    if isinstance(m, list):
        return True
    else:
        return False
# print(test_Text_words())

# Generated at 2022-06-23 21:56:26.459281
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    t = Text()
    assert(t.answer() in t._data['answers'])
# End test


# Generated at 2022-06-23 21:56:29.439905
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() == 'He s chances of becoming a caddie.'


# Generated at 2022-06-23 21:56:32.111535
# Unit test for method title of class Text
def test_Text_title():
    # Create the text object
    text = Text()

    for _ in range(100):
        t = text.title()
        assert len(t.split()) >= 3


# Generated at 2022-06-23 21:56:33.806916
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    assert text.quote() == "Bond... James Bond."

# Generated at 2022-06-23 21:56:35.899259
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en') 
    data = text.swear_word() 
    assert(isinstance(data, str))
    

# Generated at 2022-06-23 21:56:36.826655
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text"""
    pass


# Generated at 2022-06-23 21:56:38.827166
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussiaSpecProvider
    x = RussiaSpecProvider()
    assert x.text.sentence() != x.text.sentence()


# Generated at 2022-06-23 21:56:40.393453
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    print(text.answer())

# Generated at 2022-06-23 21:56:43.393236
# Unit test for method title of class Text
def test_Text_title():
    text_text = Text()
    title = text_text.title()
    assert isinstance(title, str)
    # Unit test for method level of class Text

# Generated at 2022-06-23 21:56:46.709981
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    random_words = text.words(quantity=1)
    assert len(random_words) == 1
    assert isinstance(random_words, list)


# Generated at 2022-06-23 21:56:52.403723
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    expected_hex_color_1 = '#d8346b'
    expected_hex_color_2 = '#6F8DB6'
    actual_hex_color_1 = Text().hex_color()
    actual_hex_color_2 = Text().hex_color()
    assert expected_hex_color_1 == actual_hex_color_1
    assert expected_hex_color_2 == actual_hex_color_2
    print(actual_hex_color_1)
    print(actual_hex_color_2)


# Generated at 2022-06-23 21:56:58.484086
# Unit test for method title of class Text
def test_Text_title():
    """Test method title of class Text."""
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.tools import random_datetime

    t = Text(Locale.EN)
    for _ in range(100):
        title = t.title()
        assert isinstance(title, str) and len(title) > 0
        print(title)


# Generated at 2022-06-23 21:56:59.873793
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() in ['Damn', 'Son of a bitch']

# Generated at 2022-06-23 21:57:04.970024
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet(lower_case=False)) == 26
    assert len(text.alphabet(lower_case=True)) == 26
    assert text.alphabet(lower_case=False)[0:5] == ['A', 'B', 'C', 'D', 'E']
    assert text.alphabet(lower_case=True)[0:5] == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-23 21:57:10.626234
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Brand, Service

    a = Text('en')
    print(a.word())
    print(a.sentence())
    print(a.text())
    print(a.title())
    for _ in range(10):
        print(a.hex_color())

    # print(a.word())
    # print(a.quote())
    # print(a.color())

    # print(a.rgb_color())
    # print(a.rgb_color(safe=False))


# Generated at 2022-06-23 21:57:12.534186
# Unit test for method title of class Text
def test_Text_title():
    text = Text('en')
    assert text.title() != text.title()



# Generated at 2022-06-23 21:57:14.613735
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None


# Generated at 2022-06-23 21:57:16.997540
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color())
    print(t.hex_color(safe=True))



# Generated at 2022-06-23 21:57:17.835869
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text(locale='en')
    print(t.sentence())

# Generated at 2022-06-23 21:57:19.614492
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    print("Sentence:")
    print(txt.sentence())


# Generated at 2022-06-23 21:57:25.905601
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test Text.hex_color()"""
    t = Text()
    res = t.hex_color()
    assert isinstance(res, str)
    assert len(res) == 7
    assert res[:1] == '#'

    res = t.hex_color(safe=True)
    assert isinstance(res, str)
    assert len(res) == 7
    assert res[:1] == '#'
    assert res in SAFE_COLORS


# Generated at 2022-06-23 21:57:27.962184
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text)


# Generated at 2022-06-23 21:57:32.901145
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text
    assert isinstance(text.title(), str)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.rgb_color(True), tuple)
    assert isinstance(text.color(), str)

# Generated at 2022-06-23 21:57:38.155185
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text(seed=589)
    assert txt.quote() == "I don't care if you're black, white, straight, bisexual, gay, lesbian, short, tall, fat, skinny, rich or poor. If you're nice to me, I'll be nice to you. Simple as that."


# Generated at 2022-06-23 21:57:40.499354
# Unit test for method color of class Text
def test_Text_color():
    print()
    print("\tText().color()")
    # Code here
    print(Text().color())



# Generated at 2022-06-23 21:57:42.114647
# Unit test for method quote of class Text
def test_Text_quote():
    print(Text().quote())
# '"Bond... James Bond."'

# Generated at 2022-06-23 21:57:44.526493
# Unit test for method title of class Text
def test_Text_title():
  assert Text.get_random_sample(provider=Text(), method_name='title', data_field='title')


# Generated at 2022-06-23 21:57:46.817385
# Unit test for method sentence of class Text
def test_Text_sentence():
    for x in range(10000):
        text = Text('en')
        text.sentence()


# Generated at 2022-06-23 21:57:48.350885
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert isinstance(text.word(), str)

# Generated at 2022-06-23 21:57:51.963097
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())
    print(text.words())
    print(text.quote())
    print(text.text())
    print(text.level())



# Generated at 2022-06-23 21:57:53.254430
# Unit test for method title of class Text
def test_Text_title():
    provider = Text()
    assert provider.title() is not None

# Generated at 2022-06-23 21:57:56.525522
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    t = Text()
    assert len(t.words()) == 5

# Generated at 2022-06-23 21:57:58.848653
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_provider = Text()
    alphabet = text_provider.alphabet()
    assert len(alphabet) == 26


# Generated at 2022-06-23 21:58:03.925915
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.providers.text import Text

    t = Text(locale=Locale.RU)
    bad_words = t._data['words'].get('bad')
    assert t.swear_word() in bad_words

# Generated at 2022-06-23 21:58:06.831101
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    for i in range(1, 1000):
        if text.quote() != quote:
            break
    
    assert i != 999
    

# Generated at 2022-06-23 21:58:08.808853
# Unit test for method level of class Text
def test_Text_level():
    print("Test level method of Text class")
    TEST = Text()
    print("A random level is ", TEST.level())



# Generated at 2022-06-23 21:58:11.565868
# Unit test for method sentence of class Text
def test_Text_sentence():
    """
    Unit test for method sentence of class Text.
    """
    text = Text('en')
    result = text.sentence()
    assert isinstance(result, str)
    assert result.count(' ') == 1



# Generated at 2022-06-23 21:58:12.749484
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print(Text().rgb_color(safe=True))


# Generated at 2022-06-23 21:58:13.977844
# Unit test for method quote of class Text
def test_Text_quote():
    test = Text()
    assert test.quote() in test._data['quotes']

# Generated at 2022-06-23 21:58:17.533491
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.data import IANA_LANGUAGES
    text=Text(seed=1)
    result = text.title()
    assert result in IANA_LANGUAGES


# Generated at 2022-06-23 21:58:19.818130
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from pprint import pprint
    obj = Text()
    rgb = obj.rgb_color()
    pprint(rgb)

# Generated at 2022-06-23 21:58:23.633024
# Unit test for method words of class Text
def test_Text_words():
    txt = Text()
    normal_words = txt.words()
    assert isinstance(normal_words, list)
    assert len(normal_words) == 5
    assert normal_words[0] in txt._data['words']['normal']


# Generated at 2022-06-23 21:58:26.721288
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    text.hex_color()
    text.hex_color(safe=True)
    text.random.choice(SAFE_COLORS)


# Generated at 2022-06-23 21:58:29.258920
# Unit test for method quote of class Text
def test_Text_quote():
    """test Text.quote()"""
    text = Text()
    print(text.quote())
    print(text.quote())


# Generated at 2022-06-23 21:58:31.107502
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']


# Generated at 2022-06-23 21:58:32.478448
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())



# Generated at 2022-06-23 21:58:35.324636
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Languages
    from mimesis.providers.text import Text

    text = Text(Languages.EN)
    assert text.color() in text._data['color']

# Generated at 2022-06-23 21:58:36.410699
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert len(Text().alphabet()) == 26
    assert len(Text().alphabet(True)) == 26

# Generated at 2022-06-23 21:58:38.698041
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    x = t.level()
    assert isinstance(x, str)
    assert len(x) > 0
    assert x.islower()


# Generated at 2022-06-23 21:58:42.839752
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of class Text
        and check if the result is as expected."""
    text = Text()
    swear_word = text.swear_word()
    print(swear_word)
    assert swear_word in ['hell', 'damn', 'asshole']


# Generated at 2022-06-23 21:58:47.807858
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text('en')
    hc = t.hex_color()
    assert len(hc) == 7

    assert hc.startswith('#')

    assert len(t.hex_color(safe=True).strip('#')) == 6


# Generated at 2022-06-23 21:58:54.875002
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender

    t = Text()
    result = t.words()

    assert len(result) == 5
    assert result[0].isalpha()

    t.set_locale('ru')

    result = t.words()
    assert len(result) == 5
    assert result[0].isalpha()

    # Test for Gender
    result = t.words(gender=Gender.FEMALE)
    assert len(result) == 5
    assert result[0].isalpha()

# Generated at 2022-06-23 21:58:58.606266
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    answer = text.quote()
    print(answer)
    assert isinstance(answer, str)

if __name__ == "__main__":
    test_Text_quote()

# Generated at 2022-06-23 21:59:02.529543
# Unit test for method color of class Text
def test_Text_color():
    # Initialize the pseudo-random generator
    import random
    random.seed(10)
    # Create object of class Text
    text = Text(seed=10)
    # Get a color
    color = text.color()
    assert(color == 'Olive')

# Generated at 2022-06-23 21:59:04.529166
# Unit test for method level of class Text
def test_Text_level():
    """Test Text.level method."""
    text_ob = Text()
    assert isinstance(text_ob.level(), str)


# Generated at 2022-06-23 21:59:14.502606
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Format

    provider = Text()

    # Test all formats
    assert provider.word(format_='lower') == provider.word(format_='lower_case')
    assert provider.word(format_='UPPER') == provider.word(format_='UPPER_CASE')
    assert provider.word(format_='camel') == provider.word(format_='camel_case')
    assert provider.word(format_='pascal') == provider.word(format_='pascal_case')
    assert provider.word(format_='kebab') == provider.word(format_='kebab_case')
    assert provider.word(format_='snake') == provider.word(format_='snake_case')

# Generated at 2022-06-23 21:59:16.394848
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = Text(seed = 12345678901234567890).hex_color()
    assert result == '#1b8a06'

# Generated at 2022-06-23 21:59:20.982242
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.localization import EN
    from mimesis.providers.text import Text

    provider = Text(EN)
    hex_color = provider.hex_color()

    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert isinstance(provider.hex_color(safe=True), str)


# Generated at 2022-06-23 21:59:23.110453
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    tmp = Text()
    assert len(tmp.swear_word()) > 0
    assert isinstance(tmp.swear_word(), str)

# Generated at 2022-06-23 21:59:25.770524
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    p = Text()
    print (p.rgb_color())


# Generated at 2022-06-23 21:59:30.711015
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert isinstance(text.alphabet(), list)
    assert len(text.alphabet()) == 26
    assert all([x in text.alphabet() for x in "abcdefghijklmnopqrstuvwxyz"])


# Generated at 2022-06-23 21:59:34.137268
# Unit test for method level of class Text
def test_Text_level():
    from mimesis import Text
    import pytest

    my_text = Text()
    my_level = my_text.level()

    assert isinstance(my_level, str)
    assert my_level in my_text._data['level']


# Generated at 2022-06-23 21:59:36.820474
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    answer = text.sentence()
    assert isinstance(answer, str) is True


# Generated at 2022-06-23 21:59:38.236212
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    for _ in range(100):
        assert Text().alphabet(lower_case=True) != Text().alphabet()


# Generated at 2022-06-23 21:59:39.618440
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    x = Text(seed=123)
    assert x.hex_color() == '#22a6b3', "Should return '#22a6b3'"

# Generated at 2022-06-23 21:59:40.457818
# Unit test for method word of class Text
def test_Text_word():
    text = Text()

    assert len(text.word()) > 0


# Generated at 2022-06-23 21:59:42.015557
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)

# Generated at 2022-06-23 21:59:44.610252
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() is not None

# Generated at 2022-06-23 21:59:46.742938
# Unit test for method text of class Text
def test_Text_text():
    print(Text().text())
    print(Text().text(quantity=10))
    print(Text().text(quantity=1))


# Generated at 2022-06-23 21:59:49.499338
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No']

# Generated at 2022-06-23 21:59:51.937029
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words = t.words()
    words_len = len(words)
    assert (isinstance(words, list), words_len == 5)

# Generated at 2022-06-23 21:59:53.290175
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    print(t.level())



# Generated at 2022-06-23 21:59:56.202786
# Unit test for method words of class Text
def test_Text_words():
    provider = Text()
    res1 = provider.words(quantity=3)
    res2 = provider.words(quantity=7)
    assert len(res1) == 3
    assert len(res2) == 7



# Generated at 2022-06-23 21:59:58.286734
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    result = t.words(quantity = 4)
    if len(result) != 4:
        raise Exception('Wrong length')
    else:
        print('Test success!')


# Generated at 2022-06-23 21:59:59.586962
# Unit test for method answer of class Text
def test_Text_answer():
    '''Unit test for method answer of class Text'''
    txt = Text()
    assert txt.answer() in ['Yes', 'No']

# Generated at 2022-06-23 22:00:04.339482
# Unit test for method answer of class Text
def test_Text_answer():
    from pprint import pprint as pp
    from .language import Language
    from .localization import Localization

    language = Language()
    l = Localization(language.code)
    t = Text(l)
    result = t.answer()
    assert result is not None
    pp(result)

# Generated at 2022-06-23 22:00:07.428911
# Unit test for method level of class Text
def test_Text_level():
    # Arrange
    t = Text()
    t.seed(1)
    # Act
    result = t.level()
    # Assert
    assert result == 'critical'


# Generated at 2022-06-23 22:00:09.212001
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    text.color()

# Generated at 2022-06-23 22:00:10.921794
# Unit test for method hex_color of class Text
def test_Text_hex_color():
        t = Text()
        assert isinstance(t.hex_color(), str)

# Generated at 2022-06-23 22:00:13.280856
# Unit test for method words of class Text
def test_Text_words():
    """
    Test method of words from class Text
    :return:
    """
    text = Text()
    text.words()

# Generated at 2022-06-23 22:00:16.277669
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method Text.answer."""
    from mimesis.enums import Locale
    t = Text(Locale.US)
    print(t.answer())

# Generated at 2022-06-23 22:00:18.487404
# Unit test for method title of class Text
def test_Text_title():
	
	from mimesis.enums import Gender
	from mimesis.builtins import Text
	print(Text().title())


# Generated at 2022-06-23 22:00:20.636936
# Unit test for method word of class Text
def test_Text_word():
    a = Text()
    for i in range(100):
        assert isinstance(a.word(), str)


# Generated at 2022-06-23 22:00:22.666722
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    answer = text.rgb_color()
    assert isinstance(answer, tuple)


# Generated at 2022-06-23 22:00:24.536183
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    for i in range(20):
        #assert len(text.word()) == 2
        print(text.word())


# Generated at 2022-06-23 22:00:26.724541
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=123)
    text.text()


# Generated at 2022-06-23 22:00:32.200032
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    result1 = text.hex_color()
    assert len(result1) == 7
    assert result1.startswith('#')

    result2 = text.hex_color(safe=True)
    assert len(result2) == 7
    assert result2 in SAFE_COLORS

# Generated at 2022-06-23 22:00:33.288435
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert isinstance(text.word(), str)
    assert len(text.word()) > 0


# Generated at 2022-06-23 22:00:34.347101
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    text.answer()


# Generated at 2022-06-23 22:00:35.316559
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    print(text.answer())

# Generated at 2022-06-23 22:00:40.906868
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=123)
    alphabet = text.alphabet()
    assert alphabet == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K',
                        'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
                        'W', 'X', 'Y', 'Z']


# Generated at 2022-06-23 22:00:43.290129
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text(quantity = 5) == "xyz abc asd qwe ewq"


# Generated at 2022-06-23 22:00:48.608207
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    text = Text('ru', seed=10)
    actual = text.swear_word()
    expected = 'ебанат'
    assert actual == expected

    rs = RussiaSpecProvider(seed=10)
    actual = rs.person(gender=Gender.FEMALE).swear_word()
    assert actual == expected

# Generated at 2022-06-23 22:00:51.760148
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale

    a = Text(locale=Locale.EN)

    assert a.swear_word() in a._data['words'].get('bad')

# Generated at 2022-06-23 22:00:54.910678
# Unit test for method text of class Text
def test_Text_text():
    text = Text('ru')
    text_res = text.text()
    assert isinstance(text_res, str)


# Generated at 2022-06-23 22:00:57.240004
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == "Text"



# Generated at 2022-06-23 22:00:59.892303
# Unit test for method title of class Text
def test_Text_title():
    for i in range(0, 10):
        t = Text()
        print(t.title())
        assert (len(t.title()) <= 20)


# Generated at 2022-06-23 22:01:01.412497
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)



# Generated at 2022-06-23 22:01:03.027403
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert a.name == 'text'


# Generated at 2022-06-23 22:01:05.101591
# Unit test for method word of class Text
def test_Text_word():
    from pprint import pprint
    user = Text()
    print(user)
    pprint("The word generated is: " + user.word())


# Generated at 2022-06-23 22:01:06.575409
# Unit test for constructor of class Text
def test_Text():
        demo = Text()
        res = demo.text()
        assert res



# Generated at 2022-06-23 22:01:08.216557
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert len(quote) > 0, "Text quote is empty"

# Generated at 2022-06-23 22:01:15.323671
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    en = Text(locale='en')
    assert True == (en.swear_word() in ['Shit', 'Fuck', 'Damn', 'Hell', 'Damn it'])
    assert True == (en.swear_word() in ['Shit', 'Fuck', 'Damn', 'Hell', 'Damn it'])
    assert True == (en.swear_word() in ['Shit', 'Fuck', 'Damn', 'Hell', 'Damn it'])
    assert True == (en.swear_word() in ['Shit', 'Fuck', 'Damn', 'Hell', 'Damn it'])
    assert True == (en.swear_word() in ['Shit', 'Fuck', 'Damn', 'Hell', 'Damn it'])

    es = Text(locale='es')

# Generated at 2022-06-23 22:01:20.297689
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    text = Text('en')
    rgb = text.rgb_color()
    assert len(rgb) == 3
    assert rgb[0] <= 255
    assert rgb[1] <= 255
    assert rgb[2] <= 255
    assert isinstance(rgb, tuple)

# Generated at 2022-06-23 22:01:22.436416
# Unit test for method sentence of class Text
def test_Text_sentence():
    tmp = Text()
    x = tmp.sentence()
    print(x)
    assert len(x) is not None


# Generated at 2022-06-23 22:01:23.337830
# Unit test for method word of class Text
def test_Text_word():
    assert 1 == 1


# Generated at 2022-06-23 22:01:26.762046
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Gender

    text = Text(gender=Gender.MALE, locale='zh')
    assert text.word() != ''

# Generated at 2022-06-23 22:01:31.899774
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text()
    # test for method quote of class Text
    assert txt.quote() == '"Bond... James Bond."'
    assert txt.quote() == '"Nobody\'s gonna hurt anybody. Not on my watch."'
    assert txt.quote() == '"Hello Clarice."'
    assert txt.quote() == '"I\'m going to make him an offer he can\'t refuse."'