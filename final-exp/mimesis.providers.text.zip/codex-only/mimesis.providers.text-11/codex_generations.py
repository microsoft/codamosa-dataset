

# Generated at 2022-06-23 21:51:26.215142
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    t = Text()
    assert len(t.hex_color()) == 7

# Generated at 2022-06-23 21:51:27.577490
# Unit test for method words of class Text
def test_Text_words():
    t = Text(locale='en')
    print(t.words())

# Generated at 2022-06-23 21:51:30.060551
# Unit test for method level of class Text
def test_Text_level():
    txt = Text()
    txt.level()

# Generated at 2022-06-23 21:51:32.240792
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())
    print(t.answer())



# Generated at 2022-06-23 21:51:34.325674
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    text = Text()
    assert isinstance(text.swear_word(), str)

# Generated at 2022-06-23 21:51:36.670083
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    words = text.words()
    assert len(words) == 5

# Generated at 2022-06-23 21:51:37.808486
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    Text_instance = Text()
    print(Text_instance.swear_word())


# Generated at 2022-06-23 21:51:41.656276
# Unit test for method color of class Text
def test_Text_color():
    # English
    color = Text(language='en').color()
    assert color in ('Red', 'Green', 'Blue')
    # Russian
    color = Text(language='ru').color()
    assert color in ('Красный', 'Зеленый', 'Голубой')

# Generated at 2022-06-23 21:51:48.868036
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words(1)) > 0
    assert len(text.words(2)) > 1
    assert len(text.words(3)) > 2
    assert len(text.words(4)) > 3
    assert len(text.words(5)) > 4
    assert len(text.words(6)) > 5
    assert len(text.words(7)) > 6
    assert len(text.words(8)) > 7


# Generated at 2022-06-23 21:51:49.849204
# Unit test for method color of class Text
def test_Text_color():
  print(Text().color())



# Generated at 2022-06-23 21:51:51.535463
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    r = Text()
    r.swear_word()
    assert "fuck" in r.swear_word()

# Generated at 2022-06-23 21:51:52.159635
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass

# Generated at 2022-06-23 21:51:54.282052
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    if type(t.hex_color()) is str:
        print("Method hex_color of class Text works!")

# Generated at 2022-06-23 21:51:57.041253
# Unit test for method color of class Text
def test_Text_color():
    """Unit test method color of class Text."""
    from mimesis.enums import Language
    text = Text(language=Language.ENGLISH)
    color = text.color()
    assert isinstance(color, str)

# Generated at 2022-06-23 21:52:00.035785
# Unit test for method sentence of class Text
def test_Text_sentence():
    s = Text()
    sentence = s.sentence()
    print(sentence)

if __name__ == "__main__":
    test_Text_sentence()

# Generated at 2022-06-23 21:52:12.047451
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    t.seed(0)

    assert len(t.alphabet()) == len(t.alphabet(True))
    assert t.level() in t._data['level']
    assert t.sentence() == t.title()
    assert len(t.words()) == 5
    assert len(t.words(2)) == 2
    assert len(t.words(9)) == 9
    assert t.word() in t._data['words']['normal']
    assert t.swear_word() in t._data['words']['bad']
    assert t.quote() in t._data['quotes']
    assert t.color() in t._data['color']
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(True)) == 7

# Generated at 2022-06-23 21:52:13.962322
# Unit test for method quote of class Text
def test_Text_quote():
    for _ in range(100):
        quote = Text().quote()
        if quote:
            print(quote)

# Generated at 2022-06-23 21:52:16.145215
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text()
    assert type(x.swear_word()) == str

# Generated at 2022-06-23 21:52:18.653843
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert isinstance(alphabet, list)


# Generated at 2022-06-23 21:52:28.468639
# Unit test for method color of class Text
def test_Text_color():
    # Initialize a text object
    t = Text(seed=0)
    # Generate a list of colors. Each color should be in the list

# Generated at 2022-06-23 21:52:32.108656
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    text = Text('en')
    assert text.level() in ['critical']


# Generated at 2022-06-23 21:52:35.679100
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    len_list = []
    for num in range(1000):
        len_list.append(len(t.hex_color()))
    assert all(elem == 7 for elem in len_list)


# Generated at 2022-06-23 21:52:39.306051
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-23 21:52:40.335493
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote()

# Generated at 2022-06-23 21:52:45.508820
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in [
        'Да', 'Нет', 'Не знаю',
        'Не определено', 'Неправильно',
        'Правильно', 'Оба', 'Ни один',
        'Ни тот, ни другой', 'Вероятно'
    ]

# Generated at 2022-06-23 21:52:46.492308
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert isinstance(text.swear_word(), str)

# Generated at 2022-06-23 21:52:50.881496
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method Text.swear_word()."""
    txt = Text()
    word = txt.swear_word()
    print(word)
    assert 1==1 #this is correct, just for testing


# Generated at 2022-06-23 21:53:01.048228
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test an ability of method Text.hex_color() to
    return str."""
    from inspect import isfunction
    from mimesis.enums import ColorType
    from mimesis.providers.text import Text
    t = Text('en')
    assert isfunction(t.hex_color)
    assert isinstance(t.hex_color(safe=True), str)
    assert len(t.hex_color(safe=True)) == 7
    assert isinstance(t.hex_color(safe=False), str)
    assert len(t.hex_color(safe=False)) == 7
    assert t.hex_color() == t.color(color_type=ColorType.HEX)


# Generated at 2022-06-23 21:53:02.563799
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert isinstance(t.title(), str)


# Generated at 2022-06-23 21:53:08.049655
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert  text.answer() in ['Yes', 'No', 'Maybe', 'Perhaps', 'Of course', 'I hope so', 'I hope not', 'Never', 'Possibly', 'Certainly', 'Absolutely', 'I am afraid so', 'Ask me later', 'Better not tell you now', 'Cannot predict now', 'Concentrate and ask again']



# Generated at 2022-06-23 21:53:11.526475
# Unit test for method level of class Text
def test_Text_level():
    #text = Text()
    #print(text.level())
    x = []
    for i in range(10):
        text = Text()
        x.append(text.level())
    x = set(x)
    print(x)
    

# Generated at 2022-06-23 21:53:16.988639
# Unit test for method color of class Text
def test_Text_color():

    local_text = Text(locale='en')
    assert local_text.color() == 'Red' or \
        local_text.color() == 'Blue' or \
        local_text.color() == 'Green' or \
        local_text.color() == 'Yellow' or \
        local_text.color() == 'Black' or \
        local_text.color() == 'White' or \
        local_text.color() == 'Orange'

    assert local_text.hex_color() == '#d8346b' or \
        local_text.hex_color() == '#d8346c' or \
        local_text.hex_color() == '#d8346d' or \
        local_text.hex_color() == '#d8346e' or \
        local_text.hex_color

# Generated at 2022-06-23 21:53:18.123175
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() is not None

# Generated at 2022-06-23 21:53:20.414243
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Language
    en_text = Text(Language.ENGLISH)
    result = en_text.title()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:53:22.081752
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()

    # result=provider.color()

    # print(result)



# Generated at 2022-06-23 21:53:23.672309
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    #Creates a Text object x
    x = Text('ru')
    #Generate a random swear word
    swear_word = x.swear_word()
    #Check if it contains bad words
    assert 'ХУЙ!' in swear_word

# Generated at 2022-06-23 21:53:29.842525
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.typing import Seed
    import random

    for _ in range(10):
        seed = random.randint(0, 100000000)
        text = Text(seed=seed)
        result = text.title()
        # If a seed is None, then the result will be different.
        text = Text(locale=Locale.RU, seed=seed)
        assert result == text.title()


# Generated at 2022-06-23 21:53:31.232085
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3

# Generated at 2022-06-23 21:53:36.292642
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.providers.text import Text
    from mimesis.enums import Gender
    
    # get a color from a Text instance
    text = Text('en')
    color = text.color()
    assert color is not None

    # get a gender from a Text instance
    gender = text.gender()
    assert gender == Gender.OTHER

# Generated at 2022-06-23 21:53:38.349718
# Unit test for method level of class Text
def test_Text_level():
	text_provider = Text()
	level = text_provider.level()
	assert isinstance(level,str)


# Generated at 2022-06-23 21:53:39.057525
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print(Text().rgb_color())


# Generated at 2022-06-23 21:53:44.561981
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Locale
    from mimesis.text import Text
    t = Text(Locale.ENGLISH)
    print(t.alphabet())
    print(t.level())
    print(t.text())
    print(t.sentence())
    print(t.title())
    print(t.words())
    print(t.word())
    print(t.swear_word())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())


test_Text()

# Generated at 2022-06-23 21:53:54.721138
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.text())
    print(text.sentence())
    print(text.title())
    print(text.words())
    print(text.word())
    print(text.swear_word())
    print(text.quote())
    print(text.color())
    print(text.hex_color())
    print(text.hex_color(safe=True))
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    print(text.answer())
    print(text.level())

if __name__ == "__main__" :
    test_Text()

# Generated at 2022-06-23 21:53:58.352984
# Unit test for method word of class Text
def test_Text_word():
    test_text = Text(seed=0)
    print("Get a random word: %s" % (test_text.word()))
    print("Get a random word: %s" % (test_text.word()))


# Generated at 2022-06-23 21:54:02.678531
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    new_text = Text()
    print('default alphabet:', new_text.alphabet())
    print('lower case alphabet:', new_text.alphabet(lower_case=True))


# Generated at 2022-06-23 21:54:04.972110
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text.
    """
    text = Text(seed=456)
    print("Generate one random quote: ", text.quote())


# Generated at 2022-06-23 21:54:09.484392
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Language
    from mimesis.mimesis import Mimesis
    m = Mimesis(language=Language.RUSSIAN)
    text = m.text()


# Generated at 2022-06-23 21:54:10.992531
# Unit test for method word of class Text
def test_Text_word():
    assert Text().word() == "Science"


# Generated at 2022-06-23 21:54:12.031187
# Unit test for method level of class Text
def test_Text_level():
    print(Text().level())
    

# Generated at 2022-06-23 21:54:14.288573
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.rgb_color())
    print(text.hex_color())


# Generated at 2022-06-23 21:54:16.841208
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert isinstance(text.swear_word(), str)
    assert text.swear_word() in text._data['words'].get('bad')


# Generated at 2022-06-23 21:54:18.438926
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    res = text.level()
    assert len(res)


test_Text_level()


# Generated at 2022-06-23 21:54:21.785052
# Unit test for method word of class Text
def test_Text_word():
    """Test method word of class Text.

    What it should do:
    It should return a random word.

    What it does:
    It does return a word.
    """
    provider = Text(seed=4)
    test_word = provider.word()
    assert test_word == 'science'


# Generated at 2022-06-23 21:54:24.277960
# Unit test for method quote of class Text
def test_Text_quote():
    """Checking the correctness of the method quote"""
    text = Text()
    quote = text.quote()

    assert isinstance(quote, str)

# Generated at 2022-06-23 21:54:26.763278
# Unit test for method title of class Text
def test_Text_title():
    # Initialize seed
    text = Text()
    # Generate title
    title = text.title()
    # Print title to console
    print(title)

test_Text_title()

# Generated at 2022-06-23 21:54:29.796928
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    text = Text(locale=Locale.EN)
    for a in range(1, 999999):
        _ = text.swear_word
        b = a
        if _ == "Crap":
            print(b)
            break

# Generated at 2022-06-23 21:54:31.150154
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # test_method = 'hex_color'
    # [TODO]
    pass


# Generated at 2022-06-23 21:54:33.009042
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    test_text = text.level()
    assert test_text != ''


# Generated at 2022-06-23 21:54:36.503692
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print("\n--- Method alphabet ---\n")

    t = Text('en')
    print(t.alphabet())
    print(t.alphabet(lower_case=True))


# Generated at 2022-06-23 21:54:41.781144
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    t = Text('en')
    person = Person('en')
    person.gender = Gender.MALE
    s = t.sentence()

    print("test_Text_sentence", s)


# Generated at 2022-06-23 21:54:44.140347
# Unit test for method title of class Text
def test_Text_title():
    # Parameters
    lang = 'en'
    quantity = 100
    title = ''
    # Call title method
    for i in range(quantity):
        title = Text(lang).title()
        # Verify if title method returns a string
        assert isinstance(title, str)


# Generated at 2022-06-23 21:54:45.336405
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert(t.swear_word() != None)

# Generated at 2022-06-23 21:54:46.203964
# Unit test for method level of class Text
def test_Text_level():
    Text().level()

# Generated at 2022-06-23 21:54:47.448320
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text
    Text().words()


# Generated at 2022-06-23 21:54:49.072426
# Unit test for method answer of class Text
def test_Text_answer():
    s = set()
    for _ in range(1000):
        s.add(Text().answer())
    assert len(s) == 2


# Generated at 2022-06-23 21:54:52.646530
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis import Text
    t = Text()
    a = t.alphabet()
    assert(len(a)==26)


# Generated at 2022-06-23 21:54:56.210794
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Method for testing sentence of class Text."""
    from mimesis import Text
    t = Text()
    t.set_seed(123456)
    assert t.sentence() == 'Bond... James Bond.'


# Generated at 2022-06-23 21:54:58.333761
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=1)
    x = text.text()

    assert x == 'Goneril and Regan are not. The power of the king is too much. Regain the king!'

# Generated at 2022-06-23 21:55:00.735536
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    _random.seed(1)
    _hex_color = Text().hex_color()

    assert _hex_color == '#6e5da6'

# Generated at 2022-06-23 21:55:01.124454
# Unit test for method word of class Text
def test_Text_word():
    pass

# Generated at 2022-06-23 21:55:11.690543
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender, TitleType
    from mimesis.text import Text, TextSpecifier

    # 1. Init a Text instance
    t = Text()

    # 2. Generate text
    text = t.title()

    # 3. Perform some assertions
    assert t.title() == text
    assert not t.title() == t.title()

    # 1. Init a TextSpecifier instance
    ts = TextSpecifier(t)

    # 2. Generate text
    text = ts.title(TitleType.ACADEMIC)
    academic_title_for_female = ts.title(TitleType.ACADEMIC, Gender.FEMININE)
    academic_title_for_male = ts.title(TitleType.ACADEMIC, Gender.MASCULINE)

    # 3. Perform some assertions

# Generated at 2022-06-23 21:55:13.808332
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words = t.words(quantity=20)
   
    for w in words:
         assert len(w) > 2
         assert w.isalpha()


# Generated at 2022-06-23 21:55:16.410003
# Unit test for method text of class Text
def test_Text_text():
    # Initilize Text Class
    text = Text()
    # Get a text from methods
    text_result = text.text()
    # Check that returns only string
    assert isinstance(text_result, str)

# Generated at 2022-06-23 21:55:18.134538
# Unit test for method title of class Text
def test_Text_title():
    print("Method title of class Text:")
    print(Text().title())


# Generated at 2022-06-23 21:55:21.568820
# Unit test for method text of class Text
def test_Text_text():
    print("Testing Text_text()")
    text = Text(False)
    text_without_params = text.text()
    text_with_params = text.text(10)
    assert isinstance(text_without_params, str)
    assert len(text_without_params) > 0
    assert isinstance(text_with_params, str)
    assert len(text_with_params) > text_without_params
print("Text_text() passed")


# Generated at 2022-06-23 21:55:22.720125
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())
    pass # test succeed

# Generated at 2022-06-23 21:55:23.830316
# Unit test for method color of class Text
def test_Text_color():
    p = Text()
    print(p.color())

# Generated at 2022-06-23 21:55:26.445483
# Unit test for method level of class Text
def test_Text_level():
    pattern = re.compile(r'^[a-z]+$')
    text = Text().level()
    assert pattern.match(text)


# Generated at 2022-06-23 21:55:30.311191
# Unit test for method level of class Text
def test_Text_level():
    from test_class import TestClass
    text = TestClass(Text)
    assert text.level() in Text._data['level']

# Generated at 2022-06-23 21:55:33.053896
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    hex_string = t.hex_color()
    assert hex_string.startswith('#')
    assert len(hex_string) == 7


# Generated at 2022-06-23 21:55:34.173515
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=0)
    assert text.swear_word() == 'Damn'

# Generated at 2022-06-23 21:55:35.595918
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in text._data['answers']


# Generated at 2022-06-23 21:55:37.741020
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.words())
    print(t.word())
    print(t.text())
    print(t.answer())

# Generated at 2022-06-23 21:55:46.470804
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Method for unit testing of class Text.
    :return: Assertion
    """

    from mimesis.enums import Locale

    class Text_test(Text):
        """Class for testing of method rgb_color from class Text."""

        class Meta:
            """Class for metadata."""

            locale = Locale.EN
            seed = 'test'

    t = Text_test()

    for _ in range(100):
        assert t.rgb_color() == (10, 66, 100)
        assert t.rgb_color(safe=True) == (50, 38, 16)


# Generated at 2022-06-23 21:55:51.465546
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Gender
    for x in range(1):
        text = Text(seed=x)
        w = text.word()
        assert w != None
        word = text.word(gender=Gender.FEMALE)
        assert word != w
        assert word != None


# Generated at 2022-06-23 21:55:53.597220
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    obj = Text()
    assert(obj.swear_word())

# Generated at 2022-06-23 21:56:00.376580
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ is 'Text'
    assert not t.seed
    assert 'en' in str(t)

    t = Text(seed=True)
    assert t.seed
    assert 'de' in str(t)

    t = Text(locale='be')
    assert 'be' in str(t)

    t = Text(locale='ru')
    assert 'ru' in str(t)


if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-23 21:56:06.528353
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import Text
    tt = Text()
    data = tt.rgb_color()
    assert len(data) == 3
    assert isinstance(data, tuple)
    assert isinstance(data[0], int)
    assert isinstance(data[1], int)
    assert isinstance(data[2], int)


# Generated at 2022-06-23 21:56:10.731042
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    color = text.hex_color()
    rgb_color = text._hex_to_rgb(color)
    assert color.startswith('#')
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)

# Generated at 2022-06-23 21:56:13.004379
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.text())

# Execute test for class Text
test_Text_color()

# Generated at 2022-06-23 21:56:14.371133
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26



# Generated at 2022-06-23 21:56:16.063494
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    print(result)


# Generated at 2022-06-23 21:56:19.381197
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text"""
    title = Text(seed=0).title()
    assert isinstance(title, str)
    assert title in ['Science', 'Welcome', 'Love', 'Colors', 'Colors']


# Generated at 2022-06-23 21:56:23.287340
# Unit test for method title of class Text
def test_Text_title():
    if __name__ == '__main__':
        text = Text('en')
        text_title = text.title()
        print('Test for method title:')
        print('\t', text_title)



# Generated at 2022-06-23 21:56:25.121317
# Unit test for method words of class Text
def test_Text_words():
    text = Text("zh")
    words = text.words(5)
    print(words)


# Generated at 2022-06-23 21:56:27.472064
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert text.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-23 21:56:31.685876
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text.

    :return: True if success otherwise raise AssertionError
    """
    txt = Text(seed=1)
    assert txt.answer() == 'No'


# Generated at 2022-06-23 21:56:32.687918
# Unit test for method words of class Text
def test_Text_words():
    assert len(Text().words()) == 5

# Generated at 2022-06-23 21:56:35.546859
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    print(text.hex_color())
    print(text.hex_color(safe=True))


# Generated at 2022-06-23 21:56:37.772305
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'
    assert text.__dict__.get('_data') is not None


# Generated at 2022-06-23 21:56:38.942200
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    Text.rgb_color()


# Generated at 2022-06-23 21:56:42.224842
# Unit test for method quote of class Text
def test_Text_quote():
    for i in range(10):
        quote = Text().quote()
        print(quote)
        assert isinstance(quote, str)
        assert quote


# Generated at 2022-06-23 21:56:47.679329
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    t = Text(locale=Locale.LITHUANIAN)
    title = t.title()
    assert t.title() != t.title()
    assert isinstance(title, str) == True


# Generated at 2022-06-23 21:56:50.857571
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    # Проверяем генерацию rgb цвета
    assert len(text.rgb_color()) == 3


# Generated at 2022-06-23 21:56:59.879983
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # "Testing rgb_color"
    # "Test_Args: {'safe': False}"

    assert Text().rgb_color() == (242, 158, 50)
    # "Test_Returns: {'(242, 158, 50)'}"
    # "Test_EndingQuote: '''"
    # PASS

    # "Test_Args: {'safe': True}"

    assert Text().rgb_color(safe=True) == (85, 239, 196)
    # "Test_Returns: {'(85, 239, 196)'}"
    # "Test_EndingQuote: '''"
    # PASS

    # "Test_EndingQuote: '''"
    # PASS

# Generated at 2022-06-23 21:57:03.194648
# Unit test for method quote of class Text
def test_Text_quote():
    """Tests for  method quote of class Text."""
    assert Text('es').quote() == "¿Qué crees que estoy haciendo aquí, " \
                                 "estudiando el lenguaje de las flores?"


# Generated at 2022-06-23 21:57:05.417786
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_gen=Text()
    print("Предложение: ", text_gen.sentence())


# Generated at 2022-06-23 21:57:07.790858
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=12345)

    assert text.swear_word() == 'shit'  # Because it has seed


# Generated at 2022-06-23 21:57:18.761686
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert isinstance(rgb_color, tuple)
    assert len(rgb_color) == 3
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)
    assert len(str(rgb_color[0])) == 3
    assert len(str(rgb_color[1])) == 3
    assert len(str(rgb_color[2])) == 3
    assert rgb_color[0] in range(0, 256)
    assert rgb_color[1] in range(0, 256)
    assert rgb_color[2] in range(0, 256)
    rgb_color = text.rgb_color

# Generated at 2022-06-23 21:57:23.491280
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__str__() == '<Text>'
    assert t.__repr__() == '<Text>'
    assert t.__class__.__base__ == BaseDataProvider

    t = Text(['a', 'b', 'c'])
    assert  t.__str__() == '<Text>'
    assert t.__repr__() == '<Text>'
    assert t.__class__.__base__ == BaseDataProvider

    t = Text('abc', 'def')
    assert t.__str__() == '<Text>'
    assert t.__repr__() == '<Text>'
    assert t.__class__.__base__ == BaseDataProvider


# Generated at 2022-06-23 21:57:25.304348
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5
    for word in words:
        assert isinstance(word, str)
        assert len(word) > 0


# Generated at 2022-06-23 21:57:27.367254
# Unit test for method answer of class Text
def test_Text_answer():
    """Method for testing method answer of class Text."""
    from mimesis.enums import Locales
    t = Text(Locales.EN)
    print(t.answer())

# Generated at 2022-06-23 21:57:30.074742
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    x = t.level()
    assert x in t._data['level']



# Generated at 2022-06-23 21:57:31.496254
# Unit test for method title of class Text
def test_Text_title():
    # Test case 1: Check the function title() with default parameters
    answer = Text().title()
    assert isinstance(answer, str)
    print(answer)


# Generated at 2022-06-23 21:57:33.684854
# Unit test for method sentence of class Text
def test_Text_sentence():
    x = Text()
    assert type(x.sentence()) == str



# Generated at 2022-06-23 21:57:41.122507
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    t = Text()
    assert t.title() in t._data['text']
    t = Text(gender=Gender.MALE)
    assert t.title() in t._data['text']
    t = Text(gender=Gender.FEMALE)
    assert t.title() in t._data['text']
    t = Text(gender=Gender.NON_BINARY)
    assert t.title() in t._data['text']


# Generated at 2022-06-23 21:57:42.230317
# Unit test for method level of class Text
def test_Text_level():
    ci = Text()
    print(ci.level())

# Generated at 2022-06-23 21:57:43.803944
# Unit test for method text of class Text
def test_Text_text():
    x = Text()
    print(x.text())


# Generated at 2022-06-23 21:57:46.181058
# Unit test for method title of class Text
def test_Text_title():
    title = Text(seed=123).title()
    assert title == 'I\'m not enough'

# Generated at 2022-06-23 21:57:47.893174
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.words(quantity=2), list)


# Generated at 2022-06-23 21:57:49.078973
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence() == 'additional'

# Generated at 2022-06-23 21:57:52.291168
# Unit test for method quote of class Text
def test_Text_quote():
    test_obj = Text('zh_CN')
    result = test_obj.quote()
    assert(result)
    assert(isinstance(result, str))


# Generated at 2022-06-23 21:57:53.894681
# Unit test for method answer of class Text
def test_Text_answer():
    """Test method answer of class Text."""
    sl = Text('es')
    print(sl.answer())

# Generated at 2022-06-23 21:57:56.734697
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    provider = Text()
    assert isinstance(provider.swear_word(), str)

# Generated at 2022-06-23 21:58:01.677304
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    color = text.hex_color()
    assert len(color) == 7
    assert color.startswith('#')
    assert color.lstrip('#') == color[1:]
    assert color[0] == '#'
    assert color[1:] == color[1:].lower()


# Generated at 2022-06-23 21:58:02.805913
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.answer())

# Generated at 2022-06-23 21:58:05.478875
# Unit test for method title of class Text
def test_Text_title():
    a=Text()
    result=a.title()
    assert len(result)>0 , 'Error not return'
    print(result)


# Generated at 2022-06-23 21:58:07.860587
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text
    from mimesis.enums import Gender
    t = Text()
    word = t.word()
    assert len(word) > 0


# Generated at 2022-06-23 21:58:09.115064
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    print(text.text())


# Generated at 2022-06-23 21:58:12.422396
# Unit test for constructor of class Text
def test_Text():
    # result1 = Text().sentence()
    # result2 = Text().text()
    # print('sentence is: ', result1)
    # print('text is: ', result2)
    print(Text().hex_color(safe=True))

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 21:58:15.358570
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text('en')
    s = t.swear_word()
    assert s in t._data['words'].get('bad')



# Generated at 2022-06-23 21:58:18.925436
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in ['Да', 'Нет', 'Принимаю', 'Не принимаю']

# Generated at 2022-06-23 21:58:20.001874
# Unit test for method level of class Text
def test_Text_level():
    result = Text.level()
    print(result)


# Generated at 2022-06-23 21:58:21.526060
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert len(t.title()) > 0


# Generated at 2022-06-23 21:58:23.674193
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    locale = 'en'
    text = Text(locale)
    assert len(text.alphabet()) == 26


# Generated at 2022-06-23 21:58:27.145614
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()  # Create an instance of class Text
    output = text.hex_color()  # Call method hex_color and store it in output
    assert output == '#c3da25'

# Generated at 2022-06-23 21:58:31.013263
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    color = Text()
    results = []
    for _ in range(10):
        results.append(color.color())
    assert isinstance(results, list)
    assert len(results) == 10

# Generated at 2022-06-23 21:58:33.168026
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import DataFields
    from mimesis.providers.text import Text
    text = Text('en')

# Generated at 2022-06-23 21:58:33.899922
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())


# Generated at 2022-06-23 21:58:34.699389
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    assert text.swear_word(), type(str)

# Generated at 2022-06-23 21:58:36.890495
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test method rgb_color of class Text."""
    from pprint import pprint
    from mimesis.builtins import Text
    t = Text()
    pprint(t.rgb_color(safe=True))
    pprint(t.rgb_color())



# Generated at 2022-06-23 21:58:41.325177
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    a = Text('en')
    quotes = list()
    for i in range(0, 100):
        quotes.append(a.quote())
    assert all(isinstance(l, str) for l in quotes)
    for l in quotes:
        assert len(l) > 0


# Generated at 2022-06-23 21:58:47.655061
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']


# Generated at 2022-06-23 21:58:50.496441
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    for i in range(100):
        rgb = text.rgb_color()
        assert isinstance(rgb, tuple)
        assert len(rgb) == 3
        for j in range(3):
            assert isinstance(rgb[j], int)
            assert rgb[j] >= 0 and rgb[j] <= 255



# Generated at 2022-06-23 21:58:59.281485
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    rus = RussiaSpecProvider(seed=20)
    assert rus.text(quantity=5) == ' динамика праздник абстракция судьба информация'
    rus = RussiaSpecProvider(seed=200, gender=Gender.FEMALE)
    assert rus.text(quantity=5) == ' каталог колония пластик повод счастье'



# Generated at 2022-06-23 21:59:00.382137
# Unit test for method level of class Text
def test_Text_level():
    assert t.level().islower()


# Generated at 2022-06-23 21:59:21.737137
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    from mimesis.enums import ContainerType
    from mimesis.exceptions import ContainerError
    from mimesis.providers.text import DataProcessor

    processor = DataProcessor(locale='en')
    processor._pull(processor._datafile)

    text_data = processor._data
    assert text_data is not None

    # Fixed part
    levels = text_data['level'][:2]
    levels.append('danger')

    # Dynamic part
    levels.append('color')
    levels.append('word')

    level = processor.level(levels)
    assert isinstance(level, str)
    assert level in levels

    level = processor.level(levels,
                            container=ContainerType.TUPLE)
    assert isinstance(level, tuple)

# Generated at 2022-06-23 21:59:23.917075
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == len(t.alphabet(lower_case=True))


# Generated at 2022-06-23 21:59:26.901888
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    # We assert that the method `answer` doesn't return an empty result
    assert text.answer()



# Generated at 2022-06-23 21:59:31.005747
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text()
    assert isinstance(x.swear_word(), str)
    assert len(x.swear_word()) > 2
    print(x.swear_word())


# Generated at 2022-06-23 21:59:31.725010
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    t.text()

# Generated at 2022-06-23 21:59:35.406876
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Create a text object
    text = Text()

    # Generate a swear word
    swear_word = text.swear_word()

    # Assert that the word is a string
    assert isinstance(swear_word, str)

    # Assert that the word is not empty string
    assert len(swear_word) > 0



# Generated at 2022-06-23 21:59:37.458964
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t.words()

# Generated at 2022-06-23 21:59:38.542415
# Unit test for method words of class Text
def test_Text_words():
    items = Text.words()
    assert isinstance(items, list)

# Generated at 2022-06-23 21:59:40.222547
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    result = text.words()
    assert(len(result) == 5)

# Generated at 2022-06-23 21:59:47.936110
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.data import text_answer
    from mimesis.enums import Locales
    from mimesis.providers.text import Text

    t = Text(seed=1)
    assert t.answer() == text_answer.DEFAULT
    assert t.answer() == 'Yes'
    t = Text(local=Locales.DE)
    assert t.answer() == text_answer.DE
    assert t.answer() == 'No'



# Generated at 2022-06-23 21:59:50.485493
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text(seed=555)
    assert t.hex_color() == '#fbf959'
    assert t.hex_color(safe=True) == '#0088cc'


# Generated at 2022-06-23 21:59:52.226839
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text.Text()
    color.hex_color()
    return


# Generated at 2022-06-23 21:59:53.326408
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    pass


# Generated at 2022-06-23 21:59:54.438539
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    text.level()

# Generated at 2022-06-23 22:00:00.208405
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import Color

    text = Text()
    for safe in (True, False):
        for _ in range(5):
            assert len(text.rgb_color(safe)) == 3
            r, g, b = text.rgb_color(safe)
            if safe:
                assert (r, g, b) in Color.FLATUI.value
            else:
                assert 0 <= r <= 255
                assert 0 <= g <= 255
                assert 0 <= b <= 255

# Generated at 2022-06-23 22:00:03.482481
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == len(t.alphabet(lower_case = True))


# Generated at 2022-06-23 22:00:06.605891
# Unit test for method text of class Text
def test_Text_text():
    print('== Start function test_Text_text ==')
    t = Text()
    print(t.text())
    print('== End function test_Text_text ==')

#Unit test for method level of class Text

# Generated at 2022-06-23 22:00:08.125769
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('ru')
    text.alphabet(True)



# Generated at 2022-06-23 22:00:09.610538
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    print(t.answer())


# Generated at 2022-06-23 22:00:15.388652
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    obj = Text()
    assert((0,0,0) == obj.rgb_color(True))
    assert((255,255,255) == obj.rgb_color(True))
    assert((0,0,0) != obj.rgb_color(False))
    assert((255,255,255) != obj.rgb_color(False))
    return True


# Generated at 2022-06-23 22:00:18.710706
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()
    color = provider.color()
    assert isinstance(color, str) is True
    assert color.isalpha() is True
    assert len(color) >= 3


# Generated at 2022-06-23 22:00:20.620682
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text(seed=1)
    assert t.quote() == 'I\'m Batman.'

# Generated at 2022-06-23 22:00:22.941185
# Unit test for method color of class Text
def test_Text_color():
    for i in range(20):
        result=Text().color()
        assert result is not None
        assert isinstance(result,str)


# Generated at 2022-06-23 22:00:26.384264
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text.seed, int)
    assert isinstance(text.random_native, int)
    assert isinstance(text.random_custom, int)
    assert isinstance(text.locales, list)
    assert isinstance(text.data, dict)


# Generated at 2022-06-23 22:00:29.152382
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet(False)) == 26
    assert len(t.alphabet(True)) == 26


# Generated at 2022-06-23 22:00:34.336361
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    test_value = text.rgb_color(safe=True)
    assert isinstance(test_value, tuple)
    assert len(test_value) == 3
    assert text.rgb_color(safe=False) != text.rgb_color(safe=True)


# Generated at 2022-06-23 22:00:35.246803
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    for _ in range(100):
        print(Text.swear_word())

# Generated at 2022-06-23 22:00:36.945704
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    import random
    seed = random.randint(1, 2 ** 32 - 1)
    obj = Text(seed=seed)
    expected = (194, 121, 200)
    assert obj.rgb_color() == expected


# Generated at 2022-06-23 22:00:39.105909
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7


# Generated at 2022-06-23 22:00:40.225555
# Unit test for method color of class Text
def test_Text_color():
    print(Text().color())

# Generated at 2022-06-23 22:00:41.142983
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    print(x.answer())

# Generated at 2022-06-23 22:00:43.237778
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis import Text
    text = Text()
    text.hex_color(safe=True)



# Generated at 2022-06-23 22:00:45.780082
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    data = t.alphabet(lower_case=True)
    assert isinstance(data, list)
    assert len(data) == 26



# Generated at 2022-06-23 22:00:47.953960
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text_out = text.text()
    assert text_out != None, "Test method text of class Text failed."


# Generated at 2022-06-23 22:00:49.436653
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert type(t.level()) == str

# Generated at 2022-06-23 22:00:57.026511
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print("\n\nTesting method alphabet of class Text")
    text_obj = Text()
    text_obj.seed(12345)
    print(text_obj.alphabet())
    print(text_obj.alphabet(lower_case=True))
    text_obj.seed(12345)
    print(text_obj.alphabet())
    print(text_obj.alphabet(lower_case=True))



# Generated at 2022-06-23 22:01:00.228009
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.text())
    print(text.words())
    print(text.swear_word())
    print(text.sentence())
    print(text.title())


# Generated at 2022-06-23 22:01:03.794395
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    p = Text(['de'])
    ok = p.alphabet()
    try:
        len(ok)
    except TypeError:
        status = False
    else:
        status = True
    return status


# Generated at 2022-06-23 22:01:06.006951
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ["Yes", "No"]


# Generated at 2022-06-23 22:01:08.317695
# Unit test for method level of class Text
def test_Text_level():
    obj = Text(seed=42)
    result = obj.level()
    assert result == 'critical'

# Generated at 2022-06-23 22:01:09.361712
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    word = t.word()
    assert word


# Generated at 2022-06-23 22:01:13.033216
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    res = t.sentence()
    assert isinstance(res, str)
    assert len(res) > 0
    print(res)


# Generated at 2022-06-23 22:01:21.274620
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    en_provider = Text()
    ru_provider = Text(RussiaSpecProvider)
    assert en_provider.sentence() == en_provider.sentence()
    assert ru_provider.sentence() == ru_provider.sentence()
    assert en_provider.sentence(gender=Gender.FEMALE) != en_provider.sentence(gender=Gender.MALE)
    assert ru_provider.sentence(gender=Gender.FEMALE) == ru_provider.sentence(gender=Gender.MALE)

# Generated at 2022-06-23 22:01:28.470936
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import random
    import json
    import os

    # Create JSON file with list of words
    data_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = '{}/data/{}'.format(data_dir, 'text.json')

    # List of words
    word_list = ['Teletubbies', 'Hello', 'Africa', 'What', 'Europe']

    # JSON data
    jsonFile = {
        'words': {
            'normal': word_list
        }
    }

    # Open JSON file and write data
    with open(data_file, 'w') as outfile:
        json.dump(jsonFile, outfile)

    # Set random seed
    random.seed(1)

    # Instantiate Text class and get random word
    text