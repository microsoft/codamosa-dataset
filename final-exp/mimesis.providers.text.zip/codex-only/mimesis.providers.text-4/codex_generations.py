

# Generated at 2022-06-23 21:51:30.021650
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)


# Generated at 2022-06-23 21:51:32.240782
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    m = t.level()
    assert m in t._data['level']

# Generated at 2022-06-23 21:51:33.966163
# Unit test for method color of class Text
def test_Text_color():
    t = Text('en')
    color = t.color()
    assert len(color) > 0


# Generated at 2022-06-23 21:51:35.741083
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    words = Text(seed=123456789)
    assert words.swear_word() == 'shit'

# Generated at 2022-06-23 21:51:38.443440
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=1)
    title = text.title()
    assert title == 'Id in cupidatat aliquip est occaecat incididunt'



# Generated at 2022-06-23 21:51:40.363109
# Unit test for method answer of class Text
def test_Text_answer():
    returned = Text().answer()
    assert returned not in ['No', 'Niet']
    assert returned in ['Нет', 'Nee']

# Generated at 2022-06-23 21:51:44.145255
# Unit test for method quote of class Text
def test_Text_quote():
    """Testing method quote for class Text"""
    text = Text()
    quote = text.quote()
    print(quote)
    assert quote in text._data['quotes']



# Generated at 2022-06-23 21:51:45.877864
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    obj = Text()
    res = obj.rgb_color()
    print(res)



# Generated at 2022-06-23 21:51:47.265016
# Unit test for method answer of class Text
def test_Text_answer():
    str = Text().answer()
    assert(isinstance(str, str))

# Generated at 2022-06-23 21:51:48.172071
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())


# Generated at 2022-06-23 21:51:52.812223
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    result = text.alphabet()
    assert len(result) == 26
    assert isinstance(result, list)
    assert isinstance(result[0], str)
    result = text.alphabet(lower_case=True)
    assert len(result) == 26
    assert result[0] == result[0].lower()


# Generated at 2022-06-23 21:51:55.046534
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    result = t.title()
    assert isinstance(result, str)
    assert len(result) >= 3
    assert len(result) <= 25


# Generated at 2022-06-23 21:51:57.042147
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text.

    :return: None.
    """
    text = Text()
    assert text.sentence()

# Generated at 2022-06-23 21:52:02.744369
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    a = Text()
    color = a.hex_color()
    color_safe = a.hex_color(safe=True)
    assert color != color_safe
    assert color[0] == '#'
    assert color_safe[0] != '#'
    assert len(color) == len('#ffffff')
    assert len(color_safe) == len('ffffff')

# Generated at 2022-06-23 21:52:04.642045
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    ans = text.answer()
    assert len(ans)>0
    
    

# Generated at 2022-06-23 21:52:06.598891
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() == 'Red'


# Generated at 2022-06-23 21:52:08.749667
# Unit test for method answer of class Text
def test_Text_answer():
    obj = Text()
    obj.seed(1)
    result = obj.answer()
    assert result == "Yes"


# Generated at 2022-06-23 21:52:11.558379
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(
        text.answer()
    )


# Generated at 2022-06-23 21:52:13.030170
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=1337)
    assert text.swear_word() == 'Damn'


# Generated at 2022-06-23 21:52:14.457845
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No']



# Generated at 2022-06-23 21:52:18.121251
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert type(text.title()) == str

if __name__ == "__main__":
    test_Text_title()

# Generated at 2022-06-23 21:52:28.142320
# Unit test for method quote of class Text
def test_Text_quote():
    text_instance = Text(seed=42)
    results = set()
    for _ in range(5):
        results.add(text_instance.quote())


# Generated at 2022-06-23 21:52:29.986626
# Unit test for method title of class Text
def test_Text_title(): 
    t = Text()
    title = t.title()
    assert isinstance(title, str)
    assert title != ''


# Generated at 2022-06-23 21:52:31.573981
# Unit test for method quote of class Text
def test_Text_quote():
    test_Text = Text()
    test_quote = test_Text.quote()
    assert isinstance(test_quote, str)


# Generated at 2022-06-23 21:52:33.800982
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(lang='en', seed=42)
    s = text.sentence()
    assert s == 'Below-the-line are below-the-line.'


# Generated at 2022-06-23 21:52:37.959116
# Unit test for constructor of class Text
def test_Text():
    answers = ['Yes', 'No', 'Maybe', 'It is possible', 'I am not sure',
               'It is unlikely', 'Absolutely', 'Certainly', 'Not']
    assert Text().answer() in answers


# Generated at 2022-06-23 21:52:39.755437
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)


# Generated at 2022-06-23 21:52:40.608818
# Unit test for method words of class Text
def test_Text_words():
    provider = Text()
    word = 'Earth'
    assert word in provider.words()

# Generated at 2022-06-23 21:52:41.575177
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in ['Yes', 'No']

# Generated at 2022-06-23 21:52:51.725631
# Unit test for method title of class Text
def test_Text_title():
    from random import seed
    from mimesis import Generic, Text

    seed(500)
    generic = Generic('en')
    text = Text('en')

    for _ in range(10):
        # sample title
        generated_title = text.title()
        # sample sentence
        generated_sentence = text.sentence()
        # sample word
        generated_word = text.word()

        assert len(generated_title.split()) >= 4
        assert len(generated_sentence.split()) >= 3
        assert len(generated_word.split()) == 1



# Generated at 2022-06-23 21:52:54.524640
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    result = text.words()
    assert isinstance(result, list)
    assert len(result) == 5


# Generated at 2022-06-23 21:53:02.172995
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    result = text.alphabet()
    assert len(result) == 26
    assert isinstance(result, list)
    assert result[0] == 'A'
    assert result[-1] == 'Z'

    result = text.alphabet(lower_case=True)
    assert len(result) == 26
    assert isinstance(result, list)
    assert result[0] == 'a'
    assert result[-1] == 'z'


# Generated at 2022-06-23 21:53:03.601689
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sentence = t.sentence()
    print(sentence)

# Generated at 2022-06-23 21:53:07.109728
# Unit test for method alphabet of class Text
def test_Text_alphabet():

    #arrange
    provider = Text('en')
    lower_case = True

    #act
    result = provider.alphabet(lower_case)

    #assert
    assert len(result) == 26

# Generated at 2022-06-23 21:53:08.465087
# Unit test for method sentence of class Text
def test_Text_sentence():
    txt = Text()
    print(txt.sentence())


# Generated at 2022-06-23 21:53:12.214636
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    for _ in range(1000):
        color = text.rgb_color(safe=True)
        assert color in SAFE_COLORS
    for _ in range(1000):
        color = text.rgb_color(safe=False)
        assert color not in SAFE_COLORS

# Generated at 2022-06-23 21:53:16.777796
# Unit test for method level of class Text
def test_Text_level():
    txt = Text('fa-IR')
    txt.seed(1)
    assert txt.level() == 'متوسط'


# Generated at 2022-06-23 21:53:18.699071
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-23 21:53:21.154826
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert callable(text.color)
    assert isinstance(text.color(), str)
    assert text.color() in text._data['color']



# Generated at 2022-06-23 21:53:21.926945
# Unit test for method level of class Text
def test_Text_level():
    assert Text.level == Text().level

# Generated at 2022-06-23 21:53:23.179614
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet(lower_case=True)) == 26
    assert len(text.alphabet()) == 26


# Generated at 2022-06-23 21:53:26.640795
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text("test")
    for i in range(50):
        sentence = text.sentence()
    print("test text:", sentence)


if __name__ == '__main__':
    test_Text_sentence()
    # test_Text_words()

# Generated at 2022-06-23 21:53:28.685999
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    text = Text()
    assert isinstance(text.answer(), str)



# Generated at 2022-06-23 21:53:33.333109
# Unit test for method words of class Text
def test_Text_words():
    """ Unit test for method 'words' of class Text.
        Return a list of n random words.
    """
    text = Text()
    random_words = text.words(quantity=5)
    assert len(random_words) == 5


# Generated at 2022-06-23 21:53:37.030711
# Unit test for method words of class Text
def test_Text_words():
    print("Test: method words of class Text")
    word_list = Text().words()
    assert len(word_list) == 5
    print("Pass: method words of class Text")

# Run unit tests
if __name__ == "__main__":
    test_Text_words()

# Generated at 2022-06-23 21:53:38.710048
# Unit test for method sentence of class Text
def test_Text_sentence():
  text_sentence = Text()
  assert text_sentence.sentence() is not None


# Generated at 2022-06-23 21:53:39.822422
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() == (252, 85, 32)


# Generated at 2022-06-23 21:53:41.413013
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe = True)) == 7


# Generated at 2022-06-23 21:53:43.779224
# Unit test for method words of class Text
def test_Text_words():
    """Test method words of class Text."""
    text = Text()
    assert len(text.words()) == 5

# Generated at 2022-06-23 21:53:47.311019
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test the correctness of the method Text.rgb_color"""
    t = Text()
    for i in range(1,10):
        t.rgb_color()
        

# Generated at 2022-06-23 21:53:49.009901
# Unit test for method title of class Text
def test_Text_title():
    data = Text()
    a=data.title()
    print(a)

# Generated at 2022-06-23 21:53:52.909734
# Unit test for method word of class Text
def test_Text_word():
    obj = Text('ru')

    _list = [obj.word() for _ in range(2)]
    assert len(_list) == 2
    assert _list[0] != _list[1]


# Generated at 2022-06-23 21:53:54.812614
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3


# Generated at 2022-06-23 21:53:57.181791
# Unit test for method title of class Text
def test_Text_title():
    obj = Text()
    result = obj.title()
    print(result)

test_Text_title()

# Generated at 2022-06-23 21:53:58.656225
# Unit test for method text of class Text
def test_Text_text():
    """Test text method of class Text."""
    text = Text()
    assert text.text()


# Generated at 2022-06-23 21:54:02.958325
# Unit test for method words of class Text
def test_Text_words():
    class UnitTestText(Text):
        def __init__(self):
            self.random = Random()
    unit = UnitTestText()
    assert isinstance(unit.words(quantity=5), list)
    assert len(unit.words(quantity=5)) == 5
    assert isinstance(unit.words(quantity=5)[0], str)
    assert isinstance(unit.words(quantity=5)[-1], str)


# Generated at 2022-06-23 21:54:04.105511
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert type(text.level()) == str


# Generated at 2022-06-23 21:54:06.286935
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    answer = t.rgb_color()
    assert answer
    assert isinstance(answer, tuple)

test_Text_rgb_color()

# Generated at 2022-06-23 21:54:09.422272
# Unit test for method words of class Text
def test_Text_words():
    t = Text('fr-FR')
    assert t.words(quantity=3) == t.words(quantity=3)
    assert len(t.words(quantity=3)) == 3
    words = t.words(quantity=3)
    for word in words:
        assert len(word) <= 10


# Generated at 2022-06-23 21:54:12.181519
# Unit test for method words of class Text
def test_Text_words():
    text1 = Text()
    words_list = text1.words()
    # print(words_list)
    assert len(words_list) == 5


# Generated at 2022-06-23 21:54:15.173471
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']

# Generated at 2022-06-23 21:54:21.315275
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locales
    from mimesis.text import Text
    ru = Text(Locales.RU)
    en = Text(Locales.EN)
    ru_example = ru.swear_word()
    en_example = en.swear_word()
    assert ru_example
    assert ru_example in ru._data['words']['bad']
    assert en_example
    assert en_example in en._data['words']['bad']

if __name__ == '__main__':
    test_Text_swear_word()

# Generated at 2022-06-23 21:54:23.397098
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test text.alphabet()."""
    assert len(Text().alphabet()) == 26


# Generated at 2022-06-23 21:54:24.327518
# Unit test for method color of class Text
def test_Text_color():
    obj = Text()
    result = obj.color()
    print(result)


# Generated at 2022-06-23 21:54:25.326388
# Unit test for constructor of class Text
def test_Text():
    pass


# Generated at 2022-06-23 21:54:26.066650
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    t.word()

# Generated at 2022-06-23 21:54:33.041177
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person as P
    from mimesis.providers.person import Person as Person_
    from mimesis.providers.person import Person as Person__
    from mimesis.providers.person import Person as Person___
    p = Person('en')
    P = Person('en')
    P_ = Person('en')
    P__ = Person('en')
    P___ = Person('en')
    t = Text('en')
    color = t.color
    assert color is not None
    assert len(color) > 0
    assert type(color) is str



# Generated at 2022-06-23 21:54:35.813230
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text=Text()
    print(text.rgb_color(safe=True))

if __name__ == '__main__':
    test_Text_rgb_color()

# Generated at 2022-06-23 21:54:37.862765
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    a = t.words()
    print(a)

# Generated at 2022-06-23 21:54:47.712796
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    a = Text('en')
    assert a.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert a.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-23 21:54:49.037433
# Unit test for method word of class Text
def test_Text_word():
    text_text = Text()
    word = text_text.word()
    assert word == 'Science'

# Generated at 2022-06-23 21:54:52.599297
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())
    assert isinstance(t.sentence(), str)


# Generated at 2022-06-23 21:54:54.828847
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert isinstance(answer, str)


# Generated at 2022-06-23 21:54:59.160621
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import DataFields
    from mimesis.enums import Locales
    from mimesis.text import Text
    t = Text(locale=Locales.ES)
    color1 = t.color()
    color2 = t.color()
    assert color1 in t.data[DataFields.COLOR]
    assert color2 in t.data[DataFields.COLOR]
    assert color1 != color2

# Generated at 2022-06-23 21:55:02.378146
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test method hex_color of class Text."""
    t = Text()
    assert re.match('#[a-f0-9]{6}', t.hex_color()) is not None

# Generated at 2022-06-23 21:55:10.805164
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    import unittest
    test_case = unittest.TestCase()
    t = Text()
    rgb = t.rgb_color()
    test_case.assertEqual(len(rgb), 3)
    test_case.assertIsInstance(rgb, tuple)
    safe_rgb = t.rgb_color(safe=True)
    test_case.assertEqual(len(safe_rgb), 3)
    test_case.assertIsInstance(rgb, tuple)
    test_case.assertIn(safe_rgb, SAFE_COLORS)


# Generated at 2022-06-23 21:55:12.349595
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    sentence = provider.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:55:14.886312
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert type(sentence) == str
    assert len(sentence) > 0


# Generated at 2022-06-23 21:55:20.659185
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=123)
    assert text.text(quantity=1) == 'Aliquam erat volutpat.'
    assert text.text(quantity=2) == 'Aliquam erat volutpat. Donec sit amet varius diam.'
    assert text.text(quantity=3) == 'Aliquam erat volutpat. Donec sit amet varius diam. Vivamus quis posuere nisi.'


# Generated at 2022-06-23 21:55:22.481229
# Unit test for method level of class Text
def test_Text_level():

    text = Text()
    result = text.level()
    assert result in ['critical','serious','not dangerous','safe']


# Generated at 2022-06-23 21:55:23.847767
# Unit test for method title of class Text
def test_Text_title():
    t = Text(seed=123)
    assert t.title() == 'Bond... James Bond.'

# Generated at 2022-06-23 21:55:25.671005
# Unit test for method level of class Text
def test_Text_level():
    obj = Text()
    res = obj.level()
    assert(res != '')


# Generated at 2022-06-23 21:55:30.383581
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    t.random.seed(0)
    # test alphabet
    assert len(t.alphabet(False)) == 26
    assert len(t.alphabet(True)) == 26
    # test level
    assert t.level() == 'critical'
    # test text
    assert t.text() == 'Freeze your enemy before he freezes you.'
    assert t.sentence() == 'Freeze your enemy before he freezes you.'
    assert t.title() == 'Freeze your enemy before he freezes you.'
    # test words
    assert len(t.word()) == 8
    assert len(t.words()) == 5
    assert len(t.swear_word()) == 4
    assert t.quote() == 'You only live twice... or so it seems.'
    assert len(t.color()) == 6
    # test

# Generated at 2022-06-23 21:55:32.291613
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    a = t.words(3)
    print(a)


# Generated at 2022-06-23 21:55:33.337835
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()

# Generated at 2022-06-23 21:55:34.359623
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    t.sentence()

# Generated at 2022-06-23 21:55:36.784397
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert len(Text().hex_color()) == 7
    assert Text().hex_color()[0] == '#'


# Generated at 2022-06-23 21:55:39.545290
# Unit test for method text of class Text
def test_Text_text():
    print(Text().text())


# Generated at 2022-06-23 21:55:44.047048
# Unit test for method color of class Text
def test_Text_color():
    print("Start test_Text_color")
    t = Text()
    color = t.color()
    assert color in t._data['color']
    assert type(color) == str
    print("Finish test_Text_color")



# Generated at 2022-06-23 21:55:45.507514
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    print(x.title())

test_Text()

# Generated at 2022-06-23 21:55:48.658037
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert text.hex_color(safe=True) == '#f2d13a'

# Generated at 2022-06-23 21:55:54.674231
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    from mimesis.enums import Language
    from mimesis.builtins import RussiaSpecProvider

    class TestText(Text):
        class Meta:
            locales = [Language.RU,]

    t = TestText(RussiaSpecProvider)
    swear_word = t.swear_word()
    assert len(swear_word) > 0
    assert type(swear_word) is str

# Generated at 2022-06-23 21:55:57.600868
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    text = Text()
    bad_word = text.swear_word()
    assert bad_word in text._data['words']['bad']

# Generated at 2022-06-23 21:56:00.112865
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for method hex_color."""
    data = '#d8346b'
    t = Text()
    assert data in t.hex_color(safe=True)

# Generated at 2022-06-23 21:56:03.854185
# Unit test for method answer of class Text
def test_Text_answer():
    text_generator = Text()
    #  text_generator.answers() # throwing an KeyError: 'answers'
    text_generator.answer() # It doesn't raise any error


# Generated at 2022-06-23 21:56:06.347262
# Unit test for method words of class Text
def test_Text_words():
    x = Text()
    assert len(x.words()) == 5
    assert isinstance(x.words(quantity=1), list)


# Generated at 2022-06-23 21:56:08.343254
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() != text.swear_word()


# Generated at 2022-06-23 21:56:10.356627
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-23 21:56:12.296266
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    t.rgb_color()
    t.rgb_color(True)
    assert True

# Generated at 2022-06-23 21:56:13.598797
# Unit test for method title of class Text
def test_Text_title():
     print(Text(seed=4).title())

# Generated at 2022-06-23 21:56:14.891788
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7

# Generated at 2022-06-23 21:56:18.997575
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test hex color method of Text class."""
    t = Text()
    hex_color = t.hex_color()
    assert len(hex_color) == 7
    assert hex_color[0] == '#'


# Generated at 2022-06-23 21:56:25.270834
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print("Testing method alphabet of class Text")

    # Object of class Text
    txt = Text()

    # Test alphabet in lower case
    # Test with 50 iterations
    for _ in range(50):
        txt.alphabet(lower_case=True)
        print("Lower case : OK")

    # Test alphabet in upper case
    # Test with 50 iterations
    for _ in range(50):
        txt.alphabet(lower_case=False)
        print("Upper case : OK")

    print("Test for method alphabet of class Text finish.")


# Generated at 2022-06-23 21:56:30.145405
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Gender
    print("Test method answer of class Text")
    text = Text('en')
    print("Check that both of the following lines are equal")
    if Gender.MALE == Gender.MALE:
        print(text.answer())
    else:
        print(text.answer())
    # Tested result, both are equal
    # No
    # No


# Generated at 2022-06-23 21:56:32.343923
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text("ru")
    result = text.rgb_color()
    assert(result == (18, 52, 86))

# Generated at 2022-06-23 21:56:38.071263
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7
    assert '#' in hex_color
    assert sum([int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]) > 0
    assert sum([int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]) < 4095


# Generated at 2022-06-23 21:56:41.401251
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test works correctly method rgb_color."""
    # Get a Text class object
    provider = Text.create()
    # Get rgb color
    rgb = provider.rgb_color()
    # Check that each part of tuple is between 0 and 255
    assert all(x >= 0 and x <= 255 for x in rgb)

# Generated at 2022-06-23 21:56:45.722235
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    red = t.rgb_color()
    print(red)
    assert 0 <= red[0] <= 255
    assert 0 <= red[1] <= 255
    assert 0 <= red[2] <= 255


# Generated at 2022-06-23 21:56:48.439294
# Unit test for method title of class Text
def test_Text_title():
    """Test method title of class Text."""
    text = Text()
    result = text.title()
    print(result)
    assert isinstance(result, str)



# Generated at 2022-06-23 21:56:50.206210
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    result = text.hex_color()
    print(result)


# Generated at 2022-06-23 21:56:53.348163
# Unit test for method answer of class Text
def test_Text_answer():
  s = Text('ru')
  assert type(s.answer()) == str
  assert len(s.answer()) > 0


# Generated at 2022-06-23 21:56:55.832785
# Unit test for method color of class Text
def test_Text_color():
    # Testing method color of class Text
    text = Text()
    color = text.color()
    assert color in text._data['color']


# Generated at 2022-06-23 21:56:57.143836
# Unit test for method level of class Text
def test_Text_level():
    from mimesis import Text

    T = Text()
    # This should be a str
    assert isinstance(T.level(), str)


# Generated at 2022-06-23 21:57:01.483509
# Unit test for method text of class Text
def test_Text_text():
    # Prepare data
    langs =  ['ru', 'en', 'es', 'uk', 'de']
    n = 5
    # Testing the correctness of the generated data
    for lang in langs:
        text_len = []
        for _ in range(5):
            text = Text(lang).text(quantity=n)
            t = text.split(' ')
            text_len.append(len(t))
            print(t)
        mean = sum(text_len) / len(text_len)
        print('mean: {} {}'.format(mean, lang))
        assert mean == n

# Generated at 2022-06-23 21:57:09.066300
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    t = Text(locale='en', seed=10)
    # how to write good tests

    #print(t.sentence())
    #assert t.sentence() == 'How to write good tests?'
    #assert t.sentence() == 'How to write good tests?'
    #assert len(t.sentence()) > 2

    #print(t.sentence(seed=10))
    #assert t.sentence() == 'How to write good tests?'
    #assert t.sentence() == 'How to write good tests?'
    #assert len(t.sentence()) > 2

    print('Test successful')

# Run test
test_Text_sentence()


# Generated at 2022-06-23 21:57:10.952693
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    assert result in t._data['level']

# Generated at 2022-06-23 21:57:12.018609
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() != ''


# Generated at 2022-06-23 21:57:13.114149
# Unit test for method title of class Text
def test_Text_title():
    print(Text(seed=10).title())

# Generated at 2022-06-23 21:57:16.030792
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title = t.title()
    assert len(title) > 0 and type(title) == str


# Generated at 2022-06-23 21:57:17.570674
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color()[0] == 252
    print('test_Text_rgb_color -> ok')
test_Text_rgb_color()

# Generated at 2022-06-23 21:57:27.368182
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import os
    import pprint
    import unittest

    # 3 Tests - Test 1: EN, Test 2: RU, Test 3: DE
    class TestText(unittest.TestCase):
        def test_swear_word_en(self):
            try:
                from mimesis import Text
            except ImportError:
                self.fail("Unable to import Text class")
            t = Text('en')
            swear_words = ['Damn', 'Fuck', 'Damn it', 'Crap', 'Shit', 'Bullshit', 'Fuck off', 'Son of a bitch', 'Piss']
            print(os.path.basename(__file__) + " - Test 1 (EN):", t.swear_word() in swear_words)


# Generated at 2022-06-23 21:57:30.520577
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    t = Text(Locale.EN)
    assert t.level() in ['low', 'critical', 'moderate', 'high']

# Generated at 2022-06-23 21:57:33.474931
# Unit test for method answer of class Text
def test_Text_answer():
    '''
    test_Text_answer method of class Text
    '''
    text = Text()
    text.answer()

# Generated at 2022-06-23 21:57:39.318634
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Language
    from bson.objectid import ObjectId
    text = Text(language=Language.ENGLISH, seed=ObjectId("5a66a18d60c1f8270e804e45"))
    word_list = text.words(quantity=3)
    print(word_list)

test_Text_words()

# Generated at 2022-06-23 21:57:41.725311
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    for _ in range(10):
        rgb = t.rgb_color()
        print(rgb)


# Generated at 2022-06-23 21:57:44.944169
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    for i in range(1000):
        s = Text().sentence()
        assert(s != '')



# Generated at 2022-06-23 21:57:47.137223
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    res = text.title()
    assert len(res) > 0


# Generated at 2022-06-23 21:57:48.708427
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']

# Generated at 2022-06-23 21:57:51.966689
# Unit test for method text of class Text
def test_Text_text():
    from mimesis import Text
    t = Text()
    text = t.text()
    assert text != "" and len(text) > 0


# Generated at 2022-06-23 21:57:53.878919
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    swear_word = t.swear_word()
    print(swear_word)

test_Text_swear_word()

# Generated at 2022-06-23 21:57:57.137323
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    result = text.word()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:57:59.046474
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text() #create an instance of class Text
    print(text.sentence())


# Generated at 2022-06-23 21:58:04.126828
# Unit test for method quote of class Text
def test_Text_quote():
    '''
    Create example of quotes from movie.
    '''
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    text = Text(Locale.ENGLISH)
    assert text.quote() == "I'm surprised you had the courage to take the responsibility yourself."


# Generated at 2022-06-23 21:58:08.083043
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.builtins import Text
    text = Text()
    test_value_for_text = text.text(quantity=1)
    expected_value_for_text = 'a'
    assert test_value_for_text == expected_value_for_text


# Generated at 2022-06-23 21:58:09.371908
# Unit test for method word of class Text
def test_Text_word():
    for i in range(10):
        print(Text().word())

# Generated at 2022-06-23 21:58:11.463754
# Unit test for method word of class Text
def test_Text_word():
    t = Text(seed=1)
    word = t.word()
    expected = 'Science'
    assert word == expected
    assert word != '1234'


# Generated at 2022-06-23 21:58:13.618355
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    hex_color = Text.hex_color(safe=True)
    assert len(hex_color) == 7
    assert hex_color[0] == '#'

# Generated at 2022-06-23 21:58:16.013612
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    s = t.text(quantity=1)
    assert(isinstance(s, str))

# Generated at 2022-06-23 21:58:21.137820
# Unit test for method level of class Text
def test_Text_level():
    case1 = 'critical'
    levels = [
        'critical', 'debug', 'emergency', 'error',
        'information', 'notice', 'warning'
    ]
    test = Text('en')
    for _ in range(100):
        assert test.level() in levels
    assert test.level() == case1


# Generated at 2022-06-23 21:58:22.551484
# Unit test for method words of class Text
def test_Text_words():
    # Create object of class
    obj = Text()
    # print(obj.words(quantity=10))



# Generated at 2022-06-23 21:58:24.691664
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert isinstance(level, str)
    assert level != ""
    assert len(level) > 0


# Generated at 2022-06-23 21:58:30.055107
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test_Text_rgb_color function."""
    test_Text = Text('en')
    test_rgb = test_Text.rgb_color()
    assert len(test_rgb) == 3

    test_rgb = test_Text.rgb_color(True)
    assert len(test_rgb) == 3

# Generated at 2022-06-23 21:58:31.842137
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in t._data['level']


# Generated at 2022-06-23 21:58:34.325509
# Unit test for method sentence of class Text
def test_Text_sentence():
    # sentence = Text._Text__sentence()
    # assert isinstance(sentence, str)
    # assert sentence == "Bond... James Bond."
    pass

# Generated at 2022-06-23 21:58:36.344416
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert isinstance(level, str)
    assert len(level) > 0



# Generated at 2022-06-23 21:58:37.337110
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    ans = text.quote()
    assert ans != ''


# Generated at 2022-06-23 21:58:39.595938
# Unit test for method quote of class Text
def test_Text_quote():
	txt = Text()
	quote_list = txt.quote()
	assert isinstance(quote_list, str), "Quote should be of type string"

# Generated at 2022-06-23 21:58:40.984261
# Unit test for constructor of class Text
def test_Text():
    from mimesis.providers.text import Text
    t = Text()

# Generated at 2022-06-23 21:58:45.234250
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    for _ in range(100):
        assert t.answer() in ["Yes", "Yes.", "No", "No.", "Maybe.", "Maybe", "Probably", "Probably."]


# Generated at 2022-06-23 21:58:51.682596
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import FinlandSpecProvider
    from mimesis.enums import Culture
    from mimesis.providers.text import Text
    text = Text(Culture.EN)
    text.add_provider(FinlandSpecProvider)
    try:
        assert text.answer() in text._data['answers']
    except KeyError:
        pass
    else:
        assert text.answer() == 'No'
# End of unit test


# Generated at 2022-06-23 21:58:52.363019
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() != ""


# Generated at 2022-06-23 21:58:55.641355
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_1 = Text()
    text_2 = Text(locale='de')
    assert len(text_1.alphabet()) == 26
    assert len(text_2.alphabet(lower_case=True)) == 26



# Generated at 2022-06-23 21:58:58.046615
# Unit test for method word of class Text
def test_Text_word():
    word1 = Text().word()
    assert word1 is not None


# Generated at 2022-06-23 21:59:01.040689
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Language

    text = Text(language=Language.EN)
    for _ in range(10):
        print(text.swear_word())


# Generated at 2022-06-23 21:59:02.530222
# Unit test for constructor of class Text
def test_Text():
    text=Text()
    print(text)

# Produce a random language

# Generated at 2022-06-23 21:59:03.530508
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    text.quote()

# Generated at 2022-06-23 21:59:05.949501
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    t1 = Text(safe=True)
    assert len(t.rgb_color()) == 3
    assert t1.rgb_color() in SAFE_COLORS

# Generated at 2022-06-23 21:59:08.940573
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test."""
    text = Text(seed=12345)
    answer = text.quote()
    expected = '"Bond... James Bond."'
    assert answer == expected

# Generated at 2022-06-23 21:59:12.104832
# Unit test for method quote of class Text
def test_Text_quote():
    print('test_Text_quote ... start')
    my_text = Text()
    my_quote = my_text.quote()
    print(my_quote)
    print('test_Text_quote ... end')


test_Text_quote()

# Generated at 2022-06-23 21:59:14.151985
# Unit test for constructor of class Text
def test_Text():
    t = Text(seed=42)
    assert t._datafile == 'text.json'
    assert t._pull('text.json')


# Generated at 2022-06-23 21:59:17.341529
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    text = Text(Locale.EN)
    test = text.quote()
    print(test)
    # test = text.quote(quantity=1)
    # print(test)


# Generated at 2022-06-23 21:59:21.139683
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    result = text.hex_color()
    assert len(result) == 7
    assert result[0] == '#'
    assert result[1:].isalnum()


if __name__ == '__main__':
    text = Text()
    print(text.hex_color(safe=True))

# Generated at 2022-06-23 21:59:22.762472
# Unit test for method words of class Text
def test_Text_words():
    """Testing for method words of class Text."""
    t = Text()
    assert isinstance(t.words(), type([]))


# Generated at 2022-06-23 21:59:23.540111
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())

# Generated at 2022-06-23 21:59:27.157210
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert len(sentence) > 0

# Generated at 2022-06-23 21:59:35.876946
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    t = Text()

    t.random.seed(1)
    level = t.level()
    assert level == 'critical'

    t.random.seed(2)
    level = t.level()
    assert level == 'event'

    t.random.seed(3)
    level = t.level()
    assert level == 'warning'

    t.random.seed(4)
    level = t.level()
    assert level == 'informational'

    t.random.seed(5)
    level = t.level()
    assert level == 'trace'



# Generated at 2022-06-23 21:59:40.657050
# Unit test for method level of class Text
def test_Text_level():
    print("Testing Text class method level...")
    text = Text(seed=9999)
    result = text.level()
    expected = "fatal"
    assert result == expected, "Expected {0} but got {1}".format(expected, result)
    print("PASSED: The result of method level matches the expectation!")
    print()


# Generated at 2022-06-23 21:59:44.991882
# Unit test for method words of class Text
def test_Text_words():
    provider = Text('en')
    word_list = provider.words()
    assert len(word_list) == 5
    assert isinstance(word_list, list)


# Generated at 2022-06-23 21:59:46.742643
# Unit test for method color of class Text
def test_Text_color():
    q = Text(seed=123)
    assert q.color() == "Black"


# Generated at 2022-06-23 21:59:50.740519
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    text = Text()
    sentence = text.sentence()
    assert sentence != ''
    # print(sentence)

# Generated at 2022-06-23 21:59:53.152372
# Unit test for method level of class Text
def test_Text_level():
    global text
    text = Text()
    levels = text.level()
    assert levels == "critical" or levels == "danger" or levels == "warning"


# Generated at 2022-06-23 21:59:57.451048
# Unit test for method level of class Text
def test_Text_level():
    """Assert that result from method `level` is not none and
    is in list of possible answers.
    """
    text = Text()
    possible_answers = ['High', 'Medium', 'Low', 'Critical']
    result = text.level()
    assert result != ''
    assert (result in possible_answers) == True

# Generated at 2022-06-23 21:59:58.581756
# Unit test for method title of class Text
def test_Text_title():
    result = Text(seed=123).title()
    assert result == 'Network'

# Generated at 2022-06-23 22:00:01.160848
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit tests for method answer."""
    from mimesis.enums import Locale

    t = Text(Locale.RUSSIAN)

    for i in range(10):
        assert t.answer() in t._data['answers']

# Generated at 2022-06-23 22:00:04.423857
# Unit test for method level of class Text
def test_Text_level():
    import random
    t = Text(random)
    result = t.level()
    assert type(result) == str


# Generated at 2022-06-23 22:00:07.128181
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text(4)
    assert isinstance(text, str)
    assert 4 <= len(text.split()) <= 6


# Generated at 2022-06-23 22:00:18.057088
# Unit test for method text of class Text
def test_Text_text():
    """
    Test case for method text of class Text.
    """
    text = Text(seed=2)

# Generated at 2022-06-23 22:00:19.850713
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = {"#d8346b"}
    assert result == Text().hex_color(safe=True)



# Generated at 2022-06-23 22:00:26.632440
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    t = Text()

    words = t.words(quantity=5, locale=Locale.EN)
    assert len(words) == 5
    assert isinstance(words, (list, tuple))

    words = t.words(quantity=5, locale=Locale.RU)
    assert len(words) == 5
    assert isinstance(words, (list, tuple))

    words = t.words(quantity=5)
    assert len(words) == 5
    assert isinstance(words, (list, tuple))


# Generated at 2022-06-23 22:00:29.219390
# Unit test for method word of class Text
def test_Text_word():
    for i in range(1000):
        text = Text()
        word = text.word()
        assert len(word) > 0

# Generated at 2022-06-23 22:00:32.347980
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert type(t.rgb_color()) == tuple
    assert len(t.rgb_color()) == 3


# Generated at 2022-06-23 22:00:34.819114
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    txt = Text()
    color = txt.rgb_color()
    assert len(color) == 3
    assert isinstance(color, tuple)


# Generated at 2022-06-23 22:00:38.353922
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('ja')
    upper_alphabet = text.alphabet()
    lower_alphabet = text.alphabet(lower_case=True)
    #output = f"upper alphabet : {upper_alphabet} ; lower alphabet : {lower_alphabet}"
    #print(output)

# test_Text_alphabet()


# Generated at 2022-06-23 22:00:46.000865
# Unit test for constructor of class Text
def test_Text():
	text_seed = Text(seed=42)
	assert (text_seed.alphabet(lower_case=True) == ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'])
	assert (text_seed.alphabet(lower_case=False) == ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'])
	assert (text_seed.level() == 'critical')

# Generated at 2022-06-23 22:00:48.821011
# Unit test for method text of class Text
def test_Text_text():
    m = Text()
    list_of_sentences = m.text()
    print(list_of_sentences)
    assert type(list_of_sentences) is str


# Generated at 2022-06-23 22:00:52.183339
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    text = Text(Locale.EN)
    assert text.level() in ['critical', 'high', 'medium', 'low', 'none']


# Generated at 2022-06-23 22:00:54.808341
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert (isinstance(text.alphabet(), list))


# Generated at 2022-06-23 22:01:00.580562
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=0, locale='en')
    res = text.quote()
    assert res == '"Bond... James Bond."'
    assert res == '"Bond... James Bond."'
    assert res == '"Bond... James Bond."'
    assert res == '"Bond... James Bond."'
    assert res == '"Bond... James Bond."'



# Generated at 2022-06-23 22:01:05.067931
# Unit test for method quote of class Text
def test_Text_quote():
    # Initialize instance of class Text
    text = Text(seed=42)
    # Call method quote() of class Text
    # and save the result in variable result
    result = text.quote()
    # Check that result is the same as expected
    assert result == '"Bond... James Bond."'


# Generated at 2022-06-23 22:01:06.059098
# Unit test for method quote of class Text
def test_Text_quote():
    assert type(Text().quote()) == str

# Generated at 2022-06-23 22:01:07.050861
# Unit test for method text of class Text
def test_Text_text():
    assert Text('en').text() != ''

# Generated at 2022-06-23 22:01:12.080403
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from unittest import TestCase
    tc = TestCase()
    from mimesis.providers.text import Text
    t = Text('en')
    hex_color_str = t.hex_color(False)
    hex_color_str2 = t.hex_color(True)
    tc.assertEqual(len(hex_color_str), 7)
    tc.assertEqual(len(hex_color_str2), 7)


# Generated at 2022-06-23 22:01:15.434944
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.localization.en import English
    from mimesis.mimesis import Mimesis
    mimesis = Mimesis(language=English)
    a = mimesis.Text.title()
    assert isinstance(a, str)
    pass

# Generated at 2022-06-23 22:01:17.740371
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answers() in t._data['answers']

# Generated at 2022-06-23 22:01:20.910323
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider()
    ru_answers = ru.text.answer()
    assert ru_answers == ru.text._data['answers'][0]

# Generated at 2022-06-23 22:01:28.306649
# Unit test for constructor of class Text
def test_Text():
    a = Text.alphabet()           # => ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я']
    b = Text.level()              # => critical
    c = Text.text()               # => Несмотря на это, что в некотор

# Generated at 2022-06-23 22:01:30.810347
# Unit test for method text of class Text
def test_Text_text():
    t = Text(seed=12345)
    assert t.text() == 'I am sorry for the loss of your mother.'