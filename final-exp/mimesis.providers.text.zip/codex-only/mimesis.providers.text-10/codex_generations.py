

# Generated at 2022-06-23 21:51:34.056970
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Create an instance Text
    text = Text()
    # call method swear_word
    swear_word = text.swear_word()
    assert isinstance(swear_word, str)
    assert len(swear_word) > 0


# Generated at 2022-06-23 21:51:34.695824
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote()

# Generated at 2022-06-23 21:51:43.340151
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    value = txt.color()

# Generated at 2022-06-23 21:51:52.969414
# Unit test for method words of class Text
def test_Text_words():
    str_list = []
    for i in range(0, 20):
        str_list.append(Text(seed=i).words())

# Generated at 2022-06-23 21:51:55.392815
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() != ''
    assert text.text() == 'This is a random generator of text'
    assert text.text() != 'This is a random generator of text'


# Generated at 2022-06-23 21:51:57.796924
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed=123)
    assert t.swear_word() == 'damn'
    assert t.swear_word() == 'damn'

# Generated at 2022-06-23 21:52:02.370756
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for method Text.hex_color()"""
    tx = Text()
    assert isinstance(tx.hex_color(), str) == True
    assert len(tx.hex_color()) == 7
    assert len(tx.hex_color(safe=True)) == 7



# Generated at 2022-06-23 21:52:05.431765
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text"""
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-23 21:52:07.448992
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert type(text.answer()) is str


# Generated at 2022-06-23 21:52:09.584020
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text(quantity=2) != ' '


# Generated at 2022-06-23 21:52:17.237483
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.alphabet()
    assert text.alphabet(lower_case=True)
    assert text.answer()
    assert text.color()
    assert text.hex_color()
    assert text.hex_color(safe=True)
    assert text.level()
    assert text.quote()
    assert text.rgb_color()
    assert text.rgb_color(safe=True)
    assert text.sentence()
    assert text.swear_word()
    assert text.text()
    assert text.title()
    assert text.word()
    assert text.words()

# Generated at 2022-06-23 21:52:19.512601
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ['Yes', 'No', 'Maybe', 'I don\'t know']


# Generated at 2022-06-23 21:52:20.527353
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    pass


# Generated at 2022-06-23 21:52:22.995220
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text."""
    data = Text()
    answer = data.color()
    assert isinstance(answer, str)
    assert answer



# Generated at 2022-06-23 21:52:27.930388
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    word1 = t.word()
    t = Text()
    word2 = t.word()
    if word1 == word2:
        print(word1 + " " + word2 + " -> " + "test failed")
    else:
        print(word1 + " " + word2 + " -> " + "test passed")


# Generated at 2022-06-23 21:52:30.685438
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text.data['words']['bad']

# Generated at 2022-06-23 21:52:33.181898
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    colors = set(t.color() for _ in range(1000))
    assert len(colors) == len(t._data['color'])

# Generated at 2022-06-23 21:52:35.184776
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    t = text.title()
    assert t in text(text.data())

# Generated at 2022-06-23 21:52:37.959374
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    t.title()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-23 21:52:40.191473
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert not re.search(r"\s", level)


# Generated at 2022-06-23 21:52:41.576330
# Unit test for method level of class Text
def test_Text_level():
    x = Text()
    assert x.level() != x.level()


# Generated at 2022-06-23 21:52:46.755871
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    t = Text('en', 0)
    t.quote()
    t.quote(locales='ru')


# Generated at 2022-06-23 21:52:48.039948
# Unit test for method text of class Text
def test_Text_text():
    x = Text()


# Generated at 2022-06-23 21:52:49.168550
# Unit test for method sentence of class Text
def test_Text_sentence():
        text = Text()
        assert isinstance(text.sentence(), str)


# Generated at 2022-06-23 21:52:51.670045
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text().hex_color() != ''
    assert Text().hex_color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 21:52:53.692438
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()
    color_name = provider.color()
    assert color_name in provider._data['color']


# Generated at 2022-06-23 21:52:57.634869
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert type(text.hex_color()) == str
    # TODO: Write a better test.
    assert len(text.hex_color()) == 7


# Generated at 2022-06-23 21:53:02.418659
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import ColorCodeType
    text = Text()
    # safe colors
    assert text.hex_color(safe=True) in SAFE_COLORS
    # random colors
    assert str(text.hex_color(safe=False)) in ColorCodeType.HEX_COLOR.value


# Generated at 2022-06-23 21:53:12.485365
# Unit test for method words of class Text
def test_Text_words():
    import pytest
    from mimesis.builtins import Text as txt1
    from mimesis.enums import WordType
    from mimesis.enums import WordSubset

    t = txt1('en')

    assert isinstance(t.words(), list)
    assert len(t.words()) == 5

    assert len(t.words(10)) == 10
    assert isinstance(t.words(10), list)

    assert isinstance(t.words(WordType.NORMAL), list)
    assert len(t.words(WordType.NORMAL)) == 5
    assert isinstance(t.words(WordType.NORMAL, 10), list)
    assert len(t.words(WordType.NORMAL, 10)) == 10

    assert isinstance(t.words(WordType.BAD), list)

# Generated at 2022-06-23 21:53:20.089731
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Method to test method swear_word of class Text."""
    text = Text()

    expected_result = 'shit'

    for _ in range(50):
        assert len(text.swear_word()) > 0
        if text.swear_word() == expected_result:
            break
        # If 50 iterations executed, it was impossible to find expected_result
        assert False



# Generated at 2022-06-23 21:53:25.033854
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.enums import Person as PersonEnum
    import re
    import random
    person = PersonEnum.MALE
    provider = Text(seed=random.randint(0, 100))
    actual = len(re.findall('[aeiou]', ''.join(provider.words(quantity=10))))
    expected = 4
    assert actual > expected


# Generated at 2022-06-23 21:53:27.237490
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    test = text.text()
    assert type(test) == str
    assert len(test.split()) > 3


# Generated at 2022-06-23 21:53:29.801927
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ["Yes", "No"]

# Generated at 2022-06-23 21:53:39.939691
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    answer = text.answer()
    assert answer in text._data['answers']
    assert text.color() in text._data['color']
    assert text.level() in text._data['level']
    assert isinstance(text.hex_color(), str)
    assert text.hex_color(safe=True) in SAFE_COLORS
    assert isinstance(text.rgb_color(), tuple)
    assert text.rgb_color(safe=True) in text._data['safe_colors']
    assert text.quote() in text._data['quotes']
    assert text.swear_word() in text._data['words']['bad']
    assert text.word() in text._data['words']['normal']
    assert isinstance(text.words(), list)
    assert text.sentence

# Generated at 2022-06-23 21:53:42.848383
# Unit test for method color of class Text
def test_Text_color():
    # Create an instance of class Text
    text = Text()
    # Check if method color of class Text return a string
    assert isinstance(text.color(), str)


# Generated at 2022-06-23 21:53:45.561949
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for answer method of class Text."""
    t = Text('en')
    assert t.answer() in t._data['answers']


# Generated at 2022-06-23 21:53:49.115260
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    result1 = t.rgb_color(True)
    result2 = t.rgb_color()
    assert isinstance(result1, tuple)
    assert isinstance(result2, tuple)

# Generated at 2022-06-23 21:53:50.813820
# Unit test for method level of class Text
def test_Text_level():
    provider = Text()
    assert type(provider.level())==str

# Generated at 2022-06-23 21:53:53.783355
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=6)
    assert words
    assert len(words) == 6


# Generated at 2022-06-23 21:53:56.269523
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    print(t.alphabet(lower_case=True)) # ['a', 'b', 'c', 'd', 'e', ...]


# Generated at 2022-06-23 21:53:58.031213
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    for i in range (100):
        t = Text()
        s = t.swear_word()
        assert type(s) == str

# Generated at 2022-06-23 21:53:59.657200
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    t.quote

# Generated at 2022-06-23 21:54:02.362132
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert result != ""


# Generated at 2022-06-23 21:54:04.342755
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    text = Text()
    title = text.title()
    assert title is not None
    assert isinstance(title, str)

# Generated at 2022-06-23 21:54:07.565264
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert type(text.sentence()) == str


# Generated at 2022-06-23 21:54:12.081815
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    from mimesis.builtins import  Text
    # Test for method swear_word of class Text
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text.words().get('bad')

# Generated at 2022-06-23 21:54:13.115707
# Unit test for method color of class Text
def test_Text_color():
    # print(Text.color())
    pass


# Generated at 2022-06-23 21:54:18.825906
# Unit test for method answer of class Text
def test_Text_answer():
    import time
    import random
    import numpy as np

    start_time = time.time()
    answer_list = []
    for i in range(100000):
        t = Text()
        answer = t.answer()
        answer_list.append(answer)
    test_time = time.time()-start_time
    print("test_time is %f second" % test_time)

    np.savetxt('test_Text_answer.csv', answer_list, delimiter=',',fmt='%s')
# test_Text_answer()

# Generated at 2022-06-23 21:54:21.850015
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    expected = 'What is the answer to the Ultimate Question of Life, the Universe, and Everything?'
    assert t.text(1) == expected


# Generated at 2022-06-23 21:54:23.575569
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-23 21:54:25.326544
# Unit test for method title of class Text
def test_Text_title():
    class_text = Text("en")
    assert 'The' in class_text.title()



# Generated at 2022-06-23 21:54:31.513837
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    # Unit test for method rgb_color of class Text
    for _ in range(100):
        result = t.rgb_color()
        assert len(result) == 3
        assert isinstance(result[0], int)
        assert isinstance(result[1], int)
        assert isinstance(result[2], int)
        assert result[0] >= 0
        assert result[0] <= 255
        assert result[1] >= 0
        assert result[1] <= 255
        assert result[2] >= 0
        assert result[2] <= 255
        assert isinstance(result, tuple)

# Generated at 2022-06-23 21:54:33.009030
# Unit test for method color of class Text
def test_Text_color():
    data = Text()
    assert data.color() in data._data['color']

# Generated at 2022-06-23 21:54:35.755338
# Unit test for method text of class Text
def test_Text_text():
    """Unit test."""
    text = Text()
    answer = text.text(quantity=2)
    assert len(answer.split()) > 0


# Generated at 2022-06-23 21:54:39.013899
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=42)
    rgb_color = t.rgb_color()
    assert rgb_color == (27, 229, 234)

# Generated at 2022-06-23 21:54:40.294041
# Unit test for constructor of class Text
def test_Text():
    gen = Text()
    print(gen.alphabet())

# Generated at 2022-06-23 21:54:42.794643
# Unit test for constructor of class Text
def test_Text():
    from mimesis.enums import Gender
    from mimesis.builtins import Text
    t=Text(gender=Gender.MALE)
    print(t.color)

# Generated at 2022-06-23 21:54:45.205626
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text('pt')
    for i in range(1, 1000):
        texto = t.sentence()
        if len(texto) < 3:
            print('ERRO - Texto com {} caracters: "{}"'.format(len(texto), texto))

test_Text_sentence()

# Generated at 2022-06-23 21:54:47.408877
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-23 21:54:48.202618
# Unit test for constructor of class Text
def test_Text():
    t = Text('en')


# Generated at 2022-06-23 21:54:52.212338
# Unit test for method quote of class Text
def test_Text_quote():
    tmp = Text()
    print(tmp.quote())
    print(tmp.quote())
    print(tmp.quote())
    print(tmp.quote())
    print(tmp.quote())


# Generated at 2022-06-23 21:54:55.556218
# Unit test for method color of class Text
def test_Text_color():
    # Create object Text
    text = Text()
    # Get a random name of color
    color = text.color()
    # Check type result
    assert isinstance(color, str)


# Generated at 2022-06-23 21:54:57.402005
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']


# Generated at 2022-06-23 21:54:59.412952
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed=10)
    result = text.color()
    assert result == 'Red'

# Generated at 2022-06-23 21:55:01.465443
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title = t.title()
    assert isinstance(title, str)


# Generated at 2022-06-23 21:55:05.708493
# Unit test for method quote of class Text
def test_Text_quote():
    """Test case for method quote of class Text."""
    t = Text(seed=27)
    assert t.quote() == 'Три дня, и она еще полагается на него.'

# Generated at 2022-06-23 21:55:08.181438
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    print(color)



# Generated at 2022-06-23 21:55:09.491067
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-23 21:55:11.647493
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    word = text.swear_word()
    print(word)
    assert word



# Generated at 2022-06-23 21:55:14.060106
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    try:
        text.sentence()
    except Exception:
        pass

# Generated at 2022-06-23 21:55:15.436065
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()

# Generated at 2022-06-23 21:55:17.254430
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('ru')
    print("Swear word: " + text.swear_word())



# Generated at 2022-06-23 21:55:18.614672
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert isinstance(text.rgb_color(), tuple)
    

# Generated at 2022-06-23 21:55:19.478101
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    assert type(result) == str

# Generated at 2022-06-23 21:55:21.359699
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    word = t.swear_word()
    assert word in t._data['words'].get('bad')


# Generated at 2022-06-23 21:55:24.215773
# Unit test for method color of class Text
def test_Text_color():
    """Check color method of Text class.
    """
    text = Text('ru')
    for _ in range(10):
        res = text.color()
        assert isinstance(res, str)


# Generated at 2022-06-23 21:55:25.674542
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    print(text.hex_color(False))


# Generated at 2022-06-23 21:55:26.978371
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    g = t.word()
    f = "science"
    assert(g == f)



# Generated at 2022-06-23 21:55:33.130041
# Unit test for method color of class Text
def test_Text_color():
    class Test_Text(Text):
        def __init__(self, *args, **kwargs):
            self._datafile = 'text.json'
            self._pull(self._datafile)

    test_text = Test_Text()
    color = "Red"
    assert test_text.color() == color



# Generated at 2022-06-23 21:55:36.286531
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert isinstance(quote, str)
    assert len(quote) > 3
    assert isinstance(quote, str)


# Generated at 2022-06-23 21:55:37.956747
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text(use_random=True, seeds=[1]).sentence() == 'Within five or ten'

# Generated at 2022-06-23 21:55:40.727890
# Unit test for method answer of class Text
def test_Text_answer():
    global text
    text = Text()
    for _ in range(100):
        assert text.answer()


# Generated at 2022-06-23 21:55:42.420622
# Unit test for method answer of class Text
def test_Text_answer():
    f = Text('ru')
    return f.answer()

# Generated at 2022-06-23 21:55:44.344168
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() == 'Algorithms'


# Generated at 2022-06-23 21:55:48.147116
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text(seed=42)
    hex_color = text.hex_color()
    assert hex_color == "#e4bdbc"


# Generated at 2022-06-23 21:55:50.825384
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    test_data = text.word()
    assert test_data
    assert len(test_data) > 0


# Generated at 2022-06-23 21:55:54.297301
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text.

    To run this test you must type "make test" in project root folder.
    """
    obj = Text('en')
    quote = [obj.quote() for _ in range(5)]
    print(quote)


# Generated at 2022-06-23 21:55:58.975494
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    data = text.words(quantity = 0)
    assert type(data) == list
    assert len(data) == 0
    data = text.words(quantity = 10)
    assert type(data) == list
    assert len(data) == 10
    data = text.words(quantity = 20)
    assert type(data) == list
    assert len(data) == 20
    data = text.words(quantity = 24)
    assert type(data) == list
    assert len(data) == 24


# Generated at 2022-06-23 21:56:06.643156
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    assert x.color() in x
    assert x.sentence() in x
    assert x.text() in x
    assert x.title() in x
    assert x.word() in x
    assert x.words() in x
    assert x.swear_word() in x
    assert x.quote() in x
    assert x.answer() in x
    assert x.hex_color() in x
    assert x.rgb_color() in x

# Generated at 2022-06-23 21:56:07.621872
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    print(color)


# Generated at 2022-06-23 21:56:08.753159
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())

# Generated at 2022-06-23 21:56:16.399821
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    print(t.title())
    print(t.text(quantity=2))
    print(t.sentence())
    print(t.words(quantity=6))
    print(t.word())
    print(t.swear_word())
    print(t.quote())
    print(t.color())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())

if __name__ == '__main__':
    test_Text_title()

# Generated at 2022-06-23 21:56:19.290269
# Unit test for method text of class Text
def test_Text_text():
    a = Text(seed=1)
    assert a.text() == 'Aenean nibh. Fusce ut mauris nec sapien ultricies porta. Magna sit amet turpis.'


# Generated at 2022-06-23 21:56:21.311179
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=123)
    title = text.title()
    assert title == 'It is impossible to explain.'



# Generated at 2022-06-23 21:56:23.036906
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed = 3)
    assert text.color() == "Red"

# Generated at 2022-06-23 21:56:27.041408
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    text = Text(Language.ENGLISH) # Instantiation class

    for _ in range(5):
        _result = text.color() # Get a random color name
        assert _result in text._data['color'] # assert condition


# Generated at 2022-06-23 21:56:31.586752
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert Text().alphabet(False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-23 21:56:33.290636
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() == '"Bond… James Bond."'


# Generated at 2022-06-23 21:56:35.071278
# Unit test for method words of class Text
def test_Text_words():
    list_words = Text().words(quantity=5)
    assert len(list_words) == 5

# Generated at 2022-06-23 21:56:36.203664
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """."""
    text = Text()
    assert len(text.hex_color()) == 7



# Generated at 2022-06-23 21:56:37.733125
# Unit test for method word of class Text
def test_Text_word():
    a = Text()
    assert isinstance(a.word(), str) == True


# Generated at 2022-06-23 21:56:39.266543
# Unit test for method level of class Text
def test_Text_level():
    a = Text()
    assert len(a.level()) > 0


# Generated at 2022-06-23 21:56:41.222763
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert isinstance(t.alphabet(), list)


# Generated at 2022-06-23 21:56:43.522666
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words = t.words(quantity = 3)
    print(words)



# Generated at 2022-06-23 21:56:50.318229
# Unit test for constructor of class Text
def test_Text():
    # Creating text instance
    from mimesis.providers.text import Text
    provider = Text()
    # Getting random alphabet letter
    provider.alphabet()
    # Getting a random answer
    provider.answer()
    # Getting a random color
    provider.color()
    # Getting random hex color
    provider.hex_color()
    # Getting random RGB color
    provider.rgb_color()
    # Getting random level
    provider.level()
    # Getting random quote
    provider.quote()
    # Getting random sentence
    provider.sentence()
    # Getting random text
    provider.text()
    # Getting random title
    provider.title()
    # Getting random word
    provider.word()
    # Getting random words
    provider.words()
    # Getting random swear words
    provider.swear_word()
# End

# Generated at 2022-06-23 21:56:53.728581
# Unit test for method sentence of class Text
def test_Text_sentence():
    print("\n\nTesting Text_sentence")

    t = Text()
    for i in range(100):
        print(t.sentence())


# Generated at 2022-06-23 21:57:01.008734
# Unit test for method title of class Text
def test_Text_title():
    """Test method title of class Language."""
    text = Text()
    print(text.title())
    print(text.sentence())
    print(text.words())
    print(text.word())
    print(text.swear_word())
    print(text.quote())
    print(text.color())
    print(text.hex_color())
    print(text.hex_color(safe=True))
    print(text.rgb_color())
    print(text.rgb_color(safe=True))
    print(text.answer())


# Generated at 2022-06-23 21:57:02.542169
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote in text._data['quotes']

# Generated at 2022-06-23 21:57:07.500179
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    ans = text.answer()
    assert ans in ['yes','no','ok','k','yes','sure','yes','Sure','no','No','no','yes','Yes','yes','no','no','dont','Don\'t','u','U','yeah','Yea','no','No','no','yes','Yes','Yes','ok','Ok','ok','Ok','nope','Yes','no']



# Generated at 2022-06-23 21:57:09.054722
# Unit test for method level of class Text
def test_Text_level():
    t = Text()

    assert isinstance(t.level(), str) == True


# Generated at 2022-06-23 21:57:13.061649
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    import random
    random.seed(424242)
    text = Text()
    assert text.hex_color() == '#e76f2c'
    assert text.hex_color(safe=True) == '#e76f2c'


# Generated at 2022-06-23 21:57:18.003731
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins.en import English
    text = Text(English())
    result = text.words(quantity=3)
    assert len(result) == 3
    assert isinstance(result, list)
    for i in range(3):
        assert isinstance(result[i], str)

# Generated at 2022-06-23 21:57:23.621026
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for method rgb_color of class Text"""
    t = Text()
    result = type(t.rgb_color())
    assert result == tuple
    assert t.rgb_color() != t.rgb_color()
    for _ in range(10):
        assert t.rgb_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-23 21:57:25.606909
# Unit test for method title of class Text
def test_Text_title():
    # Create a new object Text
    text = Text()
    
    title = text.title()
    
    # Checks that the type of the generated value is str
    assert isinstance(title, str)

# Generated at 2022-06-23 21:57:31.693879
# Unit test for constructor of class Text
def test_Text():
    c = Text()
    assert c is not None
    assert hasattr(c, 'random')
    assert hasattr(c, 'dataset')
    assert hasattr(c, '__locale__')
    assert hasattr(c, 'provider')
    assert hasattr(c, '__seed__')


# Generated at 2022-06-23 21:57:33.684809
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())

# Generated at 2022-06-23 21:57:34.717348
# Unit test for method word of class Text
def test_Text_word():
    print("Call function word: ", Text().word())

# Generated at 2022-06-23 21:57:41.784918
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    en = Text('en')
    # Male
    male = en.create(seed=420, gender=Gender.MALE)
    # text = male.text()
    # assert text.startswith('"When you')
    # Female
    female = en.create(seed=420, gender=Gender.FEMALE)
    # text = female.text()
    # assert text.startswith('"When you')

# Generated at 2022-06-23 21:57:49.753316
# Unit test for constructor of class Text
def test_Text():
    text = Text()

    for x in range(10):
        text.alphabet()
        text.level()
        text.text()
        text.sentence()
        text.title()
        text.words()
        text.word()
        text.quote()
        text.color()
        text.hex_color()
        text.rgb_color()
        text.answer()

    text.hex_color(safe=True)
    text.rgb_color(safe=True)
    text.swear_word()

    # _hex_to_rgb
    rgb = text._hex_to_rgb('#ff0000')
    rgb[0]
    rgb[1]
    rgb[2]


# Generated at 2022-06-23 21:57:51.735875
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-23 21:57:53.379007
# Unit test for method word of class Text
def test_Text_word():
    text_generator = Text()
    print(text_generator.word())


# Generated at 2022-06-23 21:57:54.476596
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-23 21:57:58.383563
# Unit test for method text of class Text
def test_Text_text():
    """Test for class Text method text
    """
    text = Text()
    result = text.text(quantity=1)
    assert result


# Generated at 2022-06-23 21:58:00.712587
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    answer = t.answer()
    assert isinstance(answer, str) and answer in ["Yes","No"]


# Generated at 2022-06-23 21:58:06.451464
# Unit test for method sentence of class Text
def test_Text_sentence():
    s = Text(seed = 42)
    assert s.seed == 42
    assert s.sentence() == 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.'

# Generated at 2022-06-23 21:58:08.424202
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    result = text.title()
    assert type(result) is str
    assert len(result.split()) > 1


# Generated at 2022-06-23 21:58:09.232885
# Unit test for method title of class Text
def test_Text_title():
    print(Text(seed=4321).title())

# Generated at 2022-06-23 21:58:10.742903
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text
    t = Text()
    assert isinstance(t.words(), list) == True


# Generated at 2022-06-23 21:58:12.216660
# Unit test for method color of class Text
def test_Text_color():
    obj = Text('zh')
    color = obj.color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:58:13.749152
# Unit test for method title of class Text
def test_Text_title():
    txt = Text()
    #title = txt.title()
    print(txt.title())


# Generated at 2022-06-23 21:58:15.732762
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() != ''
    assert isinstance(Text().title(), str)

# Generated at 2022-06-23 21:58:23.834992
# Unit test for method answer of class Text
def test_Text_answer():
    import pytest
    from mimesis.enums import Languages
    from mimesis.providers.text import Text
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider

    # Initialize class
    text = Text('ru')

    with pytest.raises(NonEnumerableError):
        text.answer(non_enum=True)

    # Check by default version of language
    answer = text.answer()
    assert answer in Text(Languages.RU)._data['answers']
    assert answer in RussiaSpecProvider().yes_no()

# Generated at 2022-06-23 21:58:25.399122
# Unit test for method word of class Text
def test_Text_word():

    t = Text()
    word = t.word()

    assert isinstance(word, str)


# Generated at 2022-06-23 21:58:27.139160
# Unit test for method quote of class Text
def test_Text_quote():
    '''Check if the method works properly'''
    text = Text()
    assert text.quote() in text._data['quotes']

# Generated at 2022-06-23 21:58:28.524348
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    print(text.quote())

# Generated at 2022-06-23 21:58:32.046838
# Unit test for method text of class Text
def test_Text_text():
    a = Text()
    b = a.text()
    c = a.text(quantity=10)
    assert len(b) > 0
    assert len(c) > 0


# Generated at 2022-06-23 21:58:38.368976
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    # text = Text(seed=42)
    # assert text.text(quantity=10) == 'Voluptas et ut eius nihil vel. Est velit velit quisquam sed et. Et incidunt voluptate sed sed. Molestiae dignissimos et aut. Neque quia et ut neque. Maxime fugiat est tempora voluptatem maiores quis. Provident eum sequi autem voluptates esse autem et. Officiis aut dolores voluptatibus et.'

# Generated at 2022-06-23 21:58:40.792339
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Branch
    from mimesis.providers.text import Text

    text_provider = Text(Branch.EN)
    text_provider.level()

# Generated at 2022-06-23 21:58:42.556214
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert (len(text.sentence()) > 0)



# Generated at 2022-06-23 21:58:45.182325
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())


# Generated at 2022-06-23 21:58:55.102137
# Unit test for constructor of class Text
def test_Text():
    # Generator of objects
    text = Text()
    assert isinstance(text.alphabet, list)
    assert isinstance(text.level(), str)
    assert isinstance(text.text(10), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.title(), str)
    assert isinstance(text.words(1), list)
    assert isinstance(text.word(), str)
    assert isinstance(text.swear_word(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.color(), str)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.answer(), str)

# Generated at 2022-06-23 21:58:57.288307
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import RussiaSpecProvider
    ru = Text(RussiaSpecProvider())
    assert ru.word() in ru._data['words']['normal']

# Generated at 2022-06-23 21:58:58.786732
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text()
    print(provider.answer())


# Generated at 2022-06-23 21:59:00.617632
# Unit test for method quote of class Text
def test_Text_quote():
    a = Text(seed=12345)
    print(a.quote())


# Generated at 2022-06-23 21:59:02.950852
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert re.search(r'[a-fA-F0-9]{6}', text.hex_color())

# Generated at 2022-06-23 21:59:04.906071
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert type(color) is str
    assert color in text._data['color']

# Generated at 2022-06-23 21:59:07.701881
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    assert isinstance(result, str)
    assert result.isalnum()


# Generated at 2022-06-23 21:59:16.681561
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.answer(),t.alphabet())
    print(t.color(),t.hex_color(),t.rgb_color())
    print(t.level(),t.quote(),t.sentence(),t.swear_word(),t.title(),t.word(),t.words())
    print(type(t.answer()),type(t.alphabet()))
    print(type(t.color()),type(t.hex_color()),type(t.rgb_color()))
    print(type(t.level()),type(t.quote()),type(t.sentence()),type(t.swear_word()),type(t.title()),type(t.word()),type(t.words()))


# Generated at 2022-06-23 21:59:18.415778
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text(seed=12)
    assert t.hex_color() == "#a0b5ed"

# Generated at 2022-06-23 21:59:19.565131
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert len(title) > 0


# Generated at 2022-06-23 21:59:21.321395
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    sw = Text()
    print(sw.swear_word())


# Generated at 2022-06-23 21:59:22.916947
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answers = text.answer()
    assert answers in text._data['answers']



# Generated at 2022-06-23 21:59:25.567214
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())


# Generated at 2022-06-23 21:59:28.792387
# Unit test for method level of class Text
def test_Text_level():
    locale = 'en'
    provider = Text(locale)
    result = provider.level()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:59:31.809538
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    x = t.swear_word()
    if(x[0].isupper):
        print(x)
    else:
        print("Fail")


# Generated at 2022-06-23 21:59:33.444153
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-23 21:59:34.527746
# Unit test for method sentence of class Text
def test_Text_sentence():
    Text().sentence() # Returns a random sentence


# Generated at 2022-06-23 21:59:36.819331
# Unit test for method level of class Text
def test_Text_level():
    t = Text(seed=1)
    assert t.level() == 'critical'


# Generated at 2022-06-23 21:59:40.661205
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit tests Text.rgb_color method."""
    t = Text()
    rgb_color = t.rgb_color()
    assert rgb_color is not None
    assert type(rgb_color) == tuple
    assert len(rgb_color) == 3
    assert all(0 <= x <= 255 for x in rgb_color)

# Generated at 2022-06-23 21:59:46.877713
# Unit test for constructor of class Text
def test_Text():
    t = Text("tr-tr")
    assert t.provider == 'text'
    assert t.code == "tr-tr"
    assert t.country == "Turkey"
    assert t.country_code == "TR"
    assert t.language == "Turkish"
    assert t.lang == "tr"


# Generated at 2022-06-23 21:59:50.665837
# Unit test for method color of class Text
def test_Text_color():
    """Test_Text_color"""
    text = Text()
    color = text.color()
    assert color
    assert isinstance(color, str)

# Generated at 2022-06-23 21:59:52.666368
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    result = t.text()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:59:54.699556
# Unit test for method color of class Text
def test_Text_color():
    obj = Text()
    result = obj.color()
    assert result is not None


# Generated at 2022-06-23 21:59:57.120808
# Unit test for method text of class Text
def test_Text_text():
    # Arrange
    t = Text()

    # Act
    result = t.text(quantity=1)

    # Assert
    assert len(result) > 0


# Generated at 2022-06-23 22:00:04.775410
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text"""
    from mimesis import Text
    from mimesis.enums import ColorName
    from mimesis.providers.text import hex_to_rgb

    t = Text()

    for _ in range(1000):
        c = t.hex_color()
        assert len(c) == 7
        assert c.startswith('#')
        assert hex_to_rgb(c) is not None

    for i in range(1000):
        c = t.hex_color(safe=True)
        assert len(c) == 7
        assert c.startswith('#')
        assert hex_to_rgb(c) is not None
        assert c in [ColorName.color_to_hex(color) for color in ColorName]

# Generated at 2022-06-23 22:00:07.078327
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence != '';
    print(sentence)


# Generated at 2022-06-23 22:00:10.343276
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text.rgb_color()
    assert len(t) == 3
    for i in range(len(t)):
        assert t[i] < 256
        assert t[i] >= 0


# Generated at 2022-06-23 22:00:11.734187
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert isinstance(t.quote(), str)

# Generated at 2022-06-23 22:00:12.932790
# Unit test for method word of class Text
def test_Text_word():
    pass


# Generated at 2022-06-23 22:00:14.944655
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert text.hex_color() != text.hex_color()

# Generated at 2022-06-23 22:00:16.973694
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text('en')
    assert isinstance(text.sentence(), str)


# Generated at 2022-06-23 22:00:19.186891
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words'].get('bad')

# Generated at 2022-06-23 22:00:23.398516
# Unit test for method color of class Text
def test_Text_color():
    # Arrange
    t = Text()

    # Act
    result = t.color()
    result2 = t.color()
    print(result)
    print(result2)

    # Assert
    assert result != result2
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 22:00:24.630131
# Unit test for method text of class Text
def test_Text_text():
    text = Text('en')
    assert text.text(quantity=3) == 'A text. A simple text.'

# Generated at 2022-06-23 22:00:27.300250
# Unit test for method color of class Text
def test_Text_color():
    txt = Text(seed=123)
    print(txt.color())


# Generated at 2022-06-23 22:00:38.498875
# Unit test for constructor of class Text
def test_Text():
    text = Text("zh-CN")
    print("text.alphabet(True) = {0}".format(text.alphabet(True)))
    print("text.level() = {0}".format(text.level()))
    print("text.text() = {0}".format(text.text()))
    print("text.sentence() = {0}".format(text.sentence()))
    print("text.title() = {0}".format(text.title()))
    print("text.words() = {0}".format(text.words()))
    print("text.word() = {0}".format(text.word()))
    print("text.swear_word() = {0}".format(text.swear_word()))

# Generated at 2022-06-23 22:00:41.189397
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """ Test method swear_word of class Text ."""
    text = Text()
    result = text.swear_word()
    assert result in text._data['words']['bad']



# Generated at 2022-06-23 22:00:43.538636
# Unit test for method answer of class Text
def test_Text_answer():
    a = Text()
    answer = a.answer()
    assert (answer in a._data['answers'])



# Generated at 2022-06-23 22:00:45.210027
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t=Text()
    assert t.swear_word().isalpha()


# Generated at 2022-06-23 22:00:54.003808
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    b = Text(seed=0)

    assert a.color() != b.color()

    assert a.color() != b.color()
    assert a.rgb_color() != b.rgb_color()
    assert a.hex_color() != b.hex_color()
    assert a.text() != b.text()
    assert a.words() != b.words()
    assert a.word() != b.word()
    assert a.level() != b.level()
    assert a.quote() != b.quote()
    assert a.answer() != b.answer()
    assert a.sentence() != b.sentence()
    assert a.title() != b.title()
    assert a.swear_word() != b.swear_word()



# Generated at 2022-06-23 22:00:55.914401
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(), str)


# Generated at 2022-06-23 22:00:59.515850
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import Text
    from mimesis.enums import Language
    test_instance = Text(Language.ENGLISH)
    answer = test_instance.answer()
    assert answer in test_instance.answers


# Generated at 2022-06-23 22:01:06.447361
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    from mimesis.builtins import Text
    from mimesis.enums import ResultTypes

    result = Text().level()
    assert result in ["high", "medium", "low", "critical"]

    result = Text().level(result_type=ResultTypes.RAW)
    assert isinstance(result, (list, tuple))
    assert all(isinstance(x, str) for x in result)

# Uni test for method text of class Text

# Generated at 2022-06-23 22:01:09.090661
# Unit test for method title of class Text
def test_Text_title():
    # Create an instance of Text.
    text = Text()

    # Generate title
    title = text.title()

    # Check if the title is a string
    assert isinstance(title, str) is True

# Generated at 2022-06-23 22:01:10.860320
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    for _ in range(1000):
        text = Text('ja')
        assert text.swear_word()



# Generated at 2022-06-23 22:01:12.212289
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    q = text.text()
    print(q)

# Generated at 2022-06-23 22:01:15.530740
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import RussiaSpecProvider

    ro = RussiaSpecProvider()
    color = ro.text.rgb_color()
    assert type(color) == tuple
    assert len(color) == 3
    assert isinstance(color[0], int) == True
    assert isinstance(color[1], int) == True
    assert isinstance(color[2], int) == True


# Generated at 2022-06-23 22:01:19.993380
# Unit test for method word of class Text
def test_Text_word():
    # import the class Text from package mimesis
    from mimesis.builtins import Text as mimesis_Text
    # Instantiate a mimesis_Text
    t = mimesis_Text()
    # Print the value returned by the method word of instance t
    print(t.word())


# Generated at 2022-06-23 22:01:21.931706
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert len(t.word()) == 7

# Generated at 2022-06-23 22:01:22.639067
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())

# Generated at 2022-06-23 22:01:23.966305
# Unit test for method words of class Text
def test_Text_words():
    t = Text("en")
    l = t.words()
    assert len(l) == 5


# Generated at 2022-06-23 22:01:26.135091
# Unit test for method level of class Text
def test_Text_level():
    assert Text(seed=0).level() == "critical"


# Generated at 2022-06-23 22:01:34.760393
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=1)
    assert text.text(quantity=1) == 'Sidney Holt'
    assert text.text(quantity=3) == 'Sidney Holt and his team. Human health. Sidney Holt and his team.'
    text = Text(seed=2)
    assert text.text(quantity=1) == 'Theorists say that as the body increases in size, the limits on the speed of its reactions increase more rapidly.'
    assert text.text(quantity=3) == 'Theorists say that as the body increases in size, the limits on the speed of its reactions increase more rapidly. Theorists say that as the body increases in size, the limits on the speed of its reactions increase more rapidly. Theorists say that as the body increases in size, the limits on the speed of its reactions increase more rapidly.'
