

# Generated at 2022-06-23 21:51:27.452554
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']

# Generated at 2022-06-23 21:51:31.247969
# Unit test for method word of class Text
def test_Text_word():
    
    text = Text()
    word = text.word()
    assert type(word) == str and len(word) > 0
    

# Generated at 2022-06-23 21:51:32.614500
# Unit test for method words of class Text
def test_Text_words():
	words = Text().words()
	len(words) == 5

# Generated at 2022-06-23 21:51:34.735397
# Unit test for method sentence of class Text
def test_Text_sentence():
    s = Text()
    sentence = s.sentence()
    assert(len(sentence) >= 0)


# Generated at 2022-06-23 21:51:36.266766
# Unit test for method color of class Text
def test_Text_color():
    for i in range(100):
        print(Text().color())


# Generated at 2022-06-23 21:51:37.294739
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color()


# Generated at 2022-06-23 21:51:41.824161
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    import pytest
    from pprint import pprint

    t = Text()
    uppercase = t.alphabet(lower_case=False)

    lowercase = t.alphabet(lower_case=True)

    assert uppercase != lowercase
    # pprint(uppercase)
    # pprint(lowercase)
    

# Generated at 2022-06-23 21:51:45.460783
# Unit test for method level of class Text
def test_Text_level():
    t1 = Text('en')
    t2 = Text('ru')
    print(t1.level())
    print(t2.level())


# Generated at 2022-06-23 21:51:47.263822
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    generator = Text()
    temp = generator.hex_color()
    assert '#' in str(temp)

# Generated at 2022-06-23 21:51:48.629476
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text('en')
    assert t.hex_color() == '#ff0000'

# Generated at 2022-06-23 21:51:54.706210
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Method with argument safe
    t = Text()
    res = t.rgb_color(safe=True)
    assert res in SAFE_COLORS
    # Method without argument safe
    res = t.rgb_color()
    assert isinstance(res, tuple)
    assert len(res) == 3
    r,g,b = res
    assert r>=0 and r<=255
    assert g>=0 and g<=255
    assert b>=0 and b<=255

# Generated at 2022-06-23 21:51:56.408485
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() in ['shit', 'bitch', 'crap', 'fuck']

# Generated at 2022-06-23 21:52:00.928836
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words_list = text.words()
    # print(words_list)
    assert len(words_list) == 5

    word_list = text.words(10)
    # print(word_list)
    assert word_list  # todo


# Generated at 2022-06-23 21:52:10.343198
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """
    Test when you want to get a random hex color.
    """
    # Test with safe parameters
    safe = True
    text = Text()
    hex_color = text.hex_color(safe)
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color[0] == "#"
    # Test without safe parameters
    safe = False
    text = Text()
    hex_color = text.hex_color(safe)
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color[0] == "#"


# Generated at 2022-06-23 21:52:14.825119
# Unit test for method answer of class Text
def test_Text_answer():
    """Test method answer of class Text."""
    provider = Text()
    result1 = provider.answer()
    result2 = provider.answer()
    assert result1 == result2 or result1 != result2
    provider_subclass = Text()
    result1 = provider_subclass.answer()
    result2 = provider_subclass.answer()
    assert result1 == result2 or result1 != result2



# Generated at 2022-06-23 21:52:18.173322
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    title = text.title()
    print(title)
    assert title is not None

# Generated at 2022-06-23 21:52:21.538120
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.providers.base import random
    t = Text(seed=random.seed)
    t.add_provider(Locale.CHINESE)
    t._data['words']['bad'] =['a','b','c','d', 'e']
    assert t.swear_word() in ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-23 21:52:21.928698
# Unit test for method word of class Text
def test_Text_word():
    assert Text().word()

# Generated at 2022-06-23 21:52:23.735925
# Unit test for method alphabet of class Text
def test_Text_alphabet():
  assert Text().alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  assert Text().alphabet(True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 21:52:26.706461
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test Text().hex_color() method."""
    t = Text()
    hex_color = t.hex_color(safe=True)
    assert len(hex_color) == 7


# Generated at 2022-06-23 21:52:29.085242
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    random_text = text.text()
    assert(isinstance(random_text, str))


# Generated at 2022-06-23 21:52:31.962244
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis import Text
    t = Text()
    sentence = t.sentence()
    assert sentence in t._data['text']


# Generated at 2022-06-23 21:52:35.183331
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert result in [
        'critical', 'danger', 'error', 'warning', 'info', 'success', 'debug']



# Generated at 2022-06-23 21:52:41.142566
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text(5) == 'Dans le tas. Mange sur place. On sépare. On reste.' \
                             ' Sur le pouce. Limiter les frais. ' \
                             'Ne pas y aller de main morte.'
    assert Text().text(1) == "Ça fait mal."
    assert Text().text() == ""

# Generated at 2022-06-23 21:52:45.294409
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Language
    t = Text(language=Language.RUSSIAN)
    print('words(): ', t.words(quantity=5))



# Generated at 2022-06-23 21:52:48.705029
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    print("Test Text.hex_color:")
    text = Text()
    for _ in range(10):
        print("\t" + text.hex_color())

# Generated at 2022-06-23 21:52:50.824901
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text()
    txt.quote()
    # Return a random quote

# Generated at 2022-06-23 21:52:52.879150
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    print(result)
    assert type(result) == str


# Generated at 2022-06-23 21:52:56.273066
# Unit test for method color of class Text
def test_Text_color():
    """ Test method color of class Text. """
    x = Text.color()
    assert isinstance(x, str)
    assert len(x) > 0


# Generated at 2022-06-23 21:52:57.735754
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert type(t.text()) is str

# Generated at 2022-06-23 21:53:00.341579
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words'].get('bad')


# Generated at 2022-06-23 21:53:03.153730
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert not word
    assert len(word) > 3


# Generated at 2022-06-23 21:53:05.183925
# Unit test for method word of class Text
def test_Text_word():
    x = Text()
    print(x.word())


# Generated at 2022-06-23 21:53:07.365495
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    res = t.text(quantity=1)
    assert res != ''
    assert type(res) is str


# Generated at 2022-06-23 21:53:09.057830
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    a = Text()
    assert a.rgb_color() == (230, 113, 24)

# Generated at 2022-06-23 21:53:10.757897
# Unit test for method answer of class Text
def test_Text_answer():
    answer = [2, 3, 4, 5, 6]
    assert Text().answer() in answer

# Generated at 2022-06-23 21:53:11.979999
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text('zh')
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-23 21:53:16.567032
# Unit test for method words of class Text
def test_Text_words():
    words = Text().words(5)
    assert words
    assert len(words) == 5
    assert isinstance(words, list)
    assert len(words[0]) > 0

# Generated at 2022-06-23 21:53:23.146949
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print (Text.alphabet())
    #:[u'q', u'W', u'E', u'R', u'T', u'Y', u'U', u'I', u'O', u'P', u'A', u'S', u'D', u'F', u'G', u'H', u'J', u'K', u'L', u'Z', u'X', u'C', u'V', u'B', u'N', u'M']


# Generated at 2022-06-23 21:53:25.392894
# Unit test for method level of class Text
def test_Text_level():
    text_obj = Text()
    level = text_obj.level()
    assert len(level) > 0
    assert type(level) == str


# Generated at 2022-06-23 21:53:28.961815
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alph = t.alphabet()
    assert len(alph[0]) == 2
    assert type(alph[0]) == str
    assert alph[0][0].isupper()
    assert alph[0][1].islower()



# Generated at 2022-06-23 21:53:34.441380
# Unit test for method words of class Text
def test_Text_words():
    """Test words function."""
    t = Text()
    assert len(t.words()) == 5
    assert isinstance(t.words(), list)
    assert isinstance(t.words(quantity=1)[0], str)
    assert t.words(quantity=5) != t.words(quantity=5)


# Generated at 2022-06-23 21:53:37.637418
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    # test
    answer1 = text.answer()
    assert isinstance(answer1, str)
    answer2 = text.answer()
    assert isinstance(answer2, str)
    assert answer1 != answer2


# Generated at 2022-06-23 21:53:43.791281
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    provider = Text()
    assert provider.alphabet() == \
        'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    assert provider.alphabet(lower_case=True) == \
        'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'


# Generated at 2022-06-23 21:53:45.061929
# Unit test for method level of class Text
def test_Text_level():
    assert Text().level() in Text()._data['level']

# Generated at 2022-06-23 21:53:48.009228
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in ['critical', 'fatal', 'dangerous', 'secure']


# Generated at 2022-06-23 21:53:49.834233
# Unit test for method quote of class Text
def test_Text_quote():
    """ Unit test for method quote of class Text. """
    import json

    text = Text()
    assert text.quote() in json.loads(open('mimesis/data/text.json').read())['quotes']


# Generated at 2022-06-23 21:53:52.858735
# Unit test for constructor of class Text
def test_Text():
    """
    Test for constructor of class Text
    :return: None
    """
    t = Text()
    assert t is not None

# Generated at 2022-06-23 21:53:58.106857
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Language
    from mimesis.localization import get_localizer
    localizer = get_localizer(Language.RUSSIAN)
    text = Text.__new__(Text)
    text.random = localizer
    string = text.level()
    assert string in ['риск', 'опасность', 'польза', 'условие']

# Generated at 2022-06-23 21:54:01.305287
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in t._data['level']


# Generated at 2022-06-23 21:54:09.179684
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert type(t.words()) == list
    assert len(t.words()) == 5
    assert type(t.words(1)[0]) == str
    assert type(t.words(2)[0]) == str
    assert len(t.words(1)) == 1
    assert len(t.words(2)) == 2
    assert t.words()[0] in t._data['words']['normal']
    assert t.words()[1] in t._data['words']['normal']
    assert t.words()[2] in t._data['words']['normal']
    assert t.words()[3] in t._data['words']['normal']
    assert t.words()[4] in t._data['words']['normal']

# Generated at 2022-06-23 21:54:10.687924
# Unit test for method answer of class Text
def test_Text_answer():
    test_text = Text()

    for i in range(100):
        result = test_text.answer()
        assert len(result) > 0


# Generated at 2022-06-23 21:54:12.190971
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    w = t.words()
    assert len(w) == 5  # default quantity
    assert type(w) == list


# Generated at 2022-06-23 21:54:13.062714
# Unit test for method text of class Text
def test_Text_text():
    for _ in range(100):
        assert len(Text().text(quantity=100)) > 100


# Generated at 2022-06-23 21:54:14.418737
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    x = Text()
    result = x.alphabet()
    assert len(result) == 27

# Generated at 2022-06-23 21:54:16.637103
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']
    assert isinstance(color, str)


# Generated at 2022-06-23 21:54:20.936615
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']

"""
if __name__ == '__main__':
    t = Text('en')
    print(t.hex_color())
    print(t.hex_color(safe=True))
    print(t.rgb_color())
    print(t.rgb_color(safe=True))
"""

# Generated at 2022-06-23 21:54:30.263772
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text("es")
    assert text.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert text.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'ñ', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

# Unit test

# Generated at 2022-06-23 21:54:31.307815
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-23 21:54:32.732974
# Unit test for method level of class Text
def test_Text_level():
    # Test 2
    t = Text()
    level = t.level()
    assert level in ['low', 'medium', 'high', 'critical', 'danger']


# Generated at 2022-06-23 21:54:35.113901
# Unit test for method answer of class Text
def test_Text_answer():
  text = Text()
  # Test
  assert(text.answer() in ['Yes', 'No', 'Undefined'])


# Generated at 2022-06-23 21:54:42.624786
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from .test import SINGLE_LOCALE
    from .test.fixtures import text_provider

    provider = text_provider(locales=[SINGLE_LOCALE])

    for i in range(100):
        color = provider.rgb_color(safe=True)
        assert isinstance(color, tuple)
        assert isinstance(color[0], int)
        assert isinstance(color[1], int)
        assert isinstance(color[2], int)

# Generated at 2022-06-23 21:54:44.067885
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())



# Generated at 2022-06-23 21:54:45.636063
# Unit test for method word of class Text
def test_Text_word():
    tmp = Text()
    rez = tmp.word()
    print(rez)


# Generated at 2022-06-23 21:54:50.765206
# Unit test for constructor of class Text
def test_Text():
    my_text = Text()

    ##############
    # Attributes #
    ##############
    assert my_text.dataprovider != None
    assert my_text._data != None
    assert my_text._seed != None

    ##################
    # Return methods #
    ##################
    assert my_text.level() != None
    assert my_text.text(quantity = my_text.random.randint(1, 5)) != None
    assert my_text.title() != None
    assert my_text.sentence() != None
    assert my_text.words(quantity = my_text.random.randint(1, 5)) != None
    assert my_text.word() != None
    assert my_text.swear_word() != None
    assert my_text.quote() != None
   

# Generated at 2022-06-23 21:54:53.342717
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text()
    result = x.swear_word()
    assert isinstance(result, str) is True


# Generated at 2022-06-23 21:54:55.556501
# Unit test for method level of class Text
def test_Text_level():
    a = Text()
    for _ in range(32):
        a.level()


# Generated at 2022-06-23 21:54:56.597321
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() != None

# Generated at 2022-06-23 21:55:06.679601
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert len(t.color()) > 0
    assert len(t.hex_color()) > 0
    assert len(t.hex_color(safe=True)) > 0
    assert len(t.rgb_color()) > 0
    assert len(t.rgb_color(safe=True)) > 0
    assert len(t.text()) > 0
    assert len(t.sentence()) > 0
    assert len(t.title()) > 0
    assert len(t.word()) > 0
    assert len(t.words()) > 0
    assert len(t.swear_word()) > 0
    assert len(t.quote()) > 0
    assert len(t.answer()) > 0
    
    t.seed(2)
    assert len(t.color()) > 0

# Generated at 2022-06-23 21:55:09.927374
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    # print(text.sentence())
    assert len(text.sentence()) != 0 and text.sentence().isspace() is False


# Generated at 2022-06-23 21:55:13.785229
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() in [(252, 85, 32),(242, 106, 92),(240, 72, 49),
                                  (192, 62, 42),(227, 93, 41),(219, 44, 28)]

# Generated at 2022-06-23 21:55:15.879564
# Unit test for method word of class Text
def test_Text_word():
    print("Method word of class Text")
    assert Text().word() is not None, "Error in method word of class Text"


# Generated at 2022-06-23 21:55:26.711200
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import Text
    from mimesis.enums import Category
    from settings import CATEGORIES
    from settings import LOCALE_CATEGORIES
    from settings import DEFAULT_LOCALE
    for locale in LOCALE_CATEGORIES[Category.TEXT]:
        t = Text(locale=locale)
        assert t.sentence()
    t = Text(seed=42)
    assert t.sentence() == 'How few of the great minds of the past have been ' \
                           'equally great in the power of accomplishing their ' \
                           'purposes in private life.'
    t = Text(seed=42, locale=DEFAULT_LOCALE)  # English

# Generated at 2022-06-23 21:55:29.630156
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text.data('level')

# Generated at 2022-06-23 21:55:31.511346
# Unit test for method level of class Text
def test_Text_level():
    t = Text(seed=123)
    assert t.level() == "low"


# Generated at 2022-06-23 21:55:34.168762
# Unit test for method level of class Text
def test_Text_level():
    '''
    :return:
    '''
    text = Text()
    assert text.level() in ['critical','danger','important','normal']


# Generated at 2022-06-23 21:55:36.590403
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7 and text.hex_color()[0] == '#'

# Generated at 2022-06-23 21:55:41.682571
# Unit test for method quote of class Text
def test_Text_quote():
    locales = ['en', 'ja', 'ko']
    obj = Text('ja')
    assert obj.quote() in obj._data['quotes']
    assert obj.quote() in obj._data['quotes']
    assert obj.quote() in obj._data['quotes']
    
    obj = Text('ko')
    assert obj.quote() in obj._data['quotes']
    assert obj.quote() in obj._data['quotes']
    assert obj.quote() in obj._data['quotes']


# Generated at 2022-06-23 21:55:44.704116
# Unit test for constructor of class Text
def test_Text():
    """Unit testing for the constructor of class Text"""
    text = Text()
    for _ in range(10):
        assert text.rgb_color()

# Generated at 2022-06-23 21:55:48.146650
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    ans = t.answer()
    print(ans)
    assert ans in t._data['answers']


# Generated at 2022-06-23 21:55:49.822045
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test method sentence of class Text"""
    assert Text().sentence() != ""

# Generated at 2022-06-23 21:55:58.364600
# Unit test for constructor of class Text
def test_Text():
    text = Text('it')
    assert text
    assert text.random.choice(text._data['text']) is not None
    assert text.random.choice(text._data['words']['normal']) is not None
    assert text.random.choice(text._data['level']) is not None
    assert text.random.choice(text._data['answers']) is not None
    assert text.random.choice(text._data['color']) is not None
    assert text.random.choice(text._data['alphabet']['uppercase']) is not None
    assert text.random.choice(text._data['alphabet']['lowercase']) is not None
    assert text.random.choice(text._data['quotes']) is not None
    
if __name__ == "__main__":
    test

# Generated at 2022-06-23 21:55:59.703099
# Unit test for method words of class Text
def test_Text_words():
    words = Text().words()
    assert len(words) == 5

# Generated at 2022-06-23 21:56:01.921930
# Unit test for method words of class Text
def test_Text_words():
    print("------------------")
    print("Text.words")
    print("------------------")
    text = Text()
    assert len(text.words()) == 5


# Generated at 2022-06-23 21:56:03.690666
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() != ""


# Generated at 2022-06-23 21:56:05.272393
# Unit test for method answer of class Text
def test_Text_answer():
    assert len(Text().answer()) > 0


# Generated at 2022-06-23 21:56:07.764434
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test data type for method sentence."""
    t = Text()
    assert isinstance(t.sentence(), str)


# Generated at 2022-06-23 21:56:12.344075
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    hex_color = Text.hex_color
    assert len(hex_color()) == 7
    assert hex_color().startswith('#')
    assert len(hex_color(safe=True)) == 7
    assert hex_color(safe=True).startswith('#')



# Generated at 2022-06-23 21:56:13.270208
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() != ''


# Generated at 2022-06-23 21:56:18.131716
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis import Text
    from random import randint
    from .config import seed_repository

    p = Text(seed=seed_repository)
    for i in range(3):
        text = p.answer()
        assert len(text) >= 0
    for i in range(3):
        text = p.answer()
        assert text in p._data['answers']


# Generated at 2022-06-23 21:56:21.587774
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from mimesis.builtins import Text
    text = Text()
    print(text.rgb_color(safe=True))
    print(text.rgb_color(ColorType.SAFE))


# Generated at 2022-06-23 21:56:24.135211
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert isinstance(level, str)
    assert len(level) != 0


# Generated at 2022-06-23 21:56:26.114141
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert isinstance(t.sentence(), str)



# Generated at 2022-06-23 21:56:31.449721
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    text = Text()
    while True:
        assert isinstance(text.alphabet(), list)
        assert isinstance(text.alphabet(lower_case=True), list)
        assert isinstance(text.alphabet(), list)


# Generated at 2022-06-23 21:56:33.158847
# Unit test for method color of class Text
def test_Text_color():
    text = Text('en')
    color = text.color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:56:34.555326
# Unit test for method words of class Text
def test_Text_words():
    assert isinstance(Text().words(), list)


# Generated at 2022-06-23 21:56:36.886071
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print(text.alphabet(lower_case = True))
    print(text.alphabet(lower_case = False))


# Generated at 2022-06-23 21:56:40.349389
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet(False) == list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert t.alphabet(True) == list('abcdefghijklmnopqrstuvwxyz')


# Generated at 2022-06-23 21:56:43.340535
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # true
    assert Text().hex_color(safe=True) in SAFE_COLORS

    # false
    assert Text().hex_color() not in SAFE_COLORS

# Generated at 2022-06-23 21:56:52.630076
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Style
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.datetime import Datetime

    dt = Datetime('ru', seed='randomseed')

    # Test for english
    t = Text('en', seed='randomseed')
    assert t.text()

    # Test for russian
    t = Text('ru', seed='randomseed')

# Generated at 2022-06-23 21:56:54.997888
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    assert len(alpha) == 26
    assert type(alpha) is list


# Generated at 2022-06-23 21:56:55.738386
# Unit test for constructor of class Text
def test_Text():
    Text().sentence()

# Generated at 2022-06-23 21:56:57.112769
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    text.color()


# Generated at 2022-06-23 21:57:01.317925
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    res1 = text.text(quantity=7)
    res2 = text.text(quantity=2)
    example1 = 'Thank you for the idea. Pretty girl, isn\'t it?. Buy a new computer and get to work. \
    Yes, I know that. You\'re not where you are from. What are you doing there? You never give up, do you?'
    example2 = 'What are you doing there? You never give up, do you?'
    assert res1 == example1
    assert res2 == example2


# Generated at 2022-06-23 21:57:02.195081
# Unit test for method swear_word of class Text
def test_Text_swear_word():

    obj = Text()
    obj.swear_word()

# Generated at 2022-06-23 21:57:04.360497
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Gender
    text = Text(gender=Gender.FEMALE)
    assert text.color() in text._data['color']

# Generated at 2022-06-23 21:57:07.949286
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Languages

    gen = Text(Languages.VIETNAMESE)
    for char in gen.alphabet():
        assert isinstance(char, str)
    for char in gen.alphabet(lower_case=True):
        assert isinstance(char, str)


# Generated at 2022-06-23 21:57:09.995580
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert isinstance(answer, str)
    assert len(answer) > 0


# Generated at 2022-06-23 21:57:11.534598
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) > 0

# Generated at 2022-06-23 21:57:18.145171
# Unit test for method text of class Text
def test_Text_text():
    # simple assert
    from mimesis.builtins import RussiaSpecProvider
    from mimesis import Text
    text = Text(RussiaSpecProvider)
    answer = (text.text())
    assert answer == ('Получатель согласен с условиями нового договора.')


# Generated at 2022-06-23 21:57:20.287052
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    print(t.rgb_color())
    print(t.rgb_color(True))  # Safe


# Generated at 2022-06-23 21:57:24.218431
# Unit test for method title of class Text
def test_Text_title():
    test_object = Text()
    test_list = []
    for i in range(0, 10):
        test_list.append(test_object.title())
    assert test_list[0] in test_list


# Generated at 2022-06-23 21:57:25.716834
# Unit test for method color of class Text
def test_Text_color():
    t = Text(seed=True)
    assert t.color() in t._data['color']


# Generated at 2022-06-23 21:57:27.567788
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    print(text.color())

# Generated at 2022-06-23 21:57:36.131964
# Unit test for constructor of class Text
def test_Text():
	x = Text(seed=433020)
	print(x.alphabet(lower_case=True)) # ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
	print(x.alphabet(lower_case=False)) # ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

# Generated at 2022-06-23 21:57:42.283297
# Unit test for constructor of class Text
def test_Text():
    t = Text('ru')
    assert t.answer() in ['Да', 'Нет']
    print(t.text())
    print(t.words())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.color())
    print(t.quotes())
    print(t.title())
    print(t.level())

# Generated at 2022-06-23 21:57:47.902099
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    text = txt.title()
    print (text)
    print (txt.answer())
    print (txt.swear_word())
    print (txt.color())
    print (txt.hex_color(safe=True))
    print (txt.rgb_color())
    print (txt.rgb_color(safe=True))
    print (txt.word())
    print (txt.words())
    print (txt.quote())
    print (txt.level())

if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-23 21:57:50.499470
# Unit test for method answer of class Text
def test_Text_answer():
    class Test_Class:
        def get_locale(self):
            return 'en'

        def get_seed(self):
            return 'test_seed'

    text_provider = Text(Test_Class())
    answer = text_provider.answer()
    assert answer in text_provider._data['answers']

# Generated at 2022-06-23 21:57:52.359634
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Language

    print("\n")

    print("Testing method level of class Text")

    tr = Text(lang=Language.TR)

    print(tr.level())


# Generated at 2022-06-23 21:57:58.800855
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    test_locales = ['en']
    result0 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
               'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
               'Y', 'Z']
    test_seed = 0
    for test_locale in test_locales:
        text = Text(test_locale, seed=test_seed)
        result1 = text.alphabet()
        assert (result1 == result0)
        result2 = text.alphabet(lower_case=True)

# Generated at 2022-06-23 21:58:08.978173
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    t = Text('en')
    assert len(t.text()) == 257

# Generated at 2022-06-23 21:58:11.226419
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Category
    from mimesis.providers import Text
    t = Text(Category.TEXT)
    print(t.text(2))

# Generated at 2022-06-23 21:58:14.747930
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.typing import RGB

    t = Text()
    rgbs = [t.rgb_color() for i in range(100)]
    for r in rgbs:
        assert isinstance(r, RGB)


# Generated at 2022-06-23 21:58:17.328193
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    rgb = t.rgb_color()
    assert t._hex_to_rgb(t.hex_color()) == rgb
    assert len(rgb) ==3

# Generated at 2022-06-23 21:58:19.401209
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text.random.choice(text._data['text']), str)

# Generated at 2022-06-23 21:58:22.651870
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Locale
    text = Text(locale=Locale.EN)
    t = text.text(3)
    assert t == 'Is it? Or does it? How to ask a question.'

# Generated at 2022-06-23 21:58:26.049967
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    print(text.color())



# Generated at 2022-06-23 21:58:33.495539
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text()
    rbg_color = provider.rgb_color()
    assert len(rbg_color) == 3
    assert isinstance(rbg_color, tuple)
    assert isinstance(rbg_color[0], int)
    assert isinstance(rbg_color[1], int)
    assert isinstance(rbg_color[2], int)
    assert rbg_color[0] <= 255
    assert rbg_color[1] <= 255
    assert rbg_color[2] <= 255


# Generated at 2022-06-23 21:58:35.403667
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    text = Text()
    assert text.title() == 'Строка длиной до 140 символов.'


# Generated at 2022-06-23 21:58:36.682364
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())
    
    

# Generated at 2022-06-23 21:58:38.739181
# Unit test for method title of class Text
def test_Text_title():
    text = Text('en')
    result = text.title()
    print(result)

    # Unit test for method level of class Text

# Generated at 2022-06-23 21:58:50.247910
# Unit test for method text of class Text
def test_Text_text():
    print("Unit test for method text of class Text")
    try:
        text = Text(seed=15)
        assert text.text() == 'Please make sure that your printer is ' \
                              'turned on and connected to your computer.'
        assert text.text() == 'We apologize for any inconvenience.'
        assert text.text() == 'Please call customer support.'
        assert text.text() == 'The power switch is located at the back of ' \
                              'the printer.'
        assert text.text() == 'It would be a good idea to unplug your printer.'
        assert text.text() == 'Make sure that all cables are properly ' \
                              'connected.'
    except AssertionError as error:
        print("Test failed", error)
    except Exception as e:
        print("An unexpected error occurs:", e)

# Unit

# Generated at 2022-06-23 21:58:53.257136
# Unit test for method quote of class Text
def test_Text_quote():
    """Test for method quote of class Text."""
    from pprint import pprint
    quote = Text().quote()
    pprint(quote)
    assert True


# Generated at 2022-06-23 21:58:57.956711
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import DataFields

    text = Text()

    l = text.level()
    assert isinstance(l, str) == True
    assert len(l) > 0

    text = Text(language='en')
    l = text.level()
    assert isinstance(l, str) == True
    assert len(l) > 0


# Generated at 2022-06-23 21:58:59.625222
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text(locale='en')
    result = provider.rgb_color()
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert isinstance(result[0], int)

# Generated at 2022-06-23 21:59:00.708447
# Unit test for constructor of class Text
def test_Text():
    tt = Text()
    tt.color()

# Generated at 2022-06-23 21:59:05.692513
# Unit test for method level of class Text
def test_Text_level():
    """Тест на безопасность выходных данных функции level."""
    test_object = Text('ru')
    test_object.level()
    assert(test_object.level() in test_object._data['level'])


# Generated at 2022-06-23 21:59:11.556356
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    obj = Text()
    result = obj.hex_color()
    assert len(result) == 7
    assert result[1] == '0'
    assert result[2] == '0'
    assert result[3] == 'f'
    assert result[4] == 'f'
    assert result[5] == 'f'
    assert result[6] == 'f'


# Generated at 2022-06-23 21:59:13.457462
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text(seed=123456)
    ans = t.answer()
    assert ans == 'No'


# Generated at 2022-06-23 21:59:16.680088
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text as T
    t = T('en')
    words_list = []
    for _ in range(100):
        words_list.append(t.word())
    print(words_list)


# Generated at 2022-06-23 21:59:20.898535
# Unit test for constructor of class Text
def test_Text():
    o = Text()
    r1 = o.hex_color()
    assert len(r1) == 7
    r2 = o.rgb_color()
    assert len(r2) == 3
    r3 = o.color()
    assert r3 in ['Black', 'Red', 'Blue', 'Yellow', 'Green', 'White']

# Generated at 2022-06-23 21:59:21.743981
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text()
    assert provider.quote()

# Generated at 2022-06-23 21:59:28.039633
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    # Check that the class initializes correctly
    assert text.__class__.__name__ == "Text"

    # Check that when called, the output has the correct length
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=False)) == 26
    assert len(text.alphabet(lower_case=True)) == 26

    assert text.level() in ['critical', 'high', 'medium', 'low', 'normal',
                            'notice', 'warning']


# Generated at 2022-06-23 21:59:29.924193
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance (text.words, list)

# Generated at 2022-06-23 21:59:31.973662
# Unit test for method words of class Text
def test_Text_words():
    txt = Text()
    for _ in range(10):
        assert isinstance(txt.words(), list)


# Generated at 2022-06-23 21:59:33.515333
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word1 = text.word()
    assert word1
    assert isinstance(word1, str)

# Generated at 2022-06-23 21:59:35.406347
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test sentence."""
    s = Text()
    assert (s.sentence() in s._data[s.Meta.name]["text"])


# Generated at 2022-06-23 21:59:37.939920
# Unit test for method title of class Text
def test_Text_title():
    t = Text(seed=123456789)
    assert t.title() == 'About some text for tests'


# Generated at 2022-06-23 21:59:40.429837
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == t.hex_color()
    assert len(t.hex_color()) == 7
    assert t.hex_color().startswith('#')

# Generated at 2022-06-23 21:59:42.769063
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color,str)


# Generated at 2022-06-23 21:59:45.224294
# Unit test for method level of class Text
def test_Text_level():
    obj = Text()
    result = obj.level()
    assert result


# Generated at 2022-06-23 21:59:51.277692
# Unit test for constructor of class Text
def test_Text():
    t = Text('en')
    # assert t.sentence() != t.sentence()
    assert t.level() in ['critical', 'important', 'normal', 'not important']
    assert len(t.words()) == 5
    assert len(t.word()) > 1
    assert t.quote() != t.quote()
    assert len(t.hex_color()) == 7
    assert len(t.rgb_color()) == 3
    assert t.answer() in ['yes', 'no', 'maybe']

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 22:00:00.284959
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.text import Text

    c = Text('en', seed=987654321)
    assert c.word() == "Science"
    assert c.word() == "Science"
    assert c.word() == "Science"
    assert c.word() == "Service"
    assert c.word() == "Huge"
    assert c.word() == "Market"
    assert c.word() == "Power"
    assert c.word() == "Thought"
    assert c.word() == "Riot"
    assert c.word() == "Wiredly"
    assert c.word() == "Over"
    assert c.word() == "Composed"

# Generated at 2022-06-23 22:00:03.394209
# Unit test for method text of class Text
def test_Text_text():
    t1 = Text()
    if t1.text(quantity=20) == None:
        print("An exception has been thrown")

# Generated at 2022-06-23 22:00:05.970406
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert callable(text.answer)
    assert isinstance(text.answer(), str)
    assert text.answer() != text.answer()


# Generated at 2022-06-23 22:00:11.599967
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """
    Test for method hex_color of class Text.
    """
    from mimesis.enums import SupportLanguages
    from mimesis.providers.text import Text
    from mimesis.data import SAFE_COLORS

    text = Text("en")
    text.hex_color()

    for color in SAFE_COLORS:
        assert color in text.hex_color(safe=True)

# Generated at 2022-06-23 22:00:16.772897
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print("***** In function test_Text_alphabet *****")
    print('Test 1 in function test_Text_alphabet : ')
    alphabet_1 = Text.alphabet(lower_case=False)
    for i in range(len(alphabet_1)):
        print(alphabet_1[i])


# Generated at 2022-06-23 22:00:22.323670
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    for _ in range(100):
        x = Text()
        alpha_1 = x.alphabet()
        alpha_2 = x.alphabet(lower_case=True)
        assert type(alpha_1) is list
        assert type(alpha_2) is list
        for s in alpha_1:
            assert len(s) == 1
        for s in alpha_2:
            assert len(s) == 1
        

# Generated at 2022-06-23 22:00:24.536196
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.builtins import Text
    txt = Text()
    result = txt.level()
    assert result in ('critical', 'low', 'high')


# Generated at 2022-06-23 22:00:25.608990
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert isinstance(t.swear_word(), str) is True

# Generated at 2022-06-23 22:00:28.656963
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    text = Text(locale=Locale.RUSSIAN)
    assert text.title() == 'Вот и мой неважный делец' or 'И даже изредка'

# Generated at 2022-06-23 22:00:33.102056
# Unit test for method color of class Text
def test_Text_color():
    t = Text(locale='en')
    for _ in range(10):
        color = t.color()
        assert color is not None
        assert type(color) == str
        assert len(color) > 1


# Generated at 2022-06-23 22:00:35.913474
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Locale

    text = Text(Locale.EN)
    answer = text.answer()
    assert answer in {'No', 'Yes'}


# Generated at 2022-06-23 22:00:41.732561
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.providers.text import Text
    from mimesis.i18n import LOCALES
    from mimesis.enums import Gender

    print(Text('ru').sentence())
    print(Text('en').sentence())
    print(Text('ru').sentence())
    print(Text('en').sentence())

    for locale in LOCALES['text']:
        print(locale)
        print(Text(locale).sentence())



# Generated at 2022-06-23 22:00:43.329491
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    u = Text()
    print(u.swear_word())


# Generated at 2022-06-23 22:00:44.975846
# Unit test for method color of class Text
def test_Text_color():
    for i in range(0,10):
        color = Text()
        print(color.color())


# Generated at 2022-06-23 22:00:46.677262
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-23 22:00:52.248949
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Тестирование длины списка возвращаемого методом rgb_color.

    :return: Нет
    :rtype: Нет
    """
    from mimesis import Text
    text = Text()
    a = text.rgb_color()
    len(a)

# Generated at 2022-06-23 22:00:55.669475
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    assert result in ['critical', 'normal', 'low', 'high']



# Generated at 2022-06-23 22:00:59.290931
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    hex_color = t.hex_color()
    assert len(hex_color) == 7
    for i in hex_color[1:]:
        assert i in t.alphabet(True)



# Generated at 2022-06-23 22:01:07.122566
# Unit test for constructor of class Text
def test_Text():
    from mimesis.builtins.en_US.text import Text
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y',
        'Z']

# Generated at 2022-06-23 22:01:08.073310
# Unit test for method text of class Text
def test_Text_text():
    assert len(Text().text()) == 5

# Generated at 2022-06-23 22:01:11.464796
# Unit test for method words of class Text
def test_Text_words():
    print("-- test_Text_words --")
    # Initialize Provider
    text = Text()
    # Generate list of the random words
    result = text.words(quantity=2)
    print(result)
    # Check length
    assert len(result) == 2


# Generated at 2022-06-23 22:01:12.519960
# Unit test for constructor of class Text
def test_Text():
    text = Text(seed=123)
    print(text)

# Generated at 2022-06-23 22:01:14.523635
# Unit test for method title of class Text
def test_Text_title():
    locale = 'ru'
    provider = Text(locale=locale)
    result = provider.title()
    assert result is not None


# Generated at 2022-06-23 22:01:18.302328
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Return this text.

    Random text.

    :return:
    """
    t = Text('en')
    text = t.sentence()
    assert isinstance(text, str)
    assert len(text) > 1

# Generated at 2022-06-23 22:01:20.442134
# Unit test for method level of class Text
def test_Text_level():
    """Test level of class Text."""
    t = Text()
    assert t.level() in ['critical', 'danger', 'normal', 'warning']

# Generated at 2022-06-23 22:01:28.097363
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of class Text."""
    import sys
    sys.path.insert(0, '..')
    from lib import bin
    from lib import lib
    import random
    import pytest
    text = Text('ru')
    text.random.seed(2)
    random.seed(2)

    for _ in range(100):
        text_data = text.text()

        assert isinstance(text_data, str)

        import re
        regex = r'(^[А-ЯЁ][а-яё,\-\.\s]+[\.\!\?])|(^[А-ЯЁ][а-яё,\-\.\s]+[\.\!\?] $)'
        assert re.findall(regex, text_data)
