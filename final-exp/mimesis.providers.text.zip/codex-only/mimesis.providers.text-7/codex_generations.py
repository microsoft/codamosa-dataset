

# Generated at 2022-06-23 21:51:37.348298
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    import os, sys
    dirname = os.path.dirname(__file__)
    sys.path.append(os.path.join(dirname, '..'))
    from mimesis.enums import Color
    from mimesis.exceptions import NonEnumerableError
    t = Text()
    safe = True
    for i in range(0, 97):
        print(t.rgb_color(safe))

    safe = False
    for i in range(0, 94):
        print(t.rgb_color(safe))
    
    try: 
        print(t.rgb_color(1))
    except NonEnumerableError:
        print('Exception Caught!')

# Generated at 2022-06-23 21:51:41.618275
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Locale
    from mimesis.localization import get_localizer
    from mimesis.text import Text
    localizer = get_localizer(Locale.RU)
    text = Text(localizer=localizer)
    data = text.answer()
    assert data in localizer._data['text']['answers']


# Generated at 2022-06-23 21:51:52.544886
# Unit test for constructor of class Text
def test_Text():
    assert isinstance(Text().text(), str)
    assert Text().text(3) != Text().title()
    assert isinstance(Text().sentence(), str)
    assert Text().sentence().endswith('.')
    assert isinstance(Text().words(), list)
    assert isinstance(Text().words(5), list)
    assert len(Text().words(10)) == 10
    assert isinstance(Text().word(), str)
    assert isinstance(Text().alphabet(), list)
    assert isinstance(Text().alphabet(True), list)
    assert isinstance(Text().alphabet(False), list)
    assert len(Text().alphabet()) == len(Text().alphabet(True))
    assert len(Text().alphabet()) == len(Text().alphabet(False))
    assert isinstance(Text().answer(), str)


# Generated at 2022-06-23 21:51:54.630921
# Unit test for method words of class Text
def test_Text_words():
    t = Text()

    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-23 21:52:05.383979
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.providers.text import Text
    from mimesis.builtins.text import Text as Text_language
    from mimesis.builtins.en import English
    import random

    class seeder(object):
        def __init__(self, seed):
            self.seed = seed
            self.mim = Text

    mim = Text()
    mim_ru = Text_language('ru')
    mim_en = English()

    mim.random = random.Random(1)
    mim_ru.random = mim.random
    mim_en.random = mim.random

    mim_ru.words(3)
    mim_en.words(3)
    mim_ru.words(3, seed=1)
    mim_en.words(3, seed=1)

# Generated at 2022-06-23 21:52:08.510782
# Unit test for method level of class Text
def test_Text_level():
    level_list = ['critical', 'high', 'mid', 'low']
    text = Text()
    level = text.level()
    assert (level in level_list)


# Generated at 2022-06-23 21:52:11.310463
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in (t._data['color'])


# Generated at 2022-06-23 21:52:14.005042
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Languages

    text = Text(Languages.EN)
    alphabet = text.alphabet()
    print(alphabet)


# Generated at 2022-06-23 21:52:15.299674
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert('damn' == Text().swear_word())

# Generated at 2022-06-23 21:52:19.889017
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Run unit test for method swear_word of class Text."""
    # Create the text class
    text = Text()
    assert text.swear_word() is not None

# This is a unit test for the method hex_color of class Text

# Generated at 2022-06-23 21:52:21.229436
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']

# Generated at 2022-06-23 21:52:23.041078
# Unit test for method word of class Text
def test_Text_word():
    provider = Text(seed=1)
    sentence = provider.word()
    assert sentence != None
    assert type(sentence) == str
    assert len(sentence) != 0
    assert len(sentence) >= 2


# Generated at 2022-06-23 21:52:30.544103
# Unit test for constructor of class Text
def test_Text():
    import unittest
    import json

    class Test(unittest.TestCase):
        def setUp(self):
            self.obj = Text()

        def test_data_file(self):
            self.assertEqual(self.obj._datafile, 'text.json')

        def test_load_datafile(self):
            with open(self.obj._datafile, 'r', encoding='utf-8') as f:
                loaded_data = json.load(f)
            self.assertEqual(loaded_data, self.obj._data)

    unittest.main(module=__name__, verbosity=3)

# Generated at 2022-06-23 21:52:34.371818
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == "#edb900" or t.hex_color() == '#f6cc0a' or t.hex_color() == '#f6d867' or t.hex_color() == '#f6ebb3'


# Generated at 2022-06-23 21:52:35.778346
# Unit test for method word of class Text
def test_Text_word():
    t=Text(seed=13)
    assert t.word() == "laboris"

# Generated at 2022-06-23 21:52:45.331257
# Unit test for method word of class Text
def test_Text_word():
    # Text.word()

    t = Text()
    w = t.word()

# Generated at 2022-06-23 21:52:47.609041
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text"""
    # Initialization with parameters
    test_class_object = Text(seed=42)
    # Call method
    test_output = test_class_object.swear_word()
    # Check result
    assert test_output == "Crap"


# Generated at 2022-06-23 21:52:48.649747
# Unit test for method word of class Text
def test_Text_word():
    Text().word() == "science"

# Generated at 2022-06-23 21:52:52.208763
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Speciality
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.number import Number

    number = Number(seed=0)
    rus = RussiaSpecProvider(seed=0)
    answer = rus.answer()
    assert answer == 'Нет'
    answer = rus.answer()
    assert answer == 'Да'
    answer = rus.answer()
    assert answer == 'Нет'

# Generated at 2022-06-23 21:52:58.438514
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import Color

    t = Text()
    color = t.hex_color(safe=True)
    color_code = color[1:]

    assert len(color) == 7
    assert color[0] == '#'
    assert color_code.isalnum()

    for c in Color:
        # Ensure all Flat UI colors are present in the list
        assert c.value in SAFE_COLORS

# Generated at 2022-06-23 21:53:00.709941
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test method alphabet of class Text."""
    assert Text().alphabet() == Text().alphabet()


# Generated at 2022-06-23 21:53:07.905609
# Unit test for method text of class Text
def test_Text_text():
    # Use Text class
    t = Text()

    # Test text method
    for i in range(20):
        # Generate text
        text = t.text()
        # Define regex to match sentences
        regex = r"^[A-Z][^\.!?]*[\.!?]$"
        # Match text with regex
        matches = t.matches(regex, text)
        # Check if number of sentences is equal 5 (default)
        assert len(matches) == 5


# Generated at 2022-06-23 21:53:09.223492
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    b = '#'
    for i in range(30):
        assert t.hex_color().startswith(b)
        assert len(t.hex_color()) == 7


# Generated at 2022-06-23 21:53:11.230744
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    rgb = t.rgb_color()
    assert rgb == (252, 85, 32)


# Generated at 2022-06-23 21:53:12.706641
# Unit test for method words of class Text
def test_Text_words():
    txt = Text()
    res = txt.words()
    assert len(res) == 5



# Generated at 2022-06-23 21:53:17.473539
# Unit test for method words of class Text
def test_Text_words():
    test = Text()
    words = test.words()
    assert len(words) == 5
    assert isinstance(words, list)
    assert isinstance(words[0], str)



# Generated at 2022-06-23 21:53:21.867487
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
   t = Text()
   for i in range(100000): # Test for 100000 times
       rgb = t.rgb_color()
       assert isinstance(rgb, tuple), "not a tuple"
       for i in rgb:
           assert i >= 0 and i <= 255, "out of range"


# Generated at 2022-06-23 21:53:24.554412
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    for i in range(10):
        answer = t.answer()
        assert isinstance(answer, str)
        assert len(answer) > 0


# Generated at 2022-06-23 21:53:26.150144
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import Text
    t = Text('ja')
    word = t.color()
    assert len(word)>0



# Generated at 2022-06-23 21:53:31.367557
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Create object of class Text
    t = Text(seed=123)
    # Get a safe color from Flat UI colors
    color = t.hex_color(safe=True)
    # Should be equal:
    # '#1abc9c'
    assert color == '#1abc9c'
    # Get a random color
    color = t.hex_color()
    # Should be equal:
    # '#a5d1b5'
    assert color == '#a5d1b5'


# Generated at 2022-06-23 21:53:33.331879
# Unit test for method title of class Text
def test_Text_title():
    text = Text('ru')
    text.title()


# Generated at 2022-06-23 21:53:35.151497
# Unit test for method answer of class Text
def test_Text_answer():
    txt = Text()
    assert txt.answer() in ['Yes', 'No']
    

# Generated at 2022-06-23 21:53:36.892741
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    print(title)



# Generated at 2022-06-23 21:53:40.884235
# Unit test for method color of class Text
def test_Text_color():
    """Test method color of class Text.

    Return:
        [str] -- [string is random color of tuple in Text]

    """
    a = Text()
    ans = a.color()
    return ans

if __name__ == '__main__':
    text = Text()
    a = text.color()
    print(a)

# Generated at 2022-06-23 21:53:42.532845
# Unit test for method text of class Text
def test_Text_text():
    provider = Text()
    text = provider.text()
    assert text != ""
    assert isinstance(text, str)


# Generated at 2022-06-23 21:53:44.436090
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    result = t.title()
    assert isinstance(result, str)
    assert len(result)


# Generated at 2022-06-23 21:53:46.356035
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    if t.answer() != "Ne":
        raise Exception()

# Generated at 2022-06-23 21:53:47.802353
# Unit test for method text of class Text
def test_Text_text():
    from mimesis import Text
    txt = Text()
    text = txt.text()
    assert text
    assert len(text) > 1
 

# Generated at 2022-06-23 21:53:48.955567
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print(Text('en').swear_word())

# Generated at 2022-06-23 21:53:54.943557
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import Text
    t = Text()
    t.color()
    t.color()
    t.color()
    t.color()
    t.color()
    t.color()
    t.color()
    t.color()
    print(t.color())

if __name__ == '__main__':
    test_Text_color()

# Generated at 2022-06-23 21:54:00.436590
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(seed='seed')
    #print(text.alphabet(lower_case=True))
    #print(text.alphabet())
    # print(text.level())
    #print(text.text())
    #print(text.sentence())
    #print(text.words())
    #print(text.word())
    #print(text.swear_word())
    #print(text.quote())
    #print(text.color())
    #print(text.hex_color())
    #print(text.rgb_color())
    print(text.answer())

# Generated at 2022-06-23 21:54:03.080359
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    p = t.text()
    assert isinstance(p, str)
    print(p)


# Generated at 2022-06-23 21:54:05.281183
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    text = Text()
    color = text.hex_color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:54:08.367103
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert type(text.quote()) == type('')


# Generated at 2022-06-23 21:54:10.353766
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    result = t.alphabet()
    assert isinstance(result, list)


# Generated at 2022-06-23 21:54:18.870689
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert isinstance(t.rgb_color(), tuple)
    assert len(t.rgb_color()) == 3
    assert isinstance(t.rgb_color()[0], int)
    assert isinstance(t.rgb_color()[1], int)
    assert isinstance(t.rgb_color()[2], int)
    assert t.rgb_color()[0] == t.rgb_color()[1]
    assert t.rgb_color()[0] == t.rgb_color()[2]
    assert t.rgb_color(safe=True)[0] == t.rgb_color()[1]
    assert t.rgb_color(safe=True)[0] == t.rgb_color()[2]
    assert t.rgb_color

# Generated at 2022-06-23 21:54:22.917483
# Unit test for method title of class Text
def test_Text_title():
    t=Text(seed=12)
    assert t.title() == "People like you will always let you down"
    assert t.title() == "A lack of planning on your part does not constitute an emergency on my part"


# Generated at 2022-06-23 21:54:24.465412
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-23 21:54:26.934397
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    tmp = Text()
    tmp_1 = tmp.rgb_color(True)
    print(tmp_1)
    print(tmp.hex_color(True))


# Generated at 2022-06-23 21:54:29.652613
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    text = Text(gender=Gender.FEMALE)
    title = text.title()
    assert title is not None


# Generated at 2022-06-23 21:54:30.622710
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=47)
    assert text.level() == 'critical'

# Generated at 2022-06-23 21:54:32.560901
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    t = text.words(quantity=3)
    assert t in (['science', 'network', 'god'], ['network', 'science', 'god']), "Wrong answer"


# Generated at 2022-06-23 21:54:34.940727
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color(True))
    print(t.hex_color(False))


# Generated at 2022-06-23 21:54:37.097219
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    obj = Text()
    assert len(obj.hex_color()) == 7


# Generated at 2022-06-23 21:54:42.668329
# Unit test for method answer of class Text
def test_Text_answer():
    '''
    Unit test for method answer of class Text

    Returns:
        None.
    '''
    from mimesis.enums import Language
    text = Text(language=Language.VIETNAMESE)
    print("\n-- test_Text_answer")
    print("text.answer(): {}".format(text.answer()))


# Generated at 2022-06-23 21:54:43.785217
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() == 'Bitch'

# Generated at 2022-06-23 21:54:44.963731
# Unit test for constructor of class Text
def test_Text():
        text = Text()
        print(text._data)

# Generated at 2022-06-23 21:54:48.677860
# Unit test for method word of class Text
def test_Text_word():
    """Test word."""
    from mimesis.builtins import Text
    t = Text()
    word = t.word()
    assert isinstance(word, str)
    assert len(word) >= 1
    assert word[0].isalpha()
    assert word[0].isupper()


# Generated at 2022-06-23 21:54:50.312767
# Unit test for method color of class Text
def test_Text_color():
    # Given
    text = Text('en')

    # When
    result = text.color()

    # Then
    assert result


# Generated at 2022-06-23 21:54:52.960484
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    results = t.words()

    assert len(results) == 5


# Generated at 2022-06-23 21:54:55.832110
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    a = text.sentence()
    print(a)
    assert a != None, 'Text_sentence Failed!'


# Generated at 2022-06-23 21:54:57.401972
# Unit test for method answer of class Text
def test_Text_answer():
    """Test for Text().answer()"""
    a = Text(seed=4123).answer()
    assert a == 'Ja'


# Generated at 2022-06-23 21:55:01.224299
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # Initialization of the class
    t = Text()
    # Generate a Latin alphabet
    print(t.alphabet())
    # Generate a Cyrillic alphabet
    print(t.alphabet(lower_case=True))


# Generated at 2022-06-23 21:55:03.545101
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.seed is not None
    assert text._data is not None
    assert text.provider is not None


# Generated at 2022-06-23 21:55:07.630644
# Unit test for method hex_color of class Text
def test_Text_hex_color():

    from pprint import pprint

    # Create an instance of class Text
    t = Text()
    result = t.hex_color()

    print("hex_color: " + result)
    assert len(result) == 7

    # Print result and original dict
    pprint(result)

# Generated at 2022-06-23 21:55:08.260465
# Unit test for method level of class Text
def test_Text_level():
    print(Text().level())


# Generated at 2022-06-23 21:55:13.011315
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Test without parameter safe - get random RGB tuple
    text = Text(seed=1)
    result = text.rgb_color()
    assert result == (61, 184, 46)

    # Test with parameter safe - get random RGB tuple from safe colors
    text = Text(seed=1)
    result = text.rgb_color(safe=True)
    assert result == (252, 85, 32)

# Generated at 2022-06-23 21:55:20.078477
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person

    person1 = Person('de')
    person2 = Person('de')
    t = Text('de')

    for i in range(100):
        p1 = person1.full_name(Gender.FEMALE)
        p2 = person2.full_name(Gender.MALE)
        print('{} - {}: {}'.format(p1, p2, t.quote()))


# Generated at 2022-06-23 21:55:21.599582
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=123)
    assert text.level() == 'critical'


# Generated at 2022-06-23 21:55:22.799811
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    print(t.hex_color())



# Generated at 2022-06-23 21:55:29.281822
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    from mimesis.localization import DEFAULT_LOCALE, LOCALE_SCHEMA

    l = DEFAULT_LOCALE
    r = LOCALE_SCHEMA[l]

    dp = Text(l)
    c = dp.color()

    assert c in r['text']['color']


# Generated at 2022-06-23 21:55:32.139591
# Unit test for method level of class Text
def test_Text_level():
    # Unit test for method level of class Text
    t = Text()
    assert t.level() in ('critical', 'low', 'high', 'medium')


# Generated at 2022-06-23 21:55:33.387034
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t._datafile == 'text.json'
    assert t.Meta.name == 'text'


# Generated at 2022-06-23 21:55:34.919793
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    list_words = text.words()
    print(list_words)


if __name__ == '__main__':
    test_Text_words()

# Generated at 2022-06-23 21:55:37.603965
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    import mimesis
    text = mimesis.Text()
    color = text.rgb_color()
    assert(type(color) == tuple)


# Generated at 2022-06-23 21:55:40.660593
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text(seed=0)
    assert t.swear_word() == 'Ass'

# Generated at 2022-06-23 21:55:43.182387
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    result = text.text()
    print(result)


# Generated at 2022-06-23 21:55:47.244001
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color."""
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color



# Generated at 2022-06-23 21:55:49.243208
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3

# Generated at 2022-06-23 21:55:52.943991
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text("en")
    # Generates a random quote
    print(text.quote())
    # Generates a random quote
    print(text.quote())
    # Generates a random quote
    print(text.quote())


# Generated at 2022-06-23 21:55:54.754782
# Unit test for method sentence of class Text
def test_Text_sentence():
	b = Text()
	print(b.sentence())

# unit test for method title of class Text

# Generated at 2022-06-23 21:55:56.294535
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) > 0


# Generated at 2022-06-23 21:56:03.944798
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.file_path, str)
    assert isinstance(text.words(quantity=5), list)
    assert isinstance(text.color(), str)
    assert isinstance(text.hex_color(safe=True), str)
    assert isinstance(text.hex_color(safe=False), str)
    assert isinstance(text.rgb_color(safe=True), tuple)
    assert isinstance(text.rgb_color(safe=False), tuple)
    assert isinstance(text.answer(), str)
    assert isinstance(text.level(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.swear_word(), str)
    assert isinstance(text.text(), str)


# Generated at 2022-06-23 21:56:06.012567
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text('en')
    assert t.quote() in t._data['quotes']


# Generated at 2022-06-23 21:56:07.591458
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())


# Generated at 2022-06-23 21:56:11.352603
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test that method rgb_color of class Text doesn't return the same color. """
    first_color = Text().rgb_color()
    second_color = Text().rgb_color()
    assert first_color != second_color

# Generated at 2022-06-23 21:56:20.113058
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ['No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','No','Yes','Yes','Yes','Yes','Yes','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe','Maybe'], "random value"

# Generated at 2022-06-23 21:56:21.009470
# Unit test for method answer of class Text
def test_Text_answer():
    return None

# Generated at 2022-06-23 21:56:28.401655
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    print(x.alphabet())
    print()

    for i in range(5):
        print(x.level())
    print()

    for i in range(5):
        print(x.text())
    print()

    for i in range(5):
        print(x.sentence())
    print()

    for i in range(5):
        print(x.title())
    print()

    for i in range(5):
        print(x.words())
    print()

    for i in range(5):
        print(x.word())
    print()

    for i in range(5):
        print(x.swear_word())
    print()

    for i in range(5):
        print(x.quote())
    print()


# Generated at 2022-06-23 21:56:37.849643
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=1)

    class_name = str(text).split(' ')[0].split('.')[-1]
    method_name = sys._getframe().f_code.co_name

    result = text.text()
    assert result == "The world of day and night, light and darkness is the world of the spirit.\
                    So, what can we do to help the victim, tackle the offence?\
                    I think if you're going to use that line, you need to come up with a better excuse.\
                    I don't like to repeat myself, but your behavior is unacceptable.\
                    So, where are you calling from, exactly? I'm in a bit of a rush."

    print('{}.{} OK!'.format(class_name, method_name))


# Generated at 2022-06-23 21:56:40.247567
# Unit test for method text of class Text
def test_Text_text():
    textObj = Text('en')
    result = textObj.text()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:56:51.130457
# Unit test for constructor of class Text
def test_Text():
    assert Text()

    assert Text(seed=123456789)

    assert Text(locale='en')

    # Test the alphabet getter
    text_provider = Text()
    alphabets = text_provider.alphabet()
    uppercase_length = len(text_provider.alphabet(lower_case=False))

    assert uppercase_length > 0

    lowercase_length = len(text_provider.alphabet(lower_case=True))

    assert alphabets != text_provider.alphabet()

    assert uppercase_length == lowercase_length

    # Test the level getter
    levels = text_provider.level()
    assert levels

    # Test the text getter
    text = text_provider.text()
    assert text

    # Test the sentence getter


# Generated at 2022-06-23 21:56:53.214547
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    test_word = t.word()
    assert test_word is not None

# Generated at 2022-06-23 21:56:59.026696
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.builtins import Text
    from string import ascii_lowercase
    from string import ascii_uppercase

    # Test for getting lowercase letters alphabet
    for level in Text.level():
        assert level in ascii_lowercase

    # Test for getting uppercase letters alphabet
    for level in Text.level(lower_case=False):
        assert level in ascii_uppercase



# Generated at 2022-06-23 21:57:00.002924
# Unit test for method title of class Text
def test_Text_title():
    print(Text().title())


# Generated at 2022-06-23 21:57:01.268658
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert len(t.answer())>0

# Generated at 2022-06-23 21:57:09.306450
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    import os
    file_path = './mimesis/tests/data/hex_color.json'
    # Read data from file, if exists
    if os.path.isfile(file_path):
        with open(file_path, 'r') as file:
            data = file.read().strip().split(os.linesep)
    else:
        data = None
    # Generate hex color
    t = Text()
    if data is None:
        data = []
        for _ in range(10):
            data.append(t.hex_color())
        with open(file_path, 'w') as file:
            file.write(os.linesep.join(data))
    else:
        for hex_color in data:
            assert(t.hex_color() == hex_color)

# Unit test

# Generated at 2022-06-23 21:57:11.642015
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text
    c = Text('en')
    c.word()
    print(c.word())
test_Text_word()

# Generated at 2022-06-23 21:57:13.897869
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    words = text.words()
    assert words, "Words is empty"
    assert isinstance(words, list), "Words is not a list"
    assert all(isinstance(s, str) for s in words), "Words is not a string"


# Generated at 2022-06-23 21:57:15.850806
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    word = text.word()
    word_val = True in [word in text.words() for _ in range(100)]
    assert word_val

# Generated at 2022-06-23 21:57:17.025226
# Unit test for method color of class Text
def test_Text_color():
    for x in range(100):
        assert isinstance(Text().color(), str)


# Generated at 2022-06-23 21:57:21.133252
# Unit test for method answer of class Text
def test_Text_answer():
    locale = 'en'
    seed = None
    text = Text(locale=locale, seed=seed)
    result = text.answer()
    if result in text._data['answers']:
        print(text.answer())
        assert type(text.answer()) == str
    else:
        assert False

# Generated at 2022-06-23 21:57:24.589319
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for color method of class Text"""
    _text = Text()
    _color = _text.color()
    assert isinstance(_color, str)
    assert len(_color) > 0


# Generated at 2022-06-23 21:57:26.050159
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert isinstance(t.alphabet(), list)



# Generated at 2022-06-23 21:57:27.462723
# Unit test for method text of class Text
def test_Text_text():
    text = Text('en')
    txt = text.text()
    assert (txt != None)


# Generated at 2022-06-23 21:57:28.446776
# Unit test for method color of class Text
def test_Text_color():
    print(Text().color())

# Generated at 2022-06-23 21:57:29.976137
# Unit test for constructor of class Text
def test_Text():
    assert Text().text() != Text().text()

# Generated at 2022-06-23 21:57:32.824194
# Unit test for method text of class Text
def test_Text_text():
    # Setup
    t = Text(seed=42)

    # Exercise and verify
    assert(t.text() == 'Mr. Bond, they have a saying in Chicago:...')


# Generated at 2022-06-23 21:57:38.155188
# Unit test for method sentence of class Text
def test_Text_sentence():
    text=Text()
    res1=text.sentence()
    print('第一个单词是'+res1)
    res2=text.sentence()
    print('第二个单词是'+res2)


# Generated at 2022-06-23 21:57:38.897958
# Unit test for method title of class Text
def test_Text_title():
    obj = Text()
    obj.title()
    

# Generated at 2022-06-23 21:57:43.058512
# Unit test for method text of class Text
def test_Text_text():
    """Тест для метода text класса Text."""
    t = Text()
    text = t.text()
    assert isinstance(text, str)
    assert len(text) != 0


# Generated at 2022-06-23 21:57:44.946608
# Unit test for method quote of class Text
def test_Text_quote():
    obj = Text()
    result = obj.quote()
    assert result == 'Bond... James Bond.'

# Generated at 2022-06-23 21:57:47.697873
# Unit test for method sentence of class Text
def test_Text_sentence():
    locale = 'en'
    seed = 'some_seed'
    text = Text(locale, seed)
    assert isinstance(text.sentence(), str)


# Generated at 2022-06-23 21:57:51.110909
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text('es')
    for i in range(100):
        output_text_rgb_color = provider.rgb_color(safe=False)
        assert output_text_rgb_color
        assert isinstance(output_text_rgb_color, tuple)
        assert len(output_text_rgb_color) == 3
        assert isinstance(output_text_rgb_color[0], int) == int


# Generated at 2022-06-23 21:57:54.974077
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_provider = Text()
    sentence = text_provider.sentence()
    assert isinstance(sentence, str)
if __name__ == '__main__':
    test_Text_sentence()

# Generated at 2022-06-23 21:57:58.020447
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    res = text.text()
    assert (isinstance(res, str))
    assert (len(res) > 0)

# Generated at 2022-06-23 21:58:01.314957
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text
    assert text.random.choice(['a', 'b']) in ['a', 'b']
    assert text.level() in text._data.get('level')


# Generated at 2022-06-23 21:58:02.859837
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    t.level()


# Generated at 2022-06-23 21:58:04.464642
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert ',' in t.sentence() and '.' in t.sentence()

# Generated at 2022-06-23 21:58:07.498105
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    assert len(Text().words()) == 5
    assert len(Text().words(quantity=3)) == 3

# Generated at 2022-06-23 21:58:14.485702
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    alphabet = text.alphabet()
    assert type(alphabet) == list
    # Unit test for method "level" of class Text
    level = text.level()
    assert type(level) == str
    # Unit test for method "text" of class Text
    sentence = text.text()
    assert type(sentence) == str
    # Unit test for method "title" of class Text
    title = text.title()
    assert type(title) == str
    # Unit test for method "words" of class Text
    sentence = text.words()
    assert type(sentence) == list
    # Unit test for method "word" of class Text
    word = text.word()
    assert type(word) == str
    # Unit test for method "swear_word" of class Text
    word = text.sw

# Generated at 2022-06-23 21:58:22.805196
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Setup
    my_Text = Text()
    my_words = []

    # Exercise
    my_words.append(my_Text.swear_word())
    my_words.append(my_Text.swear_word())
    my_words.append(my_Text.swear_word())
    my_words.append(my_Text.swear_word())
    my_words.append(my_Text.swear_word())

    # Verify
    my_set = set(my_words)
    assert len(my_words) == len(my_set)
    assert len(my_words) == 5

# Generated at 2022-06-23 21:58:25.573464
# Unit test for method words of class Text
def test_Text_words():
    for _ in range(100):
        print(Text('en').words())


# Generated at 2022-06-23 21:58:28.140099
# Unit test for method answer of class Text
def test_Text_answer():
    # Case 1. Default locale
    t = Text()
    assert t.answer() in t._data['answers']

    # Case 2. Custom locale
    t = Text(locale='ru')
    assert t.answer() in t._data['answers']

# Generated at 2022-06-23 21:58:30.105054
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    print(text.text(1))


# Generated at 2022-06-23 21:58:37.847858
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert type(text.alphabet()) == list
    assert type(text.level()) == str
    assert type(text.text()) == str
    assert type(text.sentence()) == str
    assert type(text.title()) == str
    assert type(text.words()) == list
    assert type(text.word()) == str
    assert type(text.swear_word()) == str
    assert type(text.quote()) == str
    assert type(text.color()) == str
    assert type(text.hex_color()) == str
    assert type(text.rgb_color()) == tuple
    assert type(text.answer()) == str


# Generated at 2022-06-23 21:58:40.984793
# Unit test for constructor of class Text
def test_Text():
    """Module test."""
    text = Text()
    output = text.alphabet()
    assert isinstance(output, list)
    assert len(Text().alphabet()) == 26


# Generated at 2022-06-23 21:58:41.985653
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())

# Generated at 2022-06-23 21:58:45.421444
# Unit test for method words of class Text
def test_Text_words():
    random_text = Text()
    result = random_text.words(quantity=1)
    assert len(result) == 1 or type(result) is list

# Generated at 2022-06-23 21:58:47.347548
# Unit test for method sentence of class Text
def test_Text_sentence():
    g = Text
    s = g.sentence(g)
    print(s)


# Generated at 2022-06-23 21:58:57.439958
# Unit test for method title of class Text
def test_Text_title():
    """Test for title method."""
    from mimesis.enums import Provinces, Specialization
    from mimesis.schema import Field, Schema


# Generated at 2022-06-23 21:58:59.647757
# Unit test for method sentence of class Text
def test_Text_sentence():
    _t = Text()
    _str = _t.sentence()
    
    assert isinstance(_str, str)
    

# Generated at 2022-06-23 21:59:04.614761
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.text())
    print(t.swear_word())
    print(t.hex_color(safe=True))
    print(t.rgb_color(safe=True))
    print(t.firstname())
    print(t.lastname())

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 21:59:05.577512
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text().hex_color(safe=False) == '#d8346b'

# Generated at 2022-06-23 21:59:09.686522
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == "Text"
    # case = true
    assert t.__class__.__bases__ == (BaseDataProvider,)
    assert t.provider == "Text"


# Generated at 2022-06-23 21:59:11.068464
# Unit test for method text of class Text
def test_Text_text():
    text1=Text()
    text=text1.text()
    assert text is not False

# Generated at 2022-06-23 21:59:15.184854
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.providers.text import Text
    from mimesis.enums import Case
    c = Text()
    for i in range(100):
        ans = c.alphabet(lower_case=True)
        assert isinstance(ans, list)
        assert isinstance(Case.LOWER, Case)


# Generated at 2022-06-23 21:59:17.295506
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(locale='en')
    answer = text.answer()
    assert answer in ['Yes', 'No']


# Generated at 2022-06-23 21:59:25.336168
# Unit test for constructor of class Text
def test_Text():
    # Creating an instance of class Text
    text = Text()

    # Checking the type of an attribute
    assert isinstance(text.level(), str)
    assert isinstance(text.color(), str)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.quote(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.title(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.word(), str)
    assert isinstance(text.words(), list)
    assert isinstance(text.answer(), str)

    # Checking the length of an attribute
    assert len(text.alphabet()) == 26
    assert len

# Generated at 2022-06-23 21:59:26.871608
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())


# Generated at 2022-06-23 21:59:30.111693
# Unit test for method text of class Text
def test_Text_text():
    text_ = Text()
    print(text_.text())


if __name__ == "__main__":
    test_Text_text()

# Generated at 2022-06-23 21:59:37.473165
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    all_quotes = t._data['quotes']
    print("all quotes", len(all_quotes))
    test_quotes = set()
    for _ in range(1500):
        new_quote = t.quote()
        print("new quote", new_quote)
        test_quotes.add(new_quote)
    print("test quotes", len(test_quotes))
    test_quotes = set(test_quotes)
    assert(len(all_quotes) >= len(test_quotes))
#test_Text_quote()

# Generated at 2022-06-23 21:59:38.701318
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    print(text.text())


# Generated at 2022-06-23 21:59:47.279974
# Unit test for method word of class Text
def test_Text_word():
    txt = Text()
    assert Text.Meta.name == 'text'
    assert type(txt.text()) == str
    assert type(txt.sentence()) == str
    assert type(txt.words()) == list
    assert type(txt.word()) == str
    assert type(txt.swear_word()) == str
    assert type(txt.quote()) == str
    assert type(txt.color()) == str
    assert type(txt.hex_color()) == str
    assert type(txt.rgb_color()) == tuple
    assert type(txt.answer()) == str

if __name__ == '__main__':
    test_Text_word()

# Generated at 2022-06-23 21:59:48.938210
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence
    assert isinstance(sentence, str)

# Generated at 2022-06-23 21:59:50.579083
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())


# Generated at 2022-06-23 21:59:53.335080
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    a = Text()
    for cases in ['lowercase', 'uppercase']:
        alphabet = a.alphabet(cases == 'uppercase')
        assert isinstance(alphabet, list)

# Generated at 2022-06-23 21:59:55.132426
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert isinstance(text.hex_color(), str)


# Generated at 2022-06-23 21:59:56.091848
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.answer())

# Generated at 2022-06-23 21:59:57.512844
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() != ''


# Generated at 2022-06-23 21:59:57.937770
# Unit test for method title of class Text
def test_Text_title():
    pass

# Generated at 2022-06-23 21:59:59.512566
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    _text = Text(seed = 1)
    assert _text.swear_word() == "Bitch"

# Generated at 2022-06-23 22:00:00.878522
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(f"Random swear word: {text.swear_word()}")


# Generated at 2022-06-23 22:00:04.802566
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    obj = Text()
    test_data = 'αβγδεζηθικλμνξοπρστυφχψω'
    assert obj.alphabet() == test_data, 'Text.alphabet return not equal'
    assert isinstance(obj.alphabet(), str), 'Text.alphabet return not string'


# Generated at 2022-06-23 22:00:05.817356
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t)

# Generated at 2022-06-23 22:00:08.055777
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert isinstance(t.words(), list)
    assert isinstance(t.words(quantity=2), list)


# Generated at 2022-06-23 22:00:09.815067
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    q = t.quote()
    assert q #is not None


# Generated at 2022-06-23 22:00:13.625611
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert True
    
answers = ['да', 'нет', 'невозможно', 'не знаю']
assert answer in answers

# Generated at 2022-06-23 22:00:15.175296
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words_list = text.words(quantity=10)
    assert len(words_list) == 10
    assert isinstance(words_list, list)


# Generated at 2022-06-23 22:00:17.626016
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    sentence = provider.sentence()
    print(sentence)
    assert isinstance(sentence, str)



# Generated at 2022-06-23 22:00:19.802499
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level
    assert isinstance(level, str)


# Generated at 2022-06-23 22:00:21.893858
# Unit test for constructor of class Text
def test_Text():
    """Unit test for constructor of class Text."""
    data = Text('en')

    assert data._datafile == 'text.json'



# Generated at 2022-06-23 22:00:23.812606
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())
    print(text.swear_word())
    print(text.swear_word())

# Generated at 2022-06-23 22:00:26.249322
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    r = text.color()
    assert type(r) == str


# Generated at 2022-06-23 22:00:27.158072
# Unit test for constructor of class Text
def test_Text():
    Text()

# Generated at 2022-06-23 22:00:29.276786
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    words = Text().swear_word()
    assert words == "fuck"


# Generated at 2022-06-23 22:00:40.111771
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.localization import Localization
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider

    # Valid: Dict, Dict[str, Dict[str, str]], Dict[str, Dict[str, List[str]]]
    russian_spec = {
        'answers': ['Да', 'Нет'],
        'color': ['Красный'],
        'hex_color': ['#ff0000'],
        'level': ['Критический', 'Серьёзный'],
    }

    lc = RussiaSpecProvider(Localization('ru'))


# Generated at 2022-06-23 22:00:41.825267
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color 



# Generated at 2022-06-23 22:00:43.829101
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    result = text.text(2)
    print(result, '\n')


# Generated at 2022-06-23 22:00:46.205738
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text(seed=1)
    text = t.alphabet()

    assert len(text) == 26
    assert text[0] == 'A'


# Generated at 2022-06-23 22:00:52.442916
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    t = Text()
    assert '.' in t.title()

    print("Test RussiaSpecProvider")
    t = RussiaSpecProvider(Gender.FEMALE)
    assert '.' in t.title()

    print("Test USASpecProvider")
    t = USASpecProvider(Gender.FEMALE)
    assert '.' in t.title()

# Generated at 2022-06-23 22:00:55.866955
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    provider = Text()
    result = provider.alphabet()
    assert isinstance(result, list)
    assert len(result) == 26


# Generated at 2022-06-23 22:01:00.196901
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    try:
        assert type(title) is str
    except AssertionError:
        print("text.py: test_Text_title() test failed")
    else:
        print("text.py: test_Text_title() test passed")


# Generated at 2022-06-23 22:01:03.999043
# Unit test for method words of class Text
def test_Text_words():
    """Test method words of class Text."""
    t = Text()
    result = t.words()
    assert isinstance(result, list)
    result = t.words(10)
    assert isinstance(result, list)
    assert len(result) == 10

# Generated at 2022-06-23 22:01:09.892542
# Unit test for constructor of class Text
def test_Text():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    provider = Text(RussiaSpecProvider())
    provider.seed(1)
    assert provider.language == 'ru'
    assert provider.region == 'ru'
    assert provider.localization == 'ru-RU'
    assert provider.seed_instance == 1


# Generated at 2022-06-23 22:01:11.614847
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    word = text.swear_word()
    assert word in text._data['words']['bad']

# Generated at 2022-06-23 22:01:13.293661
# Unit test for method text of class Text
def test_Text_text():
    text = Text('uk')
    text.text()
    text.text(3)


# Generated at 2022-06-23 22:01:14.918906
# Unit test for method word of class Text
def test_Text_word():
    word = Text('en').word()
    print(word)
    assert word is not None


# Generated at 2022-06-23 22:01:18.348287
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Gender
    from mimesis.builtins import Text

    t = Text(gender=Gender.MALE, seed=1)

    assert t.level() == 'critical'


# Generated at 2022-06-23 22:01:25.324679
# Unit test for constructor of class Text
def test_Text():
    testText = Text()
    print(testText.alphabet())
    print(testText.level())
    print(testText.text())
    print(testText.sentence())
    print(testText.title())
    print(testText.words())
    print(testText.word())
    print(testText.swear_word())
    print(testText.quote())
    print(testText.color())
    print(testText.hex_color())
    print(testText.rgb_color())
    print(testText.answer())

if (__name__ == "__main__"):
    test_Text()

# Generated at 2022-06-23 22:01:28.378761
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    g = Text()
    s = g.swear_word()
    try:
        assert s == 'Damn'
    except AssertionError:
        pass
    else:
        return True