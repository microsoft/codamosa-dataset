

# Generated at 2022-06-23 21:51:34.144796
# Unit test for method words of class Text
def test_Text_words():
    text_provider = Text(seed=42)
    result = text_provider.words(quantity=5)
    assert result[0] == "science"
    assert result[1] == "network"
    assert result[2] == "god"
    assert result[3] == "octopus"
    assert result[4] == "love"


# Generated at 2022-06-23 21:51:35.311208
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('en')
    # It tests that the method returns a tuple
    assert isinstance(text.alphabet(), list)


# Generated at 2022-06-23 21:51:38.353983
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_provider = Text()
    rgb_color = text_provider.rgb_color()
    assert type(rgb_color) == tuple
    assert len(rgb_color) == 3


# Generated at 2022-06-23 21:51:39.651173
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print(Text.swear_word())
    pass


# Generated at 2022-06-23 21:51:41.517871
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear = text.swear_word()
    assert type(swear) == str


# Generated at 2022-06-23 21:51:45.021980
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    pp = {'safe': True}
    assert t.rgb_color(**pp) == (244, 67, 54)

# Generated at 2022-06-23 21:51:49.483843
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import Color
    from pprint import pprint

    x = Text(seed = 42)
    y = Text(seed = 42)

    pprint(x.hex_color())
    pprint(y.hex_color(safe = True))
    pprint(x.hex_color(safe = Color.PASTEL))

# Generated at 2022-06-23 21:51:50.433873
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text().sentence())


# Generated at 2022-06-23 21:51:52.090972
# Unit test for method words of class Text
def test_Text_words():
    text = Text(locale='en')
    words = text.words(quantity=10)
    assert len(words) == 10
    for word in words:
        assert isinstance(word, str)

# Generated at 2022-06-23 21:51:54.199041
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    a=Text()
    print(a.swear_word())
    print(a.swear_word())

test_Text_swear_word()

# Generated at 2022-06-23 21:51:56.206378
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    for i in range(5):
        result = t.color()
        assert isinstance(result, str)

# Generated at 2022-06-23 21:51:57.567080
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert type(t.title()) == str


# Generated at 2022-06-23 21:51:59.730430
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    assert provider.sentence() == "I don't care."

# Generated at 2022-06-23 21:52:01.120567
# Unit test for method quote of class Text
def test_Text_quote():
    tmp = Text().quote()
    assert not tmp.isspace()

# Generated at 2022-06-23 21:52:13.006988
# Unit test for method alphabet of class Text
def test_Text_alphabet():

    from mimesis.enums import Case
    from mimesis.providers.text import Text

    t = Text()
    assert len(t.alphabet()) == 26
    assert t.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'
    assert t.alphabet(lower_case=False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert len(t.alphabet(lower_case=True)) == 26
    assert len(t.alphabet(lower_case=False)) == 26
    assert t.alphabet(lower_case=Case.LOWER) == \
        'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-23 21:52:17.439722
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from doctest import debug
    debug.Debugger(
        _checker=Text(seed=42).rgb_color(safe=True)
    )
# Output:
# <doctest._DebugOutput instance at 0x04DC7910>

# Generated at 2022-06-23 21:52:19.744255
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert type(t.word()) == str
    assert len(t.word()) >= 2


# Generated at 2022-06-23 21:52:21.880145
# Unit test for method word of class Text
def test_Text_word():
	txt = Text()
	result = txt.word()
	assert isinstance(result, str)
	assert len(result) >= 1

# Generated at 2022-06-23 21:52:23.314542
# Unit test for method swear_word of class Text
def test_Text_swear_word():    
    text = Text('en')
    text.swear_word()

# Generated at 2022-06-23 21:52:27.445549
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alpha = 'abcdefghijklmnopqrstuvwxyz'
    assert len(t.alphabet(lower_case=True)) == len(alpha)
    assert len(t.alphabet(lower_case=False)) == len(alpha.upper())

# Generated at 2022-06-23 21:52:36.411361
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    for i in range(10):
        text = Text('en')
        sentence = text.sentence()
        assert isinstance(sentence, str)
        assert len(sentence) > 0
        assert sentence[0].isupper()
        assert sentence[-1] == '.'
    ru = Text('ru')
    ru_sentence = ru.sentence()
    assert ru_sentence.endswith('.')
    ru_sentence_2 = ru.sentence(lowercase=True)
    assert ru_sentence_2.endswith('.')
    ru_sentence_3 = ru.sentence(punctuation=True)
    assert ru_sentence_3.endswith('!')
    ru

# Generated at 2022-06-23 21:52:41.744634
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    provider = Text(locale='ru')
    color = provider.rgb_color()
    assert isinstance(color, tuple)
    assert len(color) == 3
    assert all([isinstance(c, int) for c in color])
    assert all([0 <= c <= 255 for c in color])



# Generated at 2022-06-23 21:52:45.054425
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    a = t.level()
    assert type(a) is str and a



# Generated at 2022-06-23 21:52:48.144490
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    t = Text()
    assert isinstance(t.sentence(), str)

# Generated at 2022-06-23 21:52:48.837572
# Unit test for constructor of class Text
def test_Text():
    text = Text()


# Generated at 2022-06-23 21:52:50.923724
# Unit test for method color of class Text
def test_Text_color():
    txt = Text()
    assert isinstance(txt.color(), str) is True

# Generated at 2022-06-23 21:52:51.829495
# Unit test for method color of class Text
def test_Text_color():
    assert Text().color() in Text().color_list()


# Generated at 2022-06-23 21:52:53.519895
# Unit test for method word of class Text
def test_Text_word():
  for i in range(100):
    assert isinstance(Text().word(), str)


# Generated at 2022-06-23 21:52:55.304060
# Unit test for method color of class Text
def test_Text_color():
    test = Text()
    assert isinstance(test.color(), str)

# Generated at 2022-06-23 21:52:57.225074
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert len(text.sentence()) > 0


# Generated at 2022-06-23 21:53:02.276377
# Unit test for constructor of class Text
def test_Text():
    from mimesis import __version__
    from mimesis.enums import Gender, PersonField
# Define variable for text
    text = Text('en')
    text = Text(seed=0)
    text = Text(random_state=0)
    text = Text(seed=None)
    print(text.raw_data(PersonField.FULL_NAME, gender=Gender.MALE))
    print(text.random_element(['abc', 'def']))
    print(text.random_elements(['abc', 'def'], unique=True))
    print(text.random_elements(['abc', 'def'], unique=False))
    print(text.random_elements(['abc', 'def'], unique=True, quantity=None))
    print(text.randomize('abc'))

# Generated at 2022-06-23 21:53:07.021106
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    from . import Text
    txt = Text(locale=Locale.EN)
    for _ in range(20):
        assert txt.level() in ['critical', 'high', 'low', 'very high', 'very low']



# Generated at 2022-06-23 21:53:09.474284
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    # print("Debug: Text.answer() = {}".format(text.answer()))
    assert len(text.answer()) > 0


# Generated at 2022-06-23 21:53:11.145181
# Unit test for method answer of class Text
def test_Text_answer():
    provider = Text()

    result = provider.answer()
    assert result in ['yes', 'no']

# Generated at 2022-06-23 21:53:12.637835
# Unit test for method words of class Text
def test_Text_words():
    print('\nMethod words of class Text:')
    print(Text().words(3))



# Generated at 2022-06-23 21:53:16.881948
# Unit test for method quote of class Text
def test_Text_quote():
    provider = Text()
    for _ in range(20):
        quote = provider.quote()
        assert(len(quote) > 5)
        

# Generated at 2022-06-23 21:53:19.197888
# Unit test for method words of class Text
def test_Text_words():
    count = 100
    text = Text()
    assert len(text.words(quantity=count)) == count

# Generated at 2022-06-23 21:53:21.293053
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    provider = Text()
    swear = provider.swear_word()
    assert swear in provider._data['words']['bad']

# Generated at 2022-06-23 21:53:23.795097
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # create object of class Text
    T = Text(seed=42)
    # call function to check if we get string or not
    assert isinstance(T.swear_word(), str)


# Generated at 2022-06-23 21:53:24.993340
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() not in text.words()

# Generated at 2022-06-23 21:53:26.820608
# Unit test for method word of class Text
def test_Text_word():
    input = Text().word()
    output = 'science'
    assert input == output


# Generated at 2022-06-23 21:53:28.512153
# Unit test for method level of class Text
def test_Text_level():
    p = Text()
    result = p.level()
    assert result in p._data['level']


# Generated at 2022-06-23 21:53:31.784138
# Unit test for method words of class Text
def test_Text_words():
    t = Text('en')
    word_list = t.words(quantity=10)
    assert len(word_list) == 10
    assert isinstance(word_list, list)

# Generated at 2022-06-23 21:53:33.733813
# Unit test for method text of class Text
def test_Text_text():
    txt = Text()
    assert isinstance(txt.text(), str)

# Generated at 2022-06-23 21:53:35.879831
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for Text.sentence()."""
    provider = Text()
    sentence = provider.sentence()
    assert isinstance(sentence, str)

# Generated at 2022-06-23 21:53:37.218805
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert len(t.color()) > 0

# Generated at 2022-06-23 21:53:38.527046
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert type(text.word()) is str


# Generated at 2022-06-23 21:53:45.142280
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorSchema
    from mimesis.builtins import Text

    text = Text()
    for _ in range(10):
        color_1 = text.rgb_color()
        color_2 = text.rgb_color(safe=True)
        assert (isinstance(color_1, tuple))
        assert (isinstance(color_2, tuple))
        assert (len(color_1) == len(color_2) == 3)

    safe_colors = [ColorSchema.BLUE, ColorSchema.GREEN, ColorSchema.PURPLE,
                   ColorSchema.RED, ColorSchema.YELLOW]
    for color in safe_colors:
        color_1 = text.rgb_color(safe=True)
        color_2 = text.rgb_color()

# Generated at 2022-06-23 21:53:47.035684
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    list = text.words()
    assert len(list) == 5

# Generated at 2022-06-23 21:53:55.349201
# Unit test for method text of class Text
def test_Text_text():
    text = Text(seed=0)
    assert text.text() == 'Battlestar pragmatique, ne se lance pas dans la gueule du loup.'
    assert text.text() == 'Il était une fois, le vieux débat, entre politiciens, sur fonds publics.'
    assert text.text() == 'Pourquoi le rock ne se bat jamais contre le tonnerre? Parce que c\'est un groupe qui vient de la pluie.'


# Generated at 2022-06-23 21:54:00.004771
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    result = Text().rgb_color()
    if result is not None:
        if type(result) == tuple:
            for item in result:
                if type(item) == int:
                    pass
                else:
                    raise Exception('result must be a tuple')
        else:
            raise Exception('result must be a tuple')
    else:
        raise Exception('result must be a tuple')


# Generated at 2022-06-23 21:54:04.930874
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print('Text#rgb_color')
    text = Text()
    rgb = text.rgb_color()
    print(rgb, type(rgb))
    assert isinstance(rgb, tuple)
    assert len(rgb) == 3
    for i in rgb:
        assert isinstance(i, int)


# Generated at 2022-06-23 21:54:08.530649
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    t = Text('en')
    print(t.quote())



# Generated at 2022-06-23 21:54:11.364755
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


test_Text_sentence()


# Generated at 2022-06-23 21:54:13.258646
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert color in t._data['color']

# Generated at 2022-06-23 21:54:16.010132
# Unit test for method title of class Text
def test_Text_title():
    inst = Text()
    assert inst.title() == 'Američki predsjednik Barack Obama pozvao je američku Kongres povesti rat protiv terorista u Siriji'


# Generated at 2022-06-23 21:54:17.543626
# Unit test for method quote of class Text
def test_Text_quote():


    random.seed(0)

    assert Text.quote() in Text._data['quotes']



# Generated at 2022-06-23 21:54:18.742865
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    provider = Text('en')
    print(provider.hex_color())

# Generated at 2022-06-23 21:54:19.616892
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text().sentence())


# Generated at 2022-06-23 21:54:23.174541
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert 5 <= len(sentence) <= 25
    assert sentence.count(' ') == 0


# Generated at 2022-06-23 21:54:24.862050
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.builtins import RussiaSpecProvider
    t = Text(RussiaSpecProvider)
    assert t.level() in t._data['level']


# Generated at 2022-06-23 21:54:26.263578
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis import Text
    t = Text('zh_CN')
    ans = t.answer()
    assert ans == '是'


# Generated at 2022-06-23 21:54:27.405528
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-23 21:54:28.591289
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-23 21:54:32.848324
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    print(a.color())
    print(a.alphabet())
    print(a.alphabet(lower_case=True))
    print(a.level())
    print(a.swear_word())
    print(a.quote())
    print(a.answer())
    print(a.word())
    print(a.word())
    print(a.text())
    print(a.title())


if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-23 21:54:33.411715
# Unit test for method title of class Text
def test_Text_title():
    pass

# Generated at 2022-06-23 21:54:35.430323
# Unit test for method level of class Text
def test_Text_level():
    level = Text().level()
    assert level in ['critical', 'moderate', 'normal', 'low']
    

# Generated at 2022-06-23 21:54:41.097066
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert 'A' in t.alphabet()
    assert 'b' in t.alphabet(lower_case=True)
    assert 'B' not in t.alphabet(lower_case=True)


# Generated at 2022-06-23 21:54:42.752051
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text("en")
    assert "#e25e33" == text.hex_color()

# Generated at 2022-06-23 21:54:47.486909
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Language
    from mimesis.localization import DEFAULT_LOCALE, LOCALES
    for key in LOCALES.keys():
        text = Text(language=key)
        assert text.level() in text._data['level']
    text = Text(locale=DEFAULT_LOCALE)
    assert text.level(locale=Language.EN) == 'critical'

# Generated at 2022-06-23 21:54:50.338650
# Unit test for method title of class Text
def test_Text_title():
    # create object Text
    text = Text()
    # create a string with a title
    title = text.title()
    # check the first letter is capital
    assert title[0].isupper()


# Generated at 2022-06-23 21:54:55.904875
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Gender
    from mimesis.text import Text
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.computer import Computer
    from mimesis.providers.payment import Payment
    from mimesis.providers.business import Business
    from mimesis.providers.lorem import Lorem

    # Create an instance of the class Text
    t = Text()
    # Create an instance of the class Person
    p = Person('en')
    # Create an instance of the class Address
    a = Address('en')
    # Create an instance of the class Internet
    i = Internet('en')
    # Create an instance of the class Computer

# Generated at 2022-06-23 21:55:05.793497
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import UnitedStatesSpecProvider
    from mimesis.builtins import PolandSpecProvider
    from pprint import pprint
    # Create Russian Text provider
    russian = Text(locale=Locale.RUSSIAN)
    # Create English Text provider
    english = Text(locale=Locale.ENGLISH)
    # Create Polish Text provider
    polish = Text(locale=Locale.POLISH)
    # Get 10 random words by russian provider
    rus_words_10 = russian.words(10)
    pprint(rus_words_10)
    # Get 1 random word by english provider
    eng_words_1 = english.words(1)

# Generated at 2022-06-23 21:55:08.279390
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-23 21:55:09.969344
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    result = t.level()
    print(result)


# Generated at 2022-06-23 21:55:13.786014
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.builtins import Text
    t = Text()
    color = t.hex_color()
    assert isinstance(color, str)
    assert len(color) == 7
    assert color.startswith('#')


# Generated at 2022-06-23 21:55:17.119857
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.providers.text import Text
    t = Text()
    
    assert t.hex_color() in ("#fcbdb3", "#c95501")
    assert t.hex_color(True) in ("#1abc9c", "#3498db")
    

# Generated at 2022-06-23 21:55:18.186623
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    print('Text.alphabet: ', text.alphabet())


# Generated at 2022-06-23 21:55:19.063059
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert isinstance(t.level(), str)


# Generated at 2022-06-23 21:55:20.659239
# Unit test for method sentence of class Text
def test_Text_sentence():
    for i in range(10):
        text = Text()
        print(text.sentence())

# Generated at 2022-06-23 21:55:23.545097
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alphabet = t.alphabet(lower_case=True)
    assert isinstance(alphabet, list)
    assert len(alphabet) == 26


# Generated at 2022-06-23 21:55:33.054894
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test method hex_color."""
    text = Text()

    # 10 test of method hex_color
    for _ in range(10):
        # It's very hard to check because output in hex format
        # So I will test:
        # - len of hex color is 7
        # - first char is #
        # - hex color include only letters from a-f and numbers
        color_hex = text.hex_color()

        assert(len(color_hex) == 7)
        assert(color_hex[0] == '#')
        assert(color_hex[1:].isalnum())



# Generated at 2022-06-23 21:55:36.646378
# Unit test for method color of class Text
def test_Text_color():
    # Test to make sure that a certain color is one of the colors in the language file
    color = 'red'
    text = Text('en')
    colors = text._data['color']
    assert color == colors[0]


# Generated at 2022-06-23 21:55:37.442093
# Unit test for method answer of class Text
def test_Text_answer():
    a = Text()
    for i in range(100):
        print(a.answer())

# Generated at 2022-06-23 21:55:40.618527
# Unit test for method level of class Text
def test_Text_level():
    text_provider = Text()
    result = text_provider.level()
    assert result != None

# Generated at 2022-06-23 21:55:48.483710
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis import Text

    ru = RussiaSpecProvider()
    assert ru.text.answer() == "Да"
    assert ru.text.answer() == "Нет"
    assert ru.text.answer() == "Возможно"
    assert ru.text.answer() == "Скорее да"
    assert ru.text.answer() == "Скорее нет"
    assert ru.text.answer() == "Очень сомнительно"

    text = Text('hh')
    assert text.answer() == "Да"
    assert text.answer() == "Нет"

# Generated at 2022-06-23 21:55:53.024636
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title = t.title()
    tmp0 = title
    assert isinstance(tmp0, str)
    tmp1 = t.title()
    assert isinstance(tmp1, str)
    tmp2 = t.title()
    assert isinstance(tmp2, str)


# Generated at 2022-06-23 21:55:54.017666
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    print(Text().hex_color())


# Generated at 2022-06-23 21:55:55.754975
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of class Text"""
    print(Text().swear_word())


# Generated at 2022-06-23 21:55:59.477094
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    res = t.hex_color()
    assert len(res) == 7
    assert res[0] == '#'
    assert res[1:].isalnum()
    assert t.hex_color(True) in SAFE_COLORS


# Generated at 2022-06-23 21:56:01.430907
# Unit test for method level of class Text
def test_Text_level():
    """Testing method level of class Text."""
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-23 21:56:09.911388
# Unit test for method level of class Text
def test_Text_level():
    """Проверка корректности возможных значений метода level."""
    text = Text()
    possible_levels = ['critical','safe','danger','warning','normal','success','info']
    while True:
        level = text.level()
        assert level in possible_levels
        print(f'level = {level}')
        if level == 'info':
            break


# Generated at 2022-06-23 21:56:10.598638
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None

# Generated at 2022-06-23 21:56:12.141321
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    print(t.text())


# Generated at 2022-06-23 21:56:13.416052
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.words(), list)


# Generated at 2022-06-23 21:56:16.147419
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins import Text
    text = Text('fr')
    lst = text.words(quantity=5)
    assert isinstance(lst, list)



# Generated at 2022-06-23 21:56:19.748898
# Unit test for method quote of class Text
def test_Text_quote():
    x = Text()
    assert x.quote() == "Hello, World!"

# Generated at 2022-06-23 21:56:22.786644
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text."""
    text = Text()
    result = text.sentence()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-23 21:56:23.596881
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    text.answer()

# Generated at 2022-06-23 21:56:31.693525
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.builtins import Text as Text_
    t = Text_('zh')

# Generated at 2022-06-23 21:56:39.569169
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.data import SAFE_COLORS
    print(Text().sentence())
    print(Text().words())
    print(Text().word())
    # print(Text().quote())
    # print(Text().hex_color(True))
    # print(Text().rgb_color(True))
    print(Text().sentence())
    print(Text().text(quantity=10))
    # print(Text().swear_word())
    print(Text().alphabet())
    print(Text().alphabet(lower_case=True))
    print(Text().answer())
    print(Text().level())
    print(Text().color())

if __name__ == '__main__':
    test_Text_sentence()

# Generated at 2022-06-23 21:56:40.945876
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() == t.sentence()

# Generated at 2022-06-23 21:56:43.235697
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color(safe=True) in SAFE_COLORS

# Generated at 2022-06-23 21:56:44.793698
# Unit test for method words of class Text
def test_Text_words():
    assert  Text.words() == len(Text.words())

# Generated at 2022-06-23 21:56:50.867376
# Unit test for method words of class Text
def test_Text_words():
    result = []
    for i in range(10):
        w = Text()
        list = w.words(quantity=2)
        result.append(list)
    for i in range(10):
        assert type(result[i]) == list
    for i in range(10):
        assert len(result[i]) == 2
    for index in range(10):
        for i in range(2):
            assert type(result[index][i]) == str


# Generated at 2022-06-23 21:56:53.866369
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Gender
    for k in range(100):
        t = Text()
        a = t.color()
        print(a)


# Generated at 2022-06-23 21:56:57.484253
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert type(t.swear_word()) == str
    assert len(t.swear_word()) > 0
    assert t.swear_word() in t._data['words'].get('bad')

# Generated at 2022-06-23 21:56:58.543926
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    p = Text()
    assert len(p.hex_color()) == len('#ffffff')


# Generated at 2022-06-23 21:56:59.515557
# Unit test for method quote of class Text
def test_Text_quote():
  text = Text()
  print(text.quote())


# Generated at 2022-06-23 21:57:00.796500
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    print("\nУровень: ", t.level())


# Generated at 2022-06-23 21:57:02.050139
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert len(Text().sentence()) > 0


# Generated at 2022-06-23 21:57:09.583068
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import ColorSchemes
    from mimesis.builtins import Text
    from mimesis.exceptions import NonEnumerableError

    text = Text('en_GB')
    assert isinstance(text.hex_color(), str)

    text = Text('en_US')
    assert isinstance(text.hex_color(safe=True), str)

    assert text.hex_color(safe=ColorSchemes.GREEN) == '#85cc00'

    try:
        text.hex_color(safe=-1)
    except NonEnumerableError as e:
        assert e.args[0] == '<ColorSchemes.RED: 1>'

    assert text.hex_color(safe=ColorSchemes.RED) == '#e1523d'

# Generated at 2022-06-23 21:57:11.059396
# Unit test for method words of class Text
def test_Text_words():
    pop = Text()
    assert len(pop.words()) == 5


# Generated at 2022-06-23 21:57:15.654331
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    text = Text(seed=1234)
    color = text.hex_color()
    assert len(color) == 7
    assert color.startswith('#')


# Generated at 2022-06-23 21:57:18.709986
# Unit test for method quote of class Text
def test_Text_quote():

    text = Text(seed=42)

# Generated at 2022-06-23 21:57:20.103262
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title()


# Generated at 2022-06-23 21:57:24.378597
# Unit test for method color of class Text
def test_Text_color():
    text = Text("en")
    color_name = text.color()
    assert color_name in ['Red', 'Green', 'Blue']

    color_name = text.color()
    assert color_name in ['Red', 'Green', 'Blue']


# Generated at 2022-06-23 21:57:26.864590
# Unit test for method level of class Text
def test_Text_level():
    print()
    print("Testing Text.level")
    t = Text()
    result = t.level()
    print("Level: ", result)
    assert result
    print("PASSED")


# Generated at 2022-06-23 21:57:29.190667
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    result = t.words(quantity=7)
    print(result)


# Generated at 2022-06-23 21:57:29.819702
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    print(t.level())


# Generated at 2022-06-23 21:57:30.454195
# Unit test for method answer of class Text
def test_Text_answer():
    # Assert output length
    assert len(answer()) >= 2


# Generated at 2022-06-23 21:57:36.657182
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert hasattr(text, 'alphabet')
    assert hasattr(text, 'title')
    assert hasattr(text, 'text')
    assert hasattr(text, 'sentence')
    assert hasattr(text, 'words')
    assert hasattr(text, 'word')
    assert hasattr(text, 'quote')
    assert hasattr(text, 'color')
    assert hasattr(text, 'hex_color')
    assert hasattr(text, 'rgb_color')
    assert hasattr(text, 'answer')
    assert hasattr(text, 'level')

test_Text()

# Test for Alphabet

# Generated at 2022-06-23 21:57:38.765835
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Testing method swear_word of class Text"""
    t = Text()
    assert type(t.swear_word()) is str
    for _ in range(10):
        assert t.swear_word() in Text()._data['words'].get('bad')
    

# Generated at 2022-06-23 21:57:40.727872
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    data = Text.hex_color()
    print(data)
    assert len(data)==7


# Generated at 2022-06-23 21:57:44.076567
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    actual = text.quote()
    result = ('Derive pleasure in your work or you may as well commit suicide.'.capitalize())
    assert actual == result


# Generated at 2022-06-23 21:57:46.045137
# Unit test for method word of class Text
def test_Text_word():
    assert Text.word() in Text.words(quantity=5)

# Generated at 2022-06-23 21:57:47.892993
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print("Text.rgb_color(): " + repr(Text.rgb_color()))


# Generated at 2022-06-23 21:57:49.078372
# Unit test for method level of class Text
def test_Text_level():
    pass


# Generated at 2022-06-23 21:57:53.934079
# Unit test for method word of class Text
def test_Text_word():
    """Test method word of class Text."""
    my_text_obj = Text()
    my_word = my_text_obj.word()
    assert isinstance(my_word, str) and len(my_word) > 0
    assert my_word in my_text_obj._data['words']['normal']


# Generated at 2022-06-23 21:58:00.115395
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text.
    The method is used in function get_color of module get_color.
    """
    # Arrange
    expected = (128,128,128)
    # Act
    actual = Text().rgb_color(safe=True)
    # Assert
    assert(actual == expected)

# Generated at 2022-06-23 21:58:01.780350
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())


# Generated at 2022-06-23 21:58:08.943264
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text(seed=SEED)
    verbose = False
    num_of_tests = 0
    num_of_passed_tests = 0
    for _ in range(num_of_tests):
        if verbose:
            print("{}. {}".format(_, text.swear_word()))
        num_of_passed_tests += 1
    print("[PASSED: {} / TESTED: {}] - {}".format(num_of_passed_tests, num_of_tests, text.swear_word()))


# Generated at 2022-06-23 21:58:11.923309
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed=1)
    list_of_colors = [text.color() for _ in range(100)]
    assert list_of_colors[0] == 'BlanchedAlmond'
    assert list_of_colors[-1] == 'DarkSlateGray'

# Generated at 2022-06-23 21:58:13.445995
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = Text.hex_color()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:58:15.778558
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()
    assert isinstance(provider.color(), str)


# Generated at 2022-06-23 21:58:17.234731
# Unit test for method level of class Text
def test_Text_level():
    assert Text().level() in ['critical', 'high', 'medium', 'low']

# Generated at 2022-06-23 21:58:20.198466
# Unit test for method quote of class Text
def test_Text_quote():
    text_class = Text()
    quote = text_class.quote()
    assert isinstance(quote, str) and (len(quote)>=15)


# Generated at 2022-06-23 21:58:22.953609
# Unit test for method level of class Text
def test_Text_level():
    # Call method
    text = Text()
    level = text.level()
    assert type(level) is str and len(level) >= 4



# Generated at 2022-06-23 21:58:25.290521
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())

# Generated at 2022-06-23 21:58:27.739148
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    my_text = Text()
    swear_word = my_text.swear_word()
    print("\n")
    print("Swear word: ", swear_word)
    assert isinstance(swear_word, str)


# Generated at 2022-06-23 21:58:30.054897
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_cls = Text()
    assert type(text_cls.rgb_color()) == tuple


# Generated at 2022-06-23 21:58:30.681456
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    pass

# Generated at 2022-06-23 21:58:38.248847
# Unit test for constructor of class Text
def test_Text():
    """Unit test for constructor of class Text."""
    my_text = Text()
    print(my_text.hex_color)
    print(my_text.rgb_color)
    print(my_text.answer)
    print(my_text.quote)
    print(my_text.swear_word)
    print(my_text.word)
    print(my_text.words)
    print(my_text.sentence)
    print(my_text.title)
    print(my_text.text)
    print(my_text.level)
    print(my_text.alphabet)
    print(my_text.color)


# Generated at 2022-06-23 21:58:39.177943
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word()

# Generated at 2022-06-23 21:58:41.697380
# Unit test for method level of class Text
def test_Text_level():
    assert Text().level() in [
        "critical", "high", "medium", "low",
        "informational", "debug"
    ]


# Generated at 2022-06-23 21:58:45.182596
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet(lower_case=False)
    print(alphabet)


# Generated at 2022-06-23 21:58:46.242327
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    result = t.word()
    assert type(result) is str
    assert len(result) > 0


# Generated at 2022-06-23 21:58:51.531729
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.builtins import RussiaSpecProvider
    text = Text(locale='ru')
    answer_1 = text.answer()
    assert answer_1 in text._data['answers']
    russian = RussiaSpecProvider()
    answer_2 = russian.answer()
    assert answer_2 in text._data['answers']


# Generated at 2022-06-23 21:58:54.090244
# Unit test for method text of class Text
def test_Text_text():
    locale = 'en'
    test_obj = Text(locale)
    result = test_obj.text()
    print(result)


# Generated at 2022-06-23 21:58:56.745835
# Unit test for method title of class Text
def test_Text_title():
    """Test for text.title"""
    from mimesis.enums import Locale
    test_text = Text(Locale.ENGLISH)
    assert test_text.sentence() != test_text.sentence()

# Generated at 2022-06-23 21:58:59.515263
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=12345)
    assert text.quote() == 'What do you want to be remembered for?'

test_Text_quote()


# Generated at 2022-06-23 21:59:02.344180
# Unit test for method text of class Text
def test_Text_text():
    """Test function text of class Text"""
    text = Text()
    res = text.text()
    assert isinstance(res, str)
    


# Generated at 2022-06-23 21:59:04.432206
# Unit test for method quote of class Text
def test_Text_quote():
    '''
    Вызов метода quote класса Text
    '''
    text = Text()
    print(text.quote())



# Generated at 2022-06-23 21:59:05.875221
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    a = Text()
    word = a.swear_word()
    assert word
    assert isinstance(word, str)

# Generated at 2022-06-23 21:59:08.162300
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color_name = t.color()
    assert color_name in t._data['color']

# Generated at 2022-06-23 21:59:09.906296
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    result = t.words(quantity=7)
    print(result)


# Generated at 2022-06-23 21:59:13.077539
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text("es")
    assert len(text.hex_color()) == 7
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.hex_color(safe=True), str)


# Generated at 2022-06-23 21:59:14.839375
# Unit test for constructor of class Text
def test_Text():
    assert Text().provider.seed == 0
    assert Text().provider.random
    assert Text()


# Generated at 2022-06-23 21:59:17.295638
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    result = text.level()
    assert isinstance(result, str)
    assert result in text._data['level']


# Generated at 2022-06-23 21:59:18.981149
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print('test_text',text.text())
    
if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 21:59:20.977357
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert "critical" in t.level()
    assert t.level() in ["normal", "medium", "critical"]


# Generated at 2022-06-23 21:59:22.130535
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color()

# Generated at 2022-06-23 21:59:23.501621
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() not in t._data['words']['normal']

# Generated at 2022-06-23 21:59:25.023810
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    result = t.swear_word()
    assert result in t._data['words']['bad']

# Generated at 2022-06-23 21:59:26.609744
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    test_text = Text()
    rgb_value = test_text.rgb_color(safe=True)
    print(rgb_value)


# Generated at 2022-06-23 21:59:29.704395
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print("text.word() = " + str(text.word()))
    assert type(text.word()) is str

# Generated at 2022-06-23 21:59:31.047506
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    words = text.words()
    for word in words:
        assert type(word) is str
        assert len(word) > 0


# Generated at 2022-06-23 21:59:40.621378
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    
    text = Text('ru')
    quantity = 5
    # Должен вернуть список слов заданного количества
    if text.words(quantity) != ['Пол', 'Юмор', 'Сегодня', 'Масло', 'Работа']:
        raise ValueError
    
    # Должен вернуть список слов заданного кол

# Generated at 2022-06-23 21:59:44.567169
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text"""
    t = Text()
    print(t.sentence())


# Generated at 2022-06-23 21:59:48.112584
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    safe_hex_color = text.hex_color(True)

    print("Hex color:", hex_color)
    print("Safe Hex color:", safe_hex_color)



# Generated at 2022-06-23 21:59:52.884906
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.providers.text import Text
    from mimesis.enums import Color
    dc = Text('en')
    result = dc.rgb_color(safe=True)
    if result == Color.RED.rgb_code:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:59:58.465635
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.generators.text import Text
    text = Text()
    level1 = text.level()
    level2 = text.level()
    assert isinstance(level1, str)
    assert isinstance(level2, str)
    assert isinstance(level1, str)
    assert isinstance(level2, str)
    assert len(level1) != 0
    assert len(level2) != 0
    assert level1 != level2


# Generated at 2022-06-23 22:00:02.327881
# Unit test for constructor of class Text
def test_Text():
    text_obj = Text()
    locales = ['en', 'ru', 'ua']
    for _ in locales:
        text_obj.seed(_)
        text_obj.alphabet()
        text_obj.level()
        text_obj.text()
        text_obj.sentence()
        text_obj.title()
        text_obj.words()
        text_obj.word()
        text_obj.swear_word()
        text_obj.quote()
        text_obj.color()
        text_obj.hex_color()
        text_obj.rgb_color()
        text_obj.answer()

# Generated at 2022-06-23 22:00:06.426561
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    t.text()
    t.answer()
    t.level()
    t.sentence()
    t.swear_word()
    t.word()
    t.words()

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 22:00:12.982697
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import ColorType
    text = Text('en')
    hex_color = text.hex_color(safe=True)
    assert hex_color in SAFE_COLORS
    assert len(hex_color) == 7
    assert hex_color.startswith('#')

    hex_color = text.hex_color(safe=False)
    assert len(hex_color) == 7
    assert hex_color.startswith('#')

# Generated at 2022-06-23 22:00:18.395012
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for Text.rgb_color().

    :return: None.
    """
    t = Text()
    res = t.rgb_color()
    assert isinstance(res, tuple)
    assert all(isinstance(x, int) for x in res)
    assert len(res) == 3
    assert all(0 <= x <= 255 for x in res)

# Generated at 2022-06-23 22:00:24.057853
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_alphabet = Text().alphabet(lower_case=True)
    assert text_alphabet == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
                             'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                             's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-23 22:00:25.468938
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    text_quote = t.quote()
    assert len(text_quote) > 0


# Generated at 2022-06-23 22:00:27.053487
# Unit test for method word of class Text
def test_Text_word():
    provider = Text(seed=43)
    assert provider.word() == 'proportions'
    assert provider.word() == 'nerve'

# Generated at 2022-06-23 22:00:28.210114
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert len(Text().rgb_color()) == 3

# Generated at 2022-06-23 22:00:31.953565
# Unit test for method words of class Text
def test_Text_words():
    for i in range(3):
        text = Text(i)
        words = text.words()
        assert len(words) == 5
        assert isinstance(words, list)

# Generated at 2022-06-23 22:00:34.451610
# Unit test for method words of class Text
def test_Text_words():
    # Instance of class Text
    words = Text()
    # Calling method words
    result = words.words()
    # Checking length of result
    assert  len(result) == 5

# Generated at 2022-06-23 22:00:36.515101
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    print(text.rgb_color(False))
    print(text.rgb_color(True))


# Generated at 2022-06-23 22:00:38.857001
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in ['critical','danger','attention']



# Generated at 2022-06-23 22:00:46.295114
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import Text

    rf = RussiaSpecProvider('ru')
    text = Text('ru')
    assert text.word()

    assert text.word() != rf.person.full_name(gender=Gender.FEMALE)
    assert text.word() != rf.person.full_name(gender=Gender.MALE)
    assert text.word() != rf.address.address()
    assert text.word() != rf.address.email()
    assert text.word() != rf.address.phone_number()
    

# Generated at 2022-06-23 22:00:48.013744
# Unit test for method answer of class Text
def test_Text_answer():
    # No error
    assert Text().answer()
    print(Text().answer())


# Generated at 2022-06-23 22:00:50.020194
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    color = Text().hex_color();
    assert (len(color) == 7 and color[0] == '#')


# Generated at 2022-06-23 22:00:52.315859
# Unit test for method sentence of class Text
def test_Text_sentence():
    g = Text()
    answer = g.sentence()
    print(answer)
    assert len(answer) > 0


# Generated at 2022-06-23 22:00:54.961561
# Unit test for method word of class Text
def test_Text_word():
    text = Text(seed=11)
    assert text.word() == 'science'


# Generated at 2022-06-23 22:01:03.908511
# Unit test for method answer of class Text
def test_Text_answer():
    a = Text()

# Generated at 2022-06-23 22:01:06.790474
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import DataField
    text = Text('en')
    assert text.color() in text.provider.data.get(DataField.COLOR)

# Generated at 2022-06-23 22:01:08.425647
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    res = t.hex_color(safe=True)
    assert res in SAFE_COLORS

# Generated at 2022-06-23 22:01:11.167597
# Unit test for method sentence of class Text
def test_Text_sentence():
    from faker import Faker
    fake = Faker()
    t = fake.sentence()
    x = fake.sentence(ext_word_list=None)
    assert isinstance(t, str)
    assert isinstance(x, str)

# Generated at 2022-06-23 22:01:12.487490
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    text.title()

# Generated at 2022-06-23 22:01:15.522450
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    #for i in range(10):
    #    print(text.hex_color())
    #print(text.hex_color())
    assert len(text.hex_color()) == 7


# Generated at 2022-06-23 22:01:17.359735
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data.get('level')

# Generated at 2022-06-23 22:01:18.339794
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    t.quote()

# Generated at 2022-06-23 22:01:20.080612
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    ret = text.text()
    assert (ret is not None)


# Generated at 2022-06-23 22:01:21.360806
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    print(t.swear_word())

# Generated at 2022-06-23 22:01:23.485920
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color()

if __name__ == '__main__':
    test_Text_color()

# Generated at 2022-06-23 22:01:24.487409
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    result = t.alphabet()
    assert t.alphabet() == result


# Generated at 2022-06-23 22:01:27.732804
# Unit test for method text of class Text
def test_Text_text():
    text = Text()

    result = text.text()
    assert result is not None
    assert type(result) == str
    assert len(result) > 0
