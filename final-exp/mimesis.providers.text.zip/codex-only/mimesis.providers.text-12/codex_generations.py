

# Generated at 2022-06-23 21:51:29.648495
# Unit test for method words of class Text
def test_Text_words():
    """Test method words of class Text."""
    text = Text()
    words = text.words()
    print(words)

# Generated at 2022-06-23 21:51:31.625883
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == "Whether to use a custom keymap"

# Generated at 2022-06-23 21:51:34.099439
# Unit test for method quote of class Text
def test_Text_quote():
    obj = Text()
    for i in range(100):
        s = obj.quote()
        if not isinstance(s, str):
            raise Exception


# Generated at 2022-06-23 21:51:35.140314
# Unit test for method quote of class Text
def test_Text_quote():
    obj_text = Text()
    for i in range(10):
        assert obj_text.quote()

# Generated at 2022-06-23 21:51:36.720710
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text('en')
    assert isinstance(text.quote(), str)

# Generated at 2022-06-23 21:51:38.560394
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    from mimesis import Text as T
    t = T()
    word = t.word()
    assert t.random.choice(t._data['words']['normal']) == word

# Generated at 2022-06-23 21:51:43.260036
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    ans = text.alphabet()
    ans == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
            'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert len(ans) == 26



# Generated at 2022-06-23 21:51:45.414790
# Unit test for method text of class Text
def test_Text_text():
    test_obj = Text()
    assert type(test_obj.text()) == str, 'Return value is not string'


# Generated at 2022-06-23 21:51:47.971742
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    x = text.answer()
    y = text.answer()
    z = text.answer()
    assert x != y != z != x

# Generated at 2022-06-23 21:51:50.438494
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    assert isinstance(t.level(), str)
    assert t.level() in ['low', 'medium', 'high', 'critical']


# Generated at 2022-06-23 21:51:53.252350
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert isinstance(text.rgb_color(), tuple)
    assert len(text.rgb_color()) == 3
    for i in text.rgb_color():
        assert 0 <= i < 256

# Generated at 2022-06-23 21:51:54.977777
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    print(text.word())


# Generated at 2022-06-23 21:51:58.293979
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text
    from mimesis.enums import Gender
    my_text = Text()
    my_text.gender = Gender.FEMALE # set gender for the class
    out = my_text.word()

# Generated at 2022-06-23 21:52:02.323990
# Unit test for method word of class Text
def test_Text_word():
    provider = Text()
    k = 0
    word = provider.word()
    while word is not '' and k < 100:
        k += 1
        word = provider.word()
    assert k == 100
    assert word is not ''


# Generated at 2022-06-23 21:52:04.166525
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    swearWord = t.swear_word()
    assert isinstance(swearWord, str)

# Generated at 2022-06-23 21:52:07.730222
# Unit test for method answer of class Text
def test_Text_answer():
    from random import randint

    rand = randint(1, 1_000)
    t = Text.__init__(rand)
    t.answer()
    assert t.answer() in t._data['answers']

# Generated at 2022-06-23 21:52:12.457026
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Dataset
    from mimesis.providers.text import Text

    t = Text(locale='en', dataset=Dataset.LITE)
    res = t.quote()
    assert res
    assert isinstance(res, str)

# Generated at 2022-06-23 21:52:14.352031
# Unit test for method level of class Text
def test_Text_level():
    """Test method level of class Text."""
    text = Text('es_ES')
    print(text.level())

# Generated at 2022-06-23 21:52:16.792624
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    # test lowercase
    assert 'a' in Text.alphabet(lower_case=True)
    # test uppercase
    assert 'A' in Text.alphabet(lower_case=False)

# Generated at 2022-06-23 21:52:18.173073
# Unit test for method color of class Text
def test_Text_color():
    assert Text().color() != Text().color()


# Generated at 2022-06-23 21:52:19.912633
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis import Text
    from pprint import pprint
    test = Text()
    pprint(test.quote())


# Generated at 2022-06-23 21:52:22.392971
# Unit test for method words of class Text
def test_Text_words():
    # Instantiate Text class
    t = Text()

    # Get 5 words
    print(t.words())

    # Get a word
    print(t.word())

# Generated at 2022-06-23 21:52:24.747664
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()

    print(t.hex_color(safe=True))
    print(t.hex_color())



# Generated at 2022-06-23 21:52:26.466075
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    print(t.level())


# Generated at 2022-06-23 21:52:27.210218
# Unit test for method title of class Text
def test_Text_title():
    tx = Text()
    title = tx.title()
    print("Title:", title)


# Generated at 2022-06-23 21:52:28.882183
# Unit test for method word of class Text
def test_Text_word():
    for _ in range(10):
        t = Text(seed = 777)
        assert t.word() == "table"

# Generated at 2022-06-23 21:52:32.110559
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_provider = Text()
    sentence = text_provider.sentence()
    assert len(sentence) > 0, "The sentence's length is zero"


# Generated at 2022-06-23 21:52:37.859292
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """
        This test pass IFF the method hex_color generate a hex color code.
    """
    text = Text()
    hex_color = text.hex_color()
    assert isinstance(hex_color, (str))
    assert len(hex_color) == 7
    assert hex_color[0] == "#"


# Generated at 2022-06-23 21:52:38.880106
# Unit test for method level of class Text
def test_Text_level():
    """The result is a string."""
    text = Text()
    print(text.level())


# Generated at 2022-06-23 21:52:42.768972
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color in [(252, 85, 32), (214, 52, 107),
                         (122, 42, 255), (42, 151, 255),
                         (37, 177, 56), (255, 177, 37)]

# Generated at 2022-06-23 21:52:44.896158
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-23 21:52:48.401576
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text(seed=4545)
    results = [text.rgb_color(safe=True) for _ in range(100)]
    print(results)


# Generated at 2022-06-23 21:52:53.137535
# Unit test for constructor of class Text
def test_Text():
    t = Text(seed=0)
    t.alphabet(lower_case=True)
    t.alphabet(lower_case=False)
    t.level()
    t.text(quantity=1)
    t.sentence()
    t.words()
    t.word()
    t.swear_word()
    t.quote()
    t.color()
    t.hex_color()
    t.hex_color(safe=True)
    t.rgb_color()
    t.rgb_color(safe=True)
    t.answer()

# Generated at 2022-06-23 21:52:54.479249
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    for i in range(20):
        print(t.color())

# Generated at 2022-06-23 21:52:57.225496
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text()

# Generated at 2022-06-23 21:52:58.634262
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    a = Text()
    print(a.rgb_color())

# Generated at 2022-06-23 21:53:02.565525
# Unit test for method level of class Text
def test_Text_level():
    i = 10
    levels = ['low', 'medium', 'high', 'critical']
    text = Text('en')
    for _ in range(i):
        result = text.level()
        assert result in levels

# Generated at 2022-06-23 21:53:12.599401
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.data import SAFE_COLORS
    from mimesis.enums import Color
    from mimesis.enums import Language
    from mimesis import Text
    cl = Text
    cl.Meta.language = Language.EN

    def create_hex_colors(safe: bool = False):
        length = len(SAFE_COLORS) if safe else len(SAFE_COLORS) + 1
        colors = set()
        for i in range(length):
            colors.add(cl.hex_color(safe))
        return colors

    assert len(create_hex_colors()) > len(SAFE_COLORS), 'No safe colors'
    assert len(create_hex_colors()) < len(SAFE_COLORS) + 1, 'Too many colors'

# Generated at 2022-06-23 21:53:15.808859
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    color = text.hex_color()
    assert isinstance(color, str)


# Generated at 2022-06-23 21:53:19.952588
# Unit test for method words of class Text
def test_Text_words():
    r = Text()
    r = Text()
    r = Text()
    print(r.words())
    print(r.words())
    print(r.words())
# print(r.words())
# print(r.words())


# Generated at 2022-06-23 21:53:21.651687
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text().rgb_color()
    if type(text) is tuple:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-23 21:53:25.378431
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    x = Text('en')
    assert isinstance(x.title(), str)
    x = Text(Locale.KAZAKH)
    assert isinstance(x.title(), str)


# Generated at 2022-06-23 21:53:28.287612
# Unit test for method words of class Text
def test_Text_words():
    sentence = Text()
    words = sentence.words(quantity=5)
    assert len(words) == 5
    print("Unit test for method words of class Text: PASSED!")


# Generated at 2022-06-23 21:53:29.978881
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-23 21:53:35.469799
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    for i in range(0, len(text.alphabet(True)), 5):
        print(text.alphabet(True)[i:i+5])
    print('\n')
    for i in range(0, len(text.alphabet()), 5):
        print(text.alphabet()[i:i+5])


# Generated at 2022-06-23 21:53:37.549065
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    fr = t.answer()
    en = t.answer()
    assert fr == 'Non'
    assert en == 'No'

# Generated at 2022-06-23 21:53:40.178088
# Unit test for constructor of class Text
def test_Text():
    # instantiate
    x = Text()

    # run
    result = x.word()

    # assert
    assert isinstance(result, str)

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-23 21:53:41.605889
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(locale='en')
    assert isinstance(text.answer(), str)


# Generated at 2022-06-23 21:53:43.818635
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert Text.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-23 21:53:45.162243
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    text.answer() == 'No'

# Generated at 2022-06-23 21:53:47.475679
# Unit test for method quote of class Text
def test_Text_quote():
    actual = Text().quote()
    expected = "Bond... James Bond"
    assert actual == expected


# Generated at 2022-06-23 21:53:49.226518
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    assert isinstance(txt, Text)

# Generated at 2022-06-23 21:53:53.635176
# Unit test for constructor of class Text
def test_Text():
    _t = Text()
    assert _t.title() in _t._data['text']
    assert _t.words() in _t._data['words'].get('normal')
    assert _t.color() in _t._data['color']

# Generated at 2022-06-23 21:54:01.320585
# Unit test for method color of class Text
def test_Text_color():
    """Test method color of class Text."""
    text = Text('en')

# Generated at 2022-06-23 21:54:02.376971
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    result = text.hex_color(safe=True)
    assert isinstance(result, str) and result.startswith('#')


# Generated at 2022-06-23 21:54:03.223822
# Unit test for method color of class Text
def test_Text_color():
    word = Text()
    assert isinstance(word.color(), str)

# Generated at 2022-06-23 21:54:07.885897
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    try:
        text = Text()
        assert text.rgb_color(safe=True) in SAFE_COLORS
    except Exception as e:
        print(e)


# Generated at 2022-06-23 21:54:10.299122
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words = t.words()
    assert 50 > len(' '.join(words)) > 10



# Generated at 2022-06-23 21:54:13.412096
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Locales
    text_1 = Text(Locales.EN)
    sentence = text_1.sentence()
    assert sentence != text_1.sentence()


# Generated at 2022-06-23 21:54:14.539043
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert isinstance(text.title(), str)


# Generated at 2022-06-23 21:54:16.756539
# Unit test for method word of class Text
def test_Text_word():
    print("\nUnit test for method word of class Text")
    text = Text('en')
    for i in range(50):
        print(text.word())


# Generated at 2022-06-23 21:54:19.282081
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert '#' in Text().hex_color()
    assert '#' in Text(seed=1).hex_color()
    assert '#' in Text(seed=2).hex_color()


# Generated at 2022-06-23 21:54:21.088957
# Unit test for method level of class Text
def test_Text_level():
    data = Text()
    for _ in range(10):
        level = data.level()
        assert level in data._data['level']


# Generated at 2022-06-23 21:54:29.798904
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    result = text.text()
    assert result == "Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae Itaque earum rerum hic tenetur a sapiente delectu, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat."


# Generated at 2022-06-23 21:54:30.596342
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color()



# Generated at 2022-06-23 21:54:41.964705
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7
    assert len(text.hex_color()) == 7

# Generated at 2022-06-23 21:54:44.150540
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    for _ in range(10):
        sentence = text.sentence()
        assert len(sentence) > 0


# Generated at 2022-06-23 21:54:45.730530
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    res = text.level()
    assert res in text._data['level']



# Generated at 2022-06-23 21:54:47.901040
# Unit test for constructor of class Text
def test_Text():
    # Initialize an instance of Text
    t = Text()
    # Check if the result is correct
    assert t.answer() in t._data['answers']

# Generated at 2022-06-23 21:54:50.384116
# Unit test for method word of class Text
def test_Text_word():
    from mimesis import Text
    from mimesis.builtins import RussiaSpecProvider
    text = Text(RussiaSpecProvider)
    assert isinstance(text.word(), str)


# Generated at 2022-06-23 21:54:52.378632
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    data = Text()
    data._init_provider()
    print("Text.alphabet(""'lower_case'=False)")
    print("==>",data.alphabet())


# Generated at 2022-06-23 21:54:53.685111
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text.quote() == '"Bond... James Bond."'


# Generated at 2022-06-23 21:54:58.229434
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()

# Generated at 2022-06-23 21:55:01.465865
# Unit test for method hex_color of class Text
def test_Text_hex_color():

    text = Text()
    assert len(text.hex_color(safe=True)) > 0
    assert len(text.hex_color(safe=False)) > 0



# Generated at 2022-06-23 21:55:02.468876
# Unit test for method answer of class Text
def test_Text_answer():
    print(Text().answer())


# Generated at 2022-06-23 21:55:04.812219
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text"""
    # Assert that word is not empty
    assert len(Text().word()) > 0

# Generated at 2022-06-23 21:55:06.154465
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert len(t.color()) == 3


# Generated at 2022-06-23 21:55:07.198690
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    test = Text()
    assert isinstance(test.rgb_color(), tuple)


# Generated at 2022-06-23 21:55:13.212607
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins import Text as TextCls
    t = TextCls()
    words = t.words()
    assert isinstance(words, list)
    assert len(words) == 5
    assert all(map(lambda x: isinstance(x, str), words))

    words = t.words(quantity=2)
    assert isinstance(words, list)
    assert len(words) == 2
    assert all(map(lambda x: isinstance(x, str), words))


# Generated at 2022-06-23 21:55:15.072654
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Default locale.
    t = Text()
    result = t.sentence()
    assert result is not None

# Generated at 2022-06-23 21:55:16.317723
# Unit test for method level of class Text
def test_Text_level():
    text = Text(seed=123)
    result = text.level()
    assert result == 'Low'


# Generated at 2022-06-23 21:55:19.524494
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import DataField
    from mimesis.builtins import RussianSpecProvider

    x = RussianSpecProvider('ru')
    x.seed(123)
    assert x.color() == 'Синий'

# Generated at 2022-06-23 21:55:22.435994
# Unit test for method quote of class Text
def test_Text_quote():
    text=Text()
    s=text.quote()
    assert (type(s)==str)
    print(s)
    #assert (type(s)==str)


# Generated at 2022-06-23 21:55:25.060527
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    text = Text('en')
    result = text.quote()
    assert result is not None


# Generated at 2022-06-23 21:55:29.068850
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() == (240, 91, 118)
    assert Text().rgb_color(safe=True) == (0, 0, 0)

# Generated at 2022-06-23 21:55:30.261214
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    print(t.sentence())

# Generated at 2022-06-23 21:55:31.264680
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    t.__class__ == Text

# Generated at 2022-06-23 21:55:33.235245
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    res = t.rgb_color()
    assert isinstance(res, tuple)

# Generated at 2022-06-23 21:55:37.510518
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Language
    from mimesis.builtins import Text as Text_
    for _ in range(100):
        text = Text_(language=Language.EN)
        sentence = text.sentence()
        # print(sentence)
        assert isinstance(sentence, str)


# Generated at 2022-06-23 21:55:38.719169
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    print(t.color())


# Generated at 2022-06-23 21:55:41.811518
# Unit test for method color of class Text
def test_Text_color():
    text = Text('en')
    for i in range(100):
        color = text.color()
        assert isinstance(color, str)

# Generated at 2022-06-23 21:55:44.136847
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No', 'Maybe']


# Generated at 2022-06-23 21:55:47.366190
# Unit test for method sentence of class Text
def test_Text_sentence():
    # Set up
    text = Text()

    # Exercise

    # Verify
    assert type(text.sentence()) == str


# Generated at 2022-06-23 21:55:51.126273
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in ['critical','moderate','low','normal','danger','minor','major','safe','ok','high','urgent','high','safe','warning']


# Generated at 2022-06-23 21:55:53.024164
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']


# Generated at 2022-06-23 21:55:55.949475
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.providers.text import Text
    from mimesis import DataGenerator
    t = Text(DataGenerator())
    assert t.hex_color().startswith('#') == True

# Generated at 2022-06-23 21:56:00.361287
# Unit test for method words of class Text
def test_Text_words():
    """The test for the Word method of class Text"""
    from mimesis.builtins import TextEn
    text = TextEn()
    assert len(text.words(quantity=1)) == 1
    assert len(text.words(quantity=3)) == 3
    assert len(text.words(quantity=100)) == 100


# Generated at 2022-06-23 21:56:04.195824
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    data = t.alphabet()
    assert len(data) == 26
    data = t.alphabet(lower_case=True)
    assert len(data) == 26

# Generated at 2022-06-23 21:56:07.590473
# Unit test for method color of class Text
def test_Text_color():
    directory = '/app'
    provider = Text(locale='en')
    color = provider.color()
    print("Random Color ")
    print(color)

#Unit test for method word of class Text

# Generated at 2022-06-23 21:56:11.770292
# Unit test for method text of class Text
def test_Text_text():
    tx = Text()
    for _ in range(10):
        result = tx.text()
        assert result
        assert len(result) >= 5
    result = tx.text(quantity=7)
    assert result
    assert len(result) >= 7


# Generated at 2022-06-23 21:56:13.179716
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    t.title()


# Generated at 2022-06-23 21:56:16.445121
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    color = t.hex_color()
    assert len(color) == 7
    assert color.startswith('#')
    assert isinstance(color, str)
    assert color != t.hex_color()


# Generated at 2022-06-23 21:56:18.212203
# Unit test for method alphabet of class Text
def test_Text_alphabet():
   
    text = Text('en')

    text.alphabet()

    text.alphabet(lower_case=True)

# Generated at 2022-06-23 21:56:20.670671
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    x = Text()
    assert x.hex_color(safe=True) in SAFE_COLORS
    assert x.hex_color(safe=False) not in SAFE_COLORS

# Generated at 2022-06-23 21:56:23.187073
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussiaSpecProvider
    t = Text(RussiaSpecProvider)
    print(t.sentence())

# Generated at 2022-06-23 21:56:31.478226
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider

    rus = RussiaSpecProvider()
    us = USASpecProvider()

    quantity = 5
    a_rus = rus.text.words(quantity=quantity)
    a_us = us.text.words(quantity=quantity)

    assert len(a_rus) == len(a_us) == quantity

    rus_man = rus.person(gender=Gender.MALE)
    rus_woman = rus.person(gender=Gender.FEMALE)

    rus_man_name = rus_man.name()
    rus_woman_name = rus_woman.name()


# Generated at 2022-06-23 21:56:34.364027
# Unit test for method sentence of class Text
def test_Text_sentence():
    en = Text(locale = 'en')
    assert en.sentence() == "I know this doesn't mean anything."


# Generated at 2022-06-23 21:56:36.718685
# Unit test for method answer of class Text
def test_Text_answer():
    test_obj = Text(locale="en")
    test_result = test_obj.answer()
    assert isinstance(test_result, str)


# Generated at 2022-06-23 21:56:38.941242
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text
    text = Text()
    assert type(text.word()) == str


# Generated at 2022-06-23 21:56:42.679311
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    data = text.sentence()
    assert isinstance(data, str)
    assert data.endswith(".")
    assert data.istitle()


# Generated at 2022-06-23 21:56:47.629177
# Unit test for method rgb_color of class Text
def test_Text_rgb_color(): #Unit test for Text.rgb_color()
    # Test with safe set to true
    print("Test with safe set to true:", Text('en').rgb_color(True))
    # Test with safe set to false
    print("Test with safe set to false:", Text('en').rgb_color(False))

# Generated at 2022-06-23 21:56:49.041574
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    text.level() # NOSONAR

# Generated at 2022-06-23 21:56:51.230808
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.builtins import Text as Text_
    txt = Text_('en')
    result = txt.word()
    assert result


# Generated at 2022-06-23 21:56:51.866545
# Unit test for method answer of class Text
def test_Text_answer():
    Text().answer()

# Generated at 2022-06-23 21:56:55.306188
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locales
    
    for locale in Locales:
        text = Text(locale)
        color = text.color()
        assert isinstance(color, str)


# Generated at 2022-06-23 21:56:57.066094
# Unit test for method quote of class Text
def test_Text_quote():
    result = Text().quote()
    assert result
    assert isinstance(result, str)


# Generated at 2022-06-23 21:56:59.508610
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    from mimesis.text import Text
    t = Text()
    assert len(t.word()) >= 3

# Generated at 2022-06-23 21:57:02.863906
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    text = Text('en','zh')

    assert text.words(1) != None
    assert text.words(0) == None

    assert text.words(2) != text.words(3)


# Generated at 2022-06-23 21:57:04.968414
# Unit test for method word of class Text
def test_Text_word():
    text = Text('en')
    word = text.word()
    assert word == "Science"

if __name__ == "__main__":
    test_Text_word()

# Generated at 2022-06-23 21:57:07.706525
# Unit test for method text of class Text
def test_Text_text():
    """Unit test for method text of the class Text."""
    text = Text()
    assert isinstance(text.text(quantity=1), str)


# Generated at 2022-06-23 21:57:09.263330
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    print(word)
    assert word


# Generated at 2022-06-23 21:57:14.225045
# Unit test for method word of class Text
def test_Text_word():
    # This method doesn't have a meaningful test
    # as it returns a random word
    # and this test is prone to fail when a word
    # is added or removed from the text.json file
    # but the test is kept in order to be
    # consistent with other tests in this project.
    assert Text.word()

# Generated at 2022-06-23 21:57:16.618605
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    _obj = Text()
    result = _obj.hex_color()
    print(result)
    assert len(result) == 7

# Generated at 2022-06-23 21:57:18.807778
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    color = t.color()
    assert isinstance(color, str)
    assert len(color) > 0

# Generated at 2022-06-23 21:57:23.266665
# Unit test for method quote of class Text
def test_Text_quote():
    text_class_obj = Text()
    sample_quotes = text_class_obj.quote()
    print(sample_quotes)
    #assert len(sample_quotes) ==
    #assert sample_quotes in text_class_obj._data['quotes']


# Generated at 2022-06-23 21:57:24.468913
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    print(t.title())


# Generated at 2022-06-23 21:57:25.671965
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text()
    print(txt.quote())


# Generated at 2022-06-23 21:57:29.672171
# Unit test for method quote of class Text
def test_Text_quote():
    """Test to assure that the method quote returns a string
    """
    tclass = Text()
    quote = tclass.quote()
    assert type(quote) is str


# Generated at 2022-06-23 21:57:30.886315
# Unit test for method quote of class Text
def test_Text_quote():
    a = Text()
    print(a.quote())
    print(a.quote())
    print(a.quote())

# test_Text_quote()

# Generated at 2022-06-23 21:57:33.793726
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # GIVEN
    text = Text()
    # WHEN
    result = text.rgb_color()
    # THEN
    assert isinstance(result, tuple)

test_Text_rgb_color()

# Generated at 2022-06-23 21:57:45.503039
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import Color


# Generated at 2022-06-23 21:57:48.712378
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text('en')
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert all(isinstance(color, int) for color in rgb_color)
    # TODO: Write more tests for method rgb_color of class Text


# Generated at 2022-06-23 21:57:53.034961
# Unit test for constructor of class Text
def test_Text():  # NOTICE: Assume that all functions run correctly
    '''
    This unit test is to make sure that the constructor works correctly
    '''
    # Constructor must work correctly
    assert Text(seed=0).__class__.__name__ == 'Text'


# Generated at 2022-06-23 21:57:54.545362
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level is not None



# Generated at 2022-06-23 21:57:58.383703
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    swear_words = text._data['words'].get('bad')
    assert swear_word in swear_words

# Generated at 2022-06-23 21:58:08.640879
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from .utils import Testable
    from mimesis import Fake


    class TestText(Testable):
        """Test Text class."""

        def setUp(self):
            """Set up attributes for testing."""
            self.provider = Text(locale=Locale.EN)

        def test_title(self):
            result = self.provider.title()
            self.assertIsInstance(result, str)

        def test_text(self):
            result = self.provider.text()
            self.assertIsInstance(result, str)

        def test_sentence(self):
            result = self.provider.sentence()
            self.assertIsInstance(result, str)


# Generated at 2022-06-23 21:58:10.176492
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=3)
    print(words)

# Generated at 2022-06-23 21:58:11.114404
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert len(t.swear_word()) == 4

# Generated at 2022-06-23 21:58:12.328473
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str)


# Generated at 2022-06-23 21:58:23.215817
# Unit test for method title of class Text
def test_Text_title():
    # В одном из тестов возникает исключение: в инициализаторе класса Text
    # для значения поля _datafile указывается имя файла 'text.json', но файл
    # с таким именем отсутствует в рабочей директории
    return True

# Generated at 2022-06-23 21:58:29.528691
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test that the method Text.hex_color returns a hex color code.

    :return: A hex color code.
    """
    sample = Text()
    hex_color = sample.hex_color()

    assert isinstance(hex_color, str)
    assert hex_color.startswith('#')
    assert len(hex_color) == 7


# Generated at 2022-06-23 21:58:30.531846
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word()


# Generated at 2022-06-23 21:58:33.495685
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alph = text.alphabet()
    assert len(alph) > 0, "Not working with method alphabet"
    assert isinstance(alph, list), "Not working with method alphabet"

# Generated at 2022-06-23 21:58:36.255620
# Unit test for method text of class Text
def test_Text_text():
    from mimesis import Text
    t = Text()
    assert len(t.text()) <= 28
    assert t.text().endswith('.')
    assert t.text().isalpha() == False


# Generated at 2022-06-23 21:58:38.218617
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    print(t.swear_word())


if __name__ == '__main__':
    test_Text_swear_word()

# Generated at 2022-06-23 21:58:42.179558
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text(seed=1)
    assert t.rgb_color() == (135, 41, 137)
    assert t.rgb_color(safe=False) == (135, 41, 137)
    assert t.rgb_color(safe=True) == (66, 165, 245)

# Generated at 2022-06-23 21:58:45.661110
# Unit test for method words of class Text
def test_Text_words():
    rng_words_list = Text().words(quantity=10)
    assert len(rng_words_list) == 10


# Generated at 2022-06-23 21:58:48.403315
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import Text

    x = Text().color()
    # assert x is not ""
    assert isinstance(x, str)


# Generated at 2022-06-23 21:58:53.908803
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    t = Text()
    output = t.level()
    # Unit test function
    assert isinstance(output, str)
    assert len(output) > 0
    # Unit test subclass Meta
    assert isinstance(t.Meta.name, str)
    assert len(t.Meta.name) > 0


# Generated at 2022-06-23 21:58:55.204746
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert len(t.word()) != 0
    assert type(t.word()) == str 


# Generated at 2022-06-23 21:58:57.957233
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() in text._data['color']



# Generated at 2022-06-23 21:58:59.209795
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    result = text.words()
    assert len(result) == 5


# Generated at 2022-06-23 21:59:03.530534
# Unit test for constructor of class Text
def test_Text():
    """Assert Text() uses data from text.json."""
    # Instantiate provider
    provider = Text()

    # Check that text.json exists in the data dir
    assert provider._datafile in provider._files

    # Check that there is no switch key word in text.json
    assert 'switch' not in provider._data

# Generated at 2022-06-23 21:59:05.211633
# Unit test for method color of class Text
def test_Text_color():
    """Test for color method of class Text."""
    t = Text()
    color = t.color()
    assert isinstance(color,str)
    

# Generated at 2022-06-23 21:59:07.745759
# Unit test for method sentence of class Text
def test_Text_sentence():
    tmp = Text()
    assert len(tmp.sentence()) > 0  # NOPEP8


# Generated at 2022-06-23 21:59:08.955805
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3
    assert len(t.rgb_color(True)) == 3

# Generated at 2022-06-23 21:59:13.426281
# Unit test for constructor of class Text
def test_Text():
  text = Text()
  print(text.alphabet(False))
  print(text.alphabet(True))
  print(text.level())
  print(text.text(quantity = 5))
  print(text.words(quantity = 5))
  print(text.quote())
  print(text.color())
  print(text.hex_color())
  print(text.rgb_color(False))
  print(text.answer())


# Generated at 2022-06-23 21:59:14.501916
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None

# Generated at 2022-06-23 21:59:23.328478
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    base = Text()
    assert base.alphabet(True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                                   's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    assert base.alphabet(False) == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                    'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert base.alphabet(True)

# Generated at 2022-06-23 21:59:27.110839
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    c = Text(seed=12345)
    print(c.hex_color())
    print(c.hex_color())
    print(c.hex_color())


# Generated at 2022-06-23 21:59:30.341199
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test method swear_word of class Text."""
    text = Text()
    assert text.swear_word() == 'Damn'

# Generated at 2022-06-23 21:59:32.719429
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    print("\n--------- test_Text_rgb_color() -----------------")
    text = Text()
    for _ in range(10):
        print(text.rgb_color())

# Generated at 2022-06-23 21:59:38.513526
# Unit test for method title of class Text
def test_Text_title():
    """Test result of function title."""
    # Russian locale
    text = Text(locale='ru')
    title_ru = text.title()
    print(title_ru)
    print(type(title_ru))
    assert isinstance(title_ru, str)
    assert title_ru.isupper()
    assert len(title_ru.split(' ')) > 2
    # English locale
    text = Text(locale='en')
    title_en = text.title()
    print(title_en)
    print(type(title_en))
    assert isinstance(title_en, str)
    assert title_en.isupper()
    assert len(title_en.split(' ')) > 2

# Generated at 2022-06-23 21:59:39.297436
# Unit test for method text of class Text
def test_Text_text(): # pragma: no cover
    text = Text()
    assert text.text() is not None

# Generated at 2022-06-23 21:59:41.056729
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    assert isinstance(rgb, tuple)
    assert len(rgb) == 3

# Generated at 2022-06-23 21:59:45.562612
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    gen_sentence = text.sentence()
    assert len(gen_sentence) > 0
    assert gen_sentence.endswith('.')


# Generated at 2022-06-23 21:59:47.268668
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text(seed=1)
    assert t.answer() == 'Yes'


# Generated at 2022-06-23 21:59:57.700167
# Unit test for constructor of class Text
def test_Text():
    # Create an instance of Text class
    text = Text()
    # Get the alphabet of current locale
    alphabet = text.alphabet()
    assert len(alphabet) > 0
    # Get the title
    title = text.title()
    assert len(title) > 0
    # Get a random text
    _text = text.text()
    assert len(_text) > 0
    # Get a random quote
    quote = text.quote()
    assert len(quote) > 0
    # Get a random word
    word = text.word()
    assert len(word) > 0
    # Get a random word list
    word_list = text.words()
    assert len(word_list) > 0
    # Get a random hex color
    hex_color = text.hex_color()
    assert len(hex_color) > 0


# Generated at 2022-06-23 21:59:59.586544
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']


# Generated at 2022-06-23 22:00:00.653057
# Unit test for constructor of class Text
def test_Text():
    provider = Text('en')
    assert provider


# Generated at 2022-06-23 22:00:08.198086
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import IntervalDirection
    from mimesis.builtins import RussianSpecProvider
    import re

    t = Text('ru')
    t_override = Text('ru', seed=42)
    r = RussianSpecProvider()

    assert isinstance(t.level(), str)
    assert re.match('^[А-яёЁ]', t.level())
    assert t.level(direction=IntervalDirection.LEFT) in r.intervals()


# Generated at 2022-06-23 22:00:14.054471
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import random
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    random.seed(12345678)
    words = ['heck', 'hell', 'damn', 'butt', 'bum', 'arse', 'bollocks']
    text = Text(locale=Locale.ENGLISH)
    assert text.swear_word() in words

# Generated at 2022-06-23 22:00:15.570839
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert isinstance(t.words(), list)


# Generated at 2022-06-23 22:00:17.965280
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    word = text.swear_word()
    assert word in text._data['words']['bad']

# Generated at 2022-06-23 22:00:20.498171
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.providers.text import Text
    t = Text()
    color = t.color()
    assert isinstance(color, str)


# Generated at 2022-06-23 22:00:25.136996
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import CardinalDirection
    from mimesis.providers.text import Text

    t = Text()
    print("Text.level : ", t.level())
    print("Text.level : ", t.level())
    print("Text.level : ", t.level())
    print("Text.level : ", t.level())
    print("Text.level : ", t.level())


# Generated at 2022-06-23 22:00:27.961075
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    word = text.swear_word()
    assert word


# Generated at 2022-06-23 22:00:29.628953
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert isinstance(t.title(), str)

# Generated at 2022-06-23 22:00:32.347341
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    result = text.answer()
    assert isinstance(result, str)


# Generated at 2022-06-23 22:00:34.818155
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    answer = t.hex_color()

    if len(answer) != 7:
        raise ValueError('The hex color format is incorrect')


# Generated at 2022-06-23 22:00:36.139224
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert len(text.title()) > 0


# Generated at 2022-06-23 22:00:44.826477
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Method test_Text_alphabet."""
    from mimesis.enums import Language
    from mimesis.local import Local
    from mimesis.data import DEFAULT_LOCALE

    locale = Local(language=Language.EN)
    t = Text(locale=locale)
    alphabet_uppercase = t.alphabet(lower_case=False)
    alphabet_lowercase = t.alphabet(lower_case=True)

# Generated at 2022-06-23 22:00:46.535781
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ["True", "Yes", "No", "False"]


# Generated at 2022-06-23 22:00:49.001279
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    dictionary = t._data['words'].get('normal')
    assert t.words() in dictionary
    assert t.words(quantity=10) in dictionary

# Generated at 2022-06-23 22:00:50.673292
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in text._data.get('answers')

# Generated at 2022-06-23 22:00:53.579515
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-23 22:00:56.641566
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    text = t.text()
    assert isinstance(text, str)
    assert text.startswith('He')


# Generated at 2022-06-23 22:00:59.470665
# Unit test for method words of class Text
def test_Text_words():
    a = Text()
    #print(a.words())
    #print(a.words(10))
    pass

# Unittest for method word of class Text

# Generated at 2022-06-23 22:01:01.569332
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color() of class Text."""
    text = Text('en')
    assert text.color() in text._data['color']


# Generated at 2022-06-23 22:01:03.630631
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence().__class__.__name__ == 'str', 'fail'


# Generated at 2022-06-23 22:01:06.532210
# Unit test for method words of class Text
def test_Text_words():
    text = Text()  # instance of class Text
    word_list = text.words(6) # list of words
    print(word_list)



# Generated at 2022-06-23 22:01:09.169706
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    rgb = Text().rgb_color()
    for i in range(len(rgb)):
        assert 0 <= rgb[i] <= 255, "Value must be in the range of 0 - 255"


# Generated at 2022-06-23 22:01:11.834276
# Unit test for method word of class Text
def test_Text_word():
    # Initialize an object of class Text
    word = Text()
    # Get a random word
    random_word = word.word()
    print('Random word: ', random_word)
    assert random_word


# Generated at 2022-06-23 22:01:14.326556
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color() == (252, 85, 32)
    assert Text().rgb_color(safe=True) == (41, 128, 185)
    assert Text().rgb_color(safe=False) == (0, 105, 139)

# Generated at 2022-06-23 22:01:15.261253
# Unit test for method title of class Text
def test_Text_title():
    Text().title()


# Generated at 2022-06-23 22:01:19.086866
# Unit test for method words of class Text
def test_Text_words():
    list_of_str = Text().words(quantity = 5)
    for s in list_of_str:
        assert(len(s) >= 2)
        assert(s.isalpha() == True)


# Generated at 2022-06-23 22:01:23.775427
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    text1 = t.swear_word()
    text2 = t.swear_word()
    text3 = t.swear_word()
    text4 = t.swear_word()
    listText = t.swear_word()
    assert text1 == text2 == text3 == text4
    assert type(listText) == str


# Generated at 2022-06-23 22:01:25.988615
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None


# Generated at 2022-06-23 22:01:29.023936
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    locale = ['en', 'ru', 'zh']
    for _ in locale:
        t = Text(_)
        swear_word = t.swear_word()
        assert swear_word in t._data['words']['bad']
