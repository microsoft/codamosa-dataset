

# Generated at 2022-06-12 02:37:14.108731
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']



# Generated at 2022-06-12 02:37:16.697859
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in ["critical", "high", "medium", "low"]


# Generated at 2022-06-12 02:37:18.854261
# Unit test for method words of class Text
def test_Text_words():
    m = Text(seed=123456789)
    assert len(m.words(quantity=10)) == 10


# Generated at 2022-06-12 02:37:21.989032
# Unit test for method text of class Text
def test_Text_text():
    from mimesis import Text
    from mimesis.typing import Seed

    t = Text('en')
    t.seed(Seed(5))
    print(t.text())


# Generated at 2022-06-12 02:37:26.046909
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    result = text.words(quantity=5)
    assert result is not None
    assert len(result) == 5
    assert isinstance(result, list)



# Generated at 2022-06-12 02:37:31.443763
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    x = t.words()
    y = t.words(quantity=3)
    assert isinstance(x, list)
    assert isinstance(y, list)
    for w in x:
        assert isinstance(w, str)
    for w in y:
        assert isinstance(w, str)


# Generated at 2022-06-12 02:37:36.305895
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Test the alphabet method of Text class."""
    print('Test for method alphabet of class Text')
    t = Text(seed=1234567890)
    print('\tTest for return alphabet in uppercase')
    print(t.alphabet())
    print('\tTest for return alphabet in lowercase')
    print(t.alphabet(lower_case=True))


# Generated at 2022-06-12 02:37:37.808357
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text(seed=0).swear_word() == 'Damned'

# Generated at 2022-06-12 02:37:40.358683
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() != ''

# Generated at 2022-06-12 02:37:47.179726
# Unit test for method words of class Text
def test_Text_words():
    # Test by default
    text = Text()
    assert isinstance(text.words(), list)
    assert len(text.words()) == 5

    # Test with different number
    assert len(text.words(quantity=1)) == 1
    assert len(text.words(quantity=10)) == 10


# Generated at 2022-06-12 02:41:09.464365
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color in text._data['color']

# Generated at 2022-06-12 02:41:12.714129
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    m = Text()
    assert type(m.swear_word()) == str


# Generated at 2022-06-12 02:41:17.295930
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """
    input:
        123456789

    ouput:
        0123456789
    """
    t = Text()
    result = t.alphabet()
    assert len(result) == 26


# Generated at 2022-06-12 02:41:23.024352
# Unit test for constructor of class Text
def test_Text():
	Text()


# Generated at 2022-06-12 02:41:28.245429
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    result = text.rgb_color(safe=True)
    if not isinstance(result, tuple):
        print(result)
        raise Exception('Unit tests failed')

# Generated at 2022-06-12 02:41:37.084215
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print("------------------Method swear_word of class Text------------------")
    print("Test: Swear word")
    texter = Text()
    print("English: " + texter.swear_word())
    print("Spanish: " + texter.swear_word())
    print("Japanese: " + texter.swear_word())
    print("Chinese: " + texter.swear_word())


# Generated at 2022-06-12 02:41:41.694048
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert isinstance(text.rgb_color(), tuple)
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3


# Generated at 2022-06-12 02:41:45.669131
# Unit test for method quote of class Text
def test_Text_quote():
    # Test with seed
    t = Text(seed=0)
    assert t.quote() == '''“What we do in life echoes in eternity.”'''
    # Test without seed
    t = Text()
    assert t.quote() in ['“What we do in life echoes in eternity.”', '“Show me the money.”']


# Generated at 2022-06-12 02:41:49.416018
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    test_text = text.text()
    assert test_text != ""


# Generated at 2022-06-12 02:41:52.309778
# Unit test for constructor of class Text
def test_Text():
    # Instantiating the object
    obj = Text()
    # Check instance of class Text
    assert isinstance(obj, Text)