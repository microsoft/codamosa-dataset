

# Generated at 2022-06-12 02:37:32.305886
# Unit test for method level of class Text
def test_Text_level():
    t = Text(seed=42)
    print(t.level())


# Generated at 2022-06-12 02:37:33.692627
# Unit test for method words of class Text
def test_Text_words():
    pass


# Generated at 2022-06-12 02:37:35.254777
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    print(t.text(quantity=2))
    

# Generated at 2022-06-12 02:37:37.080319
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    x = t.sentence()
    assert x is not None
    assert len(x) > 0


# Generated at 2022-06-12 02:37:38.853894
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    print(t.level())


# Generated at 2022-06-12 02:37:41.933822
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    tm = Text()
    assert len(tm.hex_color()) == 7


# Generated at 2022-06-12 02:37:50.176958
# Unit test for method word of class Text
def test_Text_word():
    print('Text.word()')
    text = Text()
    # print('Text.word(): {}'.format(text.word()))
    # print('Text.word(): {}'.format(text.word()))
    # print('Text.word(): {}'.format(text.word()))
    # print('Text.word(): {}'.format(text.word()))
    for i in range(10):
        print('Text.word(): {}'.format(text.word()))



# Generated at 2022-06-12 02:37:53.002854
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    sentence = t.sentence()
    assert sentence
    print(sentence)


# Generated at 2022-06-12 02:37:54.367992
# Unit test for method title of class Text
def test_Text_title():
    result = Text().title()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-12 02:37:57.263062
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())


# Generated at 2022-06-12 02:40:59.966296
# Unit test for method title of class Text
def test_Text_title():
    text = Text('zh')
    text.text()
    text.title()



# Generated at 2022-06-12 02:41:09.558656
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.alphabet() == list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert t.alphabet(lower_case=True) == list('abcdefghijklmnopqrstuvwxyz')
    assert type(t.level()) == str
    assert type(t.text()) == str
    assert type(t.sentence()) == str
    assert type(t.title()) == str
    assert type(t.words()) == list
    assert type(t.words(quantity=1)) == list
    assert type(t.word()) == str
    assert type(t.swear_word()) == str
    assert type(t.quote()) == str
    assert type(t.color()) == str
    assert type(t.hex_color()) == str

# Generated at 2022-06-12 02:41:12.336988
# Unit test for method answer of class Text
def test_Text_answer():
    answer = Text().answer()
    assert type(answer) == str
    assert len(answer) != 0



# Generated at 2022-06-12 02:41:13.127746
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    print(text.words())

# Generated at 2022-06-12 02:41:14.239103
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    p = Text()
    assert len(p.alphabet()) == 26


# Generated at 2022-06-12 02:41:20.794624
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    from mimesis.enums import Locales
    from mimesis.data import SAFE_COLORS
    from mimesis.text import Text
    T = Text(locale=Locales.EN)
    assert T.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert T.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-12 02:41:26.077574
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    testing_data = {}
    for i in range(10):
        ans = text.word()
        testing_data[ans] = testing_data.get(ans, 0) + 1
    print(testing_data)


# Generated at 2022-06-12 02:41:28.786691
# Unit test for constructor of class Text
def test_Text():
    """Basic unit test for class Text"""
    text_obj = Text()
    assert(text_obj is not None)

# Generated at 2022-06-12 02:41:30.642847
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.providers.text import Text
    t = Text()
    print(t.word())


# Generated at 2022-06-12 02:41:32.299518
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert alphabet != ' ' or alphabet != '' or alphabet != [] or alphabet != () or alphabet != ''


# Generated at 2022-06-12 02:46:21.781189
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    s = text.words()
    assert(len(s) > 0)

# Generated at 2022-06-12 02:46:27.318735
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    a = Text()
    b = Text()
    if a.swear_word() != b.swear_word():
        print("Text_swear_word_test: Success")
    else:
        print("Text_swear_word_test: Failed")
