

# Generated at 2022-06-12 02:36:40.668207
# Unit test for method answer of class Text
def test_Text_answer():
    """Unit test for method answer of class Text."""
    text = Text()
    assert text.answer() in text._data['answers']

# Generated at 2022-06-12 02:36:45.271180
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    from datetime import datetime
    now = datetime.now()
    print ("Current date and time : ", now.strftime("%Y-%m-%d %H:%M:%S"))
    print(text.sentence())
    assert isinstance(text.sentence(), str)

#Unit test for method words of class Text

# Generated at 2022-06-12 02:36:47.837055
# Unit test for method quote of class Text
def test_Text_quote():
    t  = Text()
    assert t.quote() !=""


# Generated at 2022-06-12 02:36:50.632277
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)

# Generated at 2022-06-12 02:36:55.231370
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    a = text.alphabet()
    b = text.alphabet(lower_case=True)
    print(a)
    print(b)


# Generated at 2022-06-12 02:37:05.100728
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    word = text.color()
    assert len(word) > 1



# Generated at 2022-06-12 02:37:11.099248
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) >= 10
    assert len(title) <= 50


# Generated at 2022-06-12 02:37:14.418110
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Unit test for method rgb_color of class Text."""
    txt = Text()
    rgb = txt.rgb_color()
    assert len(rgb) == 3
    for el in rgb:
        assert 0 <= el <= 255

# Generated at 2022-06-12 02:37:16.967629
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    word = t.word()
    assert len(word) > 0


# Generated at 2022-06-12 02:37:22.337682
# Unit test for method level of class Text
def test_Text_level():
    """Test for the Text.level method."""
    from mimesis.enums import Level
    levels = [
        Level.CRITICAL,
        Level.HIGH,
        Level.MEDIUM,
        Level.LOW,
        Level.NEGLIGIBLE
    ]

    t = Text('en')

    for _ in range(100):
        level = t.level()
        assert level in levels



# Generated at 2022-06-12 02:37:36.736933
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # without seed
    assert (Text().rgb_color() in list(map(Text._hex_to_rgb, SAFE_COLORS))) == False
    # with seed
    # if RGB color is not one of the safe colors
    text = Text('ru', seed=1)
    color = text.rgb_color(safe=True)
    assert color == (248, 157, 40)


# Generated at 2022-06-12 02:37:39.808074
# Unit test for method text of class Text
def test_Text_text():
    """Test the method text of class Text."""
    from mimesis.enums import Locale
    text = Text(Locale.GERMANY)
    text.text()

# Generated at 2022-06-12 02:37:45.607858
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Language
    t = Text(language=Language.ENGLISH)
    color = t.color()
    assert color in ['Red', 'Green', 'Blue', 'Black', 'Yellow', 'White', 'Gray',
                     'Purple']

# Generated at 2022-06-12 02:37:49.023113
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    print("\ntext.rgb_color() =", rgb)



# Generated at 2022-06-12 02:38:00.439069
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    #test = Text(locale='en')
    test = Text(locale='ru')
    print("test swear_word:", test.swear_word())

# Generated at 2022-06-12 02:38:02.533151
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) > 0


# Generated at 2022-06-12 02:38:14.300896
# Unit test for method answer of class Text
def test_Text_answer():
    tab = ['ой', 'эх', 'ех', 'да', 'нет', 'может быть', 'конечно', 'видимо', 'кажется', 'наверное', 'наверно', 'говорят', 'я думаю', 'может', 'нужно', 'подумать еще', 'кажется, что', 'уверен, что', 'считаю, что', 'должно быть']
   

# Generated at 2022-06-12 02:38:27.042189
# Unit test for method title of class Text
def test_Text_title():
    from .number import Number
    from .datetime import Datetime
    from .random import Random
    from .regex import Regex
    from .person import Person
    from .internet import Internet
    from .person import Person
    from .address import Address
    from .numbers import Numbers
    from .lorem import Lorem
    from .business import Business
    from .code import Code
    from .food import Food
    from .payment import Payment
    from .science import Science
    from .transport import Transport
    from .datetime import Datetime
    from .geography import Geography
    from .file import File
    t = Text(Random(), Address(), Business(), Code(), Food(),
             Lorem(), Numbers(), Number(), Person(),
             Science(), Datetime(random=Random()), Geography(), File(),
             Transport(), Payment(), Internet(), Regex())

# Generated at 2022-06-12 02:38:28.288615
# Unit test for method quote of class Text
def test_Text_quote():
    a = Text('zh')
    print(a)
    print(a.quote())



# Generated at 2022-06-12 02:38:30.923870
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text(seed=1)
    assert text.hex_color() == '#9d7d27'
    assert text.hex_color(safe=True) == '#58D68D'


# Generated at 2022-06-12 02:39:50.579559
# Unit test for constructor of class Text
def test_Text():
    t = Text(seed=0)
    # print(t.alphabet(lower_case=True))
    # print(t.alphabet(lower_case=False))
    # print(t.level())
    # print(t.text())
    # print(t.text(10))
    # print(t.word())
    # print(t.words())
    # print(t.words(10))
    # print(t.swear_word())
    # print(t.quote())
    # print(t.color())
    # print(t.hex_color())
    # print(t.hex_color(safe=True))
    # print(t.rgb_color())
    # print(t.rgb_color(safe=True))
    print(t.answer())

# Generated at 2022-06-12 02:39:57.181551
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    list_colors = ['#000000', '#FFFFFF', '#1E1E1E', '#9A9A9A', '#B3B3B3',
                   '#BEBEBE', '#BFBFBF', '#C9C9C9', '#E6E6E6', '#F2F2F2',
                   '#2C3E50', '#E74C3C', '#ECF0F1', '#3498DB', '#2980B9',
                   '#E67E22', '#27AE60', '#16A085']
    assert text.color() in list_colors
    assert isinstance(text.color(), str)


# Generated at 2022-06-12 02:40:08.133958
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.builtins import RussiaSpecProvider
    import sys
    if sys.version_info[0] < 3:
        from mock import Mock
        simple_text = Text()
        simple_text.random = Mock()
        simple_text._data = {
            'quotes': ['This is a quote #1', 'This is a quote #2']
        }
        simple_text.random.choice.return_value = 'This is a quote #1'
        assert simple_text.quote() == 'This is a quote #1'

    ru = RussiaSpecProvider('ru')
    ru_text = Text(locale='ru')
    ru_text._data = {
        'quotes': ru.quotes()
    }
    ru_text.random = ru
    assert ru_text.quote() in ru.quotes()


# Generated at 2022-06-12 02:40:12.113539
# Unit test for method level of class Text
def test_Text_level():
    """Test Text.level() method."""
    t = Text()
    lvl = t.level()
    assert isinstance(lvl, str)

# Generated at 2022-06-12 02:40:15.671394
# Unit test for method sentence of class Text
def test_Text_sentence():
  final_test = Text(seed=0)
  assert final_test.sentence() == "Doloribus dicta quibusdam impedit nostrum."

# Generated at 2022-06-12 02:40:19.295038
# Unit test for method words of class Text
def test_Text_words():
    for _ in range(100):
        l = Text().words(3)
        print(l)

    for _ in range(100):
        l = Text().word()
        print(l)


# Generated at 2022-06-12 02:40:31.043021
# Unit test for method level of class Text
def test_Text_level():
    # All strings is lowercase
    req = 'abc'
    for i in range(1, 1000):
        req = req + Text().level() + '%'
    assert req.islower()


# Generated at 2022-06-12 02:40:37.784656
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import ColorType
    from mimesis.providers.text import Text
    from . import UnitTest

    class TestText(UnitTest):
        def setUp(self):
            self.text = Text()

        def test_hex_color(self):
            result = self.text.hex_color()
            self.assertIsInstance(result, str)

        def test_hex_color_with_enum(self):
            safe_hex = self.text.hex_color(safe=ColorType.SAFE)
            self.assertIn(safe_hex, SAFE_COLORS)

# Generated at 2022-06-12 02:40:44.996261
# Unit test for constructor of class Text
def test_Text():
    unit = Text(seed=1)


# Generated at 2022-06-12 02:40:48.779722
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence
