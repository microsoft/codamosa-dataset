

# Generated at 2022-06-12 02:36:46.748993
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text"""
    # When
    my_text = Text('en')
    # Then
    result = my_text.hex_color()
    assert isinstance(result, str)
    assert result[0] == '#'
    result = my_text.hex_color(safe=True)
    assert isinstance(result, str)
    assert result[0] == '#'


# Generated at 2022-06-12 02:36:49.938592
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert len(text.text()) == 5
    assert len(text.words()) == 5
    assert len(text.words(quantity=1)) == 1
    assert len(text.hex_color()) == 7
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3

# Generated at 2022-06-12 02:36:54.779571
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locales
    t = Text(Locales.EN)
    c = t.color()
    assert isinstance(c, str)



# Generated at 2022-06-12 02:36:55.934918
# Unit test for method level of class Text
def test_Text_level():
    word = Text().level()
    assert word == "critical"

# Generated at 2022-06-12 02:37:02.992706
# Unit test for constructor of class Text
def test_Text():
    print("\nUnit test for constructor of class Text:")
    t = Text()
    print("Construct a text object success!")
    print("The alphabet of this text is: ", t.alphabet())
    print("The level of this text is: ", t.level())
    print("The text of this text is: ", t.text())
    print("The sentence of this text is: ", t.sentence())
    print("The title of this text is: ", t.title())
    print("The words of this text is: ", t.words())
    print("The word of this text is: ", t.word())
    print("The swear word of this text is: ", t.swear_word())
    print("The quote of this text is: ", t.quote())
    print("The color of this text is: ", t.color())
   

# Generated at 2022-06-12 02:37:05.186706
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text.rgb_color() == (228, 52, 107)

# Generated at 2022-06-12 02:37:12.259274
# Unit test for constructor of class Text
def test_Text():
    # Unit test for a constructor of class Text
    text = Text()
    for i in range(0, 100):
        assert len(text.alphabet()) > 0
        assert len(text.level()) > 0
        assert len(text.text()) > 0
        assert len(text.sentence()) > 0
        assert len(text.title()) > 0
        assert len(text.words()) > 0
        assert len(text.word()) > 0
        assert len(text.swear_word()) > 0
        assert len(text.quote()) > 0
        assert len(text.color()) > 0
        assert len(text.hex_color()) > 0
        assert len(text.rgb_color()) > 0
        assert len(text.answer()) > 0

if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-12 02:37:13.598167
# Unit test for method title of class Text
def test_Text_title():
    x = Text()
    assert type(x.title()) == str


# Generated at 2022-06-12 02:37:24.835790
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    res = t.alphabet(lower_case=True)
    assert res is not None
    assert not isinstance(res, list)


# Generated at 2022-06-12 02:37:28.125941
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert isinstance(level, str)
    assert len(level) > 0


# Generated at 2022-06-12 02:38:50.830675
# Unit test for method sentence of class Text

# Generated at 2022-06-12 02:39:01.922564
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=123456789)
    res1 = text.alphabet(lower_case=True)
    res2 = text.alphabet(lower_case=False)

    assert res1 == ['а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л',
                    'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш',
                    'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я']

# Generated at 2022-06-12 02:39:08.626137
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    class obj1(object):
        seed, locale = 'aaa', 'xx-XX'
        custom_data = {
                "magic": {
                    "hex": [
                        "#000000", '#FF0000',
                    ]
                }
            }
    text1 = Text(obj1)
    test1 = text1.hex_color()
    test2 = text1.hex_color(safe=True)
    assert test1 == '#000000'
    assert test2 == '#FF0000'

# Generated at 2022-06-12 02:39:14.040386
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = Text().hex_color()
    assert len(result)==7
    assert result[0]=='#'
    for i in range(1,6):
        assert result[i] in ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']


# Generated at 2022-06-12 02:39:17.296828
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.builtins import Text
    text = Text('de')
    result_1 = text.color()
    result_2 = text.color()



# Generated at 2022-06-12 02:39:20.770626
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    generated_color = t.hex_color()
    list_of_colors = generated_color.replace('#', '').lower()
    assert(list_of_colors)


# Generated at 2022-06-12 02:39:27.118301
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.color is not None
    assert text.hex_color is not None
    assert text.rgb_color is not None
    assert text.alphabet is not None
    assert text.level is not None
    assert text.quote is not None
    assert text.answers is not None
    assert text.title is not None
    assert text.word is not None
    assert text.wods is not None
    assert text.sentence is not None
    assert text.text is not None

# Generated at 2022-06-12 02:39:29.076328
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    test_Text = Text(seed=0)
    assert test_Text.hex_color() == '#434d1c'


# Generated at 2022-06-12 02:39:41.030175
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.enums import ColorType
    from mimesis.typing import Color
    t = Text('en')
    assert t.rgb_color() == (230, 0, 0)
    assert t.rgb_color(safe=True) == (241, 196, 15)
    assert t.rgb_color(safe=ColorType.HEX) == '#F1C40F'
    assert t.rgb_color() != (45, 220, 0)
    assert t.rgb_color(safe=True) != (230, 0, 0)
    assert t.rgb_color(safe=True) != (21, 21, 0)
    assert t.rgb_color(safe=True) != '#131300'

# Generated at 2022-06-12 02:39:53.194412
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text(seed=0)
    assert '"Bond... James Bond."' == text.quote(), \
        'Should return: "Bond... James Bond."'



# Generated at 2022-06-12 02:40:18.690306
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.provider == 'text'


# Generated at 2022-06-12 02:40:19.505428
# Unit test for method quote of class Text
def test_Text_quote():
    n = Text()
    assert len(n.quote()) > 1

# Generated at 2022-06-12 02:40:31.006373
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text('en')
    print("\nTesting method rgb_color of class Text")
    assert len(t.rgb_color()) == 3
    print("Method rgb_color of class Text works fine")

# Generated at 2022-06-12 02:40:31.928814
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert len(t.quote()) > 0

# Generated at 2022-06-12 02:40:34.213901
# Unit test for method text of class Text
def test_Text_text():
    text = Text('zh')
    print(text.text())
    print(text.words())



# Generated at 2022-06-12 02:40:36.593439
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in \
        text._data['answers'], 'test_answer failed'

# Generated at 2022-06-12 02:40:55.534573
# Unit test for method color of class Text
def test_Text_color():
    import os
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.data import CITIES, STATES
    data_path_rus = os.path.join(
        os.getcwd(), 'tests', 'data', 'ru', 'text.json')
    data_path_usa = os.path.join(
        os.getcwd(), 'tests', 'data', 'en', 'text.json')

    with open(data_path_rus) as json_file:
        ru_data = json_file.read()

    with open(data_path_usa) as json_file:
        en_data = json_file.read()


# Generated at 2022-06-12 02:40:59.316984
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    import random
    text = Text()
    text.random.seed(42)
    result = text.hex_color(safe=True)
    #print(result)
    assert result == "e27a3f"  # #e27a3f
    ##
    text.random.seed(42)
    result = text.hex_color()
    #print(result)
    assert result == "#ff4848"  # #ff4848


# Generated at 2022-06-12 02:41:04.811911
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.sentence())
    print(t.rgb_color(safe=True))
    print(t.hex_color())
    print(t.color())
    print(t.quote())
    print(t.word())
    print(t.words())
    print(t.title())
    print(t.swear_word())
    print(t.text())
    print(t.alphabet())
    print(t.alphabet(lower_case=True))
    print(t.level())
    print(t.answer())


if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-12 02:41:14.117748
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Arrange
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    en_text = Text(Locale.EN)
    ru_text = Text(Locale.RU)

    # Act
    en_result = en_text.swear_word()
    ru_result = ru_text.swear_word()
    # print("English:", en_result, "Russian:", ru_result)
    # Assert
    assert isinstance(en_result, str)
    assert isinstance(ru_result, str)



# Generated at 2022-06-12 02:43:20.513136
# Unit test for method answer of class Text
def test_Text_answer():
    random_answer_lower="yes"
    random_answer_upper="NO"
    text = Text()
    first_ans= text.answer()
    second_ans= text.answer()
    assert first_ans.lower()== random_answer_lower or first_ans.upper()== random_answer_upper
    assert second_ans.lower()== random_answer_lower or second_ans.upper()== random_answer_upper
    
    if first_ans.lower()=="yes": 
        assert second_ans.lower()=="no"
    else:
        assert second_ans.upper()=="YES"


# Generated at 2022-06-12 02:43:24.586083
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_obj=Text()
    text_obj.swear_word()


# Generated at 2022-06-12 02:43:26.692229
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    res = t.sentence()
    assert isinstance(res, str), "Is not a str"


# Generated at 2022-06-12 02:43:28.430226
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test hex_color without safe parameter."""
    text = Text()
    assert len(text.hex_color()) == 7
    assert text.hex_color().startswith('#')


# Generated at 2022-06-12 02:43:29.705024
# Unit test for method title of class Text
def test_Text_title():
    title = text.title()
    assert title != "" or None

# Generated at 2022-06-12 02:43:30.686780
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level == "critical"

# Generated at 2022-06-12 02:43:44.695622
# Unit test for method quote of class Text
def test_Text_quote():
    for _ in range (1, 10):
        quote_str = Text().quote()
        assert quote_str.count("'") <= 2
        assert quote_str.count("\"") <= 2
        assert quote_str.count("'") + quote_str.count("\"") >= 1


# Generated at 2022-06-12 02:43:47.217736
# Unit test for constructor of class Text
def test_Text():
    text_obj = Text(seed=1234)
    print(text_obj.answer())

# Generated at 2022-06-12 02:43:49.274492
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color.title() == color

# Generated at 2022-06-12 02:43:58.548810
# Unit test for method word of class Text
def test_Text_word():
    # Test result is "Science"
    result = Text().word()
    assert result == 'Science'
