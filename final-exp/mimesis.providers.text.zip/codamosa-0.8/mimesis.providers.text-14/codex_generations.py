

# Generated at 2022-06-12 02:36:50.086476
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    Text().hex_color()


# Generated at 2022-06-12 02:36:54.858444
# Unit test for method text of class Text
def test_Text_text():
    """Test text()
    """
    tt = Text()
    assert tt.text(quantity=1) == "Ut enim ad minim veniam."



# Generated at 2022-06-12 02:37:03.740193
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    print(text.title())


# Generated at 2022-06-12 02:37:07.042283
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text(locale='ko')
    assert len(text.sentence()) > 0


# Generated at 2022-06-12 02:37:08.616691
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alph = text.alphabet()
    assert len(alph) == 26
    assert alph[0] == 'A'
    assert alph[-1] == 'Z'



# Generated at 2022-06-12 02:37:13.283290
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text._datafile == 'text.json'
    assert text.__class__.__name__ == 'Text'
    assert text.__class__.Meta.name == 'text'


# Generated at 2022-06-12 02:37:27.198237
# Unit test for method color of class Text
def test_Text_color():
    # Test with locale ru_RU
    t = Text(locale='ru')
    assert t.color() in t._data['color']
    # Test with locale en_GB
    t1 = Text(locale='en')
    assert t1.color() in t1._data['color']



# Generated at 2022-06-12 02:37:31.905818
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enum import Language

    t = Text(Language.ENGLISH)
    result = t.words(10)

    assert len(result) == 10



# Generated at 2022-06-12 02:37:32.476100
# Unit test for method sentence of class Text
def test_Text_sentence():
    pass

# Generated at 2022-06-12 02:37:33.560994
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)