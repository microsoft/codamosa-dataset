

# Generated at 2022-06-12 02:38:21.613130
# Unit test for method text of class Text
def test_Text_text():
    """Function for unit test of Text.text()."""
    text = Text()
    for _ in range(100):
        txt = text.text()
        if not isinstance(txt, str):
            raise AssertionError(
                'Wrong data type: {}, should be str.'.format(type(txt)))

# Generated at 2022-06-12 02:38:22.796515
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    alpha = t.alphabet()
    assert type(alpha) is list


# Generated at 2022-06-12 02:38:39.295250
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    safe_color = text.hex_color(safe=True)
    assert len(hex_color) == 7
    assert len(safe_color) == 7
    assert hex_color.startswith('#')
    assert safe_color.startswith('#')
    for color in (hex_color, safe_color):
        for char in color:
            assert char in '0123456789abcdef#'


# Generated at 2022-06-12 02:38:42.138727
# Unit test for method answer of class Text
def test_Text_answer():
    for _ in range(5):
        print(Text().answer())


# Generated at 2022-06-12 02:38:44.986987
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    [t.words(quantity = 5) for _ in range(100)]


# Generated at 2022-06-12 02:38:48.070151
# Unit test for method words of class Text
def test_Text_words():
    text = Text('en')
    result = text.words(10)
    assert (len(result) == 10)


# Generated at 2022-06-12 02:38:50.889421
# Unit test for method words of class Text
def test_Text_words():
    text_generator = Text()
    test_text = text_generator.words()
    print(test_text)


# Generated at 2022-06-12 02:38:52.707501
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote()


# Generated at 2022-06-12 02:38:56.400663
# Unit test for method words of class Text
def test_Text_words():
    import random
    """
    This method returns random words from the text
    :returns: list of words
    """ 
    text_gen = Text(random.seed(1))
    print(text_gen.words())
    
test_Text_words()

# Generated at 2022-06-12 02:38:59.654758
# Unit test for method title of class Text
def test_Text_title():
  t=Text()
  tit=t.title()
  print(tit)
  assert isinstance(tit,str)



# Generated at 2022-06-12 02:39:57.601687
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert isinstance(level, str)
    assert len(level) > 1


# Generated at 2022-06-12 02:40:02.787110
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    words_list = t.words(quantity=5)
    assert len(words_list)==5
    assert isinstance(words_list,list)
    assert isinstance(words_list[0],str)


# Generated at 2022-06-12 02:40:06.946294
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    p = Text()
    assert len(p.hex_color()) == 7
    assert len(p.hex_color(safe=True)) == 7
    assert p.hex_color()[0] == '#'
    assert p.hex_color(safe=True)[0] == '#'


# Generated at 2022-06-12 02:40:09.245648
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text(seed=0)
    for _ in range(100):
        actual = text.alphabet(lower_case=True)
        expected = 'a b c d e f g h i j k l m n o p q r s t u v w x y z'
        assert actual == expected


# Generated at 2022-06-12 02:40:13.333373
# Unit test for method color of class Text
def test_Text_color():
    for i in range(100):
        color = Text('en').color()
        assert type(color) == str


# Generated at 2022-06-12 02:40:16.090756
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert t.title()
    assert len(t.title()) > 0


# Generated at 2022-06-12 02:40:18.230625
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote() in Text()._data.get('quotes')


# Generated at 2022-06-12 02:40:19.959000
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    res = t.words()
    assert isinstance(res, list)
    assert len(res) == 5
    assert all(isinstance(i, str) for i in res)


# Generated at 2022-06-12 02:40:23.998491
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    text.seed(1)

    for i in range(10):
        print(text.swear_word())

# Generated at 2022-06-12 02:40:25.351827
# Unit test for method words of class Text
def test_Text_words():
    test = Text()
    assert test.words()
