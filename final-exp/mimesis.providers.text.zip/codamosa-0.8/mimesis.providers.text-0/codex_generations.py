

# Generated at 2022-06-12 02:37:01.419935
# Unit test for method color of class Text
def test_Text_color():
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()

    method_1 = text_1.color()
    method_2 = text_2.color()
    method_3 = text_3.color()
    method_4 = text_4.color()

    assert (method_1 == method_2) == False
    assert (method_1 == method_3) == False
    assert (method_1 == method_4) == False

    assert (method_2 == method_3) == False
    assert (method_2 == method_4) == False

    assert (method_3 == method_4) == False


# Generated at 2022-06-12 02:37:02.646763
# Unit test for method answer of class Text
def test_Text_answer():
    # Method : returns the random answer
    # test one (should return string)
    assert type(Text.answer()) == str

# Generated at 2022-06-12 02:37:07.272578
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    txt = Text()
    result = txt.alphabet()
    assert result is not None


# Generated at 2022-06-12 02:37:11.100883
# Unit test for method text of class Text
def test_Text_text():
    tes = Text()
    text = tes.text()
    print(text)
    assert text is not None


# Generated at 2022-06-12 02:37:13.670122
# Unit test for method word of class Text
def test_Text_word():
    """Unit tests for method word of class Text."""
    text = Text()
    word = text.word()
    assert isinstance(word, str)

# Generated at 2022-06-12 02:37:26.062279
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    num = text.random.randint(0, 100)
    result = text.title()
    assert result != None
    print(result)
    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-12 02:37:28.308019
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    res = t.level()
    assert res in ["critical", "high", "medium", "low"]

# Generated at 2022-06-12 02:37:34.074007
# Unit test for method level of class Text
def test_Text_level():
    results = []
    for _ in range(100000):
        results.append(Text().level())

    assert len(results) == 100000
    assert isinstance(results, list)
    assert results[0] in ['low', 'medium', 'high', 'critical']



# Generated at 2022-06-12 02:37:36.128295
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert isinstance(text.swear_word(), str)

# Generated at 2022-06-12 02:37:37.198182
# Unit test for method word of class Text
def test_Text_word():
    provider = Text()
    print(provider.word())
