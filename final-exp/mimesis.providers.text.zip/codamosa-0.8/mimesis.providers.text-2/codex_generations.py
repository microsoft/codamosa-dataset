

# Generated at 2022-06-12 02:36:55.936853
# Unit test for method word of class Text
def test_Text_word():
    from mimesis.enums import Gender
    Text().word()
    Text(Gender.FEMALE).word()


# Generated at 2022-06-12 02:36:58.064410
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    colors = text.color()
    print(colors)
    colors = text.color()
    print(colors)
    colors = text.color()
    print(colors)


# Generated at 2022-06-12 02:36:59.684844
# Unit test for method level of class Text
def test_Text_level():
    try:
        Text().level()
    except Exception as e:
        return "Error"
    else:
        return "Success"


# Generated at 2022-06-12 02:37:02.793443
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    # Do it 1000 times
    for i in range(1000):
        # Get a sentence
        sentence = text.sentence()
        # Check if the sentence has a correct format
        if sentence != sentence.capitalize() + '.':
            print("Wrong format! It must be \"Something.\"")


# Generated at 2022-06-12 02:37:15.060650
# Unit test for constructor of class Text
def test_Text():
    print("testing Text")
    t = Text()
    print("testing Text.alphabet")
    for i in range(20):
        print(t.alphabet())
    print("testing Text.level")
    for i in range(20):
        print(t.level())
    print("testing Text.text")
    for i in range(20):
        print(t.text())
    print("testing Text.title")
    for i in range(20):
        print(t.title())
    print("testing Text.words")
    for i in range(20):
        print(t.words())
    print("testing Text.word")
    for i in range(20):
        print(t.word())
    print("testing Text.swear_word")

# Generated at 2022-06-12 02:37:17.718768
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    result = text.text()
    assert isinstance(result, str) == True


# Generated at 2022-06-12 02:37:19.237692
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    obj = Text(seed=2)
    assert obj.swear_word() == "idiot"

# Generated at 2022-06-12 02:37:23.295385
# Unit test for method level of class Text
def test_Text_level():
    x = Text()
    assert Text.level() in  ['critical','dummy','important','serious','secure','safe','info','warning','error','debug','primary','secondary','success','danger','light','dark','test']

# Generated at 2022-06-12 02:37:36.130011
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.text import Text

    t = Text(RussiaSpecProvider)

# Generated at 2022-06-12 02:37:37.714703
# Unit test for method quote of class Text
def test_Text_quote():
	quotes = []
	for _ in range(100):
		quotes.append(Text().quote())
	assert quotes != []