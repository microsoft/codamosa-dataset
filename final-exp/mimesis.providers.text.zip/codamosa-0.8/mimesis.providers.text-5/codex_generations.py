

# Generated at 2022-06-12 02:36:49.806007
# Unit test for constructor of class Text
def test_Text():
    pass


# Generated at 2022-06-12 02:36:53.172408
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert 0 < len(text.sentence()) < 200
    

# Generated at 2022-06-12 02:36:55.898816
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Languages
    text = Text(Languages.EN)
    assert text.level()


# Generated at 2022-06-12 02:37:02.965432
# Unit test for method hex_color of class Text
def test_Text_hex_color():

    from mimesis.builtins import RussiaSpecProvider

    text_provider = Text(RussiaSpecProvider())

    assert text_provider.hex_color()  == '#a1a6fc'
    assert text_provider.hex_color()  == '#6ad3a4'
    assert text_provider.hex_color()  == '#59a6e7'
    assert text_provider.hex_color()  == '#b84e8d'
    assert text_provider.hex_color()  == '#eec290'
    assert text_provider.hex_color()  == '#cf2ef9'
    assert text_provider.hex_color()  == '#ebea03'
    assert text_provider.hex_color()  == '#e5d7c2'


# Generated at 2022-06-12 02:37:11.100767
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    try:
        txt = Text()
        hexCode = txt.hex_color()
        assert hexCode is not None, "Error, method hex_color of class Text must return a hexadecimal code"
    except AssertionError as msg:
        print(msg)


# Generated at 2022-06-12 02:37:21.791109
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.enums import Special
    from mimesis.builtins import Text
    from mimesis.enums import Special
    #text = Text(seed=123456)
    #assert text_hex_color(False,text) == '#f4b4dd' # Добавить проверку этого и нижнего примеров
    #assert text_hex_color(True,text) == '#D63031'
    assert Text(Special.NULL).hex_color() == '#000000' # Проверка для специального значения

# Generated at 2022-06-12 02:37:24.673102
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    from mimesis.enums import DataField
    t = Text(DataField.RUSSIAN)
    print(t.swear_word())



# Generated at 2022-06-12 02:37:26.655754
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    text.words(5) # list


# Generated at 2022-06-12 02:37:29.035552
# Unit test for method text of class Text
def test_Text_text():
    # test_Text_text()
    provider = Text()

    assert provider.text() == provider.text()


# Generated at 2022-06-12 02:37:35.502179
# Unit test for method title of class Text
def test_Text_title():
    text1 = Text()
    text2 = Text(locale = 'zh_CN')
    text3 = Text(locale = 'en_US')
    text4 = Text(locale = 'jp_JP')
    print(text1.title())
    print(text2.title())
    print(text3.title())
    print(text4.title())


# Generated at 2022-06-12 02:41:51.508265
# Unit test for method color of class Text
def test_Text_color():
    for _ in range(100):
        assert Text('ru').color() in Text('ru')._data['color']
        assert Text().color() in Text()._data['color']



# Generated at 2022-06-12 02:41:53.672092
# Unit test for method sentence of class Text
def test_Text_sentence():
    print("Testing Text class method sentence")
    assert Text().sentence() != ""
    print("Success")


# Generated at 2022-06-12 02:41:55.406429
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.providers.text import Text
    t = Text()
    print(t.color())


# Generated at 2022-06-12 02:42:13.279662
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis import __version__
    from mimesis.builtins import Text
    from mimesis.enums import Locale
    from mimesis.providers.text import Answer
    from mimesis.providers.text import Text as Text_
    t = Text(locale='en')
    assert isinstance(t, Text_)
    assert isinstance(t.answer, Answer)
    assert t.answer._data['answers'] == ['yes', 'no', 'maybe', 'try again']
    assert t.answer._data['answers'] == t.answer()
    assert t.answer.affirmative() in ['yes', 'maybe']
    assert t.answer.negative() in ['no', 'maybe']
    assert isinstance(t.answer.sometimes(), str)

# Generated at 2022-06-12 02:42:23.630647
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    t.alphabet(lower_case=True)
    t.alphabet(lower_case=False)


# Generated at 2022-06-12 02:42:27.000214
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text()
    result = provider.rgb_color()
    assert isinstance(result, tuple)


# Generated at 2022-06-12 02:42:29.179481
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locales
    t = Text(Locales.EN)
    assert t.level() == "critical"

# Unit tests for method text of class Text

# Generated at 2022-06-12 02:42:30.764374
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    print(text.text())

# Generated at 2022-06-12 02:42:31.887521
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert len(t.text()) == 5

# Generated at 2022-06-12 02:42:33.096681
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() == "Bond... James Bond."


# Generated at 2022-06-12 02:46:13.626851
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.builtins import en

    text = Text(en)
    assert len(text.words()) == 5

    text = Text(en)
    assert len(text.words(quantity=10)) == 10

    text = Text(en)
    assert len(text.words(quantity=1)) == 1

    text = Text(en)
    assert not text.words(quantity=2) == 10



# Generated at 2022-06-12 02:46:15.641305
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert Text(seed=0).hex_color() == "#8d5681"
    assert Text(seed=0).hex_color() == "#8d5681"
    assert Text(seed=0).hex_color() == "#8d5681"

# Generated at 2022-06-12 02:46:18.007881
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert type(text.level()) == str


# Generated at 2022-06-12 02:46:21.864774
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    for _ in range(1000):
        hex_color = Text().hex_color()
        assert isinstance(hex_color, str) and len(hex_color) == 7


# Generated at 2022-06-12 02:46:25.196676
# Unit test for method level of class Text
def test_Text_level():
    t = Text('en')
    for i in range(10):
        level = t.level()
        assert level in t._data['level']



# Generated at 2022-06-12 02:46:27.440172
# Unit test for method word of class Text
def test_Text_word():
    text_provider = Text()
    word = text_provider.word()
    assert word


# Generated at 2022-06-12 02:46:29.670215
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    obj=Text()
    assert obj.swear_word() in obj._data['words']['bad']
