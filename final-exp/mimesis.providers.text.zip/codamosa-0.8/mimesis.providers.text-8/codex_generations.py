

# Generated at 2022-06-12 02:41:04.107598
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    obj = Text()
    assert type(obj.hex_color()) == str
    assert obj.hex_color().startswith('#') == True

# Generated at 2022-06-12 02:41:06.896760
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert isinstance(t.answer(), str)


# Generated at 2022-06-12 02:41:13.614919
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    x = text.sentence()
    assert isinstance(x, str)
    x = text.sentence()
    assert isinstance(x, str)
    x = text.sentence()
    assert isinstance(x, str)


# Generated at 2022-06-12 02:41:17.432138
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    answer = t._data['words'].get('bad')
    assert t.swear_word() in answer

# Generated at 2022-06-12 02:41:23.469507
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    result = t.word()
    assert isinstance(result, str)


# Generated at 2022-06-12 02:41:26.157007
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data["quotes"]

# Generated at 2022-06-12 02:41:30.878744
# Unit test for constructor of class Text
def test_Text():
    # Create instance of class Text
    text = Text()
    obj = vars(text)

    # Test of constructor
    assert (obj.get('_data') == {})
    assert (obj.get('_datafile') == 'text.json')
    assert (obj.get('_seed') == 1)


# Generated at 2022-06-12 02:41:32.634487
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    expected = text.color()
    assert type(expected) == str
    assert expected in text._data["color"]


# Generated at 2022-06-12 02:41:35.706397
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed=0)
    result = text.color()
    assert result == 'Red'

# Generated at 2022-06-12 02:41:40.965621
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    '''Testing the method hex_color of class Text'''
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe = True)) == 7
