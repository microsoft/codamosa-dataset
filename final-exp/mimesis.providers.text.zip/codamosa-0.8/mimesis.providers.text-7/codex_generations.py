

# Generated at 2022-06-12 02:46:29.572923
# Unit test for method sentence of class Text
def test_Text_sentence():
    for i in range(10):
        text = Text()
        assert text.sentence() in text._data['text']
        assert len(text.sentence()) > 10 and len(text.sentence()) < 100
