

# Generated at 2022-06-12 02:36:43.072175
# Unit test for constructor of class Text
def test_Text():
    print("Running test for constructor of class Text\n")
    print("Testing with valid inputs\n")
    text = Text(seed=5)
    print("Seed 5")
    print("The random value generated is: ", text.answer())
    text = Text(seed=6)
    print("Seed 6")
    print("The random value generated is: ", text.answer())
    text = Text(seed=6, locale='en')
    print("Seed 6")
    print("The random value generated is: ", text.answer())
    text = Text(seed=5, locale='en_US')
    print("Seed 5")
    print("The random value generated is: ", text.answer())
    print("\n")
    print("Testing with invalid inputs\n")

# Generated at 2022-06-12 02:36:48.513585
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    def test_fail(obj):
        assert obj is not None, "\"title\" returns None"
        assert isinstance(obj, str), "\"title\" is not a string"

    t = Text()
    #test_fail
    assert Text.title() is not None, "\"title\" returns None"
    assert isinstance(Text.title(), str), "\"title\" is not a string"



# Generated at 2022-06-12 02:36:50.709632
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    t.title()


# Generated at 2022-06-12 02:36:53.512350
# Unit test for method title of class Text
def test_Text_title():
    title = Text().title()
    print(title)


# Generated at 2022-06-12 02:36:58.832025
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)
    assert isinstance(t.sentence(), str)


# Generated at 2022-06-12 02:37:01.553118
# Unit test for method word of class Text
def test_Text_word():
    """Unit test for method word of class Text."""
    expected_type = str
    expected_length = 1

    text = Text()
    assert isinstance(text.word(), expected_type)
    assert len(text.word()) == expected_length


# Generated at 2022-06-12 02:37:02.290413
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert type(text) == Text

# Generated at 2022-06-12 02:37:04.575837
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert type(t.sentence()) == str


# Generated at 2022-06-12 02:37:07.910441
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    result = t.answer()
    assert result
    assert isinstance(result, str)

# Generated at 2022-06-12 02:37:15.105130
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    from mimesis.enums import Case
    from mimesis.providers.text import Text

    text = Text()
    alphabet_lower = text.alphabet(lower_case=True)
    alphabet_upper = text.alphabet(lower_case=False)

    assert len(alphabet_lower) == len(alphabet_upper) == 26

    assert alphabet_lower == text.alphabet(lower_case=Case.LOWER_CASE)
    assert alphabet_upper == text.alphabet(lower_case=Case.UPPER_CASE)


# Generated at 2022-06-12 02:37:36.740355
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.providers.text import Text

    t = Text('en')

    word = t.words(quantity=None)
    assert word != None
    assert isinstance(word, list)

    word = t.words(quantity=2)
    assert len(word) == 2
    assert isinstance(word, list)



# Generated at 2022-06-12 02:37:38.656777
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert len(text.title()) > 0, 'Not correct title'

# Generated at 2022-06-12 02:37:41.660324
# Unit test for method word of class Text
def test_Text_word():
	word = Text()
	word_ = word.word()
	assert isinstance(word_,str)


# Generated at 2022-06-12 02:37:44.486597
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    res = t.hex_color()
    assert(res[0] == '#')


# Generated at 2022-06-12 02:37:48.047259
# Unit test for method title of class Text
def test_Text_title():
    """Test for Text.title()"""
    text = Text('ru')
    for _ in range(100):
        _ = text.title()

# Generated at 2022-06-12 02:37:55.666024
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert (t.level() != '')
    assert (t.text() != '')
    assert (t.words() != '')
    assert (t.sentence() != '')
    assert (t.title() != '')
    assert (t.word() != '')
    assert (t.swear_word() != '')
    assert (t.quote() != '')
    assert (t.color() != '')
    assert (t.hex_color() != '')
    assert (t.rgb_color() != '')
    assert (t.answer() != '')


if __name__ == '__main__':
    test_Text()

# Generated at 2022-06-12 02:37:59.918654
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    provider = Text()
    text = provider.rgb_color()
    assert isinstance(text, tuple)
    assert len(text) == 3

# Generated at 2022-06-12 02:38:08.418450
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    print(t.color())    # 获取颜色名
    print(t.alphabet()) # 获取字母表
    print(t.level())    # 获取级别
    print(t.text())
    print(t.sentence())
    print(t.words(5))
    print(t.swear_word())
    print(t.quote())
    print(t.hex_color())
    print(t.rgb_color())
    print(t.answer())

if __name__ == "__main__":
    test_Text()

# Generated at 2022-06-12 02:38:13.278221
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert len(answer) > 0, \
        'Returned answer is empty'
    assert answer in text._data['answers'], \
        'Returned answer is not in the given list'

if __name__ == "__main__":
    test_Text_answer()

# Generated at 2022-06-12 02:38:15.248785
# Unit test for constructor of class Text
def test_Text():

    print(Text())


# Generated at 2022-06-12 02:39:56.686383
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    p = Text()
    rgb_color = p.rgb_color()
    assert type(rgb_color) == tuple


# Generated at 2022-06-12 02:39:59.790023
# Unit test for constructor of class Text
def test_Text():
    p = Text()
    assert p.__class__.__name__ == 'Text'


# Generated at 2022-06-12 02:40:02.278813
# Unit test for method title of class Text
def test_Text_title():
    assert Text().title() in Text()._data['text']
# Test for method level of class Text

# Generated at 2022-06-12 02:40:04.376385
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Language

    text = Text(Language.EN)
    quote = text.quote()

    assert quote in text._data['quotes']



# Generated at 2022-06-12 02:40:06.863226
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ['Yes', 'No', 'Maybe']

# Generated at 2022-06-12 02:40:11.009520
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Test for method rgb_color"""
    provider = Text('zh')
    result = provider.rgb_color()
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert all(isinstance(i, int) for i in result)
    assert result != provider.rgb_color()

    result = provider.rgb_color(safe=True)
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert all(isinstance(i, int) for i in result)
    assert result == provider.rgb_color(safe=True)


# Generated at 2022-06-12 02:40:13.662228
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    text = t.level()
    assert text

# Generated at 2022-06-12 02:40:19.457044
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Gender
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    t = Text(Locale.ENGLISH)
    # assert t.answer() in Text.ANSWERS[Locale.ENGLISH.value]
    return t.answer()


# Generated at 2022-06-12 02:40:27.961774
# Unit test for method sentence of class Text
def test_Text_sentence():
    print(Text().sentence())

# Generated at 2022-06-12 02:40:30.812928
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    t.alphabet()
    print(t.alphabet())
