

# Generated at 2022-06-12 02:36:51.991488
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text.
    """
    x = Text(seed=False).level()
    assert x in (Text(seed=False)._data['level'])

# Generated at 2022-06-12 02:36:56.211661
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unittest for method alphabet of class Text."""
    text = Text()
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.alphabet(lower_case=True), list)


# Generated at 2022-06-12 02:36:57.703158
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence
    assert isinstance(sentence, str)


# Generated at 2022-06-12 02:36:59.041328
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert isinstance(t.rgb_color(), tuple)


# Generated at 2022-06-12 02:37:00.404819
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    res = t.color()
    assert isinstance(res,str)


# Generated at 2022-06-12 02:37:01.962860
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert type(swear_word) is str


# Generated at 2022-06-12 02:37:05.178998
# Unit test for method sentence of class Text
def test_Text_sentence():
    provider = Text()
    sentence = provider.sentence()
    assert sentence


# Generated at 2022-06-12 02:37:09.026110
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text.

    Check that all available alphabets are valid.

    :return: Result of unit test.
    :rtype: bool
    """
    from mimesis.enums import Case
    for c in Case:
        t = Text('ru')
        result = t.alphabet(c == Case.LOWER)
        for char in result:
            if char not in list(set(map(chr, range(97, 123)))):
                return False
    return True


# Generated at 2022-06-12 02:37:20.130862
# Unit test for method sentence of class Text
def test_Text_sentence():
    # initialize new instance Text()
    t = Text()
    # test method sentence()
    assert isinstance(t.sentence(), str)
    # test method text()
    assert isinstance(t.text(), str)
    # test method title()
    assert isinstance(t.title(), str)
    # test method words()
    assert isinstance(t.words(), list)
    # test method word()
    assert isinstance(t.word(), str)
    # test method swear_word()
    assert isinstance(t.swear_word(), str)
    # test method quote()
    assert isinstance(t.quote(), str)
    # test method color()
    assert isinstance(t.color(), str)
    # test method hex_color()
    assert isinstance(t.hex_color(), str)
    # test method

# Generated at 2022-06-12 02:37:21.109543
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text()


# Generated at 2022-06-12 02:37:44.134614
# Unit test for method title of class Text
def test_Text_title():
    test_text = Text()
    assert '\t' not in test_text.title()
    assert ' ' in test_text.title()
    assert '.' in test_text.title()
    assert '\n' not in test_text.title()

# Generated at 2022-06-12 02:37:48.292820
# Unit test for method words of class Text
def test_Text_words():
    obj = Text(seed=17)
    list_w = ["return", "speak", "take", "clear", "hit"]
    assert obj.words(5) == list_w

# Generated at 2022-06-12 02:37:52.043819
# Unit test for method text of class Text
def test_Text_text():
    text = Text('en')
    text.text()

# Generated at 2022-06-12 02:37:57.245508
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    r = text.rgb_color()
    assert isinstance(r, tuple)
    assert len(r) == 3
    for a in r:
        assert isinstance(a, int)
        assert 0 <= a <= 255

# Generated at 2022-06-12 02:38:08.378532
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.answer())
    print(text.color())
    print(text.text())
    print(text.text())
    print(text.text())
    print(text.text())
    print(text.text())
    print(text.quote())
    print(text.title())
    words = text.words()
    print(words)
    print(text.sentence())
    print(text.level())
    print(text.word())
    print(text.word())
    print(text.word())
    print(text.swear_word())
    print(text.hex_color())
    print(text.hex_color())
    print(text.hex_color())
    print(text.hex_color())
    print(text.hex_color(True))

# Generated at 2022-06-12 02:38:18.398565
# Unit test for method words of class Text
def test_Text_words():
    """
    Unit test for method words of class Text
    """

    from mimesis import Text
    t = Text('en')
    assert len(t.words()) == 5, 'Not as expected :('



# Generated at 2022-06-12 02:38:20.487032
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    assert txt is not None


# Generated at 2022-06-12 02:38:28.485886
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    output_1 = t.alphabet()
    output_2 = t.random.choice(output_1)

    assert isinstance(output_1, list)
    assert len(output_1) == 26
    assert output_1[0] == 'A'
    assert output_1[25] == 'Z'
    assert isinstance(output_2, str)
    assert len(output_2) == 1

    output_3 = t.alphabet(lower_case=True)
    assert isinstance(output_3, list)
    assert len(output_3) == 26
    assert output_3[0] == 'a'
    assert output_3[25] == 'z'
    assert isinstance(output_2, str)
    assert len(output_2) == 1



# Generated at 2022-06-12 02:38:30.205204
# Unit test for method words of class Text
def test_Text_words():
    x = Text()
    x.words(quantity=5)


# Generated at 2022-06-12 02:38:31.763985
# Unit test for method title of class Text
def test_Text_title():
    """Unit test for method title of class Text."""
    t = Text()
    result = t.title()
    assert result
    assert len(result) > 0
