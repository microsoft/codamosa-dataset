

# Generated at 2022-06-12 02:36:54.623336
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    for i in range(20):
        print(text.swear_word())



# Generated at 2022-06-12 02:36:56.453890
# Unit test for method color of class Text
def test_Text_color():
    """Unit test for method color of class Text."""
    text = Text()
    assert text.color() in text._data['color']

# Generated at 2022-06-12 02:36:58.014126
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    sw = t.swear_word()
    assert type(sw) is str
    assert sw


# Generated at 2022-06-12 02:36:59.649738
# Unit test for constructor of class Text
def test_Text():
  text = Text()
  print(text.text())

if __name__ == "__main__":
  test_Text()

# Generated at 2022-06-12 02:37:00.745006
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())
    print(t.words())

# Generated at 2022-06-12 02:37:01.758127
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    assert Text().rgb_color(safe=True) == (241, 196, 15)

# Generated at 2022-06-12 02:37:03.668326
# Unit test for method text of class Text
def test_Text_text():
    provider = Text()
    result = provider.text()
    assert result == "Adipisci enim maxime ea natus. Enim quia maiores quia." 


# Generated at 2022-06-12 02:37:14.172054
# Unit test for method words of class Text
def test_Text_words():
    from unittest import TestCase
    from mimesis.builtins import Text

    class TestTextWords(TestCase):
        """Unit test for Text.words()."""

        def setUp(self):
            self.text = Text('en')

        def test_words(self):
            result = self.text.words(quantity=2)
            self.assertIsInstance(result, list)
            self.assertIsInstance(result[0], str)
            self.assertEqual(len(result), 2)

    TestTextWords()

    print("Unit Test TestTextWords: Pass")


# Generated at 2022-06-12 02:37:16.677873
# Unit test for method color of class Text
def test_Text_color():
    result = Text().color()
    assert isinstance(result, str) is True
    assert result not in []

# Generated at 2022-06-12 02:37:18.730684
# Unit test for method answer of class Text
def test_Text_answer():
    blood = Text()
    blood.set_seed(123)
    print(blood.answer()) # should return "No", not other value


# Generated at 2022-06-12 02:37:43.893218
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7
    assert '#' in hex_color
    assert int(hex_color[1:], 16) <= 0xffffff

# Generated at 2022-06-12 02:37:48.053955
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Unit test for method sentence of class Text.
    
    :return: True if unit test is success.
    """
    text = Text()
    sentence = text.sentence()
    return sentence


# Generated at 2022-06-12 02:37:52.043874
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    print(f'text.color: {text.color()}')


# Generated at 2022-06-12 02:37:57.280784
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    
    text = Text()
    assert isinstance(text.rgb_color(), tuple)
    assert len(text.rgb_color()) == 3
    assert isinstance(text.rgb_color()[0], int)
    

# Generated at 2022-06-12 02:37:59.434375
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    for x in range(100):
        assert len(t.sentence()) <= 140


# Generated at 2022-06-12 02:38:04.510303
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_hc = Text('en')
    result = text_hc.hex_color()
    print(result)
    assert result[0] == '#'
    assert len(result) == 7
    assert result[1:].isalnum() == True

# Generated at 2022-06-12 02:38:06.431317
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    print("Text.alphabet(): ", Text.alphabet())
    

# Generated at 2022-06-12 02:38:16.586586
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    x = Text()
    for i in range(0, 50):
        print(x.swear_word())

# Generated at 2022-06-12 02:38:22.406688
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from mimesis.builtins import Text
    t = Text('en')
    test_hex_color = t.hex_color()
    assert len(test_hex_color) == 7
    assert test_hex_color.startswith('#')


# Generated at 2022-06-12 02:38:41.647039
# Unit test for method quote of class Text
def test_Text_quote():
    from mimesis.enums import Locale

    text = Text()
    text.seed(430)
    assert text.quote() == 'You got to ask yourself one question: "Do I feel lucky?" ' \
                           'Well, do ya, punk?'

    text.seed_instance(430, locales=[Locale.RU])
    assert text.quote() == 'Для начала ответьте сами себе на вопрос: «Вы чувствуете себя удачливым?»'

# Generated at 2022-06-12 02:39:02.255477
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.builtins import Address
    from mimesis.builtins import Person
    from mimesis.builtins import Datetime
    from mimesis.builtins import Internet
    from mimesis.builtins import Number

    t = Text(locale='ca', seed=1234)
    p = Person('ca', seed=1234)
    a = Address('ca', seed=1234)
    n = Number()
    i = Internet()
    d = Datetime(datetime_format='%Y-%m-%d', seed=1234)
    expected = p.get_full_name(gender=Gender.FEMALE)
    result = t.sentence()
    assert expected in result



# Generated at 2022-06-12 02:39:06.695858
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    print("\n")
    print("Testing Text.swear_word()")
    provider = Text("en")
    print(provider.swear_word())



# Generated at 2022-06-12 02:39:08.725918
# Unit test for method color of class Text
def test_Text_color():
    provider = Text()
    colors = set()
    QUANTITY = 1000
    for _ in range(QUANTITY):
        colors.add(provider.color())
    assert len(colors) == QUANTITY



# Generated at 2022-06-12 02:39:12.332634
# Unit test for method title of class Text
def test_Text_title():
    class_text = Text()
    result = class_text.title()
    assert type(result) is str


# Generated at 2022-06-12 02:39:13.693452
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.builtins import Text
    tt = Text()
    tt.title()


# Generated at 2022-06-12 02:39:17.628406
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color(safe=True)
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color[:1] == '#'


# Generated at 2022-06-12 02:39:19.548411
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    assert (Text().hex_color(safe = False)) == '#d8346b'


# Generated at 2022-06-12 02:39:21.854078
# Unit test for method words of class Text
def test_Text_words():
    a = Text()
    text = a.words(quantity=2)
    assert len(text)==2
    

# Generated at 2022-06-12 02:39:22.962072
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert len(text.swear_word()) > 2


# Generated at 2022-06-12 02:39:27.468788
# Unit test for constructor of class Text
def test_Text():
    text = Text("en")
    assert text.answer() in [
        "Yes",
        "No",
        "Probably",
        "Maybe",
        "Certainly",
        "I am not sure",
        "It is impossible",
        "I don't know",
    ]

# Generated at 2022-06-12 02:41:02.796785
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert isinstance(quote,str)


# Generated at 2022-06-12 02:41:03.685309
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())



# Generated at 2022-06-12 02:41:04.872785
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert len(color) >= 3


# Unit test method quote of class Text

# Generated at 2022-06-12 02:41:13.217539
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    s = text.hex_color()
    assert s != None, "Expected a color, but got the NoneType"
    assert s != '', "Expected a color, but got an empty string"
    assert len(s) == 7, "Expected a color with 7 characters, but got a string with {} characters".format(len(s))
    assert s[0] == '#', "Expected a color starting with '#', but got {}".format(s)

# Generated at 2022-06-12 02:41:21.714578
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Create a generator
    t1 = Text()
    t2 = Text()
    t3 = Text()
    t4 = Text()
    t5 = Text()
    # Use the generator
    print(t1.hex_color())
    print(t2.hex_color())
    print(t3.hex_color())
    print(t4.hex_color())
    print(t5.hex_color())
    # Redo the test to see if the results are the same
    print(t1.hex_color())
    print(t2.hex_color())
    print(t3.hex_color())
    print(t4.hex_color())
    print(t5.hex_color())
    # Use the generator
    print(t1.hex_color())
    print(t2.hex_color())

# Generated at 2022-06-12 02:41:25.074494
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    result = text.hex_color(False)
    assert isinstance(result, str) == True
    assert len(result) == 7


# Generated at 2022-06-12 02:41:27.917742
# Unit test for method words of class Text
def test_Text_words():
    print(Text().words(quantity=5))



# Generated at 2022-06-12 02:41:29.614765
# Unit test for method title of class Text
def test_Text_title():
    a = Text()
    for _ in range(100):
        assert len(a.title()) > 0


# Generated at 2022-06-12 02:41:30.878376
# Unit test for method level of class Text
def test_Text_level():
    text_data = Text(seed=0)
    assert text_data.level() == 'critical'



# Generated at 2022-06-12 02:41:32.327737
# Unit test for method sentence of class Text
def test_Text_sentence():
	provider = Text()
	sentence = provider.sentence()
	assert len(sentence) != 0
