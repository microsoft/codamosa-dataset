

# Generated at 2022-06-12 02:36:55.189067
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words_list = text.words(quantity=10)
    assert len(words_list) == 10

# Generated at 2022-06-12 02:37:12.462372
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    result = []
    for _ in range(50):
        result.append(Text().hex_color())
    assert isinstance(result, list)
    assert isinstance(result[0], str)
    assert isinstance(result[1], str)
    assert isinstance(result[2], str)
    print("result[0]: ", result[0])
    print("result[1]: ", result[1])
    print("result[2]: ", result[2])


# Generated at 2022-06-12 02:37:14.455720
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words']['bad']

# Generated at 2022-06-12 02:37:23.686806
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    generator = Text(locale='en')
    assert generator._hex_to_rgb('#FFFFFF') == (255, 255, 255)
    assert generator._hex_to_rgb('#123456') == (18, 52, 86)
    assert generator._hex_to_rgb('#D8346B') == (216, 52, 107)
    assert generator._hex_to_rgb('#D8346b') == (216, 52, 107)
    generator._locales = ['en']
    generator.random.seed(0)
    assert generator.rgb_color() == (0, 0, 0)
    assert generator.rgb_color(safe=True) == (0, 255, 0)
    hex_color = generator.hex_color()
    assert hex_color.startswith('#')

# Generated at 2022-06-12 02:37:28.050139
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Arrange
    text = Text()
    text.seed(0)

    # Act
    result = text.hex_color()

    # Assert
    assert result == '#e9c9d1'


# Generated at 2022-06-12 02:37:32.397803
# Unit test for method words of class Text
def test_Text_words():
    from mimesis import Text as text
    size = 5
    text = text()
    words = text.words(size)
    assert len(words) == size


# Generated at 2022-06-12 02:37:43.422085
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.numbers import Numbers
    rus = RussiaSpecProvider()
    text = Text(locale='ru')
    nums = Numbers()
    rus.create_person(gender=Gender.FEMALE)
    print(rus)
    print(rus.full_name)
    print(rus.full_name_male)
    print(rus.full_name_female)
    print(rus.personal_document_code)
    print(rus.personal_document_series)
    print(rus.personal_document_number)
    print(rus.first_name)
    print(rus.middle_name)

# Generated at 2022-06-12 02:37:46.345794
# Unit test for method title of class Text
def test_Text_title():
    f = Text("en")
    result = f.title()
    print(result)


# Generated at 2022-06-12 02:37:52.043658
# Unit test for method text of class Text
def test_Text_text():
    """Test that the method text of Text class works."""
    import pytest
    from mimesis.exceptions import NonEnumerableError
    t = Text()
    assert isinstance(t.text(), str) == True
    with pytest.raises(NonEnumerableError):
        t.text(quantity='Bad')
    with pytest.raises(NonEnumerableError):
        t.text(quantity=0)
    assert isinstance(t.text(quantity=1), str) == True

# Generated at 2022-06-12 02:37:54.687403
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert isinstance(text.words(), list)
    assert len(text.words()) == 5


# Generated at 2022-06-12 02:38:37.206083
# Unit test for method title of class Text
def test_Text_title():
    from mimesis.enums import Locale
    from mimesis.enums import Gender
    from mimesis.text import Text

    t = Text(Locale.EN, gender=Gender.MALE)
    assert t.title() == 'The text'

# Generated at 2022-06-12 02:38:39.460145
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert (answer in text._data['answers'])


# Generated at 2022-06-12 02:38:50.309441
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    a = Text(seed=123)
    assert a.alphabet(True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
                                'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    assert a.alphabet(False) == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
                                 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']


# Generated at 2022-06-12 02:38:54.951675
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # GIVEN
    txt =  Text("en_US")
    # WHEN
    result = txt.swear_word()
    # THEN
    assert result in ["ass", "bastard", "bitch", "bloody", "damn"]

# Generated at 2022-06-12 02:38:57.291956
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    expected = 'O que você gostaria de fazer hoje?'
    actual = text.title()
    assert expected == actual


# Generated at 2022-06-12 02:39:00.754608
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    data = Text(seed=42)

    res = data.alphabet(lower_case=True)
    assert res == "abcdefghijklmnopqrstuvwxyz"


# Generated at 2022-06-12 02:39:02.653656
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    data = Text()
    data2 = Text(seed=0)
    assert data.swear_word() == data2.swear_word()


# Generated at 2022-06-12 02:39:06.735164
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    result = text.alphabet()
    print(result)
    assert result != None



# Generated at 2022-06-12 02:39:08.572705
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    print("test_Text_hex_color: ")
    for x in range(100):
        assert len(Text.hex_color()) == 7 
test_Text_hex_color();

# Generated at 2022-06-12 02:39:11.849737
# Unit test for method answer of class Text
def test_Text_answer():
  d = Text()
  assert(d.answer() in d._data['answers'])
