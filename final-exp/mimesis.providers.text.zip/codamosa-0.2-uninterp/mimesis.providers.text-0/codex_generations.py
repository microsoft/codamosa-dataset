

# Generated at 2022-06-17 23:06:20.986059
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'
    assert t.__doc__ is not None


# Generated at 2022-06-17 23:06:22.861799
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-17 23:06:24.827145
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert len(color) > 0


# Generated at 2022-06-17 23:06:28.422735
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert isinstance(words, list)
    assert len(words) == 5
    assert isinstance(words[0], str)


# Generated at 2022-06-17 23:06:30.190454
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:06:33.193509
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote == "I'm going to make him an offer he can't refuse."


# Generated at 2022-06-17 23:06:36.817768
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'
    assert t.hex_color(safe=True) == '#1abc9c'


# Generated at 2022-06-17 23:06:40.346627
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert text.hex_color().startswith('#')
    assert len(text.hex_color(safe=True)) == 7
    assert text.hex_color(safe=True).startswith('#')


# Generated at 2022-06-17 23:06:44.410768
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert isinstance(t.alphabet(), list)
    assert isinstance(t.alphabet(lower_case=True), list)


# Generated at 2022-06-17 23:06:45.564108
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() is not None
