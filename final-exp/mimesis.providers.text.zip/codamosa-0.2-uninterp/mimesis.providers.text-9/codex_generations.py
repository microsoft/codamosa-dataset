

# Generated at 2022-06-17 23:06:21.501325
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:06:23.717912
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']


# Generated at 2022-06-17 23:06:26.601072
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:06:28.882243
# Unit test for method level of class Text
def test_Text_level():
    from mimesis.enums import Locale
    t = Text(Locale.EN)
    assert t.level() in t._data['level']

# Generated at 2022-06-17 23:06:31.601383
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == 'Привет'


# Generated at 2022-06-17 23:06:33.285553
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    level = t.level()
    assert level in t._data['level']


# Generated at 2022-06-17 23:06:35.074168
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3


# Generated at 2022-06-17 23:06:37.078097
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert len(text.word()) > 0


# Generated at 2022-06-17 23:06:38.709930
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-17 23:06:40.170863
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:56.395622
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:06:57.924276
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']

# Generated at 2022-06-17 23:06:59.409338
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(), str)


# Generated at 2022-06-17 23:07:01.709180
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:07:02.831678
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']

# Generated at 2022-06-17 23:07:13.336094
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.seed is not None
    assert text.random is not None
    assert text.random.seed is not None
    assert text.locale is not None
    assert text.datetime is not None
    assert text.seed == text.random.seed
    assert text.provider == 'text'
    assert text.type_ == 'providers'
    assert text.datetime.seed == text.seed
    assert text.datetime.random is not None
    assert text.datetime.random.seed == text.seed
    assert text.datetime.locale == text.locale
    assert text.datetime.type_ == 'datetime'
    assert text.datetime.provider == 'datetime'
    assert text.datetime.datetime is not None
    assert text.datetime.datetime.seed

# Generated at 2022-06-17 23:07:14.875574
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:17.538889
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color == (252, 85, 32)

# Generated at 2022-06-17 23:07:22.806498
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-17 23:07:24.881935
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:07:53.888677
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']

# Generated at 2022-06-17 23:07:55.297315
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == 'The quick brown fox jumps over the lazy dog'

# Generated at 2022-06-17 23:07:57.713415
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:07:59.224183
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color == (252, 85, 32)

# Generated at 2022-06-17 23:07:59.952553
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:08:01.294893
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() == "I'm not a robot"


# Generated at 2022-06-17 23:08:02.910303
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() != ''


# Generated at 2022-06-17 23:08:03.987113
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-17 23:08:05.503631
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() in text._data['color']


# Generated at 2022-06-17 23:08:08.361084
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0
