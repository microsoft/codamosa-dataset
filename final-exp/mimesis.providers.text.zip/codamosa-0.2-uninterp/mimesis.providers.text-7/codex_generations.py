

# Generated at 2022-06-17 23:06:16.947414
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    text.sentence()


# Generated at 2022-06-17 23:06:26.029508
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.seed is not None
    assert text.locale is not None
    assert text.random is not None
    assert text.datetime is not None
    assert text.provider is not None
    assert text.seed == text.random.seed
    assert text.seed == text.datetime.seed
    assert text.seed == text.provider.seed
    assert text.seed == text.random.seed
    assert text.seed == text.datetime.seed
    assert text.seed == text.provider.seed
    assert text.random is text.datetime.random
    assert text.random is text.provider.random
    assert text.datetime is text.provider.datetime


# Generated at 2022-06-17 23:06:27.923026
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:39.027208
# Unit test for method words of class Text
def test_Text_words():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.payment import Payment
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.geo import Geo
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.person import Person
   

# Generated at 2022-06-17 23:06:42.240660
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:06:44.524540
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:06:45.981289
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert text.sentence() in text._data['text']


# Generated at 2022-06-17 23:06:47.904796
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:06:49.983458
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()


# Generated at 2022-06-17 23:06:51.124015
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert title is not None


# Generated at 2022-06-17 23:07:23.394748
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.level() in t._data['level']
    assert t.text() in t._data['text']
    assert t.title() in t._data['text']
    assert t.sentence() in t._data['text']
    assert t.word() in t._data['words']['normal']
    assert t.swear_word() in t._data['words']['bad']
    assert t.quote() in t._data['quotes']
    assert t.color() in t._data['color']
    assert t.answer() in t._data['answers']

# Generated at 2022-06-17 23:07:25.100510
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title = t.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:28.701629
# Unit test for method words of class Text
def test_Text_words():
    """Test for method words of class Text."""
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10


# Generated at 2022-06-17 23:07:30.964181
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:07:35.670262
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7
    assert t.hex_color()[0] == '#'
    assert t.hex_color(safe=True)[0] == '#'


# Generated at 2022-06-17 23:07:38.129981
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() in t._data['text']


# Generated at 2022-06-17 23:07:44.983157
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert isinstance(t.rgb_color(), tuple)
    assert len(t.rgb_color()) == 3
    assert isinstance(t.rgb_color()[0], int)
    assert isinstance(t.rgb_color()[1], int)
    assert isinstance(t.rgb_color()[2], int)
    assert t.rgb_color()[0] >= 0
    assert t.rgb_color()[0] <= 255
    assert t.rgb_color()[1] >= 0
    assert t.rgb_color()[1] <= 255
    assert t.rgb_color()[2] >= 0
    assert t.rgb_color()[2] <= 255


# Generated at 2022-06-17 23:07:46.786279
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-17 23:07:55.343507
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-17 23:07:58.302459
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']


# Generated at 2022-06-17 23:10:46.773827
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:10:54.372230
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-17 23:10:55.689330
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert len(t.word()) > 0


# Generated at 2022-06-17 23:11:00.365373
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color[0] >= 0 and rgb_color[0] <= 255
    assert rgb_color[1] >= 0 and rgb_color[1] <= 255
    assert rgb_color[2] >= 0 and rgb_color[2] <= 255


# Generated at 2022-06-17 23:11:01.351668
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:11:04.740853
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']

# Generated at 2022-06-17 23:11:06.186686
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:11:09.994221
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3
    assert len(t.rgb_color(safe=True)) == 3


# Generated at 2022-06-17 23:11:11.468467
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']


# Generated at 2022-06-17 23:11:14.794131
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:15:31.981839
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:15:34.266812
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(), str)
    assert isinstance(text.text(quantity=1), str)


# Generated at 2022-06-17 23:15:36.234798
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:15:39.633977
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)


# Generated at 2022-06-17 23:15:42.153289
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == 'Как продать мороженное в Африке'

# Generated at 2022-06-17 23:15:44.897232
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:15:46.456772
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:15:48.231265
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:15:49.237041
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No']

# Generated at 2022-06-17 23:15:51.067315
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert sentence != ''
