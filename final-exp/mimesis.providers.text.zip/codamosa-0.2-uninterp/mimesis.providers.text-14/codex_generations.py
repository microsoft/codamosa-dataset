

# Generated at 2022-06-17 23:06:25.892644
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']


# Generated at 2022-06-17 23:06:28.799573
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() == 'Все просто и понятно.'


# Generated at 2022-06-17 23:06:30.190253
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert isinstance(t.text(), str)


# Generated at 2022-06-17 23:06:32.874075
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'


# Generated at 2022-06-17 23:06:34.529268
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-17 23:06:37.078139
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:37.870541
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() == (252, 85, 32)


# Generated at 2022-06-17 23:06:39.252925
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.provider == 'text'
    assert text.dataset == 'text.json'
    assert text.locale == 'en'
    assert text.seed is None


# Generated at 2022-06-17 23:06:40.444166
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-17 23:06:41.899829
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5
    assert isinstance(words, list)
    assert isinstance(words[0], str)


# Generated at 2022-06-17 23:07:05.020350
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']


# Generated at 2022-06-17 23:07:08.281239
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10
    assert isinstance(text.words(), list)
    assert isinstance(text.words(quantity=10), list)


# Generated at 2022-06-17 23:07:10.227352
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:07:12.636636
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
