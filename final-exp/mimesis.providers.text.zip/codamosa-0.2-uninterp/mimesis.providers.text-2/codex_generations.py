

# Generated at 2022-06-17 23:06:27.097775
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']


# Generated at 2022-06-17 23:06:29.633465
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:06:39.859882
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert isinstance(text.alphabet(), list)
    assert isinstance(text.level(), str)
    assert isinstance(text.text(), str)
    assert isinstance(text.sentence(), str)
    assert isinstance(text.title(), str)
    assert isinstance(text.words(), list)
    assert isinstance(text.word(), str)
    assert isinstance(text.swear_word(), str)
    assert isinstance(text.quote(), str)
    assert isinstance(text.color(), str)
    assert isinstance(text.hex_color(), str)
    assert isinstance(text.rgb_color(), tuple)
    assert isinstance(text.answer(), str)

# Generated at 2022-06-17 23:06:43.016713
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() == '"Bond... James Bond."'


# Generated at 2022-06-17 23:06:44.779212
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:46.536380
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in ['critical', 'high', 'medium', 'low', 'info']


# Generated at 2022-06-17 23:06:49.982990
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']


# Generated at 2022-06-17 23:06:51.540819
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:06:53.918266
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert sentence != ''


# Generated at 2022-06-17 23:06:56.640697
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence != ''
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:07:20.659439
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:07:22.850944
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:07:31.900009
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'


# Generated at 2022-06-17 23:07:34.251003
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:36.960888
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']

# Generated at 2022-06-17 23:07:39.247735
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:07:40.573433
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() in text._data['color']


# Generated at 2022-06-17 23:07:42.431527
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:07:44.289648
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10
    assert len(t.words(quantity=1)) == 1


# Generated at 2022-06-17 23:07:48.106000
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.text() != ''
    assert text.sentence() != ''
    assert text.title() != ''
    assert text.words() != ''
    assert text.word() != ''
    assert text.swear_word() != ''
    assert text.quote() != ''
    assert text.color() != ''
    assert text.hex_color() != ''
    assert text.rgb_color() != ''
    assert text.answer() != ''