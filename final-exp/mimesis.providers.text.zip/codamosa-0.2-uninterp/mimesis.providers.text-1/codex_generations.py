

# Generated at 2022-06-17 23:06:28.544049
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:31.651674
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    text = Text()
    assert text.hex_color() == '#d8346b'

# Generated at 2022-06-17 23:06:33.331275
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']

# Generated at 2022-06-17 23:06:35.123347
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:37.463986
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:06:38.327376
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:39.822151
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']

# Generated at 2022-06-17 23:06:43.414181
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert isinstance(quote, str)
    assert len(quote) > 0


# Generated at 2022-06-17 23:06:45.348555
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:06:47.248928
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0
