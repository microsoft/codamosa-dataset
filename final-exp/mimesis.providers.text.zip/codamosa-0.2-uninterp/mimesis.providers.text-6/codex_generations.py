

# Generated at 2022-06-17 23:06:17.666270
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']


# Generated at 2022-06-17 23:06:19.307808
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote in text._data['quotes']


# Generated at 2022-06-17 23:06:21.356123
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:06:23.601390
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence != ''
    assert sentence != None


# Generated at 2022-06-17 23:06:24.869449
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5


# Generated at 2022-06-17 23:06:27.283190
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'


# Generated at 2022-06-17 23:06:29.500813
# Unit test for method words of class Text
def test_Text_words():
    """Test for method words of class Text."""
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10
    assert len(t.words(quantity=1)) == 1


# Generated at 2022-06-17 23:06:31.850279
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:34.262261
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']


# Generated at 2022-06-17 23:06:36.817689
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert text.word() in text._data['words']['normal']


# Generated at 2022-06-17 23:06:49.983278
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test method hex_color of class Text."""
    text = Text()
    assert text.hex_color() != text.hex_color()


# Generated at 2022-06-17 23:06:50.890163
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert len(t.sentence()) > 0


# Generated at 2022-06-17 23:06:52.451418
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert t.title() != ''


# Generated at 2022-06-17 23:06:54.032173
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5


# Generated at 2022-06-17 23:06:56.395928
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:06:57.941548
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:58.861834
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:00.974248
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']

# Generated at 2022-06-17 23:07:02.400952
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:07:03.666164
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None


# Generated at 2022-06-17 23:07:34.290346
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text."""
    t = Text()
    assert t.color() in t._data['color']

# Generated at 2022-06-17 23:07:37.608292
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:07:39.635294
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:07:41.092892
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-17 23:07:42.164414
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() == 'Привет'

# Generated at 2022-06-17 23:07:48.148178
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    from mimesis.providers.science import Science
    from mimesis.providers.geography import Geography
    from mimesis.providers.transport import Transport
    from mimesis.providers.food import Food
    from mimesis.providers.unit import Unit
   

# Generated at 2022-06-17 23:07:50.865719
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5
    assert isinstance(words, list)
    assert isinstance(words[0], str)


# Generated at 2022-06-17 23:07:52.852601
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() != ''


# Generated at 2022-06-17 23:08:01.295327
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.provider == 'text'
    assert text.locale == 'en'
    assert text.seed is None
    assert text.seed_instance is None
    assert text.random is not None
    assert text.random is not None
    assert text.dataset is not None
    assert text.dataset is not None
    assert text.SPECIAL_CHARS is not None
    assert text.SPECIAL_CHARS is not None
    assert text.FLAGS is not None
    assert text.FLAGS is not None
    assert text.DEFAULT_LOCALE == 'en'
    assert text.LOCALES == ['en']
    assert text.__doc__ is not None
    assert text.__doc__ is not None
    assert text.__init__.__doc__ is not None

# Generated at 2022-06-17 23:08:02.910810
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() in t._data['text']