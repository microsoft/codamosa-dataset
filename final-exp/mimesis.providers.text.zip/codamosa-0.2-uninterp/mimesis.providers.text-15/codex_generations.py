

# Generated at 2022-06-17 23:07:54.463434
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words'].get('bad')

# Generated at 2022-06-17 23:07:56.949979
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:07:58.773997
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:08:00.092341
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert t.title() != ''


# Generated at 2022-06-17 23:08:02.920955
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert len(t.hex_color(safe=True)) == 7
    assert t.hex_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-17 23:08:04.920006
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:08.892753
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    text = Text()
    assert text.level() in text._data['level']

# Generated at 2022-06-17 23:08:10.827829
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:08:13.565942
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() != ''


# Generated at 2022-06-17 23:08:15.460365
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:13:33.655876
# Unit test for method quote of class Text
def test_Text_quote():
    """Unit test for method quote of class Text."""
    text = Text()
    quote = text.quote()
    assert isinstance(quote, str)
    assert len(quote) > 0


# Generated at 2022-06-17 23:13:35.642865
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:13:38.709125
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:13:41.829366
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in text._data['answers']

# Generated at 2022-06-17 23:13:45.620805
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:13:46.926648
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']

# Generated at 2022-06-17 23:13:49.661033
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    hex_color = text.hex_color()
    assert len(hex_color) == 7
    assert hex_color.startswith('#')
    assert hex_color[1:].isalnum()


# Generated at 2022-06-17 23:13:56.128983
# Unit test for method sentence of class Text
def test_Text_sentence():
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.providers.text import Text
    p = Person('en')
    t = Text('en')
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())
    print(t.sentence())

# Generated at 2022-06-17 23:13:59.021129
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)


# Generated at 2022-06-17 23:14:01.402086
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0
