

# Generated at 2022-06-17 23:06:16.180348
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:06:17.529246
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:06:19.750923
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']


# Generated at 2022-06-17 23:06:21.649725
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:06:25.004592
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert t.hex_color().startswith('#')
    assert t.hex_color(safe=True) in SAFE_COLORS


# Generated at 2022-06-17 23:06:27.405582
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:29.456054
# Unit test for method quote of class Text
def test_Text_quote():
    """Test Text.quote()"""
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:06:31.804554
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert t.sentence() in t._data['text']

# Generated at 2022-06-17 23:06:33.861008
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote != None
    assert type(quote) == str


# Generated at 2022-06-17 23:06:36.337574
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:07:32.025372
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:07:41.921914
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.answer() in ['Yes', 'No']
    assert text.color() in ['Red', 'Green', 'Blue']
    assert text.hex_color() in ['#d8346b', '#d8346b', '#d8346b']
    assert text.level() in ['critical', 'high', 'medium', 'low']
    assert text.rgb_color() in [(252, 85, 32), (252, 85, 32), (252, 85, 32)]
    assert text.sentence() in ['I love you.', 'I love you.', 'I love you.']
    assert text.swear_word() in ['Damn', 'Damn', 'Damn']
    assert text.text() in ['I love you.', 'I love you.', 'I love you.']
    assert text.title()

# Generated at 2022-06-17 23:07:43.912170
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'
    assert t.hex_color(safe=True) == '#1abc9c'


# Generated at 2022-06-17 23:07:44.742844
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    print(t.word())


# Generated at 2022-06-17 23:07:46.369074
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:07:49.261607
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=3)) == 3
    assert len(t.words(quantity=1)) == 1
    assert len(t.words(quantity=0)) == 0


# Generated at 2022-06-17 23:07:51.211227
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() != ''


# Generated at 2022-06-17 23:07:53.888391
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:07:55.009128
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    print(text.swear_word())


# Generated at 2022-06-17 23:07:57.998489
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:08:28.577713
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5


# Generated at 2022-06-17 23:08:29.649168
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:08:30.251083
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() != ''

# Generated at 2022-06-17 23:08:31.088369
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']

# Generated at 2022-06-17 23:08:33.625770
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:08:35.080858
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:08:38.310795
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:08:40.020132
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:41.136141
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    print(t.quote())


# Generated at 2022-06-17 23:08:43.155689
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words']['bad']