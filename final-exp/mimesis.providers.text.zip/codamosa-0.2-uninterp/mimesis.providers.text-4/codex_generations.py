

# Generated at 2022-06-17 23:06:12.636525
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)


# Generated at 2022-06-17 23:06:15.272735
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'


# Generated at 2022-06-17 23:06:19.010963
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color is not None
    assert isinstance(rgb_color, tuple)
    assert len(rgb_color) == 3
    assert all(isinstance(i, int) for i in rgb_color)


# Generated at 2022-06-17 23:06:23.247594
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert isinstance(text.rgb_color(), tuple)
    assert len(text.rgb_color()) == 3
    assert isinstance(text.rgb_color(safe=True), tuple)
    assert len(text.rgb_color(safe=True)) == 3


# Generated at 2022-06-17 23:06:24.563187
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:27.345505
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert answer in text._data['answers']


# Generated at 2022-06-17 23:06:29.056303
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:32.919520
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert len(words) == 5
    assert isinstance(words, list)
    assert isinstance(words[0], str)


# Generated at 2022-06-17 23:06:35.074612
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3
    assert len(t.rgb_color(safe=True)) == 3

# Generated at 2022-06-17 23:06:37.078347
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:44.966946
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() == 'I love you'


# Generated at 2022-06-17 23:06:46.411317
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:49.982957
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:06:51.300775
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert type(title) == str
    assert len(title) > 0


# Generated at 2022-06-17 23:06:52.356070
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None


# Generated at 2022-06-17 23:06:54.031565
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-17 23:06:56.016026
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert len(text.word()) > 0


# Generated at 2022-06-17 23:06:57.924240
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']


# Generated at 2022-06-17 23:07:00.360682
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:07:02.251428
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:07:23.080244
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert isinstance(text.text(), str)


# Generated at 2022-06-17 23:07:24.881446
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:07:28.498166
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10
    assert len(t.words(quantity=1)) == 1


# Generated at 2022-06-17 23:07:30.531124
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:07:33.058820
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() == "Bond... James Bond."

# Generated at 2022-06-17 23:07:34.331767
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()


# Generated at 2022-06-17 23:07:37.919540
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:07:39.057338
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.text() is not None

# Generated at 2022-06-17 23:07:40.127414
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    assert len(text.sentence()) > 0


# Generated at 2022-06-17 23:07:41.744226
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:08:18.272595
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:08:19.198860
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert isinstance(text.word(), str)


# Generated at 2022-06-17 23:08:20.101021
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']

# Generated at 2022-06-17 23:08:21.226658
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']


# Generated at 2022-06-17 23:08:24.079964
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:25.357389
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=5)
    assert len(words) == 5


# Generated at 2022-06-17 23:08:28.230015
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:29.302344
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote == "Bond... James Bond."

# Generated at 2022-06-17 23:08:39.000384
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-17 23:08:39.901797
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']