

# Generated at 2022-06-17 23:06:16.529781
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words'].get('bad')

# Generated at 2022-06-17 23:06:18.244696
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:06:20.596374
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:06:23.093071
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from mimesis.builtins import Text
    t = Text()
    assert t.rgb_color() == (252, 85, 32)


# Generated at 2022-06-17 23:06:24.035007
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()

# Generated at 2022-06-17 23:06:25.416626
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:06:27.281421
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text()) > 0


# Generated at 2022-06-17 23:06:29.008998
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:31.752137
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:33.417465
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:44.487859
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    assert text.title() in text._data['text']

# Generated at 2022-06-17 23:06:46.474860
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']


# Generated at 2022-06-17 23:06:49.983248
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert len(alphabet) == 26
    assert alphabet[0] == 'A'
    assert alphabet[-1] == 'Z'


# Generated at 2022-06-17 23:06:51.758932
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert isinstance(swear_word, str)
    assert len(swear_word) > 0


# Generated at 2022-06-17 23:06:54.150831
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-17 23:06:57.924229
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert t.hex_color() == '#d8346b'
    assert t.hex_color(safe=True) == '#1abc9c'


# Generated at 2022-06-17 23:07:00.890130
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words']['bad']

# Generated at 2022-06-17 23:07:01.752979
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None


# Generated at 2022-06-17 23:07:03.907162
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:07:06.460261
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']