

# Generated at 2022-06-17 23:06:13.123727
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:06:16.565773
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10


# Generated at 2022-06-17 23:06:17.597841
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:06:19.522981
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote == '"Bond... James Bond."'


# Generated at 2022-06-17 23:06:22.859869
# Unit test for method color of class Text
def test_Text_color():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    t = Text(Locale.EN)
    print(t.color())


# Generated at 2022-06-17 23:06:24.512816
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:06:26.780841
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:06:28.622453
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:06:32.830476
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3
    assert len(text.rgb_color(safe=False)) == 3


# Generated at 2022-06-17 23:06:34.975687
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote == "I'm gonna make him an offer he can't refuse."


# Generated at 2022-06-17 23:06:42.549058
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:06:43.398810
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:45.052198
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']

# Generated at 2022-06-17 23:06:46.175745
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()


# Generated at 2022-06-17 23:06:49.983408
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    swear_word = text.swear_word()
    assert swear_word in text._data['words']['bad']

# Generated at 2022-06-17 23:07:01.220487
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'
    assert text.__doc__ is not None
    assert text.__init__.__doc__ is not None
    assert text.alphabet.__doc__ is not None
    assert text.level.__doc__ is not None
    assert text.text.__doc__ is not None
    assert text.sentence.__doc__ is not None
    assert text.title.__doc__ is not None
    assert text.words.__doc__ is not None
    assert text.word.__doc__ is not None
    assert text.swear_word.__doc__ is not None
    assert text.quote.__doc__ is not None
    assert text.color.__doc__ is not None
    assert text.hex_color.__doc__ is not None
   

# Generated at 2022-06-17 23:07:06.913296
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    print(text.text())
    print(text.sentence())
    print(text.title())
    print(text.words())
    print(text.word())
    print(text.swear_word())
    print(text.quote())
    print(text.color())
    print(text.hex_color())
    print(text.rgb_color())
    print(text.answer())


# Generated at 2022-06-17 23:07:08.316967
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() == "Bond... James Bond."


# Generated at 2022-06-17 23:07:11.436621
# Unit test for method color of class Text
def test_Text_color():
    """Test for method color of class Text."""
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-17 23:07:12.961554
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:07:36.997464
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert sentence is not None


# Generated at 2022-06-17 23:07:38.297193
# Unit test for method text of class Text
def test_Text_text():
    t = Text()
    assert t.text() != ''


# Generated at 2022-06-17 23:07:40.017890
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-17 23:07:41.636178
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-17 23:07:43.209919
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    assert t.title() == 'Не получилось'


# Generated at 2022-06-17 23:07:44.719622
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:07:45.596674
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in ['Yes', 'No']

# Generated at 2022-06-17 23:07:46.869338
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:48.747242
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)
    assert len(title) > 0


# Generated at 2022-06-17 23:07:50.424808
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:08:30.041732
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert len(t.rgb_color()) == 3
    assert len(t.rgb_color(safe=True)) == 3


# Generated at 2022-06-17 23:08:31.309051
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert isinstance(quote, str)
    assert len(quote) > 0


# Generated at 2022-06-17 23:08:38.013039
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert isinstance(rgb_color, tuple)
    assert len(rgb_color) == 3
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)

# Generated at 2022-06-17 23:08:39.309470
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote()
    assert quote in text._data['quotes']

# Generated at 2022-06-17 23:08:41.136644
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert word is not None
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:08:42.613546
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:08:44.292637
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:46.079945
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']

# Generated at 2022-06-17 23:08:49.135734
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert len(text.alphabet()) == 26
    assert len(text.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:08:55.333581
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.title() is not None
    assert text.sentence() is not None
    assert text.words() is not None
    assert text.word() is not None
    assert text.swear_word() is not None
    assert text.quote() is not None
    assert text.color() is not None
    assert text.hex_color() is not None
    assert text.rgb_color() is not None
    assert text.answer() is not None