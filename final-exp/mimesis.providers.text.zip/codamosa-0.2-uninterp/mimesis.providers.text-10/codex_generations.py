

# Generated at 2022-06-17 23:06:25.947800
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:06:27.658221
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:06:32.962696
# Unit test for method words of class Text
def test_Text_words():
    """Unit test for method words of class Text."""
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10
    assert isinstance(text.words(), list)
    assert isinstance(text.words(quantity=10), list)


# Generated at 2022-06-17 23:06:44.524761
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.seed is not None
    assert t.locale is not None
    assert t.random is not None
    assert t.datetime is not None
    assert t.provider is not None
    assert t.seed == t.random.seed
    assert t.random.seed == t.datetime.seed
    assert t.random.seed == t.provider.seed
    assert t.datetime.seed == t.provider.seed
    assert t.datetime.locale == t.locale
    assert t.provider.locale == t.locale
    assert t.random.locale == t.locale
    assert t.provider.random is t.random
    assert t.provider.datetime is t.datetime
    assert t.provider.random is t.random

# Generated at 2022-06-17 23:06:46.260737
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:06:56.944205
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    assert text.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert text.alphabet(True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-17 23:06:58.600134
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:07:08.318910
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert text.alphabet(lower_case=True) == 'abcdefghijklmnopqrstuvwxyz'
    assert text.level() == 'critical'
    assert text.text() != ''
    assert text.sentence() != ''
    assert text.title() != ''
    assert text.words() != []
    assert text.word() != ''
    assert text.swear_word() != ''
    assert text.quote() != ''
    assert text.color() != ''
    assert text.hex_color() != ''
    assert text.rgb_color() != ()
    assert text.answer() != ''


# Generated at 2022-06-17 23:07:12.203237
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=5)
    assert len(words) == 5
    assert isinstance(words, list)
    assert isinstance(words[0], str)


# Generated at 2022-06-17 23:07:14.243127
# Unit test for method level of class Text
def test_Text_level():
    """Unit test for method level of class Text."""
    text = Text()
    assert text.level() in text._data['level']
