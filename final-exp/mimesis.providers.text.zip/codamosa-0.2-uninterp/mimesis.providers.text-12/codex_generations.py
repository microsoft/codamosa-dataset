

# Generated at 2022-06-17 23:06:24.117716
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:06:33.149047
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.text() is not None
    assert text.sentence() is not None
    assert text.title() is not None
    assert text.word() is not None
    assert text.words() is not None
    assert text.swear_word() is not None
    assert text.quote() is not None
    assert text.color() is not None
    assert text.hex_color() is not None
    assert text.rgb_color() is not None
    assert text.answer() is not None
    assert text.alphabet() is not None
    assert text.level() is not None

# Generated at 2022-06-17 23:06:35.325925
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3

# Generated at 2022-06-17 23:06:38.376903
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert isinstance(color, str)
    assert color in text._data['color']


# Generated at 2022-06-17 23:06:40.170139
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert word in text._data['words']['normal']


# Generated at 2022-06-17 23:06:43.510300
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in text._data['level']


# Generated at 2022-06-17 23:06:53.606243
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.seed is not None
    assert t.locale is not None
    assert t.random is not None
    assert t.datetime is not None
    assert t.provider is not None
    assert t.seed == t.random.seed
    assert t.seed == t.datetime.seed
    assert t.seed == t.provider.seed
    assert t.seed == t.seed
    assert t.locale == t.random.locale
    assert t.locale == t.datetime.locale
    assert t.locale == t.provider.locale
    assert t.locale == t.locale
    assert t.random == t.datetime.random
    assert t.random == t.provider.random
    assert t.random == t.random
    assert t.dat

# Generated at 2022-06-17 23:06:56.640320
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Test for method swear_word of class Text."""
    text = Text()
    assert text.swear_word() in text._data['words']['bad']

# Generated at 2022-06-17 23:07:06.139170
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert text.text() == "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."


# Generated at 2022-06-17 23:07:07.785459
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10
