

# Generated at 2022-06-17 23:06:11.541222
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7
    assert len(text.hex_color(safe=True)) == 7


# Generated at 2022-06-17 23:06:12.638040
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=10)) == 10


# Generated at 2022-06-17 23:06:15.135136
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    assert t.rgb_color() == (252, 85, 32)


# Generated at 2022-06-17 23:06:17.223513
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:06:19.417562
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:06:23.091395
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for method hex_color of class Text."""
    text = Text()
    assert text.hex_color() == '#d8346b'
    assert text.hex_color(safe=True) == '#1abc9c'


# Generated at 2022-06-17 23:06:24.737694
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert color in text._data['color']


# Generated at 2022-06-17 23:06:27.101911
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-17 23:06:29.066465
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    assert len(text.words()) == 5
    assert len(text.words(quantity=3)) == 3
    assert len(text.words(quantity=10)) == 10


# Generated at 2022-06-17 23:06:30.501309
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None


# Generated at 2022-06-17 23:06:39.106521
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert text.hex_color() == '#d8346b'
    assert text.hex_color(safe=True) == '#1abc9c'


# Generated at 2022-06-17 23:06:40.061261
# Unit test for method answer of class Text
def test_Text_answer():
    t = Text()
    assert t.answer() in t._data['answers']


# Generated at 2022-06-17 23:06:42.888785
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert t.quote() in t._data['quotes']

# Generated at 2022-06-17 23:06:45.315360
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert len(t.alphabet()) == 26
    assert len(t.alphabet(lower_case=True)) == 26


# Generated at 2022-06-17 23:06:46.789939
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:06:49.983330
# Unit test for method word of class Text
def test_Text_word():
    """Test method word of class Text."""
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:07:00.889627
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert t.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert t.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


# Generated at 2022-06-17 23:07:02.633565
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert text.swear_word() in text._data['words']['bad']


# Generated at 2022-06-17 23:07:05.856832
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)
    assert len(sentence) > 0


# Generated at 2022-06-17 23:07:07.265399
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    assert t.word() in t._data['words']['normal']


# Generated at 2022-06-17 23:07:28.366727
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() in text._data['quotes']


# Generated at 2022-06-17 23:07:33.797643
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)


# Generated at 2022-06-17 23:07:39.019938
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert len(rgb_color) == 3
    assert isinstance(rgb_color, tuple)
    assert isinstance(rgb_color[0], int)
    assert isinstance(rgb_color[1], int)
    assert isinstance(rgb_color[2], int)


# Generated at 2022-06-17 23:07:40.341228
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:07:41.920607
# Unit test for method words of class Text
def test_Text_words():
    text = Text('en')
    print(text.words(quantity=10))


# Generated at 2022-06-17 23:07:43.810684
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    t = Text()
    assert len(t.hex_color()) == 7
    assert t.hex_color().startswith('#')
    assert len(t.hex_color(safe=True)) == 7
    assert t.hex_color(safe=True).startswith('#')


# Generated at 2022-06-17 23:07:45.272084
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert isinstance(words, list)
    assert len(words) == 5


# Generated at 2022-06-17 23:07:46.559836
# Unit test for method words of class Text
def test_Text_words():
    t = Text()
    assert len(t.words()) == 5
    assert len(t.words(quantity=10)) == 10


# Generated at 2022-06-17 23:07:48.505090
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)
    assert len(word) > 0


# Generated at 2022-06-17 23:07:49.392419
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Yes', 'No']

# Generated at 2022-06-17 23:09:07.023635
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color()
    assert len(rgb) == 3
    assert isinstance(rgb, tuple)
    assert isinstance(rgb[0], int)
    assert isinstance(rgb[1], int)
    assert isinstance(rgb[2], int)


# Generated at 2022-06-17 23:09:08.638860
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert text.level() in text._data['level']


# Generated at 2022-06-17 23:09:09.432221
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-17 23:09:10.717340
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:09:13.125743
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:09:14.389122
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t = Text()
    assert t.swear_word() in t._data['words']['bad']

# Generated at 2022-06-17 23:09:15.794453
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert len(text.rgb_color()) == 3
    assert len(text.rgb_color(safe=True)) == 3

# Generated at 2022-06-17 23:09:17.707433
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert t.color() in t._data['color']


# Generated at 2022-06-17 23:09:19.102715
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str)


# Generated at 2022-06-17 23:09:20.153064
# Unit test for method sentence of class Text
def test_Text_sentence():
    t = Text()
    assert type(t.sentence()) == str
