

# Generated at 2022-06-25 21:16:59.632083
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    assert isinstance(text.rgb_color(False), tuple)
    assert isinstance(text.rgb_color(True), tuple)

# Generated at 2022-06-25 21:17:01.908406
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet()


# Generated at 2022-06-25 21:17:07.958855
# Unit test for method color of class Text
def test_Text_color():
    """Test for color."""
    text_ = Text()

    list = list()
    for _ in range(100):
        list.append(text_.color())

    assert len(text_._data['color']) == len(list)
    assert set(list) == set(text_._data['color'])



# Generated at 2022-06-25 21:17:11.373769
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    first = text.sentence()
    second = text.sentence()
    assert first != second


# Generated at 2022-06-25 21:17:13.322025
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert hasattr(text, 'random')


# Generated at 2022-06-25 21:17:15.740106
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text != None


# Generated at 2022-06-25 21:17:17.319958
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    assert text.quote() == text.quote()


# Generated at 2022-06-25 21:17:22.103215
# Unit test for method color of class Text
def test_Text_color():
    # Build
    text = Text()
    # Act
    color = text.color()
    color_is_str = type(color) is str
    # Assert
    assert color_is_str


# Generated at 2022-06-25 21:17:25.457783
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    text_1 = text_0.text()
    assert type(text_1) == str


# Generated at 2022-06-25 21:17:28.999266
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj is not None


# Generated at 2022-06-25 21:19:20.950723
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    word = text_0.word()
    assert isinstance(word, str)


# Generated at 2022-06-25 21:19:24.086798
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    assert text_0.hex_color(False) == '#1f2dbe'

# Generated at 2022-06-25 21:19:28.771420
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    assert text_0.alphabet(lower_case=True) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    assert text_0.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']


# Generated at 2022-06-25 21:19:30.597692
# Unit test for method quote of class Text
def test_Text_quote():
    """Test method quote of class Text"""
    text_1 = Text()
    str_0 = text_1.quote()
    print("Text quote: " + str_0)

#  Unit test for method title of class Text

# Generated at 2022-06-25 21:19:32.040859
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    assert isinstance(text_0.level(), str)


# Generated at 2022-06-25 21:19:33.611294
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    str_0 = text_0.swear_word()
    assert str_0


# Generated at 2022-06-25 21:19:34.655308
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    word = text_0.word()
    assert word


# Generated at 2022-06-25 21:19:35.824663
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    text_1 = text_0.text()
    assert type(text_1) is str


# Generated at 2022-06-25 21:19:37.945346
# Unit test for method word of class Text
def test_Text_word():
    text = Text('en')
    word = text.word()
    assert isinstance(word, str)
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-25 21:19:38.951898
# Unit test for method sentence of class Text
def test_Text_sentence():
    t=Text()
    s=t.sentence()
    return True


# Generated at 2022-06-25 21:23:42.496234
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_1 = Text()
    assert type(text_1.hex_color()) == str

# Generated at 2022-06-25 21:23:43.929541
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    list_0 = text_0.words()


# Generated at 2022-06-25 21:23:45.151026
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert Text().alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


# Generated at 2022-06-25 21:23:46.268913
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in text._data['answers']


# Generated at 2022-06-25 21:23:47.576685
# Unit test for method words of class Text
def test_Text_words():
    text_1 = Text()
    list_1 = text_1.words()
    assert len(list_1) == 5


# Generated at 2022-06-25 21:23:51.527194
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    text_0_quote = text_0.quote()


# Generated at 2022-06-25 21:23:52.843109
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    text_1 = text_0.word()
    assert isinstance(text_1, str)


# Generated at 2022-06-25 21:23:53.669322
# Unit test for method title of class Text
def test_Text_title():
    text_1 = Text()
    assert isinstance(text_1.title(), str)

# Generated at 2022-06-25 21:23:56.607882
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    from asserts import assert_true
    from mimesis.builtins import Text
    try:
        t = Text()

        assert_true(t.hex_color(safe=True) in SAFE_COLORS)
        assert_true(t.hex_color(safe=False) not in SAFE_COLORS)
    except Exception as e:
        assert False, e


# Generated at 2022-06-25 21:23:58.561162
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    rgb_0 = text_0.rgb_color()

    if type(rgb_0) not in [tuple]:
        print("test_Text_rgb_color(0) failed: unexpected return type")
