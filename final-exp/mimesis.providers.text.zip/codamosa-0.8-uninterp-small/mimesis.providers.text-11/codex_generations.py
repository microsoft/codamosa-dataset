

# Generated at 2022-06-25 21:17:03.805031
# Unit test for constructor of class Text
def test_Text():
    # test the Text class
    t0 = Text()
    str0 = t0.answer()

# Generated at 2022-06-25 21:17:05.911115
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    assert len(text_0.rgb_color()) == 3


# Generated at 2022-06-25 21:17:08.710379
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()

# Generated at 2022-06-25 21:17:19.929649
# Unit test for method text of class Text
def test_Text_text():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.utils import ProviderType
    import random
    import core.logic as logic
    import datetime
    import json

    random.seed(0)
    person = Person('en')
    address = Address('en')
    test_person = logic.Person(None)
    text = Text()

    # Create 100 test cases
    with open('test_cases.json', 'w') as file:
        test_cases = list()
        for _ in range(100):
            test_case = dict()
            test_case["name"] = text.words(random.randint(1, 2))

# Generated at 2022-06-25 21:17:22.748183
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()


# Generated at 2022-06-25 21:17:24.970955
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    str_0 = text.level()



# Generated at 2022-06-25 21:17:27.204229
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    assert type(text_0.color()) == str


# Generated at 2022-06-25 21:17:28.371529
# Unit test for method sentence of class Text
def test_Text_sentence():
    assert Text().sentence()


# Generated at 2022-06-25 21:17:31.938866
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    word_0 = text_0.word()
    assert isinstance(word_0, str)


# Generated at 2022-06-25 21:17:37.183575
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    str_0 = text_0.swear_word()
    assert isinstance(str_0, str)
    assert str_0 == 'Damn'


# Generated at 2022-06-25 21:17:52.669231
# Unit test for method color of class Text
def test_Text_color():
    str_0 = Text(seed=0).color()
    assert str_0 == 'Aqua'


# Generated at 2022-06-25 21:17:56.802940
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()
    assert len(str_0) > 1


# Generated at 2022-06-25 21:17:57.957237
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    assert text.swear_word() in text._data['words']['bad']


# Generated at 2022-06-25 21:18:00.263023
# Unit test for method color of class Text
def test_Text_color():
    print('Test method color of class Text')
    text_1 = Text()
    str_0 = text_1.color()
    print('Color name: {}'.format(str_0))
    assert(str_0 is not None)


# Generated at 2022-06-25 21:18:01.340676
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    assert len(text.swear_word()) > 0


# Generated at 2022-06-25 21:18:03.095369
# Unit test for method color of class Text
def test_Text_color():
    t0 = Text()
    r0 = t0.color()
    assert type(r0) == str, 'Return value is not string'


# Generated at 2022-06-25 21:18:07.557033
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    str_0 = text_0.word()


# Generated at 2022-06-25 21:18:09.278635
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_gen = Text()
    sentence = text_gen.sentence()


# Generated at 2022-06-25 21:18:13.637705
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()
    str_1 = text_0.sentence()


# Generated at 2022-06-25 21:18:17.188903
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """Unit test for method swear_word of class Text."""
    text_0 = Text()
    word_0 = text_0.swear_word()



# Generated at 2022-06-25 21:18:46.067932
# Unit test for method title of class Text
def test_Text_title():
    text_1 = Text()
    title_1 = text_1.title()


# Generated at 2022-06-25 21:18:55.970353
# Unit test for method title of class Text
def test_Text_title():
    # Input data for testing
    text_0 = Text()
    str_0 = text_0.title()
    _str_0 = text_0.title()
    _str_1 = text_0.title()
    _str_2 = text_0.title()
    _str_3 = text_0.title()
    _str_4 = text_0.title()
    # Testing
    assert str_0 != _str_0
    assert str_0 != _str_1
    assert str_0 != _str_2
    assert str_0 != _str_3
    assert str_0 != _str_4
    assert _str_0 != _str_1
    assert _str_0 != _str_2
    assert _str_0 != _str_3
    assert _str_0 != _str_4


# Generated at 2022-06-25 21:18:56.932002
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()


# Generated at 2022-06-25 21:18:59.901660
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet(lower_case=True)



# Generated at 2022-06-25 21:19:04.373710
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    
    assert len(text_0.alphabet()) == 29
    assert len(text_0.alphabet(lower_case=True)) == 29
    assert len(text_0.alphabet()) == 29
    assert len(text_0.alphabet(lower_case=True)) == 29
    assert len(text_0.alphabet()) == 26
    assert len(text_0.alphabet(lower_case=True)) == 26
    

# Generated at 2022-06-25 21:19:06.338580
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_1 = Text()
    str_1 = text_1.sentence()


# Generated at 2022-06-25 21:19:09.181975
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_obj = Text()
    swear_word = text_obj.swear_word()
    assert isinstance(swear_word, str) == True


# Generated at 2022-06-25 21:19:12.650922
# Unit test for method title of class Text
def test_Text_title():

    # Arrange
    title_Text = Text()

    # Act
    output_title_Text = title_Text.title()

    # Assert
    assert(output_title_Text is not None)


# Generated at 2022-06-25 21:19:14.245801
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    answer = text.answer()
    assert isinstance(answer, str)



# Generated at 2022-06-25 21:19:15.493307
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_0 = text_0.level()
