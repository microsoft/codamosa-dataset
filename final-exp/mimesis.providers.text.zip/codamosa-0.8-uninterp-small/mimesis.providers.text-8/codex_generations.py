

# Generated at 2022-06-25 21:17:08.112844
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    word_0 = text_0.word()


# Generated at 2022-06-25 21:17:17.345315
# Unit test for method quote of class Text
def test_Text_quote():
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()

    str_1 = text_1.quote()
    str_2 = text_2.quote()
    str_3 = text_3.quote()
    str_4 = text_4.quote()
    str_5 = text_5.quote()



# Generated at 2022-06-25 21:17:22.677694
# Unit test for method level of class Text
def test_Text_level():
    # Unit test for the level method
    text_0 = Text()
    str_0 = text_0.level()
    assert (type(str_0) == str)
    assert (len(str_0) >= 0)


# Generated at 2022-06-25 21:17:26.548652
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    for x in range(100):
        word = text.word()
        assert(len(word.split()) == 1)


# Generated at 2022-06-25 21:17:31.913507
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert isinstance(text.seed, str)
    assert isinstance(text.random, random.Random)
    assert isinstance(text.datetime, datetime.datetime)
    assert isinstance(text.provider_data, dict)
    assert isinstance(text.provider_name, str)
    assert isinstance(text.seed, str)
    assert isinstance(text.randomize, bool)
    assert isinstance(text.locale, str)


# Generated at 2022-06-25 21:17:36.530894
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    text_0.text(quantity=1)
    random_title = text_0.title()
    print(random_title)


# Generated at 2022-06-25 21:17:38.564883
# Unit test for method answer of class Text
def test_Text_answer():
    txt_1 = Text()
    assert isinstance(txt_1.answer(), str)



# Generated at 2022-06-25 21:17:42.292968
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    for _ in range(1000):
        str_0 = text_0.title()
        assert str_0


# Generated at 2022-06-25 21:17:45.232360
# Unit test for constructor of class Text
def test_Text():
    try:
        text_1 = Text()
        assert True
    except:
        assert False


# Generated at 2022-06-25 21:17:52.232081
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    assert len(Text().alphabet()) == 26
    assert Text().alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
                                 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                                 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert len(Text().alphabet(lower_case=True)) == 26

# Generated at 2022-06-25 21:18:44.315670
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text is not None

# Generated at 2022-06-25 21:18:49.546121
# Unit test for method color of class Text
def test_Text_color():
    assert Text().color() in ['Crimson',
                              'DarkMagenta',
                              'DeepPink',
                              'Lavender',
                              'Orchid',
                              'Plum',
                              'Violet',
                              'Purple']


# Generated at 2022-06-25 21:18:55.970643
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t0 = Text()
    r = t0.rgb_color()
    assert len(r)==3
    r = t0.rgb_color(safe=True)
    assert len(r)==3


# Generated at 2022-06-25 21:18:59.085627
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    ret_1 = t.alphabet(False)
    assert ret_1 != None


# Generated at 2022-06-25 21:19:01.005322
# Unit test for method color of class Text
def test_Text_color():
    t = Text()
    assert type(t.color()) == str


# Generated at 2022-06-25 21:19:03.947543
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()

    text_0.hex_color() == text_1.hex_color() == text_2.hex_color()
    text_0.hex_color() != text_1.hex_color() != text_2.hex_color()


# Generated at 2022-06-25 21:19:09.349053
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    str_0 = text_0.answer()
    #   text_0.answer() =>  'Yes'
    #   text_0.answer() =>  'No'
    assert text_0.answer() == 'No' or text_0.answer() == 'Yes'
#   print(text_0.answer())



# Generated at 2022-06-25 21:19:14.785317
# Unit test for method text of class Text
def test_Text_text():
    # Set up test values
    text_0 = Text()
    integer_0 = 10

    # Call method
    str_0 = text_0.text(integer_0)

    # Check result
    assert len(str_0) > integer_0
    for word in str_0.split(' '):
        assert len(word) > 0 and word[0].isupper()


# Generated at 2022-06-25 21:19:16.268407
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    test_0 = Text()
    assert len(test_0.rgb_color()) == 3


# Generated at 2022-06-25 21:19:17.406999
# Unit test for method word of class Text
def test_Text_word():
    sl = Text()
    word = sl.word()
    assert isinstance(word, str)


# Generated at 2022-06-25 21:20:07.625035
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    assert len(text_0.words()) == 5


# Generated at 2022-06-25 21:20:08.936592
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    str_0 = text_0.word()


# Generated at 2022-06-25 21:20:11.394027
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_1 = Text()
    text_1.seed(42)
    assert text_1.hex_color(safe=True) == '#2f9fc9'
    assert text_1.hex_color(safe=False) == '#c0bda8'


# Generated at 2022-06-25 21:20:13.164353
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_1 = Text()
    list_0 = text_1.alphabet()


# Generated at 2022-06-25 21:20:14.673921
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_1 = Text()
    assert len(text_1.hex_color()) == 7

# Generated at 2022-06-25 21:20:15.303108
# Unit test for method answer of class Text
def test_Text_answer():
    test_case_0()

# Generated at 2022-06-25 21:20:17.103445
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # Asserts
    assert Text().rgb_color() in Text().rgb_color()


# Generated at 2022-06-25 21:20:18.416798
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()


# Generated at 2022-06-25 21:20:20.753457
# Unit test for method word of class Text
def test_Text_word():
    text_1 = Text()
    str_1 = text_1.word()
    assert str_1 in text_1._data['words'].get('normal')

# Generated at 2022-06-25 21:20:21.854071
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()



# Generated at 2022-06-25 21:21:52.898813
# Unit test for method color of class Text
def test_Text_color():
    assert len(Text().color()) > 0


# Generated at 2022-06-25 21:21:54.357192
# Unit test for method title of class Text
def test_Text_title():
    some_text_t0 = Text(seed=0)
    txt_t0 = some_text_t0.title()
    assert txt_t0 == 'Battle'


# Generated at 2022-06-25 21:21:55.536244
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_0 = text_0.level()


# Generated at 2022-06-25 21:21:56.789126
# Unit test for constructor of class Text
def test_Text():
    test_case_0()

# Generated at 2022-06-25 21:21:58.356053
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()


# Generated at 2022-06-25 21:21:59.737736
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    assert type(text_0.text()) == str

# Generated at 2022-06-25 21:22:01.568398
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_1 = text_0.level()
    assert str_1 is not None


# Generated at 2022-06-25 21:22:02.952954
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    text.text()


# Generated at 2022-06-25 21:22:07.418825
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    """Check colors."""
    text_obj = Text()
    for i in range(50):
        rgb_color = text_obj.rgb_color()
        assert len(rgb_color) == 3
        assert all(isinstance(x, int) for x in rgb_color)
        assert all(0 <= x <= 255 for x in rgb_color)


# Generated at 2022-06-25 21:22:08.319219
# Unit test for method words of class Text
def test_Text_words():
    # TODO: IMPLEMENT
    pass
    # find a way to test it.