

# Generated at 2022-06-25 21:16:58.782383
# Unit test for method color of class Text
def test_Text_color():
    # Create new instance of Text
    text = Text()
    text.color()


# Generated at 2022-06-25 21:16:59.515139
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    test_case_0()


# Generated at 2022-06-25 21:17:03.476285
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:17:05.778247
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert len(word) > 0


# Generated at 2022-06-25 21:17:09.177319
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    list_0 = text_0.words()


# Generated at 2022-06-25 21:17:20.082292
# Unit test for method answer of class Text
def test_Text_answer():
    from mimesis.enums import Field
    from mimesis.providers.text import Text
    from mimesis.builtins import TextSpecProvider
    from mimesis.typing import ProviderT
    t = Text('en')
    assert isinstance(t, (Text, TextSpecProvider))
    assert t._seed is None
    assert t.seed_instance('nice') is None
    assert t._seed == 'nice'
    assert t.create(Field.ANSWER) in t._data['answers']
    assert t.hash_code() is None
    assert t._hash_code == ''
    assert 'mimesis.builtins.TextSpecProvider' in repr(t)
    assert '<TextSpecProvider' in str(t)

test_case_0()
test_Text_answer()

# Generated at 2022-06-25 21:17:20.960839
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    txt = Text()
    txt.alphabet()
    txt.alphabet(lower_case=True)


# Generated at 2022-06-25 21:17:24.907271
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet()
    str_1 = text_0.alphabet(lower_case=True)


# Generated at 2022-06-25 21:17:26.813120
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    q = t.quote()
    assert q


# Generated at 2022-06-25 21:17:29.761819
# Unit test for constructor of class Text
def test_Text():
    """Test constructor of class Text."""
    text_0 = Text()
    assert text_0.__class__.__name__ == 'Text'


# Generated at 2022-06-25 21:18:09.313592
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    str_0 = text_0.hex_color()
    text_1 = Text()
    str_1 = text_1.hex_color()
    assert (str_0 != str_1)

# Generated at 2022-06-25 21:18:15.347456
# Unit test for method color of class Text
def test_Text_color():
    try:
        safes = list(filter(lambda s: s.startswith('#'),
                            Text().hex_color(safe=True)))
        assert len(safes) == 13
    except:
        assert False


# Generated at 2022-06-25 21:18:17.798419
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    str_0 = text_0.color()


# Generated at 2022-06-25 21:18:19.181359
# Unit test for method text of class Text
def test_Text_text():
    text_1 = Text()
    x = text_1.text()


# Generated at 2022-06-25 21:18:22.968374
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    word_0 = text_0.word()


# Generated at 2022-06-25 21:18:25.353318
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    str_0 = text_0.color()



# Generated at 2022-06-25 21:18:29.594797
# Unit test for method title of class Text
def test_Text_title():
    t = Text(seed=42)
    assert t.title() == 'The new technology'
    assert t.title() == 'The best thing'
    assert t.title() == 'The best program'
    

# Generated at 2022-06-25 21:18:34.732576
# Unit test for method word of class Text
def test_Text_word():
    for _ in range(20):
        word_0 = Text().word()
        assert isinstance(word_0, str)


if __name__ == "__main__":
    test_case_0()
    test_Text_word()

# Generated at 2022-06-25 21:18:38.847753
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    str = text.answer()
    assert isinstance(str, str)
    assert isinstance(str, str)



# Generated at 2022-06-25 21:18:40.620320
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    c = text.color()
    assert isinstance(c, str)
    