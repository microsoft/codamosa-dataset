

# Generated at 2022-06-25 21:18:04.431822
# Unit test for method title of class Text
def test_Text_title():
    assert str is type(Text().title())


# Generated at 2022-06-25 21:18:11.840226
# Unit test for method quote of class Text
def test_Text_quote():
    # Example call #0
    text_0 = Text()
    str_0 = text_0.quote()
    assert(str_0 == '"Bond... James Bond."')
    # Example call #1
    text_0 = Text()
    str_0 = text_0.quote()
    assert(str_0 == '"Life moves pretty fast. If you don\'t stop and look around once in a while, you could miss it."')
    # Example call #2
    text_0 = Text()
    str_0 = text_0.quote()
    assert(str_0 == '"You know how to whistle, don\'t you, Steve? You just put your lips together and... blow."')
    # Example call #3
    text_0 = Text()
    str_0 = text_0.quote()

# Generated at 2022-06-25 21:18:14.239391
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    print(text.sentence())


# Generated at 2022-06-25 21:18:16.809351
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert(len(word) > 0)


# Generated at 2022-06-25 21:18:19.735713
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Unit test for method hex_color of class Text."""
    text_1 = Text()
    str_0 = text_1.hex_color()
    print(str_0, '👈')


# Generated at 2022-06-25 21:18:23.494639
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    assert isinstance(sentence, str) and sentence


# Generated at 2022-06-25 21:18:24.652809
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    words = text.swear_word()
    assert words in text._data['words'].get('bad')

# Generated at 2022-06-25 21:18:26.908146
# Unit test for method word of class Text
def test_Text_word():
    text1 = Text()
    print(text1.word())


# Generated at 2022-06-25 21:18:30.686762
# Unit test for method color of class Text
def test_Text_color():
    """Get a random name of color.

    :return: Color name.

    :Example:
        Red.
    """
    text_0 = Text(seed=0)
    str_0 = text_0.color()
    assert str_0 == 'Violet'


# Generated at 2022-06-25 21:18:31.580677
# Unit test for method quote of class Text
def test_Text_quote():
    assert Text().quote() == "That's the second biggest monkey head I've ever seen."


# Generated at 2022-06-25 21:20:18.416836
# Unit test for method word of class Text
def test_Text_word():
    t = Text()
    result = t.word()
    assert True is not False


# Generated at 2022-06-25 21:20:21.673190
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    assert isinstance(text_0.alphabet(), list)
    assert len(text_0.alphabet()) == 26
    assert isinstance(text_0.alphabet(), list)
    assert len(text_0.alphabet(True)) == 26


# Generated at 2022-06-25 21:20:23.009866
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    str_0 = text_0.swear_word()


# Generated at 2022-06-25 21:20:23.799732
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    result = text.alphabet()


# Generated at 2022-06-25 21:20:26.430536
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    assert len(text_0.color()) == 4
    assert len(text_0.color()) == 9
    assert len(text_0.color()) == 4
    assert len(text_0.color()) == 9


# Generated at 2022-06-25 21:20:27.351477
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text(seed=0)
    assert text.answer() == 'Yes'



# Generated at 2022-06-25 21:20:29.583318
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text() 
    result = text_0.swear_word()
    assert isinstance(result, str) is True


# Generated at 2022-06-25 21:20:31.569622
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    text_0 = Text(locale='ru')



# Generated at 2022-06-25 21:20:33.135433
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()
    assert str_0 is not None
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:20:34.633139
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()
    assert str_0


# Generated at 2022-06-25 21:21:39.077072
# Unit test for constructor of class Text
def test_Text():
    t1 = Text()
    x = t1.alphabet()
    assert len(x) > 1


# Generated at 2022-06-25 21:21:40.301651
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    str_0 = Text.swear_word()
    assert str_0 != ''


# Generated at 2022-06-25 21:21:41.172046
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet()


# Generated at 2022-06-25 21:21:44.102002
# Unit test for method answer of class Text
def test_Text_answer():
    # String
    str_0 = Text().answer()
    assert isinstance(str_0, str)
    # String
    str_1 = Text().answer()
    assert isinstance(str_1, str)
    # String
    str_2 = Text().answer()
    assert isinstance(str_2, str)
    # String
    str_3 = Text().answer()
    assert isinstance(str_3, str)


# Generated at 2022-06-25 21:21:45.332660
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    assert isinstance(text_0.hex_color(), str)

# Generated at 2022-06-25 21:21:46.589956
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    sentence_0 = text_0.sentence()
    return sentence_0


# Generated at 2022-06-25 21:21:50.835398
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_1 = Text()
    assert text_1.sentence() in text_1._data['text']


# Generated at 2022-06-25 21:21:51.855184
# Unit test for method title of class Text
def test_Text_title():
    str_0 = Text().title()
    assert str_0 is not None


# Generated at 2022-06-25 21:21:52.816606
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()


# Generated at 2022-06-25 21:21:53.785499
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()

