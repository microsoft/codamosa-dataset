

# Generated at 2022-06-25 21:17:30.093830
# Unit test for method text of class Text
def test_Text_text():
    text_1 = Text()
    assert len(text_1.text(5)) > 0
    assert type(text_1.text(5)) == str


# Generated at 2022-06-25 21:17:32.827307
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    res_0 = text_0.color()



# Generated at 2022-06-25 21:17:38.530998
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_1 = Text(seed=1)
    result = text_1.rgb_color()
    expected = (246, 107, 66)
    assert result == expected
    result_1 = text_1.rgb_color()
    assert result_1 == result


# Generated at 2022-06-25 21:17:41.149709
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    result = text_0.color()
    assert result != None


# Generated at 2022-06-25 21:17:44.341798
# Unit test for method words of class Text
def test_Text_words():
    test_case_0()
    words = Text().words(quantity=10)
    assert len(words) == 10


# Generated at 2022-06-25 21:17:47.554138
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = ' '
    assert text_0.title() != str_0


# Generated at 2022-06-25 21:17:50.638963
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb_color = text.rgb_color()
    assert rgb_color != None


# Generated at 2022-06-25 21:17:56.177895
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    text_0.answer()
    text_0.answer()
    text_0.answer()
    text_0.answer()
    text_0.answer()


# Generated at 2022-06-25 21:17:58.047368
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    assert Text().swear_word() == Text().swear_word()


# Generated at 2022-06-25 21:18:10.343396
# Unit test for constructor of class Text

# Generated at 2022-06-25 21:21:08.168186
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_1 = Text()
    print("\n".join([text_1.hex_color() for _ in range(10)]))


# Generated at 2022-06-25 21:21:10.246993
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # case 0
    text = Text()
    assert len(text.rgb_color()) is 3


# Generated at 2022-06-25 21:21:13.613510
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()
    print(str_0)
    assert str_0 == 'Yes' or str_0 == 'No' or str_0 == 'Sometimes' or str_0 == 'Maybe' or str_0 == 'Probably' or str_0 == 'Probably not' or str_0 == 'Probably yes'


# Generated at 2022-06-25 21:21:15.453141
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text('en')
    assert len(text.alphabet()) == 26

    text = Text('ru')
    assert len(text.alphabet()) == 33


# Generated at 2022-06-25 21:21:17.064983
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    assert text_0.swear_word() in text_0.data["words"]["bad"]

# Unit tests for method word of class Text

# Generated at 2022-06-25 21:21:17.853310
# Unit test for constructor of class Text
def test_Text():
    assert Text().__init__

# Generated at 2022-06-25 21:21:19.544181
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_1 = Text()
    assert text_1.sentence()



# Generated at 2022-06-25 21:21:21.603688
# Unit test for method words of class Text
def test_Text_words():
    sample_size = 100
    default_quantity = 5
    for i in range(sample_size):
        text_words_returned = Text().words()
        assert(len(text_words_returned) == default_quantity)


# Generated at 2022-06-25 21:21:22.304603
# Unit test for method title of class Text
def test_Text_title():
    assert len(Text().title()) <= 15

# Generated at 2022-06-25 21:21:23.487234
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # to be written
    assert True


if __name__ == '__main__':
    test_case_0()