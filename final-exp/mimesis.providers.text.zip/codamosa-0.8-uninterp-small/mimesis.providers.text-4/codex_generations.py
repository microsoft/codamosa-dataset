

# Generated at 2022-06-25 21:16:54.328975
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert type(text.level()) == str


# Generated at 2022-06-25 21:16:55.930070
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    assert isinstance(text_0.swear_word(), str)


# Generated at 2022-06-25 21:16:56.789334
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    text_0.quote()


# Generated at 2022-06-25 21:17:08.875576
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    """Test for method hex_color"""
    text_0 = Text()
    assert text_0.hex_color() == '#e36e62'
    assert text_0.hex_color() == '#26b46e'
    assert text_0.hex_color() == '#9fed4e'
    assert text_0.hex_color() == '#5bc5bc'
    assert text_0.hex_color() == '#b38bbe'
    assert text_0.hex_color() == '#c0b08a'
    assert text_0.hex_color() == '#ac9575'
    assert text_0.hex_color() == '#b6997a'
    assert text_0.hex_color() == '#e4c8cb'
    assert text_0.hex_color

# Generated at 2022-06-25 21:17:11.232007
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    text_0.quote()


# Generated at 2022-06-25 21:17:17.316408
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    # check to see if a hex color is retured
    assert text_0.hex_color()
    # check to see if a safe hex color is retured
    assert text_0.hex_color(True)


# Generated at 2022-06-25 21:17:22.103114
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_1.hex_color(True)
    text_2.hex_color(True)

# Generated at 2022-06-25 21:17:24.901714
# Unit test for constructor of class Text
def test_Text():
    text_1 = Text()
    assert isinstance(text_1, Text)


# Generated at 2022-06-25 21:17:29.706745
# Unit test for method title of class Text
def test_Text_title():
    text_1 = Text()
    assert hasattr(text_1, 'title')
    assert text_1.title() == text_1.text(1)


# Generated at 2022-06-25 21:17:32.408404
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    for _ in range(100):
        text_0 = Text()
        _ = text_0.rgb_color()

# Generated at 2022-06-25 21:17:45.431373
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()

    assert len(text_0.words()) == 5


# Generated at 2022-06-25 21:17:47.380607
# Unit test for constructor of class Text
def test_Text():
    assert Text()
    assert Text._datafile == 'text.json'


# Generated at 2022-06-25 21:17:50.768024
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    assert text_0.alphabet() == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert text_0.alphabet(False) == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert text_0.alphabet(True) == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-25 21:17:53.636959
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text = Text()
    assert len(text.hex_color()) == 7


# Generated at 2022-06-25 21:18:02.896867
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()

# Generated at 2022-06-25 21:18:08.202570
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    import random

    random.seed(123)
    text_0 = Text()
    word = text_0.swear_word()
    assert word == "shit"

# Generated at 2022-06-25 21:18:09.775119
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    assert isinstance(text_0.word(), str)

# Generated at 2022-06-25 21:18:13.015180
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    assert text_0


# Generated at 2022-06-25 21:18:14.916569
# Unit test for method quote of class Text
def test_Text_quote():
    txt = Text()
    txt.quote()


# Generated at 2022-06-25 21:18:18.477348
# Unit test for method color of class Text
def test_Text_color():
    print('# Test method color of class Text')

    text_0 = Text()
    color_str = text_0.color()
    print(color_str)


# Generated at 2022-06-25 21:18:42.025056
# Unit test for method sentence of class Text
def test_Text_sentence():
    """Test case for method sentence of class Text"""
    text_0 = Text()
    text_1 = Text()
    text_2 = Text(seed=1234)
    text_3 = Text(seed=1234)
    print("Text sentence: " + text_0.sentence())
    print("Text sentence: " + text_1.sentence())
    print("Text sentence: " + text_2.sentence())
    print("Text sentence: " + text_3.sentence())
    
    

# Generated at 2022-06-25 21:18:46.309626
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    result = text_0.title()
    assert type(result)==str


# Generated at 2022-06-25 21:18:55.970795
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    words_0 = text_0.words(quantity=5)
    words_1 = text_0.words(quantity=5)
    words_2 = text_0.words(quantity=5)
    words_3 = text_0.words(quantity=5)
    words_4 = text_0.words(quantity=5)
    assert isinstance(words_0, list)
    assert isinstance(words_1, list)
    assert isinstance(words_2, list)
    assert isinstance(words_3, list)
    assert isinstance(words_4, list)
    print("assert isinstance(words, list)")
    print("words_0 : ", words_0)
    print("words_1 : ", words_1)

# Generated at 2022-06-25 21:19:00.170425
# Unit test for constructor of class Text
def test_Text():
    # This is what I'm trying to test.
    text_0 = Text()
    assert text_0 != None
    assert text_0 != ''
    assert text_0 != "This is the wrong text."


# Generated at 2022-06-25 21:19:01.639018
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()
    assert type(color) == str


# Generated at 2022-06-25 21:19:02.723593
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    # check for the color
    assert (text_0.color() == "white")


# Generated at 2022-06-25 21:19:03.816364
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_2 = Text()
    assert text_2.swear_word() == 'Damn'


# Generated at 2022-06-25 21:19:04.999579
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    quote_0 = text_0.quote()
    print(quote_0)


# Generated at 2022-06-25 21:19:06.754245
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in Text()._data['answers']


# Generated at 2022-06-25 21:19:09.005228
# Unit test for method level of class Text
def test_Text_level():
    t = Text()
    assert t.level() in t._data['level']


# Generated at 2022-06-25 21:19:50.341305
# Unit test for method quote of class Text
def test_Text_quote():
    assert len(Text().quote()) > 0


# Generated at 2022-06-25 21:19:51.481127
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert text.answer() in ['Y' ,'No','Yes','N','Yes','No','Y']


# Generated at 2022-06-25 21:19:53.456758
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    assert len(text_0.words(5)) == 5


# Generated at 2022-06-25 21:19:54.288074
# Unit test for method color of class Text
def test_Text_color():
    control = Text()
    print(control.color())



# Generated at 2022-06-25 21:19:55.307341
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    assert text_0 is not None


# Generated at 2022-06-25 21:19:56.364142
# Unit test for method text of class Text
def test_Text_text():
    
    text = Text()
    text_0 = text.text()


# Generated at 2022-06-25 21:19:58.885240
# Unit test for method words of class Text
def test_Text_words():
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_list = [text_1.words(), text_2.words(), text_3.words(), text_4.words()]
    print(text_list)



# Generated at 2022-06-25 21:19:59.771368
# Unit test for method answer of class Text
def test_Text_answer():
    assert Text().answer() in ["No", "Yes"]



# Generated at 2022-06-25 21:20:04.229152
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    Test_alphabet = text_0.alphabet()
    assert Test_alphabet == list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    Test_alphabet = text_0.alphabet(True)
    assert Test_alphabet == list('abcdefghijklmnopqrstuvwxyz')
    Test_alphabet = text_0.alphabet(False)
    assert Test_alphabet == list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')


# Generated at 2022-06-25 21:20:05.105478
# Unit test for method answer of class Text
def test_Text_answer():
    text_1 = Text()
    text_1.answer()


# Generated at 2022-06-25 21:21:31.373509
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None, "Constructor Test"
    assert t.random is not None, "Random object not created"
    assert t._data is not None, "Data not loaded"


# Generated at 2022-06-25 21:21:36.579972
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    assert type(text_0.alphabet()) is list
    assert type(text_0.level()) is str
    assert type(text_0.text()) is str
    assert type(text_0.sentence()) is str
    assert type(text_0.title()) is str
    assert type(text_0.word()) is str
    assert type(text_0.words()) is list
    assert type(text_0.swear_word()) is str
    assert type(text_0.quote()) is str
    assert type(text_0.color()) is str
    assert type(text_0.hex_color()) is str
    assert type(text_0.rgb_color()) is tuple
    assert type(text_0.answer()) is str

# Generated at 2022-06-25 21:21:37.591904
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    f = text_0.words()
    assert isinstance(f, list), "Return type mismatch"


# Generated at 2022-06-25 21:21:38.786321
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    result = text.rgb_color()
    assert len(result) == 3
    assert result[2] >= 0 and result[2] <= 255

# Generated at 2022-06-25 21:21:40.154602
# Unit test for method word of class Text
def test_Text_word():
    text_1 = Text()
    words = text_1.word()
    assert len(words) > 0


# Generated at 2022-06-25 21:21:41.373617
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    text_0.alphabet()
    text_1 = Text()
    text_1.alphabet(lower_case=True)


# Generated at 2022-06-25 21:21:43.278932
# Unit test for method level of class Text
def test_Text_level():
    text_1 = Text()
    level_0 = text_1.level()
    assert isinstance(level_0, str)
    assert level_0 in ['critical', 'high', 'medium', 'low']


# Generated at 2022-06-25 21:21:44.642757
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    if not isinstance(sentence, str):
        raise AssertionError("Wrong type for sentence: " + sentence)


# Generated at 2022-06-25 21:21:45.999670
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    assert isinstance(text_0.color(), str)


# Generated at 2022-06-25 21:21:50.681374
# Unit test for method title of class Text
def test_Text_title():

    text_0 = Text()
    #assert text_0.title() == ""
    text_0 = Text(seed=456)
    #assert text_0.title() == ""

