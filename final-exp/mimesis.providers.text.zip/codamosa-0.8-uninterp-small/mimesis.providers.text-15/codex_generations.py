

# Generated at 2022-06-25 21:16:59.910458
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_1 = Text()
    assert text_1.sentence() is not None


# Generated at 2022-06-25 21:17:03.771532
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    assert len(text_0.hex_color()) == 7


# Generated at 2022-06-25 21:17:07.076907
# Unit test for method answer of class Text
def test_Text_answer():
    """Test for method answer of class Text"""
    text_0 = Text()
    text_0.answer()


# Generated at 2022-06-25 21:17:09.041476
# Unit test for method color of class Text
def test_Text_color():
    text_1 = Text()
    txt_color = text_1.color()

# Generated at 2022-06-25 21:17:15.950723
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text = Text()
    rgb = text.rgb_color(safe=True)
    assert len(rgb) == 3
    assert isinstance(rgb, tuple)

    for i in rgb:
        assert isinstance(i, int)
        assert 0 <= i <= 255

# Generated at 2022-06-25 21:17:17.592718
# Unit test for method words of class Text
def test_Text_words():
    word_1 = Text().words()
    word_2 = Text().words(1)

    assert isinstance(word_1, list)
    assert isinstance(word_2, list)



# Generated at 2022-06-25 21:17:28.392949
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    locale_0 = 'en'
    seed_0 = '5r0h5ky7c0g5eo'
    text_0 = Text(locale_0, seed_0)
    hex_color_0 = text_0.hex_color()
    assert hex_color_0 == '#a6a5a1'

    seed_1 = 'epm2jz2q7q3i3x'
    text_1 = Text(locale_0, seed_1)
    hex_color_1 = text_1.hex_color(safe=True)
    assert hex_color_1 == '#f1a9a0'



# Generated at 2022-06-25 21:17:31.936299
# Unit test for method word of class Text
def test_Text_word():
    text_1 = Text()
    word_1 = text_1.word()
    assert isinstance(word_1,str)



# Generated at 2022-06-25 21:17:35.932369
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet(lower_case=True)
    assert isinstance(alphabet, list)



# Generated at 2022-06-25 21:17:38.274663
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    assert isinstance(text_0.alphabet(), list)


# Generated at 2022-06-25 21:17:53.822342
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    t1 = Text()
    t1.swear_word()

# Code to test the above

# Generated at 2022-06-25 21:17:56.800700
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    assert text_0.answer()


# Generated at 2022-06-25 21:17:58.375709
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert len(text.answer()) > 0


# Generated at 2022-06-25 21:18:04.581703
# Unit test for method text of class Text
def test_Text_text():
    # Test case #0
    text_0 = Text()
    text_0.text()  # should not error

    # Test case #1
    text_1 = Text()
    text_1.text(2)  # should not error



# Generated at 2022-06-25 21:18:07.405344
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    answer_0 = text_0.swear_word()
    assert answer_0 == "Damn"


# Generated at 2022-06-25 21:18:09.417557
# Unit test for method words of class Text
def test_Text_words():
    text_1 = Text()
    list_1 = text_1.words()
    assert type(list_1) == list


# Generated at 2022-06-25 21:18:17.050735
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    assert text_0.level() != text_1.level()
    assert text_1.level() != text_2.level()
    assert text_2.level() != text_3.level()


# Generated at 2022-06-25 21:18:20.231487
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text('en')
    locales = text.locales
    results = []
    for locale in locales:
        text.set_locale(locale)
        result = text.swear_word()
        results.append(result)
    assert all(results)



# Generated at 2022-06-25 21:18:23.544955
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words(quantity=5)
    assert len(words) == 5


# Generated at 2022-06-25 21:18:29.481643
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    # Instance of class Text
    text = Text()
    # Variable for storing the result of the method definition
    result = text.swear_word()
    # Assert the result with attribute 'bad' of class Text
    assert result in text._data['words']['bad']


# Generated at 2022-06-25 21:19:03.422310
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet(False)
    assert isinstance(list_0, list)
    assert len(list_0) == 26
    assert list_0[0] == 'A'



# Generated at 2022-06-25 21:19:04.606679
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    text_0.quote()


# Generated at 2022-06-25 21:19:07.010375
# Unit test for method level of class Text
def test_Text_level():
    """Unittest for method level."""
    text_1 = Text()
    list_1 = text_1.level()

# Generated at 2022-06-25 21:19:16.770816
# Unit test for method words of class Text
def test_Text_words():
    import unittest

    class Test(unittest.TestCase):
        def test__words_of_Text(self):
            text = Text()
            self.assertIsInstance(text.words(2), list)
            self.assertIsInstance(text.words(2)[0], str)
            self.assertIsInstance(text.words(2)[1], str)
            self.assertIsInstance(text.words(1)[0], str)
            self.assertTrue(len(text.words(2)) == 2)
            self.assertTrue(len(text.words(2)[0]) > 0)
            self.assertTrue(len(text.words(1)[0]) > 0)
            self.assertNotEqual(text.words(2)[0], text.words(2)[1])


# Generated at 2022-06-25 21:19:25.776621
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()


# Generated at 2022-06-25 21:19:26.909358
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    quote_0 = text_0.quote()

# Generated at 2022-06-25 21:19:28.830159
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    # Unit test for method methex_color of class Text
    text_0 = Text()
    result_0 = text_0.hex_color()
    assert result_0.startswith('#')
    result_1 = text_0.hex_color(safe=True)
    assert result_1.startswith('#')


# Generated at 2022-06-25 21:19:31.981548
# Unit test for method quote of class Text
def test_Text_quote():
    """ Test the method quote of class Text
    """
    newText = Text(seed=0)
    assert newText.quote() == 'If you want a picture of the future, imagine a boot stamping on a human face—forever.'
    assert newText.quote() == 'Just because you\'re paranoid doesn\'t mean they\'re not after you.'
    assert newText.quote() == '"I\'ll be back" Terminator.'


# Generated at 2022-06-25 21:19:33.386365
# Unit test for method color of class Text
def test_Text_color():
    rnd = Text()
    assert rnd.color() in rnd._data['color']


# Generated at 2022-06-25 21:19:34.328835
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    assert type(text_0.title()) == str
