

# Generated at 2022-06-25 21:16:58.903695
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-25 21:17:02.518770
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()
    assert str_0 == 'Yes' or str_0 == 'No'


# Generated at 2022-06-25 21:17:05.544896
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet(lower_case=False)


# Generated at 2022-06-25 21:17:08.320454
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    str = text.quote()


# Generated at 2022-06-25 21:17:11.913840
# Unit test for method level of class Text
def test_Text_level():
    text_unit = Text()
    str_unit = text_unit.level()
    assert isinstance(str_unit, str) is True


# Generated at 2022-06-25 21:17:17.017044
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    result_0 = text_0.rgb_color()
    assert isinstance(result_0, tuple)
    assert len(result_0) == 3


# Generated at 2022-06-25 21:17:20.000227
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    instance = Text()
    assert len(instance.hex_color()) == 7


# Generated at 2022-06-25 21:17:24.104168
# Unit test for method color of class Text
def test_Text_color():
    text_ = Text()
    str_ = text_.color()
    assert type(str_) is str
# unit test for method hex_color of class Text

# Generated at 2022-06-25 21:17:26.003780
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    str_0 = text_0.word()


# Generated at 2022-06-25 21:17:29.294260
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    assert(len(text_0.quote()) == 0)


# Generated at 2022-06-25 21:17:38.200232
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert isinstance(text.answer(), str)


# Generated at 2022-06-25 21:17:40.889289
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet()



# Generated at 2022-06-25 21:17:43.340686
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()


# Generated at 2022-06-25 21:17:46.278301
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet()


# Generated at 2022-06-25 21:17:48.994170
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet()
    list_1 = text_0.alphabet(True)
    assert len(list_0) == 26



# Generated at 2022-06-25 21:17:51.981697
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_0 = text_0.level()
    assert (str_0 != '')


# Generated at 2022-06-25 21:17:58.228851
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    try:
        text = Text()
        assert text.hex_color() is not None
        assert text.hex_color(safe=True) is not None
    except:
        raise AssertionError("Error in test_Text_hex_color")


# Generated at 2022-06-25 21:18:08.743183
# Unit test for method answer of class Text
def test_Text_answer():
    _sample = [
        'Da',
        'Nee',
        'Nu',
        'Nie',
        'Nie',
        'Ne',
        'Nei',
    ]

    _locales = [
        'de',
        'en',
        'es',
        'fi',
        'fr',
        'it',
        'pt',
    ]

    for locale in _locales:
        provider = Text(locale=locale)
        assert provider.answer() in _sample


# Generated at 2022-06-25 21:18:11.703870
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()


# Generated at 2022-06-25 21:18:14.592860
# Unit test for method quote of class Text
def test_Text_quote():
    text = Text()
    quote = text.quote().split('-')[0]
    assert quote in text.quotes


# Generated at 2022-06-25 21:18:39.758204
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    str_0 = text_0.quote()
    assert len(str_0) > 0


# Generated at 2022-06-25 21:18:41.070664
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()


# Generated at 2022-06-25 21:18:45.529738
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    assert (text_0.answer() in text_0.answers)


# Generated at 2022-06-25 21:18:50.945522
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()

    # Is str_0 an instance of string
    assert isinstance(str_0, str)

    # Does len(str_0) not equal 0
    assert len(str_0) != 0



# Generated at 2022-06-25 21:18:56.292595
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    str_0 = text_0.hex_color()
    str_1 = text_0.hex_color(True)
    assert str_0 != str_1


# Generated at 2022-06-25 21:18:59.284370
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    str_0 = text_0.color()
    assert type(str_0) is str


# Generated at 2022-06-25 21:19:02.794473
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()
    assert isinstance(str_0, str)
    assert str_0 != "Aliquam in purus arcu."
    assert not (str_0 == "Aliquam in purus arcu.")

# Generated at 2022-06-25 21:19:03.779596
# Unit test for method word of class Text
def test_Text_word():
    text_obj = Text()
    text_obj.word()


# Generated at 2022-06-25 21:19:04.978371
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alphabet = text.alphabet()
    assert isinstance(alphabet, (list, tuple)) is True


# Generated at 2022-06-25 21:19:15.435836
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """
    Test for method alphabet of class Text
    """
    text_0 = Text()
    assert isinstance(text_0.alphabet(), list)
    assert text_0.alphabet() == ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert isinstance(text_0.alphabet(lower_case=True), list)

# Generated at 2022-06-25 21:19:59.832208
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()
    assert str_0 in ['Yes', 'No', 'Maybe', 'Sure', 'Of course', 'Why not', 'Whatever', 'Not yet', 'Not possible', 'I don\'t know', "It's not a question", 'Definitely', 'Second to none', 'No way', 'Absolutely', 'Don\'t even think about it', 'Out of the question', 'Not a chance', 'Why ask me', 'No way, Jose', 'Not in a million years', 'Call the doctor', "I don't think so", 'Who knows', 'Tricky', 'This is it', 'Try again', 'Not likely']


# Generated at 2022-06-25 21:20:01.456077
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    list_0 = text_0.words()
    assert len(list_0) == 5


# Generated at 2022-06-25 21:20:03.433118
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    list_0 = [text_0.rgb_color() for x in range(10)]
    list_1 = [text_0.rgb_color(safe=True) for x in range(10)]


# Generated at 2022-06-25 21:20:04.457319
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    assert (type(text.word()) == str)


# Generated at 2022-06-25 21:20:05.543135
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    words = text.words()
    assert(len(words) == 5)


# Generated at 2022-06-25 21:20:12.744123
# Unit test for method title of class Text
def test_Text_title():
    # Create instance of the class Text
    text_0 = Text()
    str_0 = text_0.title()
    str_1 = text_0.title()
    str_2 = text_0.title()
    str_3 = text_0.title()
    str_4 = text_0.title()
    str_5 = text_0.title()
    str_6 = text_0.title()
    str_7 = text_0.title()
    str_8 = text_0.title()
    str_9 = text_0.title()
    str_10 = text_0.title()
    assert str_0 == str_1
    assert str_2 == str_3
    assert str_4 == str_5
    assert str_6 == str_7
    assert str_8 == str_9


# Generated at 2022-06-25 21:20:14.732721
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    rgb_color_0 = text_0.rgb_color()
    assert (len(rgb_color_0) == 3)


# Generated at 2022-06-25 21:20:17.178298
# Unit test for method color of class Text
def test_Text_color():
    text_1 = Text()
    str_1 = text_1.color()
    assert isinstance(str_1, str)
    assert len(str_1) > 0


# Generated at 2022-06-25 21:20:21.313829
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    string_0 = text_0.sentence()
    assert string_0 is not None
    text_1 = Text()
    string_1 = text_1.sentence()
    assert string_1 is not None
    text_2 = Text()
    string_2 = text_2.sentence()
    assert string_2 is not None


# Generated at 2022-06-25 21:20:22.647634
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    str_0 = text_0.sentence()
