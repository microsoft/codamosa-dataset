

# Generated at 2022-06-25 21:16:58.776892
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    assert type(text_0.sentence()) == str



# Generated at 2022-06-25 21:17:02.894336
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    list_0 = []
    text_0 = Text(*list_0)
    var_0 = text_0.rgb_color()
    assert var_0 == (255, 255, 255)


# Generated at 2022-06-25 21:17:05.768643
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    list_0 = []
    text_0 = Text(*list_0)
    str_0 = text_0.hex_color()


# Generated at 2022-06-25 21:17:08.623814
# Unit test for constructor of class Text
def test_Text():
    list_1 = []
    text_1 = Text(*list_1)
    text_1.alphabet()
    text_1.level()
    text_1.text()
    text_1.sentence()
    text_1.title()
    text_1.words()
    text_1.word()
    text_1.swear_word()
    text_1.quote()
    text_1.color()
    text_1.hex_color()
    text_1.rgb_color()
    text_1.answer()


# Generated at 2022-06-25 21:17:17.872897
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert callable(text.level)
    assert isinstance(text.level(), str)
    text = Text(seed=19)
    assert text.level() == 'high'
    text = Text(seed=20)
    assert text.level() == 'low'
    text = Text(seed=21)
    assert text.level() == 'very high'
    text = Text(seed=22)
    assert text.level() == 'very low'


# Generated at 2022-06-25 21:17:21.534257
# Unit test for method quote of class Text
def test_Text_quote():
    import pytest
    list_0 = []
    word = Text(*list_0).quote()
    assert type(word) == str


# Generated at 2022-06-25 21:17:24.901470
# Unit test for constructor of class Text
def test_Text():
    list_0 = []
    text_0 = Text(*list_0)
    assert isinstance(text_0, Text)


# Generated at 2022-06-25 21:17:29.479276
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    list_0 = []
    text_0 = Text(*list_0)
    tuple_0 = text_0.rgb_color()


# Generated at 2022-06-25 21:17:32.769469
# Unit test for method title of class Text
def test_Text_title():
    list_1 = []
    text_1 = Text(*list_1)
    print(text_1.title())



# Generated at 2022-06-25 21:17:39.756611
# Unit test for method words of class Text
def test_Text_words():
    """Testing method words of class Text."""
    list_0 = []
    text_0 = Text(*list_0)
    list_1 = []
    i = 0
    while i < 2:
        list_1.append(text_0.words())
        i += 1
    assert list_1 == [['science', 'network', 'god', 'octopus', 'love'], ['science', 'network', 'god', 'octopus', 'love']]

# Generated at 2022-06-25 21:18:02.624803
# Unit test for method word of class Text
def test_Text_word():
    list_0 = []
    text_0 = Text(*list_0)
    str_0 = text_0.word()
    assert str_0 == str_0
    assert str_0 != str_0
    assert str_0 == text_0.word()
    assert str_0 != text_0.word()
    assert str_0 != text_0.word()
    assert text_0.word() != str_0
    assert str_0 == str_0
    assert str_0 != str_0
    assert text_0.word() == str_0
    assert text_0.word() != str_0
    assert str_0 != text_0.word()
    assert str_0 == str_0
    assert str_0 == str_0
    assert text_0.word() != str_0
    assert text_

# Generated at 2022-06-25 21:18:09.603314
# Unit test for method words of class Text
def test_Text_words():
    list_0 = ['abc', 'def', 'ghi', 'jkl', 'mno']
    text_0 = Text(*list_0)
    text_0.seed(0)
    list_1 = text_0.words(5)
    func_0(list_0, list_1)


# Generated at 2022-06-25 21:18:14.498890
# Unit test for method quote of class Text
def test_Text_quote():
    list_0 = []
    text_0 = Text(*list_0)
    result_0 = text_0.quote()
    assert type(result_0) == str


# Generated at 2022-06-25 21:18:16.983973
# Unit test for method text of class Text
def test_Text_text():
    pass
    # tex = Text()
    # assert tex.text() is not None



# Generated at 2022-06-25 21:18:19.050767
# Unit test for method color of class Text
def test_Text_color():
    text = Text(seed=1234)
    assert text.color() == 'Yellow'


# Generated at 2022-06-25 21:18:23.480586
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    t = Text()
    rgb = t.rgb_color()
    assert rgb == (252, 85, 32)


# Generated at 2022-06-25 21:18:29.998970
# Unit test for method level of class Text
def test_Text_level():
    # Test case 0
    list_0 = []
    text_0 = Text(*list_0)
    word_0 = text_0.level()
    word_1 = text_0.level()
    word_2 = text_0.level()
    word_3 = text_0.level()
    word_4 = text_0.level()


# Generated at 2022-06-25 21:18:34.925542
# Unit test for method title of class Text
def test_Text_title():
    list_0 = []
    text_0 = Text(*list_0)
    string_0 = text_0.title()
    string_1 = text_0.title()
    string_2 = text_0.title()


# Generated at 2022-06-25 21:18:43.235401
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    list_1 = text_0.sentence()
    list_1 = text_0.word()
    list_1 = text_0.words()
    list_1 = text_0.title()
    list_1 = text_0.answer()
    list_1 = text_0.rgb_color()
    list_1 = text_0.hex_color()
    list_1 = text_0.level()
    list_1 = text_0.color()
    list_1 = text_0.alphabet()
    list_1 = text_0.quote()
    list_1 = text_0.swear_word()
    list_1 = text_0.text()

# Generated at 2022-06-25 21:18:51.446288
# Unit test for method word of class Text
def test_Text_word():
	# Fixture 1
	txt = Text()
	result = txt.word()
	answer = "science"

	if result != answer:
		raise AssertionError("Result is {} and should be {}".format(result, answer))

	# Fixture 2
	txt = Text()
	result = txt.word()
	answer = "network"

	if result != answer:
		raise AssertionError("Result is {} and should be {}".format(result, answer))


# Generated at 2022-06-25 21:19:58.978397
# Unit test for constructor of class Text
def test_Text():
    test_case_0()

# Generated at 2022-06-25 21:19:59.532055
# Unit test for constructor of class Text
def test_Text():
    pass

# Generated at 2022-06-25 21:20:01.488665
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert isinstance(level, str)
    assert level in text._data['level']



# Generated at 2022-06-25 21:20:02.707134
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()



# Generated at 2022-06-25 21:20:04.637226
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    test_result_0 = text_0.color()
    assert test_result_0 == 'Gold'
    assert text_0.random.choice.__func__.__name__ == 'choice'



# Generated at 2022-06-25 21:20:11.272056
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    # assert text_0.swear_word() in
    # d = dict(dutch={"bad": ["kanker",
    # "Kutwijf",
    # "kut",
    # "kutmarokkaan",
    # "kutbelg",
    # "kuthond",
    # "kutstel",
    # "kutland",
    # "kutstad",
    # "kutfries",
    # "kutje",
    # "kutcafé",
    # "kutbrigade",
    # "kutrestaurant",
    # "kutwinkel",
    # "Kut",
    # "kutwijf",
    # "kut",
    # "kutmarokkaan",

# Generated at 2022-06-25 21:20:13.378314
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text = Text()
    alpha = text.alphabet()
    assert isinstance(alpha, str)
    assert len(alpha) > 0


# Generated at 2022-06-25 21:20:15.118770
# Unit test for method title of class Text
def test_Text_title():
    t = Text()
    title_test = t.title()
    assert type(title_test) is str


# Generated at 2022-06-25 21:20:16.984708
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    str_0 = text_0.swear_word()


# Generated at 2022-06-25 21:20:18.400515
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t is not None



# Generated at 2022-06-25 21:23:03.191246
# Unit test for method sentence of class Text
def test_Text_sentence():
    """
    Unit test for method sentence of class Text.
    """
    text = Text()
    sentence = text.sentence()
    assert (isinstance(sentence, str))


# Generated at 2022-06-25 21:23:04.116699
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)



# Generated at 2022-06-25 21:23:05.309219
# Unit test for method text of class Text
def test_Text_text():
    text = Text()
    assert len(text.text().split('.')) == 5


# Generated at 2022-06-25 21:23:06.167835
# Unit test for method quote of class Text
def test_Text_quote():
    t = Text()
    assert type(t.quote()) is str


# Generated at 2022-06-25 21:23:12.381337
# Unit test for method text of class Text
def test_Text_text():

    # Locale: en-US
    text_0 = Text(locale='en-US')
    string_0 = text_0.text()
    assert string_0 == 'You need to do something else.'

    # Locale: ru
    text_1 = Text(locale='ru')
    string_1 = text_1.text()
    assert string_1 == 'Вы можете сделать это.'

    # Locale: de
    text_2 = Text(locale='de')
    string_2 = text_2.text()
    assert string_2 == 'Sie müssen es ein bisschen anders machen.'

    # Locale: es
    text_3 = Text(locale='es')
    string_3 = text_

# Generated at 2022-06-25 21:23:13.737156
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    output = text.word()
    assert len(output) > 0


# Generated at 2022-06-25 21:23:18.086254
# Unit test for method text of class Text
def test_Text_text():
    # Case 0:
    # text_0 = Text()
    # text_0.text(quantity=1)
    # Case 1:
    # text_1 = Text()
    # text_1.text(quantity=1)
    # Case 2:
    # text_2 = Text()
    # text_2.text(quantity=1)
    # Case 3:
    # text_3 = Text()
    # text_3.text(quantity=1)
    pass


# Generated at 2022-06-25 21:23:19.186588
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()



# Generated at 2022-06-25 21:23:20.162864
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    string_0 = text_0.answer()


# Generated at 2022-06-25 21:23:21.231339
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert isinstance(title, str)