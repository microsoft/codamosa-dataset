

# Generated at 2022-06-25 21:19:59.262185
# Unit test for method level of class Text
def test_Text_level():
    """Method level of class Text"""
    text_0 = Text()
    str_0 = text_0.level()


# Generated at 2022-06-25 21:20:00.857584
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_1 = Text()
    tuple_0 = text_1.rgb_color()
    assert(tuple_0)

# Generated at 2022-06-25 21:20:02.012078
# Unit test for method quote of class Text
def test_Text_quote():
    text_1 = Text()
    str_1 = text_1.quote()


# Generated at 2022-06-25 21:20:03.309568
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text(5)
    assert text_0.provider == 'text'
    assert text_0.locale == 'ru'

# Generated at 2022-06-25 21:20:04.568781
# Unit test for method words of class Text
def test_Text_words():
    for _ in range(10000):
        i = Text().words()
        assert isinstance(i, list)


# Generated at 2022-06-25 21:20:05.644710
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    word = text.word()
    assert isinstance(word, str)


# Generated at 2022-06-25 21:20:07.238176
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    assert text_0.swear_word() not in (None, '')


# Generated at 2022-06-25 21:20:09.257309
# Unit test for method level of class Text
def test_Text_level():
    # given
    text_0 = Text()
    # when
    level_0 = text_0.level()
    # then
    assert isinstance(level_0, str)


# Generated at 2022-06-25 21:20:12.244312
# Unit test for method title of class Text
def test_Text_title():
    print("\nUnittest for method title of class Text")
    text_0 = Text()
    str_0 = text_0.title()
    print("Result:\n{0}".format(str_0))
    print("-" * 140)


# Generated at 2022-06-25 21:20:13.435627
# Unit test for method answer of class Text
def test_Text_answer():
    text_1 = Text()
    str_1 = text_1.answer()


# Generated at 2022-06-25 21:23:44.231008
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text(random=Random())
    str_0 = text_0.word()


# Generated at 2022-06-25 21:23:45.287764
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    string_0 = text_0.quote()



# Generated at 2022-06-25 21:23:46.472403
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()
    str_1 = text_0.text()


# Generated at 2022-06-25 21:23:47.268236
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert isinstance(t, Text) == True


# Generated at 2022-06-25 21:23:52.175890
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    word = text.word()
    word_list = text.words()
    assert isinstance(word, str)
    assert isinstance(word_list, list)
    assert all(isinstance(w, str) for w in word_list)



# Generated at 2022-06-25 21:23:53.145550
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__class__.__name__ == 'Text'


# Generated at 2022-06-25 21:23:58.336925
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    text_0.random.seed(0)

    level_0 = text_0.level()
    assert level_0 == 'critical'

    text_0.random.seed(1)

    level_1 = text_0.level()
    assert level_1 == 'warning'

    text_0.random.seed(2)

    level_2 = text_0.level()
    assert level_2 == 'notice'

    text_0.random.seed(3)

    level_3 = text_0.level()
    assert level_3 == 'info'

    text_0.random.seed(4)

    level_4 = text_0.level()
    assert level_4 == 'debug'

    text_0.random.seed(5)


# Generated at 2022-06-25 21:23:59.214283
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    str_0 = text_0.rgb_color()


# Generated at 2022-06-25 21:24:00.088061
# Unit test for method word of class Text
def test_Text_word():
    assert Text().word() in Text()._data['words']['normal']


# Generated at 2022-06-25 21:24:01.824914
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_1 = Text()
    str_0 = text_1.swear_word()
    assert str_0 is not None
    assert isinstance(str_0, str)
    assert str_0 not in (' ', '', '  ')
