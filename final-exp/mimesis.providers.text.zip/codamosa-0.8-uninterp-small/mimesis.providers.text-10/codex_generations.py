

# Generated at 2022-06-25 21:16:58.099543
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    sentence_0 = text_0.sentence()


# Generated at 2022-06-25 21:17:00.906740
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert level in ('critical', 'high', 'normal', 'low', 'none')


# Generated at 2022-06-25 21:17:07.435300
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    text_1 = Text()

    text_0.seed(0)
    text_1.seed(0)
    assert text_0.text() == text_1.text()

    text_0.seed(0)
    text_1.seed(1)
    assert text_0.text() != text_1.text()

    text_0.seed()
    text_1.seed()
    assert text_0.text() != text_1.text()



# Generated at 2022-06-25 21:17:09.988211
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    assert len(text_0.word()) > 0


# Generated at 2022-06-25 21:17:13.536327
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()
    print(str_0)



# Generated at 2022-06-25 21:17:16.442179
# Unit test for method text of class Text
def test_Text_text():
    assert text_0 == "No"  # Unit test failed

# Generated at 2022-06-25 21:17:18.773020
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert hasattr(text, 'seed')
    assert hasattr(text, '_data')
    assert hasattr(text, '_datafile')


# Generated at 2022-06-25 21:17:24.404789
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()
    str_1 = text_0.text()
    str_2 = text_0.text()
    assert str_0 != str_1 != str_2


# Generated at 2022-06-25 21:17:29.481414
# Unit test for method quote of class Text
def test_Text_quote():
    import re
    t = Text()
    quote = t.quote()
    assert re.search('^".*"$', quote)

# Generated at 2022-06-25 21:17:33.320201
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_1 = Text()
    word_0 = text_1.swear_word()
    assert word_0

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 21:17:50.892149
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    result = text._data
    assert isinstance(result, dict)


# Generated at 2022-06-25 21:18:01.698094
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()
    word_quantity_0 = text_0.words(quantity=5)
    str_0 = text_0.title()
    str_1 = text_0.text(quantity=5)
    str_2 = text_0.quote()
    rgb_0 = text_0.rgb_color()
    word_0 = text_0.word()
    hex_0 = text_0.hex_color()
    str_3 = text_0.level()
    str_4 = text_0.sentence()
    color_0 = text_0.color()
    str_5 = text_0.answer()
    level_0 = text_0.level()
    alpha_0 = text_0.alphabet(lower_case=False)

# Generated at 2022-06-25 21:18:03.501160
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    n = text_0.words()
    assert (len(n) == 5)


# Generated at 2022-06-25 21:18:07.265774
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    tp = Text()
    assert len(tp.hex_color()) == 7

# Generated at 2022-06-25 21:18:09.314431
# Unit test for method quote of class Text
def test_Text_quote():
    text_1 = Text()
    str_0 = text_1.quote()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:18:13.636153
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    str_0 = text_0.quote()
    assert type(str_0) is str


# Generated at 2022-06-25 21:18:14.653028
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_1 = Text()
    str_1 = text_1.swear_word()


# Generated at 2022-06-25 21:18:17.125800
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    text_0_rgb_color = text_0.rgb_color()


# Generated at 2022-06-25 21:18:18.855131
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    Text_0 = Text()
    str_0 = Text_0.swear_word()

# Generated at 2022-06-25 21:18:22.169623
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    str_0 = text.level()


# Generated at 2022-06-25 21:18:56.227720
# Unit test for method level of class Text
def test_Text_level():
    '''
    Unit test for method level
    '''
    text_0 = Text()
    str_0 = text_0.level()
    assert str_0


# Generated at 2022-06-25 21:19:02.406398
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    alp = text_0.alphabet()
    assert all(item in alp for item in "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    alp = text_0.alphabet(lower_case=True)
    assert all(item in alp for item in "abcdefghijklmnopqrstuvwxyz")


# Generated at 2022-06-25 21:19:03.228436
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    color = text.color()


# Generated at 2022-06-25 21:19:04.663461
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_0 = text_0.level()


# Generated at 2022-06-25 21:19:06.395262
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert "critical" in text.level()


# Generated at 2022-06-25 21:19:08.968400
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text = Text()
    generated = text.swear_word()
    assert(isinstance(generated, str))


# Generated at 2022-06-25 21:19:12.976092
# Unit test for method title of class Text
def test_Text_title():
    # create a dummy Text object
    text_0 = Text()
    # assign the title to a variable
    str_0 = text_0.title()
    # test if the length of the title is more than 1
    assert (len(str_0) > 1)



# Generated at 2022-06-25 21:19:14.963228
# Unit test for method quote of class Text
def test_Text_quote():
    Text_0 = Text()
    str_0 = Text_0.quote()
    assert(str_0 == "I'll be back.")


# Generated at 2022-06-25 21:19:16.423788
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()
	
	

# Generated at 2022-06-25 21:19:17.569705
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    """Unit test for method alphabet of class Text."""
    text_1 = Text()
    text_1.alphabet()