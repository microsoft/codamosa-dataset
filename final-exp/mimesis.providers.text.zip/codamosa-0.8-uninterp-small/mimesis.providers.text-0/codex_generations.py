

# Generated at 2022-06-25 21:17:47.922409
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    string_0 = text_0.quote()


# Generated at 2022-06-25 21:17:49.619995
# Unit test for constructor of class Text
def test_Text():
    text_0 = Text()


# Generated at 2022-06-25 21:18:01.269147
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    from sys import version_info
    from random import seed
    from mimesis.builtins import Text
    from mimesis.data import SAFE_COLORS

    if version_info.major == 2:
        seed(5, 4)
    elif version_info.major == 3:
        seed(5, 4, 4)

    text_0 = Text()
    assert tuple == type(text_0.rgb_color(bool_0))
    assert len(text_0.rgb_color(bool_0)) == 3
    assert tuple == type(text_0.rgb_color(bool_0))
    assert len(text_0.rgb_color(bool_0)) == 3
    assert tuple == type(text_0.rgb_color(bool_0))

# Generated at 2022-06-25 21:18:08.895436
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    text_0.random.seed(0)
    str_0 = text_0.answer()
    assert str_0 == 'No'

    text_0.random.seed(1)
    str_0 = text_0.answer()
    assert str_0 == 'Yes'

    text_0.random.seed(2)
    str_0 = text_0.answer()
    assert str_0 != 'not'


# Generated at 2022-06-25 21:18:11.273654
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    text_0.alphabet()


# Generated at 2022-06-25 21:18:14.730543
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    assert isinstance(text.level(), str), '#level method in Text failed'


# Generated at 2022-06-25 21:18:18.825493
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    bool_0 = True
    text_0 = Text()
    tuple_0 = text_0.rgb_color(bool_0)
    assert tuple_0 is not None


# Generated at 2022-06-25 21:18:22.472870
# Unit test for method text of class Text
def test_Text_text():
    assert Text().text() == "I'll be back."



# Generated at 2022-06-25 21:18:26.292922
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    int_0 = 5
    list_0 = text_0.words(int_0)
    assert len(list_0) == 5


# Generated at 2022-06-25 21:18:29.713137
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    string_0 = '#7adb01'
    str_0 = Text().hex_color()
    assert str_0 == string_0


# Generated at 2022-06-25 21:20:07.149271
# Unit test for method level of class Text
def test_Text_level():
    # Unit test for method level of class Text without arguments
    text = Text()
    assert isinstance(text.level(), str)
    # Unit test for method level of class Text with arguments
    # 1. Name of arguments is not exist
    try:
        text.level(name = 'test')
    except TypeError as e:
        assert '[E010] The method does not take this argument: "name".' == str(e)
    # 2. Name of arguments is wrong
    try:
        text.level(test = 0)
    except TypeError as e:
        assert '[E009] The method does not take this argument: "test".' == str(e)

# Generated at 2022-06-25 21:20:08.665647
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text(seed=688, )
    assert(text_0.level() == 'medium')
    # Some tests of Text.level

# Generated at 2022-06-25 21:20:10.036171
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    for i in range(5):
        word = text.word()
        assert(isinstance(word, str))


# Generated at 2022-06-25 21:20:11.293649
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    assert isinstance(text_0.swear_word(), str)


# Generated at 2022-06-25 21:20:13.040237
# Unit test for method text of class Text
def test_Text_text():
    text_1 = Text()
    str_0 = text_1.text()


# Generated at 2022-06-25 21:20:14.759900
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet(lower_case=False)


# Generated at 2022-06-25 21:20:15.798208
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    text_0 = Text()
    str_0 = text_0.swear_word()


# Generated at 2022-06-25 21:20:17.811475
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    assert text.color() in text._data.get('color')


# Generated at 2022-06-25 21:20:19.903585
# Unit test for method level of class Text
def test_Text_level():
    inst_0 = Text()
    assert type(inst_0.level()) is str
    assert len(inst_0.level()) >= 1


# Generated at 2022-06-25 21:20:21.804086
# Unit test for method quote of class Text
def test_Text_quote():
    text_1 = Text(seed=824135)
    text_2 = Text(seed=824135)
    assert text_1.quote() == text_2.quote()


# Generated at 2022-06-25 21:21:19.804738
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()
    text_6 = Text()
    text_7 = Text()
    text_8 = Text()
    text_9 = Text()
    text_10 = Text()
    text_11 = Text()
    text_12 = Text()
    text_13 = Text()

    hex_0 = text_0.hex_color()
    assert len(hex_0) == 7

    hex_1 = text_1.hex_color()
    assert len(hex_1) == 7

    hex_2 = text_2.hex_color()
    assert len(hex_2) == 7

    hex_3 = text_3.hex_color

# Generated at 2022-06-25 21:21:21.142277
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:21:22.373507
# Unit test for method quote of class Text
def test_Text_quote():
    """Class Text quote method test."""
    text = Text()
    assert type(text.quote()) is str


# Generated at 2022-06-25 21:21:24.013504
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=1)
    assert text.title().is_string()
    assert len(text.title()) > 0
    assert text.title() == 'Vision'


# Generated at 2022-06-25 21:21:25.435249
# Unit test for method word of class Text
def test_Text_word():
    # Unit test for method word of class Text
    text_1 = Text()
    word_1 = text_1.word()
    assert(len(word_1) > 0)


# Generated at 2022-06-25 21:21:26.874485
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    text_0.seed(0)
    assert text_0.word() == 'octopus'


# Generated at 2022-06-25 21:21:30.470690
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    result_0 = text_0.hex_color(safe=True)
    assert isinstance(result_0, str) is True
    assert result_0 in SAFE_COLORS
    assert result_0.startswith('#')
    assert len(result_0) == 7


# Generated at 2022-06-25 21:21:31.108638
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    test_case_0()


# Generated at 2022-06-25 21:21:32.241657
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    level = text.level()
    assert type(level) == str


# Generated at 2022-06-25 21:21:33.599573
# Unit test for method title of class Text
def test_Text_title():
    text = Text(seed=4593297364)
    title = text.title()
    assert title == 'Odio et in.'
