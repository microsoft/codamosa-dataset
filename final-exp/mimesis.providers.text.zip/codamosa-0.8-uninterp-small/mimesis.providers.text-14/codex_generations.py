

# Generated at 2022-06-25 21:16:54.973400
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    str_0 = text_0.words()


# Generated at 2022-06-25 21:16:58.434665
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    # using seed
    text_0 = Text(seed=0)
    r0, g0, b0 = text_0.rgb_color()
    r1, g1, b1 = text_0.rgb_color(safe=True)
    assert r0 == 250 and g0 == 85 and b0 == 32
    assert r1 == 218 and g1 == 52 and b1 == 107
    print("test_Text_rgb_color passed")



# Generated at 2022-06-25 21:17:00.714689
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    assert len(text_0.hex_color()) == 7


# Generated at 2022-06-25 21:17:03.257479
# Unit test for constructor of class Text
def test_Text():

    txt = Text()



# Generated at 2022-06-25 21:17:07.386867
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()
    str_1 = text_0.title()
    assert str_0 != str_1, "Mismatch found"


# Generated at 2022-06-25 21:17:09.928661
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    str_0 = text_0.rgb_color()



# Generated at 2022-06-25 21:17:12.407671
# Unit test for method color of class Text
def test_Text_color():
    text_1 = Text()
    text_1.color()


# Generated at 2022-06-25 21:17:15.949640
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    str_0 = text_0.quote()



# Generated at 2022-06-25 21:17:17.250756
# Unit test for method words of class Text
def test_Text_words():
    text = Text()
    x = text.words()
    assert len(x) == 5
    assert type(x) == list


# Generated at 2022-06-25 21:17:29.095873
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    str_0 = text_0.color()
    assert str_0 == "Azul" or str_0 == "Verde" or str_0 == "Rojo" \
        or str_0 == "Verde" or str_0 == "Comun" or str_0 == "Rojo" \
        or str_0 == "Azur" or str_0 == "Vermell" or str_0 == "Marro" \
        or str_0 == "Carmesí" or str_0 == "Rosa" or str_0 == "Fucsia" \
        or str_0 == "Violeta" or str_0 == "Verde" or str_0 == "Celeste" \
        or str_0 == "Amarillo" or str_0 == "Negro" or str

# Generated at 2022-06-25 21:17:48.661643
# Unit test for method color of class Text
def test_Text_color():
    text = Text()
    result = text.color()
    assert type(result) is str


# Generated at 2022-06-25 21:17:50.069059
# Unit test for constructor of class Text
def test_Text():
    # There is no public initializer
    pass



# Generated at 2022-06-25 21:17:53.581345
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    result = text_0.sentence()
    assert type(result) is str


# Generated at 2022-06-25 21:17:57.177009
# Unit test for method text of class Text
def test_Text_text():
    # Initializing an instance for testing
    text_instance = Text()
    # Testing the API
    text_instance.text()

# Generated at 2022-06-25 21:17:58.932965
# Unit test for method title of class Text
def test_Text_title():
    text_1 = Text()
    str_0 = text_1.title()


# Generated at 2022-06-25 21:18:02.898478
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    t = Text()
    assert type(t.alphabet(lower_case=False)) == list


# Generated at 2022-06-25 21:18:08.202377
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_1 = Text()
    str_0 = text_1.hex_color()
    assert len(str_0) == 7, str_0


# Generated at 2022-06-25 21:18:09.541724
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()



# Generated at 2022-06-25 21:18:21.314397
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()
    text_6 = Text()
    text_7 = Text()
    text_8 = Text()
    text_9 = Text()
    text_10 = Text()

    assert text_0.rgb_color()==text_1.rgb_color()
    assert text_2.rgb_color(safe=False)==text_3.rgb_color(safe=False)
    assert text_4.rgb_color(safe=True)==text_5.rgb_color(safe=True)
    assert text_6.rgb_color()==text_7.rgb_color()
    assert text_8.r

# Generated at 2022-06-25 21:18:23.155131
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    assert isinstance(text_0.sentence(), str)

# Generated at 2022-06-25 21:18:40.689985
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    str_0 = text_0.title()
    assert str_0 is not None


# Generated at 2022-06-25 21:18:44.646151
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_1 = Text()
    str_1 = text_1.sentence()


# Generated at 2022-06-25 21:18:47.090566
# Unit test for method color of class Text
def test_Text_color():
    text_0 = Text()
    str_0 = text_0.color()


# Generated at 2022-06-25 21:18:51.619383
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_0 = text_0.level()
    # Check that str_0 is a string
    if not isinstance(str_0, str):
        print('Error: method level of class Text returned type: {}'.format(type(str_0)))


# Generated at 2022-06-25 21:18:55.970302
# Unit test for method answer of class Text
def test_Text_answer():
    text_1 = Text()
    assert type(text_1.answer()) is str


# Generated at 2022-06-25 21:18:56.968418
# Unit test for method quote of class Text
def test_Text_quote():
    text_0 = Text()
    str_0 = text_0.quote()


# Generated at 2022-06-25 21:18:59.490530
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()



# Generated at 2022-06-25 21:19:01.911906
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    str_0 = text_0.word()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:19:03.970963
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    list_0 = text_0.words(quantity=3)
    assert len(list_0) == 3
    assert list_0[2] * 3 == list_0[1] * 3 * 3


# Generated at 2022-06-25 21:19:06.428192
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    int_0 = 1
    str_0 = text_0.words(int_0)


# Generated at 2022-06-25 21:19:47.066915
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    tuple_0 = text_0.rgb_color()
    tuple_1 = text_0.rgb_color()
    tuple_2 = text_0.rgb_color()
    print(tuple_0)
    print(tuple_1)
    print(tuple_2)


# Generated at 2022-06-25 21:19:48.740262
# Unit test for method word of class Text
def test_Text_word():
    text = Text()
    text.word()


# Generated at 2022-06-25 21:19:49.536909
# Unit test for method words of class Text
def test_Text_words():
    text1 = Text()
    word_list = text1.words()

# Generated at 2022-06-25 21:19:51.018771
# Unit test for method words of class Text
def test_Text_words():
    # Tests for method words of class Text
    text_0 = Text()
    str_0 = text_0.words(quantity=1)
    assert isinstance(str_0, list)


# Generated at 2022-06-25 21:19:53.457086
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    str_0 = text_0.alphabet()
    str_1 = text_0.alphabet(True)


# Generated at 2022-06-25 21:19:54.485401
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    str_0 = text_0.hex_color()


# Generated at 2022-06-25 21:19:56.787348
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    """
    Tests for text.swear_word
    """
    text_0 = Text()
    str_0 = text_0.swear_word()

    if str_0.find(' ') != -1:
        assert False

# Generated at 2022-06-25 21:19:57.850431
# Unit test for method title of class Text
def test_Text_title():
    text_1 = Text()
    str_1 = text_1.title()


# Generated at 2022-06-25 21:20:01.002439
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()
    assert str_0.lower() in ['yes','no','maybe','i don\'t know','of course','i\'m not sure','let me think','i really don\'t know','yes, of course','no, never','yes, of course not']


# Generated at 2022-06-25 21:20:02.402462
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    assert(text_0.level() in text_0._data['level'])
