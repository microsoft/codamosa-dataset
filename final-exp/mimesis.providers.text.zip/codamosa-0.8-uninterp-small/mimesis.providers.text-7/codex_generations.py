

# Generated at 2022-06-25 21:17:15.086025
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    str_0 = text.title()
    print(str_0)
    str_1 = text.text()
    print(str_1)



# Generated at 2022-06-25 21:17:16.905085
# Unit test for method swear_word of class Text
def test_Text_swear_word():
    a=Text()
    result=a.swear_word()
    #assert result in ["mama","father"]

# Generated at 2022-06-25 21:17:19.600717
# Unit test for method title of class Text
def test_Text_title():
    text = Text()
    title = text.title()
    assert title == 'Bond... James Bond.'


# Generated at 2022-06-25 21:17:25.663663
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    try:
        str_0 = text_0.hex_color()
        str_1 = text_0.hex_color(safe=True)
    except Exception as e:
        str_2 = str(e)


# Generated at 2022-06-25 21:17:33.206821
# Unit test for constructor of class Text
def test_Text():
    # Test 1:
    constructor_text_1 = Text()

    assert constructor_text_1.language == 'en'
    assert constructor_text_1.country == 'US'
    assert constructor_text_1.seed == 42

    # Test 2:
    constructor_text_2 = Text(language='fr')

    assert constructor_text_2.language == 'fr'
    assert constructor_text_2.country == 'FR'
    assert constructor_text_2.seed == 42

    # Test 3:
    constructor_text_3 = Text(language='es', country='ES')

    assert constructor_text_3.language == 'es'
    assert constructor_text_3.country == 'ES'
    assert constructor_text_3.seed == 42

    # Test 4:

# Generated at 2022-06-25 21:17:37.824256
# Unit test for method title of class Text
def test_Text_title():
    text_2 = Text(seed=172216)
    result = text_2.title()
    assert result == "Like a bird on the wire"


# Generated at 2022-06-25 21:17:41.688717
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    str_0 = text_0.hex_color(False)
    assert(str_0 == '#6b8ec6')


# Generated at 2022-06-25 21:17:43.618944
# Unit test for method answer of class Text
def test_Text_answer():
    text = Text()
    assert isinstance(text.answer(), str)



# Generated at 2022-06-25 21:17:49.931933
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    rnd = False
    text_i = Text(seed=rnd)
    text_i_hex = text_i.hex_color(rnd)
    rnd = True
    text_r = Text(seed=rnd)
    text_r_hex = text_r.hex_color(rnd)
    assert(text_i_hex == '#b4fb4c')
    assert(text_r_hex == '#d8346b')


# Generated at 2022-06-25 21:18:01.314316
# Unit test for method words of class Text
def test_Text_words():
    text_0 = Text()
    list_0 = text_0.words(quantity = 7)
    assert (list_0 == ['', '', '', '', '', '', ''])
    text_1 = Text()
    list_1 = text_1.words(quantity = 9)
    assert (list_1 == ['', '', '', '', '', '', '', '', ''])
    text_2 = Text()
    list_2 = text_2.words(quantity = 3)
    assert (list_2 == ['', '', ''])
    text_3 = Text()
    list_3 = text_3.words(quantity = 4)
    assert (list_3 == ['', '', '', ''])
    text_4 = Text()