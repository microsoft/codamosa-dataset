

# Generated at 2022-06-25 21:17:45.888497
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()

    assert sentence
    assert type(sentence) == str


# Generated at 2022-06-25 21:17:48.026399
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    str_0 = text_0.rgb_color()


# Generated at 2022-06-25 21:17:50.263115
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)

# Generated at 2022-06-25 21:17:53.111219
# Unit test for method rgb_color of class Text
def test_Text_rgb_color():
    text_0 = Text()
    assert len(text_0.rgb_color()) == 3


# Generated at 2022-06-25 21:17:56.773720
# Unit test for method word of class Text
def test_Text_word():
    text_0 = Text()
    str_0 = text_0.word()


# Generated at 2022-06-25 21:17:57.789009
# Unit test for method level of class Text
def test_Text_level():
    text_0 = Text()
    str_1 = text_0.level()


# Generated at 2022-06-25 21:18:02.233080
# Unit test for constructor of class Text
def test_Text():
    import unittest
    from mimesis.enums import Language

    class TestText(unittest.TestCase):

        def setUp(self):
            self.seed = 0
            self.text = Text(self.seed)

        def test_constructor(self):
            self.assertTrue(isinstance(self.text, Text))

        def test_locale(self):
            self.assertEqual(self.text.seed, 0)

    unittest.main()



# Generated at 2022-06-25 21:18:07.850073
# Unit test for method word of class Text
def test_Text_word():
    text_1 = Text() 
    text_1.word()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:18:09.567619
# Unit test for method text of class Text
def test_Text_text():
    text_0 = Text()
    str_0 = text_0.text()


# Generated at 2022-06-25 21:18:18.851325
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    text_0 = Text()
    hex_color = text_0.hex_color()
    assert isinstance(hex_color, str)
    assert len(hex_color) == 7
    assert hex_color[0] == "#"
    assert len(hex_color[1:]) == 6
    assert all(key in "0123456789abcdef" for key in hex_color[1:].lower())


# Generated at 2022-06-25 21:20:51.484900
# Unit test for constructor of class Text
def test_Text():
    assert(Text())


# Generated at 2022-06-25 21:20:52.648797
# Unit test for method sentence of class Text
def test_Text_sentence():
    text_0 = Text()
    assert isinstance(text_0.sentence(), str)


# Generated at 2022-06-25 21:20:53.637823
# Unit test for method quote of class Text
def test_Text_quote():
    str_0 = Text().quote()


# Generated at 2022-06-25 21:20:55.001753
# Unit test for method alphabet of class Text
def test_Text_alphabet():
    text_0 = Text()
    list_0 = text_0.alphabet(lower_case = False)


# Generated at 2022-06-25 21:20:55.979559
# Unit test for method hex_color of class Text
def test_Text_hex_color():
    txt = Text()
    assert 7 == len(txt.hex_color())

# Generated at 2022-06-25 21:20:58.270800
# Unit test for method level of class Text
def test_Text_level():
    try:
        text = Text.level()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 21:21:03.609028
# Unit test for method title of class Text
def test_Text_title():
    text_0 = Text()
    # Testing method title with arguments (quantity=None).
    str_0 = text_0.title()
    # Testing method title with arguments (quantity=0).
    str_0 = text_0.title(quantity=0)
    # Testing method title with arguments (quantity=1).
    str_0 = text_0.title(quantity=1)
    # Testing method title with arguments (quantity=2).
    str_0 = text_0.title(quantity=2)
    # Testing method title with arguments (quantity=3).
    str_0 = text_0.title(quantity=3)
    # Testing method title with arguments (quantity=4).
    str_0 = text_0.title(quantity=4)
    # Testing method title with arguments (quantity

# Generated at 2022-06-25 21:21:05.552703
# Unit test for method level of class Text
def test_Text_level():
    text = Text()
    print("Printing 5 random levels of danger\n")
    for x in range(0, 5):
        print(text.level())


# Generated at 2022-06-25 21:21:08.182269
# Unit test for method answer of class Text
def test_Text_answer():
    text_0 = Text()
    str_0 = text_0.answer()

# Generated at 2022-06-25 21:21:10.240975
# Unit test for method sentence of class Text
def test_Text_sentence():
    text = Text()
    sentence = text.sentence()
    print(sentence)

