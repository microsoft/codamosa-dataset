

# Generated at 2022-06-22 08:39:29.593867
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    playlist_id = ie._match_id(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_id == 'zzdE77v6Mmo'
    playlist_data = ie._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

# Generated at 2022-06-22 08:39:37.166912
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_info_extractor = TudouPlaylistIE
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_id = 'zzdE77v6Mmo'
    test_info = {'id': 'zzdE77v6Mmo'}
    test_playlist_mincount = 209
    assert test_info_extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_info_extractor._TESTS[0]['url'] == test_url
    a = test_info_extractor()
    assert a.IE_NAME == 'tudou:playlist'
    assert a._VAL

# Generated at 2022-06-22 08:39:38.312742
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, TudouPlaylistIE)


# Generated at 2022-06-22 08:39:42.125551
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'Tudou:playlist'

# Generated at 2022-06-22 08:39:47.624138
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Call the constructor
    album_ie = TudouAlbumIE()
    # Make sure URL is valid
    assert album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', 'URL is invalid'


# Generated at 2022-06-22 08:39:49.318068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    checker = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:53.762929
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    # start test code
    # print '-' * 30 + ' Testing TudouAlbumIE ... ' + '-' * 30

    test_playlist = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    # print test_playlist.__dict__
    # end test code



# Generated at 2022-06-22 08:39:58.092978
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(params = {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'});
    assert ie is not None;
    assert ie._TESTS is not None;
    assert len(ie._TESTS) > 0;

# Generated at 2022-06-22 08:40:00.290918
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-22 08:40:08.920062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import json
    import os
    import os.path
    importedName = __name__ + '.test_TudouAlbumIE'
    class TestTudouAlbumIE(unittest.TestCase):
        def test_TudouAlbumIE(self):
            filePath = os.path.join(os.getcwd(), 'test', 'testdata', 'tudou_album_expected.json')
            # to get TestTudouAlbumIE
            album_id = 'v5qckFJvNJg'
            album_data = self._download_json(
                'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)

# Generated at 2022-06-22 08:40:18.843817
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL
    assert ie._TESTS



# Generated at 2022-06-22 08:40:22.606076
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test_obj = TudouAlbumIE()
    assert test_obj.suitable(test_url) == True
    return

# Generated at 2022-06-22 08:40:33.896733
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')

    class TestTudouPlaylistIE(unittest.TestCase):
        def setUp(self):
            self.ie = TudouPlaylistIE()

        def test_constructor(self):
            self.assertEqual(self.ie.IE_NAME, 'tudou:playlist')
            self.assertEqual(self.ie.IE_DESC, '土豆 - 发现更多优质视频')

# Generated at 2022-06-22 08:40:41.309067
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    c = TudouPlaylistIE();
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    c.url_result('http://www.tudou.com/programs/view/%s' % album_id,
            'Tudou', album_id,
            album_data['items']['kw'])

# Generated at 2022-06-22 08:40:42.893060
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()


# Generated at 2022-06-22 08:40:43.891529
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE()

# Generated at 2022-06-22 08:40:54.046307
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html','tudou', 'test','test')
    ie._download_json('http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg')
    entries = [ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return ie.playlist_result(entries, album_id)

if __name__ == '__main__':
    test_TudouAlbum

# Generated at 2022-06-22 08:41:05.349310
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().IE_NAME == 'tudou:album'
    assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(TudouAlbumIE()._TESTS) == 1
    assert TudouAlbumIE()._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE()._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE()._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-22 08:41:09.691596
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE(None)
    assert True

# Generated at 2022-06-22 08:41:15.937101
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-22 08:41:31.974644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:41:44.500114
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert(test_obj.IE_NAME == 'tudou:playlist')
    assert(test_obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(test_obj.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:41:55.825227
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    tests = [
        # Testcase 1: playlist with multiple video items
        {
            'input_url': 'http://www.tudou.com/listplay/Qc51a8GkdF0.html',
            'expected_url': 'http://www.tudou.com/tvp/plist.action?lcode=Qc51a8GkdF0',
            'expected_id_1': 'Qc51a8GkdF0',
            'expected_id_2': 'Qc51a8GkdF0',
            'playlist_id': 4,
        },
    ]

    for testcase in tests:
        playlist_ie = TudouPlaylistIE(testcase['input_url'])
        assert playlist_ie.url == testcase['expected_url']
        assert playlist

# Generated at 2022-06-22 08:41:59.658747
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = TudouPlaylistIE()

    result = info_extractor._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

    assert len(result['entries']) >= 209 
    assert result['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:42:02.875381
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  tudou_albumIE = TudouAlbumIE()
  assert tudou_albumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
  assert tudou_albumIE.IE_NAME == 'tudou:album'



# Generated at 2022-06-22 08:42:11.919315
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_ie = TudouPlaylistIE()
    assert test_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:42:23.279597
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test url: http://www.tudou.com/albumplay/Z1VX9sxuF7M
    """
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:42:31.102240
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		url1 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
		url2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
		TudouAlbumIE(url1)
		TudouAlbumIE(url2)
	except:
		print('Cannot construct an instance of class TudouAlbumIE')
		return False
	else:
		return True

# Generated at 2022-06-22 08:42:40.341504
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Assume following constants are correct.
    #_VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    #IE_NAME = 'tudou:album'
    #_TESTS = [{
    #    'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
    #    'info_dict': {
    #        'id': 'v5qckFJvNJg',
    #    },
    #    'playlist_mincount': 45,
    #}]
    tudou_album = TudouAlbumIE()
    # Check that the album_id is extracted correctly
    # since _VALID_URL

# Generated at 2022-06-22 08:42:43.964650
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from TudouAlbumIE import TudouAlbumIE
    tu = TudouAlbumIE("", "v5qckFJvNJg", "", "", "")
    assert tu != None, "Constructor of class TudouAlbumIE returns None."

# Generated at 2022-06-22 08:43:01.884783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	newTudouPlaylistIE = TudouPlaylistIE("www.tudou.com/listplay/zzdE77v6Mmo.html");
	print("newTudouPlaylistIE = " + newTudouPlaylistIE);

# Generated at 2022-06-22 08:43:10.523421
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert (TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (TudouPlaylistIE._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}])
    assert (type(TudouPlaylistIE._TESTS) == type([]))


# Generated at 2022-06-22 08:43:16.171793
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE('www.tudou.com', {}, True)
    assert(isinstance(albumIE, InfoExtractor))
    assert(isinstance(albumIE, TudouAlbumIE))


# Generated at 2022-06-22 08:43:26.196513
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    from .theplatform import ThePlatformIE
    from .common import FileDownloader
    from .subtitles import SubtitlesInfoExtractor
    from .francetv import FranceTvInfoExtractor
    from .dotsub import DotSubIE
    from .viddler import ViddlerIE
    from .fourtube import FourTubeIE
    from .telecinco import TelecincoIE
    from .common import InfoExtractor
    from .ooyala import OoyalaIE
    from .tsn import TSNIE
    from .condenast import CondeNastIE
    from .teachable import TeachableIE
    from .pornhub import PornHubIE
    from .youtube import YoutubeIE

# Generated at 2022-06-22 08:43:29.610439
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ief = TudouPlaylistIE()
    assert ief == ief, "I don't know what this assert does exactly"
    return 0

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-22 08:43:32.695360
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:43:43.578175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    valid_url2 = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
    valid_url3 = 'www.tudou.com/listplay/zzdE77v6Mmo'
    valid_url4 = 'http://www.tudou.com/listplay/zzdE77v6Mmo/'
    valid_url5 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html/'
    valid_url6 = 'http://www.tudou.com/listplay/zzdE77v6Mmo#'

# Generated at 2022-06-22 08:43:49.527514
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE._download_webpage(TudouAlbumIE._VALID_URL))
    ie.init()
    assert ie.is_match()
    assert ie.get_id()
    assert ie.get_name()


# Generated at 2022-06-22 08:43:55.698063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    assert (ie.IE_NAME == 'tudou:playlist')
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    match = ie._VALID_URL.search(url)
    assert (match.group('id') == 'zzdE77v6Mmo')
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-22 08:44:01.249850
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import re
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    hc = InfoExtractor.__new__(TudouPlaylistIE)

    results = hc.extract(test_url)
    #print results


# Generated at 2022-06-22 08:44:29.830590
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistie = TudouPlaylistIE()
    assert tudouplaylistie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:44:30.340841
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE()

# Generated at 2022-06-22 08:44:37.355306
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    asser = TudouPlaylistIE()
    asser.extract(test_url)
    asser.IE_NAME
    asser._VALID_URL
    asser._TESTS
    asser.test_suite()


# Generated at 2022-06-22 08:44:47.898410
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_1 = {
        'name': 'test_1',
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'expect_result': 'zzdE77v6Mmo',
    }

    test_2 = {
        'name': 'test_2',
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo/',
        'expect_result': 'zzdE77v6Mmo',
    }


# Generated at 2022-06-22 08:44:56.338986
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(InfoExtractor())
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert obj._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert obj._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-22 08:44:58.668250
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:45:01.367695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except:
        print('Failed to create object of class TudouAlbumIE')


# Generated at 2022-06-22 08:45:08.149379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist._VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:45:09.136394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:45:14.312768
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Unit test for constructor of class TudouAlbumIE

    >>> TudouAlbumIE()._VALID_URL
    'https?://(?:www\\.)?tudou\\.com/album(?:cover|play)/(?P<id>[\\w-]{11})'
    >>> TudouAlbumIE().IE_NAME
    'tudou:album'
    '''
    pass

# Generated at 2022-06-22 08:46:18.885610
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playList = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    print(playList)
    print(playList.title)
    print(playList.thumbnail)
    print(playList.url)

# Generated at 2022-06-22 08:46:27.777877
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE

    obj = TudouPlaylistIE()
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert obj._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    
    assert obj.ie_key() == 'TudouPlaylist'

# Generated at 2022-06-22 08:46:32.207583
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.VIDEO_URL_TEMPLATE


# Generated at 2022-06-22 08:46:36.722081
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test Case:
    #   Given
    a = u'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    #   When
    b = TudouAlbumIE._match_id(TudouAlbumIE(), a)
    #   Then
    assert b == u'v5qckFJvNJg'
    print("test_TudouAlbumIE passed!")


# Generated at 2022-06-22 08:46:47.522941
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Instance should be created
    instance = TudouPlaylistIE("")
    assert instance is not None

    # Should extract from url containing playlist_id
    instance = TudouPlaylistIE("http://www.tudou.com/listplay/var6w4in6qk")
    assert instance._match_id("http://www.tudou.com/listplay/var6w4in6qk") == 'var6w4in6qk'

    # Should be able to construct url from playlist_id
    assert instance._real_extract("http://www.tudou.com/listplay/var6w4in6qk")["url"] == "http://www.tudou.com/listplay/var6w4in6qk.html"


# Generated at 2022-06-22 08:46:54.957498
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:47:05.771722
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_data = {'code': 0, 'channel': [{'code': 'zzdE77v6Mmo'}],
                     'items': [{'icode': '0f1aSSy_xjI'}]}
    playlist_entry = {'id': '0f1aSSy_xjI'}
    playlist_result_data = {'_type': 'playlist', 'id': 'zzdE77v6Mmo', 'entries': [playlist_entry]}

    def _download_json(url, video_id):
        return playlist_data


# Generated at 2022-06-22 08:47:16.738025
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    IE_NAME = 'tudou:album'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    assert ie.IE_NAME == IE_NAME
    assert ie._VALID_URL == _VALID_URL
    assert ie._TESTS == _TESTS
# End of test for constructor of class

# Generated at 2022-06-22 08:47:18.419935
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE.__name__ == 'TudouPlaylistIE')


# Generated at 2022-06-22 08:47:19.411484
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	return TudouAlbumIE