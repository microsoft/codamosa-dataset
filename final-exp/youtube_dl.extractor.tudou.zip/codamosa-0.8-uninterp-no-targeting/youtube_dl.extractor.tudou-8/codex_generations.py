

# Generated at 2022-06-22 08:39:20.972082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE();
    assert(a)

# Generated at 2022-06-22 08:39:23.469959
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  def construct_a_TudouAlbumIE():
    import TudouPlaylistIE
    ie = TudouPlaylistIE.TudouAlbumIE('foo')
  construct_a_TudouAlbumIE()

# Generated at 2022-06-22 08:39:24.030064
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-22 08:39:27.697877
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    assert i.IE_NAME == 'tudou:album'
    assert i.INFO_SRC_NAME == 'tudou'
    assert i.IE_DESC == '土豆人人视频'



# Generated at 2022-06-22 08:39:35.634361
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbumIE = TudouAlbumIE()
	# test case for is_cool_url()
	url = "https://www.tudou.com/albumcover/v5qckFJvNJg.html"
	assert (tudouAlbumIE.is_cool_url(url)),'Should be cool url'
	url = "https://www.tudou.com/albumplay/v5qckFJvNJg.html"
	assert (tudouAlbumIE.is_cool_url(url)),'Should be cool url'
	url = "https://www.tudou.com/albumcover/v5qckFJvNJg"
	assert (tudouAlbumIE.is_cool_url(url)),'Should be cool url'

# Generated at 2022-06-22 08:39:37.024233
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE(None)
    assert isinstance(t, TudouAlbumIE)

# Generated at 2022-06-22 08:39:37.656635
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-22 08:39:41.121020
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-22 08:39:46.777189
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:39:57.327224
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class tudou(object):
        def __init__(self, url):
            self.url = url
            self.return_value = None
        def register(self):
            return self
        def extrac(self, *args, **kwargs):
            return self.return_value

# Generated at 2022-06-22 08:40:02.081524
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test if TudouAlbumIE can be constructed
    assert(TudouAlbumIE(_download_html))


# Generated at 2022-06-22 08:40:05.199123
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:40:14.946453
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    my_test = TudouPlaylistIE(None)
    assert my_test.get_IE_NAME() == 'tudou:playlist'
    assert my_test.get_VALID_URL() == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert my_test.get_TESTS() == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:40:19.257199
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'tudou:playlist'
    assert ie.ie_version()


# Generated at 2022-06-22 08:40:26.946826
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_obj = TudouAlbumIE(InfoExtractor()); # create an object of type TudouAlbumIE
    assert(test_obj._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\\w-]{11})') # test the value of _VALID_URL, the regular expression of 'http://'

# Generated at 2022-06-22 08:40:37.510989
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    play_list = TudouPlaylistIE()
    assert play_list.IE_NAME == 'tudou:playlist'
    assert play_list._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(play_list._TESTS) == 1
    assert play_list._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert play_list._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:40:40.553986
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:40:42.644987
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Constructor of class TudouPlaylistIE
	TudouPlaylistIE()


# Generated at 2022-06-22 08:40:51.537716
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    extractor = TudouPlaylistIE(TudouPlaylistIE.IE_NAME, url)
    assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert extractor._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:40:57.460152
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()

    r_url = tudou_album_ie._match_id(url)
    assert r_url == 'v5qckFJvNJg'
    assert r_url == tudou_album_ie._real_extract(url)



# Generated at 2022-06-22 08:41:06.163618
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	try:
		TudouPlaylistIE('This is a unit test')
	except Exception as ex:
		raise ex


# Generated at 2022-06-22 08:41:19.131232
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """test constructor of class TudouPlaylistIE"""
    youtube_playlist = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    id = 'zzdE77v6Mmo'
    assert youtube_playlist._match_id(url) == id
    assert youtube_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:41:24.042671
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE().IE_NAME == TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE().IE_NAME == TudouPlaylistIE._VALID_URL


# Generated at 2022-06-22 08:41:33.647993
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playListUrl = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylist = TudouPlaylistIE()
    tudouPlaylist.extract(playListUrl)
    assert(tudouPlaylist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(tudouPlaylist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(tudouPlaylist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')


# Generated at 2022-06-22 08:41:45.837533
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result_list = []

# Generated at 2022-06-22 08:41:51.653524
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test.IE_NAME == 'tudou:playlist'

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-22 08:42:01.598107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE("Tudou")
    assert tudou_album_ie is not None
    assert tudou_album_ie.IE_NAME == "tudou:album"
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert tudou_album_ie._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg"
    assert tudou

# Generated at 2022-06-22 08:42:06.367616
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    def generate_url(url_without_extension):
        return url_without_extension

    # test
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_object = TudouAlbumIE(TudouAlbumIE, generate_url)
    # test_object.extract(test_url)



# Generated at 2022-06-22 08:42:08.669131
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  pass


# Generated at 2022-06-22 08:42:14.688065
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com')
    assert ie.ie_key() == 'TudouAlbum'
    assert ie.ie_key() in ie.IE_NAME
    assert ie.ie_key() in ie.url_result(0, 0, 0)
    assert ie.ie_key() in ie.playlist_result(0, 0)

# Generated at 2022-06-22 08:42:33.598734
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    def get_album_id(url):
        album_id = None
        if url is not None:
            if isinstance(url, unicode):
                url = url.encode('utf-8')
            if isinstance(url, str):
                m = re.match(r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', url)
                if m:
                    # If a pattern of url is valid, we can get the album ID
                    album_id = m.group('id')
        return album_id

    ie = TudouAlbumIE()
    result = ie._real_extract(ie._VALID_URL)

    assert result is not None
    assert result['_type'] == 'playlist'
    assert result

# Generated at 2022-06-22 08:42:36.362451
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE._real_extract(TudouAlbumIE(), 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:42:47.339790
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert i.IE_NAME == 'tudou:album'
    assert i.password_protected == False
    assert i._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert i._TESTS == [{'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45, 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'}]



# Generated at 2022-06-22 08:42:59.387700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest.mock
    from .tests.test_tudou import mock_TudouIE
    assert mock_TudouIE
    with unittest.mock.patch('youtube_dl.extractor.tudou.common.fetch_decrypt_sig'):
        url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        ie = TudouAlbumIE()
        assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
        assert ie.IE_NAME == 'tudou:album'
        assert ie.ie_key() == 'tudou:album'
        assert ie._real_extract

# Generated at 2022-06-22 08:43:03.987777
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # It should be able to construct an object
    instance = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert instance is not None


# Generated at 2022-06-22 08:43:06.507284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album',{})
    assert ie.ie_key() == 'TudouAlbum'


# Generated at 2022-06-22 08:43:07.161592
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-22 08:43:09.728034
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE._real_extract(self, url)

# Generated at 2022-06-22 08:43:12.042357
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    print(ie.IE_NAME)
    print(ie._VALID_URL)
    print(ie._TESTS)


# Generated at 2022-06-22 08:43:14.954042
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()

# Generated at 2022-06-22 08:43:42.189800
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouPlaylistIE()

# Generated at 2022-06-22 08:43:43.408166
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE(TudouPlaylistIE)

# Generated at 2022-06-22 08:43:45.002964
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1 == 1


# Generated at 2022-06-22 08:43:45.980566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(1)



# Generated at 2022-06-22 08:43:48.529092
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test the constructor of class TudouAlbumIE
    """
    assert TudouAlbumIE.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:43:55.279592
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Initialize a TudouPlaylistIE object
	myTudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-22 08:43:58.693733
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().extract('http://www.tudou.com/albumcover/TJdXyYWFLo0.html')

# Generated at 2022-06-22 08:44:09.985874
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    id = tudou_playlist_ie._match_id(url)
    playlist_data = tudou_playlist_ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % id, id)
    entries = [tudou_playlist_ie.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    playlist_result = tud

# Generated at 2022-06-22 08:44:13.184641
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """test the constructor of class TudouPlaylistIE"""
    ie = TudouPlaylistIE()
    assert(ie != None)


# Generated at 2022-06-22 08:44:14.259147
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:45:21.406717
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()



# Generated at 2022-06-22 08:45:22.234251
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:45:31.191838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Test to create instance with no argument
    try:
        TudouPlaylistIE()
        # No Exception
        assert True
    except:
        # Exception
        assert False

    # Test to create instance with empty argument
    try:
        TudouPlaylistIE({})
        # No Exception
        assert True
    except:
        # Exception
        assert False

    # Test to create instance with valid argument
    try:
        TudouPlaylistIE({'_downloader': 'no'})
        # No Exception
        assert True
    except:
        # Exception
        assert False


# Generated at 2022-06-22 08:45:35.411595
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    assert e.IE_NAME == 'tudou:album'
    assert e._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:45:37.530294
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(None, None), InfoExtractor)



# Generated at 2022-06-22 08:45:40.485844
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_common import shell_exec
    from . import extract
    from .constructor import constructor
    shell_exec( extract.__name__, constructor.__name__, TudouPlaylistIE.IE_NAME)


# Generated at 2022-06-22 08:45:48.583528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info_dict = {'id': 'v5qckFJvNJg'}
    tu_alb = TudouAlbumIE(InfoExtractor._downloader, url)
    assert tu_alb._match_id(url) == info_dict['id']
    assert tu_alb._match_id('') is None

# Generated at 2022-06-22 08:45:54.134496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_tudou import extractor

    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_playlist = TudouPlaylistIE(extractor)
    test_playlist._real_initialize()
    assert(test_playlist._real_extract(test_url))


# Generated at 2022-06-22 08:46:05.631033
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    fileName = 'tudou.py'
    className = 'TudouPlaylistIE'
    result = {}
    exec (compile(open(fileName, "rb").read(), fileName, 'exec')) in result
    myClass = result[className]()

    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    _VALID_URL = myClass._VALID_URL
    match = re.match(_VALID_URL, url)

    playlist_id = match.group('id')
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }
    assert(playlist_id == info_dict['id'])
    # print(playlist_id)
    print(info_dict)


#

# Generated at 2022-06-22 08:46:12.432376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'tudou:playlist' in TudouPlaylistIE.IE_NAME
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE.IE_DESC == '土豆网'
    assert 'tudou:album' in TudouPlaylistIE.IE_NAME
    assert TudouPlaylistIE.IE_NAME == 'tudou:album'
    assert TudouPlaylistIE.IE_DESC == '土豆网'

# Generated at 2022-06-22 08:48:39.896549
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	ie = TudouPlaylistIE()
	assert ie.IE_NAME == 'tudou:playlist'
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert ie._real_initialize(url) == None
	assert ie._real_extract(url) == None
	assert ie.IE_DESC == 'Tudou Playlist'
	assert ie._download_webpage(url, 'zzdE77v6Mmo') == None
	assert ie._download_json(url, 'zzdE77v6Mmo') == None


# Generated at 2022-06-22 08:48:42.152385
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = '<class \'__main__.TudouAlbumIE\'>'
    assert str(type(TudouAlbumIE)) == result

# Generated at 2022-06-22 08:48:48.293309
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test constructor of class TudouAlbumIE
    # Create a TudouAlbumIE instance
    obj = TudouAlbumIE()
    # Assert type is "tudou:album"
    assert obj.IE_NAME == 'tudou:album'
    # Assert Valid URL
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # Assert _TESTS
    # Check if each item in the list is a AlbumTestCase
    #TODO:

# Generated at 2022-06-22 08:48:54.338657
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.playlist_id == 'zzdE77v6Mmo'
    assert ie.playlist_mincount == 209
    #print(ie.playlist_result(entries, 'zzdE77v6Mmo'))
    

# Generated at 2022-06-22 08:48:58.932197
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Arrange
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()

    # Act
    try:
        TudouPlaylistIE(url)
    except Exception as e:
        # Assert
        assert e.args[0] == url

# Generated at 2022-06-22 08:49:06.133570
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DESC == '土豆网 (Tudou) - 列表'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:49:07.947473
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:49:18.904180
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'