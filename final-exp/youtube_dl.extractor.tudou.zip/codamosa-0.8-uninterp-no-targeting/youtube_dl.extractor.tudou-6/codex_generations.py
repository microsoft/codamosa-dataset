

# Generated at 2022-06-22 08:39:23.161106
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(TudouAlbumIE._create_ie(), url)
    assert ie._TESTS[0]['url'] == ie._VALID_URL

# Generated at 2022-06-22 08:39:30.421264
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        obj = TudouPlaylistIE('TudouPlaylistIE', 'TudouPlaylistIE', 'TudouPlaylistIE', 'TudouPlaylistIE')
        print("Test create object of class TudouPlaylistIE: Success")
    except:
        print("Test create object of class TudouPlaylistIE: Failed")
    try:
        obj = TudouPlaylistIE('', '', '', '')
        print("Test create object of class TudouPlaylistIE with blank parameter: Success")
    except:
        print("Test create object of class TudouPlaylistIE with blank parameter: Failed")


# Generated at 2022-06-22 08:39:31.952591
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'Tudou:playlist'

# Generated at 2022-06-22 08:39:43.423334
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    ie = TudouAlbumIE(defaults={'skip': 'true'})
    ie._get_albumId_by_url(url)
    ie._real_extract(url)
    ie.extract(url)
    ie.extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    ie.extract("http://www.tudou.com/albumplay/v5qckFJvNJg")
    ie.extract("http://www.tudou.com/albumcover/v5qckFJvNJg")


# Generated at 2022-06-22 08:39:45.814713
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert len(result['entries']) > 0
    assert result['id'] == result['entries'][0]['id']

# Generated at 2022-06-22 08:39:51.726340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    x = t.url
    y = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    if x != y:
        raise ValueError('%s is expected, but got %s' % (y, x))

# Generated at 2022-06-22 08:40:01.392484
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'playlist_mincount': 45, 'info_dict': {'id': 'v5qckFJvNJg'}}]

# Generated at 2022-06-22 08:40:04.966428
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor of class TudouPlaylistIE
    from .tudou import TudouPlaylistIE
    assert isinstance(TudouPlaylistIE(None, None), object)

# Generated at 2022-06-22 08:40:07.695463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE

    """
    print("Calling tudou:playlist constructor...")
    playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    t = TudouPlaylistIE(playlist_url)

    assert t is not None


# Generated at 2022-06-22 08:40:17.405414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
	assert t.IE_NAME == "tudou:album"
	assert t.VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert t.TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]

# Generated at 2022-06-22 08:40:29.756075
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    class TestTudouAlbumIE(unittest.TestCase):
        def setUp(self):
            self.item = {
                'icode': "1234567890",
                'kw': "测试"
            }
            self.ie = TudouAlbumIE()


# Generated at 2022-06-22 08:40:38.713883
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie.IE_NAME, unicode)
    assert ie.IE_NAME == 'tudou:playlist'
    assert isinstance(ie._VALID_URL, (type(None), unicode))
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:40:40.070662
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    unittest.main()


# Generated at 2022-06-22 08:40:49.176144
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.playlist_id == 'zzdE77v6Mmo'
    assert playlist.playlist_entries
    assert playlist.playlist_entries[0].icode == 'fELyEuJ7f34'
    assert playlist.playlist_entries[20].kw == u'美容养颜'
    assert playlist.playlist_entries[100].icode == 'A6AIW8ESRxk'


# Generated at 2022-06-22 08:40:54.480624
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudoup = TudouPlaylistIE()
    item = tudoup.url_result(url, 'Tudou', 'zzdE77v6Mmo')
    assert item['id'] == 'zzdE77v6Mmo'
    assert item['ext'] == 'mp4'
    assert item['url'] == url


# Generated at 2022-06-22 08:40:57.881228
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:41:08.132586
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:41:12.750278
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ts = TudouPlaylistIE()
    videoUrl = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    reslut = ts.suitable(videoUrl)
    assert reslut == True


# Generated at 2022-06-22 08:41:15.696886
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   TudouAlbumIE()

# Generated at 2022-06-22 08:41:25.279136
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html');
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    field_names = ['url', 'ie_key', 'video_id']
    values = [url, 'Tudou', 'v5qckFJvNJg']
    assert (i.SUFFIX == '.html');
    assert (i._TEST == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45});

# Generated at 2022-06-22 08:41:43.352031
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test 1
    album_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/%s.html' % album_id
    tudou_album_ie = TudouAlbumIE(url)
    assert (tudou_album_ie is not None)
    assert (tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert (tudou_album_ie._TESTS[0]['url'] == url)
    assert (tudou_album_ie._downloader is not None)


# Generated at 2022-06-22 08:41:45.479812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_obj = TudouAlbumIE()
    assert tudou_album_obj is not None

# Generated at 2022-06-22 08:41:47.805812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:41:49.767573
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ref = TudouAlbumIE()
	print(ref)

# Generated at 2022-06-22 08:41:59.765557
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test None input case
    playlist = TudouPlaylistIE()
    assert playlist.ie_key() == 'Tudou:playlist'

    # Test URL input case
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
    assert playlist.ie_key() == 'Tudou:playlist'


# Generated at 2022-06-22 08:42:01.458162
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE(None)
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    

# Generated at 2022-06-22 08:42:10.885839
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:42:15.666599
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.name == 'tudou:playlist'
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.ie_key() == 'TudouPlaylist'

    # Test some cases for _VALID_URL
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._match_id('http://www.tudou.com/listplay/1234.html') == '1234'
    assert playlist._match_id('http://www.tudou.com/listplay/hahahehehi.html') == 'hahahehehi'

# Generated at 2022-06-22 08:42:17.209019
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie=TudouPlaylistIE()

# Generated at 2022-06-22 08:42:20.590563
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert t.suitable(url)


# Generated at 2022-06-22 08:42:38.744670
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import test
    from .test_tudou import TudouPlaylistIE
    info = r'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test(info, TudouPlaylistIE)


# Generated at 2022-06-22 08:42:42.328375
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-22 08:42:52.206301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/' + album_id + '.html'
    album_data = {
        'count': 45,
        'items': [{
            'icode': 'W8zvEs5nN1w',
            'kw': {}
        }, {
            'icode': 'vsY5WUlB8YY',
            'kw': {}
        }]
    }
    result = {
        'id': album_id,
        'entries': []
    }

# Generated at 2022-06-22 08:42:55.327489
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Constructor of class TudouPlaylistIE
    TudouPlaylistIE(url)

# Generated at 2022-06-22 08:42:57.054301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/album/')
    assert ie.name == 'Tudou'

# Generated at 2022-06-22 08:43:06.578078
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.__module__ == 'tudou'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}

# Generated at 2022-06-22 08:43:07.217251
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert True

# Generated at 2022-06-22 08:43:10.566186
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert(t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-22 08:43:23.210858
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	obj = TudouAlbumIE();
	obj.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	obj.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	obj.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	obj.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
	obj.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:43:26.938269
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album = TudouAlbumIE(None)
	if not tudou_album:
		raise RuntimeError("Test case failed: tudou_album object can't be initialized")

# Generated at 2022-06-22 08:43:42.978693
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_TudouAlbumIE = TudouAlbumIE()
	assert(test_TudouAlbumIE != None)



# Generated at 2022-06-22 08:43:47.285674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(
           'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'test_TudouPlaylistIE',
            'test_TudouPlaylistIE',
            {})


# Generated at 2022-06-22 08:43:50.096508
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert (TudouPlaylistIE().IE_NAME == "tudou:playlist") == True


# Generated at 2022-06-22 08:43:52.274393
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:43:58.248994
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    This is a constructor test for class TudouPlaylistIE.
    """
    def test_TudouPlaylistIE_constructor():
        ie = TudouPlaylistIE()
        assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    test_TudouPlaylistIE_constructor()


# Generated at 2022-06-22 08:44:04.477866
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test_TudouPlaylistIE_invalid_url
    with pytest.raises(RegexMatchError):
        TudouPlaylistIE(IE_NAME, IE_VALID_URL)

    # test_TudouPlaylistIE_valid_url
    TudouPlaylistIE(IE_NAME, IE_VALID_URL)


# Generated at 2022-06-22 08:44:05.585693
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:44:10.906556
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.ie_name = 'tudou:playlist'
    tudou_playlist_ie.ie_key = 'tudou:playlist'
    tudou_playlist_ie.ie_desc = 'tudou:playlist'
    tudou_playlist_ie.ie_suffix = '.html'

# Generated at 2022-06-22 08:44:18.199999
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj._match_id('http://www.tudou.com/albumcover/v6zwU3qD-gE.html')=='v6zwU3qD-gE'
    assert obj._match_id('http://www.tudou.com/albumplay/v6zwU3qD-gE.html')=='v6zwU3qD-gE'

test_TudouAlbumIE()

# Generated at 2022-06-22 08:44:27.586088
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE()
    assert ie.suitable(test_url)
    assert ie.IE_NAME in ie._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [
        {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
         'info_dict': {'id': 'v5qckFJvNJg'},
         'playlist_mincount': 45
         }
    ]

   

# Generated at 2022-06-22 08:45:14.774663
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test if the url is valid or invalid. 
	assert TudouPlaylistIE._VALID_URL.match('http://www.tudou.com/listplay/v5qckFJvNJg.html') is not None, 'this url is valid'
	assert TudouPlaylistIE._VALID_URL.match('http://www.bilibili.com/video/av2557445/') is None, 'this url is not valid'
	# Test if the url contains playlist_id.
	r = TudouPlaylistIE._VALID_URL.match('http://www.tudou.com/listplay/v5qckFJvNJg.html')
	assert r.group('id') == 'v5qckFJvNJg', 'this url contain id: %s' % r.group('id')


# Generated at 2022-06-22 08:45:15.957406
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test code
	assert 1 == 1


# Generated at 2022-06-22 08:45:17.302731
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:45:28.250024
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # tudou_playlist_url = "http://www.tudou.com/listplay/0K1T-TmwKj0.html"
    # tudou_playlist_id = "0K1T-TmwKj0"
    tudou_playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist_id = "zzdE77v6Mmo"
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.extract(tudou_playlist_url)

    # Unit test for method _real_extract of class TudouPlaylistIE

# Generated at 2022-06-22 08:45:30.026568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    r = TudouPlaylistIE()
    r.IE_NAME

# Generated at 2022-06-22 08:45:40.072531
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [
        {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}
    ]


# Generated at 2022-06-22 08:45:45.239386
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Construct object
	tudouAlbumIE = TudouAlbumIE()
	# Check attributes
	assert tudouAlbumIE.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:45:53.933570
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    playList = "TudouAlbumIE"
    className = "TudouAlbumIE"
    initExpect = {'playlistid': "v5qckFJvNJg"}
    extractExpect = {
        'id': 'v5qckFJvNJg',
        'title': '娱乐星天地',
        'uploader': '腾讯视频',
        'uploader_id': '',
        'extractor_key': 'Tudou',
        'extractors': ['TudouAlbumIE', 'Tudou'],
        'thumbnail': 're:^https?://.*',
    }

    _constructorTest(playList, className, initExpect, extractExpect)


# Generated at 2022-06-22 08:46:02.983186
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:46:12.201728
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'Tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:47:34.211041
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouAlbumIE
    test_TudouAlbumIE = TudouAlbumIE.TudouAlbumIE()
    test_TudouAlbumIE.download = lambda url: url
    # Test case 1: normal url
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    result_dict = test_TudouAlbumIE.extract(url)
    assert result_dict['title'] == u'装备资讯'
    cleaned_list = result_dict['entries'][:2]

# Generated at 2022-06-22 08:47:39.925991
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == 'http://www.tudou.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:47:40.816831
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-22 08:47:50.471681
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    assert tudouAlbum.IE_NAME == 'tudou:album'
    assert tudouAlbum._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbum._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudouAlbum._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert tudouAlbum._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-22 08:47:53.526184
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test constructor
    ie = TudouAlbumIE()
    # check whether we can extract some information
    ret = ie.extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert len(ret['entries']) == 45

# Generated at 2022-06-22 08:47:56.977921
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import test_urls_metadata
    test_urls_metadata('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:48:05.702073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME=='tudou:playlist'
    assert ie._VALID_URL==r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS==[{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:48:09.969324
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    instance = TudouAlbumIE()
    assert (instance.IE_NAME is not None)
    assert (instance._VALID_URL is not None)
    assert (instance._TESTS is not None)

# Generated at 2022-06-22 08:48:13.000590
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_Tudou import tudou_playlist_test
    # test for code coverage for initializing class TudouPlaylistIE
    ie = TudouPlaylistIE()
    try:
        ie.extract(tudou_playlist_test['url'])
    except AssertionError:
        pass


# Generated at 2022-06-22 08:48:16.139703
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("test_TudouPlaylistIE\n")
	instance = TudouPlaylistIE("TudouPlaylistIE", "TudouPlaylistIE")
	assert not (instance is None), "test_TudouPlaylistIE instance is null"