

# Generated at 2022-06-22 08:39:26.340105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('tudou:album')
    assert tudou_album_ie.ie_name == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    test = tudou_album_ie._TESTS[0]
    assert test['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert test['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert test['playlist_mincount'] == 45


# Generated at 2022-06-22 08:39:29.677522
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Real-life test for constructor of class TudouAlbumIE
    """
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE()._real_initialize()
    assert True

# Generated at 2022-06-22 08:39:37.303637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from pprint import pprint
    from youtube_dl.utils import DateRange
    print('\n')
    tpi = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    pprint(tpi.extract(url))
    assert len(tpi.extract(url)) == 2
    assert len(tpi._real_extract(url)) == 8
    assert len(tpi.extract_entries(url)) == 209
    assert isinstance(tpi, InfoExtractor)
    assert isinstance(tpi.playlist_result(tpi.extract_entries(url), 'zzdE77v6Mmo'), dict)
    assert isinstance(tpi.extract_entries(url), list)
   

# Generated at 2022-06-22 08:39:44.518077
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import get_testdata_file
    from .extractor.tudou_playlist import TudouPlaylistIE
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_content = get_testdata_file('zzdE77v6Mmo.json')
    playlist_extractor = TudouPlaylistIE(playlist_url, playlist_content)
    assert playlist_extractor != None


# Generated at 2022-06-22 08:39:46.197784
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie._real_extract(url)


# Generated at 2022-06-22 08:39:48.603582
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()

# Generated at 2022-06-22 08:39:56.943066
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Test a valid URL.
    ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")

    # Test some other valid URLs.
    ie = TudouPlaylistIE("http://www.tudou.com/listplay/3d0f73b0ae02cd28.html")
    ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")

    # Test an invalid URL.
    with pytest.raises(TudouPlaylistIE):
        ie = TudouPlaylistIE("http://www.tudou.com/programs/view/WrWrWrWrWr")


# Generated at 2022-06-22 08:40:01.170488
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	if __name__=='__main__':
		tudou_obj = TudouPlaylistIE()
		tudou_obj.download = lambda x: print(x)
		url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
		tudou_obj._real_extract(url)

# Generated at 2022-06-22 08:40:03.295448
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    return album_ie


# Generated at 2022-06-22 08:40:07.822639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    for url in [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    ]:
        # Construct a TudouAlbumIE
        ie = TudouAlbumIE(url)
        assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:40:20.546701
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouIE = TudouPlaylistIE()
    # Test if the id contains only leters, digits and underscores and is under lenght 11
    assert tudouIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    return tudouIE


# Generated at 2022-06-22 08:40:23.818528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test whether tudou album support works."""
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(ie)

# Generated at 2022-06-22 08:40:24.440257
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert True

# Generated at 2022-06-22 08:40:27.227541
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouAlbumIE
    # Unit test for constructor of class TudouAlbumIE
    assert TudouAlbumIE.TudouAlbumIE(TudouAlbumIE.TudouAlbumIE.IE_NAME)


# Generated at 2022-06-22 08:40:28.958697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE.test()
    except:
        print("Failed")

# Generated at 2022-06-22 08:40:30.665124
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:40:36.718006
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    global TudouAlbumIE
    TudouAlbumIE = class_name_import(
        "tudou.TudouAlbumIE",
        __name__
    )
    assert TudouAlbumIE._VALID_URL is not None
    TudouAlbumIE = class_name_import(
        "tudou.TudouAlbumIE",
        "__main__"
    )

# Generated at 2022-06-22 08:40:40.672381
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        print("Constructor test: ")
        tudou_album_ie = TudouAlbumIE()
    except Exception as e:
        print(e)
    return


# Generated at 2022-06-22 08:40:41.819360
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor
    TudouPlaylistIE()

# Generated at 2022-06-22 08:40:42.954544
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE() is not None)

# Generated at 2022-06-22 08:40:53.512536
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    app = QApplication(sys.argv)
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-22 08:40:55.966121
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():  
    tudou = TudouAlbumIE()
    # test the type of class TudouAlbumIE
    assert tudou != None

# Generated at 2022-06-22 08:41:06.831811
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._match_id('') == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:41:10.337184
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test with the URL of a real playlist
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_extract(playlist_url)


# Generated at 2022-06-22 08:41:17.307090
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	id = 'zzdE77v6Mmo'
	playlist_mincount = 209
	TudouPlaylistIE = TudouPlaylistIE(url, id)

# Generated at 2022-06-22 08:41:26.233688
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest
	from tudou2 import TudouAlbumIE
	class test_tudou(unittest.TestCase):
		def setUp(self):
			self.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
			self.test = TudouAlbumIE(self.url)
			self.test._downloader = MockTudou()

		def tearDown(self):
			pass

		def test_url(self):
			self.assertEqual(self.test.url, self.url)

		def test_real_extract(self):
			self.assertEqual(len(self.test._real_extract(self.url)), 3)


# Generated at 2022-06-22 08:41:27.489049
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return


# Generated at 2022-06-22 08:41:32.509724
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album_ie_instance = TudouAlbumIE()
	assert(tudou_album_ie_instance.ie_name() == 'tudou:album')
	assert(type(tudou_album_ie_instance) == TudouAlbumIE)


# Generated at 2022-06-22 08:41:37.435715
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_obj = TudouAlbumIE()
    assert_equal('v5qckFJvNJg', test_obj._match_id(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html'))

# Generated at 2022-06-22 08:41:45.542708
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(None)._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE(None)._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', \
        'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-22 08:42:01.233109
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()

# Generated at 2022-06-22 08:42:09.676085
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    extractor = TudouAlbumIE()
    assert extractor.IE_NAME == 'tudou:album'
    assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert extractor._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:42:15.374518
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = TudouPlaylistIE()
    assert(info_extractor.IE_NAME == 'tudou:playlist')
    assert(info_extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')    


# Generated at 2022-06-22 08:42:24.728013
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:42:33.530359
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:42:35.296263
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.__class__.__name__ == 'TudouAlbumIE'

# Generated at 2022-06-22 08:42:41.218762
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()

# Generated at 2022-06-22 08:42:43.565900
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #Constructor
    TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-22 08:42:51.809096
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(InfoExtractor())
    # tests is going to contain a copy of all the class members
    tests = dict(TudouPlaylistIE.__dict__)
    # remove all the class members other than _VALID_URL
    for key in tests.keys():
        if key[:2] != '__' and key[-2:] != '__' and key != '_VALID_URL':
            del tests[key]

    assert tests == {
        '_VALID_URL': r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    }


# Generated at 2022-06-22 08:42:57.981021
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie_class = TudouAlbumIE(url)
    extractor = tudou_album_ie_class.extractor
    assert extractor._match_id(url) == "v5qckFJvNJg"
    assert not extractor._match_id("https://www.tudou.com/video/xxxxx.html")
    assert not extractor._match_id("https://www.tudou.com/video/")

# Generated at 2022-06-22 08:43:31.055007
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(TudouPlaylistIE.ie_key())
    assert(tudou_playlist_ie.suitable(url)) == True
    assert(tudou_playlist_ie._VALID_URL)


# Generated at 2022-06-22 08:43:36.710357
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_ie = TudouAlbumIE()
    assert album_ie.IE_NAME == 'tudou:album'
    assert album_ie.IE_DESC == '土豆网 专辑'
    assert album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:43:42.138634
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert "TudouAlbumIE" == ie.IE_NAME
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:43:47.244072
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = [0,0]
    try:
        TudouPlaylistIE(t)
    except:
        pass

    TudouPlaylistIE({"url":"http://www.tudou.com/listplay/zzdE77v6Mmo.html","ie_key":"TudouPlaylist"})

# Generated at 2022-06-22 08:43:52.327176
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("===== Running unit test for class TudouPlaylistIE =====")
    tudouPlaylistIE = TudouPlaylistIE(InfoExtractor())
    print("===== Completed unit test for class TudouPlaylistIE =====")

test_TudouPlaylistIE()


# Generated at 2022-06-22 08:44:00.351074
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("\n===============\nUNITTEST FOR TUDOUPLAYLISTIE\n===============\n")
	test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	tudouplaylistie = TudouPlaylistIE()
	test_url_extract = tudouplaylistie._real_extract(test_url)
	assert test_url_extract['id'] == "zzdE77v6Mmo"
	print("Test succeeded.\n")


# Generated at 2022-06-22 08:44:07.134538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	extractor = TudouPlaylistIE()
	assert extractor.IE_NAME == 'tudou:playlist'
	assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:44:11.413416
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    expected = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._URL_PATTERN == expected


# Generated at 2022-06-22 08:44:21.907534
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumurl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudoualbumie = TudouAlbumIE()
    assert tudoualbumie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/([\w-]{11})'# check _VALID_URL
    assert tudoualbumie._match_id(albumurl) == 'v5qckFJvNJg'# check _match_id
    assert tudoualbumie.IE_NAME == 'tudou:album'# check IE_NAME
    assert tudoualbumie._TESTS[0]['url'] == albumurl# check _TESTS[0]['url']
    assert tudoualbumie._

# Generated at 2022-06-22 08:44:26.314030
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    We don't check the actual video data, thus just check if no exception is raised.
    """
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist


# Generated at 2022-06-22 08:45:49.302013
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    video_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_video = TudouPlaylistIE()._real_extract(video_url)
    assert tudou_video.get('id') == 'zzdE77v6Mmo'
    assert tudou_video.get('_type') == 'playlist'
    assert len(tudou_video.get('entries')) == 209


# Generated at 2022-06-22 08:45:53.918096
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylistIE = TudouPlaylistIE(url)
    assert (tudouPlaylistIE._VALID_URL == url)

# Generated at 2022-06-22 08:46:01.311440
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouAlbumIE','http://www.tudou.com/albumplay/v5qckFJvNJg.html','zzdE77v6Mmo')
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:46:05.460735
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(TudouPlaylistIE._downloader)._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-22 08:46:14.387002
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    download_json = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    test_instance = TudouPlaylistIE()
    assert test_instance.IE_NAME == 'tudou:playlist'
    assert test_instance.IE_DESC == 'Tudou Playlist'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test

# Generated at 2022-06-22 08:46:17.044267
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert x is not None


# Generated at 2022-06-22 08:46:20.804149
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	a = TudouAlbumIE(TudouAlbumIE._downloader, TudouAlbumIE._VALID_URL)

# Generated at 2022-06-22 08:46:28.607708
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    al = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert al._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html")=="v5qckFJvNJg"
    assert al._download_json("http://www.tudou.com/tvp/alist.action?acode=%s" % al._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html"), al._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html"))!=None

# Generated at 2022-06-22 08:46:30.244802
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TypeError("object() takes no parameters")
	

# Generated at 2022-06-22 08:46:36.062266
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.url == 'https://www.tudou.com/albumplay/v5qckFJvNJg'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.extract(ie.url)['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:49:11.690887
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(TudouAlbumIE))
    runner = unittest.TextTestRunner()
    runner.run(suite)
