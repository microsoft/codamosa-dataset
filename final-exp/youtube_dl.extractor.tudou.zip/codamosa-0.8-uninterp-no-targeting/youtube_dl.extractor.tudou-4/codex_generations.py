

# Generated at 2022-06-22 08:39:18.466394
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE('Tudou', 'tudou:album')
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 08:39:21.804907
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	x = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:27.815383
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE("http://www.tudou.com/albumcover/VN6oWwcN_7s.html")
    print("test_TudouAlbumIE init")
    assert test_TudouAlbumIE.IE_NAME == 'tudou:album'
    print("test_TudouAlbumIE pass")


# Generated at 2022-06-22 08:39:29.421048
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#TudouPlaylistIE.__init__()
	ex = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:31.711306
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import tudou
	tudou.TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:39:43.422919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  import sys
  import unittest
  if sys.version_info >= (3, 0):
    from urllib.error import HTTPError
  else:
    from urllib2 import HTTPError

  class TudouAlbumIETest(unittest.TestCase):
    class MockResult:
      def __init__(self, text, headers):
        self._text = text
        self._headers = headers

      @property
      def text(self):
        return self._text

      @property
      def headers(self):
        return self._headers

    def MockPerformRequest(self, method, url, body, headers):
      if (url == 'http://www.tudou.com/tvp/alist.action?acode=None'):
        raise HTTPError(url, 400, 'Bad Request', {}, None)

# Generated at 2022-06-22 08:39:44.883003
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:39:53.338220
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create an instance of class TudouPlaylistIE
    ie = TudouPlaylistIE()

    # Test if the url of the video is extracted correctly when url is a valid url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = {
            'id': 'zzdE77v6Mmo',
        }
    actual_result = ie._real_extract(url)
    actual_result_id = actual_result["uploader_id"]
    assert actual_result_id == info_dict["id"]


# Generated at 2022-06-22 08:39:57.966449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:40:01.129825
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_playlist_ie = TudouPlaylistIE()
    assert test_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:40:05.468261
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for https://github.com/rg3/youtube-dl/issues/7950
    assert 1 == 0

# Generated at 2022-06-22 08:40:06.684183
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    D = TudouAlbumIE(None)


# Generated at 2022-06-22 08:40:13.693163
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for url: http://www.tudou.com/albumplay/v5qckFJvNJg.html
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._valid_url(test_url)


# Generated at 2022-06-22 08:40:20.437790
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE(url)
    assert (ie.url == url)
    assert (ie.playlist_id == "zzdE77v6Mmo")
    assert (ie._TEST == True)


# Generated at 2022-06-22 08:40:28.424400
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.ie_name == 'tudou:playlist'
    assert tudou_playlist_ie.valid_urls == [(r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', {'ie_key': 'Tudou'})]
    assert tudou_playlist_ie.youtube_ie == None
    assert tudou_playlist_ie._WORKING == True


# Generated at 2022-06-22 08:40:33.478363
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    # test for method _real_extract
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudouPlaylistIE._real_extract(url)

# Generated at 2022-06-22 08:40:35.634259
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.IE_NAME)



# Generated at 2022-06-22 08:40:47.085543
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   arg = 'https://www.tudou.com/albumcover/X4FZqMsdWuc.html'
   tudou_album_ie = TudouAlbumIE(arg)
   assert tudou_album_ie.ie_key() == 'Tudou:Album'
   assert tudou_album_ie.ie_name() == 'Tudou'
   assert tudou_album_ie._real_extract('https://www.tudou.com/albumcover/X4FZqMsdWuc.html') == tudou_album_ie._real_extract('https://www.tudou.com/albumplay/X4FZqMsdWuc.html')

# Generated at 2022-06-22 08:40:47.790761
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinsta

# Generated at 2022-06-22 08:40:51.014755
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:40:58.145300
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:41:07.588367
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TudouPlaylistIE is a subclass of InfoExtractor
    assert issubclass(TudouPlaylistIE, InfoExtractor)
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    # _real_extract returns a Playlist
    result = ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['_type'] == 'playlist'

# Generated at 2022-06-22 08:41:11.246212
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Validate that no exception is thrown when constructing an instance of
    # class TudouAlbumIE.
    TudouAlbumIE(None)


# Generated at 2022-06-22 08:41:17.822380
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    expected_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_id = 'v5qckFJvNJg'
    expected_min_count = 45
    c = TudouAlbumIE(expected_url)
    assert c._TESTS[0][0] == expected_url
    assert c._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert c._TESTS[0]['info_dict']['id'] == expected_id
    assert c._TESTS[0]['playlist_mincount'] == expected_min_count


# Generated at 2022-06-22 08:41:25.899137
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """ Unit test for constructor of class TudouAlbumIE"""
    
    k_playlist_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    instance = TudouAlbumIE()
    
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == 'tudou:album'
    assert instance._VALID_URL == k_playlist_url


# Generated at 2022-06-22 08:41:30.409245
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE
    obj = constructor('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(obj.ie_key == 'Tudou:album')

# Generated at 2022-06-22 08:41:34.263049
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE(InfoExtractor())
    print(obj._real_extract(url))


# Generated at 2022-06-22 08:41:41.038586
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._match_id(url) == 'zzdE77v6Mmo'
    TudouPlaylistIE._real_initialize()
    TudouPlaylistIE._real_extract(url)



# Generated at 2022-06-22 08:41:42.817383
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(InfoExtractor)
    assert True


# Generated at 2022-06-22 08:41:44.176389
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:41:58.234876
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/rI_7VQ2nxuw.html'
    # Test the constructor of class TudouAlbumIE
    TudouAlbumIE(url)

# Generated at 2022-06-22 08:42:09.186072
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_common import (
        FakeHttpServer, assertIsPlaylist, assertRegex, assertEqual)
    from .test_tudou import (make_tudou_album_json, tudou_album_json_content)
    from . import tudou

    def request_handler(h):
        h.send_response(200)
        h.send_header('Content-Type', 'application/json')
        h.end_headers()
        h.wfile.write(tudou_album_json_content.encode('utf-8'))

    with FakeHttpServer(request_handler) as httpd:
        server_url = 'http://%s:%d/' % (httpd.server_name, httpd.server_port)
        tudou_album_json = make_tudou

# Generated at 2022-06-22 08:42:20.154360
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/RMq3Y2lFR1Q.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    ie2 = TudouPlaylistIE('http://www.tudou.com/albumplay/qL2QdEn4H4s.html')
    assert ie2.IE_NAME == 'tudou:album'
    assert ie2._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:42:26.090992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	
	print ("Unit test for constructor of class TudouPlaylistIE")

	# Test URL by parsing the listplay
	TanyaTudouExtractor = TudouPlaylistIE("Test")
	result1 = TanyaTudouExtractor.url_result("http://www.tudou.com/albumcover/9C5c8L-yVd0.html", "Test")
	print("Test for URL: http://www.tudou.com/albumcover/9C5c8L-yVd0.html")	

# Generated at 2022-06-22 08:42:31.650540
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    for i in range(0, 20):
        url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        tudou_playlist = TudouPlaylistIE(i)
        assert tudou_playlist._match_id(url)
        assert tudou_playlist._VALID_URL
        assert tudou_playlist._TESTS
        assert tudou_playlist._real_extract(url)


# Generated at 2022-06-22 08:42:38.953822
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .TudouPlaylistIE import TudouPlaylistIE
    url_list=['http://www.tudou.com/listplay/zzdE77v6Mmo.html']
    url_list_correct=['zzdE77v6Mmo']
    test_result=True
    for i in range(0,len(url_list)):
        test_result=test_result and (url_lis[i]==TudouPlaylistIE._VALID_URL)

# Generated at 2022-06-22 08:42:50.449972
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test 'https://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-22 08:42:54.812013
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor = []
    constructor.append(TudouPlaylistIE)
    constructor.append(TudouAlbumIE)
    for class_object in constructor:
        instance = class_object([])
        assert instance.IE_NAME

# Generated at 2022-06-22 08:43:00.480541
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:43:10.147284
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'Tudou'
    assert ie.ie_name() == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.extract('https://www.tudou.com/listplay/zzdE77v6Mmo.html') == {'url': 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'playlist': 'zzdE77v6Mmo'}


# Generated at 2022-06-22 08:43:43.131100
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t.IE_DESC == '土豆网视频列表'


# Generated at 2022-06-22 08:43:49.062354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/F1Q2NkHfAOo.html')
    assert TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:43:54.713576
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert obj.playlist_mincount == 209


# Generated at 2022-06-22 08:44:06.931293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:44:09.260186
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# test constructor of class TudouPlaylistIE
	TudouPlaylistIE = TudouPlaylistIE(TudouPlaylistIE)


# Generated at 2022-06-22 08:44:11.222684
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 1 == 1, "One is equal one"
    #pass
    #print(self.get_id)


# Generated at 2022-06-22 08:44:20.709825
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    assert_equal(tudou.IE_NAME, 'tudou:album')
    assert_equal(tudou._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-22 08:44:27.018052
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert 'www.tudou.com/albumplay/v5qckFJvNJg.html' in ie.valid_urls('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert 'www.tudou.com/albumcover/v5qckFJvNJg.html' in ie.valid_urls('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:44:34.766666
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:44:37.185017
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE.IE_NAME)



# Generated at 2022-06-22 08:45:48.496170
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE()._TESTS == TudouPlaylistIE._TESTS


# Generated at 2022-06-22 08:45:58.732019
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Arrange
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	video_result = {
		'url': 'http://www.tudou.com/programs/view/zzdE77v6Mmo/',
		'id': 'zzdE77v6Mmo',
		'uploader': None,
		'title': 'zzdE77v6Mmo',
		'ext': 'flv',
		'categories': [],
		'tags': [],
	}
	
	# Act
	actual = TudouPlaylistIE()._real_extract(url=url)
	
	# Assert
	assert actual == video_result


# Generated at 2022-06-22 08:46:01.424470
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE('album');
	assert album.IE_NAME == "tudou:album"

# Generated at 2022-06-22 08:46:06.650821
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1


# Generated at 2022-06-22 08:46:13.674368
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    tudouAlbumIE = TudouAlbumIE()
    print(tudouAlbumIE.TEST_PLAYLIST_MIN_MATCHES)
    tudouAlbumIE.playlist_mincount = 1
    assert tudouAlbumIE.playlist_mincount == 1
    assert tudouAlbumIE.playlist_result(entries = None, name = None) == None
    assert tudouAlbumIE._real_extract(url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html") == None


# Generated at 2022-06-22 08:46:16.632667
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL[0] == 'h'
    assert TudouAlbumIE().IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:46:18.042972
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert 'tudou:playlist' == TudouPlaylistIE._VALID_URL

# Generated at 2022-06-22 08:46:20.976029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouAlbumIE
    instance = TudouAlbumIE.TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert instan

# Generated at 2022-06-22 08:46:23.115127
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:46:26.850094
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    Lcode = 'zzdE77v6Mmo'
    url = 'http://www.tudou.com/listplay/'+Lcode+'.html'
    tudou = TudouPlaylistIE()
    tudou.extract(url)


# Generated at 2022-06-22 08:48:54.148893
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)

# Generated at 2022-06-22 08:48:57.956134
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tp = TudouPlaylistIE()
    assert tp._match_id(url) == "zzdE77v6Mmo"


# Generated at 2022-06-22 08:49:03.556750
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-22 08:49:07.693077
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    ies = InfoExtractor._create_ies(
        url = u'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        ie = u'tudou:album',
        test = True
    )
    assert isinstance(ies[0], TudouAlbumIE)



# Generated at 2022-06-22 08:49:15.190579
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(tudou_playlist.wurl == 
           'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')
    assert(tudou_playlist.ie_key == 'zzdE77v6Mmo')
    assert(tudou_playlist.video_count == 209)
