

# Generated at 2022-06-22 08:39:20.197101
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudopl_playlistIE = TudouPlaylistIE()
    # test function _real_extract with playlist_id
    playlist_id = 'zzdE77v6Mmo'
    assert tudopl_playlistIE._real_extract(tudopl_playlistIE._VALID_URL)['id'] == playlist_id


# Generated at 2022-06-22 08:39:21.142354
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:39:22.053879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(not TudouAlbumIE(None))

# Generated at 2022-06-22 08:39:25.403705
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_ie = TudouAlbumIE()
    #assert (
    #    tudou_ie.IE_NAME == 'tudou:album'
    #)


# Generated at 2022-06-22 08:39:28.766124
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td_album_ie = TudouAlbumIE()
    td_album_ie.extract()
    assert td_album_ie.ie_key() == 'Tudou'
    assert td_album_ie.ie_name() == 'tudou:album'


# Generated at 2022-06-22 08:39:31.384637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert isinstance(TudouPlaylistIE(url), InfoExtractor)


# Generated at 2022-06-22 08:39:37.311582
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:39:39.149489
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Test extraction
    ie.extract(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:39:40.012879
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:46.673496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE('test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test')
    assert tudouPlaylistIE
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:39:51.493738
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    obj.IE_NAME
    print('test over')


# Generated at 2022-06-22 08:39:58.544602
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    from .tudou import TudouPlaylistIE

    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    output = TudouPlaylistIE().extract(url)

    #Assert that the get_real_extract function returns a non-empty dictionary
    assert output is not None


# Generated at 2022-06-22 08:40:01.364674
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        album = TudouAlbumIE()
    except ArgumentError as e:
        print ("Bad constructor : ") + e.message
    except Exception as ex:
        print ("Unexpected error : ") + ex.message


# Generated at 2022-06-22 08:40:04.001061
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(None).ie_key() == 'TudouAlbum'

# Generated at 2022-06-22 08:40:09.406864
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	exp_id = 'zzdE77v6Mmo'
	exp_params = {
        'id': 'zzdE77v6Mmo',
    }
	exp_playlist_mincount = 209

	test_ie = TudouPlaylistIE()
	test_ie._match_id(test_url)
	test_ie.IE_NAME = 'Tudou:playlist'
	test_ie._download_json(test_url, exp_id)
	test_ie._real_extract(test_url)
	test_ie.playlist_result(test_id, exp_playlist_mincount)
	

# Generated at 2022-06-22 08:40:11.573956
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass
	

# Generated at 2022-06-22 08:40:15.826856
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.name == 'tudou:album'
    assert ie.ie_key() == 'Tudou:album'



# Generated at 2022-06-22 08:40:26.885972
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE._build_url_result("https://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert result == "https://www.tudou.com/albumplay/v5qckFJvNJg.html"
    result = TudouAlbumIE._build_url_result("https://www.tudou.com/albumplay/v5qckFJvNJg.html", 0)
    assert result == "https://www.tudou.com/albumplay/v5qckFJvNJg.html"
    result = TudouAlbumIE._build_url_result("https://www.tudou.com/albumplay/v5qckFJvNJg.html", 1)
    assert result == None
    result = Tud

# Generated at 2022-06-22 08:40:34.577356
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE(
        'Tudou',
        'http://www.tudou.com/tvp/plist.action?lcode=vvgxC6TbX9Y',
        'vvgxC6TbX9Y')
    i.login()
    a = i._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:40:40.613182
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.ie_key() == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-22 08:40:53.241435
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    assert(TudouPlaylistIE._match_id(TudouPlaylistIE._VALID_URL, url) == playlist_id)
    assert(TudouPlaylistIE._match_id(TudouPlaylistIE._VALID_URL, url.replace('listplay/', 'listplay/m/')) == playlist_id)



# Generated at 2022-06-22 08:41:00.886498
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert TudouPlaylistIE(TudouPlaylistIE._create_getinfo()).suitable(url)
	assert TudouPlaylistIE(TudouPlaylistIE._create_getinfo()).extract_urls(url) == [u'http://www.tudou.com/listplay/zzdE77v6Mmo.html']


# Generated at 2022-06-22 08:41:01.925254
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()


# Generated at 2022-06-22 08:41:03.393565
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE().IE_NAME == 'tudou:playlist')

# Generated at 2022-06-22 08:41:07.224028
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    Album = TudouAlbumIE
    Album('https://www.tudou.com/albumcover/v5qckFJvNJg.html', None)
    Album('https://www.tudou.com/albumplay/v5qckFJvNJg.html', None)

# Generated at 2022-06-22 08:41:10.300840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	extractor = TudouAlbumIE()

# Generated at 2022-06-22 08:41:19.918950
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-22 08:41:20.619358
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-22 08:41:21.958898
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check the constructor
    assert(TudouPlaylistIE(None))

# Generated at 2022-06-22 08:41:29.297007
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    inst = TudouPlaylistIE()
    assert inst.name == 'tudou:playlist'
    assert inst.IE_NAME == 'tudou:playlist'
    assert inst.IE_DESC == 'tudou.com playlists'
    assert inst._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert inst.private == True
    assert inst.age_limit == 0
    assert inst.webpage_url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert inst.webpage_id == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:41:47.940774
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # object creation
    tudou_album_object = TudouAlbumIE(None)

    # validate object properties
    assert(tudou_album_object.ie_key() == "TudouAlbum")

    # validate method ie_key()
    assert(tudou_album_object.ie_key() == "TudouAlbum")

    # validate method _real_extract()
    # TODO wait for an online video
    assert(1 == 1)

    # validation passed
    print("*** Validation passed for class TudouAlbumIE.")



# Generated at 2022-06-22 08:41:55.875374
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    url_id = ie._match_id(url)
    assert url_id == "zzdE77v6Mmo"
    playlist_data = ie._download_json("http://www.tudou.com/tvp/plist.action?lcode=" + url_id, url_id)
    
    assert len(playlist_data['items']) == 209


# Generated at 2022-06-22 08:42:08.563869
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test if we can construct class TudouAlbumIE with valid URL
    assert(TudouAlbumIE._VALID_URL)
    t=TudouAlbumIE()

    # Test if we can construct class TudouAlbumIE with valid url for class TudouAlbumIE
    url=TudouAlbumIE._VALID_URL
    # match_id will return id from url
    id=t._match_id(url)
    # make sure match_id returns the same id as in url
    assert(id in url)
    # download_json will download data from url and return json data
    data=t._download_json("http://www.tudou.com/tvp/alist.action?acode="+id,id)
    # make sure we can get json data
    assert(data)

# Generated at 2022-06-22 08:42:20.426215
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE_object = TudouPlaylistIE()
    assert test_TudouPlaylistIE_object.IE_NAME == "tudou:playlist"
    assert test_TudouPlaylistIE_object._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_TudouPlaylistIE_object._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:42:26.263668
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_tudou_albumie = TudouAlbumIE()
    # test the constructor of TudouAlbumIE
    assert_equal(test_tudou_albumie.IE_NAME, 'tudou:album')
    assert_equal(test_tudou_albumie._VALID_URL, 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-22 08:42:27.454089
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    print(instance.IE_NAME)

# Generated at 2022-06-22 08:42:30.044041
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test._detect_ie('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'TudouPlaylist'


# Generated at 2022-06-22 08:42:34.765068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test creating object "IE"
    assert isinstance(TudouPlaylistIE, (InfoExtractor))


# Generated at 2022-06-22 08:42:36.521675
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudoualbumIE = TudouAlbumIE()

# Generated at 2022-06-22 08:42:45.537777
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Construct a instance of TudouPlaylistIE
    ie = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # Test the '_real_extract' method of TudouPlaylistIE
    ie._real_extract()
    # Test the '_real_extract' method of TudouAlbumIE
    ie = TudouAlbumIE(url='http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    ie._real_extract()


# Generated at 2022-06-22 08:43:10.010727
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    return

# Generated at 2022-06-22 08:43:16.277080
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album_ie != None, "Test1: Fail to instantiate class TudouAlbumIE"
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert tudou_album_ie != None, "Test2: Fail to instantiate class TudouAlbumIE"


# Generated at 2022-06-22 08:43:20.038934
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """ constructor test of TudouAlbumIE """
    ie = TudouAlbumIE()
    if ie is None:
        raise AssertionError("TudouAlbumIE constructor returns None")


# Generated at 2022-06-22 08:43:22.738938
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import test_infoextractor
    test_infoextractor('tudou:playlist','http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:43:29.077570
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.IE_NAME == 'tudou:album'



# Generated at 2022-06-22 08:43:30.478575
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(None) is None


# Generated at 2022-06-22 08:43:34.273390
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    play_list_ID = "zzdE77v6Mmo"
    url = a._TESTS[0]['url']
    a._real_extract(url)

# Generated at 2022-06-22 08:43:38.950403
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert (ie.IE_NAME == 'tudou:playlist')
    assert (ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    # Test for constructor of class InfoExtractor
    assert (isinstance(ie, InfoExtractor))


# Generated at 2022-06-22 08:43:42.834941
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/' + id + '.html'
    TudouAlbumIE(None)._real_extract(url)

# Generated at 2022-06-22 08:43:51.624830
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    album_id = 'v5qckFJvNJg'
    album_data = ie._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [ie.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]
    playlist = ie.playlist_result(entries, album_id)

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-22 08:44:47.077895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:44:48.032087
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()

# Generated at 2022-06-22 08:44:51.350747
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    my_info_extractor = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    return my_info_extractor.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:44:53.748458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if isinstance(TudouAlbumIE, object):
        test = TudouAlbumIE
    else:
        test = TudouAlbumIE()
    assert( test != None )
    return


# Generated at 2022-06-22 08:44:54.888669
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('', None)


# Generated at 2022-06-22 08:44:56.018402
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE)

# Generated at 2022-06-22 08:44:59.053064
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-22 08:45:02.728733
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Call constructor
    d = TudouAlbumIE(InfoExtractor)

    # Check if the super was properly initialized
    assert d.ie_key() == 'Tudou:album'



# Generated at 2022-06-22 08:45:07.478640
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test = TudouPlaylistIE()
    tester = test._real_extract(url)
    assert tester['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:45:11.734968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbum_ie = TudouAlbumIE()
    tudouAlbum_ie._real_extract(url)

test_TudouAlbumIE()

# Generated at 2022-06-22 08:47:26.808198
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	Test = TudouAlbumIE
	print('\nTesting constructor of class TudouAlbumIE')
	TUDOU_ALBUM_TEST = Test(Test._downloader)
	TUDOU_ALBUM_TEST._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	TUDOU_ALBUM_TEST._download_json('http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg')


# Generated at 2022-06-22 08:47:37.426779
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
   assert len(TudouPlaylistIE._TESTS) == 1
   url = TudouPlaylistIE._TESTS[0]["url"]
   print(url)
   playlist_id = TudouPlaylistIE._match_id(url)
   print(playlist_id)
   print(TudouPlaylistIE._TESTS[0])

   listplay_url = 'http://www.tudou.com/tvp/plist.action?lcode=' + playlist_id
   print(listplay_url)
   playlist_data = TudouPlaylistIE._download_json(listplay_url, playlist_id)
   #entries = []
   #for item in playlist_data['items']:
   #   entries.append(TudouPlaylistIE.url_result(
   #      'http://

# Generated at 2022-06-22 08:47:38.791369
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = TudouPlaylistIE()
    
import unittest

# Generated at 2022-06-22 08:47:42.902998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    


# Generated at 2022-06-22 08:47:50.583545
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = "album_id_name"
    url_string = "http://www.tudou.com/albumplay/%s.html" % album_id
    album_data = [{
        "icode": "ICODE",
        "kw": "KW"
    }]
    tudou_album_ie = TudouAlbumIE(url_string, album_id)
    tudou_album_ie._download_json = lambda a, b: album_data
    playlist_result = tudou_album_ie._real_extract(url_string)

    assert playlist_result["_type"] == "playlist"
    assert playlist_result["id"] == album_id
    assert playlist_result["entries"][0]["_type"] == "url"

# Generated at 2022-06-22 08:47:55.948874
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE(None)

    assert obj.IE_NAME == 'tudou:album'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert obj._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-22 08:48:07.224497
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test with a valid url
    item = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert item._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert item.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html') != []
    assert item.extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html') != []
    assert item.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')[0]['id']

# Generated at 2022-06-22 08:48:17.043048
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    import json

    params = {
        'lcode': 'zzdE77v6Mmo',
    }

    from .common import HEADERS
    from .common import HEADERS_FORM

    from .common import HEADERS_SPOOF
    from .common import HEADERS_FORM_SPOOF
    from .common import HEADERS_JSON
    from .common import HEADERS_JSON_SPOOF

    # import requests
    import urllib

    # cookies = dict(
    #     tudouAuth='edb2862a542cc04460440d2c919a9f6c%7C%7C2016-06-26+23%3A28%3A49%7C%7C9a6ad16c7deec92c8e36fc1690ec6da5c6beb0c8',

# Generated at 2022-06-22 08:48:26.301172
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE()
    assert test_obj.IE_NAME == 'tudou:playlist'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_obj._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-22 08:48:28.757493
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playListUrl = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url2 = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
    playlist_id = TudouPlaylistIE._match_id(playListUrl)
    playlist_id2 = TudouPlaylistIE._match_id(url2)
    assert playlist_id == playlist_id2 == 'zzdE77v6Mmo'
