

# Generated at 2022-06-22 08:39:25.680842
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/8GvnZnSSQ7Q.html'
    tudouAlbumIE = TudouAlbumIE(url)
    assert str(TudouAlbumIE.__class__) == "<class 'tudou.tudouIE.TudouAlbumIE'>"
    assert len(tudouAlbumIE._TESTS) == 1
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._real_extract(url) is not None

# Generated at 2022-06-22 08:39:27.322634
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from .TudouPlaylistIE import TudouPlaylistIE
	TudouPlaylistIE()


# Generated at 2022-06-22 08:39:28.562726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE({})


# Generated at 2022-06-22 08:39:30.472270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE == 'tudou:album'

# Unit test of method extract in class TudouAlbumIE

# Generated at 2022-06-22 08:39:31.000436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert True

# Generated at 2022-06-22 08:39:34.722341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_plist_ie = TudouPlaylistIE()
    assert tudou_plist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_plist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:39:35.380419
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:39:36.786806
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist_ie = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:39.696644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    t._match_id('http://www.tudou.com/listplay/y9r-cvyv_fw.html')


# Generated at 2022-06-22 08:39:42.402428
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		tudou_album_ie = TudouAlbumIE()
		assert False
	except:
		assert True

# Generated at 2022-06-22 08:39:48.311284
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Construct smart playlists and test if it is working"""
    # Test smart playlist in tudou and get items from it
    smartlist = TudouPlaylistIE.smart_list(u'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    smartlist.extract()
    items = smartlist.items
    assert len(items) == 209, 'There should be 209 items in this smart playlist'

# Generated at 2022-06-22 08:39:54.230808
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test import tudou_playlist_config, tudou_playlist_result
    try:
        b = TudouPlaylistIE()
        assert b._VALID_URL == tudou_playlist_config['_VALID_URL']
        assert b.IE_NAME == tudou_playlist_config['IE_NAME']
        assert b._TESTS == tudou_playlist_config['_TESTS']
        assert b._real_extract == tudou_playlist_result['_real_extract']
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-22 08:39:59.610912
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	extractor = TudouPlaylistIE(url)
	assert extractor._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert extractor.playlist_mincount == 209


# Generated at 2022-06-22 08:40:01.251831
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.ie_key() == 'tudou:playlist'


# Generated at 2022-06-22 08:40:08.687270
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor()
    print(ie)
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert len(ie._TESTS[0]['info_dict']) == 1
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:40:11.630728
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(isinstance(TudouPlaylistIE(),InfoExtractor))

# Generated at 2022-06-22 08:40:23.161768
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    test_instance = TudouPlaylistIE()
    assert test_instance.NAME == "tudou:playlist"
    assert test_instance.VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_instance.TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:40:27.201858
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouAlbumIE')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:40:31.054268
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # pylint: disable=line-too-long
    TudouAlbumIE(InfoExtractor())._real_extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-22 08:40:32.506576
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-22 08:40:41.089365
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('udou.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-22 08:40:50.831766
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Get the album id
    album_id = 'v5qckFJvNJg'
    # Download the json
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s'%album_id
    # Get the list of items in the album
    items = album_data['items']
    entries = [self.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]
    # Return the list of entries in the album
    return playlist_

# Generated at 2022-06-22 08:40:54.365120
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE(url)
    assert tudou_playlist.ie_key() == 'TudouPlaylist'
    

# Generated at 2022-06-22 08:41:05.794553
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    tudouplaylist.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouplaylist.playlist_id = 'zzdE77v6Mmo'
    tudouplaylist.playlist_data = tudouplaylist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % tudouplaylist.playlist_id, tudouplaylist.playlist_id)

# Generated at 2022-06-22 08:41:08.631178
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:41:11.689222
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE(url).url == url

# Generated at 2022-06-22 08:41:19.366662
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE.TEST = True
    TudouPlaylistIE.__init__(TudouPlaylistIE, url)
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:41:28.221127
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import expectedFailure
    from .common import urlopen
    from .common import urlretrieve

    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.playlist_id == 'zzdE77v6Mmo'
    assert ie.playlist_data == ''
    assert ie.playlist_data_json == ''
    assert ie.playlist_title == ''
    assert ie.playlist_description == ''
    assert ie.playlist_thumbnail == ''
    assert ie.url == url
    assert ie.domain == 'www.tudou.com'
    assert ie.protocol == 'http'
    
    ie.download_playlist()

# Generated at 2022-06-22 08:41:32.711352
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_class = TudouAlbumIE(url, None)
    assert test_class._VALID_URL == url
    assert test_class._TESTS == []

# Generated at 2022-06-22 08:41:37.674538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    construct = TudouPlaylistIE()
    assert construct._match_id(url) == "zzdE77v6Mmo"

# Generated at 2022-06-22 08:41:50.952462
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('tudou:playlist',True)
    return


# Generated at 2022-06-22 08:41:53.745104
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    sp = TudouPlaylistIE()
    if sp.IE_NAME != 'tudou:playlist':
        print("constructor of class TudouPlaylistIE error")



# Generated at 2022-06-22 08:41:57.998934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert_raises(ValueError, TudouPlaylistIE, None, {}, {}, {})
    assert_raises(ValueError, TudouPlaylistIE, None, {}, {}, {})
    assert_raises(ValueError, TudouPlaylistIE, None, {}, {}, {})


# Generated at 2022-06-22 08:42:00.024597
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from re import compile
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    return TudouAlbumIE

# Generated at 2022-06-22 08:42:02.883500
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case for constructor of class TudouPlaylistIE
    obj = TudouPlaylistIE()
    assert(obj.IE_NAME is not None)
    assert(obj.IE_NAME == 'tudou:playlist')



# Generated at 2022-06-22 08:42:04.798381
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE({
        "url": "http://www.tudou.com/listplay/zzdE77v6Mmo.html",
    })
    assert info.url == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"


# Generated at 2022-06-22 08:42:06.904317
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	a = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-22 08:42:14.765668
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0] == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}


# Generated at 2022-06-22 08:42:25.252845
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:42:32.553747
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test = TudouAlbumIE()
	assert test.IE_NAME == 'Tudou:album'
	assert test._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert test._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:42:59.627575
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print('Unit test for constructor of class  TudouPlaylistIE')
	print('-----------------------------------------')
	tudou_playlist_ie = TudouPlaylistIE()
	print('url: %s, IE_NAME: %s' %(tudou_playlist_ie._VALID_URL, tudou_playlist_ie.IE_NAME))


if __name__ == '__main__':
	test_TudouPlaylistIE()

# Generated at 2022-06-22 08:43:06.462065
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("\nTest TudouAlbumIE...")
    tudouAlbum = TudouAlbumIE()
    assert tudouAlbum._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbum.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:43:11.883906
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    unit test for constructor of class TudouAlbumIE
    """
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

    # assert_equal
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:43:23.720779
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test 1
    test1 = TudouPlaylistIE()
    test1.sanity_check = lambda *args, **kwargs: True
    mp4_url = test1._extract_via_playlist(
        'http://www.tudou.com/playlist/p/l1422082.html')
    assert mp4_url == 'http://g3.tdimg.com/599/099/085/i/0.mp4'
    mp4_url = test1._extract_via_playlist(
        'http://www.tudou.com/plcover/gX5B-MBPBhg/-')
    assert mp4_url == 'http://g3.tdimg.com/599/099/085/i/0.mp4'
    mp4_url = test1

# Generated at 2022-06-22 08:43:33.824454
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, (InfoExtractor, TudouPlaylistIE))
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.test_cases == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]



# Generated at 2022-06-22 08:43:35.371476
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE("ttt", "ttt", "ttt", "ttt")
    assert instance

# Generated at 2022-06-22 08:43:41.305422
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    try:
        e.extract(url)
    except Exception as e:
        print("Exception occured {}".format(e))
        assert False, "extract for album should not raise exception"


# Generated at 2022-06-22 08:43:45.074766
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert obj.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:43:47.119960
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    anAlbum = TudouAlbumIE()
    assert anAlbum != None


# Generated at 2022-06-22 08:43:55.562313
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                                       'info_dict': {'id': 'zzdE77v6Mmo'},
                                       'playlist_mincount': 209}]


# Generated at 2022-06-22 08:44:53.218612
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.IE_NAME == "tudou:playlist"
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:44:55.803511
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert obj.IE_NAME == 'Tudou:album'

# Generated at 2022-06-22 08:44:56.763243
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()



# Generated at 2022-06-22 08:45:04.499677
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]

# Generated at 2022-06-22 08:45:05.890833
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:45:08.100507
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_test = TudouAlbumIE()
    assert tudou_test.IE_NAME == "tudou:album"


# Generated at 2022-06-22 08:45:10.709184
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html").IE_NAME == "TudouPlaylistIE"

# Generated at 2022-06-22 08:45:14.570073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/%s.html' % playlist_id
    playlist_ie = TudouPlaylistIE()
    assert playlist_ie.suitable(playlist_url) == True


# Generated at 2022-06-22 08:45:16.319358
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE(None)
    assert tudouPlaylistIE is not None


# Generated at 2022-06-22 08:45:18.827302
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:47:27.429140
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(TudouPlaylistIE._VALID_URL, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'tudou:playlist')
    print(ie)


# Generated at 2022-06-22 08:47:31.159874
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TD = TudouPlaylistIE()
    a = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    b = TD._match_id(a)

# Generated at 2022-06-22 08:47:32.287827
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'tudou:playlist' in globals().keys()


# Generated at 2022-06-22 08:47:38.287058
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('test_TudouAlbumIE')
    tudouAlbumIE = TudouAlbumIE()
    assert 'www.tudou.com/albumplay/' in tudouAlbumIE._VALID_URL
    assert tudouAlbumIE._TESTS[0]['url'] is not None
    assert tudouAlbumIE._TESTS[0]['info_dict']['id'] is not None
    assert tudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    if True:
        print('test_TudouAlbumIE success!\n')


# Generated at 2022-06-22 08:47:40.386359
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True


# Generated at 2022-06-22 08:47:44.605195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE();
    assert(obj.IE_NAME.encode('utf8') == "tudou:playlist")
    assert(obj._VALID_URL.encode('utf8') == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-22 08:47:51.536283
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    entries = [classmethod()(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return classmethod()(entries, album_id)

# Generated at 2022-06-22 08:47:52.537051
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    assert x != None


# Generated at 2022-06-22 08:48:03.616332
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-22 08:48:06.781647
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instances = [TudouPlaylistIE(1), TudouAlbumIE(1)]
    for instance in instances:
        assert isinstance(instance, InfoExtractor)
