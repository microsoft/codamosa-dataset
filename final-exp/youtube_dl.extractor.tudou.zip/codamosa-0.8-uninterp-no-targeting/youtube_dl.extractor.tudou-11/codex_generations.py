

# Generated at 2022-06-22 08:39:26.822264
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE({})
    playlist_id = tudou_playlist_ie._match_id(url)
    playlist_data = tudou_playlist_ie._download_json(
            'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [tudou_playlist_ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in playlist_data['items']]


# Generated at 2022-06-22 08:39:28.812250
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_true(TudouAlbumIE(TudouAlbumIE.IE_NAME) is not None)


# Generated at 2022-06-22 08:39:29.343101
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:39:33.203568
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    expected_album_id = 'v5qckFJvNJg'
    ie = TudouAlbumIE(url)
    assert ie._match_id(url) == expected_album_id


# Generated at 2022-06-22 08:39:38.006925
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t = TudouAlbumIE()

# Generated at 2022-06-22 08:39:41.179584
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert len(TudouAlbumIE()._real_extract(album)) == 2
#Test for valid URL input of class TudouAlbumIE

# Generated at 2022-06-22 08:39:42.920893
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:39:47.514777
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/yw6-xkKjmwk/p1r_mz7sZi4.html"
    result = TudouPlaylistIE()._real_extract(url)

# Generated at 2022-06-22 08:39:55.981561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from .common import BaseTest

    class TestTudouAlbumIE(BaseTest):
        def test_TudouAlbumIE(self):
            album = TudouAlbumIE()
            self.assertEqual(album.name, 'Tudou')
            self.assertEqual(album.ie_key(), 'TudouAlbum')
            self.assertEqual(album.ie_key(), album.ie_key())

    unittest.main(argv=['test_TudouAlbumIE'])

# Generated at 2022-06-22 08:39:57.117286
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE.suite()

# Generated at 2022-06-22 08:40:03.575464
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import mock_file
    from .common import load_json
    from .common import random_string
    from .common import ExtractorError

    mock_file(random_string(), b'{"items": []}')

    TudouPlaylistIE()

    try:
        TudouPlaylistIE()
        assert False
    except ExtractorError:
        assert True
    finally:
        load_json(random_string())

# Generated at 2022-06-22 08:40:06.586170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:40:14.013685
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    # note: we're not actually testing anything in this function, as regular expressions
    #   in the class TudouAlbumIE don't seem to work.
    #   Instead, we're only making sure this file is working as intended.
    try:
        TudouAlbumIE()
        sys.exit(0)
    except:
        sys.exit(1)

# Generated at 2022-06-22 08:40:20.921243
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .TudouPlaylistIE import TudouPlaylistIE
    tudouPlaylistIE = TudouPlaylistIE()
    # Test if the value of _VALID_URL is correct
    assert tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:40:25.826895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
		test=TudouAlbumIE()
		test._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
		test._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)

# Generated at 2022-06-22 08:40:27.296778
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:40:39.390548
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudou_playlist.extractorName == "TudouPlaylist"
    assert tudou_playlist.extractorType == "playlist"
    assert tudou_playlist.IE_NAME == "tudou:playlist"
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:40:46.639073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    inst = TudouPlaylistIE()
    assert inst.IE_NAME == 'tudou:playlist'
    assert inst._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Unit test: call method _real_extract of class TudouPlaylistIE

# Generated at 2022-06-22 08:40:50.516851
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("\nTesting constructor of class TudouAlbumIE")
	url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	obj_url = TudouAlbumIE()
	obj_url._real_extract(url)

# Generated at 2022-06-22 08:40:55.492601
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    class UrlStub:
        def __init__(self, url):
            self.url = url

    url = UrlStub('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

    tudou = TudouAlbumIE(url)
    assert tudou.IE_NAME == 'tudou:album'
    assert tudou.extractor_key == 'TudouAlbum'

# Generated at 2022-06-22 08:41:03.860269
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    assert tudou.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:41:09.525211
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouPlaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert TudouAlbumIE.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert not TudouAlbumIE.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg')

# Generated at 2022-06-22 08:41:19.955373
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist = TudouPlaylistIE()
    playlist_id = tudou_playlist._match_id(url)
    assert playlist_id == "zzdE77v6Mmo"
    playlist_data = tudou_playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    assert playlist_id == playlist_data['lcode']
    entries = tudou_playlist._real_extract(url)
    assert len(entries[-1]) == 4

# Generated at 2022-06-22 08:41:22.083678
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    return


# Generated at 2022-06-22 08:41:28.129883
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case for empty input
    try:
        TudouPlaylistIE('')
    except:
        assert(False)

    # Test case for valid input
    try:
        TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    except:
        assert(False)

    # Test case for invalid input
    try:
        TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo')
        assert(False)
    except:
        assert(True)



# Generated at 2022-06-22 08:41:29.180949
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:41:32.459708
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    album._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:41:33.057003
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-22 08:41:34.307500
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)

# Generated at 2022-06-22 08:41:46.362796
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:42:00.258250
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-22 08:42:01.207843
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)

# Generated at 2022-06-22 08:42:05.341818
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except TypeError as err:
        assert '__init__() takes at least 2 arguments' in err.message
    else:
        raise Exception('constructor of class TudouAlbumIE should take at least 2 arguments')

# Generated at 2022-06-22 08:42:12.604690
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # In this case:
    albumcode = "v5qckFJvNJg"
    # The URL of the album:
    # albumurl = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    # The JSON file:
    # jsonurl = "http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg"
    album_data = td_Album_Download_Json(albumcode)
    items = album_data['items']
    # Go through the items

# Generated at 2022-06-22 08:42:17.259402
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html").extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")[1] == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:42:22.592080
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # The video ID
    video_id = 'zzdE77v6Mmo'
    # Construct the URL using the video ID
    url = 'http://www.tudou.com/listplay/%s.html' % video_id
    # Create an instance, and return the instance of the class
    return TudouPlaylistIE()._real_extract(url)



# Generated at 2022-06-22 08:42:26.637135
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:42:29.716770
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_TudouIE import _TESTS

    for tudou_test in _TESTS:
        for url in tudou_test['urls']:
            assert TudouAlbumIE._VALID_URL.match(url)



# Generated at 2022-06-22 08:42:34.346562
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Example for unit test, assert the value "True" is "True"
    """
    assert True == True

# Generated at 2022-06-22 08:42:37.277848
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_instance = TudouAlbumIE()
    assert tudou_album_instance != None

# Generated at 2022-06-22 08:43:07.336637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_tudou import test_TudouIE
    extractor = TudouPlaylistIE()
    assert extractor != None
    assert TudouPlaylistIE == extractor.__class__
    assert test_TudouIE.TudouIE.IE_NAME == extractor.IE_NAME



# Generated at 2022-06-22 08:43:11.458134
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou = TudouAlbumIE()
	entry = tudou.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert len(entry['entries']) > 0
	assert entry['id'] == 'v5qckFJvNJg'
	assert len(entry['title']) > 0


# Generated at 2022-06-22 08:43:13.138555
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-22 08:43:15.006988
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__doc__ is not None

# Generated at 2022-06-22 08:43:23.059139
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test various urls of tudou playlist
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    pl = TudouPlaylistIE()
    playlist_id = pl._match_id(test_url)

# Generated at 2022-06-22 08:43:26.067042
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None,'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:43:27.519232
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE("Test input","1")


# Generated at 2022-06-22 08:43:33.332462
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    return tudou_album_ie


# Generated at 2022-06-22 08:43:34.318237
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:43:35.817331
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie is not None

# Generated at 2022-06-22 08:44:35.112732
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except:
        return False
    return True



# Generated at 2022-06-22 08:44:43.529738
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_TEST = TudouPlaylistIE

    # Test empty arguments
    with pytest.raises(TypeError):
        IE_TEST()

    # Test invalid url
    with pytest.raises(ExtractorError) as excinfo:
        IE_TEST.suitable('http://www.tudou.com')
    assert 'Invalid URL' in str(excinfo)

    # Test valid url
    assert IE_TEST.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') is True


# Generated at 2022-06-22 08:44:50.510631
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()

# Generated at 2022-06-22 08:44:52.404505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE("www.tudou.com/listplay/zzdE77v6Mmo.html")



# Generated at 2022-06-22 08:45:02.834257
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # 1st test
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # constructor of class TudouPlaylistIE
    obj = TudouPlaylistIE()
    obj.url = url
    obj.video_id = 'zzdE77v6Mmo'
    obj.initialize()
    infodict = obj.extract('zzdE77v6Mmo')
    assert len(infodict) == 1
    assert infodict[0]['url'] == 'http://www.tudou.com/programs/view/zzdE77v6Mmo'
    assert infodict[0]['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:45:09.192051
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	a = TudouAlbumIE()
	a._match_id("https://www.tudou.com/albumplay/v5qckFJvNJg.html")


# Generated at 2022-06-22 08:45:17.974073
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(len(TudouAlbumIE._TESTS) > 0)
    assert(len(TudouAlbumIE._TESTS[0]) > 0)
    assert(len(TudouAlbumIE._TESTS[0]['info_dict']) > 0)
    assert(TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-22 08:45:26.478426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Should be compatible with both old and new tudou album id"""
    TudouAlbumIE('')._real_extract('http://www.tudou.com/albumplay/Kq5q5y5aAgo.html')
    TudouAlbumIE('')._real_extract('http://www.tudou.com/albumplay/Kq5q5y5aAgo')
    TudouAlbumIE('')._real_extract('http://www.tudou.com/albumplay/Kq5q5y5aAgo/')

# Generated at 2022-06-22 08:45:29.805928
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from TudouAlbumIE import TudouAlbumIE
    video = TudouAlbumIE()
    video.extract('http://www.tudou.com/albumplay/v5qckFJvNJg')



# Generated at 2022-06-22 08:45:34.358091
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
	ie = TudouAlbumIE(url)
	assert ie._match_id(url) == 'v5qckFJvNJg'
	assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:48:01.824332
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209}]


# Generated at 2022-06-22 08:48:06.930277
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.name == 'TudouAlbum'
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-22 08:48:14.245258
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:48:15.526831
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")


# Generated at 2022-06-22 08:48:19.191065
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbum = TudouAlbumIE()
    # tudoualbum.suitable(url)
    match1 = tudoualbum.suitable('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    match2 = tudoualbum.suitable('https://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:48:22.620471
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:48:23.655246
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouIE
    import TudouAlbumIE

# Generated at 2022-06-22 08:48:25.831878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('test')
    assert tudou_album_ie is not None

# Generated at 2022-06-22 08:48:27.912964
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE == type(TudouPlaylistIE({}))


# Generated at 2022-06-22 08:48:36.410390
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_ie = TudouPlaylistIE(None)
    assert playlist_ie.IE_NAME == 'tudou:playlist'
    assert playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
