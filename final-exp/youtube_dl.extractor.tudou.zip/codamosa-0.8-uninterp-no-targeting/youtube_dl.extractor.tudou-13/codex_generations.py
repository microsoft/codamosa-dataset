

# Generated at 2022-06-22 08:39:23.688370
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ''' test for constructor of TudouAlbumIE class
    '''
    assert TudouAlbumIE._VALID_URL is not None
    assert TudouAlbumIE.IE_NAME is not None
    assert TudouAlbumIE.IE_DESC is not None
    assert TudouAlbumIE._TESTS is not None
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._match_id(url) is 'v5qckFJvNJg'
    assert TudouAlbumIE._build_url(TudouAlbumIE._match_id(url)) is url
    assert isinstance(TudouAlbumIE(), InfoExtractor)
    assert TudouAlbumIE._NAME is not None

# Unit test

# Generated at 2022-06-22 08:39:25.554627
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    if not obj:
        raise Exception("TudouAlbumIE instance is None!")

# Generated at 2022-06-22 08:39:26.712770
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test is not None


# Generated at 2022-06-22 08:39:33.885740
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    entry = TudouAlbumIE()
    assert entry.IE_NAME == 'tudou:album'
    assert entry.VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert entry.TESTS == [
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }
    ]



# Generated at 2022-06-22 08:39:38.746344
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg')


# Generated at 2022-06-22 08:39:42.365319
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/spXjKLYlgCE.html")
    TudouAlbumIE("http://www.tudou.com/albumcover/9P6fCJaqcpU.html")

# Generated at 2022-06-22 08:39:47.910115
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    from .tudou import TudouPlaylistIE
    IE = InfoExtractor()
    IE.get_info = lambda url: {'id': 'pgCldp9bUVo'}
    IE.get_video_id = lambda url: 'pgCldp9bUVo'
    IE.get_video_title = lambda url: 'check'
    IE.get_video_info = lambda url: {'id': 'pgCldp9bUVo'}
    IE.get_video_urls = lambda url: {'id': 'pgCldp9bUVo'}
    PLAYLIST = TudouPlaylistIE()
    PLAYLIST._get_video_info = IE.get_video_info
    PLAYLIST._get_video_urls = IE.get_video_url

# Generated at 2022-06-22 08:39:53.085624
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Instantiate your class
    i = TudouPlaylistIE()
    # Grab test data from url
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    webpage = i._download_webpage(url,None)
    # Do they match
    assert webpage.startswith('<!doctype html>')

test_TudouPlaylistIE()

# Generated at 2022-06-22 08:39:57.610548
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._VALID_URL == expected


# Generated at 2022-06-22 08:40:05.219608
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/%s.html' % playlist_id
    playlist_info = {
        'id': playlist_id,
    }
    playlist_apiUrl = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id

    from . import tudou
    self = tudou
    self.tudou_downloader = self
    playlist = self.TudouPlaylistIE(playlist_url)
    assert playlist._VALID_URL == self.TudouPlaylistIE._VALID_URL
    assert playlist._TESTS == self.TudouPlaylistIE._TESTS

# Generated at 2022-06-22 08:40:19.120797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("====test_TudouPlaylistIE====")
	
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	
	tudou = TudouPlaylistIE()
	
	result = tudou._real_extract(url)
	
	print(result)

test_TudouPlaylistIE()

# Generated at 2022-06-22 08:40:28.202190
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    # Assert that the URL is correct
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    #Assert that the output is correct

# Generated at 2022-06-22 08:40:39.571091
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie = TudouPlaylistIE()
	assert tudou_playlist_ie.ie_name == 'tudou:playlist', 'tudou_playlist_ie.ie_name == \'tudou:playlist\''
	assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', 'tudou_playlist_ie._VALID_URL == r\'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html\''

# Generated at 2022-06-22 08:40:44.339740
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.ie_key() == 'TudouAlbum'
    assert t.media_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:40:47.964751
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('Unit test for constructor of class TudouAlbumIE')
    assert TudouAlbumIE._TESTS[0]['url'] == TudouAlbumIE(None)._VALID_URL

# Generated at 2022-06-22 08:40:50.464295
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:41:00.244627
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert_equals(test_TudouPlaylistIE._VALID_URL,  "https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html")
    assert_equals(test_TudouPlaylistIE._TESTS[0]["url"], "http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert_equals(test_TudouPlaylistIE._TESTS[0]["info_dict"]["id"], "zzdE77v6Mmo")
    assert_equals(test_TudouPlaylistIE._TESTS[0]["playlist_mincount"], 209)


# Generated at 2022-06-22 08:41:01.318151
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:41:04.015286
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-22 08:41:05.843598
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert str(TudouPlaylistIE) == 'tudou:playlist'


# Generated at 2022-06-22 08:41:23.430329
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_IE = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    print (tudou_playlist_IE._extract_id(url))


# Generated at 2022-06-22 08:41:33.105598
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tp_ie = TudouPlaylistIE()
    assert tp_ie.name == "tudou:playlist"
    assert tp_ie.IE_NAME == "tudou:playlist"
    assert tp_ie.description == "Youku Tudou Inc."
    assert tp_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tp_ie.IE_DESC == "Youku Tudou Inc."
    assert len(tp_ie.ie_keywords) == 1
    assert 'playlist' in tp_ie.ie_keywords
    assert 'TudouPlaylistIE' in tp_ie.ie_keywords['playlist']


# Generated at 2022-06-22 08:41:38.468371
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:41:46.982561
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    assert ie._match_id(url) == 'zzdE77v6Mmo'
    assert ie._download_json(ie.url_result('http://www.tudou.com/programs/view/zzdE77v6Mmo'),
                             ie._match_id(url)) == ie.url_result('http://www.tudou.com/programs/view/zzdE77v6Mmo')


# Generated at 2022-06-22 08:41:56.229801
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test1 = TudouAlbumIE(None)
    assert test1._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert test1._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:42:03.202394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_tudou_playlist = TudouPlaylistIE()
    assert isinstance(test_tudou_playlist, InfoExtractor)
    assert test_tudou_playlist.IE_NAME == 'tudou:playlist'
    assert test_tudou_playlist._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(test_tudou_playlist._TESTS) == 1
    assert test_tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-22 08:42:11.584948
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    i = TudouPlaylistIE(url)
    assert i.IE_NAME == 'tudou:playlist'
    assert i._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert i._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:42:13.513603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('www.tudou.com', url='http://www.tudou.com/listplay/', id='123456789')


# Generated at 2022-06-22 08:42:15.495574
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE(None)
    assert tudou_album is not None

# Generated at 2022-06-22 08:42:21.832477
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    t.url_result('http://www.tudou.com/programs/view/F91nQfhZljs', 'Tudou','F91nQfhZljs','芭比之秘密王国剧场版')

# Generated at 2022-06-22 08:42:47.184879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE()


# Generated at 2022-06-22 08:42:49.584896
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'v5qckFJvNJg')
    assert ie is not None

# Generated at 2022-06-22 08:42:51.906784
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-22 08:42:53.712642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert (TudouAlbumIE(None) != None)


# Generated at 2022-06-22 08:42:59.659627
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-22 08:43:02.949457
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    assert(tudou.ie_key() == 'Tudou:album')

# Generated at 2022-06-22 08:43:06.301276
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist.info['id'] == 'zzdE77v6Mmo'



# Generated at 2022-06-22 08:43:09.058911
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/bQH9B8Kj-s0.html")
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-22 08:43:10.500883
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME

# Generated at 2022-06-22 08:43:19.566638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # 播放列表1
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()
    result = playlist.extract(url)
    assert len(result['entries']) == 209
    assert 'id' in result
    assert result['id'] == 'zzdE77v6Mmo'
    assert result['title'] is None


# Generated at 2022-06-22 08:43:49.163705
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouplaylistIE = TudouPlaylistIE()
    assert not tudouplaylistIE._real_extract(url) == 0

# Generated at 2022-06-22 08:44:00.014394
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    info_extractor = InfoExtractor() 
    tudou_album_ie.downloader = info_extractor.downloader
    tudou_album_ie.suitable = info_extractor.suitable
    tudou_album_ie.add_info_extractor = info_extractor.add_info_extractor
    tudou_album_ie.add_ie = info_extractor.add_ie
    tudou_album_ie.detect_extractor = info_extractor.detect_extractor 
    tudou_album_ie.ie_key_map = info_extractor.ie_key_map
    tudou_album_ie.gen_extractors = info_extractor.gen_extractors
    t

# Generated at 2022-06-22 08:44:00.913684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()


# Generated at 2022-06-22 08:44:04.818800
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Test: TudouAlbumIE")
    valid_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_album_ie = TudouAlbumIE()
    assert (tudou_album_ie._match_id(valid_url) == "v5qckFJvNJg")

# Generated at 2022-06-22 08:44:08.195258
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert str(TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')) == '<TudouAlbumIE(http://www.tudou.com/albumplay/v5qckFJvNJg.html)>'



# Generated at 2022-06-22 08:44:10.553427
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html').run()

# Generated at 2022-06-22 08:44:19.371898
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ts = TudouAlbumIE()
    assert ts._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ts._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-22 08:44:28.627903
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create an instance
    playlist = TudouPlaylistIE()

    # Check expected cases
    playlist_id = 'fW-Ln-1KCN0'
    playlist_data = playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

    assert(isinstance(playlist_data, dict))
    assert(isinstance(playlist_data['total'], int))
    assert(isinstance(playlist_data['items'], list))
    for item in playlist_data['items']:
        assert(isinstance(item['kw'], unicode))
        assert(isinstance(item['icode'], unicode))

    # Check negative cases
    assert(playlist_data['items'] == [])



# Generated at 2022-06-22 08:44:30.470653
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_ie = TudouPlaylistIE('tudou', 'tudou:playlist')
    assert tudou_ie is not None

# Generated at 2022-06-22 08:44:35.931464
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test create TudouPlaylistIE instance with valid url
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:45:49.548322
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert valid_tudou_playlist is not None


# Generated at 2022-06-22 08:45:52.769481
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Construction test.
    """
    from .TudouAlbumIE import TudouAlbumIE
    TudouAlbumIE()
    return
test_TudouAlbumIE()


# Generated at 2022-06-22 08:45:54.633906
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE()
    assert isinstance(x, InfoExtractor)


# Generated at 2022-06-22 08:45:58.595934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    i = TudouPlaylistIE()
    i.extract(url)

# Generated at 2022-06-22 08:46:00.485055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj

# Generated at 2022-06-22 08:46:05.148932
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for normal operation
    try:
        temp = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    except Exception:
        assert False, 'TudouAlbumIE constructor tested error'
    assert True


# Generated at 2022-06-22 08:46:06.067713
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:46:09.651196
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import _test_playlist

    _test_playlist(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        TudouAlbumIE)


# Generated at 2022-06-22 08:46:16.514897
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE.
    """
    # A playlist URL extracted from official web page
    url_one = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_one = TudouPlaylistIE()
    assert playlist_one._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_one.suitable(url_one) == True
    assert playlist_one.IE_NAME == "tudou:playlist"


# Generated at 2022-06-22 08:46:23.017522
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie_obj = TudouPlaylistIE()
    tudou_playlist_ie_obj._match_id(url)
    tudou_playlist_ie_obj._real_extract(url)
    tudou_playlist_ie_obj._download_json(url, 'zzdE77v6Mmo')


# Generated at 2022-06-22 08:48:46.790406
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    o = TudouAlbumIE()

# Generated at 2022-06-22 08:48:51.250441
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    # test if the _VALID_URL is correct
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:48:52.429770
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-22 08:48:57.019376
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_obj = TudouAlbumIE()
    assert (tudou_obj.IE_NAME == 'tudou:album') and (tudou_obj.ie_key() == 'tudou:album')

# Generated at 2022-06-22 08:49:01.373789
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouIE = TudouAlbumIE('www.tudou.com')
    assert tudouIE.domain == 'www.tudou.com'
    assert tudouIE.ie_key == 'TudouAlbum'
    assert tudouIE.video_id == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:49:06.561702
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    assert "http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg" == TudouAlbumIE(TudouAlbumIE.IE_NAME, {'url': url, 'downloader': 'test'})._real_initialize()

# Generated at 2022-06-22 08:49:09.643701
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    test._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    test._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:49:19.222476
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})' 
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45
