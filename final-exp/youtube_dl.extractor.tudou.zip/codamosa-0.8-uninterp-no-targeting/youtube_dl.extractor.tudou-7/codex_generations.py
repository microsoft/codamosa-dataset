

# Generated at 2022-06-22 08:39:17.334913
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE("zzdE77v6Mmo")

# Generated at 2022-06-22 08:39:26.189853
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import json
    from urllib import urlopen
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-22 08:39:34.537432
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-22 08:39:42.234693
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Test for constructor of class TudouPlaylistIE")
    import json
    import requests
    from TudouIE import TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }
    playlist_mincount = 209
    http_header = {
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'
                       ),
    }
    url_list = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % info_dict['id']
    playlist_data

# Generated at 2022-06-22 08:39:52.785749
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert getattr(TudouPlaylistIE, '__name__') == 'TudouPlaylistIE'
    assert getattr(TudouPlaylistIE, '_VALID_URL') == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert getattr(TudouPlaylistIE, '_TESTS') == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:40:01.292465
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]



# Generated at 2022-06-22 08:40:02.081571
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:40:04.636382
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie != None


# Generated at 2022-06-22 08:40:13.202840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumcover/L-6QsU6y8P0"
	url = "http://www.tudou.com/albumplay/L-6QsU6y8P0"
	album_id = url.split("/")[-1]
	album_data = self._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)

# Generated at 2022-06-22 08:40:15.397386
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:40:29.449533
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudoulist = TudouPlaylistIE()
    # Make sure it's True
    assert tudoulist.is_supported("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudoulist.is_supported("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudoulist.is_supported("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    # Make sure it's False
    assert not tudoulist.is_supported("https://www.tudou.com/listplay/zzdE77v6Mmo/")

# Generated at 2022-06-22 08:40:34.060026
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    album_id = 'zzdE77v6Mmo'
    album = TudouPlaylistIE()._real_extract(url)
    assert album.get('id') == album_id

# Generated at 2022-06-22 08:40:45.730077
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test constructor
    d = TudouPlaylistIE()
    # test class attribute
    assert d.IE_NAME == 'tudou:playlist'
    # test class attribute
    assert d._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert d._TESTS
    assert d._TESTS[0]
    assert d._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert d._TESTS[0]['info_dict']
    assert d._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert d._

# Generated at 2022-06-22 08:40:46.986697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE(False, 'Tudou playlist')


# Generated at 2022-06-22 08:40:50.377681
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert ie.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:40:51.296508
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE.test()

# Generated at 2022-06-22 08:40:52.826255
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.name == 'tudou:album'

# Generated at 2022-06-22 08:40:54.631784
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert_raises(AttributeError, getattr, t, 'IE_NAME')

# Generated at 2022-06-22 08:40:58.427027
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()

# Generated at 2022-06-22 08:41:03.534691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'TudouPlaylist'
    assert ie.VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:41:19.171024
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test with no parameters
    ie = TudouPlaylistIE()
    assert ie.name == 'tudou:playlist'
    # test with real parameters
    ie = TudouPlaylistIE(downloader=True, params={'id': 'test'})
    assert ie.name == 'tudou:playlist'
    assert ie.downloader == True
    assert ie.params == {'id': 'test'}
    # test with wrong parameters
    try:
        ie = TudouPlaylistIE(wrong_parameter=True)
    except Exception:
        pass
    else:
        raise Exception(
            'should raise exception when input invalid parameter!')


# Generated at 2022-06-22 08:41:28.099498
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert (tudou_album_ie._valid_url("http://www.tudou.com/albumplay/v5qckFJvNJg.html",TudouAlbumIE._VALID_URL) == 'v5qckFJvNJg')
    assert (tudou_album_ie._valid_url("http://www.tudou.com/albumcover/v5qckFJvNJg",TudouAlbumIE._VALID_URL) == 'v5qckFJvNJg')
test_TudouAlbumIE()

# Generated at 2022-06-22 08:41:29.132988
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE()

# Generated at 2022-06-22 08:41:34.026656
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album = TudouAlbumIE(url=url, album_id=album_id)
    playlist_mincount = 45
    return album, playlist_mincount

# Generated at 2022-06-22 08:41:41.831289
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import libpysmart
    #print libpysmart.__file__
    #print '-'*40
    #print libpysmart.inspect_obj(TudouAlbumIE)
    #print '-'*40
    #print TudouAlbumIE
    #print '-'*40
    #print dir(TudouAlbumIE)
    #print '='*80
    #print TudouAlbumIE.__module__
    #print '='*80
    #print TudouAlbumIE.__name__
    #print '='*80
    #for k in dir(TudouAlbumIE):
    #    print "TudouAlbumIE.%s = %s" % (k, getattr(TudouAlbumIE, k))
    #print '='*80
    #print Tudou

# Generated at 2022-06-22 08:41:50.034719
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # url to be tested
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # create an instance of class TudouPlaylistIE
    tudou_playlist_ie = TudouPlaylistIE()
    # test function url_result
    url_result = tudou_playlist_ie.url_result('http://www.tudou.com/programs/view/rD0_v-kR-X0/'
        , 'Tudou', 'rD0_v-kR-X0', '繁星之间《第25集-游戏王》')
    # extract playlist data
    playlist_data = tudou_playlist_ie.extract(url)
    # if error

# Generated at 2022-06-22 08:41:55.580238
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
        test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
        tudou_playlist_IE = TudouPlaylistIE()
        tudou_playlist_IE.get_url_info(test_url)
        assert tudou_playlist_IE.get_url_info(test_url)


# Generated at 2022-06-22 08:42:08.205556
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:42:15.910746
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert(tudouAlbumIE.IE_NAME == 'tudou:album')
    assert_valid_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html', tudouAlbumIE)
    assert_valid_url('http://www.tudou.com/albumcover/v5qckFJvNJg.html', tudouAlbumIE)

# Generated at 2022-06-22 08:42:23.327798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Test for constructor of class TudouPlaylistIE
    """
    _TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    _TESTS[0]["info_dict"]["id"] = "zzdE77v6Mmo"


# Generated at 2022-06-22 08:42:33.315434
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:42:34.931622
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE.create()
    assert isinstance(album, TudouAlbumIE)

# Generated at 2022-06-22 08:42:37.852723
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL is None


# Generated at 2022-06-22 08:42:43.620937
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    TudouAlbumIE = TudouAlbumIE(url, album_id)
    assert(TudouAlbumIE.album_id==album_id)
    assert(TudouAlbumIE.url==url)

# Generated at 2022-06-22 08:42:45.997842
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(TudouPlaylistIE.ie_key()).ie_key() == TudouPlaylistIE.ie_key()

# Generated at 2022-06-22 08:42:49.309131
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Test for constructor for class TudouPlaylistIE.
    """
    TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")


# Generated at 2022-06-22 08:42:55.327338
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    t = TudouPlaylistIE.DEFAULT_TEST_TEMPLATE()
    assert t['url'] == url
    assert t['playlist_mincount'] == 209


# Generated at 2022-06-22 08:43:02.390090
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Unit test for constructor of class TudouAlbumIE
    '''
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ieg_ = TudouAlbumIE()
    ieg_.match(url)

# Generated at 2022-06-22 08:43:07.588792
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert obj._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:43:08.202362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:43:28.691053
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    dummy_TudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert dummy_TudouAlbumIE._is_valid_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True
    assert dummy_TudouAlbumIE._is_valid_url('http://www.tudou.com/album/v5qckFJvNJg.html') == False
    assert dummy_TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:43:33.194700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test_obj = TudouAlbumIE()
    match_obj = test_obj._match_id(url)
    assert match_obj == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:43:38.987079
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	list_play_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	new_playlist = TudouPlaylistIE(list_play_url)
	assert new_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert new_playlist.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-22 08:43:40.706034
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1 == 1

# Generated at 2022-06-22 08:43:49.732730
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	yt = TudouPlaylistIE()

	assert yt.IE_NAME == 'tudou:playlist'
	assert yt._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert yt._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert yt._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
	assert yt._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-22 08:43:53.101689
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import tudou_extractor
    expected = 'tudou:album'
    actual = tudou_extractor.TudouAlbumIE._VALID_URL
    assert actual == expected

# Generated at 2022-06-22 08:43:54.124341
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()


# Generated at 2022-06-22 08:43:56.399140
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    a._download_json(a.tudou_album_url, 'abcd')


# Generated at 2022-06-22 08:44:00.829159
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE({})
    entry = ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw'])

#Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:44:03.152499
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    d = TudouAlbumIE()
    assert d is not None
    assert isinstance(d, InfoExtractor)
    assert isinstance(d, TudouAlbumIE)


# Generated at 2022-06-22 08:44:37.328367
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    entry = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert entry.ie_key() == 'Tudou:album'
    assert entry.ie_name() == 'tudou:album'

# Generated at 2022-06-22 08:44:44.026137
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert len(TudouPlaylistIE._TESTS) > 0
    for _, test in TudouPlaylistIE._TESTS:
        playlist = TudouPlaylistIE()
        pl = playlist._real_extract(test['url'])
        assert pl
        assert pl['_type'] == 'playlist'
        assert pl['id'] == test['info_dict']['id']
        assert len(pl['entries']) >= test['playlist_mincount']

# Generated at 2022-06-22 08:44:51.872675
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    assert ie.get_url_result('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == {'id': 'zzdE77v6Mmo', 'type': 'TudouPlaylist', 'title': None, 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'}


# Generated at 2022-06-22 08:44:54.854313
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:45:04.056068
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert x._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert x._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:45:05.891121
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert (TudouAlbumIE() != None)


# Generated at 2022-06-22 08:45:13.465328
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:45:16.766122
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg')
    assert ie.playlist_title == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:45:22.235559
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    b = TudouAlbumIE()
    assert b.IE_NAME == 'tudou:album'
    assert b._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-22 08:45:32.782472
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #__init__(self, ie_name, ie_key, fetch_webpage_handle=_fetch_webpage,
        # url_result_cls=TudouIE.url_result_cls,
        #https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py#L62
    #)
    tudou_playlist_ie = TudouPlaylistIE.ie_key()
    print('tudou_playlist_ie:', tudou_playlist_ie)
    assert(tudou_playlist_ie == 'TudouPlaylist')
    assert(isinstance(TudouPlaylistIE.ie_key, classmethod))


# Generated at 2022-06-22 08:46:49.033769
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    assert TudouAlbumIE._match_id(url) == "v5qckFJvNJg"

# Generated at 2022-06-22 08:46:52.571844
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/' + id + '.html'
    url = 'http://www.tudou.com/albumcover/' + id
    IE = TudouAlbumIE()
    IE.extract(url)


# Generated at 2022-06-22 08:46:54.841561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')


# Generated at 2022-06-22 08:46:55.963081
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert isinstance(TudouAlbumIE('test'), InfoExtractor)

# Generated at 2022-06-22 08:47:04.334255
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case for invalid string and valid string
    # invalid string
    tudouplaylist_info_extractor1=TudouPlaylistIE()
    tudouplaylist_info_extractor1._match_id("www.haha.com");
    # valid string
    tudouplaylist_info_extractor2=TudouPlaylistIE()
    tudouplaylist_info_extractor2._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html");


# Generated at 2022-06-22 08:47:14.843099
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:47:19.370612
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouPlaylistIE = TudouPlaylistIE()
    try:
        tudouPlaylistIE._real_extract(url)
    except:
        assert False



# Generated at 2022-06-22 08:47:26.506502
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)

# Generated at 2022-06-22 08:47:29.755237
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'https://www.tudou.com/albumcover/m5wogx5yBpk.html'
    albumIE = TudouAlbumIE()
    assert albumIE._match_id(url) == 'm5wogx5yBpk'

# Generated at 2022-06-22 08:47:33.204625
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
