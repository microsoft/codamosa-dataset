

# Generated at 2022-06-22 08:39:21.370788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-22 08:39:26.566101
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie.VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:39:28.891169
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        print("Test Constructor")
        ie = TudouAlbumIE()
        print("Done")
    except:
        print("Failed")


# Generated at 2022-06-22 08:39:32.729920
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = u'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_return = u'zzdE77v6Mmo'
    test_class = TudouPlaylistIE()
    assert test_class._match_id(test_url) == test_return


# Generated at 2022-06-22 08:39:37.636382
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-22 08:39:44.767751
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:39:55.589649
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_utils import CheckClass
    from .test_utils import TestCase
    from .test_utils import attr

    class TestTudouPlaylistIE(TestCase):
        """Tests for class TudouAlbumIE"""
        class_to_test = TudouAlbumIE


# Generated at 2022-06-22 08:40:02.008237
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Incorrect url
    wrong_url = 'http://www.tudou.com/albumplay'
    ie = TudouAlbumIE(wrong_url)
    assert_equals(ie._match_id(wrong_url), None)

    # Correct url
    correct_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(correct_url)
    assert_equals(ie._match_id(correct_url), 'v5qckFJvNJg')

# Generated at 2022-06-22 08:40:09.107923
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:40:16.711861
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test method construct of the class TudouAlbumIE"""
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE.IE_NAME == 'tudou:album'



# Generated at 2022-06-22 08:40:27.011360
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:40:34.139937
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE()
    assert tudou.IE_NAME == 'tudou:playlist'
    assert tudou.ie_key() == 'TudouList'
    assert tudou.playlist_id is None
    assert tudou.playlist_title is None
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:40:35.634598
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie is not None

# Generated at 2022-06-22 08:40:38.941089
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	if __name__ == '__main__':
		url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
		ie = TudouPlaylistIE()
		ie.url_result(url, 'Tudou', 'zzdE77v6Mmo')


# Generated at 2022-06-22 08:40:44.754365
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	Test = TudouAlbumIE()
	assert Test.IE_NAME == 'tudou:album'
	assert Test._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert Test._TESTS[0] == {'url' : 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict' : {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}



# Generated at 2022-06-22 08:40:54.404217
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'

    # test extract function
    result = tudou_playlist_ie.extract(test_url)

    # test response's key
    expected_keys = ['id']
    for key in expected_keys:
        assert key in result

    # test response's id
    assert result['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist_ie._match_id('sss') == None

# Generated at 2022-06-22 08:41:04.991196
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj_TudouAlbumIE = TudouAlbumIE()
    assert obj_TudouAlbumIE.IE_NAME == 'tudou:album'
    assert obj_TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert obj_TudouAlbumIE._TESTS == [ { 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': { 'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]


# Generated at 2022-06-22 08:41:08.378681
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylistIE.extract(url)


# Generated at 2022-06-22 08:41:19.442570
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import sys
    import os.path
    asset_file = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "data", "tudou_zzdE77v6Mmo.html")
    asset_data = open(asset_file, "rb").read()
    asset_url = 'http://www.tudou.com/plist/zzdE77v6Mmo'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:41:21.247338
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:41:32.588893
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE(TudouPlaylistIE())
    assert tudou_album.ie_key() == 'TudouAlbum'
    assert tudou_album.ie_name() == 'tudou:album'
    assert tudou_album.ie_description() == 'tudou:album'

# Generated at 2022-06-22 08:41:45.055479
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist1 = TudouPlaylistIE(None)
    assert tudou_playlist1.name == 'tudou:playlist'
    assert tudou_playlist1._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist1._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist1._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist1._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:41:46.487577
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    print(ie)



# Generated at 2022-06-22 08:41:49.767914
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testitem = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert testitem


# Generated at 2022-06-22 08:41:56.774284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE()
    assert(tudou_albumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')  
    assert(tudou_albumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-22 08:41:58.924598
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-22 08:42:00.197862
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print(TudouPlaylistIE)


# Generated at 2022-06-22 08:42:03.137257
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:42:06.118293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE._VALID_URL)


# Generated at 2022-06-22 08:42:09.978569
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    x.IE_NAME = 'TudouPlaylistIE'
    assert x.IE_NAME == 'TudouPlaylistIE'


# Generated at 2022-06-22 08:42:24.080388
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    id = ie._match_id(url)
    assert type(id) is unicode
    assert id == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:42:26.339354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-22 08:42:27.557688
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE(dict(id='abc123')) 
	pass

# Generated at 2022-06-22 08:42:30.363666
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg')


# Generated at 2022-06-22 08:42:37.371408
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    test_obj = TudouAlbumIE(test_url)
    assert test_obj.url == test_url
    assert test_obj.ie_key == 'Tudou'
    assert test_obj.video_id == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:42:46.509603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-22 08:42:51.504240
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("\nTest constructor method of class TudouPlaylistIE")
	print("\nINPUT: url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'")
	ex = TudouPlaylistIE()
	print("OUTPUT: " + str(ex))
	print("EXPECTED: " + "<tudou:playlist: 'tudou:playlist'>")


# Generated at 2022-06-22 08:42:59.775317
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from collections import namedtuple
    from .common import InfoExtractor
    from .common import InfoExtractor_UnitTest
    Playlist_UnitTest = namedtuple('Playlist_UnitTest', ['input', 'output'])
    Playlist_UnitTest.__new__.__defaults__ = (None,) * len(Playlist_UnitTest._fields)
    TudouPlaylistIE_UnitTest = Playlist_UnitTest(
        input=InfoExtractor_UnitTest('http://www.tudou.com/listplay/zzdE77v6Mmo.html'),
        output={'id': 'zzdE77v6Mmo'}
    )
    assert TudouPlaylistIE_UnitTest.input.test() == TudouPlaylistIE_UnitTest.output


# Generated at 2022-06-22 08:43:02.238586
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:43:12.256600
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#define attr of object TudouPlaylistIE

	#Attr of object InfoExtractor
	o_InfoExtractor = InfoExtractor()
	o_InfoExtractor._downloader = None
	o_InfoExtractor._match_id = None
	o_InfoExtractor._working_path = None
	o_InfoExtractor._downloader_options = None    
	o_TudouPlaylistIE = TudouPlaylistIE(o_InfoExtractor)
    
	#Attr of object TudouPlaylistIE
	o_TudouPlaylistIE._VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:43:48.490012
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == "tudou:album"
    assert tudou_album_ie._VALID_URL == r"https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"
    assert tudou_album_ie._TESTS[0]["url"] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert tudou_album_ie._TESTS[0]["info_dict"] == {
        "id": "v5qckFJvNJg"
    }

# Generated at 2022-06-22 08:43:49.903408
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:44:00.198388
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inputURL = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    expectedIE_NAME = 'tudou:album'
    expectedAlbum_id = 'v5qckFJvNJg'
    expected_VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/' + expectedAlbum_id
    expected_TESTS = [{
        'url':'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

    tudou_album_extractor = Tudou

# Generated at 2022-06-22 08:44:08.091486
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
    assert ie._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:44:14.188538
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'TudouAlbum'
    assert ie._VALID_URL == 'http[s]?://(?:www\.)?tudou.com/album(cover|play)/(?P<id>[\w-]{11})'
    assert ie.__class__.__name__ == 'TudouAlbumIE'


# Generated at 2022-06-22 08:44:16.563324
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'



# Generated at 2022-06-22 08:44:20.759258
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('https://www.tudou.com/listplay/F8aBCGxHdwQ.html')
    assert TudouPlaylistIE('https://www.tudou.com/listplay/F8aBCGxHdwQ.html')


# Generated at 2022-06-22 08:44:27.129697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    u'''TudouPlaylistIE testconstructor'''
    iedict = {
        '_VALID_URL': 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html',
        'IE_NAME': 'tudou:playlist',
        '_TESTS': [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
        }]
    } 
    assert iedict == InfoExtractor._get_info_extractors()['tudou:playlist']

    # Test case of _

# Generated at 2022-06-22 08:44:27.992897
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-22 08:44:34.730840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE(None)
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert tudouAlbumIE.suitable(url)
    assert tudouAlbumIE.IE_NAME == "tudou:album"
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:45:51.600561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    This test only shows the difference between TudouAlbumIE and TudouPlaylistIE.
    """
    ut = InfoExtractor
    url_playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url_album = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ut.suitable(url_playlist)
    assert ut.suitable(url_album)
    assert ut.IE_NAME == 'generic'
    # Here is the difference!
    assert not TudouPlaylistIE.suitable(url_album)
    assert not TudouAlbumIE.suitable(url_playlist)

# Generated at 2022-06-22 08:45:55.921566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE();
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:46:04.399378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie.SUCCESS == True)
    assert(ie.FAILURE == False)
    assert(ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')
    assert(ie._TESTS[0]['playlist_mincount'] == 209)

# Generated at 2022-06-22 08:46:05.020762
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:46:08.053757
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class MyTudouAlbumIE(TudouAlbumIE):
        def _real_extract(self, url):
            return True
    MyTudouAlbumIE()

# Generated at 2022-06-22 08:46:09.174185
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(5, "test")

# Generated at 2022-06-22 08:46:17.018652
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """test it"""
    import unittest
    import sys
    class TestTudouAlbumIE(unittest.TestCase):
        def setUp(self):
            self.test_class = TudouAlbumIE()

        def test_instance(self):
            self.assertIsInstance(self.test_class, TudouAlbumIE)
        def test_parameter(self):
            self.assertEqual("tudou:album", self.test_class._TEST)
            self.assertEqual("/albumcover/(?P<id>[\\w-]{11})", self.test_class._VALID_URL)
            self.assertEqual("TudouAlbumIE", self.test_class.IE_NAME)
    test_suite = unittest.TestSuite()
    test_suite

# Generated at 2022-06-22 08:46:24.182754
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
    'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
    'info_dict': {
        'id': 'zzdE77v6Mmo',
    },
    'playlist_mincount': 209,
}]

# Generated at 2022-06-22 08:46:27.838039
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    playList = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.extract(playList) == None


# Generated at 2022-06-22 08:46:31.476969
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_name() == 'Tudou'


# Generated at 2022-06-22 08:48:55.560511
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:48:59.735670
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'https://www.tudou.com/albumplay/v5qckFJvNJg.html' == TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html', {})._VALID_URL


# Generated at 2022-06-22 08:49:08.421656
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test before the request
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    # Test after the request
    # The result we expected
   

# Generated at 2022-06-22 08:49:19.336973
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE._download_json = lambda self, url: {
        'items': [
            {
                'icode': '1',
                'kw': 'item_1'
            },
            {
                'icode': '2',
                'kw': 'item_2'
            }
        ]
    }

    TudouPlaylistIE._real_extract = lambda self, url: self._download_json(url)

    ie = TudouPlaylistIE()
    assert ie._download_json('')['items'][0]['icode'] == '1', "Value icode should be '1'"
    assert ie._download_json('url')['items'][0]['kw'] == 'item_1', "First item's kw attribute should be 'item_1'"
