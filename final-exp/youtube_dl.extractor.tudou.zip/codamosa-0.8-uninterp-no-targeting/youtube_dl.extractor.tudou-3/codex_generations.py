

# Generated at 2022-06-22 08:39:23.729351
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test for valid url
    ie = TudouAlbumIE()
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True
    # test for invalid url
    ie = TudouAlbumIE()
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg') == False


# Generated at 2022-06-22 08:39:28.043929
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print('Start testing constructor of class TudouAlbumIE')
	ie = TudouAlbumIE()
	if isinstance(ie, TudouAlbumIE):
		print("Test of constructing class TudouAlbumIE successfully")
	else:
		print("Test of constructing class TudouAlbumIE failed")
	print("\n"*2)


# Generated at 2022-06-22 08:39:32.656677
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    href = "http://www.flvcd.com/parse.php?format=&kw=http%3A%2F%2Fwww.tudou.com%2Flisticon.php%3Flistid%3D121143930&format=super"
    import requests
    r = requests.get(href)
    assert r.text.count(".flv") == 209

# Generated at 2022-06-22 08:39:36.701495
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    assert_equal(IE.__name__, 'tudou:album')
    assert_equal(IE.IE_NAME, 'tudou:album')
    assert_equal(IE._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')


# Generated at 2022-06-22 08:39:40.615857
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:39:41.111628
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:39:43.273243
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(None)


# Generated at 2022-06-22 08:39:50.058234
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_data = {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    assert(TudouAlbumIE._TESTS[0] == test_data)

# Generated at 2022-06-22 08:39:58.970071
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/pV_R0wmdMj4.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie.extract("http://www.tudou.com/albumplay/pV_R0wmdMj4.html") != None


# Generated at 2022-06-22 08:40:01.752001
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test = TudouAlbumIE()
    assert test.suitable(url)
    return True


# Generated at 2022-06-22 08:40:09.711176
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    album_id = "v5qckFJvNJg"

# Generated at 2022-06-22 08:40:15.903238
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Get the URL you want to test
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # Create a new instance of the class using the URL
    tudou_playlist = TudouPlaylistIE(url)
    # Call the real_extract method using the URL

# Generated at 2022-06-22 08:40:25.022606
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlistIE = TudouPlaylistIE()
    realURL = playlistIE.workingURL('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert realURL == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert playlistIE.ie_key() == 'TudouPlaylist'
    assert playlistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlistIE.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:40:32.683217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    target = TudouAlbumIE()._real_extract(test_url)
    length = len(target["_type"])
    assert target["_type"].find("playlist") != -1
    assert length == 10
    assert target["id"] == "v5qckFJvNJg"
    #assert target["title"] == "title"
    #assert target["description"] == "description"


# Generated at 2022-06-22 08:40:37.365011
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test with url from v5qckFJvNJg
    try:
        tudou_album_ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    except:
        pass

# Generated at 2022-06-22 08:40:39.941636
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(None)._TESTS[0], dict)


# Generated at 2022-06-22 08:40:42.945212
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        url = "http://www.tudou.com/listplay/aKj1yYErYOo.html";
        TudouAlbumIE(url);


# Generated at 2022-06-22 08:40:45.622363
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url="http://www.tudou.com/listplay/zzdE77v6Mmo.html"

# Generated at 2022-06-22 08:40:54.859440
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Imports here as it is in a function and thus not imported with the other classes
    import re
    import unittest
    import httpretty
    import json
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE

    def download_json(url, *args, **kwargs):
        # Ignore all arguments.
        return {
            'items': [
                {
                    'icode': 'abcdefg',
                    'kw': 'example1',
                },
                {
                    'icode': 'hijklmn',
                    'kw': 'example2',
                },
            ],
        }


# Generated at 2022-06-22 08:40:57.231914
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.ie_key() == 'Tudou:playlist'


# Generated at 2022-06-22 08:41:11.385363
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
            url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:41:15.894510
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()
    assert(test_TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-22 08:41:25.441045
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test that redirects to https://www.tudou.com/list/albumitem.action?xdl=1&listCode=zzdE77v6Mmo
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    urls = []
    ie = TudouPlaylistIE()
    for e in ie.extract(url):
        urls.append(e.url)

# Generated at 2022-06-22 08:41:28.547624
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # pdb.set_trace()
    TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:41:37.497682
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url1 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    url2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(url1)
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._match_id(url1) == 'v5qckFJvNJg'
    assert tudou_album_ie._match_id(url2) == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:41:48.041498
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    ie.IE_NAME = 'tudou:album'
    ie._VALID_URL = r'https?://(?:www\.)?tudou\.com/album/(?P<id>[\w-]{11})'
    ie._TESTS = [{
        'url': 'http://www.tudou.com/album/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-22 08:41:50.469576
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        tudouAlbumIE =  TudouAlbumIE()
        print(tudouAlbumIE)

# Generated at 2022-06-22 08:41:58.538326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie.playlist_id == 'v5qckFJvNJg'
    assert ie.api_url == 'http://www.tudou.com/tvp/alist.action?acode=%s' % ie.playlist_id
    assert ie.IE_DESC == 'TudouAlbum'
    assert 'TudouAlbum' in ie.__class__.__name__

# Generated at 2022-06-22 08:42:05.537291
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td_album_ie = TudouAlbumIE()
    assert td_album_ie.IE_NAME == 'tudou:album'
    assert td_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert td_album_ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:42:08.669380
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE()
    assert constructor.__name__ == 'tudou:album'

# Generated at 2022-06-22 08:42:23.666981
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE()
    assert obj.suitable(url)



# Generated at 2022-06-22 08:42:25.296186
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), TudouAlbumIE)


# Generated at 2022-06-22 08:42:29.605430
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('\nTesting for TudouPlaylistIE\n')

    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE().url_result(test_url, None, None)
    assert playlist is not None


# Generated at 2022-06-22 08:42:32.838140
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Given the following
    testInput = ['http://www.tudou.com/albumcover/v5qckFJvNJg.html']
    # When I call the constructor of class TudouAlbumIE
    testOutput = TudouAlbumIE.suitable(testInput)
    # Then I get the expected output
    assert testOutput == (True, None)



# Generated at 2022-06-22 08:42:35.958198
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie == 'TudouPlaylistIE'
    assert ie.playlist_mincount == 1
    assert ie.__dict__ == {'playlist_mincount': 1}



# Generated at 2022-06-22 08:42:40.471862
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # It's a simple test to see if the constructor is working or not
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE.suite()(url)

# Generated at 2022-06-22 08:42:49.507992
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:42:55.013498
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'
    assert TudouAlbumIE.ie_key() == 'tudou:album'
    assert TudouAlbumIE.ie_key() == 'tudou:album'

# Generated at 2022-06-22 08:42:57.389874
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE(None).ie_key() == 'TudouPlaylist')

import unittest
from .test_tudou import TudouIE
from .test_common import TestCommon

# Generated at 2022-06-22 08:43:02.904074
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE(None, None)
    except TypeError as e:
        print("Unit test for testing constructor of class \"TudouPlaylistIE\" fail!")
        raise e
    print("Unit test for testing constructor of class \"TudouPlaylistIE\" succeed!")


# Generated at 2022-06-22 08:43:28.298322
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_obj = TudouAlbumIE()
    assert test_obj



# Generated at 2022-06-22 08:43:33.671953
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Performance test for constructor of class TudouPlaylistIE
    import time
    start = time.clock()
    for i in range(0, 1000):
        inst = TudouPlaylistIE()
        inst.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    print((time.clock() - start) / 1000)
    assert True

# Generated at 2022-06-22 08:43:43.318866
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie.IE_NAME == 'tudou:album')
    assert(ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(ie._TESTS == [{ 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
                           'info_dict': {'id': 'v5qckFJvNJg'},
                           'playlist_mincount': 45}])
    assert(ie._download_json)


# Generated at 2022-06-22 08:43:54.129839
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert isinstance(ie._TESTS, (list, tuple))
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:43:57.859602
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)
    assert True


# Generated at 2022-06-22 08:44:09.174169
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize a TodouAlbumIE.
    iev1 = TudouAlbumIE()
    iev1_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info_dict = {
        'id': 'v5qckFJvNJg'
    }
    playlist_mincount = 45
    _TESTS = [{
        'url': url,
        'info_dict': info_dict,
        'playlist_mincount': playlist_mincount,
    }]

    # Test _real_extract()
    iev1_extracted_info = iev1._real_extract(url)

# Generated at 2022-06-22 08:44:13.458962
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()
    assert inst._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert inst._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert inst._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-22 08:44:16.247055
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie = TudouPlaylistIE()
	assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:44:25.220703
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test that listplay is the same as albumplay
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_album_ie = TudouAlbumIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Save the page html to temp file.
    tudou_playlist_ie._downloader.cache.get(url)
    playlist_url = tudou_playlist_ie._real_extract(url)[0].url
    album_url = tudou_album_ie._real_extract(url)[0].url
    assert playlist_url == album_url, 'Fail to assert that listplay url equals albumplay url'



# Generated at 2022-06-22 08:44:30.297740
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test url : http://www.tudou.com/listplay/zzdE77v6Mmo.html
    valid_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    IE = TudouPlaylistIE()
    # test _real_extract function
    IE._real_extract(valid_url)

# Generated at 2022-06-22 08:45:40.986496
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import Tudou.TudouAlbumIE
	import urllib
	x = urllib.urlopen("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
	url = x.geturl()
	TudouAlbumIE.TudouAlbumIE()
	TudouAlbumIE.TudouAlbumIE()._match_id(url)
	TudouAlbumIE.TudouAlbumIE()._real_extract(url)

# Generated at 2022-06-22 08:45:48.965743
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('')
    ie.playlist_result('')
    ie.playlist_result([])
    ie.playlist_result([{}])
    ie.playlist_result({})
    ie.playlist_result([{'url': ''}])
    ie.playlist_result([{'url': '1'}])
    ie.playlist_result([{'url': '1'}, {'url': '2'}])

# Generated at 2022-06-22 08:45:53.251625
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    (res,err) = TudouAlbumIE(url)
    assert res["id"] == "v5qckFJvNJg"

# Generated at 2022-06-22 08:45:58.013797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    entry = ie._real_extract(TudouPlaylistIE._VALID_URL)[0]
    entry["id"] == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:46:01.213378
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
     TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-22 08:46:05.717484
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE.IE_NAME == 'tudou:album'
	assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-22 08:46:09.886613
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    m = TudouAlbumIE()
    m = TudouAlbumIE('www.tudou.com/albumcover/v5qckFJvNJg')
    m = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    m = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    m = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg')

# Generated at 2022-06-22 08:46:15.254321
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.suitable(url)
    assert tudou_album_ie.extract(url)['id'] == 'v5qckFJvNJg'
    assert tudou_album_ie._real_extract(url)['_type'] == 'playlist'

# Generated at 2022-06-22 08:46:16.422262
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:46:17.404926
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()

# Generated at 2022-06-22 08:48:38.660982
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Test for constructor without argument
    try:
        playlist = TudouPlaylistIE()
    except:
        assert False
    else:
        assert True

    # Test for legitimate URLs
    url1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url0 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist.suitable(url0)
    playlist.url_result(url1, 'Tudou', 'zzdE77v6Mmo', 'Songs')
    playlist.url_result(url1)

# Generated at 2022-06-22 08:48:44.433839
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    Test the constructor of class TudouPlaylistIE
    '''
    TudouPlaylistIE.__name__ = 'TudouPlaylistIE'
    TudouPlaylistIE.__doc__ = InfoExtractor.__doc__
    i = TudouPlaylistIE()
    assert i.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:48:49.988248
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    param = [test_TudouPlaylistIE, 'Tudou:Playlist']
    test_TudouPlaylistIE1 = TudouPlaylistIE(*param)

# Generated at 2022-06-22 08:49:00.256129
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

	# Test case 1: Valid url
	tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert tudouAlbumIE._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]
	assert tudouAlbumIE.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:49:03.481231
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:49:04.284903
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    entry = TudouPlaylistIE()
    return

# Generated at 2022-06-22 08:49:14.366224
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url_valid = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	url_invalid = 'http://www.tudou.com/myplaylist/zzdE77v6Mmo.html'
	assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert TudouPlaylistIE._TESTS[0].get('url') == url_valid
	assert TudouPlaylistIE._TESTS[0].get('info_dict') == {'id': 'zzdE77v6Mmo'}
	assert TudouPlaylistIE._TESTS[0].get('playlist_mincount') == 209
	