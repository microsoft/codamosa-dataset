

# Generated at 2022-06-22 08:39:21.415843
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    temp=TudouPlaylistIE()
    assert temp._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:39:24.614759
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	assert ie.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:39:30.003595
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Pass the url to the constructor of class TudouAlbumIE
    tudou_album_ie = TudouAlbumIE(url)

    assert(tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-22 08:39:31.911021
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'Tudou:album'


# Generated at 2022-06-22 08:39:38.658201
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("===============-=-=TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT=-=-=-=-=======")
	url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	ie = TudouAlbumIE()
	print(ie.suitable(url))



# Generated at 2022-06-22 08:39:40.563010
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import pytest
    with pytest.raises(TypeError):
        TudouAlbumIE()



# Generated at 2022-06-22 08:39:45.232111
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    _, ie = TudouAlbumIE._extract_info(url)
    assert ie.get('id') == url



# Generated at 2022-06-22 08:39:51.151905
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    info_dict = {
            'id': 'zzdE77v6Mmo',
        }
    ret = InfoExtractor._call_ie(TudouPlaylistIE.ie_key(), url)
    assert ret.get('id') == info_dict.get('id')


# Generated at 2022-06-22 08:39:52.991441
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie =  TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:39:58.864423
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-22 08:40:08.332229
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    _VALID_URL = r'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(_VALID_URL)
    assert ie.url == _VALID_URL
    assert ie.video_id == 'zzdE77v6Mmo'
    assert ie.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:40:18.450669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().is_suitable(TudouAlbumIE._VALID_URL)
    assert not TudouAlbumIE().is_suitable('http://www.tudou.com/albumcover/v5qckFJvNJg')
    assert not TudouAlbumIE().is_suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.htmll')
    assert not TudouAlbumIE().is_suitable('http://www.tudou.com/albumplay/v5qckFJvNJ')
    assert not TudouAlbumIE().is_suitable('http://www.tudou.com/albumplay/v5qckFJvNJgg')


# Generated at 2022-06-22 08:40:25.105351
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudouAlbumIE._real_extract(url) is not None


# Generated at 2022-06-22 08:40:35.331180
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie.IE_NAME == 'tudou:album')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(len(ie._TESTS) == 1)
    assert(ie._TESTS[0]['url'] == r'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(ie._TESTS[0]['info_dict']['id'] == r'v5qckFJvNJg')
    assert(ie._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-22 08:40:35.959856
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-22 08:40:42.080900
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE(InfoExtractor())
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_id = 'v5qckFJvNJg'
    assert(tudouAlbumIE._match_id(test_url) == test_id)

# Generated at 2022-06-22 08:40:48.207027
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_obj = InfoExtractor(url)
    result = test_obj.extract()
    assert_true(result['id'] == 'zzdE77v6Mmo')
    assert_true(result['title'] == 'zzdE77v6Mmo')



# Generated at 2022-06-22 08:40:50.719290
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    print(obj.IE_NAME)


if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-22 08:40:51.960513
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('tudou:album', 'test album')


# Generated at 2022-06-22 08:40:52.825346
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True == False


# Generated at 2022-06-22 08:41:08.287043
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_object = TudouPlaylistIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_object._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert test_object._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert test_object._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:41:11.245850
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_test = TudouAlbumIE()
    tudou_album_test._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:41:21.048300
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:41:26.931183
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:41:34.303288
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:41:43.459059
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print (TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                   None).getUrl())
    print (TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                   None).getName())
    print (TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                   None).getInfo())


# Generated at 2022-06-22 08:41:54.955711
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_extractor = TudouAlbumIE(None)
    assert album_extractor.IE_NAME == 'tudou:album'
    assert len(album_extractor._VALID_URL.split('http')) == 2
    assert album_extractor._VALID_URL.split('http')[0] == ''
    assert album_extractor._VALID_URL.split('http')[1] == 's?://(?:www\\.)?tudou\\.com/album(?:cover|play)/(?P<id>[\\w-]{11})'
    assert album_extractor._match_id(album_url) == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:41:56.380879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie


# Generated at 2022-06-22 08:42:03.254275
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou')
    init(ie, 'Tudou')
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:42:05.904053
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-22 08:42:22.399882
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('Tudou Album')
    assert tudou_album_ie is not None
    assert type(tudou_album_ie) == TudouAlbumIE

# Generated at 2022-06-22 08:42:26.933379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE()
	test.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	expected_id = 'zzdE77v6Mmo'
	assert test._match_id(test.url) == expected_id, 'Test for TudouPlaylistIE constructor failed.'


# Generated at 2022-06-22 08:42:32.089348
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-22 08:42:40.367761
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.IE_DESC == '土豆 - 在线视频观看,原创视频上传'
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:42:41.594436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:42:45.489513
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        test_dict = {'id':'test_id'}
        test_url = 'test_url'
        test_ie = TudouPlaylistIE(test_dict, test_url)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-22 08:42:48.072008
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_tudou_playlist_ie = TudouPlaylistIE()
    assert test_tudou_playlist_ie is not None


# Generated at 2022-06-22 08:42:51.719966
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:43:00.104840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    # Set up dummy apps-engine environment
    from google.appengine.api import memcache
    from google.appengine.api import urlfetch
    urlfetch.set_default_fetch_deadline(45)
    urlfetch._make_fetch_call = lambda *args, **kwargs: {'status_code': 200, 'content': '{}'}


# Generated at 2022-06-22 08:43:06.681000
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:43:42.687888
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import sys
    import tempfile

    try:
        sys.exc_clear()
        tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test-homepage-')
        ie = TudouPlaylistIE(tmp_dir)
        assert ie is not None
        ie = TudouPlaylistIE(tmp_dir, downloader=None)
        assert ie is not None
    except:
        sys.exc_clear()

    try:
        tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test-homepage-')
        ie = TudouPlaylistIE(tmp_dir, downloader=None)
        assert ie is not None
    except:
        sys.exc_clear()


# Generated at 2022-06-22 08:43:47.985520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    import inspect
    # Get the source code of the constructor
    src = inspect.getsource(ie.__init__)
    # Check if url_result is called to construct playlist_result
    assert "url_result = ie.url_result" in src
    assert "playlist_result = ie.playlist_result" in src

# Generated at 2022-06-22 08:43:49.805726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:43:55.317304
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()

# Generated at 2022-06-22 08:43:59.430090
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'v5qckFJvNJg', 'albumplay/v5qckFJvNJg.html')
    assert ie._NAME == 'Tudou'

# Generated at 2022-06-22 08:44:01.985249
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .tudou import TudouAlbumIE
	TudouAlbumIE()

# Generated at 2022-06-22 08:44:05.297145
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test instantiation
    test = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(test != None)



# Generated at 2022-06-22 08:44:16.058440
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # 测试构造函数
    ie = TudouPlaylistIE()
    # 测试正则表达式

# Generated at 2022-06-22 08:44:25.752688
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    __test__ = True
    def test_real_extract(self):
        __test__ = True
        playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
        playlist_id = "zzdE77v6Mmo"

        playlist_data = self._download_json(
            'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
        entries = [self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in playlist_data['items']]

# Generated at 2022-06-22 08:44:33.671946
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou = TudouAlbumIE()
    assert(tudou._match_id(test_url) == 'v5qckFJvNJg')
    assert(tudou.IE_NAME == 'tudou:album')
    assert(tudou._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(len(tudou._TESTS) == 1)
    assert(tudou._TESTS[0]['url'] == test_url)


# Generated at 2022-06-22 08:45:46.646195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None)

# Generated at 2022-06-22 08:45:51.768895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Test TouDouAlbumIE by creating a object of this class,
	# and call the function url_result()
	album = TudouAlbumIE();
	album.url_result('test', 'Tudou', 'test2', 'test3');
	return True;

# Generated at 2022-06-22 08:45:55.282781
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
  ie = TudouAlbumIE()
  extractor = ie.suitable(url)
  assert extractor

# Generated at 2022-06-22 08:45:58.643743
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album = TudouAlbumIE()
    assert tudou_album.suitable(test_case)

# Generated at 2022-06-22 08:46:06.335072
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    InfoExtractor.decrypt_signature = lambda self, x: x
    info_extractor = InfoExtractor()
    info_extractor.add_info_extractor(TudouPlaylistIE.ie_key())

    # Download playlist
    playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    info_extractor._downloader.cache._download_webpage = lambda *a, **k: (None, {'id': playlist_id})
    info_extractor._real_extract(playlist)
    assert info_extractor.url_result(playlist, 'Tudou', playlist_id)

    # Download album

# Generated at 2022-06-22 08:46:15.715155
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

	#Test with a valid url
	assert (TudouAlbumIE._VALID_URL == u'https?://(?:www\\.)?tudou\\.com/album(?:cover|play)/(?P<id>[\\w-]{11})')

	#Test with a valid album_id

# Generated at 2022-06-22 08:46:17.895933
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        playlist = TudouPlaylistIE()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-22 08:46:26.156868
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-22 08:46:29.268229
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()

# Generated at 2022-06-22 08:46:32.981726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #test_TudouPlaylistIE creates an instance of
    # TudouPlaylistIE and persist in file.txt
    s = TudouPlaylistIE()
    s.to_file('./file.txt')
    assert True

# Generated at 2022-06-22 08:49:03.457538
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:49:08.782492
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    exp_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Tester using class methods
    test_obj = InfoExtractor.test('TudouAlbumIE', exp_url)
    assert test_obj.test() == 'TudouAlbumIE'
    # Tester using object methods
    test_obj = TudouAlbumIE()
    assert test_obj.test(exp_url) == test_obj.IE_NAME

# Generated at 2022-06-22 08:49:13.277931
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    c = TudouPlaylistIE()
    assert c.IE_NAME == 'TudouPlaylistIE'
    assert c._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'