

# Generated at 2022-06-22 08:39:18.303758
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_instance = TudouPlaylistIE()
    assert tudou_playlist_ie_instance


# Generated at 2022-06-22 08:39:26.884558
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    web_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'json_file'

# Generated at 2022-06-22 08:39:27.776372
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-22 08:39:34.902295
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Given
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # When
    playlist = TudouPlaylistIE()

    # Then
    assert playlist.ie_key() == 'TudouPlaylist'
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.suitable(url) == True
    assert playlist._match_id(url) == 'zzdE77v6Mmo'
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:39:45.994986
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import testvideo
    from .common import testvideo_data
    from .common import MSIE
    from .common import MSIE_UA
    from .common import mp4_test_url, mp4_test_data
    from .common import testvideo_result

    import copy
    import re
    import sys

    import os
    import urllib

    import xml.etree.ElementTree as ET

    IE_NAME = 'tudou:album'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    #
    # with open('./tudou.xml', 'r') as f:
    #     news_data = f.read()

    # album_data =

# Generated at 2022-06-22 08:39:50.589650
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    i = TudouAlbumIE()
    m = i.extract(url)
    for key in m.keys():
        assert m[key] is not None

# Generated at 2022-06-22 08:39:59.169325
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tu = TudouPlaylistIE(None)
    tu.IE_NAME = 'tudou:playlist'
    tu._VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tu._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:40:01.325572
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    if not hasattr(obj, 'IE_NAME'):
        raise AssertionError("It should has attribute of IE_NAME")

# Generated at 2022-06-22 08:40:08.751474
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._downloader.params['noprogress'] == True
    assert ie.SUCCESS == True
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:40:10.809685
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()


# Generated at 2022-06-22 08:40:17.739031
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE()

# Generated at 2022-06-22 08:40:20.164796
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    dict = {'key': 'value'}
    assert dict['key'] == 'value'
    

# Generated at 2022-06-22 08:40:24.246715
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE()
    print ('Test constructor of class TudouAlbumIE is done!')
    

# Generated at 2022-06-22 08:40:31.112465
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie_class = TudouAlbumIE
    urls = ["http://www.tudou.com/albumcover/v5qckFJvNJg",
            "http://www.tudou.com/albumplay/v5qckFJvNJg.html"]
    for url in urls:
        ie_test = ie_class(url)
        assert ie_test._VALID_URL == ie_class._VALID_URL
        assert ie_test.IE_NAME == ie_class.IE_NAME

# Generated at 2022-06-22 08:40:32.209886
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-22 08:40:37.219286
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('TudouPlaylistIE', 'https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'TudouPlaylistIE'
    assert ie.IE_DESC == 'Tudou Playlist'

# Generated at 2022-06-22 08:40:40.728477
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_tudoualbum = TudouAlbumIE()
    assert test_tudoualbum.IE_NAME == 'tudou:album'


# Generated at 2022-06-22 08:40:46.450592
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:40:53.032147
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	obj = TudouPlaylistIE()._real_initialize(url)
	assert obj._match_id(url) == 'zzdE77v6Mmo'
	assert obj._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % 'zzdE77v6Mmo', 'zzdE77v6Mmo').items() != []


# Generated at 2022-06-22 08:40:56.816825
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj.IE_NAME == 'tudou:album'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-22 08:41:15.867983
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    ier = ie._real_initialize()
    assert ier == ie
    playlist_id = ie._match_id(url)
    assert playlist_id == 'zzdE77v6Mmo'
    playlist_data = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    assert len(playlist_data) > 0

# Generated at 2022-06-22 08:41:25.440507
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    # Assert the value of IE_NAME and _VALID_URL
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    # Assert the value of _TESTS[0]['url'], _TESTS[0]['info_dict']['id'] and _TESTS[0]['playlist_mincount']
    assert tudou_playlist_ie

# Generated at 2022-06-22 08:41:27.317654
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(None)
    assert obj is None


# Generated at 2022-06-22 08:41:28.404027
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:41:30.547913
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(TudouPlaylistIE._downloader).suitable(TudouPlaylistIE._VALID_URL)


# Generated at 2022-06-22 08:41:38.312190
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.url = url
    tudou_playlist_ie.playlist_id = tudou_playlist_ie._match_id(url)
    tudou_playlist_ie.playlist_url = tudou_playlist_ie._VALID_URL
    tudou_playlist_ie.playlist_title = tudou_playlist_ie.playlist_id
    assert tudou_playlist_ie == tudou_playlist_ie == tudou_playlist_ie


# Generated at 2022-06-22 08:41:40.934549
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except RuntimeError as e:
        print(e)


# Generated at 2022-06-22 08:41:48.674535
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    urls = [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    ]

    ie = TudouAlbumIE()
    for url in urls:
        match = ie._VALID_URL_RE.match(url)
        assert match is not None
        assert match.group('id') == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:41:53.903396
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    play_list = TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert play_list.IE_NAME == 'tudou:playlist'
    assert play_list.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-22 08:41:54.954007
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:42:21.673414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    ie = TudouAlbumIE()
    ie.extract(url)
    assert ie.url == url
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:42:33.204467
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.SUCCEEDED_REGEX == r'ok\:(?P<url>http://v\.youku\.com/player/getM3U8/vid/[\w\-]{11}/type/[\w\-]{1,2}/ts/[\d\-]{10,}/v\.m3u8)'
    assert ie.SITE == 'Tudou'
    assert ie.SITE_THUMBNAIL == 'http://s4.tdimg.com/s/sns_logo/sns_logo_tudou_300.png'

# Generated at 2022-06-22 08:42:40.490000
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Unit test for constructor of class TudouAlbumIE")

    import sys
    import os
    from youtube_dl import YoutubeDL
    from tools import get_resource_path as grp
    from nose.tools import assert_equals

    # Get test video
    ydl = YoutubeDL({})
    path = grp(True, "fixtures", "tudou", "album")
    path = os.path.join(path, "v5qckFJvNJg")
    with open(path) as f:
        content = f.read()

    # Constructor
    tae = TudouAlbumIE({'test_suite': True})
    tae._download = lambda x: content

    # Extract video

# Generated at 2022-06-22 08:42:46.578323
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_template = {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'}
    result = InfoExtractor(dict(test_template)).extract()

    assert result['id'] == 'zzdE77v6Mmo'
    assert result['_type'] == 'url_transparent'


# Generated at 2022-06-22 08:42:47.878444
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert instance

# Generated at 2022-06-22 08:42:53.762270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(result)

# Generated at 2022-06-22 08:42:55.735000
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
# End of unit test

# Generated at 2022-06-22 08:43:08.289307
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Example URL of a Tudou Album
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Create an instance of class TudouAlbumIE
    tudou_album = TudouAlbumIE()
    # Check that the instance has attribute '_VALID_URL'
    assert hasattr(tudou_album, '_VALID_URL')
    # Check that the instance's attribute '_VALID_URL' is a regular expression
    assert type(tudou_album._VALID_URL) is unicode
    # Check that the instance's attribute '_VALID_URL' can match the example URL
    assert re.match(r'^'+tudou_album._VALID_URL+r'$', url) is not None
    # Get the tuple

# Generated at 2022-06-22 08:43:17.129580
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#输入参数
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' #普通的优酷网的视频地址
	playlist_id = 'zzdE77v6Mmo'
	playlist_data = {'items':[{'icode':'v5qckFJvNJg','kw':'午夜剧场'},{'icode':'3tMpz2_sMd8','kw':'电影'}]}
	#创建TudouPlaylistIE类
	test_instance = TudouPlaylistIE()
	#模拟私有成员

# Generated at 2022-06-22 08:43:22.126916
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_test = TudouPlaylistIE()

    # First parameter of assertEqual should be the expected value,
    # second one should be the value got by running the function / class
    assertEqual(tudou_test.ie_key(), 'Tudou')
    assertEqual(tudou_test.ie_name(), 'tudou:playlist')

# Generated at 2022-06-22 08:44:12.127340
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.val['album_id'] == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:44:14.416162
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    res = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:44:20.368659
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouAlbumIE._VALID_URL.search(album).group('id') \
            == TudouPlaylistIE._VALID_URL.search(playlist).group('id')



# Generated at 2022-06-22 08:44:21.937387
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:44:26.353604
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    inst = TudouPlaylistIE()
    inst._match_id(url)


# Generated at 2022-06-22 08:44:33.738574
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_ie = TudouAlbumIE()
    assert album_ie.ie_key() == 'TudouAlbum'
    assert album_ie.ie_name() == 'Tudou:album'
    valid_urls = [
        'http://www.tudou.com/album/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    ]
    for url in valid_urls:
        assert album_ie._match_id(url) == 'v5qckFJvNJg'
        assert album_ie._match_id(url) != 'v5qckFJvNJ'

# Generated at 2022-06-22 08:44:39.878949
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    TudouPlaylistIE()._real_initialize()

    ie = TudouPlaylistIE(test_url)
    info = ie._real_extract()

    from pprint import pprint
    pprint(info)

# Generated at 2022-06-22 08:44:43.777788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Arrange
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_ie = TudouPlaylistIE()
    # Act
    playlist_ie.real_extract(url)


# Generated at 2022-06-22 08:44:45.568361
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE('TudouAlbumIE')
    assert result != False


# Generated at 2022-06-22 08:44:55.524903
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Refer: http://www.tudou.com/listplay/zzdE77v6Mmo/A1W8H_Ff_yI.html
    """
    tudou_album_test_url = 'http://www.tudou.com/albumplay/A1W8H_Ff_yI.html'
    video_album_test_id = 'A1W8H_Ff_yI'
    print('Begin test function tudou_playlist')
    test_tudou_album = TudouAlbumIE()
    test_tudou_album.extract(tudou_album_test_url)
    assert(video_album_test_id == test_tudou_album._match_id(tudou_album_test_url))

# Unit test

# Generated at 2022-06-22 08:47:05.807915
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import os, sys
	sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'ytdl'))
	from yt_dl import extractor
	tudouPlaylistIE = extractor.get_info_extractor('tudou:playlist')
	assert tudouPlaylistIE.__name__ == 'TudouPlaylistIE'
	assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:47:08.076737
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('1') == '1'
    assert TudouAlbumIE(None) == None


# Generated at 2022-06-22 08:47:10.033840
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://baidu.com', {}, {});



# Generated at 2022-06-22 08:47:21.108717
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_p_id = 'zzdE77v6Mmo'
    test_playlist = TudouPlaylistIE()._real_extract(test_url)
    assert test_playlist['id'] == test_p_id
    assert test_playlist['entries'][0]['id'] == 'XMTUyMjY1OTEwOA', 'The attribute "id" of the 0th video should be "XMTUyMjY1OTEwOA".'

# Generated at 2022-06-22 08:47:31.115265
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_object = TudouPlaylistIE()
    assert tudou_playlist_object.IE_NAME == "TudouPlaylistIE"
    assert tudou_playlist_object._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_object._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_object._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:47:40.686036
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.suitable(
        'https://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    assert ie.suitable(
        'https://www.tudou.com/playlistplay/zzdE77v6Mmo.html') == False
    assert ie.suitable(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    assert ie.suitable(
        'http://www.tudou.com/albumcover/zzdE77v6Mmo.html') == False
    assert ie.suitable(
        'http://www.tudou.com/listplay/zzdE77v6Mmo') == False
    assert ie.su

# Generated at 2022-06-22 08:47:43.383548
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # valid URL, return a true
    assert(TudouPlaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html'))


# Generated at 2022-06-22 08:47:47.133422
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "http://www.tudou.com/listplay/kxlkp0mz4F4.html"
	playlistIE = TudouPlaylistIE()
	assert playlistIE.suitable(url) == True


# Generated at 2022-06-22 08:47:49.340032
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t = TudouAlbumIE('tudou.com', 'v5qckFJvNJg')
	assert(t != None)

# Generated at 2022-06-22 08:47:50.700729
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE is not None
