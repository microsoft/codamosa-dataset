

# Generated at 2022-06-22 08:39:21.057979
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-22 08:39:27.906549
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = r'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    info = TudouAlbumIE()._real_extract(url)
    assert (info['id'] == 'v5qckFJvNJg')
    url = r'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info = TudouAlbumIE()._real_extract(url)
    assert (info['id'] == 'v5qckFJvNJg')

# Generated at 2022-06-22 08:39:30.210542
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import TudouPlaylistIE
	test_object=TudouPlaylistIE.TudouPlaylistIE('test',{})
	test_object.test()
	

# Generated at 2022-06-22 08:39:31.467892
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("Testing constructor of class TudouAlbumIE")
	TudouAlbumIE()

# Generated at 2022-06-22 08:39:36.177291
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tudouAlbum = TudouAlbumIE()
    tudouAlbum.extract(url)

# Generated at 2022-06-22 08:39:42.365639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # url of album
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

    # valid, assert the playlist_mincount
    assert ie.suitable(url)
    playlist_mincount = ie._real_extract(url)['entries']
    assert len(playlist_mincount) == 45

    assert not ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:39:50.889804
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test no duplicates
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_listplay_ie = TudouPlaylistIE(tudou_listplay_ie)
    tudou_listplay_ie._real_extract(url)
    tudou_listplay_ie._real_extract(url)
    tudou_listplay_ie._real_extract(url)

# Generated at 2022-06-22 08:39:52.735310
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a_album = TudouAlbumIE()
    assert a_album is not None


# Generated at 2022-06-22 08:39:54.118188
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pls = TudouAlbumIE("Tudou", "album", "Tudou")

# Generated at 2022-06-22 08:39:57.526872
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        ie = TudouAlbumIE()
    except:
        print("Constructor of class TudouAlbumIE failed.")
        raise

if __name__ == "__main__":
    test_TudouAlbumIE()

# Generated at 2022-06-22 08:40:04.998438
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._VALID_URL)
    assert(TudouAlbumIE._TESTS)

# Generated at 2022-06-22 08:40:05.674838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE('123456')

# Generated at 2022-06-22 08:40:07.923433
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-22 08:40:17.315142
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test.IE_NAME == 'tudou:playlist'
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert 'id' in test._TESTS[0]['info_dict']
    assert test._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:40:26.127953
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Refer to C:/Users/Elaine/PycharmProjects/ipython/you_get/you_get/extractors/tudou.py
    # Line 141

    # initialize TudouPlaylistIE
    TudouPlaylistIE_object = TudouPlaylistIE()

    # set the input value
    TudouPlaylistIE_object.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # call the actual function
    TudouPlaylistIE_object._real_extract(TudouPlaylistIE_object.url)



# Generated at 2022-06-22 08:40:30.013337
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:40:40.553963
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('')
    ie.IE_NAME = 'TudouAlbumIE'
    ie.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.playlist_mincount = 45
    ie.extractor = 'TudouAlbumIE'
    ie.playlist_result = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.id = 'v5qckFJvNJg'
    ie._match_id = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:40:41.705843
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import main
    assert main()



# Generated at 2022-06-22 08:40:46.113708
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou:album')
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:40:48.009862
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE(): 
    from . import tests
    ie = TudouAlbumIE(tests)
    assert ie

# Generated at 2022-06-22 08:40:57.315323
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-22 08:41:07.876169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')
    assert(TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209)


# Generated at 2022-06-22 08:41:19.250288
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	video_id = 'zzdE77v6Mmo'
	the_url = 'http://www.tudou.com/listplay/%s.html' % video_id
	the_class = TudouPlaylistIE
	the_instance = the_class(the_url, video_id)

# Generated at 2022-06-22 08:41:30.109354
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url, "", "", "")
    assert ie.__class__ == TudouAlbumIE
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:41:33.910520
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_TudouIE import _test_InfoExtractor_constructor_url
    _test_InfoExtractor_constructor_url(TudouPlaylistIE, 'http://www.tudou.com/listplay/aw6k28ic_2o.html')


# Generated at 2022-06-22 08:41:37.435043
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = InfoExtractor()
    ie.report_warning('a warning')
    ie.to_screen('test')
    ie.trouble(u'trouble')

# Generated at 2022-06-22 08:41:38.420863
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    infoExtractor = TudouAlbumIE()

# Generated at 2022-06-22 08:41:40.599077
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE(TudouAlbumIE)


# Generated at 2022-06-22 08:41:41.801157
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:41:50.008738
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert(obj._VALID_URL == "http://(?:www.)?tudou\.com/album(?:cover|play)/([\\w-]{11})")

# Generated at 2022-06-22 08:42:02.262892
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:42:08.562336
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('tudou:playlist')
    assert tudou_playlist.ie_key() == 'TudouPlaylist'
    assert tudou_playlist.ie_name() == 'TudouPlaylist'
    assert tudou_playlist.suitable('tudou:playlist') == True
    assert tudou_playlist.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-22 08:42:10.807297
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE(InfoExtractor)
    except Exception:
        assert False

# Generated at 2022-06-22 08:42:13.605705
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

# Generated at 2022-06-22 08:42:24.062062
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create an instance of class TudouPlaylistIE()
    expected_result = TudouPlaylistIE()
    # Check if outer attributes are properly set
    assert expected_result.IE_NAME == 'tudou:playlist'
    assert expected_result._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert expected_result._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:42:26.402692
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou:album')

# Generated at 2022-06-22 08:42:33.417417
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    inst = TudouAlbumIE()
    assert inst._match_id(test_url) == 'v5qckFJvNJg'
    assert inst.IE_NAME == 'tudou:album'
    assert inst._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert inst._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert inst._TESTS[0]['playlist_mincount'] == 45
    assert inst._TESTS

# Generated at 2022-06-22 08:42:34.345477
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE()
	assert obj

# Generated at 2022-06-22 08:42:39.847980
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(url)
    assert isinstance(tudou_playlist_ie, TudouPlaylistIE)


# Generated at 2022-06-22 08:42:45.956488
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-22 08:43:17.933409
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Start unit test for constructor of class TudouAlbumIE")
    ie = TudouAlbumIE("www.tudou.com/albumcover/v5qckFJvNJg.html")
    assert ie.url == "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    print("Finished unit test for constructor of class TudouAlbumIE")


# Generated at 2022-06-22 08:43:26.022859
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """
    # when: call constructor of class TudouPlaylistIE with no parameter
    tudou_playlist_ie = TudouPlaylistIE()

    # then: name should be set to 'tudou:playlist'
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'

    # and: valid url should be set to regular expression
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-22 08:43:27.801053
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE({})
	return isinstance(obj, InfoExtractor)


# Generated at 2022-06-22 08:43:29.458011
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-22 08:43:38.874333
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .tudou import InfoExtractor
    from .tudou import extract_format
    from .common import playlist_mincount
    import re
    import urlparse
    assert TudouAlbumIE.__bases__[0] == InfoExtractor
    assert TudouAlbumIE._VALID_URL == re.compile(r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:43:48.797092
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tests = [
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }
    ]

    for test in tests:
        url = test['url']
        album_id = 'v5qckFJvNJg'
        album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
        # test
        assert TudouAlbumIE._download_json(album_data, album_id) == test['info_dict']

# Generated at 2022-06-22 08:43:59.701285
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    _TudouPlaylistIE = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    _TudouPlaylistIE.url
    assert _TudouPlaylistIE._VALID_URL == r'https?://(?:www\.|player\.)?tudou\.com/[pt]?/[^#?/]+/(?:[^#?/]+/)*(?P<id>\d+)[#?]?'
    _TudouPlaylistIE.url_result('programs', 'Tudou')
    _TudouPlaylistIE.playlist_result('playlist')
    assert _TudouPlaylistIE.playlist_count == 0

# Generated at 2022-06-22 08:44:06.197615
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  test_obj = TudouPlaylistIE()
  assert test_obj.IE_NAME == 'tudou:playlist'
  assert test_obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
  assert test_obj._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-22 08:44:16.895720
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import HEADRequest
    from .tudou import TudouIE
    from .tudou import TudouAlbumIE
    from .tudou import _extract_tudou_id
    from .tudou import _extract_tudou_info
    from urllib.parse import urlparse
    from urllib.parse import parse_qs
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    #Constructor of class InfoExtractor
    ie = TudouAlbumIE(TudouIE(), _extract_tudou_id.__name__, url, {}, {}, {})
    #Constructor of class InfoExtractor

# Generated at 2022-06-22 08:44:20.320660
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-22 08:45:29.371932
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-22 08:45:31.182224
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:45:33.520296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:45:41.116575
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    e = TudouPlaylistIE()

    assert e.IE_NAME == 'tudou:playlist'
    assert e._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert e._TESTS == [
        {
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }
    ]


# Generated at 2022-06-22 08:45:52.261973
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test constructor of class TudouAlbumIE
    """
    tudou_album_ie = TudouAlbumIE
    # Test in case: given url already contains http://
    url='http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_extracted_id='v5qckFJvNJg'
    extracted_id = tudou_album_ie._match_id(url)
    assert extracted_id==expected_extracted_id
    # Test in case: given url does not contain http://
    url='www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_extracted_id='v5qckFJvNJg'
    extracted_id = tudou_album_ie._

# Generated at 2022-06-22 08:46:01.799286
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test 1:
    tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-22 08:46:12.162730
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test 1: "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    # URI: "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    expected = (
        "tudou:album",
        True
    )
    assert (
        TudouAlbumIE.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html"),
        True
    ) == expected

    # Test 2: "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    # URI: "http://www.tudou.com/albumcover/v5qckFJvNJg.html"

# Generated at 2022-06-22 08:46:22.068857
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert obj._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:46:22.987243
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-22 08:46:29.646826
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    class_test = TudouPlaylistIE()
    assert class_test.IE_NAME == 'tudou:playlist'
    assert class_test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert class_test._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-22 08:48:55.749076
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test with invalid url
    invalid_url = 'https://www.tudou.com/listplay/zzdz.html'
    assert TudouPlaylistIE._match_id(invalid_url) is None
    assert TudouPlaylistIE._real_extract(invalid_url) is None
    # Test with valid url
    valid_url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._match_id(valid_url) == 'zzdE77v6Mmo'
    assert isinstance(TudouPlaylistIE._real_extract(valid_url), dict)


# Generated at 2022-06-22 08:49:03.424473
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    expectUrl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expectUrl2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'

    actual = TudouAlbumIE._match_id(expectUrl)
    assert actual == 'v5qckFJvNJg', actual
    actual2 = TudouAlbumIE._match_id(expectUrl2)
    assert actual2 == 'v5qckFJvNJg', actual2

test_TudouAlbumIE()


# Generated at 2022-06-22 08:49:06.308631
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-22 08:49:08.649498
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._match_id(ie._VALID_URL) == ie._VALID_URL.split('/')[-1].split('.')[0]


# Generated at 2022-06-22 08:49:11.876956
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE()._real_extract(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html'), dict)

# Generated at 2022-06-22 08:49:23.307859
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert hasattr(TudouAlbumIE, 'IE_NAME')
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert hasattr(TudouAlbumIE, '_TESTS')
    assert hasattr(TudouAlbumIE, '_real_extract')
    # test _real_extract function
    from ytdl.extractor import YoutubePlaylistIE
    from ytdl.extractor import YoutubeIE
    test_url = 'https://www.tudou.com/albumcover/IRDEwIz0WtQ.html'
    assert TudouAlbumIE._real_extract(YoutubePlaylistIE(), test_url) == \
        YoutubePlaylistIE()._real_extract(test_url)
    assert TudouAlbumIE._real_ext