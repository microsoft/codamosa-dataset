

# Generated at 2022-06-22 08:39:29.294726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-22 08:39:31.911895
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	i = TudouPlaylistIE()

# Generated at 2022-06-22 08:39:36.320126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist is not None


# Generated at 2022-06-22 08:39:38.127184
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie is not None

# Generated at 2022-06-22 08:39:46.994443
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test invalid URL
    tudou_playlist = TudouPlaylistIE()  # constructor
    assert tudou_playlist._real_extract('http://www.tudou.com/a/B3qYfZC-k7c') is None
    # test valid URL
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()  # constructor again
    assert tudou_playlist._real_extract(test_url) is not None



# Generated at 2022-06-22 08:39:47.884160
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE is not None)

# Generated at 2022-06-22 08:39:56.321629
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	info = TudouPlaylistIE._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	assert(info['id'] == 'zzdE77v6Mmo')
	assert(info['playlist_mincount'] == 209)
	assert(info['entries'][0]['id'] == 'oD0jxnfX9wo')
	assert(info['entries'][1]['id'] == 'BfYtaCr8dmo')
	assert(info['entries'][2]['id'] == 'NzKGYbNDcY0')


# Generated at 2022-06-22 08:40:03.097612
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                          'info_dict': {'id': 'zzdE77v6Mmo'},
                          'playlist_mincount': 209
                          }]



# Generated at 2022-06-22 08:40:06.553368
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-22 08:40:09.625013
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE()
	test._download_json()


# Generated at 2022-06-22 08:40:16.031100
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'Tudou'


# Generated at 2022-06-22 08:40:26.983512
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }
    playlist_id = ie._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-22 08:40:36.843241
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import json
    import requests
    class test_case(unittest.TestCase):
        def setUp(self):
            self.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
            self.album_id = 'v5qckFJvNJg'
            self.album_data = requests.get(
                'http://www.tudou.com/tvp/alist.action?acode=%s' % self.album_id)
            self.album_data = json.loads(self.album_data.text)

        def test_get_album_id(self):
            ie = TudouAlbumIE(TudouAlbumIE.suitable(self.url))
            album_id = ie._match_id

# Generated at 2022-06-22 08:40:46.680483
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:40:50.381403
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    for item in TudouPlaylistIE._TESTS:
        url = item['url']
        tudou_playlist_object = TudouPlaylistIE()
        tudou_playlist_object._real_extract(url)


# Unit test of constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:40:58.220405
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info_dict = {
        'id': 'v5qckFJvNJg',
    }
    playlist_mincount = 45

    o = TudouAlbumIE(url)

    assert o._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert o.IE_NAME == 'tudou:album'
    assert o.test() == True
    assert o._real_extract(o._VALID_URL) != None
    assert o.test() == True

# Generated at 2022-06-22 08:41:00.839531
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test: Constructor of class TudouPlaylistIE
	# Expect: The instance object should be created
	TudouPlaylistIE()


# Generated at 2022-06-22 08:41:02.307023
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    playlist.to_screen(playlist)

# Generated at 2022-06-22 08:41:05.794668
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE.ie_key() == 'TudouPlaylist')
	assert(TudouPlaylistIE._VALID_URL == TudouPlaylistIE._TESTS[0].get('url'))


# Generated at 2022-06-22 08:41:11.081662
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
  TudouPlaylistIE(url)


# Generated at 2022-06-22 08:41:21.897761
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_URL = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(tudou_URL)
    album_id = ie._match_id(tudou_URL)
    assert album_id == 'v5qckFJvNJg'


# Generated at 2022-06-22 08:41:31.845494
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from .common import InfoExtractor
	import re
	from .tudou import TudouPlaylistIE

	# Test case 1: valid url
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert TudouPlaylistIE._VALID_URL == re.compile(TudouPlaylistIE._VALID_URL)
	mobj = TudouPlaylistIE._VALID_URL.match(url)
	assert mobj is not None
	assert mobj.group('id') == 'zzdE77v6Mmo'

# Generated at 2022-06-22 08:41:36.744002
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:41:45.228062
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist';
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html';
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}];

# Generated at 2022-06-22 08:41:54.062847
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:41:57.360986
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_IE = TudouAlbumIE(None)
    assert tudou_album_IE._VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"

# Generated at 2022-06-22 08:42:05.034712
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouAlbumIE', {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'}, {'extractor': 'TudouAlbumIE'})
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-22 08:42:06.750483
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test for constructor of class TudouAlbumIE."""
    pass

# Generated at 2022-06-22 08:42:10.522245
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(None)._VALID_URL == \
    r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-22 08:42:11.547817
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-22 08:42:31.261873
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()
    assert ie.match_url(url)
    assert ie.IE_NAME == "tudou:playlist"
    assert ie.VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.TESTS == [
        {
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }
    ]



# Generated at 2022-06-22 08:42:33.864400
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE()

# Generated at 2022-06-22 08:42:38.404595
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    sample_url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    assert TudouAlbumIE._TESTS[0]['url'] == sample_url

# Generated at 2022-06-22 08:42:43.280698
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/wewyNxR_yp8.html'
    ie = TudouAlbumIE()
    assert ie.suitable(ie.IE_NAME, url)
    print(ie._real_extract(url))
    print(ie)


# Generated at 2022-06-22 08:42:44.925894
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-22 08:42:46.332397
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t != None

# Generated at 2022-06-22 08:42:47.323496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()


# Generated at 2022-06-22 08:42:50.451409
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    assert TudouAlbumIE({}, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-22 08:42:52.464200
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_class = TudouPlaylistIE()
    assert playlist_class._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-22 08:42:54.853090
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert "TudouPlaylistIE(ie_key='tudou:playlist')" == str(TudouPlaylistIE)

# Generated at 2022-06-22 08:43:21.135783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()



# Generated at 2022-06-22 08:43:25.693060
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE(url='http://www.tudou.com/albumplay/v5qckFJvNJg.html')

    assert(tudou_album_ie.IE_NAME == 'tudou:album')
    assert(tudou_album_ie.ie_key() == 'TudouAlbum')


# Generated at 2022-06-22 08:43:35.825835
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE({'id':'zzdE77v6Mmo', 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'})
    assert ie.IE_NAME=='tudou:playlist' #passed!
    assert ie.VALID_URL=='https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' #passed!

# Generated at 2022-06-22 08:43:38.523995
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case = TudouPlaylistIE()
    assert isinstance(test_case, InfoExtractor) == True


# Generated at 2022-06-22 08:43:39.788506
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:43:46.906214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_album_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE()
    assert ie.suitable(test_album_url) == True, "Should be a valid URL!"
    assert ie.IE_NAME == 'tudou:album', 'Should be a tudou album url!'
    ie.extract(test_album_url)


# Generated at 2022-06-22 08:43:58.444386
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'GgYvYsvW1l8'

# Generated at 2022-06-22 08:44:05.539196
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistIE = TudouPlaylistIE()
    tudouplaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudouplaylistIE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'



# Generated at 2022-06-22 08:44:08.559688
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()

# Generated at 2022-06-22 08:44:09.464230
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:45:16.337895
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_initialize()

# Generated at 2022-06-22 08:45:18.140601
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_string = "The constructor of class TudouPlaylistIE is called."
    print(test_string)


# Generated at 2022-06-22 08:45:29.034467
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:45:33.737095
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   """unit test for constructor"""
   tudouAlbumIE = TudouAlbumIE("www.tudou.com/albumplay/v5qckFJvNJg.html")
   print("The url is: " + tudouAlbumIE._VALID_URL)

# Generated at 2022-06-22 08:45:34.708997
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None)


# Generated at 2022-06-22 08:45:42.086187
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  obj = TudouAlbumIE()
  assert obj.IE_NAME == 'tudou:album'
  assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
  assert obj._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-22 08:45:51.331321
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    s = TudouPlaylistIE()
    assert s.IE_NAME == 'tudou:playlist'
    assert s._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert s._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert s._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert s._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-22 08:45:53.252421
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-22 08:46:00.726524
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = '{ "totalCount": 209, "items": [{ "kw": "", "icode": "Bz_OtM23x0Y" }]}'

    ie = TudouPlaylistIE()
    ie._download_webpage = mock_download_json(playlist_data)

    result = ie._real_extract(url)

    assert result['id'] == playlist_id


# Generated at 2022-06-22 08:46:11.294875
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/([\w-]{11})'
    assert TudouAlbumIE._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]

# Generated at 2022-06-22 08:48:44.146992
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album = TudouAlbumIE()
    assert tudou_album._match_id(url) == album_id
    assert tudou_album._real_extract(url)

# Generated at 2022-06-22 08:48:55.991535
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-22 08:49:00.159848
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.playlist_id == 'zzdE77v6Mmo'
    assert ie.playlist_mincount == 209

# Generated at 2022-06-22 08:49:01.075082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-22 08:49:04.065551
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class TestClass(TudouAlbumIE):
        def __init__(self):
            return
        def _real_extract(self, url):
            return
    result = TestClass()
    assert isinstance(result,TestClass)

# Generated at 2022-06-22 08:49:14.140379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Assert instance attributes are initialized properly
    assert TudouPlaylistIE._VALID_URL is not None
    assert TudouPlaylistIE._TESTS is not None
    assert TudouPlaylistIE.IE_NAME is not None
    assert TudouPlaylistIE.ie_key() is not None
    assert TudouPlaylistIE.ie_key() == TudouPlaylistIE.IE_NAME

    # Assert instance methods are defined properly
    assert hasattr(TudouPlaylistIE, '_real_extract')
    assert callable(getattr(TudouPlaylistIE, '_real_extract'))
    assert hasattr(TudouPlaylistIE, '_real_initialize')
    assert callable(getattr(TudouPlaylistIE, '_real_initialize'))

# Generated at 2022-06-22 08:49:16.697620
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'

test_TudouAlbumIE()