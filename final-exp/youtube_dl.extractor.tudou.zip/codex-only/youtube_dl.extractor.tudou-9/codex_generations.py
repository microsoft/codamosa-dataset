

# Generated at 2022-06-24 13:29:10.618412
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass
    # Should be a test for tudou:playlist


# Generated at 2022-06-24 13:29:14.601202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url_playlist = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(TudouPlaylistIE.IE_NAME, url_playlist, 'tudou:playlist')


# Generated at 2022-06-24 13:29:15.558065
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:21.508176
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()
# We use try and except block to handle probable exceptions
try:
	TudouPlaylistIE()
# if all goes well, except block is not executed
except Exception as e:
	print("Exception occured |%s " % e)
# if exception occurs, control flows to except block and it is executed
finally:
	print("Finally block is always executed")

# Generated at 2022-06-24 13:29:28.513702
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert ie._TESTS == [{
		'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
		'info_dict': {
			'id': 'v5qckFJvNJg',
		},
		'playlist_mincount': 45,
	}]


# Generated at 2022-06-24 13:29:29.022617
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

# Generated at 2022-06-24 13:29:31.623229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:29:41.922748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()

    assert(tudou_album_ie.IE_NAME) == 'tudou:album'
    assert(tudou_album_ie._VALID_URL) == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:29:44.952284
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.checksum == ie._valid_url(
        ie._TESTS[0]['url'])['id']

# Generated at 2022-06-24 13:29:46.644493
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(TudouPlaylistIE.ie_key())


# Generated at 2022-06-24 13:29:47.994736
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE
    assert i is not None

# Generated at 2022-06-24 13:29:57.150483
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test for url 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # test for url 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    album_id = 'v5qckFJvNJg'
    album_data = tudou_album_ie._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)


# Generated at 2022-06-24 13:29:58.740563
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj

# Test case for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:30:01.878250
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().get_playlist("http://www.tudou.com/listplay/zzdE77v6Mmo.html") is not None


# Generated at 2022-06-24 13:30:02.951897
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:30:09.171232
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/"
    ie = TudouAlbumIE(url=url)
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(ie.IE_NAME == 'tudou:album')

# Generated at 2022-06-24 13:30:10.528263
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo')


# Generated at 2022-06-24 13:30:15.485081
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().name == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:30:17.703593
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test constructor of class TudouAlbumIE"""
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'


# Generated at 2022-06-24 13:30:26.753400
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'TudouPlaylist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'})
    assert(ie._TESTS[0]['playlist_mincount'] == 209)




# Generated at 2022-06-24 13:30:34.624713
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = TudouPlaylistIE(None)
    #assert that the IE_NAME is set to the IE_NAME of the class
    assert infoExtractor.IE_NAME == 'tudou:playlist'
    #assert that the _VALID_URL is set to the _VALID_URL of the class
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    #assert that the _TESTS is set to the _TESTS of the class

# Generated at 2022-06-24 13:30:39.377307
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import soupselect
    import requests

    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    r = requests.get(url)
    n = soupselect.select(r.text, 'body')

# Generated at 2022-06-24 13:30:42.175483
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE._VALID_URL)


# Generated at 2022-06-24 13:30:43.125739
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE();

# Generated at 2022-06-24 13:30:45.011148
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_obj = TudouAlbumIE()
    assert test_obj.ie_key() == 'Tudou'
    assert test_obj.ie_name() == 'tudou:album'

# Generated at 2022-06-24 13:30:50.824278
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE, InfoExtractor)
    assert isinstance(TudouAlbumIE.IE_NAME, object)
    assert isinstance(TudouAlbumIE._VALID_URL, object)
    assert isinstance(TudouAlbumIE._TESTS, list)


# Generated at 2022-06-24 13:30:57.426610
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.match_url(url) == 'zzdE77v6Mmo'
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'tudou:playlist'


# Generated at 2022-06-24 13:31:08.446273
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test_TudouAlbumIE.data = {'_type': 'url', 'ie_key': 'Tudou', 'url': url, 'title': 'NewsStand', 'id': 'v5qckFJvNJg'}
    test_TudouAlbumIE.extractor = TudouAlbumIE(test_TudouAlbumIE.data)
    test_TudouAlbumIE.playlist_id = test_TudouAlbumIE.extractor._match_id(url)
    assert test_TudouAlbumIE.playlist_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:17.556719
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # create a MockInfoExtractor instance for testing
    mock_ie = InfoExtractor(
        downloader=None,
        ie_key='TudouPlaylist',
        ie_name='TudouPlaylist',
        ie_version=1
    )
    # create a Mock instance for testing
    mock_downloader = Mock()

    # create a real TudouPlaylistIE instance for testing
    tudou_playlist = TudouPlaylistIE(mock_downloader, mock_ie)

    # test method _real_extract

# Generated at 2022-06-24 13:31:23.968476
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:31:32.131015
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test constructor of class TudouAlbumIE
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE()
    assert ie._match_id(url) == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert ie.IE_NAME == 'tudou:album'
    assert ie.SITE_NAME == 'tudou'

# Generated at 2022-06-24 13:31:40.943445
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE().IE_NAME == 'tudou:playlist')
    assert(TudouPlaylistIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE()._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'playlist_mincount': 209, 'info_dict': {'id': 'zzdE77v6Mmo'}}])


# Generated at 2022-06-24 13:31:42.829099
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.extract()


# Generated at 2022-06-24 13:31:50.454720
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # pylint: disable = E1101, C0301
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'TudouPlaylist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # assert ie._TESTS is a list
    assert ie.IE_NAME in globals()
    assert ie.IE_DESC in globals()


# Generated at 2022-06-24 13:31:56.863217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    input_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert TudouAlbumIE()._match_id(input_url) == 'v5qckFJvNJg'
    print('Test of class TudouAlbumIE constructing successfully!\n')


# Generated at 2022-06-24 13:31:59.874196
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test for constructor of class TudouAlbumIE"""

    tudou_albumie = TudouAlbumIE()
    assert tudou_albumie


# Generated at 2022-06-24 13:32:04.903082
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/V_f0jdF04Xs.html'
    ie = TudouPlaylistIE({})
    oe = ie.extract(url)
    assert oe.get('id') == 'V_f0jdF04Xs'

# Generated at 2022-06-24 13:32:10.368259
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import make_a_get_request
    from .tudou import TudouAlbumIE
    from .tudou import TudouIE

    assert isinstance(TudouAlbumIE.suitable(make_a_get_request('http://www.tudou.com/albumplay/v5qckFJvNJg.html')), bool)
    assert not TudouAlbumIE.suitable(make_a_get_request('http://www.tudou.com/programs/view/v5qckFJvNJg'))
    assert isinstance(TudouAlbumIE(TudouIE.IE_NAME), TudouAlbumIE)



# Generated at 2022-06-24 13:32:15.453175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    

# Generated at 2022-06-24 13:32:20.316084
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # test valid url
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # test invalid url
    ie.extract('http://www.tudou.com/listplay/zzdE77v6M.html')

# Generated at 2022-06-24 13:32:21.278836
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None)

# Generated at 2022-06-24 13:32:23.592950
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert str(ie.__class__) == "<class 'tudou.TudouPlaylistIE'>"


# Generated at 2022-06-24 13:32:30.248849
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert_equal(i._extract_playlist(
        'https://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'zzdE77v6Mmo'),
        ['https://www.tudou.com/programs/view/oMIif2A7Muo/'])


# Generated at 2022-06-24 13:32:38.944620
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    "test constructor of class TudouPlaylistIE"
    tudou = TudouPlaylistIE("test", "http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudou.IE_NAME == "tudou:playlist"
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:32:42.129358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE.test('https://www.tudou.com/albumcover/v5qckFJvNJg.html');

# Generated at 2022-06-24 13:32:43.811111
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-24 13:32:46.587834
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist = TudouPlaylistIE()
	assert(tudou_playlist.IE_NAME == 'tudou:playlist')




# Generated at 2022-06-24 13:32:49.285428
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie_obj = TudouPlaylistIE()
    ie_obj._real_extract(test_url)



# Generated at 2022-06-24 13:32:50.364626
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

# Generated at 2022-06-24 13:32:54.488052
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(None)
    ie._downloader = None
    info = ie.extract(url)
    assert len(info) == 1
    assert info['id'] == 'zzdE77v6Mmo'
    assert len(info['entries']) == 209


# Generated at 2022-06-24 13:33:00.067317
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t=TudouAlbumIE()

# Generated at 2022-06-24 13:33:03.298477
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:33:04.283111
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO
    pass


# Generated at 2022-06-24 13:33:05.229644
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert None == "TudouAlbumIE"

# Generated at 2022-06-24 13:33:08.510435
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == {
        'entries': [],
        'id': 'v5qckFJvNJg',
        'title': 'v5qckFJvNJg',
        '_type': 'playlist'
    }

# Generated at 2022-06-24 13:33:10.735191
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for constructor of class TudouPlaylistIE
    assert TudouPlaylistIE(None, None).ie_key() == 'TudouPlaylist'

# Generated at 2022-06-24 13:33:11.760673
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert (1==1)


# Generated at 2022-06-24 13:33:15.023766
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.extract(url)

# Generated at 2022-06-24 13:33:20.006091
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:33:23.744660
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
        test constructor of class TudouAlbumIE
        """
    ie = TudouAlbumIE("1234567890")
    assert ie.ie_key() == 'Tudou'
    return 1



# Generated at 2022-06-24 13:33:28.120983
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Constructor call
    tudou_playlist = TudouPlaylistIE()

    # Asserting the class variable _VALID_URL is the same as the one we defined in the class
    assert(tudou_playlist._VALID_URL == TudouPlaylistIE._VALID_URL)

# Generated at 2022-06-24 13:33:33.870487
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Successful case
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)
    assert type(ie.ie_key()) is str

    # Fail case
    context = dict()
    context['IE_NAME'] = 'tudou:playlist'
    ie = TudouPlaylistIE(context)
    assert isinstance(ie, InfoExtractor)
    assert type(ie.ie_key()) is str


# Generated at 2022-06-24 13:33:45.013293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                          'info_dict': {'id': 'zzdE77v6Mmo'},
                          'playlist_mincount': 209}]
    assert ie._match_id(url) == 'zzdE77v6Mmo'

#

# Generated at 2022-06-24 13:33:49.289797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return TudouPlaylistIE(TudouPlaylistIE._downloader)._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')

# Generated at 2022-06-24 13:33:58.136717
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:34:09.804328
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .constructors import unit_tester
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:34:11.325514
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie


# Generated at 2022-06-24 13:34:13.918802
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:34:14.857671
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    maintest = TudouAlbumIE()

# Generated at 2022-06-24 13:34:16.025664
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    obj._match_id('')
    obj._real_extract('')

# Generated at 2022-06-24 13:34:19.376719
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE(test_TudouPlaylistIE)
    assert 'TudouPlaylist' in str(playlist)

# Generated at 2022-06-24 13:34:24.870334
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Testing TudouAlbumIE Constructor")
    expected = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    album = TudouAlbumIE("http://www.tudou.com/albumcover/v5qckFJvNJg")
    assert expected == album._VALID_URL


# Generated at 2022-06-24 13:34:35.537263
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:34:38.188199
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE
    assert tudou_album.IE_NAME == 'tudou:album'



# Generated at 2022-06-24 13:34:48.044577
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert t._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:34:53.792884
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import test_get_pages
    
    info_page = test_get_pages(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    album_id = 'v5qckFJvNJg'
    album_data = info_page["TudouAlbumIE"]["album_data"]
    entries = info_page["TudouAlbumIE"]["entries"]



# Generated at 2022-06-24 13:34:55.273202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(_VALID_URL) != None


# Generated at 2022-06-24 13:35:03.228186
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from .tudou import TudouPlaylistIE
	import json

# Generated at 2022-06-24 13:35:08.941306
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_param = ['http://www.tudou.com/albumcovers/v5qckFJvNJg.html','http://www.tudou.com/albumplay/v5qckFJvNJg.html','http://www.tudou.com/albumplay/v5qckFJvNJg.html']
    for url in test_param:
        TudouAlbumIE(url)._real_extract(url)

# Generated at 2022-06-24 13:35:10.744583
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    assert isinstance(TudouAlbumIE(), TudouAlbumIE)

# Generated at 2022-06-24 13:35:13.393991
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Testing TudouPlaylistIE constructor')
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url, {})


# Generated at 2022-06-24 13:35:14.973175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('Tudou')
    print("Passed!")

# Generated at 2022-06-24 13:35:18.548385
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(album.__class__)
    assert 1 == 1


# Generated at 2022-06-24 13:35:21.180188
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	result = TudouPlaylistIE.suitable(TudouPlaylistIE._VALID_URL)
	assert result == True



# Generated at 2022-06-24 13:35:30.789318
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    _TESTS = [{
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }]
    assert playlist._TESTS == _TESTS

# Generated at 2022-06-24 13:35:37.507478
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    response = requests.get('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    response.encoding = 'gbk'
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    # Select tags with class "tv_title"
    tags = soup.select('.tv_title')
    # Select text from tags with class "tv_title"
    titles = [tag.text for tag in tags]
    #print(titles)
    assert True
    

# Generated at 2022-06-24 13:35:38.416176
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-24 13:35:46.871873
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:56.118385
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import test_playlist
    TestPlaylist = test_playlist.TudouPlaylistIE
    TestPlaylist.TEST = [{
        'add_ie': ['Tudou', 'TudouAlbum'],
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    TestPlaylist().test()
    TestPlaylist().test() # test twice to make sure playlist will not be broken by previous run


# Generated at 2022-06-24 13:35:57.035524
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ts = TudouAlbumIE("test","test2","test3")
	print("test")

# Generated at 2022-06-24 13:35:58.760044
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE._TESTS[0]['url'] == url



# Generated at 2022-06-24 13:35:59.596318
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(), InfoExtractor)


# Generated at 2022-06-24 13:36:03.694265
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    td_pe = TudouPlaylistIE()
    assert td_pe.IE_NAME == 'tudou:playlist'
    assert td_pe._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:36:05.799286
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
     # Constructor of TudouPlaylistIE should require playlist_id
    with pytest.raises(TypeError):
        ie = TudouPlaylistIE(None)

# Generated at 2022-06-24 13:36:07.714427
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
        from unit.test_tudou import test_TudouAlbumIE
        test_TudouAlbumIE()

# Generated at 2022-06-24 13:36:09.028769
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE.suite()


# Generated at 2022-06-24 13:36:14.534117
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Just make sure that class can be instantiated.
    #
    # The URL itself will not be touched.

    from .common import InfoExtractor

    _VALID_URL = r'^https?://www.tudou.com/listplay/(.+)$'

    ie = InfoExtractor(TudouPlaylistIE._VALID_URL)
    ie = InfoExtractor(TudouAlbumIE._VALID_URL)

# Generated at 2022-06-24 13:36:16.856628
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:36:20.078264
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    myclass = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert myclass.IE_NAME == "tudou:playlist"



# Generated at 2022-06-24 13:36:21.213318
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE()


# Generated at 2022-06-24 13:36:27.065976
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(InfoExtractor)
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:36:31.043126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('www', 'tudou.com', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', {})
    assert ie.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-24 13:36:34.957664
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:35.971274
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:40.040592
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj.name == 'tudou:playlist'
    assert obj.ie_key() == 'TudouPlaylist'
    assert 'http://www.tudou.com/listplay/' in obj._VALID_URL


# Generated at 2022-06-24 13:36:44.410352
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:45.367087
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:53.579716
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Test
	test = TudouAlbumIE()
	assert (test.IE_NAME == "tudou:album")
	assert (test._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
	assert (test._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }])

# Generated at 2022-06-24 13:36:55.434253
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:37:03.408907
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for extracting playlist id
    assert TudouPlaylistIE._match_id(TudouPlaylistIE._VALID_URL) == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._match_id(TudouPlaylistIE._VALID_URL) == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._match_id(TudouPlaylistIE._VALID_URL) == 'zzdE77v6Mmo'
    # Test for _extract_playlist_entries() method
    m = TudouPlaylistIE()
    m._extract_playlist_entries()
    # Test for _real_extract() method
    m._real_extract(TudouPlaylistIE._VALID_URL)

# Generated at 2022-06-24 13:37:04.309386
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	global extractor
	extractor = TudouPlaylistIE()


# Generated at 2022-06-24 13:37:11.361737
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("\ntest_TudouAlbumIE")
    urls = [
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
    ]
    for url in urls:
        TudouAlbumIE()._real_extract(url)

# Generated at 2022-06-24 13:37:12.914784
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t != None


# Generated at 2022-06-24 13:37:17.168291
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor()
    ie.add_info_extractor('TudouPlaylist', TudouPlaylistIE)

# Generated at 2022-06-24 13:37:20.359317
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:27.800862
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj._get_video_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
    assert obj._get_video_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:37.988649
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("test_TudouPlaylistIE")
    #test url: http://www.tudou.com/listplay/_PJ0KjezBbo/cIdJxgLBPH0.html
    #url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    #url = 'http://www.tudou.com/listplay/cIdJxgLBPH0.html'
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo/cIdJxgLBPH0.html'
    info = TudouPlaylistIE()._real_extract(url)
    print(info)

# test_TudouPlaylistIE()



# Generated at 2022-06-24 13:37:44.308447
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert len(obj._TESTS) == 1
    assert obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert obj._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert obj._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:37:47.234753
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test if the object is instance of class InfoExtractor
    assert isinstance(TudouAlbumIE(), InfoExtractor)


# Generated at 2022-06-24 13:37:53.504502
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:54.653131
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()

# Generated at 2022-06-24 13:38:02.922264
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
	assert(TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])
	return


# Generated at 2022-06-24 13:38:11.141575
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """

# Generated at 2022-06-24 13:38:22.013526
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test case: http://www.tudou.com/listplay/bJ8LSxabCGQ.html
    tudou_playlist_ie = TudouPlaylistIE("http://www.tudou.com/listplay/bJ8LSxabCGQ.html")
    assert tudou_playlist_ie.ie_name == "tudou:playlist"
    assert tudou_playlist_ie.playlist_id == "bJ8LSxabCGQ"
    assert tudou_playlist_ie.url == "http://www.tudou.com/listplay/bJ8LSxabCGQ.html"

    # test case: http://www.tudou.com/listplay/zzdE77v6Mmo.html

# Generated at 2022-06-24 13:38:31.161388
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    playlist_id = 'v5qckFJvNJg'
    playlist_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info_dict = {}
    info_dict['id'] = playlist_id
    playlist_mincount = 45
    info_dict['playlist_mincount'] = playlist_mincount

    obj = TudouAlbumIE()

    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:38:32.284110
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:38:39.382487
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlist_id = "zzdE77v6Mmo"
	playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	playlist_ie = TudouPlaylistIE(playlist_id, playlist_url)

# Generated at 2022-06-24 13:38:40.710353
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie != None


# Generated at 2022-06-24 13:38:51.585825
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE.suitable(url)
    assert tudouPlaylistIE._VALID_URL.match(url)
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert tudouPlaylistIE._TESTS[0]['url'] == url
    assert tudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:39:02.913765
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import re
    import json
    import urllib
    import urllib2

    # Test arguments
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    # Test attributes
    assert ie.ie_key() == 'tudou:playlist'
    # Test functions
    assert ie._real_extract(None) is None
    assert ie._real_extract(url) is not None
    assert ie._real_extract(url) == {
        'id': u'zzdE77v6Mmo',
        'entries': [],
        '_type': u'playlist',
    }
    assert ie._match_id(None) is None
    assert ie._match_id(url) == u

# Generated at 2022-06-24 13:39:05.494874
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:39:06.572629
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()

# Generated at 2022-06-24 13:39:15.285224
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE({})
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']
    assert ie._TESTS[0]['playlist_mincount'] == 209