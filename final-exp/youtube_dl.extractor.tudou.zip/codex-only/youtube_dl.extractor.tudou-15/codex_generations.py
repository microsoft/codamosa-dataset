

# Generated at 2022-06-24 13:29:14.974991
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.suitable('https://www.tudou.com/listplay/8Wn9Xe-V7_c.html?lcode=8Wn9Xe-V7_c')
    assert not TudouPlaylistIE.suitable('https://www.tudou.com/listplay/8_c.html?lcode=8Wn9Xe-V7_c')
    assert not TudouPlaylistIE.suitable('https://www.tudou.com/tag/tag.action?tagName=%E5%A4%B4%E6%9D%A1%E6%90%9C%E7%B4%A2&pageNo=1')

# Generated at 2022-06-24 13:29:17.959255
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-24 13:29:28.143423
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:29:29.878976
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE('www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:29:36.180514
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.SUFFIX == '.html'
    assert ie.SEARCH_KEY == 'zzdE77v6Mmo'
    assert ie.URL_TEMPLATE == 'http://www.tudou.com/tvp/plist.action?lcode={id}'


# Generated at 2022-06-24 13:29:47.303163
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    testcases = [
        (
            'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
        ),
        (
            'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
            'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
        )
    ]
    for url, expected_url in testcases:
        album_ie = TudouAlbumIE(TudouAlbumIE.ie_key())
        assert(expected_url == album_ie._get_album_url(url))



# Generated at 2022-06-24 13:29:51.288807
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor('tudou:playlist','https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DE

# Generated at 2022-06-24 13:29:54.371393
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    assert a
    assert a._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:29:57.756016
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:29:59.568239
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    Instance = TudouPlaylistIE()
    assert Instance.IE_NAME == 'tudou:playlist'
# Test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:30:11.048180
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    # case 1: Valid item from a valid JSON response
    """
    album_id = "v5qckFJvNJg"

# Generated at 2022-06-24 13:30:13.378524
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == TudouAlbumIE._VALID_URL


# Generated at 2022-06-24 13:30:23.378708
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' 
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 
                                         'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylist

# Generated at 2022-06-24 13:30:28.336666
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()
    assert(TudouPlaylistIE._VALID_URL == url)
    assert(TudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(TudouPlaylistIE._TESTS[0]['url'] == url)


# Generated at 2022-06-24 13:30:35.949651
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.IE_NAME == "Tudou"

# Generated at 2022-06-24 13:30:38.928439
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Better place to put this test case?
    # As there are a lot of similar cases, this test can be a template.
    TudouAlbumIE()

# Generated at 2022-06-24 13:30:43.631851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouIE = TudouPlaylistIE()
    result = tudouIE.get_video_id(url="http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert result == "zzdE77v6Mmo"


# Generated at 2022-06-24 13:30:49.384073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    p = TudouPlaylistIE()
    # Tests if the url is valid
    assert p._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Tests if the url matches the regex
    assert p._match_id('zzdE77v6Mmo') == 'zzdE77v6Mmo'
    # Tests if the url is valid
    assert p.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    # Tests if the playlist_id is returned correctly

# Generated at 2022-06-24 13:30:53.899633
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:01.966461
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import album
    import unittest

    class TestTudouAlbumIE(unittest.TestCase):
        def setUp(self):
            self.test_class = album.TudouAlbumIE()

        def test_tv_id(self):
            self.assertEqual(self.test_class._TEST, 'ttest')

        def test_initial(self):
            self.assertEqual(self.test_class._TEST, 'ttest')

    test_suite = unittest.TestLoader().loadTestsFromTestCase(TestTudouAlbumIE)

    unittest.TextTestRunner(verbosity=2).run(test_suite)

# Generated at 2022-06-24 13:31:05.035080
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    T = TudouAlbumIE()
    assert len(T.extract('http://www.tudou.com/albumcover/v5qckFJvNJg')) is not 0

# Generated at 2022-06-24 13:31:09.752472
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:10.418655
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:31:21.395512
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = {'items':[{'icode':'12345','kw':'some description'},{'icode':'67890','kw':'some description2'}]}

# Generated at 2022-06-24 13:31:27.475946
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    b = a.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    c = a.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    if b and c:
        print('Succeed.')
    else:
        print('Failed.')

# Generated at 2022-06-24 13:31:35.477213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test Constructor method
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.name == 'tudou:album'
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:31:39.458899
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:31:40.891495
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test Vidme constructor."""
    TudouPlaylistIE()

# Generated at 2022-06-24 13:31:42.966971
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
     try:
         tudo = TudouPlaylistIE()
         assert 1==1
     except:
         assert 1==2


# Generated at 2022-06-24 13:31:47.226207
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    g = globals()
    def f(url):
        ret = TudouPlaylistIE()._real_extract(url)
        print(ret)
        return ret
    g['test_TudouPlaylistIE'] = f


# Generated at 2022-06-24 13:31:49.562296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert str(ie) == 'TudouPlaylistIE()'
    assert repr(ie) == 'TudouPlaylistIE()'


# Generated at 2022-06-24 13:31:50.529259
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()

# Generated at 2022-06-24 13:31:57.410048
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'Tudou', ie.ie_name()
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not ie.suitable('http://www.tudou.com/')


# Generated at 2022-06-24 13:31:59.171977
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.IE_NAME, '', '')

# Generated at 2022-06-24 13:32:03.530691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    extractor = TudouPlaylistIE()
    assert extractor._match_id(url) == 'zzdE77v6Mmo'



# Generated at 2022-06-24 13:32:15.337786
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = '{ "totalCount" : 3, "code" : 0,\
                    "items" : [{"code" : 0, "kw" : "kw1", "icode" : "icode1"},\
                              {"code" : 0, "kw" : "kw2", "icode" : "icode2"},\
                              {"code" : 0, "kw" : "kw3", "icode" : "icode3"}]}'

    def download_json(url, name):
        return album_data

    ie = TudouAlbumIE(url)
    ie.download_json = download_json
   

# Generated at 2022-06-24 13:32:17.262335
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_id = 'v5qckFJvNJg'
	obj = TudouAlbumIE()
	assert obj.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:32:20.365184
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE

    instance = TudouAlbumIE('1')
    assert not instance is None
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:32:22.135270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Execute constructor of class TudouAlbumIE
    inst = TudouAlbumIE()
    assert inst

# Generated at 2022-06-24 13:32:33.598423
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    album_id = 'wHw6o0PZl8Y'
    result_filename = 'album_' + album_id + '.json'
    album_data = ie._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    play_list = ie.playlist_result(entries, album_id)

# Generated at 2022-06-24 13:32:39.036894
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    tudou_playlist_ie._real_extract('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:32:43.215463
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.extract(url)

# Generated at 2022-06-24 13:32:52.605872
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 看看的url地址
    url = 'http://www.tudou.com/albumcover/cTvTlgxI8yU.html'
    tudou = TudouAlbumIE()
    items_data = tudou._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=cTvTlgxI8yU', 'cTvTlgxI8yU')
    items = items_data['items']
    

# Generated at 2022-06-24 13:32:58.373353
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from . import Extractor
    from .common import InfoExtractor

    ie = InfoExtractor()
    ie_py = ie.__class__()._get_IE('Tudou:playlist')
    ie_py.__module__ = ie.__module__
    assert isinstance(ie_py, Extractor)
    assert issubclass(ie_py.__class__, InfoExtractor)


# Generated at 2022-06-24 13:33:04.475729
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE();
    print(tudou_playlist.IE_NAME);
    assert "TudouPlaylistIE" == tudou_playlist.IE_NAME;
    assert "tudou:playlist" == tudou_playlist.IE_NAME;
    print(tudou_playlist.IE_NAME);


# Generated at 2022-06-24 13:33:08.396876
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html";
    tudouPlaylistIE = TudouPlaylistIE(url);
    assert tudouPlaylistIE.IE_NAME == "TudouPlaylist";
    #assert tudouPlaylistIE.url == url;


# Generated at 2022-06-24 13:33:09.618169
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album = TudouAlbumIE()

# Generated at 2022-06-24 13:33:17.444710
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor_test(TudouAlbumIE, [('http://www.tudou.com/albumplay/v5qckFJvNJg.html', [
        'http://www.tudou.com/programs/view/v5qckFJvNJg/']),
        ('http://www.tudou.com/albumcover/v5qckFJvNJg.html', [
         'http://www.tudou.com/programs/view/v5qckFJvNJg/'])])


# Generated at 2022-06-24 13:33:19.618125
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from TudouPlaylistIE import TudouPlaylistIE
	obj = TudouPlaylistIE()
	print(obj)

# Generated at 2022-06-24 13:33:21.568880
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()


# Generated at 2022-06-24 13:33:27.157640
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_TudouAlbumIE = TudouAlbumIE();
	assert(test_TudouAlbumIE.IE_NAME == 'tudou:album');
	assert(test_TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html');


# Generated at 2022-06-24 13:33:30.304935
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print('Playlist...')
	tudou1 = TudouPlaylistIE()
	tudou2 = TudouPlaylistIE()
	tudou3 = TudouPlaylistIE()
	return

# Generated at 2022-06-24 13:33:32.844746
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)



# Generated at 2022-06-24 13:33:36.797339
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	raw_string = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	expect_res = "zzdE77v6Mmo"
	res = ie._match_id(raw_string)
	assert res == expect_res

# Generated at 2022-06-24 13:33:39.954431
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:33:43.148196
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(1)._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:33:51.335056
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:33:54.682826
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test the constructor
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'TudouAlbum'
    assert ie.ie_name() == 'Tudou:album'

# Generated at 2022-06-24 13:33:59.258409
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:34:10.860962
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    sample_url_1 = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    sample_url_2 = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    sample_url_3 = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    sample_url_4 = "http://www.tudou.com/albumcover/v5qckFJvNJg"
    sample_url_5 = "http://www.tudou.com/albumplay/v5qckFJvNJg"

    # assert correct class is created
    assert TudouAlbumIE.suitable(sample_url_1)

# Generated at 2022-06-24 13:34:17.729894
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:34:20.132058
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS



# Generated at 2022-06-24 13:34:30.404844
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    if sys.version_info.major == 2:
        import imp
        imp.reload(sys)
        sys.setdefaultencoding('utf-8')
    url = 'http://www.tudou.com/albumplay/Rd1yA6UO-Og.html'
    test = TudouAlbumIE()
    test._match_id(url)
    test._download_json('http://www.tudou.com/tvp/alist.action?acode=Rd1yA6UO-Og', 'Rd1yA6UO-Og')
    test._real_extract(url)
    return 'Pass'

# Generated at 2022-06-24 13:34:32.351093
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:34:37.390324
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tester = TudouAlbumIE()
    # test invalid URL
    assert tester._real_extract('http://www.tudou.com/albumplay/zzdE77v6Mmo.html') == None
    # test valid URL
    assert tester._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html') != None
# Test case pass

# Generated at 2022-06-24 13:34:42.447631
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Unit test for constructor of class TudouAlbumIE
    """
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_instance = TudouAlbumIE()
    assert test_instance._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:34:47.238336
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL ==  TudouAlbumIE._VALID_URL
    assert ie._TESTS ==  TudouAlbumIE._TESTS

# Generated at 2022-06-24 13:34:51.387492
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:52.662175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(InfoExtractor())


# Generated at 2022-06-24 13:34:54.191738
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('tudou:playlist')


# Generated at 2022-06-24 13:34:56.036961
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Unit test for constructor of class TudouAlbumIE")
    print("This is TODO")


# Generated at 2022-06-24 13:35:06.317881
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:35:08.237637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("test_TudouPlaylistIE")
    print("********************")
    tudou_playlist = TudouPlaylistIE(1)
    print("********************")
    assert tudou_playlist


# Generated at 2022-06-24 13:35:12.844203
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert instance._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-24 13:35:21.873120
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE({})
    assert tudou_playlist_ie.suitable(url)
    tudou_playlist_ie_result = tudou_playlist_ie.extract(url)
    assert tudou_playlist_ie_result['id'] == 'zzdE77v6Mmo'
    assert len(tudou_playlist_ie_result['entries']) > 0


# Generated at 2022-06-24 13:35:24.639362
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test that class constructor returns an instance of TudouPlaylistIE."""
    obj = TudouPlaylistIE()
    assert isinstance(obj, TudouPlaylistIE)



# Generated at 2022-06-24 13:35:26.153022
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    res = TudouAlbumIE.suite()

# Generated at 2022-06-24 13:35:35.143540
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-24 13:35:37.171394
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()
    assert isinstance(test_TudouAlbumIE,TudouAlbumIE)

# Generated at 2022-06-24 13:35:45.848434
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbumIE = TudouAlbumIE()
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	assert tudouAlbumIE.IE_NAME == 'tudou:album'
	assert tudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert tudouAlbumIE._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:35:55.046301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    #assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:35:55.688373
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-24 13:35:59.254332
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    assert playlist_id == TudouPlaylistIE._match_id(url)


# Generated at 2022-06-24 13:36:03.092656
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	info_extractor = InfoExtractor()
	assert info_extractor.suitable("http://www.tudou.com/listplay/zzdE77v6Mmo.html") == True
	assert info_extractor.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:36:05.156575
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:36:15.458061
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    from .common import TestGuess
    from .ttvnw import TTVNWIE
    from .youku import YoukuIE
    from .youku import YoukuPlaylistIE
    from .youku import YoukuShowIE
    from .sohu import SohuIE
    from .sohu import SohuTVPlaylistIE

    test_obj = TestGuess(url, ie=TTVNWIE)
    assert test_obj.match() == True
    assert test_obj.parse()['id'] == ''
    assert test_obj.parse()['display_id'] == ''
    assert test_obj.parse()['title'] == ''
    assert test_obj.parse()['ext'] == 'mp4'


# Generated at 2022-06-24 13:36:19.995620
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	playlist = TudouPlaylistIE()
	playlist.extract(url)
	assert playlist.ie_name == 'tudou:playlist'
	assert playlist.tbr == None
	assert playlist.id == 'zzdE77v6Mmo'
	assert playlist.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-24 13:36:29.161261
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "https://www.tudou.com/listplay/gMrEf6HD_Wg.html"
    a = TudouPlaylistIE(url)
    b = a._real_extract(url)
    assert a.IE_NAME == "tudou:playlist"
    assert a._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert a._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert a._TESTS[0]['info_dict']['id'] == "zzdE77v6Mmo"

# Generated at 2022-06-24 13:36:32.636549
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:36.360031
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_object = TudouPlaylistIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-24 13:36:38.923340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    check_test_ie(TudouPlaylistIE, ['http://www.tudou.com/listplay/zzdE77v6Mmo.html'])


# Generated at 2022-06-24 13:36:47.571764
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 1. check if the type of instanse is correct
    test_album = TudouAlbumIE("https://www.tudou.com/albumcover/0vt_DTUGnYY.html")
    assert type(test_album) == TudouAlbumIE

    # 2. check if the url of instance is correctly processed
    assert test_album._TESTS[0]['url'] == "https://www.tudou.com/albumcover/0vt_DTUGnYY.html"

    # 3. check if the id of instance is correctly processed
    assert test_album._TESTS[0]['info_dict']['id'] == "0vt_DTUGnYY"


# Generated at 2022-06-24 13:36:48.592684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:56.448022
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test case for constructor arguments
    assert(TudouAlbumIE._VALID_URL == True)
    assert(TudouAlbumIE._TESTS == True)
    assert(TudouAlbumIE.IE_NAME == True)
    assert(TudouAlbumIE.http == False)
    assert(TudouAlbumIE._json_lds == False)
    assert(TudouAlbumIE._netscape_cookie == False)
    assert(TudouAlbumIE._search_regex == False)
    assert(TudouAlbumIE._type == False)

# Generated at 2022-06-24 13:37:02.592851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:37:13.914746
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Test for normal case
	testCase1 = {
		'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
		'expected': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
		'expectedId': 'v5qckFJvNJg',
		'expectedName': 'Tudou',	
	}

	testCase1_test = TudouAlbumIE(testCase1['url'])
	assert testCase1_test._VALID_URL == testCase1['expected']
	assert testCase1_test._match_id(testCase1['url']) == testCase1['expectedId']

# Generated at 2022-06-24 13:37:18.905757
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE.IE_NAME, basestring)
    assert isinstance(TudouAlbumIE.IE_NAME, basestring)
    assert isinstance(TudouAlbumIE._VALID_URL, basestring)
    assert isinstance(TudouAlbumIE._TESTS, list)

# Generated at 2022-06-24 13:37:24.670461
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL== 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME== 'tudou:playlist'


# Generated at 2022-06-24 13:37:29.772523
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE.test() == 0


# Generated at 2022-06-24 13:37:32.822418
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist_obj=TudouPlaylistIE()
    assert tudouPlaylist_obj.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:37:35.073737
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "http://www.tudou.com/listplay/k20jKUu-6b8.html"
	return TudouPlaylistIE(url)


# Generated at 2022-06-24 13:37:36.442696
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert td_alb.IE_NAME == "tudou:album"


# Generated at 2022-06-24 13:37:42.649050
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert (test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (test.IE_NAME == 'tudou:playlist')
    assert (test._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert (test._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')
    assert (test._TESTS[0]['playlist_mincount'] == 209)


# Generated at 2022-06-24 13:37:46.520241
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import playlist_result, InfoExtractor
    assert(isinstance(TudouPlaylistIE(), InfoExtractor))
    assert(isinstance(TudouPlaylistIE().playlist_result, playlist_result))


# Generated at 2022-06-24 13:37:50.383448
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td_ie = TudouAlbumIE()
    assert td_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:37:56.620536
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie.ie_key() == 'TudouPlaylist')
    assert(ie.ie_name() == 'Tudou')
    assert(ie.playlist_id() == 'zzdE77v6Mmo')



# Generated at 2022-06-24 13:37:59.479708
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(_make_valid_url(), {})
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:38:07.571506
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Start test TudouPlaylistIE")

# Generated at 2022-06-24 13:38:13.685646
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:38:24.031351
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:38:28.305567
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test a listplay URL
    assert TudouPlaylistIE._VALID_URL.search('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:38:36.648520
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test the construct of TudouPlaylistIE
    # tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # assert tudou_playlist.url_info['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # assert tudou_playlist.url_info['playlist_id'] == 'zzdE77v6Mmo'
    assert True


# Generated at 2022-06-24 13:38:40.979777
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    inst = TudouAlbumIE()
    assert inst._match_id(album_url) == album_id

# Generated at 2022-06-24 13:38:43.094791
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()

# Generated at 2022-06-24 13:38:45.466280
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:38:46.576501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE



# Generated at 2022-06-24 13:38:47.741457
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:38:58.406779
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    assert_false(ie.IE_NAME is "")
    assert_false(ie._VALID_URL == "")
    assert_false(ie._TESTS == "")
    assert_true(ie.IE_NAME == "tudou:playlist")
    assert_true(ie._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html")
    assert_true(ie._TESTS[0] == {"url": "http://www.tudou.com/listplay/zzdE77v6Mmo.html", "info_dict": {"id": "zzdE77v6Mmo"}, "playlist_mincount": 209})
    

# Generated at 2022-06-24 13:39:00.386868
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert(a) # return nothing


# Generated at 2022-06-24 13:39:02.514660
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
        assert(True)
    except:
        assert(False)


# Generated at 2022-06-24 13:39:13.993717
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url_test = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    cls_test = 'TudouPlaylistIE'
    # Wrong URL
    # The URL should be started with 'http://www.tudou.com/listplay/'.
    assert TudouPlaylistIE.suitable(url_test[:-5]) is False
    # Right URL
    assert TudouPlaylistIE.suitable(url_test) is True
    # Constructor test
    ie_test = TudouPlaylistIE(url_test)
    print(ie_test)
    print(ie_test.__class__.__name__)
    assert ie_test.__class__.__name__ == cls_test
    assert ie_test.name == cls_test