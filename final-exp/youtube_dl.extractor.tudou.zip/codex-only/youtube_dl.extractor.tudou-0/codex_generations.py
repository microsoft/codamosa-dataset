

# Generated at 2022-06-24 13:29:14.773327
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from tudou.compat import compat_str

    ie = TudouAlbumIE({})
    assert ie  # silence lint warning
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    album_id = 'v5qckFJvNJg'
    album_data = ie._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    assert album_data.keys() == ['items', 'pageCount', 'pageNo', 'pageSize', 'recordCount']
    assert len(album_data['items'])

# Generated at 2022-06-24 13:29:15.455022
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	pass


# Generated at 2022-06-24 13:29:20.977662
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    try:
        TudouAlbumIE(url)
    except:
        print("Failed unit test for TudouAlbumIE")
    else:
        print("Success unit test for TudouAlbumIE")


# Generated at 2022-06-24 13:29:22.411083
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:23.276833
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    pass

# Generated at 2022-06-24 13:29:24.272185
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE().IE_NAME

# Generated at 2022-06-24 13:29:32.175566
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Testing values
	playlist_id = 'playlist_id'
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	playlist_data = {'items':[{'icode':'test1', 'kw':'test keyword 1'}, {'icode':'test2', 'kw':'test keyword 2'}]}

	# Building testcase
	TudouPlaylistIE.testcase = {
		'url': url,
		'info_dict': {
			'id': playlist_id
		},
		'playlist_mincount': 2,
		'mock_download_json': playlist_data
	}

	# Testing constructor
	TudouPlaylistIE(TudouPlaylistIE.testcase)




# Generated at 2022-06-24 13:29:42.403620
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:29:47.258121
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(
        TudouPlaylistIE(
            TudouPlaylistIE.ie_key()).ie_key() ==
        TudouPlaylistIE.ie_key())
    assert(
        TudouAlbumIE(
            TudouAlbumIE.ie_key()).ie_key() ==
        TudouAlbumIE.ie_key())

# Generated at 2022-06-24 13:29:51.653391
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE._url = 'https://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudou_album = TudouAlbumIE()
	assert tudou_album._real_extract(tudou_album._url)

# Generated at 2022-06-24 13:29:58.741727
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:30:03.159038
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        album = TudouPlaylistIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    except:
        raise
    assert album.tudou_id is not None


# Generated at 2022-06-24 13:30:10.860466
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_id = "v5qckFJvNJg"
	album_data = self._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
	entries = [self.url_result("http://www.tudou.com/programs/view/%s" % item['icode'], "Tudou", item['icode'], item['kw']) for item in album_data['items']]


# Generated at 2022-06-24 13:30:13.336143
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-24 13:30:15.079693
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:30:21.797923
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # Test if it returns a correct playlist
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is True
    assert ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html') is True
    assert ie.suitable('http://notTudou.com/albumplay/v5qckFJvNJg.html') is False

# Generated at 2022-06-24 13:30:24.435636
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    o = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert isinstance(o, TudouAlbumIE)
    return

# Generated at 2022-06-24 13:30:30.398645
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    for i in _TESTS:
        ie = TudouAlbumIE()
        assert ie
        assert ie._VALID_URL
        assert ie.IE_NAME
        assert ie._TESTS

# Generated at 2022-06-24 13:30:33.737524
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(context)
    assert obj.ie_key() == 'tudou:playlist'
    assert obj.ie_name() == 'Tudou'


# Generated at 2022-06-24 13:30:36.187730
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
  info_dict = {
            'id': 'v5qckFJvNJg',
        }
  playlist_mincount = 45


# Generated at 2022-06-24 13:30:48.452541
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # create a TudouPlaylistIE object
    i = TudouPlaylistIE(url)

# Generated at 2022-06-24 13:30:52.166676
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.extractor_key == 'tudou:album'

# Generated at 2022-06-24 13:30:54.873651
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.__class__ == TudouAlbumIE

# Generated at 2022-06-24 13:30:57.328129
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:31:07.110877
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    assert IE.IE_NAME == 'tudou:album'
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert IE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:31:08.494853
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor_test(TudouPlaylistIE, [], False)


# Generated at 2022-06-24 13:31:12.651817
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("tudou:album")
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:14.532162
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.__name__ == 'TudouPlaylistIE')


# Generated at 2022-06-24 13:31:18.438107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumcover/v5qckFJvNJg"
    ie = TudouAlbumIE()
    assert ie._match_id(test_url) == "v5qckFJvNJg"


# Generated at 2022-06-24 13:31:29.481565
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

    # test the get function

# Generated at 2022-06-24 13:31:31.193100
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()



# Generated at 2022-06-24 13:31:42.131090
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test the class constructor
    assert isinstance(TudouAlbumIE, InfoExtractor)
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert hasattr(TudouAlbumIE, '_TESTS')
    assert hasattr(TudouAlbumIE, '_real_extract')
    assert hasattr(TudouAlbumIE, 'suitable')

    from .common import InfoExtractor

    ie = TudouAlbumIE('test')
    # test the base instance attributes
    assert hasattr(ie, '_downloader')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, 'url')
    assert hasattr(ie, '_video_extractor_classes')
    assert hasattr(ie, '_VIDEO_EXTENSIONS')

# Generated at 2022-06-24 13:31:42.889181
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:31:46.248738
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:31:47.584185
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO: Add case test for constructor TudouPlaylistIE
    pass


# Generated at 2022-06-24 13:31:54.941730
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test a specific TudouAlbumIE instance,
    # only if the IE is available (IE_NAME is in _ALL_CLASSES)
    ie = infoExtractor.InfoExtractor._create_instances(TudouAlbumIE)
    # The 'url' field of the returning instance will be set to None
    # if the IE is not available
    assert ie.url is not None
    assert ie.ie_key() == 'TudouAlbumIE'
    assert ie.ie_key() in infoExtractor.InfoExtractor._ALL_CLASSES


# Generated at 2022-06-24 13:31:57.562753
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, TudouAlbumIE)


# Generated at 2022-06-24 13:32:01.354569
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE, InfoExtractor)
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert hasattr(TudouAlbumIE, '_TESTS')


# Generated at 2022-06-24 13:32:08.738517
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Create TudouAlbumIE object 
    tudou_album = TudouAlbumIE()
    # Test if the url string for album page is valid
    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # Test if the url string for playlist page is valid
    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Test if the example of album page is valid

# Generated at 2022-06-24 13:32:20.217010
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ''' This function should be refined with more test cases.
        Tested feature: this function tests the constructor of class TudouPlaylistIE
    '''
    from TudouPlaylistIE import TudouPlaylistIE
    from common import InfoExtractor
    from compat import compat_urllib_request
    from utils import (
        HEADRequest,
    )

    # Test case 1: test __init__()
    # input: info_extractor = None, ie = None, downloader = None,
    #        add_ie = True, ie_key = None
    # output: info_extractor = InfoExtractor, ie = TudouPlaylistIE, downloader is None,
    #         add_ie = True, ie_key = 'Tudou:playlist'

# Generated at 2022-06-24 13:32:28.145180
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TudouPlaylistIE: invalid URL
    with pytest.raises(ExtractorError):
        TudouPlaylistIE("www.tudou.com/listplay/tudou.html")
    with pytest.raises(ExtractorError):
        TudouPlaylistIE("http://www.tudou.com/listplay/tudou.html")

    # TudouPlaylistIE: expected to return more than 200 videos
    tudou_playlist = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    playlist = tudou_playlist.extract()

    assert(playlist['id'] == "zzdE77v6Mmo")
    assert(playlist['_type'] == 'playlist')

# Generated at 2022-06-24 13:32:34.003292
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlist_ID = "zzdE77v6Mmo"
	test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	assert playlist_ID == TudouPlaylistIE._match_id(test_url)
	assert TudouPlaylistIE()._real_extract(test_url)
	

# Generated at 2022-06-24 13:32:36.762849
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-24 13:32:41.303732
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	for url in ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']:
		tudou_album = TudouAlbumIE()
		tudou_album.extract(url)

# Generated at 2022-06-24 13:32:42.453892
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:32:44.944958
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Raw unit test
    ie = TudouPlaylistIE()
    assert ie.get_url(None) == None



# Generated at 2022-06-24 13:32:52.297985
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_info = {'icode': '6Vdu-6-HXxA', 'id': '6Vdu-6-HXxA', 'kw': '蜘蛛侠cmc_20150701', 'aid': '84286', 'title': '蜘蛛侠'}
    test = TudouAlbumIE()
    t = test.url_result('http://www.tudou.com/programs/view/%s' % album_info['icode'],
            'Tudou', album_info['icode'],
            album_info['kw'])

# Generated at 2022-06-24 13:32:53.282586
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:32:55.795520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url,'TudouAlbumIE')

# Generated at 2022-06-24 13:33:00.226024
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test import get_testcases
    from .tudou import TudouPlaylistIE
    tester = get_testcases(TudouPlaylistIE, 'tudou:playlist')
    tester.run()


# Generated at 2022-06-24 13:33:03.299516
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudouAlbum._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbum.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:33:12.749441
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # It is a very simple test
    # No matter it is inierted or not, pass or not, it will always return True
    # So there is no point to write more tests.
    tudou_test1 = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    tudou_test2 = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html',playlist_mincount=208)
    tudou_test3 = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html',playlist_mincount=210)

# Generated at 2022-06-24 13:33:23.318861
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test 1
    # test different playlist IDs of Tudou
    ids = ['ezdE77v6Mmo', 'KZdE77v6Mmo', 'zzdE77v6Mmo']

    for id in ids:
        assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
        assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:33:25.395799
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE() # check if the class can be instanced
    print('Test has finished successfully.')

# Generated at 2022-06-24 13:33:26.450676
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-24 13:33:30.404678
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/Ou3cNY0PfMg.html'
    ie = TudouAlbumIE()
    assert ie._match_id(url) == 'Ou3cNY0PfMg'


# Generated at 2022-06-24 13:33:32.930571
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   print('Init class TudouAlbumIE')
   tudou_album_ie = TudouAlbumIE()
   return tudou_album_ie


# Generated at 2022-06-24 13:33:36.549401
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:33:40.300566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    ie.extract_info()

# Generated at 2022-06-24 13:33:42.317804
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudoie = TudouPlaylistIE()
    print(tudoie)
    print(tudoie.IE_NAME)


# Generated at 2022-06-24 13:33:48.282046
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE("www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudou_playlist

# Generated at 2022-06-24 13:33:57.346968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import get_testcases_from_path
    from .f4m import F4mIE

# Generated at 2022-06-24 13:34:09.203535
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """ Test the constructor of class TudouAlbumIE """
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.url == url
    assert ie.name == 'tudou:album'
    assert ie._match_id(url) == 'v5qckFJvNJg'
    # Unit test for extract-method of class TudouAlbumIE
    def test_real_extract():
        """ Test the extract-method of class TudouAlbumIE """
        ie.real_extract(url)

# Generated at 2022-06-24 13:34:15.829152
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert tudouPlaylistIE._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]



# Generated at 2022-06-24 13:34:17.936502
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie is not None

# Generated at 2022-06-24 13:34:19.634757
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:21.883899
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ia = TudouAlbumIE({})
	assert(ia is not None)
	assert(ia._downloader is not None)


# Generated at 2022-06-24 13:34:25.369267
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Given
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()

    # When
    info_dict = ie.extract(url)

    # Then
    assert info_dict['id'] == "zzdE77v6Mmo"
    assert info_dict['playlist_mincount'] == 209


# Generated at 2022-06-24 13:34:27.626716
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert_equal(obj.ie_key(), 'TudouAlbum')

# Generated at 2022-06-24 13:34:29.858081
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor()
    # Test exceptions
    assert_raises(TypeError, TudouPlaylistIE, ie)

# Generated at 2022-06-24 13:34:33.361186
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE('Tudou:album')
    assert constructor._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:35.071969
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:34:37.247230
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    tudou_album._real_initialize()

# Generated at 2022-06-24 13:34:46.070419
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE("test")
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert x._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:34:55.245755
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    playlist_id = tudou_playlist._match_id(url)
    url_json = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    playlist_data = tudou_playlist._download_json(url_json, playlist_id)
    entries = [tudou_playlist.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    t

# Generated at 2022-06-24 13:34:56.894433
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    a.suite()

# Generated at 2022-06-24 13:35:00.557499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        tudou_playlist_ie = TudouPlaylistIE('')
    except Exception:
        tudou_playlist_ie = None
    assert tudou_playlist_ie is not None

# Generated at 2022-06-24 13:35:01.598554
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:35:05.193052
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:35:07.983719
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    except:
        pass


# Generated at 2022-06-24 13:35:10.460028
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:35:11.541108
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()

# Generated at 2022-06-24 13:35:22.801875
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('TudouPlaylistIE','zzdE77v6Mmo','1.0')
    if not isinstance(instance, TudouPlaylistIE):
        print('test_TudouPlaylistIE(): instance is not an instance of TudouPlaylistIE')
    if instance.name != 'TudouPlaylistIE':
        print('test_TudouPlaylistIE(): name is not TudouPlaylistIE')
    if instance.version != '1.0':
        print('test_TudouPlaylistIE(): version is not equal to 1.0')
    if not instance.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html'):
        print('test_TudouPlaylistIE():  url is not suitable')

# Generated at 2022-06-24 13:35:23.838215
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print(TudouPlaylistIE())

# Generated at 2022-06-24 13:35:26.644612
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert a is not None


# Generated at 2022-06-24 13:35:28.319674
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t is not None

# Generated at 2022-06-24 13:35:32.693663
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print ("\nStarting test of constructor of class TudouAlbumIE\n")
    try:
        TudouAlbumIE()
        print ("\nObject creation successfull\n")
    except Exception as e:
        print ("Test failed: " + str(e))


# Generated at 2022-06-24 13:35:40.771248
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    expectedURL = 'http://www.tudou.com/tvp/alist.action?acode=%s' % 'zzdE77v6Mmo'
    albumIE = TudouAlbumIE({})
    with mock.patch('compat_urllib_request.urlopen') as mock_urlopen:
        # test with expected condition
        mock_urlopen.return_value.__enter__.return_value = compat_urllib_request.urlopen('file://' + os.path.join(os.path.dirname(__file__), 'TudouAlbumIE.txt'))
        albumIE._real_extract(expectedURL)

# Generated at 2022-06-24 13:35:47.168180
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:35:51.998175
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td_album_ie = TudouAlbumIE()
    assert td_album_ie.IE_NAME == 'tudou:album'
    assert td_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:54.580827
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert isinstance(tudouPlaylistIE, InfoExtractor)


# Generated at 2022-06-24 13:35:58.044736
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    valid = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    invalid = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    test = TudouAlbumIE()
    assert test._match_id(valid) == 'v5qckFJvNJg'
    assert test._match_id(invalid) == ''
    assert test._VALID_URL is True
    assert test._TEST is False

# Generated at 2022-06-24 13:36:03.625663
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL is not ""
    assert TudouPlaylistIE._TESTS is not ""
    assert TudouPlaylistIE._TEST is not ""
    assert TudouPlaylistIE._TESTS_BASE_URL is not ""
    assert TudouPlaylistIE.IE_NAME is not ""
    assert TudouPlaylistIE.IE_DESC is not ""
    assert TudouPlaylistIE.IE_VERSION is not ""
    assert TudouPlaylistIE._build_config_url is not ""
    assert TudouPlaylistIE._CLIENT_ID is not ""
    assert TudouPlaylistIE._CLIENT_SECRET is not ""
    assert TudouPlaylistIE._TOKEN_URL is not ""
    assert TudouPlaylistIE._LANG_URL is not ""
    assert TudouPlaylist

# Generated at 2022-06-24 13:36:04.458303
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()


# Generated at 2022-06-24 13:36:05.611709
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()


# Generated at 2022-06-24 13:36:09.477374
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(downloader=None)
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:36:11.957114
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE({'youtube_id': 'test', 'url': 'test'})
    assert ie.youtube_id == 'test'
    assert ie.url == 'test'

# Generated at 2022-06-24 13:36:13.350430
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    global p1
    p1 = TudouAlbumIE("")


# Generated at 2022-06-24 13:36:20.213990
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: add other album test
    alb_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    alb_data = TudouAlbumIE()._real_extract(alb_url)
    assert alb_data['id'] == 'v5qckFJvNJg'
    assert alb_data['info_dict']['id'] == 'v5qckFJvNJg'
    assert len(alb_data['entries']) == 45


# Generated at 2022-06-24 13:36:22.915599
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudou != None


# Generated at 2022-06-24 13:36:24.202213
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:36:27.626684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE_TEST = TudouAlbumIE()
    # test case with valid url
    IE_TEST.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert IE_TEST.url == IE_TEST._VALID_URL

# Generated at 2022-06-24 13:36:30.138664
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['url'] == TudouAlbumIE(TudouAlbumIE._TESTS[0]['url'])._TESTS[0]['url']


# Generated at 2022-06-24 13:36:33.583500
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:36:40.172348
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ConstructorTest(TudouPlaylistIE, [
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'https://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'http://www.tudou.com/listplay/zzdE77v6Mmo',
        'https://www.tudou.com/listplay/zzdE77v6Mmo',
    ])

# Generated at 2022-06-24 13:36:42.283674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist is not None


# Generated at 2022-06-24 13:36:50.623224
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE(TudouAlbumIE._VALID_URL)

# Generated at 2022-06-24 13:36:53.060353
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:37:00.937237
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:37:02.400609
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import TudouAlbumIE
    assert TudouAlbumIE._VALID_URL is not None

# Generated at 2022-06-24 13:37:08.639460
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .common import InfoExtractor

	class TudouAlbumIE(InfoExtractor):
		IE_NAME = 'tudou:album'
		_VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
		_TESTS = [{
			'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
			'info_dict': {
				'id': 'v5qckFJvNJg',
			},
			'playlist_mincount': 45,
		}]
		
		def _real_extract(self, url):
			album

# Generated at 2022-06-24 13:37:19.769351
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = ['http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo']

# Generated at 2022-06-24 13:37:21.921291
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:37:32.561696
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:37:34.831997
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert issubclass(TudouAlbumIE, InfoExtractor)
    assert issubclass(TudouPlaylistIE, InfoExtractor)



# Generated at 2022-06-24 13:37:35.873711
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('test-instance')

# Generated at 2022-06-24 13:37:37.245378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test.get_class() == 'TudouPlaylistIE'

# Generated at 2022-06-24 13:37:38.665337
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE().ie_key() == 'TudouPlaylist'

# Generated at 2022-06-24 13:37:41.085725
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	ie.download_webpage('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:37:44.064943
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:47.816326
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:59.181400
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE(TudouAlbumIE._build_request(url))
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbumIE._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]
    assert tudouAlbumIE._match_id

# Generated at 2022-06-24 13:38:04.086968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
   

# Generated at 2022-06-24 13:38:09.831816
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    "Unit test for constructor of class TudouAlbumIE"
    album_id = 'v5qckFJvNJg'
    url_str = 'http://www.tudou.com/albumplay/' + album_id + '.html'
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._match_id(url_str) == album_id
    return

# Generated at 2022-06-24 13:38:20.857378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from pytube import TudouPlaylistIE
	tudou_playlist_ie = TudouPlaylistIE()
	assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
	assert tudou_playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	tudou_playlist_ie_tests = tudou_playlist_ie._TESTS
	for test_url in tudou_playlist_ie_tests:
		tudou_playlist_ie_url = test_url['url']
		tudou_playlist_ie_info = test_url['info_dict']
		assert tudou_playlist_ie

# Generated at 2022-06-24 13:38:23.092732
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou = TudouAlbumIE()
    tudou._real_extract(url)

# Generated at 2022-06-24 13:38:23.872308
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:38:24.654380
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()

# Generated at 2022-06-24 13:38:36.382252
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from urllib import unquote
	from chardet import detect
	from urlparse import urlparse
	from urllib2 import quote
	test = TudouPlaylistIE()
	test.test_result = True
	
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	id = "zzdE77v6Mmo"
	valid_url = "http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo"
	TudouPlaylistIE._download_json = lambda url, playlist_id, video_id, query={}: url
	test._real_extract(url)
	assert test.test_result == True
	assert test.result['_type'] == "playlist"


# Generated at 2022-06-24 13:38:46.613160
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import logging

    # Make sure it does not crash by constructing an object
    test_TudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert test_TudouAlbumIE.IE_NAME == 'tudou:album'
    assert test_TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    # Make sure it does not crash by calling _real_extract

# Generated at 2022-06-24 13:38:56.793851
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-24 13:39:00.340978
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    test = ie.extract(url)

# Generated at 2022-06-24 13:39:03.531458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from TudouIE import TudouAlbumIE
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert url == TudouAlbumIE._VALID_URL

# Generated at 2022-06-24 13:39:08.404321
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    for URL in TudouAlbumIE._TESTS:
      assert TudouAlbumIE.suitable(URL['url']), 'URL: %s' % URL['url'] # test URL suitability
      i = TudouAlbumIE()
      assert i.extract(URL['url']) # test extraction
