

# Generated at 2022-06-24 13:29:14.910688
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    videoId = 'zzdE77v6Mmo'
    innerId = '_'.join([videoId, '1'])
    playlistId = 'listplay_' + videoId
    playlist = {'playlistId': playlistId, 'videoId': videoId, 'innerId': innerId}
    ie = TudouPlaylistIE()
    assert ie is not None
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.ID == 'tudou'
    assert ie.VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._real_extract(playlist['playlistId']) is not None
    assert ie._real_extract(playlist['videoId'])

# Generated at 2022-06-24 13:29:17.916195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE.TudouPlaylistIE(None, None)



# Generated at 2022-06-24 13:29:21.508231
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        from . import TudouAlbumIE
    except:
        from ykdl.extractors import TudouAlbumIE
    assert TudouAlbumIE.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:29:24.509698
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:29:28.435450
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from tudou.TudouIE import TudouAlbumIE
    import urllib
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE(urllib.urlopen(url))
    tudouAlbumIE

# Generated at 2022-06-24 13:29:33.701109
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouPlaylistIE()._real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert len(result["entries"]) == 209
    assert result["playlist_id"] == "zzdE77v6Mmo"


# Generated at 2022-06-24 13:29:34.637510
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:36.558590
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Testing TudouAlbumIE class")


# Generated at 2022-06-24 13:29:43.341274
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudou_album_ie._TESTS) == 1
    assert tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:29:45.755324
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert obj.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:29:51.605185
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor url is invalid
    try:
        TudouPlaylistIE(url='ha')
    except BaseException:
        assert True
    else:
        assert False

    # Constructor url is valid
    try:
        TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except BaseException:
        assert False
    else:
        assert True



# Generated at 2022-06-24 13:29:55.035530
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import tools
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album = 'v5qckFJvNJg'
    data = tools.get_url_content(url)
    assert album in data

# Generated at 2022-06-24 13:30:01.825431
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    See http://www.tudou.com/album/albumData/-l8p0zP7oNw-.html for data source.
    '''
    import json


# Generated at 2022-06-24 13:30:11.552590
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    result = TudouPlaylistIE()
    assert result.IE_NAME == 'tudou:playlist'
    assert result._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert result._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert result._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert result._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:30:14.273103
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou=TudouAlbumIE()
    url='http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou._match_id(url)

# Generated at 2022-06-24 13:30:20.023806
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:30:22.989838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    td_p_ie = TudouPlaylistIE()
    td_p_ie.test(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:30:27.306700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_instance = TudouAlbumIE()

    assert test_instance.ie_name == 'tudou:album'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:30:31.951949
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie_obj = TudouAlbumIE(_download_webpage=lambda url: '{"items":[{"icode":"12345","kw":"title"}]}')
    assert ie_obj._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')['entries'][0]['url'] == 'http://www.tudou.com/programs/view/12345'


# Generated at 2022-06-24 13:30:34.452991
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_ab = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:30:35.436365
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert(TudouAlbumIE)


# Generated at 2022-06-24 13:30:47.778290
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert(tudou_album.IE_NAME == "tudou:album")
    assert(tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(tudou_album._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(tudou_album._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(tudou_album._TESTS[0]['playlist_mincount'] == 45)

#

# Generated at 2022-06-24 13:30:53.206139
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	t = TudouPlaylistIE()
	assert(t.IE_NAME == 'tudou:playlist')
	assert(t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-24 13:30:55.233376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE is not None


# Generated at 2022-06-24 13:30:57.569906
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_tudou import TudouPlaylistIE
    # test instance creation
    assert isinstance(TudouPlaylistIE(),InfoExtractor)

# Generated at 2022-06-24 13:31:01.592588
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE( 'youtube', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'Test Title', 'tt', ['kw'] )


# Generated at 2022-06-24 13:31:12.841850
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
    entries = [
        {
            'pageNum': str(pageNum),
            'pageSize': str(pageSize)
        }
        for pageSize in xrange(1, 1000, 100)
        for pageNum in xrange(0, 1000)
    ]
    playlist_id = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:23.151105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a.name == 'tudou:album'
    assert a.ie_key() == 'Tudou:album'
    assert a._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert a._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert a._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert a._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:31:24.772328
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()

# Generated at 2022-06-24 13:31:36.411697
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	list_valid_urls = [
		'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
		'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
		'http://www.tudou.com/albumcover/v5qckFJvNJg/',
		'http://www.tudou.com/albumplay/v5qckFJvNJg/'
	]
	list_key = [
		'v5qckFJvNJg',
		'v5qckFJvNJg',
		'v5qckFJvNJg',
		'v5qckFJvNJg'
	]

# Generated at 2022-06-24 13:31:38.705744
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'Tudou'


# Generated at 2022-06-24 13:31:40.548146
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(None).extractor_key == TudouAlbumIE.IE_KEY

# Generated at 2022-06-24 13:31:47.126313
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #tudou album
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    ie = TudouAlbumIE()
    result = ie.extract(url)

    assert len(result['entries']) == 45
    assert result['id'] == 'v5qckFJvNJg'
    # TODO: result['entries'][0]['id']
    # TODO: result['entries'][0]['title']
    # TODO: result['entries'][0]['description']


# Generated at 2022-06-24 13:31:48.773213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:31:55.349146
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    InfoExtractor

# Generated at 2022-06-24 13:31:59.573188
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE()
    assert obj._match_id(url) == "zzdE77v6Mmo"


# Generated at 2022-06-24 13:32:03.954692
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    res = TudouAlbumIE()._build_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert res == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:32:15.779324
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert (tudouAlbumIE.ie_key() == "TudouAlbumIE")
    assert (tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert (tudouAlbumIE._TESTS[0] == {'url':'http://www.tudou.com/albumplay/v5qckFJvNJg.html','info_dict':{'id':'v5qckFJvNJg'},'playlist_mincount':45})

# Generated at 2022-06-24 13:32:17.312828
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    assert type(e) == TudouAlbumIE

# Generated at 2022-06-24 13:32:19.403479
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('TudouPlaylistIE','http://www.tudou.com/listplay/zzdE77v6Mmo.html','Tudou','zzdE77v6Mmo')


# Generated at 2022-06-24 13:32:30.525729
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #test when url is http://www.tudou.com/albumcover...
    url = 'http://www.tudou.com/albumcover/FPlwKZC1H-k.html'
    from you_get.extractors import tudou
    yg_extractor1 = tudou.TudouAlbumIE(url)
    assert yg_extractor1._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # test when url is http://www.tudou.com/albumplay..
    url = 'http://www.tudou.com/albumplay/FPlwKZC1H-k.html'
    yg_extractor2 = t

# Generated at 2022-06-24 13:32:33.327315
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert ie != None


# Generated at 2022-06-24 13:32:35.513528
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")()


# Generated at 2022-06-24 13:32:37.508542
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:32:43.540608
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return InfoExtractor._build_test({
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    })


# Generated at 2022-06-24 13:32:47.122802
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:32:51.062103
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # playlist_id is the only valid parameter, with the exception of ie_key
    # and video_id, which are also necessary
    assert ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:32:51.912544
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE(None)

# Generated at 2022-06-24 13:32:58.065918
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys

    sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__))))

    from tudou import TudouAlbumIE

    tuAlbumIE = TudouAlbumIE()
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    import re
    import json
    import urllib2
    from urllib import urlencode
    from urlparse import urlparse

    import urllib
    import urllib2
    import json

    # print dir(tuAlbumIE)
    tuAlbumIE._real_initialize()
    #tuAlbumIE.playlist_mincount = 10

# Generated at 2022-06-24 13:33:00.388745
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie.ie_key() == 'Tudou'

# Generated at 2022-06-24 13:33:04.378711
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().ie_key() == 'TudouPlaylist'
    assert TudouPlaylistIE().ie_name() == 'TudouPlaylist'
    assert TudouPlaylistIE().ie_id() == 'tudou:playlist'


# Generated at 2022-06-24 13:33:05.745729
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: Find a test case.
    pass


# Generated at 2022-06-24 13:33:15.601461
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  from .common import fake_urlopen
  from .common import ExtractorError
  from .tudou import TudouAlbumIE
  import json
  import pytest
  @pytest.fixture(autouse=True)
  def inject_faux_urlopen(monkeypatch):
    import youtube_dl.extractor.tudou
    monkeypatch.setattr(
      'youtube_dl.extractor.tudou.urlopen', fake_urlopen)

  # test album not found
  fake_urlopen.side_effect = lambda s: json.loads(
    '{"status":{"code":2,"description":"failed"}}')

# Generated at 2022-06-24 13:33:16.584338
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE()

# Generated at 2022-06-24 13:33:21.139195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import RegexNotFoundError

    try:
        obj_TudouPlaylistIE = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    except Exception as err:
        print("Error: " + str(err))



# Generated at 2022-06-24 13:33:29.685732
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	_TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    },
	{
		'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
	}]
	for test in _TESTS:
		ie = TudouAlbumIE()

# Generated at 2022-06-24 13:33:30.714035
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

	assert TudouAlbumIE('tudou:album')

# Generated at 2022-06-24 13:33:39.487490
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Tests for a valid URL
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album = TudouAlbumIE(url)
    assert tudou_album.url == url
    assert tudou_album._match_id(url) == 'v5qckFJvNJg'
    assert tudou_album._download_json('http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg') is not None

    # Tests for a URL containing an invalid ID
    url = 'http://www.tudou.com/albumplay/v5qzFJvNJg.html'
    tudou_album = Tud

# Generated at 2022-06-24 13:33:47.542087
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_id = "zzdE77v6Mmo"
    playlist_data = "http://www.tudou.com/tvp/plist.action?lcode=%s" %playlist_id
    playlist_data = "http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo"
    playlist_data = "http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo"
    entries = playlist_id
    entries = playlist_id
    test_TudouPlaylistIE = TudouPlaylistIE(url, playlist_id)
    test_TudouPlay

# Generated at 2022-06-24 13:33:52.383145
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    args = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'.split('/')
    assert args[3] == 'albumplay'

# Generated at 2022-06-24 13:33:55.146647
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('test')
    assert ie.name == 'tudou:album'
    assert ie.ie_key() == 'TudouAlbum'

# Generated at 2022-06-24 13:33:58.217459
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:34:04.964998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest
	class test(unittest.TestCase):
		def test_should_parse_album_id(self):
			actual = TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
			self.assertEqual(actual, 'v5qckFJvNJg')

	unittest.main()

# Generated at 2022-06-24 13:34:14.452866
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test for valid url
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlistIE = TudouPlaylistIE()
    assert tudou_playlistIE._match_id(url)=="zzdE77v6Mmo"
    assert tudou_playlistIE._real_extract(url)['id']=="zzdE77v6Mmo"
    assert tudou_playlistIE._real_extract(url)['entries'][0]['id'] == 'zbbbFk-z2tQ'
    assert tudou_playlistIE._real_extract(url)['playlist_mincount'] == 209

    # test for invalid url

# Generated at 2022-06-24 13:34:15.817523
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """test_TudouPlaylistIE"""
    TudouPlaylistIE()


# Generated at 2022-06-24 13:34:20.127382
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    Test_TudouAlbumIE = TudouAlbumIE(54, 'http', 'www.tudou.com')
    assert Test_TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-24 13:34:30.405193
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_instance = TudouPlaylistIE()
    assert playlist_instance._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_instance._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert playlist_instance._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert playlist_instance._TESTS[0]['playlist_mincount'] == 209



# Generated at 2022-06-24 13:34:33.447249
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:41.797853
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html") == "v5qckFJvNJg"
    assert TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")._match_id("http://www.tudou.com/albumplay/12345678901.html") == "12345678901"


# Generated at 2022-06-24 13:34:51.811397
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test case constructor of class TudouPlaylistIE."""
    # Positive test case
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(url)
    assert tudou_playlist_ie._match_id(url) == 'zzdE77v6Mmo'
    # Negative test case
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.htmllllll'
    tudou_playlist_ie = TudouPlaylistIE(url)
    assert tudou_playlist_ie._match_id(url) is None


# Generated at 2022-06-24 13:34:54.605444
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    tudouAlbum = TudouAlbumIE()
    tudouAlbum.extract(url)

# Generated at 2022-06-24 13:35:06.076961
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import FakeYDL
    from .util import copy_and_replace_in_filename
    ydl = FakeYDL()
    TudouAlbumIE().download_playlist(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html', ydl)
    assert any(r['code'] == 'v5qckFJvNJg' for r in ydl.extract_results)
    # This playlist contains 2 clips with identical title
    ydl = FakeYDL()
    TudouAlbumIE().download_playlist(
        'http://www.tudou.com/albumplay/hj1NLJb78_Q.html', ydl)
    results = ydl.extract_results

# Generated at 2022-06-24 13:35:14.340116
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Construct a dummy playlist url
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    # Construct a TudouPlaylistIE object
    tudou_playlist_ie = TudouPlaylistIE(url)

    assert(tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(tudou_playlist_ie.IE_NAME == 'tudou:playlist')

# Generated at 2022-06-24 13:35:18.355806
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
test_TudouPlaylistIE()

# Generated at 2022-06-24 13:35:22.697880
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE();
    assert instance._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html';
    assert instance.IE_NAME == 'tudou:playlist';

# Generated at 2022-06-24 13:35:24.512942
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # initialization
    a = TudouAlbumIE()

    # assertion
    assert True


# Generated at 2022-06-24 13:35:28.798852
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert tudou.TudouAlbumIE(None)._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:34.291586
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo' in tudou_playlist._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:35:36.336650
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouIE = TudouAlbumIE()
    assert tudouIE.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:35:38.249824
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(),InfoExtractor)
    assert isinstance(TudouAlbumIE(),InfoExtractor)

# Generated at 2022-06-24 13:35:43.560697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testurl = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    tudouplaylistie_obj = TudouPlaylistIE()
    assert testurl == tudouplaylistie_obj._build_url(
            'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:35:51.950141
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test with invalid URL
    invalid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    album = TudouAlbumIE(invalid_url)
    assert album.IE_NAME != TudouAlbumIE.IE_NAME
    # Test with valid URL
    valid_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album = TudouAlbumIE(valid_url)
    assert album.IE_NAME == TudouAlbumIE.IE_NAME


# Generated at 2022-06-24 13:35:55.917633
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test URL is valid
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(playlist_url)
    assert ie.url == playlist_url

    # test URL is invalid
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mm.html'
    ie = TudouPlaylistIE(playlist_url)
    assert ie.url != playlist_url

# Test for real_extract() function in class TudouPlaylistIE

# Generated at 2022-06-24 13:36:01.104925
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    IE.IE_NAME = 'Tudou'
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

    expected_url = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    expected_end_url = 'http://www.tudou.com/programs/view/%s'

    album_data = IE._download_json(expected_url, album_id)

# Generated at 2022-06-24 13:36:01.834050
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-24 13:36:05.623081
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = "http://www.tudou.com/listplay/" + playlist_id + ".html"
    tudou_playlist = TudouPlaylistIE(None)._real_extract(playlist_url)
    assert playlist_id == tudou_playlist['id']


# Generated at 2022-06-24 13:36:12.953328
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = self._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [self.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]
	

# Generated at 2022-06-24 13:36:22.248210
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    start_time = 0
    end_time = 1
    error = 0
    test_name = 'test_TudouAlbumIE'
    test_input = 'https://www.tudou.com/albumplay/tqd3J8W42D4.html'
    test_ans = 'tqd3J8W42D4'

# Generated at 2022-06-24 13:36:23.451609
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Instantiate a clonstructor of class TudouAlbumIE
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:30.033794
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('test')
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(tudou_playlist._TESTS) == 1
    assert tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist._TES

# Generated at 2022-06-24 13:36:36.764588
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    xtube = TudouAlbumIE()
    #assert xtube.isClass(object)
    assert hasattr(xtube, 'IE_NAME')
    assert hasattr(xtube, '_VALID_URL')
    assert hasattr(xtube, '_TESTS')
    assert xtube.IE_NAME == 'tudou:album'
    #assert xtube.isClass(InfoExtractor)
    assert type(xtube._TESTS) is list
    assert callable(xtube._real_extract)


# Generated at 2022-06-24 13:36:38.998335
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('tudou:album')

# Generated at 2022-06-24 13:36:48.505303
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .python_libs import YouTubeIE
    from .python_libs import extractor
    from .python_libs import compat_urllib_parse
    from .python_libs.extractor import unescapeHTML
    from .python_libs.extractor import parse_duration
    import os

    def _real_extract(self, url):
        identify = self._match_id(url)
        # Download web page using compat_urllib_request
        webpage = self._download_webpage(url, identify)
        title = self._html_search_regex(
            r'(?s)<h1>(.+?)</h1>', webpage, u'title')

# Generated at 2022-06-24 13:36:50.961852
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_obj = TudouPlaylistIE()
    assert tudou_playlist_obj._VALID_URL is not None


# Generated at 2022-06-24 13:36:55.479760
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_obj = TudouPlaylistIE(test_url)
    assert test_obj.valid_url
    assert test_obj.get_id() == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:36:56.771979
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:37:02.672948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE('www.tudou.com')
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert instance._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

# Generated at 2022-06-24 13:37:04.042119
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        constructorTest = TudouAlbumIE(test1, test2)
        return constructorTest.test_key == test1

# Generated at 2022-06-24 13:37:07.272395
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)

    # Unit test for test_TudouPlaylistIE.test_suitable
    def test_suitable(content):
        assert(ie.suitable(content))

    test_suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:37:10.583573
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:37:11.909354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:37:13.807828
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIEObj = TudouAlbumIE()

# Generated at 2022-06-24 13:37:22.512484
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:37:27.147939
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:37:29.234893
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-24 13:37:30.066226
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('x')

# Generated at 2022-06-24 13:37:38.485231
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case = {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209
    }

    tudou_playlist_IE = TudouPlaylistIE()
    id_code = tudou_playlist_IE._match_id(test_case['url'])
    assert id_code == test_case['info_dict']['id']



# Generated at 2022-06-24 13:37:41.276612
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = u'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert list(TudouAlbumIE._match_id(url)) != None

# Generated at 2022-06-24 13:37:52.954371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import sys
    import os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from youtube_dl.extractor.tudou import TudouPlaylistIE

    # The following tests are not really worth testing.
    # It is hard to verify the output of the tests,
    # and the tests run for a long time.

    # import doctest
    # tests = (TudouPlaylistIE, )
    # for test in tests:
    #     # The parameters may not be passed.
    #     # If they are not passed, an error will occur.
    #     result = doctest.testmod(test, raise_on_error=False,
    #                              optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)


# Generated at 2022-06-24 13:37:55.018144
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        tudoualbum = TudouAlbumIE();
        assert tudoualbum is not None;


# Generated at 2022-06-24 13:37:57.877514
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:58.858135
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(InfoExtractor)

# Generated at 2022-06-24 13:38:08.618050
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test with URLs of type "http://www.tudou.com/albumcover/<video_id>.html".
    album = TudouAlbumIE('tudou:album')
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert album.IE_NAME == 'tudou:album'
    # Test with URLs of type "http://www.tudou.com/albumplay/<video_id>.html".
    album = TudouAlbumIE('tudou:album')

# Generated at 2022-06-24 13:38:19.911397
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    assert ie._match_id(ie._TESTS[0]['url']) == 'v5qckFJvNJg'
    assert ie._real_ext

# Generated at 2022-06-24 13:38:20.692366
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:38:21.968828
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    assert 1 == 1 # pass


# Generated at 2022-06-24 13:38:25.305358
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou = TudouPlaylistIE()
    assert tudou.get_id(url) == tudou._match_id(url)

# Generated at 2022-06-24 13:38:27.691606
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    plst = GatherTube.TudouPlaylistIE()
    assert plst.name == 'TudouPlaylistIE'


# Generated at 2022-06-24 13:38:39.628525
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # None and '' where both input
    playlist1 = TudouPlaylistIE(None, '')
    assert playlist1 is not None

    # a valid Tudou playlist url is given
    playlist2 = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist2.IE_NAME == 'tudou:playlist'

    # None is input
    playlist3 = TudouPlaylistIE(None, '')
    assert playlist3 is not None

    # a valid Tudou playlist url is given with '_VALID_URL'

# Generated at 2022-06-24 13:38:50.559258
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }]
    match = ie._real_extract('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:38:58.041926
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """TudouAlbumIE simple test for constructor"""
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45
    assert TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:39:00.965976
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # 测试初始化
    test_TudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-24 13:39:02.291782
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE, InfoExtractor)

# Generated at 2022-06-24 13:39:03.612244
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:39:05.765640
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)