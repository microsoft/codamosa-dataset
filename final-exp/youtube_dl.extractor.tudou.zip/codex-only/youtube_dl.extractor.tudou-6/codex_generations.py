

# Generated at 2022-06-24 13:29:09.796489
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-24 13:29:11.557025
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE('tudou:album')
    assert constructor.ie_key() == 'Tudou'

# Generated at 2022-06-24 13:29:20.279193
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_play_list = TudouPlaylistIE()
    assert tudou_play_list.IE_NAME == 'tudou:playlist'
    assert tudou_play_list._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_play_list._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:29:22.538530
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	return 0


# Generated at 2022-06-24 13:29:29.131544
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert test._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert test._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:29:33.521251
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    global tudouplaylistie
    tudouplaylistie = TudouPlaylistIE()
    print ("Tudou Playlist InfoExtractor successfully constructed.")


# Generated at 2022-06-24 13:29:43.274093
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    import os
    import tempfile
    import tudou_dl

    # Create temporary file
    f = tempfile.NamedTemporaryFile(delete=False)

    # Write file content

# Generated at 2022-06-24 13:29:49.389505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Begin to test class TudouPlaylistIE in tudou.py")
    
    video_list = [
            ('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'zzdE77v6Mmo'), 
    ]
    for (url, video_id) in video_list:
        tudou_playlist = TudouPlaylistIE()._real_extract(url)
        
        # Check the video id.
        if tudou_playlist['id'] != video_id:
            print("The video id is not the same!")
            print("Expected: " + video_id)
            print("Actual: " + tudou_playlist['id'])
            return False
    print("Test class TudouPlaylistIE passed!")
   

# Generated at 2022-06-24 13:29:58.503997
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:30:05.197496
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    test the constructor of class TudouAlbumIE
    """
    # init
    tudou_album_ie = TudouAlbumIE()

    # check
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:30:14.860437
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # This is a routine to test constructor of class TudouPlaylistIE
    # first of all, import unittest module
    import unittest
    # then, create class TudouPlaylistIETestCase which is derived from unittest.TestCase
    class TudouPlaylistIETestCase(unittest.TestCase):
        # during the creation of class TudouPlaylistIETestCase,
        # the method __init__(self) will be called for initialization
        def __init__(self):
            # in this method, we initialize the parameters of unittest.TestCase
            # then, during the execution of the methods in class
            # TudouPlaylistIETestCase, we can call the methods in unittest.TestCase
            unittest.TestCase.__init__(self, methodName='testConstructor')
       

# Generated at 2022-06-24 13:30:24.615326
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(tudou_playlist_ie._TESTS) == 1
    assert tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'



# Generated at 2022-06-24 13:30:26.626198
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
    	TudouAlbumIE()
    except:
    	print("test class failed")


# Generated at 2022-06-24 13:30:29.504583
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    input_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    result = TudouPlaylistIE._match_id(input_url)
    assert result == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:30:36.082120
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    d = TudouPlaylistIE()
    assert d is not None
    assert d.IE_NAME == 'tudou:playlist'
    assert d._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert d._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert d._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert d._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:30:37.736251
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:30:45.678503
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist.IE_NAME == 'tudou:playlist', 'Unexpected ie name'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', 'Unexpected valid url'


# Generated at 2022-06-24 13:30:46.437171
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:30:58.498639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._downloader == ie
    assert ie._downloader.troubleshoot == [ie.troubleshoot]
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:03.605136
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
test_TudouPlaylistIE()


# Generated at 2022-06-24 13:31:08.599942
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE('test', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert t._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:31:17.644505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'


# Generated at 2022-06-24 13:31:21.734159
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    string = 'http://www.tudou.com/albumcover/McYVavTEgIc.html'
    tudou_album = TudouAlbumIE()
    print(tudou_album._match_id(string))

# Generated at 2022-06-24 13:31:32.708497
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplistIE = TudouPlaylistIE()
    assert tudouplistIE.IE_NAME == 'tudou:playlist'
    assert tudouplistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudouplistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-24 13:31:35.377437
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  test = TudouAlbumIE(None)
  # In the future, it may be a good idea to extend the test to include an
  # instance of InfoExtractor as an argument.

# Generated at 2022-06-24 13:31:38.866628
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	video_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	ie = TudouPlaylistIE(video_url)
	assert ie.url == video_url

# Generated at 2022-06-24 13:31:47.620718
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Initialize the class
    test_tudou_playlist_ie = TudouPlaylistIE()
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    # Check for get_id()
    assert test_tudou_playlist_ie.get_id(url) == "zzdE77v6Mmo"

    # Check for get_id()
    assert test_tudou_playlist_ie.get_id(url) != "zzdE77v6Mmok"

    # Check for _valid_url()
    assert test_tudou_playlist_ie._valid_url(url) == True

    # Check for _valid_url()

# Generated at 2022-06-24 13:31:49.371827
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE()
    assert td.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:31:51.752588
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:31:53.851476
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Simply test for the class constructor and the valid_url function
    """
    # TODO
    assert(1 == 1)

# Generated at 2022-06-24 13:31:57.254908
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import TudouPlaylistIE
    info_Extractor = TudouPlaylistIE.TudouPlaylistIE()
    info_Extractor.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:32:01.866948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:32:08.817738
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert isinstance(tudou_playlist, InfoExtractor)
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:32:20.267944
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:32:31.509659
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test normal case
    tudou_album_case1 = TudouAlbumIE("http://www.tudou.com/albumplay/Qn5eIDYrYBk.html")
    assert (tudou_album_case1.ie_key() == "TudouAlbumIE")
    assert (tudou_album_case1.ie_name() == "Tudou")
    assert (tudou_album_case1._VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})")
    # test wild card

# Generated at 2022-06-24 13:32:35.634670
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''TudouAlbumIE.__init__()'''
    # create an instance of class TudouAlbumIE
    tudou_album_ie = TudouAlbumIE()
    # Check type of instance is a film
    assert isinstance(tudou_album_ie, InfoExtractor)

# Generated at 2022-06-24 13:32:39.533414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    # Test the assert
    assert_raises(AssertionError, tudouAlbum)
    assert_raises(AssertionError, tudouAlbum._real_extract)


# Generated at 2022-06-24 13:32:43.211322
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:32:47.965105
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_ie = TudouPlaylistIE()
    # Test info_dict
    assert playlist_ie.info_dict is not None
    # Test _VALID_URL
    assert playlist_ie._VALID_URL is not None
    # Test _TESTS
    assert playlist_ie._TESTS is not None



# Generated at 2022-06-24 13:32:58.222362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert(tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(tudou_album_ie._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-24 13:33:09.006162
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import os
    import sys
    import inspect
    cmd_subfolder = os.path.realpath(os.path.abspath(os.path.join(os.path.split(inspect.getfile(inspect.currentframe()))[0],"youtube-dl")))
    if cmd_subfolder not in sys.path:
        sys.path.insert(0, cmd_subfolder)
    import youtube_dl
    import urlparse
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

# Generated at 2022-06-24 13:33:17.203333
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Testing constructor of TudouPlaylistIE.')
    # This should be valid.
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # This should be invalid.
    url2 = 'http://www.tudou.com/listplay/zzdE77v6Mmofd.html'
    try:
        TudouPlaylistIE(url)
        TudouPlaylistIE(url2)
    except ValueError:
        # This should be caught.
        print('Invalid url is caught!')
        flag = True
    else:
        # This should be seen.
        print('Invalid url is not caught!')
        flag = False
    if flag:
        print('Constructor of TudouPlaylistIE passed test.')

# Generated at 2022-06-24 13:33:27.971936
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert isinstance(album, InfoExtractor)
    assert hasattr(album, 'IE_NAME')
    assert hasattr(album, '_VALID_URL')
    assert hasattr(album, '_TESTS')
    assert hasattr(album, '_real_extract')
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:33:32.280739
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-24 13:33:33.712549
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert type(tudouAlbumIE) == TudouAlbumIE


# Generated at 2022-06-24 13:33:38.410283
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE('', {})
    if test_obj.__class__.__name__ != 'TudouPlaylistIE':
        raise Exception(test_obj.__class__)

# Generated at 2022-06-24 13:33:44.896046
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import get_testcases, list_testcases
    from .common import expected_warnings
    from .tudou import _download_webpage
    from .tudou import TudouAlbumIE
    with expected_warnings(['unable to extract description']):
        ie = TudouAlbumIE(None)
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    webpage = _download_webpage(
        ie._downloader,
        url,
        ie._match_id(url),
        'Downloading webpage')
    ie_result = ie.result_from_webpage(webpage, url)
    assert ie_result['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:33:48.752848
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest

# Generated at 2022-06-24 13:33:52.142998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    u = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    i = TudouAlbumIE()
    assert(i.suitable(u))

# Generated at 2022-06-24 13:33:54.538529
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()
# Output: <__main__.TudouPlaylistIE object at 0x102f89dd0>

# Generated at 2022-06-24 13:33:57.037961
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html','')
    ie.extract()

# Generated at 2022-06-24 13:33:58.173768
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:34:03.212347
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE(url, '/tmp/')
    tudouAlbumIE._match_id(url)
    #assert tudouAlbumIE._download_json()



# Generated at 2022-06-24 13:34:12.919514
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert len(TudouPlaylistIE._TESTS) == 1
    assert TudouPlaylistIE._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-24 13:34:20.956721
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:32.867449
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import os

    class AllTest(unittest.TestCase):
        def setUp(self):
            import youtube_dl.YoutubeDL
            self.ydl = youtube_dl.YoutubeDL({
                'outtmpl': u'%(id)s%(ext)s',
                'download_archive': os.path.join(os.getcwd(),".youtubedl_dl_archive"),
            })
            self.ydl.add_default_info_extractors()

        def test_album(self):
            self.ydl.extract_info('http://www.tudou.com/albumplay/g7v-bJ1c8lE/D9g63fjvznI.html')
    unittest.main()

# Generated at 2022-06-24 13:34:36.289401
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #test constructor of class TudouAlbumIE
    class_name='TudouAlbumIE'
    TudouAlbumIE(class_name, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:34:38.190861
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None, None, None)


# Generated at 2022-06-24 13:34:40.153606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = [TudouAlbumIE]
    print("Test case: Test extract of TudouAlbumIE ----------")
    assert "http://www.tudou.com/albumplay/v5qckFJvNJg.html" == info_extractor[0]._VALID_URL


test_TudouAlbumIE()

# Generated at 2022-06-24 13:34:42.064449
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE(1, 2)
    assert t == None


# Generated at 2022-06-24 13:34:50.236741
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #Test for album
    url_album = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_albumIE = TudouAlbumIE(url_album)
    tudou_albumIE.extract()
    #Test for playlist
    url_list = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE(url_list)
    tudou_playlist.extract()

# Generated at 2022-06-24 13:34:51.209176
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:34:56.129695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        tudoualbumie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg/')
    except:
        print("construct a TudouAlbumIE failed")
        raise
    else:
        print("construct a TudouAlbumIE passed")

# Generated at 2022-06-24 13:35:06.786825
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

    assert ie.ie_key() == 'Tudou'
    assert ie.ie_name() == 'tudou:playlist'

    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:35:16.895985
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    # Test extract method of class TudouPlaylistIE
    def _test_url_extract(url, **kwargs):
        ie.extract(url, downloader=None, **kwargs)

    # Valid URL
    result = _test_url_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:35:28.175302
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE(None)
    assert IE.suitable("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert IE.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert IE.suitable("tudou.com/albumplay/v5qckFJvNJg.html")
    assert not IE.suitable("http://www.tudou.com/a/zzdE77v6Mmo/&rpid=107904351&resourceId=107904351_06_05_99")

# Generated at 2022-06-24 13:35:32.545638
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()
    test_TudouAlbumIE._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(True)

# Generated at 2022-06-24 13:35:36.020106
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumcover/B8EZlkpZF6k.html"
	#youtube_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
	#test_youtube_dl.test_url_result_video_id(url, "BaW_jenozKc")
	tudou_ie = TudouAlbumIE(url)
	#tudou_ie.test_url(url)


# Generated at 2022-06-24 13:35:42.653501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE()._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert TudouPlaylistIE()._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-24 13:35:47.206074
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test.IE_NAME == 'tudou:album'
    assert test._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:55.722006
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_object = TudouPlaylistIE()
    assert test_object._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_object._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:36:00.787056
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

    if obj is None:
        raise AssertionError('TudouAlbumIE constructor returned None')

    if obj.IE_NAME != 'tudou:album':
        raise AssertionError("TudouAlbumIE.IE_NAME != 'tudou:album'. '%s' instead" % obj.IE_NAME)

    if 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' not in obj.VALID_URL:
        raise AssertionError("http://www.tudou.com/albumplay/v5qckFJvNJg.html not in TudouAlbumIE.VALID_URL")

# Generated at 2022-06-24 13:36:01.737480
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:36:08.334002
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    t.IE_NAME = 'tudou:playlist'
    t._VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    t.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t._match_id(t.url) == 'zzdE77v6Mmo'
    assert t._real_extract(t.url) == {
        'id': 'zzdE77v6Mmo',
    }

# Generated at 2022-06-24 13:36:13.825676
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case 1:
    # Test if the constructor of class TudouPlaylistIE can deal with valid URL
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(valid_url)
    assert ie.url == valid_url
    assert ie.video_id == 'zzdE77v6Mmo'



# Generated at 2022-06-24 13:36:22.291183
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url='http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	tudouPlaylistIE = TudouPlaylistIE(url)
	assert tudouPlaylistIE.url == url, "TudouPlaylistIE constructor sets the right url value"
	assert tudouPlaylistIE.IE_NAME == 'tudou:playlist', "TudouPlaylistIE constructor sets the right IE_NAME value"
	assert tudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', "TudouPlaylistIE constructor sets the right _VALID_URL value"


# Generated at 2022-06-24 13:36:22.865990
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE("")


# Generated at 2022-06-24 13:36:23.463465
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)


# Generated at 2022-06-24 13:36:31.181154
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    InfoExtractor.__bases__ = (TudouAlbumIE,)
    #Test the case when url is valid
    if TudouAlbumIE.IE_NAME in TudouAlbumIE._WORKING_IEBASE_FACTORY.ie_key_map:
        assert isinstance(TudouAlbumIE._WORKING_IEBASE_FACTORY.ie_key_map[TudouAlbumIE.IE_NAME], TudouAlbumIE)
        assert TudouAlbumIE._WORKING_IEBASE_FACTORY.ie_key_map[TudouAlbumIE.IE_NAME].IE_NAME == 'tudou:album'
        assert TudouAlbumIE._WORKING_IEBASE_FACT

# Generated at 2022-06-24 13:36:32.053586
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:37.234307
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert re.search(ie._VALID_URL, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'), 'url does not match regular expression'
    assert re.search(ie._VALID_URL, 'http://www.tudou.com/albumcover/v5qckFJvNJg'), 'url does not match regular expression'

# Generated at 2022-06-24 13:36:38.244542
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("test_tudou")

# Generated at 2022-06-24 13:36:43.529100
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)

# Generated at 2022-06-24 13:36:45.322843
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import TudouAlbumIE
    from .test import get_testcases
    from .test import tudou_testcases
    get_testcases(tudou_testcases, TudouAlbumIE)


# Generated at 2022-06-24 13:36:51.243799
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Unit test for constructor of class TudouAlbumIE")
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE()
    play = ie._real_extract(url)
    if len(play) != 2:
        print("test fail, class TudouAlbumIE, _real_extract")
    else:
        print("test pass, class TudouAlbumIE, _real_extract")

# Generated at 2022-06-24 13:36:54.443300
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
  assert ie.IE_NAME == 'tudou:album'
  assert ie.IE_DESC == '土豆专辑'
  assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:36:55.097691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()



# Generated at 2022-06-24 13:36:57.730263
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.suitable(url) == True


# Generated at 2022-06-24 13:37:00.635700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    p = TudouAlbumIE(TudouAlbumIE._VALID_URL, 'Tudou')
    assert p.playlist_mincount == 0
    assert p.playlist_maxcount == 0
    assert p.title == None
    assert p.description == None

# Generated at 2022-06-24 13:37:03.308293
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouPlaylistIE(InfoExtractor)._download_json)
    assert ie._download_json is TudouPlaylistIE(InfoExtractor)._download_json

test_TudouAlbumIE()

# Generated at 2022-06-24 13:37:04.119318
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	a = TudouPlaylistIE()


# Generated at 2022-06-24 13:37:07.119100
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    u = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    assert ie.suitable(u) != False
    assert ie._real_extract(u) is not None
    assert ie.extract(u) is not None


# Generated at 2022-06-24 13:37:08.645721
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj_TudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-24 13:37:16.563542
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()
    assert info._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert info._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:37:24.780632
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert IE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:37:25.960426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE


# Generated at 2022-06-24 13:37:36.636432
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:40.431069
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # test_TudouPlaylistIE
    assert ie._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:37:45.009047
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import TEST_PLAYLIST_ID
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist._real_extract('http://www.tudou.com/listplay/%s.html' % TEST_PLAYLIST_ID)


# Generated at 2022-06-24 13:37:56.879169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.ie_key() == 'Tudou:playlist'
    assert tudou_playlist_ie.ie_name() == 'Tudou:playlist'
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'

# Generated at 2022-06-24 13:37:58.736572
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .tudou import json

# Generated at 2022-06-24 13:38:06.947277
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    p = TudouPlaylistIE()
    assert p._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert p._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Test for method _real_extract of class TudouPlaylistIE

# Generated at 2022-06-24 13:38:12.043505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:38:18.446563
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # get a webpage http://www.tudou.com/listplay/zzdE77v6Mmo.html
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Test the constructor of class TudouPlaylistIE
    test = TudouPlaylistIE(url)
    # Test the function _entries
    test._entries()


# Generated at 2022-06-24 13:38:24.292237
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('')
    assert obj.IE_NAME == 'tudou:album'
    assert obj._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:38:35.145798
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE(
        name=r'tudou',
        downloader=r'simpleDownloader',
        params=r'params', 
        extractor=r'videoInfoExtractor',
        age_limit=r'5')
    assert tudou_album_ie.name == r'tudou'
    assert tudou_album_ie.downloader == r'simpleDownloader'
    assert tudou_album_ie.params == r'params'
    assert tudou_album_ie.extractor == r'videoInfoExtractor'
    assert tudou_album_ie.age_limit == r'5'

# Generated at 2022-06-24 13:38:37.025578
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:38:39.447411
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    
    test = TudouPlaylistIE()
    
    assert test._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]
    

# Generated at 2022-06-24 13:38:44.229467
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    #assert len(ie._TESTS) == 1
    #assert ie._TESTS[0] == 
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:38:54.858355
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.ie_name() == 'tudou:playlist'
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert not ie.suitable('http://www.tudou.com/programs/view/v5qckFJvNJg')

# Generated at 2022-06-24 13:39:05.830477
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:39:14.378784
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' 
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' 
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo' 
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209