

# Generated at 2022-06-24 13:29:10.513293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()

# Generated at 2022-06-24 13:29:11.795218
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('zzdE77v6Mmo')

# Generated at 2022-06-24 13:29:14.698974
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Start Testing")

# Constructor of class TudouAlbumIE
    # t = TudouAlbumIE()
    # print(t)


# Generated at 2022-06-24 13:29:18.886129
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._TESTS[0]['url'] == ie.test_cases[0]['url']
    assert ie.test_cases[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:29:24.683828
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('tudou:playlist')
    TudouPlaylistIE('www.tudou.com/albumplay/v5qckFJvNJg.html')
    TudouPlaylistIE('tudou.com/listplay/zzdE77v6Mmo.html')
    TudouPlaylistIE('tudou.listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:29:29.509099
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.url == url
    assert ie.playlist_id == 'zzdE77v6Mmo'
    assert ie.playlist_mincount == 209
    assert set(ie.extract_entries()) >= set(range(209))


# Generated at 2022-06-24 13:29:33.286405
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("TudouAlbumIE", "TudouAlbumIE", "TudouAlbumIE", "TudouAlbumIE")

# Generated at 2022-06-24 13:29:36.795534
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tpi = TudouPlaylistIE()
    tpi.extract(url)


# Generated at 2022-06-24 13:29:40.195422
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:29:42.610893
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:29:45.497392
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print(TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html'))

# Generated at 2022-06-24 13:29:55.338052
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import TestCommon
    from .tudou import TudouPlaylistIE
    from .tudou import TudouAlbumIE
    import inspect

    # Print function name
    TestCommon.print_testname()
    # Create a object of class TudouAlbumIE
    # Test the constructor
    print()
    print('Constructor:')
    tudou_album_ie = TudouAlbumIE()
    TestCommon.print_result(True)

    # Print function name
    TestCommon.print_testname()
    # Test the function _extract_feed_info
    print()
    print('Function:')
    print(inspect.getsource(TudouAlbumIE._extract_feed_info))
    print('Result:')

    tudou_playlist_ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:30:01.932217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Test for constructor of class TudouAlbumIE")
    url = "http://www.tudou.com/albumplay/a3qK1zmS5_g.html"
    data = TudouAlbumIE(url)
    # test for method _real_extract of class TudouAlbumIE
    print("test for method _real_extract of class TudouAlbumIE")
    data._real_extract(url)

# Generated at 2022-06-24 13:30:03.005362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()

# Generated at 2022-06-24 13:30:08.454101
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test TudouPlaylistIE"""

    # input:  a valid url of TudouPlaylistIE.VALID_URL
    # outcome: a TudouPlaylistIE object
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:30:17.828525
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:30:20.541387
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('zzdE77v6Mmo')
    # Test for the material of the playlist
    assert len(ie.playlist) == 209

# Generated at 2022-06-24 13:30:23.750514
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', "Unit test failed"

# Generated at 2022-06-24 13:30:25.450217
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test import get_testcases
    get_testcases(TudouPlaylistIE, [], skip=True)

# Generated at 2022-06-24 13:30:28.008851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    init = TudouPlaylistIE()
    playlist = init._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:30:35.696092
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    pl = TudouPlaylistIE()
    playlist_data = pl._download_json(
            'http://www.tudou.com/tvp/plist.action?lcode=%s' % pl._match_id(url), pl._match_id(url))
    entries = [pl.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in playlist_data['items']]
    results = pl.playlist_result(entries, pl._match_id(url))


# Generated at 2022-06-24 13:30:42.899399
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
        Test for TudouPlaylistIE.
    """
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_ie = TudouPlaylistIE(url)
    json_file = playlist_ie.download_list_data(url)
    assert json_file != 'error'
    print('%s test OK.' % json_file)


# Generated at 2022-06-24 13:30:48.235266
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE()._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-24 13:30:49.408316
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:30:52.166274
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj=TudouAlbumIE()
    assert obj.IE_NAME == 'tudou:album'



# Generated at 2022-06-24 13:31:01.909934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tudou_playlistIE1 = TudouPlaylistIE()
    tudou_playlistIE2 = TudouAlbumIE()

    # Test case1:
    # url1 is valid
    # playlist should be downloaded successfully
    assert tudou_playlistIE1._match_id(url1) != None
    webpage = tudou_playlistIE1._download_webpage(url1, 'zzdE77v6Mmo')
    assert webpage != None
    tudou_playlistIE1._real_extract(url1)

    # Test case2

# Generated at 2022-06-24 13:31:11.190473
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE(url)
    playlist_id = ie._match_id(url)
    assert playlist_id == "zzdE77v6Mmo"
    assert ie.IE_NAME == "tudou:playlist"
    assert ie.IE_DESC == "Tudou"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:31:15.940067
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert 'Tudou' == ie.ie_key()
    assert 'tudou:playlist' == ie.ie_name()
    assert ie.ie_description() is not None
    assert ie.VALID_URL == TudouPlaylistIE._VALID_URL
    assert ie.TEST == TudouPlaylistIE._TESTS



# Generated at 2022-06-24 13:31:19.827353
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  ie = TudouAlbumIE._real_initialize()
  assert ie.IE_NAME == TudouAlbumIE.IE_NAME
  assert ie._VALID_URL == TudouAlbumIE._VALID_URL

# Generated at 2022-06-24 13:31:23.777024
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = (TudouPlaylistIE())._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert 'entries' in info
    assert len(info['entries']) == 209



# Generated at 2022-06-24 13:31:28.217148
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    e = TudouPlaylistIE()._real_extract(url)
    assert len(e['entries']) == 209


# Generated at 2022-06-24 13:31:30.175574
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test = TudouAlbumIE();
	test.test_extract();


# Generated at 2022-06-24 13:31:38.546551
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    newobject = TudouPlaylistIE(None)
    assert newobject is not None
    assert newobject.IE_NAME is not None
    assert newobject._VALID_URL is not None
    assert newobject._TESTS is not None
    assert newobject._real_extract is not None
    assert newobject._match_id is not None
    assert newobject.url_result is not None
    assert newobject.playlist_result is not None
    assert newobject._download_json is not None
    return True


# Generated at 2022-06-24 13:31:39.928772
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html";

# Generated at 2022-06-24 13:31:40.943634
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()


# Generated at 2022-06-24 13:31:43.403457
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    TudouPlaylistIE(url)

# Generated at 2022-06-24 13:31:48.871597
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    print("test_constructor_begin")
    url = r'https://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url, 'Tudou')
    print("test_constructor_end")


# Generated at 2022-06-24 13:31:55.000259
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE('http://www.tudou.com/albumcover/j1wJFqqZHm4.html')
    assert isinstance(tudou_album, InfoExtractor)
    assert tudou_album.suitable('http://www.tudou.com/albumcover/j1wJFqqZHm4.html') == True
    assert tudou_album.suitable('http://www.tudou.com/albumplay/j1wJFqqZHm4.html') == True
    assert tudou_album.suitable('http://www.tudou.com/cover/j1wJFqqZHm4.html') == False



# Generated at 2022-06-24 13:32:04.396513
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Use pytest to verify constructor using test cases
    tudou = TudouPlaylistIE()

# Generated at 2022-06-24 13:32:07.081378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudoupl = TudouPlaylistIE(
        InfoExtractor(
            downloader=None,
            params=None,
        )
    )
    assert tudoupl._match_id(url) == 'zzdE77v6Mmo'
    assert tudoupl.ie_key() == 'Tudou:playlist'


# Generated at 2022-06-24 13:32:18.683919
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print(__name__)
	# Create the object with all valid attributes.
	tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	# Check if assignment was successful.
	assert tudou_playlist_ie.playlist_id == 'zzdE77v6Mmo'
	assert tudou_playlist_ie.playlist_url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	# If a wrong url is given, an exception is raised and a message is printed.
	# try:
	# 	tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77

# Generated at 2022-06-24 13:32:20.840769
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test constructor with no arguments
    a1 = TudouAlbumIE()
    assert(a1.IE_NAME == 'tudou:album')


# Generated at 2022-06-24 13:32:32.112250
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    ie = TudouPlaylistIE('Test')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    ie = TudouPlaylistIE(ie_name = 'Test')
    assert ie.IE_NAME

# Generated at 2022-06-24 13:32:34.751839
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    Test = ie.constructor(dict())
    pass

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-24 13:32:39.706194
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.suitable("http://www.tudou.com/albumcover/v5qckFJvNJg")


# Generated at 2022-06-24 13:32:43.375036
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:32:52.709815
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TPG = TudouPlaylistIE()
    assert TPG._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TPG._downloader is not None
    assert TPG.suitable(url) is not False
    assert TPG.IE_NAME == 'tudou:playlist'
    assert TPG._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': '209'}]

# Generated at 2022-06-24 13:32:55.558085
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:33:03.394895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.__class__.__name__ == "TudouAlbumIE"

# Generated at 2022-06-24 13:33:08.690449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # given
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected_name = 'tudou:playlist'
    # when
    tudou_playlist_ie = TudouPlaylistIE(url)
    # then
    assert tudou_playlist_ie.IE_NAME == expected_name



# Generated at 2022-06-24 13:33:10.550500
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE('combiner')
    print('test finished\n')


# Generated at 2022-06-24 13:33:16.991747
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouPlaylistIE
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouPlaylistIE.TudouAlbumIE()
    info = ie._real_extract(url)

# Generated at 2022-06-24 13:33:20.721988
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tu = TudouPlaylistIE()
    # check for regex match
    tu.match(url)
    tu._real_extract(url)

# Generated at 2022-06-24 13:33:31.708887
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    from .tudou import TudouAlbumIE
    url = "http://www.tudou.com/albumplay/eZ2IbhT1q3M.html"
    album_ie = TudouAlbumIE()
    assert album_ie._match_id(url) == "eZ2IbhT1q3M"
    assert album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert album_ie.extract("http://www.tudou.com/albumplay/eZ2IbhT1q3M.html") == album_ie._real_extract(url)

# Unit test

# Generated at 2022-06-24 13:33:33.063282
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE, InfoExtractor)


# Generated at 2022-06-24 13:33:39.025825
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert(TudouAlbumIE.IE_NAME == 'tudou:album')
	assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
	assert(TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert(TudouAlbumIE._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'})
	assert(TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-24 13:33:42.544679
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(TudouPlaylistIE.ie_key())(url)


# Generated at 2022-06-24 13:33:51.387029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE()._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }])

# Generated at 2022-06-24 13:33:56.313073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    item_tuple = ("mv", "hongkong", 'http://www.tudou.com/listplay/m_4_1_1.html', "1", "1", "1", "1", "1", "", "", "", "1")
    assert item_tuple in TudouPlaylistIE._TESTS


# Generated at 2022-06-24 13:34:07.407760
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlist = TudouPlaylistIE(None)
	assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert playlist._TESTS == [
		{
			'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
			'info_dict': {
				'id': 'zzdE77v6Mmo',
			},
			'playlist_mincount': 209,
		}
	]
	assert playlist.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:34:15.569094
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    Test_TudouPlaylistIE = TudouPlaylistIE(0, 'https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert Test_TudouPlaylistIE.name == 'Tudou'
    assert Test_TudouPlaylistIE.ie_key == 'Tudou'
    assert Test_TudouPlaylistIE.url == 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert Test_TudouPlaylistIE.urls == ['https://www.tudou.com/listplay/zzdE77v6Mmo.html']
    assert Test_TudouPlaylistIE.playlist_id == 'zzdE77v6Mmo'
    assert Test_TudouPlaylist

# Generated at 2022-06-24 13:34:16.297107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()


# Generated at 2022-06-24 13:34:27.120761
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert ie._match_id('http://www.tudou.com/albumplay/a5qckFJvNJg.html') == None
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:36.579376
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import os
    import requests
    import json
    
    from .common import InfoExtractor, ExtractorError
    from utils import (
        compat_urllib_parse,
        compat_urllib_request,
    )
    from compatible import (
        compat_str,
    )

    import _test_data_util as ut

    ###################################################################
    # Setup test cases
    ###################################################################

    def extract_testcases(urls):
        test_cases = []
        for url in urls:
            class_name_list = [x for x in url.split('/') if x and x != '.']
            if class_name_list:
                class_name = class_name_list[-1]
            else:
                class_name = url

# Generated at 2022-06-24 13:34:39.311756
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert t._download_json == 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    assert t._match_id == album_id

# Generated at 2022-06-24 13:34:40.342400
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-24 13:34:44.895147
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:49.854288
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from tudou import TudouAlbumIE
	# album_id = 'v5qckFJvNJg'
	# url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	TudouAlbumIE(None, TudouAlbumIE.ie_key(), url)

test_TudouAlbumIE()

# Generated at 2022-06-24 13:34:50.636269
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:34:56.179520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import ExtractorTest
    ExtractorTest.__name__ = "test_TudouAlbumIE"
    ExtractorTest.__doc__ = """Unit test class for constructor of class TudouAlbumIE"""

    print('Debug info: running unit test for TudouAlbumIE')
    test = ExtractorTest(TudouAlbumIE, "https://www.tudou.com/albumplay/v5qckFJvNJg.html")
    test.run_TudouAlbumIE()


# Generated at 2022-06-24 13:35:01.039535
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_initialize()
    TudouPlaylistIE().suitable(url)
    TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-24 13:35:07.420502
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE(InfoExtractor())
	assert album.ie_key() == 'TudouAlbum'
	assert album.ie_name() == 'tudou:album'
	assert album.http_headers() == None
	assert album.template() == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:35:18.120017
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE.IE_NAME == 'tudou:playlist'
    instance = IE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert instance._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert instance._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert instance.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:35:22.849641
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    Album = TudouAlbumIE()
    assert (Album.IE_NAME == "tudou:album")
    assert (Album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:35:34.049977
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(TudouPlaylistIE.ie_key()) == TudouPlaylistIE
    assert TudouPlaylistIE(TudouPlaylistIE.ie_key()).IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE(TudouPlaylistIE.ie_key())._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    tudou_playlist = TudouPlaylistIE(TudouPlaylistIE.ie_key())
    assert tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_play

# Generated at 2022-06-24 13:35:40.493563
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("*************************************************")
	print("Testing TudouAlbumIE constructor...")
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	album_id = 'v5qckFJvNJg'
	print("Testing:")
	print("url = %s" % url)
	print("album_id = %s" % album_id)
	album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
	print("album_data = %s" % album_data)
	print("Testing ended")
	print("*************************************************")


# Generated at 2022-06-24 13:35:41.489817
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouplay = TudouPlaylistIE()

# Generated at 2022-06-24 13:35:48.681145
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	valid_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	ie = TudouPlaylistIE()
	assert ie.ie_key() == 'tudou:playlist'
	assert ie.ie_name() == 'tudou:playlist'	
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:35:53.408967
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie=TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:35:55.347564
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()

# Generated at 2022-06-24 13:36:00.115297
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case for invalid url
    invalid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
    try:
        TudouPlaylistIE(invalid_url)
    except AssertionError:
        print('Invalid url tested successfully')
    else:
        print('Invalid url tested unsuccessfully')

    # Test case for valid url
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    try:
        TudouPlaylistIE(valid_url)
    except AssertionError:
        print('Valid url tested unsuccessfully')
    else:
        print('Valid url tested successfully')

# Generated at 2022-06-24 13:36:01.475079
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    obj.TudouAlbumIE()

# Generated at 2022-06-24 13:36:08.645675
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert(TudouAlbumIE.IE_NAME == 'tudou:album')
	assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
	tudou_album_test = TudouAlbumIE(None)
	assert(tudou_album_test.IE_NAME == 'tudou:album')
	assert(tudou_album_test._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:36:11.816850
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:36:16.438935
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/6CjU6KIyUJw.html'
    ie = TudouAlbumIE().ie_key()
    assert(ie in TudouAlbumIE._WORKING_IE_NAME)
    assert(TudouAlbumIE._VALID_URL.match(url))



# Generated at 2022-06-24 13:36:17.733085
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:36:27.070767
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:36:35.477124
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:36:40.306576
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class TestTudouAlbumIE(TudouAlbumIE):
        def _real_extract(self, url):
            raise Exception('should not be called')

    p = TestTudouAlbumIE()
    p.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')



# Generated at 2022-06-24 13:36:42.840003
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html','zzdE77v6Mmo')

# Generated at 2022-06-24 13:36:48.711911
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    import os
    import unittest
    test_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.join(test_dir, '..'))
    from tudou import TudouAlbumIE
    tudou_album_ie = TudouAlbumIE('Tudou')
    assert tudou_album_ie.ie_key() == 'Tudou'
    sys.path.pop(0)

# Generated at 2022-06-24 13:36:55.479593
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #  print "Testing TudouAlbumIE class constructor"
    try:
        #  print "Creating object of TudouAlbumIE class"
        tudou_albumie = TudouAlbumIE()
        #  print "TudouAlbumIE", tudou_albumie
        #  assert isinstance(tudou_albumie,TudouAlbumIE)
    except Exception:
        #  print "Test failed"
        return False
    #  print "Test succeeded"
    return True

# Generated at 2022-06-24 13:36:55.858130
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 1 == 1

# Generated at 2022-06-24 13:36:57.879637
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Just test if class TudouAlbumIE is instantiated successfully"""
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:37:02.321960
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not TudouPlaylistIE.suitable('http://www.tudou.com/tvp/alist.action')
    assert not TudouPlaylistIE.suitable('http://www.tudou.com/playlist/p/a0112058.html')


# Generated at 2022-06-24 13:37:06.912306
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.IE_NAME == "tudou:playlist")
    assert(len(TudouPlaylistIE._TESTS) == 1)
    assert(TudouPlaylistIE._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209})


# Generated at 2022-06-24 13:37:11.750299
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Unit test for constructor of class TudouAlbumIE
    """
    ie = TudouAlbumIE()
    assert hasattr(ie, "IE_NAME")
    assert ie.IE_NAME == "tudou:album"
    assert hasattr(ie, "_VALID_URL")



# Generated at 2022-06-24 13:37:13.090209
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Check if a basic instance is constructed.
    try:
        ie = TudouAlbumIE("")
        assert ie
    except:
        pytest.fail("Failed to construct a TudouAlbumIE object.")

# Generated at 2022-06-24 13:37:16.456518
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = ie._VALID_URL
    ie._match_id(url)
    ie.playlist_result(None, 'Tudou')


# Generated at 2022-06-24 13:37:27.348754
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 's_-9OKQ2zjo'

# Generated at 2022-06-24 13:37:30.426904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    actual_value = tudou_album_ie.IE_NAME
    expected_value = 'tudou:album'
    assert actual_value == expected_value

# Generated at 2022-06-24 13:37:33.603297
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_TudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-24 13:37:36.255624
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except:
        assert False, "Failed to construct an instance of class TudouPlaylistIE"


# Generated at 2022-06-24 13:37:40.099912
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    loader = TudouAlbumIE()
    cmpStr = '<TudouAlbumIE: type=album>'
    assert loader.ie_key() == cmpStr, "assertion error.  instance: %s, cmpStr: %s" % (loader.ie_key(), cmpStr)


# Generated at 2022-06-24 13:37:47.395242
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .tudou import _VALID_URL
    from .tudou import _TESTS
    for test in _TESTS:
        ie = TudouAlbumIE(test['url'], test['IE_NAME'])
        assert isinstance(ie, InfoExtractor)
        #assert ie.IE_NAME == test['IE_NAME']
        assert _VALID_URL == test['_VALID_URL']

# Generated at 2022-06-24 13:37:51.658185
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_tudouplaylist = TudouPlaylistIE()
	test_tudouplaylist.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:38:02.932744
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

  # We will construct an instance of class TudouPlaylistIE
  i = TudouPlaylistIE(False)

  # Test the instance method _match_id()
  assert i._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html") == 'zzdE77v6Mmo'
  assert i._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html?a=9") == 'zzdE77v6Mmo'
  assert i._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html?a=9&b=30") == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:38:03.502766
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:38:05.791966
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo')


# Generated at 2022-06-24 13:38:10.542354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Testing constructor of the class TudouPlaylistIE"""

    # Initialize an instance of class TudouPlaylistIE
    x = TudouPlaylistIE()

    assert type(x) == TudouPlaylistIE
    assert x.IE_NAME == 'tudou:playlist'
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(x._TESTS) == 1


# Generated at 2022-06-24 13:38:16.408939
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert len(TudouAlbumIE._TESTS) == 1
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}

# Generated at 2022-06-24 13:38:25.711013
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()
    # Test regexp
    playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Test get id
    id = playlist._match_id(url)
    assert id == 'zzdE77v6Mmo'
    # Test download page
    page = playlist._download_webpage(url, id)
    assert page
    # Test construct playlist
    playlist = playlist._real_extract(url)
    assert len(playlist) == 1
    assert 'playlist' == playlist[0]['_type']

# Generated at 2022-06-24 13:38:27.114853
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie is not None


# Generated at 2022-06-24 13:38:28.826591
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:38:31.209984
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:38:42.557228
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/albumplay/v5qckFJvNJg.html'
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:38:53.266672
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		from .. import TudouAlbumIE
	except Exception as e:
		assert False, "Fail to import TudouAlbumIE from .."

# Generated at 2022-06-24 13:38:59.741537
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('tudou:playlist', 'www.tudou.com/listplay/zzdE77v6Mmo.html', None)
    assert playlist.suitable(None)
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.valid_url('http://www.tudou.com/listplay/zzdE77v6Mmo.html')



# Generated at 2022-06-24 13:39:05.213850
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]


# Generated at 2022-06-24 13:39:08.140939
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()