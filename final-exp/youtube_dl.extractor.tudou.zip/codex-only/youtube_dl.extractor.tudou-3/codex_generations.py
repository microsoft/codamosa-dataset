

# Generated at 2022-06-24 13:29:08.994200
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    testcase = TudouAlbumIE()
    assert testcase != None

# Generated at 2022-06-24 13:29:11.147522
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test case for constructor of class TudouPlaylistIE"""
    TudouPlaylistIE(InfoExtractor(), u'https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:29:20.555707
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_cases = [
        # Invalid URL.
        ('http://www.tudou.com/listplay/', {
            'accept': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'reject': 'http://www.tudou.com/listplay/',
        }),
    ]
    name = 'TudouPlaylistIE'
    for url, expect in test_cases:
        match = TudouPlaylistIE._VALID_URL.match(url)
        if not match:
            assert not expect['accept']
        else:
            assert match.groupdict() == {'id': 'zzdE77v6Mmo'}
            assert match.group(1) == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:29:23.322431
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg'
    TudouAlbumIE(url)


# Generated at 2022-06-24 13:29:24.256365
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:26.861161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
        assert True
    except:
        assert False



# Generated at 2022-06-24 13:29:29.526157
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE._TESTS[0] == IE.test_tudou_playlist(IE)
    assert ['zzdE77v6Mmo'] == IE.extract(IE._TESTS[0]['url'])

# Generated at 2022-06-24 13:29:34.407008
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:29:35.623853
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass



# Generated at 2022-06-24 13:29:38.410118
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_instance = TudouPlaylistIE()
    assert isinstance(test_instance, InfoExtractor)
    assert test_instance.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:29:44.596246
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE("www.tudou.com/listplay/zzdE77v6Mmo.html")
    # Test function _real_extract
    tudou_playlist_ie._real_extract("www.tudou.com/listplay/zzdE77v6Mmo.html")
    return tudou_playlist_ie

# Generated at 2022-06-24 13:29:45.620813
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(common.FakeYDL(), {})


# Generated at 2022-06-24 13:29:55.421021
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE.IE_DESC == '土豆 - 发现更大的世界 http://www.tudou.com/'
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert hasattr(TudouAlbumIE, '_TESTS')
    assert hasattr(TudouAlbumIE, '_download_json')


# Generated at 2022-06-24 13:30:01.065244
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1


# Generated at 2022-06-24 13:30:09.134600
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    entries = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._match_id(entries) == playlist_id
    assert TudouPlaylistIE()._real_extract(entries)['_type'] == 'playlist'

# Generated at 2022-06-24 13:30:13.859338
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert ie._TESTS[0]['url'] == ie._TESTS[0]['info_dict']['url']


# Generated at 2022-06-24 13:30:14.904400
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-24 13:30:17.511130
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:30:19.334951
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_object = TudouPlaylistIE()

# Generated at 2022-06-24 13:30:23.250114
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ieobj = TudouAlbumIE()
    assert ieobj._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-24 13:30:28.590136
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.ie_key() == 'Tudou:album'

# Generated at 2022-06-24 13:30:30.725092
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:30:34.499117
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = InfoExtractor()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:30:42.663376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__name__ == 'TudouPlaylistIE'
    assert TudouPlaylistIE.__qualname__ == 'TudouPlaylistIE'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert hasattr(TudouPlaylistIE, '_VALID_URL')
    assert hasattr(TudouPlaylistIE, '_TESTS')
    assert hasattr(TudouPlaylistIE, '_real_extract')

# Generated at 2022-06-24 13:30:44.743949
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:30:46.152959
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE



# Generated at 2022-06-24 13:30:48.847310
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a =TuoduAlbumIE('Tudou:album')

# Generated at 2022-06-24 13:30:58.452798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE1 = TudouPlaylistIE()
    tudouPlaylistIE2 = TudouPlaylistIE()
    tudouPlaylistIE3 = TudouPlaylistIE()
    tudouPlaylistIE4 = TudouPlaylistIE()
    assert (tudouPlaylistIE1.IE_NAME == tudouPlaylistIE2.IE_NAME)
    assert (tudouPlaylistIE1.IE_NAME == tudouPlaylistIE3.IE_NAME)
    assert (tudouPlaylistIE1.IE_NAME == tudouPlaylistIE4.IE_NAME)


# Generated at 2022-06-24 13:31:01.695510
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:31:12.932963
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .common import InfoExtractor
	from .tudou import TudouAlbumIE
	from .tudou import TudouPlaylistIE
	from .tudou import TudouIE
	from .tudou import TudouVideoIE
	from .youtube import YoutubeIE
	album_IE = TudouAlbumIE()

	# Test for exception
	try:
		album_IE.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
		assert 'Exception should be raised'
	except:
		pass

	# Test for inheritance
	assert issubclass(TudouAlbumIE, InfoExtractor)
	assert issubclass(TudouPlaylistIE, InfoExtractor)
	assert issubclass(TudouIE, InfoExtractor)


# Generated at 2022-06-24 13:31:22.458261
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_instance = TudouAlbumIE('id','name','thumbnail','duration','views','uploader','uploader_url','upload_date','categories',
                                        'tags','like_count','dislike_count','age_limit','average_rating','formats','resolution','format_id',
                                        'tbr','tbn','ext','vcodec','acodec','abr','filesize','protocol','http_headers','extractor','extractor_key')
    assert tudou_album_instance.name == 'name'
    assert tudou_album_instance.description == 'description'
    assert tudou_album_instance.age_limit == 'age_limit'


# Generated at 2022-06-24 13:31:34.331855
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    import re
    import json
    import pycurl
    import StringIO
    from urllib import quote_plus

    def _download_json(url, video_id, note=None, errnote=None, fatal=True):
        try:
            return json.loads(self._download_webpage(url, video_id, note=note, errnote=errnote, fatal=fatal))
        except ValueError as ve:
            raise ExtractorError('Invalid JSON returned')

    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    video_id = "v5qckFJvNJg"


# Generated at 2022-06-24 13:31:43.619437
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #Test case 01: 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
    #'info_dict': {'id': 'zzdE77v6Mmo',},'playlist_mincount': 209,
    try:
        assert 'id' in 'zzdE77v6Mmo'
        assert 'playlist_mincount' in '209'
        assert 'url' in 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    except AssertionError:
        print("test_TudouPlaylistIE failed")

test_TudouPlaylistIE()



# Generated at 2022-06-24 13:31:49.947916
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testExtractor = TudouPlaylistIE()
    
    assert testExtractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', \
           'Invalid instance of _VALID_URL.'
    assert testExtractor.IE_NAME == 'tudou:playlist', \
           'Invalid instance of IE_NAME.'


# Generated at 2022-06-24 13:31:51.561715
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist



# Generated at 2022-06-24 13:31:55.495097
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album_ie = TudouAlbumIE()
	tudou_album_ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')



# Generated at 2022-06-24 13:32:06.980220
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_object = TudouPlaylistIE()
    expected_output = TudouPlaylistIE
    assert type(tudou_playlist_ie_object) == expected_output
    # Unit test for method _real_extract of TudouPlaylistIE
    def test_TudouPlaylistIE_real_extract():
        tudou_playlist_ie_object = TudouPlaylistIE()
        expected_output = ('zzdE77v6Mmo', 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')
        url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        playlist_id = tudou_playlist_ie_object._match_id

# Generated at 2022-06-24 13:32:14.696019
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_tudou_videos import test_TudouVideoIE
    
    def check_test(test):
        assert test['info_dict']['id'] == test['url'].split('/')[-1].split('.')[0]
    check_test(test_TudouVideoIE.TESTS[0])
    check_test(test_TudouVideoIE.TESTS[1])
    
# Test consturctor of class TudouPlaylistIE

# Generated at 2022-06-24 13:32:15.317284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:32:20.607315
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    actual_video_id = 'zzdE77v6Mmo'
    video_id = tudou._match_id(url)
    assert video_id == actual_video_id


# Generated at 2022-06-24 13:32:31.893505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_id = "zzdE77v6Mmo"
    assert playlist.IE_NAME == "tudou:playlist"
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._match_id(url) == playlist_id
    assert playlist._download_json("http://www.tudou.com/tvp/plist.action?lcode=%s" % playlist_id, playlist_id)

# Generated at 2022-06-24 13:32:39.750549
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_name = "unit-test-album"
    album_id = "unit-test-album-id"
    album_data = {"items":[{"kw":"unit-test-kw1","icode":"unit-test-icode1"},{"kw":"unit-test-kw2","icode":"unit-test-icode2"},{"kw":"unit-test-kw3","icode":"unit-test-icode3"}]}

    tudou_album_ie = TudouAlbumIE()
    tudou_album_ie._download_json = lambda url, video_id, fatal=True, headers=None: album_data
    tudou_album_ie._match_id = lambda url: album_id


# Generated at 2022-06-24 13:32:46.798037
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    assert album_id == TudouAlbumIE._match_id(u'http://www.tudou.com/albumplay/%s.html' % album_id)
    assert album_id == TudouAlbumIE._match_id(u'http://www.tudou.com/albumcover/%s.html' % album_id)


# Generated at 2022-06-24 13:32:48.235512
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE.playlist_id == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:32:51.186710
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.IE_NAME, 'example.com', '', {'id': '0123456789a'}).playlist_id == '0123456789a'

# Generated at 2022-06-24 13:33:02.348947
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert (ie._TESTS[0]['url']) == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert (ie._TESTS[0]['info_dict']['id']) == 'zzdE77v6Mmo'
    assert (ie._TESTS[0]['playlist_mincount']) == 209

# Generated at 2022-06-24 13:33:09.543573
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:33:20.101071
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    tudou_album_ie = TudouAlbumIE()
    test_url = 'http://www.tudou.com/albumcover/j0Nfv-1W2cQ.html'
    # get album id from url
    id = 'j0Nfv-1W2cQ'
    assert tudou_album_ie._match_id(test_url) == id

    # test the regex pattern
    regex_pattern = 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._VALID_URL == regex_pattern

    # test the playlist result

# Generated at 2022-06-24 13:33:29.371036
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_page = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id

# Generated at 2022-06-24 13:33:31.926201
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t = TudouAlbumIE()
	url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
	assert (t.IE_NAME == 'tudou:album')
	assert (re.match(t.VALID_URL, url) is not None)



# Generated at 2022-06-24 13:33:41.835840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Unit test for constructor of class TudouAlbumIE
    """
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    validation_id = 'v5qckFJvNJg'
    tudou_album = TudouAlbumIE(url)

    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album._match_id(url) == validation_id
    assert tudou_album.IE_NAME == 'tudou:album'



# Generated at 2022-06-24 13:33:46.454472
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj = TudouAlbumIE(object())
    result = obj._real_extract(url)
    assert result['_type'] == 'playlist'
    assert result['id'] == 'v5qckFJvNJg'
    assert result['entries'][0]['id'] == 'v5qckFJvNJg'
    

# Generated at 2022-06-24 13:33:47.924423
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:33:48.498364
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#assert(0 == 1)
	return 1

# Generated at 2022-06-24 13:33:58.771998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        assert(TudouAlbumIE.__name__ == 'TudouAlbumIE')
    except AssertionError:
        raise AssertionError("Class name not match, is it modified?")
    try:
        assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    except AssertionError:
        raise AssertionError("URL patterns are changed, please modify unit test")
    try:
        assert(TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    except AssertionError:
        raise Ass

# Generated at 2022-06-24 13:34:03.640912
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
        print('Unit test for constructor of class TudouPlaylistIE successfully')
    except:
        print('Unit test for constructor of class TudouPlaylistIE failed')

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-24 13:34:06.718161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist = TudouPlaylistIE.TudouPlaylistIE('tudou:playlist')
	assert tudou_playlist is not None


# Generated at 2022-06-24 13:34:10.977291
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:34:17.807828
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    actual = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert actual.IE_NAME == 'tudou'
    assert actual.ie_key() == 'tudou:playlist'
    assert actual.VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert actual.TEST == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-24 13:34:23.882554
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    global tudou_album_ie, url, playlist_id
    tudou_album_ie = TudouAlbumIE()
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    playlist_id = "v5qckFJvNJg"
    return tudou_album_ie._real_extract(url)["_type"] == "playlist"


# Generated at 2022-06-24 13:34:30.563527
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:34:32.629454
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # use this url 
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert ie._match_id(url) == "v5qckFJvNJg"



# Generated at 2022-06-24 13:34:34.151096
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:34:45.974902
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # album_id = v5qckFJvNJg
    instance = TudouAlbumIE()
    assert instance.IE_NAME == 'tudou:album'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(instance._TESTS) > 0
    assert instance._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert instance._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert instance._TESTS[0]['playlist_mincount'] == 45
    # check

# Generated at 2022-06-24 13:34:49.255547
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/xKjhCyt7gLU.html'
    assert TudouAlbumIE().suitable(url) == True
    obj = TudouAlbumIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert obj._match_id(url) == 'xKjhCyt7gLU'

# Generated at 2022-06-24 13:34:57.298979
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert not ie is None
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1
    assert len(ie._TESTS[0]) == 4
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert len(ie._TESTS[0]['info_dict']) == 1

# Generated at 2022-06-24 13:35:01.397674
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert list(TudouAlbumIE._get_login_info('http://www.tudou.com/albumplay/v5qckFJvNJg.html'))[0:3] == ['v5qckFJvNJg', 'album', True]


# Generated at 2022-06-24 13:35:09.722501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._TESTS[0]['url'] == url
    assert playlist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert playlist._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:35:15.953890
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    class_instance = InfoExtractor.extract(url)
    assert class_instance.__class__ == TudouPlaylistIE
    assert class_instance.ie_key() == 'Tudou:playlist'
    assert class_instance.ie_name() == 'TudouPlaylistIE'


# Generated at 2022-06-24 13:35:21.971509
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    video_url = 'http://www.tudou.com/tvp/listplay/zzdE77v6Mmo.html'
    video = TudouPlaylistIE().url_result(video_url,'Tudou','zzdE77v6Mmo','video_title')

# Generated at 2022-06-24 13:35:25.925358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test url
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    # Test constructor
    test_TudouAlbumIE = TudouAlbumIE()
    assert test_TudouAlbumIE

# Generated at 2022-06-24 13:35:36.786840
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	playlist_id = 'zzdE77v6Mmo'
	playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
	entries = [self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in playlist_data['items']]
	result = self.playlist_result(entries, playlist_id)
	result = InfoExtractor.get_info()

# Generated at 2022-06-24 13:35:42.729637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('zzdE77v6Mmo')
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]



# Generated at 2022-06-24 13:35:53.753294
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    test_class = dict()
    test_class['valid_url'] = [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        ]
    test_class['invalid_url'] = [
        'http://www.tudou.com/albumplay/v5qckFJvNJg',
        ]

# Generated at 2022-06-24 13:36:01.650588
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # This URL is copied from test case in test_TudouPlaylistIE.
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    TudouPlaylistIE.test(
        TudouPlaylistIE,
        url,
        ie=TudouPlaylistIE.ie_key())

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE.test(
        TudouAlbumIE,
        url,
        ie=TudouAlbumIE.ie_key())

# Generated at 2022-06-24 13:36:03.806535
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.is_valid_url(url)

# Generated at 2022-06-24 13:36:06.542506
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie_obj = TudouPlaylistIE()
	assert tudou_playlist_ie_obj
	assert isinstance(tudou_playlist_ie_obj,InfoExtractor)
    

# Generated at 2022-06-24 13:36:14.439182
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE().IE_NAME == 'tudou:album')
    assert(TudouAlbumIE()._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}])


# Generated at 2022-06-24 13:36:17.475341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:19.238653
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import pytest_class
    pytest_class.TudouAlbumIE()


# Generated at 2022-06-24 13:36:20.663745
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return test_TudouPlaylistIE()


# Generated at 2022-06-24 13:36:27.621583
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{'url':'http://www.tudou.com/albumplay/v5qckFJvNJg.html','info_dict':{'id':'v5qckFJvNJg'},'playlist_mincount':45}]


# Generated at 2022-06-24 13:36:35.024867
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudou_album_ie._TESTS) == 1
    assert tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert t

# Generated at 2022-06-24 13:36:36.020081
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:37.848716
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbumIE = TudouAlbumIE()
	assert tudouAlbumIE is not None

# Generated at 2022-06-24 13:36:40.260123
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import sys
	sys.path.append("../")
	from ykdl.extractors import tudou
	tudou.TudouAlbumIE(None)



# Generated at 2022-06-24 13:36:44.573163
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie= TudouAlbumIE()
    # url='http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    url='http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.extract(url)


# Generated at 2022-06-24 13:36:46.861633
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    ie.test()

# Generated at 2022-06-24 13:36:56.937756
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Given
    my_object = TudouAlbumIE()
    
    # When
    my_object.IE_NAME = 'tudou:album'
    my_object._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    my_object._TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

    my_object._real_extract(my_object._TESTS)
    # Then
    assert my

# Generated at 2022-06-24 13:36:57.424890
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1 == 1

# Generated at 2022-06-24 13:37:00.598711
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'

    assert TudouAlbumIE._VALID_URL.search(url)
    assert TudouAlbumIE.IE_NAME == 'tudou:album'



# Generated at 2022-06-24 13:37:01.267499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    simple test of TudouPlaylistIE
    """
    TudouPlaylistIE(None, None)



# Generated at 2022-06-24 13:37:02.711168
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE()
	assert obj.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:37:05.129804
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert 'www' in ie.IE_NAME
    assert 'tudou' in ie.IE_NAME
    assert 'playlist' in ie.IE_NAME
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:37:09.007838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    assert 'tudou:playlist' == ie._VALID_URL
    assert 'tudou:playlist' == ie.IE_NAME


# Generated at 2022-06-24 13:37:10.583458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-24 13:37:19.900459
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE();

    # Test _VALID_URL
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    # Test IE_NAME
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'

    # Test _real_extract
    tudou_playlist_ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:37:26.053904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        return
        # do not run this test case
        my_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        test = TudouAlbumIE(my_url)
        print("test_TudouAlbumIE succeeded")
    except:
        return
    url = test._real_extract(my_url)
    print("test_TudouAlbumIE: url = %s" % url)
    assert(isinstance(url, dict))
    return


# Generated at 2022-06-24 13:37:29.295844
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.playlist_result(1, 2) == {'_type': 'playlist',
                                        'entries': 1,
                                        'id': 2}


# Generated at 2022-06-24 13:37:34.648683
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_playlist = TudouPlaylistIE()
    assert 'tudou' in test_playlist.IE_NAME
    assert 'listplay' in test_playlist._VALID_URL
    assert test_playlist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:37:36.918999
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .TudouIE import TudouIE
    TudouIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:37:45.127274
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import pytest
    tudou_playlist_ie = TudouPlaylistIE(None)
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:37:56.881941
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]["url"] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert ie._TESTS[0]["info_dict"]["id"] == "zzdE77v6Mmo"
    assert ie._TESTS[0]["playlist_mincount"] == 209

# Generated at 2022-06-24 13:38:05.965790
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    "Unit tests for class TudouAlbumIE"

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, url):
            self.url = url
            self.info_dict = {
                'id': 'v5qckFJvNJg',
            }
            self.playlist_mincount = 45

    class MockTudouAlbumIE(TudouAlbumIE, object):
        """
        Mock class: Override _real_extract and _download_json
        in order to avoid downloading data from the real site.
        """
        def _real_extract(self, url):
            """Override _real_extract to avoid real downloading.
            """
            return MockInfoExtractor(url)


# Generated at 2022-06-24 13:38:16.506951
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert(obj.IE_NAME == 'tudou:playlist')
    assert(obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(len(obj._TESTS) == 1)
    obj._TESTS[0] = {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'}
    assert(obj._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'})


# Generated at 2022-06-24 13:38:21.792514
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Valid URLs
    test_cases = [
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ]

    for test_case in test_cases:
        assert TudouAlbumIE(test_case)

# Generated at 2022-06-24 13:38:25.946925
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test for correct creation of class TudouPlaylistIE
    tudou = TudouPlaylistIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou.suitable(url)
    assert 'tudou' in tudou.IE_NAME
    assert 'www.tudou.com' in tudou._VALID_URL


# Generated at 2022-06-24 13:38:30.314984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_album_ie = TudouAlbumIE(url, {})
    assert tudou_album_ie.url == url

# Generated at 2022-06-24 13:38:41.700575
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_data = {'items': [{'icode': 'a', 'kw': 'f'}, {'icode': 'b', 'kw': 'g'}], 'id': 1}

# Generated at 2022-06-24 13:38:44.432967
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie._match_id(ie._VALID_URL) == "v5qckFJvNJg"

# Generated at 2022-06-24 13:38:45.102745
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1 == 1

# Generated at 2022-06-24 13:38:47.038882
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:38:48.998295
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

if __name__ == "__main__":
    test_TudouPlaylistIE()

# Generated at 2022-06-24 13:38:53.649123
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from constructor.TudouAlbumIE import TudouAlbumIE
    myTudouAlbumIE = TudouAlbumIE()
    print(myTudouAlbumIE.IE_NAME)
    print(myTudouAlbumIE._VALID_URL)
    print(myTudouAlbumIE._TESTS)

# Generated at 2022-06-24 13:38:55.111864
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie is not None

# Generated at 2022-06-24 13:39:00.757858
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Check exceptions
    album_id = 'test'
    url = 'http://www.tudou.com/albumplay/%s.html' % album_id
    try:
        TudouAlbumIE._download_json(url, album_id)
    except:
        pass
    else:
        assert False, "Test failure: %s" % url

# Generated at 2022-06-24 13:39:02.470990
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(None).ie_key() == 'Tudou'

# Generated at 2022-06-24 13:39:13.744973
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    entries = 'http://www.tudou.com/programs/view/'

    # the call of _match_id, _download_json