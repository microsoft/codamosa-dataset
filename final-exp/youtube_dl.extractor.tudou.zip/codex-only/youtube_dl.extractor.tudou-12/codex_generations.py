

# Generated at 2022-06-24 13:29:10.217337
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    raise NotImplementedError

# Generated at 2022-06-24 13:29:19.773836
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case 1:
    # Test TudouPlaylistIE class constructor
    playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    response = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = dict(items=[dict(kw='tvshow_name', icode='icode')])
    url_list = ['http://www.tudou.com/programs/view/icode']

# Generated at 2022-06-24 13:29:22.923774
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playList = TudouPlaylistIE()
    playList.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:29:28.232456
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert len(TudouPlaylistIE._TESTS) > 0
    tc = TudouPlaylistIE._TESTS[0]
    actual = TudouPlaylistIE(None)._real_extract(tc['url'])._asdict()
    actual.pop('_type', None)
    actual.pop('_downloader', None)
    for k, v in tc['info_dict'].items():
        assert actual[k] == v


# Generated at 2022-06-24 13:29:37.964505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:29:40.987450
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou.core.TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")


# Generated at 2022-06-24 13:29:48.526654
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test constructor of class TudouPlaylistIE"""
    ie = TudouPlaylistIE()
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo/')
    assert not ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:29:57.832326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    info_dict = {'id': 'v5qckFJvNJg'}

# Generated at 2022-06-24 13:30:07.798944
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # "TudouPlaylistIE" instance given a valid URL
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._VALID_URL in url
    tudouplaylist = TudouPlaylistIE(url)
    assert tudouplaylist is not None
    # "TudouPlaylistIE" instance given an invalid URL
    invalid_url = r'http://www.tudou.com/listplay/.html'
    tudouplaylist = TudouPlaylistIE(invalid_url)
    assert tudouplaylist is not None




# Generated at 2022-06-24 13:30:14.269252
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    import TudouPlaylistIE
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudouPlaylistIE = TudouPlaylistIE.TudouPlaylistIE(TudouPlaylistIE.IE_NAME, url)
    assert tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-24 13:30:20.398525
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from pytube import get
	url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	album_id = "v5qckFJvNJg"
	s = get(url)
	s.__TudouAlbumIE__(url)
	assert __TudouAlbumIE__._album_id == album_id, 'Constructor of class TudouAlbumIE is failure'


# Generated at 2022-06-24 13:30:20.990041
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-24 13:30:21.523613
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass


# Generated at 2022-06-24 13:30:23.998280
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.name == 'tudou:playlist'


# Generated at 2022-06-24 13:30:32.225489
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .common import expected_warnings
    from .test_tudou import test_tudou_playlist_result
    

# Generated at 2022-06-24 13:30:38.451910
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert test._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert test.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:30:43.219083
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import HEADRequest
    from .tudou import TudouAlbumIE
    a = TudouAlbumIE(None)._real_initialize()
    assert(isinstance(a._request_webpage('http://dummy.com', None, HEADRequest()), HEADRequest))


# Generated at 2022-06-24 13:30:44.660999
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.ie_key())(test_TudouAlbumIE.__doc__)


# Generated at 2022-06-24 13:30:57.329178
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tu = TudouPlaylistIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tu.url = url
    tu_id = tu._match_id(url)
    tu_playlist = tu._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % tu_id, tu_id)
    tu_playlist_mincount = 45
    tu_playlist_dict = dict()
    for tu_item in tu_playlist['items']:
        tu_playlist_dict[tu_item['icode']] = tu_item['kw']

# Generated at 2022-06-24 13:31:00.780199
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(TudouAlbumIE._VALID_URL.rstrip('/') + '/', '')
           is not None), "Object construction test failed"

# Generated at 2022-06-24 13:31:06.490968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #TudouAlbumIE(InfoExtractor, TudouIE, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    TudouAlbumIE(InfoExtractor, TudouIE, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:31:08.348210
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # assert that the class for a website exists
    assert TudouPlaylistIE is not None


# Generated at 2022-06-24 13:31:17.494496
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:18.526845
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-24 13:31:21.783921
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    p = TudouPlaylistIE()
    p._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:31:24.574775
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'Tudou'
    assert ie.ie_name() == 'tudou:playlist'

# Generated at 2022-06-24 13:31:28.373451
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	tudou_playlist = TudouPlaylistIE()
	tudou_playlist._real_extract(url)

# Generated at 2022-06-24 13:31:32.758804
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:31:43.358671
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudouAlbumIE._TESTS) == 1
    assert tudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudouAlbumIE._TESTS[0]['info_dict'] == {
        'id': 'v5qckFJvNJg',
    }
    assert tud

# Generated at 2022-06-24 13:31:49.274482
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert isinstance(ie, InfoExtractor)
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert hasattr(TudouAlbumIE, '_TESTS')
    assert hasattr(TudouAlbumIE, '_real_extract')
    assert hasattr(TudouAlbumIE, '_download_json')

# Generated at 2022-06-24 13:31:53.723330
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize the class
    ie = TudouAlbumIE()

    # Assert the extracted id
    assert ie._match_id("http://www.tudou.com/albumcover/v5qckFJvNJg") == "v5qckFJvNJg"
    assert ie._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html") == "v5qckFJvNJg"


# Generated at 2022-06-24 13:31:57.562752
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    err_msg = "Constructor of class TudouPlaylistIE should create an instance of the class"
    assert isinstance(TudouPlaylistIE('Tudou'),TudouPlaylistIE), err_msg


# Generated at 2022-06-24 13:32:03.475765
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE()
    assert tudouPlaylist.IE_NAME == 'tudou:playlist'
    assert tudouPlaylist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:32:04.687684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('test')

# Generated at 2022-06-24 13:32:16.379875
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert instance.playlist_result([], '') == {'entries': [], 'id': ''}
    assert instance.playlist_result([{'song1': 'a'}, {'song2': 'b'}], 'tudou:461536') == {'entries': [{'song1': 'a'}, {'song2': 'b'}], 'id': 'tudou:461536'}

# Generated at 2022-06-24 13:32:17.028184
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:32:19.641617
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    string = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tu = TudouAlbumIE()
    if tu.suitable(string):
        tu.extract(string)
    else:
        print('url does not match!')


# Generated at 2022-06-24 13:32:21.399321
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  test = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:32:23.380876
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")


# Generated at 2022-06-24 13:32:34.611114
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album = TudouAlbumIE()
	assert tudou_album.IE_NAME == 'tudou:album'
	assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert tudou_album._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	assert tudou_album._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
	assert tudou_album._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:32:38.538692
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Testcase's constructor
    extractor = TudouAlbumIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:32:40.858517
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie



# Generated at 2022-06-24 13:32:44.811600
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert(TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45)
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:32:53.599089
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS.__len__() == 1
    assert len(TudouAlbumIE._TESTS[0]) == 3
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:33:04.898304
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for the constructor of class TudouAlbumIE

    test_tudouAlbumIE = TudouAlbumIE(None)

    assert test_tudouAlbumIE.IE_NAME == 'tudou:album'

    assert test_tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    test = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

    assert test == test_tudou

# Generated at 2022-06-24 13:33:10.410934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Real URL
    url = 'http://www.tudou.com/listplay/wwM9R2KkHic.html'
    # Expected output
    playlist_id = 'wwM9R2KkHic'
    # Testing
    result = ie._match_id(url)
    # Expected output of testing
    expected_result = playlist_id
    assert result == expected_result

# Generated at 2022-06-24 13:33:20.769977
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:33:26.397851
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1


# Generated at 2022-06-24 13:33:36.134125
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Cover URL
    cover_test_urls = [
        'http://www.tudou.com/albumcover/d3Iq1O8OlnI.html',
        'http://www.tudou.com/albumcover/d3Iq1O8OlnI',
        'http://www.tudou.com/albumcover/d3Iq1O8OlnI/'
    ]
    # Play URL

# Generated at 2022-06-24 13:33:40.809161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .TudouPlaylistIE import TudouPlaylistIE
    # Create object of class TudouPlaylistIE
    obj = TudouPlaylistIE()
    # Call the constructor of class TudouPlaylistIE
    obj.__init__()



# Generated at 2022-06-24 13:33:43.140177
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistie = TudouPlaylistIE()
    assert (tudouplaylistie.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-24 13:33:47.654849
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case 1
    tudou_playlist_1 = TudouPlaylistIE()
    tudou_playlist_1.extract("http://www.tudou.com/listplay/NrLNdA_vZgs.html")


# Generated at 2022-06-24 13:33:55.833729
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    data = ie.url_result('https://www.tudou.com/albumplay/b_O53JBSa6U.html')
    assert data == {
        '_type': 'url_transparent',
        'url': 'http://www.tudou.com/programs/view/b_O53JBSa6U/',
        'ie_key': 'Tudou',
        'id': 'b_O53JBSa6U',
        'playlist_mincount': 36
    }

# Generated at 2022-06-24 13:34:05.984924
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    init = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert init.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert init.playlist_id == 'zzdE77v6Mmo'
    assert init.playlist_data == 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    assert init.playlist_url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-24 13:34:11.470192
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE.ie_key())
    assert ie.IE_NAME == 'tudou:album'
    assert ie.ie_key() == 'TudouAlbum'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:18.105273
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import TudouAlbumIE
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    playlist_id = 'v5qckFJvNJg'
    # create new instance
    tudou_album_ie = TudouAlbumIE()
    # assert IE_NAME is set correctly
    expectedIE_NAME = 'tudou:album'
    actualIE_NAME = tudou_album_ie.IE_NAME
    assert actualIE_NAME == expectedIE_NAME
    # assert IE_DESC is set correctly
    expectedIE_DESC = 'Tudou Albums'
    actualIE_DESC = tudou_album_ie.IE_DESC
    assert actualIE_DESC == expectedIE_DESC
    # assert _VAL

# Generated at 2022-06-24 13:34:28.922154
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE()._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE()._TESTS[0]['playlist_mincount'] == 209



# Generated at 2022-06-24 13:34:37.281903
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE(url)

# Generated at 2022-06-24 13:34:39.266862
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist != None


# Generated at 2022-06-24 13:34:41.097055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE._VALID_URL)

# Generated at 2022-06-24 13:34:51.937161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url="http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    self=TudouPlaylistIE(url)

# Generated at 2022-06-24 13:34:53.156167
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE()
    assert test_obj


# Generated at 2022-06-24 13:34:57.535041
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playListIE = TudouPlaylistIE()
    assert playListIE
    assert playListIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-24 13:35:01.247212
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html');
	assert ie.IE_NAME == 'tudou:album';


# Generated at 2022-06-24 13:35:05.286739
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-24 13:35:12.259440
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }]
    assert "test" == "test"

# Generated at 2022-06-24 13:35:18.923696
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import FakePycurl
    try:
        class MockPycurl(FakePycurl):
            def getinfo(self, info_type):
                if info_type == pycurl.CONTENT_TYPE:
                    return 'application/json;charset=utf-8'
                else:
                    return super(MockPycurl, self).getinfo(info_type)
            def getresponse(self):
                return '[{"icode": "12345678910", "kw": "test"}]'
    except ImportError:
        # TODO: Consider using mpycurl
        pass
    else:
        MockPycurl.setup()
        TudouPlaylistIE._download_json = lambda *args: FakePycurl._curl.getresponse()

# Generated at 2022-06-24 13:35:23.635977
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_album_id = 'v5qckFJvNJg'
    assert TudouAlbumIE._match_id(test_url) == test_album_id

# Generated at 2022-06-24 13:35:27.911516
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	albumid = "npC6HBxz7TI"
	album_info = TudouAlbumIE()._real_extract("http://www.tudou.com/albumcover/%s.html" % albumid)
	assert album_info['id'] == albumid

# Generated at 2022-06-24 13:35:38.171105
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Create an instance of class TudouPlaylistIE to test methods by real tudou playlist url
    test_TudouPlaylistIE = TudouPlaylistIE(test_url)
    assert test_TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert test_TudouPlaylistIE.IE_DESC == 'tudou.com (playlist)'
    assert test_TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:35:40.584534
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_tudou_playlist_ie = TudouPlaylistIE(InfoExtractor)

# Generated at 2022-06-24 13:35:48.227296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    * It's designed as a unit test for constructor of class TudouPlaylistIE
    * It tried to test the constructor in the following way.
    * 1) First create a TudouPlaylistIE instance by passing a url of playist.
    * 2) Run extract_entries to get playlist data in a list.
    * 3) Check the number of playlist entries.
    * 4) Check the number of playlist items
    * 5) Check the type of playlist items
    '''
    tudou = TudouPlaylistIE()
    tudou_playlist = tudou.extract_entries('http://www.tudou.com/listplay/zzdE77v6Mmo.html');
    assert(len(tudou_playlist) == 1)

# Generated at 2022-06-24 13:35:56.360621
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/a/v5qckFJvNJg/&bid=05&iid=382126334&resourceId=5_05_05_99&v=1.3&ik=5c5a7d8a5e&aid=67&ck=6657&rpid=382130714&pg=1&ch=0', printlog)
    assert ie.album_id == 'v5qckFJvNJg'
    assert ie.album_data is not None
    pass

# Generated at 2022-06-24 13:36:04.104617
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE._VALID_URL, TudouPlaylistIE._TESTS)
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj.IE_DESC == '土豆网视频列表'
    assert obj.ie_key() == 'TudouPlaylist'
    assert obj.suitable(TudouPlaylistIE._VALID_URL)
    assert obj.working()
    assert obj.result_type() == 'playlist'
    assert obj.can_extract()


# Generated at 2022-06-24 13:36:06.902343
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE(None)
    tudou_playlist._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:36:16.232449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('tudou:playlist', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' and \
           ie._TESTS == [{
           'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
           'info_dict': {
              'id': 'zzdE77v6Mmo',
           },
           'playlist_mincount': 209,
           }]
    #assert ie.playlist_result([], 'zzdE77v6Mmo') == {'_type': 'playlist

# Generated at 2022-06-24 13:36:25.368974
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = []

# Generated at 2022-06-24 13:36:28.664628
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    class_name = 'TudouAlbumIE'
    TudouAlbumIE(url,class_name)


# Generated at 2022-06-24 13:36:35.478379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Build an example url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Information expected to be returned by the unit test
    expected_info = {
        'id': 'zzdE77v6Mmo'
    }
    # Create a instance of the class
    tudou_playlist = TudouPlaylistIE(url)
    # Call the method _match_id
    actual_info = tudou_playlist._match_id(url)
    assert actual_info == expected_info['id']


# Generated at 2022-06-24 13:36:36.512748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-24 13:36:45.569403
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie.IE_DESC == '土豆 - 发现更大的世界'
    assert ie.URL_TEMPLATES == []
    assert ie.BROWSER_PARAMS == {}
    assert ie.VIDEO_CODE_REGEXES == [re.compile(r'(?P<id>[\w-]{11})')]
    assert ie.REQUIRED_PARAMS == {}

# Generated at 2022-06-24 13:36:47.446841
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:54.964583
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .extractor import (
        InfoExtractor,
        get_info_extractor
    )
    ie = get_info_extractor(TudouAlbumIE.IE_NAME)
    info_extractor = InfoExtractor()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert isinstance(ie, TudouAlbumIE)
    assert ie.suitable(url)
    assert ie._real_extract(url) == info_extractor._real_extract(url)

# Generated at 2022-06-24 13:36:56.675019
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO: write this unit test
    print("Unit test for constructor of class TudouPlaylistIE\n")



# Generated at 2022-06-24 13:37:04.336848
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE(url)
    playlist_id = tudou_playlist._match_id(url)
    assert playlist_id == 'zzdE77v6Mmo'
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    playlist_data = tudou_playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

# Generated at 2022-06-24 13:37:05.669622
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('TudouAlbumIE','args')

# Generated at 2022-06-24 13:37:17.689641
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumcover/Gp6CzV7l8w0.html')
    assert tudou_album_ie.url == 'http://www.tudou.com/albumcover/Gp6CzV7l8w0.html'
    assert tudou_album_ie.album_id == 'Gp6CzV7l8w0'
    assert tudou_album_ie.url_result == 'http://www.tudou.com/programs/view/{icode}'
    assert tudou_album_ie.album_url == 'http://www.tudou.com/tvp/alist.action?acode={id}'


# Generated at 2022-06-24 13:37:18.725108
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE()


# Generated at 2022-06-24 13:37:21.280900
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    Test for constructor of class TudouPlaylistIE
    '''
    x = TudouPlaylistIE()
    example_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_url = x._match_id(example_url)
    assert test_url == "zzdE77v6Mmo"

# Generated at 2022-06-24 13:37:22.133222
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:37:32.724490
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test with valid URL
    valid_playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    m = tudou_playlist_ie._VALID_URL_RE.match(valid_playlist_url)
    assert m is not None

    # Test with invalid URL
    invalid_playlist_url = 'http://www.tudou.com/'
    tudou_playlist_ie = TudouPlaylistIE()
    m = tudou_playlist_ie._VALID_URL_RE.match(invalid_playlist_url)
    assert m is None

    # Test with empty URL
    invalid_playlist_url = ''
    tudou_playlist

# Generated at 2022-06-24 13:37:39.738662
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist.url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist.playlist_id = 'zzdE77v6Mmo'
    tudou_playlist.playlist_extractor()
    assert tudou_playlist.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:37:45.655944
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i=TudouPlaylistIE()
    playlist_id="zzdE77v6Mmo"
    url="http://www.tudou.com/listplay/%s.html" % playlist_id
    assert i._match_id(url)==playlist_id
    assert i._real_extract(url)['id']==playlist_id


# Generated at 2022-06-24 13:37:53.449501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test the constructor
    TudouPlaylistIE.__name__ = 'TudouPlaylistIE_unit_test'
    i = TudouPlaylistIE()
    assert i.ie_key() == 'TudouPlaylist'
    assert i.ie_name() == 'TudouPlaylistIE_unit_test'
    assert i.ie_description() == 'Tudou Playlist'
    assert i.ie_version() == '0.0.1'
    assert i.working


# Generated at 2022-06-24 13:38:00.239874
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_pl = TudouPlaylistIE(url)

    assert tudou_pl.url == url, 'Url of TudouPlaylistIE is wrong'
    assert tudou_pl._TEST, 'TEST is false'
    assert tudou_pl.playlist_mincount == 209, 'Number of videos on the playlist is wrong'



# Generated at 2022-06-24 13:38:09.429057
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	"""
	This is the testing function for TudouPlaylistIE
	"""
	print('Testing TudouPlaylistIE')
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	instance = TudouPlaylistIE( url )

	print('Unit test for TudouPlaylistIE.url_result')
	print('The program should be toutiao-v')
	print('The program is : ' + instance.url_result( url, 'Tudou', 'toutiao-v', 'nothing'))
	print('Unit test for TudouPlaylistIE.playlist_result')
	entries = [instance.url_result(url, 'Tudou', 'zzdE77v6Mmo', 'nothing')]

# Generated at 2022-06-24 13:38:10.641648
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)


# Generated at 2022-06-24 13:38:15.278068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:38:18.803047
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    module = __import__("tudou")
    inst = module.TudouAlbumIE()
    inst.download("http://www.tudou.com/albumplay/v5qckFJvNJg.html")


# Generated at 2022-06-24 13:38:20.492122
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), InfoExtractor)

# Generated at 2022-06-24 13:38:21.208545
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:38:27.928642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize Object
    test = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Assert the library module used
    assert test.IE_NAME == 'tudou:album'
    # Assert that the given url can be handled by the module
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # Assert the test case

# Generated at 2022-06-24 13:38:38.966394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    m = TudouPlaylistIE.__new__(TudouPlaylistIE)
    assert m.__name__ == 'TudouPlaylistIE'
    assert m.IE_NAME == 'tudou:playlist'
    assert m._VALID_URL.match("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert m._TESTS[0].url == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert m._TESTS[0].info_dict["id"] == "zzdE77v6Mmo"
    assert m._TESTS[0].playlist_mincount == 209


# Generated at 2022-06-24 13:38:41.363300
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    try:
        raise AssertionError('error')
    except AssertionError:
        print('test_TudouPlaylistIE')

# Generated at 2022-06-24 13:38:51.585447
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  try:
    # testcase 1
    # input param
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.url == url
  except AssertionError as e:
    print(e)
  try:
    # testcase 2
    # input param
    url = 'http://www.tudou.com/albumcover/TjzQwBd6U_0.html'
    ie = TudouAlbumIE(url)
    assert ie.url == url
  except AssertionError as e:
    print(e)

test_TudouAlbumIE()

# Generated at 2022-06-24 13:38:58.407141
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = InfoExtractor._download_xml(InfoExtractor(),
                                                'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [InfoExtractor.url_result(
        'http://www.tudou.com/programs/view/%s' % item.icode,
        'Tudou', item.icode,
        item.kw) for item in playlist_data.items]
    
    playlist_result = InfoExtractor.playlist_result(InfoExtractor(), entries, playlist_id)

# Generated at 2022-06-24 13:39:04.608501
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE._build_url_result('http://www.tudou.com/albumplay/v5qckFJvNJg.html'))
    assert ie.name == 'tudou:album'
    assert ie.urls == ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']



# Generated at 2022-06-24 13:39:14.962644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE();
	assert ie.IE_NAME == "tudou:playlist"	
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
	assert ie._TESTS[0]['playlist_mincount'] == 209