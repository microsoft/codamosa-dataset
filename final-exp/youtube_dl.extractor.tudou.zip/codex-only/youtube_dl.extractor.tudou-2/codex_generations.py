

# Generated at 2022-06-24 13:29:09.082915
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'Tudou' == TudouAlbumIE().ie_key()

# Generated at 2022-06-24 13:29:11.065859
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'Tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-24 13:29:19.891574
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ''' Unit test for constructor of class TudouPlaylistIE '''
    url_1 = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    url_2 = "http://www.tudou.com/listplay/NjU5NzM5.html" 
    tudou_playlist_1 = TudouPlaylistIE(url_1)
    tudou_playlist_2 = TudouPlaylistIE(url_2)
    assert tudou_playlist_1.url == url_1
    assert tudou_playlist_2.url == url_2

# Generated at 2022-06-24 13:29:29.284208
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.name == 'tudou:playlist'
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:29:31.765038
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:42.042692
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
	download_webpage = lambda url: "test"
	_download_json = lambda url, video_id: {'items':[{'kw':'test1', 'icode':'test0'}, {'kw':'test2', 'icode':'test1'}]}
	extract_urls = lambda webpage: ["http://www.tudou.com/programs/view/test0", 
		"http://www.tudou.com/programs/view/test1"]
	class InfoExtractor:
		def __init__(self, ie_name, ie_id):
			self.ie_name = ie_name
			self.ie_id = ie_

# Generated at 2022-06-24 13:29:52.597218
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album.IE_NAME == 'tudou:album'
    assert tudou_album.ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album.ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album.ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:29:54.370812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE()

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-24 13:29:55.144223
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()


# Generated at 2022-06-24 13:30:06.990227
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }
    playlist_mincount = 209

    playlist_id = ie._match_id(url)
    assert playlist_id == 'zzdE77v6Mmo'

    playlist_data = ie._download_json(
            'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

# Generated at 2022-06-24 13:30:09.545082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie =  TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')



# Generated at 2022-06-24 13:30:15.435326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert ie.video_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:30:23.545922
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._real_extract(test_url)['id'] == 'zzdE77v6Mmo'
    

# Generated at 2022-06-24 13:30:27.773197
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie.id == 'v5qckFJvNJg'


# Generated at 2022-06-24 13:30:29.153241
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE();
    print(album);

test_TudouAlbumIE();

# Generated at 2022-06-24 13:30:30.906431
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE.IE_DESC)

# Generated at 2022-06-24 13:30:42.942510
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE', 'class name should be TudouAlbumIE'

# Generated at 2022-06-24 13:30:46.995816
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html');
    assert(tudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-24 13:30:48.342113
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:30:56.483499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    # Test whether the constructor is called with 'tudou:playlist' as the ie_key.
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_IE = TudouPlaylistIE(url, 'tudou:playlist')
    assert tudou_playlist_IE.ie_key == 'tudou:playlist'
    return



# Generated at 2022-06-24 13:31:00.310940
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:01.096620
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(tuple()) != None)

# Generated at 2022-06-24 13:31:08.855501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    class SubTudouPlaylistIE(TudouPlaylistIE):
        pass

    sub_tudou_playlist_ie = SubTudouPlaylistIE("SubTudouPlaylistIE", "SubTudouPlaylistIE")

    # Check that the init method was called appropriately
    assert sub_tudou_playlist_ie.ie_key == "SubTudouPlaylistIE"
    assert sub_tudou_playlist_ie.ie_name == "SubTudouPlaylistIE"


# Generated at 2022-06-24 13:31:16.781720
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    p = TudouPlaylistIE();
    assert p.IE_NAME == 'tudou:playlist'
    assert p._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert p._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert p._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert p._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-24 13:31:21.684664
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = TudouPlaylistIE()
    result = info_extractor.get_info('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:31:24.128561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        TudouAlbumIE(url)
    except:
        assert False, 'TudouAlbumIE() constructor test failed'
    assert True, 'Success'



# Generated at 2022-06-24 13:31:26.021647
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.__class__.__name__ == "TudouAlbumIE"

# Generated at 2022-06-24 13:31:35.628024
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE._download_webpage = lambda self, url, video_id: 'test'
    TudouPlaylistIE._download_json = lambda self, url, video_id: {'items': [{'kw': 'test', 'icode': 'test'}]}
    playlist = TudouPlaylistIE(url)
    assert playlist.__name__ == 'tudou:playlist'
    assert playlist._match_id.match(url).group('id') == 'zzdE77v6Mmo'



# Generated at 2022-06-24 13:31:39.553527
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_instance = TudouAlbumIE()
    tudou_album_instance.IE_NAME
    tudou_album_instance._VALID_URL
    tudou_album_instance._TESTS


# Generated at 2022-06-24 13:31:43.183669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album_ie = TudouAlbumIE(TudouIE(), 'tudou:album', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert tudou_album_ie

# Generated at 2022-06-24 13:31:47.386110
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE(InfoExtractor())
    assert constructor._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:52.428367
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE.playlist_result == 'playlist_result'



# Generated at 2022-06-24 13:31:58.883735
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # The correct input
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE(url) != -1
    
    # The wrong input, this will raise exception
    #url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    #assert TudouAlbumIE(url) != -1

# Generated at 2022-06-24 13:32:01.414965
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:32:02.934549
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    assert x is not None
    

# Generated at 2022-06-24 13:32:09.200833
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	playlist = InfoExtractor()._real_extract(url)
	assert playlist.keys() == ['_type', 'id', 'entries']
	assert playlist['id'] == 'zzdE77v6Mmo'
	assert playlist['_type'] == 'playlist'
	assert playlist['entries'] == []


# Generated at 2022-06-24 13:32:19.418192
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    td_playlist_ie = TudouPlaylistIE()
    assert td_playlist_ie.IE_NAME == 'tudou:playlist'
    assert td_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert td_playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-24 13:32:20.752136
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test != None


# Generated at 2022-06-24 13:32:29.904499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE()._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }

# Generated at 2022-06-24 13:32:36.387093
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # The input url is valid
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(test_url)
    assert ie.ie_key() == 'Tudou'
    assert ie.url == test_url
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:32:41.752727
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create instance
    TudouPlaylistIE(TudouPlaylistIE._download_json, TudouPlaylistIE._match_id, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', TudouPlaylistIE._VALID_URL)


# Generated at 2022-06-24 13:32:43.809369
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_tudou import test_TudouAlbumIE
    test_TudouAlbumIE()

# Generated at 2022-06-24 13:32:48.816048
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:32:52.567460
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    results = [
        {'id': 'v5qckFJvNJg',
         'playlist_mincount': 45}
    ]
    for result in results:
        assert_true(TudouAlbumIE(result['id']) is not None)

# Generated at 2022-06-24 13:33:03.849377
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class UrlLoad():
        def get_url(url):
            dict = {
                'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg': 'tudou_album.json',
            }
            return dict[url]
    TudouAlbumIE._download_json = UrlLoad
    IE_instant = TudouAlbumIE()
    playlist = IE_instant.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(playlist['id'] == 'v5qckFJvNJg')

# Generated at 2022-06-24 13:33:13.158643
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    print("\nUnit test for constructor of class TudouAlbumIE:")

    # Input parameter
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    # Output parameter
    # assertEqual is used for unit test of equality.
    # assertTrue and assertFalse are used for unit test of boolean value.
    # assertIsNone is used for unit test that a variable is None.
    # assertIsNotNone is used for unit test that a variable is not None.

    print('\ntest_TudouAlbumIE.test_TudouAlbumIE()')
    print('Input parameter url: ' + url)

    # Construct an instance of class TudouAlbumIE.
    NEW_TudouAlbumIE = TudouAlbumIE(url)

    # Ass

# Generated at 2022-06-24 13:33:16.687535
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    tudou_album_ie._real_extract(url)

# Generated at 2022-06-24 13:33:18.495581
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE(None)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:33:21.795260
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:33:24.851266
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')._TEST == True

# Test if the default parameter for the constructor of class TudouAlbumIE
# is correct.

# Generated at 2022-06-24 13:33:27.158131
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("Test construct class TudouAlbumIE")
	t = TudouAlbumIE(None)
	print("Test passed")


# Generated at 2022-06-24 13:33:32.276394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist = TudouPlaylistIE(url)
    assert tudou_playlist.get_id() == "zzdE77v6Mmo"
    assert tudou_playlist.get_url() == url
    

# Generated at 2022-06-24 13:33:33.608205
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert isinstance(TudouPlaylistIE(),InfoExtractor)


# Generated at 2022-06-24 13:33:34.850467
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t != None


# Generated at 2022-06-24 13:33:43.581169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i.IE_NAME == 'tudou:playlist'
    assert i._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert i._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:33:47.498214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie._TESTS[0]['url'] == url

# Generated at 2022-06-24 13:33:58.177693
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE.IE_DESC == '土豆网 (Tudou) - 列表'
    assert TudouPlaylistIE.info_extractors == None
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:33:59.498885
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_obj = TudouAlbumIE()
    assert test_obj


# Generated at 2022-06-24 13:34:10.420614
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/album/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:34:15.169639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    # _VALID_URL doesn't support the old URL format
    assert ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:34:19.640887
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_key('Hello') == 'Tudou:album:Hello'
    assert ie.ie_name() == 'tudou:album'
    assert ie.ie_name('Hello') == 'tudou:album:Hello'
    assert ie.playlist_count() == 45
    assert ie.playlist_index() == 0

# Generated at 2022-06-24 13:34:31.674446
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DESC == '土豆 - 发现更多好玩的'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:34:34.642303
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouplaylistie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	assert tudouplaylistie is not None


# Generated at 2022-06-24 13:34:45.185393
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from mock import patch

	def _mock_download_json(url, playlist_id):
		return {
			'items':[{
				'kw':'tudou1',
				'icode':'tudou1'
			}]
		}
	with patch('youtube_dl.extractor.tudou.TudouAlbumIE._download_json', side_effect=_mock_download_json):
		tudou_album = TudouAlbumIE()
		assert tudou_album._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:34:47.759606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/yOuFoysS0V8.html'
    TudouAlbumIE(url)

# Generated at 2022-06-24 13:34:56.401058
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html");
    assert tudou_playlist_ie.IE_NAME == "tudou:playlist";
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html';

# Generated at 2022-06-24 13:34:59.477105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('tudou:album', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:35:07.759214
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:35:10.939740
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('tudou:album')
    assert tudou_album_ie.ie_key() == 'Tudou'
    assert tudou_album_ie.ie_code() == 'tudou:album'


# Generated at 2022-06-24 13:35:12.374385
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-24 13:35:18.597492
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    global _TudouAlbumIE
    _TudouAlbumIE = TudouAlbumIE()
    assert _TudouAlbumIE.IE_NAME == 'tudou:album'
    assert _TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:25.359918
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	playlist_mincount = 45
	tudou_album_ie = TudouAlbumIE()
	tudou_album_ie.url_result(url, 'Tudou', 'v5qckFJvNJg', '超级女声')
	tudou_album_ie.playlist_result(url, playlist_mincount)

# Generated at 2022-06-24 13:35:36.336766
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'Tudou'
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not ie.suitable('http://www.tudou.com/albumcover/AbO39UQo98Q.html')
    assert ie.search_ie_key('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'TudouPlaylist'
    assert ie.search_ie_key('http://www.tudou.com/albumcover/AbO39UQo98Q.html') == 'TudouAlbum'
    assert ie.search_

# Generated at 2022-06-24 13:35:38.246032
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html', 'Tudou') is not None

# Generated at 2022-06-24 13:35:41.821651
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-24 13:35:47.540866
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # Test case
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    response = ie.urlopen(url)

    # Assertion
    assert(ie._VALID_URL.match(url))
    assert(response)
    assert(ie._real_extract(url))


# Generated at 2022-06-24 13:35:49.827015
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(InfoExtractor())._match_id(TudouAlbumIE(InfoExtractor())._VALID_URL) != None

# Generated at 2022-06-24 13:36:00.355923
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # The constructor of class InfoExtractor
    def __init__(self, downloader=None):
        """Constructor.
        Args:
            downloader (BaseDownloader)
        """
        self._downloader = downloader
    # The constructor of class InfoExtractor
    def __init__(self, ie, downloader=None):
        """Constructor.
        The old parameters are just left for backward compatibility,
        you should use a 'IE_NAME' attribute instead.
        Args:
            ie (str): The name of the InfoExtractor.
            downloader (BaseDownloader)
        """
        self._ies = [ie] if isinstance(ie, compat_str) else ie
        self._downloader = downloader
        self.age_limit = None

# Generated at 2022-06-24 13:36:01.336507
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()


# Generated at 2022-06-24 13:36:09.805893
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test when url is an album cover page
    album_cover_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(album_cover_url)
    assert tudou_album_ie._VALID_URL == TudouAlbumIE._VALID_URL
    assert tudou_album_ie._match_id(album_cover_url) == 'v5qckFJvNJg'

    # Test when url is an album play page
    album_play_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(album_play_url)
    assert tudou_

# Generated at 2022-06-24 13:36:15.275236
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # init
    from .tudou import TudouAlbumIE
    ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    # test
    assert ie._match_id == ie._match_id(TudouAlbumIE._VALID_URL)
    assert ie._match_id == ie._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:36:17.584408
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    unit_test_TudouPlaylistIE = TudouPlaylistIE()
    assert(unit_test_TudouPlaylistIE.IE_NAME == "tudou:playlist")
    

# Generated at 2022-06-24 13:36:18.188613
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-24 13:36:21.057798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-24 13:36:23.760107
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:30.314284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg';

# Generated at 2022-06-24 13:36:31.537327
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_playlist_obj = TudouAlbumIE()


# Generated at 2022-06-24 13:36:34.750879
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(InfoExtractor)._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:36:37.749075
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    initTest = TudouAlbumIE(None)
    if initTest:
        print("Create object of class TudouAlbumIE successful")
    else:
        print("Fail to create object")


# Generated at 2022-06-24 13:36:38.729313
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)

# Generated at 2022-06-24 13:36:48.329232
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert test_TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert test_TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert test_TudouPlaylistIE._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}

# Generated at 2022-06-24 13:36:49.261353
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:36:51.638708
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('tudou:album')
    print(tudou_album_ie)

# Generated at 2022-06-24 13:36:53.898863
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Testing Playlist initializer')
    tsi = TudouPlaylistIE()
    assert tsi
    print('Passed')


# Generated at 2022-06-24 13:36:56.493749
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import ItagType
    from . import tudou_album 
    assert ItagType.MOBILE == tudou_album.TudouAlbumIE.IE_NAME

# Generated at 2022-06-24 13:37:00.817722
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:05.183590
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """TudouAlbum: constructor"""
    # This URL should be valid
    TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    # This URL should be invalid
    try:
        TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')
    except ValueError:
        pass

# Generated at 2022-06-24 13:37:08.646116
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(InfoExtractor)._real_extract(
        "http://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-24 13:37:11.126471
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i.IE_NAME == "tudou:playlist"


# Generated at 2022-06-24 13:37:14.847923
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.playlist_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:17.430486
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_TudouPlaylistIE = TudouPlaylistIE()
	assert test_TudouPlaylistIE != None


# Generated at 2022-06-24 13:37:27.801505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('www', 'tudou.com', 'listplay')
    assert tudou_playlist.name == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:37:29.524907
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()

# Generated at 2022-06-24 13:37:33.700388
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Init
    tudouAlbumIE = TudouAlbumIE()
    # Execute
    tudouAlbumIE._real_extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:37:41.277128
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class args:
        pass
    args.url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    args.playliststart = 1
    args.playlistend = 10
    args.extract_flat = True

    playlist = TudouAlbumIE._real_extract(
        TudouAlbumIE(args),
        "http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert playlist is not None
    assert len(playlist['entries']) == 10


# Generated at 2022-06-24 13:37:46.323539
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = ie._match_id(url)
    album = ie._real_extract(url)
    assert(album_id == album['id'])


# Generated at 2022-06-24 13:37:47.959384
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE(InfoExtractor)

# Generated at 2022-06-24 13:37:59.551355
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    folder = os.path.dirname(os.path.abspath(__file__))
    assert os.path.isfile(folder + '/__init__.py')
    if not os.path.isdir(folder + '/tests'):
        os.mkdir(folder + '/tests')
        test_file = open(folder + '/tests/test_tudou_album.py', 'w')
        import_str = 'from . import ' + 'tudou_album' + '\n'
        test_file.write(import_str)

        test_str = 'def test_' + 'tudou_album' + '():\n'
        test_str += '    inst = ' + 'tudou_album' + '.TudouAlbumIE()\n'

# Generated at 2022-06-24 13:38:05.366219
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'https://www.tudou.com/albumcover/QnfYBhCN3eo.html'
    instance = TudouAlbumIE()
    assert instance.suitable(url) is True
    infoExtractor = instance.extract(url)
    assert instance.IE_NAME == infoExtractor['_type']
    assert infoExtractor['id'] == 'QnfYBhCN3eo'

# Generated at 2022-06-24 13:38:15.764669
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert(IE.IE_NAME == 'tudou:playlist')
    assert(IE.IE_DESC == 'Playlist from Tudo.com')
    assert(IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(IE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])


# Generated at 2022-06-24 13:38:22.279261
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test valid url
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Test cases of invalid urls
    invalid_urls = ['http://www.tudou.com/listplay/1234.html',
                    'https://www.tudou.com/listplay/zzdE77vm.html'
                    ]
    for url in invalid_urls:
        assert TudouPlaylistIE._VALID_URL_RE.match(url) is None
    # Test cases of valid urls

# Generated at 2022-06-24 13:38:25.945955
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_obj = TudouPlaylistIE()
    assert test_obj.suitable(url)
    assert test_obj._VALID_URL == url
    assert test_obj.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:38:28.573212
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE._VALID_URL)

# Generated at 2022-06-24 13:38:40.320939
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:38:48.206025
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE._VALID_URL, TudouAlbumIE._TESTS[0]['url'])
    assert tudou_album_ie.name == TudouAlbumIE.IE_NAME
    assert tudou_album_ie._VALID_URL == TudouAlbumIE._VALID_URL
    assert tudou_album_ie.url == TudouAlbumIE._TESTS[0]['url']

# Generated at 2022-06-24 13:38:50.805517
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:38:57.833909
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist = TudouPlaylistIE()
	assert tudou_playlist.IE_NAME == 'tudou:playlist'
	assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert tudou_playlist._TESTS and isinstance(tudou_playlist._TESTS, list)


# Generated at 2022-06-24 13:39:01.171203
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    video = InfoExtractor(url)
    video.download()
    return


# Generated at 2022-06-24 13:39:06.550289
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert TudouPlaylistIE._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:39:12.495558
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = InfoExtractor()
    tudou_playlist_ie = info_extractor.tudou_playlist_ie
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie_info = tudou_playlist_ie._real_extract(url)
    assert ie_info is not None
