

# Generated at 2022-06-24 13:29:19.379528
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    test_cases = (
        (
            'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            {
                'id': 'zzdE77v6Mmo',
                'extractor': 'TudouPlaylistIE',
                'module': 'tudou',
            }
        ),
    )

    for test_case in test_cases:
        playlist_ie = TudouPlaylistIE(test_case[0])
        assert playlist_ie.test() == True
        assert playlist_ie.extract()['id'] == test_case[1]['id']
        assert playlist_ie.ie_key() == test_case[1]['extractor']
        assert playlist_ie.ie_key() == test_

# Generated at 2022-06-24 13:29:20.365894
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:29:29.017748
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:29:32.390907
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 13:29:33.568776
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:29:35.512540
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie != None

# Generated at 2022-06-24 13:29:42.934820
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:29:46.165946
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    playlist_mincount = 45
    assert tudouAlbumIE._real_extract(url)['playlist_mincount'] == playlist_mincount


# Generated at 2022-06-24 13:29:47.116668
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie

# Generated at 2022-06-24 13:29:54.383624
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert (TudouAlbumIE._VALID_URL ==
            r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE._TESTS ==
           [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
             'info_dict': {'id': 'v5qckFJvNJg'},
             'playlist_mincount': 45}])

# Generated at 2022-06-24 13:29:58.366940
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(url)
    assert tudou_playlist_ie.url == url
    assert tudou_playlist_ie.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:29:59.099604
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE

# Generated at 2022-06-24 13:30:00.014485
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'tudou.com' in TudouAlbumIE._VALID_URL

# Generated at 2022-06-24 13:30:03.457571
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        #Unit test for constructor of class TudouAlbumIE
        video = TudouAlbumIE()
        assert video is not None
    except Exception as e:
        assert False



# Generated at 2022-06-24 13:30:05.145642
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return TudouPlaylistIE()

# Generated at 2022-06-24 13:30:14.134959
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.IE_NAME=='tudou:playlist')
    assert(TudouPlaylistIE._VALID_URL==r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS[0]['url']=='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id']=='zzdE77v6Mmo')

# Generated at 2022-06-24 13:30:23.989602
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    T = TudouPlaylistIE()
    T._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')
    T.url_result(
        'http://www.tudou.com/programs/view/Mmw7VYkZcHY',
        'Tudou', 'Mmw7VYkZcHY',
        '少年张三丰之贪狼传')

# Generated at 2022-06-24 13:30:30.287718
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url =('http://www.tudou.com/albumplay/v5qckFJvNJg.html',)
    ie = TudouAlbumIE()
    if ie._VALID_URL == TudouAlbumIE._VALID_URL:
        ie = TudouPlaylistIE()
        if ie._VALID_URL == TudouPlaylistIE._VALID_URL:
            print ('Test for constructor passed')
        else:
            print ('Url or class name is not matching')
    else:
        print ('Url or class name is not matching')

# Generated at 2022-06-24 13:30:39.908868
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_id = 'MRGcxmBmpHU'
	album_url = 'http://www.tudou.com/albumcover/MRGcxmBmpHU.html'
	album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id

	instance = TudouAlbumIE()
	album_url_match_id = instance._match_id(album_url)
	assert(album_id == album_url_match_id)

	album_data_json = instance._download_json(album_data, album_id)


# Generated at 2022-06-24 13:30:42.566466
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE('1')
    except:
        print("Constructor not working properly")



# Generated at 2022-06-24 13:30:48.777949
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	pass

url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
# 由url构造IE对象，传入参数url
ie = TudouPlaylistIE(url)
# 对IE对象进行检查
ie.suitable(url)
# 真正的获取信息函数
ie.extract()
# _VALID_URL

# Generated at 2022-06-24 13:30:51.364294
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL.find('(?P<id>[\\w-]{11})') is not -1

# Generated at 2022-06-24 13:30:59.937655
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	
	# Constructor parameters list
	paramsList = [{
		'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
	}]

	# Should test the first item in the paramsList
	td_playlist = TudouPlaylistIE()
	# _download_json
	td_playlist._download_json();
	# _real_extract
	td_playlist._real_extract();
	# extract
	td_playlist.extract();

	# Test result
	assert td_playlist.result == ''


# Generated at 2022-06-24 13:31:03.998890
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a.IE_NAME == 'tudou:album'
    assert a._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert a._TESTS == [
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg'
            },
            'playlist_mincount': 45
        }
    ]


# Generated at 2022-06-24 13:31:14.641222
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    list_url_cases = [
        "http://www.tudou.com/albumcover/v5qckFJvNJg.html",
        "http://www.tudou.com/albumplay/v5qckFJvNJg.html",
        "http://www.tudou.com/albumplay/v5qckFJvNJg/",
        "http://www.tudou.com/albumplay/v5qckFJvNJg",
    ]

    for url in list_url_cases:
        assert TudouAlbumIE._VALID_URL == TudouAlbumIE._VALID_URL_TEMPLATE % "albumcover" or TudouAlbumIE._VALID_URL == TudouAlbumIE._VALID_URL_TEMPLATE % "albumplay"
       

# Generated at 2022-06-24 13:31:19.071025
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album = TudouAlbumIE()
    assert(tudou_album.suitable(url))
    tudou_album._real_extract(url)

# Generated at 2022-06-24 13:31:22.752717
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url) 

    assert ie.handler_name == "Tudou"
    assert ie.video_id == "v5qckFJvNJg"

    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS[0]['url'] == ie.TESTS[0]['url']

# Generated at 2022-06-24 13:31:23.730480
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:31:29.384871
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import get_testdata_file, get_results_for_url
    # __init__
    ie = TudouAlbumIE()
    assert ie
    # _real_extract
    results = get_results_for_url(ie, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:31:30.747394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist

# Generated at 2022-06-24 13:31:41.992330
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    T = TudouPlaylistIE()
    assert T.IE_NAME == 'tudou:playlist'
    assert T._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Test case:
    #  http://www.tudou.com/listplay/zzdE77v6Mmo.html
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    kw = 'test'
    ret = T._real_extract(url)
    id_list = []
    for video in ret['entries']:
        id_list.append(video['id'])
    id_list.sort()

# Generated at 2022-06-24 13:31:45.711955
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	TudouPlaylistIE(url)
	

# Generated at 2022-06-24 13:31:46.617040
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()

# Generated at 2022-06-24 13:31:48.760332
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    sys.argv[1] = 'tudou.TudouAlbumIE'
    execfile('tudou/TudouAlbumIE.py')

# Generated at 2022-06-24 13:31:53.530282
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie.SEARCH_KEY == None
    assert ie._VALID_URL == '^https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})$'

# Generated at 2022-06-24 13:31:58.439462
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouIE = TudouPlaylistIE()
    assert tudouIE.ie_key() == 'tudou:playlist'
    assert tudouIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:32:01.154131
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:32:05.815299
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert (tudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-24 13:32:12.314202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    if __name__ == '__main__':
        test_instance = TudouPlaylistIE()
        url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        print('Validity test for URL \'%s\': ' % url +
              ('Success' if test_instance._match_id(url) ==
               'zzdE77v6Mmo' else 'Failed'))


# Generated at 2022-06-24 13:32:13.548594
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.IE_NAME, 'TudouAlbumIE')


# Generated at 2022-06-24 13:32:23.082901
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:32:26.500387
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from unit import UnitTests

    test = UnitTests(TudouPlaylistIE, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    test.run()


# Generated at 2022-06-24 13:32:33.599104
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE("test")
	print("test: ", test)
	print("test.IE_NAME: ", test.IE_NAME)
	print("test.test_url: ", test.test_url)
	print("test._VALID_URL: ", test._VALID_URL)
	print("test._TESTS: ", test._TESTS)
	print("test._TEST: ", test._TEST)

# Generated at 2022-06-24 13:32:38.655380
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('abc5229233', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

    assert(ie.IE_NAME == 'tudou:album')
    assert(ie.pattern == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(ie.id == 'abc5229233')


# Generated at 2022-06-24 13:32:40.964484
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj != None

# Generated at 2022-06-24 13:32:43.916063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)



# Generated at 2022-06-24 13:32:53.050365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DESC == '土豆-中国第一视频网站'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert ie._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-24 13:33:03.992688
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert ie._TESTS[0]['playlist_mincount'] == 45



# Generated at 2022-06-24 13:33:07.170148
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou.ie_key() == 'TudouAlbum'

# Generated at 2022-06-24 13:33:10.680836
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:33:21.092789
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	testPlaylist = TudouPlaylistIE(
		'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
		'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html',
		'./tudoudata/playlist/zzdE77v6Mmo.json')
	assert testPlaylist.playlist_id == 'zzdE77v6Mmo'
	assert testPlaylist.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:33:22.083468
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:33:30.414390
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == "tudou:playlist"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://data.vod.itc.cn/?new=/%(id)s&vid=%(id)s&plat=17&mkey=%(key)s&ch=tv&cateCode=0&range=1-10000&pay=0&src=1'
    assert ie.ITAGS == {
        '18': {'container': 'mp4', 'resolution': '360p', 'video_profile': 'baseline'},
        '22': {'container': 'mp4', 'resolution': '720p', 'video_profile': 'high'},
    }
    assert ie.real_initialize() is None
    assert ie

# Generated at 2022-06-24 13:33:33.695318
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(len(TudouPlaylistIE._TESTS) > 0)
    for test_dic in TudouPlaylistIE._TESTS:
        yield check_download_url, (test_dic, )


# Generated at 2022-06-24 13:33:36.701526
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE('tudou:album'), InfoExtractor)


# Generated at 2022-06-24 13:33:39.666472
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:33:43.073406
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE("tudou:playlist", '', 'https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudouPlaylist.extractor_key() == "tudou:playlist"
    assert tudouPlaylist.ie_key() == "TudouPlaylist"

# Generated at 2022-06-24 13:33:49.450777
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	id = ie.back_id()
	assert id == 'zzdE77v6Mmo'
	url = ie.back_url()
	assert url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-24 13:33:52.871989
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE('Tudou', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')._VALID_URL is not None
	

# Generated at 2022-06-24 13:33:59.229082
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Start executing unit test for constructor of class TudouPlaylistIE")
    result = TudouPlaylistIE(input={"url": "http://www.tudou.com/listplay/zzdE77v6Mmo.html"})
    if str(type(result)) == "<class 'ytdl_tudou.extractor.tudou.TudouPlaylistIE'>":
        print("Pass constructor of class TudouPlaylistIE")
    else:
        print("Fail constructor of class TudouPlaylistIE")


# Generated at 2022-06-24 13:34:05.765411
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():    
    instance = TudouPlaylistIE()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == "tudou:playlist"
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(instance._TESTS) == 1


# Generated at 2022-06-24 13:34:14.935744
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE = {
        "input": "http://www.tudou.com/listplay/zzdE77v6Mmo.html",
        "id": "zzdE77v6Mmo",
        "class": "TudouPlaylistIE"
    }
    TudouAlbumIE = {
        "input": "http://www.tudou.com/albumplay/v5qckFJvNJg.html",
        "id": "v5qckFJvNJg",
        "class": "TudouAlbumIE"
    }


# Generated at 2022-06-24 13:34:15.485380
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-24 13:34:22.916398
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [playlist.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    assert playlist.playlist_result(entries, playlist_id)


# Generated at 2022-06-24 13:34:26.359913
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	obj = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	obj._real_extract()

# Generated at 2022-06-24 13:34:27.450217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('TudouAlbumIE')

# Generated at 2022-06-24 13:34:33.405091
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    example_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tuple_obj = TudouPlaylistIE._extract_url(example_url)
    expt_id = 'zzdE77v6Mmo'
    assert tuple_obj.suitable(example_url)
    assert tuple_obj.id == expt_id


# Generated at 2022-06-24 13:34:34.612101
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj


# Generated at 2022-06-24 13:34:41.581702
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test: TudouAlbumIE"""

    album_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    album_id = "v5qckFJvNJg"
    tudou_album = TudouAlbumIE(album_url,album_id)

    assert tudou_album.IE_NAME == 'tudou:album', 'unit test: tudou:album failed'

# Generated at 2022-06-24 13:34:44.507429
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:34:45.561767
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    list = TudouPlaylistIE()

# Generated at 2022-06-24 13:34:47.722788
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE(): 
	assert TudouAlbumIE()._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}

# Generated at 2022-06-24 13:34:50.427529
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('')
    if not ie._VALID_URL:
        print ('VALID_URL is empty!')


# Generated at 2022-06-24 13:34:53.280511
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE()
    obj.extract(url)


# Generated at 2022-06-24 13:34:54.471172
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:35:04.813975
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL.match('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert not TudouAlbumIE._VALID_URL.match('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert not TudouAlbumIE._VALID_URL.match('http://www.tudou.com/albumplay/v5qckfjvnjg.html')
    assert not TudouAlbumIE._VALID_URL.match('http://www.tudou.com/albumcover/v5qckfjvnjg.html')

# Generated at 2022-06-24 13:35:10.366980
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from sys import argv, exit
	from re import match
	from pprint import pformat

	if len(argv) != 2:
		exit(1)

	try:
		id = match(TudouAlbumIE._VALID_URL, argv[1]).group('id')
	except:
		exit(2)

	print(pformat(TudouAlbumIE()._real_extract(argv[1])))
	return



# Generated at 2022-06-24 13:35:13.944930
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE(url)
    tudouAlbumIE.extract()
    # tudouAlbumIE.extract_url(url)


# Generated at 2022-06-24 13:35:19.042997
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    class TestTudouAlbumIE(unittest.TestCase):
        def test_constuctor(self):
            self.assertRaises(TypeError, TudouAlbumIE, None)
            self.assertRaises(TypeError, TudouAlbumIE, 1)
            self.assertRaises(TypeError, TudouAlbumIE, 3.14)
            self.assertRaises(TypeError, TudouAlbumIE, True)
            IE = TudouAlbumIE(IE_NAME='TEST')
            self.assertEqual('TEST', IE.ie_key())
    unittest.main()

# Generated at 2022-06-24 13:35:24.639627
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE()
    assert tudou_albumIE.IE_NAME == 'tudou:album'
    assert tudou_albumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:35:33.805638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	ie = TudouPlaylistIE()
	info = ie.extract(url)
	assert info['id'] == 'zzdE77v6Mmo'
	assert info['comp'] == 'tudou'
	assert info['module'] == 'tudou'
	assert info['upload_date'] == None
	assert info['title'] == None
	assert info['description'] == None
	assert info['thumbnail'] == None
	assert info['duration'] == 0
	assert info['webpage_url'] == url


# Generated at 2022-06-24 13:35:39.418464
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert isinstance(tudou_album_ie._TESTS, list)


# Generated at 2022-06-24 13:35:42.282668
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	m1 = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:35:53.548068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._download_json.__name__ == '_download_webpage'
    assert ie._match_id.__name__ == '_match_id'
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:35:59.192237
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE(object)
    assert tudouAlbumIE.name == 'tudou:album'
    assert tudouAlbumIE.ie_key() == 'tudou:album'
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:36:07.578719
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:09.611267
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        test_TudouAlbumIE = TudouAlbumIE()
        assert False
    except:
        assert True


# Generated at 2022-06-24 13:36:10.599598
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('a', 'b')

# Generated at 2022-06-24 13:36:14.977327
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouPlaylist = TudouPlaylistIE()
	assert(tudouPlaylist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')

test_TudouPlaylistIE()


# Generated at 2022-06-24 13:36:16.565194
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE('url')

# Generated at 2022-06-24 13:36:19.384309
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html" 
    item = TudouAlbumIE(url)
    print(item.entries)

# Generated at 2022-06-24 13:36:23.182603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_dict = {'id': 'zzdE77v6Mmo'}
    IE = InfoExtractor(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert IE.extract() == info_dict


# Generated at 2022-06-24 13:36:25.409361
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-24 13:36:28.364062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-24 13:36:31.578596
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE._VALID_URL.match(url)



# Generated at 2022-06-24 13:36:41.901300
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie.IE_DESC == '土豆网 - 列表视频'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:36:42.893885
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-24 13:36:48.348623
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudou_album_ie._TESTS) == 1
    assert tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert tud

# Generated at 2022-06-24 13:36:49.261396
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print(TudouAlbumIE())

# Generated at 2022-06-24 13:36:57.454164
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album._VALID_URL =="https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"
    assert album.IE_NAME =="tudou:album"
    assert album._TESTS ==[{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:37:05.109056
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == "tudou:album"
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

# Generated at 2022-06-24 13:37:09.809800
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    albumIE = TudouAlbumIE()
    assert albumIE._match_id(url) == "v5qckFJvNJg"


# Generated at 2022-06-24 13:37:13.276674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        assert(TudouPlaylistIE == 'TudouPlaylistIE')
    except:
        assert(TudouPlaylistIE == 'TudouPlaylistIE')


# Generated at 2022-06-24 13:37:14.325929
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE()

# Generated at 2022-06-24 13:37:17.326940
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    result = TudouPlaylistIE(url)



# Generated at 2022-06-24 13:37:18.300275
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    unit testing for constructor of class TudouAlbumIE
    """
    TudouAlbumIE()

# Generated at 2022-06-24 13:37:22.426536
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:37:25.321306
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    Object = TudouAlbumIE(None)
    assert isinstance(Object, TudouAlbumIE)


# Generated at 2022-06-24 13:37:34.049106
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/zvV7mjGmDtw.html")
    assert_equal("http://www.tudou.com/albumplay/zvV7mjGmDtw.html", ie.url)
    assert_equal("Tudou", ie.ie_key())
    assert_equal("http://www.tudou.com/albumplay/zvV7mjGmDtw.html", ie.url)
    assert_equal("TudouAlbumIE", ie.ie_key())
    ie = TudouAlbumIE("http://www.tudou.com/albumcover/zvV7mjGmDtw.html")

# Generated at 2022-06-24 13:37:35.922472
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')


# Generated at 2022-06-24 13:37:42.879225
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistIE = TudouPlaylistIE()
    assert tudouplaylistIE.info().get('id') == 'test_playlist_id'
    assert tudouplaylistIE.info().get('_type') == 'url'
    assert tudouplaylistIE.info().get('url') == 'http://www.tudou.com/listplay/test_playlist_id.html'
    assert tudouplaylistIE.info().get('title') == 'test_playlist_title'
    assert tudouplaylistIE.info().get('ext') == 'mp4'
    assert tudouplaylistIE.info().get('ie_key') == 'Tudou'
    assert tudouplaylistIE.info().get('id') == 'test_playlist_id'
    assert t

# Generated at 2022-06-24 13:37:54.767778
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE._VALID_URL = TudouPlaylistIE._VALID_URL.replace('^https?://', '')
    TudouPlaylistIE._TESTS[0]['url'] = TudouPlaylistIE._TESTS[0]['url'].replace('^https?://', '')
    TudouPlaylistIE._TESTS[0]['info_dict'] = {'id': 'zzdE77v6Mmo'}
    TudouPlaylistIE._TESTS[0]['playlist_mincount'] = 209
    TudouPlaylistIE.real_extract = TudouPlaylistIE._real_extract
    TudouAlbumIE._VALID_URL = TudouAlbumIE._VALID_URL.replace('^https?://', '')
    TudouAlbumIE._TES

# Generated at 2022-06-24 13:37:55.876210
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:38:01.180883
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) >= 1


# Generated at 2022-06-24 13:38:10.098379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]
    playlist = ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:38:11.104756
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE()


# Generated at 2022-06-24 13:38:16.942319
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:38:20.767693
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou = TudouAlbumIE()
	assert(tudou._VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})")

# Generated at 2022-06-24 13:38:21.800383
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE,InfoExtractor)


# Generated at 2022-06-24 13:38:25.128356
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE_list = [TudouAlbumIE()]
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    for IE in IE_list:
        if IE.suitable(url):
            IE.download(url)
            break


# Generated at 2022-06-24 13:38:26.074036
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(extractor='foo')

# Generated at 2022-06-24 13:38:30.900442
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.__class__.__name__ == 'TudouAlbumIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:38:34.983916
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    assert hasattr(e, 'name')
    assert hasattr(e, '_VALID_URL')
    assert hasattr(e, '_TESTS')
    


# Generated at 2022-06-24 13:38:40.979805
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.get_url_regex() == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', "check get_url_regex"
    assert playlist.get_name() == 'tudou:playlist', "check get_name"



# Generated at 2022-06-24 13:38:45.261959
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE('tudou', 'tudou.com')

    assert(tudou.ie_key() == 'tudou')
    assert(tudou.ie_id() == 'tudou.com')


# Generated at 2022-06-24 13:38:48.155064
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('creating class instance')
    TudouPlaylistIE = TudouPlaylistIE()
    print(TudouPlaylistIE)
#

# Generated at 2022-06-24 13:38:58.829728
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_listplay_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_listplay_id = 'zzdE77v6Mmo'
    tudou_listplay_dict = {'id': 'zzdE77v6Mmo'}
    tudou_listplay_playlist_mincount = 209
    tudou_listplay_result = {
        'url': tudou_listplay_url,
        'info_dict': {
            'id': tudou_listplay_id
        },
        'playlist_mincount': tudou_listplay_playlist_mincount
    }
    # Call function _real_extract of class TudouPlaylistIE to get result
    tudou_list

# Generated at 2022-06-24 13:39:02.277798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html';
    TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-24 13:39:03.988201
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo')


# Generated at 2022-06-24 13:39:06.995213
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:39:09.429053
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None, 'http://www.tudou.com/albumcover/yXq3Fz.html', None, None, None)

# Generated at 2022-06-24 13:39:14.841548
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert TudouAlbumIE._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg/') == 'v5qckFJvNJg'