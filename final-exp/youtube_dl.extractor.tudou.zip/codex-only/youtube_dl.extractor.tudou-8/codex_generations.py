

# Generated at 2022-06-24 13:29:12.066693
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test that the constructor of a class can be used outside
    """
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:29:14.602732
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE('http://www.tudou.com/albumcover/d1NIQcY92VA.html')


# Generated at 2022-06-24 13:29:19.445661
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # test_class = TudouPlaylistIE()
    # test_class.extract(url)
    # test_class.suitable(url)
    # test_class.url_result(url)
    # test_class._real_extract(url)
    # test_class.add_default_values()
    # test_class.add_ie()
    # test_class.add_info_extractor()
    # test_class.add_info_extractors()
    # test_class.add_supported_ie()
    # test_class.add_supported_ies()
    # test_class.add_video_info_extractor()
    # test_class._download_webpage(

# Generated at 2022-06-24 13:29:24.020191
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:29:25.922298
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Unit test for constructor of TudouPlaylistIE"""
    test_object = TudouPlaylistIE()
    assert test_object is not None

# Generated at 2022-06-24 13:29:27.494352
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()
    assert inst.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:29:32.744251
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # case1
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:29:41.042831
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    filename = 'tudou:playlist'
    ie = TudouPlaylistIE(filename, filename)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:29:45.226601
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    expected = TudouAlbumIE(url)
    assert expected.IE_NAME == 'tudou:album'
    assert url == expected.url

# Generated at 2022-06-24 13:29:55.078121
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.BR_DESC == 'ilook'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_build_brigades')

# Generated at 2022-06-24 13:30:00.547672
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    exp_playlist_id = 'zzdE77v6Mmo'
    assert tudouplaylist.TudouPlaylistIE._match_id(tudouplaylist.TudouPlaylistIE(), valid_url) == exp_playlist_id

# Generated at 2022-06-24 13:30:02.151772
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert tuple(TudouPlaylistIE._TESTS) != ()

# Generated at 2022-06-24 13:30:06.497361
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    temp = TudouPlaylistIE().suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert temp

test_TudouPlaylistIE()


# Generated at 2022-06-24 13:30:07.497905
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:30:11.506278
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
	assert ie._match_id('www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:30:14.587934
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	x = 'http://www.tudou.com/album/v5qckFJvNJg.html'
	assert(x in (IE.IE_NAME for IE in IE_NAME))

# Generated at 2022-06-24 13:30:22.380204
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # construct an TudouPlaylistIE object
    tudouPlaylistIE = TudouPlaylistIE()
    # Test whether the url_result conversion is working properly
    actual_result = tudouPlaylistIE.url_result('http://www.tudou.com/programs/view/iqs8Ky_plX0')
    expected_result = 'http://www.tudou.com/programs/view/iqs8Ky_plX0'
    assert actual_result == expected_result, 'Expected result: %s, Actual result: %s' % (expected_result, actual_result)


# Generated at 2022-06-24 13:30:26.183867
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class constructorTest(object):
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-24 13:30:28.571240
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:30:30.690045
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:30:40.940420
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for constructor
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:30:42.174528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE

# Generated at 2022-06-24 13:30:52.348330
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:30:55.931717
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ins = TudouAlbumIE(url='http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(ins.IE_NAME)
    ins.extract()

# Generated at 2022-06-24 13:30:56.291129
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:30:57.376283
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()



# Generated at 2022-06-24 13:31:04.036855
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Test constructor of class TudouPlaylistIE')
    # Test normal case
    tudou_video = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_video.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    

# Generated at 2022-06-24 13:31:07.405094
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE('tudou:playlist')
    assert tudouPlaylistIE.ie_key() == 'tudou:playlist'


# Generated at 2022-06-24 13:31:11.633675
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE."""
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    s = TudouAlbumIE(url)
    s.extract(url)

# Generated at 2022-06-24 13:31:22.866478
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:34.729891
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from contextlib import contextmanager

    from .common import get_testdata_file
    from .common import make_result
    from .common import FakeYDL

    from .tudou import TudouPlaylistIE

    with open(get_testdata_file(
            'tudou', 'www.tudou.com_listplay_zzdE77v6Mmo.json'),
            'rb') as f:
        playlist_json = f.read()


# Generated at 2022-06-24 13:31:36.569241
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudiouIEobj = TudouPlaylistIE()
    assert type(tudiouIEobj) == TudouPlaylistIE

# Generated at 2022-06-24 13:31:40.943270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    try:
        TudouAlbumIE()(url)
    except:
        assert False # constructor has failed
    assert True


# Generated at 2022-06-24 13:31:44.038003
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    ie.IE_NAME
    ie._VALID_URL
    ie._TESTS
    ie._real_extract(ie._TESTS[0]['url'])


# Generated at 2022-06-24 13:31:53.081107
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test normal situation
    tudou_playlist_ie = TudouPlaylistIE('tudou:playlist', 'tudou:playlist')
    assert tudou_playlist_ie.name == 'tudou:playlist'
    assert tudou_playlist_ie.ie_key == 'tudou:playlist'
    
    # Test name is None
    tudou_playlist_ie = TudouPlaylistIE('tudou:playlist', None)
    assert tudou_playlist_ie.name == 'tudou:playlist'
    assert tudou_playlist_ie.ie_key == 'tudou:playlist'
    
    # Test ie_key is None

# Generated at 2022-06-24 13:32:00.544703
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', ie.__class__.__name__
    assert ie.IE_NAME == 'tudou:album', ie.__class__.__name__
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', ie.__class__.__name__



# Generated at 2022-06-24 13:32:06.852558
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie.IE_NAME == 'tudou:album'
	assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:32:11.224892
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE(None)._match_id(valid_url) == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:32:11.901204
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-24 13:32:14.694519
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE()
    assert(tudouPlaylist is not None)


# Generated at 2022-06-24 13:32:15.396976
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:32:24.900259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import sys
    import pytest
    sys.path.append('.')
    from tudou.downloader import TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    json_url = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:32:26.866133
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return TudouPlaylistIE(InfoExtractor(None))



# Generated at 2022-06-24 13:32:36.761216
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE()._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert TudouPlaylistIE()._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:32:40.859308
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE._TESTS

    abc = TudouPlaylistIE._VALID_URL
    assert abc and abc


# Generated at 2022-06-24 13:32:46.784231
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # create an instance of class TudouPlaylistIE
    # Test the constructor
    try:
        TudouPlaylistIE(True)
    except AssertionError as e:
        assert '_VALID_URL is not defined' in str(e)
    except Exception as e:
        assert False, 'unexpected exception was thrown' + str(e)
    else:
        assert False, 'no exception was thrown'

# Generated at 2022-06-24 13:32:49.167476
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    return 0


# Generated at 2022-06-24 13:32:50.063994
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)

# Generated at 2022-06-24 13:32:50.925319
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True, 'TudouPlaylistIE constructor works'

# Generated at 2022-06-24 13:32:52.080863
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert isinstance(test, InfoExtractor)

# Generated at 2022-06-24 13:32:53.742669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Test for constructor of class TudouAlbumIE
    '''

    x = TudouAlbumIE()

# Generated at 2022-06-24 13:32:55.461782
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == "tudou:album"


# Generated at 2022-06-24 13:33:03.701789
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info = TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert info.keys() == ['_type', 'id', 'title', 'entry_count', 'entries']
    assert info['title'] == info['id']
    assert info['_type'] == 'playlist'
    assert info['entry_count'] == 45
    # The following is executed only to test that the entries are right.
    for _ in info['entries']:
        pass

# Generated at 2022-06-24 13:33:11.531548
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie.IE_NAME == 'tudou:album'
	assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:33:18.392581
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE(InfoExtractor())
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    data = tudou_album_ie._real_extract(test_url)
    assert data.get('id') == 'zzdE77v6Mmo'
    assert data.get('entries')
    assert len(data.get('entries'))


# Generated at 2022-06-24 13:33:22.594439
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    test = ie.construct_url('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    print(test)
    return test

# Generated at 2022-06-24 13:33:30.866795
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie = TudouPlaylistIE(TudouPlaylistIE._VALID_URL)
	# test class type, should be InfoExtractor
	assert isinstance(tudou_playlist_ie, InfoExtractor)
	# check for 'tudou:playlist'
	assert tudou_playlist_ie._VALID_URL == TudouPlaylistIE._VALID_URL
	assert tudou_playlist_ie._TESTS == TudouPlaylistIE._TESTS	
	assert tudou_playlist_ie.IE_NAME == TudouPlaylistIE.IE_NAME
	assert tudou_playlist_ie._match_id == InfoExtractor._match_id
	assert tudou_playlist_ie._real_extract == TudouPlaylistIE._real_ext

# Generated at 2022-06-24 13:33:36.854097
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:33:41.738365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE(TudouPlaylistIE.IE_NAME,
                               TudouPlaylistIE._VALID_URL,
                               TudouPlaylistIE._TESTS)

# Generated at 2022-06-24 13:33:43.342136
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'the album id'
    TudouAlbumIE.__init__(album_id)

# Generated at 2022-06-24 13:33:44.747806
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("=====")
    TudouPlaylistIE()

# Generated at 2022-06-24 13:33:46.340260
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print('test TudouPlaylistIE')
	# TODO


# Generated at 2022-06-24 13:33:47.814160
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE();
    assert a is not None;

# Generated at 2022-06-24 13:33:52.653767
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE(url)
    assert isinstance(ie, InfoExtractor)

# For test _real_extract method of class TudouPlaylistIE

# Generated at 2022-06-24 13:33:53.749239
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:34:04.808696
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert playlist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert playlist._TESTS[0]['playlist_mincount'] == 209

# Specify pytest for unit test
if __name__ == "__main__":
    import pytest
    pytest.main

# Generated at 2022-06-24 13:34:08.748365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:34:10.577439
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

# Generated at 2022-06-24 13:34:12.081326
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Unit test for constructor of class TudouPlaylistIE"""
    pass

# Generated at 2022-06-24 13:34:13.523704
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:15.812845
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html') is not None


# Generated at 2022-06-24 13:34:16.568926
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:34:17.556788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True



# Generated at 2022-06-24 13:34:19.585143
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE.IE_NAME,{})
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-24 13:34:21.093937
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test != None

# Generated at 2022-06-24 13:34:24.545224
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor test
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie is not None


# Generated at 2022-06-24 13:34:32.073701
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.name == 'Tudou'
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Unit testing function test_TudouAlbumIE()
test_TudouAlbumIE()


# Generated at 2022-06-24 13:34:34.974233
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # We should be able to create an instance of TudouAlbumIE
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")



# Generated at 2022-06-24 13:34:41.302132
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg')
    assert(TudouAlbumIE._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg')

# Generated at 2022-06-24 13:34:52.101877
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#test1
    e = TudouPlaylistIE({})
    assert e.TUDOU_ALBUM_URL_TEMPLATE == 'http://www.tudou.com/albumplay/%s.html'
    assert e.TUDOU_ALBUM_JSON_TEMPLATE == 'http://www.tudou.com/tvp/alist.action?acode=%s'
    assert e.TUDOU_PLAYLIST_URL_TEMPLATE == 'http://www.tudou.com/listplay/%s.html'
    assert e.TUDOU_PLAYLIST_JSON_TEMPLATE == 'http://www.tudou.com/tvp/plist.action?lcode=%s'

# Generated at 2022-06-24 13:34:52.990015
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:34:58.410310
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    assert tudou.IE_NAME == 'tudou:album'
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:35:08.980144
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_NAME = 'tudou:playlist'
    _VALID_URL1 = r'https?://(?:www\.)?tudou\.com/my/album/playlist.html?lid=124055'
    _VALID_URL2 = r'https?://(?:www\.)?tudou\.com/my/album/view.html?lid=124055'

# Generated at 2022-06-24 13:35:09.522596
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE

# Generated at 2022-06-24 13:35:14.017047
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	_VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	tudou_album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert(tudou_album._VALID_URL == _VALID_URL)

# Generated at 2022-06-24 13:35:18.546150
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ieinst = TudouAlbumIE()
    assert ieinst._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ieinst.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:35:19.573783
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE()

# Generated at 2022-06-24 13:35:19.900742
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-24 13:35:23.788746
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_example = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(tudou_album_example)


# Generated at 2022-06-24 13:35:24.843984
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pl = TudouPlaylistIE()


# Generated at 2022-06-24 13:35:33.223414
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test constructor
    ie = TudouPlaylistIE()

    # test method _real_extract
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }
    playlist_mincount = 209
    playlist = ie._real_extract(url)
    assert info_dict['id'] == playlist['id']
    assert playlist_mincount <= len(playlist['entries'])



# Generated at 2022-06-24 13:35:42.604109
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_NAME = 'tudou:playlist'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    URL = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    IE_DESC = '儿歌大全_好听的儿歌给孩子听'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:35:43.925867
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    assert i is not None

# Generated at 2022-06-24 13:35:45.553727
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-24 13:35:56.313448
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    # Test for method _real_extract
    assert obj._real_extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html") is not None
    # Test for method _match_id
    assert obj._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html") == "v5qckFJvNJg"
    # Test for method playlist_result
    assert obj.playlist_result([], "v5qckFJvNJg") is not None
    # Test for method url_result

# Generated at 2022-06-24 13:36:05.279710
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:09.022220
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:12.242527
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create a mock downloader
    downloader = MockDownloader()
    # Create an instance of class TudouPlaylistIE, testing only its constructor
    instance = TudouPlaylistIE("TudouPlaylistIE", downloader)
    assert instance != None

# Generated at 2022-06-24 13:36:21.494319
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    global url
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    print("unit test for TudouPlaylistIE")
    try:
        global tudouplist
        tudouplist = TudouPlaylistIE()
        print("create a TudouPlaylistIE instance")
    except Exception:
        print("fail to create a TudouPlaylistIE instance")
    try:
        assert tudouplist.suitable(url) == True, 'URL does not match'
    except Exception:
        print("URL does not match")
    try:
        assert tudouplist.IE_NAME == "tudou:playlist", "IE_NAME error"
    except Exception:
        print("IE_NAME error")

# Generated at 2022-06-24 13:36:24.439431
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    tudou_album_ie._real_extract(url)


# Generated at 2022-06-24 13:36:31.249652
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tuple_returned = TudouAlbumIE()
    assert tuple_returned[0] == 'tudou:album'
    assert tuple_returned[1] == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tuple_returned[2] == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:36:35.118857
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_tudou_album_url = 'http://www.tudou.com/albumplay/BODDdyNyiMM.html'
    assert 'tudou:album' == TudouAlbumIE._get_ie_key_name(test_tudou_album_url)


# Generated at 2022-06-24 13:36:36.141932
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-24 13:36:43.124057
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = {'id': 'zzdE77v6Mmo'}
    playlist_mincount = 209
    assert('playlist_mincount' in info_dict)
    assert (playlist_mincount == 209)
    assert (info_dict['id'] == 'zzdE77v6Mmo')
    assert (url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:36:50.654616
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert playlist_ie
    assert playlist_ie.suitable("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert not playlist_ie.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html")  # album url
    assert playlist_ie.IE_NAME == 'tudou:playlist'
    assert playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:36:57.321183
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = r'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    a = TudouPlaylistIE(url)

# Generated at 2022-06-24 13:36:58.346112
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'

# Generated at 2022-06-24 13:37:00.415774
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:37:07.463763
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:37:08.724690
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE.IE_NAME
	assert TudouPlaylistIE._VALID_URL
	assert TudouPlaylistIE._TESTS


# Generated at 2022-06-24 13:37:10.329564
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE()
    return tudou

# Generated at 2022-06-24 13:37:16.456376
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert e.real_extract_behavior == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert e.real_extract_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:19.498369
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	assert TudouPlaylistIE(url).url==url


# Generated at 2022-06-24 13:37:23.888776
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie_object = TudouAlbumIE()

    assert(tudou_album_ie_object.IE_NAME == 'tudou:album')
    assert(tudou_album_ie_object._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(tudou_album_ie_object._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }])



# Generated at 2022-06-24 13:37:31.182177
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_TEST = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert IE_TEST.IE_NAME == 'Tudou'
    assert IE_TEST.IE_DESC == '土豆'
    assert IE_TEST.URL_PATTERN == r'https?://(?:www\.)?tudou\.com/(?:listplay|album(?:cover|play))/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:37:37.485808
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	expected_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:37:39.644261
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    m = TudouPlaylistIE()
    print(m._real_extract(m._TESTS[0]['url']))


# Generated at 2022-06-24 13:37:42.912974
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  test_obj = TudouPlaylistIE(InfoExtractor())
  assert test_obj.ie_name == 'tudou:playlist'


# Generated at 2022-06-24 13:37:48.662832
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = "https://www.tudou.com/listplay/o7k0Q_fE6gE.html"
	TudouPlaylistIE(url).run()
	# print(TudouPlaylistIE(url)._is_url_valid)
	# print(TudouPlaylistIE(url)._real_extract(url))


# Generated at 2022-06-24 13:38:00.192095
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest

    class TestTudouAlbumIE(unittest.TestCase):
        def setUp(self):
            self.ie = TudouAlbumIE()
            self.url = 'http://www.tudou.com/albumcover/v5qckFJvNJg/'
        def test_valid(self):
            self.assertEqual(self.ie._match_id(self.url), self.ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg/'))
        def test_invalid(self):
            self.assertNotEqual(self.ie._match_id(self.url), self.ie._match_id('http://www.tudou.com/'))



# Generated at 2022-06-24 13:38:06.338654
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'



# Generated at 2022-06-24 13:38:12.397785
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # url for test case.
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    # instantiate class TudouAlbumIE.
    extractor = TudouAlbumIE()
    # test the results of _match_id
    assert extractor._match_id(url) == "v5qckFJvNJg"

# Generated at 2022-06-24 13:38:21.037418
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    list_ie = TudouPlaylistIE("Tudou")
    assert list_ie.http_headers == {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'}
    assert list_ie.request_headers == {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'}

##############
# Unit tests #
##############


# Generated at 2022-06-24 13:38:27.390544
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test the case with album
    instance = TudouAlbumIE(
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert(instance.IE_NAME == 'tudou:album')
    # Test the case without album
    instance = TudouAlbumIE(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(instance.IE_NAME == 'tudou:album')
    # Test the case for invalid url
    instance = TudouAlbumIE(
        'http://www.tudou.com/albumcover/v5qckFJvNJg')
    assert(not instance)

# Generated at 2022-06-24 13:38:39.382147
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE("http://www.tudou.com/albumplay/")
    assert unicode(tudouAlbumIE) == "http://www.tudou.com/albumplay/"
    tudouAlbumIE = TudouAlbumIE("http://www.tudou.com/albumplay/w-QPI-OtOco")
    assert unicode(tudouAlbumIE) == "http://www.tudou.com/albumplay/w-QPI-OtOco"
    tudouAlbumIE = TudouAlbumIE("http://www.tudou.com/albumplay/f-jQ8Wx9aVM")

# Generated at 2022-06-24 13:38:40.488482
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'


# Generated at 2022-06-24 13:38:51.103330
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'v5qckFJvNJg'
    url_json = 'http://www.tudou.com/tvp/plist.action?lcode=' + playlist_id
    playlist_data = {}
    i = 0
    e = {}
    for i in range(0, 45):
        e[i] = {}
        e[i]['icode'] = 'na'
    playlist_data['items'] = e

    tudou_playlist = TudouPlaylistIE()

# Generated at 2022-06-24 13:39:02.228769
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE)
    tests = [('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg', 45, []),
            ('http://www.tudou.com/albumcover/v5qckFJvNJg.html', 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg', 45, [])]
    for test in tests:
        result = ie.url_result(test[0], 'Tudou')
        result_test

# Generated at 2022-06-24 13:39:13.569270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
  album_id = 'v5qckFJvNJg'