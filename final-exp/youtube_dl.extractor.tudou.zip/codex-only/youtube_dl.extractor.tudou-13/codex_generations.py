

# Generated at 2022-06-24 13:29:11.019856
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie.IE_NAME == 'tudou:album')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')



# Generated at 2022-06-24 13:29:18.636802
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]



# Generated at 2022-06-24 13:29:19.713135
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()


# Generated at 2022-06-24 13:29:29.172105
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:29:37.517989
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_ = TudouAlbumIE
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert class_._match_id(url) == 'v5qckFJvNJg'
    assert class_._match_id(url) == 'v5qckFJvNJg', 'TudouAlbumIE._match_id should match the album id embedded in the URL'


# Generated at 2022-06-24 13:29:48.131163
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import fetch_data, urlopen, urljoin
    from .extractor.tudou import TudouAlbumIE
    from .compat import compat_urllib_parse, compat_urllib_request
    from .downloader.common import FileDownloader
    url = 'http://www.tudou.com/albumcover/aSvTgWPotis.html'

    response = urlopen(url)
    html = response.read().decode('utf-8')
    assert (html is not None)

    m_match = re.match(r'.*\s*aid\s*:\s*\'(\w+)\'',html)
    assert (m_match is not None)
    album_id = m_match.group(1)

    # for album_id in match:
    #     print(

# Generated at 2022-06-24 13:29:49.491966
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #print("TudouPlaylistIE constructor")
    pass

	

# Generated at 2022-06-24 13:29:50.724546
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-24 13:29:51.749539
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:29:55.826437
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:29:58.600901
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test import get_testcases
    for url in [case['url'] for case in get_testcases(TudouPlaylistIE)]:
        TudouPlaylistIE(url,{'test': True})

test_TudouPlaylistIE()

# Generated at 2022-06-24 13:30:04.270450
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	assert TudouAlbumIE(url).url == url
	assert TudouAlbumIE(url).ie_key() == 'TudouAlbum'
	assert TudouAlbumIE(url).info() == {}

# Generated at 2022-06-24 13:30:11.094153
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj = TudouAlbumIE()

# Generated at 2022-06-24 13:30:19.178893
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/2FzOwvLCrZM.html'
    tudou_playlist_ie = TudouPlaylistIE(url)

    assert tudou_playlist_ie.url == url
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:30:26.209356
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import Dict
    from .tudou import TudouPlaylistIE
    tudou_playlist = TudouPlaylistIE(Dict({'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                                           'info_dict': {'id': 'zzdE77v6Mmo'},
                                           'playlist_mincount': 209}))
    assert tudou_playlist.name == 'tudou'
    assert tudou_playlist.title == 'tudou'



# Generated at 2022-06-24 13:30:33.815030
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    info_dict = {'id': 'zzdE77v6Mmo'}

    playlist_extract = TudouPlaylistIE()
    playlist_extract._match_id(url)
    playlist_extract._download_json(playlist_data, playlist_id)
    playlist_extract._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    return


# Generated at 2022-06-24 13:30:35.138632
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:30:40.993638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.valid_url(url) == True
    assert ie.test_url(url) == True


# Generated at 2022-06-24 13:30:42.224223
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:30:48.616841
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    def test_url(in_url,out_url):
        try:
            ie = TudouPlaylistIE(in_url)
        except ValueError as err:
            print("Caught exception :"+str(err))
        assert ie._TESTS[0]['url'] == out_url

    test_url("http://www.tudou.com/listplay/zzdE77v6Mmo.html","http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    test_url("www.tudou.com/listplay/zzdE77v6Mmo.html","http://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-24 13:30:53.275126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for TudouPlaylistIE.
    """
    from .test_downloader import TestDownloader
    assert TestDownloader.test_constructor(TudouPlaylistIE, "TudouPlaylistIE")


# Generated at 2022-06-24 13:31:02.324201
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import fake_urlopen
    from .common import MockUrlOpenTestCase

    # Case1: get_video() in the end
    class Case1(MockUrlOpenTestCase):

        def _run(self):
            url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
            TudouPlaylistIE().url_result(
            'http://www.tudou.com/programs/view/%s' % 'zzdE77v6Mmo')
            assert self.urlopen.called

    Case1().run()

    # Case2: playlist_result() in the end

# Generated at 2022-06-24 13:31:08.749767
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_name() == 'Tudou'
    assert ie.ie_key() == 'tudou:album'
    assert ie.template_url() == 'https://www.tudou.com/albumplay/{id}.html'
    assert ie.valid_url(ie.template_url().format(id='v5qckFJvNJg'))



# Generated at 2022-06-24 13:31:17.760911
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class tuple_class():
        def __init__(self, icode, kw):
            self.icode = icode
            self.kw = kw
    test_list = []
    test_list.append(tuple_class('MTYwNDI4NjA0', 'Test key word 1'))
    test_list.append(tuple_class('MTYwNDI4NjA1', 'Test key word 2'))
    test_list.append(tuple_class('MTYwNDI4NjA2', 'Test key word 3'))
    test_album_id = 'MTYwNDI4NjEw'
    test_album_playlist = { 
        '_type' : None,
        'items' : test_list,
    }
    test_ie = Tudou

# Generated at 2022-06-24 13:31:20.659774
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from tudou import TudouAlbumIE
    test_TudouAlbumIE = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert test_TudouAlbumIE.album_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:31:23.005307
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test to not crash while loading the constructor
    try:
        TudouPlaylistIE()
    except Exception as e:
        raise e


# Generated at 2022-06-24 13:31:30.385371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist_ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html");
    assert type(tudouplaylist_ie.url) is unicode
    assert tudouplaylist_ie.url == "http://www.tudou.com/listplay/zzdE77v6Mmo.html";
    assert tudouplaylist_ie.id == "zzdE77v6Mmo";

# Generated at 2022-06-24 13:31:35.478288
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:31:45.490869
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for https://github.com/rg3/youtube-dl/pull/9247
    import sys
    import os
    import json
    from .common import test_basenames

    # No need to specify tests for this constructor, as the subclass TudouAlbumIE inherits from the parent class InfoExtractor and
    # the test for parent class has been specified in test_common.py

    # These urls should not be accepted by the TudouAlbumIE constructor
    # Check that _VALID_URL is defined in class TudouAlbumIE
    if not hasattr(TudouAlbumIE, '_VALID_URL'):
        print('The TudouAlbumIE constructor has no _VALID_URL attribute!')
        ydl = None
        return
    # Check that _VALID_URL is a string

# Generated at 2022-06-24 13:31:51.889993
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/7td0mpC8uVg.html"
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie.IE_DESC == '土豆网'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._match_id(url) == "7td0mpC8uVg"

# Generated at 2022-06-24 13:31:53.916119
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE(None)

# Generated at 2022-06-24 13:31:58.430849
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()

# Generated at 2022-06-24 13:32:08.268362
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [
                {
                    'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                    'info_dict': {
                        'id': 'zzdE77v6Mmo',
                    },
                    'playlist_mincount': 209,
                }
            ]


# Generated at 2022-06-24 13:32:10.671710
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    assert(TudouAlbumIE('Tudou', 'tudou:album'))

# Generated at 2022-06-24 13:32:15.279336
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test = TudouAlbumIE()
    assert test._match_id(url) == 'v5qckFJvNJg'


# Generated at 2022-06-24 13:32:19.366944
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:32:21.791566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    o = TudouAlbumIE()

# Generated at 2022-06-24 13:32:22.696344
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-24 13:32:26.448175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Initialize a TudouPlaylistIE instance
	TudouPlaylistIE = TudouPlaylistIE()
	
	# Validate the URL format of TudouPlaylistIE
	assert TudouPlaylistIE._VALID_URL is not None


# Generated at 2022-06-24 13:32:32.736350
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_parameters = [
        ('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'zzdE77v6Mmo')
    ]
    for url, playlist_id in test_parameters:
        result = TudouPlaylistIE()._match_id(url)
        assert result == playlist_id


# Generated at 2022-06-24 13:32:35.470517
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    assert isinstance(tudou, InfoExtractor)
    assert tudou._VALID_URL is not None


# Generated at 2022-06-24 13:32:38.226821
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'http://www.tudou.com/albumcover/YNc-sCgLVqQ.html' == TudouAlbumIE('http://www.tudou.com/albumcover/YNc-sCgLVqQ.html')._VALID_URL

# Generated at 2022-06-24 13:32:39.815513
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ies = TudouPlaylistIE()

# Generated at 2022-06-24 13:32:50.690279
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(TudouPlaylistIE.IE_DESC == 'Tudou:playlist')
    assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')

# Generated at 2022-06-24 13:33:00.009839
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE.IE_NAME == 'tudou:album'
	assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:33:03.249348
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    madedict = {
        'id': 'v5qckFJvNJg',
    }
    assert TudouAlbumIE._TESTS[0]['info_dict'] == madedict

# Generated at 2022-06-24 13:33:11.193001
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Uncomment the following line to test a failed match
    # assert False
    from .constructor_test import run_constructor_tests, TestCase, TUDOU_ALBUM_URL
    import inspect
    module = inspect.getmodule(TudouAlbumIE())
    module_tests = [n for n, _ in inspect.getmembers(module, inspect.isclass) if 'Test' in n]
    list_urls = [TUDOU_ALBUM_URL]
    for url in list_urls:
        for test_class_name in module_tests:
            run_constructor_tests(test_class_name, TestCase, url, module)

# Generated at 2022-06-24 13:33:16.886106
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test case for unit test."""
    # call class TudouAlbumIE
    tudou_album = TudouAlbumIE()
    # call function _match_id
    tudou_album._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-24 13:33:19.862140
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-24 13:33:29.175805
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from ..extractor.common import InfoExtractor
	try:
		from ..extractor.common import ExtractorError
	except ImportError:
		from ..exceptions import ExtractorError
	try:
		from ..extractor.common import ExtractorError
	except ImportError:
		from ..exceptions import ExtractorError

# Generated at 2022-06-24 13:33:30.905978
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:33:32.546639
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    constructor_test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    TudouPlaylistIE(constructor_test_url)


# Generated at 2022-06-24 13:33:38.409213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest
    from .common import HEADRequest

# Generated at 2022-06-24 13:33:39.320964
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    iox=TudouAlbumIE()

# Generated at 2022-06-24 13:33:42.839127
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    ie.get_extract_info(url)


# Generated at 2022-06-24 13:33:46.591469
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == 'http://www.tudou.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:33:56.769670
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor given a valid url.
    playlist = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # Test constructor given an invalid url
    try:
        playlist = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.htm')
        assert False
    except ValueError as e:
        assert str(e) == 'Invalid URL: http://www.tudou.com/listplay/zzdE77v6Mmo.htm'


# Generated at 2022-06-24 13:34:03.976378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie._match_id(test_playlist_url)
    assert tudou_playlist_ie._match_id(test_playlist_url) == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:34:13.812311
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Unit test for constructor of class TudouPlaylistIE
    _1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    _2 = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
    _3 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.htm'
    _4 = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'

    assert TudouPlaylistIE._match_url(_1) != False
    assert TudouPlaylistIE._match_url(_2) != False
    assert TudouPlaylistIE._match_url(_3) != False
    assert TudouPlaylistIE._match_url(_4) != False

# Generated at 2022-06-24 13:34:15.958812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Given
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE()

    # When
    album_id = ie._match_id(url)

    # Then
    assert album_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:34:16.576466
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE()

# Generated at 2022-06-24 13:34:20.953049
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for constructor
    ie = TudouAlbumIE()

    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:24.815172
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE("Tudou")._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:34:34.065158
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE._TESTS[0]['url'] = url
    TudouPlaylistIE._VALID_URL = TudouPlaylistIE._VALID_URL.replace('zzdE77v6Mmo', '(?P<id>[\w-]{11})')
    TudouPlaylistIE._TESTS[0]['info_dict']['id'] = 'zzdE77v6Mmo'
    return TudouPlaylistIE(TudouPlaylistIE._TESTS[0])


# Generated at 2022-06-24 13:34:39.852264
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert(tudouAlbumIE.IE_NAME == 'tudou:album')
    assert(tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:34:50.844275
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_instance = TudouPlaylistIE()
    assert(test_instance.IE_NAME == 'tudou:playlist')
    assert (test_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (test_instance._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                                     'info_dict': {'id': 'zzdE77v6Mmo'},
                                     'playlist_mincount': 209}])

# Generated at 2022-06-24 13:34:56.939154
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie.extractor_key == 'TudouAlbum'
    assert ie.playlist_id == 'v5qckFJvNJg'



# Generated at 2022-06-24 13:34:59.148901
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:35:00.150677
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert  TudouPlaylistIE(123) == None

# Generated at 2022-06-24 13:35:10.355766
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    # assert t._match_id("222") == "222"
    assert t._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html") == "zzdE77v6Mmo"
    assert str(t._download_json("http://www.tudou.com/tvp/plist.action?lcode=%s" % t._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html"), "zzdE77v6Mmo")) == '<bound method IEDownloader.download_json of <__main__.TudouPlaylistIE object at 0x1047c85f8>>'

# Generated at 2022-06-24 13:35:11.795067
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('', {})
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:35:13.373927
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert(obj != None)



# Generated at 2022-06-24 13:35:19.568723
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Test for the initialization of the entry
    # Test case 1: 
    #	Send url http://www.tudou.com/listplay/zzdE77v6Mmo.html, id is zzdE77v6Mmo
    #   expected result: playlist_mincount is 209
    test_1_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_1_result = ie._real_extract(test_1_url)
    test_1_expected = 209
    assert test_1_expected == test_1_result['playlist_mincount']
    # Test case 2: 
    #	Send url which is not a playlist, id is empty string
    #   expected result: raise an exception

# Generated at 2022-06-24 13:35:22.295801
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    test = tudou_album.IE_NAME
    assert test == 'tudou:album'

# Generated at 2022-06-24 13:35:22.812648
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:35:34.049984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    mgr = TudouAlbumIE()
    # URL for album id
    url_1 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # URL for album cover
    url_2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    # URL for album cover with album id
    url_3 = 'http://www.tudou.com/albumcover/v5qckFJvNJg/v5qckFJvNJg.html'
    # URL for album cover without album id
    url_4 = 'http://www.tudou.com/albumcover/v5qckFJvNJg/'
    # URL for album cover without album id or slash

# Generated at 2022-06-24 13:35:37.839331
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html")
	assert(TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209)


# Generated at 2022-06-24 13:35:43.480943
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    params = [{
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'IE_NAME': 'TudouAlbumIE',
            'id': 'v5qckFJvNJg',
            'playlist_mincount': 45,
    }]
    for p in params:
        obj = TudouAlbumIE(None, None)
        obj._real_extract(p['url'])

# Generated at 2022-06-24 13:35:48.900278
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(TudouPlaylistIE._VALID_URL, TudouPlaylistIE.IE_NAME)
    assert obj.ie_key() == 'Tudou'
    assert obj.ie_name() == 'tudou:playlist'
    assert obj.video_id == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:35:57.660064
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .tudou import TudouAlbumIE
	from .common import InfoExtractor
	from .utils import search_dict
	pl = search_dict(TudouAlbumIE._TESTS, lambda t: t['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html")[0]
	assert(pl['info_dict']['id'] == 'v5qckFJvNJg')
	assert(pl['playlist_mincount'] == 45)
	assert(isinstance(TudouAlbumIE(InfoExtractor()), TudouAlbumIE))


# Generated at 2022-06-24 13:36:04.064773
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'album_id'
    ydl = YDL()
    ydl.params['nooverwrites'] = True
    tudou_album_ie_1 = TudouAlbumIE(ydl, {'id': album_id})
    tudou_album_ie_2 = TudouAlbumIE(ydl, {'url': 'http://www.tudou.com/albumplay/%s.html' % album_id})
    assert tudou_album_ie_1 == tudou_album_ie_2

# Generated at 2022-06-24 13:36:13.831603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_id = "zzdE77v6Mmo"
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.IE_NAME == "tudou:playlist"
    assert tudou_playlist._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"
    assert tudou_playlist._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

# Generated at 2022-06-24 13:36:19.497173
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.ie_key()).ie_key() == 'Tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'
    assert TudouAlbumIE.__doc__

# Generated at 2022-06-24 13:36:20.524477
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()


# Generated at 2022-06-24 13:36:26.197958
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .tudou_playlist import TudouPlaylistIE
    tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    tudouAlbumIE.extract()
    tudouPlaylistIE = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    tudouPlaylistIE.extract()

# Generated at 2022-06-24 13:36:29.658185
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from common import get_testdata_file

    file = get_testdata_file('tudou_playlist.json')
    testDict = json.load(file)
    obj = TudouAlbumIE(testDict)
    assert obj != None



# Generated at 2022-06-24 13:36:31.859301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = "v5qckFJvNJg"
    test_extractor = TudouAlbumIE()
    test_extractor._real_extract(album_id)

# Generated at 2022-06-24 13:36:33.721580
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('tudou:playlist') is not None


# Generated at 2022-06-24 13:36:42.426027
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou = TudouAlbumIE(url)
    assert tudou.url == url
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou.ie_key() == 'TudouAlbum'
    assert tudou.IE_NAME == 'tudou:album'
    assert tudou.ie_name() == 'TudouAlbum'

# Generated at 2022-06-24 13:36:43.433137
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-24 13:36:45.452035
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #intialize the object
    tudoualbum = TudouAlbumIE()
    #use assert to check the object is initialized correctly or not
    assert tudoualbum is not None


# Generated at 2022-06-24 13:36:47.296301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:36:48.989706
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    return tudou_album_ie

# Generated at 2022-06-24 13:36:52.103485
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class ClassUnderTest:
        def __init__(self, **kw):
            return
    tudouAlbum = TudouAlbumIE(ClassUnderTest)

# Generated at 2022-06-24 13:36:55.248671
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info = TudouPlaylistIE()._real_extract(url)
    return info

# Generated at 2022-06-24 13:37:00.573217
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE("%s/listplay/zzdE77v6Mmo.html" % "http://www.tudou.com")
    assert(a._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(a._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html")


# Generated at 2022-06-24 13:37:02.789975
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:37:03.594402
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:37:08.810769
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().name == 'tudou:playlist'
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    

# Generated at 2022-06-24 13:37:09.810583
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie.IE_NAME == "tudou:album"


# Generated at 2022-06-24 13:37:16.816049
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album = TudouAlbumIE()
    assert album.suitable(album_url)
    assert album.IE_NAME == 'tudou:album'
    assert album.ie_key() == 'TudouAlbum'
    assert album.extract_id(album_url) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:20.285280
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE()

# Generated at 2022-06-24 13:37:28.828063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    if __name__ == '__main__':
        print(__doc__)

    expected = (
        'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo',
        'http://www.tudou.com/programs/view/2e4BE4nbhok',
        'http://www.tudou.com/programs/view/NcNX9y3qgGQ',
    )

    playlister = TudouPlaylistIE()
    playlist = playlister._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

    assert playlist['entries'][0]['url'] == expected[1]
    assert playlist['entries'][1]['url']

# Generated at 2022-06-24 13:37:39.598928
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("typing")
    import sys
    import os
    import re
    
    this_file_path = os.path.dirname(os.path.abspath(__file__))
    this_file_name = os.path.basename(__file__)
    this_file_type = os.path.splitext(this_file_name)[1]
    sys.path.append(os.path.join(this_file_path, "..", ".."))
    from youtube_dl.extractor import common

    # copy from _match_id
    def _match_id(self, url):
        mobj = re.match(self._VALID_URL, url)
        if mobj is None:
            print("failed to match id with :",self._VALID_URL)

# Generated at 2022-06-24 13:37:41.546741
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:37:45.601407
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:37:50.491528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    album_id = "yiw0xjP5JKY"
    playlist_id = "3q3g1qjK1EQ"

    assert get_album_id(album_id) == album_id
    assert get_album_id(playlist_id) == None
    

# Generated at 2022-06-24 13:37:58.442740
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import FakeYDL
    ydl = FakeYDL()
    TudouPlaylistIE()._real_initialize(ydl)
    assert ydl.add_info_extractor.called
    assert ydl.add_info_extractor.call_count == 1
    assert ydl.add_info_extractor._mock_call_args_list[0] == \
        call('tudou:playlist', TudouPlaylistIE._VALID_URL, TudouPlaylistIE._TESTS)


# Generated at 2022-06-24 13:38:05.886646
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    stg_class = TudouPlaylistIE()
    assert stg_class.IE_NAME == 'tudou:playlist'
    assert stg_class._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert stg_class._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:38:13.780695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    sources = [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'http://www.tudou.com/albumplay/v5qckFJvNJg/',
        'http://www.tudou.com/albumcover/v5qckFJvNJg/',
    ]
    for source in sources:
        TudouAlbumIE(source)

# Generated at 2022-06-24 13:38:24.105457
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Set up for tests
    # Url and contents of list items
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_items = {'icode':123456, 'kw':'Test video'}
    # Url and json data of listitems
    album_url_expected = 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
    album_data_expected = '{' + '"items":[' + str(album_items) + ']' + '}'
    # Response of album data
    album_response_expected = 'application/json' # Response of url
    # Url and title of video

# Generated at 2022-06-24 13:38:26.032415
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_tudouPlaylistIE = TudouPlaylistIE()
    assert test_tudouPlaylistIE
    

# Generated at 2022-06-24 13:38:29.590510
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing TudouPlaylistIE class constructor.")
    TudouPlaylistIE('TudouPlaylistIE', 'tudou:playlist', None, None)
    print("Test completed.")


# Generated at 2022-06-24 13:38:41.109138
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    obj.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj.IE_NAME = 'tudou:album'
    obj._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    obj.album_id = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:38:42.194765
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-24 13:38:45.153920
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == "TudouPlaylistIE"

# Generated at 2022-06-24 13:38:51.684066
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tp = TudouPlaylistIE()
    assert tp._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tp._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tp._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:38:55.274726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE._VALID_URL)
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:38:58.196056
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert c.TudouAlbumIE.IE_NAME == 'tudou:album'
    assert c.TudouPlaylistIE.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-24 13:39:09.825421
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/skLZOJ7hYjo.html'
    td_album = TudouAlbumIE(url)
    assert td_album.IE_NAME  == 'tudou:album'
    assert td_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert td_album._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/skLZOJ7hYjo.html',
        'info_dict': {
            'id': 'skLZOJ7hYjo',
        },
        'playlist_mincount': 1,
    }]

