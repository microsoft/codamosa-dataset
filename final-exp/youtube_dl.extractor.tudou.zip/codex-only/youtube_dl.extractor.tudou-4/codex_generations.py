

# Generated at 2022-06-24 13:29:13.768199
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 1st test case: basic input test
    test_input = [{'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg/', 'expected': ('http://www.tudou.com/albumcover/v5qckFJvNJg/', True)},
    {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg/', 'expected': ('http://www.tudou.com/albumplay/v5qckFJvNJg/', True)},
    {'url': 'http://www.tudou.com/v/xVhTMK2eIr8/', 'expected': ('http://www.tudou.com/v/xVhTMK2eIr8/', False)}]

# Generated at 2022-06-24 13:29:17.465509
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = appspot_check_extractor(TudouAlbumIE)
    assert result == 303 or result == 303

test_TudouAlbumIE.func_annotations = {}
test_TudouAlbumIE.__annotations__ = {'return': NoneType}

# Generated at 2022-06-24 13:29:22.619886
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE();
    assert t.IE_NAME == 'tudou:album'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert t._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:29:24.213017
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    p = TudouAlbumIE()
    assert p.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:29:32.149960
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    album_id = "v5qckFJvNJg"
    download_url = "http://www.tudou.com/tvp/alist.action?acode=%s" % album_id
    info_dict = {'id': 'v5qckFJvNJg'}
    playlist_mincount = 45

    # check case of input url
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    # check case of _real_extract

# Generated at 2022-06-24 13:29:35.825486
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE(url) is not None


# Generated at 2022-06-24 13:29:42.826297
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:29:46.416824
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	x = TudouAlbumIE()
	assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:29:48.131813
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert_equal(ie.IE_NAME, 'Tudou')

# Generated at 2022-06-24 13:29:49.113984
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:29:51.557244
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie != None

# Generated at 2022-06-24 13:29:56.619168
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = tudou_album_ie._match_id(url)
    assert album_id == 'v5qckFJvNJg'
    tudou_album_ie._download_json
    tudou_album_ie.url_result

# Generated at 2022-06-24 13:29:58.838022
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Intance of class TudouPlaylistIE
    TudouPlaylistIE()


# Generated at 2022-06-24 13:30:06.889248
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie.NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:30:12.756900
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    item = TudouPlaylistIE()
    print (item._TESTS)
    item._TESTS.append({
        'url': 'http://www.tudou.com/listplay/O-HA1zw6f-U.html',
        'info_dict': {
            'id': 'O-HA1zw6f-U',
        },
        'playlist_mincount': 209,
    })
    print (item._TESTS)

# Generated at 2022-06-24 13:30:15.613111
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('<TudouPlaylistIE: TudouPlaylistIE>', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:30:17.506560
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:30:18.786207
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i != None


# Generated at 2022-06-24 13:30:27.559390
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE_TEST = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

    downloader = InfoExtractor()
    downloader.add_info_extractor('tudou:album', TudouAlbumIE)

    import sys
    sys.exit(0)


# Generated at 2022-06-24 13:30:33.745171
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }

    playlistIE = TudouPlaylistIE()
    result = playlistIE.extract_info(test['url'], download=False)
    assert result['id'] == test['info_dict']['id']
    assert len(result['entries']) == test['playlist_mincount']


# Generated at 2022-06-24 13:30:39.280578
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # todo: diff with self._real_extract
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    album_id = ie._match_id(ie._VALID_URL)
    album_data = ie._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [ie.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]

# Generated at 2022-06-24 13:30:48.799550
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE([])
    except:
        pass
    try:
        TudouPlaylistIE({})
    except:
        pass
    try:
        TudouPlaylistIE(None)
    except:
        pass
    try:
        TudouPlaylistIE(3)
    except:
        pass
    try:
        TudouPlaylistIE(4.5)
    except:
        pass
    try:
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except:
        pass


# Generated at 2022-06-24 13:30:57.327592
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testClass = TudouPlaylistIE()
    test1 = testClass.IE_NAME == 'tudou:playlist'
    test2 = testClass._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    if not test1:
        print("Failed to get expected IE_NAME of testClass.")
    if not test2:
        print("Failed to get expected _valid_url of testClass.")


# Generated at 2022-06-24 13:30:58.469771
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), InfoExtractor)


# Generated at 2022-06-24 13:31:08.802374
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test.IE_NAME == 'tudou:album'
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert test._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:31:10.512053
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO: implement test_TudouPlaylistIE
    pass


# Generated at 2022-06-24 13:31:16.338465
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou = TudouAlbumIE()
	assert_equal(tudou.ie_key(), 'TudouAlbum')
	assert_equal(tudou.name(), 'tudou')
	assert_true(tudou.url_result('http://www.tudou.com/programs/view/qqQDQEa4z4I', 'Tudou', 'qqQDQEa4z4I', '李彦宏'))
	

# Generated at 2022-06-24 13:31:26.283225
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    res = ie.extract(r'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert res['id'] == 'v5qckFJvNJg'
    assert res['title'] == 'v5qckFJvNJg'
    assert len(res['entries']) == 45
    assert res['entries'][0]['id'] == 'bQLh5m72P5I'
    assert res['entries'][0]['title'] == '跳转星（结局待定）'


# Generated at 2022-06-24 13:31:38.331935
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = '103107489'

# Generated at 2022-06-24 13:31:40.741929
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import main, test
    from .aextractors import TudouAlbumIE

    if main.__name__ == "__main__":
        t = TudouAlbumIE()
        st = test.TestStub()
        main(st, "")

# Generated at 2022-06-24 13:31:48.811004
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():


    # test result for normal case
    data = TudouPlaylistIE()._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

    assert data['id'] == 'zzdE77v6Mmo'
    assert data['title'] == 'zzdE77v6Mmo'
    assert data['_type'] == 'playlist'
    assert data['entries'][0]['id'] == 'VjY0ZFoQV0I'
    assert data['entries'][0]['title'] == '这才是真正的《天天向上》！'
    assert data['entries'][0]['ext'] == 'mp4'

# Generated at 2022-06-24 13:31:49.566098
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert True

# Generated at 2022-06-24 13:31:52.715376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    global TudouPlaylistIE
    TudouPlaylistIE(InfoExtractor(), 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:31:56.839341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()._real_extract(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert info['id'] == 'zzdE77v6Mmo'
    assert len(info['entries']) == 209


# Generated at 2022-06-24 13:31:58.536412
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo')

# Generated at 2022-06-24 13:31:59.636252
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    obj1 = TudouAlbumIE()

# Generated at 2022-06-24 13:32:11.281014
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    tudou_playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_id = ie._match_id(tudou_playlist_url)
    tudou_playlist_data = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % tudou_playlist_id, tudou_playlist_id)

# Generated at 2022-06-24 13:32:15.452399
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'




# Generated at 2022-06-24 13:32:17.057555
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:32:18.258783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tdpl_extractor = TudouPlaylistIE()
    tdpl_extractor.extract("")



# Generated at 2022-06-24 13:32:23.382422
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor = TudouPlaylistIE()

# Generated at 2022-06-24 13:32:28.952710
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    r = TudouPlaylistIE()._real_extract(test_url)
    assert(r['id'] == 'zzdE77v6Mmo' and r['playlist_mincount'] == 209)


# Generated at 2022-06-24 13:32:30.124356
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:32:37.194791
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE();

    tudouAlbumUrl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' # album
    tudouPlaylistUrl = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' # playlist

    assert ie._match_id(tudouAlbumUrl) is not None
    assert ie._match_id(tudouPlaylistUrl) is None

# Generated at 2022-06-24 13:32:48.851405
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'nJhAOeNxPgI'

# Generated at 2022-06-24 13:32:52.336209
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:32:56.140970
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()

# Generated at 2022-06-24 13:33:03.395168
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_tudou import expected_results, test_urls, test_formats
    from .test_youtube import params

    ie = TudouPlaylistIE()
    for url, expected_title, expected_items in expected_results:
        filename = url.split("/")[-1]
        filename = filename.split("?")[0]
        filename += ".txt"
        filename = params["output_path"] + filename
        ie.download(url, params=params)

# Generated at 2022-06-24 13:33:11.887853
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import pytest
    aie = TudouAlbumIE('tudou:album')
    assert aie.IE_NAME == 'tudou:album'
    assert aie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert aie._TESTS[0] == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
           'info_dict': {'id': 'v5qckFJvNJg'},
           'playlist_mincount': 45}



# Generated at 2022-06-24 13:33:16.736431
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/album/ws4jKi22oJY.html')
    ie.url_result('http://www.tudou.com/programs/view/%s' % item['icode'], 'Tudou', item['icode'], item['kw'])

# Generated at 2022-06-24 13:33:20.485095
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    aI = TudouAlbumIE(None, None)
    assert aI.url_regex == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:33:23.817296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    ie = TudouPlaylistIE(None)
    ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:33:27.763187
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/%s' % album_id

# Generated at 2022-06-24 13:33:31.322415
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert True == TudouPlaylistIE().suitable(playlist_url)
    

# Generated at 2022-06-24 13:33:32.953622
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor of class TudouPlaylistIE
    assert TudouPlaylistIE('TudouPlaylistIE', True)


# Generated at 2022-06-24 13:33:36.235259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Test it with your favorite URL.
    # tudou_playlist.extract(url)

# Generated at 2022-06-24 13:33:38.592971
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   assert TudouAlbumIE(TudouAlbumIE._TESTS)


# Generated at 2022-06-24 13:33:46.942267
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_raises(
        TypeError,
        TudouAlbumIE.__init__,
        TudouAlbumIE(TudouAlbumIE.name, 'TudouAlbumIE._build_url', tuple(), {})
    )
    assert_raises(
        TypeError,
        TudouAlbumIE.__init__,
        TudouAlbumIE(TudouAlbumIE.name, {}, tuple(), {})
    )
    assert_raises(
        TypeError,
        TudouAlbumIE.__init__,
        TudouAlbumIE(TudouAlbumIE.name, u'http://www.tudou.com/album(?:cover|play)/(.+)', tuple(), {})
    )

# Generated at 2022-06-24 13:33:49.015988
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:33:52.434886
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:33:54.792187
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE(None)
    assert test_TudouAlbumIE is not None

# Generated at 2022-06-24 13:33:58.836582
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_ie = TudouPlaylistIE()
    assert playlist_ie.IE_NAME == 'tudou:playlist'
    assert playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-24 13:34:08.162147
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from . import _make_valid_url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert _make_valid_url(tudou_playlist_ie._VALID_URL, url) == 'tudou:playlist'
    assert tudou_playlist_ie._TESTS[0]['url'] == url


# Generated at 2022-06-24 13:34:09.987429
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE("N/A")
    assert a.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:13.490923
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    ie.extract()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:34:19.518742
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html';
    test_album_id = 'v5qckFJvNJg';
    tudou_album_ie = TudouAlbumIE();
    ans_dict = tudou_album_ie._real_extract(test_url);
    album_id = ans_dict.get('_id');
    if album_id == test_album_id:
        return True;
    else:
        return False;


# Generated at 2022-06-24 13:34:21.089468
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    wang = TudouPlaylistIE()
    assert wang.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:34:27.526327
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test for the constructor of class TudouAlbumIE
    """
    instance_of_TudouAlbumIE = TudouAlbumIE()
    msg = "Instance of TudouAlbumIE should be an instance of InfoExtractor"
    assert isinstance(instance_of_TudouAlbumIE, InfoExtractor), msg

# Test for _real_extract method of class TudouAlbumIE

# Generated at 2022-06-24 13:34:32.727346
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_ie = TudouAlbumIE(album)
    assert album_ie.IE_NAME == 'TudouAlbum'
    assert album_ie.IE_DESC == '土豆'


# Generated at 2022-06-24 13:34:43.695289
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    d = TudouAlbumIE("./tests/tudou_test.json")
    assert d.albumid == "kYRtQ0Vt8_I"
    assert d.albumname == "高考2016语文中考真题高清珍藏版"
    assert d.albumdesc == "专辑栏目描述"
    assert d.catagory1 == "教育"
    assert d.catagory2 == "考试"
    assert d.catagory3 == "高中"
    assert d.accountid == "170119"
    assert d.accountname == "吴翟建"
    assert d.views == "14900"
    assert d

# Generated at 2022-06-24 13:34:48.055196
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.playlist_id == ie._match_id(url)
    assert ie.playlist_mincount == 209


# Generated at 2022-06-24 13:34:51.118196
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    expected_output = {'id': 'zzdE77v6Mmo'}
    assert TudouPlaylistIE._TESTS[0]['info_dict'] == expected_output


# Generated at 2022-06-24 13:34:57.602653
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("test_user")
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:34:59.284921
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouPlaylistIE)

# Generated at 2022-06-24 13:35:04.619570
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE(None)
    # test match and extract
    tudou_playlist.match(url)
    tudou_playlist.extract(url)


# Generated at 2022-06-24 13:35:05.811125
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    InfoExtractor.test_video_class('zzdE77v6Mmo')
    

# Generated at 2022-06-24 13:35:06.786104
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('Tudou')

# Generated at 2022-06-24 13:35:14.252937
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'EhGBL-BXNv8'

    playlist_data = self._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [self.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    return self.playlist_result(entries, album_id)

# Generated at 2022-06-24 13:35:16.101865
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:35:21.332764
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:35:24.577420
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    dict = ie._real_extract(ie._VALID_URL)
    assert dict['id'] == 'v5qckFJvNJg'
    # Unit test for constructor of class TudouAlbumIE
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    dict = ie._real_extract(ie._VALID_URL)
    assert dict['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:35:29.272807
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:35:32.357236
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlistIE = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert tudou_playlistIE.IE_NAME == 'tudou:playlist'
    # assert tudou_playlistIE.get_to_download()
    # assert tudou_playlistIE.get_playlist_mincount() == 209
    # assert tudou_playlistIE.get_playlist_maxcount() == 209


# Generated at 2022-06-24 13:35:41.775594
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .common import InfoExtractor
	from .tudou import TudouPlaylistIE
	from .tudou import TudouAlbumIE
	album1 = TudouAlbumIE("https://www.tudou.com/albumplay/v5qckFJvNJg.html")
	album2 = TudouAlbumIE("https://www.tudou.com/album/v5qckFJvNJg.html")
	assert(album1._VALID_URL == album2._VALID_URL)
	assert(album1.IE_NAME == album2.IE_NAME)
	playlist = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
	assert(album1._VALID_URL != playlist._VALID_URL)
	

# Generated at 2022-06-24 13:35:44.931019
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    base_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html';
    assert TudouAlbumIE(base_url)._match_id(base_url) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:35:49.005629
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_test_url = "http://www.tudou.com/albumcover/gv5J7QH1jYI.html"
	assert "TudouAlbumIE" == TudouAlbumIE()._real_extract(album_test_url)


# Generated at 2022-06-24 13:35:57.006739
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    expect = (
        r'http://www.tudou.com/tvp/plist.action\?lcode=%s' % playlist_id,
        playlist_id,
    )
    obj = TudouPlaylistIE(url)
    assert obj._download_json_url == expect[0]
    assert obj._download_json_id == expect[1]


# Generated at 2022-06-24 13:36:05.873424
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    testurl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE(None)
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:36:08.001687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    d=TudouAlbumIE()

# Generated at 2022-06-24 13:36:09.653815
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(None).ie_key() == 'TudouAlbum')


# Generated at 2022-06-24 13:36:16.900259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    expected_info = {
        'id': 'zzdE77v6Mmo',
        }
    playlist_mincount = 209
    ie = TudouPlaylistIE(None)
    result = ie.extract(url)
    assert(result['id'] == expected_info['id'])
    assert(len(result['entries']) == playlist_mincount)
    assert(result['entries'][0]['id'] == 'zzdE77v6Mmo')


# Generated at 2022-06-24 13:36:22.971567
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS == [{'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45, 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'}]
    assert 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' == TudouAlbumIE._TESTS[0]['url']

# Generated at 2022-06-24 13:36:23.563680
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest
	unittest.main()

# Generated at 2022-06-24 13:36:24.234039
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:36:32.368293
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    old_test_urls = TudouAlbumIE.test_urls
    TudouAlbumIE.test_urls = [
            'https://www.tudou.com/albumplay/zNH05xnjV7I/X9nuhlnJZK0.html',
    ]

# Generated at 2022-06-24 13:36:35.516143
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    from YoutubeUnitTest import YoutubeUnitTest
    YoutubeUnitTest(TudouAlbumIE, url).run()


# Generated at 2022-06-24 13:36:38.595341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE(dict())
    assert tudou_playlist_ie.ie_key() == 'TudouPlaylist'


# Generated at 2022-06-24 13:36:47.337422
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_object = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    assert_equals(test_object._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert_equals(test_object._TESTS[0], {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    })

# Generated at 2022-06-24 13:36:48.675305
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor of class TudouPlaylistIE
    assert TudouPlaylistIE({})

# Generated at 2022-06-24 13:36:58.561112
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/tcv/plist.action?lcode=zzdE77v6Mmo'
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }
    playlist_mincount = 209
    tup = {'url': url, 'info_dict': info_dict, 'playlist_mincount': playlist_mincount}
    t = TudouPlaylistIE(url, url)
    # assert equal (assertEqual)
    assert t.IE_NAME == 'TudouPlaylist'
    #assert dictionary equal (assertDictEqual)
    t.IE_NAME = 'Tudou'
    assert t.IE_NAME == 'Tudou'
    assert tup == t.TESTS[0]


# Generated at 2022-06-24 13:37:06.172897
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE.
    """
    # Build a dictionary to be passed to TudouPlaylistIE constructor.
    __kwargs = {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    }
    # Construct an object of type TudouPlaylistIE.
    __ie_extractor = TudouPlaylistIE(__kwargs)
    # Check that returned value of method url_result is as expected.

# Generated at 2022-06-24 13:37:08.700186
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:37:19.812999
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert_equal(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', True)
    assert_equal(ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', True)
    assert_equal(ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo', True)
    assert_equal(ie._TESTS[0]['playlist_mincount'] == 209, True)
    ie2 = TudouPlaylist

# Generated at 2022-06-24 13:37:30.449618
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test constructor of class TudouAlbumIE."""
    ie = TudouAlbumIE()
    test_cases = [
        ('http://www.tudou.com/albumcover/9rcQ2nxI8_U.html',
            'http://www.tudou.com/albumcover/9rcQ2nxI8_U.html'),
        ('http://www.tudou.com/albumplay/9rcQ2nxI8_U.html',
            'http://www.tudou.com/albumplay/9rcQ2nxI8_U.html'),
    ]

    for test_case in test_cases:
        actual = ie._match_id(test_case[0])
        expected = test_case[1]

# Generated at 2022-06-24 13:37:34.447608
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:37:38.618244
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert info_extractor.suitable(url) == True
    assert info_extractor._real_extract(url) != None



# Generated at 2022-06-24 13:37:40.695936
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from YoutubeIE import test_constructor_of_IE
    test_constructor_of_IE(TudouAlbumIE)


# Generated at 2022-06-24 13:37:42.247922
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE)


# Generated at 2022-06-24 13:37:54.054904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Test Constructor")

    print("Test 1")
    #Test 1: Normal Constructor
    album = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html", "tudou")
    assert album.valid_urls != None
    assert album.valid_urls[0] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert album.album_id == "v5qckFJvNJg"
    assert album.album_data == None
    assert album.entries == None

    print("Test 2")
    #Test 2: Invalid url, nothing in album_id

# Generated at 2022-06-24 13:38:04.794882
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for URL which should be supported
    for url in [
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ]:
        tudou_playlist = TudouPlaylistIE(url)
        tudou_playlist.get_urls()
        tudou_playlist.get_ids()
        tudou_playlist.get_id()
        tudou_playlist.get_real_url()
        tudou_playlist.get_video_info()

    # Test for URL which should not be supported

# Generated at 2022-06-24 13:38:11.496302
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    test_case1 = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    assert(ie.playlist_result(test_case1, 'zzdE77v6Mmo') == test_case1)


# Generated at 2022-06-24 13:38:16.213972
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	instance = TudouAlbumIE()
	assert instance.IE_NAME == 'tudou:album'
	assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:38:23.874387
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:38:34.491258
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE.IE_NAME == 'tudou:playlist'
    assert isinstance(IE.IE_DESC, type(u''))
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert IE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:38:42.434866
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist._download_webpage = lambda url, video_id: ''
    tudou_playlist._download_json = lambda url, playlist_id: {'items': []}
    tudou_playlist.url_result = lambda url, ie, video_id, video_title: ''
    assert tudou_playlist._real_extract(test_url)



# Generated at 2022-06-24 13:38:44.826462
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    r=TudouAlbumIE({})
    #assert False


# Generated at 2022-06-24 13:38:47.192945
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()

# Generated at 2022-06-24 13:38:57.989561
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check if TudoPlaylistIE is created correctly
    try:
        url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        playlist = TudouPlaylistIE._real_extract(TudouPlaylistIE(), url)
        playlist_id = playlist['id']
        playlist_json = playlist['_type']
    except NameError:
        raise NameError('Creation of TudoPlaylistIE failed!')
    # Check if playlist_id is correct
    if playlist_id != 'zzdE77v6Mmo':
        raise ValueError('Playlist_id is wrong!')
    # Check if playlist_json is right
    if playlist_json != 'playlist':
        raise ValueError('Playlist_json is wrong!')
    # No return if test is correct


# Generated at 2022-06-24 13:39:00.498683
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE,type)
    assert issubclass(TudouAlbumIE,InfoExtractor)


# Generated at 2022-06-24 13:39:08.444645
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE(url)
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj.IE_DESC == 'www.tudou.com'
    assert obj.js == 'tudou'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:39:12.142099
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert album.IE_NAME == 'tudou:album'
	assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
