

# Generated at 2022-06-24 13:29:11.931705
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url).run()


# Generated at 2022-06-24 13:29:14.458723
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except:
        raise Exception('TudouPlaylistIE constructor is not working properly.')


# Generated at 2022-06-24 13:29:15.414129
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 13:29:18.545024
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-24 13:29:23.638683
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    class Test(unittest.TestCase):
        def test_TudouPlaylistIE(self):
            self.assertEqual(True, True)
    suite = unittest.TestLoader().loadTestsFromTestCase(Test)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-24 13:29:30.898158
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    valid_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    assert(tudou_album_ie._match_id(valid_url) == 'v5qckFJvNJg')
    assert(tudou_album_ie._TESTS[0]['url'] == valid_url)
    valid_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert(tudou_album_ie._match_id(valid_url) == 'v5qckFJvNJg')

# Generated at 2022-06-24 13:29:31.625965
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:29:41.924369
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:29:43.344891
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 13:29:49.432007
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    import sys

    class TestTudouPlaylistIE(unittest.TestCase):
        # Constructor of the class

        def setUp(self):
            self.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
            self.tudou = TudouPlaylistIE()
            sys.stdout.write(repr(self.tudou))
            sys.stdout.flush()

        def test1_TudouPlaylistIE(self):
            self.tudou.url = self.url
            # Call the method for the class
            self.tudou.extract()
            self.assertEqual(self.tudou.url, self.url)

    # If this is run from the command line, run the tests


# Generated at 2022-06-24 13:29:58.225073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """test for constructor of class TudouPlaylistIE"""
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:29:59.517790
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouP = TudouPlaylistIE()



# Generated at 2022-06-24 13:30:07.548929
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie.__name__ == 'TudouPlaylistIE'

# Generated at 2022-06-24 13:30:12.522906
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    t = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert t.IE_NAME == "tudou:playlist"
    assert t._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t._TESTS[0]["url"] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t._TESTS[0]["info_dict"]["id"] == 'zzdE77v6Mmo'
    assert t._TESTS[0]["playlist_mincount"] == 209
 
# Test for extracting playlist entries

# Generated at 2022-06-24 13:30:13.816633
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    r = TudouAlbumIE().extract()
    assert r == None

# Generated at 2022-06-24 13:30:15.217613
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   extractor = TudouAlbumIE()


# Generated at 2022-06-24 13:30:22.644316
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test when given invalid url
    TudouPlaylistIE(None, invalid_url='https://techcrunch.com/2015/01/29/with-six-days-to-go-before-the-fccs-net-neutrality-vote-the-movement-is-gaining-momentum/?ncid=rss', charToType='1')

    # Test when given valid url
    TudouPlaylistIE(None, valid_url='http://www.tudou.com/listplay/zzdE77v6Mmo.html', charToType='1')


# Generated at 2022-06-24 13:30:29.110261
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:30:30.869068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor of class TudouPlaylistIE(InfoExtractor)
    #TudouPlaylistIE()
    return

# Generated at 2022-06-24 13:30:34.638107
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test URL: http://www.tudou.com/listplay/zzdE77v6Mmo.html
    TudouPlaylistIE()._real_extract(TudouPlaylistIE._TESTS[0])


# Generated at 2022-06-24 13:30:46.751515
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:30:57.273856
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:31:08.600297
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_TEST = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert IE_TEST.IE_NAME == 'tudou:playlist' and IE_TEST._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' and IE_TEST._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:31:12.747322
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    playlist = ie._real_extract(url)
    assert playlist['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:31:18.810633
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-24 13:31:20.709685
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert str(test) == 'Tudou:album'

# Generated at 2022-06-24 13:31:24.951186
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert t._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:31:36.605432
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudouPlaylistIE = TudouPlaylistIE()
    assert(tudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(tudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    

# Generated at 2022-06-24 13:31:38.062780
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE(None)



# Generated at 2022-06-24 13:31:42.269617
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    ie.get_url()
    ie.get_video_id()
    ie.get_title()


# Generated at 2022-06-24 13:31:43.896458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:31:46.700259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

#Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:31:56.441771
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(test_url)
    assert ie.ie_name == 'tudou:playlist'
    assert ie.VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-24 13:32:06.280335
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict'] == {
            'id': 'v5qckFJvNJg',
        }
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:32:09.558206
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert_equal(tudou_album_ie._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')


# Generated at 2022-06-24 13:32:20.562465
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import test_url
    from .common import test_dict

    test_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'TudouAlbumIE', 'v5qckFJvNJg')
    test_url('http://www.tudou.com/albumcover/v5qckFJvNJg.html', 'TudouAlbumIE', 'v5qckFJvNJg')
    test_dict(
        'TudouAlbumIE', 'v5qckFJvNJg', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        query={'id': 'v5qckFJvNJg'})

# Generated at 2022-06-24 13:32:28.384273
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t1 = TudouPlaylistIE()
    assert t1.IE_NAME == 'tudou:playlist', 'test1: IE_NAME error!'
    assert t1._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', 'test2: _VALID_URL error!'
    assert t1._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }], 'test3: _TESTS error!'


# Generated at 2022-06-24 13:32:35.257288
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    playlist = TudouAlbumIE('http://www.tudou.com/albumplay/abcdefghijk.html')
    assert playlist.entries[0] == {
        'id': 'abcdefghijk',
        'webpage_url': 'http://www.tudou.com/albumplay/abcdefghijk.html',
        'ie_key': 'Tudou',
    }
    assert playlist.title == 'abcdefghijk'


# Generated at 2022-06-24 13:32:46.835750
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import  fake_useragent
    from .common import  fake_urlopen
    from .common import  FakeDisplay
    from .common import  FakeDownload
    from .common import FakeToString
    from .common import  class_register, method_register
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import TEST_DIRECTORY
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest
    from .common import  unittest

# Generated at 2022-06-24 13:32:51.352758
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie.album_id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:33:02.455697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	
    # Test instance creation
    try:
        playlist = TudouPlaylistIE()
    except:
        raise AssertionError('[ERROR] Test instance creation failed.')
    
    # Test regular expression
    try:
        test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        result = playlist._VALID_URL.match(test_url)
        assert result
    except:
        raise AssertionError('[ERROR] Test regular expression failed.')

# Generated at 2022-06-24 13:33:07.953341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test with a valid url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)
    # test with a invalid url
    url = 'http://www.tudou.com/'
    try:
        TudouPlaylistIE(url)
    except ValueError:
        print('test passed')


# Generated at 2022-06-24 13:33:10.457609
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_IE = TudouPlaylistIE();
    assert (tudou_playlist_IE.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-24 13:33:11.463841
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:33:12.979694
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return
    album_ie = TudouAlbumIE(None)

# Generated at 2022-06-24 13:33:16.082815
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    list_TudouPlaylistIE = []
    for i in range(0, 2):
        list_TudouPlaylistIE.append(TudouPlaylistIE(i))
    return


# Generated at 2022-06-24 13:33:17.946892
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = [TudouPlaylistIE()]
    assert tudouplaylist

# Generated at 2022-06-24 13:33:21.685482
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()._info_from_url
    assert info('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == {
        'id': 'zzdE77v6Mmo',
    }



# Generated at 2022-06-24 13:33:23.358181
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except SystemExit:
        pass

# Generated at 2022-06-24 13:33:33.826458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Testing constructor of class TudouAlbumIE
    from TudouAlbumIE import TudouAlbumIE
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    # test for url_pattern
    try:
        TudouAlbumIE(url)
    except ExtractorError:
        assert False, 'url_pattern failed'
    try:
        TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    except ExtractorError:
        assert False, 'url_pattern failed'

# Generated at 2022-06-24 13:33:35.955723
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-24 13:33:40.987774
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/v5qckFJvNJg.html'
    #TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    TudouPlaylistIE(url)


# Generated at 2022-06-24 13:33:44.533903
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE(TudouAlbumIE._downloader)
    assert obj.ie_key() == "Tudou"
    assert obj.ie_name() == "tudou:album"
    assert obj.ie_description() == "Tudou.com"

# Generated at 2022-06-24 13:33:54.489892
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_instance = TudouAlbumIE()
    assert_equal(test_instance._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert_equal(test_instance._TESTS[0]['url'], 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert_equal(test_instance._TESTS[0]['info_dict'], {'id': 'v5qckFJvNJg'})
    assert_equal(test_instance._TESTS[0]['playlist_mincount'], 45)

# Generated at 2022-06-24 13:33:57.346794
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    field = tudouAlbumIE.__dict__
    has = "TudouAlbumIE" in field.keys()
    print(has)

# Generated at 2022-06-24 13:34:09.203834
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	result = TudouPlaylistIE(InfoExtractor())
	assert result.ie_key() == 'Tudou'
	assert result.ie_name == 'tudou:playlist'

# Generated at 2022-06-24 13:34:15.608794
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Basic usage
    TudouPlaylistIE().extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # Test for non existing URL
    TudouPlaylistIE().extract('http://www.tudou.com/listplay/zzdE7.html')
    # Test for non existing URL
    TudouPlaylistIE().extract('http://www.tudou.com/listplay/zzdE77v6Mmo_____.html')


# Generated at 2022-06-24 13:34:19.162471
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:34:21.217957
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case from https://www.tudou.com/listplay/zzdE77v6Mmo.html
    playlist = TudouPlaylistIE()
    playlist.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:34:28.871819
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(TudouAlbumIE.IE_NAME)._match_id(url) == 'v5qckFJvNJg'
    TudouAlbumIE(TudouAlbumIE.IE_NAME, 'TudouAlbumIE._real_extract')._real_extract(url)


# Generated at 2022-06-24 13:34:34.261644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Run testcase for TudouPlaylistIE class.
    """
    from .test_utils import get_testcases

# Generated at 2022-06-24 13:34:40.488889
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:34:47.902940
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Case 1: URL for playlist page
    url1 = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tpd1 = TudouPlaylistIE()
    assert tpd1._match_id(url1) == 'zzdE77v6Mmo'
    assert tpd1._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:34:49.699336
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	Playlist = TudouPlaylistIE()
	assert isinstance(Playlist,InfoExtractor)


# Generated at 2022-06-24 13:34:57.548927
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album = TudouAlbumIE()
    assert album is not None
    assert album.suitable(url) is True
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:01.244962
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:35:06.461341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie1 = TudouPlaylistIE(None)
    print('Unit test for constructor of class TudouPlaylistIE...\n')

    ie1.extract_info('http://www.tudou.com/listplay/zzdE77v6Mmo.html', force_generic_extractor=False)
    


# Generated at 2022-06-24 13:35:12.107479
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()
    assert test_TudouAlbumIE.IE_NAME == 'tudou:album'
    assert test_TudouAlbumIE.IE_NAME_RE == 'tudou:album'
    assert test_TudouAlbumIE.VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert test_TudouAlbumIE.VALID_URL_RE == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:35:23.539151
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()
    assert 'tudou:album' == info_extractor.IE_NAME
    assert 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})' == info_extractor._VALID_URL
    with open("../tudou/tudou_album.py", "r") as album_file:
        content = album_file.read()
        assert 'def _real_extract(self, url):' in content
        assert 'album_id = self._match_id(url)' in content
        assert 'album_data = self._download_json' in content
        assert 'entries = [self.url_result' in content

# Generated at 2022-06-24 13:35:29.068399
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    app = TudouPlaylistIE(None, None, None)
    info = app.extract(url)
    assert info['id'] == 'zzdE77v6Mmo'
    assert len(info['entries']) == 209


# Generated at 2022-06-24 13:35:32.594810
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html', {'id': 'v5qckFJvNJg'}, {})

# Generated at 2022-06-24 13:35:40.619107
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE.__doc__ = ' """\n'
    test_TudouPlaylistIE.__doc__ += 'The code is copied from test_YoutubePlaylistIE.\n'
    test_TudouPlaylistIE.__doc__ += 'It is intended to test the constructor of class TudouPlaylistIE.\n'
    test_TudouPlaylistIE.__doc__ += '"""\n'

    from .youtube import YoutubePlaylistIE
    from .youtube import YoutubeIE
    test_TudouPlaylistIE.__doc__ += 'Test code of YoutubePlaylistIE:\n'
    test_TudouPlaylistIE.__doc__ += str(YoutubePlaylistIE)
    test_TudouPlaylistIE.__doc__ += '\n\n'
    test_Tud

# Generated at 2022-06-24 13:35:43.572767
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    extractor = TudouPlaylistIE('zzdE77v6Mmo.html')
    assert extractor._match_id('zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
    assert extractor._download_json('') == None


# Generated at 2022-06-24 13:35:54.328060
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    IE = TudouPlaylistIE(url)
    assert IE.url == url
    assert IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert IE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:35:56.108779
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE._real_extract(TudouAlbumIE(), url)

# Generated at 2022-06-24 13:35:57.035411
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbum = TudouAlbumIE()
	assert tudouAlbum != None


# Generated at 2022-06-24 13:36:02.438438
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/qgAi4F2mgMA.html'

# Generated at 2022-06-24 13:36:06.344389
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1


# Generated at 2022-06-24 13:36:15.703098
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing constructor of the class TudouPlaylistIE")
    tudou_playlist = TudouPlaylistIE()
    print("Testing url property")
    print("The url is: ", tudou_playlist.url)
    print("Testing name property")
    print("The name is: ", tudou_playlist.name)
    print("Testing description property")
    print("The description is: ", tudou_playlist.description)
    print("Testing test property")
    print("The test is: ", tudou_playlist.test)
    print("Testing ie_key property")
    print("The ie_key property is: ", tudou_playlist.ie_key)
    print("Testing ie_key property")
    print("The ie_key property is: ", tudou_playlist.ie_key)

# Generated at 2022-06-24 13:36:17.684069
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist.IE_NAME


# Generated at 2022-06-24 13:36:19.794975
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    ie = TudouAlbumIE()
    assert ie != None


# Generated at 2022-06-24 13:36:22.212251
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert(TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html") != None)


# Generated at 2022-06-24 13:36:24.095223
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE is not None



# Generated at 2022-06-24 13:36:30.388882
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor(None)
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:36:35.193257
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test parameters
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Test real extraction
    try:
        TudouAlbumIE()._real_extract(url)
    # Catch exceptions
    except:
        print('Catch an exception')
        return False
    else:
        return True

# Test
if test_TudouAlbumIE():
    print('Test passed')
else:
    print('Test failed')

# Generated at 2022-06-24 13:36:44.868496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    class_ = TudouPlaylistIE('tudou:playlist')
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    playlist_data_json = class_._download_json(playlist_data, playlist_id)
    playlist_entries = [class_.url_result('http://www.tudou.com/programs/view/%s' % item['icode'], 'Tudou', item['icode'], item['kw']) for item in playlist_data_json['items']]
    playlist_result = class_.playlist_

# Generated at 2022-06-24 13:36:54.593151
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE(): 
    tudou_playlist_obj = TudouPlaylistIE()

    assert tudou_playlist_obj.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_obj._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_obj._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    # assert tudou_playlist_obj._download_json is True

# Generated at 2022-06-24 13:37:01.909818
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    
  # 1.
  # Test for the constructor of class TudouAlbumIE
  # 1.1.
  # Test for the construction of a empty object
  # 1.1.1.
  # Test the type of the object is class TudouAlbumIE
  assert(type(TudouAlbumIE()) == TudouAlbumIE)

  # 1.2
  # Test for the construction of a non-empty object
  # 1.2.1
  # Test the type of the object is class TudouAlbumIE
  assert(type(TudouAlbumIE(123, "play")) == TudouAlbumIE)

  # 1.2.2
  # Test the value of the attribute _VALID_URL of the object

# Generated at 2022-06-24 13:37:02.929146
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE(None)
    assert a


# Generated at 2022-06-24 13:37:05.099314
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

# Generated at 2022-06-24 13:37:09.019453
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("\nTest: TudouPlaylistIE")
    instance_list = [("http://www.tudou.com/listplay/zzdE77v6Mmo.html","tudou:playlist")]
    for url_test, ie in instance_list:
        ie_test = TudouPlaylistIE(url_test)
        print("\nInstance: "+ie+"\nURL: "+ie_test.url)
        assert ie == ie_test._type, 'Expected "' + ie + '", obtained "' + ie_test._type + '"'


# Generated at 2022-06-24 13:37:20.117806
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Example: Constructor of class TudouAlbumIE
    from you_get.extractors.tudou import TudouAlbumIE
    tudou_album_ie = TudouAlbumIE()
    print(tudou_album_ie.IE_NAME) # tudou:album
    print(tudou_album_ie._VALID_URL) # https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})
    print(tudou_album_ie._TESTS) # [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount

# Generated at 2022-06-24 13:37:21.175144
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    m = TudouPlaylistIE()
    ie = InfoExtractor()
    ie.add_info_extractor(m)
    ie._real_initialize()


# Generated at 2022-06-24 13:37:31.803958
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import json

    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-24 13:37:34.501357
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    p = t.playlist_result([], {})
    assert p is not None

# Generated at 2022-06-24 13:37:42.448838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE({})
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:37:43.417406
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  TudouPlaylistIE('TudouPlaylistIE')

# Generated at 2022-06-24 13:37:45.547826
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except Exception:
        raise AssertionError


# Generated at 2022-06-24 13:37:46.813425
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-24 13:37:47.959783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:37:58.904687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie=TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = ie._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return ie.playlist_result(entries, album_id)

# Generated at 2022-06-24 13:38:06.462189
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:38:17.038415
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tpIE = TudouPlaylistIE()
    assert tpIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tpIE._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]
    assert tpIE.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-24 13:38:20.812517
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ifile = 'tests/data/tudou_album.html'
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    i = TudouAlbumIE(ifile,url)

# Generated at 2022-06-24 13:38:27.418574
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:38:29.903591
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:38:41.364310
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test a valid url
    tudou_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    result = ie.suitable(tudou_url)
    assert result, '%s should be a valid url for %s' % (tudou_url, ie.IE_NAME)

    # test a invalid url
    tudou_url = 'http://www.baidu.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    result = ie.suitable(tudou_url)
    assert not result, '%s is a invalid url for %s' % (tudou_url, ie.IE_NAME)


# Generated at 2022-06-24 13:38:42.397370
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    extractor = TudouAlbumIE()

# Generated at 2022-06-24 13:38:43.472448
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:38:45.413244
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE()
	assert obj.ie_key() == "Tudou"

# Generated at 2022-06-24 13:38:48.358234
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(12, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')



# Generated at 2022-06-24 13:38:59.037585
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	tudou_playlist_IE = TudouPlaylistIE(playlist)
	assert tudou_playlist_IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert tudou_playlist_IE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
	assert tudou_playlist

# Generated at 2022-06-24 13:39:03.692305
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-24 13:39:06.728114
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
  TudouPlaylistIE(url)


# Generated at 2022-06-24 13:39:11.490029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        tudouAlbumIE = TudouAlbumIE()
        print("The constructor of class TudouAlbumIE is successfully!")
    except Exception as err:
        print("The constructor of class TudouAlbumIE is failed!")

if __name__ == '__main__':
    test_TudouAlbumIE()