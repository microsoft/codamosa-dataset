

# Generated at 2022-06-24 13:29:16.212682
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie.ie_key() == 'Tudou:album')
    assert(ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html'))
    assert(ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html'))
    assert(not ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.htm'))

# Generated at 2022-06-24 13:29:26.998131
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'
    assert TudouAlbumIE.test() == (True, None)
    assert TudouAlbumIE._extract_urls('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']

# Generated at 2022-06-24 13:29:28.382249
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    print(tudouPlaylistIE)


# Generated at 2022-06-24 13:29:29.508503
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL



# Generated at 2022-06-24 13:29:41.343371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_id = tudou_playlist_url.split('/')[-1].split('.')[0]
    tudou_playlist_json_url = 'http://www.tudou.com/tvp/plist.action?lcode=' + tudou_playlist_id

# Generated at 2022-06-24 13:29:42.520090
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-24 13:29:44.235374
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO
    return NotImplemented


# Generated at 2022-06-24 13:29:46.106853
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:29:55.866810
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE()
    video_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = test_obj._match_id(video_url)
    playlist_data = test_obj._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [test_obj.url_result(
                'http://www.tudou.com/programs/view/%s' % item['icode'],
                'Tudou', item['icode'],
                item['kw']) for item in playlist_data['items']]
    test_obj.playlist_result(entries, playlist_id)


#

# Generated at 2022-06-24 13:29:59.000827
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:30:04.075837
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    play = TudouPlaylistIE()
    assert play.IE_NAME == 'tudou:playlist'
    assert play._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert play._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert play._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert play._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:30:08.691684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou = TudouAlbumIE()
    assert tudou._match_id(url) == 'v5qckFJvNJg'


# Generated at 2022-06-24 13:30:13.688426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""

# Generated at 2022-06-24 13:30:16.782414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('Tudou','http://www.tudou.com/albumplay/v5qckFJvNJg.html','Album','v5qckFJvNJg',None,{})

# Generated at 2022-06-24 13:30:19.498244
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.ie_key() == 'Tudou:playlist'
    assert playlist.ie_name() == 'TudouPlaylist'


# Generated at 2022-06-24 13:30:24.692741
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert test._match_id("") == "v5qckFJvNJg"
    assert test._download_json("","") == [{'icode': '', 'kw': ''}]
    assert test.url_result("","","","") == ""

# Generated at 2022-06-24 13:30:32.556797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:30:38.598836
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for List Page
    assert(isinstance(TudouPlaylistIE(1), InfoExtractor))
    assert(isinstance(TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html'), InfoExtractor))
    assert(isinstance(TudouPlaylistIE('zzdE77v6Mmo'), InfoExtractor))
    assert(isinstance(TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html?page=1'), InfoExtractor))
    # Test for Album Page
    assert(isinstance(TudouPlaylistIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html'), InfoExtractor))

# Generated at 2022-06-24 13:30:50.454656
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor raises an exception if extractor type is not playlist
    test_cases = [
        {
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        },
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }
    ]

# Generated at 2022-06-24 13:31:01.084771
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import pytest

    # Assert that a valid url can be well-constructed
    valid_url = r'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE(valid_url)
    assert tudou_playlist.url == valid_url
    assert tudou_playlist.name == r'zzdE77v6Mmo'

    # Assert that an invalid url will throw an exception
    invalid_url = r'http://www.tudou.com/listplay/zzdE77v6Mmo'
    with pytest.raises(ValueError) as excinfo:
        TudouPlaylistIE(invalid_url)

# Generated at 2022-06-24 13:31:02.090984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:31:07.355868
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #### http://www.tudou.com/listplay/zzdE77v6Mmo.html
    assert TudouPlaylistIE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:31:11.084108
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    tudouAlbumIE = self._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert True
    '''


# Generated at 2022-06-24 13:31:12.507824
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist



# Generated at 2022-06-24 13:31:21.046018
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209



# Generated at 2022-06-24 13:31:24.625823
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:31:36.317021
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test valid URL:
	for url in [
					'http://www.tudou.com/listplay/SZH_bLC1LOE.html',
					'http://www.tudou.com/listplay/SZH_bLC1LOE.HTML'
			]:
		tudouplaylistie = TudouPlaylistIE(url)
		assert tudouplaylistie.is_valid() == True
	# Test invalid URL:

# Generated at 2022-06-24 13:31:46.141475
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case 1
    url1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected_output1 = {
        'id': 'zzdE77v6Mmo',
    }
    # Test case 2
    url2 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_output2 = {
        'id': 'v5qckFJvNJg',
    }
    
    tudou_playlist_instance = TudouPlaylistIE()
    output1 = tudou_playlist_instance._real_extract(url1)
    output2 = tudou_playlist_instance._real_extract(url2)

# Generated at 2022-06-24 13:31:48.602256
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import re
	from .common import InfoExtractor
	def __init__(self, ie_name):
		assert(re.match(r'^TudouAlbumIE$', ie_name))


# Generated at 2022-06-24 13:31:51.465022
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print(TudouAlbumIE.__init__.__doc__)
    # Actual test code
    tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-24 13:32:01.964340
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    with open("tudou.txt", "w") as f:
        f.write("""
http://www.tudou.com/albumcover/v5qckFJvNJg.html
http://www.tudou.com/albumcover/abcdEG1231g.html
        """)
    with open("tudou.txt", "r") as f:
        assert ie._VALID_URL in f.read()
    import os
    os.remove("tudou.txt")
    tudou_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

# Generated at 2022-06-24 13:32:04.116875
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import extractor.tudou
    extractor.tudou.TudouAlbumIE

# Generated at 2022-06-24 13:32:05.731450
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()


# Generated at 2022-06-24 13:32:17.479374
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# _VALID_URL - check all codes from a-z, A-Z and 0-9 and check for URL with a path and without it
	# example case of valid URL: http://www.tudou.com/listplay/zzdE77v6Mmo.html
	# example case of invalid URL: http://www.tudou.com/listplay/zzdE77v6Mmo
	# example case of invalid URL: http://www.tudou.com/listplay/zzdE77v6-mo.html
	for i in range(0, 62):
		if (i<26):
			TudouPlaylistIE(i, "http://www.tudou.com/listplay/zzdE77v%cMmo.html" % (i+97))

# Generated at 2022-06-24 13:32:18.164062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:32:18.862904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE.suite()

# Generated at 2022-06-24 13:32:24.564269
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:32:30.066017
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:32:36.499939
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('TudouPlaylistIE','http://www.tudou.com/listplay/zzdE77v6Mmo.html','zzdE77v6Mmo')
    assert instance.name == 'TudouPlaylistIE'
    assert instance.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert instance.video_id == 'zzdE77v6Mmo'


# Generated at 2022-06-24 13:32:48.188801
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_str = 'this is a string'
    album_data = {
        'id' : album_id,
        'album_id' : album_id,
        'title': album_str,
        'description': album_str,
        'items': [
            {
                'icode' : album_id,
                'kw' : album_str
            }
        ]
    }
    i = TudouAlbumIE()
    i.album_id = album_id
    i.album_data = album_data
    assert i.album_id == album_id
    assert i.album_data['id'] == album_id
    assert i.album_data['title'] == album_str

# Generated at 2022-06-24 13:32:52.606745
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import re

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ies = TudouAlbumIE().extract(url)
    assert len(ies) >= 1
    assert ies[0]['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:32:55.844264
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    tudou_album_ie._real_extract(url)

# Generated at 2022-06-24 13:33:05.182948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert album._TESTS[0].url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert album._TESTS[0].info_dict.id == 'v5qckFJvNJg'
    assert album._TESTS[0].playlist_mincount == 45

# Generated at 2022-06-24 13:33:10.735056
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    
    # Define the test input and test result
    TestInput = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TestResult = lambda x: x == 'zzdE77v6Mmo'

    # Create a instance of TudouPlaylistIE
    test_instance = TudouPlaylistIE()
    
    # Test the constructor
    assert TestResult(test_instance._match_id(TestInput))



# Generated at 2022-06-24 13:33:15.268674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test case 1
	tudou_playlist_ie = TudouPlaylistIE()

	assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:33:19.474892
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_playlist = "https://www.tudou.com/listplay/338c8MjTdT0.html"
    extractor = TudouPlaylistIE()
    assert extractor._match_id(test_playlist) == "338c8MjTdT0"


# Generated at 2022-06-24 13:33:21.828391
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    c = TudouAlbumIE()
    assert c.IE_NAME == 'Tudou:album'



# Generated at 2022-06-24 13:33:24.060990
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    assert ie.ID == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:33:29.224762
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie == TudouAlbumIE()
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie == TudouPlaylistIE()
    assert tudou_album_ie != tudou_playlist_ie


# Generated at 2022-06-24 13:33:33.425704
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    playlist_id = 'zzdE77v6Mmo'
    assert playlist_id == TudouPlaylistIE._match_id(url)


# Generated at 2022-06-24 13:33:39.064558
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: Transform to unit test
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_album_ie = TudouAlbumIE(url)
    print(tudou_album_ie)


# Generated at 2022-06-24 13:33:44.499432
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbum = TudouAlbumIE()
	# Test the constructor
	assert tudouAlbum
	# Test the _real_extract function, in which we can see the response on the url
	# we can also get the information of each video and the total number
	tudouAlbum._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:33:46.848186
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Check that the constructor of class TudouAlbumIE is not None
    ie = TudouAlbumIE()
    assert ie != None


# Generated at 2022-06-24 13:33:47.706321
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for normal case
    TudouPlaylistIE()


# Generated at 2022-06-24 13:33:52.978524
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    #assert TudouPlaylistIE()._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:33:55.549989
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__name__ == 'TudouPlaylistIE'
    assert TudouPlaylistIE.__qualname__ == 'TudouPlaylistIE'


# Generated at 2022-06-24 13:33:58.204258
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:34:09.894191
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouUrl = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudouPlaylist = TudouPlaylistIE(tudouUrl)
    assert tudouPlaylist.name == 'TudouPlaylistIE'
    assert tudouPlaylist.ie_key() == 'Tudou'
    assert tudouPlaylist.url == tudouUrl
    assert tudouPlaylist.url.count("//") == 2
    assert tudouPlaylist.url.count("//www.tudou.com/listplay/zzdE77v6Mmo.html") == 1
    assert tudouPlaylist.url.count("www.tudou.com/listplay/zzdE77v6Mmo.html") == 1

# Unit

# Generated at 2022-06-24 13:34:16.466280
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0].get('url') == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0].get('info_dict').get('id') == 'zzdE77v6Mmo'
    assert ie._TESTS[0].get('playlist_mincount') == 209


# Generated at 2022-06-24 13:34:17.305671
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie is not None)

# Generated at 2022-06-24 13:34:18.851331
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
        url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        ie = TudouAlbumIE(url)

# Generated at 2022-06-24 13:34:19.425745
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-24 13:34:31.431466
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    # Extract album info with given album_id
    ID = 'v5qckFJvNJg'

# Generated at 2022-06-24 13:34:33.489213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   album_id = 'a0123456789'
   assert isinstance(TudouAlbumIE(album_id), InfoExtractor)

# Generated at 2022-06-24 13:34:37.237084
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:40.838962
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from TudouPlaylistIE import TudouPlaylistIE
	import unittest	
	class TestTudouPlaylistIE(unittest.TestCase):
		def test_constructor(self):
			TudouPlaylistIE()

# Generated at 2022-06-24 13:34:42.441089
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import main
    main(TudouAlbumIE, __file__, int)

# Generated at 2022-06-24 13:34:46.075798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    browser = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    browser.test_playlist_mincount()


# Generated at 2022-06-24 13:34:54.985159
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    assert tudouAlbum.IE_NAME == 'tudou:album'
    assert tudouAlbum._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudouAlbum._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudouAlbum._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert tudouAlbum._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:34:59.283072
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	testUrl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	TudouTest = TudouAlbumIE()
	assert TudouTest._match_id(testUrl) == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:35:07.984216
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = _download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return self.playlist_result(entries, album_id)



# Generated at 2022-06-24 13:35:14.252884
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    result = tudou_playlist_ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['id'] == 'zzdE77v6Mmo'
    assert len(result['entries']) == 209


# Generated at 2022-06-24 13:35:15.317049
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE()

# Generated at 2022-06-24 13:35:17.254881
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
        from tests.main import main
    main(TudouAlbumIE)

# Generated at 2022-06-24 13:35:21.231430
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    # Test wrong url
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg'
    assert ie._match_id(url) == None

# Generated at 2022-06-24 13:35:26.041562
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://example.com/abc.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-24 13:35:36.874988
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    #url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html?cid=17&fcode=2&type=0&sid=8860555&sid=8860555"
    #print('url:', url)
    #url_base = "http://www.tudou.com/tvp/alist.action?acode=%s"
    album_id = "v5qckFJvNJg"
    #print('url_base:', url_base)
    #print('album_id:',

# Generated at 2022-06-24 13:35:38.602906
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'Tudou')

# Generated at 2022-06-24 13:35:42.860788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('tudou:playlist')
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:35:43.720670
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-24 13:35:54.998192
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test when pass a invalid url
    invalid_url = 'http://example.com/listplay/zzdE77v6Mmo.html'
    test_1 = TudouPlaylistIE()
    assert test_1._match_id(invalid_url) == None, "test when pass a invalid url"
    # test when not pass url
    test_2 = TudouPlaylistIE()
    assert test_2._match_id(None) == None, "test when not pass url"
    # test when pass a valid url
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_3 = TudouPlaylistIE()

# Generated at 2022-06-24 13:35:57.243721
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for default constructor
    assert TD.IE_NAME == "tudou:playlist"

# Tests for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:01.150868
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert tudou_albumIE.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-24 13:36:07.373317
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #Unit testing on Tudou Playlist sites

    #Constructor
    ie = TudouPlaylistIE(TudouPlaylistIE._create_ie_instance())

    #Public members
    assert ie.name == 'tudou'
    assert ie.ie_key() == 'tudou'
    assert ie.description == '东方视讯网络电视台'
    assert ie.version == '1.0'
    assert ie.extractor_key == 'TudouPlaylist'

    #Private members
    assert ie._WORKING == True
    assert ie._TEST == False

    #Protected members

# Generated at 2022-06-24 13:36:14.628484
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                          'info_dict': {'id': 'zzdE77v6Mmo'},
                          'playlist_mincount': 209,
                          }]

# Generated at 2022-06-24 13:36:17.037479
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-24 13:36:18.759934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except:
        assert False

# Generated at 2022-06-24 13:36:27.999909
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	a = TudouAlbumIE()
	assert a.IE_NAME == "tudou:album"
	assert type(a._VALID_URL) == str
	assert a._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	assert type(a._TESTS[0]) == dict
	assert a._TESTS[0]['info_dict'] == {"id": "v5qckFJvNJg"}
	assert type(a._TESTS[0]['info_dict']) == dict
	assert a._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg"

# Generated at 2022-06-24 13:36:28.903055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    return a

# Generated at 2022-06-24 13:36:38.198319
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.IE_NAME == "tudou:album"
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudouAlbumIE._TESTS) == 1
    assert tudouAlbumIE._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert tudouAlbumIE._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg"
    assert tudouAlbumIE._

# Generated at 2022-06-24 13:36:42.319774
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(test_url)

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-24 13:36:45.122981
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import expected_warnings
    TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-24 13:36:46.589955
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test empty constructor
    try:
        TudouPlaylistIE()
    except:
        pass


# Generated at 2022-06-24 13:36:49.035675
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'TudouPlaylistIE').test()

# Generated at 2022-06-24 13:36:58.252791
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj = TudouAlbumIE(url)
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert obj._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-24 13:37:01.197333
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == TudouPlaylistIE.IE_NAME
    assert ie._VALID_URL == TudouPlaylistIE._VALID_URL
    assert ie._TESTS == TudouPlaylistIE._TESTS


# Generated at 2022-06-24 13:37:04.115668
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()
    IE_NAME = playlist._VALID_URL
    assert playlist._VALID_URL == IE_NAME

# Generated at 2022-06-24 13:37:09.267203
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 1. Check if the constructor is able to load the page
    ie = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    # 2. Check id of the page
    assert ie.id == 'v5qckFJvNJg'

# Generated at 2022-06-24 13:37:13.225691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(
        InfoExtractor())._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:37:16.573223
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create a tudou playlist object
    test_TudouPlaylistIE = TudouPlaylistIE()
    # Check the type of the object
    assert isinstance(test_TudouPlaylistIE, object)

# Generated at 2022-06-24 13:37:21.596386
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Test these two types of urls
    ie._real_initialize('http://www.tudou.com/listplay/z0s-sK_URio.html')
    ie._real_initialize('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    return "PASS"


# Generated at 2022-06-24 13:37:31.610117
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie_test_instance = TudouAlbumIE()
    input_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_output_id_value = 'v5qckFJvNJg'
    tudou_album_ie_test_instance._real_extract(input_url)
    output_id_value = tudou_album_ie_test_instance._match_id(input_url)
    if (expected_output_id_value == output_id_value):
        print("test_TudouAlbumIE passed!")
    else:
        print("test_TudouAlbumIE failed!")

# Generated at 2022-06-24 13:37:34.694730
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE()._match_id('zzdE77v6Mmo') == 'zzdE77v6Mmo')

# Generated at 2022-06-24 13:37:36.990408
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = TudouAlbumIE._VALID_URL
    ie = TudouAlbumIE('test', url)
    assert ie._match_id(url) == ie.IE_NAME


# Generated at 2022-06-24 13:37:43.446563
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.playlist_mincount == 1
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert t

# Generated at 2022-06-24 13:37:44.915718
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    l = TudouAlbumIE()
    assert l.IE_NAME == "TudouAlbumIE"



# Generated at 2022-06-24 13:37:52.373063
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_in = ["http://www.tudou.com/albumplay/v5qckFJvNJg.html"]
    test_out = ["v5qckFJvNJg"]
    assert_res = True
    for i in range(len(test_in)):
        if(test_out[i] != TudouAlbumIE._match_id(test_in[i])):
            assert_res = False
    return assert_res


# Generated at 2022-06-24 13:37:56.622484
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.suitable(url)


# Generated at 2022-06-24 13:38:04.392624
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/b1J2QnyHN6U.html'
    tudou_playlist = TudouPlaylistIE(url)
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist.url == url
    assert tudou_playlist.playlist_id == 'b1J2QnyHN6U'


# Generated at 2022-06-24 13:38:05.602577
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_TudouPlaylistIE = TudouPlaylistIE();
    assert isinstance(ie_TudouPlaylistIE, InfoExtractor)

# Generated at 2022-06-24 13:38:16.942260
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import re
    import os
    import pkgutil
    from .common import InfoExtractor
    from .aenetworks import AENetworksIE
    from .tudou import TudouAlbumIE
    from .tudou import TudouPlaylistIE
    from .common import expectedFailure

    #######################
    # Check the IE list
    #######################

    # Check all the file names follow the rule
    for importer, modname, ispkg in pkgutil.iter_modules(__path__):
        if modname.startswith('_') or modname.endswith('_test') or 'common' in modname:
            continue
        if modname in ('youtube', 'XTubeUserIE'):
            continue


# Generated at 2022-06-24 13:38:25.271684
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-24 13:38:28.973855
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    o = TudouPlaylistIE()
    o._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')


# Generated at 2022-06-24 13:38:40.675365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pie = TudouPlaylistIE()
    assert pie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert pie.ie_name == 'tudou:playlist'
    assert pie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert pie.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not pie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.htm')

# Generated at 2022-06-24 13:38:44.501068
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import  TudouAlbumIE
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:38:48.650257
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    assert(tudouPlaylist is not None)

# Generated at 2022-06-24 13:38:54.146824
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('id')
    assert(ie.IE_NAME == 'tudou:album')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(len(ie._TESTS) == 1)



# Generated at 2022-06-24 13:38:56.987196
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url, {})


# Generated at 2022-06-24 13:39:08.815062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'