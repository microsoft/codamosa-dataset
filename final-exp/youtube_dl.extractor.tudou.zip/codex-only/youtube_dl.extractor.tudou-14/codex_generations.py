

# Generated at 2022-06-24 13:29:14.510032
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:29:16.592334
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert type(tudouPlaylistIE) == TudouPlaylistIE


# Generated at 2022-06-24 13:29:18.001425
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(None, None)



# Generated at 2022-06-24 13:29:20.364224
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    assert  x.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:29:23.277654
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(InfoExtractor)._VALID_URL == TudouAlbumIE._VALID_URL
    assert TudouAlbumIE(InfoExtractor)._TESTS == TudouAlbumIE._TESTS

# Generated at 2022-06-24 13:29:29.164153
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Unit test for constructor of class TudouPlaylistIE")
    url1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url2 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouPlaylistIE()
    if not ie.suitable(url1):
        print("Failed to recognize the playlist URL %s" % url1)


# Generated at 2022-06-24 13:29:36.419808
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.ID == 'v5qckFJvNJg'
    assert ie.ALBUM_URL == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'



# Generated at 2022-06-24 13:29:39.511397
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE = TudouPlaylistIE(url)
    assert TudouPlaylistIE.url == url

# Generated at 2022-06-24 13:29:42.972023
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(None)._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:29:45.386823
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/eK4Dt71XdO4"
    test = TudouAlbumIE()
    assert test._real_extract(url) is not None


# Generated at 2022-06-24 13:29:55.205554
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	def run():
		from .class_InfoExtractor import InfoExtractor
		import re
		from .class_TudouAlbumIE import TudouAlbumIE
		from .class_TudouPlaylistIE import TudouPlaylistIE
		from .class_TudouIE import TudouIE

		url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
		self = InfoExtractor(url)

		self.__class__ = TudouAlbumIE
		self._real_initialize()
		self._real_extract(url)

		url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
		self = InfoExtractor(url)

		self

# Generated at 2022-06-24 13:30:05.799388
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class Alum_URL:
        def _valid_url(self):
            return self.url
        def _match_id(self):
            return self.id
        def __init__(self, id, url):
            self.id = id
            self.url = url
    test_input = Alum_URL("z_l1yjd4zpw", "http://www.tudou.com/albumplay/z_l1yjd4zpw.html")
    test_instance = TudouAlbumIE()
    assert_equal(test_instance._real_extract(test_input), "Album list extract from tudou.com")
    print("Done test.")

# Generated at 2022-06-24 13:30:12.171998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert test_object.ie_key() == 'Tudou:album'
    assert test_object.ie_name() == 'tudou:album'
    assert test_object.work(url) == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

test_object = TudouAlbumIE()
url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
test_TudouAlbumIE()

# Generated at 2022-06-24 13:30:21.890353
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoui = TudouAlbumIE()
    assert tudoui
    assert tudoui.IE_NAME == 'tudou:album'
    assert tudoui._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudoui._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudoui._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert tudoui._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-24 13:30:24.546737
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        test_playlist = TudouPlaylistIE()
        assert (test_playlist is not None)
    except:
        print("test_TudouPlaylistIE failed\n")
        

# Generated at 2022-06-24 13:30:32.679796
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Constructor of class InfoExtractor
    ie.info_extractors = []
    ie.add_info_extractor(TudouPlaylistIE)
    ie.add_info_extractor(TudouAlbumIE)
    # Constructor of class InfoExtractor
    ie.IE_DESC = ie.ie_key().replace('_', '.') + ':'
    ie.suitable = lambda url: False
    ie._WORKING = False
    ie._downloader = None
    ie._match_id = lambda url: 'zzdE77v6Mmo'
    ie.js_to_json = lambda x: x

# Generated at 2022-06-24 13:30:36.764976
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    name = 'Tudou'
    playlist_id = 'zzdE77v6Mmo'

    test_obj = TudouPlaylistIE(url, name)
    #assert test_obj.get_id() == playlist_id
    #assert test_obj.get_name() == name
    #assert test_obj.get_url() == url

# Generated at 2022-06-24 13:30:44.026017
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("~~~~ UNIT TEST: TudouPlaylistIE ~~~~")
    TudouPlaylistIE()._real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    TudouPlaylistIE()._real_extract("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    #assert(False)  # test failed
    # assert(True)  # test passed

# Generated at 2022-06-24 13:30:45.786452
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE().to_screen()


# Generated at 2022-06-24 13:30:49.986188
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == ('https?://(?:www\.)?tudou\.com/album(?:cover|play)/([\w-]{11})')
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45



# Generated at 2022-06-24 13:30:53.151972
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE("TudouAlbumIE")
    assert(obj.ie_key() == "TudouAlbumIE")

# Generated at 2022-06-24 13:31:01.777291
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    # Test case 1, test pattern match
    assert tudou_playlist_ie._VALID_URL.match('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not tudou_playlist_ie._VALID_URL.match('http://www.tudou.com/listplay/zzdE77v6.html')
    # Test case 2, test ID extraction
    assert tudou_playlist_ie._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'



# Generated at 2022-06-24 13:31:04.828311
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        x = TudouAlbumIE.TudouAlbumIE(None, None, None)
    except Exception:
        raise Exception('initialization failed')

# Generated at 2022-06-24 13:31:15.220767
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE
    # Valid URL
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Construct object
    instance = IE(url, 'tudou')
    # Test extract method
    instance.extract()
    # Valid URL
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    # Construct object
    instance = IE(url, 'tudou')
    # Test extract method
    instance.extract()
    # Test invalid URL
    url = 'http://www.tudou.com/albumplayx/v5qckFJvNJg.html'
    # Construct object
    instance = IE(url, 'tudou')
    # Test

# Generated at 2022-06-24 13:31:26.180561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .test_tudou import url_succ, url_fail
    # Test url's validation:
    url_succ(TudouAlbumIE, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    url_succ(TudouAlbumIE, 'http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    url_fail(TudouAlbumIE, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    url_fail(TudouAlbumIE, 'http://www.tudou.com/albumcover/v5qckFJvNJg/xxx.html')

# Generated at 2022-06-24 13:31:33.415218
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = TudouPlaylistIE()
    info_extractor.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert_equal(info_extractor._TESTS[0]['url'], 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    info_extractor.extract('1')

# Generated at 2022-06-24 13:31:34.896696
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(TudouPlaylistIE, url)


# Generated at 2022-06-24 13:31:43.095757
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance.valid_url == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert instance.video_id == 'zzdE77v6Mmo'
    assert instance.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'



# Generated at 2022-06-24 13:31:45.986357
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    print(tudou_playlist)


# Generated at 2022-06-24 13:31:53.621795
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'Tudou:playlist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])

# Generated at 2022-06-24 13:32:01.458783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:32:06.925175
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Test with a supported URL
    info_dict = {'id': 'zzdE77v6Mmo'}
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_extract(url)
    

# Generated at 2022-06-24 13:32:15.166463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''Unit test for constructor of class TudouPlaylistIE'''
    playlist = TudouPlaylistIE()
    assert (
        playlist.IE_NAME == 'tudou:playlist'
    ), 'Constructor with no parameter should set correct IE Name'
    assert (
        playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    ), 'Constructor with no parameter should set correct url format'


# Generated at 2022-06-24 13:32:17.734956
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:32:20.793046
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie.suitable(url)

# Generated at 2022-06-24 13:32:26.399011
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Given
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # When
    global extractor
    extractor = TudouPlaylistIE()
    # Then
    assert (extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-24 13:32:37.425905
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    IE.IE_NAME = 'tudou:playlist'
    IE.IE_DESC = '土豆网-专辑'
    IE.URL_PATTERN = 'https?://(?:www.)?tudou.com/listplay/(?P<id>[\w-]{11}).html'
    IE.TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-24 13:32:41.647070
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ex = TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE._VALID_URL, 'md5')
	#assert type(ex) is TudouAlbumIE
	

# Generated at 2022-06-24 13:32:42.292455
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()

# Generated at 2022-06-24 13:32:49.725807
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    _instance = TudouAlbumIE()
    assert hasattr(_instance, 'IE_NAME') == True
    assert hasattr(_instance, '_VALID_URL') == True
    assert hasattr(_instance, '_TESTS') == True
    assert hasattr(_instance, '_real_extract') == True
    assert hasattr(_instance, 'suitable') == True
    assert callable(_instance.suitable) == True
    assert hasattr(_instance, '_real_extract') == True
    assert callable(_instance._real_extract) == True



# Generated at 2022-06-24 13:32:51.608885
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('','')
    print(ie.TUDOU_ALBUM)

# Generated at 2022-06-24 13:32:52.885376
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE is not None


# Generated at 2022-06-24 13:32:56.346849
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' == TudouPlaylistIE._VALID_URL
    assert 'Tudou' == TudouPlaylistIE.IE_NAME


# Generated at 2022-06-24 13:32:57.710557
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()



# Generated at 2022-06-24 13:33:00.917947
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-24 13:33:02.856426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    TudouAlbumIE


# Generated at 2022-06-24 13:33:12.885671
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_data = {
        'items': [{
            'icode': '1111',
            'kw': 'a song',
        }, {
            'icode': '2222',
            'kw': 'another song',
        }]
    }
    tudou_album_ie = TudouAlbumIE()
    tudou_album_ie._download_json = lambda url, album_id: album_data
    tudou_album_ie._match_id = lambda url: 'v5qckFJvNJg'
    result = tudou_album_ie.url_result('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'Tudou')
    playlist = eval(result).get('_type')

# Generated at 2022-06-24 13:33:14.886073
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj is not None

TudouPlaylistIE = TudouPlaylistIE

# Generated at 2022-06-24 13:33:21.833474
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check that a valid playlist is extracted
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_IE = TudouPlaylistIE(valid_url)
    playlist_IE.extract()

    # Check that an invalid playlist raises an error
    invalid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_IE = TudouPlaylistIE(invalid_url)
    playlist_IE.extract()

# Generated at 2022-06-24 13:33:30.357479
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
}]


# Generated at 2022-06-24 13:33:31.749328
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()

    assert obj != None

# Generated at 2022-06-24 13:33:37.601961
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Test 'InfoExtractor' constructor
    try:
        cc = InfoExtractor(url)
    except Exception as e:
        assert FAIL_IF_UNEXPECTED(e), 'Could not instantiate an ' \
            'InfoExtractor.'
    else:
        assert PASS_IF_EXPECTED, 'Passed: InfoExtractor was created.'

    # Test 'TudouPlaylistIE' constructor
    try:
        t = TudouPlaylistIE(url)
    except Exception as e:
        assert FAIL_IF_UNEXPECTED(e), \
            'Could not instantiate a TudouPlaylistIE.'

# Generated at 2022-06-24 13:33:46.424770
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-24 13:33:50.201408
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album_ie is not None


# Generated at 2022-06-24 13:33:59.761229
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.name == 'tudou:playlist'
    assert t.IE_NAME == 'tudou:playlist'
    assert t.ie_key() == 'TudouPlaylist'
    assert t.valid_url('http://www.tudou.com/listplay/p_9-HFhPTKu8.html')
    assert t.valid_url('http://www.tudou.com/albumplay/p9HFhPTKu8.html')
    assert t.valid_url('http://www.tudou.com/albumcover/p9HFhPTKu8.html') is False
    assert t.valid_url('http://www.tudou.com/playlistplay/p9HFhPTKu8.html') is False
    assert t.valid

# Generated at 2022-06-24 13:34:06.896627
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Test the correct case
	test_case = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudou_album_ie = TudouAlbumIE()
	tudou_album_ie.suitable(test_case)
	tudou_album_ie._match_id(test_case)
	tudou_album_ie._real_extract(test_case)

# Generated at 2022-06-24 13:34:09.359598
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	IE = TudouPlaylistIE(); 

# Generated at 2022-06-24 13:34:11.752377
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except:
        assert False, "Constructor of class TudouPlaylistIE failed."


# Generated at 2022-06-24 13:34:15.278173
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()

# Generated at 2022-06-24 13:34:19.858936
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_implement = TudouAlbumIE(None)
    assert test_implement._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:21.000414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-24 13:34:23.009101
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    obj.url = 'http://www.tudou.com/albumplay/v5qckFJvNJg'

# Generated at 2022-06-24 13:34:27.341356
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:34:31.868935
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    example = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(example)
    data = ie.process_url(example)
    assert data['_type'] == 'playlist'


# Generated at 2022-06-24 13:34:32.821092
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        p=TudouAlbumIE()

# Generated at 2022-06-24 13:34:35.430403
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import sys
    sys.path.append('..')
    from ykdl.test.test_playlist import TestPlaylist
    TestPlaylist.run(TudouPlaylistIE)


# Generated at 2022-06-24 13:34:38.076631
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-24 13:34:48.331214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(0, "")
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-24 13:34:50.982444
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert album is not None

# Generated at 2022-06-24 13:35:00.102851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test the constructor of class TudouPlaylistIE
    assert TudouPlaylistIE(None)._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # test the test cases
    assert TudouPlaylistIE(None)._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-24 13:35:09.022456
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:35:10.450459
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    c = TudouAlbumIE()
    assert c is not None


# Generated at 2022-06-24 13:35:17.674879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import os
    import re
    import json
    import urlparse
    from .test_tudou import generate_test_testcase as test_generator
    from .common import parse_resolution
    from .tudou import extract_video_data, parse_video_data
    from .tudouplaylist import parse_tudou_playlist_data
    from .tudoualbum import extract_album_data, parse_album_data
    from .tudou import TudouIE

    def gen_mock_data(url):
        assert re.match(r'http://www\.tudou\.com/album(?:cover|play)/\w+', url)
        _, _, path, _, _ = urlparse.urlsplit(url)

# Generated at 2022-06-24 13:35:18.142525
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-24 13:35:21.579557
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """

# Generated at 2022-06-24 13:35:32.887831
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    import re
    from urlparse import urlparse

    url_list = [
        # url without "album"
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        # url with "album"
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    ]

    for url in url_list:
        m = re.search(TudouAlbumIE._VALID_URL, url)
        assert m, "%s is not valid" % url
        # create an instance of class TudouAlbumIE
        tudou_album_ie = TudouAlbumIE()
        # test _real_extract
        assert tudou_album_ie._real_extract(url)
        # test _match

# Generated at 2022-06-24 13:35:36.366146
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	ie.url_result("http://www.tudou.com/programs/view/Uy_EkS8W1hg","Tudou","Uy_EkS8W1hg","")

# Generated at 2022-06-24 13:35:42.909836
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """
    tests = [
        {
            'name': 'TudouPlaylistIE',
            'object': TudouPlaylistIE,
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'playlist_mincount': 209,
        }
    ]
    for test in tests:
        name = test['name']
        object = test['object']
        url = test['url']
        playlist_mincount = test['playlist_mincount']
        _TESTS.append({'url': url, 'playlist_mincount': playlist_mincount})
        playlist_ie = object()
        playlist = playlist_ie.extract(url)
        assert playlist is not None
       

# Generated at 2022-06-24 13:35:43.729083
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:35:44.816403
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-24 13:35:56.022906
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = '5U6ibmkMknY'

# Generated at 2022-06-24 13:35:58.193107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('', '')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-24 13:36:01.253072
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    from .common import main
    from .utils import url_basename
    sys.modules['__main__'].main = main
    sys.modules['__main__'].url_basename = url_basename
    sys.modules['__main__'].InfoExtractor = InfoExtractor
    sys.modules['__main__'].TudouAlbumIE = TudouAlbumIE
    __import__('__main__')

# Generated at 2022-06-24 13:36:04.460397
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = info_extractor._match_id(url)
    assert album_id is not None

# Generated at 2022-06-24 13:36:05.271356
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:36:07.686356
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-24 13:36:11.203084
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    tudou_albumIE = TudouAlbumIE()


# Generated at 2022-06-24 13:36:14.110683
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    y = TudouAlbumIE(url)
    y.extract()

# Generated at 2022-06-24 13:36:15.063420
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:36:21.588672
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from ..downloader import _downloader_classes as downloaders

    class downloader(object):
        def __init__(self, downloader_opts):
            self.downloader_opts = downloader_opts

    downloader_instance = downloader({
        'noplaylist': False
    })
    extractor_class = downloaders[0][1]
    assert extractor_class.IE_NAME == 'TudouPlaylist'
    assert extractor_class.ie_key() == 'TudouPlaylist'
    extractor_instance = extractor_class(downloader_instance)
    assert extractor_instance._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-24 13:36:24.880169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert (TudouPlaylistIE(None)._VALID_URL ==  r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
	assert (TudouPlaylistIE(None).playlist_mincount ==  209)

# Generated at 2022-06-24 13:36:28.824642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    ie.url = "http://www.tudou.com/albumplay/FiilW6U29Ck.html"
    ie.extract('http://www.tudou.com/albumplay/FiilW6U29Ck.html')

# Generated at 2022-06-24 13:36:38.101489
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DESC == '土豆 - 发现最有趣的视频'
    assert ie.VALID_URL == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-24 13:36:48.110365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	
	# Case 1:
	valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	correct_playlist_id = 'zzdE77v6Mmo'

	# Case 2:
	valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
	correct_playlist_id = 'zzdE77v6Mmo'

	playlist_ie = TudouPlaylistIE(valid_url)
	playlist_ie.playlist_id = playlist_ie._match_id(valid_url)


# Generated at 2022-06-24 13:36:50.173660
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-24 13:36:51.145659
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE()


# Generated at 2022-06-24 13:37:00.558104
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    tudou_playlist = TudouPlaylistIE(url)
    assert tudou_playlist.ie_key() == 'Tudou:playlist'
    playlist_mincount = 209
    assert tudou_playlist.test_playlist_mincount() == playlist_mincount
    assert tudou_playlist.test_url(url)
    assert tudou_playlist.test_url_result(url)
    assert tudou_playlist.test_match_id(url) == playlist_id
    assert tudou_playlist.match_id(url) == playlist_id
    assert tudou_play

# Generated at 2022-06-24 13:37:03.018105
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    res = ie.match('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert res == 'Tudou', 'The constructor of class TudouPlaylistIE is not correct!'


# Generated at 2022-06-24 13:37:08.010001
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-24 13:37:09.058815
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-24 13:37:20.114105
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Need to create a mock object for example, see Python document
    # for details about unittest.mock
    from unittest.mock import Mock
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    MockInfoExtractor = Mock(spec=InfoExtractor)
    MockMatchId = Mock(spec=InfoExtractor._match_id)
    MockMatchId.return_value = "zzdE77v6Mmo"
    MockDownloadJson = Mock(spec=InfoExtractor._download_json)
    MockDownloadJson.return_value = {}
    MockPlaylistResult = Mock(spec=InfoExtractor.playlist_result)
    MockPlaylistResult.return_value = True

    # Replace the fields with mock objects
    InfoExtractor._match_

# Generated at 2022-06-24 13:37:23.529951
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	real_extract = None
	# now passing album_data and entries manually
	album_data = {
		'items': [
			{
				'kw': 'testkw1',
				'icode': 'testicode1'
			},
			{
				'kw': 'testkw2',
				'icode': 'testicode2'
			}
		]
	}

# Generated at 2022-06-24 13:37:29.816229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-24 13:37:40.784701
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE()
    print(td.__init__)
    print(td.__doc__)
    print(td.IE_NAME)
    print(td.IE_DESC)
    # test mp4 download
    #td.download('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    # test m3u8 download
    #td.download('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    # test redirection url
    #td.download('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-24 13:37:45.779494
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert albumIE._match_id(url) == 'v5qckFJvNJg'
    assert albumIE._real_initialize() == None


# Generated at 2022-06-24 13:37:54.504348
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:37:55.983487
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE(None)


# Generated at 2022-06-24 13:37:58.678323
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()._real_extract(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-24 13:37:59.880705
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert(t is not None)

# Generated at 2022-06-24 13:38:05.692857
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    # Get a TudouPlaylistIE instance
    tudouPlaylistIE = TudouPlaylistIE()

    # Get the expected result
    expected = {
        'id': 'zzdE77v6Mmo',
    }

    # Get the actual result
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    actual = tudouPlaylistIE._real_extract(url)

    # Check the actual result with expected result
    assert_equal(actual, expected)


# Generated at 2022-06-24 13:38:17.085969
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict' : {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-24 13:38:18.124493
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()

# Generated at 2022-06-24 13:38:22.409115
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE();
    print("test TudouAlbumIE")
    print("url: " + td._VALID_URL)
    print("match id: " + td._match_id("https://www.tudou.com/albumcover/QYtsb74hM9I"))

# Generated at 2022-06-24 13:38:24.550736
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert type(TudouPlaylistIE(InfoExtractor())) == TudouPlaylistIE
    assert type(TudouAlbumIE(InfoExtractor())) == TudouAlbumIE

# Generated at 2022-06-24 13:38:34.213107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-24 13:38:39.228671
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-24 13:38:40.891542
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_TudouIE import test_TudouIE
    test_TudouIE()

# Generated at 2022-06-24 13:38:49.046360
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie.ie_key() == 'TudouAlbum'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-24 13:38:59.964759
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from constants import constants
	from extractor.common import InfoExtractor
	from extractor.tudou import TudouAlbumIE
	from extractor.tudou import TudouPlaylistIE
	from extractor.youtube import YoutubeIE
	import unittest
	import youtube_dl
	import sys

	class TestTudouAlbumIE(unittest.TestCase):
		#check if testing is executing
		def test_TudouAlbumIE(self):
			assert True

		def setUp(self):
			#override the default InfoExtractor.extract() method
			InfoExtractor.extract = lambda self, url: {'id': 'v5qckFJvNJg'}


# Generated at 2022-06-24 13:39:07.580339
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # A constructor for class TudouAlbumIE
    # @param ie: The name of the class
    # @param url: The URL to search for
    # @return: A new instance of the class
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_name() == 'Tudou'

