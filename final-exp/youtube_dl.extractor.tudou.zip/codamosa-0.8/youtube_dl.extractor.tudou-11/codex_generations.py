

# Generated at 2022-06-12 18:27:58.925000
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert(IE.IE_NAME == 'tudou:playlist')
    assert(IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-12 18:28:05.779330
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')
    assert(TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209)

# Generated at 2022-06-12 18:28:13.435053
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'tudou:playlist' in InfoExtractor._ALL_CLASSES
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}
    print('successfully passed testing for TudouPlaylistIE() constructor')


# Generated at 2022-06-12 18:28:23.207129
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME is 'tudou:playlist'
    assert ie._VALID_URL is r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TEST is {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}
    assert ie.IE_DESC is 'Tudou playlists'

# Generated at 2022-06-12 18:28:27.467354
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html') is not None
    assert TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is not None
    

# Generated at 2022-06-12 18:28:34.517540
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE_TEST = 'tudou:album'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    i = TudouAlbumIE()
    assert i.IE_NAME == IE_TEST
    assert i._VALID_URL == _VALID_URL
    assert i._TESTS == _TESTS

# Generated at 2022-06-12 18:28:41.742122
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE(url)
    assert playlist.url == url
    assert playlist.name == 'tudou:playlist'
    assert playlist.valid_url == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:28:47.841757
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbum = TudouAlbumIE()
    assert tudoualbum._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert tudoualbum._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:28:49.290421
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:28:51.660756
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou:album', 'v5qckFJvNJg')
    assert ie._match_id(ie._VALID_URL) == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:28:57.276964
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist._downloader is not None
    assert tudouplaylist._downloader.params is not None


# Generated at 2022-06-12 18:28:59.350930
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), InfoExtractor)

# Generated at 2022-06-12 18:29:09.049001
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Create an object of class TudouAlbumIE
    obj_TudouAlbumIE = TudouAlbumIE()
    # Check if the constructor of the class TudouAlbumIE is working
    assert re.match(
        r'^(https?://(?:www\.)?tudou\.com/album(?:cover|play)/(\w){11}$)',
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        ) is not None
    # Check if the constructor of the class TudouAlbumIE is working

# Generated at 2022-06-12 18:29:16.699154
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist.IE_NAME == 'tudou:playlist'
    assert tudouplaylist._VALID_URL ==  r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(tudouplaylist._TESTS) == 1


# Generated at 2022-06-12 18:29:20.351967
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor of class TudouPlaylistIE
    test_TudouPlaylistIE = TudouPlaylistIE()
    # AssertionError: ValueError not raised
    assert test_TudouPlaylistIE, 'ValueError not raised'


# Generated at 2022-06-12 18:29:25.612020
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    URL = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = {}
    playlist["id"] = "zzdE77v6Mmo"
    playlist["_type"] = "playlist"
    downloader = InfoExtractor()
    downloader.add_info_extractor(TudouPlaylistIE)
    playlist["_downloader"] = downloader
    playlist_IE = TudouPlaylistIE()
    assert playlist["id"] == playlist_IE._match_id(URL)


# Generated at 2022-06-12 18:29:31.505126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    output = tudou_playlist.real_download('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert "playlist" in output.keys()
    assert "entries" in output.keys()
    assert len(output["entries"]) == 209


# Generated at 2022-06-12 18:29:32.329917
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-12 18:29:33.323485
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:29:36.276696
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-12 18:29:43.243347
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Test constructor
	TudouAlbumIE()


# Generated at 2022-06-12 18:29:45.355635
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist is not None
    assert tudou_playlist.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:29:49.493200
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.get_url() == None


# Generated at 2022-06-12 18:29:53.258860
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE();
	assert(ie.extract('https://www.tudou.com/listplay/zzdE77v6Mmo.html')[0] == 'zzdE77v6Mmo');

# Generated at 2022-06-12 18:29:56.485367
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('Tudou', {'id': 'v5qckFJvNJg'})
    assert(tudou_album_ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html'))

# Generated at 2022-06-12 18:29:59.122374
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case
    test1 = TudouPlaylistIE()
    test2 = TudouPlaylistIE()
    print('Done!')


# Generated at 2022-06-12 18:30:04.829018
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not TudouPlaylistIE().suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html#abc')


# Generated at 2022-06-12 18:30:06.930194
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-12 18:30:17.697903
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    result = TudouPlaylistIE('TudouPlaylistIE', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(result.name == 'TudouPlaylistIE')
    assert(result.ie_key() == 'Tudou:playlist')
    assert(result.IE_NAME == 'tudou:playlist')
    assert(result._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(result._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:30:21.130941
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_dict = {
            'id': 'zzdE77v6Mmo',
        }
    assert (TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')._TESTS[0]['info_dict'] == test_dict)

# Generated at 2022-06-12 18:30:34.429075
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

# Generated at 2022-06-12 18:30:43.000748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import sys
    def redirect_stdout(to):
        sys.stdout = to
    def make_test_case(test_url):
        class TestClass(unittest.TestCase):
            def test_result(self):
                obj = TudouAlbumIE()

# Generated at 2022-06-12 18:30:45.481649
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist is not None


# Generated at 2022-06-12 18:30:50.756912
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    ie.extract()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:30:51.267639
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

# Generated at 2022-06-12 18:30:53.612276
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_playlist = TudouAlbumIE()
	tudou_playlist.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:30:58.462333
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    # Constructor of Class InfoExtractor
    ie.suitable(url)
    ie.extract(url)

# Generated at 2022-06-12 18:31:01.705404
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #TudouAlbumIE should not call _match_id, but call _match_id_from_url
    instance = TudouAlbumIE()
    assert hasattr(instance, "_match_id_from_url")

# Generated at 2022-06-12 18:31:11.318592
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = InfoExtractor('tudou:playlist', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.IE_DESC == '土豆网'
    assert ie.VALID_URL == 'http://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert ie.MOB_URL_TEMPLATE == None
    assert ie.SUFFIX == None
    assert ie.BR_DESCS == None


# Generated at 2022-06-12 18:31:15.914269
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    

# Generated at 2022-06-12 18:31:46.898035
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from  .common import Instance
    tudou_album_ie = Instance(TudouAlbumIE)
    assert tudou_album_ie.name() == 'tudou:album'
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie.valid_url('http://www.tudou.com/albumcover/F76pBbzY1K8.html')

# Generated at 2022-06-12 18:31:47.445640
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert True

# Generated at 2022-06-12 18:31:49.529689
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ins = TudouAlbumIE()
    assert ins.IE_NAME

# Generated at 2022-06-12 18:31:51.542364
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.ie_key() == 'Tudou:playlist'



# Generated at 2022-06-12 18:31:52.366582
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:31:53.719029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE();

# Generated at 2022-06-12 18:31:58.057171
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    ie = TudouPlaylistIE()
    expected = 'tudou'
    actual = ie._VALID_URL.split('http://www.')[1].split('.')[0]
    assert actual == expected
    print ('Constructor of TudouPlaylistIE class -- Passed')


# Generated at 2022-06-12 18:32:00.324212
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:32:05.193313
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:32:10.070583
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumurl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:33:10.739268
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:33:11.850210
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-12 18:33:19.483384
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'eB93l8xwprw'
    url = 'http://www.tudou.com/albumcover/%s/' % album_id

# Generated at 2022-06-12 18:33:25.605290
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert TudouAlbumIE()._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg"
    assert TudouAlbumIE()._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-12 18:33:35.613164
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import os
	os.chdir('../..')
	obj = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert obj._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
	'info_dict': {'id': 'v5qckFJvNJg'},
	'playlist_mincount': 45}]

# Generated at 2022-06-12 18:33:42.813432
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-12 18:33:43.579136
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('url') != None

# Generated at 2022-06-12 18:33:48.769295
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]



# Generated at 2022-06-12 18:33:57.298174
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    if not hasattr(TudouPlaylistIE, '_download_json'):
        from .test_tudou import download_json
        TudouPlaylistIE._download_json = download_json
    if not hasattr(TudouPlaylistIE, '_real_extract'):
        from .test_tudou import real_extract
        TudouPlaylistIE._real_extract = real_extract

    assert(type(TudouPlaylistIE).__name__ == 'type')
    assert(TudouPlaylistIE.__doc__ == 'TudouPlaylistIE(data)')
    assert(type(TudouPlaylistIE._VALID_URL).__name__ == '_sre.SRE_Pattern')
    assert(len(TudouPlaylistIE._TESTS) == 1)

# Generated at 2022-06-12 18:34:00.422689
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._download_json is not None
    assert ie.ie_key() is 'Tudou'
    assert ie._VALID_URL is not None



# Generated at 2022-06-12 18:36:24.976854
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  my_TudouPlaylistIE = TudouPlaylistIE()
  assert isinstance(my_TudouPlaylistIE, InfoExtractor)
  assert my_TudouPlaylistIE.IE_NAME == 'tudou:playlist'
  assert my_TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
  assert my_TudouPlaylistIE._TESTS[0].get('url') == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
  assert my_TudouPlaylistIE._TESTS[0].get('info_dict') == {'id': 'zzdE77v6Mmo',}

# Generated at 2022-06-12 18:36:27.549879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test an invalid URL:
    from unittest import TestCase

    class TestTudouAlbumIE(TestCase):
        def test_invalid_url(self):
            invalid_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg/index.html'
            assert TudouAlbumIE._VALID_URL == invalid_url

# Generated at 2022-06-12 18:36:37.660624
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE.TudouAlbumIE = TudouAlbumIE
    assert hasattr(TudouAlbumIE, '_VALID_URL')
    assert hasattr(TudouAlbumIE, '_TEST')
    assert hasattr(TudouAlbumIE, '_real_extract')
    assert hasattr(TudouAlbumIE, 'playlist_result')
    assert hasattr(TudouAlbumIE, 'url_result')
    assert hasattr(TudouAlbumIE, '_match_id')
    assert hasattr(TudouAlbumIE, '_download_json')
    print("All test for constructor of class TudouAlbumIE passed\n")
# Test for constructor of class TudouAlbumIE
test_TudouAlbumIE()

# Generated at 2022-06-12 18:36:40.706591
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('Tudou', 'v5qckFJvNJg') == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-12 18:36:43.335908
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i.IE_NAME == 'tudou:playlist'
    assert i._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-12 18:36:46.780249
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistie1 = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouplaylistie2 = TudouPlaylistIE(url)
    tudouplaylistie3 = TudouPlaylistIE({
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    })


# Generated at 2022-06-12 18:36:54.628873
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudouAlbumIE._TESTS) == 1
    assert tudouAlbumIE._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

# Generated at 2022-06-12 18:36:56.739159
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE(url)
    ie._real_extract(url)

# Generated at 2022-06-12 18:36:57.189229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-12 18:36:58.542737
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
