

# Generated at 2022-06-12 18:27:56.237151
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    return True


# Generated at 2022-06-12 18:27:59.092886
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE is not None


# Generated at 2022-06-12 18:28:01.983116
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:28:06.280667
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE(None)

# Generated at 2022-06-12 18:28:13.154326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id

    entries = []
    for item in album_data['items']:
        entries.append(self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']))

    playlist_result(entries, album_id)

# Generated at 2022-06-12 18:28:16.367797
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('Run Unit test for constructor of class TudouAlbumIE')
    TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-12 18:28:21.917757
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:28:26.846043
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	dict = {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}
	a = TudouAlbumIE()
	assert a.IE_NAME == 'tudou:album'
	assert a._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:28:29.538391
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = u"http://www.tudou.com/albumcover/v5qckFJvNJg.html"
	TudouAlbumIE()._real_extract(url)

# Generated at 2022-06-12 18:28:30.170919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()

# Generated at 2022-06-12 18:28:40.996485
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    tudou.com playlist URL test
    """
    tudouPlaylistIE = TudouPlaylistIE('tudou:playlist', 'tudou.com')
    actual_instance_of_class = isinstance(tudouPlaylistIE, InfoExtractor)
    assert actual_instance_of_class == True


# Generated at 2022-06-12 18:28:43.976391
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    t.to_screen(t.IE_NAME)
    t.to_screen(t._VALID_URL)
    t.to_screen(t._TESTS)


# Generated at 2022-06-12 18:28:46.068346
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == TudouAlbumIE._VALID_URL
    assert "tudou.com/album" in TudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:28:46.678097
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(True)

# Generated at 2022-06-12 18:28:47.710082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:28:48.588864
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(InfoExtractor())

# Generated at 2022-06-12 18:28:50.449337
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE(None)
    assert albumIE

# Generated at 2022-06-12 18:28:52.996530
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    expect = "tudou:playlist:"
    actual = ie._VALID_URL[:-7]
    assert expect == actual


# Generated at 2022-06-12 18:28:56.465895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    assert tudouAlbum._match_id("http://www.tudou.com/albumcover/v5qckFJvNJg.html") == "v5qckFJvNJg"
    assert tudouAlbum._match_id("http://www.tudou.com/albumcover/v5qckFJvNJg") == "v5qckFJvNJg"


# Generated at 2022-06-12 18:29:00.971521
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'lq3Bjn8mVCg'
    assert TudouAlbumIE._TESTS[0].get('url') == \
        'http://www.tudou.com/albumplay/%s.html' % album_id

# Generated at 2022-06-12 18:29:14.238396
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    ie.IE_DESC = '土豆专辑'
    ie.IE_NAME = 'tudou:album'
    ie._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    ie._TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:29:23.558532
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import parse_age_limit

    # Constructor test
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie.name == 'tudou:playlist')
    assert(ie.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie.host == 'www.tudou.com')
    assert(ie.id == 'zzdE77v6Mmo')
    assert(ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-12 18:29:28.426411
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_initialize()
    assert TudouPlaylistIE()._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    # Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:29:30.490004
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

# Generated at 2022-06-12 18:29:37.607306
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])


# Generated at 2022-06-12 18:29:39.928115
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_raises(TypeError, TudouAlbumIE, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'passwd')

# Generated at 2022-06-12 18:29:41.099091
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(), InfoExtractor)

# Generated at 2022-06-12 18:29:46.621538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
   # Test with a legal url:
   url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
   assert TudouPlaylistIE._VALID_URL(url)

   # Test with a bad url:
   url = "http://www.tudou.com/listplay/zzdE77v6Mmo"
   assert not TudouPlaylistIE._VALID_URL(url)


# Generated at 2022-06-12 18:29:57.194422
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    playlist_mincount = 45
    album_data = {
        'success': True,
        'items': [{
            'icode': 'aD15ZGM0pFI',
            'kw': '汉堡包',
            'cd': '第01集',
            'br': '30',
            'list': '',
        }]
    }

# Generated at 2022-06-12 18:30:01.372447
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    return ie._real_initialize()

# Generated at 2022-06-12 18:30:22.226047
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test the method __init__ of class TudouAlbumIE
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }
    ]

# Generated at 2022-06-12 18:30:34.279714
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	vars = {}
	vars['url'] = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	vars['ie_key'] = 'Tudou'
	vars['video_id'] = 'v5qckFJvNJg'
	vars['_screen_id'] = 'v5qckFJvNJg'
	vars['_downloader'] = 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
	# print(vars)
	TudouAlbumIE(vars['url'], vars['ie_key'], vars['video_id'], vars['_downloader'])
	return vars

# Generated at 2022-06-12 18:30:37.003097
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    check_constructor(TudouAlbumIE, url)


# Generated at 2022-06-12 18:30:41.746135
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.ie_key() == "TudouAlbum"
    assert ie.ie_name == "tudou:album"
    assert ie.ie_type == "playlist"
    assert ie.url_re == ie._VALID_URL


# Generated at 2022-06-12 18:30:48.277833
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('zzdE77v6Mmo')._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE('zzdE77v6Mmo').IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:30:51.041917
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create object
    tudou_playlist_ie = TudouPlaylistIE()
    # Test the constructor
    assert isinstance(tudou_playlist_ie, InfoExtractor)


# Generated at 2022-06-12 18:30:52.511507
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        t = TudouAlbumIE()
        return True
    except:
        return False

# Generated at 2022-06-12 18:30:54.136505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.TudouPlaylistIE == "TudouPlaylistIE"


# Generated at 2022-06-12 18:31:04.010051
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor = TudouPlaylistIE()
    instance = constructor._real_extract(constructor._TESTS[0]['url'])
    assert instance['_type'] == 'playlist'
    assert instance['id'] == constructor._TESTS[0]['info_dict']['id']
    assert instance['entries'][0] == constructor.url_result('http://www.tudou.com/programs/view/kpP6f9U6oLI', 'Tudou', 'kpP6f9U6oLI', u'\u771f\u5b9e\u6545\u4e8b\u5973\u5b50\u5e72\u7684\u8eab\u4f53\u533b\u751f')

# Generated at 2022-06-12 18:31:06.574218
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE("zzdE77v6Mmo.html")


# Generated at 2022-06-12 18:31:42.847433
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance.IE_NAME == 'tudou:album'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(instance._TESTS) == 1
    assert instance._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-12 18:31:49.151412
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = TudouAlbumIE._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [TudouAlbumIE.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]

# Generated at 2022-06-12 18:31:52.260070
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    c = TudouAlbumIE()
    assert c._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:32:00.841359
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.IE_NAME == 'Tudou'
    assert tudou_playlist.IE_DESC == '土豆网'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert tudou_playlist

# Generated at 2022-06-12 18:32:11.163798
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('test')
    ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'v5qckFJvNJg')
    ie._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % 'v5qckFJvNJg' , 'v5qckFJvNJg')
    ie.url_result('http://www.tudou.com/programs/view/%s' % item['icode'], 'Tudou', item['icode'],item['kw'])
    ie.playlist_result(entries, 'v5qckFJvNJg')

# Generated at 2022-06-12 18:32:18.510883
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Invalid URL
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert not TudouAlbumIE._VALID_URL(
        'http://www.tudou.com/albumplay/1234567890_123456.html')
    assert not TudouAlbumIE._VALID_URL('http://www.tudou.com/albumcover/1234567890_123456')
    assert not TudouAlbumIE._VALID_URL('http://www.tudou.com/albumcover/12345678901')
    assert not TudouAlbumIE._VALID_URL('http://www.tudou.com/albumcover/1234567890')

# Generated at 2022-06-12 18:32:27.122399
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ' The unit test for constructor of class TudouAlbumIE '
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}]
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:32:32.906704
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Imports
    import sys
    
    # Debug

# Generated at 2022-06-12 18:32:40.702852
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import sys
    import os
    import pdb
    from .common import *
    from .TudouPlaylistIE import *

    class TestTudouAlbumIE(unittest.TestCase):
        def test_constructor(self):
            #pdb.set_trace()
            print('Testing constructor of class TudouAlbumIE')
            t = TudouAlbumIE()
            self.assertTrue(t.IE_NAME == 'tudou:album')
            self.assertTrue(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
            self.assertTrue(len(TudouAlbumIE._TESTS) == 1)

# Generated at 2022-06-12 18:32:45.267183
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tp = TudouPlaylistIE()
    tp.url = url
    assert(tp.extract() != None)
    assert(tp.playlist_id == "zzdE77v6Mmo")
    assert(tp.id == "zzdE77v6Mmo")


# Generated at 2022-06-12 18:33:59.811074
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for constructor
    assert TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE._TESTS
    

# Generated at 2022-06-12 18:34:05.841652
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest
	class TestTudouAlbumIE(unittest.TestCase):
		def setUp(self):
			self._ie = TudouAlbumIE()
			self._url = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
		def test_match(self):
			self.assertTrue(self._ie.suitable(self._url))
		def test_extract(self):
			self.assertEqual(self._ie.extract(self._url).get('id'),'v5qckFJvNJg')
	suite = unittest.TestLoader().loadTestsFromTestCase(TestTudouAlbumIE)

# Generated at 2022-06-12 18:34:16.611146
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """You can run this unit test by the following command:
    
        python -m youtube_dl.extractor.tudou test_TudouPlaylistIE
        
    Note that it is not necessary to provide the whole URL.
    """
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.test()
    return ie

if __name__=="__main__":
    ie_test = test_TudouPlaylistIE()
    print(ie_test._VALID_URL)
    assert ie_test.IE_NAME == "tudou:playlist"

# Generated at 2022-06-12 18:34:24.854635
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:34:26.897518
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Positive test case
    consturctor_obj = TudouAlbumIE()
    assert consturctor_obj
    # Negative test case
    consturctor_obj = TudouAlbumIE('tudou.com/albumcover/jshdfus77vgdf.html')
    assert consturctor_obj is None


# Generated at 2022-06-12 18:34:31.113783
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist.IE_NAME == 'tudou:playlist' and playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:34:33.964622
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._valid_url(url, tudou_album_ie.IE_NAME)

# Generated at 2022-06-12 18:34:38.978159
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    from .tudou import _VALID_URL
    from .tudou import _TESTS
    from .extractor import _API_KEY

    assert _VALID_URL
    assert _TESTS
    assert _API_KEY
    assert TudouPlaylistIE

# Generated at 2022-06-12 18:34:40.363193
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t =  TudouAlbumIE()
    print (t)
    return 0


# Generated at 2022-06-12 18:34:43.528245
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    assert i.IE_NAME == "tudou:album"
    assert i._VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"

# Generated at 2022-06-12 18:37:26.320029
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import unittest
	case = unittest.TestCase()
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	
	tudou_playlist = TudouPlaylistIE()
	results = tudou_playlist.extract(url)
	
	case.assertEqual(results['id'], 'zzdE77v6Mmo')
	case.assertEqual(results['entries'][0]['title'], u'韩剧太阳的后裔 第14集 韩国最大的青春偶像剧')
	

# Generated at 2022-06-12 18:37:27.713905
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS



# Generated at 2022-06-12 18:37:31.031090
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Test TudouAlbumIE.
    '''
    ie = TudouAlbumIE()
    if ie:
        print("test okay.")

# Execute test if run as file
if __name__ == "__main__":
    test_TudouAlbumIE()

# Generated at 2022-06-12 18:37:39.465802
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_obj = TudouAlbumIE()
	assert test_obj.name == 'tudou:album'
	assert test_obj.IE_NAME == 'tudou:album'
	assert test_obj.IE_DESC == 'Youku and Tudou'
	assert test_obj.ie_key() == 'Tudou'
	assert test_obj.working == True
	assert test_obj.filename_fmt == '%s.flv'
	assert test_obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert test_obj.ie_key() == 'Tudou'
	assert test_obj.ie == 'Tudou'
	assert test_obj.th

# Generated at 2022-06-12 18:37:40.110846
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print (TudouAlbumIE())

# Generated at 2022-06-12 18:37:41.410729
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert str(IE) == "Tudou Playlist"

# Generated at 2022-06-12 18:37:43.621855
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        album_ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-12 18:37:50.496436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import get_testcases
    from .tudou import TudouAlbumIE
    urls = []
    urls.append("http://www.tudou.com/albumplay/3-kA6U5f6_A.html")
    urls.append("http://www.tudou.com/albumcover/ILvZJTXlkzE.html")
    for url in urls:
        tudou_album_ie = TudouAlbumIE()
        assert tudou_album_ie.suitable(url)
        assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-12 18:37:56.095118
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test__html_search_regex
    TudouPlaylistIE._html_search_regex(
        r'<h1>(.*?)</h1>', '<h1>test_html_search</h1>', 'h1')

    # test_info_dict
    TudouPlaylistIE._download_webpage(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'zzdE77v6Mmo')['info_dict']

    # test_playlist_mincount
    TudouPlaylistIE._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')