

# Generated at 2022-06-12 18:27:55.621586
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    reload(sys)
    sys.setdefaultencoding("UTF-8")
    TudouAlbumIE()

test_TudouAlbumIE()


# Generated at 2022-06-12 18:27:57.340148
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = TudouPlaylistIE()
    assert infoExtractor


# Generated at 2022-06-12 18:28:04.521919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    i = TudouAlbumIE

# Generated at 2022-06-12 18:28:05.525267
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()



# Generated at 2022-06-12 18:28:06.086064
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-12 18:28:06.952694
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()

# Generated at 2022-06-12 18:28:11.311905
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()

    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.info_dict == {'id': 'v5qckFJvNJg',}
    assert tudou_album_ie.playlist_mincount == 45


# Generated at 2022-06-12 18:28:13.819527
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com')
    assert ie.IE_NAME == TudouAlbumIE.IE_NAME

# Generated at 2022-06-12 18:28:19.783457
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    td = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert td._match_id(url) == 'zzdE77v6Mmo'
    assert td._match_id(url+'#') is None
    assert td._match_id(url+'a') is None
    assert td._match_id('http://www.tudou.com/listplay/') is None    
    

# Generated at 2022-06-12 18:28:22.939418
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:28:27.423915
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE()


# Generated at 2022-06-12 18:28:28.374146
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:28:31.193441
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-12 18:28:42.624563
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = '''
        {
            "totalResults": 45,
            "items": [{
                "tid": 0,
                "icode": "XOTQ2Mjk2MzIw",
                "kw": "2014年林书豪Nike背心杯全部比赛视频（更新）",
                "spic": "http://g4.tdimg.com/0/32/224/766/p.jpg",
                "pic": "http://g4.tdimg.com/0/32/224/766/1.jpg",
                "items": []
            }]
        }
    '''

# Generated at 2022-06-12 18:28:48.350225
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_albumie = TudouAlbumIE()
    result = tudou_albumie.extract(url)
    assert len(result['entries']) > 0
    assert result['id'] == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:28:54.943833
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    video_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    assert len(playlist_data['items']) == 209

# Generated at 2022-06-12 18:28:59.760672
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

    try:
        tudou_playlist_ie = TudouPlaylistIE(url)
        assert tudou_playlist_ie is not None
    except Exception:
        assert False

# Generated at 2022-06-12 18:29:02.337566
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert _real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-12 18:29:03.216610
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("")

# Generated at 2022-06-12 18:29:09.157161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-12 18:29:17.560945
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album


# Generated at 2022-06-12 18:29:20.130756
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE("")
    assert isinstance(tudou_playlist, TudouPlaylistIE)


# Generated at 2022-06-12 18:29:22.345134
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-12 18:29:27.721372
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    # this function is called in init of class
    ie = TudouAlbumIE(url)
    assert ie.ie_key() == 'TudouAlbum'
    assert ie.ie_name() == 'Tudou:album'
    assert ie.ie_downloader()

# Generated at 2022-06-12 18:29:33.168647
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 1. Test init
    instance = TudouAlbumIE()
    assert instance is not None
    # 2. Test match
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    m = instance._match_id(url)
    assert m == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:29:40.437246
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Hello, world")
    print("I am unit test for class TudouPlaylistIE")
    # Test for an invalid URL
    invalid_url = "http://www.tudou.com/listplay"
    ie = TudouPlaylistIE()
    playlist_id = ie._match_id(invalid_url)
    assert(playlist_id == None)
    # Test for a valid URL
    valid_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_id = ie._match_id(valid_url)
    assert(playlist_id == "zzdE77v6Mmo")

# Generated at 2022-06-12 18:29:47.898790
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_TEST = 'tudou:playlist'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id
    assert IE_TEST.lower() == TudouPlaylistIE._TESTS[0]['url']
    assert playlist_id == TudouPlaylistIE._VALID_URL
    assert playlist_url == TudouPlaylistIE._TESTS[0]['url']
    assert playlist_data == TudouPlaylistIE._download_json


# Generated at 2022-06-12 18:29:49.481751
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()



# Generated at 2022-06-12 18:29:51.529084
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE(None, None)

    # Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:29:55.334704
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # Test without extracting information
    TudouAlbumIE().suitable(test_url)
    # Test with extracting information
    TudouAlbumIE().extract(test_url)

# Generated at 2022-06-12 18:30:08.581914
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-12 18:30:11.230904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), InfoExtractor)


# Generated at 2022-06-12 18:30:16.516856
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)

    assert ie.url == url
    assert ie.id == 'v5qckFJvNJg'
    assert ie.name == 'tudou:album'
    assert ie.params == {'skip_download': True}

# Generated at 2022-06-12 18:30:22.614842
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:30:24.127075
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        tudouPlaylistIE = TudouPlaylistIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 18:30:25.171699
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-12 18:30:26.921378
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:30:31.775430
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_tup = ('https://www.tudou.com/listplay/zzdE77v6Mmo.html', 'zzdE77v6Mmo')
    test_ins = TudouPlaylistIE()
    assert test_tup == test_ins._match_id_str(test_tup[0])


# Generated at 2022-06-12 18:30:34.243113
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'Tudou')
    assert ie.IE_NAME == 'Tudou'


# Generated at 2022-06-12 18:30:35.023757
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:31:01.048520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:31:05.107488
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test 1
    test_url = "http://www.tudou.com/albumcover/pHEYnofrF1Y.html"
    expect_url = "http://www.tudou.com/albumplay/pHEYnofrF1Y.html"
    expect_id = "pHEYnofrF1Y"

    assert_equal(TudouAlbumIE._match_id(test_url), expect_id)
    assert_equal(TudouAlbumIE._search_mobj(test_url).group('url'), expect_url)

# Generated at 2022-06-12 18:31:13.236959
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	"""Test constructor of class TudouPlaylistIE"""
	# Arrangement
	expected_ie_name = 'tudou:playlist'
	expected_valid_url = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	expected_tests = [{
		'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
		'info_dict': {
			'id': 'zzdE77v6Mmo',
		},
		'playlist_mincount': 209,
	}]
	
	# Action
	TudouPlaylistIE_object = TudouPlaylistIE()
	
	# Assertion
	assert expected_ie

# Generated at 2022-06-12 18:31:18.080168
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Unit test for TudouAlbumIE")
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_result = 'v5qckFJvNJg'
    result = TudouAlbumIE._match_id(pat = TudouAlbumIE._VALID_URL, url = url)
    print(result)
    if (result == expected_result):
        print("Test passed:)")
    else:
        print("Test failed!")

# Generated at 2022-06-12 18:31:21.742115
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import TudouAlbumIE
    tudou_album_ie = TudouAlbumIE._real_extract(TudouAlbumIE,
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html');

# Generated at 2022-06-12 18:31:23.308206
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:31:33.002222
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    
    # TudouAlbumIE.test()
    TudouAlbumIE().test()

    # TudouAlbumIE._download_webpage()
    tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-12 18:31:38.500108
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/aUanJ5I6HcU.html'
    TD = TudouPlaylistIE
    e = TD(url)
    assert e.url == url
    assert e.playlist_id == 'aUanJ5I6HcU'

# Generated at 2022-06-12 18:31:39.579050
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('1')

# Generated at 2022-06-12 18:31:42.052253
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import BaseTest
    BaseTest.test_video_constructor(TudouAlbumIE)


# Generated at 2022-06-12 18:32:34.680587
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:32:35.962476
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()


# Generated at 2022-06-12 18:32:45.167902
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudoualbum = TudouAlbumIE()

# Generated at 2022-06-12 18:32:50.379216
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert (tudou_album_ie.IE_NAME == 'tudou:album')
    assert (tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert (tudou_album_ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }])


# Generated at 2022-06-12 18:32:55.261165
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    result = ie.extract(url)
    print("extracted")
    print(result)
    assert len(result['entries']) > 0

# Generated at 2022-06-12 18:32:58.285765
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	playlist_mincount = '45'
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	TudouAlbumIE()._TESTS[0]['url'] == url
	TudouAlbumIE()._TESTS[0]['playlist_mincount'] == playlist_mincount

# Generated at 2022-06-12 18:32:59.345358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE._VALID_URL)

# Generated at 2022-06-12 18:33:08.598770
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    IE_NAME = 'tudou:playlist'
    # Assert valid Urls
    VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._VALID_URL == VALID_URL
    # Assert valid tests
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:33:15.248818
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_NAME = 'tudou:playlist'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    _TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]



# Generated at 2022-06-12 18:33:18.215001
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Unit test for constructor of class TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(url)
    assert tudou_playlist_ie


# Generated at 2022-06-12 18:35:42.566974
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    args = (url, )
    obj = TudouAlbumIE(*args)
    x = obj._extract_matched_id()
    assert x == album_id

# Generated at 2022-06-12 18:35:50.775603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # test url and id
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert ie._match_id(url) == "zzdE77v6Mmo"
    assert ie._match_id(ie._VALID_URL) == "zzdE77v6Mmo"
    assert ie._match_id("http://www.tudou.com/listplay/eeE77v6Mmo.html") is None
    assert ie._match_id("http://www.tudou.com/listplay/.html") is None
    # test _real_extract function (only basic test)

# Generated at 2022-06-12 18:35:52.506303
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_playlists import PlaylistsTestCase
    PlaylistsTestCase(TudouPlaylistIE).run_test('tudou:album', 'TudouAlbumIE')

# Generated at 2022-06-12 18:35:55.996568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = (TudouPlaylistIE(None, None, None, None, None))
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:36:01.978568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE._VALID_URL,
                         TudouPlaylistIE._TESTS[0]['url'])
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'Tudou:playlist'
    assert ie.ie_name() == 'Tudou'
    pattern = r'^https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html$'
    assert ie.valid_url(TudouPlaylistIE._VALID_URL)
    assert ie.valid_url('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:36:04.059812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	TudouAlbumIE()

# Generated at 2022-06-12 18:36:04.654359
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:36:09.945436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_file = 'tudou.js'
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    for test_class in [TudouAlbumIE, TudouPlaylistIE]:
        tudou_test_object = test_class(test_class._VALID_URL)
        tudou_test_object.extract(test_url)

# Generated at 2022-06-12 18:36:17.887939
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .common import InfoExtractor
	from .tudou import TudouIE
	# test a real url
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' # url of playlist
	file = 'v5qckFJvNJg.html' # the file name to be written page code of url
	i = TudouAlbumIE(InfoExtractor)
	i._write_page_code(url, file)
	assert os.path.isfile('.\\' + file) == True
	os.remove(file)

# Generated at 2022-06-12 18:36:19.101959
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('Tudou')
