

# Generated at 2022-06-12 18:27:59.634237
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.extract() == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
    'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}

# Generated at 2022-06-12 18:28:02.205796
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:28:03.010165
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-12 18:28:12.076358
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id

# Generated at 2022-06-12 18:28:21.765771
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tdpl = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tdpl.suitable(url), 'Test if the url is suitable for this extractor.'
    assert tdpl._match_id(url) == 'zzdE77v6Mmo', 'Test if we can get playlist id from url.'
    assert tdpl._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', 'Test valid url is set correctly.'
    assert tdpl.IE_NAME == 'tudou:playlist', 'Test extractor name is set correctly.'
    

# Generated at 2022-06-12 18:28:30.822499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE(url)
    assert ie.url == url
    assert ie.name == "tudou:playlist"
    assert ie.match_id == "zzdE77v6Mmo"
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert ie._TESTS[0]['info_dict']['id'] == "zzdE77v6Mmo"
    assert ie.ie_key() == "TudouPlaylistIE"

# Generated at 2022-06-12 18:28:34.983282
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert tudou_album_ie is not None

# Generated at 2022-06-12 18:28:37.620928
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE(None)
    assert isinstance(tudou_album, InfoExtractor)


# Generated at 2022-06-12 18:28:39.411618
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_test = TudouPlaylistIE()
    assert tudou_test is not None


# Generated at 2022-06-12 18:28:41.550733
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE()
    assert tudou.name == "tudou:playlist"


# Generated at 2022-06-12 18:28:54.590063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('None')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) > 0
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:28:56.068643
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tdplist = TudouPlaylistIE()
    assert tdplist != None


# Generated at 2022-06-12 18:28:57.129887
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #TudouPlaylistIE()
    return

# Generated at 2022-06-12 18:29:07.216822
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Produce the unit test for constructor of class TudouPlaylistIE
    #
    # Raises:
    #     AssertionError if the test fails
    #
    #
    # Returns:
    #     None
    
    
    tudou_playlist_info_extractor =  TudouPlaylistIE()

    assert tudou_playlist_info_extractor.ie_key() == 'Tudou:playlist'
    assert tudou_playlist_info_extractor.IE_NAME == 'tudou:playlist' 
    assert tudou_playlist_info_extractor.ie_id() == 'tudou:playlist' 

# Generated at 2022-06-12 18:29:14.388953
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS ==  [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-12 18:29:18.124781
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except:
        assert False, 'test_TudouAlbumIE() FAILED'
    else:
        assert True, 'test_TudouAlbumIE() PASSED'



# Generated at 2022-06-12 18:29:20.388404
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """
    TudouPlaylistIE(None, None)



# Generated at 2022-06-12 18:29:26.846577
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_json = """
    {
        "lcode": "zzdE77v6Mmo",
        "items": [{
            "icode": "QwNgVT_6moQ",
            "kw": "吃饭不要睡觉",
            "fid": "QwNgVT_6moQ"
        }, {
            "icode": "8-sG6cOmh0s",
            "kw": "喝酒大概也别睡觉",
            "fid": "8-sG6cOmh0s"
        }]
    }"""
    playlist = TudouPlaylistIE()
    # First test
    playlist._download_json = lambda *args, **kwargs: test_json


# Generated at 2022-06-12 18:29:35.168948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    # Unit test part
    assert tudou_album_ie.ie_key() == "TudouAlbum"
    assert tudou_album_ie.ie_name() == "tudou:album"
    assert tudou_album_ie.suitable("http://www.tudou.com/albumcover/v5qckFJvNJg_12.html")
    assert not tudou_album_ie.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-12 18:29:37.327253
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert "tudou.com/listplay/zzdE77v6Mmo.html" == TudouPlaylistIE()._VALID_URL


# Generated at 2022-06-12 18:29:45.940992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou = TudouPlaylistIE()
	tudou._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')



# Generated at 2022-06-12 18:29:53.006103
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Test correct input
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # Test invalid input
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mm.html')

# Generated at 2022-06-12 18:29:58.169472
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert(tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert(tudou_album_ie._TESTS[0]['playlist_mincount'] == 45)


# Generated at 2022-06-12 18:30:01.435184
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('tudou-playlist')
    print(tudou_playlist)


# Generated at 2022-06-12 18:30:08.793130
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = None
    entries = None

    album_data = '{}'

    tudouAlbumIE = TudouAlbumIE()
    if album_data != None:
        tudouAlbumIE._download_json = lambda url, album_id: album_data
    entries = tudouAlbumIE._real_extract(url)

# Generated at 2022-06-12 18:30:15.081050
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """
    TudouPlaylistIE("https://www.tudou.com/listplay/-A3VqZJjz5Y.html")
    TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")



# Generated at 2022-06-12 18:30:18.020580
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:30:24.461003
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert str(TudouPlaylistIE) == 'tudou:playlist'
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
        }]


# Generated at 2022-06-12 18:30:32.580601
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg') == \
        'v5qckFJvNJg'
    assert tudou_album_ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == \
        'v5qckFJvNJg'


# Generated at 2022-06-12 18:30:39.538145
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    y = TudouAlbumIE(
        url='http://www.tudou.com/albumcover/v5qckFJvNJg.html', 
        ie_key=None, 
        video_id=None, 
        note=None, 
        downloader=None
    )
    assert y.url == 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert "TudouAlbumIE" in repr(y)
    assert "TudouAlbumIE" in str(y)

# Generated at 2022-06-12 18:30:56.232383
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    i = TudouAlbumIE(url)
    assert i.getUrl() == url
    assert i.getExtractorName() == 'Tudou:album'
    assert i.getID() == 'v5qckFJvNJg'
    assert i.getPlaylistMinCount() == 45

# Generated at 2022-06-12 18:31:00.221436
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)

# Generated at 2022-06-12 18:31:05.800463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test for private method _real_extract
    playlist = TudouPlaylistIE()
    
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected_playlist_id = 'zzdE77v6Mmo'
    
    # test for private method _match_id
    assert playlist._match_id(url) == expected_playlist_id
    
    # test for private method _download_json
    # if input url is vaild, then _download_json will return download result
    assert 'items' in playlist._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist._match_id(url), playlist._match_id(url))
    

# Generated at 2022-06-12 18:31:08.191960
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	myinfor = InfoExtractor()

# Generated at 2022-06-12 18:31:16.630096
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE(InfoExtractor(downloader=None))
    # Test if test result is correct
    assert tudouAlbumIE._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    # Test if url is valid
    url = tudouAlbumIE._TESTS[0]['url']
    assert tudouAlbumIE._VALID_URL.match(url) is not None
    assert tudouAlbumIE._VALID_URL.match(url).group(1) is not None


# Generated at 2022-06-12 18:31:17.561063
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.ie_key())

# Generated at 2022-06-12 18:31:24.726355
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    video_id = 'v5qckFJvNJg'
    tudou_playlist_IE = TudouPlaylistIE()
    assert tudou_playlist_IE.ie_key() == 'Tudou:playlist'
    assert tudou_playlist_IE.extract_id(tudou_url) == video_id
    # assert tudou_playlist_IE._real_extract(tudou_url)['_type'] == 'playlist'

# Generated at 2022-06-12 18:31:25.134854
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-12 18:31:35.094375
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case: playlist with complete information
    url_good_1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_info_1 = TudouPlaylistIE(url_good_1)
    assert playlist_info_1.url == url_good_1
    assert playlist_info_1.playlist_id == 'zzdE77v6Mmo'
    # Test case: playlist with less information
    url_good_2 = 'http://www.tudou.com/listplay/a6U0o8WpHdU.html'
    playlist_info_2 = TudouPlaylistIE(url_good_2)
    assert playlist_info_2.url == url_good_2

# Generated at 2022-06-12 18:31:38.224911
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    print('pass test_TudouPlaylistIE')


# Generated at 2022-06-12 18:32:09.057505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_ie = TudouAlbumIE()
    assert album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:32:12.106693
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert(ie.url == url)


# Generated at 2022-06-12 18:32:18.459356
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # id and playlist_mincount are same as in the test dict
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._match_id(ie.ie_key()) == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['info_dict']['id'] == ie._match_id(ie.ie_key())
    assert ie._TESTS[0]['playlist_mincount'] == len(ie._real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")['entries'])


# Generated at 2022-06-12 18:32:26.395736
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-12 18:32:36.891541
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-12 18:32:41.011574
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie._match_id(url)
    assert ie._VALID_URL


# Generated at 2022-06-12 18:32:43.660328
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_extractor = InfoExtractor(None)
    assert (info_extractor.get_info_extractor(TudouPlaylistIE.IE_NAME) == None)


# Generated at 2022-06-12 18:32:46.528020
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    result = ie._real_extract(url)
    assert result['id'] == 'zzdE77v6Mmo';


# Generated at 2022-06-12 18:32:48.022268
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:32:50.574549
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-12 18:34:15.663892
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    sample_tudouAlbum_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbum_ie = TudouAlbumIE()

    tudouAlbum_ie._download_json = lambda url, video_id: {'items': [{'icode': 'abc', 'kw': 'def'}, {'icode':'ghi', 'kw':'jkl'}]}
    tudouAlbum_ie.url_result = lambda url, ie, video_id, video_title: {'id': video_id, 'title': video_title}

    expected_tudouAlbum_playlist = [{'id': 'abc', 'title': 'def'}, {'id': 'ghi', 'title': 'jkl'}]

# Generated at 2022-06-12 18:34:25.348425
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:34:28.385032
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:34:32.628008
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE as testclass
    obj = testclass()
    # Note: class TudouAlbumIE inherits from class InfoExtractor
    assert isinstance(obj, InfoExtractor)
    # Here are some tests for the 'testclass' object
    assert obj.IE_NAME == 'tudou:album'
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:34:35.342514
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.name == "tudou:playlist"
    assert playlist.IE_NAME == "tudou:playlist"


# Generated at 2022-06-12 18:34:41.930055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_data = [{'icode': 'Kj4_mh_tFbA', 'kw': 'Asterix and Obelix'}]
    expected = 'http://www.tudou.com/programs/view/Kj4_mh_tFbA'
    actual = 'http://www.tudou.com/programs/view/%s' % album_data[0]['icode']
    assert expected == actual
    expected = 'Asterix and Obelix'
    actual = album_data[0]['kw']
    assert expected == actual

# Generated at 2022-06-12 18:34:47.817238
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    # (1) Test for a correct URL
    correct_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    album_id = TudouAlbumIE._match_id(TudouAlbumIE, correct_url)
    assert album_id == 'v5qckFJvNJg', 'Test_1 Failed!'

    # (2) Test for an incorrect URL
    incorrect_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    wrong_album_id = TudouAlbumIE._match_id(TudouAlbumIE, incorrect_url)
    assert wrong_album_id is None, 'Test_2 Failed!'

    # (3) Test for multiple URLs with same album
    multi_url_

# Generated at 2022-06-12 18:34:53.335127
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    inst = TudouPlaylistIE()
    res = inst._real_extract(url)

    # Player list id
    assert 'id' in res
    assert res['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:34:54.565301
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:34:59.303019
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(playlist_id, playlist_url)
    assert tudou_playlist_ie.id == playlist_id
    assert tudou_playlist_ie.url == playlist_url


# Generated at 2022-06-12 18:37:50.059471
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#test url, url
	test_url = 'http://www.tudou.com/plcover/cover/code/zzdE77v6Mmo/'
	test_url2 = 'http://www.tudou.com/plcover/zzdE77v6Mmo/'
	#test url, url
	test_url3 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	test_url4 = 'http://www.tudou.com/listplay/ch-vh_aA_zM/'
	#test url, url
	test_url5 = 'http://www.tudou.com/album/cover/code/v5qckFJvNJg/'