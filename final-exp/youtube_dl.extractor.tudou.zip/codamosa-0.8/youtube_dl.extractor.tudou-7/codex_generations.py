

# Generated at 2022-06-12 18:28:03.821570
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import pprint
    from .common import playlist_result
    from .common import url_result

    tudou_album_ie = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    pprint(tudou_album_ie._real_extract(url))
    #输出如下：
    #playlist_result(
    #    [
    #        url_result('http://www.tudou.com/programs/view/ZdP-jKDzQw8/', 'Tudou', 'ZdP-jKDzQw8'),
    #        url_result('http://www.tudou.com/programs/view/m-G

# Generated at 2022-06-12 18:28:04.983671
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-12 18:28:12.509615
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    sub_url = "http://www.tudou.com/listplay/dWrk-r92tTc.html"
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'Tudou:Playlist'
    assert ie._VALID_URL == "^https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html$"
    assert ie._TESTS[0]['url'] == sub_url
    assert ie._TESTS[0]['info_dict']['id'] == 'dWrk-r92tTc'
    assert ie._TESTS[0]['playlist_mincount'] == 78


# Generated at 2022-06-12 18:28:15.286754
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert "http://www.tudou.com/albumplay/v5qckFJvNJg.html" == TudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:28:25.049697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    folder = 'test/data/TudouPlaylistIE/'
    _player = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    _player._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % _player._match_id(url), _player._match_id(url))
    page = open(folder + '1.json')
    page_json = page.read()
    page.close()
    import json
    # Assign the json file to a json object
    page_obj = json.loads(page_json)
    _player._real_extract(url)

# Generated at 2022-06-12 18:28:33.249205
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_Obj = TudouPlaylistIE()
    tudou_playlist_Obj.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_Obj.get_url_info()
    assert tudou_playlist_Obj.is_playlist is True
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_Obj.get_video_info(url) == {'id': 'zzdE77v6Mmo'}
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_Obj._real_extract

# Generated at 2022-06-12 18:28:43.461341
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_no = 0
    
    # Create instance of class TudouPlaylistIE
    result = TudouPlaylistIE()
    
    # Create test cases
    # Each element of 'testcase' is a tuple contains (url, playlist_id)
    testcase = [('http://www.tudou.com/playlist/p/a1633235.html', 'a1633235'),
                ('http://www.tudou.com/listplay/zwV7wG4rbQQ.html', 'zwV7wG4rbQQ')]
    
    # Iterate the test cases
    for url, playlist_id in testcase:
        test_no += 1

# Generated at 2022-06-12 18:28:53.574447
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    list_entries = [{'icode':'_a53m5i2t7o', 'kw':'tudou'}, {'icode':'_-N1fH7qxyw', 'kw':'tudou'}, {'icode':'_-N1e1i7ayw', 'kw':'tudou'}]
    playlist_data = {'count':3, 'items':list_entries}
    playlist_id = 'zzdE77v6Mmo'
    tudou_playlist_ie = TudouPlaylistIE()
    assert_equal(tudou_playlist_ie.IE_NAME, 'tudou:playlist')

# Generated at 2022-06-12 18:28:58.111245
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(hasattr(TudouAlbumIE, '_VALID_URL'))
    assert(hasattr(TudouAlbumIE, 'IE_NAME'))
    assert(hasattr(TudouAlbumIE, '_TESTS'))
    assert(hasattr(TudouAlbumIE, '_real_extract'))


# Generated at 2022-06-12 18:29:00.569891
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:29:05.586958
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:29:13.200213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert(ie.IE_NAME == 'tudou:album')
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')
    assert(ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:29:16.796796
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert isinstance(tudou_playlist_ie, InfoExtractor)


# Generated at 2022-06-12 18:29:18.377630
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:29:19.945749
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE()
    assert constructor == TudouAlbumIE()

# Generated at 2022-06-12 18:29:23.082019
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.ie_key() == 'Tudou'
    assert playlist.ie_key() == 'TudouPlaylist'
    assert playlist.ie_key() == 'Tudou:playlist'

# Generated at 2022-06-12 18:29:26.647719
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    listPlaylist = TudouPlaylistIE()
    assert listPlaylist.ie_key() == 'TudouPlaylist'
    assert listPlaylist.ie_name() == 'youku.com/playlist'
    return


# Generated at 2022-06-12 18:29:29.389467
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Unit test for constructor
    t = TudouPlaylistIE()
    t = None


# Generated at 2022-06-12 18:29:33.892552
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Testing constructor of class TudouAlbumIE")
    # This should not raise an exception when instantiated
    TudouAlbumIE()
    # It should be a subclass of InfoExtractor
    assert issubclass(TudouAlbumIE,InfoExtractor)
    print("Testing constructor of class TudouAlbumIE has passed!")


# Generated at 2022-06-12 18:29:36.477794
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    instance = TudouPlaylistIE(url,'tudou',url)

# Generated at 2022-06-12 18:29:44.259360
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	loader = unittest.TestLoader()
	suite = loader.loadTestsFromTestCase(TudouIE)
	return suite

# Generated at 2022-06-12 18:29:45.940922
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-12 18:29:54.406734
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE.iie = TudouPlaylistIE()
    assert(test_TudouPlaylistIE.iie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True)
    assert(test_TudouPlaylistIE.iie.suitable('http://www.tudou.com/listplay/zzdE77v6Mm0.html') == False)


# Generated at 2022-06-12 18:29:58.933523
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(InfoExtractor())._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:30:08.867309
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """ Test constructor of class TudouAlbumIE """
    _TUDOU_ALBUM_URL_FORMAT_1 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    _TUDOU_ALBUM_URL_FORMAT_2 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    _EXPECTED_RESULT = 'v5qckFJvNJg'

    tudouBulidAlbumIEFromUrlFormat1 = TudouAlbumIE(_TUDOU_ALBUM_URL_FORMAT_1)
    tudouBulidAlbumIEFromUrlFormat2 = TudouAlbumIE(_TUDOU_ALBUM_URL_FORMAT_2)


# Generated at 2022-06-12 18:30:11.461016
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Execute code
    TudouPlaylistIE()


# Generated at 2022-06-12 18:30:15.307266
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    extractor = TudouPlaylistIE(InfoExtractor)
    assert extractor.suitable(url)
    extractor.extract(url)


# Generated at 2022-06-12 18:30:18.564084
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html", {}).url == "http://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-12 18:30:19.793496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_TudouPlaylistIE = TudouPlaylistIE()


# Generated at 2022-06-12 18:30:23.401850
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie._match_id(url)
    tudou_playlist_ie._real_extract(url)


# Generated at 2022-06-12 18:30:38.024147
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import TudouAlbumIE
    assert isinstance(TudouAlbumIE, object)

# Generated at 2022-06-12 18:30:48.243055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ''' Test constructor of class TudouAlbumIE '''
    ie = TudouAlbumIE(None)
    assert ie.ie_name('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'tudou:album'
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True
    assert ie.suitable('http://www.letv.com/ptv/vplay/26209109.html') == False
    assert ie.valid_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True

# Generated at 2022-06-12 18:30:53.216468
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbum_ie = TudouAlbumIE()
    assert tudoualbum_ie.ie_key() == 'TudouAlbum'
    assert tudoualbum_ie.ie_name() == 'Tudou:album'
    assert tudoualbum_ie.ie_description() == 'Tudou.com albums'
    assert tudoualbum_ie.ie_version() == '0.0'


# Generated at 2022-06-12 18:30:56.383494
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_cipher = 'TudouAlbumIE(id=v5qckFJvNJg)'
    test_obj = TudouAlbumIE(test_url)
    assert test_cipher == test_obj.__str__()

# Generated at 2022-06-12 18:31:00.225094
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.NAME == 'tudou:playlist'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:31:01.669461
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE(TudouAlbumIE.ie_key())

# Generated at 2022-06-12 18:31:06.933154
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    params = {
        'tudou_playlist': {
            'name': 'TudouPlaylistTest',
            'url': 'http://www.tudou.com/listplay/fv8GyKWJkCE'
        },
        'tudou_album': {
            'name': 'TudouAlbumTest',
            'url': 'http://www.tudou.com/albumplay/KXQM6VaZtvA.html'
        }
    }
    # check the constructor of class TudouPlaylistIE
    assert isinstance(TudouPlaylistIE(params['tudou_playlist']), InfoExtractor)
    assert isinstance(TudouAlbumIE(params['tudou_album']), InfoExtractor)

# Generated at 2022-06-12 18:31:08.228593
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    # test.test()


# Generated at 2022-06-12 18:31:11.443704
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_test = TudouPlaylistIE()
    playlist_test._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')



# Generated at 2022-06-12 18:31:12.358351
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-12 18:31:48.699920
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-12 18:31:51.872614
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-12 18:31:52.758799
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-12 18:31:55.570701
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Unit test for constructor of class TudouPlaylistIE"""
    try:
        TudouPlaylistIE()
    except Exception as e:
        print(e)


# Generated at 2022-06-12 18:31:57.971866
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' == TudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:32:03.270744
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
#    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(test)

# Generated at 2022-06-12 18:32:13.426268
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test sample url
    # url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    
    # Test sample playlist_id
    # playlist_id = "zzdE77v6Mmo"
    
    playlist_id = "zzdE77v6Mmo"

# Generated at 2022-06-12 18:32:19.705631
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_info_dict = {'id': 'zzdE77v6Mmo'}
    test_playlist_mincount = 209
    ie_test = TudouPlaylistIE()
    ie_test.url = test_url
    assert ie_test.url == test_url
    assert ie_test._match_id(test_url) == test_info_dict['id']
    id = ie_test._match_id(test_url)
    test_playlist_url = 'http://www.tudou.com/tvp/plist.action?lcode=%s' % id
    assert ie_test._download_json(test_playlist_url, id) != None
   

# Generated at 2022-06-12 18:32:23.398746
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__name__ == 'TudouPlaylistIE'
    assert TudouPlaylistIE.ie_key() == 'Tudou:playlist'
    assert TudouPlaylistIE.ie_key() in InfoExtractor.ie_key_map


# Generated at 2022-06-12 18:32:24.029631
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .common import InfoExtractor
	TudouAlbum=InfoExtractor

# Generated at 2022-06-12 18:33:36.039073
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:33:43.671087
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME in ie._api_stack
    assert ie._api_stack[ie.IE_NAME] == 'http://www.tudou.com/tvp/alist.action'


# Generated at 2022-06-12 18:33:49.010576
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-12 18:33:57.529448
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    # Get page html
    page = tests.utils.get_testdata_filepath('tudou_playlist.html')
    with open(page, 'r') as page_file:
        page_content = page_file.read()

    # Mock downloader
    downloader = tests.mock.Mock()
    downloader.download.side_effect = [page_content, tests.mock.DEFAULT]
    downloader.return_value = downloader

    # Test
    with tests.mock.patch('youtube_dl.downloader.http.HttpFD.download') as mock_downloader:
        mock_downloader.return_value = tests.mock.Mock()
        mock_downloader

# Generated at 2022-06-12 18:34:03.709876
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Create an object of class TudouAlbumIE
    albumie = TudouAlbumIE()
    # Make sure that the validation on the url is passed
    assert albumie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # Call _real_extract method to extract data
    albumie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')



# Generated at 2022-06-12 18:34:06.854267
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-12 18:34:15.195345
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-12 18:34:20.564730
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Unit test of TudouPlaylistIE")

    # The URL of a Tudou playlist
    URL = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Create an instance of class TudouPlaylistIE
    tudou_playlist_ie = TudouPlaylistIE()
    # Extract contents of the Tudou playlist
    tudou_playlist_ie.extract(URL)

# Generated at 2022-06-12 18:34:22.874353
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from .common import compilation
	compilation("https://www.tudou.com/listplay/zzdE77v6Mmo.html")


# Generated at 2022-06-12 18:34:26.577621
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE._VALID_URL is not None
    assert tudouPlaylistIE._TESTS is not None


# Generated at 2022-06-12 18:37:02.929809
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	_VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	_TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-12 18:37:08.072000
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:37:14.047164
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert(obj.IE_NAME == 'tudou:playlist')
    assert(obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(obj._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')
    assert(obj._TESTS[0]['playlist_mincount'] == 209)


# Generated at 2022-06-12 18:37:16.302890
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is 'v5qckFJvNJg'

# Generated at 2022-06-12 18:37:21.901505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import test_playlists as test_playlist
    ie = TudouAlbumIE(TudouAlbumIE.ie_key())
    test_playlist.test__constructor(ie, (TudouAlbumIE._VALID_URL, 'v5qckFJvNJg',
        'Uploaded by LittlePig'))


# Generated at 2022-06-12 18:37:23.198262
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE()

# Generated at 2022-06-12 18:37:25.922618
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tu = TudouAlbumIE()
    #print len(tu._TESTS)

# Generated at 2022-06-12 18:37:32.252483
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	
	album_id = 'v5qckFJvNJg'
	album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id	
	entries = 'test'
	test_playlist_result = self.playlist_result(entries, album_id)
	
	#test_playlist_result should be equal to what the _real_extract function returns with the test album_id
	assertEqual(test_playlist_result, _real_extract(album_data))
	

# Generated at 2022-06-12 18:37:34.129508
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE())


# Generated at 2022-06-12 18:37:34.707170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True