

# Generated at 2022-06-12 18:27:56.098723
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    url = TudouPlaylistIE._VALID_URL
    id = 'zzdE77v6Mmo'

    TudouPlaylistIE(url, id)


# Generated at 2022-06-12 18:28:05.469625
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE as cls
    from .tudou import get_sha1, get_tudou_videoinfo_by_kw
    from .tudou import _decrypt_url_info, _real_extract, _real_extract as real_extract

    def test_get_sha1(kw, seed, expected):
        print('test get_sha1(kw=%s, seed=%s, expected=%s):' % (
            repr(kw), repr(seed), repr(expected),))
        got = get_sha1(kw, seed)
        print('got %s' % repr(got))
        assert got == expected

    def test_get_tudou_videoinfo_by_kw():
        pass


# Generated at 2022-06-12 18:28:13.431081
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    item = {
        'icode': 'hT2W8hmOtII',
        'kw': 'test key word',
    }
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.url_result('http://www.tudou.com/programs/view/%s' % item['icode'], 'Tudou', item['icode'], item['kw']) == {
        "url": "http://www.tudou.com/programs/view/hT2W8hmOtII",
        "ie_key": "Tudou",
        "ie_key_id": "hT2W8hmOtII",
        "id": "hT2W8hmOtII",
        "title": "test key word",
    }

# Generated at 2022-06-12 18:28:19.153546
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    string = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # assert that playlist_id is parsed correctly
    assert TudouPlaylistIE._match_id(string) == 'zzdE77v6Mmo'
    # assert that the url is parsed correctly
    assert TudouPlaylistIE._VALID_URL.match(string).groups() == (TudouPlaylistIE._match_id(string),)


# Generated at 2022-06-12 18:28:22.886118
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE({})
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:28:26.761878
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:28:28.029644
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie
    assert ie.IE_NAME

# Generated at 2022-06-12 18:28:34.287369
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE('tudou:album')
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie_result = tudouAlbumIE._real_extract(url)
    id = tudouAlbumIE._match_id(url)

    # Ensure that album_data is retrieved correctly.
    expected = tudouAlbumIE._download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % id, id)
    assert ie_result['entries'][0]['_downloader_cache'] == expected


# Generated at 2022-06-12 18:28:37.620685
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE()
    assert test_obj._match_id('zzdE77v6Mmo') == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:28:41.326645
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    object_TudouPlaylistIE = TudouPlaylistIE()
    object_TudouPlaylistIE.extract(url)
    pass

# Generated at 2022-06-12 18:28:54.943094
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("\n")
    print("Test TudouPlaylistIE")
    ie = TudouPlaylistIE()
    # Importing required modules to test extracting capabilities
    from .common import InfoExtractor
    from .common import ExtractorError

    try:
        # Extracting playlist from non-existent playlist
        ie.extract("http://www.tudou.com/listplay/zzdE77v6Mmw.html")
    except ExtractorError:
        print("Test Case 1 Passed")

    try:
        # Extracting playlist which does not exist
        ie.extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    except ExtractorError:
        print("Test Case 2 Passed")

    # Extracting information from a playlist
    test_playlist = ie.ext

# Generated at 2022-06-12 18:29:00.126733
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor
    """
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie.IE_DESC == '土豆网 (tudou.com)'


# Generated at 2022-06-12 18:29:03.996314
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test cases for constructor of class TudouAlbumIE
    tudou_Test = TudouAlbumIE()

# Generated at 2022-06-12 18:29:08.418324
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create a tudou playlist test object
    tudou_playlist_test = TudouPlaylistIE()
    assert tudou_playlist_test.ie_key() == 'TudouPlaylist'

    # Create a tudou album test object
    tudou_album_test = TudouAlbumIE()
    assert tudou_album_test.ie_key() == 'TudouAlbum'

# Generated at 2022-06-12 18:29:11.191137
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    URL = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    P = TudouPlaylistIE(URL)
    assert P._match_id == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:29:12.236959
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:29:15.831083
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Testing TudouPlaylistIE Constructor')
    # Unit test 1
    TudouPlaylistIE_test1 = TudouPlaylistIE(0)
    print('Unit Test 1 Finished')
    # Unit test 2
    TudouPlaylistIE_test2 = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    print('Unit Test 2 Finished')


# Generated at 2022-06-12 18:29:21.075992
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # check if the instance has attribute _VALID_URL
    tdAlbumIE = TudouAlbumIE()
    assert tdAlbumIE.IE_NAME == 'tudou:album'
    assert tdAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-12 18:29:22.533293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistI = TudouPlaylistIE('test')
    assert True


# Generated at 2022-06-12 18:29:30.242691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Construct an instance of TudouPlaylistIE
    info_extractor = TudouPlaylistIE()
    # Validate that the URL provided as argument is correctly parsed
    assert info_extractor._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html") == "zzdE77v6Mmo"
    # Validate that playlist data is correctly retrieved
    assert info_extractor._download_json("http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo", "zzdE77v6Mmo")['items'][0]['icode'] != ""
    # Validate that playlist entries are correctly retrieved

# Generated at 2022-06-12 18:29:44.334038
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(downloader=None)
    try:
        assert ie.IE_NAME == 'tudou:album'
        assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
        assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        assert ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
        assert ie._TESTS[0]['playlist_mincount'] == 45
    except:
        print("ERROR: test_TudouAlbumIE() ERROR!")


# Generated at 2022-06-12 18:29:48.240083
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testVideo = ['http://www.tudou.com/listplay/zzdE77v6Mmo.html']
    expectedInfo = {
        'id': 'zzdE77v6Mmo',
    }

    for url in testVideo:
        tudouPlaylistIE = TudouPlaylistIE(url)
        assert(tudouPlaylistIE.extract()['id'] == expectedInfo['id'])


# Generated at 2022-06-12 18:29:54.162280
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_id = 'v5qckFJvNJg'
	album_url = 'http://www.tudou.com/albumplay/' + album_id + '.html'
	tudou_album = TudouAlbumIE()
	tudou_album.url = album_url
	tudou_album.extract()
	assert tudou_album.playlist_id == album_id

# Generated at 2022-06-12 18:30:00.499440
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    assert e.IE_NAME == 'tudou:album'
    assert e._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:30:06.662015
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert len(TudouPlaylistIE._TESTS) == 1
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:30:08.246208
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	yt_playlist = TudouPlaylistIE()
	assert yt_playlist.IE_NAME == 'tudou:playlist'
	return 


# Generated at 2022-06-12 18:30:14.149971
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	print ('Unit test of constructor of class TudouAlbumIE')
	print ('tudouAlbumIE url : ', tudouAlbumIE._VALID_URL)

# Generated at 2022-06-12 18:30:17.860211
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistInstance = TudouPlaylistIE()
    assert TudouPlaylistInstance._match_id(test_url) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:30:23.310688
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/album(?:cover|play)/(?P<id>[\\w-]{11})'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:30:25.123288
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo')


# Generated at 2022-06-12 18:30:39.325760
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE();
    assert tudou_album_ie is not None


# Generated at 2022-06-12 18:30:44.201663
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    e = TudouPlaylistIE('tudou:playlist')
    assert e.IE_NAME == 'tudou:playlist'
    assert e._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:30:45.425164
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-12 18:30:49.240046
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    expected = 'tudou:playlist'
    print('\nexpected is [%s]\nacutal   is [%s]' % (expected, x.IE_NAME))
    assert x.IE_NAME == expected


# Generated at 2022-06-12 18:30:52.511705
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    ie = TudouPlaylistIE('tudou:playlist','http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:31:00.357404
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    _TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    tudou = TudouPlaylistIE()

# Generated at 2022-06-12 18:31:00.932892
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True

# Generated at 2022-06-12 18:31:01.552066
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:31:03.996945
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:31:09.849821
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    # Test for regular expression of the url
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    # Test for IE name
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:31:48.235170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    video_id = 'v5qckFJvNJg'
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-12 18:31:52.875514
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    ie.download()
    # Test that the playlist is valid
    assert ie.is_valid()
    # Test that the playlist id is t

# Generated at 2022-06-12 18:31:54.653499
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 2 == 2

# Generated at 2022-06-12 18:32:01.369478
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    class TestTudouPlaylistIE(TudouPlaylistIE):
        def _real_extract(self, url):
            raise Exception('Should never be called')
    TestTudouPlaylistIE('Tudou')._download_json = lambda _: None
    TestTudouPlaylistIE('Tudou').url_result = lambda _: _
    TestTudouPlaylistIE('Tudou').playlist_result = lambda _, n: n
    assert TestTudouPlaylistIE('Tudou')._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:32:08.627698
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_album_IE = TudouAlbumIE(album_url)
    assert(test_album_IE.get_name() == TudouAlbumIE.IE_NAME)
    assert(test_album_IE.get_id() == 'v5qckFJvNJg')
    assert(test_album_IE.get_url() == album_url)



# Generated at 2022-06-12 18:32:14.595355
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test tudou album page
    test_TudouAlbumIE1 = TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    test_TudouAlbumIE2 = TudouAlbumIE()._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert test_TudouAlbumIE1 == test_TudouAlbumIE2

# Generated at 2022-06-12 18:32:18.177685
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE()
    result = ie.extract(url)
    assert "http://www.tudou.com/programs/view/lqfV7dXM-kQ" in result['entries'][0]['url']

# Generated at 2022-06-12 18:32:27.071934
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test a good case
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.id == 'v5qckFJvNJg'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:32:37.176928
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert ie._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-12 18:32:41.628362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_obj = TudouAlbumIE(InfoExtractor)
	result = test_obj._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert result['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:33:56.053720
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:34:00.665366
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.url == url
    assert ie.id == 'zzdE77v6Mmo'
    assert ie.name == 'tudou:playlist'


# Generated at 2022-06-12 18:34:01.468648
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-12 18:34:06.182214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('Testing TudouAlbumIE constructor...')
    for url in [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/abcdefghij1.html',
        'http://www.tudou.com/albumplay/abcdefghij1.html',
    ]:
        try:
            TudouAlbumIE(url)
        except:
            print('URL: ' + url + ' failed to be constructed!')
            assert False


# Generated at 2022-06-12 18:34:08.685369
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    entry = TudouPlaylistIE()
    assert(entry.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-12 18:34:10.172117
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    return obj

# Generated at 2022-06-12 18:34:18.217539
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:34:21.709245
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    td_playlist_ie = TudouPlaylistIE(url="http://www.tudou.com/listplay/zzdE77v6Mmo.html", downloader=None)
    assert len(td_playlist_ie) == 1


# Generated at 2022-06-12 18:34:22.577772
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:34:26.642809
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist != None
    assert tudou_playlist._VALID_URL != None
    assert tudou_playlist._TESTS != None


# Generated at 2022-06-12 18:37:06.694546
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test of constructor for TudouPlaylistIE"""
    ie = TudouPlaylistIE('https://www.tudou.com/en')
    assert ie.IE_NAME == TudouPlaylistIE.IE_NAME
    assert ie._VALID_URL == TudouPlaylistIE._VALID_URL
    assert ie._TESTS == TudouPlaylistIE._TESTS
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_key(ie_key_preference='tudouplaylist') == 'tudouplaylist'



# Generated at 2022-06-12 18:37:07.982458
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE_instance = TudouAlbumIE()
    assert tudou_albumIE_instance is not None

# Generated at 2022-06-12 18:37:13.557371
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    m = TudouAlbumIE()
    assert m.IE_NAME == 'tudou:album'
    assert m._VALID_URL == r'https?://(?:www\.)?tudou\.com/(?:album|play)/(?P<id>[\w-]{11})'
    assert m._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        # 'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:37:16.761213
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test a full playlist
    item_dict = TudouPlaylistIE()._real_extract(TudouPlaylistIE._TESTS[0]['url'])
    assert len(item_dict['entries']) == 209


# Generated at 2022-06-12 18:37:26.588964
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE('')
    tudou_albumIE.getAcode('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    tudou_albumIE.getAcode('http://www.tudou.com/albumcover/v5qckFJvNJg/')
    tudou_albumIE.getAcode('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    tudou_albumIE.getAcode('http://www.tudou.com/album')


# Generated at 2022-06-12 18:37:28.601209
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Unit test for constructor of class TudouAlbumIE
    """
    assert isinstance(TudouAlbumIE(), InfoExtractor)

# Generated at 2022-06-12 18:37:30.928296
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	"""
	Test the constructor of class TudouAlbumIE.
	"""
	ie = TudouAlbumIE()
	assert ie.IE_NAME == "tudou:album"

# Generated at 2022-06-12 18:37:33.093833
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE(None, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'v5qckFJvNJg')
    except:
        assert False

# Generated at 2022-06-12 18:37:36.002441
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE()._real_extract(url)



# Generated at 2022-06-12 18:37:37.527268
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    play = TudouPlaylistIE()
    assert play.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
