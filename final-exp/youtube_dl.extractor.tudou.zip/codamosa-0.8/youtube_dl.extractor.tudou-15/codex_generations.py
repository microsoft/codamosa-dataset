

# Generated at 2022-06-12 18:27:56.827744
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	a = TudouAlbumIE()
	# type(a) should be <class '__main__.TudouAlbumIE'>

# Generated at 2022-06-12 18:28:01.573614
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE(6, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', {'id': 'zzdE77v6Mmo'}, {})
    test_TudouPlaylistIE.download()


# Generated at 2022-06-12 18:28:02.465408
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE({})
    assert i

# Generated at 2022-06-12 18:28:08.084950
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'http://www.tudou.com/albumplay/v5qckFJvNJg.html' == TudouAlbumIE()._TESTS[0]['url']
    assert 'http://www.tudou.com/programs/view/%s' % 'v5qckFJvNJg' == TudouAlbumIE()._TESTS[0]['entries'][0]['url']

# Generated at 2022-06-12 18:28:11.440392
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(InfoExtractor())
    #TODO: fix me:
    ie.suitable('zzdE77v6Mmo')
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:28:18.938192
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:28:20.699057
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()

# Generated at 2022-06-12 18:28:25.220149
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    entry = TudouAlbumIE()._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert entry['title'] == '汉字'
    assert entry['id'] == 'v5qckFJvNJg'
    assert len(entry['entries']) == 45

# Generated at 2022-06-12 18:28:30.971809
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    # Validate Playlist
    playlist = ie.extract(url)
    assert playlist['_type'] == 'playlist'
    assert len(playlist['entries']) == 209 # playlist_mincount in _TESTS = 209
    assert 'Tudou' in playlist['entries'][0]['uploader']



# Generated at 2022-06-12 18:28:34.668181
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-12 18:28:43.167805
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.ie_key() == 'TudouAlbum'
    assert TudouAlbumIE.ie_key() != 'TudouPlaylist'



# Generated at 2022-06-12 18:28:45.955320
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from TudouIE import TudouPlaylistIE
    tudou = TudouPlaylistIE()
    return tudou


# Generated at 2022-06-12 18:28:54.001435
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    playlist = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert playlist.IE_NAME == "tudou:album"
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert playlist._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert playlist._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg"
    assert playlist._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-12 18:28:55.637398
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE, InfoExtractor), "Assert fail: tudou.py - class 'TudouAlbumIE' doesn't inherit from 'InfoExtractor'."


# Generated at 2022-06-12 18:29:02.937148
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import sys

	# Test for constructor of TudouPlaylistIE
	list_tudouplaylistie = TudouPlaylistIE()

	# Print the test result
	if(list_tudouplaylistie.IE_NAME == 'tudou:playlist'):
		sys.stdout.write("Test for constructor of TudouPlaylistIE: pass!\n")
	else:
		sys.stdout.write("Test for constructor of TudouPlaylistIE: fail!\n")


# Generated at 2022-06-12 18:29:05.060353
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()
    obj = info_extractor.ie_key()
    assert obj == 'Tudou:album'


# Generated at 2022-06-12 18:29:08.832105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie=TudouAlbumIE()
    assert ie.IE_NAME=='TudouAlbumIE'
    assert ie.VALID_URL==r'^https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    

# Generated at 2022-06-12 18:29:15.588299
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE('https://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert tudou_album.IE_NAME == 'tudou:album'
    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert tudou_album

# Generated at 2022-06-12 18:29:19.531795
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    """Test if it can construct an instance of TudouAlbumIE."""
    IG = TudouAlbumIE(url)
    assert IG

# Generated at 2022-06-12 18:29:23.046267
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    TudouAlbumIE()._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:29:34.014192
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert TudouPlaylistIE._TESTS == [{
		'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
		'info_dict': {
			'id': 'zzdE77v6Mmo',
		},
		'playlist_mincount': 209,
	}]

# Generated at 2022-06-12 18:29:35.579255
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #tudou = TudouAlbumIE()
    assert 1 == 1


# Generated at 2022-06-12 18:29:39.804276
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import _TEST_PLAYLIST
    _test_TudouPlaylistIE = TudouPlaylistIE(_TEST_PLAYLIST.copy()).extract()
    assert _test_TudouPlaylistIE.get('entries') is not None
    assert _test_TudouPlaylistIE.get('id') == 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:29:40.678681
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:29:41.378632
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-12 18:29:45.835749
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    check_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist._match_id(check_url) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:29:46.590140
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:29:52.386707
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance.valid_url('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:29:55.263740
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('test for constructor of class TudouPlaylistIE')
    ie = TudouPlaylistIE()
    print(ie.IE_NAME)
    print(ie._VALID_URL)
    print(ie._TESTS)


# Generated at 2022-06-12 18:30:04.150239
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test = TudouAlbum(MockProcessor())
	assert test.name == 'TudouAlbum'
	assert test.extractor_key == 'TudouAlbum'
	assert test.extractor_type == 'IE'
	assert 'TudouAlbum' in list(info_extractors.keys())
	assert test.accepted_url == [re.compile('https?://(?:www\\.)?tudou\\.com/album(?:cover|play)/(?P<id>[\\w-]{11})')]

# Generated at 2022-06-12 18:30:17.573522
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:30:25.088126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert t._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
    assert t._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % 'zzdE77v6Mmo', "zzdE77v6Mmo")['num_items'] == 209

# Generated at 2022-06-12 18:30:25.773333
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:30:27.175455
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    entry = TudouAlbumIE()

# Generated at 2022-06-12 18:30:36.835306
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Regular test
    construct = TudouPlaylistIE()
    assert construct.IE_NAME == 'tudou:playlist'
    assert construct._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(construct._TESTS) == 1

    # Test case
    result = construct._TESTS[0]
    assert result['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert result['info_dict']['id'] == 'zzdE77v6Mmo'
    assert result['playlist_mincount'] == 209


# Generated at 2022-06-12 18:30:38.188004
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-12 18:30:44.088513
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url="https://www.tudou.com/albumcover/qIgEb7Vl9iQ.html"
    album_id='qIgEb7Vl9iQ'
    album_data = 'https://www.tudou.com/tvp/alist.action?acode=qIgEb7Vl9iQ'
    tudouAlbumExtractor=TudouAlbumIE()
    assert tudouAlbumExtractor._match_id(url)==album_id
    assert tudouAlbumExtractor._download_json(album_data,album_id)['acode']=='qIgEb7Vl9iQ'

# Generated at 2022-06-12 18:30:48.236115
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudouAlbumIE = TudouAlbumIE()
    tudouAlbumIE.extract(url)

# Generated at 2022-06-12 18:30:51.682358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudou_album_ie = TudouAlbumIE()
	assert tudou_album_ie.extract(url)


# Generated at 2022-06-12 18:30:53.996995
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create an instance for testing
    playlist = TudouPlaylistIE()
    # ensure that isinstance(playlist, InfoExtractor) is True
    assert isinstance(playlist, InfoExtractor)

# Generated at 2022-06-12 18:31:13.422935
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tu = TudouAlbumIE()
	assert(tu.IE_NAME == 'tudou:album')
	assert(tu == TudouAlbumIE())
	assert(tu._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
	assert(tu == TudouAlbumIE(tudou_id=None))
	assert(tu._TESTS == [{
		'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
		'info_dict': {
			'id': 'v5qckFJvNJg',
		},
		'playlist_mincount': 45,
	}])


# Generated at 2022-06-12 18:31:17.317896
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Minimum check for tudou:album url.
    tudou = TudouAlbumIE({})
    tudou._download_json = lambda url, video_id: {'items': []}
    tudou.url_result = lambda url, title, id: id
    tudou._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:31:20.017634
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_IE = TudouPlaylistIE()
    assert playlist_IE != None


# Generated at 2022-06-12 18:31:23.142958
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == "tudou:playlist"


# Generated at 2022-06-12 18:31:24.697067
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE.IE_NAME,
                 TudouAlbumIE._VALID_URL,
                 TudouAlbumIE._TESTS)

# Generated at 2022-06-12 18:31:25.402875
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:31:34.690702
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE();
	assert test.IE_NAME == 'tudou:playlist';
	assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html';
	assert len(test._TESTS) == 1;
	assert test._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    };


# Generated at 2022-06-12 18:31:40.616353
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    This function tests constructor of class TudouPlaylistIE
    """
    # Valid playlist URL
    test_url = TudouPlaylistIE._VALID_URL
    test_ie = TudouPlaylistIE(test_url)
    assert test_ie._VALID_URL is TudouPlaylistIE._VALID_URL


# Generated at 2022-06-12 18:31:42.227724
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()
    print(info)


# Generated at 2022-06-12 18:31:43.376468
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    r = TudouPlaylistIE()
    assert r != None

# Generated at 2022-06-12 18:32:15.336944
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_test = TudouPlaylistIE()
    tudou_playlist_test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_test_expected = {
        'id': 'zzdE77v6Mmo'
    }
    tudou_playlist_test_actual = {
        'id': tudou_playlist_test._match_id(tudou_playlist_test_url)
    }
    assert tudou_playlist_test_actual == tudou_playlist_test_expected


# Generated at 2022-06-12 18:32:17.525179
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:32:26.835150
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	
	import unittest
	
	# test: url
	assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

	# test: id
	assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

	# test: playlist_mincount
	assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209

	# test: IE_NAME
	assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'

	# test: real_extract

# Generated at 2022-06-12 18:32:35.849886
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Done: extract playlist_title, playlist_id and uploader for the playlist
    # Failed: -
    ie = TudouPlaylistIE()
    e = ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert e['id'] == 'zzdE77v6Mmo'
    assert e['title'] == 'tudou'
    # TODO: update the min_count after the lastest change of playlist format
    # assert e['min_count'] == 209


# Generated at 2022-06-12 18:32:44.515180
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert test_TudouPlaylistIE is not None
    assert test_TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-12 18:32:48.419434
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._valid_url(url,ie.IE_NAME) == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:32:50.023053
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('test_TudouPlaylistIE')
    assert instance is not None

# Generated at 2022-06-12 18:32:50.877238
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    t.suite()

# Generated at 2022-06-12 18:32:52.247506
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('1','2','3','4','5')


# Generated at 2022-06-12 18:32:55.294703
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = {'id': 'zzdE77v6Mmo'}
    ie = TudouPlaylistIE(TudouPlaylistIE.ie_key(), info)
    return ie


# Generated at 2022-06-12 18:34:07.596927
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_extract('url')

# Generated at 2022-06-12 18:34:11.926854
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE(InfoExtractor)
    assert_raises(ValueError, IE.extract, 'foo')
    assert_raises(ValueError, IE.extract, 'http://www.tudou.com/albumplay/q3Jly-eWXXX.html')

# Generated at 2022-06-12 18:34:12.976690
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-12 18:34:17.508344
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist.ie_key() == 'tudou:playlist'
    assert tudouplaylist.ie_name() == 'tudou:playlist'
    assert tudouplaylist.ie_description() == 'tudou:playlist'


# Generated at 2022-06-12 18:34:21.491292
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zxqzeWt1sxE'
    playlist_url = 'http://www.tudou.com/listplay/zxqzeWt1sxE.html'
    tudou_playlist = TudouPlaylistIE()
    assert unicode(tudou_playlist) == playlist_id
    assert tudou_playlist._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS[0]['url'] == playlist_url
    assert tudou_playlist._TESTS[0]['info_dict']['id'] == playlist_id

# Generated at 2022-06-12 18:34:29.825270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tu = TudouAlbumIE()
    assert tu.IE_NAME == 'tudou:album'
    assert tu._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tu._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-12 18:34:31.677900
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ret = TudouPlaylistIE._build_url_result('http://www.tudou.com/programs/view/zzdE77v6Mmo', 'Tudou', 'zzdE77v6Mmo', "cctv-15")
    print(ret)


# Generated at 2022-06-12 18:34:34.605779
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:34:39.600195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    url_str = 'http://www.tudou.com/listplay/%s.html' % playlist_id
    test_obj = TudouPlaylistIE(url=url_str)
    assert test_obj._match_id(test_obj._url) == playlist_id

# Generated at 2022-06-12 18:34:40.433393
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    raise NotImplementedError


# Generated at 2022-06-12 18:37:16.162119
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("\nIn: %s" % __file__)

	TudouAlbumIE()


# Generated at 2022-06-12 18:37:22.072117
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #assert 'tudou:album' == TudouAlbumIE._VALID_URL

    #print("\nTest 1: Create an empty TudouAlbumIE instance")
    #tudou_album = TudouAlbumIE()

    #print("\nTest 2: Create an non empty TudouAlbumIE instance")
    tudou_album = TudouAlbumIE('tudou:album')

# Generated at 2022-06-12 18:37:27.714154
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(isinstance(ie._TESTS, list))


# Generated at 2022-06-12 18:37:32.030426
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    try:
        assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    except AssertionError as err:
        print(err)



# Generated at 2022-06-12 18:37:34.544348
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    my_TudouPlaylistIE = TudouPlaylistIE()
    assert my_TudouPlaylistIE
    

# Generated at 2022-06-12 18:37:36.425999
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    ie = InfoExtractor(TudouPlaylistIE.IE_NAME)

# Generated at 2022-06-12 18:37:37.737539
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

# Generated at 2022-06-12 18:37:44.623008
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test the constructor
    info = {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }
    playlist_ie = TudouPlaylistIE(info)
    assert(playlist_ie.name == 'tudou:playlist')
    assert(playlist_ie.IE_NAME == 'tudou:playlist')
    assert(playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')

# Generated at 2022-06-12 18:37:51.390864
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import FakeYDL
    from .tudou import TudouAlbumIE
    tudou = TudouAlbumIE()
    # album_id is v5qckFJvNJg
    album_id = "v5qckFJvNJg"

    album_data = tudou._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [tudou.url_result('http://www.tudou.com/programs/view/%s' % item['icode'],
                                 'Tudou', item['icode'],
                                 item['kw']) for item in album_data['items']]