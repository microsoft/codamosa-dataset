

# Generated at 2022-06-12 18:27:57.249042
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    t._real_extract('http://www.tudou.com/albumcover/A3sYJQsB0ME.html')

# Generated at 2022-06-12 18:27:58.971362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.ie_key())

# Generated at 2022-06-12 18:28:03.741920
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:28:09.988561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import TESTS_PATH
    d = TudouAlbumIE()
    d.IE_NAME = 'tudou:album'
    d._TESTS = [{
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }]
    d._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    d._downloader.cache.load()
    d._real_extract(d._TESTS[0]['url'])

# Generated at 2022-06-12 18:28:12.819604
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    acode = obj._match_id(r'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert acode == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:28:16.138201
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE()(playlist_url)


# Generated at 2022-06-12 18:28:16.995920
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:28:21.921303
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url_1 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_url_2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    test_case_1 = TudouAlbumIE(test_url_1)
    test_case_2 = TudouAlbumIE(test_url_2)
    # Should be equal
    assert test_case_1 == test_case_2

# Generated at 2022-06-12 18:28:24.692246
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE(None)
	assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-12 18:28:32.487430
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """TudouPlaylistIE should work correctly"""

    from . import playlist
    from . import utils
    from . import tudou

    # This is a mock class of TDouPlaylistIE
    class MockTDouPlaylistIE(tudou.TudouPlaylistIE):
        def _real_extract(self, url):
            return {'id': 'zzdE77v6Mmo'}

    playlist_ie = playlist.PlaylistInfoExtractor(MockTDouPlaylistIE())

    info_dict = playlist_ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert info_dict['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:28:41.967998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE(TudouAlbumIE.ie_key())
    test = ie._real_extract(url)
    assert len(test["entries"]) == 45

# Generated at 2022-06-12 18:28:48.708826
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url_list = [
        'http://www.tudou.com/listplay/6pBn1JCHyjk.html',
        'http://www.tudou.com/listplay/6pBn1JCHyjk/',
        'http://www.tudou.com/listplay/6pBn1JCHyjk.html/',
    ]
    for url in url_list:
        TudouPlaylistIE()._real_initialize(url)

# Generated at 2022-06-12 18:28:51.168906
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(TudouAlbumIE.IE_NAME, 'test') is not None)

# Generated at 2022-06-12 18:28:55.761156
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Test case 1
	test_case = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	# Verify with expected value
	assert test_case._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:28:57.455532
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:29:05.212255
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'TudouAlbum'
    assert ie.extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == {
        'title': '孤独的美食家',
        'id': 'v5qckFJvNJg',
        '_type': 'url_transparent',
        'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    }

# Generated at 2022-06-12 18:29:06.058354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:29:07.054660
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        ie = TudouAlbumIE()

# Generated at 2022-06-12 18:29:12.738710
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouplaylistie = TudouPlaylistIE(url)
    assert tudouplaylistie.url == url
    assert tudouplaylistie.name == 'tudou:playlist zzdE77v6Mmo'
    assert tudouplaylistie.ie_key == 'Tudou'
    assert tudouplaylistie.valid_url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-12 18:29:13.678092
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1==1

# Generated at 2022-06-12 18:29:26.035784
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	class Test_TudouAlbumIE(TudouAlbumIE):
		_TESTS = []
		def _real_extract(self, url):
			entry = self.url_result(
				'http://www.tudou.com/programs/view/%s' % 'abc',
				'Tudou', 'abc',
				'keyword')
			return entry
	ie = Test_TudouAlbumIE()
	entry_test = ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert entry_test['id'] == 'abc'
	assert entry_test['title'] == 'keyword'

# Generated at 2022-06-12 18:29:30.778210
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = "www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudouid = ie._match_id(url)
    assert tudouid == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:29:31.746832
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE==TudouAlbumIE

# Generated at 2022-06-12 18:29:32.797006
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:29:34.452454
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:29:35.368930
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:29:37.531455
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'tudou:album'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:29:39.896948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
	x = TudouAlbumIE(url)


# Generated at 2022-06-12 18:29:43.576187
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/A4AAiIgcDv4.html'
    TudouPlaylistIE._real_extract(TudouPlaylistIE, url)


# Generated at 2022-06-12 18:29:47.198229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import unittest
	class tudou_album_unit_test(unittest.TestCase):
		def test_TudouAlbumIE_constructor(self):
			try:
				tudou_album_object = TudouAlbumIE()
			except Exception as err:
				self.fail("Error in constructing object of TudouAlbumIE class\n"+str(err))

# Generated at 2022-06-12 18:30:01.100817
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert isinstance(tudou_album_ie, InfoExtractor)

# Generated at 2022-06-12 18:30:05.421987
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	instance = TudouPlaylistIE()
	assert(instance.IE_NAME == 'tudou:playlist')
	assert(instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-12 18:30:07.505229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-12 18:30:08.926923
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE({}).IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:30:19.546918
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    # Create mock response for GET request to http://www.tudou.com/albumplay/v5qckFJvNJg.html
    mock_response1 = Mock()
    mock_response1.read.return_value = '<html><div id=\'js-initial-data\' data-component-initial-data="{&quot;result&quot;:{&quot;trackid&quot;:&quot;&quot;,&quot;list&quot;:[],&quot;item&quot;:{}},&quot;module&quot;:{}}" />'

    # Create mock response for GET request to http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg
    mock_response2 = Mock()
    mock_response2

# Generated at 2022-06-12 18:30:25.535033
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Unit test for constructor of class TudouPlaylistIE"""
    assert(TudouPlaylistIE.__name__ == 'TudouPlaylistIE')
    assert(TudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(isinstance(TudouPlaylistIE.IE_NAME, str))
    assert(TudouPlaylistIE.IE_DESC == 'Tudou Playlist')
    assert(isinstance(TudouPlaylistIE.IE_DESC, unicode))
    assert(TudouPlaylistIE.IE_VERSION == '0.1')
    assert(isinstance(TudouPlaylistIE.IE_VERSION, str))

# Generated at 2022-06-12 18:30:30.596919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
	album_id = 'v5qckFJvNJg'
	print(''.format(TudouAlbumIE._real_extract(TudouAlbumIE(), album_url)))

# Generated at 2022-06-12 18:30:36.486214
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert (ie._VALID_URL is not None)
    assert (ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (ie._tests is not None)
    assert (ie._tests[0] is not None)
    assert (ie._tests[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert (ie._tests[0]['info_dict'] is not None)
    assert (ie._tests[0]['info_dict']['id'] == 'zzdE77v6Mmo')

# Generated at 2022-06-12 18:30:44.138098
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from urlparse import urlparse
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(album.IE_DESC) > 0
    assert album._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert urlparse(album._TESTS[0]['url']).path == '/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-12 18:30:46.179544
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbum = TudouAlbumIE()
    assert tudoualbum is not None

# Generated at 2022-06-12 18:31:10.284238
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:31:17.844016
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html').IE_NAME == 'tudou:playlist'

# Generated at 2022-06-12 18:31:24.726140
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert test_obj._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"
    assert test_obj._TESTS == [{'playlist_mincount': 209, 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}}]



# Generated at 2022-06-12 18:31:25.339213
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

	TudouPlaylistIE(InfoExtractor())

# Generated at 2022-06-12 18:31:26.011735
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:31:26.626593
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-12 18:31:30.729109
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE(TudouPlaylistIE._VALID_URL)
    if obj.IE_NAME != 'tudou:playlist' or obj.name != 'tudou:playlist':
        raise Exception('Invalid IE name')

# Generated at 2022-06-12 18:31:33.673850
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ydl = YDL()
    ydl.add_default_info_extractors()
    ydl.download(['http://www.tudou.com/listplay/zzdE77v6Mmo.html'])

# Generated at 2022-06-12 18:31:35.024499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-12 18:31:36.494127
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()


# Generated at 2022-06-12 18:32:26.256519
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.cache_key == 'tudou:playlist'
    assert ie.socket_timeout == socket.getdefaulttimeout()
    assert ie.playlist_mincount == 1
    assert ie.playlist_maxcount == 0
    assert ie.playlist_title == 'Youtube-DL test playlist'


# Generated at 2022-06-12 18:32:29.381735
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE().match(url)


# Generated at 2022-06-12 18:32:36.917172
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    album_id = "v5qckFJvNJg"
    instance = TudouAlbumIE()
    real_extract = instance._real_extract(album_url)
    assert real_extract['id'] == album_id
    assert real_extract['_type'] == 'playlist'
    assert real_extract['playlist_mincount'] == 45


# Generated at 2022-06-12 18:32:40.001410
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist.test() == False


# Generated at 2022-06-12 18:32:47.375410
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url_input = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url_expected = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    download_url_expected = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    html_content = '<html></html>'

    # test for method _real_initialize()
    if ie._downloader is not None:
        class MockDownloader(object):
            def __init__(self, ydl):
                pass

            def to_screen(self, s):
                pass

            def trouble(self, s):
                pass


# Generated at 2022-06-12 18:32:49.218992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE, InfoExtractor)


# Generated at 2022-06-12 18:32:53.622499
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .TudouAlbumIE import TudouAlbumIE
    IE = TudouAlbumIE()
    IE._real_extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")


# Generated at 2022-06-12 18:32:57.337896
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("test tudou playlist ie")

    ie = TudouPlaylistIE()

    print("get data")
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    data = ie._real_extract(url)

    print("test data length")
    assert len(data['entries']) == 209


# Generated at 2022-06-12 18:33:01.185338
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.extract_url == 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie.extract_title == '为了你我愿意热爱整个世界'
    assert ie.playlist_mincount == 209


# Generated at 2022-06-12 18:33:05.800897
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_id = 'v5qckFJvNJg'
    tudoualbumie = TudouAlbumIE()
    album_id = tudoualbumie._match_id(url)
    assert album_id == expected_id

# Generated at 2022-06-12 18:35:09.654569
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo/')



# Generated at 2022-06-12 18:35:10.472008
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:35:17.521036
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from utils import TestDictUtils

    tu = TudouPlaylistIE()
    assert tu.IE_NAME == u'tudou:playlist'
    assert tu._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    # Test _match_id
    assert tu._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == u'zzdE77v6Mmo'

    # Test _real_extract
    test_TudouAlbumIE()

    # Test playlist_result
    sample_list = ['a', 'b', 'c']
    result = tu.playlist_result(sample_list, 'd')
    assert Test

# Generated at 2022-06-12 18:35:17.926043
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	pass

# Generated at 2022-06-12 18:35:19.168936
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE("http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo")

# Generated at 2022-06-12 18:35:22.994704
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    test = tudou_playlist.extract(url)
    assert type(test) == dict

# Generated at 2022-06-12 18:35:27.412326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    info_dict = {
        'id': 'v5qckFJvNJg',
    }
    playlist_mincount = 45
    tudou_album_video = TudouAlbumIE()
    assert (tudou_album_videoplaylist_mincount == playlist_mincount)

# Generated at 2022-06-12 18:35:31.322082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert TudouAlbumIE._VALID_URL == TudouAlbumIE._VALID_URL
    TudouAlbumIE._real_initialize()
    TudouAlbumIE._real_extract(None, url)
    pass


# Generated at 2022-06-12 18:35:33.141656
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert tudouPlaylistIE is not None


# Generated at 2022-06-12 18:35:34.583927
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')