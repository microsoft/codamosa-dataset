

# Generated at 2022-06-12 18:28:04.080182
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_obj = TudouPlaylistIE('test_id')
    if test_obj.IE_NAME != 'tudou:playlist':
        raise Exception('Wrong IE_NAME @ class TudouPlaylistIE')
    if test_obj._VALID_URL != r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html':
        raise Exception('Wrong VALID_URL @ class TudouPlaylistIE')
    if test_obj._TESTS[0]['url'] != 'http://www.tudou.com/listplay/zzdE77v6Mmo.html':
        raise Exception('Wrong VALID_URL @ class TudouPlaylistIE')

# Generated at 2022-06-12 18:28:06.547188
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    c = TudouAlbumIE()
    #assert c.IE_NAME == 'tudou:album'
    #assert c.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-12 18:28:08.387634
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist == 'listplay'

# Generated at 2022-06-12 18:28:13.018769
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    inst = TudouAlbumIE(url)
    assert inst._VIDEO_INFO_URL == 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg'
    assert inst._URL_PATTERNS == (re.compile(TudouAlbumIE._VALID_URL),)

# Generated at 2022-06-12 18:28:17.114128
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'
    t.IE_NAME = 'tudou:playlist'
    assert t.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-12 18:28:19.651551
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:28:20.634880
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    print(obj)


# Generated at 2022-06-12 18:28:26.098838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_TudouPlaylistIE = TudouPlaylistIE(webpage_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', playlist_id = None, ie = 'tudou:playlist', video_id = None, video_title = None, video_url = None, video_webpage = None, video_info = None, video_info_dict = None)
	assert test_TudouPlaylistIE.webpage_url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-12 18:28:33.841390
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_obj = TudouAlbumIE()

    assert test_obj.IE_NAME == 'tudou:album'
    assert test_obj._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert test_obj._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:28:43.811695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Input:  a TudouAlbumIE
    Output: album_data, entries
    """
    album_id = "nZ1pKiVFoMg"
    url = "http://www.tudou.com/albumplay/" + album_id + ".html"
    ie = TudouAlbumIE(downloader=None)
    results = ie._real_extract(url)
    album_data = ie._download_json('http://www.tudou.com/tvp/alist.action?acode=' + album_id, album_id)

# Generated at 2022-06-12 18:28:53.768642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('abc', {}, 'abc')

# Generated at 2022-06-12 18:28:54.670879
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:29:04.830289
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ieClass = TudouAlbumIE()
	if "TudouAlbumIE" == ieClass.IE_NAME:
		print("IE_NAME is correct.")
	else:
		print("IE_NAME is wrong.")
	# Test constructor of class TudouAlbumIE
	test_urls = [
		"http://www.tudou.com/albumplay/v5qckFJvNJg.html",
		"http://www.tudou.com/albumcover/v5qckFJvNJg.html"
	]
	for test_url in test_urls:
		if ieClass._VALID_URL == ieClass._VALID_URL:
			print("It is a valid url.")
		else:
			print("It is not a valid url.")

# Generated at 2022-06-12 18:29:08.272859
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # unit testing a constructor is different from a class method
    c = TudouAlbumIE('www.tudou.com')
    assert c._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:29:09.377595
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist is not None


# Generated at 2022-06-12 18:29:15.799156
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-12 18:29:17.960507
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:29:21.603948
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.valid_url('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:29:22.718608
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS == 'test'

# Generated at 2022-06-12 18:29:29.698076
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:29:37.765517
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert(tudou_album is not None)


# Generated at 2022-06-12 18:29:39.070766
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_extract()

# Generated at 2022-06-12 18:29:46.402988
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    _TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

    for _TEST in _TESTS:
        playlist_id = _TEST['info_dict']['id']
        url = _TEST['url']
        playlist_data = _download_json(
            'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

# Generated at 2022-06-12 18:29:57.197649
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    from .common import InfoExtractor_UnitTestCase

    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'tudou:playlist'
        _VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
        _TESTS = [{
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }]

        def _real_extract(self, url):
            playlist_id = self._match_id(url)
           

# Generated at 2022-06-12 18:29:58.423968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('test')

# Generated at 2022-06-12 18:30:08.610590
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    check_tudou_playlistIE = TudouPlaylistIE()
    assert_equal(check_tudou_playlistIE.IE_NAME, 'tudou:playlist')
    assert_equal(check_tudou_playlistIE._VALID_URL, r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert_equal(check_tudou_playlistIE._TESTS[0]['url'], 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert_equal(check_tudou_playlistIE._TESTS[0]['info_dict']['id'],'zzdE77v6Mmo')

# Generated at 2022-06-12 18:30:10.450488
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE()

# Generated at 2022-06-12 18:30:20.238062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: Test possible link types:
    # http://www.tudou.com/albumplay/
    # http://www.tudou.com/albumcover/  
    assert(TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    ie = TudouAlbumIE('fakeurl')
    # 
    testurl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.url = testurl
    # since match_id is private, have to call _match_id here
    assert(ie._match_id(testurl) == 'v5qckFJvNJg')
    # TOD

# Generated at 2022-06-12 18:30:26.015301
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE(url = playlist_url)
    playlist_data = playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [InfoExtractor().url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]

# Generated at 2022-06-12 18:30:30.143305
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:30:52.819196
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE()
    # Test that the constructor is defined correctly
    assert_equals(tudou.IE_NAME, 'tudou:album')
    assert_equals(
        tudou._VALID_URL,
        r'https?://(?:www\.)?tudou\.com/(?:album(?:cover|play)/([\w-]{11}))')
    assert_equals(
        tudou._TESTS,
        [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
          'info_dict': {'id': 'v5qckFJvNJg'},
          'playlist_mincount': 45,
        }])


# Generated at 2022-06-12 18:30:53.816931
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a!=None

# Generated at 2022-06-12 18:30:57.895555
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:30:59.254366
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()
# coverage: ignore

# Generated at 2022-06-12 18:31:03.502202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    i = TudouPlaylistIE(url)
    assert i.url == url
    assert i.ie_key() == 'TudouPlaylist'
    assert i.playlist_id() == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:31:12.534015
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test to ensure that the class TudouAlbumIE can be properly constructed with the expected name, file, and URL.

    This is a test so that the constructors of classes used by the test cases don't throw errors.
    """
    tudouAlbumIE = TudouAlbumIE(
        InfoExtractor._downloader,
        'tudou:album',
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    )
    assert tudouAlbumIE.name == 'tudou:album'
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._FILE_NAME == __file__.replace('.pyc', '.py')
    assert tudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:31:16.908743
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    print(tudou_playlist)
    #tudou_playlist._real_extract(url)
    tudou_playlist._download_json(url, 'zzdE77v6Mmo')

# Generated at 2022-06-12 18:31:19.487014
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE(TudouAlbumIE._TESTS)

# Generated at 2022-06-12 18:31:26.414815
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    parser = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert parser.IE_NAME == 'tudou:playlist'
    assert parser._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert parser._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert parser._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert parser._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:31:29.873440
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    result_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    result_expected = 'TudouPlaylistIE'
    result_data = 'zzdE77v6Mmo'
    assert result_expected == TudouPlaylistIE(result_url).IE_NAME, result_url
    assert result_data == TudouPlaylistIE(result_url)._VALID_URL, result_url


# Generated at 2022-06-12 18:31:57.351928
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE(None)

# Generated at 2022-06-12 18:32:01.116902
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Name of the class being tested
	TudouAlbumIE = "TudouAlbumIE"
	# Check if super class is InfoExtractor
	assert inspect.isclass(TudouAlbumIE), TudouAlbumIE + " is not a class."
	# Check if constructor is defined
	assert inspect.isfunction(TudouAlbumIE.__init__), TudouAlbumIE + " constructor is undefined."
	# Check if class constructor is public
	assert inspect.ismethod(TudouAlbumIE.__init__), TudouAlbumIE + " constructor is not public."
	# Check if self is first parameter of constructor
	assert inspect.getargspec(TudouAlbumIE.__init__).args[0]== 'self', TudouAlbumIE + " constructor does not have 'self' as first parameter."

# Generated at 2022-06-12 18:32:11.666418
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor of class TudouPlaylistIE
    # Input:
    #    url: url address of playlist
    url_test = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    playlist_id = "zzdE77v6Mmo"

    # Expected result:
    # playlist_id is same as url
    info_dict = {
        'id': 'zzdE77v6Mmo',
    }

    # Actual result:
    tudou_playlist_test = TudouPlaylistIE(url_test)
    assert tudou_playlist_test._match_id(url_test) == playlist_id
    assert tudou_playlist_test._TESTS[0]['info_dict'] == info_dict


# Generated at 2022-06-12 18:32:14.173995
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
   tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:32:19.602825
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print('Test constructor of class TudouAlbumIE')
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudou_album_ie = TudouAlbumIE(url)
	assert tudou_album_ie.url == url
	assert tudou_album_ie.IE_NAME == 'tudou:album'
	assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	print('Test constructor of class TudouAlbumIE finished')


# Generated at 2022-06-12 18:32:26.116325
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist_ie = TudouPlaylistIE("test")
    tudou_playlist_ie.url = test_url
    tudou_playlist_ie.id = tudou_playlist_ie._match_id(test_url)
    assert tudou_playlist_ie.url == test_url
    assert tudou_playlist_ie.id == "zzdE77v6Mmo"

# Generated at 2022-06-12 18:32:28.343443
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    assert i.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:32:34.428074
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/([\w-]{11})'
    assert TudouAlbumIE()._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:32:41.629435
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    def test_url_match(url):
        assert url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.url = test_url_match
    tudou_playlist_ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:32:45.098702
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    extractor = TudouPlaylistIE()
    (todou_playlist_id) = extractor._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert todou_playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:34:04.909562
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ifilename = 'test_tudou_album_ie.py'
    ie = TudouAlbumIE(ifilename)
    print("# test_TudouAlbumIE")
    for url in ie._TESTS:
        print("In url %s:" % url['url'])
        print("\tIn func _real_extract()")
        pl = ie._real_extract(url['url'])
        print("\tIn func _real_extract(), got playlist id %s" % pl.get('id'))
        print("\tIn func _real_extract(), got playlist entries %d" % len(pl.get('entries')))
        print("\tIn func _real_extract(), got playlist title %s" % pl.get('title'))

# Generated at 2022-06-12 18:34:05.859802
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()

# Generated at 2022-06-12 18:34:16.652456
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import generate_extract_function
    extract_function = generate_extract_function(TudouAlbumIE)
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    tests = _TESTS
    for test in tests:
        url = test['url']
        expected_result = test['info_dict']
        expected_result.update(test)
        result = extract_function(url)
        result_id = result.get('id')

# Generated at 2022-06-12 18:34:22.374848
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    global expect_url
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expect_url = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    playlist_id = 'zzdE77v6Mmo'
    # test if class constructor of TudouPlaylistIE is correct
    TudouPlaylistIE()


# Generated at 2022-06-12 18:34:31.145201
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Given
    tudou_test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_extractor = InfoExtractor()
    # When
    tudou_playlist_ie = info_extractor._call_ies(tudou_test_url,
                                                 downloader=None)
    # Then
    assert tudou_playlist_ie['_type'] == 'playlist'
    assert tudou_playlist_ie['id'] == 'zzdE77v6Mmo'
    assert 'entries' in tudou_playlist_ie
    assert len(tudou_playlist_ie['entries']) == 1


# Generated at 2022-06-12 18:34:33.366747
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._match_id(ie._VALID_URL, ie._VALID_URL ) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:34:34.493065
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()



# Generated at 2022-06-12 18:34:43.651834
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:34:53.888874
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TD.TudouAlbumIE(TD.TudouPlaylistIE(TD.InfoExtractor()))._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TD.TudouAlbumIE(TD.TudouPlaylistIE(TD.InfoExtractor())).IE_NAME == 'tudou:album'
    assert TD.TudouAlbumIE(TD.TudouPlaylistIE(TD.InfoExtractor()))._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:34:55.149591
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.compat_str('1') == '1'


# Generated at 2022-06-12 18:37:35.618271
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylist = TudouPlaylistIE()

# Generated at 2022-06-12 18:37:43.304389
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from unittest import TestCase, TextTestRunner, TestLoader
    class TestTudouAlbumIE(TestCase):
        def setUp(self):
            self.test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
            self.test_album_id = 'v5qckFJvNJg'
            self.tudou_album_ie = TudouAlbumIE()

        def test_TudouAlbumIE(self):
            self.assertEqual(self.tudou_album_ie._match_id(self.test_url), self.test_album_id)
    tests = TestLoader().loadTestsFromTestCase(TestTudouAlbumIE)
    TextTestRunner(verbosity=2).run(tests)

# Generated at 2022-06-12 18:37:44.876699
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url='http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-12 18:37:45.901878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:37:47.998429
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	albumUrl = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	d = TudouAlbumIE(albumUrl)
	assert d

# Generated at 2022-06-12 18:37:51.270385
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo'
        },
        'playlist_mincount': 209,
    }