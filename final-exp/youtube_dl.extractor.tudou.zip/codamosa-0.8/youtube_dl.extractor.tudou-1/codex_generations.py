

# Generated at 2022-06-12 18:27:59.775275
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_IE = TudouPlaylistIE()
	
	# test constructor
	assert tudou_playlist_IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:28:01.291284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'tudou:album' == TudouAlbumIE().IE_NAME

# Generated at 2022-06-12 18:28:10.647159
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS.__len__() == 1)
    assert(TudouPlaylistIE._TESTS[0].get('url') == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0].get('info_dict') == {'id': 'zzdE77v6Mmo'})
    assert(TudouPlaylistIE._TESTS[0].get('playlist_mincount') == 209)


# Generated at 2022-06-12 18:28:14.622775
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/BHzaLDZUWX0.html')
    assert ie._match_id(ie._VALID_URL) == 'BHzaLDZUWX0'

# Generated at 2022-06-12 18:28:21.731502
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'TudouPlaylist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-12 18:28:23.007077
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:28:24.377179
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_ie = TudouPlaylistIE()
	assert test_ie


# Generated at 2022-06-12 18:28:32.790333
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test single video
    url = "http://www.tudou.com/listplay/0Sh3qriNibY.html"
    ie = TudouPlaylistIE()
    playlist_id = ie._match_id(url)
    video_url_list = ie.extract(url)
    assert len(video_url_list) == 1 and video_url_list[0] == url and playlist_id == "0Sh3qriNibY"

    # test playlist
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()
    playlist_id = ie._match_id(url)
    video_url_list = ie.extract(url)

# Generated at 2022-06-12 18:28:43.293365
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # given
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"

    # when
    tudou_playlist_ie = TudouPlaylistIE()

    # then
    assert tudou_playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-12 18:28:48.020057
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():	
	tester = TudouAlbumIE()
	loader = tester._download_json('http://www.tudou.com/tvp/alist.action?acode=abcde12345', 12345)
	assert loader == True
	
#Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:29:03.805472
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouAlbumIE')
    file_upload = open('data_test/tudou_album.json', 'r')
    a = file_upload.read()
    file_upload.close()
    data = ie._parse_json(None, a, 'tudou_album.json')

# Generated at 2022-06-12 18:29:08.730288
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie._match_id(ie._VALID_URL) == 'zzdE77v6Mmo')
    assert(ie.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-12 18:29:09.811936
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)


# Generated at 2022-06-12 18:29:11.930818
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print(TudouAlbumIE())
    print(TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html'))

# Generated at 2022-06-12 18:29:17.500050
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = ie._match_id(url)
    playlist_data = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [ie.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    print(entries)


# Generated at 2022-06-12 18:29:20.330538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    _VALID_URL = ie._VALID_URL
    assert _VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:29:25.606832
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    entries = [self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return self.playlist_result(entries, album_id)

# Generated at 2022-06-12 18:29:35.906870
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    key = "zzdE77v6Mmo"
    assert ie.IE_NAME == "tudou:playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-12 18:29:36.760670
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-12 18:29:43.649669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    album_id = 'v5qckFJvNJg'
    album_data = album._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [album.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    assert album.playlist_result(entries, album_id)

# Generated at 2022-06-12 18:29:56.245499
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()._constructor_test()



# Generated at 2022-06-12 18:30:07.543977
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # check whether it's true if url is a url of type album
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    is_valid = TudouAlbumIE._VALID_URL.match(url)
    assert is_valid
    album_id = is_valid.group('id')
    # print album_id
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    # download the json form of info needed and get the items list
    album_data_json = InfoExtractor._download_json(album_data, album_id)

# Generated at 2022-06-12 18:30:18.147684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album_ie._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}

# Generated at 2022-06-12 18:30:25.505644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Test for create a correct url for playlist id
    assert ie.url_result(playlist_url, 'Tudou', playlist_id, None) == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        '_type': 'Tudou',
        'id': 'zzdE77v6Mmo',
        'title': None,
    }
    # Test for create a correct playlist

# Generated at 2022-06-12 18:30:29.385974
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._TESTS[0] == ie._build_regex(ie._TESTS[0]['url'])[0][1]


# Generated at 2022-06-12 18:30:34.470074
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for constructor of class TudouAlbumIE
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_playlist = TudouAlbumIE()._real_extract(url)
    assert tudou_playlist['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:30:39.005463
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouie = TudouAlbumIE()
    assert tudouie.compat_str == str
    assert tudouie.compat_b == bytes
    assert tudouie.IE_NAME == 'tudou:album'

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-12 18:30:39.618617
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:30:47.193300
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    from .common import gen_extractors_test

    class TestTudouAlbumIE(unittest.TestCase):
        def test_report_unrarities(self):
            extractors = gen_extractors_test([TudouAlbumIE])
            self.assertEquals(extractors[0][0], 'TudouAlbum')

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-12 18:30:54.643780
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
     'info_dict': {'id': 'zzdE77v6Mmo'},
     'playlist_mincount': 209}]

# Generated at 2022-06-12 18:31:23.204389
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert type(TudouPlaylistIE._VALID_URL) == str
    assert TudouPlaylistIE.__name__ == 'TudouPlaylistIE'
    assert type(TudouPlaylistIE.__name__) == str
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert type(TudouPlaylistIE.IE_NAME) == str

# Generated at 2022-06-12 18:31:27.038468
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) > 0


# Generated at 2022-06-12 18:31:28.217147
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    This test is for testing constructor.
    """
    TudouPlaylistIE()

# Generated at 2022-06-12 18:31:36.736237
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._match_id(url) == 'zzdE77v6Mmo'
    playlist_data = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % ie._match_id(url), ie._match_id(url))

# Generated at 2022-06-12 18:31:46.992117
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    assert ie.ie_key() == 'TudouAlbum'
    assert ie.ie_name()

# Generated at 2022-06-12 18:31:51.871109
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TUDOU_ALBUM_URL = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    instance_TudouAlbumIE = TudouAlbumIE(TUDOU_ALBUM_URL, None)
    instance_TudouAlbumIE.extract()


# Generated at 2022-06-12 18:31:55.400560
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test.get_info('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

test_TudouAlbumIE()



# Generated at 2022-06-12 18:32:01.767952
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Tested URL
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    # Create instance of TudouPlaylistIE and extract playlist
    ie = TudouPlaylistIE()
    playlist = ie.extract(url)
    # Check playlist has 209 videos
    assert playlist["_type"] == "playlist" and len(playlist["entries"]) == 209, "Playlist mismatch"
    # Check playlist has been extracted
    if len(playlist["entries"]) > 0:
        assert playlist["entries"][0]["id"] is not None, "Playlist extraction failed"


# Generated at 2022-06-12 18:32:04.841486
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # just for coverage purpose
    e = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg")
    e != None

# Generated at 2022-06-12 18:32:08.766977
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert instance._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    assert instance.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-12 18:33:06.778211
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # construct an instance of class TudouPlaylistIE
    test_tudou_playlist_ie = TudouPlaylistIE('TudouPlaylist')
      # test result of method _real_extract of class _TudouPlaylistIE
    playlist_id = test_tudou_playlist_ie._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:33:16.238683
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    """
    Function: test constructor of class TudouPlaylistIE
    """

    from .TudouPlaylistIE import TudouPlaylistIE

    # Test for url must be str, not list or dict
    with assert_raises(TypeError):
        TudouPlaylistIE([])
    with assert_raises(TypeError):
        TudouPlaylistIE({})

    # Test for invalid url
    with assert_raises(ExtractorError):
        TudouPlaylistIE("www.tudou.com")

    # Test for valid url
    TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Unit test

# Generated at 2022-06-12 18:33:16.930874
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-12 18:33:17.667208
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'TudouAlbumIE' in globals()

# Generated at 2022-06-12 18:33:23.037589
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [
        {
            'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'info_dict': {
                'id': 'v5qckFJvNJg',
            },
            'playlist_mincount': 45,
        }
    ]

    assert ie._match_id(ie._VALID_URL) == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:33:25.693871
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from ..TudouAlbumIE import TudouAlbumIE
    tudouAlbumIE = TudouAlbumIE()


# Generated at 2022-06-12 18:33:30.092773
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudouAlbumIE = TudouAlbumIE()
	assert tudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is 'v5qckFJvNJg'
	

# Generated at 2022-06-12 18:33:32.918410
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_instance = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_instance.extract(url)


# Generated at 2022-06-12 18:33:37.231584
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from tudou.extractor import TudouPlaylistIE
    # TODO: How to make sure the extracted playlist is correct?
    context = TudouPlaylistIE('Tudou', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    result = context._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['playlist_mincount'] == 209


# Generated at 2022-06-12 18:33:44.713477
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

    playlist_data = {
        'items': [
            {'icode': '8cNp-yLcP40', 'kw': '深圳大学'},
            {'icode': '8cNp-yLcP40', 'kw': '深圳大学'},
            {'icode': '8cNp-yLcP40', 'kw': '深圳大学'}
        ]
    }

    tudou_playlist_IE_test = TudouPlaylistIE()
    tudou_playlist_IE_test._download_json = lambda url, playlist_id: playlist_data
    is_instance = tudou_playlist_IE_test._real_ext

# Generated at 2022-06-12 18:35:56.683277
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE(InfoExtractor())
    assert IE.IE_NAME == 'tudou:playlist'
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-12 18:36:03.805638
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict'] == {
        'id': 'v5qckFJvNJg',
    }
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-12 18:36:05.705904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    # Test case: instantiation
    TudouAlbumIE(url, username=None, password=None)

# Generated at 2022-06-12 18:36:09.113176
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._match_id(url) == 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:36:18.890778
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.htm') == None

# Generated at 2022-06-12 18:36:22.158133
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album and tudou_album.IE_NAME == 'tudou:album'
    assert tudou_album.IE_DESC == '土豆网 - 专辑'


# Generated at 2022-06-12 18:36:24.518434
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE();
    #tudouAlbumIE._download_webpage('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'v5qckFJvNJg');

# Generated at 2022-06-12 18:36:25.954942
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-12 18:36:28.647509
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_tudouAlbumIE = TudouAlbumIE()
	print("\nAll tests pass!\n")

# Generated at 2022-06-12 18:36:32.063957
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html');
    TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html');

