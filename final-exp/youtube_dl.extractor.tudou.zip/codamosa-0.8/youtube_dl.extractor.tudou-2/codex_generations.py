

# Generated at 2022-06-12 18:28:01.239011
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case = {'id':'v5qckFJvNJg'}
    tudou = TudouPlaylistIE(url='http://www.tudou.com/albumcover/v5qckFJvNJg.html', **test_case)
    assert tudou.id == test_case['id']
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:28:04.801917
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE(InfoExtractor._downloader)
    testurl = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    albumIE._real_extract(testurl)
    print('Test TudouAlbumIE suceed!')
    

# Generated at 2022-06-12 18:28:06.121394
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert(test != None)

# Generated at 2022-06-12 18:28:13.431077
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert isinstance(t, InfoExtractor)
    assert t.IE_NAME == 'tudou:playlist'
    assert t._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert t._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert t._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert t._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:28:14.815795
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE)


# Generated at 2022-06-12 18:28:21.600660
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    # Try a single page
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    info = ie._real_extract(url)
    assert info["id"] == "zzdE77v6Mmo"
    # Try a multiple pages
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html?spm=a2htv.20009921.pages.2-1"
    info = ie._real_extract(url)
    assert info["id"] == "zzdE77v6Mmo"


# Generated at 2022-06-12 18:28:30.746242
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_tudouPlaylistIE = TudouPlaylistIE()
    # AssertionError: expected 0, got None when test with 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert test_tudouPlaylistIE._real_extract(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html') != None
    # AssertionError: expected 0, got None when test with 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert test_tudouPlaylistIE._real_extract(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html') != 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:28:39.993733
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    instance = TudouPlaylistIE(url)
    assert instance.IE_NAME == "tudou:playlist"
    assert instance._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"
    assert instance._TESTS[0]["url"] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"


# Generated at 2022-06-12 18:28:48.444521
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou = TudouAlbumIE(tudou.TudouAlbumIE)
    tudou.IE_NAME = 'tudou:album'
    tudou._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    tudou._TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

if __name__ == "__main__":
    test_TudouAlbumIE()

# Generated at 2022-06-12 18:28:51.599678
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    x = TudouPlaylistIE(url)

# Generated at 2022-06-12 18:28:55.177208
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-12 18:28:55.696410
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-12 18:28:59.155099
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    urls = [
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html/mylist',
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html/mylist/',
    ]

    for url in urls:
        assert TudouPlaylistIE._match_url(url)


# Generated at 2022-06-12 18:29:01.623559
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		TudouAlbumIE()
	except:
		print("Test failed.")
	else:
		print("Test passed.")

# Generated at 2022-06-12 18:29:02.972812
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('v5qckFJvNJg')

# Generated at 2022-06-12 18:29:09.245720
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Instantiate one instance
    tudouIE = TudouPlaylistIE()
    # Check whether the class is instantiated correctly
    assert tudouIE.IE_NAME == 'tudou:playlist'
    assert tudouIE.ie_key() == 'TudouPlaylist'
    assert tudouIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not tudouIE.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-12 18:29:18.166788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Valid Constructor
    tudou_playlist_IE = TudouPlaylistIE(TudouPlaylistIE._downloader, TudouPlaylistIE._VALID_URL, u'', u'')
    # Assert the constructor
    assert tudou_playlist_IE._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}


# Generated at 2022-06-12 18:29:22.719594
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tu = TudouPlaylistIE()
    info = tu._real_extract(url)
    assert info["id"] == "zzdE77v6Mmo"
    assert len(info["entries"]) == 209


# Generated at 2022-06-12 18:29:27.571570
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:29:34.865698
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('test', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.get_url() == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie.acceptable(ie.get_url())
    assert ie.get_id() == 'zzdE77v6Mmo'
    assert ie.get_name() == 'tudou:playlist'



# Generated at 2022-06-12 18:29:44.155128
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import sys
	sys.path.append('../')
	print(
        (TudouAlbumIE()._real_extract(
        'http://www.tudou.com/albumcover/Q2TFfGS1ZBk.html'))
            )


# Generated at 2022-06-12 18:29:46.464534
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)
    return True


# Generated at 2022-06-12 18:29:52.038371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE();
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'


# Generated at 2022-06-12 18:29:58.222271
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE()
    assert e.IE_NAME == 'tudou:album'
    assert e._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert e._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]



# Generated at 2022-06-12 18:30:08.517176
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    # Not valid URL
    TudouPlaylistIE('http://www.tudou.com/programs/view/zW8SUl-GCbM/?fr=rec1', 'Tudou')
    # Valid URL
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'Tudou')
    # Expect error with invalid id
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'Tudou', '12345678901')
    # Expect error with empty id

# Generated at 2022-06-12 18:30:17.657318
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-12 18:30:20.199663
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(test_url)


# Generated at 2022-06-12 18:30:21.274993
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    unittest.main()

# Generated at 2022-06-12 18:30:22.651890
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'



# Generated at 2022-06-12 18:30:28.320972
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    result = TudouAlbumIE()._real_extract(test_url)
    assert(len(result['entries']) == 45)

# Generated at 2022-06-12 18:30:46.023019
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    ie._VALID_URL = TudouAlbumIE._VALID_URL
    ie._TESTS = TudouAlbumIE._TESTS
    ie.IE_NAME = 'tudou:album'
    w = ie._build_url_result('http://www.tudou.com/programs/view/FkLnfPAPVYE/',
            'Tudou', 'FkLnfPAPVYE',
            'iwara')
    assert w['id'] == 'FkLnfPAPVYE',w['id']
    assert w['ie_key'] == 'Tudou',w['ie_key']
    assert w['title'] == 'iwara',w['title']

# Generated at 2022-06-12 18:30:47.546772
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou = TudouAlbumIE()
	tudou


# Generated at 2022-06-12 18:30:52.764313
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    arguments = {
        'url':'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'outtmpl':'%(id)s%(ext)s',
        'usenetrc':False,
        'verbose':True,
        }
    tudouAlbumIE = TudouAlbumIE()
    tudouAlbumIE.download(arguments)

# Generated at 2022-06-12 18:30:56.277893
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
  tudou_playlist_info = TudouPlaylistIE()._real_extract(url)

# Generated at 2022-06-12 18:31:04.070024
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-12 18:31:12.152716
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_cases = [
        {
            'url' : 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
            'playlist_mincount' : 45,
        },
        {
            'url' : 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
            'playlist_mincount' : 45,
        },
    ]

    for test_case in test_cases:
        tudou_album_ie = TudouAlbumIE(test_case['url'])
        assert tudou_album_ie.playlist_mincount == test_case['playlist_mincount']

# Generated at 2022-06-12 18:31:16.533029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_TudouAlbumIE = TudouAlbumIE();
	assert test_TudouAlbumIE is not None, "Failed to create test_TudouAlbumIE"
	assert isinstance(test_TudouAlbumIE, TudouAlbumIE) , "test_TudouAlbumIE is not an instance of TudouAlbumIE class"


# Generated at 2022-06-12 18:31:17.657030
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    print(ie._VALID_URL)


# Generated at 2022-06-12 18:31:19.330662
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	return True

# Generated at 2022-06-12 18:31:25.640217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(url)
    if tudou_album_ie.url != url:
        print("url of '%s' is not equal to '%s'" % (tudou_album_ie.url, url))
    if tudou_album_ie.ie_key != 'Tudou':
        print("ie_key of '%s' is not equal to '%s'" % (tudou_album_ie.ie_key, 'Tudou'))


# Generated at 2022-06-12 18:31:55.571017
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouPlaylist = TudouPlaylistIE()
	assert tudouPlaylist._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"


# Generated at 2022-06-12 18:31:56.901298
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance != None

# Generated at 2022-06-12 18:32:05.062158
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import urllib2
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    testObj = TudouPlaylistIE()._real_extract(url)
    assert testObj.get("id") == "zzdE77v6Mmo"
    response = urllib2.urlopen(url)
    sourceCode = response.read()
    assert sourceCode.find(testObj.get("id")) > 0


# Generated at 2022-06-12 18:32:13.543908
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE_obj=TudouPlaylistIE(None)
    assert tudouPlaylistIE_obj.ie_key() == 'tudou:playlist'
    assert tudouPlaylistIE_obj.ie_name() == 'tudou'
    assert tudouPlaylistIE_obj.suitable(None) == False
    assert tudouPlaylistIE_obj.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    assert tudouPlaylistIE_obj.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo') == False


# Generated at 2022-06-12 18:32:15.504574
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # initialize a constructor of class TudouAlbumIE
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    
    # test ent

# Generated at 2022-06-12 18:32:25.364982
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert(-1 != url.find('www.tudou.com'))
    assert(-1 != url.find('albumplay'))
    # Only one instance of class InfoExtractor is created.
    albumIE = TudouAlbumIE(InfoExtractor())
    # instance method _real_extract is called.
    albumIE._real_extract(url)
    # This will print 'http://www.tudou.com/programs/view/%s' % item['icode']

# Generated at 2022-06-12 18:32:31.321572
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_obj = TudouPlaylistIE(test_url)
    test_obj.playlist_result
    try:
        assert True
    except:
        print ('Test Failed.')
        raise



# Generated at 2022-06-12 18:32:34.296481
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    

# Generated at 2022-06-12 18:32:39.681638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing TudouPlaylistIE...")
    TudouPlaylistIE = __import__("tudou.py", fromlist=['TudouPlaylistIE'])
    ie = TudouPlaylistIE('elemeFE', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'TudouPlaylistIE'
    assert ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:32:46.263837
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    assert ie._real_extract('zzdE77v6Mmo') == ''


# Generated at 2022-06-12 18:33:54.405655
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    i.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:33:58.726040
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    ie = TudouPlaylistIE()
    obj = ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    if (obj['id']) != 'zzdE77v6Mmo':
        raise AssertionError('test_TudouPlaylistIE failed !!!')


# Generated at 2022-06-12 18:34:02.658806
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = 'http://www.tudou.com/albumcover/I7sCcZPlT2Q.html'
    tudou_album = TudouAlbumIE()
    assert tudou_album._match_id(album) == 'I7sCcZPlT2Q'

# Generated at 2022-06-12 18:34:04.924532
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    Test Constructor of class TudouPlaylistIE
    '''
    tudou_playlist_ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert isinstance(tudou_playlist_ie, InfoExtractor)
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:34:06.593137
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = TudouIE._VALID_URL
    TudouPlaylistIE(url)


# Generated at 2022-06-12 18:34:11.766170
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    urls = ['http://www.tudou.com/listplay/zzdE77v6Mmo.html']
    for url in urls:
        video_playlist = TudouPlaylistIE(url)

# Generated at 2022-06-12 18:34:18.137276
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    u1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    u2 = 'http://www.tudou.com/listplay/4jJW7N8bvfQ.html'
    instance1 = TudouPlaylistIE()
    instance2 = TudouPlaylistIE()
    assert instance1.suitable(u1) == instance2.suitable(u2)


# Generated at 2022-06-12 18:34:20.564340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:34:23.162714
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    

# Generated at 2022-06-12 18:34:31.018701
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                          'info_dict': {'id': 'zzdE77v6Mmo',},
                          'playlist_mincount': 209, 
                          }]


# Generated at 2022-06-12 18:36:57.007536
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    b = TudouAlbumIE(InfoExtractor())
    assert(b)


# Generated at 2022-06-12 18:37:00.066100
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize test
    test = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    
    # Call function
    result = test._match_id(url)

    # Assert
    assert result == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:37:03.914843
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    playlist_id = 'v5qckFJvNJg'
    album_data = tudou_album_ie._download_json('http://www.tudou.com/tvp/alist.action?acode=' + playlist_id, playlist_id)
    assert album_data['items'][0]['kw'] == u'金星秀20161028'


# Generated at 2022-06-12 18:37:04.533621
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:37:07.909815
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html");
    expect_url = "http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg"
    expect_id = "v5qckFJvNJg"
    assert(info_extractor.url == expect_url);
    assert(info_extractor._match_id(info_extractor.url) == expect_id);

# Generated at 2022-06-12 18:37:10.546784
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert 'TudouAlbumIE(url=%s)' % url == repr(TudouAlbumIE(url))

# Generated at 2022-06-12 18:37:14.316068
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_tudou import test_TudouIE
    test_TudouIE(TudouPlaylistIE, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'tudou:playlist')
    test_TudouIE(TudouAlbumIE, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'tudou:album')

# Generated at 2022-06-12 18:37:19.213970
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	try:
		ie.url_result(url, 'Tudou', 'zzdE77v6Mmo')
	except:
		assert False
	else:
		assert True


# Generated at 2022-06-12 18:37:23.883346
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')


# Generated at 2022-06-12 18:37:25.530016
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()