

# Generated at 2022-06-12 18:27:55.714684
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:27:57.840506
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    success = True
    try:
        TudouPlaylistIE()
    except Error:
        success = False
    assert success

# Generated at 2022-06-12 18:27:59.915568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    plIEInstance = TudouPlaylistIE()
    assert type(plIEInstance) is TudouPlaylistIE

# Generated at 2022-06-12 18:28:02.239176
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:28:06.163637
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie != None
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-12 18:28:09.280829
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()



# Generated at 2022-06-12 18:28:13.599740
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE()
    print(obj._match_id(url))
    print(obj._real_extract(url))
    print(obj._real_extract(url)['entries'])

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-12 18:28:17.403267
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Confirm that the constructor of TudouPlaylistIE can run as expected
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url) == True, 'Can not run the constructor of class TudouPlaylistIE'


# Generated at 2022-06-12 18:28:26.513751
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Construct an instance of the class
    ie = TudouPlaylistIE()
    # Test the result for a Playlist URL
    assert ie._TESTS
    # Test the result for a Playlist URL
    res = ie.url_result('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'tudou:playlist')
    assert res == {
        '_type': 'url_transparent',
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'ie_key': 'TudouPlaylist',
        'id': 'zzdE77v6Mmo',
    }


# Generated at 2022-06-12 18:28:27.467568
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(1, 1)

# Generated at 2022-06-12 18:28:36.536244
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('QQMusic', 'http://www.tudou.com/albumcover/GztSk5v5bo8.html')


# Generated at 2022-06-12 18:28:45.349887
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i1 = TudouPlaylistIE()
    i1.IE_NAME == 'tudou:playlist'
    i1.URL_REGEX == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    i1.TESTS[0].URL == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    i1.TESTS[0].INFO_DICT['id'] == 'zzdE77v6Mmo'
    i1.TESTS[0].PLAYLIST_MINCOUNT == 209


# Generated at 2022-06-12 18:28:53.822518
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlist_id='zzdE77v6Mmo'
	url='http://www.tudou.com/listplay/%s.html' % playlist_id
	t=TudouPlaylistIE(url)
	assert(t._match_id(url)==playlist_id)
	playlist_data=t._download_json('http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)

# Generated at 2022-06-12 18:28:56.284829
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert isinstance(album, TudouAlbumIE)

# Generated at 2022-06-12 18:29:02.292678
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_test = TudouPlaylistIE("www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-12 18:29:03.805026
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for the correct constructor for class TudouPlaylistIE
    TudouPlaylistIE


# Generated at 2022-06-12 18:29:06.971624
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/k1mplNYGd_c.html'
    result = TudouAlbumIE()._real_extract(url)
    assert result['id'] == 'k1mplNYGd_c'

# Generated at 2022-06-12 18:29:12.399435
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE(InfoExtractor()).suitable(test_url)
    get_info = TudouPlaylistIE(InfoExtractor())._real_extract(test_url)
    assert get_info["id"] == 'zzdE77v6Mmo'
    assert get_info["title"] == 'zzdE77v6Mmo'
    assert len(get_info["entries"]) == 209


# Generated at 2022-06-12 18:29:18.190405
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    result = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert (result.IE_NAME == "tudou:playlist")
    assert(result._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert result._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert result._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert result._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-12 18:29:22.719252
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_info_extractor = TudouAlbumIE()
    expected_id = 'v5qckFJvNJg'
    actual_id = album_info_extractor._match_id(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    if expected_id != actual_id:
        assert False

# Generated at 2022-06-12 18:29:38.670597
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    PL = TudouPlaylistIE()
    assert PL._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:29:41.430354
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE(None, 'Tudou', 'v5qckFJvNJg', 'Comedy', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:29:44.118308
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#test_TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	pass

# Generated at 2022-06-12 18:29:46.397424
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouplaylist = TudouPlaylistIE('tudou:playlist')
	expected = 'tudou:playlist'
	assert tudouplaylist.IE_NAME == expected


# Generated at 2022-06-12 18:29:49.116777
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:29:57.770828
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import fake_urlopen
    with fake_urlopen(body=bytes(
        '{"items": [{"icode": "1234", "kw": "xyz"}, {"icode": "1245", "kw": "abc"}]}',
        'utf-8')):
        ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
        assert ie.extract()['_type'] == 'url_transparent'
        assert ie.extract()['url'] == 'http://www.tudou.com/programs/view/1234'
        assert ie.extract()['ie_key'] == 'Tudou'
        assert ie.extract()['id'] == '1234'

# Generated at 2022-06-12 18:30:00.415557
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-12 18:30:09.199210
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist = TudouPlaylistIE({})
	assert tudou_playlist.IE_NAME == "tudou:playlist"
	assert tudou_playlist.IE_DESC == "tudou.com"
	assert "tudou:playlist" in tudou_playlist._WORKING
	assert "tudou:album" in tudou_playlist._WORKING

# Generated at 2022-06-12 18:30:18.690442
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  assert len(TudouPlaylistIE._TESTS) == 1
  for _i in range(len(TudouPlaylistIE._TESTS)):
    assert len(TudouPlaylistIE._TESTS[_i]) == 3
  assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
  assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
  assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:30:22.042797
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-12 18:30:35.871679
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(info_dict={})

# Generated at 2022-06-12 18:30:39.763859
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE("https://www.tudou.com/albumcover/v5qckFJvNJg.html", "Tudou")
    except:
        print("TudouAlbumIE constructor test fail.")


# Generated at 2022-06-12 18:30:41.622297
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert str(TudouAlbumIE) == '<class \'youtube_dl.extractor.tudou.TudouAlbumIE\'>'

# Generated at 2022-06-12 18:30:47.192117
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	assert ie._match_id(url) == 'v5qckFJvNJg'


# Generated at 2022-06-12 18:30:51.041833
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	tudouplaylist = TudouPlaylistIE()
	assert tudouplaylist._match_id(valid_url) == u'zzdE77v6Mmo'


# Generated at 2022-06-12 18:30:56.272750
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    For testing method of TudouAlbumIE
    """
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

    tudou_album = TudouAlbumIE()
    tudou_album._real_extract(_TESTS[0]['url'])



# Generated at 2022-06-12 18:31:01.244138
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:31:05.690171
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    album_data = _download_json(
        'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)
    entries = [
        self.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    return self.playlist_result(entries, album_id)


# Generated at 2022-06-12 18:31:08.153967
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE(TudouAlbumIE._VALID_URL) is not None

# Generated at 2022-06-12 18:31:16.624030
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import pprint
    from .tudou import TudouAlbumIE
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-12 18:31:48.305431
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None, None)
    assert ie


# Generated at 2022-06-12 18:31:55.137544
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test whether album page is parsed correctly
    assert TudouAlbumIE()._match_id(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert TudouAlbumIE()._match_id(
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:31:56.160604
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE

# Generated at 2022-06-12 18:32:02.174792
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_album = TudouAlbumIE()
    assert tudou_album.IE_NAME == "tudou:album"
    assert tudou_album.VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"
    assert tudou_album._real_initialize() == None
    assert tudou_album._real_extract(test_url)["id"] == "v5qckFJvNJg"

# Generated at 2022-06-12 18:32:05.245466
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    print('tudou_album_ie: %s' % tudou_album_ie)


# Generated at 2022-06-12 18:32:08.722028
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html',{'id': 'v5qckFJvNJg'},{'playlist_mincount': 45} )

# Generated at 2022-06-12 18:32:15.012948
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE_NAME = 'tudou:album'
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    _TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:32:24.903829
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().get_domain() == 'www.tudou.com'
    assert TudouAlbumIE().init().get_domain() == 'www.tudou.com'
    assert TudouAlbumIE()._extract_domain() == 'www.tudou.com'
    assert TudouAlbumIE()._extract_domain('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'www.tudou.com'
    #assert TudouAlbumIE()._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:32:26.921775
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(test_url)

# Generated at 2022-06-12 18:32:27.942782
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-12 18:33:48.862635
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    with open ('test_TudouPlaylistIE.json','r') as f:
        tudou_playlist_data = json.load(f)
    tudou_playlist_instance = TudouPlaylist(tudou_playlist_data,'1234')
    assert tudou_playlist_instance.title == '海神之歌 第一季 第35集 海神之歌 第一季 第35集'
    assert tudou_playlist_instance.video_id == '800770432'
    assert tudou_playlist_instance.album_id == '1234'
    assert tudou_playlist_instance.uploader == '蓝语音'
    assert tudou_playlist_instance.uploader

# Generated at 2022-06-12 18:33:57.374720
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

# Generated at 2022-06-12 18:34:03.088426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie.name == 'Tudou'
    assert ie.playlist_mincount == 45

# Generated at 2022-06-12 18:34:08.245049
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.name == 'tudou:playlist'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-12 18:34:17.963520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id
    entries = [self.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in album_data['items']]
    playlist_result = self.playlist_result(entries, album_id)
    print(playlist_result)

# Generated at 2022-06-12 18:34:20.413669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        obj = TudouAlbumIE()
        obj = TudouPlaylistIE()
    except Exception as e:
        assert False, "%s" % e
    assert True

# Generated at 2022-06-12 18:34:23.649578
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    extractor = TudouPlaylistIE()
    try:
        extractor.download('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except:
        assert False
    assert True


# Generated at 2022-06-12 18:34:32.338135
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test tuple of the constructor
    t_result = TudouPlaylistIE._VALID_URL
    assert t_result[0] is str('https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html')
    assert t_result[1] is str('TudouPlaylistIE')
    # Test _TESTS of the constructor
    t_result = TudouPlaylistIE._TESTS
    assert t_result[0] is dict({'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209})


# Generated at 2022-06-12 18:34:34.256554
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(album.ie_name, album.ie_key)

# Generated at 2022-06-12 18:34:39.366009
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlistIE = TudouPlaylistIE()
    assert playlistIE.IE_NAME == 'tudou:playlist'
    assert playlistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:37:31.919294
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_ie is not None
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:37:33.196022
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie


# Generated at 2022-06-12 18:37:34.964679
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE()
    i = constructor
    assert(i)

# Generated at 2022-06-12 18:37:42.276101
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    list_play_info_extractor = TudouPlaylistIE()
    assert list_play_info_extractor.IE_NAME == 'tudou:playlist'
    assert list_play_info_extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert list_play_info_extractor._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-12 18:37:44.557382
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize a new instance of class TudouAlbumIE
    touAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:37:50.843007
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert(tudouAlbumIE.IE_NAME == 'tudou:album')
    assert(tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(tudouAlbumIE._TESTS[0] == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45})
    
test_TudouAlbumIE()