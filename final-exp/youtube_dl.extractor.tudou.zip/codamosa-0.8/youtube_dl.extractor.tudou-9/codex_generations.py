

# Generated at 2022-06-12 18:27:55.203179
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()

# Generated at 2022-06-12 18:27:56.190229
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()

# Generated at 2022-06-12 18:28:00.133048
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE()
    assert td._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-12 18:28:05.199013
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert tudouAlbumIE.IE_NAME == 'tudou:album'
    assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(tudouAlbumIE._TESTS) == 1
    

# Generated at 2022-06-12 18:28:09.677106
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tuple_info = InfoExtractor._search_regex(TudouPlaylistIE._VALID_URL,
        url, 'tudou')
    assert tuple_info[1] == 'zzdE77v6Mmo'
    assert isinstance(tuple_info, tuple)



# Generated at 2022-06-12 18:28:15.619739
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    from .test import MockIE

    # Build a fake instance of an InfoExtractor and one of a MockIE to test it
    ifilter = InfoExtractor()
    fakeMockIE = MockIE(ifilter)

    # Create a fake object of the class TudouPlaylistIE
    tudouplaylistie = fakeMockIE._TudouPlaylistIE()

    # Create a set of fake objects
    fake_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    fake_id = 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:28:19.351411
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# Use youtube as example
	url = 'https://www.youtube.com/watch?v=GhN7-oHUOeY'
	ie = YoutubeIE(url)
	ie.extract() # page_url, ie_key, video_id


#test_TudouAlbumIE()



# Generated at 2022-06-12 18:28:22.594866
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Unit test for constructor of class TudouPlaylistIE

    ie = TudouPlaylistIE()
    assert ie.ie_key() == 'TudouPlaylist'
    assert ie.ie_name() == 'tudou:playlist'


# Generated at 2022-06-12 18:28:25.608513
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    assert a._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert a._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]
    assert a._REAL_URL
    assert a.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:28:28.720387
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    Playlist = TudouPlaylistIE()
    t = Playlist.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert t == True


# Generated at 2022-06-12 18:28:38.453302
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE(TudouPlaylistIE.ie_key())
    assert(x.ie_key() == TudouPlaylistIE.ie_key())

# Generated at 2022-06-12 18:28:39.803431
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('Tudou') is not None


# Generated at 2022-06-12 18:28:49.679270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import TudouAlbumIE
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-12 18:28:52.468746
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE("https://www.tudou.com/albumcover/v5qckFJvNJg.html")
    

# Generated at 2022-06-12 18:28:53.954688
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    assert isinstance(IE, TudouAlbumIE)

# Generated at 2022-06-12 18:29:02.895030
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    u = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    t = TudouAlbumIE()
    assert (t._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert (t._TESTS[0]['url'] == u)
    assert (t._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg')
    assert (t._TESTS[0]['playlist_mincount'] == 45)

# Generated at 2022-06-12 18:29:03.731026
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return TudouPlaylistIE()

# Generated at 2022-06-12 18:29:06.116687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    e = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert type(e) == TudouAlbumIE


# Generated at 2022-06-12 18:29:15.055665
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouPlaylistIE = TudouPlaylistIE('TudouPlaylistIE', 'https://www.tudou.com/listplay/zzdE77v6Mmo.html')
	tudouPlaylistIE._real_extract('https://www.tudou.com/listplay/zzdE77v6Mmo.html')
	assert tudouPlaylistIE._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:29:18.166582
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
	info = TudouAlbumIE()._real_extract(url)
	return info

# Generated at 2022-06-12 18:29:26.083993
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    info_extractor = TudouAlbumIE()

# Generated at 2022-06-12 18:29:27.370090
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE()
	assert obj


# Generated at 2022-06-12 18:29:37.530149
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import fake_urlopen
    from .common import dict_to_bytes

# Generated at 2022-06-12 18:29:41.691336
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert i.__dict__['_VALID_URL'] == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:29:43.026931
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor = TudouAlbumIE()
    assert constructor.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:29:44.660509
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert test_TudouPlaylistIE is not None
    

# Generated at 2022-06-12 18:29:54.791775
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-12 18:29:55.922979
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:29:58.833138
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html', {})

# Generated at 2022-06-12 18:30:02.933468
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	r = TudouAlbumIE(Unicode(r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'))

# Generated at 2022-06-12 18:30:19.933497
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)



# Generated at 2022-06-12 18:30:23.881228
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/-Mvf8xMx5eU.html'
    ie = TudouPlaylistIE()
    playlist_id = ie._match_id(url)
    assert playlist_id == '-Mvf8xMx5eU'
    assert ie.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-12 18:30:26.914340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'playlist_mincount' in TudouPlaylistIE(TudouPlaylistIE.ie_key())._TESTS[0]


# Generated at 2022-06-12 18:30:29.561435
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE(InfoExtractor(downloader=None)).IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:30:31.312519
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    x.url_result("http://www.tudou.com", "Tudou", "id", "title")

# Generated at 2022-06-12 18:30:33.224918
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    p = TudouPlaylistIE()
    p._download_json(url)

# Generated at 2022-06-12 18:30:42.124222
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('test tudou album')
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    playlist_id = "v5qckFJvNJg"
    tudou_playlist = TudouAlbumIE()
    playlist_data = tudou_playlist._download_json('http://www.tudou.com/tvp/alist.action?acode=%s' % playlist_id, playlist_id)
    entries = [tudou_playlist.url_result('http://www.tudou.com/programs/view/%s' % item['icode'], 'Tudou', item['icode'], item['kw'])
    for item in playlist_data['items']]
    playlist = tudou_playlist

# Generated at 2022-06-12 18:30:52.817984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    album.IE_NAME = 'tudou:album'
    album.IE_DESC = '土豆 - 全球视频第一品牌'
    album._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    album._TESTS = [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    # test

# Generated at 2022-06-12 18:30:59.735919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE({},'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:31:03.580018
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:31:36.634593
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #nothing to test
    pass


# Generated at 2022-06-12 18:31:46.963172
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    'Constructor for class TudouPlaylistIE'
    tudou_list = TudouPlaylistIE("https://www.tudou.com")
    assert tudou_list.ie_key() is 'TudouPlaylist'
    assert tudou_list.ie_name() is 'tudou:playlist'
    assert tudou_list._VALID_URL is r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_list._TESTS[0]['url'] is 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-12 18:31:47.802368
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()

# Generated at 2022-06-12 18:31:50.789270
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:31:52.564120
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-12 18:32:01.072703
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test1 = {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    test2 = {
        'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    album_id = 'v5qckFJvNJg'

# Generated at 2022-06-12 18:32:02.943880
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.get_class() == TudouPlaylistIE


# Generated at 2022-06-12 18:32:12.518722
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	assert ie.IE_NAME == 'tudou:playlist'
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert len(ie._TESTS) == 1
	assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
	assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:32:13.386297
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    def test_url_result(self):
        pass

# Generated at 2022-06-12 18:32:18.759496
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    import os
    import logging
    from tudou_downloader import TudouAlbumIE
    ie = TudouAlbumIE()
    assert isinstance(ie, TudouAlbumIE) == True
    #assert ie._real_extract("http://www.tudou.com/listplay/3qOdJzKjOQM.html")
    logging.warning("test_TudouAlbumIE() passed.")
    return


# Generated at 2022-06-12 18:33:36.420485
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('Tudou')
    assert ie.name == 'Tudou'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'


# Generated at 2022-06-12 18:33:38.838875
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert instance.name == 'TudouPlaylistIE'
    assert instance.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'



# Generated at 2022-06-12 18:33:40.272694
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    print('test start')
    tudou_album = TudouAlbumIE()
    print(tudou_album)

# Generated at 2022-06-12 18:33:43.074699
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_ie = TudouPlaylistIE(TudouPlaylistIE.IE_NAME, TudouPlaylistIE.IE_DESC)
    assert test_ie.name == "TudouPlaylistIE"
    assert test_ie.description == "tudou:playlist"
    assert test_ie.ie_key() == "tudou:playlist"
    assert test_ie.suitable("https://www.tudou.com/listplay/zzdE77v6Mmo.html") == True


# Generated at 2022-06-12 18:33:49.293743
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check if constructor of class TudouPlaylistIE is valid with valid input
    example_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]
    assert tudou

# Generated at 2022-06-12 18:33:53.981695
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # TODO: make a test case for playlist length
    tudou_playlist_ie = TudouPlaylistIE()
    result = tudou_playlist_ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result['id'] == 'zzdE77v6Mmo'
    assert len(result['entries']) == 209


# Generated at 2022-06-12 18:34:02.375809
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    global TudouPlaylistIE
    class TestTudouPlaylistIE(unittest.TestCase):
        def test_instance(self):
            obj = TudouPlaylistIE('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')
            self.assertIsInstance(obj, TudouPlaylistIE)
            self.assertEqual(obj.IE_NAME, 'tudou:playlist')
        
    tudou_playlist_suite = unittest.TestLoader().loadTestsFromTestCase(TestTudouPlaylistIE)
    unittest.TextTestRunner().run(tudou_playlist_suite)


# Generated at 2022-06-12 18:34:03.017230
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(dict())
    assert ie is not None

# Generated at 2022-06-12 18:34:03.926615
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    return TudouPlaylistIE(InfoExtractor())


# Generated at 2022-06-12 18:34:04.981041
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TD = TudouAlbumIE()

# Generated at 2022-06-12 18:36:56.054482
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE_instance = TudouPlaylistIE(
        TudouPlaylistIE.ie_key(), TudouPlaylistIE._VALID_URL)
    assert isinstance(TudouPlaylistIE_instance, InfoExtractor)
    assert TudouPlaylistIE_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE_instance.IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE_instance.ie_key() == 'tudou:playlist'
    assert TudouPlaylistIE_instance.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    assert Tud

# Generated at 2022-06-12 18:36:57.076087
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert type(TudouAlbumIE().playlist_mincount) == int

# Generated at 2022-06-12 18:36:58.440979
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 'tudou:album' == TudouAlbumIE._VALID_URL

# Generated at 2022-06-12 18:36:59.865235
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize
    tue = TudouAlbumIE()

    # No exception should be raised when created.
    assert True


# Generated at 2022-06-12 18:37:00.568858
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:37:01.372167
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:37:02.958700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album.VALID_URL == album._VALID_URL

# Generated at 2022-06-12 18:37:06.389843
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # test for already downloaded video
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

    pass

# Generated at 2022-06-12 18:37:07.075552
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()


# Generated at 2022-06-12 18:37:09.598031
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/plist/p/l138420971.html?iid=74970201'
    TudouPlaylistIE(url)
