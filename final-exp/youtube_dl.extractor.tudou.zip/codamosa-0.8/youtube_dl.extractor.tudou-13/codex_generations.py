

# Generated at 2022-06-12 18:28:02.141656
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]



# Generated at 2022-06-12 18:28:11.255049
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    s = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert (s._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (s.IE_NAME == 'tudou:playlist')
    assert (s._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'})
    assert (s._TESTS[0]['playlist_mincount'] == 209)
    assert (s._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:28:17.077182
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # valid url
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    # create class
    TudouAlbumIE(TudouAlbumIE, url)
    # invalid url
    url = 'https://www.youtube.com/watch?v=v5qckFJvNJg'
    # create class
    TudouAlbumIE(TudouAlbumIE, url)

# Generated at 2022-06-12 18:28:19.351339
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from . import _playlist_tests as playlist_tests
    playlist_tests.test_playlist_constructor(TudouPlaylistIE, 'tudou:playlist')


# Generated at 2022-06-12 18:28:21.400223
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:28:22.308421
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor = 'TudouPlaylistIE()'
    return constructor

# Generated at 2022-06-12 18:28:23.409155
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print('enter test_TudouAlbumIE\n')
	class_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-12 18:28:26.942016
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.website.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._VALID_URL == url
    assert TudouAlbumIE._TESTS[0]['url'] == url

# Generated at 2022-06-12 18:28:33.902929
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing constructor of class TudouPlaylistIE\n")
    # Constructor with no valid url
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    # Test with a correct url
    playlistIE = TudouPlaylistIE(url)

    assert playlistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlistIE.IE_NAME == 'tudou:playlist'
    assert playlistIE.playlist == []
    assert playlistIE.playlist_id == ""
    assert playlistIE.url == url
    

# Generated at 2022-06-12 18:28:41.045680
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html');
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:28:52.898666
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TPPIE = TudouPlaylistIE(None)
    assert TPPIE.name == 'tudou:playlist'
    assert TPPIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(TPPIE._TESTS) == 1
    assert TPPIE._TESTS[0].get('url') == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TPPIE._TESTS[0].get('info_dict').get('id') == 'zzdE77v6Mmo'
    assert TPPIE._TESTS[0].get('playlist_mincount') == 209


# Generated at 2022-06-12 18:28:59.672956
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    import requests
    class TestTudouPlaylistIE(unittest.TestCase):
        def test_TudouPlaylistIE_constructor(self):
            try:
                tudou_playlist = TudouPlaylistIE()
                self.assertEqual(type(tudou_playlist),TudouPlaylistIE)
                self.assertNotEqual(type(tudou_playlist),requests.Response)
            except Exception as e:
                raise e
            
    unittest.main()

# Generated at 2022-06-12 18:29:01.876984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'


# Generated at 2022-06-12 18:29:05.780018
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_utils import list_testcases
    from .test_utils import get_testcases

    list_testcases(TudouPlaylistIE)
    get_testcases(TudouPlaylistIE)


# Generated at 2022-06-12 18:29:07.416842
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# TODO: Remove these comments and implement the unit test
	assert False, "Unit test not yet implemented"

# Generated at 2022-06-12 18:29:11.692578
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 1 == len(TudouPlaylistIE._TESTS)
    assert 1 == len(TudouPlaylistIE._TESTS[0])
    assert 'url' == TudouPlaylistIE._TESTS[0].keys()[0]
    assert 4 == len(TudouPlaylistIE._TESTS[0].values())
    assert 'val' == TudouPlaylistIE._TESTS[0].values()[0]

# Generated at 2022-06-12 18:29:14.850336
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE("http://www.tudou.com/albumplay/Abc14mX0jUc.html")


# Generated at 2022-06-12 18:29:18.379780
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    testobj = TudouAlbumIE()
    assert testobj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:29:26.060397
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("\nUnit test for constructor of class TudouPlaylistIE")
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	plist = TudouPlaylistIE()
	assert plist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert plist._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]

# Generated at 2022-06-12 18:29:34.062509
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import pickle
    urls = [u'http://www.tudou.com/listplay/zzdE77v6Mmo.html', u'http://www.tudou.com/listplay/zzdE77v6Mmo.html.html']
    for url in urls:
        ie = TudouPlaylistIE(url)
        pickle.dump(ie, open('../test/test_log/test_%s' % ie.get_method(), 'wb'))

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-12 18:29:42.060651
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.suitable(url) == True
    assert tudou_album_ie._match_id(url) == 'v5qckFJvNJg'
    assert tudou_album_ie._real_extract(url) is not None

# Generated at 2022-06-12 18:29:43.650564
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie != None


# Generated at 2022-06-12 18:29:47.192590
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 1


# Generated at 2022-06-12 18:29:49.773126
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	i = TudouPlaylistIE()

# Generated at 2022-06-12 18:29:58.118891
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouIE
    assert issubclass(TudouAlbumIE, InfoExtractor)
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE.IE_DESC == '土豆网 - 专辑'
    assert TudouAlbumIE._WORKING
    assert TudouAlbumIE._TYPE == {
        'id': 'tudou:album',
        'extractors': [{
            'ie_key': 'Tudou',
            're': r'https?://(?:www\.)?tudou\.com/programs/view/(?P<id>[\w-]+)',
        }],
    }
    assert TudouAlbumIE._VAL

# Generated at 2022-06-12 18:30:00.104421
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()

# Generated at 2022-06-12 18:30:06.778254
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-12 18:30:08.492292
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('id','title','thumbnail','view_count','upload_time','description','age_limit','category','tags','duration','creator','uploader','uploader_url','extractor_key')

# Generated at 2022-06-12 18:30:10.797071
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('', '')

# Generated at 2022-06-12 18:30:20.387345
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE().ie_key()
    assert ie == TudouPlaylistIE._VALID_URL
    url_result = TudouPlaylistIE()._real_extract(url)
    id = url_result[0]
    assert id == "zzdE77v6Mmo"
    link = url_result[1]
    assert link[0] == "http://www.tudou.com/programs/view/zzdE77v6Mmo"
    assert link[1] == "Tudou"
    assert link[2] == "zzdE77v6Mmo"
    assert link[3] == "zzdE77v6Mmo"
    playlist_id

# Generated at 2022-06-12 18:30:27.176900
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()

# Generated at 2022-06-12 18:30:30.636014
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	pIE = TudouPlaylistIE()

# Generated at 2022-06-12 18:30:31.880681
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE().IE_NAME == 'TudouPlaylistIE'


# Generated at 2022-06-12 18:30:35.217515
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    result = TudouPlaylistIE()._real_extract(url)
    assert result['id'] == "zzdE77v6Mmo"
    assert result['playlist_mincount'] == 209


# Generated at 2022-06-12 18:30:39.338121
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    extractor = TudouPlaylistIE()
    assert extractor.IE_NAME == 'tudou:playlist'
    assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert extractor._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-12 18:30:39.979620
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE("")

# Generated at 2022-06-12 18:30:51.401642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url1 = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    test_url2 = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test_url3 = "http://www.tudou.com/albumplay/v5qckFJvNJg.html?spm=a2hcr.11187899.albumcenter.5!6~5!1~5~A"

    test_obj1 = TudouAlbumIE()
    test_obj2 = TudouAlbumIE()
    test_obj3 = TudouAlbumIE()

    print (test_obj1.IE_NAME) # should be tudou:album

# Generated at 2022-06-12 18:30:52.436157
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('tudou:playlist','','','','','','','','','')

# Generated at 2022-06-12 18:30:56.672200
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test1
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie = TudouAlbumIE(url)
    # test2
    tudou_album_ie2 = TudouAlbumIE(url, {'id': 'v5qckFJvNJg'})
    assert(tudou_album_ie.id == tudou_album_ie2.id)
    return

# Generated at 2022-06-12 18:31:03.107028
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_urls = [
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
    ]
    for url in test_urls:
        ie = TudouAlbumIE(url)
        assert ie.url == url
        assert ie._match_id(ie.url) == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:31:19.603341
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbum = TudouAlbumIE()
    assert tudoualbum.ie_key() == 'TudouAlbum'
    assert tudoualbum.ie_name() == 'tudou:album'
    assert tudoualbum.ie_description() == 'Youku Tudou Inc'


# Generated at 2022-06-12 18:31:22.178553
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """ Unit test for constructor of class TudouPlaylistIE """
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html', None, None)


# Generated at 2022-06-12 18:31:24.792220
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert(tudou_album_ie._match_id('http://www.tudou.com/albumcover/fZwcpB0Jt74') == 'fZwcpB0Jt74')

# Generated at 2022-06-12 18:31:27.596280
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:31:34.876486
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from .tudou_album import TudouAlbumIE
	from .common import InfoExtractor
	import unittest

	class TestTudouAlbumIE(unittest.TestCase):
		def test_constructor(self):
			ie = TudouAlbumIE()
			self.assertEqual(ie.ie_key(), 'TudouAlbum')

	suite = unittest.TestLoader().loadTestsFromTestCase(TestTudouAlbumIE)
	unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 18:31:38.312150
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
   TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")



# Generated at 2022-06-12 18:31:39.347949
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE


# Generated at 2022-06-12 18:31:44.666042
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumcover/5RKvUuW6U8E.html'
    ie = TudouAlbumIE(test_url)
    assert ie.valid_url(test_url)
    assert ie.constructor == 'TudouAlbumIE'
    assert ie.construct_url(test_url) == test_url

# Generated at 2022-06-12 18:31:46.829616
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    "TudouAlbumIE - test class constructor"
    
    # Success:
    TudouAlbumIE(None)
    # Failure:
    try:
        TudouAlbumIE()
    except:
        pass

# Generated at 2022-06-12 18:31:51.125214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    newAlbumIE = TudouAlbumIE(None)
    if newAlbumIE.valid_url(url='http://www.tudou.com/albumcover/v5qckFJvNJg'):
        assert True
    else:
        assert False



# Generated at 2022-06-12 18:32:22.930097
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import pytest
    from .testutils import time_converter
    from .common import  InfoExtractor

    @pytest.fixture(scope='module', params=['list', 'albumcover', 'albumplay'])
    def base_url_list(request):
        return ['http://www.tudou.com/' + request.param + '/v5qckFJvNJg.html']

    @pytest.fixture(scope='module', params=['albumcover', 'albumplay'])
    def url_list(request):
        return ['http://www.tudou.com/' + request.param + '/v5qckFJvNJg.html']

    ie = InfoExtractor()
    ie.add_info_extractor(TudouAlbumIE)

# Generated at 2022-06-12 18:32:23.817516
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
   return TudouPlaylistIE()


# Generated at 2022-06-12 18:32:28.734111
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()._real_extract({
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    })
    assert len(info) == 2
    assert info[1] == 'zzdE77v6Mmo'



# Generated at 2022-06-12 18:32:35.614142
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_info_dict = {
        'id': 'zzdE77v6Mmo',
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    }
    tudou_playlist_ie = TudouPlaylistIE(tudou_info_dict)
    assert tudou_playlist_ie


# Generated at 2022-06-12 18:32:43.391067
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructor of class TudouPlaylistIE
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie.IE_DESC == '土豆 - 发现更多好玩的'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'



# Generated at 2022-06-12 18:32:44.754998
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance.IE_NAME == 'tudou:album'



# Generated at 2022-06-12 18:32:46.114446
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE

# Generated at 2022-06-12 18:32:47.096692
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-12 18:32:49.037976
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    app = TudouPlaylistIE()
    print(app)

# Generated at 2022-06-12 18:32:53.778175
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-12 18:34:01.876068
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie_album = TudouAlbumIE()
	assert ie_album is not None


# Generated at 2022-06-12 18:34:02.658914
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:34:04.241759
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouPlaylistIE(InfoExtractor()), 'https://www.tudou.com/albumcover/v5qckFJvNJg')

# Generated at 2022-06-12 18:34:08.330336
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:34:09.443366
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("")

# Generated at 2022-06-12 18:34:15.998463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	IE_NAME = 'tudou:playlist'
	_VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	ie = InfoExtractor(None, None, IE_NAME) #VideoInfoExtractor(IE_NAME, ie)
	assert ie.name == IE_NAME
	assert ie._VALID_URL == _VALID_URL


# Generated at 2022-06-12 18:34:18.471252
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-12 18:34:28.538944
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE as _TudouAlbumIE
    from .tudou import TudouPlaylistIE as _TudouPlaylistIE
    from .common import InfoExtractor as _InfoExtractor
    from .common import ExtractorError as _ExtractorError
    from .compat import compat_urllib_parse_urlparse as _compat_urllib_parse_urlparse
    from .compat import compat_str as _compat_str

    # Test for valid input.
    assert _TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    # Test for invalid input.
    # This should raise an ValueError.

# Generated at 2022-06-12 18:34:32.926197
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])


# Generated at 2022-06-12 18:34:37.962442
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:37:05.340525
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-12 18:37:09.091421
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html");
    assert test.get_url() == "http://www.tudou.com/listplay/zzdE77v6Mmo.html";
    assert test.get_id() == "zzdE77v6Mmo";


# Generated at 2022-06-12 18:37:14.072736
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:37:14.639133
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:37:15.549609
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert (
        TudouAlbumIE.__name__ == 'TudouAlbumIE'
    )

# Generated at 2022-06-12 18:37:18.295047
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  url_list = [
    'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
    'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
    'http://www.tudou.com/plcover/zzdE77v6Mmo.html']
  for url in url_list:
    playlist_ie = TudouPlaylistIE(url)

# Generated at 2022-06-12 18:37:19.139854
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()



# Generated at 2022-06-12 18:37:21.098859
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:37:28.076794
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# basic tests for constructor of class TudouAlbumIE
    assert_raises(Exception, TudouAlbumIE, "http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert_raises(Exception, TudouAlbumIE, "https://www.tudou.com/albumcover/v5qckFJvNJg")
# Test if the url http://www.tudou.com/albumplay/v5qckFJvNJg.html is valid for the class TudouAlbumIE

# Generated at 2022-06-12 18:37:29.213827
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')