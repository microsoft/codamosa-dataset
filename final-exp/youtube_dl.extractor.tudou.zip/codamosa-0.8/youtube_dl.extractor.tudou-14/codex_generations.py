

# Generated at 2022-06-12 18:28:03.236998
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:28:07.224980
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    URL = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test._match_id(URL) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:28:11.585192
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-12 18:28:15.248731
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ex = TudouPlaylistIE()
    # Check for constructor
    if ex == None:
        print("Failed to init class TudouPlaylistIE");
        return
    ex._real_extract(ex._VALID_URL)


# Generated at 2022-06-12 18:28:19.916687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """ Test for constructor of class TudouAlbumIE
    """
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:28:25.250667
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case for valid link
    valid_link = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudouPlaylistIE = TudouPlaylistIE(valid_link)
    assert tudouPlaylistIE.link == valid_link
    assert tudouPlaylistIE.isLinkValid() == True

    # Test case for invalid link
    invalid_link = 'http://www.tudou.com/listplay/zzdE77v6Mmo'
    tudouPlaylistIE = TudouPlaylistIE(invalid_link)
    assert tudouPlaylistIE.link == invalid_link
    assert tudouPlaylistIE.isLinkValid() == False


# Generated at 2022-06-12 18:28:29.021170
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie=TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-12 18:28:31.158265
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert Tavrida('tudou:album', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html') == album_id

# Generated at 2022-06-12 18:28:35.657686
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # construct an instance of TudouPlaylistIE
    i = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    print(i.extract())

# Generated at 2022-06-12 18:28:44.109090
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pl = {'name': 'TestName',
          'description': 'TestDesc',
          'id': 'TestId',
          'items': [{'icode': 'abc', 'kw': 'keyword'},
                    {'icode': 'efg', 'kw': 'keyword2'},
                    {'icode': 'hij', 'kw': 'keyword3'}
                    ]
          }
    a = TudouAlbumIE('', '', '', '', '', '', '', '', pl)
    entries = a.extract_entries()
    assert entries[0].url == 'http://www.tudou.com/programs/view/abc'

# Generated at 2022-06-12 18:28:56.585187
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    assert album.IE_NAME == 'tudou:album'
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(album._TESTS) == 1
    assert album._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert album._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert album._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-12 18:29:06.783219
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test on a playlist
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert ie._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}
    assert ie._FILE_SUFFIX == '.html'

# Generated at 2022-06-12 18:29:13.326686
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    import re
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == re.compile(r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-12 18:29:23.460015
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:29:26.164368
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    assert a._VALID_URL == TudouAlbumIE._VALID_URL


# Generated at 2022-06-12 18:29:29.210717
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_raises_regexp(TypeError, '__init__() takes exactly', TudouAlbumIE)


# Generated at 2022-06-12 18:29:38.513272
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_url='http://www.tudou.com/albumplay/b8YvkRZ5xBc.html'
    album_id='b8YvkRZ5xBc'

# Generated at 2022-06-12 18:29:44.660294
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-12 18:29:56.250702
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        from tudou import TudouAlbumIE
    except ImportError:
        import sys
        sys.path.append('.')
        from tudou import TudouAlbumIE
    url = 'http://www.tudou.com/albumcover/Qbp5d5P5xCQ.html'
    res = TudouAlbumIE(url)
    assert res.ie_key() == 'Tudou:album'
    assert res.player_url() == 'http://js.tudouui.com/bin/player2/olc_8.0.2_2.swf'
    assert res.report_url() == 'http://www.tudou.com/albumcover/Qbp5d5P5xCQ.html'

# Generated at 2022-06-12 18:30:01.832050
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlistIE = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert playlistIE._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:30:15.440337
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    count = 0
    url = 'http://www.tudou.com/album/aME7rVRNtMs.html'
    count += 1
    TudouAlbumIE(count).extract(url)

    url = 'http://www.tudou.com/albumplay/aME7rVRNtMs.html'
    count += 1
    TudouAlbumIE(count).extract(url)


# Generated at 2022-06-12 18:30:22.723082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album.IE_NAME == 'tudou:album'
    assert tudou_album.VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album.TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-12 18:30:34.617067
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    tudou_album_ie_repr = repr(tudou_album_ie)
    # Unit test for methods __init__ and __repr__ of class TudouAlbumIE
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS == [{ 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': { 'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45 }]
    assert tudou_album

# Generated at 2022-06-12 18:30:38.058374
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
            },
        'playlist_mincount': 45,
        }
    assert isinstance(TudouAlbumIE(album),InfoExtractor)
    assert isinstance(TudouPlaylistIE(album),InfoExtractor)

# Generated at 2022-06-12 18:30:38.980245
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE)


# Generated at 2022-06-12 18:30:39.591095
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance

# Generated at 2022-06-12 18:30:46.603473
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_id = 'zzdE77v6Mmo'
	url = 'http://www.tudou.com/listplay/'+ tudou_id + '.html'
	raw = 'http://www.tudou.com/tvp/plist.action?lcode=' + tudou_id
	tp = TudouPlaylistIE(url)
	tp._download_json
	tp.real_extract()

# Generated at 2022-06-12 18:30:48.317854
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistie = TudouPlaylistIE()
    assert tudouplaylistie != None


# Generated at 2022-06-12 18:30:49.946620
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0].get('id') == 'v5qckFJvNJg'
    assert TudouAlbumIE._TESTS[0].get('url') == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'



# Generated at 2022-06-12 18:30:54.240213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_name() == 'Tudou'
    assert ie.SUFFIX == 'album'
    assert ie.VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:31:13.709991
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    ie = TudouAlbumIE(
        common.common.FakeYDL(),
        {'extractor': 'tudou:album',
         'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'})
    tudou_album = ie._real_extract(ie.url)
    # check function `_real_extract`
    entries = tudou_album['entries']

# Generated at 2022-06-12 18:31:17.160296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	Parser = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
	url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	id = Parser._match_id(url)
	assert id == 'zzdE77v6Mmo'


# Generated at 2022-06-12 18:31:20.956862
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    line = ' hello  '
    expected = 'hello'
    result = TudouAlbumIE.IE_NAME
    assert expected == result

TudouAlbumIE.test = test_TudouAlbumIE


# Generated at 2022-06-12 18:31:22.904580
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except Exception as e:
        assert(False), 'Construction of class TudouAlbumIE fails: ' + e.message

# Generated at 2022-06-12 18:31:27.523221
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    playlist_id = "zzdE77v6Mmo"
    playlist_url = "http://www.tudou.com/listplay/{}.html".format(playlist_id)
    result = ie._real_extract(playlist_url)
    # Test playlist id
    assert result['id'] == playlist_id
    # Test playlist item count
    assert len(result['entries']) == 1351



# Generated at 2022-06-12 18:31:32.094403
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # Test extraction from valid URL
    assert playlist.playlist_id == 'zzdE77v6Mmo'

# Generated at 2022-06-12 18:31:36.517904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    t.url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    t.IE_NAME = "tudou:album"
    t._VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    assert t._match_id is not None
    assert t._real_extract is not None



# Generated at 2022-06-12 18:31:46.932170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import os.path
    from .common import ResultList
    from .common import InfoExtractor
    from .compat import compat_str
    from .tudou import TudouAlbumIE
    from .tudou import _TESTS
    import copy

    class TestTudouAlbumIE(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestTudouAlbumIE, self).__init__(*args, **kwargs)
            self.ie = TudouAlbumIE()
            self.test_case = _TESTS[0]
            self.test_url = self.test_case.pop('url')
            self.test_id = self.test_case.pop('id')


# Generated at 2022-06-12 18:31:50.073634
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url="http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    TudouAlbumIE(url)


# Generated at 2022-06-12 18:31:55.310460
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	test_obj = TudouAlbumIE()
	assert test_obj.IE_NAME == 'tudou:album'
	assert test_obj._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert len(test_obj._TESTS) == 1


# Generated at 2022-06-12 18:32:08.892781
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-12 18:32:15.444822
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'abcdefg12345678'
    # Constructor with valid arguments
    album = TudouAlbumIE(url = 'http://www.tudou.com/albumcover/%s.html' % album_id, id = album_id)
    assert album is not None
    # Constructor with invalid arguments
    try:
        album = TudouAlbumIE(url = 'http://www.tudou.com/albumcover/%s.html' % album_id, id = album_id + '1')
    except Exception:
        album = None
    assert album is None


# Generated at 2022-06-12 18:32:17.318981
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Tests that the class constructor works
    try:
        assert TudouAlbumIE != None
    except:
        assert False

# Generated at 2022-06-12 18:32:26.694436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import TestIE
    from .test_tudou import extract
    from .pptv import PptvShowIE
    from .cntv import CNTVIE
    from .acfun import AcfunIE
    from .yinyuetai import YinYueTaiIE
    from .bandcamp import BandcampIE
    from .commons import CommonsIE
    from .generic import GenericIE
    from .test_generic import GenericTest
    from .test_ttv import TTVTest
    from .test_yandex import YandexMusicPlaylistIE
    from .test_youtube import YoutubePlaylistIE
    from .test_youku import YoukuIE
    from .test_youporn import YouPornIE
    from .test_youporn_playlist import YouPornPlaylistIE
    from .xiami import XiamiAl

# Generated at 2022-06-12 18:32:37.377813
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    test = ie._TESTS
    assert len(test) == 1
    assert test[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert test[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert test[0]['playlist_mincount'] == 45

# Generated at 2022-06-12 18:32:46.113987
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-12 18:32:56.311934
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo/zzdE77v6Mmo.html'
    # test_url = 'http://www.tudou.com/listplay/_A5oaZhkQ2Y/'
    # test_url = 'http://www.tudou.com/listplay/_A5oaZhkQ2Y.html'

    example_IE = TudouPlaylistIE()

# Generated at 2022-06-12 18:32:58.120557
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    u = TudouPlaylistIE(url)
    assert u.url == url

# Generated at 2022-06-12 18:33:02.593961
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check whether use md5 value as playlist_id if it is not provided by user.
    playlist_id = "zzdE77v6Mmo"
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(url, playlist_id)



# Generated at 2022-06-12 18:33:10.740850
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45


# Generated at 2022-06-12 18:33:51.197893
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._real_extract(url) is not None

# Generated at 2022-06-12 18:33:53.171312
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE()
    album._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-12 18:34:02.270500
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE('tudou:playlist')
    assert IE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not IE.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert IE._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert IE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE.IE_NAME == 'tudou:playlist'
    assert len(IE._TESTS) == 1


# Generated at 2022-06-12 18:34:03.278257
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a is not None


# Generated at 2022-06-12 18:34:06.304932
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-12 18:34:17.076525
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Testing constructor of class TudouAlbumIE")
    import re
    import requests
    import json
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    valid_url = re.match(TudouAlbumIE._VALID_URL, url)
    assert valid_url is not None
    album_id = valid_url.group("id")
    album_data = requests.get("http://www.tudou.com/tvp/alist.action?acode=%s" % album_id).content
    album_data = json.loads(album_data)

# Generated at 2022-06-12 18:34:21.039786
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-12 18:34:29.785978
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance.IE_NAME == 'tudou:album'
    assert instance._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert instance._TESTS[0]['info_dict']  == {'id': 'v5qckFJvNJg'}
    assert instance._TESTS[0]['playlist_mincount']  == 45
    assert instance._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'


# Generated at 2022-06-12 18:34:38.808479
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = 'dontcare'
    items = [{'icode': 'zzdE77v6Mmo', 'kw': 'Icarly'}]
    playlist_data = {'items': items}
    entries = [TudouPlaylistIE.url_result('http://www.tudou.com/programs/view/' + items[0]['icode'], 'Tudou', items[0]['icode'], items[0]['kw'])]
    info_dict = {'id': playlist_id}
    ie = TudouPlaylistIE(TudouPlaylistIE._create_ie())
   

# Generated at 2022-06-12 18:34:45.471394
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS) == 1
    url = ie._TESTS[0]['url']
    assert url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    result = ie.extract(url)

    assert result['id'] == 'zzdE77v6Mmo'
    assert type(result['entries']) == list
    assert len(result['entries']) == 209


# Generated at 2022-06-12 18:36:10.390930
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    ies = (TudouPlaylistIE, TudouAlbumIE)

    for ie in ies:
        assert ie.suitable(url)

    me = (TudouAlbumIE(), TudouPlaylistIE())

    for me_ in me:
        assert me_.suitable(url)

# Generated at 2022-06-12 18:36:13.626279
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE().suitable(url)


# Generated at 2022-06-12 18:36:15.075986
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    albumIE = TudouAlbumIE()
    assert albumIE is not None

# Generated at 2022-06-12 18:36:15.884828
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:36:21.372040
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test invalid URL for TudouPlaylistIE
    assert  TudouPlaylistIE.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo.html') is True
    # This is an invalid URL that should not match
    assert  TudouPlaylistIE.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo.xml') is False


# Generated at 2022-06-12 18:36:22.099960
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-12 18:36:27.094843
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_test = TudouAlbumIE()

    assert album_test.IE_NAME == 'tudou:album'
    assert album_test.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert album_test.extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert not album_test.extract('http://www.tudou.com/albumcover/v5qckFJvNJ.html')
    assert not album_test.extract('http://www.tudou.com/albumplay/v5qckFJvNJ.html')

# Generated at 2022-06-12 18:36:30.434590
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-12 18:36:40.187063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistUrl = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # http://stackoverflow.com/questions/7088672/py.test-running-all-functions-with-a-certain-name-pattern
    clazz = TudouPlaylistIE()
    assert clazz.suitable(tudouPlaylistUrl)
    assert clazz.IE_NAME == 'tudou:playlist'
    assert clazz._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-12 18:36:45.968137
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tupleSize = 4
    tudouPlaylistIE = TudouPlaylistIE()
    assert(len(tudouPlaylistIE.IE_NAME) > 0)
    assert(len(tudouPlaylistIE._VALID_URL) > 0)
    assert(len(tudouPlaylistIE._TESTS) > 0)
    assert(len(tudouPlaylistIE._TESTS[0]) == tupleSize)
    assert(len(tudouPlaylistIE._TESTS[0]['url']) > 0)
    assert(len(tudouPlaylistIE._match_id(tudouPlaylistIE._TESTS[0]['url'])) > 0)
