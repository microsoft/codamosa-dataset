

# Generated at 2022-06-26 13:02:17.667084
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:18.936801
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:27.295202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    # Test case: Try to extract some file.
    # assert tudou_playlist_i_e_0.extract() == 'All tests passed!'
    # Test case: Try to get the class name
    assert tudou_playlist_i_e_0.ie_key() == 'Tudou:playlist'
    # Test case: Try to get the IE name
    assert tudou_playlist_i_e_0.ie_key() == 'Tudou:playlist'
    # Test case:
    assert 'depends' in tudou_playlist_i_e_0.ie_key()
    # Test case:
    assert 'extract' in tudou_playlist_i_e_0.ie

# Generated at 2022-06-26 13:02:29.315218
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:02:30.878543
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_11 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:35.672495
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # URL is not valid
    assert_raises(RegexNotFoundError, TudouPlaylistIE._match_id, 'test')

    # URL is valid
    assert_equals(TudouPlaylistIE._match_id('zzdE77v6Mmo.html'), 'zzdE77v6Mmo')

    return


# Generated at 2022-06-26 13:02:44.275378
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  tao_pai_pai_album_url = 'tudou:album:http://www.tudou.com/albumplay/v5qckFJvNJg.html'
  tao_pai_pai_album_info_dict = {
    'id': 'v5qckFJvNJg',
  }
  tao_pai_pai_album_playlist_mincount = 45
  tao_pai_pai_album = TudouAlbumIE()

  tao_pai_pai_album.IE_NAME = tudou_album_i_e_0.IE_NAME
  tao_pai_pai_album.IE_DESC = tudou_album_i_e_0.IE_DESC
  tao_pai_pai_album.test_cases = tudou_album_i_

# Generated at 2022-06-26 13:02:46.366268
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    print(tudou_playlist_ie.IE_NAME)
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'



# Generated at 2022-06-26 13:02:48.616475
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-26 13:02:50.628031
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:57.387157
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:02:59.092445
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(),InfoExtractor)


# Generated at 2022-06-26 13:03:00.016646
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case_0()

# Generated at 2022-06-26 13:03:02.542117
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:07.175312
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from re import compile

    the_input = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_result = compile('^(.*)$')
    actual_result = tudou_album_i_e_0._VALID_URL

    assert (expected_result == actual_result)
    return


# Generated at 2022-06-26 13:03:08.036596
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:09.191508
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()

# Generated at 2022-06-26 13:03:09.721415
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-26 13:03:11.190372
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_equal(TudouAlbumIE.IE_NAME, 'tudou:album')
    

# Generated at 2022-06-26 13:03:14.854949
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Entering the values for constructor of class TudouPlaylistIE
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie is not None


# Generated at 2022-06-26 13:03:24.661107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:03:29.270965
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    return TudouAlbumIE()._real_initialize(url)

# Generated at 2022-06-26 13:03:33.966452
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    pass

# Generated at 2022-06-26 13:03:39.931419
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    #if __name__ == '__main__':
    #    import sys
    #    sys.exit(test_TudouAlbumIE(sys.argv))
    test_TudouAlbumIE()

# Generated at 2022-06-26 13:03:50.421541
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Create an instace of class TudouAlbumIE
    ie_obj = TudouAlbumIE()
    print(ie_obj) #<tudou.tudou.TudouAlbumIE object at 0x7eff0c127518>
    # Check initial value of a class variable
    print(TudouAlbumIE._VALID_URL) #r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    # Check initial value of a instance variable
    print(ie_obj._VALID_URL) #r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    # Change the value of a class variable


# Generated at 2022-06-26 13:03:58.621846
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE(url)
    actual = tudou_playlist_ie._VALID_URL
    expect = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert actual == expect

# Generated at 2022-06-26 13:04:02.383685
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-26 13:04:07.412486
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(test=True)
    # no exception
    TudouAlbumIE(test=True).extract(url)

# Generated at 2022-06-26 13:04:08.291500
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-26 13:04:09.287285
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert True

# Generated at 2022-06-26 13:04:25.422337
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE()
    assert i._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:04:26.866792
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-26 13:04:34.903443
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info_dict = {
        'description': '',
        'extractor_key': 'TudouPlaylist',
        'extractor': 'tudou:playlist',
        'webpage_url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        '_type': 'playlist',
    }
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    playlist_id = ('zzdE77v6Mmo')

# Generated at 2022-06-26 13:04:41.229870
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    playlist_id = 'v5qckFJvNJg'
    playlist_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % playlist_id
    entries = 'http://www.tudou.com/programs/view/%s' % playlist_data['items']['icode']
    return TudouAlbumIE.playlist_result(entries, playlist_id)

# Generated at 2022-06-26 13:04:43.760557
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    result = TudouAlbumIE(None)
    assert result.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:04:49.906782
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # check whether the constructor is defined correctly
    from ..tudou import TudouAlbumIE
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-26 13:04:52.392704
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()

    assert a != None
    assert isinstance(a, InfoExtractor)

# Generated at 2022-06-26 13:04:54.474897
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE == TudouPlaylistIE


# Generated at 2022-06-26 13:05:04.922057
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert (TudouPlaylistIE(InfoExtractor())._VALID_URL ==
            'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert (TudouPlaylistIE(InfoExtractor())._TESTS[0]['url'] ==
            'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert (TudouPlaylistIE(InfoExtractor())._TESTS[0]['info_dict']['id'] ==
            'zzdE77v6Mmo')
    assert (TudouPlaylistIE(InfoExtractor())._TESTS[0]['playlist_mincount'] ==
            209)

# Generated at 2022-06-26 13:05:11.857774
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    info = IE.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert info['id'] == 'zzdE77v6Mmo'
    info_dict = info['info_dict']
    assert info_dict['id'] == 'zzdE77v6Mmo'
    assert len(info['entries']) == 209


# Generated at 2022-06-26 13:05:43.912312
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(TudouPlaylistIE)
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._match_id(url) == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:05:49.991005
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
	t = TudouAlbumIE()
	t.url = url
	assert t._match_id(url) == "v5qckFJvNJg"

# Generated at 2022-06-26 13:05:58.092904
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test = TudouAlbumIE()
    assert test.IE_NAME == 'tudou:album'
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert test._TESTS
    assert test._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert test._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert test._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-26 13:06:03.255346
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_video = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert tudou_album_video.IE_NAME == "tudou:album"


# Generated at 2022-06-26 13:06:05.073300
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE(TudouAlbumIE.__name__)
	assert_equals(ie.IE_NAME, 'tudou:album')

# Generated at 2022-06-26 13:06:17.584890
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    extractor = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    if extractor.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') != True:
        assert False
    if extractor.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo.html') != True:
        assert False
    if extractor.suitable('https://www.tudou.com/listplay/zzdE77v6Mmo') != False:
        assert False

    extractor = TudouPlaylistIE('http://www.tudou.com/listplay/id.html')

# Generated at 2022-06-26 13:06:20.929642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE()
    assert x.IE_NAME == 'tudou:album'
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:06:28.506679
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-26 13:06:33.801587
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    info = TudouPlaylistIE()
    #print info._download_xml('http://www.tudou.com/plcover/zzdE77v6Mmo/')
    info._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')
    #print info._download_json('http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg')


# Generated at 2022-06-26 13:06:37.624032
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('chn', 'usa')
    assert ie.getChannel() == 'chn'
    assert ie.getRegion() == 'usa'

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-26 13:07:51.891430
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import playlist_result
    from .test_test import pattern
    assert playlist_result([
        {
            'url': 'http://www.tudou.com/programs/view/%s' % 'abcdefghijk',
            'ie': 'Tudou',
            'id': 'abcdefghijk',
            'title': 'A title',
        }
    ], '12345678901') == \
        {
            'id': '12345678901',
            'entries': [{
                'url': 'http://www.tudou.com/programs/view/%s' % 'abcdefghijk',
                'ie': 'Tudou',
                'id': 'abcdefghijk',
                'title': 'A title',
            }]
        }

# Generated at 2022-06-26 13:07:59.797987
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE("zzdE77v6Mmo")
    print("test_TudouPlaylistIE:%s", obj)
    # Nothing to test in static method _real_extract

if __name__ == '__main__':
    test_TudouPlaylistIE()

# Generated at 2022-06-26 13:08:05.357699
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert instance.IE_NAME == "tudou:playlist"
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:08:19.312265
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouPlaylist')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:08:29.097143
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Arrange
    playlist_id = 'zzdE77v6Mmo'
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    # Act
    playlist_ie = TudouPlaylistIE(0, 0)
    playlist_ie.extract(playlist_url)

    # Assert
    assert playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-26 13:08:42.858970
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_info_dict = {
        'id': 'v5qckFJvNJg',
    }
    tudou_album_playlist_mincount = 45

    # Usage of test_TudouAlbumIE(self)
    tudou_album_IE = TudouAlbumIE(tudou_album_url)

    # Usage of _match_id(self, url)
    tudou_album_id = tudou_album_IE._match_id(tudou_album_url)
    assert tudou_album_id == tudou_album_info_dict['id']

    assert tudou_album_IE

# Generated at 2022-06-26 13:08:43.859894
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie.IE_NAME == 'tudou:album'



# Generated at 2022-06-26 13:08:46.326296
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._TESTS[0].get('info_dict').get('id') == 'v5qckFJvNJg')

# Generated at 2022-06-26 13:08:48.828101
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert 'tudou.com' in test_TudouPlaylistIE._VALID_URL
    assert 'tudou.com' in test_TudouPlaylistIE._VALID_URL


# Generated at 2022-06-26 13:08:49.562299
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:11:10.946424
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-26 13:11:19.120549
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
             'info_dict': {
                    'id': 'zzdE77v6Mmo',
                },
             'playlist_mincount': 209,
         }])


# Generated at 2022-06-26 13:11:21.247593
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('test_TudouPlaylistIE')
    assert tudou_playlist.name() == 'tudou:playlist'


# Generated at 2022-06-26 13:11:34.303000
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_ie = TudouPlaylistIE()
    assert tudou_ie._match_id(url) == 'zzdE77v6Mmo'
    assert tudou_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:11:42.797138
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:11:53.837861
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  playlist = TudouPlaylistIE()
  assert playlist.ie_key() == 'Tudou:playlist'
  assert playlist.playlist_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
  assert playlist.url_result('http://www.tudou.com/programs/view/%s') == 'http://www.tudou.com/programs/view/%s'
  # Unit test for method playlist_mincount
  #assert playlist.playlist_mincount('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 209

# Generated at 2022-06-26 13:11:56.967387
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:12:02.689232
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Arrange
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    # Act
    tPI = TudouPlaylistIE(url)
    # Assert
    assert tPI.url == url
    assert tPI.ie_key == "TudouPlaylist"


# Generated at 2022-06-26 13:12:03.868729
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE.test()


# Generated at 2022-06-26 13:12:06.944216
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE(None, None) != None)
