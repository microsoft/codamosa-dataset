

# Generated at 2022-06-26 13:02:22.860968
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE().IE_NAME == 'tudou:album')
    assert(TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    tudou_album_i_e_2 = TudouAlbumIE()
    # Undefined variable 'assertIsNotNone'
    # assertIsNotNone(tudou_album_i_e_2) # expect exception


# Generated at 2022-06-26 13:02:28.396633
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'tudou:album')
    assert(TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    tudou_album_i_e_0 = TudouAlbumIE()
    assert(tudou_album_i_e_0.ie_key() == 'TudouAlbum')
    assert(tudou_album_i_e_0.ie_name() == 'tudou:album')



# Generated at 2022-06-26 13:02:29.750793
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:33.136542
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e is not None

# Generated at 2022-06-26 13:02:35.925080
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:39.581446
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:02:47.047204
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE.IE_NAME == 'Tudou:album')
    assert(TudouAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(TudouAlbumIE._TESTS[0] == {'url':'http://www.tudou.com/albumplay/v5qckFJvNJg.html','info_dict':{'id':'v5qckFJvNJg'},'playlist_mincount':45})
    assert(callable(TudouAlbumIE._real_extract))


# Generated at 2022-06-26 13:02:55.608110
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_equal(TudouAlbumIE._VALID_URL, 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert_equal(TudouAlbumIE.IE_NAME, 'tudou:album')
    assert_equal(TudouAlbumIE._TESTS, [{'playlist_mincount': 45, 'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}}])


# Generated at 2022-06-26 13:02:57.601755
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:06.787188
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()
    assert(tudou_album_i_e_0.ie_name == 'tudou:album')
    assert(tudou_album_i_e_0.ie_key == 'TudouAlbum')
    assert(tudou_album_i_e_0.host == 'tudou.com')
    assert(tudou_album_i_e_0._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')


# Generated at 2022-06-26 13:03:15.214234
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(tudou_album_i_e_0, InfoExtractor)


# Generated at 2022-06-26 13:03:17.584109
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:03:20.269241
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:23.937680
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:03:24.680656
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	pass


# Generated at 2022-06-26 13:03:26.485943
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case_0()

# Generated at 2022-06-26 13:03:28.982914
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:03:35.475060
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    assert tudou_playlist_i_e._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:03:48.798656
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-26 13:03:50.159564
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:03:58.812143
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)
    assert True


# Generated at 2022-06-26 13:04:06.496898
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    assert ie.ie_key() == 'tudou:album'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-26 13:04:12.394312
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(TudouAlbumIE.IE_NAME, TudouAlbumIE._VALID_URL, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.is_suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True


# Generated at 2022-06-26 13:04:15.004136
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE({})
    assert isinstance(instance, TudouPlaylistIE)

# Generated at 2022-06-26 13:04:24.863570
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()
    playlist_id = playlist._match_id(url)
    playlist._real_extract(url)
    playlist_data = playlist._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % playlist_id, playlist_id)
    entries = [playlist.url_result(
        'http://www.tudou.com/programs/view/%s' % item['icode'],
        'Tudou', item['icode'],
        item['kw']) for item in playlist_data['items']]
    playlist.playlist_result(entries, playlist_id)

# Generated at 2022-06-26 13:04:28.278243
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # assert __name__ == "__main__"
    assert test_TudouAlbumIE.__name__ == "__main__"


# Generated at 2022-06-26 13:04:35.422456
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test case #1
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    actual = TudouAlbumIE().extract(url)

# Generated at 2022-06-26 13:04:38.000401
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE().IE_NAME == 'tudou:album'




# Generated at 2022-06-26 13:04:45.191799
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-26 13:04:54.230734
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_IE = TudouPlaylistIE()
    tudou_playlist_IE._download_json = lambda url, playlist_id: {'items': [{'icode': 'RAc7sRu-kK0', 'kw': 'BAD BOYS BLUE'}, {'icode': '9dTFFupcFvA', 'kw': 'Backstreet Boys'}, {'icode': '8HtNFQPtSdA', 'kw': 'Chicane'}]}
    tudou_playlist_IE.url_result = lambda url, ie, video_id, video_title: {'url': url, 'info_dict': {'id': video_id, 'title': video_title}}

# Generated at 2022-06-26 13:05:11.586583
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('tudou:playlist', 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:05:20.221505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("test_TudouPlaylistIE")
    playlist_extractor = TudouPlaylistIE(None)
    assert playlist_extractor.IE_NAME == 'tudou:playlist'
    assert playlist_extractor.info_dict == {}
    assert playlist_extractor.ie == None
    assert playlist_extractor.playlist == []


# Generated at 2022-06-26 13:05:25.495382
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test full URL
    test_cases = [
        ('http://www.tudou.com/albumcover/v5qckFJvNJg.html', 'v5qckFJvNJg'),
        ('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'v5qckFJvNJg')
    ]
    for url, expected in test_cases:
        ie = TudouAlbumIE(url)
        assert(ie.url == url)
        assert(ie.id == expected)

    # Test URL with a scheme
    ie = TudouAlbumIE('tudou://www.tudou.com/albumcover/v5qckFJvNJg')

# Generated at 2022-06-26 13:05:32.093361
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    album_id = r'v5qckFJvNJg'
    assert(TudouAlbumIE(url)._match_id(url) == album_id)

# Generated at 2022-06-26 13:05:44.060238
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Unit test for constructor of class TudouAlbumIE"""
    # Testing 'url' and 'ie_key'
    tudou_album = TudouAlbumIE({'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'ie_key': 'Tudou'}, {'extract_flat': True})
    assert tudou_album.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album.ie_key == 'Tudou'


# Test for method extract_playlist

# Generated at 2022-06-26 13:05:46.665165
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert  TudouAlbumIE() is not None


# Generated at 2022-06-26 13:05:49.780049
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouplaylist = TudouPlaylistIE()

# Generated at 2022-06-26 13:05:58.994654
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # This unit test is to test the constructor of class TudouPlaylistIE
    # which is to make sure that the module can run independently
    # When we install youtube_dl, we can run the command blow to test
    # youtube-dl --dump-intermediate-pages --match-title "business" --match-filter "duration > 10" 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie= TudouPlaylistIE()
    # When we execute the different modules, we should make sure they are
    # not in the path first.
    ie.initialize()

# Generated at 2022-06-26 13:06:01.069506
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouplaylistie = TudouPlaylistIE()
    tudouplaylistie.download()
    return tudouplaylistie
    

# Generated at 2022-06-26 13:06:06.504834
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0] == {'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}


# Generated at 2022-06-26 13:06:40.650381
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    # test the case when the playlist is a shopping list
    playlist.url_result('http://shop.tudou.com/album/view/aid-5946207/',
                        'Tudou', '5946207', 'shoplist')
    # test the case when the playlist is not a shopping list
    playlist.url_result('http://www.tudou.com/listplay/zzdE77v6Mmo.html',
                        'Tudou', 'zzdE77v6Mmo', 'playlist')

# Generated at 2022-06-26 13:06:52.030160
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    (input_str, expected_output) = ('http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'v5qckFJvNJg')
    assert ie.ie_key() == expected_output, 'Unexpected value found for _match_id()'
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True, 'Unexpected value found for _match_id()'
    assert ie._match_id(input_str) == expected_output, 'Unexpected value found for _match_id()'

# Generated at 2022-06-26 13:06:57.437594
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = u"http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()
    o = ie.extract(url)
    assert o['id'] == 'zzdE77v6Mmo'
    assert len(o['entries']) > 0

# Generated at 2022-06-26 13:07:02.954386
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    assert(TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(len(TudouAlbumIE._TESTS) == 1)


# Generated at 2022-06-26 13:07:10.750789
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    print(tudou_album_ie._TESTS)


# Generated at 2022-06-26 13:07:12.404406
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    agent = TudouAlbumIE()
    assert agent.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:07:17.586815
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    
    tudouPlaylistIE = TudouPlaylistIE(None)
    tudouPlaylistIE.IE_NAME
    tudouPlaylistIE._VALID_URL
    tudouPlaylistIE._TESTS
    tudouPlaylistIE._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:07:20.971621
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('tudou:playlist','zzdE77v6Mmo')

# Generated at 2022-06-26 13:07:24.842218
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(url)


# Generated at 2022-06-26 13:07:27.439023
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._match_id(ie._VALID_URL) == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:08:28.672805
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.__class__.__name__ == 'TudouAlbumIE'

# Generated at 2022-06-26 13:08:36.573221
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._match_id(url) == album_id

# Generated at 2022-06-26 13:08:39.168700
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    inst = TudouPlaylistIE()
    assert inst

# Generated at 2022-06-26 13:08:41.838008
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    constructor_instance_helper(TudouAlbumIE(), 'tudou:album')

# Generated at 2022-06-26 13:08:43.866809
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    assert a is not None

# Generated at 2022-06-26 13:08:49.810640
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0] == {'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
                            'info_dict': {'id': 'v5qckFJvNJg'},
                            'playlist_mincount': 45}


# Generated at 2022-06-26 13:09:03.561747
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test the initials of an instance(object) of class TudouPlaylistIE
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-26 13:09:12.603687
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE_CLASS = TudouPlaylistIE
    IE_NAME = 'tudou:playlist'
    IE_CONSTRUCTOR = {
        'input': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'suffix': 'zzdE77v6Mmo',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }


# Generated at 2022-06-26 13:09:16.687126
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    

# Generated at 2022-06-26 13:09:31.038174
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
        url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        album_id = (r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/'
                    r'(?P<id>[\w-]{11})') #regex
        album_id = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'.strip()
        album_id = ''.join(album_id.split('/listplay/'))
        album_id = 'v5qckFJvNJg'
        album_id

# Generated at 2022-06-26 13:12:10.762116
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(None)._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-26 13:12:12.812427
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	extractor=TudouPlaylistIE()