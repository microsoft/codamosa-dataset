

# Generated at 2022-06-26 13:02:16.586424
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case_0()


# Generated at 2022-06-26 13:02:17.851063
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:18.846352
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:20.923053
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    pass


# Generated at 2022-06-26 13:02:22.383579
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:23.402240
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:02:25.469508
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print( # noqa: T001
        "Constructor of class TudouPlaylistIE is called")

# Generated at 2022-06-26 13:02:26.615905
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:29.056269
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:30.174913
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:38.299325
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert tudou_playlist_i_e_0.__class__.__name__ == 'TudouPlaylistIE'


# Generated at 2022-06-26 13:02:40.378930
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('test_TudouPlaylistIE')
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:41.972530
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:43.088271
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:44.547407
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:47.613507
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    tudou_album_i_e.to_screen('test')


if __name__ == '__main__':
    import sys
    sys.modules['__main__'].test_TudouAlbumIE()

# Generated at 2022-06-26 13:02:48.513988
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case_0()

# Generated at 2022-06-26 13:02:51.737623
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0.ie_key() is "TudouPlaylist"


# Generated at 2022-06-26 13:02:52.953541
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-26 13:02:58.594346
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_ = TudouPlaylistIE()
    # Check type of variable tudou_playlist_i_e_
    assert isinstance(tudou_playlist_i_e_,TudouPlaylistIE), \
        'Variable should be of type TudouPlaylistIE was %s' %type(tudou_playlist_i_e_)

# Generated at 2022-06-26 13:03:05.454380
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# TODO
	return

# Generated at 2022-06-26 13:03:15.655898
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Error during initialization
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._downloader is None
    assert ie._match_id is None
    assert ie._TESTS is None
    assert ie._download_webpage is None
    assert ie._download_json is None
    assert ie.url_result is None
    assert ie.playlist_result is None
    assert ie._download_webpage_handle is None
    assert ie._downloader_locale is None
    assert ie.report_warning is None
    assert ie.report_error is None
    assert ie._raise_error is None

# Generated at 2022-06-26 13:03:19.307334
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-26 13:03:21.911414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import _test_playlist_result
    _test_playlist_result(TudouAlbumIE)

# Generated at 2022-06-26 13:03:24.464532
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('https://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:03:30.848894
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    ie = TudouAlbumIE()
    assert ie._valid_url(url)
    assert ie._match_id(url)


# Generated at 2022-06-26 13:03:37.990085
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com', '', '', '', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', '', '', '')
    assert ie._match_id(ie._VALID_URL) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:03:48.605112
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Test cases for TudouPlaylistIE.
    """
    ie = TudouPlaylistIE()
    input_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected_id = 'zzdE77v6Mmo'
    tester = ie.match(input_url)
    assert tester(input_url)

    # Check if playlist_id is correct
    actual_id = ie._match_id(input_url)
    assert expected_id == actual_id

    # Check if download_json is correct
    actual_id = ie._download_json(
        'http://www.tudou.com/tvp/plist.action?lcode=%s' % expected_id, expected_id)
    assert 'items' in actual_

# Generated at 2022-06-26 13:03:57.520671
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE._TESTS[0]['url'] == TudouPlaylistIE._VALID_URL)
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id'] == TudouPlaylistIE._VALID_URL.split('/')[-1].split('.')[0])
    assert(type(TudouPlaylistIE._TESTS[0]['playlist_mincount'])==type(1))


# Generated at 2022-06-26 13:04:02.295017
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/Ic2jKPZoFhg.html"

# Generated at 2022-06-26 13:04:16.891456
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        assert(InfoExtractor._download_webpage == None)
        TudouPlaylistIE._download_webpage = lambda a, b, c = None, d = None, e = None, f = None, g = False: '[]'
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
        print('unit test for class TudouPlaylistIE succeeded')
    except Exception as e:
        print('unit test for class TudouPlaylistIE failed')
        print(e)

# Generated at 2022-06-26 13:04:25.640231
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test the class constructor for TudouAlbumIE"""

    url = "http://www.tudou.com/albumcover/HJl0jX9L-q8.html"
    album_id = TudouAlbumIE._match_id(url)  # Get the album id
    assert album_id == 'HJl0jX9L-q8'

# Generated at 2022-06-26 13:04:33.312459
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    x = TudouPlaylistIE()
    assert x.IE_NAME == 'tudou:playlist'
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert x._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:04:41.407585
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
#init with default parameter
    test1 = TudouPlaylistIE()
#test for private member _VALID_URL
    if test1._VALID_URL != r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html':
        print('_VALID_URL is error')
#test for private member IE_NAME
    if test1.IE_NAME != 'tudou:playlist':
        print('IE_NAME is error')


# Generated at 2022-06-26 13:04:50.136706
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# URL to test
	url = "http://www.tudou.com/listplay/9G_gQ0wbPVQ.html"
	expected_output = "9G_gQ0wbPVQ"
	# Instance the class
	playlist_ie = TudouPlaylistIE()
	# Extract playlist ID
	playlist_id = playlist_ie._real_extract(url)["id"]
	assert playlist_id == expected_output


# Generated at 2022-06-26 13:04:56.261797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_TudouPlaylistIE = TudouPlaylistIE()
    assert ie_TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:05:00.757379
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:05:02.951199
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print(TudouAlbumIE())


# Generated at 2022-06-26 13:05:05.967075
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert "test" == tudou_album_ie.TudouAlbumIE("test")

# Generated at 2022-06-26 13:05:11.472096
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou = TudouAlbumIE()
    tudou.url = url
    tudou._TESTS = []
    assert tudou._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:05:40.270475
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    test_tudou_album_ie = TudouAlbumIE()
    # test_tudou_album_ie.report_warning()

# Generated at 2022-06-26 13:05:43.229329
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:05:55.717362
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/Ng6GLvU8Djk.html'
    base = 'http://www.tudou.com/tvp/plist.action?lcode='

    class AppURLopener(object):
        def __init__(self, *args):
            pass
        def open(self, url):
            class StringIO(object):
                def read(self):
                    import json

# Generated at 2022-06-26 13:05:59.097644
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    d = TudouPlaylistIE()
    assert d.IE_NAME == 'tudou:playlist'
    assert d._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    

# Generated at 2022-06-26 13:05:59.938942
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(None)

# Generated at 2022-06-26 13:06:03.646574
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print (TudouPlaylistIE._VALID_URL.match('http://www.tudou.com/listplay/zzdE77v6Mmo.html'))


# Generated at 2022-06-26 13:06:11.955950
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    pls = TudouPlaylistIE()
    assert pls._match_id(url) == 'zzdE77v6Mmo'
    assert pls.ie_key() == 'Tudou'



# Generated at 2022-06-26 13:06:21.881005
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert IE.IE_NAME == 'tudou:playlist', 'unexpected IE_NAME for class TudouPlaylistIE'
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html', \
                    'unexpected valid URL pattern for class TudouPlaylistIE'


# Generated at 2022-06-26 13:06:26.880519
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id =  'ECK_EbZcMzo'
    url = 'http://www.tudou.com/albumplay/%s' % album_id
    ie = TudouAlbumIE(url)
    assert(ie.album_id == album_id)

# Generated at 2022-06-26 13:06:38.956040
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    assert_equal(a.IE_NAME, 'tudou:playlist')
    assert_equal(a.re._pattern,
        r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert_equal(a.re.match('http://www.tudou.com/listplay/zzdE77v6Mmo.html').group('id'), 'zzdE77v6Mmo')
    assert_equal(a.re.match('https://www.tudou.com/listplay/zzdE77v6Mmo.html').group('id'), 'zzdE77v6Mmo')

# Generated at 2022-06-26 13:07:51.763627
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from tudou import TudouAlbumIE
	from tudou import InfoExtractor

	TAI = TudouAlbumIE()
	IE = InfoExtractor()
	TAI.IE_NAME = 'TudouAlbumIE'
	TAI.IE_DESC = 'Youku Tudou Inc.'
	TAI.IE_VERSION = '20140209'
	IE_NAME = 'InfoExtractor'
	IE_DESC = 'Generic information extractor for Internet Video'
	IE_VERSION = '20140217'

	assert(TAI.IE_NAME != IE_NAME)
	assert(TAI.IE_DESC != IE_DESC)
	assert(TAI.IE_VERSION != IE_VERSION)

# Generated at 2022-06-26 13:08:03.600173
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlistIE = TudouPlaylistIE()
    assert playlistIE.IE_NAME == 'tudou:playlist'
    assert playlistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:08:05.424745
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-26 13:08:06.377748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE();

# Generated at 2022-06-26 13:08:13.828845
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE(_download_json)('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:08:18.132304
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    from .tudou import TudouPlaylistIE

    assert issubclass(TudouAlbumIE, InfoExtractor)
    assert issubclass(TudouPlaylistIE, InfoExtractor)


# Generated at 2022-06-26 13:08:19.454927
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-26 13:08:27.471567
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Test to check if the constructor of class TudouPlaylistIE raises
    a TypeError if the url is not formatted in the expected way
    """
    # Create an instance of class TudouPlaylistIE
    # with an invalid url
    # This should raise a TypeError
    try:
        TudouPlaylistIE("http://www.tudou.com")
    except TypeError:
        # If exception is raised, tests pass (no exception should be raised)
        assert True
    else:
        # If no exception is raised, tests fail
        assert False


# Generated at 2022-06-26 13:08:27.897642
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass

# Generated at 2022-06-26 13:08:31.092915
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url_playlist = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_playlist_ie = TudouPlaylistIE(url_playlist)
    tudou_playlist_ie.extract()

# Generated at 2022-06-26 13:10:59.407836
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #assert main.TudouPlaylistIE(
        #'http://www.tudou.com/listplay/9Xx3q3hraoI.html').playlist_id == 'http://www.tudou.com/listplay/9Xx3q3hraoI.html'
    assert True


# Generated at 2022-06-26 13:11:03.014936
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    assert t.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-26 13:11:04.654683
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE()

# Generated at 2022-06-26 13:11:13.412896
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:11:18.263854
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Test for constructor of class TudouAlbumIE
    '''
    # Construct an instance of class TudouAlbumIE
    i = TudouAlbumIE()

# Generated at 2022-06-26 13:11:30.831924
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import test_compat
    test_compat.init()
    from . import tudouie
    test_compat.start()
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    tudou_albumie = tudouie.TudouAlbumIE(url)
    test_compat.assert_equal(tudou_albumie.id, 'v5qckFJvNJg', msg="Test invalid album_id")

# Generated at 2022-06-26 13:11:42.463928
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	class MyArgs(object):
		def __init__(self, url):
			self._url = url
			self.method = None
			self.username = None
			self.password = None
			self.usenetrc = None
			self.verbose = False
			self.quiet = False
			self.forceurl = False
			self.forcetitle = False
			self.forcethumbnail = False
			self.forcedescription = False
			self.forcefilename = False
			self.forcejson = False
			self.dump_single_json = False
			self.simulate = False
			self.skip_download = None
			self.format = None

# Generated at 2022-06-26 13:11:49.540581
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:11:56.037992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/yyyyyyyyyyy/'
    expect_result = 'http://www.tudou.com/listplay/yyyyyyyyyyy/'
    assert url == expect_result


# Generated at 2022-06-26 13:12:03.095435
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import test_protocol_relative_url
    class_name = 'TudouAlbumIE'
    test_protocol_relative_url(
        '%s("https://www.tudou.com/albumplay/v5qckFJvNJg.html")' % class_name)
    test_protocol_relative_url(
        '%s("//www.tudou.com/albumplay/v5qckFJvNJg.html")' % class_name)
