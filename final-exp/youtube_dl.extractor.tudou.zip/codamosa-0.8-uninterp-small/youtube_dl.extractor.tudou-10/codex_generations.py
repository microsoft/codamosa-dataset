

# Generated at 2022-06-26 13:02:28.612735
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:02:29.751501
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:38.946598
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert tudou_playlist_i_e_0.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_i_e_0._TESTS == [{'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209, 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'}]


# Generated at 2022-06-26 13:02:41.805869
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

if __name__ == '__main__':
    test_case_0()
    test_TudouAlbumIE()

# Generated at 2022-06-26 13:02:43.653122
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:02:45.080464
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE_0 = TudouAlbumIE()
    assert test_TudouAlbumIE_0 != None

# Generated at 2022-06-26 13:02:47.612173
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:48.884648
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:53.033107
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_i_e_0 = TudouAlbumIE()

test_case_0()
test_TudouAlbumIE()

# Generated at 2022-06-26 13:02:54.024741
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    return TudouAlbumIE()

# Generated at 2022-06-26 13:03:02.227534
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE();

# Generated at 2022-06-26 13:03:09.467512
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
# Operation test for missing url argument
    url = ""
    tudou_playlist_i_e_0._real_extract(url)
# Operation test for blank url argument
    url = "           "
    tudou_playlist_i_e_0._real_extract(url)
# Operation test for string type url argument
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist_i_e_0._real_extract(url)


# Generated at 2022-06-26 13:03:10.125628
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:12.820483
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case_0()
    tudou_playlist_i_e = TudouPlaylistIE()

if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-26 13:03:26.216017
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Check calling constructor with empty argument
    try:
        TudouAlbumIE()
        assert False, 'Unexpected success constructing TudouAlbumIE()'
    except TypeError:
        assert True
    # Check calling constructor with proper argument
    try:
        TudouAlbumIE(None, 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    except TypeError:
        assert False, 'Unexpected failure constructing TudouAlbumIE(None, \'http://www.tudou.com/albumplay/v5qckFJvNJg.html\')'
    # Check calling constructor with invalid argument

# Generated at 2022-06-26 13:03:29.340549
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:03:30.708362
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:03:35.123992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:38.746923
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:03:43.960942
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        _TudouAlbumIE = TudouAlbumIE()
        _TudouAlbumIE.suite()
    except Exception as exp:
        print(exp)


# Generated at 2022-06-26 13:04:02.904566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Initialize TudouAlbumIE, parser of URL to test
    albumIE = TudouAlbumIE(TudouAlbumIE._VALID_URL)
    # Assert albumIE is an instance of InfoExtractor
    assert isinstance(albumIE, InfoExtractor)
    # Assert the URL parser only works on album URLs
    assert albumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert albumIE._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg') == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:04:03.708331
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-26 13:04:17.378894
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import FakeYDL

    class FakeOptions(object):
        forcejson = False

    def video_exists_test(playlist_id):
        return True

    class FakeYDL(FakeYDL):
        @staticmethod
        def to_screen(msg):
            return msg

        @staticmethod
        def urlopen(url, data=None):
            """Fake urlopen using a cache.

            Some HTTP requests are made very often. Use a cache to fake the same
            response.
            """
            # Cache the response
            # TODO: add the "cache" to the tests
            if url not in FAKE_URLOPEN_CACHE:
                FAKE_URLOPEN_CACHE[url] = _fake_urlopen(self, url, data)
            return FAKE_URLOPEN_CACHE

# Generated at 2022-06-26 13:04:22.369330
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.name == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:04:27.931282
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert_equals(TudouPlaylistIE._VALID_URL,
        r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    )

# Generated at 2022-06-26 13:04:32.394810
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('zzdE77v6Mmo')

# Generated at 2022-06-26 13:04:39.119538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE('', {'id': 'zzdE77v6Mmo'})
    assert IE.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE._PLAYLIST_TITLE == '播放列表'


# Generated at 2022-06-26 13:04:43.486449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  infoExtractor = InfoExtractor()
  print (infoExtractor.suitable("http://www.tudou.com/albumplay/v5qckFJvNJg.html"))

# Generated at 2022-06-26 13:04:51.215596
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # test_TudouPlaylistIE() can be run by "python -m unittest discover -s tests" at command line
    # if __name__ != '__main__':
    #     return 0
    # print 'Test TudouPlaylistIE'

# Generated at 2022-06-26 13:05:03.605795
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	#
	# Note that the following is for testing purpose only.
	#
	# It will be really concerneing if following lines are
	# added into production code.
	#
	import unittest
	import sys
	import types
	import os

	# As a style guideline,
	# module names are short, all lowercase and underscores separating words.
	# Thus, the name of a module is often "__init__.py".
	# If a module name starts with an underscore,
	# it's treated as a private name, e.g. _private_module_name.py
	# and can't be imported.
	#
	# This would result in the following error.
	#
	# ImportError: No module named common
	#
	# In order to solve this, sys.path will have to be modified.
	

# Generated at 2022-06-26 13:05:19.219894
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    je = TudouAlbumIE()
    jr = je._real_extract(je._TESTS[0]['url'])
    print(jr)


# Generated at 2022-06-26 13:05:24.916674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing TudouPlaylistIE")
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.playlist_mincount == 209


# Generated at 2022-06-26 13:05:36.301119
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    t = InfoExtractor(name ='TudouPlaylistIE', ie = 'TudouPlaylist',
                      ie_key ='Tudou:playlist',
                      patterns =[r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'],
    		      description ='播放列表')
    assert t.name == 'TudouPlaylistIE'
    assert t.ie == 'TudouPlaylist'
    assert t.ie_key == 'Tudou:playlist'
    assert t.description == '播放列表'

# Generated at 2022-06-26 13:05:45.577161
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .testcases import listplay1, listplay2
    api = TudouPlaylistIE()

    result = api._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')
    assert result == listplay1

    result = api._download_json('http://www.tudou.com/tvp/plist.action?lcode=nPOMZ8cH40Y', 'nPOMZ8cH40Y')
    assert result == listplay2



# Generated at 2022-06-26 13:05:55.778421
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
	    'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
	    'info_dict': {
	        'id': 'v5qckFJvNJg',
	    },
	    'playlist_mincount': 45,
	}]


# Generated at 2022-06-26 13:05:58.463638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .tudou import TudouPlaylistIE
    from .common import InfoExtractor

    # Test constructor
    assert "playlist" in TudouPlaylistIE._TYPE
    assert False == InfoExtractor.suitable(TudouPlaylistIE)

# Generated at 2022-06-26 13:06:03.070426
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert album.album_id == 'v5qckFJvNJg' 


# Generated at 2022-06-26 13:06:06.553497
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_instance = TudouAlbumIE(
        # Stub downloader instance
        {
            'params': {
                'username': 'test_username',
                'password': 'test_password',
            },
        }
    );
    assert(tudou_album_instance.username == 'test_username');
    assert(tudou_album_instance.password == 'test_password');

# Generated at 2022-06-26 13:06:09.896329
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	   obj = TudouPlaylistIE()

# Generated at 2022-06-26 13:06:14.698505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # test for invalid URL
    try:
        ie.url_result('12345678910', 'Tudou', '123', '123')
    except TypeError:
        pass
    else:
        raise Exception('URLValudationError exception was expected')

# Generated at 2022-06-26 13:06:50.107082
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    s = '<a href="http://www.tudou.com/albumplay/' + album_id + '.html">'
    a = TudouAlbumIE.TudouAlbumIE(s, album_id)
    assert a.album_id == album_id

# Generated at 2022-06-26 13:06:59.854276
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == TudouPlaylistIE._VALID_URL
    assert TudouPlaylistIE()._TESTS == TudouPlaylistIE._TESTS
    assert TudouPlaylistIE().IE_NAME == TudouPlaylistIE.IE_NAME
    assert TudouPlaylistIE()._real_extract == TudouPlaylistIE._real_extract


# Generated at 2022-06-26 13:07:07.538538
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }


# Generated at 2022-06-26 13:07:16.207712
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('TudouAlbumIE', 'Tudou:album', ['http://www.tudou.com/albumplay/v5qckFJvNJg.html'])
    assert TudouAlbumIE('TudouAlbumIE', 'Tudou:album', ['http://www.tudou.com/albumcover/v5qckFJvNJg.html'])
    assert TudouAlbumIE('TudouAlbumIE', 'Tudou:album', ['http://www.tudou.com/albumplay/v5qckFJvNJg'])
    assert TudouAlbumIE('TudouAlbumIE', 'Tudou:album', ['http://www.tudou.com/albumcover/v5qckFJvNJg'])
    assert Tud

# Generated at 2022-06-26 13:07:20.757730
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:07:24.566322
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    TudouAlbumIE(url, {})

# Generated at 2022-06-26 13:07:28.834217
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
    assert tudou_playlist_ie._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo') is not None
    print('Unit test of TudouPlaylistIE is successful!')

# Generated at 2022-06-26 13:07:42.069512
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	from tudou.extractor import TudouPlaylistIE
	from tudou.compat import compat_urllib_request
	from tudou.compat import compat_urllib_error
	try:
		compat_urllib_request.urlopen(url).read()
	except compat_urllib_error.URLError as e:
		print('Failed to load the URL %s: %s' % (url, e.reason))
	ie = TudouPlaylistIE()
	# test for method _real_extract
	res = ie._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:07:51.582492
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:07:56.312287
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    ie._match_id(TudouAlbumIE._VALID_URL) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:09:04.335323
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()
    tudou_playlist.IE_NAME = "tudou:playlist"
    tudou_playlist._VALID_URL = 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    tudou_playlist._TESTS = [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    return tudou_playlist


# Generated at 2022-06-26 13:09:11.661516
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
  inst = TudouAlbumIE(TudouAlbumIE.IE_NAME)
  inst.url = url
  assert inst._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:09:22.049849
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Unit test of class TudouAlbumIE")
    obj = TudouAlbumIE()
    print(obj.IE_NAME)
    print(obj._VALID_URL)
    print(obj._TESTS)

    print(obj.IE_NAME)
    for item in obj._TESTS:
        print(item)
    pass


# Generated at 2022-06-26 13:09:26.635674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE([])._extract_info(test_url)
    assert ie["_type"] == "url"
    assert ie["url"] == "http://www.tudou.com/programs/view/zzdE77v6Mmo"
    assert ie["ie_key"] == "Tudou"
    assert ie["id"] == "zzdE77v6Mmo"
    assert ie["title"] == "传说婚姻"


# Generated at 2022-06-26 13:09:31.720558
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE('Tudou', 'www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou.get_playlist_id() == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:09:33.525774
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	infoExtractor = InfoExtractor()
	tudouAlbumIE = TudouAlbumIE(infoExtractor)

# Generated at 2022-06-26 13:09:44.749806
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    import sys
    sys.path.append('../..')
    from ykdl.util.html import get_content
    from ykdl.extractors import (
        tudou
    )
    
    class TestTudouAlbumIE(unittest.TestCase):

        def setUp(self):
            tudou.supertv.init()

        def test_real_extract(self):
            self.assertEqual(
                tudou.TudouAlbumIE()._real_extract(
                    'http://www.tudou.com/albumcover/v5qckFJvNJg.html'),
                []
            )
        def test_constructor_common(self):
            ie = tudou.TudouAlbumIE()

# Generated at 2022-06-26 13:09:54.257375
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    p = TudouPlaylistIE('tudou:playlist')

# Generated at 2022-06-26 13:09:58.224683
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:10:06.194986
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'