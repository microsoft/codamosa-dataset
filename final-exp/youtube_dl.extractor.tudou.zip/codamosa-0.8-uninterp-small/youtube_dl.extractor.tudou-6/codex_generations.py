

# Generated at 2022-06-26 13:02:14.778374
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-26 13:02:16.146629
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:16.916522
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO
    pass


# Generated at 2022-06-26 13:02:17.978201
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:02:20.858940
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:27.732072
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert tudou_album_i_e_0.IE_NAME == 'tudou:album'
    assert tudou_album_i_e_0._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_i_e_0._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }


# Generated at 2022-06-26 13:02:35.853233
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        assert (TudouPlaylistIE()._VALID_URL == 
            r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    except AssertionError:
        raise AssertionError("TudouPlaylistIE has wrong _VALID_URL.")
    try:
        assert (TudouPlaylistIE().IE_NAME == 'tudou:playlist')
    except AssertionError:
        raise AssertionError("TudouPlaylistIE has wrong IE_NAME.")

# Generated at 2022-06-26 13:02:37.011058
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS


# Generated at 2022-06-26 13:02:37.937259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	obj = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:39.382540
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_1 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:44.226434
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
	TudouAlbumIE(tudou_album_url)

# Generated at 2022-06-26 13:02:50.704718
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	assert ie.IE_NAME == 'tudou:playlist'
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert ie._TESTS[0] == {
		'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
		'info_dict': {
			'id': 'zzdE77v6Mmo',
		},
		'playlist_mincount': 209,
	}

# Generated at 2022-06-26 13:03:02.044334
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_TudouPlaylistIE = TudouPlaylistIE()
    assert test_TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert test_TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test_TudouPlaylistIE._TESTS[0]['url'] == url
    assert test_TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:03:04.679890
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE()._real_extract(url)


# Generated at 2022-06-26 13:03:06.578548
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None)
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:03:08.437851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    # No need to test the code because the function has been tested before.


# Generated at 2022-06-26 13:03:12.374154
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('TudouAlbumIE')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:03:13.548010
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE

# Generated at 2022-06-26 13:03:15.146282
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()



# Generated at 2022-06-26 13:03:25.537340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor=InfoExtractor()
    result=infoExtractor._real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")

    assert result["_type"]=="playlist"
    assert result["entries"][0]["url"]=="http://www.tudou.com/programs/view/3n1CkJvnxmw"
    assert result["entries"][0]["_type"]=="url"
    assert result["entries"][0]["ie_key"]=="Tudou"


# Generated at 2022-06-26 13:03:35.141379
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # check the constructor of class TudouAlbumIE
    t = TudouAlbumIE(TudouAlbumIE._VALID_URL, {})
    assert t._real_extract != None

# Generated at 2022-06-26 13:03:43.670270
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('test')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:03:56.966672
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """TudouPlaylistIE constructor test."""
    impo = __import__(__name__, globals(), locals(), ['TudouPlaylistIE', 'TestYoutubePlaylistBaseInfoExtractor'])
    TestYoutubePlaylistBaseInfoExtractor = impo.TestYoutubePlaylistBaseInfoExtractor
    TudouPlaylistIE = impo.TudouPlaylistIE
    test = TestYoutubePlaylistBaseInfoExtractor(TudouPlaylistIE)
    test.run_constructor_test(TudouPlaylistIE)


# Generated at 2022-06-26 13:04:04.182214
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('Testing Tudou playlist extraction')
    tp_ie = TudouPlaylistIE()
    tp_ie.IE_NAME = 'tudou:playlist'
    tp_ie.url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tp_ie.IE_DESC = 'tudou:playlist'
    tp_ie.info_dict = {
        'id': 'zzdE77v6Mmo'
    }
    tp_ie.playlist_mincount = 209
    print(tp_ie)


# Generated at 2022-06-26 13:04:08.294625
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
	

# Generated at 2022-06-26 13:04:12.354042
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE('test_id')
    assert tudouPlaylist.IE_NAME == 'tudou:playlist'
    assert tudouPlaylist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:04:21.944499
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE(None).IE_NAME is TudouAlbumIE.IE_NAME)
    assert(TudouAlbumIE(None)._VALID_URL is TudouAlbumIE._VALID_URL)
    assert(TudouAlbumIE(None)._TESTS is TudouAlbumIE._TESTS)
    assert(TudouAlbumIE(None)._TEST is None)
    assert(TudouAlbumIE(None)._WORKING is True)


# Generated at 2022-06-26 13:04:26.936962
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = u'ttp://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info = TudouPlaylistIE(url)

    assert info.extract() == 209

# Generated at 2022-06-26 13:04:28.324461
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    c = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert c.IE_NAME == "Tudou"

# Generated at 2022-06-26 13:04:30.999228
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    TudouAlbumIE(url)

# Generated at 2022-06-26 13:04:51.349538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylist = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(tudouPlaylist.ie_key() == 'TudouPlaylist')
    assert(tudouPlaylist.ie_id() == 'zzdE77v6Mmo')
    assert(tudouPlaylist.playlist_mincount() == 209)


# Generated at 2022-06-26 13:04:59.533297
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    
    class Mock:
        pass
    
    test_TudouPlaylistIE = TudouPlaylistIE(Mock())
    
    assert hasattr(test_TudouPlaylistIE, "IE_NAME")
    assert hasattr(test_TudouPlaylistIE, "_VALID_URL")
    assert hasattr(test_TudouPlaylistIE, "_TESTS")

# Generated at 2022-06-26 13:05:08.008546
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_instance = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_instance.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:05:15.548968
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE("https://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert IE.IE_NAME == "tudou:playlist"
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:05:25.395879
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.suitable(url), 'Should be suitable for %s' % (url,)
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist', 'Should be tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == tudou_playlist_ie._VALID_URL_TEST.format('tudou:playlist'), 'Should contain tudou:playlist'
    assert tudou_playlist_ie._downloader is not None, 'Should have downloader'


# Generated at 2022-06-26 13:05:30.305070
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie = TudouPlaylistIE()
	tudou_playlist_ie.playlist_result(entries = [], playlist_id = 'zzdE77v6Mmo')

# Generated at 2022-06-26 13:05:32.868112
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

# Generated at 2022-06-26 13:05:45.784591
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL is not None
    assert TudouPlaylistIE._TESTS is not None
    assert TudouPlaylistIE._FILE_SUFFIX is not None
    assert TudouPlaylistIE._FILE_SUFFIX_RE is not None
    assert TudouPlaylistIE._GEO_BYPASS is not None
    assert TudouPlaylistIE._GEO_COUNTRIES is not None
    assert TudouPlaylistIE._JS_TO_JSON is not None
    assert TudouPlaylistIE._NETRC_MACHINE is not None
    assert TudouPlaylistIE._PSP_BASE_URL is not None
    assert TudouPlaylistIE._TEMPLATE_URL is not None
    assert TudouPlaylistIE._TEMPLATE_URL_QUERY is not None
    assert Tud

# Generated at 2022-06-26 13:05:47.398344
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import extractor._test_tudou
	extractor._test_tudou.test_TudouPlaylistIE()

# Generated at 2022-06-26 13:05:56.323284
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_IE = TudouPlaylistIE()
    assert playlist_IE.IE_NAME == 'tudou:playlist'
    assert playlist_IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist_IE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:06:24.564989
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for: TudouAlbumIE()
    # TODO: remove this function after tudou.py fix
    return

# Generated at 2022-06-26 13:06:33.669322
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test the constructor of TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert(ie.url == url)
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')

# Generated at 2022-06-26 13:06:39.149170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # param = tudou.com/albumcover/v5qckFJvNJg
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    tudouAlbum = TudouAlbumIE()
    info = tudouAlbum._real_extract(url)
    print(info)


# Generated at 2022-06-26 13:06:44.398554
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' == tuple('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' != tuple('http://www.tudou.com/listplay/zzdE77v6Mmo.htm')
    assert 'http://www.tudou.com/listplay/zzdE77v6Mmo.html' != tuple('http://www.tudou.com/listplay/zzdE77v6Mm.html')

# Generated at 2022-06-26 13:06:49.038271
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    extractor = TudouAlbumIE(object)

    assert extractor._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:06:56.770530
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:07:03.319089
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is not None
    assert ie._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html') is not None


# Generated at 2022-06-26 13:07:12.062540
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:07:15.892722
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('TudouAlbumIE', 'http://www.tudou.com/albumcover/v5qckFJvNJg')

# Generated at 2022-06-26 13:07:27.750623
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    # test valid URL. (test_valid_url)
    valid_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert(ie._match_id(valid_url) == 'zzdE77v6Mmo')

    # test valid URL. (test_valid_url)
    valid_url = "http://www.tudou.com/listplay/zzdE77v6Mmo"
    assert(ie._match_id(valid_url) == 'zzdE77v6Mmo')

    # test invalid URL. (test_invalid_url)
    invalid_url = "http://www.tudou.com/listplay/zzdE77v6Mm.html"

# Generated at 2022-06-26 13:08:29.479086
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # constructor of class TudouAlbumIE
    assert(TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html') is not None)



# Generated at 2022-06-26 13:08:34.036404
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE()
    # test inheriting from class InfoExtractor and class TudouAlbumIE
    assert isinstance(td, TudouAlbumIE)
    assert isinstance(td, InfoExtractor)



# Generated at 2022-06-26 13:08:38.562823
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert isinstance(instance, TudouPlaylistIE)


# Generated at 2022-06-26 13:08:48.076966
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-26 13:08:52.984886
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    object = TudouPlaylistIE()
    url = object._real_extract
    url = url('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert url['id'] == playlist_id



# Generated at 2022-06-26 13:09:02.716734
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .embed import Tudou as tudou_embed
    from .tudou import TudouIE as tudou_ie
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    match = tudou_embed._VALID_URL.match(url)
    test_ie = TudouPlaylistIE(match)
    assert type(test_ie) == TudouPlaylistIE

    test_ie = tudou_ie(match)
    assert type(test_ie) == TudouPlaylistIE

# Generated at 2022-06-26 13:09:13.830436
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    obj = TudouPlaylistIE(url)
    assert obj.url == url
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert obj.IE_NAME == 'tudou:playlist'
    assert obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert obj._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert obj._TESTS[0]['playlist_mincount']

# Generated at 2022-06-26 13:09:19.408343
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-26 13:09:26.157320
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert_raises(RegexNotFoundError, ie._match_id, "https://v.youku.com/v_show/id_XMTM5OTYyMjY4OA==.html")
    assert ie._match_id(ie.VALID_URL) == "v5qckFJvNJg"

# Generated at 2022-06-26 13:09:32.384952
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
        tudou_playlist = TudouPlaylistIE()
        assert tudou_playlist.__class__ == TudouPlaylistIE
        assert tudou_playlist.IE_NAME == 'tudou:playlist'
        assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:12:14.715534
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  print("Testing constructor")
  tudou_playlist_ie = TudouAlbumIE("test_url")
  assert tudou_playlist_ie.__class__ == TudouAlbumIE
  assert tudou_playlist_ie.extractor_key == "TudouAlbumIE"
  assert tudou_playlist_ie.ie_key == "Tudou"
  assert tudou_playlist_ie.video_id == "test_url"
  assert tudou_playlist_ie.url == "test_url"
  assert tudou_playlist_ie.query == {'id': 'test_url'}
  print("Passed!")
