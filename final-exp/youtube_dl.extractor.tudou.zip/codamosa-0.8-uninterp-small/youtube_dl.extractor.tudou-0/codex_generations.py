

# Generated at 2022-06-26 13:02:14.930343
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:23.236979
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_i_e_0.ie_key() == 'TudouPlaylist'
    assert tudou_playlist_i_e_0.server_encoding == None
    assert tudou_playlist_i_e_0._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_i_e_0._downloader == None
    assert tudou_playlist_i_e_0._WORKING == True

# Unit test

# Generated at 2022-06-26 13:02:24.466564
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE().assertTrue()



# Generated at 2022-06-26 13:02:25.909543
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_1 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:28.851173
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if isinstance(tudou_album_i_e_0, InfoExtractor):
        pass


# Generated at 2022-06-26 13:02:30.244862
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test errors
    assert(not TudouPlaylistIE._WORKING)


# Generated at 2022-06-26 13:02:33.628133
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Unit tests for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:02:36.007837
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:37.165022
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:39.932222
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()

if __name__ == '__main__':
    test_case_0()
    test_TudouPlaylistIE()

# Generated at 2022-06-26 13:02:46.694614
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    expected_obj_name = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj = TudouAlbumIE(expected_obj_name)
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:02:56.946973
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    constructor = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = constructor._match_id(url)

# Generated at 2022-06-26 13:02:58.990298
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist == type(playlist)


# Generated at 2022-06-26 13:03:03.376111
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouIE = TudouPlaylistIE()
    assert 'tudou:playlist' == TudouIE._real_extract(url)

# Generated at 2022-06-26 13:03:08.275327
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_name = 'TudouAlbumIE'
    arg = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    instance = TudouAlbumIE(class_name, arg)
    assert(instance._TESTS[0]['url'] == TudouAlbumIE._TESTS[0]['url'])


# Generated at 2022-06-26 13:03:18.094444
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()

    assert ie._VALID_URL == "https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html"
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209

    assert ie._real_extract(url) != None

# Generated at 2022-06-26 13:03:20.847378
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test constructing a class
    assert isinstance(TudouPlaylistIE, InfoExtractor)


# Generated at 2022-06-26 13:03:30.003762
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test parameter: url, expected result
    cases = [
        # 0
        (
            'http://www.tudou.com/albumcover/HOyV7Mg41Fo.html',
            'http://www.tudou.com/albumplay/HOyV7Mg41Fo.html'
        ),
        # 1
        (
            'http://www.tudou.com/albumplay/HOyV7Mg41Fo.html',
            'http://www.tudou.com/albumplay/HOyV7Mg41Fo.html'
        ),
    ]

# Generated at 2022-06-26 13:03:40.190156
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Construct a TudouPlaylistIE instance
    ie = TudouPlaylistIE()
    # Test its _VALID_URL attribute
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Test its _TESTS attribute
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:03:46.188266
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_playlist_ie = TudouAlbumIE('www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:03:54.542050
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert '__main__' == __name__
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 13:03:58.149607
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    assert ie.ie_key() == 'tudou:album'
    assert ie.ie_key() == ie.IeKey(), "ie_key() should equal IeKey()"

# Generated at 2022-06-26 13:04:05.311436
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_name() == 'Tudou:album'
    assert ie.valid_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.valid_url('http://www.tudou.com/albumcover/v5qckFJvNJg')
    assert ie.valid_url('http://www.tudou.com/albumplay/v5qcKFJvNJg.html')
    assert not ie.valid_url('http://www.tudou.com/albumplay/v5qckFJvNJg')


# Generated at 2022-06-26 13:04:13.544289
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    ie._real_initialize()
    ie._real_extract(url)
    assert(ie.IE_NAME == 'tudou:playlist')
    assert(ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')


# Generated at 2022-06-26 13:04:19.857164
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    data = TudouAlbumIE()._real_extract(url)
    assert data['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:04:21.049217
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	playlistie = TudouPlaylistIE()
	return playlistie

# Generated at 2022-06-26 13:04:26.492722
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	x = TudouAlbumIE()
	res = x._real_extract(url)
	y = res['entries']

# Generated at 2022-06-26 13:04:32.394505
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    assert True



# Generated at 2022-06-26 13:04:34.560898
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    print(ie)



# Generated at 2022-06-26 13:04:36.562417
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    Playlist = TudouPlaylistIE()

# Generated at 2022-06-26 13:04:56.580346
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing the constructor of a TudouPlaylistIE object...")
    playlist = TudouPlaylistIE()
    print("Testing the constructor of a TudouPlaylistIE object finished")


# Generated at 2022-06-26 13:05:04.044105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie.ie_key == 'TudouAlbum'
    assert ie.video_id == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

if __name__ == '__main__':
    test_TudouAlbumIE()

# Generated at 2022-06-26 13:05:10.221500
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    assert(IE.P_STYPE == 'plist')
    assert(IE.P_CODE_LABEL == 'lcode')
    assert(IE.DETAIL_URL == 'http://www.tudou.com/tvp/plist.action')



# Generated at 2022-06-26 13:05:13.252155
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    ie = TudouPlaylistIE()
    assert ie.suitable(url)
    assert ie.extract(url) is not None


# Generated at 2022-06-26 13:05:19.072806
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    b = TudouPlaylistIE()
    assert b._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert b._TESTS != []


# Generated at 2022-06-26 13:05:22.423992
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)


# Generated at 2022-06-26 13:05:35.433870
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie = TudouPlaylistIE()
	assert(tudou_playlist_ie.IE_NAME == 'tudou:playlist')
	assert(tudou_playlist_ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
	assert(len(tudou_playlist_ie._TESTS) == 1)
	assert(tudou_playlist_ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:05:47.036788
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	from tudou.tudouie import TudouAlbumIE
	from tudou.tudouie import _VALID_URL
	from tudou.tudouie import IE_NAME
	from tudou.tudouie import _TESTS
	from tudou.tudouie import _TEST
	from tudou.tudouie import _match_id
	from tudou.tudouie import _download_json
	from tudou.tudouie import _get_media_info
	from tudou.tudouie import _get_video_from_vid
	from tudou.tudouie import _extract_from_code
	from tudou.tudouie import _real_extract
	from tudou.tudouie import _real

# Generated at 2022-06-26 13:05:54.226680
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    a = TudouPlaylistIE()
    assert(a.IE_NAME == 'tudou:playlist')
    assert(a._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(a._TESTS[0] == {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    })


# Generated at 2022-06-26 13:06:03.972923
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__name__ == 'tudou:playlist' # check name
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'  # check ie name
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' # check regex pattern
    assert len(TudouPlaylistIE._TESTS) == 1 # check number of test cases


# Generated at 2022-06-26 13:06:43.746687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #1. Test construction with valid URL
    album_url1 = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    album1 = TudouAlbumIE(album_url1)
    assert album1.IE_NAME == 'tudou:album'
    assert album1._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert album1._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert album1._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:06:45.552816
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:06:54.334026
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:06:59.375105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  import sys
  sys.path.append('E:\workspace-python\ytdl')
  #IE_NAME = 'tudou:album'
  #_VALID_URL = r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
  #_TESTS = ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']
  #_TESTS = []
  #_TESTS = ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']
  _TESTS = ['http://www.tudou.com/albumplay/v5qckFJvNJg.html']


# Generated at 2022-06-26 13:07:03.996830
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("https://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:07:15.728878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudouAlbumIE = TudouAlbumIE._instantiate(url)
	assert tudouAlbumIE.ie_key() == 'Tudou:album'
	assert tudouAlbumIE.suitable(url)
	assert tudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:07:27.752018
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # The argument of constructor:
    #   1. The name of extractor.
    #   2. YoutubeUrlMatcher.
    #
    # Each youtube extractor class must derieve from YoutubeIE
    ie = TudouPlaylistIE("TudouPlaylist", "https?://(?:www\.)?tudou.com/listplay/.*")
    assert ie.ie_key() == 'TudouPlaylist'
    test_urls = [
        "http://www.tudou.com/listplay/zzdE77v6Mmo.html",
        "http://www.tudou.com/listplay/xikxVAt6hMk.html",
        "http://www.tudou.com/listplay/sZsncW8sdms.html",
    ]

# Generated at 2022-06-26 13:07:36.355259
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    class TestTudouPlaylistIE(unittest.TestCase):
        def test_valid_url(self):
            tudou_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
            valid_url = TudouPlaylistIE._VALID_URL
            self.assertRegexpMatches(tudou_url, valid_url)
    unittest.main()

# Generated at 2022-06-26 13:07:50.480071
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import sys
    if sys.version_info.major == 2:
        import urllib
    else:
        import urllib.parse as urllib

    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    test_object = TudouAlbumIE()
    assert test_object._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'
    assert test_object._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:07:57.910919
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert(inst.IE_NAME == 'tudou:album')
    assert(inst.ie_key() == 'TudouAlbum')
    assert(inst._VALID_URL is not None)

# Generated at 2022-06-26 13:09:08.841108
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except:
        assert False, 'Constructor of class TudouPlaylistIE throw an exception.'
    else:
        assert True


# Generated at 2022-06-26 13:09:09.667527
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()

# Generated at 2022-06-26 13:09:11.604636
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()



# Generated at 2022-06-26 13:09:19.683588
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE._TESTS[0]["info_dict"] == dict(id = 'v5qckFJvNJg'))



# Generated at 2022-06-26 13:09:21.605496
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE(TudouPlaylistIE._VALID_URL)
	assert ie.IE_NAME == "tudou:playlist"

# Generated at 2022-06-26 13:09:22.228644
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

# Generated at 2022-06-26 13:09:25.578510
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(_TUDOU_ALBUM_TEST_PARAMS) # call TudouAlbumIE constructor, initialize the object data
    assert ie.ie_key() == 'Tudou:album' # assert if ie_key or self.IE_KEY == 'Tudou:album'
    assert ie.ie_name() == 'Tudou:album' # assert if ie_name or self.IE_NAME == 'Tudou:album'

# Generated at 2022-06-26 13:09:31.916936
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.ie_key() == 'Tudou:album'
    assert ie.ie_name() == 'tudou:album'
    assert ie.SUCCEEDED == object()
    assert ie.FAILED == object()
    assert ie.EXCEPTION == object()
    assert ie.EXTRACTING == object()



# Generated at 2022-06-26 13:09:34.987914
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        test_url='http://www.tudou.com/listplay/zzdE77v6Mmo.html'
        TudouPlaylistIE(test_url)
    except Exception as e:
        print("Invalid URL: ", e)
        return 1
    return 0


# Generated at 2022-06-26 13:09:45.068263
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    PlayListTest = TudouPlaylistIE('TudouPlaylistIE_test')
    assert PlayListTest.IE_NAME == 'tudou:playlist'
    assert PlayListTest._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert PlayListTest._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert PlayListTest._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert PlayListTest._TESTS[0]['playlist_mincount'] == 209
