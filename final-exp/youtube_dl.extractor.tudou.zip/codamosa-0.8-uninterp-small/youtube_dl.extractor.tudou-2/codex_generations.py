

# Generated at 2022-06-26 13:02:19.281366
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.IE_NAME
    tudou_playlist_i_e = TudouPlaylistIE()
    assert tudou_playlist_i_e.IE_NAME


# Generated at 2022-06-26 13:02:20.922524
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:22.383214
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()



# Generated at 2022-06-26 13:02:25.536423
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test basic instantiation of class TudouPlaylistIE
    tudou_playlist_i_e = TudouPlaylistIE()

    # Test all features of class TudouPlaylistIE
    test_case_0()


# Generated at 2022-06-26 13:02:26.012171
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:02:35.514166
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    #assert [u'zzdE77v6Mmo'] == tudou_playlist_i_e_0._MATCH_ID # 'zzdE77v6Mmo' is expected
    assert tudou_playlist_i_e_0._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' # 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' is expected


# Generated at 2022-06-26 13:02:39.185971
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:02:41.014762
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudou_playlist_ie_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:42.597242
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:49.007578
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()
    # the initial value of the instance is null
    assert(tudou_album_i_e_0.IE_NAME is not None)
    assert(tudou_album_i_e_0._VALID_URL is not None)
    assert(tudou_album_i_e_0._TESTS is not None)
    assert(tudou_album_i_e_0.ie_key() is not None)
    assert(tudou_album_i_e_0._WORKING is not None)

test_TudouAlbumIE()
test_case_0()


# Generated at 2022-06-26 13:03:03.246332
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print("constructing a TudouPlaylistIE object ...")
	fetch_url_info = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	douban = TudouPlaylistIE(fetch_url_info,"")
	print("id: %s" % douban.extractor_id)
	print("url: %s" % douban.url)
	print("IE_NAME: %s" % douban.IE_NAME)
	print("extractor id: %s" % douban.extractor_id)
	print("fetching info for %s ..." % douban.url)
	douban.fetch_info()
	print("Fetch result for %s ..." % douban.url)
	print(douban.fetch_result)

# Generated at 2022-06-26 13:03:11.887066
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Invalid URL
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Valid URL
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Invalid playlist_id
    assert TudouPlaylistIE._real_extract(TudouPlaylistIE(), 'http://www.tudou.com/listplay/') == None
    # Invalid url
    assert TudouPlaylistIE._real_extract(TudouPlaylistIE(), 'http://www.tudou.com/') == None


# Generated at 2022-06-26 13:03:15.740666
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = r'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._VALID_URL(url)


# Generated at 2022-06-26 13:03:24.221771
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'
    url = 'http://www.tudou.com/listplay/%s.html' % playlist_id
    playlist = TudouPlaylistIE()._real_extract(url)
    assert playlist['id'] == playlist_id
    assert len(playlist['entries']) >= 1
    assert playlist['entries'][0]['id'] == playlist_id

# Generated at 2022-06-26 13:03:30.565956
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:03:36.173850
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE('ddd')
    except Exception as e:
        assert(str(e) == 'Invalid URL: http://www.tudou.com/programs/view/ddd')


# Generated at 2022-06-26 13:03:43.682096
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'v5qckFJvNJg'
    url = 'http://www.tudou.com/albumplay/' + album_id
    TudouAlbumIE()._real_extract(url)

# Generated at 2022-06-26 13:03:49.313703
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test constructor of TudouAlbumIE
    ie = TudouAlbumIE({})
    assert ie is not None

# Generated at 2022-06-26 13:03:59.447701
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE('TudouPlaylistIE')
    assert IE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert IE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert IE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert IE._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:04:03.705969
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		TudouAlbumIE()
	except:
		pass


# Generated at 2022-06-26 13:04:22.784288
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    print("\n------------------test_TudouAlbumIE------------------\n")

    # 从test_common.py获取test_class
    from .test_common import TestCommon

    # 获取TestCommon实例对象
    tc = TestCommon()

    # 获取url
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    # 获取ie对象
    ie = tc.get_info_extractor(url)

    # 判断是否为TudouAlbumIE类型
    assert isinstance(ie, TudouAlbumIE)

# Generated at 2022-06-26 13:04:23.545179
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-26 13:04:28.774683
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	import sys, os
	sys.path.append(os.path.join(os.path.dirname(__file__), "../../.."))
	from test_utils import *
	from youtube_dl.utils import *
	from youtube_dl.extractor.tudou import *
	from youtube_dl import YoutubeDL
	from youtube_dl.postprocessor import FFmpegMetadataPP
	from youtube_dl.postprocessor.metadata import BaseMetadataPP


# Generated at 2022-06-26 13:04:39.570660
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check if URL is valid
    r = TudouPlaylistIE._VALID_URL
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    m = re.match(r, valid_url)
    assert m
    assert m.group('id') == 'zzdE77v6Mmo'

    # Check if URL is invalid
    invalid_url = 'https://www.tudou.com/listplay/zzdE77v6Mmo.html'
    m = re.match(r, invalid_url)
    assert m is None
    

# Generated at 2022-06-26 13:04:50.557739
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-26 13:04:57.255968
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE('tudou:playlist')
    assert obj.ie_key() == 'TudouPlaylistIE'
    assert obj.ie_name() == 'tudou:playlist'
    assert obj.ie_description() == 'Tudou Playlist'


# Generated at 2022-06-26 13:05:06.047706
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Remove the first line of the following test code:
    # http://www.tudou.com/listplay/zzdE77v6Mmo.html
    # |
    # | http://www.tudou.com/listplay/zzdE77v6Mmo.html
    #
    # This is because the functions in info extractor are imported later on in
    # __init__.py, so this file exits (and prints information about the
    # constructor), before the imports in __init__.py.
    # See also https://github.com/rg3/youtube-dl/pull/3309
    valid_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    expected_playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:05:12.148146
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Instantiate an object of class TudouPlaylistIE 
	tudouPlaylistObj = TudouPlaylistIE(InfoExtractor())

	# Test '_VALID_URL' attribute of the object
	assert tudouPlaylistObj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:05:23.167798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = InfoExtractor()
    infoExtractor.add_info_extractor(TudouAlbumIE.IE_NAME, TudouAlbumIE())
    infoExtractor.add_info_extractor(TudouPlaylistIE.IE_NAME, TudouPlaylistIE())
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    assert infoExtractor.suitable(url) == 'tudou:playlist'
    assert infoExtractor.extract(url)['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:05:35.400494
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-26 13:05:48.974340
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True


# Generated at 2022-06-26 13:05:54.879865
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	loader = TudouAlbumIE("https://www.tudou.com/albumcover/{}".format("v5qckFJvNJg"))
	assert loader.tudou_id == "v5qckFJvNJg"
	assert loader.album_name == "贴身高手"
	assert loader.album_id == "v5qckFJvNJg"

# Generated at 2022-06-26 13:05:57.114873
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
  tudouplaylistIE = TudouPlaylistIE()
  tudouplaylistIE._real_extract(tudouplaylistIE._TESTS[0]['url'])


# Generated at 2022-06-26 13:06:05.128031
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import TudouAlbumIE
    import re

    # It should be able to match the input url
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    regex = re.compile(TudouAlbumIE._VALID_URL)
    match = regex.match(test_url)
    assert match

    test_TudouAlbumIE = TudouAlbumIE()
    assert test_TudouAlbumIE._real_extract(test_url) != None


# Generated at 2022-06-26 13:06:12.245895
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert _TESTS[0] == (
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        {
            'id': 'v5qckFJvNJg',
        },
        45,
    )

# Generated at 2022-06-26 13:06:15.542666
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	result = TudouAlbumIE()
	

# Generated at 2022-06-26 13:06:21.650158
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.url == url
    assert ie.playlist_id == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:06:23.792029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_ = TudouAlbumIE(InfoExtractor())


# Generated at 2022-06-26 13:06:26.111271
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:06:33.959260
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    url = r'http://www.tudou.com/tvp/alist.action?acode=zzdE77v6Mmo'
    td = TudouPlaylistIE()

# Generated at 2022-06-26 13:07:17.048396
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    info_dict = {'id': 'zzdE77v6Mmo'}
    playlist_mincount = 209
    valid_url = "https://www.tudou.com/listplay/zzdE77v6Mmo.html"
    
    tpie = TudouPlaylistIE()
    assert tpie.IE_NAME == 'tudou:playlist'
    assert tpie.valid_url == _VALID_URL
    assert tpie.playlist_mincount == playlist_mincount
    assert tpie._real_extract(url) == playlist_mincount
    assert tpie._real_extract(valid_url) == playlist_mincount

# Generated at 2022-06-26 13:07:27.775720
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print ('****************** Unit Test Case: TudouPlaylistIE ******************')
    print ('1. tudou playlist url construction')
    print ('1.1 check tudou playlist url is accepted')
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    print ('correct playlist url is accepted')
    print ('1.2 check tudou playlist url is rejected')
    assert TudouPlaylistIE._VALID_URL != r'https?://(?:www\.)?tudou\.com/listplay/.html'
    print ('correct playlist url is rejected')
    print ()



# Generated at 2022-06-26 13:07:37.080873
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ins = TudouAlbumIE()
    assert ins._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ins._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-26 13:07:44.339682
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE.TudouPlaylistIE(None, "http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert test_TudouPlaylistIE != None


# Generated at 2022-06-26 13:07:52.203596
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test case of constructing a TudouPlaylistIE object with a valid URL
    try:
        TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except TypeError:
        raise AssertionError('Construct TudouPlaylistIE object with valid URL fails.')
    # Test case of constructing a TudouPlaylistIE object with an invalid URL
    try:
        TudouPlaylistIE(url='http://www.tudou.com')
    except TypeError:
        raise AssertionError('Construct TudouPlaylistIE object with invalid URL fails.')


# Generated at 2022-06-26 13:08:04.523687
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = {
        'id': 'zzdE77v6Mmo'
    }
    playlist_mincount = 209
    ie = TudouPlaylistIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': info_dict,
        'playlist_mincount': playlist_mincount,
    }]

# Generated at 2022-06-26 13:08:06.355991
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-26 13:08:13.554350
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pl_ie = TudouPlaylistIE()
    assert pl_ie.IE_NAME == 'tudou:playlist'
    assert pl_ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'

# Generated at 2022-06-26 13:08:22.084996
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert tudou_album_ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:08:27.044918
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie is not None

# Generated at 2022-06-26 13:09:36.968463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:09:41.842188
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    i = TudouAlbumIE()
    line = i.extract(r'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:09:43.990567
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_video = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test = TudouPlaylistIE(test_video)
    assert test


# Generated at 2022-06-26 13:09:50.135825
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_playlist = TudouPlaylistIE()
    assert ie_playlist.succeeded(False)
    # TODO
    # assert ie_playlist.supported()
    # assert ie_playlist.IE_NAME


# Generated at 2022-06-26 13:09:57.750241
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'}
    assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45
    return True

# Generated at 2022-06-26 13:10:06.090561
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_name = 'TudouAlbumIE'
    album_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(album_url)
    assert (ie.IE_NAME == class_name), 'Check class_name of %s fail' % class_name
    assert (ie.IE_DESC == '土豆网'), 'Check IE name of %s fail' % class_name
    assert (ie.VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/([\w-]{11})'), 'Check VALID_URL of %s fail' % class_name

# Generated at 2022-06-26 13:10:09.609195
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_obj = TudouPlaylistIE()
    assert ie_obj.IE_NAME == 'tudou:playlist'
    assert ie_obj._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert ie_obj._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # assert main function test_TudouPlaylistIE() is executed

# Generated at 2022-06-26 13:10:13.054956
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    result = ie._real_extract(url)
    assert result['id'] == 'zzdE77v6Mmo'
    assert 'entries' in result
    assert len(result['entries']) == 209


# Generated at 2022-06-26 13:10:14.273888
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()


# Generated at 2022-06-26 13:10:24.447925
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudoutests = [
        ["http://www.tudou.com/listplay/zzdE77v6Mmo.html","zzdE77v6Mmo","http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo"],
        ["http://www.tudou.com/listplay/zzdE77v6Mmm.html","zzdE77v6Mmm","http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmm"]
    ]
