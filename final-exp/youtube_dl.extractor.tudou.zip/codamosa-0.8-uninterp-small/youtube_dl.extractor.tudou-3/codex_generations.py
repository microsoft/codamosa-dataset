

# Generated at 2022-06-26 13:02:21.014746
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()
    

# Generated at 2022-06-26 13:02:22.214073
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert isinstance(TudouAlbumIE(), InfoExtractor)

# Generated at 2022-06-26 13:02:23.507314
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:25.604855
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:29.621690
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert tudou_playlist_i_e_0.ie_name == 'Tudou'
    assert tudou_playlist_i_e_0.valid_urls == [r'http://www\.tudou\.com/listplay/(?P<id>[\w-]{11})\.html']
    assert tudou_playlist_i_e_0._TESTS == [{'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209, 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'}]


# Generated at 2022-06-26 13:02:30.924311
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:34.482390
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

if __name__ == '__main__':
    test_case_0()
    test_TudouAlbumIE()
    pass

# Generated at 2022-06-26 13:02:36.255362
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:37.411841
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:39.104866
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    # Create an instance of TudouAlbumIE using constructor
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:49.361708
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import fake_urlopen
    from .common import make_extractor

    class FakeUrlopenImpl(fake_urlopen.FakeUrlopenImpl):
        def _do_read(self, url):
            if url.rstrip('/').endswith('/tvp/alist.action?acode=D2wC1hEkQLQ'):
                return '{"items": [{"icode": "D2wC1hEkQLQ", "kw": "Wo Ai Hei Se Hui"}, {"icode": "KRx5i5fzSMw", "kw": "Liang Shan Feng Bao"}], "page_info": {"acode": "D2wC1hEkQLQ", "page_no": 1, "page_size": 2, "page_total": 1, "total_count": 2}}'

# Generated at 2022-06-26 13:03:00.016878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    assert_equal(ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html'), 'v5qckFJvNJg')
    assert_equal(ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg'), 'v5qckFJvNJg')
    assert_equal(ie._match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html'), 'v5qckFJvNJg')
    assert_equal(ie._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg'), 'v5qckFJvNJg')
   

# Generated at 2022-06-26 13:03:07.998327
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test a playlist
    list1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    pl1 = TudouPlaylistIE(list1)
    assert pl1.playlist_id == 'zzdE77v6Mmo'
    # Test an album
    list2 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    pl2 = TudouAlbumIE(list2)
    assert pl2.playlist_id == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:03:20.132368
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._match_id(url) == 'zzdE77v6Mmo'
    assert ie._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo', 'zzdE77v6Mmo')['items'][0]['icode'] == 'XMTQ1ODA4NzU4NA'
    #

# Generated at 2022-06-26 13:03:29.693276
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumcover/g5e4k9UeH6U.html'
    ie = TudouAlbumIE(test_url)
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{'url': test_url, 'info_dict': {'id': 'g5e4k9UeH6U'}, 'playlist_mincount': 45}]
    assert hasattr(ie, '_real_extract')
    assert callable(ie._real_extract)


# Generated at 2022-06-26 13:03:36.973567
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie4 = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html');
    assert ie4._match_id(ie4._VALID_URL) == 'v5qckFJvNJg';

# Generated at 2022-06-26 13:03:41.284964
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    assert TudouAlbumIE() is not None

# Generated at 2022-06-26 13:03:50.391918
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test that the URL format `http://www.tudou.com/albumcover/IfRKgZuwOoQ.html`
    # can be handled successfully
    tudou_album_ie = TudouAlbumIE({})
    assert tudou_album_ie.suitable('http://www.tudou.com/albumcover/IfRKgZuwOoQ.html')
    assert tudou_album_ie._real_extract('http://www.tudou.com/albumcover/IfRKgZuwOoQ.html')
    assert tudou_album_ie._match_id(u'http://www.tudou.com/albumcover/IfRKgZuwOoQ.html') == u'IfRKgZuwOoQ'

# Generated at 2022-06-26 13:03:51.467565
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(1 == 1)

# Generated at 2022-06-26 13:03:59.447580
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # This test's purpose is to test if an album has been uploaded to the playlist.
    # If there are no albums uploaded, the album id will be empty.
    # The playlist will then be empty as well.
    # It will be regarded as a wrong test case.

    ie = TudouAlbumIE()
    playlist = ie.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert len(playlist['entries']) > 0

# Generated at 2022-06-26 13:04:06.698057
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:04:13.322722
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie.extract(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist_ie.playlist_id == 'zzdE77v6Mmo'
    assert tudou_playlist_ie.playlist_mincount == 209


# Generated at 2022-06-26 13:04:15.297779
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    InfoExtractor.test_all(TudouPlaylistIE)

# Generated at 2022-06-26 13:04:24.207809
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test tudou album ie
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:04:32.606878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE

    # test for valid url
    i = InfoExtractor("tudou:album")
    info = i.extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert info.id == "v5qckFJvNJg"
    assert info.title == "v5qckFJvNJg"
    assert info.description == "v5qckFJvNJg"
    assert len(info.entries) == 45

# Generated at 2022-06-26 13:04:43.133967
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	instance = TudouPlaylistIE()
	assert 'TudouPlaylistIE' in str(type(instance))
	assert instance._match_id('zzdE77v6Mmo.html') == 'zzdE77v6Mmo'
	assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert instance.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-26 13:04:46.190071
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:04:49.694075
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:05:01.227004
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == True
    assert ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == True
    assert ie.suitable('http://www.tudou.com/albumcover/v5qckFJvNJg.htm') == False
    assert ie.suitable('http://www.tudou.com/albumcover/v5qck-FJvNJg.html') == False


# Generated at 2022-06-26 13:05:13.621821
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_ie.IE_DESC == '土豆网 (tudou.com) 列表'
    assert tudou_playlist_ie.VALID_URL == Tup(Tup('http', 0), Tup('https', 0), Tup('www.tudou.com', 1), Tup('listplay', 1), Tup('zzdE77v6Mmo.html', 1))

# Generated at 2022-06-26 13:05:35.804372
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"    # Test URL
    ie = TudouAlbumIE()                                            # Create a new object
    assert ie.IE_NAME == "tudou:album"                             # Verify the IE_NAME
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'       # Verify the URL
    
    # Verify the match
    match = ie._match_id(test_url)
    assert match == "v5qckFJvNJg"


# Generated at 2022-06-26 13:05:44.098608
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert album._match_id("http://www.tudou.com/albumplay/v5qckFJvNJg.html") == "v5qckFJvNJg"
    #TODO: assert album_id == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:05:48.508395
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: find a better way to unit test
    IE = TudouAlbumIE('iE_NAME', 'url')
    print(IE)

# Generated at 2022-06-26 13:05:54.374870
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    assert(tudouAlbum.IE_NAME == 'tudou:album')
    assert(tudouAlbum._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')


# Generated at 2022-06-26 13:05:57.124313
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-26 13:06:05.012958
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

	playlist_url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	test_tudou = TudouPlaylistIE()
	test_tudou._download = lambda url: {'page_content': "test_page_content"}
	test_tudou._match_id = lambda url: "zzdE77v6Mmo"

# Generated at 2022-06-26 13:06:17.346854
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    x = TudouPlaylistIE()
    assert x.IE_NAME == 'tudou:playlist'
    assert x._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert x._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-26 13:06:23.284001
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test.IE_NAME =='tudou:playlist'
    assert test._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert test._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:06:27.332714
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlistIE = TudouPlaylistIE()
    assert playlistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:06:34.221556
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._VALID_URL == test_url
    url = TudouPlaylistIE._VALID_URL
    assert url == test_url


# Generated at 2022-06-26 13:07:07.316213
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()  # no exception


# Generated at 2022-06-26 13:07:15.533089
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE({
        'url':'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount':209,
    })


# Generated at 2022-06-26 13:07:17.113656
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()._real_initialize()

# Generated at 2022-06-26 13:07:20.616568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    i = TudouPlaylistIE({})
    assert i.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-26 13:07:22.762566
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(1, 1)


# Generated at 2022-06-26 13:07:29.479770
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie_obj = TudouPlaylistIE('www.tudou.com')
    ie_obj_2 = TudouPlaylistIE('www.tudou.com',TudouPlaylistIE._VALID_URL)
    ie_obj_3 = TudouPlaylistIE('www.tudou.com',TudouPlaylistIE._DOWNLOAD_TEMPLATE)
    ie_obj_4 = TudouPlaylistIE('www.tudou.com',TudouPlaylistIE._GEO_BYPASS)
    ie_obj_5 = TudouPlaylistIE('www.tudou.com',TudouPlaylistIE._GEO_COUNTRIES)
    ie_obj_6 = TudouPlaylistIE('www.tudou.com',TudouPlaylistIE._NETRC_MACHINE)


# Generated at 2022-06-26 13:07:33.672368
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    ie.extract()

# Generated at 2022-06-26 13:07:35.626918
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE(InfoExtractor()) != None)

# Generated at 2022-06-26 13:07:43.545400
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/OiDIy8cQYa0.html'
    TudouPlaylistIE(TudouPlaylistIE.IE_NAME, [TudouPlaylistIE.IE_NAME], {}).extract(url)


# Generated at 2022-06-26 13:07:50.883113
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tpie = TudouPlaylistIE()
    # test case 1: invalid playlist_id
    try:
        tpie._real_extract('http://www.tudou.com/listplay/asdf.html')
    except Exception:
        pass
    # test case 2: valid playlist_id
    playlist = tpie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert playlist['id'] == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:08:47.820166
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert 1 == 2

# Generated at 2022-06-26 13:08:49.287146
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert isinstance(TudouPlaylistIE()._real_extract()[0],'Object')


# Generated at 2022-06-26 13:08:54.096403
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	obj = TudouAlbumIE('www.tudou.com/albumplay/v5qckFJvNJg.html')
	obj.start()
	

# Generated at 2022-06-26 13:09:06.915778
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou_embed import TudouEmbedIE
    from .tudou import TudouIE
    from .tudou_swf import TudouSwfIE
    from .tudou_vg import TudouVgIE
    from .tudou_lq import TudouLqIE
    from .tudou_ipad import TudouIPadIE
    from .tudou_simple import TudouSimpleIE
    from .tudou_mobile import TudouMobileIE
    from .tudou_outplay import TudouOutplayIE

    # pattern: (url_regex, ie_constructor)

# Generated at 2022-06-26 13:09:14.541642
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    InfoExtractor.get_info = lambda self, x: None
    ie = TudouAlbumIE(InfoExtractor())
    InfoExtractor.get_info = lambda self, x: {'id': 'VideoID', 'title': 'VideoFileTitle'}
    info = ie._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert info['_type'] == 'playlist'
    assert info['entries'][0]['id'] == 'VideoID'
    assert info['entries'][0]['title'] == 'VideoFileTitle'

# Generated at 2022-06-26 13:09:22.317939
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # We test class constructor here
    print("Testing class constructor...")
    # Make sure it returns a class object
    assert(type(TudouAlbumIE) == type(InfoExtractor))
    # Make sure it does not return a function object
    assert(type(TudouAlbumIE) != type(lambda: 1))

    # Unit test for _real_extract of class TudouAlbumIE

# Generated at 2022-06-26 13:09:26.744600
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE('v5qckFJvNJg')
    assert isinstance(album, InfoExtractor)
    assert album.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:09:31.481762
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE('http://www.tudou.com/albumcover/Nt_5R5lPlhE', '[class]')
    print(tudou_album_ie)


# Generated at 2022-06-26 13:09:36.984012
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.name == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:09:41.444354
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test self.url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    match = TudouPlaylistIE._VALID_URL.match(url)
    assert match.group('id') == 'zzdE77v6Mmo'
    # test self.id
    id = 'zzdE77v6Mmo'
    playlist_id = TudouPlaylistIE._match_id(url)
    assert playlist_id == id


# Generated at 2022-06-26 13:12:18.792182
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'