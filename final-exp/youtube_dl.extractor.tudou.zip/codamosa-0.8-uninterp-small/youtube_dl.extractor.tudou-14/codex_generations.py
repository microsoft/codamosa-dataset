

# Generated at 2022-06-26 13:02:23.987633
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("test_TudouAlbumIE")
    assert True


# Generated at 2022-06-26 13:02:25.885144
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:28.850520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_1 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:29.922358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:02:32.979502
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:35.875926
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert tudou_album_i_e_0.__class__ == TudouAlbumIE


# Generated at 2022-06-26 13:02:37.373418
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:38.809937
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:41.285490
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_ = test_case_0
    name = 'test_case_0'
    tudou_album_i_e_0 = class_


# Generated at 2022-06-26 13:02:42.847860
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:47.874607
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouPlaylistIE = TudouPlaylistIE()
    assert(tudouPlaylistIE.IE_NAME == 'tudou:playlist')


# Generated at 2022-06-26 13:02:51.011932
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(TudouPlyalistIE._downloader, url)


# Generated at 2022-06-26 13:02:55.607727
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert len(ie._TESTS) == 6

# Generated at 2022-06-26 13:03:06.622930
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url=r'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-26 13:03:12.556753
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    #Constructor for class TudouAlbum shall not raise any error.
    #This unit test checks the constructor of class TudouAlbumIE, which is a subclass of class InfoExtractor.
    i = TudouAlbumIE()
    assert i.IE_NAME == 'TUDOU:ALBUM'
    assert i.VERSION == '0.1'
    assert isinstance(i, InfoExtractor)
    #TODO
    #There is nothing to test for the instance variable 'BR_DESC' in class TudouAlbumIE


# Generated at 2022-06-26 13:03:15.741765
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE(TudouPlaylistIE._VALID_URL)

# Generated at 2022-06-26 13:03:27.426012
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # create a video list
    video_list =[]

    # create a tuple for each video
    video_1 = ('Spiderman', 'http://www.dailymotion.com/video/x17rf8f_spider-man-2002_shortfilms',
               'http://www.youtube.com/watch?v=PSu8HjYV7rs')

    video_2 = ('Spiderman 2', 'http://www.dailymotion.com/video/x17rf8g_spiderman-2-2004_shortfilms',
               'http://www.youtube.com/watch?v=nSDnY7RUXCo')


# Generated at 2022-06-26 13:03:38.826212
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	#test url: "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	tudou_playlist_ins = TudouPlaylistIE()
	assert tudou_playlist_ins._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert tudou_playlist_ins._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	assert tudou_playlist_ins._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
	assert tudou_playlist_ins._TESTS

# Generated at 2022-06-26 13:03:49.198896
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist_IE = TudouPlaylistIE()
    tudou_playlist_IE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    tudou_playlist_IE._download_json('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo','zzdE77v6Mmo')
    tudou_playlist_IE._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:03:51.066171
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie is not None


# Generated at 2022-06-26 13:03:58.812324
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tp = TudouPlaylistIE()
    assert tp is not None


# Generated at 2022-06-26 13:04:05.988610
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]



# Generated at 2022-06-26 13:04:07.378570
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL is not None

# Generated at 2022-06-26 13:04:08.251959
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert(TudouAlbumIE)

# Generated at 2022-06-26 13:04:14.184303
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	result =  TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
	assert result.IE_NAME == 'tudou:album'
	assert result._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert result._TESTS == [{
'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
'info_dict': {
'id': 'v5qckFJvNJg',
},
'playlist_mincount': 45,
}]

# Generated at 2022-06-26 13:04:23.939064
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    This function is used to test class TudouPlaylistIE.

    The function create an instance and check if it can really create an
    instance.
    '''
    id = 'zzdE77v6Mmo'
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(id, url)


# Generated at 2022-06-26 13:04:26.725069
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert "tudou:album" == TudouAlbumIE().IE_NAME

# Generated at 2022-06-26 13:04:31.311057
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert not TudouAlbumIE().suitable('http://www.tudou.com/album_cover/v5qckFJvNJg.html')
    assert not TudouAlbumIE().suitable('http://www.tudou.com/album_cover/v5qckFJvNJg')

# Generated at 2022-06-26 13:04:42.556726
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	album_id = "v5qckFJvNJg"

# Generated at 2022-06-26 13:04:44.036910
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-26 13:05:06.425806
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    entries = """
        <programs>
            <item>
                <kw>恋爱疗愈</kw>
                <icode>MW93MQ==</icode>
            </item>
            <item>
                <kw>像我这样的人</kw>
                <icode>c7V5p5Y=</icode>
            </item>
        </programs>
    """
    self.playlist_

# Generated at 2022-06-26 13:05:11.428342
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    #Test whether object of class TudouPlaylistIE created successfully
    tudou_playlist = TudouPlaylistIE('http://www.tudou.com/listplay/1e8IjCzM3qI.html')
    assert tudou_playlist is not None


# Generated at 2022-06-26 13:05:13.728863
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(None)

# Generated at 2022-06-26 13:05:21.155414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	"""
	Test method for TudouAlbumIE class
	"""
	# Create an object
	tudou_album_ie = TudouAlbumIE()
	# Test if the object is instance of class TudouAlbumIE
	assert isinstance(tudou_album_ie, TudouAlbumIE)


# Generated at 2022-06-26 13:05:23.320128
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/4n_4D_aNwYk.html'
    ie = TudouAlbumIE()
    instance = ie._real_extract(test_url)
    print(instance)

# Generated at 2022-06-26 13:05:33.069079
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_test = {
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }
    instance = TudouPlaylistIE()
    assert playlist_test['info_dict'] == instance._real_extract(playlist_test['url'])['entries']


# Generated at 2022-06-26 13:05:35.509606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()

# Generated at 2022-06-26 13:05:39.461102
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-26 13:05:45.673538
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:05:50.866090
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert obj.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-26 13:06:18.877750
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()
    assert True


# Generated at 2022-06-26 13:06:28.709403
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumcover/v5qckFJvNJg.html"
    videoie = TudouAlbumIE()

# Generated at 2022-06-26 13:06:30.171212
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE()
	assert ie

# Generated at 2022-06-26 13:06:41.267275
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:06:52.276384
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """ test for class constructor """
    tudou_playlist = TudouPlaylistIE()
    assert tudou_playlist.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:07:04.471576
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # case 1
    # album_url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    test_album_url = 'http://www.tudou.com/albumplay/' + album_id + '.html'
    # test if the passed url is correct
    # Using the class constructor to create an instance and test
    tudou_album_ie = TudouAlbumIE(album_id)
    if tudou_album_ie._VALID_URL == test_album_url:
        print('Unit test for class TudouAlbumIE passed!')
    else:
        print('Unit test for class TudouAlbumIE failed!')


# Generated at 2022-06-26 13:07:10.599698
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:07:17.153606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print("===== Test for TudouAlbumIE =====")
	print("1. Test for url: ")
	test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	test_TudouAlbumIE = TudouAlbumIE()
	print("Test completed!")


# Generated at 2022-06-26 13:07:19.943528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_album_ie = TudouAlbumIE()
	

# Generated at 2022-06-26 13:07:22.834004
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
        assert True
    except:
        assert False


# Generated at 2022-06-26 13:08:29.507246
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:08:34.036790
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-26 13:08:44.474620
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    test the constructor of class TudouPlaylistIE
    """
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE(url)
    assert ie.url == url
    assert ie.ie_key() == 'Tudou:playlist'
    assert ie.video_id == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:08:49.520450
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    tudou_playlist = TudouPlaylistIE()
    # Test for method _real_extract
    assert tudou_playlist._real_extract(url)


# Generated at 2022-06-26 13:08:52.503515
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playList = TudouPlaylistIE(None)

# Generated at 2022-06-26 13:09:01.918907
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tdpl = TudouPlaylistIE()
    assert tdpl.ie_key() == 'Tudou:playlist'
    assert tdpl.ie_name() == 'tudou:playlist'
    assert tdpl.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert not tdpl.suitable('http://www.tudou.com/programs/view/UFJiBm0m1QQ/')


# Generated at 2022-06-26 13:09:13.618686
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Unit test for constructor of class TudouPlaylistIE
    """

    # Given a class TudouPlaylistIE
    t = TudouPlaylistIE(TudouPlaylistIE.IE_NAME)

    # When I set ie_key = 'TudouPlaylist'
    ie_key = 'Tudou:album'
    # And I set test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # And I call constructor
    t.__init__(t.ie_key)
    # then I check ie_key equals 'TudouPlaylist'
    assert t.ie_key == ie_key
    #

# Generated at 2022-06-26 13:09:22.859551
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_units import TestUnits

    tudou_playlist_IE = TudouPlaylistIE()
    result_set = tudou_playlist_IE.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

    # Test the id assigned to the video
    TestUnits.assert_equal(
        result_set['id'],
        'zzdE77v6Mmo',
        "Tudou Playlist Id doesn't match",
        True,
    )


# Generated at 2022-06-26 13:09:24.467785
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL

# Generated at 2022-06-26 13:09:27.974591
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    args = ['http://www.tudou.com/listplay/zzdE77v6Mmo.html']
    ie = TudouPlaylistIE(*args)

# Generated at 2022-06-26 13:12:13.432846
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test the constructor of TudouAlbumIE class
    ie = TudouAlbumIE()
    assert ie.extractor_key == 'TudouAlbum'
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:12:15.835209
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Create a object for this class to test the constructor.
    TudouPlaylistIE()


# Generated at 2022-06-26 13:12:18.213961
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 13:12:21.254788
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # download v5qckFJvNJg.html first
    file_path = 'K:\\Videos\\v5qckFJvNJg.html'
    f = open(file_path, "rb")
    data = f.read()
    f.close()