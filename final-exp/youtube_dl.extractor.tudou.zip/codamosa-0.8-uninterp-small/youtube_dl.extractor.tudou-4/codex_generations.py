

# Generated at 2022-06-26 13:02:22.625191
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:24.962054
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Unit test for constructor of class TudouAlbumIE
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:26.237443
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
        tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:29.019668
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_1 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:30.144956
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:34.093242
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0.IE_NAME == 'tudou:playlist'


# Generated at 2022-06-26 13:02:36.294000
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:38.074449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert_equal(tudou_playlist_i_e_0.IE_NAME, 'tudou:playlist')


# Generated at 2022-06-26 13:02:41.149633
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0._VALID_URL
    assert tudou_playlist_i_e_0._TESTS



# Generated at 2022-06-26 13:02:42.388369
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:49.668449
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:51.595107
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # tudou_playlist_i_e_0 = TudouPlaylistIE()
    return


# Generated at 2022-06-26 13:02:53.599691
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert tudou_playlist_i_e_0 == TudouPlaylistIE()


# Generated at 2022-06-26 13:02:54.949941
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()

# Generated at 2022-06-26 13:03:05.946969
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print('\nUnit test for constructor of class TudouPlaylistIE')
    # Parameters:
    # 'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
    # 'info_dict': {'id': 'zzdE77v6Mmo'},
    # 'playlist_mincount': 209
    # Return:
    # None
    assert tudou_playlist_i_e_0.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_i_e_0._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_i_e_0._TESTS

# Generated at 2022-06-26 13:03:07.175935
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:03:09.310503
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-26 13:03:10.496129
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:03:11.843253
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:03:25.349252
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_i_e_0._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist_i_e_0._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist_i_e_0._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-26 13:03:34.824603
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(), InfoExtractor)

# Generated at 2022-06-26 13:03:40.934712
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html'),
        InfoExtractor
    )

# Generated at 2022-06-26 13:03:48.346695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    entry = TudouAlbumIE(url, 'http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg')
    assert entry.album_id == 'v5qckFJvNJg'
    assert entry.album_data is not None


# Generated at 2022-06-26 13:03:55.131359
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE = TudouPlaylistIE()
    instance = IE('zzdE77v6Mmo')
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:03:57.673217
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-26 13:04:03.185011
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-26 13:04:08.878063
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    video_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tu = TudouPlaylistIE(video_url)
    assert tu.playlist_id == 'zzdE77v6Mmo'
    assert tu.url == video_url


# Generated at 2022-06-26 13:04:14.689872
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # We test with the period in the URL to check the handling of escaped
    # period
    ie = TudouPlaylistIE(url)
    # if you are interested in loading the whole code of the constructor,
    # you can use the following command
    # print(inspect.getsource(ie.__class__))
    assert_equal(ie.name, 'Tudou')
    assert_equal(ie.playlist_id, 'zzdE77v6Mmo')
    assert_equal(ie.playlist_id.startswith('http'), True)

# Generated at 2022-06-26 13:04:20.254238
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Would run test for constructor of class TudouPlaylistIE")
    assert False


# Generated at 2022-06-26 13:04:22.226922
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	print(TudouAlbumIE())
	

# Generated at 2022-06-26 13:04:41.577798
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'
    playlist_data = {
        "page": {
            "pageCount": 209,
            "pageNo": 1,
            "pageSize": 1,
            "pageTotal": 209
        },
        "items":[{
            "cid": 1249,
            "cname": "",
            "icode": "zzdE77v6Mmo",
            "kw": "",
            "pct": "100",
            "pv": "20248"
        }]
    }
    playlist = TudouPlaylistIE(url)
    assert playlist._match_id(url) == playlist_id
    assert playlist.url == url


# Generated at 2022-06-26 13:04:47.404168
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    urltest = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj_album = TudouAlbumIE(urltest)
    assert obj_album
    assert obj_album.playlist_mincount == 45

# Generated at 2022-06-26 13:04:50.408171
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    result = TudouPlaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert result

# Generated at 2022-06-26 13:04:54.839579
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_info_extractor = TudouAlbumIE()
    tudou_album_info_extractor.IE_NAME
    tudou_album_info_extractor._VALID_URL

# Generated at 2022-06-26 13:04:56.348686
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:05:00.757088
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
# Unit tests for item extracting functions of class TudouPlaylistIE

# Generated at 2022-06-26 13:05:02.951110
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	assert(TudouPlaylistIE)


# Generated at 2022-06-26 13:05:11.665034
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Arrange
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    # Act
    tudou_album_ie = TudouAlbumIE(object)
    # Assert
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:05:16.841061
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert_raises(AssertionError, TudouPlaylistIE, None, None, 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:05:22.906081
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # construct a object TudouPlaylistIE
    ie = TudouPlaylistIE()

    # check whether the object has been created successfully
    assert ie.name == 'Tudou Playlist'
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.host == 'www.tudou.com'

# Generated at 2022-06-26 13:05:47.955635
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouIE = TudouPlaylistIE()
    expected = 'tudou:playlist'
    assert(expected == tudouIE.IE_NAME)


# Generated at 2022-06-26 13:05:54.949639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE(TudouAlbumIE._TESTS[0])
    assert obj._match_id(obj._VALID_URL) == 'v5qckFJvNJg'
    assert obj.IE_NAME == 'tudou:album'
    assert obj._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'



# Generated at 2022-06-26 13:05:55.714507
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()

# Generated at 2022-06-26 13:05:58.233692
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.IE_NAME == "TudouPlaylistIE"

# Generated at 2022-06-26 13:06:06.848022
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # replay the scenario in test_TudouPlaylistIE()
    _VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:06:15.209798
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbumIE = TudouAlbumIE()
    assert_equal(tudouAlbumIE._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})' )
    assert_equal(tudouAlbumIE.IE_NAME, 'tudou:album')


# Generated at 2022-06-26 13:06:17.626149
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:06:22.214687
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    Object = TudouAlbumIE() 
    test_url1 = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert Object._VALID_URL.match(test_url1)
    test_url2 = 'http://www.tudou.com/albumcover/v5qckFJvNJg'
    assert Object._VALID_URL.match(test_url2)

# Generated at 2022-06-26 13:06:28.586123
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie.id == 'zzdE77v6Mmo'
    assert not ie.real_url


# Generated at 2022-06-26 13:06:37.513555
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist = TudouPlaylistIE()
    assert playlist.IE_NAME == 'tudou:playlist'
    assert playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert playlist._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]
    return playlist


# Generated at 2022-06-26 13:07:52.908651
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    INFOS = {
        "id": "v5qckFJvNJg",
        "thumbnail": "re:http://.*\.tudouimg\.com.*",
        "uploader_id": "",
        "uploader": "",
        "title": "美国大师级传奇 极品女友",
    }

    test_urls = []
    test_urls.append("http://www.tudou.com/albumcover/v5qckFJvNJg.html")
    test_urls.append("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

    for test_url in test_urls:
        album_

# Generated at 2022-06-26 13:08:04.024652
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
	assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	assert TudouAlbumIE._TESTS[0]['info_dict'] == {'id': 'v5qckFJvNJg'};
	assert TudouAlbumIE._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-26 13:08:05.424369
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Function called by unit test
    assert True

# Generated at 2022-06-26 13:08:17.941400
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    check_def = {
        'id': 'zzdE77v6Mmo',
        'playlist_mincount': 209,
    }
    pl = TudouPlaylistIE()
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

# Generated at 2022-06-26 13:08:24.449758
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

# Generated at 2022-06-26 13:08:35.823776
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    app = TudouPlaylistIE()
    #TudouPlaylistIE.suite()
    #app = TudouPlaylistIE("contructor")
    print(app.__class__.__name__)
    print(app.__class__.__bases__)
    print(dir(app.__class__))
    print(dir(app))
    print(app.__class__.__doc__)
    print(app.__class__.__dict__)
    print(app.__class__._TESTS)
    print(app.__class__._TESTS[0])

# Generated at 2022-06-26 13:08:38.296700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    p = TudouAlbumIE()
    assert p is not None

# Generated at 2022-06-26 13:08:48.190669
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    from .tudou import strip_jsonp
    t = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    video_json = t._download_json('http://www.tudou.com/tvp/alist.action?acode=v5qckFJvNJg', 'v5qckFJvNJg', u'Downloading album json')
    assert(video_json['st'] == 1)
    assert(video_json['acode'] == u'v5qckFJvNJg')
    assert(video_json['albumName'] == u'谜样美人')
    assert(len(video_json['items']) == 45)

# Generated at 2022-06-26 13:08:53.051590
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	ie = TudouPlaylistIE("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
	assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
	assert ie._TESTS[0]['url'] == "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
	assert ie._TESTS[0]['info_dict']['id'] == "zzdE77v6Mmo"
	assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:08:59.694472
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Testing for download a playlist from website tudou.com
    ie = TudouPlaylistIE()
    url = ie.extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(ie.playlist_result is not None)



# Generated at 2022-06-26 13:11:29.222695
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie != None

if __name__ == "__main__":
    test_TudouAlbumIE()

# Generated at 2022-06-26 13:11:33.009031
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    my_test = TudouAlbumIE(1,1)


# Generated at 2022-06-26 13:11:40.482524
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    def __init__(self, ie_name, ie_key, ie_module_name, ie_module_package, ie_module_path, ie_module_version, ie_module_origin=None, ie_module_requirement=None, ie_module_last_update=None, ie_module_version_date=None, ie_module_language=None, ie_module_author=None, ie_module_description=None):
    '''
    pass

# Generated at 2022-06-26 13:11:42.441294
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True


# Generated at 2022-06-26 13:11:47.899170
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Trying to create an object of the class
    TudouAlbumIE(TudouAlbumIE.IE_NAME, [])


# Generated at 2022-06-26 13:12:01.810994
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('tudou:album')
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]


# Generated at 2022-06-26 13:12:14.027535
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import unittest
    from .common import expected_warnings

    class TudouAlbumIETest(unittest.TestCase):
        def setUp(self):
            self.test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
            self.test_class = TudouAlbumIE
            self.test_obj = self.test_class(self.test_url)

        def test_class_constructor(self):
            self.assertIsInstance(self.test_obj, self.test_class)
            self.assertEqual(self.test_obj._VALID_URL, self.test_url)

# Generated at 2022-06-26 13:12:15.317608
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-26 13:12:16.634579
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-26 13:12:23.806364
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # test url:
    # http://www.tudou.com/albumplay/9vApMfOI2H0.html
    # return an instance of TudouAlbumIE
    assert isinstance(TudouAlbumIE(None).get_info_extractor(
        'http://www.tudou.com/albumplay/9vApMfOI2H0.html'),
                      TudouAlbumIE)

    # test url:
    # http://www.tudou.com/albumcover/9vApMfOI2H0.html
    # return an instance of TudouAlbumIE