

# Generated at 2022-06-26 13:02:29.053105
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()
    tudou_album_i_e_1 = TudouAlbumIE(url_transparent_mask=None)
    tudou_album_i_e_2 = TudouAlbumIE(smuggle_url_through_post=None)
    tudou_album_i_e_3 = TudouAlbumIE(fatal_if_no_video=None)
    tudou_album_i_e_4 = TudouAlbumIE(force_generic_extractor=None)
    tudou_album_i_e_5 = TudouAlbumIE(skip_download=None)
    tudou_album_i_e_6 = TudouAlbumIE(download_queries=None)
    tudou_album

# Generated at 2022-06-26 13:02:36.348892
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE.IE_NAME in globals()['tudou_playlist_i_e_0'].IE_NAME
    assert globals()['tudou_playlist_i_e_0'].IE_NAME in globals()['tudou_playlist_i_e_0'].IE_NAME
    assert globals()['tudou_album_i_e_0'].IE_NAME in globals()['tudou_playlist_i_e_0'].IE_NAME


# Generated at 2022-06-26 13:02:39.042296
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    #print(TudouAlbumIE._VALID_URL)
    #print(tudou_playlist_i_e._VALID_URL)


# Generated at 2022-06-26 13:02:40.845846
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:46.457649
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    assert tudou_playlist_i_e.ie_key() == 'TudouPlaylist'
    assert tudou_playlist_i_e.ie_name() == 'tudou:playlist'
    assert tudou_playlist_i_e.IE_NAME == 'tudou:playlist'
    assert tudou_playlist_i_e.IE_DESC == 'Tudou Playlist'


# Generated at 2022-06-26 13:02:48.168306
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()
    return


# Generated at 2022-06-26 13:02:50.037741
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:01.504850
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_1 = TudouAlbumIE()
    tudou_album_i_e_2 = TudouAlbumIE()
    tudou_album_i_e_3 = TudouAlbumIE()
    tudou_album_i_e_4 = TudouAlbumIE()
    tudou_album_i_e_5 = TudouAlbumIE()
    tudou_album_i_e_6 = TudouAlbumIE()
    tudou_album_i_e_7 = TudouAlbumIE()
    tudou_album_i_e_8 = TudouAlbumIE()
    tudou_album_i_e_9 = TudouAlbumIE()
    tudou_album_i_e_10 = TudouAlbumIE()

# Generated at 2022-06-26 13:03:03.163464
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()



# Generated at 2022-06-26 13:03:07.748049
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e.IE_NAME == 'tudou:album'
    assert tudou_album_i_e.IE_DESC == '土豆 - 发现高清视频'


# Generated at 2022-06-26 13:03:18.997536
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:03:23.201485
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert type(tudou_album_i_e) == TudouAlbumIE



# Generated at 2022-06-26 13:03:30.850748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print('test_TudouAlbumIE')
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    assert tudou_album_i_e._VALID_URL == (
        r'https?://(?:www\.)?tudou\.com/album' +
        (+ '(?:cover|play)/(?P<id>[\w-]{11})'))
    assert tudou_album_i_e

# Generated at 2022-06-26 13:03:35.123733
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:43.160847
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', 'error at constructing object for class TudouAlbumIE'


# Generated at 2022-06-26 13:03:49.823135
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    tudou_album_i_e_1 = TudouAlbumIE()


# Generated at 2022-06-26 13:03:54.569530
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/Nz3zlqKjkuM.html"
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:56.146136
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:03:58.069495
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:04:00.804878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()



# Generated at 2022-06-26 13:04:07.890373
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('album')
    assert ie is not None

# Generated at 2022-06-26 13:04:10.370779
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		TudouAlbumIE(TudouAlbumIE._VALID_URL, TudouAlbumIE.IE_NAME)
	except:
		assert -1 == 0


# Generated at 2022-06-26 13:04:23.167022
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.ie_key() == 'tudou:playlist'
    assert TudouPlaylistIE(TudouPlaylistIE._downloader).ie_key() == 'tudou:playlist'
    assert TudouPlaylistIE(TudouPlaylistIE._downloader)._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:04:29.839272
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # invalid url (lacking the albumcover/albumplay part)
    assert TudouAlbumIE(TudouAlbumIE.ie_key())._real_extract(
        'http://www.tudou.com/album/v5qckFJvNJg.html') is None


# Generated at 2022-06-26 13:04:33.212653
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	fetch_by_url(url)

# Generated at 2022-06-26 13:04:42.165073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou = TudouPlaylistIE(None)
    assert tudou.IE_NAME == 'tudou:playlist'
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou._TESTS == [{'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'info_dict': {'id': 'zzdE77v6Mmo'}, 'playlist_mincount': 209}]


# Generated at 2022-06-26 13:04:49.291545
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import expected
    tudou_album_ie = TudouAlbumIE(expected)
    assert_equal(tudou_album_ie.ie_key(), "TudouAlbumIE")
    assert_equal(tudou_album_ie.ie_key(), "TudouAlbumIE")



# Generated at 2022-06-26 13:04:50.241522
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()

# Generated at 2022-06-26 13:04:57.417073
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE([unicode("https://www.tudou.com/listplay/zzdE77v6Mmo.html", "utf-8")])
    assert ie.url == "https://www.tudou.com/listplay/zzdE77v6Mmo.html"


# Generated at 2022-06-26 13:05:01.387299
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test = TudouPlaylistIE()
    assert test._match_id('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:05:18.104764
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/IM9P_5eZB5U.html'
    ie_test = TudouAlbumIE(url, 'Tudou', 'IM9P_5eZB5U')
    assert type(ie_test) is TudouAlbumIE
    assert ie_test._VALID_URL is TudouAlbumIE._VALID_URL
    assert ie_test.ie_key() is TudouAlbumIE.ie_key()
    assert ie_test.ie_name() is TudouAlbumIE.ie_name()
    assert ie_test._match_id(url) == 'IM9P_5eZB5U'
    assert ie_test.ie_key() == 'tudou:album'

# Generated at 2022-06-26 13:05:22.237797
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlistIE = TudouPlaylistIE()
    playlistIE.extract()

# Generated at 2022-06-26 13:05:34.531726
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Test constructor of class TudouAlbumIE"""

    # Testing url 
    url_test = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    # Instanciate object
    ie = TudouAlbumIE(url_test)

    # Test URL
    assert ie.url == url_test

    # Test regex pattern
    assert ie.regex.match(url_test)

    # Test domain
    assert ie.domain
    assert ie.domain == 'www.tudou.com'

    # Test video id
    assert ie.videoid
    assert ie.videoid == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:05:43.422736
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    instance = TudouPlaylistIE()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == 'tudou:playlist'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

if __name__ == "__main__":
    test_TudouPlaylistIE()

# Generated at 2022-06-26 13:05:48.857024
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album = TudouAlbumIE()
    tudou_album.extract(test_url)

# Generated at 2022-06-26 13:05:50.851386
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test = TudouPlaylistIE(None)

# Generated at 2022-06-26 13:05:53.201520
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
  ie = TudouAlbumIE()
  assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:06:05.638703
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__bases__ == (InfoExtractor,)
    assert hasattr(TudouPlaylistIE, '_VALID_URL')
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert hasattr(TudouPlaylistIE, 'IE_NAME')
    assert TudouPlaylistIE.IE_NAME == 'tudou:playlist'
    assert hasattr(TudouPlaylistIE, '_TEST')

# Generated at 2022-06-26 13:06:17.705862
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tdAlbum = TudouAlbumIE('tudou:album',
							'http://www.tudou.com/albumcover/v5qckFJvNJg',
							'v5qckFJvNJg',
							'http://www.tudou.com/albumcover/v5qckFJvNJg.html')
	assert(tdAlbum.name) == 'tudou:album'
	assert(tdAlbum.url) == 'http://www.tudou.com/albumcover/v5qckFJvNJg'
	assert(tdAlbum.info_dict['id']) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:06:23.393397
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import urlparse
    url = urlparse.urlparse('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    ie = TudouAlbumIE()
    tudou_album_ie = ie._real_extract(ie.extract(url))
    assert tudou_album_ie is not None
    assert tudou_album_ie['playlist'] is not None
    assert tudou_album_ie['playlist'][0] is not None
    assert tudou_album_ie['playlist'][0]['id'] is not None

# Generated at 2022-06-26 13:06:57.855081
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:07:02.411082
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    try:
        # first parameter is a URL, second parameter is metadata.
        obj.url_result('http://example.com/url', 'title', 0, 'thumbnail')
    except:
        # this case should never happen
        assert False

# Generated at 2022-06-26 13:07:14.711589
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    obj = TudouAlbumIE(TudouAlbumIE._VALID_URL, url)
    assert obj._match_id(url) == 'v5qckFJvNJg'
    assert obj._real_extract(url).get('id') == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:07:24.089979
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	#test URL: http://www.tudou.com/albumcover/uXfnenxV7lA.html
	tad = TudouAlbumIE()
	assert tad.IE_NAME == 'tudou:album'
	assert tad._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'


# Generated at 2022-06-26 13:07:36.746637
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = InfoExtractor()
    infoExtractor.get_info = lambda url: {
        'id': 'zzdE77v6Mmo',
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'extractor': 'tudou:playlist'
    }
    # test for constructor
    assert len(infoExtractor.extract_info(
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html')) == 3

# Generated at 2022-06-26 13:07:41.495214
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # This unit test checks that constructor of class
    # TudouAlbumIE does not crash
    TudouAlbumIE()

# Generated at 2022-06-26 13:07:51.817859
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]
    assert ie._TESTS[0].get('playlist_mincount') == 45
    assert ie._TESTS[0].get('playlist_mincount') == 45

# Generated at 2022-06-26 13:07:53.135749
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:08:05.956971
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	from os import path
	import requests
	from string import split
	from itertools import chain

	from random import choice
	from random import randint
	from itertools import islice
	from random import sample
	from time import time
	from time import sleep
	from time import strftime
	from multiprocessing.pool import ThreadPool
	from pprint import pprint

	from selenium import webdriver
	from selenium.webdriver.firefox.firefox_binary import FirefoxBinary

	from chromedriver_binary import add_chromedriver_to_path
	from selenium.webdriver.chrome.options import Options

	from bs4 import BeautifulSoup

	from youtube_dl.utils import std_headers
	from youtube_dl.utils import HEADRequest
	from youtube_dl.DownloadError import DownloadError

# Generated at 2022-06-26 13:08:16.689053
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('www.tudou.com', 'albumplay/v5qckFJvNJg.html', None)
    assert ie.IE_NAME == 'tudou:album'
    assert ie.name == 'Tudou'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:09:14.170776
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/nLnZ3YsQgUI.html'
    # Throws a TypeError
    tudouAlbumIE = TudouAlbumIE(url,'TudouAlbumIE',url)
    return tudouAlbumIE

# Generated at 2022-06-26 13:09:25.177329
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' 
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:09:31.545266
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert TudouAlbumIE._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:09:34.375720
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()

    # test for _real_extract
    tudou_album_ie._real_extract(tudou_album_ie._VALID_URL)


# Generated at 2022-06-26 13:09:41.036628
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

	# Create TudouPlaylistIE instance
	tudou_playlist_instance = TudouPlaylistIE()

	# Test if it has info_dict attribute

# Generated at 2022-06-26 13:09:43.234470
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/a1n4w4D_R8M.html'
    ie = TudouAlbumIE(url)
    assert ie == 'tudou:album'

# Generated at 2022-06-26 13:09:50.035291
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tdAlbumIE = TudouAlbumIE("test")
    return tdAlbumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:09:52.860577
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	try:
		TudouAlbumIE()
	except:
		assert False, "TudouAlbumIE()"
	else:
		assert True

# Generated at 2022-06-26 13:09:57.429206
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE()
    assert tudou_albumIE is not None

# Generated at 2022-06-26 13:09:58.322466
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE