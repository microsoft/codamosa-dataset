

# Generated at 2022-06-26 13:02:27.636560
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert tudou_playlist_i_e_0._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist_i_e_0._downloader == None
    assert tudou_playlist_i_e_0._NETRC_MACHINE == 'tudou'
    assert tudou_playlist_i_e_0._ps == None
    assert tudou_playlist_i_e_0._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist_i_e_0

# Generated at 2022-06-26 13:02:29.676432
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:31.302222
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:33.403138
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:37.294880
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_album_i_e_0 = TudouPlaylistIE()
    tudou_album_i_e_0._match_id("http://www.tudou.com/listplay/zzdE77v6Mmo.html")

# Generated at 2022-06-26 13:02:39.031036
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert callable(TudouAlbumIE)

# Test parsing of tudou.com playlist URLs (video list URL)

# Generated at 2022-06-26 13:02:42.888941
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test initialization
    tudou_playlist_i_e_1 = TudouPlaylistIE("TudouPlaylistIE", "TudouPlaylistIE", "TudouPlaylistIE");
    # Test instance
    assert tudou_playlist_i_e_1 != null


# Generated at 2022-06-26 13:02:44.664331
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_playlist = TudouPlaylistIE()

# Unittest for method _real_extract of class TudouPlaylistIE

# Generated at 2022-06-26 13:02:46.055442
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:47.760866
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:55.565727
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = tudou_album_i_e_0


# Generated at 2022-06-26 13:03:05.579472
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Check if instance TudouPlaylistIE is created properly
    tudou_playlist_i_e = TudouPlaylistIE()
    # Check if attribute _VALID_URL is set properly
    assert tudou_playlist_i_e._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    # Check if attribute ie_name is set properly
    assert tudou_playlist_i_e.ie_name == 'tudou:playlist'
    # Check if attribute ie_key is set properly
    assert tudou_playlist_i_e.ie_key == 'TudouPlaylist'
    

# Generated at 2022-06-26 13:03:06.525693
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if not (isinstance(tudou_album_i_e_0, InfoExtractor)):
        raise Exception('Unit test failed. Wrong type returned.')


# Generated at 2022-06-26 13:03:08.074716
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:10.193281
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert tudou_album_i_e.ie_key == 'Tudou'


# Generated at 2022-06-26 13:03:12.867791
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:03:17.727917
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()
    assert(isinstance(tudou_playlist_i_e_0, TudouPlaylistIE))


# Generated at 2022-06-26 13:03:20.483746
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:23.375531
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    pass


# Generated at 2022-06-26 13:03:26.486675
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:40.486839
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:03:44.545322
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()

if __name__ == '__main__':
    test_case_0()
    test_TudouPlaylistIE()

# Generated at 2022-06-26 13:03:48.898028
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_init = TudouPlaylistIE()

# Generated at 2022-06-26 13:03:50.236804
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:04:03.127440
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = tudou_album_i_e._match_id(url)
    album_data = tudou_album_i_e._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)

# Generated at 2022-06-26 13:04:05.505521
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:04:13.692716
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    from .tudou import TudouAlbumIE
    info_extractor_0 = InfoExtractor()
    tudou_album_i_e_0 = TudouAlbumIE(
        info_extractor_0)
    assert (tudou_album_i_e_0._VALID_URL ==
            r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    pass


# Generated at 2022-06-26 13:04:24.386975
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert (
        tudou_album_i_e_0.suitable(
            'http://www.tudou.com/albumplay/v5qckFJvNJg.html') is True
    )
    assert (
        tudou_album_i_e_0.suitable(
            'http://www.tudou.com/albumcover/v5qckFJvNJg.html') is True
    )
    assert (
        tudou_album_i_e_0.suitable('http://www.tudou.com/programs/view/v5qckFJvNJg') is False
    )

# Generated at 2022-06-26 13:04:27.647693
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()

# Generated at 2022-06-26 13:04:29.555975
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:04:59.311573
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # TODO: case 0
    pass


# Generated at 2022-06-26 13:05:02.835230
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_0 = TudouPlaylistIE()
    tudou_playlist_ie_0.IE_NAME
    tudou_playlist_ie_0._VALID_URL
    tudou_playlist_ie_0._TESTS


# Generated at 2022-06-26 13:05:05.894542
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_1 = TudouPlaylistIE()


# Generated at 2022-06-26 13:05:11.743713
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert 'tudou:playlist' == TudouPlaylistIE.IE_NAME
    assert 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html' == TudouPlaylistIE._VALID_URL
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:05:16.405239
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    tudou_album_i_e_0 = TudouAlbumIE()
    assert tudou_album_i_e_0 is not None


# Generated at 2022-06-26 13:05:19.294305
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        pass
    except:
        assert False, 'An exception has been raised'


# Generated at 2022-06-26 13:05:21.636160
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor test

    p = TudouPlaylistIE()


# Generated at 2022-06-26 13:05:24.065471
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE)


# Generated at 2022-06-26 13:05:26.405896
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert tudou_album_i_e_0 is not None


# Generated at 2022-06-26 13:05:29.398873
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("-----test_TudouAlbumIE")
    obj = TudouAlbumIE()
    

# Generated at 2022-06-26 13:05:58.717878
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    ie.__init__(url)

# Generated at 2022-06-26 13:06:05.102260
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test 1: Constructor with correct url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)

    # Test 2: Constructor with incorrect url
    url = 'http://www.tudou.com/listplay/zzdE77v6Mm.html'
    try:
        TudouPlaylistIE(url)
    except:
        pass


# Generated at 2022-06-26 13:06:13.401730
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    if __name__ == '__main__':
        a =TudouAlbumIE()
        a.IE_NAME = 'tudou:album'
        a._VALID_URL = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
        a.extract(a)

# Generated at 2022-06-26 13:06:18.541505
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL[0:-1] == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:06:29.713353
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE()

    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

    assert tudou_playlist._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou_playlist._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert tudou_playlist._TESTS[0]['playlist_mincount'] == 209



# Generated at 2022-06-26 13:06:41.252806
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import sys
	print >> sys.stderr, 'testing class TudouAlbumIE'

	album_id = 'v5qckFJvNJg'
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	tudou_album_ie = TudouAlbumIE(url)
	album_data = tudou_album_ie._download_json(
		'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id, album_id)

# Generated at 2022-06-26 13:06:46.208174
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert 'tudou:playlist' == ie._VALID_URL
    assert 'zzdE77v6Mmo' == ie.playlist_id

# Generated at 2022-06-26 13:06:53.403329
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    my_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-26 13:06:58.072925
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    except:
        assert False


# Generated at 2022-06-26 13:07:03.301025
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    match = TudouPlaylistIE._TESTS[0]
    t_p_i_e = TudouPlaylistIE(url)
    t_p_i_e.match = match
    t_p_i_e.test_url = url


# Generated at 2022-06-26 13:08:20.192028
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    TudouPlaylistIE(url)
    TudouPlaylistIE(url, extract_flat=False)
    TudouPlaylistIE(url, ie_key='Tudou')
    TudouPlaylistIE(url, ie_key='Tudou', extract_flat=False)
    TudouPlaylistIE(url, downloader=None)
    TudouPlaylistIE(url, downloader=None, extract_flat=False)
    TudouPlaylistIE(url, ie_key='Tudou', downloader=None)
    TudouPlaylistIE(url, ie_key='Tudou', downloader=None, extract_flat=False)

# Generated at 2022-06-26 13:08:27.823326
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album = TudouAlbumIE(url)
    assert album.IE_NAME == 'tudou:album'
    assert album.playlist_id == 'v5qckFJvNJg'
    assert album.album_id == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:08:31.062684
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from  .tudou import TudouAlbumIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_album_ie_instance = TudouAlbumIE(url)
    

# Generated at 2022-06-26 13:08:38.750837
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')
    TudouPlaylistIE('http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo')



# Generated at 2022-06-26 13:08:46.360620
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = 'http://www.tudou.com/albumcover/oCd_HxnBcXA.html'
    album_id = 'oCd_HxnBcXA'
    album_data = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    title = '美食日记'

# Generated at 2022-06-26 13:08:52.350306
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE(url)
    assert ie.match_id(url) == 'v5qckFJvNJg'
    assert ie.match_id('http://www.tudou.com/albumcover/v5qckFJvNJg.html') == 'v5qckFJvNJg'


# Generated at 2022-06-26 13:08:59.912187
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test the playing list in Tudou.com
       This list is a popular list, the number of videos is at least 20.
    """
    list = ['http://www.tudou.com/listplay/zzdE77v6Mmo.html']
    
    for url in list:
        tudou_plist = TudouPlaylistIE()
        tudou_plist.extract(url)
        

# Generated at 2022-06-26 13:09:02.326954
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE.test()

test_TudouPlaylistIE()


# Generated at 2022-06-26 13:09:07.631711
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    ie = TudouAlbumIE()
    assert ie._match_id(url) == "v5qckFJvNJg"


# Generated at 2022-06-26 13:09:11.346582
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    return tudou_album_ie.extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:12:01.271526
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import fetch_unit_test_data
    from .test_tudou import _TEST_INFO_DICT
    from .test_tudou import _TEST_PAGE_URL
    page = fetch_unit_test_data(_TEST_PAGE_URL)
    playlist_data = fetch_unit_test_data(_TEST_INFO_DICT)['album_data']
    ie = TudouAlbumIE._get_ie(TudouAlbumIE._download_json('', '', False, playlist_data))
    info_dict = ie._real_extract(page)
    assert info_dict['id'] == 'testurl'

# Generated at 2022-06-26 13:12:07.831167
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test playlist's integrity (e.g. works fine with downloader)
    playlist_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist = TudouPlaylistIE()._real_extract(playlist_url)
    assert len(playlist['entries']) == 209

# Generated at 2022-06-26 13:12:10.744565
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    # Constructor of class TudouAlbumIE
    assert(TudouAlbumIE(InfoExtractor()))

# Generated at 2022-06-26 13:12:16.061098
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    infoExtractor = InfoExtractor()
    tudouPlaylistIEInstance = infoExtractor._get_info_extractor('tudou:playlist')(infoExtractor)
    assert tudouPlaylistIEInstance._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudouPlaylistIEInstance._TEST == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:12:23.328253
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Url for the test
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # Object to test
    test_TudouPlaylistIE = TudouPlaylistIE()
    # Test:
    expected = test_TudouPlaylistIE.extract(url)
    print('test_TudouPlaylistIE: ', end='')
    print('Input URL: ' + url)
    print('Expected value: ' + str(expected))
    print('Actual value: ' + str(test_TudouPlaylistIE._TESTS))
    assert(str(expected) == str(test_TudouPlaylistIE._TESTS))
