

# Generated at 2022-06-26 13:02:20.453721
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        # Constructor parameter should be unicode
        # Here we try to pass string type parameter
        TudouPlaylistIE('-' * 140)
    except TypeError as t:
        print(t.message)
    assert 'TudouPlaylistIE' in globals()


# Generated at 2022-06-26 13:02:25.401560
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_1 = TudouPlaylistIE()
    assert tudou_playlist_i_e_1.ie_name == 'tudou:playlist'
    assert tudou_playlist_i_e_1.valid_urls == (
        'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
    )

# Generated at 2022-06-26 13:02:26.346501
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()



# Generated at 2022-06-26 13:02:27.782376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True


# Generated at 2022-06-26 13:02:29.857845
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()


# Generated at 2022-06-26 13:02:34.128358
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    with pytest.raises(NotImplementedError):
        tudou_album_i_e = TudouAlbumIE()
        video = tudou_album_i_e.extract('test_url')


# Generated at 2022-06-26 13:02:36.334306
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:37.519081
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:38.658145
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:39.842098
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:48.563913
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    IE=TudouPlaylistIE()
    r=IE._real_extract("http://www.tudou.com/listplay/zzdE77v6Mmo.html")
    assert r["id"] == "zzdE77v6Mmo"
    assert r["_type"] == "playlist"
    assert r["playlist_count"] == 209
    assert len(r["entries"]) ==  209
    for i in r["entries"]:
        assert i["_type"] == "url"
        assert i["ie_key"] == "Tudou"
        assert i["url"] == "http://www.tudou.com/programs/view/%s"%(i["id"])
        assert i["title"] == i["description"]

# Generated at 2022-06-26 13:02:50.091818
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test constructor
    assert(TudouPlaylistIE)


# Generated at 2022-06-26 13:02:55.168649
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    el = TudouAlbumIE()
    assert el.__class__.__name__ == 'TudouAlbumIE'
    assert el.IE_NAME == 'tudou:album'
    assert el._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:02:59.383371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TD = TudouPlaylistIE()
    tmp_url = test_TD._VALID_URL
    tmp_id = test_TD._match_id(tmp_url)
    assert tmp_id == 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:03:05.069460
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    print("Start to test")
    print("Test case 1")
    print("URL: http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    print("Result:")
    extractor = TudouAlbumIE()._real_extract("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    print(extractor)

# Generated at 2022-06-26 13:03:07.300415
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:03:12.556624
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE(TudouAlbumIE.ie_key()).md5 == '1d5a53972787a73d1b9e45d9488636cc'
    assert TudouAlbumIE(TudouAlbumIE.ie_key()).info_dict['id'] == 'v5qckFJvNJg'
    assert TudouAlbumIE(TudouAlbumIE.ie_key()).playlist_mincount == 45

# Generated at 2022-06-26 13:03:25.994766
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = '1ef0c5addfb4046b'

# Generated at 2022-06-26 13:03:29.340573
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    assert a.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:03:39.202795
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Generator of unit test for constructor of class TudouPlaylistIE
    """

    # Args used to execute the constructor
    args = []
    # Should raise error?
    should_raise_error = False
    # Args used to call the constructor
    call_args = [
    ]
    # Dict of kwargs used to call the constructor
    call_kwargs = {
    }
    # Args used to call the _real_initialize method
    real_initialize_args = [
    ]
    # Dict of kwargs used to call the _real_initialize method
    real_initialize_kwargs = {
    }
    # Args used to call the _real_extract method

# Generated at 2022-06-26 13:03:59.626801
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .TudouAlbumIE import  TudouAlbumIE
    from .TudouIE import TudouIE

    URL = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

    albumIE = TudouAlbumIE()
    assert isinstance(albumIE, TudouAlbumIE)

    albumData = albumIE._real_extract(URL)
    assert albumData['id'] == 'v5qckFJvNJg'

    entries = albumData['entries']
    assert isinstance(entries[0], dict)
    assert entries[0]['ie_key'] == 'Tudou'
    assert entries[0]['url'] == 'http://www.tudou.com/programs/view/gNcZkHdCva0'


# Generated at 2022-06-26 13:04:02.287556
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert t is not None


# Generated at 2022-06-26 13:04:03.581568
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE is not None)


# Generated at 2022-06-26 13:04:17.380103
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    TudouPlaylistIE(object)
    object1 = TudouPlaylistIE._real_extract(TudouPlaylistIE,url=url)

# Generated at 2022-06-26 13:04:21.832293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	tudouPlaylistIE = TudouPlaylistIE()
	#print tudouPlaylistIE.IE_NAME
	assert 'tudou:playlist' == tudouPlaylistIE.IE_NAME


# Generated at 2022-06-26 13:04:33.196697
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Test constructor for class TudouPlaylistIE
    """

    # Test with a valid URL
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.url == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie.playlist_id == 'zzdE77v6Mmo'

    # Test with invalid URL
    try:
        ie = TudouPlaylistIE('invalid')
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-26 13:04:37.640048
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('Tudou', 'http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 13:04:39.383384
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print(TudouPlaylistIE._VALID_URL)


# Generated at 2022-06-26 13:04:45.722169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """TudouPlaylistIE constructor"""

    # Create an instance of TudouPlaylistIE class
    tudou = TudouPlaylistIE()

    # Check that TudouPlaylistIE class inherits from InfoExtractor class
    assert tudou.IE_NAME == 'tudou:playlist'
    assert tudou._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou.__module__ == 'tudou'
    assert tudou._TESTS[0].get('info_dict')['id'] == 'zzdE77v6Mmo'
    assert tudou._download_json == InfoExtractor._download_json

    # Check that _real_extract method was invoked

# Generated at 2022-06-26 13:04:49.341588
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    for tester in TudouAlbumIE._TESTS:
        url = tester['url']
        TudouAlbumIE(url)

# Generated at 2022-06-26 13:05:07.911473
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE()
    assert tudou_albumIE is not None
    assert tudou_albumIE.IE_NAME == 'tudou:album'


# Generated at 2022-06-26 13:05:09.036906
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE._VALID_URL, 'test_id')

# Generated at 2022-06-26 13:05:11.187803
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    t = TudouAlbumIE()
    assert(t.IE_NAME == 'tudou:album')


# Generated at 2022-06-26 13:05:24.369590
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    extractor = TudouAlbumIE()
    test_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = extractor._match_id(test_url)
    expected_album_id = 'v5qckFJvNJg'
    assert album_id == expected_album_id 
    album_url = 'http://www.tudou.com/tvp/alist.action?acode=%s' % album_id
    album_data = extractor._download_json(album_url, album_id)

# Generated at 2022-06-26 13:05:27.001843
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE(InfoExtractor())



# Generated at 2022-06-26 13:05:37.455882
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    assert tudou_playlist_ie.ie_key() == 'TudouPlaylist'
    assert tudou_playlist_ie.ie_name() == 'tudou:playlist'
    assert tudou_playlist_ie.suitable('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == True
    assert tudou_playlist_ie.suitable('http://www.tudou.com/albumplay/v5qckFJvNJg.html') == False
    assert tudou_playlist_ie.suitable('http://www.tudou.com/awesome/video/') == False

# Generated at 2022-06-26 13:05:43.306933
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE(None, None)
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:05:55.714715
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie.url = url
    album_id = ie._match_id(url)
    expected_album_id = 'v5qckFJvNJg'
    assert album_id == expected_album_id

    ie.download = lambda url: '{"items": [{"icode": "foo123", "kw": "bar"}, {"icode": "foo456", "kw": "baz"}]}'
    ie.playlist_result = lambda entries, playlist_id: (entries, playlist_id)

# Generated at 2022-06-26 13:06:03.817768
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import pytest

    url = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'

    @pytest.yield_fixture
    def tudou_album_ie(monkeypatch):
        # The constructor is supposed to return a TudouAlbumIE instance
        from ..tudou import TudouAlbumIE
        ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
        yield ie

    # Make sure all methods invoked have the expected name and arguments,
    # and that it returns what it is supposed to

# Generated at 2022-06-26 13:06:16.176962
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()
    obj = ie._real_initialize(url)
    assert ie.IE_NAME == obj.IE_NAME
    assert ie._VALID_URL == obj._VALID_URL
    assert ie._TESTS == obj._TESTS
    assert ie._download_json == obj._download_json
    assert ie._match_id == obj._match_id
    assert ie._real_extract == obj._real_extract
    assert ie.url_result == obj.url_result
# End of test.


# Generated at 2022-06-26 13:06:54.399232
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:07:06.284854
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ins = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ins.ie_key() == "TudouAlbum"
    assert ins.ie_name() == "tudou:album"
    assert ins._VALID_URL == "https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})"
    assert ins._TESTS[0]["url"] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    assert ins._TESTS[0]["info_dict"]["id"] == "v5qckFJvNJg"

# Generated at 2022-06-26 13:07:10.136064
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """
    Simple test for constructor of class TudouPlaylistIE
    """
    return TudouPlaylistIE

# Generated at 2022-06-26 13:07:12.502606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_equal(TudouAlbumIE._VALID_URL, r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')

# Generated at 2022-06-26 13:07:15.222409
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-26 13:07:18.073451
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE(TudouAlbumIE._VALID_URL)

# Generated at 2022-06-26 13:07:27.661200
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == "tudou:album"
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0] == {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }


# Generated at 2022-06-26 13:07:32.179861
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        TudouAlbumIE()
    except ImportError:
        raise
    except ValueError:
        pass
    except Exception:
        raise


# Generated at 2022-06-26 13:07:34.760285
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    # can not get id from url
    assert ie._match_id('http://test.test.test/test.test') == None


# Generated at 2022-06-26 13:07:36.786371
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE.TudouPlaylistIE(TudouPlaylistIE)
    print('TudouPlaylistIE object created.')


# Generated at 2022-06-26 13:08:42.776027
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:08:47.030718
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        from ..TudouAlbumIE import TudouAlbumIE
        TudouAlbumIE()
    except TypeError:
        raise AssertionError ('type error')


# Generated at 2022-06-26 13:08:48.218047
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE  # avoid pep8 error "unused import"

# Generated at 2022-06-26 13:08:49.203300
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE._TESTS[0]

# Generated at 2022-06-26 13:08:59.187238
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	t = TudouAlbumIE();
	assert t._TESTS[0]['url'] == "http://www.tudou.com/albumplay/v5qckFJvNJg.html";
	assert t._TESTS[0]['info_dict']['id'] == "v5qckFJvNJg";
	assert t._TESTS[0]['playlist_mincount'] == 45;


# Generated at 2022-06-26 13:09:02.792282
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    print(ie._VALID_URL)
    print(ie.IE_NAME)

test_TudouPlaylistIE()

# Generated at 2022-06-26 13:09:05.943261
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:09:08.776795
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:09:15.795801
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    playlist_id = 'zzdE77v6Mmo'

# Generated at 2022-06-26 13:09:19.622438
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE = TudouPlaylistIE()
    return test_TudouPlaylistIE

# Generated at 2022-06-26 13:12:04.280473
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	print(TudouPlaylistIE)


# Generated at 2022-06-26 13:12:15.055747
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # use example url
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    tudou_album_ie_instance = TudouAlbumIE(url)
    # assert the results
    assert tudou_album_ie_instance.IE_NAME == 'tudou:album'
    assert tudou_album_ie_instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'