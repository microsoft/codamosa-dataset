

# Generated at 2022-06-26 13:02:17.666867
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case_0()

# Generated at 2022-06-26 13:02:18.728797
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:21.540753
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    assert isinstance(tudou_playlist_i_e, InfoExtractor)

# Generated at 2022-06-26 13:02:24.019615
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    try:
        tudou_album_i_e = TudouAlbumIE()
    except Exception as e:
        print("Error: ", e)
    assert tudou_album_i_e._VALID_URL is None


# Generated at 2022-06-26 13:02:25.337277
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_case_0()


# Generated at 2022-06-26 13:02:25.844411
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass



# Generated at 2022-06-26 13:02:27.799186
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()

# Generated at 2022-06-26 13:02:30.451587
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    tudou_album_i_e = TudouAlbumIE(None)


# Generated at 2022-06-26 13:02:33.516276
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_equals("TudouAlbumIE", TudouAlbumIE().IE_NAME)


# Generated at 2022-06-26 13:02:36.662376
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for constructor of class TudouPlaylistIE.\n    def __init__(self, ie_name, ie_key):
    test_case_0()



# Generated at 2022-06-26 13:02:41.598251
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__bases__ == (InfoExtractor,)


# Generated at 2022-06-26 13:02:42.473246
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # 
    assert(True)

# Generated at 2022-06-26 13:02:50.462159
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album = TudouAlbumIE()
    assert tudou_album.IE_NAME == 'tudou:album'
    assert tudou_album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-26 13:03:01.820954
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album = TudouAlbumIE("albumplay/p3qM94E5r5Y.html")
    assert album._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert album._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/p3qM94E5r5Y.html',
        'info_dict': {
            'id': 'p3qM94E5r5Y',
        },
        'playlist_mincount': 69,
    }]
    assert album._match_id("albumplay/p3qM94E5r5Y.html") == "p3qM94E5r5Y"



# Generated at 2022-06-26 13:03:03.810681
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:03:05.367963
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_ie = TudouAlbumIE()
    assert(album_ie != None)


# Generated at 2022-06-26 13:03:13.619994
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE.__doc__ ==  \
        'Tudou album info extractor'
    assert TudouAlbumIE._VALID_URL ==  \
        r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE._TESTS ==  \
        [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
          'info_dict': {'id': 'v5qckFJvNJg'},
          'playlist_mincount': 45}]


# Generated at 2022-06-26 13:03:26.597442
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    instance = TudouAlbumIE()
    assert instance.IE_NAME == 'tudou:album'
    assert instance.IE_DESC == '土豆 - 发现最有趣的视频'
    assert instance._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert instance._TESTS == [{
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }]

# Generated at 2022-06-26 13:03:30.707844
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')


# Generated at 2022-06-26 13:03:40.568241
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo')
    assert(TudouPlaylistIE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo') is None)
    assert(TudouPlaylistIE._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo/') == 'zzdE77v6Mmo')
    assert(TudouPlaylistIE._match_id('https://www.tudou.com/listplay/zzdE77v6Mmo/') == 'zzdE77v6Mmo')

# Generated at 2022-06-26 13:03:49.411077
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:03:50.238026
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-26 13:03:54.278169
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:03:57.632963
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    Tav = TudouAlbumIE()
    Tav.extract(url)


# Generated at 2022-06-26 13:04:01.816190
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    assert(td.IE_NAME == 'tudou:album')

# Generated at 2022-06-26 13:04:09.454095
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert len(ie._TESTS)>0


# Generated at 2022-06-26 13:04:13.396211
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE()
	assert ie.ie_key() == 'Tudou:album'
	assert ie.title() == 'Tudou'


# Generated at 2022-06-26 13:04:20.463223
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tests import test_TudouAlbumIE
    test_TudouAlbumIE.TudouAlbumIE = TudouAlbumIE
    test_TudouAlbumIE.test_TudouAlbumIE()
    del test_TudouAlbumIE.TudouAlbumIE


# Generated at 2022-06-26 13:04:21.752656
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass
    

# Generated at 2022-06-26 13:04:30.629403
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """ Test that constructor of class TudouPlaylistIE works """
    assert TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo'
    assert TudouPlaylistIE._TESTS[0]['playlist_mincount'] == 209

# Generated at 2022-06-26 13:04:49.029362
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert ie is not None


# Generated at 2022-06-26 13:04:52.148062
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    a._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    a._real_extract('http://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:04:59.093522
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    # return the constructed value to caller
    return tudou_album_ie._real_extract(url)


# Generated at 2022-06-26 13:05:07.857755
# Unit test for constructor of class TudouAlbumIE

# Generated at 2022-06-26 13:05:09.347606
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	ie = TudouAlbumIE({})
	assert ie

# Generated at 2022-06-26 13:05:14.022686
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    #assert tudou_album_ie._SORTS == {}

# Generated at 2022-06-26 13:05:21.829002
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    class TestTudouPlaylistIE(unittest.TestCase):
        def test_constructor(self):
            a = TudouPlaylistIE()

    suite = unittest.TestLoader().loadTestsFromTestCase(TestTudouPlaylistIE)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-26 13:05:35.235420
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import expected_warnings
    from ..utils import ExtractorError

    ie = TudouAlbumIE(None)


# Generated at 2022-06-26 13:05:46.967726
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # URL validation
    assert(TudouPlaylistIE._VALID_URL == 'http://www.tudou.com/listplay/(?P<id>[\w-]{11})\\.html')
    assert(TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert(TudouPlaylistIE._TESTS[0]['info_dict']['id'] == 'zzdE77v6Mmo')

    # Test for constructor

# Generated at 2022-06-26 13:05:48.364657
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE(
    )


# Generated at 2022-06-26 13:06:17.111441
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    t._real_extract('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:06:24.226087
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_dict = {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }
    tudou_album_IE = TudouAlbumIE()
    assert tudou_album_IE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_IE.IE_NAME == 'tudou:album'
    assert tudou_album_IE._TESTS[0] == test_dict


# Generated at 2022-06-26 13:06:25.396816
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:06:31.839985
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    I = TudouPlaylistIE()
    I._match_id(url)
    I._real_extract(url)

# Generated at 2022-06-26 13:06:35.000414
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor of Tudou Playlist class
    TudouPlaylist=TudouPlaylistIE()

# Generated at 2022-06-26 13:06:40.516818
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = "http://www.tudou.com/listplay/ZZdE77v6Mmo.html"
    tudou = TudouPlaylistIE(url)
    #test _real_extract
    testurl = 'http://www.tudou.com/tvp/plist.action?lcode=ZZdE77v6Mmo'
    assert tudou._real_extract(url) == tudou._download_json(testurl, 'ZZdE77v6Mmo')

# Generated at 2022-06-26 13:06:42.069347
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:06:43.445715
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	TudouPlaylistIE()


# Generated at 2022-06-26 13:06:45.487891
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("TudouAlbumIE")

# Generated at 2022-06-26 13:06:54.100308
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """Tests the constructor of class TudouAlbumIE"""
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE()
    assert ie.IE_NAME == 'tudou:album'
    assert ie.IE_DESC == '土豆网'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

# Generated at 2022-06-26 13:08:04.491748
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    class_ = TudouAlbumIE
    instance_of_class = class_()
    assert(instance_of_class.IE_NAME == 'tudou:album')
    assert(instance_of_class._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})')
    assert(instance_of_class._TESTS == [{'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html', 'info_dict': {'id': 'v5qckFJvNJg'}, 'playlist_mincount': 45}])


# Generated at 2022-06-26 13:08:11.130840
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    ie = TudouAlbumIE()

    assert ie._real_extract(url)['id'] == album_id
    assert ie._real_extract(url)['title'] == album_id
    assert ie._real_extract(url)['_type'] == 'playlist'
    assert len(ie._real_extract(url)['entries']) >= 1



# Generated at 2022-06-26 13:08:22.564506
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:08:28.334015
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    ie = TudouAlbumIE()
    # 'url', 'ie_key', 'video_id'
    assert 'http://www.tudou.com/albumcover/v5qckFJvNJg.html' == ie.working_url(url, 'tudou:album', None)

# Generated at 2022-06-26 13:08:31.671461
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE.__name__ == 'TudouPlaylistIE'
    assert TudouPlaylistIE.ie_key() == 'tudou:playlist'
    assert TudouPlaylistIE.supported_extractors == {'tudou:playlist'}
    assert TudouPlaylistIE.SUPPORTED_EXTENSIONS == {}

# Generated at 2022-06-26 13:08:34.036268
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ae = TudouAlbumIE()
    assert ae.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:08:40.545381
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie = TudouPlaylistIE()
    tudou_playlist_ie._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:08:53.465559
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    album_data = ie._download_json(
            'http://www.tudou.com/tvp/alist.action?acode=%s' % 'v5qckFJvNJg', 'v5qckFJvNJg', fatal=False)
    entries = [ie.url_result(
            'http://www.tudou.com/programs/view/%s' % item['icode'],
            'Tudou', item['icode'],
            item['kw']) for item in album_data['items']]
    playlist_result = ie.playlist_result(entries, 'v5qckFJvNJg')

# Generated at 2022-06-26 13:08:54.307908
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert True

# Generated at 2022-06-26 13:09:02.783087
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    Test whether the constructor of class TudouAlbumIE is working well
    """
    url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    album = TudouAlbumIE()
    album.add_default_values()
    album.url = url
    album._match_id(url)
    album._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:11:38.332639
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = 'b5br0oL-j2c'
    url = 'http://www.tudou.com/albumplay/' + album_id
    tudou_album_ie = TudouAlbumIE(url)
    assert tudou_album_ie.album_id == album_id


# Generated at 2022-06-26 13:11:49.144113
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
	playlist_id = 'zzdE77v6Mmo'
	playlist_data = '{"items":[{"icode":"spzsYiMHZtQ","kw":"神盾局特工第二季插曲-每集歌曲","cid":1116}],"totalCount":0,"pageCount":0,"pageNo":1,"pageSize":0,"totalPage":0}'
	downloader = InfoExtractor()
	assert downloader.url_result(url, playlist_id, playlist_data) == downloader.playlist_result(downloader.url_result(url, playlist_id, playlist_data))

# Unit test

# Generated at 2022-06-26 13:11:51.205140
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test for creating an instance of TudouAlbumIE
    # Your code here
    pass


# Generated at 2022-06-26 13:11:58.169495
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    expected_album_id = 'v5qckFJvNJg'
    actual_album_id = 'TudouAlbumIE._match_id(http://www.tudou.com/albumcover/v5qckFJvNJg/)'
    assert expected_album_id == actual_album_id

# Generated at 2022-06-26 13:12:10.076414
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .common import InfoExtractor
    from .tudou import _TudouPlaylistIE

    # Initialize
    tudou_playlist = _TudouPlaylistIE(InfoExtractor())

    # Properties
    assert tudou_playlist.ie_key() == 'TudouPlaylist'
    assert tudou_playlist.ie_name() == 'tudou:playlist'
    assert tudou_playlist.ie_description() == '土豆网-列表播放'
    assert tudou_playlist.ie_version() == '1.0'

    # Test method _real_extract
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert tudou

# Generated at 2022-06-26 13:12:12.639473
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert x._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
