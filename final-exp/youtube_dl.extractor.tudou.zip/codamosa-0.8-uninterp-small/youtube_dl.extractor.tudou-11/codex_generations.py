

# Generated at 2022-06-26 13:02:16.882858
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
     assert(true)


# Generated at 2022-06-26 13:02:17.902055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:18.907836
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_0 = TudouAlbumIE()

# Generated at 2022-06-26 13:02:20.703987
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert test_case_0() == None


# Generated at 2022-06-26 13:02:22.145891
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert isinstance(TudouPlaylistIE(), TudouPlaylistIE)


# Generated at 2022-06-26 13:02:23.436981
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:29.479345
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Part of URL of page where you can find videos list
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    tudou_album_i_e = TudouAlbumIE(url)
    # If parsing failed, then raise error
    assert tudou_album_i_e.url

    tudou_album_i_e.extract()
    # If parsing failed, then raise error
    assert tudou_album_i_e.playlist_id
    assert tudou_album_i_e.playlist_mincount
    assert tudou_album_i_e.playlist_title
    assert tudou_album_i_e.uploader
    assert tudou_album_i_e.uploader_id

# Generated at 2022-06-26 13:02:38.640796
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    tudou_playlist_i_e.suitable("http://www.tudou.com/listplay/PcX9x6dN1S4.html&iid=119589427")
    tudou_playlist_i_e.download("http://www.tudou.com/listplay/PcX9x6dN1S4.html&iid=119589427")
    assert tudou_playlist_i_e._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:02:39.817237
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_1 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:40.711078
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:02:45.246135
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudoualbumIE = TudouAlbumIE("http://www.tudou.com/albumcover/v5qckFJvNJg.html")

# Generated at 2022-06-26 13:02:56.771475
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert ie.IE_NAME == 'tudou:album'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['info_dict']['id'] == 'v5qckFJvNJg'
    assert ie._TESTS[0]['playlist_mincount'] == 45

# Generated at 2022-06-26 13:02:57.746310
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
   assert TudouPlaylistIE()

# Generated at 2022-06-26 13:03:01.732202
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    """Test whether it can construct an instance of class TudouPlaylistIE"""
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:03:02.674228
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	TudouAlbumIE()

# Generated at 2022-06-26 13:03:11.683292
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # test for function _real_extract
    playlist_ie = TudouPlaylistIE()
    tudou_playlist = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    info_dict = { 'id' : 'zzdE77v6Mmo' }
    playlist_mincount = 209
    playlist_data_url = 'http://www.tudou.com/tvp/plist.action?lcode=zzdE77v6Mmo'
    result = playlist_ie.url_result(tudou_playlist, 'Tudou', 'zzdE77v6Mmo', '梦想的声音')

# Generated at 2022-06-26 13:03:18.680674
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing TudouPlaylistIE constructor")
    # constructor tests
    try:
        TudouPlaylistIE()
    except Exception:
        print("Error: constructor test failed")
    # invalid argument test
    try:
        TudouPlaylistIE("Lorem Ipsum")
    except Exception:
        print("Error: invalid argument test failed")


# Generated at 2022-06-26 13:03:22.883809
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert 'http://www.tudou.com/albumcover/9j5b5f5Ezeg.html' in ie._VALID_URL

# Generated at 2022-06-26 13:03:23.895961
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    pass


# Generated at 2022-06-26 13:03:28.050592
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()
    a._real_extract('http://www.tudou.com/albumplay/nH3qn_fv_Tw.html')

# Generated at 2022-06-26 13:03:38.651935
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .tudou import TudouAlbumIE
    assert TudouAlbumIE._VALID_URL

# Generated at 2022-06-26 13:03:46.535051
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:03:51.668788
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


# Generated at 2022-06-26 13:03:54.694112
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	tudou_albumie = TudouAlbumIE()
	assert tudou_albumie.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:04:01.593890
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    album_id = "v5qckFJvNJg"
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    test_result = TudouAlbumIE._real_extract(self, url)
    assert album_id in test_result

print("Unit test for TudouAlbumIE: ", test_TudouAlbumIE())

# Generated at 2022-06-26 13:04:17.308352
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    t = TudouPlaylistIE()
    t.IE_NAME = 'tudou:playlist'
    assert t.IE_NAME == 'tudou:playlist'
    t.IE_DESC = 'legacy tudou:playlist'
    assert t.IE_DESC == 'legacy tudou:playlist'
    assert t.IE_NAME in t.ie_key()
    assert t.IE_NAME == t.ie_key()
    t._VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'

# Generated at 2022-06-26 13:04:31.509043
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import json
    from pytesseract import image_to_string
    from PIL import Image
    from urllib import unquote
    from os.path import dirname, join, abspath
    from bs4 import BeautifulSoup
    from selenium import webdriver
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.by import By
    from selenium.common.exceptions import TimeoutException

    # The user could be asked to enter a captcha.
    # Here, the code automatizes this process.


# Generated at 2022-06-26 13:04:33.416560
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from . import tudou
    type(tudou)

# Generated at 2022-06-26 13:04:38.712073
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    '''
    Test for TudouPlaylist
    '''
    # Album
    test_url_playlist = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    i = TudouAlbumIE(url = test_url_playlist, downloader = None)
    assert i._TESTS[0]['url'] == test_url_playlist
    assert i._TESTS[0]['playlist_mincount'] == 45
    assert i._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert i._real_extract(test_url_playlist)['id'] == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:04:41.155588
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    td_album_ie = TudouAlbumIE("www.tudou.com/albumplay/v5qckFJvNJg.html")
    assert td_album_ie is not None

# Generated at 2022-06-26 13:05:03.978329
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudouAlbum = TudouAlbumIE()
    tudouAlbum.IE_NAME = 'TudouAlbum'
    tudouAlbum._VALID_URL = 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    tudouAlbum.name = 'TudouAlbum'
    assert tudouAlbum.IE_NAME == 'TudouAlbum'
    assert tudouAlbum._VALID_URL == 'http://www.tudou.com/albumcover/v5qckFJvNJg.html'
    assert tudouAlbum.name == 'TudouAlbum'

# Generated at 2022-06-26 13:05:05.684762
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE is not None

# Generated at 2022-06-26 13:05:08.954652
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:05:16.219149
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Test constructor of class TudouAlbumIE
    # in "tudou.py" file.

    # Test without any parameter
    # Will raise exception
    try:
        TuDouAlbumIE()
    except Exception as e:
        print('Case 1: Exception: %s' % repr(e))
    else:
        print('Case 1: No exception')

    # Test with invalid address
    # Will raise exception
    address = 'Frodo_Baggins'
    try:
        tudou_album_ie = TudouAlbumIE(address)
    except Exception as e:
        print('Case 2: Exception: %s' % repr(e))
    else:
        print('Case 2: No exception')

    # Test with valid address
    # Will raise exception

# Generated at 2022-06-26 13:05:19.878333
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE("http://www.tudou.com/albumplay/v5qckFJvNJg.html")

# Generated at 2022-06-26 13:05:25.098852
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    valid_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    expected_url_result = 'http://www.tudou.com/programs/view/%s' % album_id
    returned_url_result = TudouAlbumIE._real_extract(TudouAlbumIE, valid_url)
    returned_url = returned_url_result[0]
    url = returned_url.url
    assert url == expected_url_result

# Generated at 2022-06-26 13:05:28.873259
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._VALID_URL == TudouAlbumIE._VALID_URL


# Generated at 2022-06-26 13:05:33.069293
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou = TudouPlaylistIE()

# Generated at 2022-06-26 13:05:39.833653
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE()._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE().IE_NAME == 'tudou:album'


# Generated at 2022-06-26 13:05:50.062528
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"
    i = TudouAlbumIE(TudouAlbumIE.ie_key())
    i_result = i.extract(test_url)

# Generated at 2022-06-26 13:06:15.281876
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-26 13:06:19.316284
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	# end-to-end test with real url
	# url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	# test_TudouAlbumIE(TudouAlbumIE, url)
	url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
	IE = TudouAlbumIE(downloader=None)
	playlist = IE.extract(url)
	print(playlist)


# Generated at 2022-06-26 13:06:23.196435
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''Test constructor of class TudouPlaylistIE'''
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')

# Generated at 2022-06-26 13:06:32.609212
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert(TudouPlaylistIE.IE_NAME == 'tudou:playlist')
    assert(TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html')
    assert(TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }])
    return


# Generated at 2022-06-26 13:06:43.529144
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    from .common import InfoExtractor
    valid_url = 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    entry = 'http://www.tudou.com/programs/view/mQ2q8Ci4gx4'
    class_name = 'Tudou'
    video_id = 'mQ2q8Ci4gx4'
    title = '高考志愿填报全方位分析'
    info = {
        'id': 'mQ2q8Ci4gx4',
        'title': title,
        'url': entry,
    }
    TudouAlbumIE.suitable(valid_url)
    ie = InfoExtractor(valid_url)

# Generated at 2022-06-26 13:06:49.354063
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE({})
    url = 'https://www.tudou.com/albumcover/v5qckFJvNJg.html'
    album_id = 'v5qckFJvNJg'
    assert ie._real_extract(url)

# Generated at 2022-06-26 13:06:52.402233
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:07:04.512318
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    """
    ---------------------------------------------------------------------------------
    * test TudouAlbumIE class constructor
    * test url parameter
    * test ie_key parameter
    """
    
    from .tudou import TudouAlbumIE
    
    # create test album playlist in instance of 'TudouAlbumIE' class
    album1 = TudouAlbumIE(url='http://www.tudou.com/albumplay/v5qckFJvNJg.html',
                          ie_key='Tudou:album')
    
    # create test playlist in instance of 'TudouAlbumIE' class
    album2 = TudouAlbumIE(url='http://www.tudou.com/albumplay/v5qckFJvNJg.html',
                          ie_key='Tudou:playlist')
    
    #

# Generated at 2022-06-26 13:07:06.298258
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()
    return 0


# Generated at 2022-06-26 13:07:14.712741
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    

# Generated at 2022-06-26 13:08:14.309689
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE()


# Generated at 2022-06-26 13:08:16.584619
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	x = TudouPlaylistIE()
	assert x.IE_NAME == 'tudou:playlist'

# Generated at 2022-06-26 13:08:25.409304
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():

	def __init__(self, url, ie=None, video_id=None, video_info=None, download=True,
							 download_id=None, note=None, errnote=None, fatal=True):
		InfoExtractor.__init__(self, url, ie, video_id, video_info, download, download_id, note, errnote, fatal)


# Generated at 2022-06-26 13:08:30.335727
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    assert ie.__class__ == TudouAlbumIE

# Generated at 2022-06-26 13:08:43.344870
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case_0 = {
        'url': 'http://www.tudou.com/albumplay/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

    test_case_1 = {
        'url': 'http://www.tudou.com/albumcover/v5qckFJvNJg.html',
        'info_dict': {
            'id': 'v5qckFJvNJg',
        },
        'playlist_mincount': 45,
    }

    test_cases = [test_case_0, test_case_1]
    album_ex = TudouAlbumIE()

# Generated at 2022-06-26 13:08:44.177158
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass

# Generated at 2022-06-26 13:08:47.238605
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert obj == obj
    assert unicode(obj) == '<TudouAlbumIE>'

# Generated at 2022-06-26 13:08:50.488232
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    '''
    Unit test for constructor of class TudouPlaylistIE.
    '''
    tudouplaylist = TudouPlaylistIE()
    assert tudouplaylist != None, 'Object cannot be created'
    assert tudouplaylist.ie_key() == 'TudouPlaylist', 'TudouPlaylistIE key must be TudouPlaylist'
    assert tudouplaylist.ie_name() == 'tudou:playlist', 'TudouPlaylistIE name must be tudou:playlist'


# Generated at 2022-06-26 13:08:54.234435
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	'''Test the constructor of the class TudouAlbumIE'''
	TudouAlbumIE()

# Generated at 2022-06-26 13:09:01.550997
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_albumIE = TudouAlbumIE(None)
    assert tudou_albumIE._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_albumIE.IE_NAME == 'tudou:album'

# Generated at 2022-06-26 13:11:38.293759
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    'Test constructor of class TudouAlbumIE'
    # Test exception if the parameter is of wrong type
    with pytest.raises(AssertionError):
        TudouAlbumIE(None, object())
    with pytest.raises(AssertionError):
        TudouAlbumIE(None, object(), 'xyz')

# Generated at 2022-06-26 13:11:40.887562
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_TudouAlbumIE = TudouAlbumIE()

# Generated at 2022-06-26 13:11:52.262595
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    url = "http://www.tudou.com/albumplay/v5qckFJvNJg.html"

    albumIE = TudouAlbumIE(None)
    assert albumIE.IE_NAME == 'tudou:album'
    assert albumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'

    assert albumIE._match_id(url) == 'v5qckFJvNJg'

# Generated at 2022-06-26 13:11:57.227003
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('https://www.tudou.com/albumcover/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:12:03.036494
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert TudouAlbumIE.IE_NAME == 'tudou:album'
    assert TudouAlbumIE.__name__ == 'TudouAlbumIE'


# Generated at 2022-06-26 13:12:14.654068
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()
    assert tudou_album_ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_ie.IE_NAME == 'tudou:album'
    assert len(tudou_album_ie._TESTS) == 1, "len(tudou_album_ie._TESTS) = %d, but should be 1" % len(tudou_album_ie._TESTS)
    assert tudou_album_ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
   