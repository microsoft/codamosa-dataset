

# Generated at 2022-06-26 13:02:15.990075
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    assert_equal(tudou_album_i_e.IE_NAME, 'tudou:album')


# Generated at 2022-06-26 13:02:17.363447
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:18.907900
# Unit test for constructor of class TudouPlaylistIE

# Generated at 2022-06-26 13:02:27.271015
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Sample url
    val_inp_1 = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    # expected output
    exp_out_1 = 'zzdE77v6Mmo'

    assert val_inp_1 == tudou_playlist_i_e_0.match_id(val_inp_1)

    # Sample url
    val_inp_2 = None
    # expected output
    exp_out_2 = None

    assert val_inp_2 == tudou_playlist_i_e_0.match_id(val_inp_2)

    # Sample url
    val_inp_3 = 'http://www.tudou.com/listplay/.html'
    # expected output
    exp_out_

# Generated at 2022-06-26 13:02:29.602971
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:30.878399
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_ie_0 = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:33.954234
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test first constructor
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:35.788903
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:02:43.140262
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test with invalid url
    tudou_playlist_i_e_1 = TudouPlaylistIE(url='http://www.youtube.com/watch?v=BaW_jenozKc')
    # Test with fake url
    tudou_playlist_i_e_2 = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')
    # Test with real url
    tudou_playlist_i_e_3 = TudouPlaylistIE(url='http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:02:43.912504
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()

# Generated at 2022-06-26 13:02:51.950078
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:03.120867
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    tudou_album_i_e.get_real_download_url('http://www.tudou.com/albumplay/v5qckFJvNJg.html')
    tudou_album_i_e.get_real_download_url('http://www.tudou.com/albumcover/v5qckFJvNJg')
    tudou_album_i_e.get_real_download_url('http://www.tudou.com/albumcover/v5qckFJvNJg.html')
    tudou_album_i_e.get_real_download_url('http://www.tudou.com/albumplay/v5qckFJvNJg/')
    tudou

# Generated at 2022-06-26 13:03:12.087383
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()
    # Test for private attributes _VALID_URL and IE_NAME
    assert tudou_album_i_e._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_i_e.IE_NAME == 'tudou:album'
    # Test for method _real_extract
    tudou_album_i_e._real_extract(
        'http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:03:20.700452
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_1 = TudouAlbumIE()
    assert tudou_album_i_e_1._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert tudou_album_i_e_1.IE_NAME == 'tudou:album'


# Generated at 2022-06-26 13:03:23.476887
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:25.790961
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e = TudouAlbumIE()


# Generated at 2022-06-26 13:03:27.618116
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    a = TudouAlbumIE()

# Generated at 2022-06-26 13:03:30.061532
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e_0 = TudouPlaylistIE()

# Generated at 2022-06-26 13:03:35.448690
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Test for constructor
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:39.673405
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_i_e_1 = TudouAlbumIE()


# Generated at 2022-06-26 13:03:55.694682
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()


# Generated at 2022-06-26 13:03:58.737700
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    # Check that type(tudou_album_i_e_0) is TudouAlbumIE
    assert type(tudou_album_i_e_0) == TudouAlbumIE



# Generated at 2022-06-26 13:04:05.289165
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert TudouPlaylistIE()._VALID_URL == 'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert TudouPlaylistIE().IE_NAME == 'tudou:playlist'
    assert TudouPlaylistIE()._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]


# Generated at 2022-06-26 13:04:07.717600
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert_equal("TudouAlbumIE", tudou_album_i_e_0.IE_NAME)


# Generated at 2022-06-26 13:04:10.219449
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    # Constructor of TudouPlaylistIE without parameters.
    tudou_playlist_i_e_0 = TudouPlaylistIE()


# Generated at 2022-06-26 13:04:12.948511
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist_i_e = TudouPlaylistIE()
    pass

# Generated at 2022-06-26 13:04:14.933008
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    with pytest.raises(TypeError):
        TudouAlbumIE()


# Generated at 2022-06-26 13:04:19.375589
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:04:20.430414
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    pass


# Generated at 2022-06-26 13:04:21.752427
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_case_0()


# Generated at 2022-06-26 13:04:35.917437
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    assert True


# Generated at 2022-06-26 13:04:43.222851
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	# Currently only one test case is provided here, you should test with your own 
	# test cases if you have modified the class TudouPlaylistIE or its methods.
	from extractors.testcases import TestCase
	from utils import unified_strdate
	TestCase(TudouPlaylistIE, expected=[
	{
		'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
		'info_dict': {
			'id': 'zzdE77v6Mmo',
		},
		'playlist_count': 209
	}
	])()

# Generated at 2022-06-26 13:04:51.871571
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    test_cases = ['http://www.tudou.com/albumcover/v5qckFJvNJg.html',
                  'http://www.tudou.com/albumcover/v5qckFJvNJg/',
                  'http://www.tudou.com/albumplay/v5qckFJvNJg/',
                  'http://www.tudou.com/albumplay/v5qckFJvNJg.html']

    for tc in test_cases:
        TudouAlbumIE(tc, {})


# Generated at 2022-06-26 13:05:03.945610
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print ('test_TudouPlaylistIE()')
    if __name__=='__main__':
        print ('real main')
        IE_NAME = 'tudou:playlist'
        VALID_URL = r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
        TESTS = [{
            'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
            'info_dict': {
                'id': 'zzdE77v6Mmo',
            },
            'playlist_mincount': 209,
        }]

        class InfoExtractor():
            pass
        class merge_dicts(*a):
            pass

# Generated at 2022-06-26 13:05:05.683625
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE

# Generated at 2022-06-26 13:05:08.357158
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    test_TudouPlaylistIE.__doc__ = InfoExtractor._download_json.__doc__


# Generated at 2022-06-26 13:05:14.620928
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    testcases = [
        ('http://www.tudou.com/listplay/zzdE77v6Mmo.html', 'zzdE77v6Mmo'),
        ('http://www.tudou.com/listplay/QMNIzgH0048.html', 'QMNIzgH0048'),
    ]
    for url, playlist_id in testcases:
        tudoutest = TudouPlaylistIE()
        result = tudoutest._match_id(url)
        assert result == playlist_id


# Generated at 2022-06-26 13:05:17.123424
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    class_ = TudouPlaylistIE
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'

    ie = class_(class_.test_working_instance())
    try:
        assert ie.suitable(url)
        ie.extract(url)
    except:
        assert False


# Generated at 2022-06-26 13:05:20.983164
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from tudou_extractor import TudouPlaylistIE
    tudoupl = TudouPlaylistIE()


# Generated at 2022-06-26 13:05:23.505640
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("test_TudouPlaylistIE")
    # Doesn't work anymore
    return
    playlist = TudouPlaylistIE()
    url = "http://www.tudou.com/listplay/zzdE77v6Mmo.html"
    print(playlist.extract(url))



# Generated at 2022-06-26 13:05:55.648022
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE()
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'
    assert ie._TESTS[0]['playlist_mincount'] == 45
    assert ie._VALID_URL == 'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})'
    assert ie.IE_NAME == 'tudou:album'


# Generated at 2022-06-26 13:05:59.803679
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    from .test_TudouIE import TEST_URL
    tdur = TudouPlaylistIE()
    for url in TEST_URL:
        result = tdur.suitable(url)
        assert result == True

# Generated at 2022-06-26 13:06:00.638946
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE._real_extract('http://www.tudou.com/albumplay/v5qckFJvNJg.html')

# Generated at 2022-06-26 13:06:07.288463
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    ie = TudouPlaylistIE()._call_api(url)
    # Test for instance type
    assert isinstance(ie, InfoExtractor)
    # Test for constructor
    assert ie._VALID_URL == 'https?://(?:www\\.)?tudou\\.com/listplay/(?P<id>[\\w-]{11})\\.html'
    assert ie.IE_NAME == 'Tudou'
    assert ie.ie_key() == 'tudou:playlist'
    assert ie.ie_key() in ie._IES
    assert ie.suitable(url)
    assert ie._downloader is not None

# Generated at 2022-06-26 13:06:17.740253
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    import unittest
    class TestTudouPlaylistIE(unittest.TestCase):
        def test_tudou_playlist(self):
            self.assertTrue(TudouPlaylistIE._VALID_URL.match('http://www.tudou.com/listplay/zzdE77v6Mmo.html'))
            self.assertTrue(TudouPlaylistIE._VALID_URL.match('https://www.tudou.com/listplay/zzdE77v6Mmo.html'))
            self.assertTrue(TudouPlaylistIE._VALID_URL.match('http://www.tudou.com/listplay/zzdE77v6Mmo'))

# Generated at 2022-06-26 13:06:18.489029
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()


# Generated at 2022-06-26 13:06:30.208249
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
	test_data = {
		"id":"zzdE77v6Mmo",
		"icode": "dE77v",
		"kw": u"超级飞侠 大明湖畔的追踪者 家族的节日",
		"title": u"第一集 超能少年队和大明湖畔的追踪者",
	}
	ie_object = TudouPlaylistIE()
	assert ie_object.test_data(test_data) == True, "test_TudouPlaylistIE: constructor test failed"

# Generated at 2022-06-26 13:06:36.685068
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    assert TudouAlbumIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/album(?:cover|play)/(?P<id>[\w-]{11})', "The regular expression is updated - this test must be updated"

# Generated at 2022-06-26 13:06:39.679625
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    obj = TudouAlbumIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-26 13:06:46.541137
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE(None)
    ie._match_id('_VALID_URL')
    ie._download_json('tvp/plist.action?lcode=zzdE77v6Mmo')

# Generated at 2022-06-26 13:07:57.025638
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    TudouPlaylistIE('http://www.tudou.com/listplay/zzdE77v6Mmo.html')


# Generated at 2022-06-26 13:08:08.210555
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie._TESTS[0]['url'] == 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    assert ie._TESTS[0]['info_dict'] == {'id': 'zzdE77v6Mmo'}
    assert ie._TESTS[0]['playlist_mincount'] == 209


# Generated at 2022-06-26 13:08:11.065039
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    TudouAlbumIE()

# Generated at 2022-06-26 13:08:14.509471
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    try:
        TudouPlaylistIE()
    except NameError as e:
        pass
    else:
        raise Exception('Expected NameError not raised')


# Generated at 2022-06-26 13:08:20.939559
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    url = 'http://www.tudou.com/listplay/zzdE77v6Mmo.html'
    tudou_playlist = TudouPlaylistIE()
    ie = tudou_playlist.extract(url)
    assert ie.get('id') == 'zzdE77v6Mmo'
    assert ie.get('playlist') == "zzdE77v6Mmo"
    assert ie.get('__type__') == 'playlist'

# Generated at 2022-06-26 13:08:23.551200
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    IE = TudouAlbumIE()
    assert IE.IE_NAME == "tudou:album"

# Generated at 2022-06-26 13:08:32.539132
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    ie = TudouPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert ie.IE_NAME == 'tudou:playlist'
    assert ie.playlist_mincount == 209
    assert ie._match_id('http://www.tudou.com/listplay/zzdE77v6Mmo.html') == 'zzdE77v6Mmo'


# Generated at 2022-06-26 13:08:34.355385
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    x = TudouAlbumIE(None)

# Generated at 2022-06-26 13:08:49.638958
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudou_playlist = TudouPlaylistIE('www.tudou.com/listplay/zzdE77v6Mmo.html')
    assert tudou_playlist.IE_NAME == 'tudou:playlist'
    assert tudou_playlist._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'
    assert tudou_playlist._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

# Generated at 2022-06-26 13:08:55.101016
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
	import sys
	import os
	import unittest


if __name__ == '__main__':
	sys.path.append(os.getcwd())
	unittest.main()

# Generated at 2022-06-26 13:11:30.931562
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    tudouIE = TudouPlaylistIE()

# Generated at 2022-06-26 13:11:35.095055
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    tudou_album_ie = TudouAlbumIE()

# Generated at 2022-06-26 13:11:42.440838
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    print("Testing TudouPlaylistIE ...")
    j_data = {
        'items': [
            {}
        ]
    }
    ie = TudouPlaylistIE()
    ie._download_json(url='', ie_id='')
    ie._real_extract(url='', playlist_id='')
    print("Done")


# Generated at 2022-06-26 13:11:50.063202
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    ie = TudouAlbumIE('http://www.tudou.com/albumcover/v5qckFJvNJg')
    assert ie.url == 'http://www.tudou.com/albumplay/v5qckFJvNJg.html'

# Generated at 2022-06-26 13:12:01.778984
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    import os
    from .common import _TESTS_ROOT, _TEST_FILES_ROOT

    from .tudou import TudouAlbumIE

    ie = TudouAlbumIE()

    json_data = open(os.path.join(_TEST_FILES_ROOT, 'tudou_albumplay_v5qckFJvNJg.json')).read()
    playlist_data = ie._parse_json(json_data, '12345')

    assert(playlist_data['id'] == 'v5qckFJvNJg')
    assert(len(playlist_data['entries']) == 45)

# Generated at 2022-06-26 13:12:02.643438
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():
    obj = TudouPlaylistIE()



# Generated at 2022-06-26 13:12:03.809162
# Unit test for constructor of class TudouAlbumIE
def test_TudouAlbumIE():
    inst = TudouAlbumIE()
    assert inst

# Generated at 2022-06-26 13:12:14.912694
# Unit test for constructor of class TudouPlaylistIE
def test_TudouPlaylistIE():

    #test __init__ function
    assert TudouPlaylistIE.__init__(TudouPlaylistIE) == None 

    #test _VALID_URL
    assert TudouPlaylistIE._VALID_URL == r'https?://(?:www\.)?tudou\.com/listplay/(?P<id>[\w-]{11})\.html'


    #test _TESTS
    assert TudouPlaylistIE._TESTS == [{
        'url': 'http://www.tudou.com/listplay/zzdE77v6Mmo.html',
        'info_dict': {
            'id': 'zzdE77v6Mmo',
        },
        'playlist_mincount': 209,
    }]

    #test _real_extract
    assert TudouPlaylist