

# Generated at 2022-06-23 14:07:08.266290
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 110) == 10
    assert pct_to_int(50, 110) == 55
    assert pct_to_int('10%', 110) == 11
    assert pct_to_int(110, 110) == 110
    assert pct_to_int('110%', 110) == 110
    assert pct_to_int(111, 110) == 110
    assert pct_to_int('111%', 110) == 110

# Generated at 2022-06-23 14:07:16.490786
# Unit test for function pct_to_int
def test_pct_to_int():
    values_table = {
        "10": 10,
        "10%": 1,
        "50%": 5,
        "56%": 5,
        "0%": 1,
        "1%": 1,
        "1.5%": 1,
        "99%": 1,
    }
    for value, expected_result in values_table.items():
        assert(pct_to_int(value, 10) == expected_result)
        assert(pct_to_int(value, 500) == expected_result * 50)



# Generated at 2022-06-23 14:07:19.338546
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 2, 2, 3, 2, 1, 2, 3, 2, 1]
    new_list = deduplicate_list(original_list)
    assert [1, 2, 3] == new_list

# Generated at 2022-06-23 14:07:24.029737
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test1 = 'test1'
        test2 = 'test2'
        test3 = 'test3'
    result = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    result2 = {'test1': 'test1', 'test3': 'test3'}
    obj = Test()
    assert object_to_dict(obj) == result
    assert object_to_dict(obj, exclude=['test2']) == result2


# Generated at 2022-06-23 14:07:28.609751
# Unit test for function object_to_dict
def test_object_to_dict():
    import json
    class TestObj(object):
        def __init__(self):
            self.test = 'foo'
            self.bar = 42

    print (json.dumps(object_to_dict(TestObj()), indent=4, sort_keys=True))



# Generated at 2022-06-23 14:07:36.121155
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass:
        def __init__(self, attr1, attr2, attr3):
            self.attr1 = attr1
            self.attr2 = attr2
            self.attr3 = attr3
    sample_obj = SampleClass('1', '2', '3')
    sample_dict = object_to_dict(sample_obj, ['attr2'])
    assert sample_dict['attr1'] == '1'
    assert "attr2" not in sample_dict
    assert sample_dict['attr3'] == '3'

# Generated at 2022-06-23 14:07:44.193843
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:  # pylint: disable=too-few-public-methods
        """
        Some class for testing
        """
        def __init__(self):
            self.a = "a"
            self.b = "b"
            self.c = "c"

    test_obj = test_class()
    result_dict = object_to_dict(test_obj)
    assert result_dict['a'] == "a"
    assert result_dict['b'] == "b"
    assert result_dict['c'] == "c"
    assert len(result_dict) == 3

    result_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in result_dict
    assert result_dict['b'] == "b"

# Generated at 2022-06-23 14:07:53.981558
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', '100') == 10
    assert pct_to_int('75%', '200') == 150
    assert pct_to_int('50%', '100') == 50
    assert pct_to_int('20%', '100') == 20
    assert pct_to_int('0%', '100') == 1
    assert pct_to_int('120%', '100') == 120
    assert pct_to_int('120%', '10') == 12
    assert pct_to_int('120%', '1') == 1
    assert pct_to_int('120%', '0') == 1
    assert pct_to_int('120%', None) == 1
    assert pct_to_int('1.2%', '100') == 1


# Generated at 2022-06-23 14:07:59.913326
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_data = [
        ([1,1,2,2,2,3,3,1], [1,2,3,1]),
        ([1,2,3,1], [1,2,3,1]),
        ([1,2,3], [1,2,3]),
        ([1], [1]),
        ([], []),
    ]

    for data_set in test_data:
        assert deduplicate_list(data_set[0]) == data_set[1]

# Generated at 2022-06-23 14:08:03.713874
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("100%", 100, min_value=5) == 100
    assert pct_to_int("1%", 100, min_value=5) == 5
    assert pct_to_int(50, 100) == 50
    assert pct_to_int("invalid", 100) == 0
    assert pct_to_int("invalid%", 100) == 0
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("101%", 100) == 100

# Generated at 2022-06-23 14:08:07.997514
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10', 20) == 2
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('120%', 100) == 100
    assert pct_to_int('120%', 100, min_value=2) == 2
    assert pct_to_int(10, 20) == 10

# Generated at 2022-06-23 14:08:14.631661
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test = "test"
            self.exclude = "exclude"

    test = TestClass()
    test_dict = object_to_dict(test, exclude=['exclude'])

    assert 'exclude' not in test_dict
    assert test_dict['test'] == "test"

# Generated at 2022-06-23 14:08:20.227483
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 5, 1, 2, 4]) == [1, 2, 5, 4]
    assert deduplicate_list([1, 2, 5, 2, 1, 2, 4]) == [1, 2, 5, 4]
    # Note: This next one may appear to be broken, but it is correct.
    # It has not been deduplicated because the second 1 is not seen before the first 1.
    assert deduplicate_list([1, 1, 2, 5, 1, 2, 4]) == [1, 1, 2, 5, 4]

# Generated at 2022-06-23 14:08:23.257856
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,2,2,1,1,4]) == [1,2,3,4]

# Generated at 2022-06-23 14:08:31.804002
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 10) == 1
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int("50%", 10, min_value=2) == 5
    assert pct_to_int("50%", 10, min_value=6) == 6
    assert pct_to_int("200%", 10) == 10
    assert pct_to_int("1%", 10, min_value=2) == 2
    assert pct_to_int(100, 10) == 100
    assert pct_to_int("100", 10) == 100
    assert pct_to_int("100", 10, min_value=6) == 100

# Generated at 2022-06-23 14:08:33.962193
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10', 10) == 10
    assert pct_to_int('-1', 10) == 1



# Generated at 2022-06-23 14:08:43.125851
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_to_int(20, 100) == 20
    pct_to_int(21, 100) == 21
    pct_to_int(22, 100) == 22
    pct_to_int(1, 100) == 1
    pct_to_int('10%', 100) == 10
    pct_to_int('11%', 100) == 11
    pct_to_int('12%', 100) == 12
    pct_to_int('2%', 100) == 2
    pct_to_int('1%', 100) == 1
    pct_to_int('0%', 100) == 1
    pct_to_int('1.1%', 100) == 1


# Generated at 2022-06-23 14:08:51.326413
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['1', '1', '1', '2', '2', '3', '3', '3', '3']) == ['1', '2', '3']
    assert deduplicate_list(['2', '2', '3', '3', '3', '3', '1', '1', '1']) == ['2', '3', '1']
    assert deduplicate_list(['1', '1', '1', '2', '2', '3', '3', '3', '3']) != ['1', '2', '3', '4']



# Generated at 2022-06-23 14:08:54.725812
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:09:01.886335
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('75%', 10) == 7
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int('0.4%', 10) == 1
    assert pct_to_int('0.5%', 10) == 1
    assert pct_to_int('0.6%', 10) == 1
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int('23%', 10) == 2
    assert pct_to_int('24%', 10) == 2
    assert pct_to

# Generated at 2022-06-23 14:09:10.212075
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','a','b','b']) == ['a','b']
    assert deduplicate_list(['a','b','b','b']) == ['a','b']
    assert deduplicate_list([1,2,2,2,2,4]) == [1,2,4]
    assert deduplicate_list([1,2,2,2,2,4,4,4,4]) == [1,2,4]
    assert deduplicate_list(['a',1,2,3,4]) == ['a',1,2,3,4]

# Generated at 2022-06-23 14:09:19.006192
# Unit test for function object_to_dict
def test_object_to_dict():
    # pylint: disable=missing-docstring,too-few-public-methods
    class SampleObject(object):
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    sample_obj = SampleObject(foo="foo", bar="bar")
    sample_dict = object_to_dict(sample_obj)

    assert sample_dict['foo'] == "foo"
    assert sample_dict['bar'] == "bar"

    sample_dict = object_to_dict(sample_obj, exclude=['bar'])

    assert 'bar' not in sample_dict

# Generated at 2022-06-23 14:09:23.969506
# Unit test for function deduplicate_list
def test_deduplicate_list():
    initial_list = ["Tom", "Harry", "Janet", "Tom", "Mark", "Mark", "Harry"]
    expected_list = ["Tom", "Harry", "Janet", "Mark"]
    deduplicated_list = deduplicate_list(initial_list)
    assert deduplicated_list == expected_list

# Generated at 2022-06-23 14:09:29.895239
# Unit test for function object_to_dict
def test_object_to_dict():
    class fake_object(object):
        a = 1
        b = 2
        c = 3

    assert object_to_dict(fake_object()) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(fake_object(), exclude=['a']) == {'b': 2, 'c': 3}
    assert object_to_dict(fake_object(), exclude=['a', 'b']) == {'c': 3}

# Generated at 2022-06-23 14:09:34.684764
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'b', 'a', 'd', 'c', 'e', 'f']
    expected_output = ['a', 'b', 'c', 'd', 'e', 'f']

    output = deduplicate_list(original_list)

    assert(expected_output == output)

# Generated at 2022-06-23 14:09:40.888540
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('obj', (object,), {'a': 1, 'b': 2})
    assert object_to_dict(obj) == {'a': 1, 'b': 2}

    obj = type('obj', (object,), {'a': 1, 'b': 2, '_c': 3})
    assert object_to_dict(obj) == {'a': 1, 'b': 2}

    obj = type('obj', (object,), {'a': 1, 'b': 2, '_c': 3})
    assert object_to_dict(obj, ['a', 'b']) == {'a': 1, 'b': 2}



# Generated at 2022-06-23 14:09:45.799835
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        x = 1
        y = 2

    a = A()
    assert object_to_dict(a) == {'x': 1, 'y': 2}
    assert object_to_dict(a, exclude=['x']) == {'y': 2}


# Generated at 2022-06-23 14:09:49.274432
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """Test deduplicate_list function"""
    assert ['a', 'b', 'cd'] == deduplicate_list(['a', 'b', 'cd', 'cd', 'a', 'b', 'cd'])

# Generated at 2022-06-23 14:09:58.052692
# Unit test for function object_to_dict
def test_object_to_dict():
    import json
    import re

    class A(object):
        name = "Ansible"
        age = 2
        def function(self):
            return "I'm a function"

    class B(A):
        def function(self):
            return "I'm function from B"

        def function2(self):
            return "I'm function 2 from B"

    # When
    a = A()
    b = B()

    # Then
    assert len(object_to_dict(a)) == 3
    assert json.dumps(object_to_dict(a), indent=4) == json.dumps({"name": "Ansible", "age": 2, "function": "I'm a function"}, indent=4)
    assert object_to_dict(a)['function']() == "I'm a function"

# Generated at 2022-06-23 14:10:05.831022
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10", 100) == 10
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10.5%", 100) == 11
    assert pct_to_int("10%", 100, min_value=0) == 10
    assert pct_to_int("10%", 100, min_value=5) == 10
    assert pct_to_int("10%", 100, min_value=11) == 11
    assert pct_to_int("10", 100, min_value=11) == 10

# Generated at 2022-06-23 14:10:12.637290
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert ['one', 'two', 'three'] == deduplicate_list(['one', 'two', 'three'])
    assert ['one', 'two', 'three'] == deduplicate_list(['one', 'two', 'three', 'two', 'three'])
    assert ['one', 'two', 'three', 'four'] == deduplicate_list(['one', 'four', 'one', 'two', 'three', 'four'])



# Generated at 2022-06-23 14:10:19.846297
# Unit test for function pct_to_int
def test_pct_to_int():

    # test a few pct_to_int calculations
    assert(pct_to_int(1, 100) == 1)
    assert(pct_to_int('1%', 100) == 1)
    assert(pct_to_int('1%', 10) == 1)
    assert(pct_to_int(10, 100) == 10)
    assert(pct_to_int('10%', 100) == 10)
    assert(pct_to_int('10%', 10) == 1)
    assert(pct_to_int(20, 100) == 20)
    assert(pct_to_int('20%', 100) == 20)
    assert(pct_to_int('20%', 10) == 2)
    assert(pct_to_int(25, 100) == 25)


# Generated at 2022-06-23 14:10:25.545745
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = self.c
            self.e = 'not in dict'

    a = A()
    print(object_to_dict(a))


# Generated at 2022-06-23 14:10:33.490723
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests for the function object_to_dict.
    """
    class example_obj:
        def __init__(self):
            self.foo = 'bar'
            self.dict = {'a': 'b'}
            self._pvt = 'baz'
            self._another_pvt = 'fizz'

    example_object = example_obj()
    result = object_to_dict(example_object)
    assert isinstance(result, dict)
    assert sorted(result.keys()) == ['dict', 'foo']
    assert result['foo'] == 'bar'

    result2 = object_to_dict(example_object, ['_another_pvt'])
    assert isinstance(result2, dict)
    assert sorted(result2.keys()) == ['_pvt', 'dict', 'foo']
   

# Generated at 2022-06-23 14:10:43.721877
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Ensures pct_to_int function in utils returns the expected integer.
    """
    assert pct_to_int(80, 4) == 3, '80% of 4 is 3'
    assert pct_to_int(20, 5) == 1, '20% of 5 is 1'
    assert pct_to_int(100, 1) == 1, '100% of 1 is 1'
    assert pct_to_int(100, 10) == 10, '100% of 10 is 10'
    assert pct_to_int(50, 6) == 3, '50% of 6 is 3'
    assert pct_to_int(12.5, 8) == 1, '12.5% of 8 is 1'

# Generated at 2022-06-23 14:10:49.277934
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int('50%', 8)
    assert value == 4
    value = pct_to_int('75%', 16)
    assert value == 12
    value = pct_to_int(50, 8)
    assert value == 50
    value = pct_to_int(75, 16)
    assert value == 75

# Generated at 2022-06-23 14:10:56.376208
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('75%', 10) == 7
    assert pct_to_int('30%', 10) == 3
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('10', 10) == 10
    assert pct_to_int(10, 10) == 10


# Generated at 2022-06-23 14:11:04.928571
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObjOne():
        name = 'test'
        value = True
        value_two = False
    test_obj_one = TestObjOne()

    # Should ignore _, get all keys
    assert object_to_dict(test_obj_one) == dict(name='test', value=True, value_two=False)

    # Should get all keys except value_two
    assert object_to_dict(test_obj_one, exclude=['value_two']) == dict(name='test', value=True)

    # Should get all keys except value_two and name
    assert object_to_dict(test_obj_one, exclude=['value_two', 'name']) == dict(value=True)

    # Should return empty dict since all keys are excluded

# Generated at 2022-06-23 14:11:11.555232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['hello', 'hello', 'world', 'world']
    assert deduplicate_list(list1) == ['hello', 'world']
    list2 = ['hello', 'world', 'world', 'hello']
    assert deduplicate_list(list2) == ['hello', 'world']
    list3 = ['hello', 'world']
    assert deduplicate_list(list3) == ['hello', 'world']



# Generated at 2022-06-23 14:11:20.594785
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test that input value which is not a string returns None
    assert pct_to_int(10, 50) == 10

    # Test the input value which is not an integer string
    assert pct_to_int('10a%', 50) is None

    # Test the input value is < 0 returns None
    assert pct_to_int('-10%', 50) is None

    # Test the input value with % returns integer
    assert pct_to_int('50%', 50) == 25

    # Test the input value with % returns integer
    assert pct_to_int('100%', 50) == 50

    # Test the input value with % returns the minimum value
    assert pct_to_int('50%', 1) == 1



# Generated at 2022-06-23 14:11:25.508909
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25%', 10) == 3
    assert pct_to_int('25%', 10, min_value=0) == 2
    assert pct_to_int(25, 10) == 3
    assert pct_to_int('50', 10) == 5
    assert pct_to_int('100%', 100) == 100

# Generated at 2022-06-23 14:11:28.286364
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,1,2,3,4,4,4,4,4]
    expected_list = [1,2,3,4]
    assert deduplicate_list(original_list)==expected_list



# Generated at 2022-06-23 14:11:35.691957
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """Unit test for function deduplicate_list"""
    assert deduplicate_list([]) == [], "List should be empty"
    assert deduplicate_list(['a', 'b', 'c', 'd', 'e']) == ['a', 'b', 'c', 'd', 'e'], "List should be the same"
    assert deduplicate_list(['a', "a", 'a', 'b', 'd', 'e', 'a']) == ['a', 'b', 'd', 'e']

# Generated at 2022-06-23 14:11:37.204093
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, 4) == 4
    assert pct_to_int('50%', 100) == 50


# Generated at 2022-06-23 14:11:40.067070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = [1, 2, 1, 2, 3, 4, 1, 2, 3]
    output_list = [1, 2, 3, 4]

    assert deduplicate_list(input_list) == output_list

# Generated at 2022-06-23 14:11:46.854041
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['10.144.170.215', '10.144.170.215']) == ['10.144.170.215']
    assert deduplicate_list([10, 1, 10, '10', 1, 10, 10]) == [10, 1, '10']
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:11:53.807513
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["a","b","c","a","d","e","c","b","f","f","a","f","d","c","b","e","d","c","f","d"]
    deduped_list = ["a","b","c","d","e","f"]
    assert deduplicate_list(original_list) == deduped_list


# Generated at 2022-06-23 14:12:02.573048
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """Unit test for function deduplicate_list"""
    assert deduplicate_list(['A', 'B', 'A', 'C']) == ['A', 'B', 'C']
    assert deduplicate_list(['A', 'B', 'A', 'C', 'A']) == ['A', 'B', 'C']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['A', 'A', 'A', 'A']) == ['A']
    assert deduplicate_list(['A']) == ['A']
    assert deduplicate_list(['A', 'B', 'C', 'D']) == ['A', 'B', 'C', 'D']


# Generated at 2022-06-23 14:12:12.912450
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,2,2,3,4,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1]) == [1,2,3,4,5,6]
    assert deduplicate_list([1,2,1,1,1,1,1]) == [1,2]

    assert deduplicate_list(['a','a','b','b','c','a','b']) == ['a','b','c']
    assert deduplicate_list(['a','a','b','b','c','a','b','c']) == ['a','b','c']

    assert deduplicate_list(['a']) == ['a']

# Generated at 2022-06-23 14:12:18.125983
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        a = 'a'
        b = 'b'
        c = 'c'

    obj = Obj()
    obj.d = 'd'
    obj.e = 'e'
    obj.f = 'f'

    assert object_to_dict(obj) == {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': 'd',
        'e': 'e',
        'f': 'f',
    }

# Generated at 2022-06-23 14:12:28.671497
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int(65, 100) == 65
    assert pct_to_int('50%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int(65, 100, min_value=5) == 65
    assert pct_to_int(0, 100, min_value=5) == 5
    assert pct_to_int(None, 100) == 1

# Generated at 2022-06-23 14:12:35.851170
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 2, 1, 1, 2, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([]) == []
    assert deduplicate_list({}) == []
    assert deduplicate_list(None) is None
    assert deduplicate_list("abc") is None


# Generated at 2022-06-23 14:12:39.266316
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l = ['a', 'a', 'b', 'a', 'b', 'c']
    result = deduplicate_list(l)
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-23 14:12:43.396441
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_with_duplicates = [ 1, 2, 4, 8, 16, 32, 4, 8, 16, 32, 64, 32, 64 ]
    deduplicated_list = deduplicate_list(list_with_duplicates)
    assert deduplicated_list == [ 1, 2, 4, 8, 16, 32, 64 ]


# Generated at 2022-06-23 14:12:50.225612
# Unit test for function pct_to_int
def test_pct_to_int():
    effective_length = 100
    assert pct_to_int("60%", effective_length) == 60
    assert pct_to_int("100%", effective_length) == 100
    assert pct_to_int("0%", effective_length) == 1
    assert pct_to_int("150%", effective_length) == 150
    assert pct_to_int("foo", effective_length) == 1
    assert pct_to_int("10.1%", effective_length) == 11


# Generated at 2022-06-23 14:12:54.481218
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 6) == 3
    assert pct_to_int(50.0, 6) == 3
    assert pct_to_int('50.0', 6) == 3
    assert pct_to_int('50%', 6) == 3

# Generated at 2022-06-23 14:12:59.502048
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(40, 100) == 40
    assert pct_to_int(40, 1) == 1
    assert pct_to_int("40%", 100) == 40
    assert pct_to_int("40%", 1) == 1
    assert pct_to_int("40.5%", 1) == 1
    assert pct_to_int("40.5%", 100) == 41


# Generated at 2022-06-23 14:13:06.108247
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import unittest

    original_list = [1, 2, 3, 2, 5, 2]

    result = deduplicate_list(original_list)
    unittest.TestCase().assertListEqual(result, [1, 2, 3, 5])

    original_list = ['red', 'green', 'blue', 'red', 'blue']
    result = deduplicate_list(original_list)
    unittest.TestCase().assertListEqual(result, ['red', 'green', 'blue'])



# Generated at 2022-06-23 14:13:11.689624
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100) == 20
    assert pct_to_int(20.0, 100) == 20
    assert pct_to_int('20', 100) == 20
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=10) == 20
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0.1%', 100, min_value=10) == 10
    assert pct_to_int('0.0%', 100, min_value=10) == 10

# Generated at 2022-06-23 14:13:18.084766
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.name = 'test'
            self.age = 1
            self.height = 185

    o = TestObject()

    assert 'name' in object_to_dict(o)
    assert 'age' in object_to_dict(o)
    assert 'height' in object_to_dict(o)
    assert 'name' in object_to_dict(o, ['age', 'height'])
    assert 'age' not in object_to_dict(o, ['age', 'height'])
    assert 'height' not in object_to_dict(o, ['age', 'height'])



# Generated at 2022-06-23 14:13:22.736174
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = ['item1', 'item2', 'item3', 'item2', 'item3', 'item3']
    result_list = deduplicate_list(input_list)
    assert result_list == ['item1', 'item2', 'item3']

# Generated at 2022-06-23 14:13:32.315432
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 3, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2]) == [1, 3, 2]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 1, 2, 3, 1, 2]) == [1, 2, 3, 4]
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:13:40.437623
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100, min_value=10) == 10
    assert pct_to_int(50, 100, min_value=10) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('5%', 100, min_value=10) == 5
    assert pct_to_int('5%', 100, min_value=10) == 5
    assert pct_to_int('1%', 100, min_value=10) == 1
    assert pct_to_int('0%', 100, min_value=10) == 10

# Generated at 2022-06-23 14:13:45.630207
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        a = 1
        b = 2
        c = 3
    test_obj = TestObject()
    assert object_to_dict(test_obj) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(test_obj, ['a']) == {'b': 2, 'c': 3}

# Generated at 2022-06-23 14:13:53.651701
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        def __init__(self):
            self.key1 = "value1"
            self.key2 = "value2"
            self.key3 = "value3"

    obj = Object()
    assert (object_to_dict(obj) == dict(key1="value1", key2="value2", key3="value3"))
    assert (object_to_dict(obj, exclude=["key3"]) == dict(key1="value1", key2="value2"))



# Generated at 2022-06-23 14:13:56.979208
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("20%", 100) == 20
    assert pct_to_int("20%", 100, 10) == 20
    assert pct_to_int("200%", 100, 10) == 100
    assert pct_to_int("0%", 100, 10) == 10

# Generated at 2022-06-23 14:14:02.154957
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        attr1 = "A"
        attr2 = "B"
        attr3 = None
        attr4 = 0
        def __init__(self):
            pass

    assert object_to_dict(Obj()) == {'attr1': 'A', 'attr2': 'B', 'attr3': None, 'attr4': 0}



# Generated at 2022-06-23 14:14:08.160075
# Unit test for function pct_to_int
def test_pct_to_int():
    # Given, When, Then
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20', 100) == 20
    assert pct_to_int(20, 100) == 20
    assert pct_to_int('%', 100) == 1



# Generated at 2022-06-23 14:14:10.312572
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 2]) == [1, 2, 3]


# Generated at 2022-06-23 14:14:19.174431
# Unit test for function pct_to_int

# Generated at 2022-06-23 14:14:23.733903
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('50%', 1) == 1

    assert pct_to_int(5, 6) == 5


# Generated at 2022-06-23 14:14:27.751234
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test1 = 1
            self._test2 = 1
    answer = {'test1': 1}
    assert object_to_dict(TestObject()) == answer
    assert object_to_dict(TestObject(), ['test1']) == {}

# Generated at 2022-06-23 14:14:38.197559
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10.0, 100) == 10
    assert pct_to_int('10.0', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to

# Generated at 2022-06-23 14:14:45.894635
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('0%', 1000) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('100%', 101) == 101
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 99) == 99
    assert pct_to_int(100, 99) == 100

# Generated at 2022-06-23 14:14:55.768671
# Unit test for function pct_to_int
def test_pct_to_int():
    given_nums = [(25, 100, 1), (25, 100, 5), (33, 100, 5), (33, 12, 5), (0, 50, 5)]

    expected_nums = [25, 25, 33, 2, 0]

    assert pct_to_int(*given_nums[0]) == expected_nums[0]
    assert pct_to_int(*given_nums[1]) == expected_nums[1]
    assert pct_to_int(*given_nums[2]) == expected_nums[2]
    assert pct_to_int(*given_nums[3]) == expected_nums[3]
    assert pct_to_int(*given_nums[4]) == expected_nums[4]

# Generated at 2022-06-23 14:15:01.454092
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 5) == 1
    assert pct_to_int('20%', 12) == 2
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('20%', 11) == 2

    assert pct_to_int(1, 5) == 1
    assert pct_to_int(2, 6) == 2
    assert pct_to_int(1, 6) == 1
    assert pct_to_int(2, 7) == 2



# Generated at 2022-06-23 14:15:10.256557
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj_class():
        """
        Class used for testing object_to_dict
        """
        def __init__(self):
            self.b = 2
            self.a = self.b

    obj = obj_class()
    result = object_to_dict(obj)

    assert isinstance(result, dict)
    assert 'b' in result
    assert 'a' in result
    assert result['b'] == 2
    assert result['a'] == 2

    result = object_to_dict(obj, exclude=['a'])
    assert isinstance(result, dict)
    assert 'b' in result
    assert 'a' not in result
    assert result['b'] == 2

# Generated at 2022-06-23 14:15:19.038731
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test using pct
    assert pct_to_int('10%', 100) == 10

    # Test using no pct
    assert pct_to_int(10, 100) == 10

    # Test using a float
    assert pct_to_int('10.5%', 100) == 11

    # Test using a float that doesn't round up but is greater than min_value
    assert pct_to_int('10.2%', 100) == 10

    # Test using a float that doesn't round up
    assert pct_to_int('10.2%', 100, min_value=2) == 2

# Generated at 2022-06-23 14:15:27.471576
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test 1, rounding up
    assert pct_to_int("20%", 100) == 20

    # Test 2, rounding down
    assert pct_to_int("20%", 25) == 5

    # Test 3, no value to return
    assert pct_to_int("20%", 2) == 1

    # Test 4, integer passed
    assert pct_to_int(10, 100) == 10

    # Test 5, with a space
    assert pct_to_int(" 20%", 100) == 20

    # Test 6, shouldn't be able to use a negative
    assert pct_to_int("-20%", 100) == 1


# Generated at 2022-06-23 14:15:33.666863
# Unit test for function object_to_dict
def test_object_to_dict():
    class Interface(object):
        def __init__(self, name, descr):
            self.name = name
            self.descr = descr
            self.enabled = True

    interface = Interface('ge-0/0/0', 'Some description')
    assert object_to_dict(interface, ['enabled']) == {'name': 'ge-0/0/0', 'descr': 'Some description'}

# Generated at 2022-06-23 14:15:36.926706
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('1.5%', 100) == 2
    assert pct_to_int('-1.5%', 100) == 1
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(5.5, 100) == 6

# Generated at 2022-06-23 14:15:46.794635
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('15%', 100) == 15
    assert pct_to_int('15%', 100, min_value=10) == 10
    assert pct_to_int('15%', 50) == 8
    assert pct_to_int('20', 100) == 20
    assert pct_to_int('20', 100, min_value=10) == 20
    assert pct_to_int('20', 50) == 20
    assert pct_to_int('0', 100) == 1
    assert pct_to_int('0', 50) == 1


# Generated at 2022-06-23 14:15:49.263797
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "a", "c", "a", "c", "d"]) == ["a", "b", "c", "d"]



# Generated at 2022-06-23 14:15:52.132070
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100, 1) == 50

# Generated at 2022-06-23 14:15:55.272780
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'c', 'd', 'b']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-23 14:16:03.777514
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self, key1, key2):
            self.key1 = key1
            self.key2 = key2
            self.key3 = self.key1 + self.key2

    obj = Foo("val1", "val2")
    desired_dict = {'key1': 'val1', 'key2': 'val2', 'key3': 'val1val2'}
    assert desired_dict == object_to_dict(obj)

    desired_dict = {'key1': 'val1', 'key2': 'val2'}
    assert desired_dict == object_to_dict(obj, exclude=['key3'])


# Generated at 2022-06-23 14:16:10.551782
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test integer value
    assert pct_to_int(10, 100) == 10

    # Test that percent value is converted to integer
    assert pct_to_int('10%', 100) == 10

    # Test that percent value with min_value is converted to integer
    assert pct_to_int('10%', 100, min_value=2) == 10

    # Test that percent value with min_value is converted to integer
    assert pct_to_int('1%', 100, min_value=2) == 2



# Generated at 2022-06-23 14:16:15.778568
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass(object):
        def __init__(self, **kwargs):
            self.key1 = kwargs.get('key1', 'default1')
            self.key2 = kwargs.get('key2', 'default2')

    sample = SampleClass()
    sample_dict = object_to_dict(sample, exclude=['key2'])
    assert sample_dict['key1'] == 'default1'
    assert 'key2' not in sample_dict.keys()


# Generated at 2022-06-23 14:16:26.863600
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100) == 25
    assert pct_to_int(25, 100, min_value=0) == 25
    assert pct_to_int(25, 100, min_value=1) == 25
    assert pct_to_int(25, 100, min_value=2) == 25
    assert pct_to_int(25, 100, min_value=3) == 25
    assert pct_to_int(25, 100, min_value=100) == 25

    assert pct_to_int(26, 100) == 26
    assert pct_to_int(26, 100, min_value=0) == 26
    assert pct_to_int(26, 100, min_value=1) == 26

# Generated at 2022-06-23 14:16:30.841823
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("5%", 100) == 5
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("100%", 100) == 100

# Generated at 2022-06-23 14:16:35.717117
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        """
        Test class
        """
        def __init__(self):
            self.test1 = "hello"
            self.test2 = "world"

    test_instance = test_class()
    result = object_to_dict(test_instance, ["test2"])

    return result["test1"] == test_instance.test1


# Generated at 2022-06-23 14:16:46.218198
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 2, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2]) == [1, 2, 1, 2]
    assert deduplicate_list([1, 1, 1, 1]) == [1]
    assert deduplicate_list([2, 2, 1, 1]) == [2, 1]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-23 14:16:50.463706
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:16:54.396125
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        pass

    obj = TestClass()
    obj.test_prop1 = 'test1'
    obj.test_prop2 = 'test2'

    assert object_to_dict(obj, ['test_prop2']) == {'test_prop1': 'test1'}



# Generated at 2022-06-23 14:16:58.902881
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 3, 1, 1, 2, 3, 4]
    expected_list1 = [1, 2, 3, 4]
    assert deduplicate_list(list1) == expected_list1


# Generated at 2022-06-23 14:17:02.078093
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 5, 2, 3, 3, 6, 1, 3, 2]) == [1, 2, 3, 5, 6]



# Generated at 2022-06-23 14:17:11.583950
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,2,2,2,2,1]) == [1,2]
    assert deduplicate_list([1,2,2,2,2,2,2,1,1,1]) == [1,2]
    assert deduplicate_list([1,2,3,4,5,6]) == [1,2,3,4,5,6]
    assert deduplicate_list([1,2,2,2,2,2,2,1,1,1,3,3,3,3,3,3,3,3,3,3,3,3,3]) == [1,2,3]
    assert deduplicate_list(['a','b','c','d']) == ['a','b','c','d']
   