

# Generated at 2022-06-23 14:07:02.246970
# Unit test for function object_to_dict
def test_object_to_dict():
    class Temp(object):
        def __init__(self):
            self.field1 = 'abc'
            self.field2 = 123
            self.excluded_field = 'test'

    temp = Temp()
    temp_dict = object_to_dict(temp, ['excluded_field'])
    assert 'field1' in temp_dict
    assert 'field2' in temp_dict
    assert not 'excluded_field' in temp_dict



# Generated at 2022-06-23 14:07:07.753068
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 2 == pct_to_int(10, 20, min_value=2)
    assert 2 == pct_to_int(20, 20, min_value=2)
    assert 3 == pct_to_int(25, 20, min_value=2)
    assert 2 == pct_to_int('10%', 20, min_value=2)
    assert 2 == pct_to_int('20%', 20, min_value=2)
    assert 3 == pct_to_int('25%', 20, min_value=2)

# Generated at 2022-06-23 14:07:18.501459
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0.55%', 100) == 1
    assert pct_to_int('0.56%', 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(101, 100) == 101
    assert pct_to_int(0, 100) == 1

# Generated at 2022-06-23 14:07:30.388091
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 10, min_value=1) == 5
    assert pct_to_int('50%', 10, min_value=2) == 5
    assert pct_to_int('25%', 10) == 2
    assert pct_to_int('25%', 10, min_value=1) == 2
    assert pct_to_int('25%', 10, min_value=2) == 3
    assert pct_to_int(50, 10) == 50
    assert pct_to_int(50, 10, min_value=1) == 50

# Generated at 2022-06-23 14:07:36.257262
# Unit test for function object_to_dict
def test_object_to_dict():

    class Foo:
        def __init__(self):
            self.x = "x"
            self.y = "y"
            self.z = "z"
            self.a = "a"
            self.b = "b"
    f = Foo()
    assert object_to_dict(f) == {'a': 'a', 'b': 'b', 'x': 'x', 'y': 'y', 'z': 'z'}
    assert object_to_dict(f, exclude=['x', 'z']) == {'a': 'a', 'b': 'b', 'y': 'y'}

# Generated at 2022-06-23 14:07:40.313627
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Test deduplicate_list function
    """
    assert deduplicate_list(['a', 'b', 'c', 'd', 'a', 'b', 'c', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-23 14:07:45.342617
# Unit test for function object_to_dict
def test_object_to_dict():
    class Example(object):
        def __init__(self):
            self.foo = "foo"
            self.bar = "bar"
            self.baz = "baz"

    result = object_to_dict(Example(), ["bar"])
    assert result == {"foo": "foo", "baz": "baz"}

# Generated at 2022-06-23 14:07:50.810407
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.foo = "foo"
            self.bar = "bar"
    tc = TestClass()
    tc_dict = object_to_dict(tc)
    assert 'foo' in tc_dict
    assert tc_dict['foo'] == 'foo'
    assert 'bar' in tc_dict
    assert tc_dict['bar'] == 'bar'
    assert '__init__' not in tc_dict


# Generated at 2022-06-23 14:07:58.202412
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 20
    percentage_of_num_items = 10
    percentage_value = str(percentage_of_num_items) + '%'
    assert pct_to_int(percentage_value, num_items) == 2
    assert pct_to_int('0%', num_items) == 1
    assert pct_to_int('0%', num_items, 5) == 5
    assert pct_to_int('100%', num_items) == 20
    assert pct_to_int('150%', num_items) == 30



# Generated at 2022-06-23 14:08:01.242303
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("50", 100) == 50

# Generated at 2022-06-23 14:08:05.524127
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['vlan300', 'vlan300', 'vlan200', 'vlan100', 'vlan100', 'vlan200', 'vlan400']
    deduplicated_list = ['vlan300', 'vlan200', 'vlan100', 'vlan400']
    assert deduplicate_list(test_list) == deduplicated_list



# Generated at 2022-06-23 14:08:07.112898
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = [1, 2, 3, 2, 1, 3, 3]
    assert deduplicate_list(input_list) == [1, 2, 3]

# Generated at 2022-06-23 14:08:12.043163
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Test integer result from pct_to_int.
    '''
    assert pct_to_int("3%", 100) == 3
    assert pct_to_int("3", 100) == 3


# Generated at 2022-06-23 14:08:14.383466
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 2 == pct_to_int('2%', 100)
    assert 2 == pct_to_int(2, 100)



# Generated at 2022-06-23 14:08:17.341641
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicated_list = deduplicate_list(['a', 'b', 'c', 'a', 'd', 'b', 'd'])
    assert deduplicated_list == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 14:08:22.263385
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['A', 'A', 'C', 'B', 'D', 'A', 'E', 'C', 'B']
    expected_list = ['A', 'C', 'B', 'D', 'E']
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-23 14:08:32.245042
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(99, 100) == 99
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int(1, 10000) == 1
    assert pct_to_int('1%', 10000) == 1
    assert pct_to_int('1', 10000) == 1
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(10000, 10000) == 10000
    assert pct_to_int('10000', 10000) == 10000
    assert pct_to_int('10000%', 10000) == 10000

# Generated at 2022-06-23 14:08:35.928348
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 4, 4, 5, 6, 7, 1, 5]
    deduplicated_list = [1, 2, 4, 5, 6, 7]
    assert deduplicate_list(original_list) == deduplicated_list



# Generated at 2022-06-23 14:08:40.797354
# Unit test for function object_to_dict
def test_object_to_dict():
    class CustomClass(object):
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
    custom_class = CustomClass()
    obj_dict = object_to_dict(custom_class)
    assert obj_dict['test1'] == 'test1', "Failed converting an object's properties to a dict"


# Generated at 2022-06-23 14:08:50.581044
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for function deduplicate_list
    """
    # test for empty list
    assert deduplicate_list([]) == []
    # test for simple integer list
    assert deduplicate_list([1, 2, 3, 2, 3, 4, 5, 2, 3, 3, 1, 2, 1, 1]) == [1, 2, 3, 4, 5]
    # test for simple string list
    assert deduplicate_list(["a", "b", "c", "b", "c", "d", "e", "b", "c", "c", "a", "b", "a", "a"]) == ["a", "b", "c", "d", "e"]


# Generated at 2022-06-23 14:08:56.961188
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Original list
    original_list = [1, 2, 3, 1, 5, 2]
    # Deduplicated list should be [1, 2, 3, 5]
    deduplicated_list = deduplicate_list(original_list)

    assert original_list != deduplicated_list
    assert len(original_list) > len(deduplicated_list)
    assert deduplicated_list == [1, 2, 3, 5]

# Generated at 2022-06-23 14:09:04.768769
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 1000) == 0
    assert pct_to_int(100, 1000) == 1000
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('1%', 1000) == 10
    assert pct_to_int('0%', 1000) == 0
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('5%', 10, min_value=2) == 2
    assert pct_to_int('10', 1000) == 10
    assert pct_to_int(500, 1000) == 500

# Generated at 2022-06-23 14:09:10.340333
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_test = [1, 2, 2, 3, 4, 4, 5, 1, 2, 3, 2, 4, 4, 5, 1, 2]
    list_expected = [1, 2, 3, 4, 5, 1, 2, 3, 2, 4, 5, 1, 2]
    assert deduplicate_list(list_to_test) == list_expected

# Generated at 2022-06-23 14:09:14.077873
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.name = 'Test'
            self.age = 99

    test_object = TestClass()
    test_dict = object_to_dict(test_object)
    assert(test_dict['age'] == 99)
    assert(test_dict['name'] == 'Test')



# Generated at 2022-06-23 14:09:25.594739
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','a','c','b','b','a','b','c','c','d','d','c','b','a','b','c','d','d','a','c','d','d','c','a','b','a','c','d','b','a','b','c','d','d','a','c','d','d','c','a','b','a','c','d','d','c','a','b','a','c','d','d','c','a','b','a','c','d','d','c','a','b','a','c','d','d','c','a','b','a','c','d','d','c','a','b','a','c','d','d','c']) == ['a','b','c','d']



# Generated at 2022-06-23 14:09:31.573574
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(51, 100) == 51
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int(1, 100, 5) == 5

# Generated at 2022-06-23 14:09:39.472808
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test = 10
            self.test1 = 20
    obj = TestObject()
    obj_dict = object_to_dict(obj, ['test'])
    assert obj_dict.get('test') is None
    assert obj_dict.get('test1') == 20

    # check for wrong arguments
    obj_dict = object_to_dict(obj, 'test')
    assert obj_dict.get('test') is None
    assert obj_dict.get('test1') == 20

    # check for wrong arguments
    obj_dict = object_to_dict(obj)
    assert obj_dict.get('test') == 10
    assert obj_dict.get('test1') == 20


# Generated at 2022-06-23 14:09:51.961091
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 100, min_value=3) == 3
    assert pct_to_int("101%", 100) == 100
    assert pct_to_int("101%", 100, min_value=3) == 3
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 100, min_value=3) == 3
    assert pct_to_int("0%", 100) == 1
    assert pct_to_int("0%", 100, min_value=3) == 3
    assert pct_to_int("-1%", 100) == 1
    assert pct_to_int("-1%", 100, min_value=3)

# Generated at 2022-06-23 14:09:56.533782
# Unit test for function pct_to_int
def test_pct_to_int():

    class TestPctToInt:
        # Test pct_to_int when value is set to 10
        def test_pct_to_int_pass(self):
            value = 10
            num_items = 100
            assert value == pct_to_int(value, num_items)

        # Test pct_to_int when value is set to 10%
        def test_pct_to_int_pass(self):
            value = '10%'
            num_items = 100
            assert 10 == pct_to_int(value, num_items)

        # Test pct_to_int when value is set to 0%
        def test_pct_to_int_pass(self):
            value = '0%'
            num_items = 100

# Generated at 2022-06-23 14:10:06.463180
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        """
        Generic class for test purposes
        """

        def __init__(self):
            self.att1 = 1
            self.att2 = 2
            self.att3 = 3
            self._att4 = 4

    testobj = TestObj()
    dictobj = object_to_dict(testobj, exclude=['att3'])

    assert 'att1' in dictobj
    assert 'att2' in dictobj
    assert 'att3' not in dictobj
    assert '_att4' not in dictobj
    assert dictobj['att1'] == 1
    assert dictobj['att2'] == 2
    assert 'att3' not in dictobj
    assert '_att4' not in dictobj

# Generated at 2022-06-23 14:10:17.219472
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int(0, 100) == 0
    assert pct_to_int('0', 100) == 0
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(1%2, 100) == 0
    assert pct_to_int('1%2', 100) == 0
    assert pct_to_int('-1%', 100) == 0
    assert pct_to_int('101%', 100) == 100

# Generated at 2022-06-23 14:10:20.970825
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('30%', 100) == 30
    assert pct_to_int('30', 100) == 30
    assert pct_to_int(30, 100) == 30



# Generated at 2022-06-23 14:10:26.193711
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(0.8, 100) == 80
    assert pct_to_int('0.8', 100) == 80
    assert pct_to_int('0', 100) == 1
    assert pct_to_int('', 100) == 1

# Generated at 2022-06-23 14:10:36.199067
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(30, 100) == 30
    assert pct_to_int(10, 200) == 20
    assert pct_to_int(15, 300) == 45
    assert pct_to_int(20, 400) == 80
    assert pct_to_int(25, 100) == 25
    assert pct_to_int(25, 100, 1) == 25
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('20%', 400) == 80
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('25%', 100, 1) == 25

# Generated at 2022-06-23 14:10:39.736857
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ["One", "Two", "Three", "Two", "Four", "One"]
    assert deduplicate_list(test_list) == ["One", "Two", "Three", "Four"]


# Generated at 2022-06-23 14:10:42.604961
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 2, 1, 2, 5, 3]
    assert deduplicate_list(original_list) == [1, 3, 2, 5]


# Generated at 2022-06-23 14:10:52.602475
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 10) == 1
    assert pct_to_int("10%", 50) == 5
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("10%", 129) == 13
    assert pct_to_int("0%", 20) == 1
    assert pct_to_int("0%", 20, min_value=20) == 20
    assert pct_to_int("0/1", 20, min_value=20) == 20
    assert pct_to_int("10", 20, min_value=20) == 10
    assert pct_to_int("100", 20, min_value=20) == 20
    assert pct_to_int("110", 20, min_value=20) == 20



# Generated at 2022-06-23 14:10:57.190543
# Unit test for function deduplicate_list
def test_deduplicate_list():
    mylist = ['item1', 'item2', 'item1']
    mylist_deduplicated = deduplicate_list(mylist)
    assert mylist_deduplicated == ['item1', 'item2']



# Generated at 2022-06-23 14:11:05.445149
# Unit test for function pct_to_int
def test_pct_to_int():
    total = 100
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(0, 100, min_value=0) == 0
    assert pct_to_int('0', 100, min_value=0) == 0
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', total, min_value=1) == 1
    assert pct_to_int('0%', total, min_value=1) == 1
    assert pct_

# Generated at 2022-06-23 14:11:15.314804
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'c', 'c', 'b', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 1, 4, 2, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 14:11:25.800461
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=0) == 100
    assert pct_to_int('100%', 100, min_value=1) == 100
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int('1%', 100, min_value=1) == 1
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=0) == 0

# Generated at 2022-06-23 14:11:29.066345
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ["foo", "bar", "test", "foo", "bar", "fo", "foobar", "test"]
    assert deduplicate_list(test_list) == ["foo", "bar", "test", "fo", "foobar"]

# Generated at 2022-06-23 14:11:39.062756
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 1000) == 100
    assert pct_to_int("10%", 1000, min_value=10) == 100
    assert pct_to_int("1%", 1000, min_value=10) == 10
    assert pct_to_int("101%", 1000) == 101
    assert pct_to_int("101%", 1000, min_value=10) == 101
    assert pct_to_int("99%", 1000, min_value=10) == 99
    assert pct_to_int("100%", 1000, min_value=10) == 100

    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 1000) == 10
   

# Generated at 2022-06-23 14:11:43.523288
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([3, 1, 3, 5]) == [3, 1, 5]
    assert deduplicate_list(['a', 'a', 'b', 1, 'x']) == ['a', 'b', 1, 'x']


# Generated at 2022-06-23 14:11:48.634415
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original = ['a', 'b', 'c', 'a']
    expected = ['a', 'b', 'c']
    result = deduplicate_list(original)
    assert result == expected, 'Deduplication failed'
    print('Deduplication result = %s' % result)



# Generated at 2022-06-23 14:11:51.543577
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3], 'Unable to deduplicate_list'



# Generated at 2022-06-23 14:12:00.136691
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    test_dict = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert test_dict == object_to_dict(Test()), 'object_to_dict returns incorrect result'
    test_dict = {'a': 'a', 'c': 'c'}
    assert test_dict == object_to_dict(Test(), ['b']), 'object_to_dict returns incorrect result with exclude passed'


# Generated at 2022-06-23 14:12:11.479240
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = ['a', 'b', 'c', 'd', 'b', 'd']
    expected = ['a', 'b', 'c', 'd']
    assert expected == deduplicate_list(sample_list)

    sample_list = ['a', 'b', 'c', 'd', 'b', 'd', 'a', 'b']
    expected = ['a', 'b', 'c', 'd']
    assert expected == deduplicate_list(sample_list)

    sample_list = [2, 3, 5, 8, 8, 7, 5, 6, 2, 7, 3, 3, 4, 7, 5]
    expected = [2, 3, 5, 8, 7, 6, 4]
    assert expected == deduplicate_list(sample_list)



# Generated at 2022-06-23 14:12:17.891587
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test for function deduplicate_list
    """
    original_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'a', 'b', 'c', 'h', 'i', 'j', 'k', 'l', 'a', 'b']
    expected_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l']
    deduplicated_list = deduplicate_list(original_list)
    assert expected_list == deduplicated_list

# Generated at 2022-06-23 14:12:23.717755
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 0, 1) == 1
    assert pct_to_int('1%', 100, 1) == 1
    assert pct_to_int('50%', 100, 1) == 50
    assert pct_to_int('1', 100, 1) == 1
    assert pct_to_int(1, 100, 1) == 1

# Generated at 2022-06-23 14:12:28.379671
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 67) == 13
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('5%', 10, min_value=0) == 0
    assert pct_to_int(5, 10) == 5
    assert pct_to_int(5, 10, min_value=5) == 5

# Generated at 2022-06-23 14:12:33.142383
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.public = True

        def get_private(self):
            return 'private'
    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert 'public' in test_dict
    assert test_dict['public'] == True

# Generated at 2022-06-23 14:12:42.488835
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Tests the function pct_to_int
    """

    actual = pct_to_int(100, 10)
    assert actual == 10

    actual = pct_to_int(10, 10)
    assert actual == 1

    actual = pct_to_int(110, 10)
    assert actual == 11

    actual = pct_to_int(110, 10, min_value=5)
    assert actual == 11

    actual = pct_to_int(90, 10, min_value=5)
    assert actual == 9

    actual = pct_to_int(50, 10)
    assert actual == 5

    actual = pct_to_int(0, 10)
    assert actual == 1

test_pct_to_int()

# Generated at 2022-06-23 14:12:49.814997
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = 'Chuck'
            self._c = None
            self._d = 'Not included'
    t = Test()
    obj_dict = object_to_dict(t, exclude=['b'])
    assert obj_dict == dict((key, getattr(t, key)) for key in dir(t) if (key.startswith('a') or key.startswith('_c')))

# Generated at 2022-06-23 14:12:56.236330
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Unit test for function pct_to_int
    '''
    pct_val_list = [10, 20, '30%', '40%']
    num_items = 10
    min_value = 1

    int_val_list = [pct_to_int(pct_item, num_items, min_value) for pct_item in pct_val_list]
    assert int_val_list == [10, 20, 3, 4]

# Generated at 2022-06-23 14:13:03.833344
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.var1 = 1
            self.var2 = 2
            self.var3 = 3
        def var4(self):
            return 'var4'

    my_obj = TestClass()
    my_dict = object_to_dict(my_obj, ['var2'])
    assert my_dict['var1'] == 1
    assert 'var2' not in my_dict
    assert my_dict['var3'] == 3
    assert 'var4' not in my_dict



# Generated at 2022-06-23 14:13:11.175530
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([2, 3, 1, 2, 3, 5, 4, 3, 1, 5, 7, 8, 1, 5, 7]) == [2, 3, 1, 5, 4, 7, 8]
    assert deduplicate_list([2, 3, 1, 2, 3, 5, 4, 3, 1, 5, 7, 8, 1, 5, 7]) != [3, 1, 2, 4, 5, 7, 8]
    assert deduplicate_list([2, 3, 1, 2, 3, 5, 4, 3, 1, 5, 7, 8, 1, 5, 7]) != [1, 2, 3, 4, 5, 7, 8]

# Generated at 2022-06-23 14:13:14.091468
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 20) == 10
    assert pct_to_int('10%', 20) == 2
    assert pct_to_int(10, 0) == 0
    assert pct_to_int('10%', 0) == 0
    assert pct_to_int('10%', 0, 1) == 1

# Generated at 2022-06-23 14:13:17.872722
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 10) == 1


# Generated at 2022-06-23 14:13:20.949103
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(1000, 100) == 100



# Generated at 2022-06-23 14:13:30.688279
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object(object):
        a = 1
        b = 2
        c = 3

    test_obj = test_object()
    test_dict = object_to_dict(obj=test_obj)
    assert 'a' in test_dict.keys()
    assert 'b' in test_dict.keys()
    assert 'c' in test_dict.keys()
    assert len(test_dict.keys()) == 3

    test_dict = object_to_dict(obj=test_obj, exclude=['b'])
    assert 'a' in test_dict.keys()
    assert 'b' not in test_dict.keys()
    assert 'c' in test_dict.keys()
    assert len(test_dict.keys()) == 2

# Generated at 2022-06-23 14:13:35.493927
# Unit test for function pct_to_int
def test_pct_to_int():
    pct = pct_to_int('10%', 1000)
    assert pct == 100
    pct = pct_to_int('10%', 0)
    assert pct == 1
    pct = pct_to_int(10, 100000)
    assert pct == 10



# Generated at 2022-06-23 14:13:42.867870
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:
        def __init__(self):
            self._exclude = ['_exclude']
            self.param1 = 'value1'
            self._param2 = '_value2'
            self.param3 = 'value3'
            self._param4 = '_value4'
            self.param5 = 'value5'

    myobj = MyClass()
    mydict = object_to_dict(myobj, exclude=myobj._exclude)

    assert '_param2' not in mydict.keys()
    assert '_exclude' not in mydict.keys()
    assert '_param4' not in mydict.keys()
    assert 'param1' in mydict.keys()
    assert 'param3' in mydict.keys()
    assert 'param5' in mydict.keys()

   

# Generated at 2022-06-23 14:13:47.458083
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['a', 'b', 'c', 'd', 'd', 'a', 'b', 'e', 'f', 'a']
    assert set(['a', 'b', 'c', 'd', 'e', 'f']) == set(deduplicate_list(list1))



# Generated at 2022-06-23 14:13:53.900240
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, value1, value2):
            self.value1 = value1
            self.value2 = value2

    test_object = TestClass("foo", "bar")
    dict_test_object = object_to_dict(test_object)
    assert dict_test_object == {'value1': 'foo', 'value2': 'bar'}



# Generated at 2022-06-23 14:13:59.183416
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test1 = 'Test1'
        test2 = [1, 2, 3, 3]
        test3 = False
        test4 = -1

    output = object_to_dict(Test())

    assert output == {'test1': 'Test1', 'test2': [1, 2, 3, 3], 'test3': False, 'test4': -1}

# Generated at 2022-06-23 14:14:05.017389
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        """
        Helper class for testing
        """
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    obj = Test(a=1, b=2, c=3, d='test', _private=True)
    obj_dict = object_to_dict(obj, ['_private'])
    assert obj_dict == {'a': 1, 'b': 2, 'c': 3, 'd': 'test'}

# Generated at 2022-06-23 14:14:15.725949
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        a = 'a'
        b = 'b'
        c = 'c'
        d = 'd'
        e = 'e'
        f = 'f'

    # test for normal functionality
    obj = TestObject()
    assert(object_to_dict(obj) == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e', 'f': 'f'})

    # test for excluding keys
    obj = TestObject()
    assert(object_to_dict(obj, exclude=['a', 'c', 'f']) == {'b': 'b', 'd': 'd', 'e': 'e'})

# Generated at 2022-06-23 14:14:25.257286
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6, 7, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 8, 8, 10, 1, 1, 2]) == [1, 2, 3, 4, 5, 6, 7, 8, 10]

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-23 14:14:36.503239
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    This function is used to test the pct_to_int function
    in utils.py
    '''
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10.1, 100) == 10
    assert pct_to_int(10.5, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10.5', 100) == 10
    assert pct_to_int('10.9', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.1%', 100) == 10
    assert pct_to_int('10.5%', 99) == 9

# Generated at 2022-06-23 14:14:42.087188
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int(0.5, 100) == 1
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-23 14:14:46.690307
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 20) == 10
    assert pct_to_int(10, 20, min_value=2) == 2
    assert pct_to_int(50, 20) == 10
    assert pct_to_int('10%', 20) == 2


# Generated at 2022-06-23 14:14:56.898128
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    min_value = 1
    test_data = [
        {'value': '0%', 'expected': 0},
        {'value': '100%', 'expected': num_items},
        {'value': '50%', 'expected': int(num_items/2)},
        {'value': '50', 'expected': 50},
        {'value': '50.5', 'expected': 50},
        {'value': '%50', 'expected': min_value},
        {'value': 'test', 'expected': min_value}
    ]
    for data in test_data:
        result = pct_to_int(data['value'], num_items, min_value)

# Generated at 2022-06-23 14:15:00.177479
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['foo', 'bar', 'baz', 'foo', 'foo', 'foo', 'bar', 'bar', 'baz', 'baz', 'baz', 'baz']
    list2 = ['foo', 'bar', 'baz']
    assert deduplicate_list(list1) == list2

# Generated at 2022-06-23 14:15:06.431390
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert sorted(deduplicate_list(['a', 'b', 'a'])) == ['a', 'b']
    assert sorted(deduplicate_list([])) == []
    assert sorted(deduplicate_list(['a', 'a', 'a', 'b', 'c', 'c', 'c', 'd', 'b'])) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 14:15:09.819119
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 4, 4, 4, 5]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4, 5]



# Generated at 2022-06-23 14:15:20.617492
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(1, 100) == 1)
    assert(pct_to_int('1', 100) == 1)
    assert(pct_to_int(10.5, 100) == 10)
    assert(pct_to_int('10.5', 100) == 10)
    assert(pct_to_int(10.5, 100.0) == 10.0)
    assert(pct_to_int('10.5', 100.0) == 10.0)
    assert(pct_to_int(10.5, 100, 3) == 3)
    assert(pct_to_int('10.5', 100, 3) == 3)
    assert(pct_to_int('10%', 100) == 10)

# Generated at 2022-06-23 14:15:29.534682
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a list, name it
    input_list = [1, 2, 4, 6, 2, 1, 8, 6]
    # Create a list, name it
    expected_list =[1, 2, 4, 6, 8,]
    # pass the list in the function and name it, then compare
    assert deduplicate_list(input_list) == expected_list
    # Create a list, name it
    input_list = [1, 2, 4, 6, 2, 1, 8, 6, 'b', 'b', 'a', 'a']
    # Create a list, name it
    expected_list =[1, 2, 4, 6, 8, 'b', 'a']
    # pass the list in the function and name it, then compare
    assert deduplicate_list(input_list) == expected_

# Generated at 2022-06-23 14:15:34.664671
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['fred', 'barney', 'wilma', 'fred', 'betty']) == ['fred', 'barney', 'wilma', 'betty']
    assert deduplicate_list(['betty']) == ['betty']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['fred', 'fred']) == ['fred']

# Generated at 2022-06-23 14:15:44.017421
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self.test3 = 'test3'
            self._test = 'test'
    obj = Test()
    assert object_to_dict(obj) == {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    assert object_to_dict(obj, exclude=['test3']) == {'test1': 'test1', 'test2': 'test2'}

# Generated at 2022-06-23 14:15:48.764386
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample = [1, 2, 3, 1, 2, 4, 5, 4, 4, 6, 5, 7, 3, 4, 2]
    result = [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list(sample) == result
    assert deduplicate_list(result) == result
    assert deduplicate_list([4,4,4,4]) == [4]
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:15:57.524439
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test for function object_to_dict
    """
    class Foo(object):
        """
        Simple class for testing object_to_dict
        """
        def __init__(self):
            """
            Constructor
            """
            self.bar = "bar"
            self.baz = "baz"

    assert object_to_dict(Foo()) == {'bar': 'bar', 'baz': 'baz'}


# Generated at 2022-06-23 14:16:07.096926
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClassBase(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4

    class TestClass(TestClassBase):
        def __init__(self):
            TestClassBase.__init__(self)
            self.e = 5
            self.f = 6

    test_object = TestClass()
    assert object_to_dict(test_object) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
    assert object_to_dict(test_object, ['a', 'b']) == {'c': 3, 'd': 4, 'e': 5, 'f': 6}

# Generated at 2022-06-23 14:16:14.471820
# Unit test for function deduplicate_list
def test_deduplicate_list():

    test_list = [
        '1',
        '2',
        '2',
        '3',
        '4',
        '5',
        '5',
        '5',
    ]

    dedup_test_list = deduplicate_list(test_list)
    assert(len(dedup_test_list) == 5)
    assert('1' in dedup_test_list)
    assert('2' in dedup_test_list)
    assert('3' in dedup_test_list)
    assert('4' in dedup_test_list)
    assert('5' in dedup_test_list)

# Generated at 2022-06-23 14:16:18.932340
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.exclude = 'this should not be in the converted dict'
            self.include = 'this will be included in the dict'
            self._private = 'this should not be in the dict'

    test = TestObject()
    result = object_to_dict(test, exclude=['_private', 'exclude'])

    assert 'exclude' not in result
    assert '_private' not in result
    assert 'include' in result
    assert result['include'] == 'this will be included in the dict'



# Generated at 2022-06-23 14:16:29.486164
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int(100, 1000) == 100
    assert pct_to_int('10', 1000) == 10
    assert pct_to_int(9, 10) == 1
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(9, 1) == 1
    assert pct_to_int(1, 10) == 1
    assert pct_to_int(0, 10) == 1
    assert pct_to_int(0, 1) == 1
    assert pct_to_int(9, 100) == 10
    assert pct_to_int(1, 100) == 1


# Generated at 2022-06-23 14:16:35.218957
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    t = TestObject()
    assert object_to_dict(t) == {'a': 1, 'b': 2, 'c': 3}, 'failed to convert object to dict'
    assert object_to_dict(t, ['a']) == {'b': 2, 'c': 3}, 'failed to exclude attributes from dict'

# Generated at 2022-06-23 14:16:43.580372
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.foo = 1
            self.bar = 2
            self.baz = 3

    obj = TestObj()

    test_dict_1 = object_to_dict(obj)
    test_dict_2 = object_to_dict(obj, exclude=['foo'])

    assert test_dict_1 == {'foo': 1, 'bar': 2, 'baz': 3}
    assert test_dict_2 == {'bar': 2, 'baz': 3}

# Generated at 2022-06-23 14:16:47.864842
# Unit test for function pct_to_int
def test_pct_to_int():
    """ Tests for function pct_to_int """
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int(10, 5) == 10
    assert pct_to_int('10', 5) == 10
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int('10%', 5, min_value=5) == 5


# Generated at 2022-06-23 14:16:53.014957
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 20, min_value=1) == 2
    assert pct_to_int(20, 20, min_value=1) == 4
    assert pct_to_int(20.0, 20, min_value=1) == 4
    assert pct_to_int('20%', 20, min_value=1) == 4



# Generated at 2022-06-23 14:17:03.785171
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        blah = 'blah'
        blah2 = 'blah2'
        blah3 = 'blah3'

    test_obj1 = TestObject()
    test_obj2 = TestObject()
    test_obj2.blah2 = 'notblah2'

    # Check test_obj1 with no exclusions
    test_result = object_to_dict(test_obj1)
    assert sorted(test_result.keys()) == ['blah', 'blah2', 'blah3']
    for key in test_result:
        assert test_result[key] == 'blah'

    # Check test_obj2 with no exclusions
    test_result = object_to_dict(test_obj2)