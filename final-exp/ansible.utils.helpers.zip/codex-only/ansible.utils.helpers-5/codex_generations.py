

# Generated at 2022-06-23 14:07:10.580801
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'c', 'b', 'c']) == ['a', 'c', 'b']
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert ded

# Generated at 2022-06-23 14:07:19.889626
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestClass(object):
        def __init__(self, name, description):
            self.name = name
            self.description = description
            self.other_key = "other value"

        def _get_dummy_attr(self):
            return "dummy"

        def get_description(self):
            return self.description

    # Test without exclude
    obj = TestClass("test", "desc")
    obj_dict = object_to_dict(obj)
    assert obj_dict['name'] == "test"
    assert obj_dict['description'] == "desc"
    assert obj_dict['other_key'] == "other value"

    # Test with exclude
    obj_dict = object_to_dict(obj, exclude=['name', 'other_key'])
    assert obj_dict['name'] == None
   

# Generated at 2022-06-23 14:07:23.321390
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 2

    assert object_to_dict(Foo()) == {'a': 1, 'b': 2}

# Generated at 2022-06-23 14:07:26.888714
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-23 14:07:33.474709
# Unit test for function pct_to_int
def test_pct_to_int():
    expected_16 = pct_to_int(100, 16)
    assert(expected_16 == 16)
    expected_17 = pct_to_int("50%", 34)
    assert(expected_17 == 17)
    expected_3 = pct_to_int("0%", 8, min_value=3)
    assert(expected_3 == 3)

# Generated at 2022-06-23 14:07:38.977740
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        attr_1 = 'foo'
        attr_2 = 'bar'
        attr_3 = 'baz'

    test = test_class()
    test_dict = object_to_dict(test)
    assert test_dict == {'attr_1': 'foo', 'attr_2': 'bar', 'attr_3': 'baz'}

    test_dict_excluded = object_to_dict(test, exclude=['attr_1', 'attr_2'])
    assert test_dict_excluded == {'attr_3': 'baz'}


# Generated at 2022-06-23 14:07:42.331126
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        x = None

    obj = A()
    obj.x = 1
    obj.y = 2
    obj.z = 3
    assert object_to_dict(obj, ['y']) == {'x': 1, 'z': 3}

# Generated at 2022-06-23 14:07:47.831011
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('.10%', 1000) == 1
    assert pct_to_int('10.0%', 1000) == 100
    assert pct_to_int('10.5%', 1000) == 105
    assert pct_to_int('a10%', 1000) == 1000

# Generated at 2022-06-23 14:07:52.434508
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["red", "red", "green", "yellow", "green", "yellow", "black"]) == ["red", "green", "yellow", "black"]
    assert deduplicate_list([]) == []
    assert deduplicate_list(["red"]) == ["red"]
    assert deduplicate_list(["red", "green", "yellow", "black"]) == ["red", "green", "yellow", "black"]



# Generated at 2022-06-23 14:08:00.797953
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test_property_1 = "property1"
            self.test_property_2 = "property2"
            self.test_property_3 = "property3"

    test_obj = TestClass()
    result = object_to_dict(test_obj, ['test_property_2'])
    assert result['test_property_1'] == 'property1'
    assert result['test_property_3'] == 'property3'
    assert 'test_property_2' not in result
    assert len(result) == 2

# Generated at 2022-06-23 14:08:07.539395
# Unit test for function pct_to_int
def test_pct_to_int():
    print(pct_to_int(20, 100))
    print(pct_to_int(20, 200))
    print(pct_to_int(20, 100, 10))
    print(pct_to_int('20%', 100))
    print(pct_to_int('20%', 200))
    print(pct_to_int('20%', 100, 10))
    print(pct_to_int('10%', 200))

if __name__ == '__main__':
    test_pct_to_int()

# Generated at 2022-06-23 14:08:10.483794
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = ['one', 'one', 'two', 'three', 'two', 'four', 'five', 'five']
    dedup_list = deduplicate_list(my_list)
    assert isinstance(dedup_list, list)
    assert 5 == len(dedup_list)
    assert dedup_list[0] == 'one'
    assert dedup_list[1] == 'two'

# Generated at 2022-06-23 14:08:19.462160
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Verifies the output of the function deduplicate_list.
    """

# Generated at 2022-06-23 14:08:30.218259
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClassObject(object):
        test1 = "test1"
        test2 = "test2"
        test3 = "test3"

    test_tuple = tuple()
    test_list = list()
    test_dict = dict()
    test_int = int()
    obj = TestClassObject()
    exclude = ["test1", "test2"]

    result = object_to_dict(obj, exclude)
    if result != {"test3": "test3"}:
        raise AssertionError("Failed to convert object")

    result = object_to_dict(test_tuple)
    if result != {}:
        raise AssertionError("Failed to convert tuple")

    result = object_to_dict(test_dict)

# Generated at 2022-06-23 14:08:33.058637
# Unit test for function object_to_dict
def test_object_to_dict():
    _obj = {"a":1, "b":2, "_class":3}
    assert object_to_dict(_obj) == {"a":1, "b":2, "_class":3}
    assert object_to_dict(_obj, exclude=["a"]) == {"b":2, "_class":3}

# Generated at 2022-06-23 14:08:35.726677
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 4, 5, 1, 2]) == [1, 2, 3, 4, 5]
    assert deduplicate_list('abcabcabcabcabc') == list('abc')
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:08:40.647581
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 10000) == 2000
    assert pct_to_int(20, 10000, min_value=0) == 2000
    assert pct_to_int(10, 10000) == 1000
    assert pct_to_int(5, 10000) == 500
    assert pct_to_int(3, 10000) == 300
    assert pct_to_int('1%', 10000) == 100
    assert pct_to_int('1%', 10000, min_value=0) == 100
    assert pct_to_int('0.01%', 10000, min_value=0) == 0
    assert pct_to_int(0, 10000) == 1
    assert pct_to_int(0.1, 10000) == 1
    assert pct_to_int('', 10000) == 1

# Generated at 2022-06-23 14:08:46.067066
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for function deduplicate_list
    """
    assert deduplicate_list([1,2,2,3,1,4]) == [1,2,3,4]
    assert deduplicate_list([1,1,1,1,1,1]) == [1]
    assert deduplicate_list([]) == []


# Generated at 2022-06-23 14:08:51.374069
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test1 = "test1"
            self.test2 = "test2"

    test_data = TestClass()
    result = object_to_dict(test_data, exclude=['test1'])
    assert result.get('test1') is None
    assert result.get('test2') == 'test2'


# Generated at 2022-06-23 14:08:57.161567
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['1', '1', '1']) == ['1']
    assert deduplicate_list(['1', '2', '3', '1', '2', '3']) == ['1', '2', '3']
    assert deduplicate_list(['2', '2', '2', '1', '1', '1']) == ['2', '1']


# Generated at 2022-06-23 14:09:01.514999
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50

    assert pct_to_int(50, 100) == 50

    assert pct_to_int("10%", 5) == 1

    assert pct_to_int("0%", 100) == 1

    assert pct_to_int("50%", 100, 2) == 50

    assert pct_to_int("10%", 5, 2) == 2

    assert pct_to_int("0%", 100, 2) == 2

# Generated at 2022-06-23 14:09:09.472230
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('100%', 10) == 10

    assert pct_to_int('5', 100) == 5
    assert pct_to_int(5, 100) == 5



# Generated at 2022-06-23 14:09:10.739373
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "b", "c", "a"]) == ["a", "b", "c"]

# Generated at 2022-06-23 14:09:14.596791
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test to validate that the method works as expected.
    """
    original_list = ['test', 'test', 'test2']
    deduped_list = deduplicate_list(original_list)
    assert deduped_list == ['test', 'test2']


# Generated at 2022-06-23 14:09:21.223116
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int(500, 100) == 500
    assert pct_to_int('500', 100) == 500
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int(0, 100) == 1


# Generated at 2022-06-23 14:09:29.042464
# Unit test for function object_to_dict
def test_object_to_dict():
    # create a test object
    class test_object:
        test_property = 'test_value'
        test_property_2 = 'test_value_2'
        _test_exclude_value = 'test_exclude_value'

        def __init__(self):
            pass

    # create the test object
    test_object_1 = test_object()

    # convert the test object to a dict
    test_object_1_dict = object_to_dict(test_object_1, exclude=['_test_exclude_value'])

    assert 'test_property' in test_object_1_dict
    assert 'test_property_2' in test_object_1_dict
    assert '_test_exclude_value' not in test_object_1_dict

# Generated at 2022-06-23 14:09:33.033966
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 10, 2, 1, 2, 100]) == [1, 2, 10, 100]

# Generated at 2022-06-23 14:09:38.137431
# Unit test for function object_to_dict
def test_object_to_dict():
    class testclass():
        field1 = "field1"
        field2 = "field2"
        def __init__(self):
            pass

    tc = testclass()
    output = object_to_dict(tc)
    assert output.has_key("field1") and output.has_key("field2")
    assert len(output.keys()) == 2

# Generated at 2022-06-23 14:09:42.697368
# Unit test for function pct_to_int
def test_pct_to_int():
    # Minimum value is always returned when percentage is less than 100%
    assert(pct_to_int(1, 10, min_value=5) == 5)

    # Int conversion works
    assert(pct_to_int(10, 10) == 10)

    # Percentage conversion works
    assert(pct_to_int(20, 20) == 4)
    assert(pct_to_int(50, 100) == 50)
    assert(pct_to_int('70%', 100) == 70)


# Generated at 2022-06-23 14:09:50.836562
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3]) == [1,2,3]
    assert deduplicate_list([1,1,1,2,2,2,3,3,3]) == [1,2,3]
    assert deduplicate_list([3,3,3,1,1,2,2,3,3,1,1,1,1,1,2,2,2]) == [3,1,2]

# Generated at 2022-06-23 14:09:53.418737
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["John", "Paul", "George", "Ringo", "John", "Paul"]) == ["John", "Paul", "George", "Ringo"]

# Generated at 2022-06-23 14:10:00.248885
# Unit test for function pct_to_int

# Generated at 2022-06-23 14:10:04.321843
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 100, min_value=0) == 5
    assert pct_to_int("5.5%", 100, min_value=0) == 6
    assert pct_to_int("50%", 100, min_value=0) == 50
    assert pct_to_int("50.5%", 100, min_value=0) == 51
    assert pct_to_int("95%", 100, min_value=0) == 95
    assert pct_to_int("95.5%", 100, min_value=0) == 96
    assert pct_to_int("100%", 100, min_value=0) == 100
    assert pct_to_int("100.5%", 100, min_value=0) == 101
    assert pct_to_

# Generated at 2022-06-23 14:10:06.709259
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,2,2,2,3]) == [1,2,3]



# Generated at 2022-06-23 14:10:10.622253
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        i = 3
        j = 5
    obj = Test()
    assert object_to_dict(obj) == {'i': 3, 'j': 5}

# Generated at 2022-06-23 14:10:17.295891
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.a = "A"
            self.b = "B"
            self.c = "C"
            self.d = "D"

    test_obj = Test()
    obj_dict = object_to_dict(test_obj, exclude=['a'])

    assert obj_dict['a'] == 'A'
    assert obj_dict['b'] == 'B'
    assert obj_dict['c'] == 'C'
    assert obj_dict['d'] == 'D'

# Generated at 2022-06-23 14:10:22.405492
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, name):
            self.name = name

    test_obj = TestClass('TestName')

    result = object_to_dict(test_obj)

    assert isinstance(result, dict)
    assert result['name'] == 'TestName'

# Generated at 2022-06-23 14:10:29.097037
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(range(10)) == list(range(10))
    assert deduplicate_list([1, 2, 3, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 2, 3, 3, 3, 4, 1, 5, 6, 7, 7]) == [1, 2, 3, 4, 5, 6, 7]



# Generated at 2022-06-23 14:10:38.737429
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 50) == 25
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 50) == 25
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 50) == 1
    assert pct_to_int(1, 10) == 1
    assert pct_to_int(0.2, 100) == 1
    assert pct_to_int(0.2, 50) == 1

# Generated at 2022-06-23 14:10:48.469169
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.key1 = 1
            self.key2 = "value"
            self._private_key = "foo"

    out = object_to_dict(MyClass())
    assert dict == type(out)
    assert "key1" in out
    assert "key2" in out
    assert "_private_key" not in out

    out = object_to_dict(MyClass(), ["key1"])
    assert dict == type(out)
    assert "key1" not in out
    assert "key2" in out
    assert "_private_key" not in out

# Generated at 2022-06-23 14:10:57.725063
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.a = 'A'
    obj.b = 'B'
    obj.c = 'C'
    obj.d = 'D'
    assert object_to_dict(obj) == {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'}
    assert object_to_dict(obj, ['c']) == {'a': 'A', 'b': 'B', 'd': 'D'}
    assert object_to_dict(obj, ['c', 'd']) == {'a': 'A', 'b': 'B'}
    assert object_to_dict(obj, ['c', 'd', 'a']) == {'b': 'B'}

# Generated at 2022-06-23 14:11:02.152277
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int(None, 100) == 100
    assert pct_to_int('20%', 100, 10) == 10
    assert pct_to_int('50.5%', 100, 10) == 51
    assert pct_to_int('50.5', 100, 10) == 50

# Generated at 2022-06-23 14:11:08.779388
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyObj:
        def __init__(self):
            self.prop1 = "prop1"
            self.prop2 = "prop2"
            self.prop3 = "prop3"

    obj = DummyObj()
    obj_dict = object_to_dict(obj)
    assert obj_dict['prop1'] == "prop1"
    assert obj_dict['prop2'] == "prop2"
    assert obj_dict['prop3'] == "prop3"



# Generated at 2022-06-23 14:11:16.689224
# Unit test for function object_to_dict
def test_object_to_dict():
    """ Test converting object into dict function """
    class TestClass:
        """ Class to test object_to_dict with """
        attr1 = 'test'
        attr2 = 1
        attr3 = 'test1'
        attr4 = 1
        attr5 = 'test2'
    test_obj = TestClass()
    result = object_to_dict(test_obj)
    assert isinstance(result, type(dict()))
    assert len(result) == 5
    assert 1 in result.values()
    assert 'test' in result.values()
    result = object_to_dict(test_obj, exclude=['attr2', 'attr4'])
    assert isinstance(result, type(dict()))
    assert len(result) == 3
    assert 1 not in result.values()
    assert 'test'

# Generated at 2022-06-23 14:11:23.115813
# Unit test for function deduplicate_list
def test_deduplicate_list():
    o = [1, 2, 3, 1]
    assert deduplicate_list(o) == [1, 2, 3]

    o = [1, 2, 3, '1']
    assert deduplicate_list(o) == [1, 2, 3, '1']

    o = [1, 2, 3, 1, 1, 2, 3, 1, '3']
    assert deduplicate_list(o) == [1, 2, 3, '3']

# Generated at 2022-06-23 14:11:27.990510
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass():
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    my_object = MyClass()
    assert object_to_dict(my_object) == {'a': 1, 'c': 3, 'b': 2}
    assert object_to_dict(my_object, exclude=['b', 'c']) == {'a': 1}

# Generated at 2022-06-23 14:11:38.292982
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3, 2]
    assert deduplicate_list([1, 2, 3, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 3, 2]) == [1, 2, 3, 2]
    assert deduplicate_list([1, 2, 3, 2, 3, 2, 1, 1, 1, 2, 3, 3])

# Generated at 2022-06-23 14:11:49.496503
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass1(object):
        def __init__(self):
            self.prop1 = 'test1'
            self.prop2 = 'test2'
            self.prop3 = 'test3'
            self.prop4 = 'test4'
            self.prop5 = 'test5'

    class TestClass2(object):
        def __init__(self):
            self.prop1 = 'test1'
            self.prop2 = 'test2'
            self.prop3 = 'test3'
            self.prop4 = 'test4'
            self.prop5 = 'test5'

    
    test_object1 = TestClass1()

# Generated at 2022-06-23 14:11:57.133390
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, 1) == 1


# Generated at 2022-06-23 14:12:01.350006
# Unit test for function object_to_dict
def test_object_to_dict():
    class testClass:
        def __init__(self):
            self.key1 = 2
            self._key2 = 2

    testObject = testClass()
    test_dict = object_to_dict(testObject)
    assert test_dict == {'key1': 2}

    test_dict = object_to_dict(testObject, ['_key2'])
    assert test_dict == {'key1': 2}

# Generated at 2022-06-23 14:12:05.293252
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        test_attr = 'test'

    obj = TestObj()
    result = object_to_dict(obj)

    assert len(result) == 1
    assert 'test_attr' in result



# Generated at 2022-06-23 14:12:09.812268
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test = 'test'
        only_parent = 'only_parent'

    class Test2(Test):
        test2 = 'test2'
        test = 'test2_override'

    class Test3(Test):
        test3 = 'test3'
        exclude = 'exclude'

    t = Test()
    t2 = Test2()
    t3 = Test3()

    assert(object_to_dict(t) == {'test': 'test', 'only_parent':'only_parent'})
    assert(object_to_dict(t2) == {'test2': 'test2', 'test': 'test2_override', 'only_parent':'only_parent'})

# Generated at 2022-06-23 14:12:17.646754
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Object to dict test
    """
    class TestObject(object):
        """
        Test class
        """
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = {'1': 'one', '2': 'two'}
            self.e = None
    test_obj = TestObject()
    result = object_to_dict(test_obj)
    assert result == {'d': {'1': 'one', '2': 'two'}, 'c': 3, 'a': 1, 'b': 2, 'e': None}

# Generated at 2022-06-23 14:12:28.214464
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10.5%", 100) == 11
    assert pct_to_int("10%", 99) == 10
    assert pct_to_int("100%", 99) == 99
    assert pct_to_int("0.1%", 99) == 1
    assert pct_to_int("50%", 1) == 1
    assert pct_to_int("50%", 2) == 1
    assert pct_to_int("50%", 3) == 2
    assert pct_to_int("50%", 9) == 5

    assert pct_to_int("10", 100) == 10
    assert pct_to_int("10", 99) == 10

# Generated at 2022-06-23 14:12:33.034021
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 4, 2, 5]
    deduped_list = deduplicate_list(original_list)
    if deduped_list != [1, 2, 3, 4, 5]:
        raise AssertionError("Expected [1, 2, 3, 4, 5] got " + str(deduped_list))



# Generated at 2022-06-23 14:12:41.417186
# Unit test for function object_to_dict
def test_object_to_dict():
    class T(object):
        name = 'test'
        attr1 = 'foo'
        attr2 = 'bar'
        attr3 = False

    t = T()
    d = object_to_dict(t, ['attr1'])
    assert d['name'] == 'test'
    assert d['attr2'] == 'bar'
    assert 'attr1' not in d
    assert 'attr3' in d

    d = object_to_dict(t)
    assert d['name'] == 'test'
    assert d['attr2'] == 'bar'
    assert d['attr1'] == 'foo'
    assert d['attr3'] == False

# Generated at 2022-06-23 14:12:45.175364
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'b', 'c', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'b', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:12:52.759460
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int("100%", 10) == 10)
    assert(pct_to_int("90%", 10) == 9)
    assert(pct_to_int("50%", 10) == 5)
    assert(pct_to_int("49%", 10) == 5)
    assert(pct_to_int(10, 10) == 10)
    assert(pct_to_int(10, 10, 1) == 10)
    assert(pct_to_int(0, 10, 1) == 1)
    assert(pct_to_int(0, 10, 2) == 2)
    assert(pct_to_int(0, 0, 2) == 2)


# Generated at 2022-06-23 14:12:58.014727
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self._exclude = 'exclude'

    t = TestObject()
    data = object_to_dict(t, exclude=['_exclude'])
    assert data == {'a': 'a', 'b': 'b'}, \
        'Excluded variable should not be included in object_to_dict result.'



# Generated at 2022-06-23 14:13:01.374236
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40]) == [1, 2, 3, 40]

# Generated at 2022-06-23 14:13:09.729420
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self._private = 4
            self.d = "testing"

    test_obj = Test()
    assert test_obj.__dict__ == object_to_dict(test_obj)
    assert test_obj.__dict__ == object_to_dict(test_obj, ['a'])
    assert {'a': 1, 'b': 2, 'c': 3, 'd': 'testing'} == object_to_dict(test_obj, ['_private'])
    assert {'b': 2, 'c': 3, 'd': 'testing'} == object_to_dict(test_obj, ['a', '_private'])

# Generated at 2022-06-23 14:13:16.264185
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test object_to_dict function
    """
    class MyClass:
        def __init__(self, var1, var2, var3):
            self.var1 = var1
            self.var2 = var2
            self.var3 = var3

    obj = MyClass("First", "Second", "Third")
    result = object_to_dict(obj, ['var2'])
    assert result.get('var1') == "First"
    assert result.get('var2') is None
    assert result.get('var3') == "Third"



# Generated at 2022-06-23 14:13:18.219198
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 51 # 1% of 100 is rounded to 1


# Generated at 2022-06-23 14:13:23.146483
# Unit test for function pct_to_int
def test_pct_to_int():
    assert (pct_to_int("50%", 100) == 50)
    assert (pct_to_int("50%", 1) == 1)
    assert (pct_to_int("50%", 1, 100) == 100)
    assert (pct_to_int(50, 100) == 50)

# Generated at 2022-06-23 14:13:28.296705
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 99) == 19
    assert pct_to_int('1.5%', 99) == 1


# Generated at 2022-06-23 14:13:33.980980
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(51, 100) == 51
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int(50.5, 100) == 50
    assert pct_to_int('50.5%', 100) == 50
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0.01%', 100) == 1

# Generated at 2022-06-23 14:13:42.281976
# Unit test for function pct_to_int
def test_pct_to_int():
    # function to test if the value is an integer
    def is_int(x):
        is_int = True
        if x is None:
            is_int = False
        elif not isinstance(x, int):
            is_int = False
        return is_int

    # case 1: value = 5%
    result = pct_to_int('5%', 100)
    assert is_int(result)
    assert result == 5

    # case 2: value = 5%
    result = pct_to_int('5%', 1000)
    assert is_int(result)
    assert result == 50

    # case 3: value = 5.2%
    result = pct_to_int('5.2%', 1000)
    assert is_int(result)
    assert result == 52

    # case 4:

# Generated at 2022-06-23 14:13:45.479232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = ['a', 'b', 'a', 'b', 'c', 'a', 'a', 'b']
    assert deduplicate_list(my_list) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:13:51.772837
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object():
        def __init__(self):
            self.prop1 = "prop1"
            self.prop2 = "prop2"

    obj = test_object()
    expected_dict = {"prop1": "prop1", "prop2": "prop2"}

    assert object_to_dict(obj) == expected_dict



# Generated at 2022-06-23 14:13:56.477548
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [2, 3, 1, 3, 2, 1, 4, 5, 6, 7, 8, 5]
    deduped_list = [2, 3, 1, 4, 5, 6, 7, 8]
    assert deduplicate_list(original_list) == deduped_list



# Generated at 2022-06-23 14:14:02.717695
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object:
        pass

    obj = test_object()
    obj.param1 = 'value1'
    obj.param2 = 'value2'
    obj.param3 = 'value3'
    obj.param4 = 'value4'
    obj.param5 = 'value5'
    obj.param6 = 'value6'

    result = object_to_dict(obj, ['param1', 'param3'])

    assert result == {'param2': 'value2', 'param4': 'value4', 'param5': 'value5', 'param6': 'value6'}



# Generated at 2022-06-23 14:14:11.497264
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'b', 'd', 'c', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']



# Generated at 2022-06-23 14:14:15.073787
# Unit test for function object_to_dict
def test_object_to_dict():
    cls = type('test_class', (object,), {'a':2, 'b':3, '_hidden':4})
    assert object_to_dict(cls()) == {'a':2, 'b':3}



# Generated at 2022-06-23 14:14:17.728704
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'a', 'c', 'c', 'b', 'b', 'a']
    assert deduplicate_list(test_list) == ['a', 'b', 'c']



# Generated at 2022-06-23 14:14:28.111261
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('60%', 150) == 90
    assert pct_to_int('2%', 500) == 10
    assert pct_to_int('2%', 0) == 0
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 0) == 0
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 0) == 0
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(5, 0) == 0

# Generated at 2022-06-23 14:14:33.872127
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(10, 100) == 10)
    assert(pct_to_int(99, 100) == 99)
    assert(pct_to_int('50%', 100) == 50)
    assert(pct_to_int('95%', 100) == 95)
    assert(pct_to_int('0%', 100) == 0)

# Generated at 2022-06-23 14:14:37.788458
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = list(range(10)) * 3
    output_list = deduplicate_list(input_list)

    assert len(output_list) == 10
    assert set(input_list) == set(output_list)
    assert output_list == list(range(10))



# Generated at 2022-06-23 14:14:48.568624
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('50.5%', 1000) == 505
    assert pct_to_int('50.51%', 1000) == 506
    assert pct_to_int('50.513%', 1000) == 506
    assert pct_to_int('50.514%', 1000) == 506
    assert pct_to_int('50.515%', 1000) == 507
    assert pct_to_int('50.516%', 1000) == 507
    assert pct_to_int(50, 1000) == 50
    assert pct_to_int(50.5, 1000) == 51
    assert pct_to_int(50.5, 1000, min_value=5) == 5
    assert pct_

# Generated at 2022-06-23 14:14:52.734767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'a', 'c', 'a', 'b', 'c', 'a', 'b', 'c']
    deduplicated_list = ['b', 'a', 'c']
    assert deduplicate_list(original_list) == deduplicated_list



# Generated at 2022-06-23 14:15:01.314807
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObj(object):
        """
        Helper class to test object_to_dict
        """
        def __init__(self):
            self.one = '1'
            self.two = '2'
            self.three = '3'
            self.four = '4'
            self.five = '5'

    obj = testObj()

    assert object_to_dict(obj) == {'one': '1', 'three': '3', 'two': '2', 'five': '5', 'four': '4'}

    assert object_to_dict(obj, exclude=['one']) == {'three': '3', 'two': '2', 'five': '5', 'four': '4'}


# Generated at 2022-06-23 14:15:11.430860
# Unit test for function object_to_dict
def test_object_to_dict():
    class FakeClass:
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self._foo = '_foo'
            self._bar = '_bar'

    obj1 = FakeClass()
    result1 = object_to_dict(obj1)
    assert result1['foo'] == 'foo'
    assert result1['bar'] == 'bar'
    assert '_foo' not in result1
    assert '_bar' not in result1

    obj2 = FakeClass()
    result2 = object_to_dict(obj2, exclude=['bar'])
    assert result2['foo'] == 'foo'
    assert 'bar' not in result2
    assert '_foo' not in result2
    assert '_bar' not in result2



# Generated at 2022-06-23 14:15:13.386984
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'bar', 'bar']) == ['foo', 'bar']

# Generated at 2022-06-23 14:15:19.623238
# Unit test for function deduplicate_list
def test_deduplicate_list():
    origin_list = [1, 2, 1, 2, 3, 4, 5, 6, 7, 6, 5, 4, 3, 2, 1, 1, 2, 3, 4, 5, 7, 6, 5, 4, 3, 2, 1, 1, 1, 2, 4, 5, 6, 7, 8]
    dedup_list = deduplicate_list(origin_list)
    assert dedup_list == [1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-23 14:15:23.780634
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25%', 4) == 1
    assert pct_to_int('25%', 5) == 1
    assert pct_to_int('25%', 6) == 2
    assert pct_to_int('50%', 12) == 6
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 200) == 1
    assert pct_to_int('0%', 0) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 10) == 11
    assert pct_to_int(20, 200) == 20
    assert pct_to_int('4', 3) == 4

# Generated at 2022-06-23 14:15:25.989545
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.one = 1
            self.two = 2
    data = object_to_dict(TestClass())

    assert 'one' in data and 'two' in data

# Generated at 2022-06-23 14:15:34.713878
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the function deduplicate_list with various scenarios.
    """
    assert deduplicate_list(None) == []
    assert deduplicate_list([]) == []
    assert deduplicate_list(["abc", "abc", "abc"]) == ["abc"]
    assert deduplicate_list(["abc", "abc", "xyz"]) == ["abc", "xyz"]
    assert deduplicate_list(["abc", "xyz", "abc"]) == ["abc", "xyz"]
    assert deduplicate_list(["xyz", "abc", "abc"]) == ["xyz", "abc"]

# Generated at 2022-06-23 14:15:39.506771
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['1','1','2','3','1','2','3','4','5','6','5','6','7','8','1','2','7','8',]) == ['1', '2', '3', '4', '5', '6', '7', '8']

# Generated at 2022-06-23 14:15:47.012612
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int("50%", 100, min_value=1) == 50)
    assert(pct_to_int("50", 100, min_value=1) == 50)
    assert(pct_to_int("100", 100, min_value=1) == 100)
    assert(pct_to_int("0%", 100, min_value=1) == 1)
    assert(pct_to_int("0", 100, min_value=1) == 0)



# Generated at 2022-06-23 14:15:59.112271
# Unit test for function deduplicate_list

# Generated at 2022-06-23 14:16:04.749954
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.property1 = "property1"
            self.property2 = "property2"
            self.property3 = "property3"

        def function1(self):
            pass

    expected = {'property1': "property1", 'property2': "property2", 'property3': "property3"}

    assert object_to_dict(TestObj()) == expected

# Generated at 2022-06-23 14:16:09.617036
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 1, 6, 8, 9, 12, 5, 9, 8, 14, 5, 9]
    expected = [1, 2, 3, 6, 8, 9, 12, 5, 14]
    result = deduplicate_list(test_list)

    if result != expected:
        raise ValueError("Expected {0} but got {1}".format(expected, result))


# Generated at 2022-06-23 14:16:13.143294
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list function
    """
    assert(deduplicate_list([1, 1, 2, 2, 2, 3, 2, 1, 2, 4, 5]) == [1, 2, 3, 4, 5])

# Generated at 2022-06-23 14:16:15.679890
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = ['e', 'a', 'd', 'e', 'b', 'a', 'c', 'e', 'd']
    assert deduplicate_list(list) == ['e', 'a', 'd', 'b', 'c']


# Generated at 2022-06-23 14:16:21.589795
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'd', 'b', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'd', 'b', 'e']) != ['a', 'd', 'c', 'e']

# Generated at 2022-06-23 14:16:28.771332
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 101) == 1
    assert pct_to_int('1', 101) == 1
    assert pct_to_int('1%', 101) == 1
    assert pct_to_int('101%', 101) == 101
    assert pct_to_int('50%', 101) == 50
    assert pct_to_int(51, 101) == 51
    assert pct_to_int('51', 101) == 51
    assert pct_to_int('51%', 101) == 51

# Generated at 2022-06-23 14:16:35.978664
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        var_one = 1
        var_two = 2
        var_three = 3

    result = object_to_dict(TestClass)

    assert isinstance(result, dict)
    assert result['var_one'] == 1
    assert result['var_two'] == 2
    assert result['var_three'] == 3

    result = object_to_dict(TestClass, ['var_three'])

    assert isinstance(result, dict)
    assert result['var_one'] == 1
    assert result['var_two'] == 2
    assert 'var_three' not in result

# Generated at 2022-06-23 14:16:42.028234
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 1, 1, 4, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list(['a', 'b', 'a', 'b', 'b', 'c', 'd', 'a', 'b']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 14:16:44.815440
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ["a", "b", "b", "c", "a"]
    list2 = ["a", "b", "c"]
    assert deduplicate_list(list1) == list2

# Generated at 2022-06-23 14:16:56.131350
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self, test_name='test', test_bool=None, test_int=None):
            self.test_name = test_name
            self.test_bool = test_bool
            self.test_int = test_int
    obj = TestObj()
    test_dict = object_to_dict(obj)
    assert len(test_dict) == 3
    assert test_dict['test_name'] == 'test'
    assert test_dict['test_bool'] == None
    assert test_dict['test_int'] == None

    test_dict = object_to_dict(obj, exclude=['test_name'])
    assert len(test_dict) == 2
    assert 'test_name' not in test_dict
    assert test_dict['test_bool'] == None

# Generated at 2022-06-23 14:16:59.674582
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,3,1,2,3]
    expected_out = [1,2,3]
    assert deduplicate_list(original_list) == expected_out

# Generated at 2022-06-23 14:17:02.699543
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 2, 3]
    output_list = [1, 2, 3]
    assert deduplicate_list(original_list) == output_list
