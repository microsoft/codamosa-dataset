

# Generated at 2022-06-23 14:07:08.359131
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test converting an object to a dict, and excluding certain keys
    """
    class Foo(object):
        """
        Simple class for the purpose of testing converting objects to dicts
        """
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    obj = Foo(a=1, b=2, c=3)
    assert object_to_dict(obj) == dict(a=1, b=2, c=3)
    assert object_to_dict(obj, exclude=['a']) == dict(b=2, c=3)

# Generated at 2022-06-23 14:07:19.080094
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self.test3 = 'test3'

    obj = TestObj()
    expected_result = dict(test1='test1', test2='test2', test3='test3')
    result = object_to_dict(obj)
    assert result == expected_result, (
        'Expected result: {0}, Actual result: {1}'.format(expected_result, result))

    expected_result = dict(test1='test1', test2='test2')
    result = object_to_dict(obj, ['test3'])

# Generated at 2022-06-23 14:07:22.968181
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('200%', 100) == 100

# Generated at 2022-06-23 14:07:34.511723
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Function to test deduplicate_list
    """
    import sys
    import traceback

    # Create a list to be de-duplicated
    list1 = ['a', 'b', 'c', 'a', 'd', 'e', 'f', 'e', 'g', 'e']

    # Create a function to test
    def test_function(original_list):
        """
        Function to test the function
        """
        new_list = deduplicate_list(original_list)
        print(new_list)

    # Call the function and let the user know if any exception happens
    try:
        test_function(list1)
    except Exception:
        print('Function encountered an exception:')
        print(sys.exc_info())
        print(traceback.format_exc())



# Generated at 2022-06-23 14:07:43.575431
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.prop1 = None
            self.prop2 = None

    obj = TestClass()

    obj.prop1 = 'prop1'
    obj.prop2 = 'prop2'

    obj_dict = object_to_dict(obj)

    assert 'prop1' in obj_dict
    assert 'prop2' in obj_dict
    assert obj_dict['prop1'] == 'prop1'
    assert obj_dict['prop2'] == 'prop2'

    obj_dict_exclude = object_to_dict(obj, ['prop1'])

    assert 'prop1' not in obj_dict_exclude
    assert 'prop2' in obj_dict_exclude
    assert obj_dict_exclude['prop2'] == 'prop2'


#

# Generated at 2022-06-23 14:07:50.413413
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self):
            self.test = 1
            self.test2 = 2
            self._test = 3
            self._test2 = 4

    class set_exclude:
        def __init__(self):
            self.exclude = ['test']

    assert object_to_dict(test_class()) == {'test': 1, 'test2': 2}
    assert object_to_dict(test_class(), ['test']) == {'test2': 2}
    assert object_to_dict(test_class(), set_exclude()) == {'test2': 2}

# Generated at 2022-06-23 14:07:57.274290
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        one = 1
        two = 2
        three = 3
    test = Test()
    results = object_to_dict(test)
    assert results['one'] == test.one
    assert results['two'] == test.two
    assert results['three'] == test.three

    results = object_to_dict(test, exclude=['two'])
    assert results['one'] == test.one
    assert 'two' not in results
    assert results['three'] == test.three

# Generated at 2022-06-23 14:08:01.457323
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj(object):
        def __init__(self):
            self.name = "a"
            self.age = 20
            self.jobs = ["developer", "consultant"]
    object1 = obj()
    assert object_to_dict(object1) == {'name': 'a', 'jobs': ['developer', 'consultant'], 'age': 20}


# Generated at 2022-06-23 14:08:06.421808
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test object_to_dict
    """
    class testClass():
        """
        Test class that instantiates 2 properties to test conversion
        """
        def __init__(self):
            self.name = 'test'
            self.id = '1'

        def excludeMethod(self):
            """
            Method that should be excluded
            """
            return

    test_object = testClass()
    test_dict = object_to_dict(test_object, exclude=['excludeMethod'])

    assert test_dict == {'name': 'test', 'id': '1'}

# Generated at 2022-06-23 14:08:12.922761
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'b', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list(['b', 'a', 'a', 'b']) == ['b', 'a']



# Generated at 2022-06-23 14:08:15.546013
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 20) == 1
    assert pct_to_int('1%', 20) == 1
    assert pct_to_int('%', 20) == 1
    assert pct_to_int('25%', 20) == 5
    assert pct_to_int(25, 20) == 25



# Generated at 2022-06-23 14:08:19.166216
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 5, 8, 3, 7, 8, 1]
    deduplicate_list_result = deduplicate_list(original_list)
    assert deduplicate_list_result == [1, 3, 5, 8, 7]

    original_list = ['a', 'b', 'c', 'b', 'd', 'a', 'a',]
    deduplicate_list_result = deduplicate_list(original_list)
    assert deduplicate_list_result == ['a', 'b', 'c', 'd']


# Generated at 2022-06-23 14:08:29.965567
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("15%", num_items=100) == 15
    assert pct_to_int("27%", num_items=100) == 27
    assert pct_to_int("5%", num_items=100) == 5
    assert pct_to_int("7%", num_items=100) == 7
    assert pct_to_int("3%", num_items=100) == 3
    assert pct_to_int("0%", num_items=100) == 1
    # Sanity check that the min_value works
    assert pct_to_int("10%", num_items=1000) == 10
    assert pct_to_int("10%", num_items=1000, min_value=5) == 5

# Generated at 2022-06-23 14:08:34.590864
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('125%', 100) == 100
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int('5%', 100, min_value=5) == 5
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50

# Generated at 2022-06-23 14:08:41.827002
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(60, 100) == 60
    assert pct_to_int('60%', 100) == 60
    assert pct_to_int('60%', 90) == 54
    assert pct_to_int(15, 100) == 15
    assert pct_to_int('15%', 100) == 15
    assert pct_to_int('15%', 90) == 13
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1



# Generated at 2022-06-23 14:08:46.002333
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_input = ['a', 'b', 'a', 'c', 'd', 'c', 'd', 'd', 'd', 'b']
    test_expected = ['a', 'b', 'c', 'd']
    test_output = deduplicate_list(test_input)
    assert test_output == test_expected, "Expected output of deduplicate_list() {0} but got {1}".format(test_expected, test_output)

# Generated at 2022-06-23 14:08:48.217326
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50

# Generated at 2022-06-23 14:08:52.399509
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'baz', 'foo', 'bar', 'baz', 'foo', 'fiz', 'baz']
    expected_list = ['foo', 'baz', 'bar', 'fiz']
    new_list = deduplicate_list(original_list)
    assert new_list == expected_list

# Generated at 2022-06-23 14:08:55.477729
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, test_key):
            self.test_key = test_key

    test_instance = TestClass('test_value')
    assert(object_to_dict(test_instance) == {'test_key': 'test_value'})

# Generated at 2022-06-23 14:09:00.413350
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('200%', 100) == 100
    assert pct_to_int('0', 100) == 0


# Generated at 2022-06-23 14:09:05.366258
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_before = [1, 2, 3, 2, 1, 4, 5, 4, 6, 2, 7, 2, 4, 2, 7, 2, 1]
    list_after = [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list(list_before) == list_after


# Generated at 2022-06-23 14:09:09.471727
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        a = 1
        b = 2
        c = 3

    result = object_to_dict(MyClass)

    assert result['a'] == 1
    assert result['b'] == 2
    assert result['c'] == 3



# Generated at 2022-06-23 14:09:16.425039
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'

    tc = TestClass()

    # this should give us a dict with the 2 keys
    retval = object_to_dict(tc)
    assert 'key1' in retval
    assert 'key2' in retval

    # this should exclude the given key
    exclude_list = ['key1']
    retval = object_to_dict(tc, exclude_list)
    assert 'key1' not in retval
    assert 'key2' in retval

    # this should exclude both keys
    exclude_list = ['key1', 'key2']
    retval = object_to_dict(tc, exclude_list)
    assert not retval



# Generated at 2022-06-23 14:09:22.190602
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObj(object):
        foo = 'bar'
        baz = None

    assert object_to_dict(testObj) == {'foo': 'bar'}
    assert object_to_dict(testObj, exclude=['foo']) == {}
    assert object_to_dict(testObj, exclude=['baz']) == {'foo': 'bar'}



# Generated at 2022-06-23 14:09:27.357119
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'a'

    test_o = TestClass()
    assert object_to_dict(test_o) == {'a': 'a', 'b': 'b', 'c': 'a'}
    assert object_to_dict(test_o, ['a', 'c']) == {'b': 'b'}

# Generated at 2022-06-23 14:09:31.764653
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['b', 'b', 'c', 'b']) == ['b', 'c']



# Generated at 2022-06-23 14:09:36.447003
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_to_int('20%', 100) == 20
    pct_to_int('20%', 100, min_value=10) == 20
    pct_to_int('200%', 100, min_value=10) == 100
    pct_to_int('1', 100, min_value=10) == 1
    pct_to_int('500', 100, min_value=10) == 100

# Generated at 2022-06-23 14:09:41.159736
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = [1, 3, 3, 3, 2, 1]
    output_list = [1, 3, 2]
    assert deduplicate_list(input_list) == output_list, 'Test failed.'
    print('Success: test_deduplicate_list')

# Run unit test from command line
if __name__ == '__main__':
    print('Executing unit test')
    test_deduplicate_list()

# Generated at 2022-06-23 14:09:50.790142
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        key1 = 'val1'
        key2 = 'val2'
        key3 = 'val3'

    exclude_list = ['key3']

    result = object_to_dict(TestClass, exclude_list)

    assert isinstance(result, dict)
    for k in exclude_list:
        assert k not in result
        assert hasattr(TestClass, k)

    assert len(result) == len(dir(TestClass)) - len(exclude_list)
    for k, v in result.iteritems():
        assert v == getattr(TestClass, k)

# Generated at 2022-06-23 14:09:53.082408
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(50, 100) == 50



# Generated at 2022-06-23 14:09:58.496999
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.test = "test"
            self.test2 = "test2"
            self.test_exclude = "test_exclude"

    inst = MyClass()

    assert object_to_dict(inst) == {'test': 'test', 'test2': 'test2', 'test_exclude': 'test_exclude'}

    assert object_to_dict(inst, exclude=['test_exclude']) == {'test': 'test', 'test2': 'test2'}

# Generated at 2022-06-23 14:10:01.630010
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = ["foo", "bar", "baz", "baz", "bar"]
    deduplicated_list = deduplicate_list(my_list)
    return deduplicated_list == ["foo", "bar", "baz"]

# Generated at 2022-06-23 14:10:07.924900
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('75%', 2000) == 1500
    assert pct_to_int('50%', 2000) == 1000
    assert pct_to_int(50, 2000) == 50
    assert pct_to_int('0%', 2000) == 1
    assert pct_to_int('0%', 1) == 1

# Generated at 2022-06-23 14:10:13.129327
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 3, 4, 4, 3, 3, 3, -1, -1]
    list2 = [1, 2, 3, 4, -1]
    deduped_list = deduplicate_list(list1)
    assert list2 == deduped_list

# Generated at 2022-06-23 14:10:20.464886
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        prop1 = 'property1'
        prop2 = 'property2'
        prop3 = 'property3'
        dict1 = dict((key, getattr(test, key)) for key in dir(test) if not (key.startswith('_')))
    test = Test()
    assert test.dict1 == object_to_dict(test)
    # test excluding certain keys
    assert test.dict1 == object_to_dict(test, exclude=['prop1'])
    assert test.dict1 == object_to_dict(test, exclude=['prop1', 'prop2'])
    assert test.dict1 == object_to_dict(test, exclude=['prop1', 'prop2', 'prop3'])

# Generated at 2022-06-23 14:10:31.251257
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(-50, 100) == 50
    assert pct_to_int(0, 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50.5, 100) == 50
    assert pct_to_int(50.5, 100, 30) == 50
    assert pct_to_int(30, 100, 10) == 30
    assert pct_to_int(9, 100, 10) == 10
    assert pct_to_int(10, 100, 10) == 10


# Generated at 2022-06-23 14:10:35.154438
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 100) == 10



# Generated at 2022-06-23 14:10:41.637183
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int(1,1)
    assert 1 == pct_to_int(10, 100)
    assert 1 == pct_to_int('1%', 1)
    assert 1 == pct_to_int('10%', 100)
    assert 1 == pct_to_int(2, 100, min_value=1)
    assert 2 == pct_to_int(20, 100)
    assert 2 == pct_to_int('20%', 100, min_value=1)

# Generated at 2022-06-23 14:10:48.468894
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def _test_property(self):
            pass

    obj = TestObject('test', 'test2')
    result = object_to_dict(obj)
    assert isinstance(result, dict)
    assert 'a' in result
    assert 'b' in result
    assert '_test_property' not in result

# Generated at 2022-06-23 14:10:52.362669
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('101%', 100) == 100
    assert pct_to_int('101%', 100, min_value=10) == 10

# Generated at 2022-06-23 14:11:02.929181
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyTestObj(object):
        def __init__(self):
            self.test1 = "test1"
            self.test2 = "test2"
            self._test3 = "test3"
            self.test4 = "test4"

    obj = MyTestObj()

    assert object_to_dict(obj) == {'test1': 'test1', 'test2': 'test2', 'test4': 'test4'}
    assert object_to_dict(obj, exclude=['test1']) == {'test2': 'test2', 'test4': 'test4'}
    assert object_to_dict(obj, exclude=['test1', '_test3']) == {'test2': 'test2', 'test4': 'test4'}


# Generated at 2022-06-23 14:11:06.286770
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 4, 3, 7, 5, 6, 4, 7, 6, 8, 8, 9, 0, 1, 2]) == [2, 4, 3, 7, 5, 6, 8, 9, 0, 1]

# Generated at 2022-06-23 14:11:15.632874
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = {'a': 'test_value', 'b': 10, 'c': ['list_item1', 'list_item2'], 'd': {'f': 'dict_value'}, 'e': object_to_dict, 'f': 'exclude_this'}
    assert object_to_dict(obj, exclude=['e', 'f']) == {'a': 'test_value', 'b': 10, 'c': ['list_item1', 'list_item2'], 'd': {'f': 'dict_value'}}
    # Test when exclude value is None

# Generated at 2022-06-23 14:11:19.303990
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        value1 = 1

        def __init__(self):
            self.value2 = 2

    obj = TestObject()
    obj_dict = object_to_dict(obj)

    assert 'value1' in obj_dict
    assert 'value2' in obj_dict
    assert obj_dict['value1'] == obj.value1
    assert obj_dict['value2'] == obj.value2

# Generated at 2022-06-23 14:11:26.171491
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Asserts the correct functionality of deduplicate_list.
    """
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'b', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'b', 'c', 'c', 'c', 'b', 'b', 'a', 'a']) == ['a', 'b', 'c']



# Generated at 2022-06-23 14:11:27.482882
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 200) == 100

# Generated at 2022-06-23 14:11:35.686354
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10.0%", 100) == 10
    assert pct_to_int("10,0%", 100) == 10
    assert pct_to_int("10.0%", 100, min_value=5) == 5
    assert pct_to_int("10%", 50) == 5
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 5
    assert pct_to_int(10, 50) == 5

# Generated at 2022-06-23 14:11:38.572722
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        a = '1'
        b = '2'
        c = '3'

    test = Test()
    assert object_to_dict(test) == {'a': '1', 'b': '2', 'c': '3'}
    assert object_to_dict(test, ['b']) == {'a': '1', 'c': '3'}

# Generated at 2022-06-23 14:11:42.603232
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, 0) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, 0) == 50

# Generated at 2022-06-23 14:11:50.485056
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObj(object):
        def __init__(self):
            self.param1 = True
            self.param2 = 'test'
            self.param3 = True

    myObj = testObj()
    myDict = object_to_dict(myObj)
    assert isinstance(myDict, dict)
    assert len(myDict) == 3
    assert myDict['param1'] == True
    assert myDict['param2'] == 'test'
    assert myDict['param3'] == True

# Unit tests for function pct_to_int

# Generated at 2022-06-23 14:11:55.670857
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 1, 2, 4]
    expected_output = [1, 2, 3, 4]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == expected_output

# Generated at 2022-06-23 14:12:03.732097
# Unit test for function object_to_dict
def test_object_to_dict():
    '''
    Test to ensure that object_to_dict returns the expected output
    '''
    class TestObject(object):
        '''
        test object
        '''
        test_attr1 = 'test_attr1'
        test_attr2 = 'test_attr2'
        _excluded1 = '_excluded1'

    test_object = TestObject()
    assert object_to_dict(test_object, []) == {'test_attr1': 'test_attr1', 'test_attr2': 'test_attr2', '_excluded1': '_excluded1'}
    assert object_to_dict(test_object, ['test_attr1', 'test_attr2', '_excluded1']) == {}

# Generated at 2022-06-23 14:12:13.314012
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.c = 'c'
            self.d = 'd'

    assert object_to_dict(A()) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(B()) == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    assert object_to_dict(B(), exclude=['a']) == {'b': 'b', 'c': 'c', 'd': 'd'}

# Generated at 2022-06-23 14:12:16.174979
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Tests each parameter type
        - %x
        - x%
        - x
        - 0
        - -1

    """
    assert pct_to_int('50%', 16384, 1) == 8192
    assert pct_to_int('10%', 1024, 1) == 102
    assert pct_to_int(1, 1024, 1) == 1
    assert pct_to_int(0, 1000, 1) == 1
    assert pct_to_int(-1, 1000, 1) == 1


# Generated at 2022-06-23 14:12:27.015897
# Unit test for function pct_to_int
def test_pct_to_int():

    # Test percent to int given a string
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.5%', 100) == 51

    # Test percent to int given an int
    assert pct_to_int(50, 100) == 50

    # Test percent to int given a negative int
    assert pct_to_int(-50, 100) == 50

    # Test percent to int given a percent below 1
    assert pct_to_int('0%', 100) == 1

    # Test percent to int given a percent above 100
    assert pct_to_int('101%', 100) == 101

    # Test percent to int given a float
    assert pct_to_int(0.5, 100) == 1



# Generated at 2022-06-23 14:12:35.851784
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 1000) == 500
    assert pct_to_int("100%", 1000) == 1000
    assert pct_to_int("10%", 1000) == 100
    assert pct_to_int("1%", 1000) == 10
    assert pct_to_int("50%", 1000, min_value=5) == 500
    assert pct_to_int("0%", 1000, min_value=5) == 5
    assert pct_to_int("0.5%", 1000) == 1
    assert pct_to_int("0.49%", 1000) == 1
    assert pct_to_int("0.5%", 1000, min_value=5) == 5
    assert pct_to_int("50", 1000) == 50
    assert pct_to

# Generated at 2022-06-23 14:12:44.641304
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 3, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 1, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 1, 1, 3, 3, 2, 1, 1]) == [1, 2, 3]

# Generated at 2022-06-23 14:12:50.335007
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1) == 1
    assert pct_to_int('101%', 1) == 1
    assert pct_to_int(101, 1) == 101
    assert pct_to_int(101, 1, min_value=101) == 101


# Generated at 2022-06-23 14:12:59.852891
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    assert pct_to_int('20%', num_items) == 20
    assert pct_to_int(20, num_items) == 20
    assert pct_to_int('20%', num_items, min_value=0) == 20
    assert pct_to_int(20.1, num_items) == 20
    assert pct_to_int(20.9, num_items) == 20
    assert pct_to_int('0%', num_items) == 1
    assert pct_to_int('0%', num_items, min_value=0) == 0
    assert pct_to_int(0, num_items) == 0
    assert pct_to_int('100%', num_items) == 100

# Generated at 2022-06-23 14:13:03.979030
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test value'

    test_obj = TestObject()
    converted_dict = object_to_dict(test_obj, exclude='test_key')
    assert 'test_key' not in converted_dict



# Generated at 2022-06-23 14:13:14.137674
# Unit test for function object_to_dict
def test_object_to_dict():
    import sys
    class TestCls(object):
        """Dummy class for testing object_to_dict"""
        def __init__(self, var1, var2=None):
            """Dummy init function"""
            self.var1 = var1
            self.var2 = var2

    if sys.version_info[0] >= 3:
        test_object = TestCls(var1='testing', var2='testing2')
    elif sys.version_info[0] == 2:
        test_object = TestCls('testing', 'testing2')
    test_dict = object_to_dict(test_object)
    assert isinstance(test_dict, dict)
    assert test_dict['var1'] == 'testing'
    assert test_dict['var2'] == 'testing2'


# Generated at 2022-06-23 14:13:25.942060
# Unit test for function deduplicate_list

# Generated at 2022-06-23 14:13:36.158623
# Unit test for function pct_to_int
def test_pct_to_int():
    import collections
    from ansible.module_utils.basic import AnsibleModule
    from module_utils.network.ios.ios import pct_to_int

    cases = collections.namedtuple('cases', ['input', 'output'])

    test_cases = [
        cases("1%", 1),
        cases("10%", 10),
        cases("100%", 100),
        cases("10", 10),
        cases("100", 100),
        cases("1", 1),
        cases("0%", 1),
        cases("-1%", 1),
        cases("-10%", 1),
    ]

    module = AnsibleModule(argument_spec=dict( percentage=dict(required=False, type='str'),
                                               num_items=dict(required=False, type='int')))


# Generated at 2022-06-23 14:13:41.890602
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(80, 100) == 80
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(50, 100, 10) == 50
    assert pct_to_int('50%', 100, 10) == 50
    assert pct_to_int('1%', 100, 10) == 10

# Generated at 2022-06-23 14:13:45.090299
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduped_list = deduplicate_list(['a', 'b', 'c', 'a', 'c'])
    assert deduped_list == ['a', 'b', 'c']



# Generated at 2022-06-23 14:13:53.949198
# Unit test for function pct_to_int
def test_pct_to_int():
    correct_tests = {
        1: [('1', 100, 1),
            ('1%', 100, 1),
            ('50%', 2, 1)],
        10: [('10', 100, 10),
             ('10%', 100, 10),
             ('50%', 20, 10)],
        99: [('99', 100, 99),
             ('99%', 100, 99),
             ('50%', 198, 99)]
    }

    for test, answers in correct_tests.items():
        for answer in answers:
            assert pct_to_int(*answer) == test

# Generated at 2022-06-23 14:14:02.424488
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, num_items=10) == 5
    assert pct_to_int(10, num_items=10) == 1
    assert pct_to_int(10, num_items=10, min_value=2) == 2
    assert pct_to_int('50%', num_items=10) == 5
    assert pct_to_int('10%', num_items=10) == 1
    assert pct_to_int('10%', num_items=10, min_value=2) == 2
    assert pct_to_int('101%', num_items=10) == 10
    assert pct_to_int('0%', num_items=10, min_value=2) == 2

# Generated at 2022-06-23 14:14:09.140722
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('15%', 5) == 1
    assert pct_to_int('15%', 5, min_value=0) == 0

# Generated at 2022-06-23 14:14:14.192779
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0', 100) == 1


# Generated at 2022-06-23 14:14:20.139375
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 1, 1, 1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2]) == [1, 2, 3, 4]

# Generated at 2022-06-23 14:14:25.508301
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 1
    assert pct_to_int('10', 10) == 1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 100) == 10

# Generated at 2022-06-23 14:14:31.944448
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for function object_to_dict
    """
    import json
    import re

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import pct_to_int

    result = object_to_dict(Connection(), exclude=['_play_context'])
    assert 'network_os' not in result
    assert isinstance(result['host'], string_types)
    assert isinstance(result['timeout'], int)
    assert isinstance(result['port'], int)

    data = deduplicate_list(['a', 'b', 'b', 'a', 'c'])

# Generated at 2022-06-23 14:14:36.831318
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('20%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 100

# Generated at 2022-06-23 14:14:40.192623
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 11) == 1
    assert pct_to_int('20%', 5) == 1
    assert pct_to_int(20, 5) == 4
    assert pct_to_int('30%', 6) == 2
    assert pct_to_int(30, 6) == 3

# Generated at 2022-06-23 14:14:51.316830
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("30%", 100) == 30
    assert pct_to_int("67%", 100) == 67
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(67, 100) == 67
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("100%", 100, min_value=1) == 100
    assert pct_to_int("61%", 100, min_value=1) == 61
    assert pct_to_int("0%", 100, min_value=1) == 1
    assert pct_to_int("0%", 100, min_value=2) == 2


# Generated at 2022-06-23 14:15:00.461982
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.cloudengine.ce import Entity

    class EntityTest(Entity):
        def __init__(self, **kwargs):
            super(EntityTest, self).__init__()

    e = EntityTest()
    e.name = 'name'
    e.value = 10

    out = object_to_dict(e)
    assert isinstance(out, dict)
    assert 'name' in out
    assert 'value' in out
    assert 'parent' not in out
    assert 'module' not in out
    assert out['name'] == 'name'
    assert out['value'] == 10

    out = object_to_dict(e, ['name'])
    assert isinstance(out, dict)
    assert 'name' not in out
    assert 'value' in out
    assert 'parent'

# Generated at 2022-06-23 14:15:10.631404
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int(50, 100) == 50

    assert pct_to_int("1%", 10000000) == 100000
    assert pct_to_int("1%", 10000000, min_value=0) == 0
    assert pct_to_int("50%", 10000000) == 5000000
    assert pct_to_int("1%", 10000000, min_value=1000) == 1000
    assert pct_to_int("1%", 10000000, min_value=1) == 100000
    assert pct_to_int("1%", 10000000, min_value=100000) == 100000
    assert pct_to_int("101%", 10000000) == 10100000

# Generated at 2022-06-23 14:15:14.440670
# Unit test for function object_to_dict
def test_object_to_dict():
    class temp:
        a = 1
        b = 2
        c = 3
    assert object_to_dict(temp, exclude=['a','c']) == {'b': 2}



# Generated at 2022-06-23 14:15:23.122406
# Unit test for function pct_to_int
def test_pct_to_int():
    # input values that are defined as integers
    value1 = 7
    num_items1 = 10
    assert pct_to_int(value1, num_items1) == 7
    value2 = 42
    num_items2 = 42
    assert pct_to_int(value2, num_items2) == 42
    value3 = 42
    num_items3 = 1
    assert pct_to_int(value3, num_items3) == 1
    # verify that min_value works
    value4 = 50
    num_items4 = 10
    assert pct_to_int(value4, num_items4, 5) == 5
    # verify that a string integer is converted properly
    value5 = '7'
    num_items5 = 10

# Generated at 2022-06-23 14:15:28.776606
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int(1, 100, min_value=2) == 1


# Generated at 2022-06-23 14:15:33.150163
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 2, 2, 1, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:15:36.528408
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test that converts to percentage integer
    assert pct_to_int('30%', 100) == 30
    # Test that converts to integer
    assert pct_to_int(5, 100) == 5
    # Test that converts to percentage with minimum value of 1
    assert pct_to_int('1%', 100) == 1



# Generated at 2022-06-23 14:15:45.112885
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 200) == 100
    assert pct_to_int("50%", 200) == 100
    assert pct_to_int("50.5%", 200) == 101
    assert pct_to_int("50.5%", 200, 2) ==  2
    assert pct_to_int("100.5%", 200, 2) ==  200
    assert pct_to_int("100%", 200, 2) == 200

# Generated at 2022-06-23 14:15:48.500999
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Unit test for function deduplicate_list
    :return:
    """
    old_list = [1, 2, 3, 4, 2, 1]
    new_list = [1, 2, 3, 4]
    assert deduplicate_list(old_list) == new_list

# Generated at 2022-06-23 14:15:56.050401
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    This tests the pct_to_int function.
    """
    num_items = 100
    assert pct_to_int("50%", num_items) == 50
    assert pct_to_int("100%", num_items) == 100
    assert pct_to_int("45%", num_items) == 45
    assert pct_to_int("-1%", num_items) == 1

# Generated at 2022-06-23 14:16:02.778282
# Unit test for function object_to_dict
def test_object_to_dict():
    class foo:
        def __init__(self):
            self.bar = "bar"
            self._pwet = "pwet"
            self.toto = "toto"

    a = foo()
    assert(object_to_dict(a) == dict(bar="bar", toto="toto"))
    assert(object_to_dict(a, ['toto']) == dict(bar="bar"))
    assert(object_to_dict(a, ['tata']) == dict(bar="bar", toto="toto"))


# Generated at 2022-06-23 14:16:08.896252
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        prop1 = 'foo'
        prop2 = 'bar'
        prop3 = 'foobar'

    test_instance = TestClass()

    assert object_to_dict(test_instance) == {
        'prop1': 'foo',
        'prop2': 'bar',
        'prop3': 'foobar',
    }

    assert object_to_dict(test_instance, exclude=['prop1']) == {
        'prop2': 'bar',
        'prop3': 'foobar',
    }

# Generated at 2022-06-23 14:16:17.252323
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0.5, 10) == 5
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50 %', 10) == 5
    assert pct_to_int('50  %', 10) == 5
    assert pct_to_int('50 %  ', 10) == 5
    assert pct_to_int('50  %  ', 10) == 5
    assert pct_to_int('50', 10) == 50
    assert pct_to_int('50 ', 10) == 50
    assert pct_to_int('50  ', 10) == 50
    assert pct_to_int('50   ', 10) == 50

# Generated at 2022-06-23 14:16:20.672843
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10', 10) == 10

# Generated at 2022-06-23 14:16:23.233957
# Unit test for function object_to_dict
def test_object_to_dict():
        obj = object()
        obj.test = "test"

        actual = object_to_dict(obj)
        expected = {"test": "test"}
        assert expected == actual



# Generated at 2022-06-23 14:16:31.321407
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int(50, 10)
    assert value == 5
    value = pct_to_int(40, 10)
    assert value == 4
    value = pct_to_int("40%", 10)
    assert value == 4
    value = pct_to_int("40%", 10, min_value=2)
    assert value == 2
    value = pct_to_int("10%", 10)
    assert value == 1
    value = pct_to_int("10%", 10, min_value=2)
    assert value == 2


# Generated at 2022-06-23 14:16:33.655767
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        attr1 = 'test1'
        attr2 = 'test2'

    foo_dict = object_to_dict(Foo(), exclude=['attr2'])
    assert foo_dict['attr1'] == 'test1'
    assert 'attr2' not in foo_dict



# Generated at 2022-06-23 14:16:41.702458
# Unit test for function object_to_dict
def test_object_to_dict():
    class my_obj(object):
        def __init__(self):
            self.name = 'object 1'
            self.__secret = 'I am secret'
            self._not_so_secret = 'Not so secret'

    obj = my_obj()
    exclude = []
    result = object_to_dict(obj, exclude)

    assert 'name' in result
    assert '_not_so_secret' not in result
    assert '__secret' not in result

# Generated at 2022-06-23 14:16:49.534801
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    # Check when the value is a integer
    value = '50'
    assert(pct_to_int(value, num_items) == 50)
    # Check when the value is a percentage and less than 1%
    value = '0.1%'
    assert(pct_to_int(value, num_items) == 1)
    # Check when the value is a percentage and greater than 100%
    value = '150%'
    assert(pct_to_int(value, num_items) == 150)
    # Check when the value is a percentage and less than 1% but min_value is 10
    value = '0.1%'
    assert(pct_to_int(value, num_items, 10) == 10)
    # Check when the value is a percentage and greater than 100%

# Generated at 2022-06-23 14:16:54.795674
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100.1%', 100) == 100


# Generated at 2022-06-23 14:16:59.718672
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        var1 = 'one'
        var2 = 'two'
        var3 = 'three'

    expected = dict(var1='one', var2='two', var3='three')
    actual = object_to_dict(TestObject())
    assert expected == actual

# Generated at 2022-06-23 14:17:06.595159
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int('0.9%', 10) == 1
    assert pct_to_int('0.1%', 10) == 1
    assert pct_to_int('0.05%', 10) == 1
    assert pct_to_int('0.01%', 10) == 1
    assert pct_to_int('0.001%', 10) == 1
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int('0', 10) == 0
    assert pct_to_int('1', 10) == 1
    assert pct_