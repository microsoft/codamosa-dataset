

# Generated at 2022-06-23 14:07:06.423317
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Ensures that the object_to_dict function works as expected
    """
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    original_dict = {'a': 1, 'b': 2}
    assert dict(original_dict) == object_to_dict(TestObject())

    original_dict = {'b': 2, 'a': 1}
    assert dict(original_dict) == object_to_dict(TestObject(), ['a'])

# Generated at 2022-06-23 14:07:11.013705
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import unittest

    class Test_Deduplicate_List(unittest.TestCase):

        def test_deduplicate_list(self):
            l1 = ['a', 'b', 'c', 'a', 'c', 'd']
            l2 = ['a', 'b', 'c', 'd']
            self.assertEqual(deduplicate_list(l1), l2)

    unittest.main(argv=['ignored', '-v'], exit=False)



# Generated at 2022-06-23 14:07:17.048495
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.foo = "foo1"
            self.bar = "bar1"
            self.baz = "baz1"
            self.ignore_me = "ignored"

    test_object = TestObject()
    result = object_to_dict(test_object, exclude=["ignore_me"])

    assert result == dict(foo="foo1",
                          bar="bar1",
                          baz="baz1")

# Generated at 2022-06-23 14:07:21.128657
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, prop1, prop2):
            self.prop1 = prop1
            self.prop2 = prop2

    test_obj = TestClass("test1", "test2")

    result = object_to_dict(test_obj)
    assert result['prop1'] == 'test1'
    assert result['prop2'] == 'test2'

# Generated at 2022-06-23 14:07:25.338733
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 4, 1, 2]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4]



# Generated at 2022-06-23 14:07:29.129080
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(20, 10) == 2
    assert pct_to_int('20%', 100) == 20


# Generated at 2022-06-23 14:07:31.424776
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l = ['foo', 'bar', 'baz', 'foo']
    assert deduplicate_list(l) == ['foo', 'bar', 'baz']



# Generated at 2022-06-23 14:07:37.134113
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeClass(object):
        def __init__(self):
            self.property1 = 1
            self.property2 = 2
            self.property3 = 3

        def method(self):
            return 'hey there'
    obj = SomeClass()
    obj_dict = object_to_dict(obj)
    assert 'property1' in obj_dict
    assert 'property2' in obj_dict
    assert 'property3' in obj_dict
    assert obj_dict['property1'] == 1
    assert obj_dict['property2'] == 2
    assert obj_dict['property3'] == 3



# Generated at 2022-06-23 14:07:44.541236
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 200) == 20
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 200) == 200
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('0.1%', 200) == 2
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0.5%', 200) == 1
    assert pct_to_int('0.5%', 100, min_value=10) == 10

# Generated at 2022-06-23 14:07:51.126089
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l1 = [1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 7, 6, 5, 4, 3, 2, 1]
    l2 = deduplicate_list(l1)
    assert l2 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    l3 = [0, 0, 0, 0, 0, 1, 2, 3, 1]
    l4 = deduplicate_list(l3)
    assert l4 == [0, 1, 2, 3]

# Generated at 2022-06-23 14:07:54.838802
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 3, 5, 4, 3, 7]
    deduped_list = [1, 3, 5, 4, 7]
    assert deduplicate_list(original_list) == deduped_list



# Generated at 2022-06-23 14:08:03.247816
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 3, 2, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([{'key': 'value'}, {'key': 'value'}]) == [{'key': 'value'}]

# Generated at 2022-06-23 14:08:05.828598
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a','b','c','c','b','a','d','e','e','e','f']
    expected_result = ['a','b','c','d','e','f']
    assert deduplicate_list(test_list) == expected_result


# Generated at 2022-06-23 14:08:17.154231
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [] == deduplicate_list([])
    assert [1] == deduplicate_list([1])
    assert ['a'] == deduplicate_list(['a'])
    assert ['a', 'b'] == deduplicate_list(['a', 'b'])
    assert [1,5] == deduplicate_list([1,5])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c'])
    assert [1,2,3] == deduplicate_list([1,2,3])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c'])


# Generated at 2022-06-23 14:08:27.281687
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 7, 6, 'five', 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 'five']

# Generated at 2022-06-23 14:08:34.490572
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(0.01, 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 10000) == 1000
    assert pct_to_int('99.9%', 100) == 100
    assert pct_to_int('1%', 10000) == 1, "min_value of 1 required to avoid 0"
    assert pct_to_int('1%', 100) == 1, "min_value of 1 required to avoid 0"
    assert pct_to_int('10%', 10) == 1, "min_value of 1 required to avoid 0"

# Generated at 2022-06-23 14:08:37.250867
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,1,3,2]
    assert deduplicate_list(original_list) == [1,2,3]

# Generated at 2022-06-23 14:08:42.050848
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int('20%', 100) == 20)
    assert(pct_to_int('20', 100) == 20)
    assert(pct_to_int('%', 100, min_value=7) == 7)
    assert(pct_to_int('30.5%', 100) == 31)
    assert(pct_to_int('101%', 100) == 100)

# Generated at 2022-06-23 14:08:49.510059
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 100, min_value=3) == 3
    try:
        assert pct_to_int('150%', 100) == 150
    except ValueError:
        pass  # This is expected to generate a ValueError



# Generated at 2022-06-23 14:08:57.687045
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,3,3,3,3,3,3,2,2,2,2,2,2,1,1,1]) == [1,2,3]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['1','2','3','3','3','3','3','3','3','3','3','3','2','2','2','2','2','2','1','1','1']) == ['1','2','3']


# Generated at 2022-06-23 14:09:01.267561
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'

    assert object_to_dict(TestClass()) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 14:09:08.685337
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.test = 'test'
            self.test2 = 'test2'
    assert object_to_dict(Test()) == {'test': 'test', 'test2': 'test2'}
    assert object_to_dict(Test(), exclude=['test']) == {'test2': 'test2'}
    assert object_to_dict(Test(), exclude=['missing']) == {'test': 'test', 'test2': 'test2'}


# Generated at 2022-06-23 14:09:11.682340
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(2, 3) == 2
    assert pct_to_int('-10%', 100) == 1
    assert pct_to_int('110%', 100) == 100
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0.50005%', 100) == 1



# Generated at 2022-06-23 14:09:20.047449
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [2, 3, 4, 3, 2, 6, 1, 0]
    deduplicated_list = deduplicate_list(test_list)

    # Ensure all test list items are also in deduplicated list
    assert len(set(test_list).intersection(set(deduplicated_list))) == len(set(test_list))

    # Ensure the deduplicated list doesn't have any duplicates
    assert len(set(deduplicated_list)) == len(deduplicated_list)



# Generated at 2022-06-23 14:09:28.583382
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # singletons
    assert deduplicate_list([0]) == [0]
    assert deduplicate_list([1]) == [1]
    # duplicates
    assert deduplicate_list([0, 0]) == [0]
    assert deduplicate_list([0, 0, 0]) == [0]
    assert deduplicate_list([1, 1]) == [1]
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list([0, 0, 1]) == [0, 1]
    assert deduplicate_list([1, 0, 0]) == [1, 0]
    assert deduplicate_list([0, 1, 1]) == [0, 1]

# Generated at 2022-06-23 14:09:36.846409
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("20%", num_items=10) == 2
    assert pct_to_int("20%", num_items=10, min_value=0) == 2
    assert pct_to_int("20%", num_items=5) == 1
    assert pct_to_int("20%", num_items=5, min_value=4) == 4
    assert pct_to_int("19%", num_items=5) == 1
    assert pct_to_int("0%", num_items=5) == 0
    assert pct_to_int("100%", num_items=5) == 5
    assert pct_to_int(0, num_items=5) == 0
    assert pct_to_int(2, num_items=5) == 2


# Generated at 2022-06-23 14:09:41.363308
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=0) == 0
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(100, 100) == 100

# Generated at 2022-06-23 14:09:48.385893
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['c', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a']

    expected = ['c', 'b', 'a']

    assert deduplicate_list(original_list) == expected
    assert deduplicate_list(original_list) == deduplicate_list(original_list)


# Generated at 2022-06-23 14:09:53.582714
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'foo', 'bar', 'baz', 'bar', 'foo', 'baz']
    expected_list = ['foo', 'bar', 'baz']
    deduplicated_list = deduplicate_list(original_list)

    assert expected_list == deduplicated_list, 'Failed to deduplicate list.'

# Generated at 2022-06-23 14:09:59.262998
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.attribute_1 = "This is a test"

        def test_method(self):
            return True

    obj = TestObject()
    expected_result = {'attribute_1': 'This is a test'}
    assert object_to_dict(obj) == expected_result


# Generated at 2022-06-23 14:10:04.010483
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests to make sure that the object_to_dict function works as expected
    """
    class TestClass(object):
        """
        Class that contains attributes needed for testing
        """
        def __init__(self):
            self.test = 1
            self.test2 = 2

        def test_method(self):
            """
            Method to test
            """
            pass

    assert object_to_dict(TestClass()) == {'test_method': TestClass.test_method, 'test': 1, 'test2': 2}, \
        'TestClass should be made into a dict'

    assert object_to_dict(TestClass(), exclude=['test2']) == {'test_method': TestClass.test_method, 'test': 1}, \
        'TestClass should have test2 excluded'


# Generated at 2022-06-23 14:10:15.064603
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        os = 'ios'
        model = 'csr'
        version = 15
    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert isinstance(test_dict, dict)
    assert 'os' in test_dict
    assert test_dict['os'] == 'ios'
    assert test_dict['model'] == 'csr'
    assert test_dict['version'] == 15

    test_dict = object_to_dict(test_obj, exclude=['os'])
    assert isinstance(test_dict, dict)
    assert 'os' not in test_dict
    assert test_dict['model'] == 'csr'
    assert test_dict['version'] == 15



# Generated at 2022-06-23 14:10:19.344829
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_deduplicate = ['foo', 'bar', 'baz', 'foo', 'bar', 'foo']
    deduplicated_list = deduplicate_list(list_to_deduplicate)

    assert 3 == len(deduplicated_list)
    assert 'foo' == deduplicated_list[0]
    assert 'bar' == deduplicated_list[1]
    assert 'baz' == deduplicated_list[2]

# Generated at 2022-06-23 14:10:24.043527
# Unit test for function object_to_dict
def test_object_to_dict():
    class dummy_obj:
        bar = "bar"
        baz = "qux"
        ignore = "ignore"

    result = object_to_dict(dummy_obj, exclude=['ignore'])
    assert result == {'bar': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 14:10:29.450800
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [
        'a', 'b', 'c',
        'a', 'b', 'c',
        'a', 'b', 'c',
        'a', 'b', 'c',
    ]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == ['a','b','c']


# Generated at 2022-06-23 14:10:36.763892
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """ testing object """
        def __init__(self):
            """ init """
            self.one = 'one'
            self._two = 'two'
            self.three = 'three'
    def __str__(self):
        return 'asd'
    expected_dict = {
        'one': 'one',
        'three': 'three'
    }
    test_object = TestClass()
    test_dict = object_to_dict(test_object, exclude=['_two'])
    assert test_dict == expected_dict



# Generated at 2022-06-23 14:10:41.683082
# Unit test for function object_to_dict
def test_object_to_dict():
    # Object
    class Test(object):
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'foo'

    test_obj = Test()
    test_dict = {'foo': 'bar', 'bar': 'foo'}

    assert object_to_dict(test_obj) == test_dic

# Generated at 2022-06-23 14:10:44.110095
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 4, 2, 3]) == [1, 2, 3, 4]


# Generated at 2022-06-23 14:10:49.451663
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    ANSIBLE_ARGS = namedtuple('ANSIBLE_ARGS', ['foo', 'bar'])
    args = ANSIBLE_ARGS('foo', 'bar')
    result = object_to_dict(args)
    assert(result == {'bar':'bar', 'foo':'foo'})

# Generated at 2022-06-23 14:10:52.263732
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 4, 3, 2, 1]
    new_list = [1, 2, 3, 4]
    assert deduplicate_list(original_list) == new_list

# Generated at 2022-06-23 14:10:56.079606
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test value not percentage
    assert pct_to_int(500, 1000) == 500
    # Test value percentage
    assert pct_to_int("50%", 1000) == 500

# Generated at 2022-06-23 14:10:59.045088
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 2, 4, 5, 5, 2, 6]
    deduplicate_list(test_list) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-23 14:11:01.642245
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['asdf', 'biff', 'biff', 'asdf', 'biff', 'biff', 'asdf']) == ['asdf', 'biff']



# Generated at 2022-06-23 14:11:08.072141
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test normal integer
    assert pct_to_int(5, 10) == 5

    # Test integer with % sign
    assert pct_to_int('5%', 10) == 1

    # Test float with % sign
    assert pct_to_int('2.4%', 10) == 1

    # Test float with % sign and 0.6%
    assert pct_to_int('0.6%', 10, min_value=0) == 0


# Generated at 2022-06-23 14:11:12.625819
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 2, 4, 2, 5, 2, 1, 2, 3, 2, 4, 2, 1, 2, 4]
    deduplicated_list = [1, 2, 3, 4, 5]
    assert deduplicate_list(original_list) == deduplicated_list


# Generated at 2022-06-23 14:11:16.587409
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test = 1
            self.test2 = 2
    test_instance = TestClass()
    test_dict = {'test':1, 'test2':2}
    assert object_to_dict(test_instance) == test_dict


# Generated at 2022-06-23 14:11:24.512428
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100, min_value=0) == 100
    assert pct_to_int(25, 100, min_value=10) == 25
    assert pct_to_int(10, 100) == 10
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10", 100) == 10
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 100, min_value=10) == 10
    assert pct_to_int("99%", 100) == 99

# Generated at 2022-06-23 14:11:27.636543
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int("10", 100) == 10

# Generated at 2022-06-23 14:11:38.000261
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10, 1) == 1
    assert pct_to_int('20%', 10, 1) == 2
    assert pct_to_int('30%', 10, 1) == 3
    assert pct_to_int('40%', 10, 1) == 4
    assert pct_to_int('50%', 10, 1) == 5
    assert pct_to_int('60%', 10, 1) == 6
    assert pct_to_int('70%', 10, 1) == 7
    assert pct_to_int('80%', 10, 1) == 8
    assert pct_to_int('90%', 10, 1) == 9
    assert pct_to_int('100%', 10, 1) == 10


# Generated at 2022-06-23 14:11:43.182320
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_var1 = 'test_val1'
            self.test_var2 = 'test_val2'
            self.test_var3 = ['test_val3_1', 'test_val3_2']
            self.test_var4 = False
            self.test_var5 = True
            self.test_var6 = None

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)

    assert test_dict['test_var1'] == 'test_val1'
    assert test_dict['test_var3'] == ['test_val3_1', 'test_val3_2']
    assert test_dict['test_var4'] == False

# Generated at 2022-06-23 14:11:52.451905
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test to verify the deduplicate_list function.
    """
    assert deduplicate_list([1,2,3,2,2,2,2,2,2,2,2,1,1,1,1,1,1]) == [1,2,3]
    assert deduplicate_list([1,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1]) == [1,2]
    assert deduplicate_list([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]) == [1]
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:12:01.678714
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_prop = 'test_value'
            self.test_prop2 = 'test_value2'

        def test_method(self):
            return 'test_method'
    test_object = TestClass()
    test_dict = object_to_dict(test_object)
    assert('test_prop' in test_dict)
    assert('test_prop2' in test_dict)
    assert('test_method' not in test_dict)
    test_dict = object_to_dict(test_object, exclude=['test_prop'])
    assert('test_prop' not in test_dict)
    assert('test_prop2' in test_dict)



# Generated at 2022-06-23 14:12:12.634911
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100) == 20
    assert pct_to_int('20', 100) == 20
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20.2%', 100) == 20
    assert pct_to_int('0.2%', 100) == 1
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(10, 10) == 1
    assert pct_to_int('10.2%', 10) == 1
    assert pct_to_int('10.2%', 0) == 0
    assert pct_to_int('10.2%', '0') == 0
    assert pct_to_int(0, 10000) == 0

# Generated at 2022-06-23 14:12:19.457456
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, 2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, 2) == 1
    assert pct_to_int('1%', 3) == 1
    assert pct_to_int('1%', 3, 2) == 2
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, 2) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, 2) == 50


# Generated at 2022-06-23 14:12:26.151885
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(40, 100) == 40
    assert pct_to_int('40%', 100) == 40
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(0, 100, 5) == 5
    assert pct_to_int('0%', 100, 5) == 5
    assert pct_to_int('-1%', 100, 5) == 5


# Generated at 2022-06-23 14:12:33.178201
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj:
        def __init__(self):
            self.property1 = "value1"
            self.property2 = "value2"
            self.property3 = "value3"

    test_object = Obj()
    test_dict = object_to_dict(test_object)

    assert isinstance(test_dict, dict)

    assert test_dict['property1'] == test_object.property1
    assert test_dict['property2'] == test_object.property2
    assert test_dict['property3'] == test_object.property3



# Generated at 2022-06-23 14:12:39.140529
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for function deduplicate_list
    """
    test_list = [1, 2, 3, 1, 2, 3, 1, 3, 3, 1, 2, 5]
    expected_result = [1, 2, 3, 5]
    result = deduplicate_list(test_list)
    assert result == expected_result, "result = %s, expected_result = %s" % (result, expected_result)

# Generated at 2022-06-23 14:12:45.074664
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'd', 'a', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:12:47.405776
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int(10, 1000) == 10

# Generated at 2022-06-23 14:12:55.920484
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 1000) == 100
    assert pct_to_int("2%", 1000) == 20
    assert pct_to_int("5%", 11) == 1
    assert pct_to_int("5%", 11, 2) == 2

    assert pct_to_int(100, 1000) == 100
    assert pct_to_int(20, 1000) == 20
    assert pct_to_int(5, 11) == 5
    assert pct_to_int(5, 11, 2) == 5

# Generated at 2022-06-23 14:13:04.510151
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.prop1 = 'value1'
            self.prop2 = 'value2'
    obj = TestClass()
    d = object_to_dict(obj)
    assert 'prop1' in d
    assert 'prop2' in d
    assert d['prop1'] == 'value1'
    assert d['prop2'] == 'value2'
    d = object_to_dict(obj, ['prop1'])
    assert 'prop1' not in d
    assert 'prop2' in d
    assert d['prop2'] == 'value2'


# Generated at 2022-06-23 14:13:14.553967
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('10%', 1000) == 10
    assert pct_to_int(10.5, 1000) == 10
    assert pct_to_int('10.5%', 1000) == 10
    assert pct_to_int('10.5%', 1000, min_value=0) == 10
    assert pct_to_int('10.5%', 1000, min_value=6) == 6
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('100%', 1000, min_value=6) == 6
    assert pct_to_int('0%', 1000) == 1
    assert pct_to_int('0%', 1000, min_value=6) == 6

# Generated at 2022-06-23 14:13:21.439328
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 0) == 0
    assert pct_to_int('10%', 0, min_value=100) == 100
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 0) == 0
    assert pct_to_int(10, 0, min_value=100) == 100



# Generated at 2022-06-23 14:13:29.730718
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for function object_to_dict
    """
    class TestClass(object):

        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self.test3 = 'test3'

    obj = TestClass()
    exclude_list = ['test1', 'test2']

    result_dict = object_to_dict(obj, exclude=exclude_list)
    assert result_dict['test1'] is None
    assert result_dict['test2'] is None
    assert result_dict['test3'] == 'test3'

# Generated at 2022-06-23 14:13:31.556969
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 10) == 2
    assert pct_to_int('25%', 10) == 2

# Generated at 2022-06-23 14:13:41.269110
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        attr1 = None
        attr2 = None
        __exclude__ = None

    obj = TestClass()
    obj.attr1 = "one"
    obj.attr2 = "two"
    obj.__exclude__ = "three"

    obj_attrs = object_to_dict(obj)

    assert obj_attrs['attr1'] == "one"
    assert obj_attrs['attr2'] == "two"
    assert '__exclude__' not in obj_attrs
    assert len(obj_attrs) == 2

    obj_attrs = object_to_dict(obj, ["attr1"])

    assert obj_attrs['attr2'] == "two"
    assert 'attr1' not in obj_attrs

# Generated at 2022-06-23 14:13:44.939475
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test ='test'
        other = 1
        excluded = 'excluded'
    assert object_to_dict(Test(), ['excluded']) == {'test':'test', 'other':1}


# Generated at 2022-06-23 14:13:49.744712
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = ['a', 'b', 'a', 'c', 'd', 'b', 'a', 'b', 'e']
    result = ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(sample_list) == result


# Generated at 2022-06-23 14:14:00.372788
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass:
        test_attr_1 = "test1"
        test_attr_2 = "test2"
        test_attr_3 = "test3"

    obj = DummyClass()
    new_dict = object_to_dict(obj)
    assert new_dict["test_attr_1"] == "test1"
    assert new_dict["test_attr_2"] == "test2"
    assert new_dict["test_attr_3"] == "test3"

    obj = DummyClass()
    new_dict = object_to_dict(obj, exclude=['test_attr_2'])
    assert new_dict["test_attr_1"] == "test1"
    assert "test_attr_2" not in new_dict

# Generated at 2022-06-23 14:14:05.377775
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('20%', 10, min_value=3) == 3

# Generated at 2022-06-23 14:14:15.317816
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, var1='a', var2='b', var3='c'):
            self.v1 = var1
            self.v2 = var2
            self.v3 = var3

    tc = TestClass()

    assert len(object_to_dict(tc)) == 3
    assert object_to_dict(tc)['v1'] == 'a'

    assert len(object_to_dict(tc, exclude=['v1', 'v2'])) == 1
    assert object_to_dict(tc, exclude=['v1', 'v2'])['v3'] == 'c'

# Generated at 2022-06-23 14:14:17.896893
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'b', 'b', 'c', 'd', 'd', 'd', 'a'])
    assert(result == ['a', 'b', 'c', 'd'])

# Generated at 2022-06-23 14:14:29.140523
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, id, name):
            self.id = id
            self.name = name
            self.test_attr = True
        def get_test_attr(self):
            return self.test_attr

    t = TestClass(1, 'name')
    obj_dict = object_to_dict(t)
    assert len(obj_dict) == 3
    assert obj_dict['id'] == 1
    assert obj_dict['name'] == 'name'
    assert obj_dict['test_attr'] is True

    obj_dict = object_to_dict(t, ['get_test_attr'])
    assert len(obj_dict) == 2
    assert obj_dict['id'] == 1
    assert obj_dict['name'] == 'name'

# Generated at 2022-06-23 14:14:37.708444
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0.99, 100, 1) == 99
    assert pct_to_int(0.5, 100, 1) == 50
    assert pct_to_int(0.5, 100) == 50
    assert pct_to_int('0.5%', 100, 1) == 1
    assert pct_to_int('50%', 100, 1) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50', 100, 1) == 50
    assert pct_to_int('50', 100) == 50

# Generated at 2022-06-23 14:14:43.627726
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("1%", 10) == 1
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int("0.5%", 10) == 1
    assert pct_to_int("99.9%", 10) == 10
    assert pct_to_int("99.9%", 10, min_value=0) == 9
    assert pct_to_int("0.1%", 10, min_value=0) == 1
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("0%", 10, min_value=0) == 0


# Generated at 2022-06-23 14:14:54.057422
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        a = 1
        b = 2
        c = 3
    # Testing a normal pass
    obj1 = A()
    assert object_to_dict(obj1) == dict(a=1, b=2, c=3)
    # Testing with excluding a key
    assert object_to_dict(obj1, exclude=['b']) == dict(a=1, c=3)
    # Testing with excluding multiple keys
    assert object_to_dict(obj1, exclude=['b', 'a']) == dict(c=3)
    # Testing with excluding nothing
    assert object_to_dict(obj1, exclude=[]) == dict(a=1, b=2, c=3)
    # Testing with excluding empty string

# Generated at 2022-06-23 14:14:57.358884
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [2, 3, 2, 3, 5, 9, 2, 3, 5]
    deduped_list = [2, 3, 5, 9]
    assert deduplicate_list(original_list)==deduped_list

# Generated at 2022-06-23 14:15:08.361426
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_with_dups = [
        {"name": "vlan10", "state": "active"},
        {"name": "vlan20", "state": "active"},
        {"name": "vlan20", "state": "active"},
        {"name": "vlan20", "state": "active"},
        {"name": "vlan30", "state": "active"},
    ]

    deduplicated_list = deduplicate_list(list_with_dups)
    assert deduplicated_list == [
        {"name": "vlan10", "state": "active"},
        {"name": "vlan20", "state": "active"},
        {"name": "vlan30", "state": "active"},
    ]

# Generated at 2022-06-23 14:15:17.511186
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.excluded_item = 5

    obj = TestObject()
    res = object_to_dict(obj, exclude=["excluded_item", "c"])
    assert len(res) == 3
    assert res["a"] == 1
    assert res["b"] == 2
    assert res["d"] == 4
    assert "excluded_item" not in res
    assert "c" not in res

# Generated at 2022-06-23 14:15:26.390123
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create a class object
    class testclass:
        def __init__(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self._arg2 = arg2
            self.arg3 = arg3

    # Create a class instance
    a = testclass('a', 'b', 'c')

    # Get the dictionary
    am = object_to_dict(a, ['_arg2'])
    # Ensure we get the correct value
    assert am['arg1'] == 'a'
    assert 'arg2' not in am
    assert am['arg3'] == 'c'



# Generated at 2022-06-23 14:15:34.094697
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = ['a','b','c','b','d','c','e','f','d','g','h','e','i','j','k','l','i','m','n','o','p','m','q','r','s','q','t','u','v','w','w','w','w']
    expected_list = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w']
    assert expected_list == deduplicate_list(list), 'Expected list: %s is not equal to the original list: %s' % (expected_list, list)


# Generated at 2022-06-23 14:15:45.779713
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test Percentages
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 50) == 25
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(9999, 100) == 99
    assert pct_to_int(1, 50) == 1
    assert pct_to_int(1, 3) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 50) == 25
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('0%', 100)

# Generated at 2022-06-23 14:15:48.496899
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 25) == 3
    assert pct_to_int(1, 10) == 1
    assert pct_to_int(10, 10) == 10

# Generated at 2022-06-23 14:15:56.054654
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test for deduplicate_list method fixture
    """
    dup_list = [1,1,2,2,3,3,4,4,5,5]
    exp_list = [1,2,3,4,5]
    dedup_list = deduplicate_list(dup_list)
    assert dedup_list == exp_list



# Generated at 2022-06-23 14:16:00.124016
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 40) == 20
    assert pct_to_int(50, 40) == 50
    assert pct_to_int('101%', 40) == 40
    assert pct_to_int('1%', 40) == 1



# Generated at 2022-06-23 14:16:04.391560
# Unit test for function deduplicate_list
def test_deduplicate_list():
    x = deduplicate_list([1,2,2,2,2,2,1,1,1,1,1,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3])
    assert x == [1,2,3]



# Generated at 2022-06-23 14:16:13.645480
# Unit test for function object_to_dict
def test_object_to_dict():
    import unittest
    class TestClass(object):
        attr1 = "value1"
        attr2 = "value2"

    class DeduplicateTest(unittest.TestCase):
        def test_deduplicate(self):
            self.assertEqual(deduplicate_list([1, 1, 2, 3, 2, 4, 3, 5]), [1, 2, 3, 4, 5])

    class ObjectToDictTest(unittest.TestCase):
        def test_no_exclude(self):
            self.assertEqual(object_to_dict(TestClass()), {'attr2': 'value2', 'attr1': 'value1'})


# Generated at 2022-06-23 14:16:19.783367
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['1', '2', '3']) == ['1', '2', '3']
    assert deduplicate_list(['1', '1', '1']) == ['1']
    assert deduplicate_list(['1', '2', '3', '2', '1', '2', '2']) == ['1', '2', '3']
    assert deduplicate_list(['1', '2', '2', '2', '2', '1', '2', '2']) == ['1', '2']

# Generated at 2022-06-23 14:16:21.763481
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 4, 5, 1, 4]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 14:16:24.716331
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 300) == 60
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('80', 300) == 80


# Generated at 2022-06-23 14:16:34.208906
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.string_value = 'foo'
            self.int_value = 1
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert 'string_value' in test_dict
    assert test_dict['string_value'] == 'foo'
    assert 'int_value' in test_dict
    assert test_dict['int_value'] == 1
    assert '__init__' not in test_dict
    test_dict = object_to_dict(test_obj, ['string_value'])
    assert 'string_value' not in test_dict
    assert 'int_value' in test_dict


# Generated at 2022-06-23 14:16:45.859083
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestSample(object):
        def __init__(self, test_args):
            self.a = test_args.get('a', None)
            self.b = test_args.get('b', None)
            self.c = test_args.get('c', None)
            self.d = test_args.get('d', None)

    test_args = dict(a='foo', b='bar', c='hello')
    test = TestSample(test_args)
    result = object_to_dict(test, ['b'])
    assert result['a'] == 'foo', 'Expecting object_to_dict to return right result'
    assert result['c'] == 'hello', 'Expecting object_to_dict to return right result'

# Generated at 2022-06-23 14:16:51.846579
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert(deduplicate_list([1, 2, 3, 2, 5, 1, 1, 2]) == [1, 2, 3, 5])
    assert(deduplicate_list([1, 2, 1, 1, 2, 5]) == [1, 2, 5])
    assert(deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5])

# Generated at 2022-06-23 14:16:57.212539
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self, key1, key2):
            self.key1 = key1
            self.key2 = key2

    obj = Test('value1', 'value2')
    result = object_to_dict(obj, exclude=['key2'])
    expected = {'key1': 'value1'}
    assert result == expected


# Generated at 2022-06-23 14:17:05.758948
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0.01%', 100) == 1
    assert pct_to_int('1%', 1000) == 10
    assert pct_to_int('2%', 1000) == 20
    assert pct_to_int('999%', 1000) == 999
    assert pct_to_int('99%', 1000) == 990
    assert pct_to_int('11%', 1000) == 110
    assert pct_to_int(0, 1000, min_value=10) == 10
    assert pct_to_int(0, 1000) == 1
    assert pct_to