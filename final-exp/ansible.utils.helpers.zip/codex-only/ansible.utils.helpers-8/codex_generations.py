

# Generated at 2022-06-23 14:07:08.058660
# Unit test for function object_to_dict
def test_object_to_dict():
    class test(object):
        x = 1
        y = 2
        _z = 3

    t = test()
    t_dict = object_to_dict(t, ['_z'])
    assert 'x' in t_dict
    assert 'y' in t_dict
    assert '_z' not in t_dict
    assert '_z' not in t_dict



# Generated at 2022-06-23 14:07:18.789961
# Unit test for function pct_to_int

# Generated at 2022-06-23 14:07:26.409685
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Unit-test for module helper function pct_to_int()
    '''
    assert pct_to_int('40%', 100) == 40
    assert pct_to_int('60%', 50) == 30
    assert pct_to_int('5%', 100) == 5

    assert pct_to_int(40, 100) == 40
    assert pct_to_int(60, 50) == 30
    assert pct_to_int(5, 100) == 5


# Generated at 2022-06-23 14:07:29.507802
# Unit test for function deduplicate_list
def test_deduplicate_list():
    dlist = deduplicate_list([1,2,1,3])
    assert [1,2,3] == dlist

# Generated at 2022-06-23 14:07:34.934015
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Setup list with duplicates
    test_list = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 'a', 'a', 'a', 'a', 'a', 'a']
    # Run deduplicate_list function with list as parameter
    test_output = deduplicate_list(test_list)
    # Define output and ensure list created is the same
    output = [1, 2, 3, 4, 5, 'a']
    assert test_output == output

# Generated at 2022-06-23 14:07:37.906683
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['a', 'b', 'c', 'c', 'c', 'b', 'b']
    assert deduplicate_list(list1) == ['a', 'b', 'c']


# Generated at 2022-06-23 14:07:44.098361
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'A'
            self.b = 'B'
            self.c = 'C'
    obj = Test()
    # Return all keys
    result = object_to_dict(obj)
    assert dict(result) == {'a': 'A', 'b': 'B', 'c': 'C'}
    # Return all keys, excluding 'a'
    result = object_to_dict(obj, exclude=['a'])
    assert dict(result) == {'b': 'B', 'c': 'C'}

# Generated at 2022-06-23 14:07:46.336615
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 3, 1, 3, 2, 1, 2]) == [2, 3, 1]

# Generated at 2022-06-23 14:07:51.825457
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObject:
        def __init__(self):
            self.test = 'value'
            self._hidden_key = 'hidden'
            self.equip_alt_name = 'test'

    assert object_to_dict(testObject()) == {'test': 'value', 'equip_alt_name': 'test'}
    assert object_to_dict(testObject(), exclude=['test']) == {'equip_alt_name': 'test'}



# Generated at 2022-06-23 14:07:58.464454
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        attr1 = "1"
        attr2 = "2"
        attr3 = "3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ["attr3"])
    assert 'attr1' in test_dict and test_dict['attr1'] == '1'
    assert 'attr2' in test_dict and test_dict['attr2'] == '2'
    assert not 'attr3' in test_dict

# Generated at 2022-06-23 14:08:05.297812
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 4, 3, 3, 5]
    deduplicate_list(original_list)
    assert original_list == [1, 2, 3, 4, 5]
    original_list = [1, 2, 2, 2, 2, 2, 2, 2, 3, 4, 3, 3, 5]
    deduplicate_list(original_list)
    assert original_list == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 14:08:10.914897
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Checks deduplicate_list for typical input
    """
    input_list = ['d', 'a', 'b', 'c', 'b', 'd']
    output_list = ['d', 'a', 'b', 'c']

    assert(deduplicate_list(input_list) == output_list)

# Generated at 2022-06-23 14:08:19.686632
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj1(object):
        prop1 = 'prop1'
        prop2 = 'prop2'
        prop3 = 'prop3'

        def __init__(self):
            self.instance_prop1 = 'prop1'
            self.instance_prop2 = 'prop2'

    class TestObj2(object):
        prop1 = 'prop1'
        prop2 = 'prop2'
        prop3 = 'prop3'

        def __init__(self):
            self.instance_prop1 = 'prop1'
            self.instance_prop2 = 'prop2'


# Generated at 2022-06-23 14:08:26.556400
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        bar = "baz"
        qux = "quux"

    result = object_to_dict(Foo())
    assert result == {"bar": "baz", "qux": "quux"}, "Did not get the correct output from object_to_dict"

    result = object_to_dict(Foo(), ["qux"])
    assert result == {"bar": "baz"}, "Did not get the correct output from object_to_dict"

# Generated at 2022-06-23 14:08:33.596404
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("20%", 10) == 2
    assert pct_to_int("40%", 10) == 4
    assert pct_to_int("40%", 10, min_value=5) == 5
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("100%", 10, min_value=5) == 10
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(10, 10, min_value=5) == 10

# Generated at 2022-06-23 14:08:36.551434
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 4, 2, 5]) == [1, 2, 4, 5]
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:08:39.021026
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['one', 'two', 'three', 'three', 'four', 'two', 'two']
    test_list_expected_result = ['one', 'two', 'three', 'four']
    deduplicated_list = deduplicate_list(test_list)
    assert test_list_expected_result == deduplicated_list


# Generated at 2022-06-23 14:08:43.160923
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['test1', 'test2', 'test3', 'test1', 'test4', 'test2', 'test1']
    answer = ['test1', 'test2', 'test3', 'test4']
    assert deduplicate_list(test_list) == answer


# Generated at 2022-06-23 14:08:53.186811
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(50, 100) == 50)
    assert(pct_to_int('50%', 100) == 50)
    assert(pct_to_int('50%', 100, 0) == 50)
    assert(pct_to_int('50.5%', 101) == 51)

    # Invalid cases
    assert(pct_to_int('50.5%', 101, 0) == 1)
    assert(pct_to_int('50.5%', '80') == 1)
    assert(pct_to_int('50.5%', '80', 0) == 0)
    assert(pct_to_int('50.5%', 0) == 1)
    assert(pct_to_int('50.5%', 0, 0) == 0)


# Generated at 2022-06-23 14:09:01.281013
# Unit test for function object_to_dict
def test_object_to_dict():
    # Dummy class for testing object_to_dict
    class DummyClass:
        a = 'a'
        b = 'b'
        def foo(self):
            return 'bar'
    dummy_class = DummyClass()
    output_dict = object_to_dict(dummy_class)
    assert isinstance(output_dict, dict)
    assert 'a' in output_dict
    assert 'b' in output_dict
    assert output_dict['a'] == dummy_class.a
    assert output_dict['b'] == dummy_class.b
    assert 'foo' not in output_dict
    output_dict = object_to_dict(dummy_class, ['a'])
    assert isinstance(output_dict, dict)
    assert 'a' not in output_dict
    assert 'b' in output_

# Generated at 2022-06-23 14:09:06.147801
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:09:13.204030
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self._test3 = 'test3'

    t = Test()
    res = object_to_dict(t)
    assert 'test1' in res.keys()
    assert 'test2' in res.keys()
    assert 'test3' not in res.keys()

    res = object_to_dict(t, ['test1'])
    assert 'test1' not in res.keys()
    assert 'test2' in res.keys()



# Generated at 2022-06-23 14:09:19.063178
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25%', 300) == 75
    assert pct_to_int('50.5%', 400) == 201
    assert pct_to_int('99%', 50) == 50
    assert pct_to_int(10, 200) == 10


# Generated at 2022-06-23 14:09:28.090827
# Unit test for function pct_to_int
def test_pct_to_int():
    tests = (
        ('0%', ['0', 130], 0),
        ('50%', ['0', 130], 65),
        ('50%', ['0', 129], 65),
        ('50%', ['0', 128], 64),
        ('51%', ['0', 128], 66),
        ('52%', ['0', 128], 67),
        ('96%', ['0', 128], 123),
        ('96%', ['0', 127], 123),
        ('96%', ['0', 126], 123),
        ('97%', ['0', 126], 124),
        ('96%', ['1', 128], 124),
        ('96%', ['2', 128], 125),
        ('2', ['0', 128], 2),
        ('2', ['0', 129], 2),
    )

    for test in tests:
        result = p

# Generated at 2022-06-23 14:09:36.865750
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('1', 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('50', 100, 0) == 50
    assert pct_to_int('10', 100, 0) == 10
    assert pct_to_int('1', 100, 0) == 1
    assert pct_to_int(10, 100, 0) == 10
    assert pct_to_int(1, 100, 0) == 1

# Generated at 2022-06-23 14:09:41.914238
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    f = Foo(1, 2, 3)
    d = object_to_dict(f)
    assert d == {'a': 1, 'b': 2, 'c': 3}

    d = object_to_dict(f, exclude=['a', ])
    assert d == {'b': 2, 'c': 3}

# Generated at 2022-06-23 14:09:48.500875
# Unit test for function deduplicate_list
def test_deduplicate_list():
    repeat_list = ['a', 'b', 'c', 'd', 'e', 'a', 'b', 'b', 'd', 'd', 'd', 'd', 'c', 'c', 'e']
    dedup_list = deduplicate_list(repeat_list)
    assert dedup_list == ['a', 'b', 'c', 'd', 'e']



# Generated at 2022-06-23 14:09:54.983509
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['dog', 'cat', 'dog', 'dog', 'cat']) == ['dog', 'cat']
    assert deduplicate_list(['cat', 'dog', 'dog', 'cat']) == ['cat', 'dog']
    assert deduplicate_list([1, 1, 2, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 14:10:06.269258
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_1 = pct_to_int("10%", 24)
    assert pct_1 == 2

    pct_2 = pct_to_int("5%", 24)
    assert pct_2 == 1

    pct_3 = pct_to_int("5%", 24, min_value=2)
    assert pct_3 == 2

    pct_4 = pct_to_int("95%", 24)
    assert pct_4 == 23

    pct_5 = pct_to_int("95%", 24, min_value=23)
    assert pct_5 == 23

    pct_6 = pct_to_int("200%", 24)
    assert pct_6 == 24


# Generated at 2022-06-23 14:10:12.637342
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 99) == 99
    assert pct_to_int('25 %', 99) == 25
    assert pct_to_int('25%', 99) == 25
    assert pct_to_int(25, 99) == 25
    assert pct_to_int('25', 99) == 25

# Generated at 2022-06-23 14:10:17.220547
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import pytest
    assert deduplicate_list(None) == []
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list([1, 2, 1, 2, 1, 2, 1, 2]) == [1, 2]

# Generated at 2022-06-23 14:10:26.003623
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 5) == 2
    assert pct_to_int('100%', 5) == 5
    assert pct_to_int('101%', 5) == 5
    assert pct_to_int('10.5%', 5) == 1
    assert pct_to_int(0, 5) == 0
    assert pct_to_int('0', 5) == 0
    assert pct_to_int('10', 5) == 10
    assert pct_to_int(-1, 5) == 1


# Generated at 2022-06-23 14:10:30.020024
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 4, 2, 1, 3, 5, 4, 1, 4, 5, 3, 3, 2, 5, 1, 4]
    expected_list = [1, 4, 2, 3, 5]
    assert deduplicate_list(sample_list) == expected_list

# Generated at 2022-06-23 14:10:35.097531
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test for function deduplicate_list
    """
    assert [1, 2, 3] == deduplicate_list([1, 2, 2, 3, 1])
    assert [] == deduplicate_list([])
    assert None == deduplicate_list(None)
    assert [1] == deduplicate_list([1])

# Generated at 2022-06-23 14:10:38.816246
# Unit test for function object_to_dict
def test_object_to_dict():
    class ModTest:
        def __init__(self):
            self.a = "b"
            self.c = "d"
            self.e = "f"
    mod_obj = ModTest()
    assert(object_to_dict(mod_obj)["a"] == "b")

# Generated at 2022-06-23 14:10:44.402238
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Verifies if function deduplicate_list works as expected
    """
    assert deduplicate_list(['a', 'b', 'c', 'd', 'a', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['d', 'c', 'b', 'c', 'a', 'c', 'a', 'a']) == ['d', 'c', 'b', 'a']
    assert deduplicate_list(['c', 'c', 'c', 'c', 'c', 'c', 'c', 'c']) == ['c']


# Generated at 2022-06-23 14:10:50.628037
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_key1 = "test_val1"
        test_key2 = "test_val2"

    assert object_to_dict(TestClass()) == {"test_key1": "test_val1", "test_key2": "test_val2"}
    assert object_to_dict(TestClass(), ["test_key1"]) == {"test_key2": "test_val2"}


# Generated at 2022-06-23 14:10:57.621477
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass():
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4

    obj = MyClass()

    dict_obj = object_to_dict(obj, exclude=["b"])

    assert dict_obj['a'] == 1
    assert dict_obj['b'] is None
    assert dict_obj['c'] == 3
    assert dict_obj['d'] == 4

# Generated at 2022-06-23 14:11:01.671137
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    TestObject = namedtuple('TestObject', ['prop1', 'prop2', '_hidden_prop'])
    obj = TestObject('prop1', 'prop2', 'should not be included')
    result = object_to_dict(obj)
    assert result['prop1'] == 'prop1'
    assert result['prop2'] == 'prop2'
    assert '_hidden_prop' not in result


# Generated at 2022-06-23 14:11:06.077654
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    o = TestObject()
    result = object_to_dict(o)
    keys = ['a', 'c', 'b']
    for key in keys:
        assert key in result



# Generated at 2022-06-23 14:11:14.792222
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.5%', 100) == 50
    assert pct_to_int('50%', 50) == 25
    assert pct_to_int('50%', 25) == 12
    assert pct_to_int('50%', 25, 5) == 5
    assert pct_to_int('54%', 25, 5) == 5
    assert pct_to_int(54, 25, 5) == 5
    assert pct_to_int(54, 25) == 13
    assert pct_to_int(50, 25) == 12
    assert pct_to_int(5, 25) == 1

# Generated at 2022-06-23 14:11:20.050506
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3, 5, 4, 1, 5]) == [1, 2, 3, 5, 4]
    assert deduplicate_list([1, 1, 2, 2, 3, 5, 4, 1, 5], unique=False) == [1, 2, 3, 5, 4, 1, 5]



# Generated at 2022-06-23 14:11:29.074318
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100) == 20
    assert pct_to_int(80, 100) == 80
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=0) == 10
    assert pct_to_int(10, 100, min_value=1) == 10
    assert pct_to_int(10, 100, min_value=4) == 4
    assert pct_to_int(10, 100, min_value=9) == 9
    assert pct_to_int(10, 100, min_value=10) == 10
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('80%', 100) == 80
    assert pct_to_

# Generated at 2022-06-23 14:11:32.662909
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input = ['foo', 'bar', 'foo', 'baz', 'qux', 'bar', 'qux']
    assert deduplicate_list(input) == ['foo', 'bar', 'baz', 'qux']

# Generated at 2022-06-23 14:11:35.771232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "a", "b", "a", "c"]) == ["a", "b", "c"]
    assert deduplicate_list([1, 2, 2, 1]) == [1, 2]

# Generated at 2022-06-23 14:11:42.604400
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create a generic class with various attributes and methods
    class Class1(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'

        def method1(self):
            return 'm1'

        def method2(self):
            return 'm2'
    test_obj = Class1(1, 2)

    class_dict = object_to_dict(test_obj)
    assert class_dict['a'] == 1
    assert class_dict['b'] == 2
    assert class_dict['c'] == 'c'
    assert class_dict['d'] == 'd'
    assert class_dict['e'] == 'e'

# Generated at 2022-06-23 14:11:51.047763
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj(object):
        def __init__(self):
            self.test1 = "test1"
            self.test2 = "test2"
            self.test3 = "test3"
        def test(self):
            return "test"
    test = test_obj()
    assert object_to_dict(test, exclude=['test2']) == {'test1': 'test1', 'test3': 'test3'}
    assert object_to_dict(test) == {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}


# Generated at 2022-06-23 14:11:59.247173
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 500) == 250
    assert pct_to_int("0%", 500) == 1
    assert pct_to_int("-50%", 500) == 1
    assert pct_to_int("150%", 500) == 500
    assert pct_to_int(250, 500) == 250
    assert pct_to_int(0, 500) == 1
    assert pct_to_int(-50, 500) == 1
    assert pct_to_int(150, 500) == 150

# Generated at 2022-06-23 14:12:06.546550
# Unit test for function object_to_dict
def test_object_to_dict():
    """ function_utils.object_to_dict: returning dict of attributes/properties """
    class Obj(object):
        def __init__(self):
            self.arg = 'val'
    myobj = Obj()
    result = object_to_dict(myobj)
    assert 'arg' in result
    assert result['arg'] == 'val'
    result = object_to_dict(myobj, exclude=['arg'])
    assert 'arg' not in result

# Generated at 2022-06-23 14:12:16.295185
# Unit test for function deduplicate_list
def test_deduplicate_list():

    # Check if the list is kept in the same order
    deduplicated_list = deduplicate_list([1, 2, 1, 3])
    assert deduplicated_list == [1, 2, 3]

    deduplicated_list = deduplicate_list([1, 2, 1, 2, 3])
    assert deduplicated_list == [1, 2, 3]

    deduplicated_list = deduplicate_list([1, 2, 3, 1, 3, 3])
    assert deduplicated_list == [1, 2, 3]

    # Check if duplicates are removed properly
    deduplicated_list = deduplicate_list([1, 1, 2, 1, 2, 3])
    assert deduplicated_list == [1, 2, 3]

    ded

# Generated at 2022-06-23 14:12:22.283749
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100, 1) == 5
    assert pct_to_int('', 100, 1) == 1
    assert pct_to_int(None, 100, 1) == 1
    assert pct_to_int('0%', 100, 1) == 1


# Generated at 2022-06-23 14:12:29.581043
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("30%", 100) == 30
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("100%", 10, min_value=10) == 10
    assert pct_to_int("100%", 10, min_value=5) == 5
    assert pct_to_int("101%", 10) == 10
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("-1%", 10) == 1

# Generated at 2022-06-23 14:12:37.075556
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self._key3 = 'value3'

        def __str__(self):
            return 'test_obj'

    obj = TestObj()

    # Test without excluding any properties
    obj_dict = object_to_dict(obj)
    assert 'key1' in obj_dict
    assert obj_dict['key1'] == 'value1'
    assert 'key2' in obj_dict
    assert obj_dict['key2'] == 'value2'
    assert '_key3' not in obj_dict

    # Test excluding keys
    obj_dict = object_to_dict(obj, exclude=['key1'])
    assert 'key1' not in obj_dict

# Generated at 2022-06-23 14:12:43.362227
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list1 = ['test1', 'test2', 'test1']
    test_list2 = ['test1', 'test1', 'test2', 'test2', 'test2', 'test2']
    expected_list1 = ['test1', 'test2']
    expected_list2 = ['test1', 'test2']

    assert deduplicate_list(test_list1) == expected_list1
    assert deduplicate_list(test_list2) == expected_list2

# Generated at 2022-06-23 14:12:50.748425
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self, obj_name='TestObj', obj_descr='Test Object Description'):
            self.name = obj_name
            self.descr = obj_descr

        def __str__(self):
            return self.name

    test_obj = TestObj()
    obj_dict = object_to_dict(test_obj)
    assert obj_dict['name'] == "TestObj"
    assert obj_dict['descr'] == "Test Object Description"
    assert len(obj_dict) == 2



# Generated at 2022-06-23 14:13:00.125942
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("100", 100) == 100

    assert pct_to_int("0%", 100, min_value=100) == 100
    assert pct_to_int("-1%", 100, min_value=100) == 100
    assert pct_to_int("-1", 100, min_value=100) == 100
    assert pct_to_int("100%", 100, min_value=100) == 100
    assert pct_to_int("100", 100, min_value=100) == 100

# Generated at 2022-06-23 14:13:08.901161
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 4, 4, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([4, 4, 4, 4, 3, 3, 3, 2, 2, 1]) == [4, 3, 2, 1]
    assert deduplicate_list(['b', 'c', 'c', 'd', 'd', 'd', 'e', 'e', 'e', 'e']) == ['b', 'c', 'd', 'e']
    assert deduplicate_list(['a', 'b', 'c', 'd', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:13:12.801910
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'c', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list([1, 1, 2, 3, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:13:21.094960
# Unit test for function deduplicate_list
def test_deduplicate_list():
    example1 = ['a', 'b', 'b', 'c']
    expected1 = ['a', 'b', 'c']
    example2 = ['c', 'b', 'c', 'a']
    expected2 = ['c', 'b', 'a']
    example3 = ['b', 'a', 'b', 'c']
    expected3 = ['b', 'a', 'c']

    assert deduplicate_list(example1) == expected1
    assert deduplicate_list(example2) == expected2
    assert deduplicate_list(example3) == expected3

# Generated at 2022-06-23 14:13:30.119887
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.var1 = "var1"
            self.var2 = "var2"
            self.var3 = "var3"

    result = object_to_dict(TestClass())
    assert result['var1'] == TestClass().var1
    assert result['var2'] == TestClass().var2
    assert result['var3'] == TestClass().var3

    result_exclude_var2 = object_to_dict(TestClass(), exclude=['var2'])
    assert result_exclude_var2 == {'var1': 'var1', 'var3': 'var3'}



# Generated at 2022-06-23 14:13:37.551025
# Unit test for function pct_to_int
def test_pct_to_int():
    from ansible.module_utils import basic
    import sys

    def test_generic_usage():
        # Basic validation.
        basic.assert_equals(pct_to_int('20%', 100), 20)
        basic.assert_equals(pct_to_int(20, 100), 20)

        # Check rounding.
        basic.assert_equals(pct_to_int('20.5%', 100), 21)
        basic.assert_equals(pct_to_int(20.5, 100), 20)

        # Check edge-case rounding.
        basic.assert_equals(pct_to_int('100.5%', 100), 101)
        basic.assert_equals(pct_to_int(100.5, 100), 100)

        # Check that numbers are rounded up, even if

# Generated at 2022-06-23 14:13:48.363351
# Unit test for function object_to_dict
def test_object_to_dict():
    class Example:
        def __init__(self):
            self.key1 = 'val1'
            self.key2 = 'val2'
            self.key3 = 'val3'

    example_dict = object_to_dict(Example())

    assert 'key1' in example_dict
    assert 'key2' in example_dict
    assert 'key3' in example_dict

    '''
    Exclude is passed as a list, even if there is only one value to exclude
    '''
    example_dict_exclude = object_to_dict(Example(), exclude=['key1'])

    assert 'key1' not in example_dict_exclude
    assert 'key2' in example_dict_exclude
    assert 'key3' in example_dict_exclude

# Generated at 2022-06-23 14:13:58.595974
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['test']) == ['test']
    assert deduplicate_list(['test', 'test2', 'test3']) == ['test', 'test2', 'test3']
    assert deduplicate_list(['test', 'test', 'test3']) == ['test', 'test3']
    assert deduplicate_list(['test', 'test', 'test']) == ['test']
    assert deduplicate_list(['test', 'test2', 'test2', 'test', 'test', 'test', 'test3']) == ['test', 'test2', 'test3']



# Generated at 2022-06-23 14:14:00.968467
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['hello', 'world', 'hello', 'universe', 'world']) == ['hello', 'world', 'universe']

# Generated at 2022-06-23 14:14:05.515521
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('150%', 100) == 150
    assert pct_to_int(150, 100) == 150

# Generated at 2022-06-23 14:14:15.726236
# Unit test for function object_to_dict
def test_object_to_dict():
    class CHILD:
        attr = 'child'

    class Example(object):
        def __init__(self):
            pass

        attr = 'root'
        child = CHILD()
        child2 = CHILD()

    example = Example()
    result = object_to_dict(example)
    assert type(result) is dict
    assert result['attr'] == 'root'
    assert result['child'].attr == 'child'
    assert result['child2'].attr == 'child'

    result = object_to_dict(example, exclude=['attr'])
    assert type(result) is dict
    assert not 'attr' in result


# Generated at 2022-06-23 14:14:21.053635
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'foo', 'baz', 'bar', 'foo']
    expected_list = ['foo', 'bar', 'baz']
    returned_list = deduplicate_list(original_list)

    if original_list != returned_list:
        assert True
    elif expected_list != returned_list:
        assert False



# Generated at 2022-06-23 14:14:26.984924
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.attr1 = 'attr1'
            self.attr2 = 'attr2'

    test_obj = TestClass()
    test_obj.custom = 'custom'
    result = {'attr1': 'attr1', 'attr2': 'attr2', 'custom': 'custom'}
    assert object_to_dict(test_obj) == result

# Generated at 2022-06-23 14:14:32.513039
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50", 1000) == 500
    assert pct_to_int(50, 1000) == 50
    assert pct_to_int("150%", 1000) == 1500
    assert pct_to_int(150, 1000) == 150
    assert pct_to_int("0%", 1000) == 1

# Generated at 2022-06-23 14:14:35.164910
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests deduplicate_list function.
    """
    test_dlist = [0, 1, 3, 3, 5, 4, 4, 2, 1]
    assert deduplicate_list(test_dlist) == [0, 1, 3, 5, 4, 2]

# Generated at 2022-06-23 14:14:37.748550
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('40%', 8) == 4
    assert pct_to_int('110%', 6) == 6
    assert pct_to_int(60, 6) == 6

# Generated at 2022-06-23 14:14:43.830606
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 100) == 5
    assert pct_to_int("5%", 100, min_value=0) == 5
    assert pct_to_int("5%", 0, min_value=0) == 0
    assert pct_to_int("5%", 0, min_value=1) == 1
    assert pct_to_int("200%", 0, min_value=1) == 1
    assert pct_to_int("200%", 100, min_value=1) == 1
    assert pct_to_int("1", 20) == 1
    assert pct_to_int("1", 20, min_value=0) == 1
    assert pct_to_int("1", 0, min_value=0) == 0
    assert pct_to_

# Generated at 2022-06-23 14:14:53.836476
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Verify that duplicates are removed from a list without changing
    the order of the original list.
    """
    assert deduplicate_list(['a', 'c', 'b']) == ['a', 'c', 'b']
    assert deduplicate_list(['a', 'c', 'c', 'b']) == ['a', 'c', 'b']
    assert deduplicate_list(['a', 'c', 'c', 'c', 'b']) == ['a', 'c', 'b']
    assert deduplicate_list(['c', 'c', 'c', 'a', 'b']) == ['c', 'a', 'b']
    assert deduplicate_list(['c', 'c', 'c']) == ['c']

# Generated at 2022-06-23 14:15:00.813616
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        a = 1
        b = 2
        c = 3
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass(1, 2, 3)
    assert test_obj.a == 1
    assert test_obj.b == 2
    assert test_obj.c == 3

    test_dict = object_to_dict(test_obj, ['b'])
    assert test_dict['a'] == 1
    assert test_dict['c'] == 3
    assert 'b' not in test_dict

# Generated at 2022-06-23 14:15:06.928232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['foo', 'bar', 'baz', 'foo', 'foo', 'foo']
    assert deduplicate_list(list1) == ['foo', 'bar', 'baz']
    
    list2 = ['1', '2', '3', 1, 2, 3, 4, '1']
    assert deduplicate_list(list2) == ['1', '2', '3', 4]

# Generated at 2022-06-23 14:15:13.375138
# Unit test for function object_to_dict
def test_object_to_dict():
    class C(object):
        def __init__(self, name, **kwargs):
            self.name = name
            self.__dict__.update(kwargs)

    exclude = ['b']
    obj = C(name='C', a=1, b=2, c=3)

    result = object_to_dict(obj, exclude)

    assert(set(result.keys()) == {'a', 'c', 'name'})
    assert(result.get('a') == 1)
    assert(result.get('b') is None)
    assert(result.get('c') == 3)
    assert(result.get('name') == 'C')

# Generated at 2022-06-23 14:15:16.519076
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        x = 1
        y = 2
    foo = Foo()
    assert object_to_dict(foo) == {'x': 1, 'y': 2}

# Generated at 2022-06-23 14:15:22.858143
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        test1 = 1
        test2 = 2

    t = TestObj()
    result = object_to_dict(t)
    assert isinstance(result, dict)
    assert 'test1' in result
    assert 'test2' in result
    assert result['test1'] == 1
    assert result['test2'] == 2

# Generated at 2022-06-23 14:15:26.203553
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = ['a', 'a', 'b', 'c', 'd', 'a', 'c']
    expected_list = ['a', 'b', 'c', 'd']
    new_list = deduplicate_list(list)
    assert new_list == expected_list



# Generated at 2022-06-23 14:15:33.273427
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        property1 = True
        property2 = 1
        property3 = 2

    obj = Object()
    d = object_to_dict(obj)
    assert d['property1'] is True
    assert d['property2'] == 1
    assert d['property3'] == 2
    assert len(d) == 3

    d = object_to_dict(obj, ['property1'])
    assert 'property1' not in d



# Generated at 2022-06-23 14:15:36.614254
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['dog', 'dog', 'cat', 'cat', 'bird']) == ['dog', 'cat', 'bird']
    assert deduplicate_list(['dog', 'dog', 'cat', 'cat', 'bird', 'snake', 'bird', 'bird']) == ['dog', 'cat', 'bird', 'snake']

# Generated at 2022-06-23 14:15:44.034069
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 2, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 3, 2, 3, 1, 2]) == [1, 3, 2]
    assert deduplicate_list([1, 1, 1]) == [1]

# Generated at 2022-06-23 14:15:48.034313
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'a', 'c', 'b', 'd']
    test_deduped_list = deduplicate_list(test_list)
    assert test_deduped_list == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 14:15:54.684583
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        pass

    obj = TestClass()
    obj.a = "a"
    obj.b = "b"

    assert object_to_dict(obj) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(obj, exclude=['a']) == {'b': 'b'}

# Generated at 2022-06-23 14:15:59.627029
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('105', 100) == 105
    assert pct_to_int('10%', 100, 2) == 2
    assert pct_to_int('2%', 100, 2) == 2

# Generated at 2022-06-23 14:16:07.757675
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 1000) == 50
    assert pct_to_int('500%', 100) == 50
    assert pct_to_int('5%', 100, 10) == 10
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 1000) == 50
    assert pct_to_int(500, 100) == 50
    assert pct_to_int(5, 100, 10) == 10



# Generated at 2022-06-23 14:16:16.427401
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.inner = TestObject()
            self.inner_list = [TestObject(), TestObject()]
    obj = TestObject()
    obj_dict = object_to_dict(obj)

# Generated at 2022-06-23 14:16:23.649348
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests the object_to_dict function
    """
    class Test(object):
        def __init__(self):
            self.foo = 1
            self.bar = 1
            self.ansible = 1
            self._ansible_module = 1
            self._ansible_module_exclude = 1

    test = Test()
    assert object_to_dict(test) == {'foo': 1, 'bar': 1, 'ansible': 1}



# Generated at 2022-06-23 14:16:29.434405
# Unit test for function object_to_dict
def test_object_to_dict():
    class test:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    t = test()
    assert object_to_dict(t) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(t, exclude=['c']) == {'a': 1, 'b': 2}

# Generated at 2022-06-23 14:16:31.174651
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 1, 2]) == [1, 2, 3]

# Generated at 2022-06-23 14:16:35.337057
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('60%', 1000) == 600
    assert pct_to_int('60%', 1000, min_value=10) == 600
    assert pct_to_int('10%', 1000, min_value=10) == 10


# Generated at 2022-06-23 14:16:42.392338
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

        def test(self):
            pass

    t = Test()
    y = object_to_dict(t, ['test'])
    assert 'a' in y
    assert 'b' in y
    assert 'c' in y
    assert 'test' not in y


# Generated at 2022-06-23 14:16:49.509680
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj():
        def __init__(self):
            self.property_1 = 'val1'
            self.property_2 = 'val2'
            return None

    test_obj = TestObj()

    # Test that the method returns a dictionary
    assert isinstance(object_to_dict(test_obj), dict)

    test_dict = object_to_dict(test_obj)
    # Test that the keys are the object properties
    assert set(['property_1', 'property_2']) == set(
        test_dict.keys())

    # Test that the keys are the object properties
    assert test_dict['property_1'] == 'val1'
    assert test_dict['property_2'] == 'val2'



# Generated at 2022-06-23 14:16:52.309516
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo():
        def __init__(self):
            pass

    foo = Foo()
    foo.test = 'test'
    foo.test2 = 'test2'
    d = object_to_dict(foo)
    assert d.has_key('test')
    assert d.has_key('test2')
    assert not d.has_key('_exclude')


# Generated at 2022-06-23 14:16:56.416905
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key1 = 'test_value1'
            self._test_key2 = 'test_value2'

        def get_test_key3(self):
            return 'test_value3'

    test_obj = TestClass()
    result = object_to_dict(test_obj)
    assert result['test_key1'] == test_obj.test_key1
    assert '_test_key2' not in result
    assert result['get_test_key3'] == test_obj.get_test_key3()


# Generated at 2022-06-23 14:17:04.983109
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(1000, 100) == 100
    assert pct_to_int('1000%', 100) == 100
    assert pct_to_int(0, 100) == 0
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int(0, 100, min_value=10) == 10
    assert pct_to_int('0%', 100, min_value=10) == 10

