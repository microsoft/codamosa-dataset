

# Generated at 2022-06-23 14:07:05.027969
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test object
    class TestObject(object):
        var1 = 'test1'
        var2 = 'test2'
        var3 = 'test3'
        exclude1 = 'test4'

        def __init__(self):
            pass

    # Init test object
    test_obj = TestObject()

    # Check to make sure dict is generated properly
    assert object_to_dict(test_obj) == {'var1': 'test1', 'var2': 'test2', 'var3': 'test3'}
    assert object_to_dict(test_obj, exclude=['exclude1']) == {'var1': 'test1', 'var2': 'test2', 'var3': 'test3'}

    # Check that the exclude parameter works

# Generated at 2022-06-23 14:07:07.819633
# Unit test for function deduplicate_list
def test_deduplicate_list():
    x = [1, 4, 2, 5, 6, 8, 4, 5, 4]
    assert deduplicate_list(x) == [1,4,2,5,6,8]



# Generated at 2022-06-23 14:07:17.326845
# Unit test for function object_to_dict
def test_object_to_dict():
    class testclass(object):
        def __init__(self):
            self.A = 'IAmA'
            self.B = 'IAmB'
            self.C = 'IAmC'

        def D(self):
            return "SillyMethod"

    assert object_to_dict(testclass()) == {'A': 'IAmA', 'C': 'IAmC', 'B': 'IAmB'}
    assert object_to_dict(testclass(), exclude=['A']) == {'C': 'IAmC', 'B': 'IAmB'}
    assert object_to_dict(testclass(), exclude=['A', 'C']) == {'B': 'IAmB'}

# Generated at 2022-06-23 14:07:20.034821
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('test', (object, ), {'a': 1, 'b': 2})()
    assert object_to_dict(obj, exclude=['b']) == {'a': 1}

# Generated at 2022-06-23 14:07:22.364860
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10

# Generated at 2022-06-23 14:07:29.899868
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        def __init__(self):
            self.valid_property = None
            self._pvt_property = None
            self.other = None
    obj = Object()
    obj.valid_property = "valid"
    obj._pvt_property = "invalid"
    obj.other = "other"
    assert object_to_dict(obj) == dict(valid_property="valid", other="other")

# Generated at 2022-06-23 14:07:34.102236
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests that object_to_dict returns a dict
    """
    o = object()
    o.foo = 'foo'
    o.bar = 'bar'
    o.baz = 'baz'
    d = object_to_dict(o, ['bar'])

    assert(d == {'foo': 'foo', 'baz': 'baz'})



# Generated at 2022-06-23 14:07:41.611268
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 11) == 1
    assert pct_to_int('10%', 11, 2) == 2
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(10, 11) == 10
    assert pct_to_int(10, 11, 2) == 10


# Generated at 2022-06-23 14:07:47.098716
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObj(object):
        a_property = 1
        another_property = 2
        a_third_property = 3

    obj = MyObj()
    result = object_to_dict(obj)
    assert result == {'a_property': 1, 'another_property': 2, 'a_third_property': 3}
    assert 'a_third_property' in result
    assert 'not_a_property' not in result



# Generated at 2022-06-23 14:07:52.409590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert not deduplicate_list(None)

    assert [1, 2, 3] == deduplicate_list([1, 2, 3])
    assert [1, 2] == deduplicate_list([1, 2, 1, 2])
    assert [1, 2, 3, 4] == deduplicate_list([1, 2, 3, 4])
    assert [1, 2, 3, 4] == deduplicate_list([1, 2, 3, 4, 3, 2, 1])



# Generated at 2022-06-23 14:07:57.004210
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['1', '2', '3', '2', '1', '2']) == ['1', '2', '3']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['1', 1, '1']) == ['1', 1]

# Generated at 2022-06-23 14:08:04.029059
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 5, 4, 5]) == [1, 2, 3, 5, 4]
    assert deduplicate_list([1, 1, 1, 2, 3, 2, 5, 4, 5]) == [1, 2, 3, 5, 4]

# Generated at 2022-06-23 14:08:07.996363
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self):
            self.a = "a"
            self._b = "b"
            self.c = "c"

    test_obj = test_class()
    assert object_to_dict(test_obj) == {"a": "a", "c": "c"}


# Generated at 2022-06-23 14:08:18.199758
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module_result = []
    for test in (('a', 'a'), ('a', 'a', 'b', 'c', 'b'), ('a', 'a', 'b', 'c', 'd', 'd', 'e')):
        result = deduplicate_list(test)
        module_result.append(result)
        if result != list(set(test)):
            module.exit_json(changed=False, msg="Deduplicate List Failed", src=test, result=result)

    module.exit_json(changed=False, msg="All tests Passed", result=module_result)


# Generated at 2022-06-23 14:08:24.861432
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('110%', 100) == 100
    assert pct_to_int(.5, 100) == 50
    assert pct_to_int(5, 10) == 5
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int(.5, 10) == 5

# Generated at 2022-06-23 14:08:28.846113
# Unit test for function pct_to_int
def test_pct_to_int():

    assert pct_to_int('50%', 10) == 5
    assert pct_to_int(50, 10) == 50
    assert pct_to_int('50', 10) == 50
    assert pct_to_int('50%', 6) == 3



# Generated at 2022-06-23 14:08:30.177809
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100, 10) == 50

# Generated at 2022-06-23 14:08:33.957094
# Unit test for function pct_to_int
def test_pct_to_int():
    foo = [('10%', 10), ('30%', 30), ('0%', 1), ('17%', 17), ('x', 0)]
    for x in foo:
        y = pct_to_int(x[0], 100)
        print('asserting {} == {}'.format(y, x[1]))
        assert y == x[1]

# Generated at 2022-06-23 14:08:36.601034
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'bar', 'foo', 'bar']) == ['foo', 'bar']


# Generated at 2022-06-23 14:08:41.091163
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 50) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('209%', 10) == 10
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('10', 10) == 10
    assert pct_to_int('0', 10) == 10
    assert pct_to_int(0, 10) == 1
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(20, 10) == 10
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 50) == 50
    assert pct_to_int(100, 40) == 40

# Unit

# Generated at 2022-06-23 14:08:46.204008
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        """
        Test class to test the object_to_dict function
        """

        def __init__(self):
            self.foo = "foo"
            self.bar = "bar"

    assert object_to_dict(TestClass()) == {'bar': 'bar', 'foo': 'foo'}



# Generated at 2022-06-23 14:08:53.333634
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 4, 3, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:08:55.278827
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([3, 1, 2, 3, 4, 2, 3, 1]) == [3, 1, 2, 4]

# Generated at 2022-06-23 14:09:00.817670
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass(object):
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar
            self.baz = 100

    dummy_obj = DummyClass(foo='hello', bar='world')
    obj_dict = object_to_dict(dummy_obj)

    assert obj_dict['foo'] == 'hello'
    assert obj_dict['bar'] == 'world'
    assert obj_dict['baz'] == 100
    assert '__module__' not in obj_dict

# Generated at 2022-06-23 14:09:08.097779
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 100) == 0
    assert pct_to_int('0', 100) == 0
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 1000) == 1000

# Generated at 2022-06-23 14:09:15.128715
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicated_list = deduplicate_list(['b','b','c','a','a','d','a','e','c','b','d','b','f','e','g','b','a','a'])
    print(deduplicated_list)
    if deduplicated_list[0] == 'b' and deduplicated_list[1] == 'c' and deduplicated_list[2] == 'a' and deduplicated_list[3] == 'd' and deduplicated_list[4] == 'e' and deduplicated_list[5] == 'f' and deduplicated_list[6] == 'g':
        print('Unit test passed')

# Generated at 2022-06-23 14:09:25.194409
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["dog", "cat", "dog"]) == ["dog", "cat"]
    assert deduplicate_list(["dog", "cat", "cat"]) == ["dog", "cat"]
    assert deduplicate_list(["dog", "cat", "cat", "dog"]) == ["dog", "cat"]
    assert deduplicate_list([]) == []
    assert deduplicate_list(["dog", "dog", "dog", "dog", "dog", "dog", "dog"]) == ["dog"]
    assert deduplicate_list('String') == TypeError
    assert deduplicate_list(1) == TypeError

# Generated at 2022-06-23 14:09:34.482891
# Unit test for function object_to_dict
def test_object_to_dict():
    class mytestclass(object):
        def __init__(self):
            self.property1 = 'test1'
            self.property2 = 'test2'
            self._property3 = 'test3'
            self.property4 = 'test4'

    test_object = mytestclass()
    test_dict = object_to_dict(test_object, ['property4'])
    assert 'property1' in test_dict
    assert test_dict['property1'] == 'test1'
    assert 'property2' in test_dict
    assert test_dict['property2'] == 'test2'
    assert '_property3' not in test_dict
    assert 'property4' not in test_dict

# Generated at 2022-06-23 14:09:40.268962
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object(object):
        """
        Test object to test with
        """
        def __init__(self, a, b):
            self.a = a
            self.b = b

    TEST_OBJECT = test_object('a', 'b')

    TEST_DICT = {'a':'a', 'b':'b'}

    RESULT = object_to_dict(TEST_OBJECT)

    assert RESULT == TEST_DICT

# Generated at 2022-06-23 14:09:45.532771
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:09:53.957559
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('50%', 12) == 6
    assert pct_to_int('51%', 11) == 6
    assert pct_to_int('51%', 11, min_value=0) == 5
    assert pct_to_int(2, 12) == 2
    assert pct_to_int('2', 12) == 2
    assert pct_to_int(2.5, 12) == 2



# Generated at 2022-06-23 14:10:02.882752
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int('15%', 20) == 3
    assert pct_to_int('99%', 123) == 122
    assert pct_to_int('101%', 123) == 123
    assert pct_to_int('101%', 0) == 0
    assert pct_to_int('102%', 0) == 0
    assert pct_to_int('100%', 1) == 1
    assert pct_to_int('100.1%', 1) == 1



# Generated at 2022-06-23 14:10:11.057471
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 50) == 10
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int('10%', 5, min_value=2) == 2
    assert pct_to_int('10%', 5, min_value=3) == 3
    assert pct_to_int(10, 50) == 10
    assert pct_to_int('10', 50) == 10
    assert pct_to_int('junk', 50) == 50


# Generated at 2022-06-23 14:10:17.884399
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return "<TestObj: %s>" % self.name

    o = TestObject('test')
    d = object_to_dict(o)
    assert d['name'] == 'test'
    d = object_to_dict(o, ['name'])
    assert 'name' not in d

    o = TestObject('test2')
    d = object_to_dict(o, ['_name'])
    assert 'name' not in d

# Generated at 2022-06-23 14:10:29.405461
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.valid1 = 1
            self.valid2 = 2
            self._hidden1 = 3
            self._hidden2 = 4
    m = MyClass()
    obj_dict = object_to_dict(m)
    expected_dict = dict((key, getattr(m, key)) for key in dir(m) if not key.startswith('_'))

    assert obj_dict == expected_dict

    exclude = ['valid1']
    obj_dict = object_to_dict(m, exclude)
    expected_dict = dict((key, getattr(m, key)) for key in dir(m) if not (key.startswith('_') or key in exclude))

    assert obj_dict == expected_dict



# Generated at 2022-06-23 14:10:39.006283
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 100, min_value=5) == 5
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("0.5%", 100) == 1
    assert pct_to_int("0.5%", 100, min_value=5) == 5
    assert pct_to_int("10%", 1000) == 100
    assert pct_to_int("10%", 1000, min_value=5) == 100
    assert pct_to_int("10%", 1000, min_value=101) == 101
    assert pct_to_int("50%", 1000) == 500
   

# Generated at 2022-06-23 14:10:46.728813
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100, min_value=1) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('50%', 100, min_value=3) == 51
    assert pct_to_int('50', 100, min_value=3) == 50
    assert pct_to_int(50, 100, min_value=3) == 50
    assert pct_to_int(51, 100, min_value=3) == 51

# Generated at 2022-06-23 14:10:51.633619
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.x = 1
            self.y = 2
            self.z = 3

        def test_func(self):
            return
    foo = Foo()
    new_dict = object_to_dict(foo)
    assert new_dict == {'x': 1, 'y': 2, 'z': 3}



# Generated at 2022-06-23 14:11:02.308441
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestObject(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._private_attr = 'private_attr'
            self._private_attr2 = 'private_attr2'

    obj = TestObject()
    actual = object_to_dict(obj)
    expected = {'test_attr': 'test_attr', 'test_attr2': 'test_attr2'}
    assert actual == expected

    actual = object_to_dict(obj, ['test_attr'])
    expected = {'test_attr2': 'test_attr2'}
    assert actual == expected

    actual = object_to_dict(obj, ['test_attr2'])

# Generated at 2022-06-23 14:11:04.792232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 4, 5, 6, 7, 7, 8, 6, 9, 8]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 14:11:14.928899
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Unit test for function pct_to_int
    '''
    assert pct_to_int(75, 100) == 75
    assert pct_to_int(70, 100) == 70
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(1, 100, min_value=1) == 1
    assert pct_to_int(1, 100, min_value=5) == 5
    assert pct_to_int('1%', 100, min_value=1) == 1
    assert pct_to_int('1%', 100, min_value=5) == 1
    assert pct_to_

# Generated at 2022-06-23 14:11:23.263424
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass(object):
        def __init__(self):
            self.property1 = 'property1'
            self.property2 = 'property2'
            self._property3 = 'property3'
            self._property4 = 'property4'

    sample_object = SampleClass()
    object_dict = object_to_dict(sample_object)
    assert '_property3' not in object_dict
    assert '_property4' not in object_dict
    assert object_dict['property1'] == sample_object.property1
    assert object_dict['property2'] == sample_object.property2

# Generated at 2022-06-23 14:11:34.442615
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Test cases:
    1. Constant percentage
        1. Over max value of 100%
        2. Over max value of 100% and min_value
        3. Under min value of 1%
        4. Under min value of 1% and min_value
        5. When num_items == 0, pct_to_int should return 0.
    2. Constant value,
        1. test with integer
        2. test with string
        3. test with zero value
        4. test with 100%
        5. test with 1%
    """
    num_items = 20
    min_value = 3
    results = []
    results.append(pct_to_int("101%", num_items, min_value=min_value) == min_value)

# Generated at 2022-06-23 14:11:36.350634
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 2, 5]) == [1, 2, 3, 5]



# Generated at 2022-06-23 14:11:42.622757
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        prop1 = "foo"
        prop2 = "bar"
        prop3 = "foo1"
        prop4 = "bar2"
        _prop5 = "foo2"
        _prop6 = "bar3"

    obj = TestObject()
    obj_dict = object_to_dict(obj, ['prop3', '_prop6'])

    assert 'prop1' in obj_dict
    assert 'prop2' in obj_dict
    assert 'prop3' not in obj_dict
    assert 'prop4' in obj_dict
    assert '_prop5' in obj_dict
    assert '_prop6' not in obj_dict
    assert obj_dict['prop1'] == 'foo'
    assert obj_dict['prop2'] == 'bar'

# Generated at 2022-06-23 14:11:47.528066
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('2%', 100) == 2
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('102', 100) == 102


# Generated at 2022-06-23 14:11:59.638319
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('0.01%', 1) == 0
    assert pct_to_int('0.01%', 1, min_value=0) == 0
    assert pct_to_int('0.01%', 1, min_value=1) == 1
    assert pct_to_int('10%', 200, min_value=5) == 10
    assert pct_to_int('10%', 20, min_value=5) == 5
    assert pct_to_int('10%', 20, min_value=1) == 2

# Generated at 2022-06-23 14:12:04.770683
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    expected_result = {'a': 1, 'b': 2}
    result = object_to_dict(TestObject())
    assert expected_result == result


# Generated at 2022-06-23 14:12:14.868351
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self._b = 2
            self.c = 3

    obj = TestObject()

    assert object_to_dict(obj, []) == {'a': 1, '_b': 2, 'c': 3}
    assert object_to_dict(obj, ['a']) == {'_b': 2, 'c': 3}
    assert object_to_dict(obj, ['_b']) == {'a': 1, 'c': 3}
    assert object_to_dict(obj, ['a', '_b']) == {'c': 3}
    assert object_to_dict(obj, ['_b', 'c']) == {'a': 1}

# Generated at 2022-06-23 14:12:17.820783
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        a = 1
        b = 2
        c = 3
        excluded = 4

    expected = dict(a=1, b=2, c=3)
    result = object_to_dict(Test(), exclude=['excluded'])
    assert expected == result

# Generated at 2022-06-23 14:12:21.937969
# Unit test for function deduplicate_list
def test_deduplicate_list():
     result = deduplicate_list([1,2,3,2,2,1,1,1,1,'test','test'])
     assert result == [1,2,3,'test']

# Generated at 2022-06-23 14:12:26.627565
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 200) == 1
    assert pct_to_int(500, 200) == 1
    assert pct_to_int(50, 200) == 1
    assert pct_to_int('1%', 200) == 2
    assert pct_to_int('40%', 200) == 80
    assert pct_to_int('0%', 200) == 1

# Generated at 2022-06-23 14:12:29.898687
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a_list = ['test1', 'test2', 'test3', 'test2']
    assert deduplicate_list(a_list) == ['test1', 'test2', 'test3']



# Generated at 2022-06-23 14:12:33.793234
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('1', 100) == 1
    assert pct_to_int('0', 100) == 0
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10

# Generated at 2022-06-23 14:12:36.137723
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([3, 2, 1, 2, 1, 2]) == [3, 2, 1]



# Generated at 2022-06-23 14:12:38.316839
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,2,3]) == [1,2,3]

# Generated at 2022-06-23 14:12:40.889857
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 1000) == 50
    assert pct_to_int("101%", 1000) == 1000
    assert pct_to_int("0%", 1000) == 1
    assert pct_to_int("1", 1000) == 1
    assert pct_to_int("1", 1000, min_value=0) == 1


# Generated at 2022-06-23 14:12:50.551863
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 101) == 1
    assert pct_to_int(2, 101) == 2
    assert pct_to_int(101, 101) == 101
    assert pct_to_int(101, 100) == 100
    assert pct_to_int('2%', 101) == 2
    assert pct_to_int('10%', 101) == 10
    assert pct_to_int(10, 101) == 10
    assert pct_to_int('10', 101) == 10
    assert pct_to_int('2', 101) == 2


# Generated at 2022-06-23 14:12:55.721964
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        attr1 = 'attr1'
        attr2 = 'attr2'
        attr3 = 'attr3'

    expected = {'attr1': 'attr1',
                'attr2': 'attr2',
                'attr3': 'attr3'}

    actual = object_to_dict(TestClass)

    assert actual == expected



# Generated at 2022-06-23 14:13:06.068572
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('49%', 100) == 49
    assert pct_to_int('49%', 100, min_value=10) == 10
    assert pct_to_int('100.0%', 100) == 100
    assert pct_to_int('100.00%', 100) == 100
    assert pct_to_int('1.0%', 100) == 1
    assert pct_to_int('0.8%', 100) == 1
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('0.0%', 100) == 1

# Generated at 2022-06-23 14:13:10.180356
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('10%', 50) == 5
    assert pct_to_int('99%', 101) == 100
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 101) == 10


# Generated at 2022-06-23 14:13:14.303929
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    for i in range(1, 10):
        x = pct_to_int("%d%%" % i, num_items)
        assert x == i
    x = pct_to_int("101%", num_items)
    assert x == num_items



# Generated at 2022-06-23 14:13:26.031338
# Unit test for function pct_to_int
def test_pct_to_int():
    module = 'pct_to_int'

    assert pct_to_int(75, 100) == 75, \
        "%s: 75% of 100 should be 75" % module

    assert pct_to_int(75, 10) == 1, \
        "%s: 75% of 10 should be 1" % module

    assert pct_to_int(100, 100) == 100, \
        "%s: 100% of 100 should be 100" % module

    assert pct_to_int(100, 10) == 10, \
        "%s: 100% of 10 should be 10" % module

    assert pct_to_int('75%', 100) == 75, \
        "%s: 75%% of 100 should be 75" % module


# Generated at 2022-06-23 14:13:30.603543
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test object_to_dict
    """
    class TestClass:
        def __init__(self):
            self.x = "X"
            self.y = "Y"
            self.z = "Z"

    assert object_to_dict(TestClass()) == {'x': 'X', 'y': 'Y', 'z': 'Z'}



# Generated at 2022-06-23 14:13:38.395227
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObj:
        testAttr = 'test'
        attr2 = None
        testAttr3 = 'test3'

        def __init__(self):
            self.testAttr = 'test'
            self.attr2 = None
            self.testAttr3 = 'test3'
    assert object_to_dict(testObj()) == {'attr2': None, 'testAttr3': 'test3', 'testAttr': 'test'}
    assert object_to_dict(testObj(), exclude=['testAttr3']) == {'attr2': None, 'testAttr': 'test'}
    assert object_to_dict(testObj(), exclude=['testAttr3']) != {'attr2': None, 'testAttr': 'test', 'testAttr3': 'test3'}


# Generated at 2022-06-23 14:13:40.838230
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 4, 5, 5, 3, 3, 3, 1, 1, 7]) == [1, 2, 4, 5, 3, 7]

# Generated at 2022-06-23 14:13:51.823799
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test with valid percentage
    assert pct_to_int(50, 2, 1) == 1
    assert pct_to_int('50%', 2, 1) == 1

    # Test with invalid percentage
    assert pct_to_int(50, 2, 2) == 2
    assert pct_to_int('50%', 2, 2) == 2

    # Test with 0 items
    assert pct_to_int(50, 0, 1) == 1
    assert pct_to_int('50%', 0, 1) == 1

    # Test with negative items
    assert pct_to_int(50, -1, 1) == 1
    assert pct_to_int('50%', -1, 1) == 1


# Generated at 2022-06-23 14:13:54.162186
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50



# Generated at 2022-06-23 14:14:02.939326
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = "hello"
            self.b = 1
            self.c = True

    # Test normal
    output = object_to_dict(Test())
    assert(output["a"] == "hello")
    assert(output["b"] == 1)
    assert(output["c"] == True)
    assert(len(output) == 3)

    # Test with excluded
    output = object_to_dict(Test(), exclude=["a"])
    assert(output["a"] == None)
    assert(output["b"] == 1)
    assert(output["c"] == True)
    assert(len(output) == 3)

    # Test with nothing excluded
    output = object_to_dict(Test(), exclude=[])

# Generated at 2022-06-23 14:14:07.517921
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 3, 5, 5, 6, 7, 5, 1, 3, 3]) == [1, 2, 3, 5, 6, 7, 1, 3]

# Generated at 2022-06-23 14:14:09.401873
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'd', 'b', 'e', 'f']) == ['a', 'b', 'c', 'd', 'e', 'f']


# Generated at 2022-06-23 14:14:15.943465
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 0, 0, 1, 1, 2]
    assert (deduplicate_list(original_list) == [1, 2, 3, 0])
    
    original_list = [1, 1, 2, 3, 5, 3, 0, 10, 5, 4, 1, 2, 5]
    assert (deduplicate_list(original_list) == [1, 2, 3, 5, 0, 10, 4])



# Generated at 2022-06-23 14:14:23.530743
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test = 'test'
        other = 'other'
    t = Test()
    obj = object_to_dict(t)
    assert 'test' in obj
    assert obj['test'] == 'test'
    assert obj['other'] == 'other'
    assert '_module' not in obj
    # Test exclude works
    obj = object_to_dict(t, exclude=['other'])
    assert 'other' not in obj
    assert 'test' in obj


# Generated at 2022-06-23 14:14:26.985351
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['b','a','c','e','f','a','b','c']
    expected_list = ['b','a','c','e','f']
    result = deduplicate_list(test_list)
    assert result == expected_list

# Generated at 2022-06-23 14:14:29.507564
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        one = "one"
        two = "two"
        three = "three"
    to = TestObj()
    object_to_dict(to)

# Generated at 2022-06-23 14:14:38.540202
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(80, 100) == 80
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('80', 100) == 80
    assert pct_to_int('80%', 100, min_value=5) == 80
    assert pct_to_int('80%', 100, min_value=81) == 81
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=81) == 81


# Generated at 2022-06-23 14:14:49.721421
# Unit test for function object_to_dict
def test_object_to_dict():

    # Test class
    class Obj(object):
        def __init__(self):
            self.a = 'attr_a'
            self.b = 'attr_b'
            self.c = 'attr_c'
            self._d = 'attr_d'

    obj = Obj()
    result = object_to_dict(obj)
    assert ('a' in result) and ('b' in result) and ('c' in result) and ('d' not in result)
    assert result['a'] == 'attr_a' and result['b'] == 'attr_b' and result['c'] == 'attr_c'

    result = object_to_dict(obj, exclude=['b'])
    assert ('a' in result) and ('b' not in result) and ('c' in result) and ('d' not in result)


# Generated at 2022-06-23 14:14:54.532333
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'b', 'c', 'b', 'c', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:14:56.052084
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,1,3]) == [1,2,3]

# Generated at 2022-06-23 14:15:00.948393
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int('1%', 100, min_value=1)
    assert 1 == pct_to_int('10%', 100, min_value=1)
    assert 10 == pct_to_int('10%', 1000, min_value=1)
    assert 10 == pct_to_int(10, 1000, min_value=1)
    assert 5 == pct_to_int('50%', 10, min_value=1)

# Generated at 2022-06-23 14:15:06.320861
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('20%', 101) == 21
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int(50, 100) == 50

# Generated at 2022-06-23 14:15:09.705430
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['cat', 'dog', 'fish', 'cat', 'lion', 'dog']
    deduplicated_list = ['cat', 'dog', 'fish', 'lion']
    assert deduplicate_list(original_list) == deduplicated_list



# Generated at 2022-06-23 14:15:15.007137
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 5]) == [1, 2, 3, 5]
    assert deduplicate_list([1, 2, 3, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:15:18.689485
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo():
        def __init__(self):
            self.bar = 'one'
            self.zap = 'two'
    obj = Foo()
    result = object_to_dict(obj)
    assert result == {'bar': 'one', 'zap': 'two'}

# Generated at 2022-06-23 14:15:21.574139
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 2, 4]) == [1, 2, 3, 2, 4]



# Generated at 2022-06-23 14:15:31.149388
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int(0, 10) == 0
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int(-1, 10) == 1
    assert pct_to_int('-1%', 10) == 1
    assert pct_to_int(11, 10) == 11
    assert pct_to_int('11%', 10) == 11

    assert pct_to_int(11, 5) == 2
    assert pct_to_int('11%', 5) == 2

# Generated at 2022-06-23 14:15:35.406032
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 50) == 5
    assert pct_to_int("1%", 50) == 1
    assert pct_to_int("1%", 10, 5) == 1
    assert pct_to_int("10%", 10, 5) == 1


# Generated at 2022-06-23 14:15:40.265746
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 3, 4, 2, 5, 5]
    deduped_test_list = deduplicate_list(test_list)
    assert len(deduped_test_list) == 5



# Generated at 2022-06-23 14:15:49.293479
# Unit test for function pct_to_int
def test_pct_to_int():
    tests = [
        {
            'input': '50%',
            'num_items': 100,
            'min_value': 1,
            'expected': 50
        },
        {
            'input': '50%',
            'num_items': 51,
            'min_value': 1,
            'expected': 26
        },
        {
            'input': '50%',
            'num_items': 51,
            'min_value': 0,
            'expected': 25
        },
        {
            'input': '50',
            'num_items': 51,
            'min_value': 0,
            'expected': 50,
        },
    ]


# Generated at 2022-06-23 14:15:54.737222
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        name = 'test'
    assert object_to_dict(MyObject()) == {'name': 'test'}
    assert object_to_dict(MyObject(), exclude=['name']) == {}


# Generated at 2022-06-23 14:16:04.248578
# Unit test for function object_to_dict
def test_object_to_dict():
    class test:

        def __init__(self):
            self.exclude_1 = 'this'
            self.exclude_2 = 'that'
            self._exclude_3 = 'other'
            self.include_1 = 'first'
            self._include_2 = 'second'
            self._include_3 = 'third'
            self.include_4 = 'fourth'

    expected_results = dict((key, getattr(test(), key)) for key in dir(test()) if not (key.startswith('_') or key in ['exclude_1', 'exclude_2']))
    actual_results = object_to_dict(test(), ['exclude_1', 'exclude_2'])


# Generated at 2022-06-23 14:16:09.682928
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    a = A()
    b = object_to_dict(a, exclude=['a', 'c'])
    assert(b['b'] == 2)
    assert('a' not in b)
    assert('c' not in b)

# Generated at 2022-06-23 14:16:12.234718
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 14:16:16.235753
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'hi'
            self._private_attr = 'bye'
    test_object = TestClass()
    test_dict = object_to_dict(test_object)
    assert test_dict['test_attr'] == 'hi'
    assert '_private_attr' not in test_dict



# Generated at 2022-06-23 14:16:25.351434
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestObj(object):
        def __init__(self, name):
            self.name = name
            self.some_var = None
            self.some_other_var = None
            self.some_hidden_var = None

    test_obj = TestObj('test')
    test_obj.some_var = True
    test_obj.some_other_var = False
    test_obj.some_hidden_var = 'should not show up'

    obj_dict = object_to_dict(test_obj)

    assert obj_dict == {'name': 'test', 'some_var': True, 'some_other_var': False}

# Generated at 2022-06-23 14:16:33.466844
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, test1, test2, test3):
            self.test1 = test1
            self.test2 = test2
            self.test3 = test3

        def test_function(self, arb1, arb2):
            return None

    test_class = TestClass(test1='test1', test2='test2', test3='test3')
    dict_test_class = dict(test1='test1', test2='test2', test3='test3')
    assert object_to_dict(test_class) == dict_test_class

# Generated at 2022-06-23 14:16:38.886745
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([3, 2, 1, 2, 1]) == [3, 2, 1]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:16:44.081152
# Unit test for function object_to_dict
def test_object_to_dict():
    class Example:
        a = 'a'
        b = 'b'
        c = 'c'

    assert object_to_dict(Example()) == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert object_to_dict(Example(), exclude=['a', 'c']) == {'b': 'b'}

# Generated at 2022-06-23 14:16:48.389615
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 300, 10) == 150
    assert pct_to_int('50%', 300.5, 10) == 150
    assert pct_to_int('50', 300, 10) == 50
    assert pct_to_int('8.5%', 300, 10) == 25
    assert pct_to_int('0%', 300, 10) == 10
    assert pct_to_int('-1%', 300, 10) == 10

# Generated at 2022-06-23 14:16:50.781219
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int(10, 10) == 10



# Generated at 2022-06-23 14:16:52.702776
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 2, 1, 4, 4, 1]) == [1, 2, 3, 2, 4, 1]
    assert deduplicate_list(['abc','abc','abc','def']) == ['abc', 'def']


# Generated at 2022-06-23 14:16:55.395009
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self._b = 2
            self.c = 3

    t = TestClass()
    d = object_to_dict(t, ['a', 'c'])
    assert '_b' not in d
    assert 'a' not in d
    assert 'c' not in d

# Generated at 2022-06-23 14:16:59.550252
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self._c = 3
            self._d = 4
    obj = TestClass()
    result = object_to_dict(obj)
    assert result['a'] == 1
    assert result['b'] == 2
    assert result['_c'] != 3
    assert result['_d'] != 4
    result = object_to_dict(obj, exclude=['_c', '_d'])
    assert result['a'] == 1
    assert result['b'] == 2
    assert result['_c'] != 3
    assert result['_d'] != 4
