

# Generated at 2022-06-23 14:07:07.063796
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestA(object):
        foo = 'bar'
        bar = 'foo'

    test = TestA()

    result = object_to_dict(test, ['bar'])
    assert 'foo' in result

    result = object_to_dict(test, ['foo'])
    assert 'bar' in result

    result = object_to_dict(test, ['foo', 'bar'])
    assert not result

# Generated at 2022-06-23 14:07:17.928960
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.ios

    class Foo(object):
        def __init__(self):
            self.bar = 'bar'
            self.baz = 'baz'
            self.fie = 'fie'
            self._fum = 'fum'

    foo = Foo()
    assert object_to_dict(foo) == {'bar': 'bar', 'baz': 'baz', 'fie': 'fie', '_fum': 'fum'}
    assert object_to_dict(foo, exclude=['fie', 'baz']) == {'bar': 'bar', '_fum': 'fum'}

# Generated at 2022-06-23 14:07:29.462074
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.test_1 = 'test1'
            self.test_2 = 'test2'
            self._test_3 = 'test3'

    test_object = test_class()
    test_result = object_to_dict(test_object)
    assert test_result['test_1'] == 'test1'
    assert test_result['test_2'] == 'test2'
    assert '_test_3' not in test_result
    assert 'test_3' not in test_result

    test_result = object_to_dict(test_object, exclude=['_test_3'])
    assert '_test_3' not in test_result
    assert test_result['test_3'] == 'test3'



# Generated at 2022-06-23 14:07:31.945476
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = [1, 2, 3, 4, 3, 2, 1, 5]
    assert deduplicate_list(my_list) == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 14:07:35.078406
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert sorted(deduplicate_list(['abc', 'abc', 'bcd', 'bcd', 'bcd', 'cde', 'cde', 'cde', 'cde', 'efg'])) == sorted(['abc', 'bcd', 'cde', 'efg'])



# Generated at 2022-06-23 14:07:40.858634
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.bar = 'bar'
            self.spam = 'spam'
            self._crap = 'crap'
            self.ham = 'ham'

    res = object_to_dict(Foo())
    assert res['bar'] == 'bar', 'Failed to convert object to dictionary'
    assert '_crap' not in res, 'Should exclude private variables'
    assert 'spam' in res and res['spam'] == 'spam', 'Failed to convert object to dictionary'

    res = object_to_dict(Foo(), ['bar'])
    assert 'bar' not in res, 'Should exclude bar'

# Generated at 2022-06-23 14:07:47.994277
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.foo = 'bar'
            self.reset = False
            self.reboot = False

    obj = TestObj()
    assert object_to_dict(obj) == {'foo': 'bar', 'reboot': False, 'reset': False}
    assert object_to_dict(obj, exclude=['foo']) == {'reboot': False, 'reset': False}
    assert object_to_dict(obj, exclude=['foo', 'reboot']) == {'reset': False}

# Generated at 2022-06-23 14:07:52.663633
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self, _name):
            self.name = _name
            self.hidden_name = '%s_secret' % _name

    test_obj = TestObject('foo')
    assert object_to_dict(test_obj) == {'name': 'foo', 'hidden_name': 'foo_secret'}
    assert object_to_dict(test_obj, exclude=['hidden_name']) == {'name': 'foo'}



# Generated at 2022-06-23 14:08:01.681118
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create the object to test with
    class MyClass(object):
        def __init__(self, attrib1, attrib2, attrib3):
            self.attrib1 = attrib1
            self.attrib2 = attrib2
            self.attrib3 = attrib3

    # Create instance of the object
    my_instance = MyClass('value1', 'value2', 'value3')

    # Dump to dict
    my_instance_dict = object_to_dict(my_instance)

    # Check the results
    assert isinstance(my_instance_dict, dict)
    assert my_instance_dict['attrib1'] == 'value1'
    assert my_instance_dict['attrib2'] == 'value2'
    assert my_instance_dict['attrib3'] == 'value3'



# Generated at 2022-06-23 14:08:10.774521
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class():
        def __init__(self):
            self.attr1 = 'attr1'
            self.attr2 = 'attr2'
            self._attr3 = '_attr3'
            self._attr2 = '_attr2'
            self.attr5 = 'attr5'
            self.attr4 = 'attr4'

    test_class_var = test_class()

    assert object_to_dict(test_class_var, ['attr2']) == {'attr1': 'attr1', '_attr3': '_attr3', 'attr4': 'attr4', '_attr2': '_attr2', 'attr5': 'attr5'}

# Generated at 2022-06-23 14:08:19.603676
# Unit test for function pct_to_int
def test_pct_to_int():
    # Some basic checks
    assert pct_to_int(100, 1000) == 100
    assert pct_to_int(50, 1000) == 500
    assert pct_to_int(10, 1000) == 100
    assert pct_to_int(1, 1000) == 1
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('1%', 1000) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(0, 100) == 1

# Generated at 2022-06-23 14:08:30.337588
# Unit test for function pct_to_int
def test_pct_to_int():
    result = pct_to_int('5%', 100)
    assert result == 5
    result = pct_to_int('5%', 100, min_value=0)
    assert result == 5
    result = pct_to_int('5%', 10)
    assert result == 1
    result = pct_to_int('5%', 1)
    assert result == 1
    result = pct_to_int('5%', 1, min_value=0)
    assert result == 0
    result = pct_to_int('100%', 100)
    assert result == 100
    result = pct_to_int('100%', 10)
    assert result == 10
    result = pct_to_int('0%', 100)
    assert result == 1

# Generated at 2022-06-23 14:08:39.461786
# Unit test for function object_to_dict
def test_object_to_dict():
    # Returns a dict with keys for all the properties
    class TestObject():
        def __init__(self):
            self.value1 = 1
            self.value2 = 2
            self.value3 = 3
            self.value4 = 4
            self.value5 = 5

    expected_keys = ['value1', 'value2', 'value3', 'value4', 'value5']
    # Create our test object
    test_obj = TestObject()

    # Create our dict using the object_to_dict function
    test_dict = object_to_dict(test_obj)

    # Check to make sure our dict has the expected keys

# Generated at 2022-06-23 14:08:43.683429
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'

    test_obj = TestObject()
    result = object_to_dict(test_obj)

    assert result['key1'] == 'value1'
    assert result['key2'] == 'value2'

# Generated at 2022-06-23 14:08:53.590822
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test a simple list
    list1 = ['a', 'b', 'b', 'c']
    list2 = ['a', 'b', 'c']
    assert list1 != list2
    assert list2 == deduplicate_list(list1)
    # Test a list with empty string
    list1 = ['a', 'b', '', 'b', 'c']
    list2 = ['a', 'b', '', 'c']
    assert list1 != list2
    assert list2 == deduplicate_list(list1)
    # Test a list with None
    list1 = ['a', 'b', None, 'b', None, 'c']
    list2 = ['a', 'b', None, 'c']
    assert list1 != list2
    assert list2 == deduplicate_list(list1)


# Generated at 2022-06-23 14:09:00.972609
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('', 100) == 0
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5', 100, min_value=0) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 100, min_value=0) == 5
    assert pct_to_int('5', 1) == 1
    assert pct_to_int('5', 1, min_value=0) == 0
    assert pct_to_int('5%', 1) == 1
    assert pct_to_int('5%', 1, min_value=0) == 0
    assert pct_to_int('1', 100) == 1

# Generated at 2022-06-23 14:09:09.216212
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.foo = "FOO"
            self.bar = "BAR"
            self.baz = "BAZ"
    test_obj = TestObject()
    expected = {"foo": "FOO", "bar": "BAR", "baz": "BAZ"}
    actual = object_to_dict(test_obj)
    assert actual == expected
    expected = {"foo": "FOO", "baz": "BAZ"}
    actual = object_to_dict(test_obj, exclude=["bar"])
    assert actual == expected

# Generated at 2022-06-23 14:09:17.467151
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object():
        def __init__(self):
            self.fruits = None
            self.vegetables = None

    objects = [Object(), Object()]
    setattr(objects[0], 'fruits', ['apples', 'bananas'])
    setattr(objects[0], 'vegetables', 'carrots')
    setattr(objects[1], 'fruits', 'apples')
    setattr(objects[1], 'vegetables', ['peas', 'carrots'])

    expected = {'vegetables': ['peas', 'carrots'], 'fruits': 'apples'}

    assert(expected == object_to_dict(objects[1]))

# Generated at 2022-06-23 14:09:27.149895
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('99.99%', 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('1.1%', 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, 0) == 0
    assert pct_to_int('0.01%', 100) == 1
    assert pct_

# Generated at 2022-06-23 14:09:29.937909
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import qubesadmin.tests
    assert deduplicate_list(qubesadmin.tests.list_dup) == qubesadmin.tests.list_no_dup

# Generated at 2022-06-23 14:09:37.238671
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('.1%', 100) == 1
    assert pct_to_int('10.0%', 100) == 10


# Generated at 2022-06-23 14:09:39.672869
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "b", "c"]) == ["a", "b", "c"]
    assert deduplicate_list(["a", "a", "b"]) == ["a", "b"]

# Generated at 2022-06-23 14:09:51.667842
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('50', 100) == 50
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5', 100, min_value=5) == 5
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('1', 100, min_value=5) == 5
    assert pct_to_int(1, 100, min_value=5) == 5

# Generated at 2022-06-23 14:09:53.016602
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 4]) == [1, 2, 3, 4]



# Generated at 2022-06-23 14:09:59.981054
# Unit test for function deduplicate_list
def test_deduplicate_list():
    ansible_list = [
        'cisco',
        'ansible',
        'juniper',
        'cisco',
        'ansible',
        'cisco',
        'arista'
    ]

    dedup_list = deduplicate_list(original_list=ansible_list)
    assert dedup_list == ['cisco', 'ansible', 'juniper', 'arista']

    ansible_list = [
        'cisco',
        'cisco',
        'juniper',
        'juniper',
        'arista',
        'arista'
    ]

    dedup_list = deduplicate_list(original_list=ansible_list)
    assert dedup_list == ['cisco', 'juniper', 'arista']

    ansible_list = []
   

# Generated at 2022-06-23 14:10:07.714320
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        """
        Dummy class
        """
        test_attr = "test"
        def __init__(self):
            self.test1 = "test1"
            self.test2 = "test2"

    test_obj = test_class()
    test_dict = {"test1": "test1", "test2": "test2"}
    assert object_to_dict(test_obj) == test_dict
    assert object_to_dict(test_obj, ["test_attr"]) == test_dict

# Generated at 2022-06-23 14:10:14.501655
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'
            self.hello = 'world'

        def say_hello(self):
            "This is a method"
            return "hello world"

    test_obj = Foo()
    test_dict = object_to_dict(test_obj)

    assert test_dict == {'bar': 'baz', 'hello': 'world'}



# Generated at 2022-06-23 14:10:17.299603
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a','a','a','b','c','b','a','d']
    assert deduplicate_list(original_list) == ['a','b','c','d']



# Generated at 2022-06-23 14:10:22.828711
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'c', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:10:30.493490
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests the object_to_dict function
    """
    class Temp(object):
        attr1 = 'foo'
        attr2 = 'bar'
        attr3 = 'baz'

    temp_obj = Temp()
    result = object_to_dict(temp_obj)
    assert 'attr1' in result
    assert 'attr2' in result
    assert 'attr3' in result
    assert result['attr1'] == 'foo'
    assert result['attr2'] == 'bar'
    assert result['attr3'] == 'baz'

# Generated at 2022-06-23 14:10:39.909696
# Unit test for function object_to_dict
def test_object_to_dict():
    """Unit test for function object_to_dict"""
    import json

    class testclass(object):
        """
        Dummy class
        """
        def __init__(self):
            self.int_one = 1
            self.int_two = 2
            self.string_one = 'One'
            self.string_two = 'Two'

    test_obj = testclass()
    out_dict = object_to_dict(test_obj)
    assert json.dumps(out_dict) == '{"string_two": "Two", "int_two": 2, "int_one": 1, "string_one": "One"}'

    test_obj = testclass()
    out_dict = object_to_dict(test_obj, exclude=['int_one'])
    assert json.dumps(out_dict)

# Generated at 2022-06-23 14:10:45.295324
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    my_obj = TestObject()
    obj_dict = object_to_dict(my_obj, ['b', 'c'])
    assert obj_dict == {'a': 'a'}

# Generated at 2022-06-23 14:10:52.688796
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('%10', 100) == 10
    assert pct_to_int(0, 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10.0, 100) == 10
    assert pct_to_int(10.5, 100) == 10
    assert pct_to_int(10.5, 100, min_value=5) == 5

# Generated at 2022-06-23 14:10:58.413511
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 10
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("100%", 2) == 2
    assert pct_to_int("150%", 2) == 3

# Generated at 2022-06-23 14:11:01.402655
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self._test = 'foo'
            self.test = 'bar'

    assert object_to_dict(Test()) == {'test': 'bar'}



# Generated at 2022-06-23 14:11:06.128435
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Empty
    assert [] == deduplicate_list([])

    # No duplicates
    assert [1, 2, 3] == deduplicate_list([1, 2, 3])

    # With duplicates
    assert [1, 2, 3] == deduplicate_list([1, 2, 3, 2, 3, 2, 3, 1, 2])



# Generated at 2022-06-23 14:11:13.323304
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test exact value
    assert pct_to_int(10, 100) == 10
    # Test percentage
    assert pct_to_int('10%', 100) == 10
    # Test percentage with zero items
    assert pct_to_int('10%', 0) == 1
    # Test percentage with float items
    assert pct_to_int('10%', 0.25) == 1
    # Test percentage with min_value
    assert pct_to_int('10%', 0, min_value=3) == 3

# Generated at 2022-06-23 14:11:22.103377
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list(['b', 'b', 'a', 'd', 'a']) == ['b', 'a', 'd']
    assert deduplicate_list(['b', 'b', 'a', 'd', 'a', 'd']) == ['b', 'a', 'd']
    assert deduplicate_list(['b', 'b', 'a', 'd', 'a', 'd', 2, 2, 2]) == ['b', 'a', 'd', 2]

# Generated at 2022-06-23 14:11:28.575204
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():

        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    test_obj = TestObject()
    result = object_to_dict(test_obj)
    assert result['a'] == 1 and result['b'] == 2 and result['c'] == 3
    result = object_to_dict(test_obj, ['a'])
    assert result['b'] == 2 and result['c'] == 3



# Generated at 2022-06-23 14:11:33.435871
# Unit test for function object_to_dict
def test_object_to_dict():
    class Tmp(object):
        a = 'test1'
        b = 'test2'

    assert object_to_dict(Tmp) == {'a': 'test1', 'b': 'test2'}
    assert object_to_dict(Tmp, ['b']) == {'a': 'test1'}

# Generated at 2022-06-23 14:11:39.557945
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:11:50.749258
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self.key3 = 'value3'
            self.key4 = 'value4'

    actual = object_to_dict(TestObject())
    expected = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    if not actual == expected:
        raise Exception("Expected dictionary %s does not match actual %s" % (expected, actual))

    actual = object_to_dict(TestObject(), ['key1'])
    expected = {'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}

# Generated at 2022-06-23 14:11:57.650586
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, x):
            self.x = x

    o = TestClass(1)
    assert object_to_dict(o) == {'x': 1}, 'true'
    assert object_to_dict(o, ['x']) == {}, 'true'
    assert object_to_dict(o, ['x'], ) == {}, 'true'

# Generated at 2022-06-23 14:12:06.984592
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('2%', 100) == 2
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=2) == 2

# Generated at 2022-06-23 14:12:09.947432
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.a = 'test'
            self.b = 'test2'

    my_foo = Foo()
    dict_out = object_to_dict(my_foo, exclude=['b'])
    assert dict_out == {'a': 'test'}
    dict_out = object_to_dict(my_foo)
    assert dict_out == {'a': 'test', 'b': 'test2'}

# Generated at 2022-06-23 14:12:11.396734
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10.0, 100) == 10


# Generated at 2022-06-23 14:12:19.217212
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(object.__new__(list), exclude=[]) == {}
    assert object_to_dict(object.__new__(list), exclude=['__doc__', '__module__', '__repr__']) == {}

# Generated at 2022-06-23 14:12:25.948429
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 4, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([5, 4, 4, 4, 3, 2, 2, 1]) == [5, 4, 3, 2, 1]
    assert deduplicate_list([5, 3, 1, 7, 3, 1, 5]) == [5, 3, 1, 7]


# Generated at 2022-06-23 14:12:34.677831
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', num_items=100) == 100
    assert pct_to_int('99%', num_items=100) == 99
    assert pct_to_int('99.5%', num_items=100) == 100
    assert pct_to_int('50%', num_items=100) == 50
    assert pct_to_int('0.5%', num_items=100) == 1
    assert pct_to_int('0%', num_items=100) == 1
    assert pct_to_int('0', num_items=100) == 0
    assert pct_to_int(0.5, num_items=100) == 0
    assert pct_to_int(5, num_items=100) == 5
    assert pct_to_

# Generated at 2022-06-23 14:12:36.659227
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'c', 'a']) == ['a', 'b', 'c']


# Generated at 2022-06-23 14:12:40.544145
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'd', 'a', 'd', 'c', 'b', 'b']
    assert deduplicate_list(test_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 14:12:45.764580
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        test_string_prop = "test string"
        test_num_prop = 1234
        def __init__(self):
            pass

    test_obj = TestObject()
    obj_dict = object_to_dict(test_obj, ['test_num_prop', 'test_string_prop'])

    assert 'test_string_prop' not in obj_dict
    assert 'test_num_prop' not in obj_dict
    assert '__class__' not in obj_dict
    assert '__init__' in obj_dict
    assert obj_dict['__init__'] == TestObject.__init__

# Generated at 2022-06-23 14:12:52.824018
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create class
    class Student:
        def __init__(self, name, age):
            self.name = name
            self.age = age
    # Instantiate
    haley = Student("Haley", 20)
    # Convert object to dict
    haley_dict = object_to_dict(haley)
    # Test result
    assert haley_dict['name'] == "Haley", "Name is not equal"
    assert haley_dict['age'] == 20, "Age is not equal"
    # Test with parameter "exclude"
    haley_dict2 = object_to_dict(haley, exclude=['name'])
    assert 'name' not in haley_dict2


# Generated at 2022-06-23 14:13:01.111377
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tests = [
        # test_list, expected_list
        ([], []),
        (['a', 'b', 'c'], ['a', 'b', 'c']),
        (['a', 'a', 'a'], ['a']),
        (['a', 'b', 'c', 'a'], ['a', 'b', 'c']),
        (['a', 'b', 'a', 'b', 'c', 'a', 'a'], ['a', 'b', 'c']),
        (['a', 'A', 'a', 'A', 'a', 'A'], ['a', 'A']),
    ]
    for test, expected in tests:
        actual = deduplicate_list(test)
        assert actual == expected, 'Expected: {} Actual: {}'.format(expected, actual)

# Generated at 2022-06-23 14:13:12.005569
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.common.utils import object_to_dict
    from ansible.module_utils.network.common.utils import dict_to_set
    from ansible.module_utils.network.common.parsing import Conditional
    import re

    class TestObject:
        def __init__(self):
            self.string = 'test'
            self.boolean = False
            self.numeric = 22
            self.dict = dict(a='test', b=dict(c='third'))
            self.conditional = Conditional(when=re.compile('test'),
                                           value='test')
            self.list = [1, 2, 3]
            self._exclude = ['exclude']
            self.exclude = 'this should be excluded'

    obj = TestObject()
   

# Generated at 2022-06-23 14:13:17.618654
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:13:28.606781
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.dmos.facts.hardware import Hardware
    from ansible.module_utils.network.dmos.facts.utils import to_lines
    hardware_obj = Hardware()
    hardware_obj.model = 'Potato'
    hardware_obj.sn = '12345'

    hardware_dict = object_to_dict(hardware_obj)
    assert hardware_dict['model'] == 'Potato'
    assert hardware_dict['sn'] == '12345'
    hardware_dict = object_to_dict(hardware_obj, ['model'])
    assert hardware_dict['model'] is None
    assert hardware_dict['sn'] == '12345'
    assert to_lines(object_to_dict(hardware_obj, ['model'])) == ['12345']

# Generated at 2022-06-23 14:13:34.500882
# Unit test for function deduplicate_list
def test_deduplicate_list():
    '''
    Test function for deduplicate_list
    '''
    from nose.tools import assert_equal

    input_list = ['SAT', 'SUN', 'SAT', 'SUN', 'THURS', 'SAT', 'SUN', 'SUN', 'FRI', 'FRI', 'SAT', 'SUN']
    expected = ['SAT', 'SUN', 'THURS', 'FRI']
    actual = deduplicate_list(input_list)
    assert_equal(actual, expected)

# Generated at 2022-06-23 14:13:41.108967
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        attrib_1 = 'zebra'
        attrib_2 = 'lion'
        attrib_3 = 'tiger'
        def __init__(self):
            pass
    test_obj = TestClass()
    result = object_to_dict(test_obj, exclude=['attrib_1', 'attrib_3'])
    assert result.get('attrib_1') is None
    assert result.get('attrib_2') == 'lion'
    assert result.get('attrib_3') is None


# Generated at 2022-06-23 14:13:52.998499
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 0 == pct_to_int('0%', 0)
    assert 0 == pct_to_int('0%', 100)
    assert 0 == pct_to_int('0%', 1000)
    assert 0 == pct_to_int(0, 100)
    assert 1 == pct_to_int(1, 100)
    assert 7 == pct_to_int('7%', 100)
    assert 10 == pct_to_int('10%', 100)
    assert 10 == pct_to_int('10%', 10)
    assert 1 == pct_to_int('10%', 10, min_value=1)
    assert 1 == pct_to_int('100%', 10, min_value=1)

# Generated at 2022-06-23 14:14:02.366774
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test the result of function deduplicate_list for
    an asserted list of input
    """
    assert deduplicate_list([]) == []
    assert deduplicate_list(['taco','burrito','taco','enchilada','taco','taco','burrito','burrito']) == ['taco','burrito','enchilada']
    assert deduplicate_list([1,1,1,1,1]) == [1]
    assert deduplicate_list([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]) == [0]
    assert deduplicate_list([9.0,9.0,9.0]) == [9.0]
    assert deduplicate

# Generated at 2022-06-23 14:14:11.096047
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self._d = 4

        def excluded(self):
            return True

    obj = Test()
    result = object_to_dict(obj, ['excluded'])
    assert result['a'] == 1
    assert result['b'] == 2
    assert result['c'] == 3
    assert '_d' not in result
    assert 'excluded' not in result

# Generated at 2022-06-23 14:14:15.271250
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'c', 'd', 'b', 'a']
    result_list = ['a', 'b', 'c', 'd']
    assert (result_list == deduplicate_list(test_list))



# Generated at 2022-06-23 14:14:18.832583
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = "test"
            self.d = False
    obj = Obj()
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 'test', 'd': False}


# Generated at 2022-06-23 14:14:29.685639
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for object_to_dict()
    """
    # Get the first interface from list
    class Interface:
        def __init__(self, name, desc, ipv4, ipv6):
            self.name = name
            self.description = desc
            self.ipv4 = ipv4
            self.ipv6 = ipv6

    interface1 = Interface('GigabitEthernet1', 'test descr', '10.10.10.1', '1::1')
    intf1_dict = object_to_dict(interface1, ['ipv6'])
    assert intf1_dict['name'] == interface1.name
    assert intf1_dict['description'] == interface1.description
    assert intf1_dict['ipv4'] == interface1.ipv4

# Generated at 2022-06-23 14:14:39.390494
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        one = 1
        two = 2
        three = 3

        def exclude_four(self):
            return 4

    class TestExclude:
        one = 1
        two = 2
        three = 3

        def exclude_four(self):
            return 4

        def exclude_five(self):
            return 5

    def test_obj_to_dict():
        assert object_to_dict(Test) == {'one': 1, 'two': 2, 'three': 3}
        assert object_to_dict(TestExclude, exclude=['one']) == {'two': 2, 'three': 3}
        assert object_to_dict(TestExclude, exclude=['one', 'two']) == {'three': 3}

    test_obj_to_dict()



# Generated at 2022-06-23 14:14:50.758599
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    from collections import OrderedDict
    from operator import itemgetter
    from itertools import groupby

    key = lambda x: x

    input_list = ['a', 'c', 'b', 'c', 'a', 'b', 'c']

    # Python 2.6 and 2.7 compatible, not using collections.OrderedDict or itertools.groupby
    output_list = [i[0] for i in OrderedDict([(i, None) for i in input_list]).items()]

    dedup_list = deduplicate_list(input_list)

# Generated at 2022-06-23 14:15:00.040502
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = []
    assert test_list == deduplicate_list(test_list)

    test_list = [1]
    assert [1] == deduplicate_list(test_list)

    test_list = [1, 1]
    assert [1] == deduplicate_list(test_list)

    test_list = [1, 1, 2]
    assert [1, 2] == deduplicate_list(test_list)

    test_list = [1, 2, 1]
    assert [1, 2] == deduplicate_list(test_list)

    test_list = [2, 2, 1]
    assert [2, 1] == deduplicate_list(test_list)

    test_list = [1, 2, 2]

# Generated at 2022-06-23 14:15:01.835068
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-23 14:15:05.472218
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_input = [1, 2, 3, 2, 'b', 3, 'a', 'b']
    assert deduplicate_list(test_input) == [1, 2, 3, 'b', 'a']

# Generated at 2022-06-23 14:15:12.861542
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'taz', 'taz', 'foo', 'bar', 'taz', 'taz']
    deduped_list = deduplicate_list(original_list)
    assert len(original_list) != len(deduped_list), 'original list and deduped list are the same length'
    assert len(deduped_list) == 3, 'there should be 3 unique items'
    assert deduped_list[0] == 'foo', 'first item should be foo'
    assert deduped_list[1] == 'bar', 'second item should be bar'
    assert deduped_list[2] == 'taz', 'third item should be taz'

# Generated at 2022-06-23 14:15:21.847428
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        test_attr1 = "Test Attr 1"
        test_attr2 = "Test Attr 2"
        test_attr3 = "Test Attr 3"
        test_attr4 = "Test Attr 4"

    exclude = ["test_attr3", "test_attr4"]
    result = object_to_dict(TestObject, exclude)

    assert len(result) == 2, 'result has 2 items'
    assert "test_attr1" in result.keys(), 'result has key test_attr1'
    assert "test_attr2" in result.keys(), 'result has key test_attr2'

    assert result["test_attr2"] == "Test Attr 2", 'result has correct vaule for test_attr2'

# Generated at 2022-06-23 14:15:27.532996
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, item1, item2):
            self.item1 = item1
            self._item2 = item2
            self.__item3 = None

    test_class = TestClass(item1=1, item2=2)

    assert object_to_dict(test_class) == {'item1': 1, '_item2': 2}
    assert object_to_dict(test_class, ['item1']) == {'_item2': 2}



# Generated at 2022-06-23 14:15:35.508351
# Unit test for function deduplicate_list
def test_deduplicate_list():
    testlist = ['a', 'b', 'c', 'a', 'b', 'd']
    expected_list = ['a', 'b', 'c', 'd']
    deduped_list = deduplicate_list(testlist)
    if deduped_list != expected_list:
        raise AssertionError("Deduped list " + str(deduped_list) + " does not match expected result " + str(expected_list))
    else:
        print("Deduped list " + str(deduped_list) + " matches expected result " + str(expected_list))

# Generated at 2022-06-23 14:15:46.570327
# Unit test for function pct_to_int
def test_pct_to_int():
    # Convert percentage to int
    assert pct_to_int('50%', 100) == 50
    # Convert percentage to int
    assert pct_to_int(20, 100) == 20
    # Convert percentage to int
    assert pct_to_int('50%', 100, min_value=0) == 50
    # Convert percentage to int
    assert pct_to_int('0%', 100, min_value=0) == 0
    # Convert percentage to int
    assert pct_to_int('0%', 100, min_value=1) == 1
    # Convert percentage to int
    assert pct_to_int('1%', 100, min_value=0) == 1


# Generated at 2022-06-23 14:15:50.298649
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 100, min_value=0) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0


# Generated at 2022-06-23 14:15:57.800056
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test = 'test'
            self.test2 = 'test2'
    obj = TestObject()
    assert object_to_dict(obj, exclude=['test']) == {'test2': 'test2'}
    assert object_to_dict(obj) == {'test': 'test', 'test2': 'test2'}

# Generated at 2022-06-23 14:16:03.168141
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.attribute1 = 1
            self.attribute2 = 2
            self.attribute3 = 3

    assert object_to_dict(Test()) == {"attribute1": 1, "attribute2": 2, "attribute3": 3}
    assert object_to_dict(Test(), exclude=['attribute1', 'attribute3']) == {"attribute2": 2}

# Generated at 2022-06-23 14:16:11.061022
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self._excluded = 'excluded'
            self.description = 'description'
            self.excluded_from_list = 'excluded_from_list'
    test_class = TestClass()
    test_object_dict = object_to_dict(test_class, ['excluded_from_list'])
    assert isinstance(test_object_dict, dict)
    assert 'excluded' not in test_object_dict
    assert 'description' in test_object_dict
    assert 'excluded_from_list' not in test_object_dict



# Generated at 2022-06-23 14:16:13.522923
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:16:18.493346
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectToDict(object):
        def __init__(self):
            self.a = dict(k1='v1', k2='v2')
            self.b = 'b'
            self.c = ['c']

    obj = ObjectToDict()
    assert obj.a is not None
    assert obj.b is not None
    assert obj.c is not None

    result = object_to_dict(obj)

    assert 'a' in result
    assert result['a'] == obj.a
    assert 'b' in result
    assert result['b'] == obj.b
    assert 'c' in result
    assert result['c'] == obj.c
    assert '__dict__' not in result


# Generated at 2022-06-23 14:16:25.530557
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.value1 = 'value1'
            self.value2 = 'value2'
            self._value3 = 'value3'

    t = TestClass()
    assert object_to_dict(t) == {'value1': 'value1', 'value2': 'value2'}
    assert object_to_dict(t, ['value1']) == {'value2': 'value2'}

# Generated at 2022-06-23 14:16:30.510829
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','c','b','a','a','a']) == ['a','b','c']
    assert deduplicate_list(['a','a','a']) == ['a']
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:16:38.005439
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('2%', 100) == 2
    assert pct_to_int('2%', 1000) == 20

    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('150%', 100) == 100

    assert pct_to_int(2, 100) == 2
    assert pct_to_int(2, 1000) == 2

    assert pct_to_int(1, 100) == 1
    assert pct_to_int(0, 100) == 1

# Generated at 2022-06-23 14:16:46.182768
# Unit test for function pct_to_int
def test_pct_to_int():
    a = pct_to_int(10, 100)
    assert a == 10

    b = pct_to_int(10, 100, min_value=10)
    assert b == 10

    c = pct_to_int(10, 100, min_value=11)
    assert c == 11

    d = pct_to_int('10%', 100)
    assert d == 10

    e = pct_to_int('10%', 100, min_value=10)
    assert e == 10

    f = pct_to_int('10%', 100, min_value=11)
    assert f == 11


# Generated at 2022-06-23 14:16:57.063064
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'b', 'b', 'b']) == ['a', 'b']

# Generated at 2022-06-23 14:17:05.697607
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("120%", 10) == 12
    assert pct_to_int("120%", 0) == 1
    assert pct_to_int("120%", 0, min_value=3) == 3
    assert pct_to_int("-20%", 10) == -2
    assert pct_to_int("-20%", 10, min_value=3) == 3
    assert pct_to_int("20", 10) == 20
    assert pct_to_int("-20", 10) == -20
    assert pct_to_int("-20", 10, min_value=3) == 3
    assert pct_to_int("-.2", 10) == -2
    assert pct_to_