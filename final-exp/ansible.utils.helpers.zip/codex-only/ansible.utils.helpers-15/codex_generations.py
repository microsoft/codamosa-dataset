

# Generated at 2022-06-23 14:07:03.404348
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['one','two','three','three','three','one','four','five','five']) == ['one','two','three','four','five']

# Generated at 2022-06-23 14:07:08.168337
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("15%", 100, min_value=1) == 15
    assert pct_to_int("15%", 1000, min_value=1) == 150
    assert pct_to_int("15%", 1, min_value=1) == 1
    assert pct_to_int("15", 100, min_value=1) == 15
    assert pct_to_int(15, 100, min_value=1) == 15

# Generated at 2022-06-23 14:07:12.182407
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 2, 4, 3, 5, 4, 6]) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-23 14:07:21.237459
# Unit test for function object_to_dict

# Generated at 2022-06-23 14:07:29.010438
# Unit test for function object_to_dict
def test_object_to_dict():
    class _Foo:
        def __init__(self, b, c, d, e=None):
            self.a = b
            self.b = c
            self.c = d
            self.d = e

    obj = _Foo(1, 2, 3)
    result = object_to_dict(obj)
    assert isinstance(result, dict)
    assert result == dict(a=1, b=2, c=3, d=None)

# Generated at 2022-06-23 14:07:39.929351
# Unit test for function pct_to_int
def test_pct_to_int():
    # Tests with float, float as string, int, int as string, percent sign and min_value of 1
    assert pct_to_int(0.2, 10) == 2
    assert pct_to_int('0.2', 10) == 2
    assert pct_to_int(2, 10) == 2
    assert pct_to_int('2', 10) == 2
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('20 %', 10) == 2

    # Tests with zero
    assert pct_to_int(0, 10) == 1
    assert pct_to_int(0, 10, min_value=0) == 0
    assert pct_to_int('0', 10) == 1

# Generated at 2022-06-23 14:07:46.741524
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 9) == 5
    assert pct_to_int('50%', 3, min_value=2) == 2
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(50, 9) == 5
    assert pct_to_int(50, 3, min_value=2) == 2



# Generated at 2022-06-23 14:07:53.393069
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        def __init__(self):
            self.my_prop = 'my_value'
            self.property_to_exclude = 'some_value'
    obj = MyObject()
    obj_dict = object_to_dict(obj, exclude=['property_to_exclude'])
    assert obj_dict
    assert 'my_prop' in obj_dict
    assert obj_dict['my_prop'] == 'my_value'
    assert 'property_to_exclude' not in obj_dict

# Generated at 2022-06-23 14:07:57.274943
# Unit test for function object_to_dict
def test_object_to_dict():
    class Mock:
        def __init__(self):
            self.key1 = 'value1'
            self._key2 = 'value2'

    data = object_to_dict(Mock())

    assert data.get('key1') == 'value1'
    assert data.get('_key2') is None

# Generated at 2022-06-23 14:08:04.596497
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int(50, 10, min_value=2) == 5
    assert pct_to_int(50, 10, min_value=300) == 3
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=3) == 3
    assert pct_to_int('1%', 100, min_value=300) == 3
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=300) == 300
    assert pct_to_int('0%', 100) == 0

# Generated at 2022-06-23 14:08:07.824307
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 5, 6, 2, 3, 5, 1, 3, 3, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1]) == [1, 5, 6, 2, 3]


# Generated at 2022-06-23 14:08:14.160434
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import operator

    original_list = ['b', 'c', 'd', 'c', 'a', 'b']
    new_list = deduplicate_list(original_list)
    assert len(new_list) == len(set(new_list))
    assert operator.eq(new_list, ['b', 'c', 'd', 'a'])

# Generated at 2022-06-23 14:08:15.849736
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']

# Generated at 2022-06-23 14:08:24.629599
# Unit test for function deduplicate_list
def test_deduplicate_list():
    duplicate_list = [1,2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,6,7,8,9,0,1,1,23]
    deduplicated_list = deduplicate_list(duplicate_list)
    print(deduplicated_list)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 23]


# Generated at 2022-06-23 14:08:31.368093
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('44%', 200) == 88
    assert pct_to_int('44%', 2) == 1
    assert pct_to_int('44%', 2, min_value=10) == 10
    assert pct_to_int('44', 200) == 44
    assert pct_to_int(44, 200) == 44
    assert pct_to_int(44, 200, min_value=1) == 44
    assert pct_to_int(44, 2) == 1



# Generated at 2022-06-23 14:08:33.508407
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:08:37.766662
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'a', 'b', 'a']) == ['a', 'b']

# Generated at 2022-06-23 14:08:46.656499
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.common.utils import object_to_dict
    class Test(object):
        def __init__(self, a, b, c, d, e=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e

    obj = Test(1, 2, 3, 4, 5)
    keywords = object_to_dict(obj)
    assert keywords['a'] == obj.a
    assert keywords['b'] == obj.b
    assert keywords['c'] == obj.c
    assert keywords['d'] == obj.d
    assert keywords['e'] == obj.e



# Generated at 2022-06-23 14:08:47.873963
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('2%', 10) == 1

# Generated at 2022-06-23 14:08:53.483209
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
    test_object = TestClass()
    test_dict = object_to_dict(test_object, exclude=['test_key2'])
    assert test_dict.get('test_key') == 'test_value'
    assert test_dict.get('test_key2', None) is None

# Generated at 2022-06-23 14:09:01.485114
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Test class for object_to_dict
        """
        a = 'a'
        b = 'b'

    test_object = TestClass()

    # Test without exclude
    result = object_to_dict(test_object)
    assert result == {'a': 'a', 'b': 'b'}

    # Test with exclude
    result = object_to_dict(test_object, exclude=['a'])
    assert result == {'b': 'b'}

    # Test with wrong exclude
    result = object_to_dict(test_object, exclude=['c'])
    assert result == {'a': 'a', 'b': 'b'}

    # Test object_to_dict with object having unicode attributes

# Generated at 2022-06-23 14:09:08.147083
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
    a = A()
    a_dict = object_to_dict(a)
    assert a_dict['a'] == 1
    assert a_dict['b'] == 2
    a_dict = object_to_dict(a, exclude=['b'])
    assert a_dict['a'] == 1
    assert 'b' not in a_dict

# Generated at 2022-06-23 14:09:12.836474
# Unit test for function pct_to_int
def test_pct_to_int():
    # Return an integer if given an integer
    assert pct_to_int(10, 100) == 10
    # Return a percentage of the given value
    assert pct_to_int('20%', 100) == 20
    # Return the given percentage as a integer
    assert pct_to_int('20', 100) == 20
    # Return an integer if given a float
    assert pct_to_int(.2, 100) == 1
    # Return a percentage of the given value as an integer
    assert pct_to_int('20.0%', 100) == 20
    # Return the given value as an integer
    assert pct_to_int('20.0', 100) == 20
    # Return the minimum value if 0 is given
    assert pct_to_int(.0, 100) == 1
    # Return the minimum

# Generated at 2022-06-23 14:09:18.018019
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [2, 3, 3, 4, 5, 3, 3, 7, 8, 1, 1, 7]
    assert deduplicate_list(test_list) == [2, 3, 4, 5, 7, 8, 1]

# Generated at 2022-06-23 14:09:23.156795
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [5, 1, 2, 3, 7, 4, 3, 5, 7]
    deduplicated_list = deduplicate_list(original_list)
    assert len(deduplicated_list) == 6
    assert deduplicated_list == [5, 1, 2, 3, 7, 4]



# Generated at 2022-06-23 14:09:26.467600
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:09:32.141767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 14:09:39.374945
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('200%', 100) == 100



# Generated at 2022-06-23 14:09:48.095280
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):

        def __init__(self, key):
            self._key = key

        def _internal(self):
            return 'internal'

    test_object = TestObject('test')
    test_object_excluding = TestObject('test')

    assert object_to_dict(test_object, exclude=None) == {'_key': 'test'}
    assert object_to_dict(test_object_excluding, exclude=['_internal']) == {'_key': 'test'}

# Generated at 2022-06-23 14:09:52.138665
# Unit test for function pct_to_int
def test_pct_to_int():
    for (pct, num_items, expected) in [('10%', 100, 10), ('10%', 1000, 100),
                                       ('2%', 100, 2), ('2%', 1000, 20)]:
        assert pct_to_int(pct, num_items) == expected

# Generated at 2022-06-23 14:09:58.696401
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for object_to_dict
    """
    class TestObject(object):
        def __init__(self):
            self.name = 'fred'
            self.age = 12
            self._private = 'should be excluded'
            self._private2 = 'should be excluded'
            self.exclude = 'should be excluded'

    obj = TestObject()
    results = object_to_dict(obj, ['exclude'])
    assert results['name'] == 'fred'
    assert results['age'] == 12
    assert '_private' not in results
    assert '_private2' not in results
    assert 'exclude' not in results



# Generated at 2022-06-23 14:10:02.007097
# Unit test for function object_to_dict
def test_object_to_dict():
    class Automobile:
        def __init__(self, color, make, model, speed):
            self.color = color
            self.make = make
            self.model = model
            self.speed = speed
            self.doors = 4

    vehicle = Automobile('red', 'honda', 'civic', 100)

    assert object_to_dict(vehicle, exclude=['doors']) == dict(color='red', make='honda', model='civic', speed=100)

# Generated at 2022-06-23 14:10:14.193452
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 2, 3, 3, 4, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 3, 3, 3, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 1, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 14:10:19.818208
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 1, 2, 3, 3, 4, 2, 1, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 1, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 1, 2, 3, 3, 3, 4, 1, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]


# Generated at 2022-06-23 14:10:27.549524
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int(50, 100, min_value=0) == 50
    assert pct_to_int('20%', 100, min_value=0) == 20
    assert pct_to_int('20%', 1, min_value=0) == 1
    assert type(pct_to_int('20%', 100, min_value=0)) == int

# Generated at 2022-06-23 14:10:31.812300
# Unit test for function object_to_dict
def test_object_to_dict():
    class C(object):
        def __init__(self):
            self.__a = 1
            self.b = 2

    c = C()
    c_dict = object_to_dict(c, exclude=['__a'])
    assert '__a' not in c_dict
    assert c_dict['b'] == 2

# Generated at 2022-06-23 14:10:35.710188
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    expected_result = {'a': 1, 'b': 2}
    assert expected_result == object_to_dict(Foo())



# Generated at 2022-06-23 14:10:37.653329
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        x = 1

    result = dict()
    result['x'] = 1

    assert object_to_dict(TestClass) == result


# Generated at 2022-06-23 14:10:41.722401
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:
        def __init__(self):
            self.a = 1
            self.b = 2

    obj = MyClass()
    assert object_to_dict(obj) == dict(a=1, b=2)
    assert object_to_dict(obj, ['a']) == dict(b=2)
    assert object_to_dict(obj, 'a') == dict(b=2)

# Generated at 2022-06-23 14:10:44.098200
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'bar', 'bar', 'baz']) == ['foo', 'bar', 'baz']



# Generated at 2022-06-23 14:10:49.785558
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 75) == 38
    assert pct_to_int('50%', 75, min_value=3) == 38

# Generated at 2022-06-23 14:10:57.621899
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:
        def __init__(self):
            self.field1 = "value1"
            self._field2 = "value2"
            self.field3 = "value3"
    obj = MyClass()
    assert object_to_dict(obj) == {'field1': 'value1', '_field2': 'value2', 'field3': 'value3'}
    assert object_to_dict(obj, exclude=['field1']) == {'_field2': 'value2', 'field3': 'value3'}

# Generated at 2022-06-23 14:11:01.402138
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 2
    assert pct_to_int(10, 100, min_value=2) == 10

# Generated at 2022-06-23 14:11:06.129693
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 300) == 100
    assert pct_to_int(33, 100) == 33
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('33.33%', 100) == 33
    assert pct_to_int('33.33%', 0) == 1



# Generated at 2022-06-23 14:11:10.051230
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['red', 'red', 'red', 'blue', 'blue', 'blue', 'blue', 'green', 'green', 'green']
    assert ['red', 'blue', 'green'] == deduplicate_list(test_list)

# Generated at 2022-06-23 14:11:20.237708
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('0', 100) == 0
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('50%', 600) == 300
    assert pct_to_int('50%', 600, min_value=1) == 1
    assert pct_

# Generated at 2022-06-23 14:11:26.575907
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, name):
            self.name = name

    t = TestClass('test')
    assert object_to_dict(t) == {'name': 'test'}
    t.new_attr = 'new'
    assert object_to_dict(t) == {'name': 'test', 'new_attr': 'new'}
    assert object_to_dict(t, exclude=['name']) == {'new_attr': 'new'}

# Generated at 2022-06-23 14:11:33.389802
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = FakeObj(**dict(hello=1, world=FakeObj(**dict(hello=2))))
    obj2 = FakeObj(**dict(hello=1, world=FakeObj(**dict(hello=2))))
    obj_dict = object_to_dict(obj, exclude=['test_exclude'])
    obj_dict2 = object_to_dict(obj2, exclude=['test_exclude'])
    assert obj_dict == obj_dict2



# Generated at 2022-06-23 14:11:41.341033
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=100) == 100
    assert pct_to_int('1%', 100, min_value=100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(80, 100) == 80
    assert pct_to_int(99, 100)

# Generated at 2022-06-23 14:11:46.804084
# Unit test for function object_to_dict
def test_object_to_dict():
    class Person:
        def __init__(self):
            self.name = 'John Doe'
            self.age = 20

    john = Person()
    john_dict = object_to_dict(john)
    assert john_dict['name'] == 'John Doe'
    assert john_dict['age'] == 20



# Generated at 2022-06-23 14:11:51.237745
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        test_attr = 'test str'
        test_attr_2 = 'test str 2'

    tc = TestClass()
    tc_dict = object_to_dict(tc)
    assert tc_dict['test_attr'] == 'test str'
    assert tc_dict['test_attr_2'] == 'test str 2'
    assert '__module__' in tc_dict


# Generated at 2022-06-23 14:12:01.591385
# Unit test for function object_to_dict
def test_object_to_dict():
    class ChangeMe(object):
        def __init__(self):
            self.test = 'test'
            self.test2 = 'test2'
            self.test3 = 'test3'
            self.test4 = 'test4'

    myobj = ChangeMe()
    ret_dict = object_to_dict(myobj)
    assert ret_dict['test'] == 'test'
    assert ret_dict['test2'] == 'test2'
    assert ret_dict['test3'] == 'test3'
    myobj.test3 = 'test3b'
    assert ret_dict['test3'] == 'test3'   # ensure it doesn't actually change the dictionary
    assert ret_dict['test4'] == 'test4'

# Generated at 2022-06-23 14:12:11.436675
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.name = 'test'
            self.age = 5
            self.is_nice = True

    # Create a new person object with some sample properties
    person = TestClass()

    # Create a dictionary of the person's properties excluding the name and age
    person_dict = object_to_dict(person, exclude=['name', 'age'])

    # Assert that the name and age were not copied over
    assert 'name' not in person_dict
    assert 'age' not in person_dict

    # Assert that the person's is_nice property is included
    assert 'is_nice' in person_dict
    assert person_dict['is_nice']



# Generated at 2022-06-23 14:12:17.258893
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.ansible = "ansible"
            self.test = "test"

    f = Foo()

    assert object_to_dict(f) == {'ansible': 'ansible', 'test': 'test'}
    assert object_to_dict(f, exclude=['ansible']) == {'test': 'test'}
    assert object_to_dict(f, exclude=['ansible']) != {'ansible': 'ansible', 'test': 'test'}

# Generated at 2022-06-23 14:12:20.360590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_1 = ["a", "b", "c", "a", "b"]
    assert deduplicate_list(list_1) == ["a", "b", "c"]



# Generated at 2022-06-23 14:12:30.821651
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,2,2,2,2]) == [1,2]
    assert deduplicate_list([1,2,1,1,2,2,2]) == [1,2]
    assert deduplicate_list([1,1,1,1,1,1,1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['abc','abc','abc','abc','abc']) == ['abc']
    assert deduplicate_list(['abc','abc','abc','cde','cde','cde']) == ['abc', 'cde']
    assert deduplicate_list(['abc','def','ghi','jkl']) == ['abc', 'def', 'ghi', 'jkl']



# Generated at 2022-06-23 14:12:34.865538
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = "a"
            self._b = "b"
            self._c = "c"
    a = A()
    assert object_to_dict(a, ["_c"]) == {'a': 'a', '_b': 'b'}



# Generated at 2022-06-23 14:12:42.789818
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.prop1 = "This is a test"
            self.prop2 = "Exclude me"
            self._prop3 = "This should be excluded"
    assert object_to_dict(MyClass()) == {'prop1': 'This is a test'}
    assert object_to_dict(MyClass(), exclude=['prop2']) == {'prop1': 'This is a test'}
    assert object_to_dict(MyClass(), exclude=['_prop3']) == {'prop1': 'This is a test', 'prop2': 'Exclude me'}

# Generated at 2022-06-23 14:12:52.381431
# Unit test for function pct_to_int
def test_pct_to_int():
    
    # Testing exact value
    assert pct_to_int('100%', 9) == 9

    # Testing value with < sign
    assert pct_to_int('<100%', 9) == 9

    # Testing value with > sign
    assert pct_to_int('>100%', 9) == 9

    # Testing value with % sign and non-string type
    assert pct_to_int('100%', 9) == pct_to_int(100, 9)

    # Testing default value
    assert pct_to_int('0%', 9) == 1

    # Testing 0% value
    assert pct_to_int('0%', 9, min_value=0) == 0

    # Testing 80th percentile value
    assert pct_to_int('80%', 9) == 7

    # Testing 80

# Generated at 2022-06-23 14:12:59.884308
# Unit test for function pct_to_int
def test_pct_to_int():
    try:
        assert pct_to_int(2, 2) == 2
        assert pct_to_int(2, 5) == 2
        assert pct_to_int('2', 5) == 2
        assert pct_to_int('1%', 5) == 1
        assert pct_to_int('20%', 5) == 1
        assert pct_to_int('50%', 20) == 10
        assert pct_to_int('50%', 20, min_value=5) == 10
        assert pct_to_int('50%', 20, min_value=20) == 20
    except:
        raise AssertionError

# Generated at 2022-06-23 14:13:07.941232
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("51%", 100) == 51
    assert pct_to_int("49%", 100) == 49
    assert pct_to_int("49%", 100, 5) == 5
    assert pct_to_int("50%", 100, 5) == 50
    assert pct_to_int("51%", 100, 5) == 51
    assert pct_to_int("52%", 100, 5) == 52
    assert pct_to_int("53%", 100, 5) == 53
    assert pct_to_int("54%", 100, 5) == 54


# Generated at 2022-06-23 14:13:12.002502
# Unit test for function deduplicate_list
def test_deduplicate_list():
    duplicates_list = ['a', 'b', 'c', 'd', 'a', 'b', 'e', 'a']
    assert deduplicate_list(duplicates_list) == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-23 14:13:16.794364
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        a = 1
        b = 2
    test_obj = test_class()
    assert object_to_dict(test_obj) == {'a': 1, 'b': 2}
    assert object_to_dict(test_obj, exclude=['a']) == {'b': 2}


# Generated at 2022-06-23 14:13:27.838435
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        pass

    class MySubObject(object):
        pass

    my_obj = MyObject()
    my_obj.test_value = 'test value'
    my_obj.test_value2 = 'test value2'
    my_obj.test_inner_obj = MySubObject()
    my_obj.test_inner_obj.test_value = 'test inner value'

    my_obj.test_list = []
    my_obj.test_list.append('test_string1')
    my_obj.test_list.append('test_string2')

    my_obj.test_exclude_me = 'test'

    my_obj_dict = object_to_dict(my_obj, ['test_exclude_me'])

    assert my_obj_dict['test_value']

# Generated at 2022-06-23 14:13:33.838761
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert([1, 2, 3] == deduplicate_list([1, 2, 3, 2, 1]))
    assert(['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c', 'b', 'a']))
    assert([1, 2, 'a', 'b', 'c'] == deduplicate_list([1, 'a', 'b', 2, 'c', 1, 'b']))



# Generated at 2022-06-23 14:13:40.290096
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.attr1 = 'foo'
            self.attr2 = 'bar'
            self.attr3 = 'baz'
            self._attr4 = 'foo'
            self._attr5 = 'bar'
            self._attr6 = 'baz'
    obj = MyClass()
    result = object_to_dict(obj)
    assert result == {'attr1': 'foo', 'attr2': 'bar', 'attr3': 'baz'}



# Generated at 2022-06-23 14:13:41.541006
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10", 10, min_value=0) == 1

# Generated at 2022-06-23 14:13:53.491827
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.facts.nxos.facts import Hardware
    from ansible.module_utils.facts.nxos.facts import Interface
    from ansible.module_utils.facts.nxos.facts import InterfaceIP
    from ansible.module_utils.facts.nxos.facts import InterfaceIPv6
    from ansible.module_utils.facts.nxos.facts import NetworkConfig
    from ansible.module_utils.facts.nxos.facts import SysLocation
    from ansible.module_utils.facts.nxos.facts import SysContact
    from ansible.module_utils.facts.nxos.facts import SysName


# Generated at 2022-06-23 14:14:02.614776
# Unit test for function pct_to_int
def test_pct_to_int():
    if pct_to_int("75%", 100) != 75:
        raise AssertionError("Percent to int failed 75%")
    if pct_to_int("121%", 100) != 100:
        raise AssertionError("Percent to int failed 121%")
    if pct_to_int("1%", 100) != 1:
        raise AssertionError("Percent to int failed 1%")
    if pct_to_int("50%", 50) != 50:
        raise AssertionError("Percent to int failed 50% of 50")
    if pct_to_int("50%", 20) != 20:
        raise AssertionError("Percent to int failed 50% of 20")

# Generated at 2022-06-23 14:14:10.851619
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('0.5', 100) == 50
    assert pct_to_int('50000000000%', 100) == 100
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('10.5%', 100) == 11

# Generated at 2022-06-23 14:14:16.197269
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.var1 = 'test'
            self.var2 = 'test2'

    obj = TestClass()
    test_dict = object_to_dict(obj)
    assert test_dict['var1'] == 'test'
    assert test_dict['var2'] == 'test2'

# Generated at 2022-06-23 14:14:18.295454
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'b', 'c', 'a']) == ['a', 'b', 'c', 'a']


# Generated at 2022-06-23 14:14:24.650959
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test deduplicate list
    """
    mylist = ["a", "b", "a", "c", "d", "a", "d", "f", "b", "c", "c"]
    assert deduplicate_list(mylist) == ["a", "b", "c", "d", "f"]

# Generated at 2022-06-23 14:14:29.767120
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.str = "value"
            self.list = [1, 2, 3]
            self._exclude_me = "1"

    obj = TestObject()
    result = object_to_dict(obj, ['_exclude_me'])
    assert isinstance(result, dict)
    assert result == {'str': 'value', 'list': [1, 2, 3]}



# Generated at 2022-06-23 14:14:39.419852
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self, test_one, test_two=None):
            self.test_one = test_one
            self.test_two = test_two

        def _test_dummy(self):
            pass

    test_obj = Test('one')
    test_dict = object_to_dict(Test('one'))

    correct_dict = test_obj.__dict__.copy()
    correct_dict['test_two'] = None
    assert correct_dict == test_dict

    test_dict = object_to_dict(Test('one'), exclude=['test_one'])

    assert 'test_one' not in test_dict
    assert 'test_two' in test_dict


# Generated at 2022-06-23 14:14:46.684782
# Unit test for function pct_to_int
def test_pct_to_int():
    '''Test function pct_to_int'''
    num_items = 20
    assert pct_to_int(10, num_items) == 10
    assert pct_to_int('10%', num_items) == 2
    assert pct_to_int('1%', num_items) == 1
    assert pct_to_int('0%', num_items) == 1
    assert pct_to_int('-1%', num_items) == 1

# Generated at 2022-06-23 14:14:54.011986
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObj:
        def __init__(self, x, y, z, a=1, b=2, c=3):
            self.x = x
            self.y = y
            self.z = z
            self.a = a
            self.b = b
            self.c = c

    expected_dict = dict(x=1, y="test", z=False)
    my_obj = MyObj(1, "test", False)

    assert expected_dict == object_to_dict(my_obj, exclude=['a', 'b', 'c'])

# Generated at 2022-06-23 14:14:57.695935
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 4, 1]
    deduplicated_list = [1, 2, 3, 4]
    assert(deduplicated_list == deduplicate_list(original_list))



# Generated at 2022-06-23 14:15:03.820365
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['hello', 'world', 'hello', 'world', 'there', 'there']) == ['hello', 'world', 'there']
    assert deduplicate_list(['hello', 'world', 'there']) == ['hello', 'world', 'there']
    assert deduplicate_list(['hello']) == ['hello']
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:15:08.897088
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        def __init__(self):
            self.prop1 = 1
            self.prop2 = 2
    o = Object()
    assert object_to_dict(o) == {'prop1': 1, 'prop2': 2}
    assert object_to_dict(o, ['prop1']) == {'prop2': 2}

# Generated at 2022-06-23 14:15:13.827951
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_dedup = [2, 3, 4, 2, 3, 1, 0, 2, 3]
    deduped_list = [0, 1, 2, 3, 4]
    assert deduped_list == deduplicate_list(list_to_dedup)

# Generated at 2022-06-23 14:15:18.671481
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass0(object):
        def __init__(self):
            self.a1 = 1
            self.a2 = 2
            self._a3 = 3

    class TestClass1(object):
        def __init__(self):
            self.b1 = 4
            self.b2 = 5
            self._b3 = 6

        def exclude_me(self):
            return

        def exclude_me_too(self):
            return

    test_obj_list = [
        TestClass0(),
        TestClass1(),
    ]

    test_obj_dict_list = [
        {'a1': 1, 'a2': 2},
        {'b1': 4, 'b2': 5},
    ]

    for i in range(len(test_obj_list)):
        assert object_to

# Generated at 2022-06-23 14:15:28.510717
# Unit test for function object_to_dict
def test_object_to_dict():
    class Sample(object):
        def __init__(self, name='test', version=1, family='eos', os='eos',
                     model='vEOS'):
            self.name = name
            self.version = version
            self.family = family
            self.os = os
            self.model = model

    res = object_to_dict(Sample())
    assert res['name'] == 'test'
    assert res['version'] == 1
    assert res['family'] == 'eos'
    assert res['os'] == 'eos'
    assert res['model'] == 'vEOS'

    res = object_to_dict(Sample(name='qfx5200-48t-6q', model='qfx5200-48t-6q'), exclude=['name'])
    assert 'name' not in res

# Generated at 2022-06-23 14:15:37.140968
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test with no input
    assert pct_to_int(None, 100, None) == None

    # Test with 100%
    assert pct_to_int('100%', 100, None) == 100

    # Test with 100% with min_value
    assert pct_to_int('100%', 100, 1) == 100

    # Test with 0% with min_value
    assert pct_to_int('0%', 100, 1) == 1

    # Test with 50% with min_value
    assert pct_to_int('50%', 100, 1) == 50

    # Test with 100
    assert pct_to_int(100, 100, None) == 100

    # Test with 0
    assert pct_to_int(0, 100, None) == 0

    # Test with 50
    assert pct

# Generated at 2022-06-23 14:15:41.560254
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['one', 'two', 'three', 'one', 'two']) == ['one', 'two', 'three']

# Generated at 2022-06-23 14:15:49.698933
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    ObjectToDict: Unit test for function object_to_dict
    """
    class MockTestClass(object):
        """
        Mock class for testing
        """
        def __init__(self):
            self.attr1 = 'value1'
            self.attr2 = 'value2'
            self.attr3 = 'value3'

    test_obj = MockTestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict == {'attr1': 'value1', 'attr2': 'value2', 'attr3': 'value3'}

    test_dict = object_to_dict(test_obj, ['attr1'])
    assert test_dict == {'attr2': 'value2', 'attr3': 'value3'}

# Generated at 2022-06-23 14:15:57.662208
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.test_attr1 = "test_attr1"
            self.test_attr2 = "test_attr2"
    actual = object_to_dict(test_class())
    expected = {'test_attr1': 'test_attr1', 'test_attr2': 'test_attr2'}
    assert actual == expected



# Generated at 2022-06-23 14:16:03.554258
# Unit test for function object_to_dict
def test_object_to_dict():
    class test(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    obj_instance = test()
    result = object_to_dict(obj_instance, ['d'])
    assert sorted(result.keys()) == ['a', 'b', 'c', 'e', 'f']

# Generated at 2022-06-23 14:16:12.358965
# Unit test for function pct_to_int
def test_pct_to_int():
    if pct_to_int("50%", 100) != 50:
        assert False
    if pct_to_int("50%", 100, 1) != 50:
        assert False
    if pct_to_int("50%", 100, 2) != 50:
        assert False
    if pct_to_int("50", 100, 2) != 50:
        assert False
    if pct_to_int("50%", 100, 1) != 50:
        assert False
    if pct_to_int("49%", 100, 1) != 49:
        assert False
    if pct_to_int("50.5%", 100, 1) != 51:
        assert False
    print("test_pct_to_int: PASSED")

# Generated at 2022-06-23 14:16:18.563096
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.first_key = 'value'
            self.second_key = 'value'

    obj_dict = object_to_dict(Obj())
    assert obj_dict['first_key'] == 'value'
    assert obj_dict['second_key'] == 'value'
    assert len(obj_dict) == 2

    obj_dict = object_to_dict(Obj(), exclude=['first_key'])
    assert obj_dict['second_key'] == 'value'
    assert len(obj_dict) == 1

    obj_dict = object_to_dict(Obj(), exclude=['first_key', 'second_key'])
    assert len(obj_dict) == 0

# Generated at 2022-06-23 14:16:24.857976
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100, 0) == 10
    assert pct_to_int(10.1, 100, 0) == 10
    assert pct_to_int("10%", 100, 0) == 10
    assert pct_to_int("10.1%", 100, 0) == 10
    assert pct_to_int("10.1%", 1000, 0) == 101

# Generated at 2022-06-23 14:16:26.078679
# Unit test for function pct_to_int
def test_pct_to_int():
    result = pct_to_int("50%", 100)
    assert result == 50

# Generated at 2022-06-23 14:16:31.862254
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object:
        def __init__(self, key1, key2):
            self.key1 = key1
            self.key2 = key2
    assert object_to_dict(test_object('value1', 'value2')) == {'key1': 'value1', 'key2': 'value2'}

if __name__ == '__main__':
    test_object_to_dict()

# Generated at 2022-06-23 14:16:37.428568
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    test_obj = namedtuple('Test', ['a', 'b'])
    assert object_to_dict(test_obj(a=1, b=2)) == {'a': 1, 'b': 2}
    assert object_to_dict(test_obj(a=1, b=2), exclude=['b']) == {'a': 1}
    assert object_to_dict(test_obj(a=1, b=2), exclude=['a']) == {'b': 2}


# Generated at 2022-06-23 14:16:47.187338
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int('1%', 100)
    assert 2 == pct_to_int('2%', 100)
    assert 3 == pct_to_int('3%', 100)
    assert 4 == pct_to_int('4%', 100)
    assert 6 == pct_to_int('6%', 100)
    assert 6 == pct_to_int('6.2%', 100)
    assert 7 == pct_to_int('6.5%', 100)
    assert 1 == pct_to_int('0%', 100)
    assert 1 == pct_to_int('-1%', 100)
    assert 1 == pct_to_int('-2%', 100)
    assert 1 == pct_to_int('0%', 100)
    assert 1 == pct

# Generated at 2022-06-23 14:16:55.539869
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2, 1]) == [1, 2]

# Generated at 2022-06-23 14:16:59.332463
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test1 = 1234
            self.test2 = 5678
            self.test3 = "abcd"
            self.test4 = "EFGH"
            self.test5 = True

        def test6(self):
            return "NotTest"

    my_class = TestClass()
    test_obj = object_to_dict(my_class, exclude=['test6'])
    assert test_obj['test1'] == 1234
    assert test_obj['test2'] == 5678
    assert test_obj['test3'] == "abcd"
    assert test_obj['test4'] == "EFGH"
    assert test_obj['test5']
    assert 'test6' not in test_obj



# Generated at 2022-06-23 14:17:03.878590
# Unit test for function pct_to_int
def test_pct_to_int():
    total_elements = 10
    assert pct_to_int('50%', total_elements) == 5
    assert pct_to_int(50, total_elements) == 5
    assert pct_to_int(50.0, total_elements) == 5
    assert pct_to_int(50.0, total_elements, min_value=2) == 5