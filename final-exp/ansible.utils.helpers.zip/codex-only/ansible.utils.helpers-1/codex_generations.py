

# Generated at 2022-06-23 14:07:07.962028
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'a', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['b', 'a', 'a', 'a', 'c']) == ['b', 'a', 'c']

# Generated at 2022-06-23 14:07:12.432064
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 1, 3, 4, 5, 4, 6, 'test', 'test']) == [1, 2, 3, 4, 5, 6, 'test']



# Generated at 2022-06-23 14:07:19.129663
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("123%", 1) == 1
    assert pct_to_int("123%", 1000, 10) == 123
    assert pct_to_int("99%", 100) == 99
    assert pct_to_int("101%", 100) == 101
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1", 100) == 1

# Generated at 2022-06-23 14:07:21.495060
# Unit test for function deduplicate_list
def test_deduplicate_list():
    actual = deduplicate_list([1, 2, 2, 3, 2, 1, 2, 3])
    expected = [1, 2, 3]
    assert actual == expected



# Generated at 2022-06-23 14:07:31.396043
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('30%', 100) == 30
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(30, 100) == 30
    assert pct_to_int(30.5, 100) == 30
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, 0) == 0
    assert pct_to_int('200%', 100) == 100
    assert pct_to_int('200%', 100, 0) == 100

# Unit tests for function object_to_dict

# Generated at 2022-06-23 14:07:38.766371
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test excluded keys
    class TestObject():
        def __init__(self, key1, key2, key3):
            self.key1 = key1
            self.key2 = key2
            self.key3 = key3

    test = TestObject('test1', 'test1', 'test1')
    assert object_to_dict(test, exclude=['key1', 'key2']) == {'key3': 'test1'}

    # Test with no excluded keys
    class TestObject2():
        def __init__(self, key1, key2, key3):
            self.key1 = key1
            self.key2 = key2
            self.key3 = key3

    test2 = TestObject2('test1', 'test1', 'test1')

# Generated at 2022-06-23 14:07:44.540841
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100.0%', 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50

    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0', 100) == 1

    assert pct_to_int(0, 1) == 1
    assert pct_to_int('0%', 1) == 1
    assert pct_to_int('0', 1) == 1

# Generated at 2022-06-23 14:07:54.248122
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(51, 100) == 51
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=4) == 50
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('49.5%', 100) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0.99%', 100) == 1
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('0.06%', 100) == 1

# Generated at 2022-06-23 14:07:58.849338
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 10) == 1
    assert pct_to_int('100%', 0) == 0
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int(50, 100) == 50


# Generated at 2022-06-23 14:08:01.274306
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'a', 'c', 'b', 'a']
    assert deduplicate_list(original_list) == ['b', 'a', 'c']


# Generated at 2022-06-23 14:08:07.627545
# Unit test for function deduplicate_list
def test_deduplicate_list():
    mylist = [1,2,1,1,2,3,2]
    deduplicated = deduplicate_list(mylist)
    if (len(deduplicated) != 3):
        raise AssertionError("Deduplication failed")
    for i, item in enumerate(deduplicated):
        count = mylist.count(item)
        if (count > 1):
            raise AssertionError("Deduplication failed")
        if (mylist[i] != item):
            raise AssertionError("Ordering not maintained")

# Generated at 2022-06-23 14:08:16.845391
# Unit test for function pct_to_int
def test_pct_to_int():
     assert pct_to_int(10, 100) == 10
     assert pct_to_int('20%', 100) == 20
     assert pct_to_int('20%', 1000) == 200
     assert pct_to_int('5%', 100) == 5
     assert pct_to_int('5%', 100, min_value=2) == 2
     assert pct_to_int('50%', 0) == 0
     assert pct_to_int('50%', 0, min_value=1) == 1
     assert pct_to_int('50%', 10) == 5

# Generated at 2022-06-23 14:08:23.600887
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = "a"
            self.b = "b"

    c = TestClass()
    result = object_to_dict(c)
    assert result == {'a': 'a', 'b': 'b'}

    result = object_to_dict(c, exclude=['a'])
    assert result == {'b': 'b'}

# Generated at 2022-06-23 14:08:32.912081
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert (deduplicate_list(["a","b","a","c","c","c","b","a","d","e","c","d","f","f"]) == ["a","b","c","d","e","f"])
    assert (deduplicate_list([1,1,2,3,4,4,4,5,6,7,8,8,8,7,9]) == [1,2,3,4,5,6,7,8,9])
    assert (deduplicate_list([1]) == [1])
    assert (deduplicate_list([]) == [])
    assert (deduplicate_list(["a","a","a","a","a","a","a","a","a","a","a","a","a","a","a"]) == ["a"])

# Generated at 2022-06-23 14:08:38.594916
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test1 = "test1"
            self._test2 = "test2"
            self.test3 = "test3"

    result = object_to_dict(TestObject)
    assert result['test1'] == "test1"
    assert result['test3'] == "test3"
    assert 'test2' not in result



# Generated at 2022-06-23 14:08:45.241937
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.value = 'test'
            self.value1 = 'test1'
            self.value2 = 'test2'

    obj = Obj()
    excluded_field = 'value2'
    expected_dict = {'value': 'test', 'value1': 'test1'}

    actual_dict = object_to_dict(obj, exclude=[excluded_field])

    assert expected_dict == actual_dict


# Generated at 2022-06-23 14:08:48.251070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 2, 1, 3, 5]) == [1, 2, 3, 5]
    assert deduplicate_list(['Bob', 'Jon', 'Bob']) == ['Bob', 'Jon']

# Generated at 2022-06-23 14:08:51.870842
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_test = ['first', 'second', 'third', 'first', 'third', 'second']
    expected = ['first', 'second', 'third']
    result = deduplicate_list(list_test)
    assert result == expected
    print("OK")

# Generated at 2022-06-23 14:08:58.045798
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 10) == 5
    assert pct_to_int(5, 10, 2) == 5
    assert pct_to_int('5%', 10) == 5
    assert pct_to_int('5%', 10, 2) == 5
    assert pct_to_int('5%', 20) == 4
    assert pct_to_int('5%', 20, 2) == 2
    assert pct_to_int('100%', 50) == 50

# Generated at 2022-06-23 14:09:02.871418
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100) == 1



# Generated at 2022-06-23 14:09:09.733916
# Unit test for function object_to_dict
def test_object_to_dict():
    class myclass:
        def __init__(self):
            self.param1 = 'hello'
            self.param2 = 'world'

        def myfun(self):
            pass

    cls = myclass()
    assert object_to_dict(cls) == {'param1': 'hello', 'param2': 'world'}
    assert object_to_dict(cls, exclude=['param2']) == {'param1': 'hello'}



# Generated at 2022-06-23 14:09:12.954732
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'a', 'b', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'b', 'a', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:09:20.441806
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject():
        def __init__(self):
            self.name = "foo"
            self.passwd = "bar"
            self._hidden_password = "qux"

    obj = MyObject()
    assert object_to_dict(obj) == {"name": "foo", "passwd": "bar"}
    assert object_to_dict(obj, ["passwd"]) == {"name": "foo"}



# Generated at 2022-06-23 14:09:25.044918
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("8%", 10) == 1
    assert pct_to_int("8%", 0) == 1
    assert pct_to_int("8%", 100) == 8
    assert pct_to_int("20%", 100) == 20
    assert pct_to_int("30%", 0) == 1

# Generated at 2022-06-23 14:09:31.050918
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        test = 'test'
        test1 = 'test1'
        test2 = 'test2'

    assert object_to_dict(Test()) == {'test': 'test', 'test1': 'test1', 'test2': 'test2'}
    assert object_to_dict(Test(), ['test2']) == {'test': 'test', 'test1': 'test1'}



# Generated at 2022-06-23 14:09:35.794380
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.exclude_me = "yes"
            self.include_me = "yes"
    t = TestObj()
    d = object_to_dict(t, "exclude_me")
    assert "include_me" in d
    assert "exclude_me" not in d


# Generated at 2022-06-23 14:09:39.817253
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests function in module_utils/nxos
    """
    # Test empty list
    assert deduplicate_list([]) == []

    # Test single value
    assert deduplicate_list(['a']) == ['a']

    # Test multiple values
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']

    # Test duplicate values
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']

    # Test single value with random order of duplicates
    assert deduplicate_list(['a', 'a', 'a']) == ['a']

    # Test multiple values with random order of duplicates

# Generated at 2022-06-23 14:09:52.228928
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests object_to_dict function which converts an object's properties into a dict.
    """
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
        def test_method(self):
            pass
    test_obj = TestClass()
    result = object_to_dict(test_obj)

    # Check if properties 'a' through 'd' and no others are in the result
    assert len(result) == 4
    assert result['a'] == 1
    assert result['b'] == 2
    assert result['c'] == 3
    assert result['d'] == 4
    assert 'test_method' not in result


# Generated at 2022-06-23 14:09:55.888331
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 1, 4, 5, 2, 3, 4, 5, 8, 8, 7, 10, 12]
    result = [1, 2, 3, 4, 5, 8, 7, 10, 12]
    assert deduplicate_list(original_list) == result

# Generated at 2022-06-23 14:09:59.468292
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['1', '2', '2', '4', '4', '4', '4', '5']
    assert deduplicate_list(test_list) == ['1', '2', '4', '5']

# Generated at 2022-06-23 14:10:09.891696
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = "a"
            self.b = "b"
            self.c = "c"
            self.d = "d"
    test_obj = TestClass()
    result = object_to_dict(test_obj)
    assert result['a'] == "a"
    assert result['b'] == "b"
    assert result['c'] == "c"
    assert result['d'] == "d"
    result = object_to_dict(test_obj, exclude=['a'])
    assert result.has_key("a") is False
    assert result['b'] == "b"
    assert result['c'] == "c"

# Generated at 2022-06-23 14:10:17.334116
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        name = None
        b = None
        def __init__(self, name, b):
            self.name = name
            self.b = b
    testclass = TestClass("Test", True)
    expected_result = {"name": "Test", "b": True}
    result = object_to_dict(testclass)
    assert result == expected_result
    testclass = TestClass("Test", True)
    expected_result = {"b": True}
    result = object_to_dict(testclass, ["name"])
    assert result == expected_result


# Generated at 2022-06-23 14:10:28.923340
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Verify that the function removes duplicates and preserves the order of the first appearance.
    """
    original_list = [1,2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,3,3,3,3,3]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4]
    assert original_list != deduplicated_list

#

# Generated at 2022-06-23 14:10:34.686226
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = TestClass()
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(obj, exclude=['b']) == {'a': 1, 'c': 3}



# Generated at 2022-06-23 14:10:38.463136
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 2, 3]
    dedupe_list = deduplicate_list(original_list)
    if not (1 in dedupe_list and 2 in dedupe_list and 3 in dedupe_list):
        raise ValueError("Failed to deduplicate list")

# Generated at 2022-06-23 14:10:43.671229
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('1000', 100) == 100
    assert pct_to_int('1', 1000) == 1
    assert pct_to_int('0.5', 1000) == 1

# Generated at 2022-06-23 14:10:48.922543
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    obj = MyClass()
    obj_dict = object_to_dict(obj)
    assert obj_dict['a'] == 1
    assert obj_dict['b'] == 2

# Generated at 2022-06-23 14:10:54.593367
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,1,3,4,2,5,6,2,1,1]
    dedup_list = deduplicate_list(original_list)
    assert dedup_list == [1,2,3,4,5,6]
    # Ensure that original list is unchanged
    assert original_list == [1,2,1,3,4,2,5,6,2,1,1]


# Generated at 2022-06-23 14:10:59.911636
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(50, 200) == 100)
    assert(pct_to_int(50, 200, min_value=15) == 15)
    assert(pct_to_int('50%', 200) == 100)
    assert(pct_to_int('50%', 200, min_value=15) == 15)



# Generated at 2022-06-23 14:11:08.187296
# Unit test for function object_to_dict
def test_object_to_dict():
    class Person(object):
        def __init__(self, first_name, last_name, hair_color, age):
            self.first_name = first_name
            self.last_name = last_name
            self.hair_color = hair_color
            self.age = age

            self.hidden_attribute = True

    person = Person('Joe', 'Blow', 'Brown', 10)

    result = object_to_dict(person, ['hidden_attribute'])

    result['hidden_attribute'] = False

    assert result == {'first_name': 'Joe', 'hair_color': 'Brown', 'age': 10, 'last_name': 'Blow', 'hidden_attribute': False}

# Generated at 2022-06-23 14:11:13.364942
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = deduplicate_list(['a', 'b', 'c', 'b', 'c', 'a'])
    module.exit_json(changed=False, ansible_facts={'result': result, 'compare_to': ['a', 'b', 'c']})

# Generated at 2022-06-23 14:11:22.925227
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    All combinations of num_items, min_value and pct value
    """
    # Argument list as
    # num_items, min_value, pct value, expected output
    test_cases = [
        (1,1,'10%',1),
        (1,1,'100%',1),
        (1,1,10,10),
        (100,1,'100%',100),
        (100,1,100,100),
        (100,1,'10%',10),
        (100,1,10,10),
    ]

    for test_case in test_cases:
        assert pct_to_int(test_case[2], test_case[0], test_case[1]) == test_case[3]

# Generated at 2022-06-23 14:11:30.242169
# Unit test for function object_to_dict
def test_object_to_dict():
    dummy_class = type("Dummy", (object,), {"_Dummy__private": "foo", "__magic": "bar"})
    dummy_class.foo = "bar"
    dummy_class.bar = "foo"
    result = object_to_dict(dummy_class, ["foo"])
    assert result.get("foo") is None
    assert result.get("bar") == "foo"
    assert result.get("_Dummy__private") is None
    assert result.get("__magic") is None

# Generated at 2022-06-23 14:11:39.725046
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100, min_value=1) == 50, "Must be 50"
    assert pct_to_int('101%', 100, min_value=1) == 101, "Must be 101"
    assert pct_to_int('90.5%', 100, min_value=1) == 91, "Must be 91"
    assert pct_to_int('0%', 100, min_value=1) == 1, "Must be 1"
    assert pct_to_int('-10%', 100, min_value=1) == 1, "Must be 1"
    assert pct_to_int('120%', 100, min_value=1) == 120, "Must be 120"
    assert pct_to_int('100%', 100, min_value=1) == 100

# Generated at 2022-06-23 14:11:49.727109
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Tests for function pct_to_int
    """

    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('123%', 100) == 100
    assert pct_to_int('1', 100) == 1
    assert pct_to_int('123', 100) == 123

    # Test min_value
    assert pct_to_int('1%', 100, 10) == 10
    assert pct_to_int('123%', 100, 10) == 100
    assert pct_to_int('1', 100, 10) == 1
    assert pct_to_int('123', 100, 10) == 123

# Generated at 2022-06-23 14:11:59.161412
# Unit test for function object_to_dict
def test_object_to_dict():
    class test1(object):
        def __init__(self):
            self.a = ''
            self.b = ''
            self.c = ''

    t1 = test1()
    t1.a = 1
    t1.b = 2
    t1.c = 3
    x = object_to_dict(t1)
    assert x == {'a': 1, 'c': 3, 'b': 2}

    t1.z = 4
    assert object_to_dict(t1) == {'a': 1, 'c': 3, 'b': 2, 'z': 4}


# Generated at 2022-06-23 14:12:04.489591
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100) == 1


# Generated at 2022-06-23 14:12:14.619925
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self):
            self.val1 = 'val1'
            self.val2 = 'val2'
            self._val3 = 'val3'
    t1 = test_class()
    assert object_to_dict(t1) == {'val1': 'val1', 'val2': 'val2'}, 'object to dict failed'
    assert object_to_dict(t1, exclude=['val1']) == {'val2': 'val2'}, 'object to dict with exclude failed'
    assert object_to_dict(t1, exclude=['val2']) == {'val1': 'val1'}, 'object to dict with exclude failed'

# Generated at 2022-06-23 14:12:18.619752
# Unit test for function pct_to_int
def test_pct_to_int():
    for value, num_items, target in [('30%', 1000, 300), ('30%', '1000', 300), ('30%', 1001, 301)]:
        assert(pct_to_int(value, num_items) == target)
    # Also make sure that if we specify less than the minimum, we get the minimum
    assert(pct_to_int('1%', 1000, 10) == 10)

# Generated at 2022-06-23 14:12:20.169698
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25.0%', 100) == 25

# Generated at 2022-06-23 14:12:30.702350
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test to see if the function deduplicate_list works as it should
    """
    new_list = deduplicate_list([3, 3, 3, 4, 1, 1, 2, 2, 2, 5, 6, 7, 7, 7, 8, 9, 9, 9, 10, 11])
    assert len(new_list) == 11   # check if the length is 11 (no duplicates)
    assert len([x for x in new_list if x == 3]) == 1   # check if there's only 1 '3' in the new list
    assert len([x for x in new_list if x == 1]) == 1   # check if there's only 1 '1' in the new list
    assert len([x for x in new_list if x == 5]) == 1   # check if there's only 1 '5' in

# Generated at 2022-06-23 14:12:37.848944
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self._internal = 3

    obj = test_class()
    obj_dict = object_to_dict(obj)
    assert obj_dict['a'] == 1
    assert obj_dict['b'] == 2
    assert obj_dict['_internal'] == 3
    obj_dict_excluding_internal = object_to_dict(obj, exclude=['_internal'])
    assert '_internal' not in obj_dict_excluding_internal



# Generated at 2022-06-23 14:12:45.473976
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 100, 2) == 10
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 100, 2) == 1
    assert pct_to_int("1%", 10) == 1
    assert pct_to_int("1%", 10, 2) == 1
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("0%", 10, 2) == 2
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("100%", 10, 2) == 10
    assert pct_to_int("101%", 10) == 10

# Generated at 2022-06-23 14:12:53.532716
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, param1='111', param2='222'):
            self.param1 = param1
            self.param2 = param2

    test = TestClass('first', 'second')
    test_dict = object_to_dict(test)
    assert test_dict['param1'] == 'first'
    assert test_dict['param2'] == 'second'

    test_dict = object_to_dict(test, exclude=['param2'])
    assert test_dict['param1'] == 'first'
    assert 'param2' not in test_dict.keys()


# Generated at 2022-06-23 14:12:58.375924
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'a'],) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []

# Generated at 2022-06-23 14:13:02.458977
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 2, 3, 1]
    if deduplicate_list(test_list) != [1, 2, 3]:
        raise AssertionError("Failed to deduplicate list")

test_deduplicate_list()

# Generated at 2022-06-23 14:13:05.687485
# Unit test for function deduplicate_list
def test_deduplicate_list():
    old_list = ['item1', 'item2', 'item3', 'item1', 'item4', 'item3']
    new_list = ['item1', 'item2', 'item3', 'item4']

    assert deduplicate_list(old_list) == new_list

# Generated at 2022-06-23 14:13:10.820196
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        a = 'a'
        b = 'b'
        c = 'c'
        d = 'd'
        def __init__(self):
            self.other = 'other'

    expected = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': 'd'
    }


    assert object_to_dict(TestClass()) == expected
    assert object_to_dict(TestClass(), exclude=['c']) == dict(expected, **{'c': 'c'})

# Generated at 2022-06-23 14:13:16.230239
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.x = "test"
            self._y = "test2"
            self.z = "test3"
    test_obj = TestObj()
    res = object_to_dict(test_obj)
    assert res == {'x': 'test', 'z': 'test3'}

    res = object_to_dict(test_obj, exclude=['x'])
    assert res == {'z': 'test3'}

# Generated at 2022-06-23 14:13:27.447892
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test_arg = 1
            self.test_arg2 = 2

    test_obj = TestClass()
    test_obj_dict = object_to_dict(test_obj)

    assert 'test_arg' in test_obj_dict
    assert test_obj_dict['test_arg'] == 1

    assert 'test_arg2' in test_obj_dict
    assert test_obj_dict['test_arg2'] == 2

    test_obj_dict = object_to_dict(test_obj, exclude=['test_arg'])

    assert 'test_arg' not in test_obj_dict
    assert 'test_arg2' in test_obj_dict
    assert test_obj_dict['test_arg2'] == 2


# Generated at 2022-06-23 14:13:37.507001
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.prop1 = 'prop1'
            self.prop2 = 'prop2'
            self._private = 'private'
            self.not_excluded = 'not_excluded'
            self.excluded_1 = 'excluded_1'
            self.excluded_2 = 'excluded_2'

    obj = TestObject()
    exclude = ['excluded_1', 'excluded_2']
    obj_dict = object_to_dict(obj, exclude)

    # Make sure the type is right
    assert isinstance(obj_dict, dict) is True

    # Make sure each key/value is set and has the right value
    assert obj_dict['prop1'] == 'prop1'
    assert obj_dict['prop2'] == 'prop2'


# Generated at 2022-06-23 14:13:42.850034
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10, min_value=0) == 1
    assert pct_to_int('10', 10, min_value=0) == 10
    assert pct_to_int(10, 10, min_value=0) == 10
    assert pct_to_int('0%', 10, min_value=0) == 0


# Generated at 2022-06-23 14:13:48.417710
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('80%', 10) == 8
    assert pct_to_int('80', 10) == 80
    assert pct_to_int('80%', 10, 5) == 8
    assert pct_to_int('80', 10, 5) == 80
    assert pct_to_int(5, 10,  3) == 5


# Generated at 2022-06-23 14:13:57.015466
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(4, 10, min_value=1) == 4
    assert pct_to_int(100, 10, min_value=1) == 10
    assert pct_to_int('40%', 10, min_value=1) == 4
    assert pct_to_int('40%', 40, min_value=1) == 16
    assert pct_to_int('40%', 1, min_value=1) == 1
    assert pct_to_int('40%', 0, min_value=1) == 1



# Generated at 2022-06-23 14:14:05.543940
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 10) == 1
    assert pct_to_int('1', 10) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('1.4%', 100) == 1
    assert pct_to_int('1.5%', 100) == 2
    assert pct_to_int('10.4%', 100) == 10
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('0.1%', 100) == 0
    assert pct_

# Generated at 2022-06-23 14:14:10.167169
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 5, 4, 3]
    expected_list = [1, 2, 3, 5, 4]
    assert (deduplicate_list(original_list) == expected_list)



# Generated at 2022-06-23 14:14:13.995249
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10", 100) == 10
    assert pct_to_int("10%", 100, min_value=2) == 2


# Generated at 2022-06-23 14:14:20.766113
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(4, 100) == 4
    assert pct_to_int('4', 100) == 4
    assert pct_to_int(4, 100, min_value=10) == 4
    assert pct_to_int(4, 100, min_value=0) == 4
    assert pct_to_int('4%', 100) == 4
    assert pct_to_int('4%', 100, min_value=0) == 4
    assert pct_to_int('4%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100, min_value=10)

# Generated at 2022-06-23 14:14:30.023233
# Unit test for function pct_to_int
def test_pct_to_int():
    # test the string input
    if pct_to_int('50%',330) != 165:
        raise AssertionError('function pct_to_int test one with string type failed')

    # test the integer input
    if pct_to_int(50,330) != 165:
        raise AssertionError('function pct_to_int test two with integer failed')

    # test the negative integer input
    if pct_to_int(-50,330) != 1:
        raise AssertionError('function pct_to_int test three with negative integer failed')

    # test the float input
    if pct_to_int(50.50,330) != 165:
        raise AssertionError('function pct_to_int test four with float failed')

# Generated at 2022-06-23 14:14:36.556401
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test 1
    num_items = 10
    value = 3
    assert value == pct_to_int(value, num_items)

    # Test 2
    num_items = 10
    value = "33%"
    assert int(num_items * .33) == pct_to_int(value, num_items)

    # Test 3
    num_items = 1
    value = "33%"
    assert 1 == pct_to_int(value, num_items)

# Generated at 2022-06-23 14:14:43.176401
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(10, 1000) == 10)
    assert(pct_to_int(50, 1000) == 500)
    assert(pct_to_int(25, 1000) == 250)
    assert(pct_to_int("10%", 1000) == 100)
    assert(pct_to_int("25%", 1000) == 250)
    assert(pct_to_int("50%", 1000) == 500)
    assert(pct_to_int("100%", 1000) == 1000)
    assert(pct_to_int("0%", 1000) == 0)
    assert(pct_to_int("110%", 1000) == 1100)
    assert(pct_to_int("10%", 1) == 1)

# Generated at 2022-06-23 14:14:49.766233
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 1, 5, 4, 2, 9, 5, 4, 6, 7, 5, 3, 2, 1, 5, 3, 2, 3, 8, 4, 1, 7, 5]
    de_test_list = [1, 2, 5, 4, 9, 6, 7, 3, 8]
    assert deduplicate_list(test_list) == de_test_list


# Generated at 2022-06-23 14:14:54.565415
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        a = 1
        b = 2
        _c = 3
        d = None

    obj = TestObj()
    expected_result = dict(a=1, b=2)
    result = object_to_dict(obj, exclude=['_c', 'd'])
    assert result == expected_result



# Generated at 2022-06-23 14:14:58.203504
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([]) == []



# Generated at 2022-06-23 14:15:08.174964
# Unit test for function pct_to_int

# Generated at 2022-06-23 14:15:19.491572
# Unit test for function object_to_dict
def test_object_to_dict():
    import collections

    class NewObject(object):
        def test_func(self, var=None):
            return var

        def test_func2(self, var=None):
            return var

        def __init__(self):
            self.str_var = 'str'
            self.dict_var = collections.OrderedDict()
            self.dict_var['key1'] = 'val1'
            self.dict_var['key2'] = 'val2'
            self.dict_var['key3'] = 'val3'
            self.list_var = ['key1', 'key2', 'key3']
            self._var = 'var'

    obj = NewObject()

    test_obj_dict = object_to_dict(obj)
    assert test_obj_dict['str_var'] == 'str'


# Generated at 2022-06-23 14:15:22.638275
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'a', 'c', 'd']
    assert deduplicate_list(test_list) == ['a', 'b', 'c', 'd']
    return

# Generated at 2022-06-23 14:15:32.148470
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('m', 100) == 0
    assert pct_to_int('1', 100) == 1
    assert pct_to_int('40', 100) == 40
    assert pct_to_int('40', 100) == 40
    assert pct_to_int('2', 100, 1) == 2
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('51', 100) == 51
    assert pct_to_int('99', 100) == 99
    assert pct_to_int('100', 100) == 100
    assert pct_to_int('101', 100) == 100
    assert pct_to_int('1', 1000) == 10
    assert pct_to_int('50', 1000) == 50
    assert pct_

# Generated at 2022-06-23 14:15:34.993295
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['c','a','a','b','b','c','b','a','c']
    result_list = ['c','a','b','c','b','a']
    assert deduplicate_list(test_list) == result_list

# Generated at 2022-06-23 14:15:46.906856
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Unit testing function pct_to_int
    '''

    # Testing input value with percentage
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=3) == 50
    assert pct_to_int('1%', 100, min_value=3) == 3

    # Testing input value with percentage but less than 1% for min_value
    assert pct_to_int('0.5%', 100, min_value=3) == 3

    # Testing input value without percentage
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50', 100, min_value=3) == 50
    assert pct_to_int('1', 100, min_value=3) == 1

# Generated at 2022-06-23 14:15:54.510204
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Creates a deduplicated list with the order in which each item is first found.
    """

    original_list = [1, 2, 2, 3, 4, 4, 5, 6, 6, 7, 8, 9, 9]
    deduplicated_list = deduplicate_list(original_list)

    assert deduplicated_list == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 14:16:04.111247
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("20%", 1000, min_value=400) == 200
    assert pct_to_int("50%", 1000) == 500
    assert pct_to_int("50%", 1000, min_value=1) == 500
    assert pct_to_int("50%", 1000, min_value=507) == 507
    assert pct_to_int("100%", 1000) == 1000
    assert pct_to_int("100%", 1000, min_value=400) == 1000
    assert pct_to_int("0%", 1000) == 1
    assert pct_to_int("0%", 1000, min_value=400) == 400
    assert pct_to_int(50, 1000) == 50
    assert pct_to_int(0, 1000) == 1


# Generated at 2022-06-23 14:16:13.414064
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5.1%', 100) == 6
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100.1%', 100) == 101
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101.5%', 100) == 101
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0.99%', 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2

    assert pct_to_int('3', 100) == 3

# Generated at 2022-06-23 14:16:14.939270
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10

# Generated at 2022-06-23 14:16:22.306288
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100, min_value=1) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('50%', 100, min_value=55) == 55
    assert pct_to_int('51%', 100, min_value=1) == 51
    assert pct_to_int('100%', 100, min_value=1) == 100

# Generated at 2022-06-23 14:16:32.741335
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test the object_to_dict function
    """

    def _test(test_obj, test_exclude=None, expected=None, assert_exception=None):
        if test_exclude is not None:
            test_exclude = test_exclude.split(',')

# Generated at 2022-06-23 14:16:39.344282
# Unit test for function deduplicate_list

# Generated at 2022-06-23 14:16:48.173159
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100, 1) == 20
    assert pct_to_int(10, 99, 1) == 10
    assert pct_to_int(50, 3, 1) == 2
    assert pct_to_int(20, 5, 1) == 1
    assert pct_to_int(1, 10, 1) == 1
    assert pct_to_int('20%', 100, 1) == 20
    assert pct_to_int('10%', 99, 1) == 10
    assert pct_to_int('50%', 3, 1) == 2
    assert pct_to_int('20%', 5, 1) == 1
    assert pct_to_int('1%', 10, 1) == 1

# Generated at 2022-06-23 14:16:54.436435
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.name = 'my_name'
            self.description = 'my_description'

    obj = MyClass()
    assert object_to_dict(obj) == {'name': 'my_name', 'description': 'my_description'}
    # Exclude some keys
    assert object_to_dict(obj, exclude=['name']) == {'description': 'my_description'}



# Generated at 2022-06-23 14:17:04.206997
# Unit test for function pct_to_int
def test_pct_to_int():
    # zero value
    assert pct_to_int(1, 0, min_value=0) == 0
    # float number should be converted to int
    assert pct_to_int(1.0, 1) == 1
    # non-percentage value
    assert pct_to_int(2, 3) == 2
    # percentage value
    assert pct_to_int('50%', 10) == 5
    # percentage with default value 1
    assert pct_to_int('100%', 10, min_value=1) == 10
    assert pct_to_int('95%', 10, min_value=1) == 10
    assert pct_to_int('0%', 10, min_value=1) == 1

