

# Generated at 2022-06-21 08:35:07.298158
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list1 = [1, 2, 4, 2, 1, 3, 3, 1, 5, 4]
    result = deduplicate_list(test_list1)
    assert result == [1, 2, 4, 3, 5]



# Generated at 2022-06-21 08:35:10.653780
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "c", "b", "a"]) == ["a", "b", "c"]
    assert deduplicate_list(["a", "b", "c", "b", "a"]) != ["b", "b", "a"]

# Generated at 2022-06-21 08:35:12.511760
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int(50, 10) == 50



# Generated at 2022-06-21 08:35:14.853701
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        first = "a"
        second = "b"
        third = "c"
    assert object_to_dict(TestObject(), exclude=["first"]) == {"second": "b", "third": "c"}

# Generated at 2022-06-21 08:35:25.005983
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict(MyClass(1, 2, 3))
    assert obj == {'one': 1, 'two': 2, 'three': 3}

    obj = object_to_dict(MyClass(1, 2, 3), exclude=['one'])
    assert obj == {'two': 2, 'three': 3}

    obj = object_to_dict(MyClass(1, 2, 3), exclude=['one', 'two'])
    assert obj == {'three': 3}

    obj = object_to_dict(MyClass(1, 2, 3), exclude=['one', 'two', 'three'])
    assert obj == {}



# Generated at 2022-06-21 08:35:35.445280
# Unit test for function pct_to_int
def test_pct_to_int():

    """This function helps in unittesting the pct_to_int function """

    print("\nTesting the function pct_to_int\n")
    assert pct_to_int("20%", 100) == 20
    assert pct_to_int("50", 100) == 50
    assert pct_to_int("20%", 100, min_value=2) == 20
    assert pct_to_int("5%", 100, min_value=2) == 2
    assert pct_to_int("10", 100, min_value=2) == 10
    assert pct_to_int("1", 100, min_value=2) == 1
    print("\nPassed all tests for function pct_to_int\n")

# Generated at 2022-06-21 08:35:37.116280
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'a', 'c', 'b', 'c', 'c']
    dedup_list = deduplicate_list(original_list)

    assert dedup_list == ['a', 'b', 'c'], "deduplicate_list() result does not match"

# Generated at 2022-06-21 08:35:40.517007
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('10', 1000) == 10
    assert pct_to_int('0%', 1000) == 1



# Generated at 2022-06-21 08:35:52.361663
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.a = "A"
            self.b = "B"

    obj = TestObj()
    result = object_to_dict(obj)
    assert result['a'] == obj.a
    assert result['b'] == obj.b

    result = object_to_dict(obj, exclude=['a'])
    assert result['a'] is not obj.a
    assert result['b'] == obj.b

    class TestObj2(object):
        def __init__(self):
            self.a = "A"
            self._b = "B"

    obj = TestObj2()
    result = object_to_dict(obj)
    assert result['a'] == obj.a
    assert '_b' not in result

# Generated at 2022-06-21 08:36:02.375360
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeClass(object):
        def __init__(self, a, b, c, d, e=None, f=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f

    obj = SomeClass(a=1, b=2, c=3, d=4, e=5, f=None)
    expected = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
        'f': None,
    }
    assert expected == object_to_dict(obj)

    obj = SomeClass(a=1, b=2, c=3, d=4, e=5, f=None)

# Generated at 2022-06-21 08:36:13.665860
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestMe(object):
        def __init__(self):
            self.test1 = 1
            self._test2 = 2
            self.test3 = 3
        def test_meth(self):
            return 'test'
        def _test_meth2(self):
            return 'test2'

    a = TestMe()
    a_dict = object_to_dict(a)
    assert len(a_dict.keys()) == 2
    assert a_dict['test1'] == a.test1
    assert a_dict['test3'] == a.test3

    # Make sure exclude, if provided works
    a_dict = object_to_dict(a, exclude=['test1'])
    assert len(a_dict.keys()) == 1
    assert a_dict['test3'] == a.test3



# Generated at 2022-06-21 08:36:18.618935
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert list() == deduplicate_list([])
    assert [1, 2, 3] == deduplicate_list([1, 2, 1, 3, 2])
    assert [1, 2, 3] == deduplicate_list([1, 1, 2, 3, 2, 3, 1, 3, 2])



# Generated at 2022-06-21 08:36:27.380712
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        pass

    test_obj = TestClass()
    test_obj.foo = 'Test foo'
    test_obj.bar = 'Test bar'

    obj_dict = object_to_dict(test_obj)

    assert obj_dict == {
        'foo': 'Test foo',
        'bar': 'Test bar',
    }, 'object_to_dict returns invalid dict'

    obj_dict = object_to_dict(test_obj, exclude=['foo'])
    assert obj_dict != {
        'foo': 'Test foo',
        'bar': 'Test bar',
    }, 'object_to_dict does not exclude correct items'

    assert obj_dict == {
        'bar': 'Test bar',
    }, 'object_to_dict returns invalid dict'

# Generated at 2022-06-21 08:36:33.953505
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('120%', 10) == 10
    assert pct_to_int('50%', 10, 0) == 5
    assert pct_to_int('120%', 10, 0) == 10

# Generated at 2022-06-21 08:36:43.276210
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(5, 10) == 1
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5', 10) == 1
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 10) == 1



# Generated at 2022-06-21 08:36:46.691372
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'

    result = object_to_dict(MyObject())

    assert result['foo'] == 'bar'
    assert result['baz'] == 'qux'



# Generated at 2022-06-21 08:36:53.598369
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("Testing deduplicate_list")
    assert ['A', 'B', 'C', 'D', 'E', 'F'] == deduplicate_list(['A', 'A', 'C', 'D', 'D', 'A', 'B', 'C', 'F', 'E', 'B', 'F', 'E'])
    print("Success!")

# Generated at 2022-06-21 08:36:57.842863
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('66%', 100) == 66
    assert pct_to_int(33, 100) == 33
    assert pct_to_int('33%', 10) == 3
    assert pct_to_int('33%', 1) == 1


# Generated at 2022-06-21 08:37:02.974057
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100) == 25
    assert pct_to_int('25', 100) == 25
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('25.5%', 100) == 26
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('101%', 100) == 101


# Generated at 2022-06-21 08:37:11.672753
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Test the pct_to_int function

    """
    assert pct_to_int('50%', num_items=2) == 1
    assert pct_to_int('50%', num_items=3) == 2
    assert pct_to_int('50%', num_items=4) == 2
    assert pct_to_int('50%', num_items=5) == 3
    assert pct_to_int(5, num_items=5) == 5
    assert pct_to_int('5%', num_items=5) == 1

# Generated at 2022-06-21 08:37:22.392513
# Unit test for function object_to_dict
def test_object_to_dict():
    class Car(object):
        def __init__(self, name, mileage):
            self.name = name
            self.mileage = mileage

    car1 = Car('Ford', 15)
    car2 = Car('Honda', 20)

    car_dict = {'name': 'Honda', 'mileage': 20}
    assert object_to_dict(car2) == car_dict

    car_dict = {'mileage': 20}
    assert object_to_dict(car2, ['name']) == car_dict

# Generated at 2022-06-21 08:37:27.890144
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(object) == {'__reduce_ex__', '__getattribute__', '__format__', '__repr__', '__doc__', '__str__', '__reduce__', '__setattr__', '__hash__', '__module__', '__delattr__', '__dir__', '__dict__', '__weakref__'}


# Generated at 2022-06-21 08:37:32.526622
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Simple test to check if deduplicate_list is working as expected
    """
    assert deduplicate_list(['a', 'b', 'c', 'd', 'a', 'e', 'a', 'b', 'd']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-21 08:37:37.192444
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'a', 'c', 'b']
    assert deduplicate_list(test_list) == ['a', 'b', 'c']


# Generated at 2022-06-21 08:37:43.287117
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 10) == 10
    assert pct_to_int('25%', 10) == 2
    assert pct_to_int('25%', 10, min_value=1) == 1
    assert pct_to_int('25%', 10, min_value=3) == 3
    assert pct_to_int('0%', 10, min_value=3) == 3


# Generated at 2022-06-21 08:37:45.239798
# Unit test for function pct_to_int
def test_pct_to_int():
    # value, num_items, min_value=1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10', 10) == 10


# Generated at 2022-06-21 08:37:57.128297
# Unit test for function pct_to_int
def test_pct_to_int():
    min_value = 5
    num_items = 1000
    assert pct_to_int(1, num_items) == 1
    assert pct_to_int(0, num_items) == 0
    assert pct_to_int(50, num_items) == 50
    assert pct_to_int(100, num_items) == 100
    assert pct_to_int(101, num_items) == 101
    assert pct_to_int(105, num_items) == 105
    assert pct_to_int('100', num_items) == 100
    assert pct_to_int('101', num_items) == 101
    assert pct_to_int('102', num_items) == 102
    assert pct_to_int('0%', num_items) == 0
    assert pct

# Generated at 2022-06-21 08:38:03.710990
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test with X percent
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100

    # Test with X
    assert pct_to_int('50', 100) == 50
    assert pct_to_int(50, 100) == 50

    # Test with the minimum value
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 1000) == 1
    assert pct_to_int('1%', 100) == 1



# Generated at 2022-06-21 08:38:10.768613
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:38:16.817249
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    my_obj = MyObject('test_obj', 100)

    obj_dict = object_to_dict(my_obj)
    assert(obj_dict.get('name') == my_obj.name)
    assert(obj_dict.get('value') == my_obj.value)

# Generated at 2022-06-21 08:38:34.026129
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int(51, 100) == 51
    assert pct_to_int('51', 100) == 51
    assert pct_to_int('51.51%', 100) == 52
    assert pct_to_int('51.49%', 100) == 51
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:38:39.879850
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    test_object = namedtuple('Object', ['key', 'value'])('key', 'value')
    assert object_to_dict(test_object) == {'key': 'key', 'value': 'value'}
    assert object_to_dict(test_object, exclude=['key']) == {'value': 'value'}


# Generated at 2022-06-21 08:38:45.478826
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 50) == 25
    assert pct_to_int("30", 20) == 30
    assert pct_to_int("50%", 50, min_value=3) == 3
    assert pct_to_int("50", 50, min_value=3) == 50
    assert pct_to_int("0%", 50) == 1

# Generated at 2022-06-21 08:38:54.557498
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Simple unit test for checking the deduplicate_list function works correctly.
    """
    data = [1, 1, 2, 3, 3, 4, 1, 1, 5]
    deduped_data = deduplicate_list(data)

    if not isinstance(deduped_data, list):
        raise AssertionError('deduped_data is not a list')

    expected_result = [1, 2, 3, 4, 5]
    if deduped_data != expected_result:
        raise AssertionError('deduped_data returned {} when {} was expected'.format(deduped_data, expected_result))



# Generated at 2022-06-21 08:38:59.117752
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.foo = "bar"
    obj = TestClass()
    assert object_to_dict(obj) == { "foo": "bar" }
    assert object_to_dict(obj, ["foo"]) == {}
    assert object_to_dict(obj, "foo") == {}



# Generated at 2022-06-21 08:39:06.694538
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["A", "A", "B"]) == ["A", "B"]
    assert deduplicate_list(["A", "B", "B"]) == ["A", "B"]
    assert deduplicate_list(["A", "A", "A"]) == ["A"]
    assert deduplicate_list([[1, 2], [1, 2], [3, 4]]) == [[1, 2], [3, 4]]


# Generated at 2022-06-21 08:39:10.110972
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 4, 4, 4, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 08:39:13.480171
# Unit test for function deduplicate_list
def test_deduplicate_list():
    new_list = deduplicate_list([1, 1, 2, 3, 2, 4, 2, 3, 2, 3, 2])
    assert new_list == [1, 2, 3, 4, 2]


# Generated at 2022-06-21 08:39:24.928409
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        test1 = False
        test2 = True
        test3 = 'test'
        test4 = None
        test5 = 'test2'
        test6 = []

    assert object_to_dict(Test()) == {'test1': False, 'test2': True, 'test3': 'test', 'test4': None, 'test5': 'test2', 'test6': []}
    assert object_to_dict(Test(), exclude=['test3']) == {'test1': False, 'test2': True, 'test4': None, 'test5': 'test2', 'test6': []}

# Generated at 2022-06-21 08:39:34.109461
# Unit test for function object_to_dict
def test_object_to_dict():
    class FakeObj():
        def __init__(self):
            self.key1 = "value1"
            self.key2 = "value2"
            self._key3 = "value3"

    obj = FakeObj()
    expected = {"key1": "value1", "key2": "value2"}
    result = object_to_dict(obj, exclude=["_key3"])

    if expected != result:
        raise Exception("This test has failed, expected result: %s, and actual result: %s" % (expected, result))

# Generated at 2022-06-21 08:39:55.774988
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 100) == 5
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("100.0%", 100) == 100


# Generated at 2022-06-21 08:40:06.286022
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(100, 100, min_value=0) == 100
    assert pct_to_int('100%', 100, min_value=0) == 100
    assert pct_to_int(50, 100, min_value=0) == 50
    assert pct_to_int('50%', 100, min_value=0) == 50

# Generated at 2022-06-21 08:40:09.959286
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 4, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-21 08:40:13.607937
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'd', 'd', 'a', 'b', 'e', 'f', 'c']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-21 08:40:25.285018
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.property_1 = 'test'
            self.property_2 = 'test2'
            self.property_3 = 'test3'

    obj = TestClass()

    exclude = None
    object_dict = object_to_dict(obj, exclude=exclude)
    assert object_dict['property_1'] == 'test'
    assert object_dict['property_2'] == 'test2'
    assert object_dict['property_3'] == 'test3'

    exclude = ['property_3']
    object_dict = object_to_dict(obj, exclude=exclude)
    assert object_dict['property_1'] == 'test'
    assert object_dict['property_2'] == 'test2'
    assert 'property_3' not in object_dict

# Generated at 2022-06-21 08:40:30.000283
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.test = 'test'
            self.test1 = 'test1'
    assert object_to_dict(TestObj()) == {'test': 'test', 'test1': 'test1'}
    assert object_to_dict(TestObj(), exclude=['test']) == {'test1': 'test1'}

# Generated at 2022-06-21 08:40:41.225375
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self.test3 = 'test3'
            self._test4 = 'test4'
            self._test5 = 'test5'
    test_obj = test_class()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test1'] == 'test1'
    assert test_dict['test2'] == 'test2'
    assert test_dict['test3'] == 'test3'
    assert '_test4' not in test_dict.keys()
    assert '_test5' not in test_dict.keys()
    test_obj2 = test_class()

# Generated at 2022-06-21 08:40:52.963940
# Unit test for function object_to_dict
def test_object_to_dict():
    class Dummy:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    dummy_obj = Dummy()
    assert object_to_dict(dummy_obj) == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert object_to_dict(dummy_obj, exclude=['b']) == {'a': 'a', 'c': 'c'}
    assert object_to_dict(dummy_obj, exclude=['c']) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(dummy_obj, exclude=['a']) == {'b': 'b', 'c': 'c'}



# Generated at 2022-06-21 08:40:57.233122
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'a', 'a', 'b', 'd', 'd']
    assert deduplicate_list(original_list) == ['a', 'b', 'd']
    assert deduplicate_list([]) == []
    assert deduplicate_list(None) == []

# Generated at 2022-06-21 08:41:08.722128
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            # Simple string
            self.string = 'string'
            # String with spaces
            self.string_spaces = 'string spaces'
            # String with alphanumeric
            self.string_alphanumeric = 'string123'
            # String with numeric
            self.string_numeric = '123'
            # String with invalid characters
            self.string_invalid = 'string-invalid'
            # String with dashes
            self.string_dashes = 'string_dashes'

            # List
            self.list = ['one', 2, 3.5]

            # Nested dict
            self.nested_dict = {
                'one': 'test1',
                'two': 2,
                'three': 'test3'
            }

            #

# Generated at 2022-06-21 08:41:31.922590
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj:
        def __init__(self):
            self.a = 1
            self.b = 2
    expected = dict(a=1, b=2)
    actual = object_to_dict(Obj())
    assert actual == expected



# Generated at 2022-06-21 08:41:36.094748
# Unit test for function pct_to_int
def test_pct_to_int():

    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20.5%', 100) == 20
    assert pct_to_int('20.5%', 100, min_value=5) == 5
    assert pct_to_int(1, 100) == 1

# Generated at 2022-06-21 08:41:39.697727
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(10, 100) == 10

# Generated at 2022-06-21 08:41:46.035889
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Runs unit tests for pct_to_int
    '''
    answers = []
    answers.append(pct_to_int("10%", 10) == 1)
    answers.append(pct_to_int(3, 10) == 3)
    if False in answers:
        raise Exception("Unit test for pct_to_int() failed")



# Generated at 2022-06-21 08:41:50.869678
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self._c = 3
            self._d = 4
    b = A()
    assert object_to_dict(b) == {'a': 1, 'b': 2}
    assert object_to_dict(b, exclude=['a']) == {'b': 2}

# Generated at 2022-06-21 08:41:59.718815
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test1 = 1
            self.test2 = 2
            self._private = 'This should not be included'

    test = TestObject()

    # test the private
    test_dict = object_to_dict(test)
    assert '_private' not in test_dict

    # test the exclude
    test_dict = object_to_dict(test, exclude=['test2'])
    assert 'test2' not in test_dict

# Generated at 2022-06-21 08:42:04.267814
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_attribute = 1
        def test_func(self):
            pass

    test_class = TestClass()
    assert object_to_dict(test_class) == {'test_attribute': 1, 'test_func': test_class.test_func}
    assert object_to_dict(test_class, exclude=['test_func']) == {'test_attribute': 1}

# Generated at 2022-06-21 08:42:06.096242
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(object()) == {}


# Generated at 2022-06-21 08:42:10.538065
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.a = 1
            self._b = 2
            self.c = 3
    obj = Foo()
    data = object_to_dict(obj, exclude=['a'])
    assert data['a'] == 1
    assert data['c'] == 3



# Generated at 2022-06-21 08:42:16.722111
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'

    obj = TestObject()

    assert object_to_dict(obj) == {'key1': 'value1', 'key2': 'value2'}
    assert object_to_dict(obj, exclude=['key1']) == {'key2': 'value2'}

# Generated at 2022-06-21 08:42:59.172235
# Unit test for function object_to_dict
def test_object_to_dict():
    test_class = collections.namedtuple('test_class', ['param1', 'param2'])
    obj = test_class('value1', 'value2')

    returned_dict = object_to_dict(obj, ['param1'])
    assert returned_dict == {'param2': 'value2'}

# Generated at 2022-06-21 08:43:06.313156
# Unit test for function object_to_dict
def test_object_to_dict():
    #Test basic functionality
    class testClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
    result = object_to_dict(testClass())
    assert result['a'] == 1
    assert result['b'] == 2

    #Test exclusion of certain keys
    result = object_to_dict(testClass(), exclude=['a'])
    assert not 'a' in result

    #Test exclusion of wildcard
    result = object_to_dict(testClass(), exclude=['_*'])
    assert not 'a' in result

    #Test exclusion of object methods
    class testClass2(object):
        def __init__(self):
            self.a = 1
            self.b = 2
        def test(self):
            return True
    result = object_to_

# Generated at 2022-06-21 08:43:11.330915
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0

# Generated at 2022-06-21 08:43:16.346134
# Unit test for function deduplicate_list
def test_deduplicate_list():

    original_list = ['a','b','c','b','a','d','e','b','c','f','g','a','h','c','j','a','e','a','k','l','a']
    assert deduplicate_list(original_list) == ['a','b','c','d','e','f','g','h','j','k','l']
    assert deduplicate_list(original_list) != ['a','b','c','d','e','f','g','h','j','k','l','a']

# Generated at 2022-06-21 08:43:18.211716
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([3, 1, 2, 2, 3, 4, 5]) == [3, 1, 2, 4, 5]



# Generated at 2022-06-21 08:43:23.484163
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectClass(object):
        def __init__(self):
            self.attr1 = 1
            self.attr2 = 2
            self._attr3 = 3

    assert object_to_dict(ObjectClass()) == {'attr1': 1, 'attr2': 2}


# Generated at 2022-06-21 08:43:28.631461
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 4, 1, 1, 2, 3]
    expected = [1, 2, 3, 4]
    assert deduplicate_list(original_list) == expected, \
        "List: %s, Expected: %s" % (str(deduplicate_list(original_list)), str(expected))



# Generated at 2022-06-21 08:43:39.982269
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 3, 4, 2]
    list2 = [1, 2, 3, 4, 2, 3]
    list3 = [1, 2, 3, 4]
    list4 = []
    list5 = [1, 2, 3, 4, 4, 3, 3, 2, 1]
    list6 = [1]
    list7 = [1, 1, 1, 1, 1, 1, 1]

    assert deduplicate_list(list1) == [1, 2, 3, 4]
    assert deduplicate_list(list2) == [1, 2, 3, 4]
    assert deduplicate_list(list3) == [1, 2, 3, 4]
    assert deduplicate_list(list4) == []

# Generated at 2022-06-21 08:43:45.421920
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests for function object_to_dict
    """
    class Test(object):
        """ Test Class """
        def __init__(self):
            self.age = 5
            self.name = 'test'
    test = Test()
    result = object_to_dict(test)
    expected_result = {'age': 5, 'name': 'test'}
    assert result == expected_result

# Generated at 2022-06-21 08:43:51.094308
# Unit test for function pct_to_int
def test_pct_to_int():
    test_values = [
        ('5%', 10, 5),
        ('5%', 5, 1),
        ('5%', 0, 0),
        ('5%', 100, 5),
        (5, 10, 5),
        (5, 5, 5),
        (5, 0, 5),
        (5, 100, 5),
        (0, 100, 0)
    ]
    for value, num_items, expected in test_values:
        result = pct_to_int(value, num_items)
        assert result == expected, 'Expected (%s, %s) -> %s, got %s' % (value, num_items, expected, result)

