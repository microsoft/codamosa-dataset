

# Generated at 2022-06-21 08:35:13.585690
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 1, 2, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 1, 6, 9]) == [1, 2, 3, 6, 9]
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list([10]) == [10]

# Generated at 2022-06-21 08:35:17.120103
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l = [3, 1, 2, 2, 1, 1]
    assert deduplicate_list(l) == [3, 1, 2]

# Generated at 2022-06-21 08:35:19.979663
# Unit test for function deduplicate_list
def test_deduplicate_list():
    ret = deduplicate_list([1, 2, 1, 3, 5, 2, 4, 6])
    assert ret == [1, 2, 3, 5, 4, 6]

# Generated at 2022-06-21 08:35:31.455445
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_duplicate_list = ['a', 'b', 'c', 'c', 'd', 'b', 'a', 'd', 'd']
    test_deduplicate_list = deduplicate_list(test_duplicate_list)
    assert 'c' in test_deduplicate_list
    assert 'd' in test_deduplicate_list
    assert 'b' in test_deduplicate_list
    assert 'a' in test_deduplicate_list
    assert test_deduplicate_list.index('a') == 0
    assert test_deduplicate_list.index('b') == 1
    assert test_deduplicate_list.index('c') == 2
    assert test_deduplicate_list.index('d') == 3

# Generated at 2022-06-21 08:35:34.510135
# Unit test for function object_to_dict
def test_object_to_dict():
    import collections
    Test = collections.namedtuple('Test', 'a b')
    obj = Test(1, 2)
    assert object_to_dict(obj, exclude=['a']) == {'b': 2}

# Generated at 2022-06-21 08:35:39.792662
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 1, 2, 5, 6, 7, 1, 5, 6, 7, 2]) == [1, 2, 5, 6, 7]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['hello', 'world', 'hello', 'world', 'hello', 'world']) == ['hello', 'world']



# Generated at 2022-06-21 08:35:43.535578
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 2, 2, 3, 3, 4, 4, 5, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 08:35:50.995278
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'c', 'a', 'b']) == ['a', 'c', 'b']
    assert deduplicate_list(['a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list([]) == []
    assert deduplicate_list(None) == []

# Generated at 2022-06-21 08:35:54.867992
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 3, 5, 2, 8, 9, 5, 4, 1, 9, 5, 3, 4, 3, 4]) == [2, 3, 5, 8, 9, 4, 1]


# Generated at 2022-06-21 08:36:00.735751
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 3, 3, 3, 'foo', 'foo', 1, 1, 1]) == [1, 2, 3, 'foo']
    assert deduplicate_list(['foo', 'foo', 'bar', 'bar', 'baz']) == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 08:36:08.917839
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicated_list = deduplicate_list([1, 2, 3, 2, 1])
    assert deduplicated_list[0] == 1
    assert deduplicated_list[1] == 2
    assert deduplicated_list[2] == 3

# Generated at 2022-06-21 08:36:12.786596
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,3,4,5,1,2,3,4,5,6,8,9,9,10]
    dedup_list = deduplicate_list(original_list)
    expected_list = [1,2,3,4,5,6,8,9,10]
    assert(dedup_list == expected_list)

# Generated at 2022-06-21 08:36:23.987859
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = 2
            self.arg5 = 2

    arg1 = 'argument1'
    arg2 = 'argument2'
    arg3 = 'argument3'

    my_object = TestClass(arg1, arg2, arg3)
    results = object_to_dict(my_object, exclude=['arg3'])
    print(results)
    assert len(results) == 4
    assert results['arg1'] == 'argument1'
    assert results['arg2'] == 'argument2'
    assert 'arg3' not in results
    assert results['arg4'] == 2
    assert results

# Generated at 2022-06-21 08:36:25.819984
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests deduplicate_list function
    """
    test_list = ["a", "b", "b", "c", "a"]
    assert deduplicate_list(test_list) == ["a", "b", "c"]

# Generated at 2022-06-21 08:36:31.384571
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('100%', 100) == 100

    assert pct_to_int(1, 10) == 1
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(100, 10) == 10
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(100, 100) == 100



# Generated at 2022-06-21 08:36:34.910435
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['a', 'b', 'a', 'c']
    list2 = ['b', 'c', 'a', 'a']
    assert deduplicate_list(list1) == list2

# Generated at 2022-06-21 08:36:45.612641
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        attr1 = "hello"
        attr2 = "world"

    class TestClass2(object):
        attr1 = "hello"
        attr2 = "world"

    obj = TestClass()
    obj2 = TestClass2()
    obj2.new_attr = "new attr"
    obj2.attr1 = "goodbye"
    obj3 = TestClass()
    obj3.attr1 = "change"
    obj3.new_attr = "new attr"
    test_dict = {'attr1': 'goodbye', 'attr2': 'world', 'new_attr': 'new attr'}
    test_dict2 = {'attr1': 'hello', 'attr2': 'world', 'new_attr': 'new attr'}
    assert test_dict

# Generated at 2022-06-21 08:36:48.537390
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 1, 2, 2, 2, 1, 2, 1, 4, 5, 8, 4, 5]
    dedup_list = deduplicate_list(sample_list)
    assert dedup_list == [1, 2, 4, 5, 8]



# Generated at 2022-06-21 08:36:55.108590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5]
    assert deduplicate_list(test_list) == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 08:37:03.181643
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int(10, 100, min_value=10) == 10
    assert pct_to_int(10, 1000, min_value=10) == 10
    assert pct_to_int(10, 100, min_value=5) == 5
    assert pct_to_int(10, 1000, min_value=5) == 5



# Generated at 2022-06-21 08:37:16.270195
# Unit test for function pct_to_int

# Generated at 2022-06-21 08:37:21.814820
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [
        "10.0.2.1",
        "10.0.2.1",
        "10.0.2.2",
        "10.0.2.1"
    ]
    assert ['10.0.2.1', '10.0.2.2'] == deduplicate_list(original_list)



# Generated at 2022-06-21 08:37:32.393939
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("100%", 100, 4) == 100
    assert pct_to_int("50%", 100, 4) == 50
    assert pct_to_int("1%", 100, 4) == 1
    assert pct_to_int("%", 100, 4) == 4
    assert pct_to_int("99%", 100, 4) == 99
    assert pct_to_int("100.1%", 100, 4) == 100
    assert pct_to_int("-0.1%", 100, 4) == 4
    assert pct_to_int("-1%", 100, 4) == 4
    assert pct_to_int("101%", 100, 4) == 100
    assert pct_to_int("-1.1%", 100, 4) == 4

   

# Generated at 2022-06-21 08:37:38.914881
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class():
        attr1 = '1'
        attr2 = '2'
        attr3 = '3'
    obj = test_class()
    dic = object_to_dict(obj, ['attr3'])
    assert set(dic.keys()) == {'attr1', 'attr2'}

# Generated at 2022-06-21 08:37:44.109046
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a test list containing duplicates
    test_list = [1,2,3,4,5,6,7,7,8,8,9,9,9,10,10,10,10,11,11,11,11]
    assert deduplicate_list(test_list) == [1,2,3,4,5,6,7,8,9,10,11]



# Generated at 2022-06-21 08:37:48.170738
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self, x=None, y=None):
            self.x = x
            self.y = y
            self.z = None

    obj = A(1, 2)
    obj.z = obj

    obj_keys = ['x', 'y', 'z']
    obj_values = [1, 2, obj]
    obj_dict = dict(zip(obj_keys, obj_values))

    assert obj_dict == object_to_dict(obj, exclude=['z'])
    assert object_to_dict(obj.z, exclude=['y', 'z']) == {'x': 1}

# Generated at 2022-06-21 08:37:59.336798
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('40%', 100) == 40
    assert pct_to_int(70, 100) == 70

    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(100, 100) == 100

    assert pct_to_int('99%', 100) == 99
    assert pct_to_int(99, 100) == 99

    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=3) == 3
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('0.1%', 100, min_value=3) == 3
    assert pct_to_int('0.001%', 100)

# Generated at 2022-06-21 08:38:04.194632
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeObj(object):
        a = "a"
        b = "b"

    class SomeOtherObj(object):
        x = "x"
        y = "y"
        z = "z"
        w = "w"

    a = SomeObj()
    b = SomeOtherObj()

    assert object_to_dict(a, exclude=['a']) == {'b': 'b'}
    assert object_to_dict(b, exclude=['x', 'z']) == {'y': 'y', 'w': 'w'}

# Generated at 2022-06-21 08:38:13.761673
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3], 'Wrong deduplication, values: [1, 2, 3, 2, 1]'
    assert deduplicate_list([1, 1, 1, 1]) == [1], 'Wrong deduplication, values: [1, 1, 1, 1]'
    assert deduplicate_list([0, 1, 2, 3, 2, 1, 0]) == [0, 1, 2, 3], 'Wrong deduplication, values: [0, 1, 2, 3, 2, 1, 0]'



# Generated at 2022-06-21 08:38:18.320030
# Unit test for function object_to_dict
def test_object_to_dict():
    class Tmp:
        a = 1
        b = 2
    assert object_to_dict(Tmp) == {'a': 1, 'b': 2}
    assert object_to_dict(Tmp, exclude=['a']) == {'b': 2}

# Generated at 2022-06-21 08:38:30.643498
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50

# Generated at 2022-06-21 08:38:41.347958
# Unit test for function pct_to_int
def test_pct_to_int():
    value = 30
    num_items = 10
    min_value = 1

    # test no percentage
    assert(pct_to_int(value, num_items, min_value) == value)

    # test percentage returns an int
    assert(type(pct_to_int(str(value) + '%', num_items, min_value)) == int)

    # test percentage returns correct value
    assert(pct_to_int(str(value) + '%', num_items, min_value) == 3)

    # test percentage returns min_value if calculated value is less than min_value
    assert(pct_to_int(str(5) + '%', num_items, 10) == 10)

# Generated at 2022-06-21 08:38:43.959269
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l = [1, 1, 2, 3, 3, 3, 4, 5, 5]
    assert deduplicate_list(l) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 08:38:51.894085
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests the object_to_dict function
    """
    class Blah(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    a = Blah('a', 'b', 'c')
    assert object_to_dict(a) == {'a': 'a', 'c': 'c', 'b': 'b'}
    assert object_to_dict(a, ['b']) == {'a': 'a', 'c': 'c'}

# Generated at 2022-06-21 08:38:53.873782
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list('aabbccdd') == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 08:39:02.259053
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100, min_value=1) == 1
    assert pct_to_int('50%', 100, min_value=1) == 50
    assert pct_to_int('100%', 100, min_value=1) == 100
    assert pct_to_int('101%', 100, min_value=1) == 101
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-21 08:39:08.722301
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Simple unit test for the function deduplicate_list
    """
    input_items = ['a','b','a','c','b','d','e','c','f','a','g','a','h','i','c']
    expected_items = ['a','b','c','d','e','f','g','h','i']

    assert deduplicate_list(input_items) == expected_items

# Generated at 2022-06-21 08:39:11.718338
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100) == 25
    assert pct_to_int('25', 100) == 25
    assert pct_to_int('25%', 100) == 25

# Generated at 2022-06-21 08:39:23.091983
# Unit test for function pct_to_int
def test_pct_to_int():
    # example 1
    assert (pct_to_int(10, 100) == 10)
    assert (pct_to_int("10", 100) == 10)
    assert (pct_to_int("10%", 100) == 10)
    assert (pct_to_int("10%", 100) == 10)
    assert (pct_to_int("20%", 100) == 20)
    assert (pct_to_int("20.6%", 100) == 21)

    # example 2
    assert (pct_to_int(101, 100) == 101)
    assert (pct_to_int("101", 100) == 101)
    assert (pct_to_int("101%", 100) == 101)
    assert (pct_to_int("101%", 100) == 101)
   

# Generated at 2022-06-21 08:39:33.818931
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 2, 1) == 0
    assert pct_to_int(1, 2, 1) == 1
    assert pct_to_int(2, 2, 1) == 2
    assert pct_to_int(3, 2, 1) == 2
    assert pct_to_int(0, 3, 1) == 0
    assert pct_to_int(1, 3, 1) == 1
    assert pct_to_int(2, 3, 1) == 2
    assert pct_to_int(3, 3, 1) == 3
    assert pct_to_int('0%', 2) == 0
    assert pct_to_int('10%', 2) == 1
    assert pct_to_int('25%', 2) == 1
    assert pct

# Generated at 2022-06-21 08:39:55.395968
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 100, min_value=4) == 4
    assert pct_to_int('5%', 100, min_value=5) == 5
    assert pct_to_int('5%', 100, 4) == 4
    assert pct_to_int('5%', 100, 5) == 5
    assert pct_to_int(10, 10) == 1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 10, min_value=1) == 1
    assert pct_to_int('10%', 10, min_value=2) == 2
    assert p

# Generated at 2022-06-21 08:40:04.074198
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests deduplicate list
    """
    from collections import OrderedDict
    test_list = ['a', 'b', 'b', 'c', 'a', 'd']
    check_list = ['a', 'b', 'c', 'd']
    deduped_list = deduplicate_list(test_list)
    assert isinstance(deduped_list, list)
    assert isinstance(deduped_list, OrderedDict)
    assert len(check_list) == len(deduped_list)
    assert check_list == deduped_list



# Generated at 2022-06-21 08:40:07.030575
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test deduplicate_list on a list with duplicated elements.
    """
    assert deduplicate_list([1, 1, 2, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 08:40:11.849270
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.hello = "world"

    obj = TestObject()

    assert(object_to_dict(obj) == {'hello': 'world'})



# Generated at 2022-06-21 08:40:22.474958
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test case 1
    # elements, value, min_value
    assert pct_to_int(10, 100, 1) == 10

    # Test case 2
    assert pct_to_int(10, 100, 10) == 10

    # Test case 3
    assert pct_to_int(50, 100, 1) == 50

    # Test case 4
    assert pct_to_int(100, 100, 1) == 100

    # Test case 5
    assert pct_to_int("10%", 100, 1) == 10

    # Test case 6
    assert pct_to_int("10%", 100, 10) == 10

    # Test case 7
    assert pct_to_int("50%", 100, 1) == 50

    # Test case 8

# Generated at 2022-06-21 08:40:27.671567
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 2, 1, 4, 3, 5, 6, 4, 6, 5]
    deduplicated_list = deduplicate_list(original_list)
    assert(deduplicated_list == [1, 2, 3, 4, 5, 6])

# Generated at 2022-06-21 08:40:34.583405
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int(50, 100.0) == 50
    assert pct_to_int(50, 200) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 200) == 100
    assert pct_to_int(50.0, 100) == 50
    assert pct_to_int('50.0', 100) == 50
    assert pct_to_int(50.0, 200) == 100
    assert pct_to_int('50.0%', 100) == 50
    assert pct_to_int('50.0%', 200) == 100
    assert pct_to_

# Generated at 2022-06-21 08:40:39.942335
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.name = "test"
            self.password = "secret"

    t = Test()
    d = object_to_dict(t, ['password'])
    assert 'name' in d
    assert 'password' not in d

# Generated at 2022-06-21 08:40:45.930453
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 101) == 11
    assert pct_to_int("99%", 100) == 99
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("100%", 101) == 101
    assert (pct_to_int("100%", 10101, min_value=0) == 10101)
    assert (pct_to_int("100%", 10101) == 10101)
    assert pct_to_int("99%", 100) == 99
    assert pct_to_int("99%", 101) == 100

# Generated at 2022-06-21 08:40:57.034056
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('99%', 100, min_value=5) == 5
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int(1, 100, min_value=5) == 1
    assert pct_to_int(50, 100, min_value=5) == 50
    assert pct_to_int(99, 100, min_value=5) == 99

# Generated at 2022-06-21 08:41:20.784378
# Unit test for function object_to_dict
def test_object_to_dict():
    assert {'a': 1, 'b': 2, 'c': 3} == object_to_dict(object, exclude=['_'])
    assert {'a': 1, 'b': 2, 'c': 3} == object_to_dict(object, exclude=['_', 'a'])
    assert {'b': 2, 'c': 3} == object_to_dict(object, exclude=['_', 'a'])

# Generated at 2022-06-21 08:41:26.299491
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self):
            self._exclude1 = 'variable1'
            self.variable2 = 'variable2'
            self._exclude2 = 'variable3'
            self.variable4 = 'variable4'
    # We expect the dict to exclude variable1, and variable3
    expected_result = {'variable2': 'variable2', 'variable4': 'variable4'}

    result = object_to_dict(TestObject())
    assert result == expected_result

# Generated at 2022-06-21 08:41:34.719553
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100, min_value=2) == 10
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('0%', 100) == 1


# Generated at 2022-06-21 08:41:37.351959
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3, 2, 3, 2, 1, 2]) == [1, 2, 3]


# Generated at 2022-06-21 08:41:42.742945
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.x = 'x'
            self.y = 'y'
            self._z = 'z'

    assert object_to_dict(Foo()) == dict(x='x', y='y')

# Generated at 2022-06-21 08:41:50.448229
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.prop1 = 1
            self.prop2 = 2
            self.hidden_property = 3

    obj = TestObject()

    assert isinstance(obj, object)
    assert isinstance(object_to_dict(obj), dict)
    assert object_to_dict(obj).get('prop1') == 1
    assert object_to_dict(obj).get('prop2') == 2
    assert object_to_dict(obj).get('hidden_property', None) is None
    assert len(object_to_dict(obj)) == 2



# Generated at 2022-06-21 08:41:58.692845
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([0, 1, 2, 3]) == [0, 1, 2, 3]
    assert deduplicate_list([1, 1, 1, 1, 1]) == [1]
    assert deduplicate_list([0]) == [0]
    assert deduplicate_list([]) == []



# Generated at 2022-06-21 08:42:02.649379
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.__c = 3

    result = object_to_dict(Foo())
    assert result['a'] == 1
    assert 'b' in result
    assert '__c' not in result



# Generated at 2022-06-21 08:42:07.025546
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestVars:
        def __init__(self, a, b, c, d=True):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
    obj = TestVars(4, 5, 6)
    dct = object_to_dict(obj)
    assert dct['a'] == 4
    assert dct['b'] == 5
    assert dct['c'] == 6
    assert dct['d'] == True



# Generated at 2022-06-21 08:42:12.524321
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj(object):
        def __init__(self):
            self.first = 'a'
            self.second = 'b'
            self._third = 'c'
    test_obj = obj()
    obj_dict = object_to_dict(test_obj, exclude=['_third'])

    assert len(obj_dict) == 2
    assert obj_dict['first'] == 'a'
    assert obj_dict['second'] == 'b'
    assert '_third' not in obj_dict

# Generated at 2022-06-21 08:42:49.238702
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "a"]) == ["a", "b"]

# Generated at 2022-06-21 08:42:53.560331
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.a = 1
            self.b = 2

    test = Test()
    result = object_to_dict(test)
    assert isinstance(result, dict)
    assert set(result) == set(['a', 'b'])
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-21 08:43:03.430253
# Unit test for function pct_to_int
def test_pct_to_int():
    # check if value is converted to percentage
    result = pct_to_int('20%', num_items=10)
    assert result == 2
    assert type(result) is int
    # check if non-percentage value is converted to int
    result = pct_to_int('5', num_items=5)
    assert result == 5
    assert type(result) is int
    # check if percentage value is converted correctly
    result = pct_to_int('50%', num_items=4)
    assert result == 2
    assert type(result) is int
    # check min_value parameter
    result = pct_to_int('50%', num_items=2)
    assert result == 1
    assert type(result) is int
    # check if non-int value is converted to int
    result = pct

# Generated at 2022-06-21 08:43:12.849545
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Input is an empty list
    original_list = []
    new_list = deduplicate_list(original_list)
    assert new_list == [], "No changes to the list is expected"

    # Input is a list with duplicates
    original_list = [1, 2, 2, 3, 4, 4, 5]
    new_list = deduplicate_list(original_list)
    assert new_list == [1, 2, 3, 4, 5], "The input list is not deduplicated"

    # Input is a list with no duplicates
    original_list = [1, 2, 3]
    new_list = deduplicate_list(original_list)
    assert new_list == [1, 2, 3], "No changes to the list is expected"



# Generated at 2022-06-21 08:43:14.920693
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['b', 'a', 'a', 'b', 'c', 'c', 'd']) == ['b', 'a', 'c', 'd']

# Generated at 2022-06-21 08:43:20.685651
# Unit test for function deduplicate_list
def test_deduplicate_list():
    org_list = [1, 1, 2, 3, 2, 2, 3, 2, 1, 2, 3, 2, 1, 2, 1, 2, 3, 3, 3, 3, 3]
    test_list = deduplicate_list(org_list)
    assert len(org_list) == 21
    assert len(test_list) == 4
    assert test_list == [1, 2, 3, 1]

# Generated at 2022-06-21 08:43:31.880586
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('.50%', 100) == 1
    assert pct_to_int('20.5%', 100) == 21
    assert pct_to_int('50%', 123) == 62
    assert pct_to_int('0.5%', 123) == 1
    assert pct_to_int('0.5%', 123, 1) == 1
    assert pct_to_int(0.5, 11, 1) == 1
    assert pct_to_int('100%', 123) == 123
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int(0, 10) == 1




# Generated at 2022-06-21 08:43:36.337032
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'
            self.blam = 'blah'

    foo = Foo()

    assert object_to_dict(obj=foo, exclude=['blam']) == dict(bar = 'baz')



# Generated at 2022-06-21 08:43:38.925826
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test function deduplicate_list.
    """
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 08:43:43.488767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    some_list = [3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,2,2,2,2,2,2,1,1,1,1,1,1,1,1,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5]
    deduped_list = deduplicate_list(some_list)
    assert deduped_list == [3,4,2,1,5]

# Generated at 2022-06-21 08:45:10.031292
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 0) == 1
    assert pct_to_int('50%', 100001) == 50001
    assert pct_to_int(50, 100001, min_value=0) == 50001
    assert pct_to_int(50, 100001, min_value=None) == 50001
    assert pct_to_int('50%', 100001, min_value=0) == 50001
    assert pct_to_int('50%', 100001, min_value=None) == 50001
    assert pct_to_int(0, 0) == 1
    assert pct_to_int('0%', 0) == 1
    assert pct_to_int(0, 0, min_value=0) == 0