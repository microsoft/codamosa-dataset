

# Generated at 2022-06-21 08:35:09.686964
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','c','c','b','a','d','g','a']) == ['a','b','c','d','g']


# Generated at 2022-06-21 08:35:14.202449
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        attr1 = 'let'
        attr2 = 'me'
        attr3 = 'in'

    obj = TestClass()

    test_dict = object_to_dict(obj)

    assert(test_dict['attr1'] == 'let')
    assert(test_dict['attr2'] == 'me')
    assert(test_dict['attr3'] == 'in')
    assert(len(test_dict) == 3)


# Generated at 2022-06-21 08:35:24.946547
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(5, 50) == 3
    assert pct_to_int('5%', 50) == 3
    assert pct_to_int('5', 50) == 5
    assert pct_to_int(1000, 10000) == 1000
    assert pct_to_int('2%', 10000) == 200
    assert pct_to_int(2, 10000) == 2
    assert pct_to_int('0%', 10000) == 1
    assert pct_to_int('0', 10000) == 0


# Generated at 2022-06-21 08:35:31.222987
# Unit test for function pct_to_int
def test_pct_to_int():
    print("Testing for pct_to_int()")

    assert pct_to_int(10, 10) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10', 10) == 10
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 1) == 1


# Generated at 2022-06-21 08:35:34.637580
# Unit test for function object_to_dict
def test_object_to_dict():
    class test:
        var1 = 1
        var2 = 2
        var3 = 3
    obj = test()
    assert object_to_dict(obj, ['var1']) == {'var2': 2, 'var3': 3}


# Generated at 2022-06-21 08:35:43.076994
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 50) == 5
    assert pct_to_int('160%', 100) == 100
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(1, 50, 1) == 1
    assert pct_to_int(10, 50, 1) == 10
    assert pct_to_int(160, 100, 1) == 100
    assert pct_to_int(0, 100, 1) == 1

# Generated at 2022-06-21 08:35:46.586016
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:35:49.648704
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'c', 'a']) == ['a', 'b', 'c']



# Generated at 2022-06-21 08:35:58.493737
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('250%', 10) == 10
    assert pct_to_int('0.1%', 10) == 1
    assert pct_to_int('.1%', 10) == 1
    assert pct_to_int('10%', 10, min_value=2) == 2
    assert pct_to_int('10', 10) == 10
    assert pct_to_int(10, 10) == 10




# Generated at 2022-06-21 08:36:07.450511
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100, 1) == 50
    assert pct_to_int("50", 100, 1) == 50
    assert pct_to_int("0%", 100, 1) == 1
    assert pct_to_int("100%", 100, 1) == 100
    assert pct_to_int("31", 100, 1) == 31
    assert pct_to_int("99", 100, 1) == 99
    assert pct_to_int("101%", 100, 1) == 101
    assert pct_to_int("999", 100, 1) == 999

# Generated at 2022-06-21 08:36:12.866249
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('80%', 10) == 8
    assert pct_to_int('0%', 10, 10) == 10
    assert pct_to_int('100%', 10, 10) == 10


# Generated at 2022-06-21 08:36:18.744039
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a','b','a','c','b','d','e','a','f','g','h','i','j','h','k','c','l','m']
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == ['a','b','c','d','e','f','g','h','i','j','k','l','m']

# Generated at 2022-06-21 08:36:25.983297
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 100) == 0
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(25, 100) == 25
    assert pct_to_int(50, 100) == 50
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("25%", 100) == 25
    assert pct_to_int("50%", 100) == 50

# Unit tests for function object_to_dict

# Generated at 2022-06-21 08:36:30.727033
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'a', 'd', 'a', 'b', 'b']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-21 08:36:36.542629
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test deduplicate_list function
    """
    original_list = [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 08:36:44.186813
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj(object):
        def __init__(self):
            self.data1 = '1'
            self.data2 = '2'
            self.data3 = '3'
            
            self._data4 = '4'

    obj_instance = obj()
    ret = object_to_dict(obj_instance, exclude=['data2'])
    assert ret['data1'] == '1'
    assert 'data2' not in ret
    assert ret['data3'] == '3'
    assert '_data4' not in ret



# Generated at 2022-06-21 08:36:52.419492
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.first_value = 'first_value'
            self.second_value = 'second_value'
            self.third_value = 'third_value'

    assert object_to_dict(TestClass()) == {'first_value': 'first_value', 'second_value': 'second_value', 'third_value': 'third_value'}
    assert object_to_dict(TestClass(), exclude=['first_value']) == {'second_value': 'second_value', 'third_value': 'third_value'}



# Generated at 2022-06-21 08:37:02.369610
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for function object_to_dict
    """
    class TestClass(object):
        def __init__(self):
            self.test = 'test'
            self.test2 = 'test2'
            self._private = 'private'

    converted_dict = object_to_dict(TestClass())
    assert(converted_dict['test'] == 'test')
    assert(converted_dict['test2'] == 'test2')
    assert not ('_private' in converted_dict.keys())

    class TestClass2(object):
        def __init__(self):
            self.test = 'test'
            self.test2 = 'test2'
            self._private = 'private'

    converted_dict = object_to_dict(TestClass())

# Generated at 2022-06-21 08:37:11.632765
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Tests the edge cases for converting percentage to integer.
    """
    assert pct_to_int('0%', 1) == 0
    assert pct_to_int('25%', 4) == 1
    assert pct_to_int('50%', 4) == 2
    assert pct_to_int('75%', 4) == 3
    assert pct_to_int('100%', 4) == 4
    assert pct_to_int('-10%', 4) == 1
    assert pct_to_int('110%', 4) == 4

# Generated at 2022-06-21 08:37:17.016998
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0', 100) == 1
    assert pct_to_int('0%', 100) == 1

    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100) == 50

# Generated at 2022-06-21 08:37:24.643940
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 1, 4, 2]
    expected_list = [1, 2, 3, 4]
    assert deduplicate_list(test_list) == expected_list


# Generated at 2022-06-21 08:37:30.233273
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeObject(object):
        attr1 = "Foo"
        attr2 = "Bar"
        attr3 = 100

    result = object_to_dict(SomeObject())
    assert len(result.keys()) == 3
    assert result['attr1'] == "Foo"
    assert result['attr2'] == "Bar"
    assert result['attr3'] == 100

# Generated at 2022-06-21 08:37:34.829764
# Unit test for function deduplicate_list
def test_deduplicate_list():
    old_list = ['1.1.1.1', '2.2.2.2', '1.1.1.1', '2.2.2.2', '3.3.3.3', '4.4.4.4', '3.3.3.3', '5.5.5.5']
    new_list = deduplicate_list(old_list)
    assert new_li

# Generated at 2022-06-21 08:37:42.466885
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100, min_value=0) == 10
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(0, 100, min_value=0) == 0
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('100%', 100) == 100

# Generated at 2022-06-21 08:37:52.509460
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int(1, 100)
    assert 0 == pct_to_int(0, 100)
    assert 0 == pct_to_int(0, 100, min_value=0)
    assert 100 == pct_to_int(100, 100)
    assert 1 == pct_to_int('1%', 100)
    assert 0 == pct_to_int('0%', 100)
    assert 0 == pct_to_int('0%', 100, min_value=0)
    assert 1 == pct_to_int('1.0%', 100)
    assert 10 == pct_to_int('10%', 100)
    assert 10 == pct_to_int('10.0%', 100)

# Generated at 2022-06-21 08:38:01.385232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Tests deduplicate_list function
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['c', 'a', 'b', 'a', 'b', 'c']) == ['c', 'a', 'b']
   

# Generated at 2022-06-21 08:38:11.646234
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1,1,1,2,2,2,3]
    list2 = [3,3,3,2,2,1,1]
    list3 = [1,2,3]
    list4 = [3,3,3,3,3,3,3]
    assert deduplicate_list(list1) == list3
    assert deduplicate_list(list2) == list3
    assert deduplicate_list(list3) == list3
    assert deduplicate_list(list4) == [3]


# Generated at 2022-06-21 08:38:19.294359
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 2, 3, 1, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 2, 1, 3, 1, 1, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:38:21.322839
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('75%', 100) == 75



# Generated at 2022-06-21 08:38:25.610021
# Unit test for function object_to_dict
def test_object_to_dict():
    class Class(object):
        def __init__(self):
            self.test_attr = 'foo'
            self.test_attr2 = 'bar'
    instance = Class()
    assert object_to_dict(instance, exclude=['test_attr2']) == {'test_attr': 'foo'}

# Generated at 2022-06-21 08:38:39.613700
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10", 100) == 10
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("120%", 100) == 100
    assert pct_to_int("10000%", 100) == 100
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("0%", 100, min_value=10) == 10


# Generated at 2022-06-21 08:38:46.543029
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.foo = 1
            self.bar = "bar1"

    test_obj = test_class()
    test_dict = object_to_dict(test_obj, exclude=['bar'])
    assert test_dict == {'foo': 1}
    test_dict = object_to_dict(test_obj)
    assert test_dict == {'foo': 1, 'bar': 'bar1'}

# Generated at 2022-06-21 08:38:55.720376
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(50, 100) == 50)
    assert(pct_to_int('75%', 100) == 75)
    assert(pct_to_int('50%', 100) == 50)
    assert(pct_to_int(50, 100, min_value=2) == 50)
    assert(pct_to_int(50, 100, min_value=1) == 50)
    assert(pct_to_int(1, 100) == 1)
    assert(pct_to_int(1, 100, min_value=2) == 2)
    assert(pct_to_int(0, 100, min_value=2) == 2)



# Generated at 2022-06-21 08:39:03.338796
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('100%', 500) == 500
    assert pct_to_int('101%', 1000) == 1010
    assert pct_to_int('50.5%', 1000) == 505
    assert pct_to_int('0.5%', 1000) == 5
    assert pct_to_int('0%', 1000) == 0
    assert pct_to_int('0%', 0) == 0
    assert pct_to_int('100%', 1) == 1
    assert pct_to_int('100%', 0) == 1
    assert pct_to_int(101, 10) == 101
    assert pct_to_int

# Generated at 2022-06-21 08:39:07.771785
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'a', 'c', 'b', 'a']
    expected_result = ['a', 'b', 'c']
    result = deduplicate_list(test_list)
    assert(result == expected_result)

# Generated at 2022-06-21 08:39:14.399951
# Unit test for function pct_to_int
def test_pct_to_int():
    assert (pct_to_int(10, 1)) == 10
    assert (pct_to_int('10', 1)) == 10
    assert (pct_to_int('10%', 100)) == 10
    assert (pct_to_int('10%', 100, min_value=0)) == 10
    assert (pct_to_int('0.5%', 100)) == 1
    assert (pct_to_int('0.5%', 100, min_value=0)) == 0

# Generated at 2022-06-21 08:39:16.079154
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["1", "2", "1", "3", "2", "2", "2", "1"]
    assert deduplicate_list(original_list) == ["1", "2", "3"]



# Generated at 2022-06-21 08:39:26.690514
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = "a"
            self.b = {
                "c": "d"
            }
            self._x = "y"
            self.z = 5
            self.bool = True
            self.d = None

    test = TestClass()
    result = object_to_dict(test)
    assert result["a"] == "a"
    assert result["b"] == {"c": "d"}
    assert result["z"] == 5
    assert result["bool"] == True
    assert result["d"] is None
    assert result["_x"] == "y"
    assert "_x" not in object_to_dict(test, exclude=["_x"])



# Generated at 2022-06-21 08:39:31.403781
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(0, 100) == 1


# Generated at 2022-06-21 08:39:38.032753
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Class to use for testing object_to_dict
        """

        def __init__(self):
            self.test_string = "TEST"
            self.test_int = 2
            self.test_none = None

    # Assert test class object
    test = TestClass()
    assert test.test_string == "TEST"
    assert test.test_int == 2
    assert test.test_none is None

    # Assert object_to_dict without excluding any keys
    test_dict = object_to_dict(test)
    assert test_dict['test_string'] == "TEST"
    assert test_dict['test_int'] == 2
    assert test_dict['test_none'] is None

    # Assert object_to_dict with excluding keys
    test_

# Generated at 2022-06-21 08:40:03.422706
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("100%", 100) == 100
    assert pct_to_int("0%", 100) == 1
    assert pct_to_int("-1%", 100) == 1
    assert pct_to_int("1", 100) == 1
    assert pct_to_int("10", 10) == 10
    assert pct_to_int("100", 1) == 100
    assert pct_to_int("0", 100) == 0
    assert pct_to_int("-1", 100) == -1



# Generated at 2022-06-21 08:40:09.744119
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create test object
    class Test(object):
        def __init__(self):
            self.test_field_one = 'A'
            self.test_field_two = 'B'
    test_object = Test()

    # Construct expected dictionary
    expected_dict = {'test_field_one': 'A', 'test_field_two': 'B'}

    # Test conversion
    result_dict = object_to_dict(test_object)
    if result_dict != expected_dict:
        raise AssertionError('conversion of test object to dict failed')

    # Test conversion with exclude field
    result_dict = object_to_dict(test_object, exclude=['test_field_two'])
    expected_dict = {'test_field_one': 'A'}

# Generated at 2022-06-21 08:40:17.688064
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(25, 100) == 25
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('0%', 100) == 1  # When 0 is passed, the minimum should be 1

# Generated at 2022-06-21 08:40:27.123739
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        '''
        This class is used to test the object_to_dict function
        '''
        def __init__(self):
            self._test_class_a = 'abc'
            self.test_class_b = 'def'

    test_obj = TestClass()

    # Build answer dictionary
    answer = {}
    answer['test_class_a'] = 'abc'
    answer['test_class_b'] = 'def'

    # Build dict to compare against
    obj_dict = object_to_dict(test_obj, exclude=['_test_class_a'])

    assert obj_dict == answer



# Generated at 2022-06-21 08:40:33.296798
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 'A'
            self.b = 'B'
            self.c = 'C'
            self._d = 'D'
            self.e = [1, 2, 3, 4]

    a = A()
    assert object_to_dict(a) == {'a': 'A', 'b': 'B', 'c': 'C', 'e': [1, 2, 3, 4]}
    assert object_to_dict(a, ["a", "b"]) == {'c': 'C', 'e': [1, 2, 3, 4]}

# Generated at 2022-06-21 08:40:42.082695
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.prop1 = 'prop1'
            self.prop2 = 'prop2'
            self.prop3 = 'prop3'
            self.prop4 = 'prop4'

    o = TestObj()
    assert object_to_dict(o) == {'prop1': 'prop1', 'prop2': 'prop2', 'prop3': 'prop3', 'prop4': 'prop4'}
    assert object_to_dict(o, ['prop1', 'prop3']) == {'prop2': 'prop2', 'prop4': 'prop4'}



# Generated at 2022-06-21 08:40:50.696499
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('40%', 500, 10) == 10
    assert pct_to_int('40%', 1000) == 400
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('50', 1000) == 50
    assert pct_to_int('-1', 1000) == -1


# Generated at 2022-06-21 08:40:56.537951
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 100, min_value=10) == 5
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('10%', 1) == 1
    assert pct_to_int('10%', 2) == 1

# Generated at 2022-06-21 08:41:06.923260
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import unittest

    class UnitTests(unittest.TestCase):

        def test_deduplicate_list_removes_duplicates(self):
            testlist = [1, 2, 1, 3, 1]
            result = deduplicate_list(testlist)
            self.assertEqual(result, [1, 2, 3])

        def test_deduplicate_list_preserves_order(self):
            testlist = [1, 2, 1, 3, 1]
            result = deduplicate_list(testlist)
            self.assertEqual(result, [1, 2, 3])

    unittest.main()

# Generated at 2022-06-21 08:41:12.576351
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('34%', 1048576) == 356880
    assert pct_to_int(34, 1048576) == 34
    assert pct_to_int('0%', 1048576) == 1
    assert pct_to_int('-1%', 1048576) == 1
    assert pct_to_int('101%', 1048576) == 1058576

# Generated at 2022-06-21 08:41:53.986722
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Case 1: Input list is not sorted and empty
    original_list = list()
    assert deduplicate_list(original_list) == []

    # Case 2: Input list is not sorted and has duplicates
    original_list = ['c', 'a', 'd', 'a', 'b', 'c']
    assert deduplicate_list(original_list) == ['c', 'a', 'd', 'b']

    # Case 3: Input list is sorted and has duplicates
    original_list = ['a', 'a', 'b', 'b', 'c', 'c', 'd', 'd']
    assert deduplicate_list(original_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 08:41:58.625747
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list(['1', 2, 3, 3]) == ['1', 2, 3]
    assert deduplicate_list([]) == []
    assert deduplicate_list(["1", "2", "3", "3"]) == ["1", "2", "3"]
    assert deduplicate_list(["1", "1", "1"]) == ["1"]

# Generated at 2022-06-21 08:42:05.533483
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1]) == [1, 2, 3]



# Generated at 2022-06-21 08:42:06.499989
# Unit test for function object_to_dict
def test_object_to_dict():
    pass

# Generated at 2022-06-21 08:42:11.055031
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test case for the function deduplicate_list.
    """
    original_list = ["foo", "bar", "foo", "bar", "baz", "foo", "baz", "baz"]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 08:42:18.726019
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 100, min_value=2) == 2
    assert pct_to_int('20%', 100) == 20
    try:
        pct_to_int('abcd%', 100)
        pct_to_int('10', '100')
    except Exception as e:
        assert True
        return

    assert False

# Generated at 2022-06-21 08:42:23.155060
# Unit test for function deduplicate_list
def test_deduplicate_list():
    initial_list = ['foo', 'bar', 'foo', 'qux', 'rab', 'far', 'faz', 'bar']
    final_list = ['foo', 'bar', 'qux', 'rab', 'far', 'faz']
    assert deduplicate_list(initial_list) == final_list



# Generated at 2022-06-21 08:42:28.136829
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int('1%', 10, min_value=2) == 2
    assert pct_to_int('0%', 10, min_value=2) == 2
    assert pct_to_int('0%', 10) == 1


# Generated at 2022-06-21 08:42:30.192718
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['A','B','C','D','A','E','F','G','H','I','I','J']
    test_list = ['A','B','C','D','E','F','G','H','I','J']
    assert deduplicate_list(original_list) == test_list


# Generated at 2022-06-21 08:42:39.640214
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        a1 = 'a1'
        a2 = 'a2'
        b1 = 'b1'
        b2 = 'b2'

    expected_dict = {
        'a1': 'a1',
        'a2': 'a2',
        'b1': 'b1',
        'b2': 'b2',
    }

    assert(object_to_dict(TestObject) == expected_dict)
    assert(object_to_dict(TestObject, exclude=['b1', 'b2']) == {'a1': 'a1', 'a2': 'a2'})
    assert(object_to_dict(TestObject, exclude=['a1', 'a2']) == {'b1': 'b1', 'b2': 'b2'})

# Generated at 2022-06-21 08:43:18.735564
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectToDictTestClass(object):
        def __init__(self):
            self.test_var1 = "test1"
            self.test_var2 = "test2"

    obj = ObjectToDictTestClass()
    # This should convert the object into a dict of the vars
    assert object_to_dict(obj) == {"test_var1": "test1", "test_var2": "test2"}
    # This should only return one of the vars and not the other
    assert object_to_dict(obj, exclude=["test_var1"]) == {"test_var2": "test2"}
    # This should return an empty list as the exclude was a list

# Generated at 2022-06-21 08:43:30.206550
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, 2) == 50
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, 2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, 2) == 100
    assert pct_to_int('101%', 100) == 100
    assert pct_to_int('101%', 100, 2) == 100
    assert pct_to_int('-1%', 100) == 0


# Generated at 2022-06-21 08:43:34.920313
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([9,0,2,1,0]) == [9,0,2,1]
    assert deduplicate_list([9,9,9,9,9]) == [9]
    assert deduplicate_list([9, 0, 2, 9, 0]) == [9, 0, 2]

# Generated at 2022-06-21 08:43:42.922513
# Unit test for function deduplicate_list
def test_deduplicate_list():
    testA = [1, 2, 2, 3, 1, 4, 8, 8, 0, 8, 1, 3, 3, 0, 2, 1]
    testB = [2, 3, 1]
    testC = []
    testD = [1]
    testE = [1, 1, 2, 2, 2, 3]
    testF = [1, 2, 3, 2, 1, 3, 2, 1, 3, 2, 1, 3, 2, 1]
    testG = [1, 2, 3, 2, 1, 2, 3, 2, 1, 2, 3, 2, 1]

    testA = deduplicate_list(testA)
    testB = deduplicate_list(testB)
    testC = deduplicate_list(testC)
    testD = dedu

# Generated at 2022-06-21 08:43:45.944411
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['a', 'b', 'a', 'a', 'b', 'c', 'd']
    list2 = ['a', 'b', 'c', 'd']
    assert list2 == deduplicate_list(list1)

# Generated at 2022-06-21 08:43:50.241996
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object:
        def __init__(self):
            self.value = 'test'
            self.value2 = 'test2'

        def dont_list_me(self):
            pass

    test_obj = Object()
    test_dict = object_to_dict(test_obj, exclude=['dont_list_me'])
    assert test_dict['value'] == 'test'
    assert 'dont_list_me' not in test_dict

# Generated at 2022-06-21 08:43:57.938624
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,1,1,1,1,1,1,1]) == [1]
    assert deduplicate_list([1,2,3,4,5,6,7,8,9,10]) == [1,2,3,4,5,6,7,8,9,10]
    assert deduplicate_list([1,2,3,3,3,3,3,3,3,3]) == [1,2,3]


# Generated at 2022-06-21 08:44:07.836733
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeObj(object):
        a = "foo"
        b = "bar"

    class SomeObj2(object):
        a = "baz"
        b = "biz"
        c = None

    obj = SomeObj()
    obj2 = SomeObj2()

    # Check basic functionality
    assert object_to_dict(obj, ['a']) == {'b': u'bar'}

    # Ensure variable types preserved
    assert isinstance(object_to_dict(obj)['a'], string_types)
    assert isinstance(object_to_dict(obj, ['a'])['b'], string_types)

    # Check excluding None variables
    assert object_to_dict(obj2, ['c']) == {'a': u'baz', 'b': u'biz'}

# Generated at 2022-06-21 08:44:16.346581
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.val1 = 'test1'
            self.val2 = 'test2'
            self.val3 = 'test3'

    obj = TestClass()
    result = object_to_dict(obj, ['val3'])

    assert result == {'val1': 'test1', 'val2': 'test2'}, 'Invalid result'

if __name__ == '__main__':
    test_object_to_dict()

# Generated at 2022-06-21 08:44:26.619411
# Unit test for function pct_to_int