

# Generated at 2022-06-21 08:35:14.583268
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test_attribute = 1
            self.another_attribute = 2
        def __str__(self):
            return str(object_to_dict(self))
    obj = TestClass()

    assert(isinstance(obj, TestClass))

    # Test for object_to_dict
    obj_dict = object_to_dict(obj)

    assert(obj_dict['test_attribute'] == 1)
    assert(obj_dict['another_attribute'] == 2)

    # Test for object_to_dict with exclusions
    obj_dict = object_to_dict(obj, ['another_attribute'])

    assert(obj_dict['test_attribute'] == 1)
    assert('another_attribute' not in obj_dict)

# Generated at 2022-06-21 08:35:25.752615
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create a test object
    class test_class(object):
        def __init__(self, a, b, c, d):
            self.test_a = a
            self.test_b = b
            self.test_c = c
            self.test_d = d
            self.test_e = None

        def __repr__(self):
            return 'class test_class'

    # Create a new test_class instance
    test_object = test_class('a', 'b', 'c', 'd')
    # Execute object_to_dict with empty exclude list
    result = object_to_dict(test_object)

# Generated at 2022-06-21 08:35:29.455749
# Unit test for function pct_to_int
def test_pct_to_int():
    results = {}
    assert pct_to_int("66%", 8) == 5, 'pct_to_int("66%", 8) should return 5'
    results['passed'] = True
    return results

# Generated at 2022-06-21 08:35:39.637811
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        '''
        Test class for testing the object_to_dict function
        '''
        def __init__(self, test1, test2=None):
            self.test1 = test1
            self.test2 = test2

        def __str__(self):
            return 'test1 = %s, test2 = %s' % (self.test1, self.test2)

    test_class1 = TestClass('test1', 'test2')
    test_class2 = TestClass('test3')
    test_dictionary = {'test_class1': test_class1, 'test_class2': test_class2}
    result = object_to_dict(test_class1)
    assert result['test1'] == 'test1'
    assert result['test2'] == 'test2'

# Generated at 2022-06-21 08:35:50.996067
# Unit test for function object_to_dict
def test_object_to_dict():
    class Parent(object):
        def __init__(self):
            self.parent_a = 1
            self.parent_b = 2

    class Child(Parent):
        def __init__(self):
            self.parent_a = 3  # overwriting parent
            self.child_a = 4
            self.child_b = 5

    child = Child()
    child_dict = object_to_dict(child)
    assert isinstance(child_dict, dict)
    assert sorted(child_dict.keys()) == ['child_a', 'child_b', 'parent_a']
    assert child_dict['parent_a'] == 3

    test_exclude = ['child_a', 'child_b']
    child_dict = object_to_dict(child, test_exclude)

# Generated at 2022-06-21 08:35:59.619545
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test cases for function object_to_dict
    """
    class TestClass(object):
        def __init__(self):
            self.test = 'test_value'
            self.test2 = 'test2_value'

    test_object = TestClass()
    obj_dict = object_to_dict(test_object)
    assert obj_dict == {'test': 'test_value', 'test2': 'test2_value'}
    obj_dict = object_to_dict(test_object, ['test2'])
    assert obj_dict == {'test': 'test_value'}

# Generated at 2022-06-21 08:36:02.007595
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 2, 2, 1, 1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 08:36:07.352367
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.one = 1
            self.two = 2
    t = Test()
    result = object_to_dict(t)
    assert result['one'] == 1
    assert result['two'] == 2



# Generated at 2022-06-21 08:36:10.714050
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,1,2,3]) == [1, 2, 3]
    assert deduplicate_list([1,1,4,4,4,4,4,4]) == [1,4]


# Generated at 2022-06-21 08:36:18.615095
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'a', 'c', 'b', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['c', 'b', 'a']) == ['c', 'b', 'a']
    assert deduplicate_list(['c', 'c', 'b', 'a', 'c']) == ['c', 'b', 'a']

# Generated at 2022-06-21 08:36:25.945434
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    assert object_to_dict(Test()) == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert object_to_dict(Test(), ['c']) == {'a': 'a', 'b': 'b'}

# Generated at 2022-06-21 08:36:31.441831
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 101) == 101
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 101) == 51
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 101) == 11
    assert pct_to_int('10%', 0) == 0
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 101) == 0
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 101) == 1

# Generated at 2022-06-21 08:36:33.671925
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int('50%', 100) == 50)
    assert(pct_to_int('5%', 100) == 5)
    assert(pct_to_int('5%', 100, min_value=10) == 10)
    assert(pct_to_int(5, 100) == 5)
    assert(pct_to_int(5, 100, min_value=10) == 5)

# Generated at 2022-06-21 08:36:42.340809
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self.key3 = ['item1', 'item2']
            self._private = True

    instance = TestClass()
    assert object_to_dict(instance) == {'key1': 'value1', 'key2': 'value2', 'key3': ['item1', 'item2']}
    assert object_to_dict(instance, exclude=['key1', 'key3']) == {'key2': 'value2'}

# Generated at 2022-06-21 08:36:48.402774
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self, test='test', test2='test2'):
            self.test = test
            self.test2 = test2

        def test_func(self):
            return 'test'

    test = TestObject()
    assert object_to_dict(test) == {'test': 'test', 'test_func': test.test_func, 'test2': 'test2'}
    assert object_to_dict(test, exclude=['test_func']) == {'test': 'test', 'test2': 'test2'}



# Generated at 2022-06-21 08:36:57.077771
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list([])
    deduplicate_list(['a'])
    deduplicate_list(['a', 'b'])
    deduplicate_list(['a', 'a', 'a'])
    deduplicate_list(['a', 'a', 'a', 'b', 'b', 'b', 'a', 'a'])
    deduplicate_list(['b', 'a', 'a', 'b', 'b', 'a', 'a'])


# Generated at 2022-06-21 08:37:03.492619
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int('35%', 100) == 35
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('50.4%', 100) == 50
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('100%', 100) == 100

# Generated at 2022-06-21 08:37:09.912116
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['b', 'a', 'b', 'c', 'a']) == ['b', 'a', 'c']
    # Make sure deduplicate_list is robust enough to handle empty list
    assert deduplicate_list([]) == []
    # Make sure deduplicate_list is robust enough to handle None
    assert deduplicate_list(None) is None

# Generated at 2022-06-21 08:37:12.532263
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 1, 3, 2, 1, 2, 4, 5, 1, 2, 1, 2]) == [2, 1, 3, 4, 5]



# Generated at 2022-06-21 08:37:23.125711
# Unit test for function pct_to_int
def test_pct_to_int():
    """ Unit test for function pct_to_int """
    result = pct_to_int("3%", 100)
    assert (result == 3), "Invalid result " + str(result)

    result = pct_to_int("12%", 200)
    assert (result == 24), "Invalid result " + str(result)

    result = pct_to_int("12%", 200, min_value=0)
    assert (result == 24), "Invalid result " + str(result)

    result = pct_to_int("12.12%", 200)
    assert (result == 24), "Invalid result " + str(result)

    result = pct_to_int("0.55%", 200)
    assert (result == 1), "Invalid result " + str(result)


# Generated at 2022-06-21 08:37:31.571743
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 40) == 4
    assert pct_to_int('100%', 40) == 40
    assert pct_to_int('100%', 40, 5) == 40
    assert pct_to_int('10%', 40, 5) == 5



# Generated at 2022-06-21 08:37:39.964587
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass(object):
        def __init__(self):
            self.dummy_string = "string"
            self.dummy_list = [1, 2, 3, 4]

    dummy_object = DummyClass()
    dummy_object_dict = object_to_dict(dummy_object)

    assert dummy_object_dict['dummy_string'] == "string"
    assert dummy_object_dict['dummy_list'] == [1, 2, 3, 4]

# Generated at 2022-06-21 08:37:47.684851
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass(object):
        def __init__(self):
            self.key_1 = "val_1"
            self.key_2 = "val_2"
            self.key_3 = "val_3"

    sample_obj = SampleClass()

    sample_dict = {
        "key_1": "val_1",
        "key_2": "val_2",
        "key_3": "val_3"
    }

    sample_dict_excluded = {
        "key_1": "val_1",
        "key_3": "val_3"
    }

    assert object_to_dict(sample_obj) == sample_dict
    assert object_to_dict(sample_obj, ["key_2"]) == sample_dict_excluded



# Generated at 2022-06-21 08:37:55.114348
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.abc = 'abc'
            self.def_ = 'def'

    obj = Foo()
    dd = object_to_dict(obj)
    assert 'abc' in dd
    assert 'def_' in dd
    assert 'def' not in dd
    assert len(dd) == 2

if __name__ == "__main__":
    test_object_to_dict()

# Generated at 2022-06-21 08:37:59.546114
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 6, min_value=0) == 3
    assert pct_to_int(2, 2, min_value=0) == 2
    assert pct_to_int(0, 2, min_value=1) == 1



# Generated at 2022-06-21 08:38:02.409268
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1,2,3,4,3,2,1,3,4,5,4,3,2,1]
    assert deduplicate_list(test_list) == [1,2,3,4,5]

# Generated at 2022-06-21 08:38:06.169790
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 2, 1]
    assert(deduplicate_list(original_list) == [1, 2, 3])


# Generated at 2022-06-21 08:38:13.231439
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self, x, y):
            self.x = x
            self.y = y
            self._private = 'priv'

    test = Test('x', 'y')

    assert object_to_dict(test) == {'_private': 'priv', 'x': 'x', 'y': 'y'}
    assert object_to_dict(test, exclude=['x']) == {'_private': 'priv', 'y': 'y'}

# Generated at 2022-06-21 08:38:19.390329
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network_common import ComplexList
    assert object_to_dict(ComplexList(dict(name='test')), exclude=['_items']) == dict(name='test', keys=['name'])
    assert object_to_dict(ComplexList(dict(name='test')), exclude=[]) == dict(name='test', keys=['name'], _items={})



# Generated at 2022-06-21 08:38:26.197970
# Unit test for function pct_to_int
def test_pct_to_int():

    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 9) == 5
    assert pct_to_int('50%', 3) == 2
    assert pct_to_int('50%', 2) == 1
    assert pct_to_int('50%', 1) == 1

    assert pct_to_int('50%', 10, min_value=2) == 5
    assert pct_to_int('50%', 9, min_value=2) == 4
    assert pct_to_int('50%', 3, min_value=2) == 2
    assert pct_to_int('50%', 2, min_value=2) == 2
    assert pct_to_int('50%', 1, min_value=2) == 2

# Generated at 2022-06-21 08:38:32.548995
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'c', 'b', 'd', 'd', 'b', 'b', 'e', 'a', 'a']
    dedup_list = deduplicate_list(original_list)
    assert dedup_list == ['a', 'c', 'b', 'd', 'e']



# Generated at 2022-06-21 08:38:36.580351
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=5) == 5
    assert pct_to_int(50, 100, min_value=5) == 50

# Generated at 2022-06-21 08:38:38.472103
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'bar', 'foo']) == ['foo', 'bar']


# Generated at 2022-06-21 08:38:49.801538
# Unit test for function object_to_dict
def test_object_to_dict():
    class SomeObject:
        def __init__(self):
            self.key1 = 1
            self.key2 = 2
            self.key3 = 3
            self._key4 = 4
            self.key5 = 5

    o = SomeObject()
    d = object_to_dict(o)
    assert isinstance(d, dict)
    assert 'key1' in d
    assert 'key2' in d
    assert 'key3' in d
    assert 'key5' in d
    assert '_key4' not in d
    d = object_to_dict(o, ['key2', 'key3'])
    assert isinstance(d, dict)
    assert 'key1' in d
    assert 'key2' not in d
    assert 'key3' not in d
    assert 'key5' in d

# Generated at 2022-06-21 08:38:57.028568
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    test_object = namedtuple("TestObject", ["first_name", "items", "details"])
    test_instance = test_object("test_instance", [1,2,3,3], {"test1": "test1", "test2": "test2"})
    assert object_to_dict(test_instance) == {"first_name": "test_instance", "items": [1,2,3,3],
                                             "details": {"test1": "test1", "test2": "test2"}}



# Generated at 2022-06-21 08:39:02.375906
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.key1 = "value1"
            self.key2 = 2

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)

    assert type(test_dict) is dict
    assert len(test_dict.keys()) == 2
    assert "key1" in test_dict
    assert "key2" in test_dict
    assert test_dict["key1"] == "value1"
    assert test_dict["key2"] == 2

# Generated at 2022-06-21 08:39:06.444321
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_attr1 = 'value'
        test_attr2 = 'value'

    assert object_to_dict(TestClass) == {'test_attr1': 'value', 'test_attr2': 'value'}

# Generated at 2022-06-21 08:39:13.336057
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100, min_value=10) == 10

# Generated at 2022-06-21 08:39:19.442842
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int("50%", 1) == 1
    assert pct_to_int("5%", 100) == 5
    assert pct_to_int("25%", 0) == 0
    assert pct_to_int("25", 0) == 25
    assert pct_to_int(25, 0) == 25

# Generated at 2022-06-21 08:39:24.545951
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 4, 4, 7, 8, 1, 2]
    new_list = deduplicate_list(original_list)

    assert(new_list == [1, 2, 4, 7, 8])

    assert([1, 2, 3] == [1, 2, 3])


# Generated at 2022-06-21 08:39:43.538843
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['foo', 'bar']) == ['foo', 'bar']
    assert deduplicate_list(['foo', 'foo']) == ['foo']
    assert deduplicate_list(['foo', 'foo', 'bar']) == ['foo', 'bar']
    assert deduplicate_list(['bar', 'foo', 'foo']) == ['bar', 'foo']
    assert deduplicate_list(['foo', 'bar', 'foo']) == ['foo', 'bar']

# Generated at 2022-06-21 08:39:50.733415
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []
    assert deduplicate_list(None) == []

# Generated at 2022-06-21 08:39:54.417595
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestClass:
        a = 'test_a'
        b = 'test_b'

    test_obj = TestClass()
    result = object_to_dict(test_obj)
    assert result == {'a': 'test_a', 'b': 'test_b'}

# Generated at 2022-06-21 08:40:05.915460
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'c', 'b', 'a']) == ['a', 'c', 'b']
    assert deduplicate_list(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']


# Generated at 2022-06-21 08:40:08.953062
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:40:20.218655
# Unit test for function deduplicate_list
def test_deduplicate_list():
    def assert_happens_before(e1, e2, values):
        assert(values.index(e1) < values.index(e2))

    assert_happens_before(1, 2, deduplicate_list([1, 2, 2, 2, 1]))
    assert_happens_before(1, 3, deduplicate_list([3, 1, 2, 2, 1]))
    assert_happens_before(1, 4, deduplicate_list([3, 4, 2, 2, 1, 1]))
    assert_happens_before(2, 3, deduplicate_list([2, 3, 2, 3, 2]))

# Generated at 2022-06-21 08:40:22.714336
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.name = "george"
    obj.age = 4
    obj.gender = "male"
    test = object_to_dict(obj)
    assert test['name'] == "george"
    assert test['age'] == 4
    assert test['gender'] == "male"

# Generated at 2022-06-21 08:40:29.392009
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyDevice(object):
        def __init__(self):
            self.name = 'dummy'
            self.domain = 'default'
            self.state = 'down'

    device = DummyDevice()

    device_dict = object_to_dict(device, exclude=['domain'])

    assert 'name' in device_dict
    assert 'domain' not in device_dict
    assert 'state' in device_dict



# Generated at 2022-06-21 08:40:33.232874
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 2, 1, 4, 5, 3, 1]
    expected_list = [1, 2, 3, 4, 5]
    actual_list = deduplicate_list(test_list)
    assert actual_list == expected_list

# Generated at 2022-06-21 08:40:41.385126
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests with the following lists:
    * [1, 2, 3, 1, 5] -> [1, 2, 3, 5]
    * ['1', '2', 1, 2, '1', '5'] -> ['1', '2', 1, 2, '5']
    """
    assert deduplicate_list([1,2,3,1,5]) == [1,2,3,5]
    assert deduplicate_list(['1','2',1,2,'1','5']) == ['1','2',1,2,'5']

# Generated at 2022-06-21 08:41:06.516069
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        a = 1
        b = 2
        c = 3

    tc = TestClass()
    result = object_to_dict(tc, exclude=['b'])
    assert len(result.keys()) == 2
    assert 'b' not in result

# Generated at 2022-06-21 08:41:18.089706
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = FakeObject()

    # test with exclude list being empty
    assert object_to_dict(obj) == {'list': [4, 5, 6], 'string': 'fake', 'dict': {'one': 1, 'two': 2, 'three': 3}, 'a': 'b'}

    # test excluding one attribute
    assert object_to_dict(obj, ['a']) == {'list': [4, 5, 6], 'string': 'fake', 'dict': {'one': 1, 'two': 2, 'three': 3}}

    # test excluding multiple attributes
    assert object_to_dict(obj, ['a', 'b']) == {'list': [4, 5, 6], 'string': 'fake', 'dict': {'one': 1, 'two': 2, 'three': 3}}

    # test excluding attributes that are

# Generated at 2022-06-21 08:41:22.702505
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'A'
            self._b = 'B'
            self.c_ = 'C'

    obj = Test()
    assert object_to_dict(obj) == {'a': 'A', '_b': 'B', 'c_': 'C'}

# Generated at 2022-06-21 08:41:27.117088
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=0) == 50
    assert pct_to_int('50%', 0, min_value=0) == 0
    assert pct_to_int('50%', 0) == 1


# Generated at 2022-06-21 08:41:35.425419
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("25%", 100) == 25
    assert pct_to_int("500%", 100) == 100
    assert pct_to_int("101%", 100) == 100
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1", 100) == 1
    assert pct_to_int("1", 100, 1) == 1
    assert pct_to_int("1", 100, 2) == 2


# Generated at 2022-06-21 08:41:42.340166
# Unit test for function pct_to_int
def test_pct_to_int():
    value = 25
    num_items = 100
    min_value = 1
    assert pct_to_int(value, num_items, min_value) == 25
    value = '27%'
    num_items = 100
    min_value = 1
    assert pct_to_int(value, num_items, min_value) == 27
    value = '20'
    num_items = 100
    min_value = 1
    assert pct_to_int(value, num_items, min_value) == 20
    value = '20%'
    num_items = 10
    min_value = 1
    assert pct_to_int(value, num_items, min_value) == 1
    value = '20%'
    num_items = 10
    min_value = 2
    assert pct_

# Generated at 2022-06-21 08:41:48.801389
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("30%", 1000) == 300
    assert pct_to_int("100%", 1000) == 1000
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("0%", 1000) == 1
    assert pct_to_int("0", 1000) == 0
    assert pct_to_int("500", 1000) == 500
    assert pct_to_int("500%", 1000) == 1000

# Generated at 2022-06-21 08:41:54.375930
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Test class to test the object_to_dict function
        """
        def __init__(self):
            self.test_property = "test"

        def __repr__(self):
            return str(self.test_property)

        def __str__(self):
            return str(self.test_property)

    class_test_object = TestClass()

    test_dict = object_to_dict(class_test_object)
    assert 'test_property' in test_dict, "property is not in dict"
    assert test_dict['test_property'] == 'test', "Property value is incorrect"


# Generated at 2022-06-21 08:41:58.646690
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'a', 'b', 'c', 'a', 'c', 'c', 'a']
    deduplicated_list = deduplicate_list(test_list)
    assert deduplicated_list == ['a', 'b', 'c']


# Generated at 2022-06-21 08:42:06.050315
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        v1 = 'a'
        v2 = 'b'
        v3 = 'c'
    assert object_to_dict(TestClass(), ['v1']) == {'v2': 'b', 'v3': 'c'}
    assert object_to_dict(TestClass(), ['v2']) == {'v1': 'a', 'v3': 'c'}
    assert object_to_dict(TestClass(), ['v3']) == {'v1': 'a', 'v2': 'b'}
    assert object_to_dict(TestClass()) == {'v1': 'a', 'v2': 'b', 'v3': 'c'}

# Generated at 2022-06-21 08:42:50.472472
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 2, 5, 6, 4, 2, 5, 2, 1, 8]
    expected_result = [1, 2, 5, 6, 4, 8]

    deduplicated_list = deduplicate_list(test_list)

    assert deduplicated_list == expected_result

# Generated at 2022-06-21 08:42:58.018630
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests for object_to_dict function
    """
    class Obj(object):
        foo = 'foo'
        bar = 'bar'
        baz = 'baz'
    obj = Obj()
    obj_dict = object_to_dict(obj)
    assert obj_dict['foo'] == 'foo'
    assert obj_dict['bar'] == 'bar'
    assert obj_dict['baz'] == 'baz'
    obj_dict = object_to_dict(obj, exclude=['foo'])
    assert obj_dict['foo'] == False

# Generated at 2022-06-21 08:43:04.135169
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    min_value = 1

    value = "25%"
    assert pct_to_int(value, num_items) == 25
    assert pct_to_int(value, num_items, min_value=5) == 5

    value = "120%"
    assert pct_to_int(value, num_items) == 120

    value = "-25%"
    assert pct_to_int(value, num_items) == 1

    value = "apple"
    assert pct_to_int(value, num_items) == 0


# Generated at 2022-06-21 08:43:12.361461
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100, min_value=5) == 25
    assert pct_to_int(0.25, 100, min_value=5) == 25
    assert pct_to_int('25%', 100, min_value=5) == 25
    assert pct_to_int('0.25', 100, min_value=5) == 25
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0.01', 100, min_value=5) == 5
    assert pct_to_int(0.01, 100, min_value=5) == 5

# Generated at 2022-06-21 08:43:16.866985
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 1001
    assert 100 == pct_to_int(100, num_items)
    assert 1 == pct_to_int(1, num_items)
    assert 0 == pct_to_int('0%', num_items)
    assert 1 == pct_to_int('0.1%', num_items)
    assert 10 == pct_to_int('1%', num_items)
    assert 100 == pct_to_int('10%', num_items)
    assert 1000 == pct_to_int('99%', num_items)
    assert 1000 == pct_to_int('99.9%', num_items)
    assert 1001 == pct_to_int('100%', num_items)

# Generated at 2022-06-21 08:43:21.780049
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
    ans = object_to_dict(TestObject())
    assert isinstance(ans, dict)
    assert len(ans) == 2
    assert 'a' in ans and 'b' in ans


# Generated at 2022-06-21 08:43:32.674265
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 1) == 0
    assert pct_to_int(0, 1, 10) == 10
    assert pct_to_int(1, 1, 10) == 1
    assert pct_to_int(10, 1, 10) == 10
    assert pct_to_int(10, 1, 11) == 11
    assert pct_to_int(101, 100, 11) == 11
    assert pct_to_int(51, 100) == 51
    assert pct_to_int('51%', 100) == 51
    assert pct_to_int('51%', 100, 10) == 51
    assert pct_to_int('51', 100, 10) == 51
    assert pct_to_int('51%', 100, 11) == 51
    assert pct

# Generated at 2022-06-21 08:43:39.928146
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("50%", 100, min_value=10) == 50
    assert pct_to_int("50%", 100, min_value=51) == 51
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int(52, 100) == 52
    assert pct_to_int(52, 100, min_value=51) == 52
    assert pct_to_int(52, 100, min_value=53) == 53

# Generated at 2022-06-21 08:43:45.027602
# Unit test for function deduplicate_list
def test_deduplicate_list():
    dummy_list = [1, 2, 2, 3, 4, 5, 6, 6, 7, 8, 8, 8, 9, 10, 11, 11, 12]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    assert expected_list == deduplicate_list(dummy_list)



# Generated at 2022-06-21 08:43:50.443074
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("5%", 10) == 1
    assert pct_to_int("33%", 10) == 3
    assert pct_to_int("33", 10) == 33
    assert pct_to_int(33, 10) == 33
    assert pct_to_int("50%", 2) == 1
    assert pct_to_int("50%", 4) == 2