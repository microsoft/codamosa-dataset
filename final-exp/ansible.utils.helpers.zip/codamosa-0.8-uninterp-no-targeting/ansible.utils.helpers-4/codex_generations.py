

# Generated at 2022-06-21 08:35:08.259238
# Unit test for function object_to_dict
def test_object_to_dict():
    test_obj = {"obj1": "value1", "obj2": "value2", "_obj3": "value3"}
    result_obj = object_to_dict(test_obj, exclude=["_obj3"])
    assert result_obj == {"obj1": "value1", "obj2": "value2"}


# Generated at 2022-06-21 08:35:13.827420
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 20) == 2
    assert pct_to_int('20%', 200) == 40
    assert pct_to_int('20%', 25) == 5
    assert pct_to_int('10%', 200, min_value=10) == 20

    assert pct_to_int(10, 200, min_value=10) == 10
    assert pct_to_int(20, 200, min_value=10) == 20
    assert pct_to_int(30, 200, min_value=10) == 30

# Generated at 2022-06-21 08:35:20.225100
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list.
    """
    original_list = [1, 2, 3, 3, 9, 5, 5, 1, 9, 5]
    expected_result = [1, 2, 3, 9, 5]
    result = deduplicate_list(original_list)
    assert result == expected_result,\
        'Returned %s instead of %s' % (result, expected_result)


# Generated at 2022-06-21 08:35:25.006474
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 3, 2, 1, 6, 7, 8]
    list2 = deduplicate_list(list1)
    assert list2 == [1, 2, 3, 6, 7, 8]



# Generated at 2022-06-21 08:35:27.454302
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        attr_1 = 'hello'
        attr_2 = 'world'

    obj = TestObj()
    assert set(object_to_dict(obj, exclude=['attr_2'])) == set(['attr_1']), 'Exclude filter failed'
    assert set(object_to_dict(obj)) == set(['attr_1', 'attr_2']), 'Not all attributes were returned'
    assert not set(object_to_dict(obj)) == set(['attr_2', 'attr_1']), 'Order does not match'

# Generated at 2022-06-21 08:35:38.623709
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('19%', 19) == 1
    assert pct_to_int('20%', 20) == 1
    assert pct_to_int('100%', 20) == 20
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(19, 19) == 19
    assert pct_to_int(20, 20) == 20
    assert pct_to_int(100, 20) == 100
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int('0%', 19) == 1
    assert pct_to_int('0%', 20) == 1
    assert pct_to_int(0, 20) == 1


# Generated at 2022-06-21 08:35:45.081441
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self.key3 = 'value3'
            self.key4 = 'value4'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, exclude=['key1'])
    assert test_dict == {'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}

# Generated at 2022-06-21 08:35:55.361437
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 4, 5, 5, 1, 2]) == [1, 2, 3, 4, 5, 1, 2]
    assert deduplicate_list(['a', 'a', 'b', 'c', 'c', 'c', 'd', 'e', 'e', 'c']) == \
        ['a', 'b', 'c', 'd', 'e', 'c']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a', 'a']) == ['a']

# Generated at 2022-06-21 08:36:01.722917
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int('1%', 100)
    assert 1 == pct_to_int('1', 100)
    assert 1 == pct_to_int('1%', 100, 1)
    assert 4 == pct_to_int('4%', 100)
    assert 4 == pct_to_int('4%', 100, 5)
    assert 5 == pct_to_int('4%', 100, 5)
    assert 5 == pct_to_int('5%', 100)


# Generated at 2022-06-21 08:36:03.787725
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 2, 1]) == [1, 2, 3]

# Generated at 2022-06-21 08:36:10.714655
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = ['b', 'a', 'a', 'c', 'd', 'd', 'a', 'c', 'd']
    expected_list = ['b', 'a', 'c', 'd']

    output_list = deduplicate_list(input_list)
    assert output_list == expected_list, "Failed to deduplicate list"

# Generated at 2022-06-21 08:36:20.415219
# Unit test for function pct_to_int
def test_pct_to_int():
    # Ensure a percent is converted to an int
    assert pct_to_int('15%', 100, 1) == 15
    assert pct_to_int('15%', 100) == 15

    # Ensure a int is passed through
    assert pct_to_int(15, 100, 1) == 15
    assert pct_to_int(15, 100) == 15

    # Ensure non numeric & empty values are set to 1
    assert pct_to_int('15%a', 100, 1) == 1
    assert pct_to_int('15%a', 100) == 1

    assert pct_to_int('', 100, 1) == 1
    assert pct_to_int('', 100) == 1

# Generated at 2022-06-21 08:36:28.202774
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [0, 1, 0, 2, 1]
    assert deduplicate_list(test_list) == [0, 1, 2]
    test_list = [0, 1, 2, 3, 4]
    assert deduplicate_list(test_list) == [0, 1, 2, 3, 4]
    test_list = [0, 0, 0, 0, 0]
    assert deduplicate_list(test_list) == [0]
    test_list = [0, 1, 0, 2, 3, 2, 1, 2, 3]
    assert deduplicate_list(test_list) == [0, 1, 2, 3]


# Generated at 2022-06-21 08:36:40.054800
# Unit test for function object_to_dict
def test_object_to_dict():
    class dict_test_class(object):
        def __init__(self):
            self.prop1 = 'test1'
            self.prop2 = 'test2'
            self.prop3 = 'test3'

    obj = dict_test_class()
    new_dict = object_to_dict(obj)
    assert new_dict['prop1'] == 'test1'
    assert new_dict['prop2'] == 'test2'
    assert new_dict['prop3'] == 'test3'

    new_dict = object_to_dict(obj, exclude=['prop2'])
    assert new_dict['prop1'] == 'test1'
    assert 'prop2' not in new_dict
    assert new_dict['prop3'] == 'test3'

# Generated at 2022-06-21 08:36:44.454514
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'a', 'b', 'b', 'b','c', 'd', 'd', 'e']
    expected_result = ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(original_list) == expected_result



# Generated at 2022-06-21 08:36:48.068378
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list_1 = [1,2,3,2,1]
    assert deduplicate_list(test_list_1) == [1,2,3]

    test_list_2 = [1,2,2,1,2]
    assert deduplicate_list(test_list_2) == [1,2]

# Generated at 2022-06-21 08:37:00.263167
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.0', 100) == 10
    assert pct_to_int('.1', 100) == 1
    assert pct_to_int('.001', 100) == 1
    assert pct_to_int('.001%', 100) == 1
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('1%', 100) == 1


# Generated at 2022-06-21 08:37:04.291496
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list1 = ['a', 'b', 'b', 'c', 'c', 'c']
    assert deduplicate_list(test_list1) == ['a', 'b', 'c']
    test_list2 = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]
    assert deduplicate_list(test_list2) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:37:08.409745
# Unit test for function object_to_dict
def test_object_to_dict():
    answer =  {'a': 3}
    class TestObject(object):
        a = 3
        b = 5
    assert object_to_dict(TestObject()) == answer
    assert object_to_dict(TestObject(), exclude=['b']) == answer

# Generated at 2022-06-21 08:37:11.912395
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 3, 4, 1, 2, 5, 6, 7, 8, 7]
    result = deduplicate_list(original_list)
    assert result == [1, 2, 3, 4, 5, 6, 7, 8]


# Generated at 2022-06-21 08:37:24.937296
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests for object_to_dict
    """
    from ansible.module_utils.net_tools.nxos import nxos
    interface_obj = nxos.Interface('Ethernet1/1', '10.0.0.1', '255.255.255.0', 'up', 'up')
    ret = object_to_dict(interface_obj)
    assert ret['description'] == 'up'
    assert ret['ipv4'] == '10.0.0.1'
    assert ret['ipv4_netmask'] == '255.255.255.0'
    assert ret['name'] == 'Ethernet1/1'
    assert ret['enabled'] == 'up'



# Generated at 2022-06-21 08:37:34.902591
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    mc = MyClass()

    # Should get back a dict with the same keys
    d = object_to_dict(mc)
    assert d == mc.__dict__

    # Should get back a dict which excludes all of the provided keys
    d = object_to_dict(mc, exclude=['a', 'b'])
    assert d == {}

    # Should not exclude any keys when no keys are provided
    d = object_to_dict(mc, exclude=None)
    assert d == mc.__dict__

    # Should not exclude any keys when empty list is provided
    d = object_to_dict(mc, exclude=[])
    assert d == mc.__dict__



# Generated at 2022-06-21 08:37:40.756335
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.id = 100
            self.ip = "1.1.1.1"
            self.name = "test"

    obj = test_class()
    result = object_to_dict(obj, ["id"])
    assert result["ip"] == "1.1.1.1"
    assert result["name"] == "test"
    assert "id" not in result

# Generated at 2022-06-21 08:37:46.637614
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([6, 4, 7, 8, 4, 2, 8, 6, 4]) == [6, 4, 7, 8, 2]
    assert deduplicate_list(["b", "a", "d", "a", "d", "c", "b", "a"]) == ["b", "a", "d", "c"]
    assert deduplicate_list(["b", "a", "d", "a", "d", "c", "b", "a"]) != ["a", "b", "c", "d"]

# Generated at 2022-06-21 08:37:58.563153
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('', 100) == 0
    assert pct_to_int('100', 100) == 100
    assert pct_to_int('100', 100) == 100
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50', 100, min_value=2) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 100) == 10

# Generated at 2022-06-21 08:38:03.993621
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    test_result = object_to_dict(test_class())
    expected_result = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    assert test_result == expected_result

# Generated at 2022-06-21 08:38:10.067042
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    obj = A()
    result = object_to_dict(obj, ['b'])
    assert set(result.keys()) == set(['a', 'c'])

# Generated at 2022-06-21 08:38:20.454455
# Unit test for function pct_to_int
def test_pct_to_int():
    # Should return an int when given a whole number
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', '100') == 10

    # Should return an int when given a whole number and convert a percent str to int
    assert pct_to_int('10%', '100') == 10
    assert pct_to_int('10.5%', '100') == 10
    assert pct_to_int('25%', '100') == 25

    # Should return the min_value when given a percent less than min_value
    assert pct_to_int('0.5%', '100') == 1
    assert pct_to_int('0.5%', '100', min_value=100) == 100



# Generated at 2022-06-21 08:38:27.374079
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    test_obj = TestClass()

    result = object_to_dict(test_obj, [])
    assert sorted(result.keys()) == ['a', 'b', 'c']

    result = object_to_dict(test_obj, ['b'])
    assert sorted(result.keys()) == ['a', 'c']

# Generated at 2022-06-21 08:38:31.360867
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 4, 1, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 1, 5]) == [1, 2, 3, 5]

# Generated at 2022-06-21 08:38:50.899177
# Unit test for function pct_to_int
def test_pct_to_int():

    # If pct_to_int is given a number it should return it unchanged
    assert pct_to_int(5, 10) == 5
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(5, 1) == 5

    # If pct_to_int is given a string it should convert it to a number
    assert pct_to_int("5", 10) == 5
    assert pct_to_int("5", 100) == 5
    assert pct_to_int("5", 1) == 5

    # If pct_to_int is given a pct it should convert it to a number
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int("50%", 100) == 50
    assert pct_to_

# Generated at 2022-06-21 08:38:55.194191
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test function.
    """
    assert deduplicate_list([1,1,2,2,3,3,4,4,5,6,7,6,8,8]) == [1, 2, 3, 4, 5, 6, 7, 8]



# Generated at 2022-06-21 08:39:02.636432
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        attribute1 = 'attribute1'
        attribute2 = 'attribute2'
        attribute3 = 'attribute3'
        _attribute4 = 'attribute4'
        def __init__(self):
            self.object_attribute1 = 'object_attribute1'
            self.object_attribute2 = 'object_attribute2'
            self._object_attribute3 = 'object_attribute3'

    testClass = MyClass()
    testDict = object_to_dict(testClass)
    assert sorted(testDict.items()) == [('attribute1', 'attribute1'), ('attribute2', 'attribute2'), ('attribute3', 'attribute3')]
    assert '_attribute4' not in testDict


# Generated at 2022-06-21 08:39:11.008949
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 08:39:21.526956
# Unit test for function object_to_dict
def test_object_to_dict():
    class vrfs(object):
        def __init__(self):
            self.name = None
            self.interfaces = None
            self.state = 'absent'
            self.max_routes = None

    v = vrfs()
    v.name = 'red'
    v.interfaces = ['one', 'two']
    v.max_routes = 100
    x = object_to_dict(v)
    assert len(x) == 5
    assert isinstance(x, dict)
    assert x['name'] == 'red'
    assert x['interfaces'] == ['one', 'two']
    assert x['state'] == 'absent'
    assert x['max_routes'] == 100

# Generated at 2022-06-21 08:39:32.673975
# Unit test for function object_to_dict
def test_object_to_dict():
    """Tests object_to_dict function."""
    class A(object):
        def __init__(self):
            self.a = 'one'
            self.b = 'two'
    class B(object):
        def __init__(self):
            self.b = 'three'
            self.c = 'four'
            self.__dict__['a'] = 'five'
            self.__dict__['d'] = 'six'
    a = A()
    assert object_to_dict(a) == {'a': 'one', 'b': 'two'}
    b = B()
    assert object_to_dict(b) == {'a': 'five', 'b': 'three', 'c': 'four', 'd': 'six'}

# Generated at 2022-06-21 08:39:39.621452
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test1:
        a = 1
        b = 2
        c = 3
        d = 4

    assert object_to_dict(Test1) == dict(a=1, b=2, c=3, d=4)
    assert object_to_dict(Test1, ['c', 'd']) == dict(a=1, b=2)



# Generated at 2022-06-21 08:39:42.709044
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert ['a', 'b', 'c', 'd'] == deduplicate_list(['a', 'a', 'b', 'b', 'b', 'c', 'd', 'd', 'd'])

# Generated at 2022-06-21 08:39:46.652602
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 3, 3, 4, 5, 5, 1]
    assert deduplicate_list(original_list) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 08:39:50.082158
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,3]) == [1,2,3]
    assert deduplicate_list([1,2,2,3,2]) == [1,2,3,2]
    assert deduplicate_list([]) == []

# Generated at 2022-06-21 08:40:11.647908
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'a', 'b', 'b', 'c']) == ['a', 'b', 'c']



# Generated at 2022-06-21 08:40:16.593391
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test to ensure the deduplicate list function works as expected
    """
    original_list = ['a', 'b', 'c', 'a', 'b', 'd']
    expected_list = ['a', 'b', 'c', 'd']
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-21 08:40:20.876161
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    t = Test()
    t_dict = object_to_dict(t, ['b'])

    assert len(t_dict) == 2
    assert 'a' in t_dict
    assert 'b' not in t_dict
    assert 'c' in t_dict
    assert t_dict['a'] == 1
    assert t_dict['c'] == 3

# Generated at 2022-06-21 08:40:25.687535
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'c', 'a', 'b', 'c', 'f', 'd', 'c', 'b', 'f']
    assert ['b', 'c', 'a', 'f', 'd'] == deduplicate_list(original_list)

# Generated at 2022-06-21 08:40:30.276911
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        foo = 'hi'
        bar = 'world'
        baz = 'how are you?'

    class Bar(object):
        foo = 'hi'
        bar = 'world'
        baz = 'how are you?'

    assert object_to_dict(Foo()) == object_to_dict(Bar())



# Generated at 2022-06-21 08:40:41.307341
# Unit test for function pct_to_int
def test_pct_to_int():
    actual = pct_to_int('50%', 10, 1)
    expected = 5
    assert actual == expected

    actual = pct_to_int(5, 10, 1)
    expected = 5
    assert actual == expected

    actual = pct_to_int(50, 10, 1)
    expected = 5
    assert actual == expected

    actual = pct_to_int('50%', 10)
    expected = 5
    assert actual == expected

    actual = pct_to_int(50, 10)
    expected = 5
    assert actual == expected

    actual = pct_to_int(0, 10)
    expected = 0
    assert actual == expected

    actual = pct_to_int(0, 10, 2)
    expected = 2
    assert actual == expected

    actual = pct_to

# Generated at 2022-06-21 08:40:52.689834
# Unit test for function object_to_dict
def test_object_to_dict():
    class ModuleTestObject(object):
        def __init__(self):
            self.attr1 = "string"
            self.attr2 = 1
            self.attr3 = [1, 2, 3]
            self._private_attr = "hidden"

    module_test_object = ModuleTestObject()

    # Make sure the module_test_object has the required attributes
    object_dict = object_to_dict(module_test_object)
    for key in ['attr1', 'attr2', 'attr3']:
        assert key in object_dict.keys()

    # Now test excluding one attribute
    object_dict = object_to_dict(module_test_object, ["attr1"])
    assert "attr1" not in object_dict.keys()


# Generated at 2022-06-21 08:40:57.620146
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    attributes = ['a', 'b', 'c', 'd']
    Test = namedtuple('Test', attributes)
    test = Test(1, 2, 3, 4)
    assert object_to_dict(test) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-21 08:41:07.381186
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test deduplicate_list()
    actual_result = deduplicate_list(['b', 'a', 'c', 'a', 'a', 'd', 'e', 'b'])
    assert actual_result == ['b', 'a', 'c', 'd', 'e']

    actual_result = deduplicate_list([])
    assert actual_result == []

    actual_result = deduplicate_list([None])
    assert actual_result == [None]

    actual_result = deduplicate_list(['a', 'a', 'a'])
    assert actual_result == ['a']



# Generated at 2022-06-21 08:41:16.831539
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClassOne:
        def __init__(self):
            self.a = ''
            self.b = ''

        def get_a(self):
            return self.a

        def get_b(self):
            return self.b

    test_obj = TestClassOne()
    test_obj.a = 'test_a'
    test_obj.b = 'test_b'

    assert object_to_dict(test_obj) == {'a': 'test_a', 'b': 'test_b'}
    assert object_to_dict(test_obj, ['a']) == {'b': 'test_b'}

# Generated at 2022-06-21 08:41:57.411731
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100) == 25
    assert pct_to_int('25', 100) == 25
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('25.5%', 100) == 25
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:42:03.848635
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 300) == 30
    assert pct_to_int('10%', 300, min_value=10) == 30
    assert pct_to_int('10%', 29, min_value=10) == 10
    assert pct_to_int(5, 8) == 5
    assert pct_to_int(5.5, 8) == 6
    assert pct_to_int(5, 8.5) == 5

# Generated at 2022-06-21 08:42:12.098427
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('110%', 100) == 110
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0.1%', 100) == 1
    assert pct_to_int('0.01%', 100) == 1
    assert pct_to_int('0.001%', 100) == 1
    assert pct_to_int('0.0001%', 100) == 1
    assert pct_to_int('0.00001%', 100) == 1

# Generated at 2022-06-21 08:42:18.435544
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
    expected_list = [1, 2, 3, 4, 5, 6]
    actual_list = deduplicate_list(test_list)
    assert expected_list == actual_list, "Unexpected results found, expected: {0}, actual: {1}".format(
        expected_list, actual_list)


# Generated at 2022-06-21 08:42:24.949557
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    assert object_to_dict(A(), ["a"]) == dict(b=2, c=3, d=4, e=5)
    assert object_to_dict(A(), ["a", "b"]) == dict(c=3, d=4, e=5)



# Generated at 2022-06-21 08:42:27.587789
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object:
        def __init__(self):
            self.x = 100

    obj = Object()
    assert object_to_dict(obj) == {'x': 100}



# Generated at 2022-06-21 08:42:30.608057
# Unit test for function object_to_dict
def test_object_to_dict():
    class Struct:
        def __init__(self):
            self.a = 1
            self.b = 2
    
    o = Struct()

    dict = object_to_dict(o)

    assert dict['a'] == 1
    assert dict['b'] == 2



# Generated at 2022-06-21 08:42:35.599776
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.test1 = 1
            self.test2 = 2
            self._test3 = 3

    obj = TestObj()
    obj_dict = object_to_dict(obj)

    assert 'test1' in obj_dict
    assert 'test2' in obj_dict
    assert '_test3' not in obj_dict

# Generated at 2022-06-21 08:42:41.561719
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test1 = 'hello'
            self.test2 = 'world'
            self.test3 = 'test'

    test = TestClass()
    result = object_to_dict(test, exclude=['test1'])
    assert result['test2'] == 'world'
    assert result['test3'] == 'test'
    assert 'test1' not in result



# Generated at 2022-06-21 08:42:46.142803
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for deduplicate_list function
    """
    assert deduplicate_list([1,2,3,1,1,1,2,3,4,5,2,2,2,2,1,1,1,1,1,1]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 08:44:05.967129
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        a = 1
        b = 2

    ret = object_to_dict(TestObj)
    assert 'a' in ret
    assert ret['a'] == 1
    assert 'b' in ret
    assert ret['b'] == 2

    class TestObj2(object):
        _a = 1
        _b = 2
        c = 3

    ret = object_to_dict(TestObj2, exclude=['c'])
    assert 'a' not in ret
    assert 'b' not in ret
    assert '_a' not in ret
    assert '_b' not in ret
    assert 'c' not in ret



# Generated at 2022-06-21 08:44:17.511754
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass(object):
        pass
    d = DummyClass()
    setattr(d, 'property1', 'value1')
    setattr(d, 'property2', 'value2')
    setattr(d, 'property3', 'value3')
    setattr(d, 'another_property', 'test')
    result = object_to_dict(d, exclude=['another_property'])
    assert result == {'property1': 'value1', 'property2': 'value2', 'property3': 'value3'}
    setattr(d, '_private_property', 'hidden')
    result = object_to_dict(d)
    assert result == {'property1': 'value1', 'property2': 'value2', 'property3': 'value3', 'another_property': 'test'}

# Generated at 2022-06-21 08:44:23.718937
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 4, 1, 5, 3]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 1, 1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 2, 1, 2, 1, 2, 5, 1, 1, 2, 5, 2, 1]) == [1, 2, 5]

# Generated at 2022-06-21 08:44:33.463164
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        x = 1
        y = 3
        z = 5
    my_object = MyObject()
    assert isinstance(object_to_dict(my_object), dict)
    assert 'x' in object_to_dict(my_object)
    assert object_to_dict(my_object)['x'] == 1
    assert 'y' in object_to_dict(my_object)
    assert object_to_dict(my_object)['y'] == 3
    assert 'z' in object_to_dict(my_object)
    assert object_to_dict(my_object)['z'] == 5
    assert 'm' not in object_to_dict(my_object)
    assert '__' not in object_to_dict(my_object)

# Generated at 2022-06-21 08:44:38.371081
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object
    obj.name = "test"
    obj.ip = "10.10.10.10"
    obj.username = "test_user"
    obj.password = "test_password"
    assert object_to_dict(obj, exclude=["username", "password"]) == {"name": "test", "ip": "10.10.10.10"}



# Generated at 2022-06-21 08:44:48.908152
# Unit test for function deduplicate_list
def test_deduplicate_list():

    test_list = [1, 1, 2, 3, 3, 4, 5, 6, 7, 7]
    assert deduplicate_list(test_list) == [1, 2, 3, 4, 5, 6, 7]

    test_list_of_strings = ['a', 'a', 'b', 'c', 'c', 'd', 'e', 'f', 'g', 'g']
    assert deduplicate_list(test_list_of_strings) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']

    test_list_of_strings_and_ints = ['a', 1, 'b', 2, 'c', 3, 'd', 4, 'e', 5, 'f', 6, 'g', 7, 8]

# Generated at 2022-06-21 08:44:57.510402
# Unit test for function object_to_dict
def test_object_to_dict():
    # Simple class to create an object
    class TestClass(object):
        class_name = 'test'
        class_type = 'test_type'

        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name', 'test_instance')
            self.type = kwargs.get('type', 'test_instance_type')
            self.state = kwargs.get('state', None)

    # Create instance of the TestClass
    test_instance = TestClass()

    # Create a dict with some values
    test_dict = dict(test_value=test_instance)

    # Translate the dict to a str
    dict_to_str = repr(test_dict)

    # Compare translated dict to known string

# Generated at 2022-06-21 08:45:07.631278
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Verifies that the output of object_to_dict should be a dictionary with the same keys as the object's
    properties.
    """
    class TestObj(object):
        def __init__(self, key1, key2):
            self.key1 = key1
            self.key2 = key2

    test_obj = TestObj('value1', 3)
    dict_obj = object_to_dict(test_obj)