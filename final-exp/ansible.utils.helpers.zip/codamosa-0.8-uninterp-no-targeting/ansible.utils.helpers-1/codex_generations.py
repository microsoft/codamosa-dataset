

# Generated at 2022-06-21 08:35:09.760885
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(2, 100) == 2



# Generated at 2022-06-21 08:35:13.966421
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = TestObject()

    assert object_to_dict(obj) == {'a': 1, 'c': 3, 'b': 2}
    assert object_to_dict(obj, exclude=['b']) == {'a': 1, 'c': 3}


# Generated at 2022-06-21 08:35:16.194925
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','a','b','c','d','b','c']) == ['a','b','c','d']

# Generated at 2022-06-21 08:35:27.129232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test function for deduplicate_list
    """
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 08:35:31.839498
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 0) == 1
    assert pct_to_int('0%', 100) == 1



# Generated at 2022-06-21 08:35:39.871265
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 'a', 2, 'a', 4, 5, 'a']) == [1, 'a', 2, 4, 5]



# Generated at 2022-06-21 08:35:46.634605
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    o = Object(a=1, b=2, c="A")
    d = object_to_dict(o, exclude=['c'])
    assert len(d) == 2
    assert d['a'] == 1
    assert d['b'] == 2
    return True


# Generated at 2022-06-21 08:35:58.296508
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list function
    """
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([2, 1, 2, 1]) == [2, 1]
    assert deduplicate_list([3, 2, 1, 2, 1, 3]) == [3, 2, 1]

# Generated at 2022-06-21 08:36:01.939000
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    assert deduplicate_list([1, 1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([3, 2, 1, 1, 4]) == [3, 2, 1, 4]



# Generated at 2022-06-21 08:36:12.569533
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj (object):
        def __init__(self):
            self.test_val = 'test_val'
            self._test_val_2 = 'test_val_2'
            self._test_val_3 = 'test_val_3'
            self.test_val_4 = 'test_val_4'

    obj = test_obj()
    assert object_to_dict(obj)['test_val'] == 'test_val'
    assert 'test_val_2' not in object_to_dict(obj)
    assert 'test_val_3' not in object_to_dict(obj)
    assert object_to_dict(obj)['test_val_4'] == 'test_val_4'
    assert object_to_dict(obj, exclude=['_test_val_3'])

# Generated at 2022-06-21 08:36:22.430516
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.prop1 = "prop1"
            self.prop2 = "prop2"
            self.prop3 = "prop3"

        def method1(self):
            return "method1"

    test_class = TestClass()
    test_dict = object_to_dict(test_class, exclude=['method1'])

    assert 'prop1' in test_dict
    assert 'prop2' in test_dict
    assert 'prop3' in test_dict
    assert 'method1' not in test_dict



# Generated at 2022-06-21 08:36:25.943956
# Unit test for function pct_to_int
def test_pct_to_int():
    # if value is an integer, it is returned unchanged
    assert pct_to_int(12, 1000) == 12

    # otherwise, the percents are converted
    assert pct_to_int("10%", 200) == 20
    assert pct_to_int("50%", 100) == 50


# Generated at 2022-06-21 08:36:29.791702
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = [1,2]
    result = deduplicate_list(list)
    assert result == [1,2], 'test_deduplicate_list failed'


# Generated at 2022-06-21 08:36:35.821202
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,2,1]) == [1,2,3]
    assert deduplicate_list([1,3,3,4]) == [1,3,4]
    assert deduplicate_list([1,2,2,2,2,2,2,1]) == [1,2]

# Generated at 2022-06-21 08:36:46.365519
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, 0) == 20
    assert pct_to_int('20%', 100, 2) == 20
    assert pct_to_int('20%', 100, 100) == 20
    assert pct_to_int('20%', 50) == 10
    assert pct_to_int(20, 50) == 20
    assert pct_to_int('20', 50) == 20
    assert pct_to_int('120%', 200) == 120
    assert pct_to_int('1%', 200) == 1
    assert pct_to_int('2%', 200, 100) == 100
    assert pct_to_int('0%', 200) == 1
    assert pct_to

# Generated at 2022-06-21 08:36:56.468993
# Unit test for function object_to_dict
def test_object_to_dict():
    class myclass(object):
        """
        Object only used to test object_to_dict()
        """
        def __init__(self):
            self.a = 'A'
            self.b = 'B'
            self.c = 'C'
            self.d = 'D'

    obj = myclass()
    assert object_to_dict(obj) == {'a': 'A', 'c': 'C', 'b': 'B', 'd': 'D'}
    assert object_to_dict(obj, exclude=['a', 'c']) == {'b': 'B', 'd': 'D'}

# Generated at 2022-06-21 08:37:04.827362
# Unit test for function object_to_dict
def test_object_to_dict():
    from napalm.base.base import NetworkDriver
    from napalm.base.exceptions import ConnectionException
    from napalm.base.helper import get_network_driver
    def test_exclude():
        driver_obj = get_network_driver('junos')
        driver_obj.connection = 'test'
        driver_obj.hostname = 'test'
        driver_obj.username = 'test'
        driver_obj.password = 'test'
        driver_obj.hostname = 'test'
        driver_obj.timeout = 'test'
        driver_obj.optional_args = 'test'
        driver_dict = {'connection': 'test', 'hostname': 'test', 'username': 'test', 'password': 'test',
                       'optional_args': 'test'}

# Generated at 2022-06-21 08:37:14.621028
# Unit test for function pct_to_int
def test_pct_to_int():
    item_count_list = [1, 100, 1000, 10000, 100000]

    for num_items in item_count_list:
        # test with full percent
        assert pct_to_int('10%', num_items) == int(0.10 * num_items)

        # test with no percent
        assert pct_to_int(num_items, num_items) == num_items

        # test with min value, which should be always rounded up to 1 at least
        assert pct_to_int('0.1%', num_items, 1) == 1

        # test with min value, which should be always rounded up to 1 at least
        assert pct_to_int('0.51%', num_items, 1) == 1

        # test with min value, which should be always rounded up to 1 at least

# Generated at 2022-06-21 08:37:18.297245
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible.module_utils.network.common.utils import deduplicate_list as to_test
    assert to_test([1,2,3,1,2]) == [1,2,3]

# Generated at 2022-06-21 08:37:26.314299
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    original_list = ['A', 'B', 'C', 'D', 'A', 'E', 'F', 'C']
    deduped_list = deduplicate_list(original_list)
    if deduped_list == ['A', 'B', 'C', 'D', 'E', 'F']:
         print("Test for function deduplicate_list: Passed")
    else:
         print("Test for function deduplicate_list: Failed")

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-21 08:37:38.575348
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("5%", 100) == 5
    assert pct_to_int("0%", 100) == 0
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 0) == 1
    assert pct_to_int("10%", 0) == 1
    assert pct_to_int("10%", 666) == 67
    assert pct_to_int("0.95%", 100) == 1
    assert pct_to_int("95%", 100) == 95
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(-1, 100) == 1
    assert pct_to_int(200, 100) == 200

# Generated at 2022-06-21 08:37:43.566313
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    Test pct_to_int
    """
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100', 100) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101', 100) == 101
    assert pct_to_int(0, 100) == 0

# Generated at 2022-06-21 08:37:47.495896
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass(object):
        def __init__(self):
            self.param1 = 'one'
            self.param2 = 'two'
            self.excluded_param = 'should not be in the result'

    obj = SampleClass()
    result = object_to_dict(obj, exclude=['excluded_param'])
    assert 'excluded_param' not in result
    assert 'param1' in result and result['param1'] == 'one'
    assert 'param2' in result and result['param2'] == 'two'



# Generated at 2022-06-21 08:37:53.521583
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 3, 2, 1]) == [1, 2, 3, 4]



# Generated at 2022-06-21 08:37:58.636481
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 1000) == 10

# Generated at 2022-06-21 08:38:01.069532
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_a = ['a', 'b', 'c', 'a', 'c', 'a', 'b']
    expected = ['a', 'b', 'c']
    result = deduplicate_list(list_a)
    assert result == expected

# Generated at 2022-06-21 08:38:04.912127
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self._c = 'c'
    a = A()
    assert object_to_dict(a) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(a, exclude=['b']) == {'a': 'a'}

# Generated at 2022-06-21 08:38:16.545541
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('75%', 100) == 75
    assert pct_to_int('75%', 85) == 64
    assert pct_to_int('100%', 85) == 85
    assert pct_to_int('85%', 85) == 73
    assert pct_to_int('10%', 85) == 9
    assert pct_to_int('0%', 85) == 1
    assert pct_to_int('-1%', 85) == 1
    assert pct_to_int('105%', 85) == 90
    assert pct_to_int(75, 85) == 75
    assert pct_to_int(88, 85) == 88
    assert pct_to_int(85, 85) == 85

# Generated at 2022-06-21 08:38:25.224590
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(2, 100, 1) == 2
    assert pct_to_int(2.5, 100, 1) == 2
    assert pct_to_int(0, 100, 1) == 0
    assert pct_to_int(101, 100, 1) == 101
    assert pct_to_int('2%', 100, 1) == 2
    assert pct_to_int('50%', 100, 1) == 50
    assert pct_to_int('99%', 100, 1) == 99
    assert pct_to_int('100%', 100, 1) == 100
    assert pct_to_int('101%', 100, 1) == 101
    assert pct_to_int('0%', 100, 1) == 1

# Generated at 2022-06-21 08:38:30.914084
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test the deduplicate_list function
    """
    orig_list = ['a','a','b','c','a','b','d','c','e','a','b','f','c','g','h']
    new_list = deduplicate_list(orig_list)
    assert new_list == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']

# Generated at 2022-06-21 08:38:49.580706
# Unit test for function pct_to_int
def test_pct_to_int():
    # Simple integer value test
    assert pct_to_int(5, 100) == 5
    # Percentage value test
    assert pct_to_int(5, 100, min_value=1) == 5
    # Percentage value test with a minimum value
    assert pct_to_int(5, 100, min_value=5) == 5
    assert pct_to_int(5, 100, min_value=10) == 10
    # Percentage value test without minimum value specified, which defaults to 1
    assert pct_to_int(1, 100, min_value=1) == 1
    assert pct_to_int(1, 100) == 1
    # Percentage value test with a minimum value
    assert pct_to_int(1, 100, min_value=1) == 1

# Generated at 2022-06-21 08:38:59.358379
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(1, 100) == 1)
    assert(pct_to_int('1', 100) == 1)
    assert(pct_to_int(10, 100) == 10)
    assert(pct_to_int(10.1, 100) == 10)
    assert(pct_to_int('1%', 100) == 1)
    assert(pct_to_int('10%', 100) == 10)
    assert(pct_to_int('10.1%', 100) == 10)
    assert(pct_to_int(0, 100) == 1)
    assert(pct_to_int('0', 100) == 1)
    assert(pct_to_int(0.0, 100) == 1)

# Generated at 2022-06-21 08:39:05.355725
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
    my_test = TestClass()
    my_dict = object_to_dict(my_test)
    assert 'test1' in my_dict
    assert my_dict.get('_private') is None



# Generated at 2022-06-21 08:39:09.895107
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 1]) == [1, 2]


# Generated at 2022-06-21 08:39:14.733363
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('75%', 100) == 75
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(1.5, 100) == 2


# Generated at 2022-06-21 08:39:20.123109
# Unit test for function object_to_dict
def test_object_to_dict():
    class ClassA(object):
        attr1 = 1
        attr2 = 2
        attr3 = 3

    my_obj = ClassA()
    my_obj.attr4 = 4

    assert object_to_dict(my_obj) == {'attr1': 1, 'attr2': 2, 'attr3': 3, 'attr4': 4}

# Generated at 2022-06-21 08:39:24.313994
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:39:34.870901
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int('1%', 4096)
    assert value == 40, 'pct_to_int failed - expected 40, got %s' % value

    value = pct_to_int('2%', 100)
    assert value == 2, 'pct_to_int failed - expected 2, got %s' % value

    value = pct_to_int(10, 100)
    assert value == 10, 'pct_to_int failed - expected 10, got %s' % value

    value = pct_to_int('1%', 1)
    assert value == 1, 'pct_to_int failed - expected 1, got %s' % value

    value = pct_to_int('1%', 0)

# Generated at 2022-06-21 08:39:37.350114
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 1, 4, 3]
    assert deduplicate_list(test_list) == [1, 2, 3, 4]


# Generated at 2022-06-21 08:39:41.041429
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100, "Percentage to int failed"
    assert pct_to_int(10, 1000) == 10, "Integer to int failed"

# Generated at 2022-06-21 08:40:00.187265
# Unit test for function deduplicate_list
def test_deduplicate_list():
    org_list = ['a', 'b', 'c', 'a', 'b', 'c']
    dedup_list = deduplicate_list(org_list)
    assert dedup_list == ['a', 'b', 'c']

# Generated at 2022-06-21 08:40:05.295219
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
    deduplicated_list = [1, 2, 3, 4, 5]
    if deduplicate_list(original_list) != deduplicated_list:
        raise AssertionError('Test not passed')
    else:
        pass


# Generated at 2022-06-21 08:40:12.488313
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [x for x in range(30)]
    original_list.append(10)
    original_list.append(15)
    deduplicate_list(original_list)

    for i, element in enumerate(original_list):
        if i == element:
            continue
        if element in original_list[i + 1:]:
            assert False, 'Duplicate element in deduplicated list'



# Generated at 2022-06-21 08:40:20.038519
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        abc = "def"
        ghi = "jkl"
        _hidden = "secret"

    obj = Obj()
    result_dict = object_to_dict(obj)
    # result_dict contains hidden keys
    assert(result_dict.keys() == ["abc", "ghi", "_hidden"])

    result_dict = object_to_dict(obj, exclude=["_hidden"])
    # hidden key is excluded
    assert(result_dict.keys() == ["abc", "ghi"])

# Generated at 2022-06-21 08:40:22.945307
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1) == 1
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int('10%', 50, min_value=2) == 5


# Generated at 2022-06-21 08:40:30.198567
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        attr1 = 'val1'
        attr2 = 'val2'
        attr3 = 'val3'
        attr4 = 'val4'
    test_obj = TestObject()

    ret = object_to_dict(test_obj, exclude=['attr4'])
    assert ret == {
        'attr1': 'val1',
        'attr2': 'val2',
        'attr3': 'val3'
    }


# Generated at 2022-06-21 08:40:37.397856
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 10, min_value=1) == 1
    assert pct_to_int('2', 10, min_value=1) == 2
    assert pct_to_int('0%', 10, min_value=1) == 1
    assert pct_to_int('100%', 10, min_value=1) == 10
    assert pct_to_int('110%', 10, min_value=1) == 11

# Generated at 2022-06-21 08:40:42.680930
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test list with duplicate items
    assert deduplicate_list([2, 2, 1]) == [2, 1]
    # Test list with no duplicate items
    assert deduplicate_list([2, 1]) == [2, 1]
    # Test with non-list input
    assert deduplicate_list(2) == [2]
    # Test with none input
    assert deduplicate_list(None) == [None]

# Generated at 2022-06-21 08:40:51.483567
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test = "test"
            self.test2 = "test2"

        def test_method(self):
            return

    obj = TestObject()
    d = object_to_dict(obj)
    assert d['test'] == "test"
    assert d['test2'] == "test2"

    d = object_to_dict(obj, exclude=['test'])
    assert d.get('test') is None
    assert d['test2'] == "test2"

# Generated at 2022-06-21 08:40:54.137453
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.x = 1
            self.y = 2
            self.z = 3

    foo = Foo()
    result = object_to_dict(foo, ['y'])
    assert result == {'x': 1, 'z': 3}


# Generated at 2022-06-21 08:41:29.972886
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self):
            self.one = 1
            self.two = 2
            self.three = 3
            self.four = None

        def five(self):
            return 5

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, ['five'])
    assert test_dict['one'] == 1
    assert test_dict['two'] == 2
    assert test_dict['three'] == 3
    assert 'five' not in test_dict
    assert test_dict['four'] is None

# Generated at 2022-06-21 08:41:37.648318
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10.5, 100) == 11
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('10.5%', 100, min_value=10) == 10
    assert pct_to_int('10.5%', 100, min_value=11) == 11


# Generated at 2022-06-21 08:41:49.396223
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Unit tests for deduplicate_list function. These tests are purely
        syntactic, do not ensure that the output is what is expected.
    """
    assert deduplicate_list(
        [1, 2, 3, 4, 5]
    ) == [1, 2, 3, 4, 5]

    assert deduplicate_list(
        [5, 4, 3, 2, 1]
    ) == [5, 4, 3, 2, 1]

    assert deduplicate_list(
        [1, 2, 2, 1, 2, 3]
    ) == [1, 2, 3]

    assert deduplicate_list(
        [1, 2, 2, 1, 2, 3, 4, 4, 5, 4]
    ) == [1, 2, 3, 4, 5]

#

# Generated at 2022-06-21 08:41:55.107619
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 3, 4, 5, 4, 6, 1]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 08:41:58.961304
# Unit test for function pct_to_int
def test_pct_to_int():
    result = pct_to_int(20, 100)
    assert result == 20
    result2 = pct_to_int('20', '100')
    assert result2 == 20
    result3 = pct_to_int('20%', '100')
    assert result3 == 20

# Generated at 2022-06-21 08:42:05.456910
# Unit test for function object_to_dict
def test_object_to_dict():
    class ExampleClass(object):
        """
        A test class
        """
        def __init__(self, name):
            self.name = name
            self._dont_include = True
            self.not_included = True

    obj = ExampleClass('test')
    assert object_to_dict(obj) == {'name': 'test'}
    assert object_to_dict(obj, exclude=['name']) == {}
    assert object_to_dict(obj, exclude=['_dont_include', 'not_included']) == {'name': 'test'}

# Generated at 2022-06-21 08:42:12.559767
# Unit test for function object_to_dict
def test_object_to_dict():
    class Sample(object):
        """
        Class to test object_to_dict
        """
        def __init__(self):
            self.a = '1'
            self.b = '2'

        def _protected(self):
            return 'protected'

        # this one is not a property
        def not_a_property(self):
            return 'not a property'

    sample = Sample()
    assert object_to_dict(sample) == {'a': '1', 'b': '2'}
    assert object_to_dict(sample, ['a']) == {'b': '2'}



# Generated at 2022-06-21 08:42:19.594273
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Validate if each unit test case returns the expected result
    """
    assert [] == deduplicate_list([])
    assert [1] == deduplicate_list([1])
    assert [1, 2, 3] == deduplicate_list([1, 2, 3])
    assert [1, 2, 3] == deduplicate_list([1, 2, 3, 3])
    assert [1, 2, 3] == deduplicate_list([1, 2, 3, 3, 2])


# Generated at 2022-06-21 08:42:26.408880
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 100

    assert pct_to_int(1, 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(101, 100) == 101



# Generated at 2022-06-21 08:42:32.920311
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        one = None
        two = None
        three = None
    test_obj = TestClass()
    test_obj.one = 1
    test_obj.two = 2
    test_obj.three = 3

    test_dict = object_to_dict(test_obj)
    assert test_dict['one'] == 1
    assert test_dict['two'] == 2
    assert test_dict['three'] == 3

    test_dict = object_to_dict(test_obj, exclude=['one'])
    assert 'one' not in test_dict
    assert test_dict['two'] == 2
    assert test_dict['three'] == 3

# Generated at 2022-06-21 08:43:42.291899
# Unit test for function object_to_dict
def test_object_to_dict():
    class Dummy(object):
        def __init__(self):
            self.a = "A"
            self.b = "B"
            self.c = "C"
            self.d = "D"

    dummy = Dummy()

    expect = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'}
    assert object_to_dict(dummy) == expect

    exclude = ['a', 'c']
    expect = {'b': 'B', 'd': 'D'}
    assert object_to_dict(dummy, exclude) == expect



# Generated at 2022-06-21 08:43:45.538397
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int(10, 10) == 10
    assert pct_to_int('-10%', 10) == 1



# Generated at 2022-06-21 08:43:49.654614
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(50, 100, min_value=10) == 50
    assert pct_to_int(5, 100, min_value=10) == 10
    assert pct_to_int('5%', 100, min_value=10) == 10



# Generated at 2022-06-21 08:44:00.763132
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.attribute1 = 'Value 1'
            self.attribute2 = 'Value 2'
            self.attribute3 = 'Value 3'

    instance = TestClass()
    result = object_to_dict(instance)
    assert isinstance(result, dict)
    assert len(result) == 3
    assert result['attribute1'] == 'Value 1'
    assert result['attribute2'] == 'Value 2'
    assert result['attribute3'] == 'Value 3'

    # Make sure excluded attributes are not in result
    result = object_to_dict(instance, exclude=['attribute1'])
    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'attribute1' not in result



# Generated at 2022-06-21 08:44:06.574574
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self._c = 3
            self.d_1 = 4
            self.d_2 = 5

    assert object_to_dict(test_class(), exclude=["a", "d_2"]) == {'_c': 3, 'd_1': 4, 'b': 2}


# Generated at 2022-06-21 08:44:14.569309
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test1 = "test1"
            self.test2 = "test2"
            self.test3 = "test3"

    test_class = TestClass()
    test_result = object_to_dict(test_class, ["test1"])
    assert test_result["test1"] is None
    assert test_result["test2"] == "test2"
    assert test_result["test3"] == "test3"

# Generated at 2022-06-21 08:44:23.718728
# Unit test for function pct_to_int
def test_pct_to_int():
    ans = pct_to_int("40%", 10)
    assert ans == 4
    ans = pct_to_int("30%", 10)
    assert ans == 3
    ans = pct_to_int("5%", 10)
    assert ans == 1
    ans = pct_to_int("5%", 1)
    assert ans == 1
    ans = pct_to_int(5, 10)
    assert ans == 5
    ans = pct_to_int(0, 10)
    assert ans == 0
    ans = pct_to_int(5, 0)
    assert ans == 0

# Generated at 2022-06-21 08:44:31.450086
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a test array
    test_array = [1, 2, 3, 4, 1, 2, 3, 5, 6, 6, 7]
    # Create a new var to store the new array
    test_array2 = deduplicate_list(test_array)
    # Assert that the new array is only 7 elements.
    assert len(test_array2) == 7
    # Assert that 1 is the first element
    assert test_array2[0] == 1
    # Assert that 6 is the last element
    assert test_array2[len(test_array2) - 1] == 7


# Generated at 2022-06-21 08:44:34.607586
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 4 == pct_to_int(10, 40)
    assert 2 == pct_to_int('5%', 40)
    assert 2 == pct_to_int('5%', 40, min_value=2)
    assert 3 == pct_to_int('5%', 20, min_value=2)

# Generated at 2022-06-21 08:44:40.051286
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2]) == [1, 2]
