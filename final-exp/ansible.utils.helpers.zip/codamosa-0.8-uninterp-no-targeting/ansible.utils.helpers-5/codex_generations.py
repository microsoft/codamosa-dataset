

# Generated at 2022-06-21 08:35:09.836048
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('3%', 100) == 3

# Generated at 2022-06-21 08:35:12.284801
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.exclude_me = 'foo'
            self.include_me = 'bar'
    assert object_to_dict(Test()) == {'include_me': 'bar'}

# Generated at 2022-06-21 08:35:17.791987
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 4, 5, 6]
    test_list.append(2)
    test_list.append(4)
    test_list.append(7)
    test_list.append(2)
    test_list.append(4)
    test_list.append(1)
    test_list.append(7)
    test_list.append(4)
    test_list.append(1)
    deduped_list = deduplicate_list(test_list)
    assert [1, 2, 3, 4, 5, 6, 7, 2, 4, 7, 4] == deduped_list

    test_list.clear()
    deduped_list = deduplicate_list(test_list)
    assert [] == deduped_list


# Generated at 2022-06-21 08:35:21.179188
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('15%', 100) == 15
    assert pct_to_int('15%', 100, min_value=2) == 3
    assert pct_to_int(15, 100) == 15

# Generated at 2022-06-21 08:35:25.801606
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
    test = Test('test1', 'test2')
    assert object_to_dict(test, exclude=['b']) == {'a': 'test1'}



# Generated at 2022-06-21 08:35:32.797716
# Unit test for function pct_to_int
def test_pct_to_int():
    
    assert pct_to_int(112, 112) == 112
    assert pct_to_int('112%', 112) == 112
    assert pct_to_int('100%', 112) == 112
    assert pct_to_int('50%', 112) == 56
    assert pct_to_int('50%', 112, 5) == 56
    assert pct_to_int('0%', 112) == 1
    


# Generated at 2022-06-21 08:35:39.396244
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.foo = 'foo'
    obj.bar = 'bar'
    obj.foobar = 'foobar'
    d = object_to_dict(obj)
    assert d.get('foo') == 'foo'
    assert d.get('bar') == 'bar'
    assert d.get('foobar') == 'foobar'
    d = object_to_dict(obj, exclude=['foo', 'bar'])
    assert d.get('foobar') == 'foobar'

# Generated at 2022-06-21 08:35:48.032117
# Unit test for function object_to_dict
def test_object_to_dict():
    test_class = type('TestClass', (object,), {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert object_to_dict(test_class, []) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    assert object_to_dict(test_class, ['key2']) == {'key1': 'value1', 'key3': 'value3'}
    assert object_to_dict(test_class, ['key1', 'key3']) == {'key2': 'value2'}



# Generated at 2022-06-21 08:35:49.290457
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['dog', 'cat', 'dog', 'dog', 'cat', 'frog']
    list2 = deduplicate_list(list1)
    assert list2 == ['dog', 'cat', 'frog']

# Generated at 2022-06-21 08:35:59.262532
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1,100) == 1
    assert pct_to_int(100,100) == 100
    assert pct_to_int('1',100) == 1
    assert pct_to_int('100',100) == 100

    assert pct_to_int('1%',100) == 1
    assert pct_to_int('100%',100) == 100
    assert pct_to_int('100.0%',100) == 100
    assert pct_to_int('50%',100) == 50
    assert pct_to_int('49%',100) == 49
    assert pct_to_int('48.5%',100) == 49


# Generated at 2022-06-21 08:36:10.122043
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test object_to_dict function
    """
    class TestObj(object):

        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = 3
    test_obj = TestObj(1, 'foo')
    result = object_to_dict(test_obj, exclude=['a'])
    assert result['a'] == 1
    assert result['b'] == 'foo'
    assert result['c'] == 3
    assert 'a' not in result.keys()


# Generated at 2022-06-21 08:36:16.470842
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):
        def __init__(self):
            self.x = "foo"
            self._hidden = "bar"
            self.string = "baz"
            self.lst = [1,2,3]

    obj = MyObject()
    result = object_to_dict(obj)
    assert result == {'x': "foo", 'string': "baz", 'lst': [1,2,3]}


# Generated at 2022-06-21 08:36:22.946686
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 10 == pct_to_int('10', 100)
    assert 10 == pct_to_int('10', 200)
    assert 1 == pct_to_int('10', 100, min_value=1)
    assert 10 == pct_to_int('10%', 100)
    assert 20 == pct_to_int('10%', 200)
    assert 25 == pct_to_int('10%', 200, min_value=25)


# Generated at 2022-06-21 08:36:26.098882
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.data = "data"
            self.excluded = "excluded"
    obj = TestClass()
    assert object_to_dict(obj, ["excluded"]) == {"data": "data"}



# Generated at 2022-06-21 08:36:32.018997
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['1', '2', '3', '1', '1', '4', '5', '4']
    expected_list = ['1', '2', '3', '4', '5']
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-21 08:36:40.705459
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from nose.tools import assert_equals
    d_list = deduplicate_list([1, 2, 3, 3, 1, 4, 4, 1, 5, 6, 7, 7, 8, 1, 1, 9, 10])
    assert_equals(d_list, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    l_list = deduplicate_list(['1', '2', '2', '1', '3'])
    assert_equals(l_list, ['1', '2', '3'])

# Generated at 2022-06-21 08:36:46.592036
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Test deduplicate_list function """
    for (original_list, deduplicated_list) in [
            (['vlan', 'vlan', 'vlan'], ['vlan']),
            (['interface', 'interface', 'vlan'], ['interface', 'vlan']),
            ([], [])
    ]:
        assert deduplicate_list(original_list) == deduplicated_list, "Test failed with {0}".format(original_list)


# Generated at 2022-06-21 08:36:52.425038
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_dedup = ['a', 'b', 'c', 'b', 'c']
    dedup_list = deduplicate_list(list_to_dedup)
    assert len(dedup_list) == 3
    assert dedup_list == ['a', 'b', 'c']

# Generated at 2022-06-21 08:37:00.771126
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('20%', 50) == 10
    assert pct_to_int('20%', 50, min_value=5) == 5
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.2%', 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(20, 100) == 20
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50.2, 100) == 50

# Generated at 2022-06-21 08:37:07.155810
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test for 100%
    assert pct_to_int('10%', num_items=10) == 1

    # Test for 10%
    assert pct_to_int('10%', num_items=100) == 10

    # Test for 0%
    assert pct_to_int('0%', num_items=100) == 0

    # Test for 0 and min_value=0
    assert pct_to_int('0%', num_items=100, min_value=0) == 0

    # Test for 0 and min_value=1
    assert pct_to_int('0%', num_items=100, min_value=1) == 1

    # Test for integer
    assert pct_to_int(10, num_items=100, min_value=1) == 10

    # Test for string

# Generated at 2022-06-21 08:37:15.034933
# Unit test for function pct_to_int
def test_pct_to_int():
    """
    This tests the pct_to_int function.
    """
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 50) == 25
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 50) == 25
    with pytest.raises(TypeError):
        assert pct_to_int('hello', 'world') == 25

# Generated at 2022-06-21 08:37:24.692292
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list function with a valid list of strings.
    """
    # Input list
    test_list = ["a", "b", "c", "d", "e", "f", "g", "h", "a", "b", "c", "d", "e", "f", "g", "h", "a", "b", "c", "d", "e", "f", "g", "h"]

    # Expected output list
    expected_result = ["a", "b", "c", "d", "e", "f", "g", "h"]

    # Run function to test
    result = deduplicate_list(test_list)

    assert result == expected_result

# Generated at 2022-06-21 08:37:30.666204
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int('80%', 100, 2) == 80
    assert pct_to_int('120%', 100, 2) == 100
    assert pct_to_int(90, 100) == 90
    assert pct_to_int('90', 100) == 90
    assert pct_to_int(0, 100) == 1

# Generated at 2022-06-21 08:37:37.746665
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        property1 = 1
        property2 = 2
        property3 = 3
    test = TestObject()
    test_dict = object_to_dict(test, ['property1'])
    assert test_dict.get('property1') is None
    assert test_dict.get('property2') == 2
    assert test_dict.get('property3') == 3

# Generated at 2022-06-21 08:37:46.408644
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('5%', 10000) == 500
    assert pct_to_int('5%', 1000000) == 50000

    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 1000) == 10
    assert pct_to_int('1%', 10000) == 100
    assert pct_to_int('1%', 1000000) == 10000

    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 1000) == 0
    assert pct_to_int('0%', 10000) == 0

# Generated at 2022-06-21 08:37:56.839566
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, "a", "b", "c", 2]) == [1, 2, "a", "b", "c"]
    assert deduplicate_list(["a", "b", "c", 2, 3]) == ["a", "b", "c", 2, 3]
    assert deduplicate_list([1, 1, 2, 2, 3, 3, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 2, 2, 3, 3, 4, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:38:05.157858
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test1 = None
            self.test2 = None
            self.test3 = None

        def test_method(self):
            return 'test_method'

    def test_function():
        return 'test_function'

    obj = TestClass()
    obj.test1 = 'test1'
    obj.test2 = 'test2'
    obj.test3 = 'test3'

    func = test_function
    results = object_to_dict(obj)

    # Verify function name shows up
    assert results['test_method'] == 'test_method'

    # Verify obj property shows up
    assert results['test1'] == 'test1'

    # Verify function does not show up
    assert results['test_function'] is None

    # Verify

# Generated at 2022-06-21 08:38:16.733923
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object():
        def __init__(self):
            self.foo = 'bar'
            self._bar = 'foo'
            self._baz = 'bug'

    obj = test_object()
    assert object_to_dict(obj) == dict(foo='bar')
    assert object_to_dict(obj, ['foo']) == dict(foo='bar')
    assert object_to_dict(obj, ['foo', '_bar']) == dict(foo='bar', _bar='foo')
    assert object_to_dict(obj, ['foo', '_bar', '_baz']) == dict(foo='bar', _bar='foo', _baz='bug')
    assert object_to_dict(obj, ['foo', 'bar']) == dict(foo='bar')

# Generated at 2022-06-21 08:38:18.948811
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 2]) == [1, 2, 3]

# Generated at 2022-06-21 08:38:25.566063
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
            self.d = 3
            self._hidden = 4

    # Test without exclude
    obj = DummyClass(1, 2, 3)
    expected = dict(a=1, b=2, c=3, d=3)
    ret = object_to_dict(obj)
    assert(ret == expected)

    # Test with exclude
    ret = object_to_dict(obj, ['a', '_hidden'])
    expected = dict(b=2, c=3, d=3)
    assert(ret == expected)

# Generated at 2022-06-21 08:38:36.048353
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test case where the value is a percentage
    assert(pct_to_int('10%', 100) == 10)
    assert(pct_to_int('101%', 100) == 100)

    # Test case where the value is an integer
    assert(pct_to_int(10, 100) == 10)
    assert(pct_to_int('101', 100) == 101)



# Generated at 2022-06-21 08:38:47.173641
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10%", 100, 10) == 10
    assert pct_to_int("1%", 100) == 1
    assert pct_to_int("1%", 100, 10) == 1
    assert pct_to_int("1%", 100, 1) == 1
    assert pct_to_int("1%", 100, 3) == 1
    assert pct_to_int("0%", 100) == 1
    assert pct_to_int("0%", 100, 10) == 1
    assert pct_to_int("0%", 100, 0) == 1
    assert pct_to_int("1", 100) == 1
    assert pct_to_int("1", 100, 10) == 1


# Generated at 2022-06-21 08:38:50.086174
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 1, 3, 4, 5, 4, 6]) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 08:38:53.971445
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1,1,1,2,2,2,3,3,3]
    deduplicated_list = deduplicate_list(test_list)
    assert deduplicated_list == [1,2,3]



# Generated at 2022-06-21 08:38:57.125070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 3, 2, 1, 1]
    expected_list = [1, 2, 3]
    assert deduplicate_list(original_list) == expected_list


# Generated at 2022-06-21 08:39:02.662725
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectUnderTest:
        TEST_VALUE = 'test'
        OTHER_VALUE = 'other'

    obj = ObjectUnderTest()

    # Basic operation without exclusion
    result = object_to_dict(obj)
    assert result['TEST_VALUE'] == 'test'
    assert result['OTHER_VALUE'] == 'other'
    assert len(result) == 2

    # With exclusion
    result = object_to_dict(obj, exclude=['OTHER_VALUE'])
    assert result['TEST_VALUE'] == 'test'
    assert len(result) == 1


# Generated at 2022-06-21 08:39:07.036737
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("50%", 1000) == 500
    assert pct_to_int("50%", 0) == 0
    assert pct_to_int("50", 1000) == 50

# Generated at 2022-06-21 08:39:12.046504
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list([1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,7])
    assert result == [1,2,3,4,5,6,7]


# Generated at 2022-06-21 08:39:23.424801
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]) == [1]

# Generated at 2022-06-21 08:39:28.480704
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50



# Generated at 2022-06-21 08:39:43.062708
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("101%", 100) == 100
    assert pct_to_int("0%", 100) == 1
    assert pct_to_int("-2%", 100) == 1
    assert pct_to_int("10", 100) == 10



# Generated at 2022-06-21 08:39:52.927917
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('1%', 1000) == 10
    assert pct_to_int('1%', 1000, 100) == 100
    assert pct_to_int('0%', 1000) == 10
    assert pct_to_int('0%', 1000, 100) == 100
    assert pct_to_int('100%', 1000) == 1000
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(100, 1000) == 100
    assert pct_to_int('100', 1000) == 100

# Generated at 2022-06-21 08:40:00.274563
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a","b","c"]) == ["a","b","c"]
    assert deduplicate_list(["a","b","c","a"]) == ["a","b","c"]
    assert deduplicate_list(["b","a","b","c"]) == ["b","a","c"]
    assert deduplicate_list(["b","a","b","c","a"]) == ["b","a","c"]

# Generated at 2022-06-21 08:40:07.680898
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([3, 2, 1, 2, 3, 4, 5, 6, 4]) == [3, 2, 1, 4, 5, 6]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
    assert deduplicate_list([1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1]) == [1, 2, 3]

# Generated at 2022-06-21 08:40:16.101918
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self, value1, value2):
            self.value_one = value1
            self.value_two = value2

    obj = MyClass('1', 2)
    dict_obj = object_to_dict(obj)
    assert dict_obj == {'value_one': '1', 'value_two': 2}
    dict_obj = object_to_dict(obj, ['value_one'])
    assert dict_obj == {'value_two': 2}


# Generated at 2022-06-21 08:40:21.199316
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests deduplicate_list function
    """
    result = deduplicate_list([1, 2, 1, 3, 3, 2, 4])

    assert result == [1, 2, 3, 4]
    assert result[0] == 1
    assert result[1] == 2
    assert result[2] == 3
    assert result[3] == 4



# Generated at 2022-06-21 08:40:28.437696
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        attr1 = 'attr1'
        attr2 = 'attr2'
        attr3 = 'attr3'

    assert object_to_dict(Foo()) == {'attr1': 'attr1', 'attr2': 'attr2', 'attr3': 'attr3'}
    assert object_to_dict(Foo(), exclude=['attr1', 'attr2']) == {'attr3': 'attr3'}

# Generated at 2022-06-21 08:40:38.197708
# Unit test for function pct_to_int
def test_pct_to_int():
    r = pct_to_int(10, 100)
    assert isinstance(r, int)
    assert r == 10
    r = pct_to_int('10%', 100)
    assert isinstance(r, int)
    assert r == 10
    r = pct_to_int('10%', 100, min_value=5)
    assert isinstance(r, int)
    assert r == 5
    r = pct_to_int('10%', 20)
    assert isinstance(r, int)
    assert r == 2
    r = pct_to_int('200%', 20)
    assert isinstance(r, int)
    assert r == 20


# Generated at 2022-06-21 08:40:43.666780
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        var_int = 1
        var_str = "test"
        var_none = None
    obj = TestObj()
    result = object_to_dict(obj)
    assert result == {'var_int': 1, 'var_str': 'test', 'var_none': None}
    result = object_to_dict(obj, exclude=['var_str'])
    assert result == {'var_int': 1, 'var_none': None}


# Generated at 2022-06-21 08:40:55.058932
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 200) == 1
    assert pct_to_int('5%', 200) == 5
    assert pct_to_int('10%', 200) == 10
    assert pct_to_int('25%', 200) == 50
    assert pct_to_int('50%', 200) == 100
    assert pct_to_int('100%', 200) == 200
    # Test for a fractional percent pct_to_int must return an integer
    assert pct_to_int('1.0%', 200) == 1
    # Test for value with min_value = 1
    assert pct_to_int('1%', 200) == 1
    assert pct_to_int('99%', 200) == 99
    # Test for value with min_value = 0
   

# Generated at 2022-06-21 08:41:22.505580
# Unit test for function pct_to_int
def test_pct_to_int():
    test_values = [
        (("20%", 20), 4),
        (("20%", 1), 1),
        (("20%", 0), 1),
        (("-20%", 100), 1),
        ((5, 10), 5),
        (("5", 10), 5),
        ((None, 10), 1),
        (("", 10), 1),
    ]

    for (value, num_items), expected in test_values:
        assert pct_to_int(value, num_items) == expected


# Generated at 2022-06-21 08:41:27.812795
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass():
        """ Dummy class for unit testing object_to_dict()"""
        def __init__(self):
            self.key1 = "value"
            self.key2 = "value"
            self.key3 = "value"

    dummy_class = DummyClass()
    result = object_to_dict(dummy_class, exclude=['key3'])
    assert result == {
        'key1': 'value',
        'key2': 'value'
    }



# Generated at 2022-06-21 08:41:33.018186
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int("10", 100) == 10
    assert pct_to_int("10%", 100, min_value=5) == 5

# Generated at 2022-06-21 08:41:34.389789
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("80%", 100) == 80


# Generated at 2022-06-21 08:41:38.383059
# Unit test for function object_to_dict
def test_object_to_dict():
    test_list = ['first', 'second', 'third']
    class test_obj:
        first = test_list[0]
        second = test_list[1]
        third = test_list[2]

    assert test_list == object_to_dict(test_obj).values()


# Generated at 2022-06-21 08:41:46.081959
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        test_value = 1

        def __init__(self):
            self.test_value_callable = 2

    a = test_class()
    result = object_to_dict(a)

    assert 'test_value' in result
    assert result['test_value'] == 1
    assert 'test_value_callable' in result
    assert result['test_value_callable'] == 2

# Generated at 2022-06-21 08:41:49.082710
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Test object to be used in testing object_to_dict
        """
        def __init__(self):
            self.variable = 'test'
            self._test = 'test2'

    assert {'variable': 'test'} == object_to_dict(TestClass())
    assert {'variable': 'test'} == object_to_dict(TestClass(), exclude=['_test'])

# Generated at 2022-06-21 08:41:55.777643
# Unit test for function pct_to_int
def test_pct_to_int():

    # Check percentage value
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50 %', 100) == 50

    # Check non-percentage value
    assert pct_to_int(0, 100, min_value=0) == 0
    assert pct_to_int(0, 100) == 1
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(99, 100) == 99
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('0', 100, min_value=0) == 0

# Generated at 2022-06-21 08:42:00.977044
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2]) == [1, 2]

# Generated at 2022-06-21 08:42:05.175729
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(10, 100) == 10)
    assert(pct_to_int("10%", 100) == 10)
    assert(pct_to_int("0%", 100) == 1)
    assert(pct_to_int("0%", 100, min_value=0) == 0)

# Generated at 2022-06-21 08:42:48.491983
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,1,3,3,3,4]) == [1,2,3,4]

# Generated at 2022-06-21 08:42:52.262992
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 08:43:02.358974
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['Kermit', 'The', 'Frog', 'Kermit', 'The']
    list2 = ['Miss', 'Piggy', 'Miss', 'Piggy']
    list3 = ['Gonzo', 'Gonzo', 'Miss', 'Piggy']
    list4 = ['Gonzo', 'Fozzie', 'The', 'Bear', 'Fozzie', 'The']
    assert deduplicate_list(list1) == ['Kermit', 'The', 'Frog']
    assert deduplicate_list(list2) == ['Miss', 'Piggy']
    assert deduplicate_list(list3) == ['Gonzo', 'Miss', 'Piggy']

# Generated at 2022-06-21 08:43:08.245609
# Unit test for function object_to_dict
def test_object_to_dict():
    import copy
    import unittest
    import mock

    class TestObject(object):
        def __init__(self):
            self.attr1 = "attr 1"
            self.attr2 = "attr 2"
            self.attr3 = "attr 3"
            self._private_attr = "private attr"

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.test_obj = TestObject()
            self.expected_dict = {'attr1': 'attr 1', 'attr2': 'attr 2', 'attr3': 'attr 3'}

        def test_basic(self):
            expected = copy.deepcopy(self.expected_dict)
            actual = object_to_dict(self.test_obj)
            self.assertEqual(actual, expected)


# Generated at 2022-06-21 08:43:11.092866
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('80%', 100) == 80
    assert pct_to_int(80, 100) == 80
    assert pct_to_int('80%', 100, 1) == 1

# Generated at 2022-06-21 08:43:16.166435
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('33%', 50) == 17
    assert pct_to_int('33%', 0) == 0
    assert pct_to_int('33%', 50, 2) == 2
    assert pct_to_int('1%', 50) == 1
    assert pct_to_int(33, 50) == 33
    assert pct_to_int(33, 0) == 0
    assert pct_to_int(33, 50, 2) == 2


# Generated at 2022-06-21 08:43:21.662110
# Unit test for function object_to_dict
def test_object_to_dict():

    class MockClass:
        def __init__(self):
            self.first = 1
            self.second = 2
            self.third = 3

    test_object = MockClass()
    example = object_to_dict(test_object, exclude=['third'])
    assert example['first'] == 1
    assert example['second'] == 2
    assert 'third' not in example


# Generated at 2022-06-21 08:43:30.598968
# Unit test for function object_to_dict
def test_object_to_dict():
    class testClass(object):
        def __init__(self, test, test2, test3):
            self.test = test
            self.test2 = test2
            self.test3 = test3

    test_obj = testClass('test', 'test2', 'test3')
    test_dict = object_to_dict(test_obj, exclude=['test3'])
    assert('test' in test_dict and 'test2' in test_dict and 'test3' not in test_dict)
    assert(test_dict['test'] == 'test')
    assert(test_dict['test2'] == 'test2')

# Generated at 2022-06-21 08:43:40.477510
# Unit test for function deduplicate_list

# Generated at 2022-06-21 08:43:43.373672
# Unit test for function object_to_dict
def test_object_to_dict():
    class Dummy:
        attr = 'attr'
        attr2 = 'attr2'

    obj = Dummy()
    assert object_to_dict(obj) == {'attr': 'attr', 'attr2': 'attr2'}
    assert object_to_dict(obj, exclude=['attr']) == {'attr2': 'attr2'}

