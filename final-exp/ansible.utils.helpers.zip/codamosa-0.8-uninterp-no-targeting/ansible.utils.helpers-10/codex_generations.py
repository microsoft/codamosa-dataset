

# Generated at 2022-06-21 08:35:15.503840
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self, value=None):
            self.value = value

        def __getitem__(self, key):
            return self.value

        @property
        def prop(self):
            return self.value

    class Test2(dict):
        def __init__(self, value=None):
            super(Test2, self).__init__()
            self['value'] = value

    class Test3(dict):
        def __init__(self, value=None):
            self['value'] = value

    obj = Test('value')
    assert object_to_dict(obj) == {'value': 'value'}

    obj = Test2('')
    assert object_to_dict(obj) == {'value': ''}

    obj = Test3('')
    assert object_

# Generated at 2022-06-21 08:35:26.046706
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_to_int(1, 3) == 1
    pct_to_int('1', 3) == 1
    pct_to_int('1%', 3) == 1
    pct_to_int('2%', 3) == 2
    pct_to_int('2.5%', 3) == 1
    pct_to_int(1, 3, 2) == 2
    pct_to_int('1', 3, 2) == 2
    pct_to_int('1%', 3, 2) == 2
    pct_to_int('2%', 3, 2) == 2
    pct_to_int('2.5%', 3, 2) == 2
    pct_to_int('0.5%', 3, 2) == 1

# Generated at 2022-06-21 08:35:34.369959
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
    expected_result = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4
    }
    test_object = Foo(1, 2, 3, 4)
    result = object_to_dict(test_object, exclude=['a'])
    assert expected_result == result


# Generated at 2022-06-21 08:35:42.681220
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['10.2.2.2', '10.2.2.2', '1.1.1.1', '1.1.1.1']) == ['10.2.2.2', '1.1.1.1']
    assert deduplicate_list(['10.2.2.2', '1.1.1.1', '10.2.2.2', '1.1.1.1']) == ['10.2.2.2', '1.1.1.1']
    assert deduplicate_list(['foo', 'bar', 'foo']) == ['foo', 'bar']
    assert deduplicate_list(['10', '10', 10, 10]) == ['10', 10]

# Generated at 2022-06-21 08:35:51.347506
# Unit test for function object_to_dict
def test_object_to_dict():
    class Source(object):
        def __init__(self):
            self.test_property = "value"
            self.test_list = [1, 2, 3]
            self.test_dict = {
                "test_key": "test_val",
            }
    source = Source()
    result = object_to_dict(source)
    assert result['test_property'] == 'value'
    assert result['test_list'] == [1, 2, 3]
    assert result['test_dict'] == {'test_key': 'test_val'}

# Generated at 2022-06-21 08:35:59.115096
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self,foo=1,bar=2):
            self.foo = foo
            self.bar = bar
            self.baz = 20
            self.bam = None
    obj = Foo()
    assert object_to_dict(obj) == {'bar': 2, 'foo': 1, 'baz': 20, 'bam': None}
    assert object_to_dict(obj, exclude=['bar','foo']) == {'baz': 20, 'bam': None}

# Generated at 2022-06-21 08:36:04.106316
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.baz = 'baz'
            self._test = 'test'
            self.__test2 = 'test2'

    result = object_to_dict(Test(), ['_test', '__test2'])
    assert 'foo' in result
    assert 'bar' in result
    assert 'baz' in result
    assert '_test' not in result
    assert '__test2' not in result



# Generated at 2022-06-21 08:36:13.514330
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}, {'a': 1, 'b': 3}]
    expected_output = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]
    assert deduplicate_list(original_list) == expected_output
    original_list = [1, 2, 3, 1, 3, 5]
    expected_output = [1, 2, 3, 5]
    assert deduplicate_list(original_list) == expected_output
    original_list = [1, 2, 3, 1, 3, 5, 3, 2]
    expected_output = [1, 2, 3, 5]
    assert deduplicate_list(original_list) == expected_output
    original

# Generated at 2022-06-21 08:36:18.487140
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(101, 100) == 101
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101', 100) == 101
    assert pct_to_int('101%', 50) == 51
    assert pct_to_int('101%', 10) == 11


# Generated at 2022-06-21 08:36:27.561412
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('30%', 10) == 3
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int('0.5%', 10) == 1
    assert pct_to_int('0.44%', 10) == 1
    assert pct_to_int('0.449%', 10) == 1
    assert pct_to_int('10', 10) == 10
    assert pct_to_int('10.00', 10) == 10
    assert pct_to_int('.07', 10) == 1
    assert pct_to

# Generated at 2022-06-21 08:36:34.054476
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test when value is a string
    assert pct_to_int('10%', 100) == 10
    # Test when value is an integer
    assert pct_to_int(5, 100) == 5


# Generated at 2022-06-21 08:36:40.197813
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a','b','c','b','c','a']) == ['a','b','c']
    assert deduplicate_list(['a','b','c','b','c','a','c','b','d']) == ['a','b','c','d']

# Generated at 2022-06-21 08:36:48.791994
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """Used for testing object_to_dict()"""
        def __init__(self, val1=None):
            self.val1 = val1
            self.val2 = None

    # Test empty object
    obj = TestClass()
    result = object_to_dict(obj)
    assert result['val1'] is None
    assert result['val2'] is None

    # Test populated object
    obj = TestClass('testval')
    result = object_to_dict(obj)
    assert result['val1'] == 'testval'
    assert result['val2'] is None

    # Test exclude
    obj = TestClass('testval')
    result = object_to_dict(obj, exclude=['val1'])
    assert 'val1' not in result

    # Test populate object with exclude

# Generated at 2022-06-21 08:36:54.905539
# Unit test for function pct_to_int
def test_pct_to_int():

    assert pct_to_int("10%", 10, min_value=5) == 1
    assert pct_to_int("10%", 10, min_value=10) == 1
    assert pct_to_int("10%", 10, min_value=11) == 2



# Generated at 2022-06-21 08:37:00.604089
# Unit test for function object_to_dict
def test_object_to_dict():
    test_obj = type('test_object', (object,), {'a_1': 1, 'b_2': 2})()

    result = object_to_dict(test_obj)
    assert sorted(result) == ['a_1', 'b_2']

    result = object_to_dict(test_obj, exclude=['a_1'])
    assert sorted(result) == ['b_2']


# Generated at 2022-06-21 08:37:11.762152
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for the deduplicate_list function.
    """

    # Tests to make sure that the list was deduplicated
    words = ["I", "am", "a", "sentence", "I", "am"]
    dedup = deduplicate_list(words)
    assert len(dedup) == 4

    # Tests to make sure the order of items is retained
    words = ["I", "am", "a", "sentence", "I", "am"]
    dedup = deduplicate_list(words)
    assert dedup == ["I", "am", "a", "sentence"]

    # Tests to make sure that empty lists return an empty list
    words = []
    dedup = deduplicate_list(words)
    assert len(dedup) == 0

    # Tests to make

# Generated at 2022-06-21 08:37:15.466757
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj_test():
        def __init__(self):
            self.test1 = 1
            self.test2 = 2

    test_obj = obj_test()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test1'] == 1 and test_dict['test2'] == 2

# Generated at 2022-06-21 08:37:22.651950
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj():
        def __init__(self):
            self.attr_0 = 'attr_0'
            self.attr_1 = 'attr_1'

    test_obj = TestObj()
    assert object_to_dict(test_obj, exclude=['attr_0']) == {'attr_1': 'attr_1'}
    assert object_to_dict(test_obj) == {'attr_0': 'attr_0', 'attr_1': 'attr_1'}



# Generated at 2022-06-21 08:37:28.866001
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.name = 'sam'
            self.age = 34
            self.weight = '175lbs'
    test_object = TestClass()
    results = object_to_dict(test_object)
    assert 'name' in results and results['name'] == 'sam'
    assert 'age' in results and results['age'] == 34
    assert 'weight' in results and results['weight'] == '175lbs'

# Generated at 2022-06-21 08:37:34.272005
# Unit test for function object_to_dict
def test_object_to_dict():
    class FakeMod:
        """
        The class instance should be converted to a dict
        """
        def __init__(self):
            self.attr1 = 'attr1'
            self.attr2 = 'attr2'

    mod = FakeMod()
    assert object_to_dict(mod) == {'attr1': 'attr1', 'attr2': 'attr2'}



# Generated at 2022-06-21 08:37:42.633991
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, 2) == 10
    assert pct_to_int('10%', 100, 20) == 20



# Generated at 2022-06-21 08:37:46.938309
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('10%', 5) == 1



# Generated at 2022-06-21 08:37:54.390801
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():

        def __init__(self):
            self.z = 5
            self.y = 7

    result = object_to_dict(TestClass(), ['x'])
    assert not result.has_key('x')
    assert result.has_key('y')
    assert result.has_key('z')
    assert result.get('y') == 7
    assert result.get('z') == 5

# Generated at 2022-06-21 08:38:02.022956
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int('1%', 100)
    assert 1 == pct_to_int('0%', 100)
    assert 1 == pct_to_int('0%', 100, 1)
    assert 1 == pct_to_int('0.1%', 100)
    assert 1 == pct_to_int(0, 100)
    assert 5 == pct_to_int(100, 100)
    assert 5 == pct_to_int(100.0, 100.0)
    assert 1 == pct_to_int('1', 100)


# Generated at 2022-06-21 08:38:08.025100
# Unit test for function object_to_dict
def test_object_to_dict():
    expected_result = {'name': 'test', 'age': 30}
    class test(object):
        def __init__(self):
            self.name = 'test'
            self.age = 30
    assert object_to_dict(test()) == expected_result



# Generated at 2022-06-21 08:38:18.268262
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestObject(object):
        """
        Dummy class to create an object for testing
        """
        def __init__(self):
            self.attr1 = "attr1"
            self.attr2 = "attr2"
            self.attr3 = "attr3"

    test_object = TestObject()
    result = object_to_dict(test_object)
    assert result == {
        'attr1': 'attr1',
        'attr2': 'attr2',
        'attr3': 'attr3'
    }

    result = object_to_dict(test_object, exclude=['attr3'])
    assert result == {
        'attr1': 'attr1',
        'attr2': 'attr2'
    }

# Generated at 2022-06-21 08:38:26.643001
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, 2) == 2

# Unit tests for function object_to_dict

# Generated at 2022-06-21 08:38:35.016448
# Unit test for function pct_to_int
def test_pct_to_int():
    values = (
        ('10%', 10),
        ('10', 10),
        (10, 10),
        ('10.0%', 10),
        ('10.123%', 10),
        ('1', 1),
        ('1%', 1),
        ('0%', 1),
        ('0.9%', 1),
        ('0.1%', 1),
        ('0.0001%', 1),
    )
    for value, expected_value in values:
        assert pct_to_int(value, 100) == expected_value


# Generated at 2022-06-21 08:38:38.857601
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a_list = [1, 1, 1, 5, 3, 2, 3, 5, '1', '2', '2', '1']
    print(a_list)
    print(deduplicate_list(a_list))



# Generated at 2022-06-21 08:38:49.800668
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items=10
    assert pct_to_int(80, num_items) == 8
    assert pct_to_int(80.0, num_items) == 8
    assert pct_to_int(4, num_items) == 4
    assert pct_to_int(4.0, num_items) == 4
    assert pct_to_int(4.5, num_items) == 5
    assert pct_to_int('80%', num_items) == 8
    assert pct_to_int('80.0%', num_items) == 8
    assert pct_to_int('0.5%', num_items) == 1
    assert pct_to_int('80%', num_items, 3) == 3


# Generated at 2022-06-21 08:38:59.758967
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", num_items=100, min_value=1) == 50

# Generated at 2022-06-21 08:39:11.288535
# Unit test for function pct_to_int
def test_pct_to_int():
    assert (pct_to_int(25, 100) == 25)
    assert (pct_to_int('25%', 100) == 25)
    assert (pct_to_int('50', 100) == 50)
    assert (pct_to_int(50, 100) == 50)
    assert (pct_to_int('100%', 100) == 100)
    assert (pct_to_int(100, 100) == 100)
    assert (pct_to_int('100%', 8) == 8)
    assert (pct_to_int(100, 8) == 8)
    assert (pct_to_int('75%', 1) == 1)
    assert (pct_to_int(75, 1) == 1)

# Generated at 2022-06-21 08:39:22.628275
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('10.1%', 100) == 10
    assert pct_to_int('10.9%', 100) == 11
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, min_value=5) == 50
    assert p

# Generated at 2022-06-21 08:39:24.797893
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-21 08:39:31.707265
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'a'
            self._b = 'b'
            self.c = 'c'
    test_obj = Test()
    test_dict = object_to_dict(test_obj, exclude=['_b'])
    assert 'a' in test_dict
    assert '_b' not in test_dict
    assert 'c' in test_dict

# Generated at 2022-06-21 08:39:36.898306
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestDeduplicateList(unittest.TestCase):
        def test_deduplicate_list(self):
            original_list = [1, 1, 2, 3, 1, 4]
            deduplicated_list = deduplicate_list(original_list)
            assert deduplicated_list == [1, 2, 3, 4]
    unittest.main(argv=['ignored', '-v'], exit=False)

# Generated at 2022-06-21 08:39:40.557744
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [1, 2, 3] == deduplicate_list([1, 2, 3])
    assert [1, 2, 3] == deduplicate_list([1, 2, 3, 2, 1, 3])

# Generated at 2022-06-21 08:39:47.581636
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'b']) == ['a', 'b']

# Generated at 2022-06-21 08:39:56.894253
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1000, 1000, min_value=1) == 1000
    assert pct_to_int('50%', 1000, min_value=1) == 500
    assert pct_to_int(50, 1000, min_value=1) == 50
    assert pct_to_int('50', 1000, min_value=1) == 50
    assert pct_to_int('50.5', 1000, min_value=1) == 50
    assert pct_to_int('.5', 1000, min_value=1) == 5
    assert pct_to_int('.5%', 1000, min_value=1) == 5
    assert pct_to_int('0.5', 1000, min_value=1) == 1

# Generated at 2022-06-21 08:40:06.943083
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test deduplicate list function
    """
    import datetime
    import copy
    original_list = []
    original_list.append(1)
    original_list.append(2)
    original_list.append(3)
    original_list.append(4)
    original_list.append(5)
    original_list.append(5)
    original_list.append(5)
    original_list.append(4)
    original_list.append(4)
    original_list.append(1)
    original_list.append(1)
    original_list.append(2)
    original_list.append(3)
    original_list.append(1)
    original_list.append(2)
    original_list.append(3)

# Generated at 2022-06-21 08:40:29.919336
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("20%", 10) == 2
    assert pct_to_int("90%", 20) == 18
    assert pct_to_int("0%", 20) == 1
    assert pct_to_int("-5%", 20) == 1
    assert pct_to_int("105%", 20) == 21
    assert pct_to_int("0", 10) == 0
    assert pct_to_int("5", 10) == 5
    assert pct_to_int("-5", 10) == -5

# Generated at 2022-06-21 08:40:37.201947
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        attr1 = 1
        attr2 = 2
        attr3 = 3
        attr4 = 4
    foo = Foo()
    assert object_to_dict(foo) == {'attr1': 1, 'attr2': 2, 'attr3': 3, 'attr4': 4}
    assert object_to_dict(foo, exclude=['attr3', 'attr4']) == {'attr1': 1, 'attr2': 2}

# Generated at 2022-06-21 08:40:42.228626
# Unit test for function pct_to_int
def test_pct_to_int():
    items = range(100)
    answers = {
        0: 1,
        25: 25,
        50: 50,
        '50%': 50,
        '15%': 15,
        '0%': 1,
        '101%': 101
    }
    for quantity, answer in answers.iteritems():
        assert answer == pct_to_int(quantity, len(items))

# Generated at 2022-06-21 08:40:51.241433
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 1, 5, 6, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 1, 5, 6, 6]) != [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 1, 5, 6, 6]) != [1, 2, 3, 4, 5, 6, 7]


# Generated at 2022-06-21 08:40:54.181815
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests arguments for a list
    """
    test_list = ['a', 'b', 'c', 'c', 'b', 'b', 'a', 'a', 'a']
    result = deduplicate_list(test_list)
    assert result == ['a', 'b', 'c', 'b', 'a']

# Generated at 2022-06-21 08:40:57.877076
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(0, 100, 1) == 1

# Generated at 2022-06-21 08:41:04.612809
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        a = None
        b = None

    t1 = TestClass()
    t1.a = "Hello"
    t1.b = "World"
    d1 = object_to_dict(t1)
    assert isinstance(d1, dict)
    assert len(d1) == 2
    assert d1['a'] == "Hello"
    assert d1['b'] == "World"

    t2 = TestClass()
    t2.a = "Goodbye"
    t2.b = "Cruel World"
    d2 = object_to_dict(t2, ['b'])
    assert isinstance(d2, dict)
    assert len(d2) == 1
    assert d2['a'] == "Goodbye"

# Generated at 2022-06-21 08:41:08.790133
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(['a', 'b']) == {'0': 'a', '1': 'b'}
    assert object_to_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert object_to_dict({'a': 1, 'b': 2}, exclude=['b']) == {'a': 1}

# Generated at 2022-06-21 08:41:21.008997
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['1', '2', '1', '4', '4', '4', '4', '4', '4']
    expected_list = ['1', '2', '4']
    assert deduplicate_list(test_list) == expected_list
    test_list = ['1', '2', '3']
    expected_list = ['1', '2', '3']
    assert deduplicate_list(test_list) == expected_list
    test_list = ['1', '1', '1', '1', '1', '1', '1', '1']
    expected_list = ['1']
    assert deduplicate_list(test_list) == expected_list
    test_list = []
    expected_list = []

# Generated at 2022-06-21 08:41:28.917806
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        def __init__(self):
            self.test_int = 1
            self.test_bool = True
            self.test_dict = {'test': True}
            self.test_str = 'hello'
            self.test_list = ['1', '2', '3']
            self._test_exclude = 'hello'
            self.test_exclude_list = 'hello'

        @property
        def test_property(self):
            return 'hello'

    obj = test_class()
    exclude = ['test_exclude_list']

# Generated at 2022-06-21 08:41:49.356157
# Unit test for function pct_to_int
def test_pct_to_int():
    """pct_to_int: Tests the pct_to_int function returns the expected values."""

    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 250) == 25
    assert pct_to_int('10%', 0) == 0
    assert pct_to_int('10%', 2) == 1

    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 250) == 10
    assert pct_to_int(10, 0) == 10
    assert pct_to_int(10, 2) == 10



# Generated at 2022-06-21 08:41:55.315318
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 10) == 5
    assert pct_to_int(50, 10) == 50
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("0%", 10, 1) == 1
    assert pct_to_int("0%", 10, 2) == 2
    assert pct_to_int("0.2%", 10) == 1
    assert pct_to_int("0.2%", 10, 1) == 1
    assert pct_to_int("0.2%", 10, 2) == 2


# Generated at 2022-06-21 08:42:00.937950
# Unit test for function pct_to_int
def test_pct_to_int():
    test_dict = [
        ("1", 5, 1),
        ("0%", 5, 1),
        ("100%", 5, 5),
        ("50%", 5, 3),
        ("33%", 5, 2)
    ]

    for test in test_dict:
        result = pct_to_int(test[0], test[1], test[2])
        assert result == test[2]

# Generated at 2022-06-21 08:42:06.134079
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Simple unit test for object_to_dict
    """
    class TestClass:
        def __init__(self):
            self.test = "test"
            self.hidden = "hidden"
    import unittest

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['hidden'])
    unittest.TestCase().assertEqual(test_dict['test'], 'test')
    unittest.TestCase().assertFalse('hidden' in test_dict)

# Generated at 2022-06-21 08:42:09.874348
# Unit test for function pct_to_int
def test_pct_to_int():
    required_pct = 10
    items_total = 100
    assert pct_to_int(required_pct, items_total) == 10
    assert pct_to_int("{0}%".format(required_pct), items_total) == 10


# Generated at 2022-06-21 08:42:19.285597
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test1 = "test1"
            self._test2 = "test2"
            self.test3 = "test3"

    test_class = TestClass()

    assert object_to_dict(test_class) == {'test1': 'test1', 'test3': 'test3'}
    assert object_to_dict(test_class, exclude=["test1"]) == {'test3': 'test3'}
    assert object_to_dict(test_class, exclude=["test1", "test3"]) == {}


# Unit tests for function deduplicate_list

# Generated at 2022-06-21 08:42:25.904050
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        Par1 = 'Param1'
        Par2 = 'Param2'
        Par3 = 'Param3'
    test_object = TestClass()
    result = object_to_dict(test_object, ['Par1'])
    assert result == {'Par2': 'Param2', 'Par3': 'Param3'}
    result = object_to_dict(test_object)
    assert result == {'Par1': 'Param1', 'Par2': 'Param2', 'Par3': 'Param3'}

# Generated at 2022-06-21 08:42:28.461730
# Unit test for function object_to_dict
def test_object_to_dict():
    class Dummy(object):
        foo = 'bar'
        bar = 'foo'

    assert object_to_dict(Dummy()) == {'bar': 'foo', 'foo': 'bar'}
    assert object_to_dict(Dummy(), ['bar']) == {'foo': 'bar'}

# Generated at 2022-06-21 08:42:32.593852
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a","b","c","a","a","d","f"]) == ["a","b","c","d","f"]
    assert deduplicate_list(["a","b","c","d"]) == ["a","b","c","d"]
    assert deduplicate_list(["a","a","a","a"]) == ["a"]
    assert deduplicate_list([]) == []



# Generated at 2022-06-21 08:42:39.124336
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 08:43:02.358214
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert ['foo', 'bar', 'baz'] == deduplicate_list(['foo', 'bar', 'bar', 'baz', 'foo'])



# Generated at 2022-06-21 08:43:11.998138
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Unit test for function pct_to_int()
    '''

    assert type(pct_to_int('50%', 100)) == int
    assert pct_to_int('50%', 100) == 50

    assert type(pct_to_int('75%', 100)) == int
    assert pct_to_int('75%', 100) == 75

    assert type(pct_to_int('100%', 100)) == int
    assert pct_to_int('100%', 100) == 100

    assert type(pct_to_int('0%', 100)) == int
    assert pct_to_int('0%', 100) == 0

    assert type(pct_to_int(97, 100)) == int
    assert pct_to_int(97, 100) == 97



# Generated at 2022-06-21 08:43:16.985528
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a sample list with duplicate entries
    original_list = [1, 2, 3, 1, 2, 5, 6, 1, 7, 5, 8, 9, 6, 1, 10, 10, 3, 5, 8]

    # Create a deduplicated list
    dedup_list = deduplicate_list(original_list)

    # Check if the expected list is the same as the deduplicated list
    assert dedup_list == [1, 2, 3, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-21 08:43:24.935150
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj(object):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.baz = 'baz'

    obj = test_obj()
    obj_dict = object_to_dict(obj)
    assert obj_dict == {'bar': 'bar', 'foo': 'foo', 'baz': 'baz'}
    assert object_to_dict(obj, exclude=['baz']) == {'bar': 'bar', 'foo': 'foo'}

# Generated at 2022-06-21 08:43:35.611561
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests the function object_to_dict
    """
    class MyObject(object):
        """
        Test object for object_to_dict
        """

        def __init__(self):
            """ Constructor """
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.p = "test password"
    testobject = MyObject()

    testdict = object_to_dict(testobject)
    assert isinstance(testdict, dict)
    assert len(testdict) == 5
    assert 'a' in testdict
    assert 'b' in testdict
    assert 'c' in testdict
    assert 'd' in testdict
    assert 'p' not in testdict


# Generated at 2022-06-21 08:43:43.186945
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create an object to test
    class TestClass:
        pass

    tc = TestClass()
    tc.apple = 1
    tc.banana = 2
    tc.cat = 3
    tc.dog = 4
    tc.elephant = 5

    # Ensure we don't include excluded items
    assert(object_to_dict(tc, exclude=["banana", "cat"]) == {"apple": 1, "dog": 4, "elephant": 5})

    # Ensure we get all items if no exclude list
    assert(object_to_dict(tc) == {"apple": 1, "banana": 2, "cat": 3, "dog": 4, "elephant": 5})

    # Ensure we don't include private attributes
    tc._apple = 1
    tc._banana = 2
    tc._cat = 3

# Generated at 2022-06-21 08:43:49.136066
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_cases = [
        ([], []),
        ([1], [1]),
        ([1, 2], [1, 2]),
        ([1, 2, 1], [1, 2]),
        ([1, 2, 2], [1, 2]),
        ([1, 2, 1, 2], [1, 2]),
        ([2, 1, 1, 2], [2, 1]),
        ([2, 1, 2, 1], [2, 1]),
    ]

    for original_list, expected_list in test_cases:
        assert expected_list == deduplicate_list(original_list)

# Generated at 2022-06-21 08:43:59.579002
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        """
        Test object used in testing object_to_dict
        """
        test1 = "test1"
        test2 = "test2"
        test3 = "test3"

        def __init__(self):
            self.test4 = "test4"
            self.test5 = "test5"

    test_obj = Test()
    test_dict = object_to_dict(obj=test_obj, exclude=['test1', 'test3'])
    assert test_dict['test5'] == 'test5'
    assert 'test1' not in test_dict
    assert 'test3' not in test_dict
    assert 'test4' not in test_dict
    assert test_dict['test2'] == 'test2'

# Generated at 2022-06-21 08:44:08.681941
# Unit test for function pct_to_int
def test_pct_to_int():
    """ Tests for pct_to_int function """
    num_items = 10
    percentage_values = ['10%', '30%', '50%']
    integer_values = [1, 5, 9]
    mixed_values = ['10%', 5, '30%']

    # Test that the pct_to_int function works with a float
    assert pct_to_int(10, num_items) == 10

    # Test that the pct_to_int function works with a number
    assert pct_to_int('10%', num_items) == 1

    # Test that the pct_to_int function works with a percentage
    for v in percentage_values:
        assert pct_to_int(v, num_items) == int(10 * float(v.replace('%', '')) / 100)

   

# Generated at 2022-06-21 08:44:19.650275
# Unit test for function object_to_dict
def test_object_to_dict():
    class myobj(object):
        # Attributes that start with _ are private and should be excluded
        def __init__(self, name, value):
            self._name = name
            self.value = value

        def get_name(self):
            return self._name


    obj = myobj("name", "value")
    returned_dict = object_to_dict(obj, None)
    assert returned_dict["_name"] == obj._name
    assert returned_dict["value"] == obj.value
    assert "_name" in returned_dict

    returned_dict = object_to_dict(obj, ["_name"])
    assert not "_name" in returned_dict
    assert returned_dict["value"] == obj.value



# Generated at 2022-06-21 08:45:07.102488
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests object_to_dict function
    """
    class TestObj(object):
        def __init__(self):
            self.foo = 'bar'
            self.test = 123
            self._bar = 'test'

    test_obj = TestObj()
    expected = {'foo': 'bar', 'test': 123}
    assert object_to_dict(test_obj) == expected

