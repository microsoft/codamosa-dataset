

# Generated at 2022-06-21 08:35:20.465088
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj:
        key1 = 'value1'
        key2 = 'value2'
        _excluded = 'exclude'

    obj = test_obj()
    assert object_to_dict(obj) == {'key1': 'value1', 'key2': 'value2'}
    assert object_to_dict(obj, exclude=['key1']) == {'key2': 'value2'}
    assert object_to_dict(obj, exclude=['key2']) == {'key1': 'value1'}
    assert object_to_dict(obj, exclude=['key1', 'key2']) == {}
    assert object_to_dict(obj, exclude=['key1', 'key2', '_excluded']) == {}
    assert object_to_dict(None) == {}

# Generated at 2022-06-21 08:35:29.456262
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_var = 'test'
            self.var_two = 'variable two'
    obj = TestClass()
    result = object_to_dict(obj)
    assert set(result.keys()) == set(dir(obj))
    assert result['test_var'] == 'test'
    assert result['var_two'] == 'variable two'
    result = object_to_dict(obj, ['test_var'])
    assert set(result.keys()) == set(dir(obj)) - set(['test_var'])

# Generated at 2022-06-21 08:35:32.729989
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyModule(object):
        class DummySubModule(object):
            a = 'test'

        a = 'test'
        b = 'test'
        c = DummySubModule

    expected_dict = {
        'a': 'test',
        'b': 'test',
        'c': {
            'a': 'test'
        }
    }

    actual_dict = object_to_dict(DummyModule)

    assert expected_dict == actual_dict

# Generated at 2022-06-21 08:35:35.902520
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 1000) == 200
    assert pct_to_int('0%', 1000) == 1
    assert pct_to_int(20, 1000) == 20


# Generated at 2022-06-21 08:35:39.832279
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        test_attr = None
        test_attr2 = 'bar'

    test_obj = TestClass()
    test_obj.test_attr = 'foo'
    assert object_to_dict(test_obj) == {'test_attr': 'foo', 'test_attr2': 'bar'}

# Generated at 2022-06-21 08:35:43.361952
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 11) == 1
    assert pct_to_int('10%', 19) == 2
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('60%', 5) == 3
    assert pct_to_int('22%', 3) == 1

# Generated at 2022-06-21 08:35:55.366598
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self._c = 'c'
            self._d = 'd'

    test = TestObject()
    assert object_to_dict(test) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(test, exclude=['c', 'd']) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(test, exclude=['a', 'b']) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(test, exclude=['a', '_c']) == {'a': 'a', 'b': 'b'}

# Generated at 2022-06-21 08:36:03.280260
# Unit test for function object_to_dict
def test_object_to_dict():

    class Foo(object):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
    f = Foo()
    assert object_to_dict(f) == {'bar': 'bar', 'foo': 'foo'}
    assert object_to_dict(f, ['bar']) == {'foo': 'foo'}
    assert object_to_dict(f, ['foo']) == {'bar': 'bar'}
    assert object_to_dict(f, []) == {'bar': 'bar', 'foo': 'foo'}
    assert object_to_dict(f, None) == {'bar': 'bar', 'foo': 'foo'}


# Generated at 2022-06-21 08:36:10.831612
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests object_to_dict function

    Returns
    """
    class Object:
        def __init__(self):
            self.a = "A"
            self.b = "B"
            self.c = "C"
    obj = Object()
    assert object_to_dict(obj) == {'a': 'A', 'b': 'B', 'c': 'C'}
    assert object_to_dict(obj, exclude=['a', 'b']) == {'c': 'C'}

# Generated at 2022-06-21 08:36:14.991911
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('0', 100) == 0
    assert pct_to_int('100%', 100) == 1

# Generated at 2022-06-21 08:36:20.414486
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 2, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:36:23.602762
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'a', 'd', 'd', 'b']
    assert deduplicate_list(test_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 08:36:30.281355
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100, min_value=1) == 50
    assert pct_to_int("100%", 100, min_value=1) == 100
    assert pct_to_int("1%", 100, min_value=1) == 1
    assert pct_to_int("1%", 5, min_value=1) == 1
    assert pct_to_int("0.1%", 5, min_value=1) == 1
    assert pct_to_int("0.5%", 100, min_value=1) == 1
    assert pct_to_int("0.51%", 100, min_value=1) == 1
    assert pct_to_int("25", 100, min_value=1) == 25

# Generated at 2022-06-21 08:36:37.312284
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 50) is 5
    assert pct_to_int('1%', 50) is 1
    assert pct_to_int('100%', 50) is 50
    assert pct_to_int('1000%', 50) is 50
    assert pct_to_int(50, 100) is 50
    assert pct_to_int(0, 100) is 1
    assert pct_to_int(-10, 100) is 1

# Generated at 2022-06-21 08:36:41.081705
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'a', 'b']) == ['a', 'b', 'a']
    assert deduplicate_list([]) == []

# Generated at 2022-06-21 08:36:43.321703
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,2,1,3,4]) == [1,2,3,4]


# Generated at 2022-06-21 08:36:49.916815
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.property1 = 'one'
            self.property2 = 'two'
            self.property3 = 'three'
            self.property4 = 'four'

    test_object = TestObject()
    obj_dict = object_to_dict(test_object)
    assert len(obj_dict.keys()) == 4

    obj_dict = object_to_dict(test_object, ['property1', 'property2'])
    assert len(obj_dict.keys()) == 2
    assert 'property1' not in obj_dict.keys()
    assert 'property2' not in obj_dict.keys()
    assert 'property3' in obj_dict.keys()
    assert 'property4' in obj_dict.keys()

# Generated at 2022-06-21 08:36:58.557402
# Unit test for function object_to_dict
def test_object_to_dict():
    """ Unit test for function object_to_dict """
    class TestClass(object):
        """
        Test Class definition
        """
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'foo'
            self.baz = 'baz'
            # noinspection PyPep8Naming
            self._internal = 'internal'

    obj = TestClass()

# Generated at 2022-06-21 08:37:03.452495
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test_1 = 10
            self.test_2 = 20
            self.test_3 = 30
    test = TestObject()
    test_exclude = ['test_1']
    expected_dict = {'test_2': 20, 'test_3': 30}
    assert object_to_dict(test, exclude=test_exclude) == expected_dict


# Generated at 2022-06-21 08:37:07.816407
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'test'

    result = object_to_dict(Test())
    assert 'a' in result and result['a'] == 'test'



# Generated at 2022-06-21 08:37:16.806632
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Easily test the deduplicate_list function by calling test_deduplicate_list.
    """
    assert deduplicate_list([1,2,3,2,1,2,1]) == [1,2,3]

# Generated at 2022-06-21 08:37:27.092988
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test case 1:
    # Original list: [1, 2, 3, 2, 1, 2]
    # Expected result: [1, 2, 3]
    test_list = [1, 2, 3, 2, 1, 2]
    result = deduplicate_list(test_list)
    assert result == [1, 2, 3]

    # Test case 2:
    # Original list: [1, 2, 3, 3, 1]
    # Expected result: [1, 2, 3]
    test_list = [1, 2, 3, 3, 1]
    result = deduplicate_list(test_list)
    assert result == [1, 2, 3]

    # Test case 3:
    # Original list: [1, 2, 3]
    # Expected result: [1, 2,

# Generated at 2022-06-21 08:37:36.439786
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(45, 10) == 4
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(45, 5) == 2
    assert pct_to_int(5, 5) == 1
    assert pct_to_int(5, 5, min_value=0) == 0
    assert pct_to_int(100, 10) == 10
    assert pct_to_int(100, 10, min_value=0) == 10
    assert pct_to_int(100, 10, min_value=0) == 10
    assert pct_to_int('45%', 10) == 4
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('45%', 5) == 2

# Generated at 2022-06-21 08:37:45.634704
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", num_items=4) == 2
    assert pct_to_int("50%", num_items=5) == 3
    assert pct_to_int("50%", num_items=6) == 3
    assert pct_to_int("50%", num_items=7) == 4
    assert pct_to_int("50%", num_items=8) == 4
    assert pct_to_int("50%", num_items=9) == 5
    assert pct_to_int("50%", num_items=10) == 5
    assert pct_to_int("50%", num_items=11) == 6
    assert pct_to_int("50%", num_items=12) == 6

# Generated at 2022-06-21 08:37:53.198366
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestModule(object):
        def __init__(self):
            self.arg1 = 'arg1'
            self.arg2 = 'arg2'

    test_module = TestModule()
    assert object_to_dict(test_module) == {'arg1': 'arg1', 'arg2': 'arg2'}
    assert object_to_dict(test_module, exclude=['arg1']) == {'arg2': 'arg2'}

# Generated at 2022-06-21 08:37:58.709712
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['dog', 'cat', 'fish', 'dog','cat','horse','dragon','dog','fish','goldfish','crocodile','monkey','fish','lion']
    expected_deduplicated_list = ['dog', 'cat', 'fish', 'horse','dragon','goldfish','crocodile','monkey','lion']
    assert deduplicate_list(original_list) == expected_deduplicated_list

# Generated at 2022-06-21 08:38:02.619328
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.property1 = 'foo'
            self.property2 = 'bar'
    obj = TestClass()
    result = object_to_dict(obj)
    assert 'property1' in result
    assert 'property2' in result
    assert result['property1'] == 'foo'
    assert result['property2'] == 'bar'

# Generated at 2022-06-21 08:38:11.158437
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.a = 'hi'
            self.b = 'bye'
            self.c = 'foo'
    expected_dict = dict(a='hi', b='bye', c='foo')
    assert object_to_dict(Foo()) == expected_dict, "Dict not returned"
    assert object_to_dict(Foo(), exclude=['a']) == dict(b='bye', c='foo'), "Failed to exclude items"



# Generated at 2022-06-21 08:38:19.947461
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # We create a list with duplicated entries
    test_list = ['apple', 'banana', 'peach', 'banana', 'apple', 'cherry', 'cherry', 'peach']
    # We create the source list with each element in a different order
    source_list = ['cherry', 'cherry', 'peach', 'apple', 'apple', 'banana', 'banana', 'peach']
    # We check that we have the correct list after removing duplicates
    assert deduplicate_list(test_list) == source_list

# ======= RANGE EXTENSIBILITY =======
# RangeModule class and unit tests

# Generated at 2022-06-21 08:38:22.947382
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'foo']
    expected = ['foo', 'bar']
    assert deduplicate_list(original_list) == expected



# Generated at 2022-06-21 08:38:42.557597
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.val1 = 1
            self.val2 = 2

    obj = TestObj()

    obj_dict = object_to_dict(obj)
    assert isinstance(obj_dict, dict)

    assert obj_dict['val1'] == 1
    assert obj_dict['val2'] == 2

    obj_dict_exclude = object_to_dict(obj, ['val1'])
    assert isinstance(obj_dict_exclude, dict)

    assert obj_dict_exclude['val1'] == '** OPTS_EXCLUDE **'
    assert obj_dict_exclude['val2'] == 2


# Generated at 2022-06-21 08:38:47.126819
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("10", 10) == 10
    assert pct_to_int("10%", 10, min_value=10) == 10
    assert pct_to_int("10%", 10, min_value=5) == 1

# Generated at 2022-06-21 08:38:55.238112
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.test_foo = "foo"
            self.test_bar = "bar"
            self.test_baz = "baz"
    obj = TestObj()
    result_dict = {'test_baz': 'baz', 'test_bar': 'bar', 'test_foo': 'foo'}
    assert object_to_dict(obj) == result_dict
    assert object_to_dict(obj, exclude=['test_baz']) == {'test_bar': 'bar', 'test_foo': 'foo'}

# Generated at 2022-06-21 08:38:58.111115
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 3, 4, 3, 1, 2, 5]
    assert deduplicate_list(test_list) == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 08:39:10.027503
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list function
    """
    original_list = [4, 'foo', 3, 3, 2, 1, 2, 'foo']

    # Test list with mixed data types
    new_list = deduplicate_list(original_list)
    assert new_list == [4, 'foo', 3, 2, 1]

    # Test list with unicode data
    original_list = [u'foo', u'foo', u'bar']
    new_list = deduplicate_list(original_list)
    assert new_list == [u'foo', u'bar']

    # Test list with int data
    original_list = [1, 1, 2, 3, 3, 4]
    new_list = deduplicate_list(original_list)

# Generated at 2022-06-21 08:39:12.191279
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 3, 4, 4, 1, 2]) == [2, 3, 4, 1]

# Generated at 2022-06-21 08:39:23.649122
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1,2,3,3,2,1]) == [1,2,3]
    assert deduplicate_list(['a','b','c','c','b','a']) == ['a','b','c']
    assert deduplicate_list([{'a':1},{'b':1},{'c':1},{'c':1},{'b':1},{'a':1}]) == [{'a':1},{'b':1},{'c':1}]

# Generated at 2022-06-21 08:39:34.384573
# Unit test for function object_to_dict
def test_object_to_dict():

    class EmptyClass(object):
        pass

    class TestClass(object):
        def __init__(self, value):
            self.value = value
            self.value_duplicate = value
        def _private_method(self):
            pass
        def public_method(self):
            pass

    def test_function():
        return
    empty_obj = EmptyClass()
    test_obj = TestClass(value='some text')

    empty_dict = {'test_function':test_function}
    test_dict = {'value':'some text','value_duplicate':'some text','public_method':test_obj.public_method}

    assert object_to_dict(empty_obj) == empty_dict
    assert object_to_dict(test_obj) == test_dict

# Generated at 2022-06-21 08:39:46.130665
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3, 4, 5, 3, 1, 2, 3, 4, 5, 6, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 'a', 'b', 'c']) == [1, 'a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'b', 'c', 'd', 'd', 'e', 'f', 'f', 'g', 'g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']

# Generated at 2022-06-21 08:39:50.892435
# Unit test for function object_to_dict
def test_object_to_dict():
    class testobject:
        test1 = 'test1'
        test2 = 'test2'
        _test3 = 'test3'

    assert object_to_dict(testobject) == {'test1': 'test1', 'test2': 'test2'}
    assert object_to_dict(testobject, exclude=['test2', 'test3']) == {'test1': 'test1'}

# Generated at 2022-06-21 08:40:21.070398
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests deduplicate_list with a set of sample input lists
    """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class UnitTestCase(unittest.TestCase):
        """
        Defines the unit tests
        """
        def test_deduplicate_list(self):
            """
            Tests deduplicate_list with a set of sample input lists
            """

# Generated at 2022-06-21 08:40:25.941912
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('90%', 1000) == 900
    assert pct_to_int('50%', 1000) == 500
    assert pct_to_int(5, 1000) == 5
    assert pct_to_int('5', 1000) == 5


# Generated at 2022-06-21 08:40:28.822944
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'

    assert object_to_dict(Foo()) == {'bar': 'baz'}

# Generated at 2022-06-21 08:40:32.517400
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 4, 5, 6, 7, 8, 6, 5, 4, 3, 1, 4, 3, 2, 6, 5]
    deduped_list = [1, 2, 3, 4, 5, 6, 7, 8]
    assert deduplicate_list(original_list) == deduped_list

# Generated at 2022-06-21 08:40:42.934985
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1

    assert pct_to_int("25%", 10) == 3

    assert pct_to_int("100%", 10) == 10

    assert pct_to_int("101%", 10) == 10

    assert pct_to_int("0%", 10) == 0

    assert pct_to_int("-1%", 10) == 0

    assert pct_to_int("0.0001%", 10) == 1

    assert pct_to_int("0.0000001%", 10) == 1

    assert pct_to_int("0.0000001", 10) == 0

    assert pct_to_int("-1", 10) == -1

    assert pct_to_int("3", 10) == 3

    assert pct

# Generated at 2022-06-21 08:40:47.626291
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj():
        def __init__(self):
            self.a = 'test'
            self.b = 'test2'
    assert object_to_dict(Obj()) == {'a': 'test', 'b': 'test2'}

# Generated at 2022-06-21 08:40:57.803557
# Unit test for function pct_to_int
def test_pct_to_int():
    pct = pct_to_int(None, 100)
    assert pct == 1
    pct = pct_to_int(100, 100)
    assert pct == 100
    pct = pct_to_int(100.0, 100)
    assert pct == 100
    pct = pct_to_int(100.3, 100)
    assert pct == 100
    pct = pct_to_int(0, 100)
    assert pct == 1
    pct = pct_to_int(0, 100, min_value=0)
    assert pct == 0
    pct = pct_to_int('100%', 100)
    assert pct == 100
    pct = pct_to_int('100.0%', 100)
    assert pct == 100
   

# Generated at 2022-06-21 08:41:08.891341
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = 5
            self.b = 6
            self._c = 8
            self.d = 4

    obj = A()

    result = object_to_dict(obj)
    assert set(result.keys()) == set(['a', 'b', 'd'])

    result = object_to_dict(obj, ['d'])
    assert set(result.keys()) == set(['a', 'b'])
    assert 'd' not in list(result.keys())

    result = object_to_dict(obj, ['a'])
    assert set(result.keys()) == set(['b', 'd'])
    assert 'a' not in list(result.keys())

    result = object_to_dict(obj, ['a', 'd'])


# Generated at 2022-06-21 08:41:16.784375
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test case 1:
    assert deduplicate_list(['a', 'a', 'b', 'c', 'd', 'a', 'b']) == ['a', 'b', 'c', 'd']

    # Test case 2:
    assert deduplicate_list([]) == []

    # Test case 3:
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-21 08:41:23.336275
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('50%', 1, min_value=10) == 1

    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, min_value=10) == 50
    assert pct_to_int(50, 1, min_value=10) == 1

# Generated at 2022-06-21 08:42:05.665272
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_test = [1,2,3,1,2,3,3,3,3,3,3,3,3,5,5,5,5,5,5,5]
    expected_result = [1,2,3,5]

    assert deduplicate_list(list_to_test) == expected_result, "Not deduplicating list correctly"

# Generated at 2022-06-21 08:42:12.453995
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.other_key = 'other_value'

    obj = TestObj()

    results = object_to_dict(obj)

    assert(results['test_key'] == 'test_value')
    assert(results['other_key'] == 'other_value')

    results = object_to_dict(obj, exclude=['test_key'])

    assert('test_key' not in results)
    assert(results['other_key'] == 'other_value')

# Generated at 2022-06-21 08:42:18.725295
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self):
            self.a1 = 1
            self.a2 = 2
            self.a3 = 3
    a = A()
    assert object_to_dict(a) == {'a1': 1, 'a2': 2, 'a3': 3}
    assert object_to_dict(a, exclude=['a1']) == {'a2': 2, 'a3': 3}

# Generated at 2022-06-21 08:42:24.518845
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 10
    targets = {
        '100%': 10,
        '50%': 5,
        '20%': 2,
        '1%': 1,
        '0%': 1,
    }
    for tstr, target in targets.items():
        assert pct_to_int(tstr, num_items) == target, \
            "pct_to_int failed on target: {}".format(tstr)

# Generated at 2022-06-21 08:42:28.137808
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        B = 'test'
    assert object_to_dict(A) == {'B': 'test'}

    class A(object):
        B = 'test'
        def __init__(self):
            self.C = 'test2'
    assert object_to_dict(A()) == {'B': 'test', 'C': 'test2'}


# Generated at 2022-06-21 08:42:34.701855
# Unit test for function pct_to_int
def test_pct_to_int():

    # pct_to_int should return the number given if the value
    #  is not a %.
    assert pct_to_int('2', 25, min_value=1) == 2

    # pct_to_int should calculate the percentage given if the value
    #  is a percentage.
    assert pct_to_int('33%', 25, min_value=1) == 9

    # pct_to_int should calculate the percentage given if the value
    #  is a percentage and that percentage is 0.
    #assert pct_to_int('0%', 25, min_value=1) == 1

    # pct_to_int should calculate the percentage given if the value
    #  is a percentage and that percentage is 0.
    #assert pct_to_int('100%', 25, min_value=

# Generated at 2022-06-21 08:42:37.428287
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'b', 'd', 'd', 'a']
    assert deduplicate_list(original_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 08:42:43.169863
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['b', 'a', 'b', 'c', 'd', 'b', 'e', 'c']) == ['b', 'a', 'c', 'd', 'e']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a']) == ['a']

# Generated at 2022-06-21 08:42:51.318813
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 1]) == [1, 2]
    assert deduplicate_list(['a', 'b', 'b', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'b', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'b', 'b']) == ['a', 'b']


# Generated at 2022-06-21 08:42:54.850876
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.a = '1'
    obj.b = '2'
    dict_obj = object_to_dict(obj, ['b'])
    assert dict_obj.get('a') == '1'
    assert 'b' not in dict_obj

# Generated at 2022-06-21 08:44:21.382908
# Unit test for function object_to_dict
def test_object_to_dict():
    class testObj:
        def __init__(self):
            self.name = "test"
            self.hidden = "test"
    assert object_to_dict(testObj()) == {'name': 'test'}
    assert object_to_dict(testObj(), exclude=['name']) == {'hidden': 'test'}
    assert object_to_dict(testObj(), exclude=['hidden', 'name']) == {}



# Generated at 2022-06-21 08:44:32.583198
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int('10%', 100, 1) == 10)
    assert(pct_to_int('1000%', 100, 1) == 100)
    assert(pct_to_int('0%', 100, 1) == 1)
    assert(pct_to_int('-10%', 100, 1) == 1)
    assert(pct_to_int('50', 100, 1) == 50)
    assert(pct_to_int(50, 100, 1) == 50)
    assert(pct_to_int('-1', 100, 1) == 1)
    assert(pct_to_int('-10', 100, 1) == 1)
    assert(pct_to_int('0', 100, 1) == 1)

# Generated at 2022-06-21 08:44:35.705927
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int('50%', 1000)
    assert value == 500
    value = pct_to_int('95%', 1000)
    assert value == 950
    value = pct_to_int('33%', 1000, min_value=2)
    assert value == 334
    value = pct_to_int('33%', 1000)
    assert value == 334

# Generated at 2022-06-21 08:44:41.329749
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Test class to test the object_to_dict function.
        """
        def __init__(self):
            self.test_key = "test_value"
            self.excluded_key = "excluded_value"

    test = TestClass()
    result = object_to_dict(test, exclude=['excluded_key'])
    assert result == {'test_key': 'test_value'}

# Generated at 2022-06-21 08:44:51.638646
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject():
        def __init__(self, exclude):
            self.test1 = "1234"
            self.test2 = "5678"
            self.test3 = "9012"
            self.exclude = exclude

    obj = TestObject(exclude=[])
    # Default parameters, no fields excluded
    result = object_to_dict(obj)
    assert result['test1'] == "1234"
    assert result['test2'] == "5678"
    assert result['test3'] == "9012"
    # Single field excluded
    result = object_to_dict(obj, exclude=["test2"])
    assert result['test1'] == "1234"
    assert result['test2'] is None
    assert result['test3'] == "9012"
    # Multiple fields excluded

# Generated at 2022-06-21 08:45:01.884293
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(33, 100) == 33
    assert pct_to_int(33, 100, min_value=10) == 33
    assert pct_to_int(33, 100, min_value=100) == 100
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 100, min_value=100) == 100
    assert pct_to_int(100, 100, min_value=10) == 100
    assert pct_to_int(200, 100) == 100
    assert pct_to_int(200, 100, min_value=100) == 100
    assert pct_to_int(200, 100, min_value=10) == 100
    assert pct_to_int(0, 100) == 1
    assert p

# Generated at 2022-06-21 08:45:09.898356
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100, 1) == 25
    assert pct_to_int(25, 100, 0) == 25
    assert pct_to_int(25, 99, 0) == 25
    assert pct_to_int(25, 99, 1) == 26
    assert pct_to_int('25%', 100, 0) == 25
    assert pct_to_int('25%', 99, 0) == 25
    assert pct_to_int('25%', 99, 1) == 26