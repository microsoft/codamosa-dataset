

# Generated at 2022-06-21 08:35:09.000795
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 1000) == 1
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('20%%', 1000) == 100
    assert pct_to_int(100, 1000) == 100

# Generated at 2022-06-21 08:35:15.967213
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20, \
        "pct_to_int('20%', 100) returned %s, expected 20" % pct_to_int('20%', 100)
    assert pct_to_int('20%', 101) == 21, \
        "pct_to_int('20%', 101) returned %s, expected 21" % pct_to_int('20%', 101)
    assert pct_to_int('100%', 100) == 100, \
        "pct_to_int('100%', 100) returned %s, expected 100" % pct_to_int('100%', 100)

# Generated at 2022-06-21 08:35:26.933665
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(20, 100) == 20
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=0) == 20
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=50) == 50
    assert pct_to_int('1%', 100, min_value=50) == 1
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int(2, 100) == 2

# Generated at 2022-06-21 08:35:34.099389
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(5, 100) == 5)
    assert(pct_to_int('5', 100) == 5)
    assert(pct_to_int('5%', 100) == 5)
    assert(pct_to_int('500%', 100) == 100)
    assert(pct_to_int(None, 100) == 0)
    assert(pct_to_int('', 100) == 0)


# Generated at 2022-06-21 08:35:40.956985
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5%', 1000) == 50
    assert pct_to_int('1%', 1000) == 10
    assert pct_to_int('1%', 100, min_value=0) == 0

# Generated at 2022-06-21 08:35:42.489797
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 5) == 1


# Generated at 2022-06-21 08:35:46.147527
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self):
            self.attribute = 1
    assert object_to_dict(test_class()) == {'attribute': 1}



# Generated at 2022-06-21 08:35:56.390370
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test object_to_dict function
    """
    class FooClass(object):
        """ sample class for testing object_to_dict function """
        def __init__(self):
            self.name = "test"
            self._private = 1
            self.__double_private = 2

    # Instantiate FooClass
    sample_object = FooClass()
    # Convert sample_object to dict
    sample_object_dictionary = object_to_dict(sample_object)
    assert sample_object_dictionary['name'] == 'test'
    assert '_private' not in sample_object_dictionary
    assert '__double_private' not in sample_object_dictionary


# Generated at 2022-06-21 08:36:01.866340
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class(object):
        test_value = "test"
        _exclude_test = "exclude"
        hidden_test = "hidden"

    test_exclude_list = ['_exclude_test', 'hidden_test']

    result = object_to_dict(test_class(), test_exclude_list)
    assert len(result.keys()) == 1, 'Failed to exclude the keys in the exclude list'


# Generated at 2022-06-21 08:36:05.656594
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int(5, 10) == 5

# Generated at 2022-06-21 08:36:09.890257
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:
        def __init__(self):
            self.a = "a_value"
    myclass = MyClass()
    assert object_to_dict(myclass) == {"a": "a_value"}

# Generated at 2022-06-21 08:36:16.971549
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create an example object
    class TestObject(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self.key3 = 'value3'

    obj = TestObject()

    # Convert to dict and test
    actual = object_to_dict(obj, ['key2'])
    expected = {'key1': 'value1', 'key3': 'value3'}

    # Compare
    assert actual == expected, "object_to_dict failed the test"

# Generated at 2022-06-21 08:36:21.459773
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_x = ['a', 'b', 'a', 'b', 'a', 'b', 'c']
    dedup_list = deduplicate_list(list_x)
    expected_dedup = ['a', 'b', 'c']
    assert dedup_list == expected_dedup


# Generated at 2022-06-21 08:36:23.502841
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 2, 1, 2, 3, 2]) == [1, 2, 3]


# Generated at 2022-06-21 08:36:28.297527
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(25, 100) == 25
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('5%', 100, min_value=5) == 5


# Generated at 2022-06-21 08:36:40.898937
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test conversion of integer
    test_value = 1
    actual_result = pct_to_int(test_value, 100)
    assert actual_result == 1

    # Test conversion of string to integer
    test_value = '10'
    actual_result = pct_to_int(test_value, 100)
    assert actual_result == 10

    # Test conversion of percentage to integer
    test_value = '10%'
    actual_result = pct_to_int(test_value, 100)
    assert actual_result == 10

    # Test conversion of percentage to integer
    test_value = '100%'
    actual_result = pct_to_int(test_value, 100)
    assert actual_result == 100

    # Test conversion of percentage to integer
    test_value = '148%'
    actual

# Generated at 2022-06-21 08:36:46.728482
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        a = 1
        b = 2
        c = 3
        _private_value = 1

    obj = A()
    result = object_to_dict(obj)
    assert result == {
        'a': 1,
        'b': 2,
        'c': 3
    }, result

    result = object_to_dict(obj, exclude=['a'])
    assert result == {
        'b': 2,
        'c': 3
    }, result



# Generated at 2022-06-21 08:36:53.252696
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-21 08:37:00.347175
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    sample_list = [
        'foo',
        'bar',
        'baz',
        'foo',
        'qux',
        'qux',
        'qux',
        'qux',
        'corge',
        'corge'
    ]

    expected = ['foo', 'bar', 'baz', 'qux', 'corge']
    result = deduplicate_list(sample_list)

    assert result == expected

# Generated at 2022-06-21 08:37:05.052755
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'
            self.key3 = 'value3'

    obj = TestObj()

    obj_dict = object_to_dict(obj, ['key2'])
    assert obj_dict['key1'] == 'value1'
    assert not obj_dict.has_key('key2')
    assert obj_dict['key3'] == 'value3'


# Generated at 2022-06-21 08:37:16.573717
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_lists = [
        range(10),
        [1, 1, 2, 3, 3, 4, 4, 4, 5, 5, 5],
        [5, 5, 5, 4, 1, 2, 4, 4, 1, 1, 3],
        ['a', 'a', 'a', 'b', 'c', 'a'],
        ['c', 'a', 'a', 'b', 'c', 'a']
    ]
    ideal_results = [
        range(10),
        [1, 2, 3, 4, 5],
        [5, 4, 1, 2, 3],
        ['a', 'b', 'c'],
        ['c', 'a', 'b']
    ]
    for test_list, ideal_result in zip(test_lists, ideal_results):
        assert deduplicate

# Generated at 2022-06-21 08:37:26.767871
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int('10%', 3) == 1
    assert pct_to_int('5%', 3) == 1
    assert pct_to_int('5.5%', 100) == 6
    assert pct_to_int('5.5%', 5) == 1
    assert pct_to_int('5.5%', 3) == 1
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0.5%', 3) == 1
    assert pct_to_int('0.5%', 5) == 1

# Generated at 2022-06-21 08:37:30.425453
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,3,3,2,1]
    deduped_list = deduplicate_list(original_list)
    assert deduped_list == [1,2,3]

# Generated at 2022-06-21 08:37:35.771537
# Unit test for function object_to_dict
def test_object_to_dict():
    class O(object):
        def __init__(self):
            self.a = 'test1'
            self.b = 'test2'
            self.c = 'test3'

    o = O()
    assert object_to_dict(o) == {'a': 'test1', 'b': 'test2', 'c': 'test3'}
    assert object_to_dict(o, exclude=['a']) == {'b': 'test2', 'c': 'test3'}

# Generated at 2022-06-21 08:37:43.245726
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int("50", 100) == 50
    assert pct_to_int("50%", 100) == 50
    assert pct_to_int("50.1%", 100) == 51
    assert pct_to_int("50.6%", 100) == 51
    assert pct_to_int("0.6%", 100) == 1
    assert pct_to_int("0.4%", 100) == 1
    assert pct_to_int("0.5%", 100) == 1

# Generated at 2022-06-21 08:37:47.966342
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    For testing it is recommended to add a new class instead of using an existing one that can potentially change
    """
    class TestClass(object):
        def __init__(self):
            self.attr1 = "val1"
            self.attr2 = "val2"
            self.attr3 = "val3"
        def __private_method__(self):
            pass
    deduped = deduplicate_list([1,2,2,3,3,3,4,5,5,1,1,1,1,6,7])
    assert [1, 2, 3, 4, 5, 6, 7] == deduped



# Generated at 2022-06-21 08:37:51.545268
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([2, 2, 3, 2, 1, 1, 4, 2, 4]) == [2, 3, 1, 4]



# Generated at 2022-06-21 08:37:57.491448
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 2, 2, 4, 1, 6]
    assert deduplicate_list(test_list) == [1, 2, 3, 4, 6]
    test_list2 = ['a', 'b', 'a', 'z', 'b', 'r']
    assert deduplicate_list(test_list2) == ['a', 'b', 'z', 'r']

# Generated at 2022-06-21 08:38:05.505802
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_a = [1,2,3,3,3,1,1,2,3,1,1,1,1,2,2,2,2]
    list_b = [1,2,3]
    list_c = [1,2,3,4,5,4,5,5,5]
    list_d = [1,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]

# Generated at 2022-06-21 08:38:17.040453
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1,3) == 1
    assert pct_to_int(3,3) == 3
    assert pct_to_int(4,3) == 3
    assert pct_to_int('50%',8) == 4
    assert pct_to_int('20%',8) == 2
    assert pct_to_int('20%',5) == 1
    assert pct_to_int('20%',4) == 1
    assert pct_to_int('20%',3) == 1
    assert pct_to_int('20%',2) == 1
    assert pct_to_int('10.1%',2) == 1
    assert pct_to_int('10%',2) == 1

# Generated at 2022-06-21 08:38:36.384333
# Unit test for function pct_to_int
def test_pct_to_int():
    assert (pct_to_int("2%", 100) == 2)
    assert (pct_to_int("2%", 100, min_value=3) == 3)
    assert (pct_to_int("2%", 1) == 1)
    assert (pct_to_int("2%", 1, min_value=2) == 2)
    assert (pct_to_int("200%", 1) == 1)
    assert (pct_to_int(2, 100) == 2)
    assert (pct_to_int("blah", 100) == 100)
    assert (pct_to_int("2.1", 100) == 2)
    assert (pct_to_int("string", 100) == 100)

# Generated at 2022-06-21 08:38:47.540448
# Unit test for function pct_to_int
def test_pct_to_int():
    from pytest import raises
    assert pct_to_int('50%', 7) == 4
    assert pct_to_int('25%', 3) == 1
    assert pct_to_int('100%', 3) == 3
    assert pct_to_int('100%', 0) == 0
    assert pct_to_int('50%', 3) == 2
    assert pct_to_int('0%', 3) == 0
    assert pct_to_int('0%', 0) == 0
    assert pct_to_int('100%', 0) == 0
    assert pct_to_int('100%', 4) == 4
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('50%', 100) == 50
    assert pct_

# Generated at 2022-06-21 08:38:57.514460
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        """
        Temporarily defines an object to use for the unittest.
        """
        def __init__(self):
            self.test_attr = 1
            self.test_attr2 = 2
            self.test_attr3 = 3
    test_obj = TestObject()
    expected_dict = {'test_attr': 1, 'test_attr2': 2, 'test_attr3': 3}

    results_dict = object_to_dict(test_obj)
    assert results_dict == expected_dict

    expected_dict = {'test_attr': 1, 'test_attr3': 3}
    results_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert results_dict == expected_dict

# Generated at 2022-06-21 08:39:07.074331
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 5, 1]) == [1, 2, 5]
    assert deduplicate_list([1, 5, 2, 2, 1]) == [1, 5, 2]
    assert deduplicate_list([1, 5, 2, 2, 1, 5]) == [1, 5, 2]
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'a', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-21 08:39:11.672139
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        bar = 'baz'
        quux = 1

    foo = Foo()
    assert object_to_dict(foo) == {'bar': 'baz', 'quux': 1}
    assert object_to_dict(foo, exclude=['bar']) == {'quux': 1}



# Generated at 2022-06-21 08:39:21.885253
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int(5.5, 100) == 5
    assert pct_to_int('5.5', 100) == 5
    assert pct_to_int(5.5, 100, min_value=5.5) == 5.5
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5.5%', 100) == 6
    assert pct_to_int('5.5%', 100, min_value=5.5) == 6
    assert pct_to_int('1.1%', 100, min_value=5.5) == 5.5



# Generated at 2022-06-21 08:39:25.886570
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'c', 'a']
    expected_list = ['a', 'b', 'c']
    new_list = deduplicate_list(original_list)

    assert expected_list == new_list


# Generated at 2022-06-21 08:39:29.077189
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=0) == 100
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5



# Generated at 2022-06-21 08:39:34.704631
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [
        'a',
        'b',
        'a',
        'c',
        'b',
        'a',
        'a',
        'b',
        'a',
        'd',
    ]
    expected = [
        'a',
        'b',
        'c',
        'd',
    ]
    assert expected == deduplicate_list(test_list)



# Generated at 2022-06-21 08:39:40.605506
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5', '12', '1') == 1
    assert pct_to_int('5%', '12', '1') == 1
    assert pct_to_int('100%', '12', '1') == 12
    assert pct_to_int(5, 12, '1') == 5
    assert pct_to_int(5000, 12, '1') == 10

# Generated at 2022-06-21 08:40:07.357273
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from nose.tools import eq_, ok_
    test = [1, 2, 1, 3, 4, 5, 6, 7, 2, 1, 8, 9, 1, 0, 3, 9, 8, 3, 1, 9, 5, 6, 7, 9, 5, 6, 7, 1]
    result = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    dedup_list = deduplicate_list(test)
    ok_(isinstance(dedup_list, list), msg='Deduplicated list should be a list')
    eq_(dedup_list, result, msg='Deduplicate list is incorrect')

# Generated at 2022-06-21 08:40:12.445718
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1,1,2,1,3,3,3,3,2,2,2,2,2]
    expected = [1,2,3]
    result = deduplicate_list(test_list)
    assert result == expected

# Generated at 2022-06-21 08:40:18.491101
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestClass:
        attribute_one = "Test Attribute One"
        attribute_two = "Test Attribute Two"
        attribute_three = None

    test_object = TestClass()

    assert object_to_dict(test_object) == {
        'attribute_one': 'Test Attribute One',
        'attribute_two': 'Test Attribute Two',
        'attribute_three': None
    }

# Generated at 2022-06-21 08:40:29.355098
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 4
    values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
    results = [1, 2, 3, 2, 3, 3, 4, 4, 4, 5]
    for i in values:
        assert results[int(i) - 2] == pct_to_int(i, num_items)
    values = ['.5', '1', '1.5', '2', '2.5', '3', '3.5', '4', '4.5', '5', '5.5']
    results = [0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3]
    for i in values:
        assert results[int(float(i) * 10 - 5)] == pct

# Generated at 2022-06-21 08:40:40.531357
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert([1,2,3,4,5] == deduplicate_list([1,5,5,5,5,5,5,5,1,2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]))

# Generated at 2022-06-21 08:40:48.667698
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50', 10) == 50
    assert pct_to_int(2, 8) == 2
    assert pct_to_int(2, 8, min_value=2) == 2
    assert pct_to_int(0, 8) == 1
    assert pct_to_int(0, 8, min_value=2) == 2
    assert pct_to_int(0, 0) == 1

# Generated at 2022-06-21 08:40:58.500911
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_to_int_values = [
        {"value": "25%", "num_items": 42, "expected": 10},
        {"value": "100%", "num_items": 0, "expected": 1},
        {"value": "100%", "num_items": 42, "expected": 42},
        {"value": "0.5%", "num_items": 42, "expected": 1},
        {"value": "50%", "num_items": 42, "expected": 21},
        {"value": 1, "num_items": 42, "expected": 1},
        {"value": 0, "num_items": 42, "expected": 0}
    ]
    for value in pct_to_int_values:
        assert pct_to_int(value["value"], value["num_items"]) == value["expected"]

# Generated at 2022-06-21 08:41:03.074545
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['one', 'one', 'two', 'one', 'three']) == ['one', 'two', 'three']
    assert deduplicate_list([]) == []



# Generated at 2022-06-21 08:41:05.894648
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'a', 'b', 'c', 'b', 'c']
    assert deduplicate_list(original_list) == ['a', 'b', 'c']


# Generated at 2022-06-21 08:41:11.380584
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.val1 = "bar"
            self.val2 = "baz"
    f = Foo()
    f_dict = object_to_dict(f)
    assert("val1" in f_dict)
    assert("val2" in f_dict)
    assert("val3" not in f_dict)
    assert("_val3" not in f_dict)
    assert("val1" not in f_dict.keys())
    assert("val2" not in f_dict.keys())
    assert("val3" not in f_dict.keys())
    assert("_val3" not in f_dict.keys())

# Generated at 2022-06-21 08:41:53.985792
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self, a=None, b=None, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    o = TestObject('a', 'b', 'c', 'd')
    d = object_to_dict(o, ['b', 'd'])
    assert len(d) == 2
    assert 'a' in d and d['a'] == 'a'
    assert 'c' in d and d['c'] == 'c'

# Generated at 2022-06-21 08:42:03.926139
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3], "Deduplication of a list with no duplicates failed"
    assert deduplicate_list([1, 1, 2, 3, 4, 4, 5, 6, 1, 7, 8, 8]) == [1, 2, 3, 4, 5, 6, 7, 8], "Deduplication of a list with duplicates failed"
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3], "Deduplication of a list with only duplicates failed"
    assert deduplicate_list([]) == [], "Deduplication of an empty list failed"

    # Test deduplication of a

# Generated at 2022-06-21 08:42:09.665736
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('20%', 9) == 2
    assert pct_to_int('20%', 8) == 2
    assert pct_to_int('20%', 7) == 1
    assert pct_to_int('20%', 6) == 1
    assert pct_to_int('20%', 5) == 1

# Generated at 2022-06-21 08:42:13.152752
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        test = "test"
        _test = "test"
        _test = "test"
        _test = "test"

    assert len(object_to_dict(Test)) == 1, "Item count is incorrect"
    assert 'test' in list(object_to_dict(Test).keys()), "Key test not found"

# Generated at 2022-06-21 08:42:18.913634
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['b', 'c', 'c', 'a', 'd', 'b', 'a', 'f', 'b']
    expected_list = ['b', 'c', 'a', 'd', 'f']
    deduplicated_list = deduplicate_list(test_list)
    assert expected_list == deduplicated_list
    assert test_list != deduplicated_list

# Generated at 2022-06-21 08:42:27.671528
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test that the function creates a list with the items in the same order as they appear in the original list
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]

    # Test that the function creates a deduplicated list
    assert deduplicate_list([1, 1, 1, 1, 1]) == [1]

    # Test that the function returns an empty list if the original list is empty
    assert deduplicate_list([]) == []

# Generated at 2022-06-21 08:42:34.445820
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.junos import JunosError
    import sys

    if sys.version_info >= (2, 7):
        import unittest

        class ObjectToDictTest(unittest.TestCase):
            def setUp(self):
                self.obj = JunosError('some message')

            def tearDown(self):
                del self.obj

            def test_object_to_dict_basic(self):
                obj_dict = object_to_dict(self.obj)
                self.assertEqual(obj_dict['message'], 'some message')
                self.assertEqual(str(obj_dict['__class__']), "<type 'instance'>")


# Generated at 2022-06-21 08:42:44.581196
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('110%', 100) == 100
    assert pct_to_int('110%', 100, min_value=0) == 100
    assert pct_to_int('110%', 100, 0) == 100
    assert pct_to_int('0%', 100, 0) == 0
    assert pct_to_int('0%', 100, -1) == -1
    assert pct_to_int('-1%', 100) == 1
    assert pct_to_int('-10%', 100) == 1

    assert pct_to_int('10', 100)

# Generated at 2022-06-21 08:42:47.570386
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["foo", "bar", "bar", "foo", "bar", "foo", "baz"]) == ["foo", "bar", "baz"]

# Generated at 2022-06-21 08:42:52.549076
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 2, 1, 3, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([2, 2, 3, 2, 1, 2, 3]) == [2, 3, 1]
    assert deduplicate_list(['bruh', 'hello', 'hello', 'bruh']) == ['bruh', 'hello']


# Generated at 2022-06-21 08:44:17.090393
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

    test_obj = TestClass()
    test_dict = {'a': 'a', 'b': 'b'}
    assert object_to_dict(test_obj) == test_dict

# Generated at 2022-06-21 08:44:27.447458
# Unit test for function pct_to_int
def test_pct_to_int():
    if pct_to_int(1, 100) != 1:
        raise AssertionError("pct_to_int didn't convert 1 to 1")
    if pct_to_int(1, 10) != 1:
        raise AssertionError("pct_to_int didn't convert 1 to 1")
    if pct_to_int('1%', 100) != 1:
        raise AssertionError("pct_to_int didn't convert '1%' to 1")
    if pct_to_int('1%', 195) != 2:
        raise AssertionError("pct_to_int didn't convert '1%' to 2")

# Generated at 2022-06-21 08:44:35.574720
# Unit test for function pct_to_int
def test_pct_to_int():
    if pct_to_int('20%', 100) != 20:
        raise AssertionError()
    if pct_to_int('20%', 50) != 10:
        raise AssertionError()
    if pct_to_int('20%', 0) != 0:
        raise AssertionError()
    if pct_to_int('20%', 50, 10) != 10:
        raise AssertionError()
    if pct_to_int('20%', 100, 10) != 20:
        raise AssertionError()
    if pct_to_int('20%', 0, 10) != 10:
        raise AssertionError()
    if pct_to_int(20, 20) != 20:
        raise AssertionError()

# Generated at 2022-06-21 08:44:46.107608
# Unit test for function object_to_dict
def test_object_to_dict():
    class testClass(object):
        def __init__(self):
            self.prop1 = 1
            self.prop2 = 2
            self.prop3 = 3
            self._prop4 = 4

    obj = testClass()
    assert object_to_dict(obj) == {'prop1': 1, 'prop2': 2, 'prop3': 3}
    assert object_to_dict(obj, exclude=['prop1']) == {'prop2': 2, 'prop3': 3}
    assert object_to_dict(obj, exclude=['prop1', 'prop2', 'prop3']) == {}
    assert object_to_dict(obj, exclude=['prop1', 'prop2', 'prop3', '_prop4']) == {}

# Generated at 2022-06-21 08:44:51.784317
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj(object):
        test1 = 'hello'
        test2 = 'world'
        test3 = 'foo'
        def test4(self):
            return 'bar'
    test_obj_dict = object_to_dict(test_obj())
    assert test_obj_dict.get('test1') == 'hello'
    assert test_obj_dict.get('test2') == 'world'
    assert test_obj_dict.get('test3') == 'foo'

# Generated at 2022-06-21 08:44:57.472868
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests object_to_dict
    """
    class TestClass(object):
        """
        A test class
        """
        def __init__(self):
            self.testkey = 'testvalue'

    result = object_to_dict(TestClass())
    assert 'testkey' in result
    assert result['testkey'] == 'testvalue'

    result = object_to_dict(TestClass(), exclude=['testkey'])
    assert 'testkey' not in result


# Generated at 2022-06-21 08:45:01.577748
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:
        test = 'a'
        test2 = 'b'

    assert object_to_dict(MyClass) == {'test2': 'b', 'test': 'a'}



# Generated at 2022-06-21 08:45:05.690054
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('20', 10) == 20
    assert pct_to_int('20%', 10, 1) == 2
    assert pct_to_int('20', 10, 1) == 20