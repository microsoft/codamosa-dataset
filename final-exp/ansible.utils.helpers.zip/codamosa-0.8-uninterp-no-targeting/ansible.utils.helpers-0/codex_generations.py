

# Generated at 2022-06-21 08:35:11.813322
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(55, 100) == 55
    assert pct_to_int('55', 100) == 55
    assert pct_to_int('55%', 100) == 55
    assert pct_to_int('50.1%', 100) == 50
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('1.5%', 100) == 2
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0.1%', 100) == 1 # min_value defaulted to 1
    assert pct_to_int('0.1%', 100, min_value=10) == 10 # min_value set to 10

# Generated at 2022-06-21 08:35:14.934917
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'a', 'c', 'd', 'c', 'a']
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == ['a', 'b', 'c', 'd']


# Generated at 2022-06-21 08:35:22.510693
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self, _id, name):
            self.id = _id
            self.name = name

    foo1 = Foo(1, 'one')
    foo2 = Foo(2, 'two')

    result = [object_to_dict(foo1), object_to_dict(foo2)]

    assert result[0]['id'] == 1
    assert result[0]['name'] == 'one'
    assert result[1]['id'] == 2
    assert result[1]['name'] == 'two'

# Generated at 2022-06-21 08:35:26.282894
# Unit test for function deduplicate_list
def test_deduplicate_list():
    x = [1,2,2,2,3,4,4,4,4,4,4,4,4,4,4]
    assert deduplicate_list(x) == [1,2,3,4]

# Generated at 2022-06-21 08:35:32.563429
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.attr1 = 'attr1'
    obj.attr2 = 'attr2'
    assert object_to_dict(obj) == {
        'attr2': 'attr2',
        'attr1': 'attr1',
    }
    assert object_to_dict(obj, exclude=['attr1']) == {
        'attr2': 'attr2',
    }

# Generated at 2022-06-21 08:35:41.870780
# Unit test for function pct_to_int
def test_pct_to_int():
    # Test one element list
    assert pct_to_int(75, 1) == 1
    assert pct_to_int('75', 1) == 1
    assert pct_to_int('75%', 1) == 1
    assert pct_to_int(75.0, 1) == 1
    assert pct_to_int(75.00, 1) == 1

    # Test two element list
    assert pct_to_int(75, 2) == 2
    assert pct_to_int('75', 2) == 2
    assert pct_to_int('75%', 2) == 2
    assert pct_to_int(75.0, 2) == 2
    assert pct_to_int(75.00, 2) == 2

    # Test three element list
    assert pct_to_int

# Generated at 2022-06-21 08:35:46.781620
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'a', 'b']) == ['a', 'b', 'c']



# Generated at 2022-06-21 08:35:58.441631
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 3, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list(['1', '2', '2', '3']) == ['1', '2', '3']
    assert deduplicate_list(['1', '1', '1']) == ['1']


# Generated at 2022-06-21 08:36:02.654719
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    lst = ["a", "b", "c", "a", "b", "d", "e", "b", "f"]
    assert(deduplicate_list(lst) == ["a", "b", "c", "d", "e", "f"])

# Generated at 2022-06-21 08:36:12.938929
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test deduplicate_list.
    """
    # Make sure this doesn't blow
    deduplicate_list([])

    # Order preserved
    assert deduplicate_list([1, 2, 1, 1, 2, 3, 2]) == [1, 2, 3]

    # Order preserved
    assert deduplicate_list(["1", "2", "2", "1", "1", "3", "3", "2"]) == ["1", "2", "3"]

    # New objects are deduplicated
    assert deduplicate_list([[1, 2], [1, 2], [3, 4]]) == [[1, 2], [3, 4]]

    # Test large numbers of objects

# Generated at 2022-06-21 08:36:25.198391
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 3, 1) == 1
    assert pct_to_int("25%", 3, 1) == 1
    assert pct_to_int("33%", 3, 1) == 1
    assert pct_to_int("50%", 3, 1) == 2
    assert pct_to_int("66%", 3, 1) == 2
    assert pct_to_int("75%", 3, 1) == 2
    assert pct_to_int("90%", 3, 1) == 3
    assert pct_to_int("95%", 3, 1) == 3
    assert pct_to_int("100%", 3, 1) == 3
    assert pct_to_int(1, 3, 1) == 1

# Generated at 2022-06-21 08:36:37.273627
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Tests the deduplicate_list function
    """
    test_data_1 = [1, 1, 2, 3, 3, 3, 3, 4, 5, 5, 6, 6]
    expected_result_1 = [1, 2, 3, 4, 5, 6]
    test_result = deduplicate_list(test_data_1)
    assert test_result == expected_result_1, "Wrong order of elements in the list"

    test_data_2 = [5, 3, 3, 3, 5, 3, 1, 1, 5, 1, 2, 6, 5]
    expected_result_2 = [5, 3, 1, 2, 6]
    test_result = deduplicate_list(test_data_2)

# Generated at 2022-06-21 08:36:44.186416
# Unit test for function object_to_dict
def test_object_to_dict():
    class FakeClass(object):
        def __init__(self):
            self.fake_attribute_1 = 'fake1'
            self.fake_attribute_2 = 'fake2'
    fake_class_obj = FakeClass()
    fake_dict = object_to_dict(fake_class_obj)
    assert fake_dict['fake_attribute_1'] == 'fake1'
    assert fake_dict['fake_attribute_2'] == 'fake2'



# Generated at 2022-06-21 08:36:48.902477
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100,10) == 10
    assert pct_to_int("100%",10) == 10
    assert pct_to_int("100%",100) == 100
    assert pct_to_int("100%",0) == 0
    with pytest.raises(ValueError):
        pct_to_int("100",0)

    # Minimum of pct_to_int(5%,5) is 1
    assert pct_to_int("5%",5) == 1

# Generated at 2022-06-21 08:36:57.756204
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, a=None, b=None, foo=None, bar=None):
            self.a = a
            self.b = b
            self.foo = foo
            self.bar = bar

    obj = TestClass(1, 2, 3, 4)
    obj_dict = object_to_dict(obj, ['foo'])
    assert obj_dict['a'] == obj.a
    assert obj_dict['b'] == obj.b
    assert not obj_dict.get('foo')

# Generated at 2022-06-21 08:37:02.904821
# Unit test for function pct_to_int
def test_pct_to_int():
    # TODO: for some reason these functions don't run when the file is imported
    # as part of iosxr.py, but they do run from test_iosxr.py
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('80%', 10) == 8
    assert pct_to_int(70, 10) == 70

# Generated at 2022-06-21 08:37:06.139627
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int(10, 100) == 10



# Generated at 2022-06-21 08:37:08.355019
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 08:37:12.224747
# Unit test for function object_to_dict
def test_object_to_dict():
     class test_object(object):
         first_key = 'first_value'
         second_key = 'second_value'
     test_obj = test_object()
     assert object_to_dict(test_obj, exclude=['first_key']) == {'second_key': 'second_value'}

# Generated at 2022-06-21 08:37:16.115878
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["1", "1", "2", "5", "4", "5", "4", "2", "2", "4", "4"]
    deduplicated_list = deduplicate_list(original_list)
    assert len(deduplicated_list) == 5
    assert deduplicated_list == ["1", "2", "5", "4", "2"]


# Generated at 2022-06-21 08:37:31.762318
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test_val = 'test'
    test_obj = TestObject()
    result = object_to_dict(test_obj)
    assert result['test_val'] == 'test'

    class TestObject:
        def __init__(self):
            self.test_val = 'test'
            self._private_val = 'private'
    test_obj = TestObject()
    result = object_to_dict(test_obj)
    assert result['test_val'] == 'test'
    assert '_private_val' not in result

    class TestObject:
        def __init__(self):
            self.public_val = 'public'
            self._private_val = 'private'
    test_obj = TestObject()
    result = object_to

# Generated at 2022-06-21 08:37:43.529735
# Unit test for function pct_to_int
def test_pct_to_int():
    """Test for conversion of utilization values.
       Value < 1 is always converted to 1.
    """
    # Function pct_to_int is tested by the tests in test_nxos_overlay_global.py
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(50.0, 10) == 5
    assert pct_to_int(50.1, 10) == 5
    assert pct_to_int(50.9, 10) == 5
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int(0.5, 10) == 1
    assert pct_to_int(0.49, 10) == 1
    assert pct_to_int(0, 10) == 1
    assert pct_to_int

# Generated at 2022-06-21 08:37:51.928017
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests for function deduplicate_list
    """
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-21 08:37:57.322327
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 0) == 0
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 100, min_value=0) == 100
    assert pct_to_int('100%', 100, min_value=0) == 100
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:38:02.674288
# Unit test for function object_to_dict
def test_object_to_dict():

    class MyClass:
        def __init__(self):
            self.to_exclude = "123"
            self.this_is_public = "456"

    instance = MyClass()
    dictionary = object_to_dict(instance, exclude=['to_exclude'])
    assert 'to_exclude' not in dictionary
    assert 'this_is_public' in dictionary
    assert dictionary['this_is_public'] == '456'

# Generated at 2022-06-21 08:38:10.426639
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input = ['a','b','b','c','b','c','d','e','f','g','h','d','e','g','h','f','h','f']
    expected = ['a','b','c','d','e','f','g','h']
    actual = deduplicate_list(input)
    assert actual == expected, "unexpected list was created. Expected %s but got %s." % (expected, actual)

# Generated at 2022-06-21 08:38:15.650223
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('40%', 100) == 40 and pct_to_int(40, 100) == 40
    assert pct_to_int('200%', 100) == 100
    assert pct_to_int('0%', 100) == 1 and pct_to_int('0%', 100, min_value=0) == 0


# Generated at 2022-06-21 08:38:22.484776
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    # Test empty list
    assert deduplicate_list([]) == []
    # Test deduplicate_list with no duplicates
    assert deduplicate_list([1,2,3,4,5,6]) == [1,2,3,4,5,6]
    # Test deduplicate_list with duplicates
    assert deduplicate_list([1,2,2,2,2,2]) == [1,2]


# Generated at 2022-06-21 08:38:29.040341
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self._c = 3

    obj_inst = TestClass()
    expected_dict = {'a': 1, 'b': 2}
    actual_dict = object_to_dict(obj_inst, exclude=['_c'])
    assert expected_dict == actual_dict, "Dictionary created is incorrect"
    del(obj_inst)

# Generated at 2022-06-21 08:38:33.394159
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.name = 'test'

    assert object_to_dict(Obj()) == {'name': 'test'}

    assert object_to_dict(Obj(), ['name']) == {}



# Generated at 2022-06-21 08:38:52.699259
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Make sure object_to_dict is working properly
    """
    class TestObj(object):
        def __init__(self):
            self.var1 = "test"
            self.var2 = "test2"

    obj1 = TestObj()
    dict1 = object_to_dict(obj1)
    assert dict1['var1'] == "test"

    obj2 = TestObj()
    obj2.var1 = "new test"
    dict2 = object_to_dict(obj2)
    assert dict2['var1'] == "new test"

    obj3 = TestObj()
    dict3 = object_to_dict(obj3, exclude=['var2'])
    assert dict3['var1'] == "test" and 'var2' not in dict3



# Generated at 2022-06-21 08:38:58.200730
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100, min_value=5) == 50
    # The following case is based on rounding behavior rather than truncate behavior
    assert pct_to_int('25%', 100) == 25

# Generated at 2022-06-21 08:39:02.647632
# Unit test for function object_to_dict
def test_object_to_dict():
    c = CClass()
    c._var1 = 1
    c._var2 = 2

    assert c.var1 == 1
    assert c.var2 == 2

    assert c._var1 == 1
    assert c._var2 == 2

    d = object_to_dict(c)

    assert d['var1'] == 1
    assert d['var2'] == 2

    assert d['_var1'] is not 1
    assert d['_var2'] is not 2


# Generated at 2022-06-21 08:39:07.031895
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.one = 1
            self.two = 2

    t = Test()
    result = object_to_dict(t)
    assert result['one'] == 1
    assert result['two'] == 2



# Generated at 2022-06-21 08:39:18.231596
# Unit test for function pct_to_int
def test_pct_to_int():
    test_list = [
        # Value, num_items, min_value, expect
        ('10%', 1, 1, 1),
        ('10%', 1, 0, 0),
        ('11%', 1, 1, 1),
        ('11%', 1, 0, 1),
        ('20%', 2, 1, 1),
        ('20%', 2, 0, 0),
        ('10%', 2, 1, 1),
        ('10%', 2, 0, 0),
        ('10%', 'a', 1, 1),
        ('10', 2, 1, 10),
        ('10', 2, 0, 10),
    ]

    for value, num_items, min_value, expect in test_list:
        actual = pct_to_int(value, num_items, min_value)


# Generated at 2022-06-21 08:39:23.375594
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([2, 3, 2, 1, 1]) == [2, 3, 1]
    assert deduplicate_list([1, 1, 1, 1]) == [1]



# Generated at 2022-06-21 08:39:32.508778
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test class to use with object_to_dict
    """
    class TestClass():
        def __init__(self):
            self.value1 = 'Test value 1'
            self.value2 = 'Test value 2'
            self.value3 = 'Test value 3'

    assert object_to_dict(TestClass()) == {'value1': 'Test value 1', 'value2': 'Test value 2', 'value3': 'Test value 3'}
    assert object_to_dict(TestClass(), ['value2']) == {'value1': 'Test value 1', 'value3': 'Test value 3'}



# Generated at 2022-06-21 08:39:35.394825
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'd', 'c', 'a', 'a', 'd', 'e']
    assert(deduplicate_list(original_list) == ['a', 'b', 'c', 'd', 'e'])

# Generated at 2022-06-21 08:39:46.331533
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    known_inputs = {
        '1': 1,
        '1%': 1,
        '5': 5,
        '5%': 5,
        '50%': 50,
        '99%': 99,
        '99.9%': 99,
        '100%': 100,
        '101%': 100,    # Out of bounds
        '99.999%': 100, # Out of bounds
        '0%': 1,        # Out of bounds
        '-1%': 1        # Out of bounds
    }
    for input_value, expected_value in known_inputs.items():
        assert expected_value == pct_to_int(input_value, num_items)



# Generated at 2022-06-21 08:39:52.281018
# Unit test for function object_to_dict
def test_object_to_dict():
    import json

    class TestClass():
        def __init__(self):
            self.test_var = ""
            self.exclude_me = ""

    obj = TestClass()
    obj.test_var = "test data"
    obj.exclude_me = "data to exclude"

    dict_obj = object_to_dict(obj, exclude=['exclude_me'])
    assert 'exclude_me' not in dict_obj
    assert dict_obj['test_var'] == 'test data'


# Generated at 2022-06-21 08:40:11.105228
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'b']) == ['a', 'b']


# Generated at 2022-06-21 08:40:21.656746
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 100) == 100
    assert pct_to_int('100', 100) == 100
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 5) == 1
    assert pct_to_int('10%', 5) == 1
    assert pct_to_int('1', 1) == 1
    assert pct_to_int('1%', 1) == 1
    assert pct_to_int('0', 1) == 1

# Generated at 2022-06-21 08:40:29.224875
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.field1 = 'field1'
            self.field2 = 'field2'
            self._field3 = 'field3'

    test_object = TestClass()
    assert object_to_dict(test_object) == {'field1': 'field1', 'field2': 'field2'}
    assert object_to_dict(test_object, ['field1']) == {'field2': 'field2'}

# Generated at 2022-06-21 08:40:33.868613
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20.0%', 10) == 2
    assert pct_to_int('50%', 10, min_value=0) == 5
    assert pct_to_int('50', 10) == 50
    assert pct_to_int(50, 10, min_value=0) == 50


# Generated at 2022-06-21 08:40:41.224944
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=8) == 8
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0.1%', 100) == 1


# Generated at 2022-06-21 08:40:46.579088
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5', 100) == 5
    assert pct_to_int('5', 100, min_value=5) == 5
    assert pct_to_int('5%', 100, min_value=10) == 10
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=10) == 20
    assert pct_to_int('20%', 100, min_value=20) == 20
    assert pct_to_int('1%', 1) == 1
    assert pct_to_int('1%', 1, min_value=1) == 1

# Generated at 2022-06-21 08:40:53.665947
# Unit test for function object_to_dict
def test_object_to_dict():
    if not pytest.config.option.module_name.startswith('unit.utils'):
        pytest.skip('Not a unit test')

    class TestClass(object):
        def __init__(self):
            self.a_property = 'a'
            self.b_property = 'b'

    obj = TestClass()
    result = object_to_dict(obj)
    assert result == {'a_property': 'a', 'b_property': 'b'}



# Generated at 2022-06-21 08:41:01.802340
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        test_val = None
        def __init__(self, val):
            self.test_val = val
    obj1 = test_class('object1')
    obj2 = test_class('object2')
    obj3 = test_class('object3')
    obj4 = test_class('object4')
    original_list = ['object1', 'object2', obj1, obj2, 'object1', 'object3', obj3, 'object4', obj4, 'object4']
    dedup_list = deduplicate_list(original_list)
    assert(len(dedup_list) == len(set(dedup_list)))
    assert(dedup_list == ['object1', 'object2', obj1, obj2, obj3, 'object3', 'object4', obj4])

# Generated at 2022-06-21 08:41:06.106413
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.baz = 'baz'
    obj = TestClass()
    assert object_to_dict(obj) == dict(foo='foo', bar='bar', baz='baz')
    assert object_to_dict(obj, exclude=['bar']) == dict(foo='foo', baz='baz')

# Generated at 2022-06-21 08:41:09.591931
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'a', 'c', 'b', 'a', 'a']
    test_list_expected = ['a', 'b', 'c']
    test_list_result = deduplicate_list(test_list)
    assert test_list_result == test_list_expected



# Generated at 2022-06-21 08:41:49.922443
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Class to test object_to_dict
        """
        def __init__(self):
            self.val1 = 'a'
            self.val2 = 1
            self.val3 = {'1': 'a', '2': 1}

    test_obj = TestClass()
    test_result = {'val1': 'a', 'val2': 1, 'val3': {'1': 'a', '2': 1}}

    assert object_to_dict(test_obj) == test_result



# Generated at 2022-06-21 08:41:53.985775
# Unit test for function object_to_dict
def test_object_to_dict():
    class X(object):
        test1 = "test1"
        test2 = "test2"
    x = X()
    y = object_to_dict(x, ['test2'])
    assert len(y) == 1
    assert y['test1'] == "test1"
    assert not y.get('test2')

# Generated at 2022-06-21 08:41:59.474425
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    result = object_to_dict(Obj())

    assert result is not None
    assert len(result) == 3
    assert result['a'] == 1
    assert result['b'] == 2
    assert result['c'] == 3



# Generated at 2022-06-21 08:42:03.459068
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['abc','abc','abc','def','def','def','ghi','jkl','jkl','jkl','mno','mno','pqr','stu','stu']
    assert deduplicate_list(test_list) == ['abc','def','ghi','jkl','mno','pqr','stu']

# Generated at 2022-06-21 08:42:08.508285
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('1', 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(95, 100) == 95
    assert pct_to_int('95%', 100) == 95



# Generated at 2022-06-21 08:42:17.404174
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests the object_to_dict function
    """
    class MyObject(object):
        def __init__(self):
            self.var1 = 'test1'
            self.var2 = 'test2'
            self.var3 = 'test3'

    assert {'var1': 'test1', 'var2': 'test2', 'var3': 'test3'} == object_to_dict(MyObject())
    assert {'var1': 'test1', 'var3': 'test3'} == object_to_dict(MyObject(), ['var2'])

# Generated at 2022-06-21 08:42:25.596738
# Unit test for function pct_to_int
def test_pct_to_int():
    pctdict = {'2%': 9, '5%': 24, '10%': 48, '50%': 240}
    for k,v in pctdict.items():
        assert pct_to_int(k, 500) == v
    assert pct_to_int(0, 500) == 0
    assert max(pct_to_int('0%', 10), pct_to_int('0%', 0)) == 1
    assert pct_to_int('10', 500) == 10
    assert pct_to_int(10, 500) == 10

# Generated at 2022-06-21 08:42:26.598469
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1



# Generated at 2022-06-21 08:42:29.431349
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 2, 1, 3]
    result = deduplicate_list(original_list)
    assert len(result) == 3
    assert result == [1, 2, 3]



# Generated at 2022-06-21 08:42:33.957019
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # List with duplicate values
    original_list = ['one', 'two', 'three', 'three', 'two', 'one', 'five']

    # Expected list
    expected_list = ['one', 'two', 'three', 'five']

    # Actual list after deduplication
    deduplicated_list = deduplicate_list(original_list)

    # Check values
    assert deduplicated_list == expected_list,\
            "Deduplicated list '{0}' creates unexpected list".format(original_list)

# Generated at 2022-06-21 08:43:46.866240
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10, 1) == 5
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(50, 10, 3) == 5



# Generated at 2022-06-21 08:43:49.273161
# Unit test for function deduplicate_list
def test_deduplicate_list():
    l = ['a', 'b', 'b', 'c', 'd', 'c']
    assert deduplicate_list(l) == ['a', 'b', 'c', 'd']
    assert deduplicate_list([]) == []



# Generated at 2022-06-21 08:43:57.512797
# Unit test for function object_to_dict
def test_object_to_dict():
    class Person(object):
        def __init__(self):
            self.name = 'Don'
            self.lastname = 'Mills'
            self._email = 'don.mills@gmail.com'
    person = Person()
    result = object_to_dict(person)
    assert "name" in result
    assert "lastname" in result
    assert "_email" not in result
    result = object_to_dict(person, exclude=['name'])
    assert "name" not in result
    assert "lastname" in result
    assert "_email" not in result

# Generated at 2022-06-21 08:44:07.566118
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass(object):
        def __init__(self):
            super(DummyClass, self).__init__()
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'
            self.f = 'f'
    class DummyClassExcluding(DummyClass):
        def __init__(self):
            super(DummyClass, self).__init__()
            self.exclude = ['d', 'f']

    dummy_obj = DummyClass()
    dummy_obj_excluding = DummyClassExcluding()


# Generated at 2022-06-21 08:44:17.043789
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 5, 8, 4, 5, 8, 1]) == [1, 5, 8, 4]
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, [1, 2, 3]]) == [1, 2, 3, [1, 2, 3]]


# Generated at 2022-06-21 08:44:22.423229
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.test1 = 'test1'
            self.test2 = 'test2'
            self.test3 = 'test3'
            self.updates = 'updates'

    expected = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    actual = object_to_dict(Test(), exclude=['updates'])
    assert expected == actual



# Generated at 2022-06-21 08:44:29.410222
# Unit test for function pct_to_int
def test_pct_to_int():
    ''' test that pct_to_int function works as expected '''
    value = pct_to_int('10%', 100)
    assert value == 10, 'Error in pct_to_int, expected 10 and got %d' % value
    value = pct_to_int(10, 100)
    assert value == 10, 'Error in pct_to_int, expected 10 and got %d' % value

# Generated at 2022-06-21 08:44:31.639513
# Unit test for function pct_to_int
def test_pct_to_int():
    test_value = "30%"
    test_num_items = 10
    assert pct_to_int(test_value, test_num_items) == 3



# Generated at 2022-06-21 08:44:37.486800
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from collections import OrderedDict
    list1 = ['a', 'b', 'c', 'd', 1, 3, 'a', 'a', 3, 3, 1, 2]
    list2 = ['a', 1, 2, 3, 'b', 'c', 'd']
    list3 = [1, 2, 1, 2, 3, OrderedDict([('a', 1), ('b', 2), ('c', 3)]),
             OrderedDict([('a', 1), ('b', 2), ('c', 3)]), OrderedDict([('a', 1), ('b', 2), ('d', 3)]),
             OrderedDict()]
    list4 = [None, 1, 2, None]
    list5 = [1, 1, 1]
    list6 = [None, None, None, None]
    list7

# Generated at 2022-06-21 08:44:48.136880
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10.0, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10.5%', 100, min_value=5) == 10
    assert pct_to_int('10.5%', 100, min_value=10) == 11
    assert pct_to_int('10.5%', 100, min_value=11) == 11
    assert pct