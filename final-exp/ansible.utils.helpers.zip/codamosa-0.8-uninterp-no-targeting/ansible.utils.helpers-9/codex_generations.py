

# Generated at 2022-06-21 08:35:15.000419
# Unit test for function pct_to_int
def test_pct_to_int():
    # 100% of 5 is 5
    assert pct_to_int('100%', 5) == 5
    # 100% of 6 is 6
    assert pct_to_int('100%', 6) == 6
    # 75% of 6 is 4
    assert pct_to_int('75%', 6) == 4
    # 25% of 1000 is 250
    assert pct_to_int('25%', 1000) == 250
    # 100% of 1 is 1
    assert pct_to_int('100%', 1) == 1
    # 100% of 0 is 1
    assert pct_to_int('100%', 0) == 1



# Generated at 2022-06-21 08:35:18.385659
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 3, 2]
    deduplicated_list = deduplicate_list(original_list)
    assert(deduplicated_list == [1, 2, 3])

# Generated at 2022-06-21 08:35:28.560902
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100, min_value=1) == 50
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50.5, 100) == 51
    assert pct_to_int('50%', 100, min_value=1) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.5%', 100) == 51
    assert pct_to_int('0.5%', 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0



# Generated at 2022-06-21 08:35:39.314141
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 1, 2, 1, 2, 2, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1]) == [1, 2]

# Generated at 2022-06-21 08:35:43.438404
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test to make sure that the object_to_dict function works properly
    test_class = AnsibleModuleUtilsTestClass()
    results = object_to_dict(test_class)

    assert results['a_string'] == "hello"
    assert results['a_list'] == [1, 2, 3, 4]
    assert results['a_dict'] == {"key": "value", "key2": "value2"}
    assert results['a_number'] == 1



# Generated at 2022-06-21 08:35:52.142598
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tests_list = [
        {
            'input': ['a', 'b', 'c', 'c', 'A', 'b'],
            'expected': ['a', 'b', 'c', 'A']
        },
        {
            'input': ['A', 'b', 'C', 'a', 'c', 'B'],
            'expected': ['A', 'b', 'C', 'a', 'c', 'B']
        }
    ]

    for test in tests_list:
        assert test['expected'] == deduplicate_list(test['input'])

# Generated at 2022-06-21 08:36:02.274181
# Unit test for function pct_to_int
def test_pct_to_int():
    # the typical case is when we have a value that is a percentage
    assert pct_to_int('50%', 10) == 5

    # the next case is when we have a simple value, as an int
    assert pct_to_int(10, 10) == 10

    # the next case is when we have a simple value, as a str
    assert pct_to_int('10', 10) == 10

    # the next case is when we have a value that is a percentage
    assert pct_to_int('200%', 10) == 20

    # the next case is when we have a 0 value
    assert pct_to_int('0%', 10) == 1

    # the next case is when we have a 0 value
    assert pct_to_int('0', 10) == 0

    # the next case is when we

# Generated at 2022-06-21 08:36:09.436518
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['item1', 'item1', 'item2']) == ['item1', 'item2']
    assert deduplicate_list(['item1', 'item2', 'item1']) == ['item1', 'item2']
    assert deduplicate_list(['item1', 'item1', 'item1']) == ['item1']
    assert deduplicate_list([]) == []

# Generated at 2022-06-21 08:36:13.084039
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 2, 3, 4, 5, 5, 5, 6, 7, 7, 8, 9, 9]
    deduplicate_list(list1) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 08:36:16.375985
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 4, 5, 5, 6, 7, 8, 8, 8, 10]) == [1, 2, 4, 5, 6, 7, 8, 10]

# Generated at 2022-06-21 08:36:27.723435
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["1", "2", "2", "3", "3"]) == ["1", "2", "3"]
    assert deduplicate_list(["1", "2", "3", "3", "2"]) == ["1", "2", "3"]
    assert deduplicate_list(["1", "2", "2", "2", "2"]) == ["1", "2"]
    assert deduplicate_list(["1", "1", "1", "1", "1"]) == ["1"]
    assert deduplicate_list(["1"]) == ["1"]
    assert deduplicate_list([]) == []
    assert deduplicate_list(["1", "2", "3"]) == ["1", "2", "3"]

# Generated at 2022-06-21 08:36:40.151347
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10', 100, min_value=1) == 10
    assert pct_to_int('%5', 100, min_value=1) == 5
    assert pct_to_int('5%', 100, min_value=2) == 5
    assert pct_to_int('0', 100, min_value=1) == 1
    assert pct_to_int('1.0', 100, min_value=1) == 1
    assert pct_to_int('100', 100, min_value=1) == 100
    assert pct_to_int('101%', 100, min_value=1) == 100

# Generated at 2022-06-21 08:36:46.740290
# Unit test for function pct_to_int
def test_pct_to_int():
    '''
    Function pct_to_int() unit test
    '''
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('8%', 100) == 8
    assert pct_to_int('8%', 100, min_value=5) == 5



# Generated at 2022-06-21 08:36:51.908030
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int("20%", 100)
    assert value == 20
    value = pct_to_int("30%", 100)
    assert value == 30
    value = pct_to_int("40%", 100)
    assert value == 40


# Generated at 2022-06-21 08:36:56.421249
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = [1,'1',3,4,4,4,4,4,4,4,5,5,5,3,3,'3']
    assert deduplicate_list(list) == [1,'1',3,4,5,3,'3']

# Generated at 2022-06-21 08:37:03.284957
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 3, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list(["b", "a", "b", "a"]) == ["b", "a"]

# Generated at 2022-06-21 08:37:07.094557
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    assert pct_to_int("33%", num_items) == 33
    assert pct_to_int("30%", num_items) == 30

# Generated at 2022-06-21 08:37:10.755975
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 2, 9, 1, 1, 5, 9, 4, 4, 5]
    expected_list = [1, 2, 9, 5, 4]
    assert deduplicate_list(sample_list) == expected_list

# Generated at 2022-06-21 08:37:17.008398
# Unit test for function object_to_dict
def test_object_to_dict():
    import json
    import ansible.module_utils.network.iosxr.facts.facts as facts
    facts = facts.Facts()
    obj = facts.interfaces
    result = object_to_dict(obj)
    assert json.dumps(result) == json.dumps({'aggregated': [], 'physical': [{'name': 'MgmtEth0/RP0/CPU0/0', 'neighbors': [{'remote_device': 'None', 'lldp': False, 'remote_interface': 'None'}], 'enabled': True}], 'virtual': []})



# Generated at 2022-06-21 08:37:27.368638
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 10) == 1
    assert pct_to_int("1%", 10) == 1
    assert pct_to_int("100%", 10) == 10
    assert pct_to_int("101%", 10) == 10
    assert pct_to_int("0%", 10) == 1
    assert pct_to_int("0.5%", 10) == 1
    assert pct_to_int("-1%", 10) == 1
    assert pct_to_int("-10%", 10) == 1

    assert pct_to_int(10, 10) == 10
    assert pct_to_int("10", 10) == 10
    assert pct_to_int("a10", 10) == 10



# Generated at 2022-06-21 08:37:37.530041
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,2,2,3,3,1,1,1,1,1,1,2]
    deduplicated_list = [1,2,3]

    assert(deduplicated_list == deduplicate_list(original_list))



# Generated at 2022-06-21 08:37:46.236761
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [] == deduplicate_list([])
    assert ['a'] == deduplicate_list(['a'])
    assert ['a'] == deduplicate_list(['a', 'a'])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c'])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c', 'b', 'a'])
    assert ['a', 'b', 'c'] == deduplicate_list(['c', 'a', 'b', 'c', 'b', 'a'])
    assert ['a', 'b', 'c'] == deduplicate_list(['c', 'b', 'a', 'c', 'a', 'b'])



# Generated at 2022-06-21 08:37:51.545271
# Unit test for function pct_to_int
def test_pct_to_int():

    # Arrange
    num_items = 100
    min_value = 1

    # Act
    x = pct_to_int(value='10%', num_items=num_items, min_value=min_value)

    # Assert
    assert x == 10



# Generated at 2022-06-21 08:37:56.849668
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        a = 'foo'
        b = 'bar'

    result = object_to_dict(Test())
    assert result == {'a': 'foo', 'b': 'bar'}

    result = object_to_dict(Test(), ['a'])
    assert result == {'b': 'bar'}


# Generated at 2022-06-21 08:38:05.156727
# Unit test for function pct_to_int
def test_pct_to_int():

    # case 1
    assert pct_to_int("2%", 200) == 4

    # case 2:
    assert pct_to_int("50%", 200) == 100

    # case 3:
    assert pct_to_int("100%", 200) == 200

    # case 4:
    assert pct_to_int("-1%", 200) == 1

    # case 5:
    assert pct_to_int("-1%", -200) == 1

    # case 6:
    assert pct_to_int("-1%", 0) == 0

    # case 7:
    assert pct_to_int("-1%", 0) == 0

    # case 8:
    assert pct_to_int(-1, 200) == -1

    # case 9:
    assert pct_

# Generated at 2022-06-21 08:38:10.911362
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    setattr(obj, 'attr1', 1)
    setattr(obj, 'attr2', 2)

    assert object_to_dict(obj, ['attr2']) == {'attr1': 1}

    # Make sure object_to_dict is not destructive
    assert getattr(obj, 'attr2') == 2



# Generated at 2022-06-21 08:38:13.956163
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2]) == [1, 2]
    assert deduplicate_list(['1', 1, 2]) == ['1', 1, 2]
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 3, 3, '1']) == [1, 2, 3, '1']

# Generated at 2022-06-21 08:38:21.979984
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.prop1 = 'value1'
            self.prop2 = 'value2'
            self.prop3 = 'value3'
            self.prop4 = 'value4'
    obj = TestObj()
    to_dict = object_to_dict(obj)
    assert isinstance(to_dict, dict)
    assert len(to_dict) == 4
    assert set(to_dict.keys()) == set(['prop1', 'prop2', 'prop3', 'prop4'])
    assert set(to_dict.values()) == set(['value1', 'value2', 'value3', 'value4'])
    to_dict = object_to_dict(obj, ['prop2', 'prop4'])

# Generated at 2022-06-21 08:38:33.113512
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('20%', 95) == 19
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('100%', 1) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('5%', 95) == 5
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int('0%', 1) == 0
    assert pct_to_int('50.5%', 5) == 3
    assert pct_to_int('50.5%', 10) == 5
    assert pct_to_int('50.5%', 9) == 5
    assert pct_to

# Generated at 2022-06-21 08:38:39.729833
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = "A"
            self.b = "B"
            self.c = "C"

    test_obj = TestClass()
    result = object_to_dict(test_obj, ['c'])
    assert isinstance(result, dict)
    assert 'a' in result
    assert 'b' in result
    assert 'c' not in result



# Generated at 2022-06-21 08:38:49.361768
# Unit test for function deduplicate_list
def test_deduplicate_list():
    mylist = []
    assert deduplicate_list(mylist) == []

    mylist = [1, 2, 3]
    assert deduplicate_list(mylist) == [1, 2, 3]

    mylist = [1, 2, 3, 2, 4, 2]
    assert deduplicate_list(mylist) == [1, 2, 3, 4]

# Unit tests for function pct_to_int

# Generated at 2022-06-21 08:38:59.200442
# Unit test for function pct_to_int

# Generated at 2022-06-21 08:39:10.679372
# Unit test for function object_to_dict
def test_object_to_dict():
    class a:
        def __init__(self, name):
            self.name = name

        def __unicode__(self):
            return str(self.name)

    class b:
        def __init__(self, name):
            self.name = name

        def __unicode__(self):
            return str(self.name)

    obj = object_to_dict(a('hello'))
    assert obj['name'] == 'hello', "object_to_dict returned incorrect " + repr(obj)
    obj = object_to_dict(a('hello'), ['name'])
    assert not 'name' in obj, "object_to_dict returned incorrect " + repr(obj)
    obj = object_to_dict(a('hello'), exclude=['name'])

# Generated at 2022-06-21 08:39:14.349452
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, None) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', None) == 1



# Generated at 2022-06-21 08:39:21.371993
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = 3
            self.test_method = 4

    test_object = test_class(1, 2)
    assert object_to_dict(test_object, exclude=['c']) == {'a': 1, 'b': 2, 'test_method': 4}



# Generated at 2022-06-21 08:39:26.293882
# Unit test for function deduplicate_list
def test_deduplicate_list():

    test_dup_list = ['b', 'a', 'c', 'b', 'd', 'e', 'd', 'd']

    expected_dup_list = ['b', 'a', 'c', 'd', 'e']

    assert deduplicate_list(test_dup_list) == expected_dup_list

# Generated at 2022-06-21 08:39:31.062712
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 10) == 10
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 1) == 1
    assert pct_to_int(1, 10) == 1



# Generated at 2022-06-21 08:39:37.688107
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    pct_value = 10
    assert(pct_to_int("10%", num_items) == 10)
    assert(pct_to_int("10", num_items) == 10)
    assert(pct_to_int("10.5", num_items) == 10)
    assert(pct_to_int("10%", num_items, min_value=10) == 10)
    assert(pct_to_int("1%", num_items, min_value=10) == 10)
    assert(pct_to_int("0%", num_items, min_value=10) == 10)
    assert(pct_to_int("-1%", num_items, min_value=10) == 10)

# Generated at 2022-06-21 08:39:49.210510
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj:
        def __init__(self):
            self.a = 'foo'
            self.b = 'bar'
            self.c = 'baz'

    obj = TestObj()

    # Test that the properties of the object are converted
    # to keys of the dict
    obj_dict = object_to_dict(obj)

    assert isinstance(obj_dict, dict)
    assert 'a' in obj_dict
    assert 'b' in obj_dict
    assert 'c' in obj_dict

    # test excluded attributes
    obj_dict = object_to_dict(obj, exclude=['a', 'c'])

    assert isinstance(obj_dict, dict)
    assert 'a' not in obj_dict
    assert 'b' in obj_dict
    assert 'c' not in obj_dict

# Generated at 2022-06-21 08:39:53.312384
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int(0, 10) == 1
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int(11, 10) == 11
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('101%', 10) == 11



# Generated at 2022-06-21 08:40:02.655299
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 2, 1, 5, 7, 1, 1, 5]
    assert deduplicate_list(original_list) == [1, 2, 5, 7]


# Generated at 2022-06-21 08:40:06.852655
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.hello = "world"
            self.foo = "bar"
            self._exclude_me = "baz"

    foo = Foo()
    result = object_to_dict(foo, exclude=["_exclude_me"])
    assert result["_exclude_me"] == "baz"

# Generated at 2022-06-21 08:40:19.001797
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 50) == 5
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 50) == 10
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10%', 50, min_value=1) == 5
    assert pct_to_int('10%', 50, min_value=2) == 10
    assert pct_to_int(10, 100, min_value=1) == 10
    assert pct_to_int(10, 50, min_value=1) == 10

# Generated at 2022-06-21 08:40:19.883481
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 1 == pct_to_int('0.5%', 200)

# Generated at 2022-06-21 08:40:23.505430
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create a stub class
    class Foo(object):
        def __init__(self, a, b, c=True, d='hello world'):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = Foo(1, 2)
    d = object_to_dict(obj)

    assert d == {
        'a': 1,
        'b': 2,
        'c': True,
        'd': 'hello world',
    }

# Generated at 2022-06-21 08:40:30.470912
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.0%', 100) == 10
    assert pct_to_int('20.0%', 100) == 20
    assert pct_to_int('10.0%', 100, min_value=2) == 10
    assert pct_to_int('10.0%', 10, min_value=2) == 2



# Generated at 2022-06-21 08:40:33.423638
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a_list = [1, 2, 3, 1, 2, 3]
    expected_list = [1, 2, 3]
    result = deduplicate_list(a_list)
    assert result == expected_list

# Generated at 2022-06-21 08:40:42.376948
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self, name, age, test2=None, test3=None, test4=None):
            self.name = name
            self.age = age

    test = Test("Test", 10)
    result = object_to_dict(test)
    assert result['name'] == 'Test'
    assert result['age'] == 10

    test2 = Test("Test2", 10, "test2")
    result2 = object_to_dict(test2, exclude=['test2'])
    assert result2['name'] == 'Test2'
    assert result2['age'] == 10
    assert 'test2' not in result2

# Generated at 2022-06-21 08:40:47.776125
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 1, 2, 3, 4, 3, 5, 4, 6, 5, 5, 7, 6, 8]
    assert deduplicate_list(sample_list) == [1, 2, 3, 4, 5, 6, 7, 8]




# Generated at 2022-06-21 08:40:57.953517
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(33, 100) == 33
    assert pct_to_int('33%', 100) == 33
    assert pct_to_int('33.3%', 100) == 33
    assert pct_to_int('33.9%', 100) == 34
    assert pct_to_int('101%', 100) == 100
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('101%', 100, min_value=0) == 100
    assert pct_to_int('50.5%', 100, min_value=0) == 51
    assert pct_to_int('50%', 100, min_value=0) == 50


# Generated at 2022-06-21 08:41:17.133539
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object(object):
        test_key = 'test value'
        other_key = 'other value'
    assert object_to_dict(test_object()) == {'other_key': 'other value', 'test_key': 'test value'}
    assert object_to_dict(test_object(), exclude=['other_key']) == {'test_key': 'test value'}

# Generated at 2022-06-21 08:41:24.568508
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(10, 75) == 10
    assert pct_to_int(100, 75) == 75
    assert pct_to_int(50, 75) == 38



# Generated at 2022-06-21 08:41:29.087977
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """Tests that the deduplicate_list function eliminates duplicate items and keeps
    the order the items were first seen in.
    """
    list_of_ints = [1, 2, 2, 3, 2, 1, 4, 1]
    expected = [1, 2, 3, 4]

    deduplicated_list = deduplicate_list(list_of_ints)

    assert deduplicated_list == expected
# End unit test for function deduplicate_list

# Generated at 2022-06-21 08:41:36.665663
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object:
        def __init__(self, name):
            self.name = name
            self.num = 0
            self.other_attr = 5
    obj = Object('test')
    #Excluding 'other_attr'
    obj_dict = object_to_dict(obj, exclude=['other_attr'])
    assert obj_dict['name'] == 'test'
    assert obj_dict['num'] == 0
    assert 'other_attr' not in obj_dict

# Generated at 2022-06-21 08:41:42.705037
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("15%", 1000) == 150
    assert pct_to_int("15%", 100) == 15
    assert pct_to_int("5%", 11) == 1
    assert pct_to_int("100%", 1000) == 1000
    # get the default value of 1 when the value is less than 1
    assert pct_to_int("1%", 9) == 1
    # get the default value of 1 when the value is 0
    assert pct_to_int("0%", 1000) == 1
    # get the default value of 1 when the value is less than 1
    assert pct_to_int("0.1%", 9) == 1
    # get the value when it is exactly 1
    assert pct_to_int("0.1%", 100) == 1
    #

# Generated at 2022-06-21 08:41:49.803194
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test cases for deduplicate_list()
    """
    or_list = [9, 9, 2, 3, 2]
    d_list = [9, 2, 3]
    assert d_list == deduplicate_list(or_list)

    or_list = ['x', 'y', 'z', 'y', 'x', 'X']
    d_list = ['x', 'y', 'z', 'X']
    assert d_list == deduplicate_list(or_list)


# Generated at 2022-06-21 08:41:52.969380
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj:
        one = 1
        two = 2
        three = 3
    obj = Obj()
    assert object_to_dict(obj) == {'one': 1, 'two': 2, 'three': 3}
    assert object_to_dict(obj, ['two']) == {'one': 1, 'three': 3}

# Generated at 2022-06-21 08:42:00.432436
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 20) == 2
    assert pct_to_int('91%', 20) == 2
    assert pct_to_int('91%', 100) == 91
    assert pct_to_int('100%', 20) == 2
    assert pct_to_int('1%', 20) == 1
    assert pct_to_int('0%', 20) == 1

# Generated at 2022-06-21 08:42:06.009556
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.exclude_me = None
            self.include = 'test'

    test_obj = TestObject()

    assert object_to_dict(test_obj, exclude=['exclude_me']) == {'include': 'test'}
    assert object_to_dict(test_obj) == {'exclude_me': None, 'include': 'test'}



# Generated at 2022-06-21 08:42:11.443315
# Unit test for function pct_to_int
def test_pct_to_int():
    pct_to_int(30, 100) == int((30 / 100.0) * 100)
    pct_to_int('30%', 100) == int((30 / 100.0) * 100)
    pct_to_int('100%', 100) == int(100)
    pct_to_int('0%', 100) == int(1)
    pct_to_int('30', 100) == int(30)

# Generated at 2022-06-21 08:42:40.761212
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(25, 100) == 25
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int(101, 100) == 101
    assert pct_to_int('101%', 100) == 101


# Generated at 2022-06-21 08:42:47.171466
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.attr1 = 'attr1'
            self.attr2 = 'attr2'

    obj = Obj()
    ret = object_to_dict(obj)

    assert ret is not None
    assert 'attr1' in ret
    assert 'attr2' in ret
    assert ret['attr1'] == 'attr1'
    assert ret['attr2'] == 'attr2'

# Generated at 2022-06-21 08:42:53.819986
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        # could not find a way to make pylint happy
        # pylint: disable=no-member
        member1 = 'A'
        member2 = 'B'
        member3 = ['A', 'B']

    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'member1': 'A', 'member2': 'B', 'member3': ['A', 'B']}
    assert object_to_dict(test_obj, exclude=['member1', 'member2']) == {'member3': ['A', 'B']}
    assert object_to_dict(test_obj, exclude=['member1']) == {'member2': 'B', 'member3': ['A', 'B']}



# Generated at 2022-06-21 08:42:59.610123
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list_test = deduplicate_list(["hello", "world", "hello", "world", "world", "world", "world", "hello", "hello", "world", "world", "new", "york"])

    return(deduplicate_list_test == ["hello", "world", "new", "york"])



# Generated at 2022-06-21 08:43:05.083833
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('15%', 100) == 15
    assert pct_to_int('0%', 10) == 1
    assert pct_to_int('99%', 101) == 100
    assert pct_to_int('101%', 100) == 100
    assert pct_to_int('101%', 100, min_value=0) == 101
    assert pct_to_int('1', 10) == 1
    assert pct_to_int(1, 10) == 1



# Generated at 2022-06-21 08:43:09.426557
# Unit test for function pct_to_int
def test_pct_to_int():
    assert int(pct_to_int("20%", 100)) == 20
    assert int(pct_to_int("10%", 100)) == 10
    assert int(pct_to_int("1%", 100)) == 1
    assert int(pct_to_int("0%", 100)) == 1

# Generated at 2022-06-21 08:43:13.162832
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import transform
    t = transform.Transform()
    assert object_to_dict(t, exclude=['to_json']) == {'input': None, 'output': None, 'scope': None}



# Generated at 2022-06-21 08:43:18.997009
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, a=None, b=None, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    obj = TestClass(a=1234, b=5678, c=9012, d=3456)
    obj_dict = {'a': 1234, 'b': 5678, 'c': 9012, 'd': 3456}
    assert(obj_dict == object_to_dict(obj))

    obj = TestClass(a=1234, b=5678, c=9012)
    obj_dict = {'a': 1234, 'b': 5678, 'c': 9012}
    assert(obj_dict == object_to_dict(obj))

   

# Generated at 2022-06-21 08:43:30.285607
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests for the function object_to_dict
    """
    class TestClass(object):
        def __init__(self):
            self.test_string = 'test'
            self.test_int = 123

    obj = TestClass()

    test_dict = object_to_dict(obj)
    assert 'test_string' in test_dict
    assert 'test_int' in test_dict
    assert obj.test_string == test_dict['test_string']
    assert obj.test_int == test_dict['test_int']
    assert len(test_dict) == 2

    test_dict = object_to_dict(obj, exclude=['test_string'])
    assert 'test_string' not in test_dict
    assert 'test_int' in test_dict

# Generated at 2022-06-21 08:43:40.242853
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        a = '1'
        b = '2'
        def __init__(self):
            self.c = 3
            self._d = '4'
            self._e = '5'

    tc = TestClass()

    # regular use
    result = object_to_dict(tc)
    assert result == {'a': '1', 'b': '2', 'c': 3, '_d': '4'}

    # exclude private variables
    result = object_to_dict(tc, ['_e'])
    assert result == {'a': '1', 'b': '2', 'c': 3, '_d': '4'}

    # exclude public variables
    result = object_to_dict(tc, ['b'])

# Generated at 2022-06-21 08:44:36.418686
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 60) == 30
    assert pct_to_int(0, 5) == 1
    assert pct_to_int('0%', 5) == 1
    assert pct_to_int('25%', 16) == 4
    assert pct_to_int('100%', 16) == 16
    assert pct_to_int(1, 16) == 1
    assert pct_to_int(100, 16) == 16
    assert pct_to_int('100%', 16, min_value=5) == 16
    assert pct_to_int('50%', 16, min_value=5) == 8
    assert pct_to_int('0%', 16, min_value=5) == 5


# Generated at 2022-06-21 08:44:43.969028
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100, min_value=1) == 5
    assert pct_to_int('105%', 100, min_value=1) == 100
    assert pct_to_int('15%', 10, min_value=1) == 2
    assert pct_to_int('15%', 10, min_value=5) == 5
    assert pct_to_int('15', 10, min_value=5) == 15
    assert pct_to_int('15.0', 10, min_value=5) == 15

# Generated at 2022-06-21 08:44:52.432735
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('1', 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50.0%', 100) == 50
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 100
    assert pct_to_int(101, 100) == 101
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-21 08:44:58.543451
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        a = 'a'
        b = 'b'
        c = 'c'
        # Unit test will fail on Python 3.3, since __dict__ contains the class name
        # as a key.
        _dict = {'a': 'a', 'b': 'b', 'c': 'c'} if not 'class' in dir(test_class) else {'a': 'a', 'b': 'b', 'c': 'c', 'class': 'test_class'}

        def __init__(self):
            self.d = 'd'
            self.exclude = 'exclude'
            self.excluded = 'excluded'

    test_object = test_class
    new_dict = object_to_dict(test_object)
    assert new_dict == test_object._dict



# Generated at 2022-06-21 08:45:02.592531
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [3, 1, 2, 1, 3, 3, 4, 5, 3]
    assert deduplicate_list(original_list) == [3, 1, 2, 4, 5]



# Generated at 2022-06-21 08:45:09.312902
# Unit test for function pct_to_int
def test_pct_to_int():
    # The function should raise TypeError if any non-integer value is supplied.
    # So there's not a lot we can test except for one good and one bad case.
    good = pct_to_int('50%', 50)
    assert good == 25
    try:
        bad = pct_to_int('abcd%', 50)
    except TypeError:
        pass
    else:
        raise AssertionError("pct_to_int didn't raise TypeError as expected")