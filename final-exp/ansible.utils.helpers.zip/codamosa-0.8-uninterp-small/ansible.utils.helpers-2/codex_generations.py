

# Generated at 2022-06-25 13:13:53.602462
# Unit test for function pct_to_int
def test_pct_to_int():
  assert pct_to_int("50%", 100) == 50
  assert pct_to_int("50%", 100, min_value=0) == 50
  assert pct_to_int("10%", 100) == 10
  assert pct_to_int("10%", 100, min_value=1) == 10
  assert pct_to_int("10%", 100, min_value=100) == 100
  assert pct_to_int("10%", 100, min_value=101) == 101
  assert pct_to_int("100%", 100) == 100
  assert pct_to_int("100%", 100, min_value=0) == 100
  assert pct_to_int("100%", 100, min_value=1) == 100

# Generated at 2022-06-25 13:13:58.536916
# Unit test for function object_to_dict
def test_object_to_dict():
    test_class = ClassTest()
    assert object_to_dict(test_class) == {'_prop_exclude': 'test', 'prop_0': 'test', 'prop_1': 'test'}
    assert object_to_dict(test_class, exclude=['_prop_exclude']) == {'prop_0': 'test', 'prop_1': 'test'}


# Generated at 2022-06-25 13:14:02.282290
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 4) == 2
    assert pct_to_int('150%', 4) == 6
    assert pct_to_int(150, 4) == 150
    assert pct_to_int('50', 4) == 50


# Generated at 2022-06-25 13:14:09.009701
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:14:18.767348
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('30%', 3600*24) == 25920
    assert pct_to_int('30%', 3600*24, min_value=0) == 25920
    assert pct_to_int('30%', 3600*24, min_value=10) == 25920
    assert pct_to_int('30%', 3600*24, min_value=25920) == 25920
    assert pct_to_int('30%', 3600*24, min_value=25921) == 25921
    assert pct_to_int('30%', 3600*24, min_value=2592) == 25920


# Generated at 2022-06-25 13:14:19.733550
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:14:21.319734
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-25 13:14:23.305643
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("10%", 100) == 10
    assert pct_to_int(10, 100) == 10


# Generated at 2022-06-25 13:14:25.172427
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('30%', 100) == 30
    assert pct_to_int(30, 100) == 30



# Generated at 2022-06-25 13:14:29.607403
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'aa'
            self.b = 'bb'
            self.c = 'cc'
            self.z = 'zz'

    tc = TestClass()
    d = object_to_dict(tc, exclude=['z'])
    assert d['a'] == 'aa'
    assert d['b'] == 'bb'
    assert d['c'] == 'cc'
    assert d['z'] is None

# Generated at 2022-06-25 13:14:42.198004
# Unit test for function deduplicate_list
def test_deduplicate_list():

    assert deduplicate_list([1, 2, 3, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 1]) == [1, 2, 3]

# Generated at 2022-06-25 13:14:49.890482
# Unit test for function object_to_dict
def test_object_to_dict():
    class ExampleObject(object):
        def __init__(self):
            self.first_property = 'first_property'
            self.another_property = 'another_property'
            self._property_to_exclude = 'property_to_exclude'

    example_object = ExampleObject()

    object_dict = object_to_dict(example_object, exclude=['_property_to_exclude'])

    assert len(object_dict.keys()) == 2
    assert object_dict['first_property'] == 'first_property'
    assert object_dict['another_property'] == 'another_property'
    assert '_property_to_exclude' not in object_dict.keys()



# Generated at 2022-06-25 13:14:50.569903
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()



# Generated at 2022-06-25 13:15:01.429474
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict(bytes)
    print(obj)
    assert(obj["__doc__"] == 'bytes(iterable_of_ints) -> bytes\nbytes(string, encoding[, errors]) -> bytes\nbytes(bytes_or_buffer) -> immutable copy of bytes_or_buffer\nbytes(int) -> bytes object of size given by the parameter initialized with null bytes\nbytes() -> empty bytes object\n\nConstruct an immutable array of bytes from:\n  - an iterable yielding integers in range(256)\n  - a text string encoded using the specified encoding\n  - any object implementing the buffer API.\n  - an integer')


if __name__ == '__main__':
    test_object_to_dict()
    test_case_0()

# Generated at 2022-06-25 13:15:07.962423
# Unit test for function object_to_dict
def test_object_to_dict():
  class TestClass(object):
    def __init__(self):
      self.a = 1
      self.b = 2
      self.c = 3

  test_object = TestClass()
  print(object_to_dict(test_object))
  assert object_to_dict(test_object) == {'a': 1, 'b': 2, 'c': 3}
  print(object_to_dict(test_object, ['b', 'c']))
  assert object_to_dict(test_object, ['b', 'c']) == {'a': 1}

# Generated at 2022-06-25 13:15:08.753614
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()



# Generated at 2022-06-25 13:15:18.403937
# Unit test for function object_to_dict
def test_object_to_dict():
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    var_7 = [object_0, object_1, object_2, object_3, object_4, object_5]
    var_8 = [object_5, object_6, object_7, object_8, object_9]

# Generated at 2022-06-25 13:15:23.576989
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert "U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7" == deduplicate_list(b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"), "Did not work"

# Generated at 2022-06-25 13:15:28.265605
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    try:
        var_0 = deduplicate_list(bytes_0)
        # assert var_0 == True
    except AssertionError:
        return False
    return True


# Generated at 2022-06-25 13:15:30.453025
# Unit test for function deduplicate_list
def test_deduplicate_list():

  assert(deduplicate_list([1,2,2,2,2,2,2,2,2,2,2,2,2]) == [1,2])



# Generated at 2022-06-25 13:15:36.384410
# Unit test for function deduplicate_list
def test_deduplicate_list():
    values = [u'\u00e05w\xc1\u00e7W\xa4\x87\x9f\'( \x05k\xf1\xdf\xc7']
    result = [u'\xe05w\xc1\x13W\xa4\x87\x9f\'( \x05k\xf1\xdf\xc7']
    assert deduplicate_list(values) == result

# Generated at 2022-06-25 13:15:46.845083
# Unit test for function object_to_dict
def test_object_to_dict():
    test_object = {'test_val_1' : 'test_val_1',
                   'test_val_2' : 'test_val_2',
                   'test_val_3' : 'test_val_3'}

    test_list = ['test_val_1',
                 'test_val_2',
                 'test_val_3']

    # Test with exclude list
    test_exclude_list = ['test_val_1',
                         'test_val_3']
    # Test exception with wrong type
    test_exclude_list_wrong_type = 'test_val_1'

    test_object_dict = object_to_dict(test_object)

    assert test_object_dict['test_val_1'] == 'test_val_1'

# Generated at 2022-06-25 13:15:50.912297
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    assert deduplicate_list(bytes_0) == b"U\xe05w\xc1\xe7k'( \xdf\xc7"

# Generated at 2022-06-25 13:15:56.575194
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils import nxos
    from nxos import nxos
    obj = nxos.NxosPlugin()
    test_dict = {'add_command': '',
                 'add_command_before': "",
                 'add_command_after': "",
                 'description': '',
                 'default': '',
                 'choices': None,
                 'required': True,
                 'conflicts': None}

    assert test_dict == object_to_dict(obj.argspec, exclude=["spec"])

# Generated at 2022-06-25 13:15:59.998547
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
        var_0 = deduplicate_list(bytes_0)
        assert var_0 == b'U\xe05w\xc1\xe7W\xa4\x87\x9f\'( \x05k\xf1\xdf\xc7'

    except AssertionError as e:
        print(e)
        raise AssertionError



# Generated at 2022-06-25 13:16:03.712435
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    result = deduplicate_list(bytes_0)
    assert result == bytes_0



# Generated at 2022-06-25 13:16:06.526890
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        key1 = 'value 1'
        key2 = 'value 2'
        key3 = 'value 3'

    obj = TestClass()
    var_0 = object_to_dict(obj, [])


# Generated at 2022-06-25 13:16:07.647856
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list('xyz') == 'xyz'


# Generated at 2022-06-25 13:16:08.779395
# Unit test for function object_to_dict
def test_object_to_dict():
    data = object_to_dict(test_case_0())

# Generated at 2022-06-25 13:16:11.772099
# Unit test for function deduplicate_list
def test_deduplicate_list():
    var_0 = b"\x03\x00\x00\x00\x02\x00\x00\x00"
    assert deduplicate_list(var_0) == [3, 0, 2]



# Generated at 2022-06-25 13:16:17.566734
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

# Generated at 2022-06-25 13:16:19.337890
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("Unit test for: deduplicate_list")
    test_case_0()



# Generated at 2022-06-25 13:16:25.534223
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectTest(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                self.__dict__[k] = v

    obj = ObjectTest(attribute_1=1, attribute_2=2, attribute_3=3)

    obj_dict = object_to_dict(obj)
    assert(len(obj_dict) == 3)
    assert(obj_dict['attribute_1'] == 1)
    assert(obj_dict['attribute_2'] == 2)
    assert(obj_dict['attribute_3'] == 3)

    assert('__module__' not in obj_dict)
    assert('__dict__' not in obj_dict)
    assert('__weakref__' not in obj_dict)



# Generated at 2022-06-25 13:16:35.240301
# Unit test for function object_to_dict
def test_object_to_dict():
    bytes_0 = b'+\x02~\x88d\x9b\x06\x17\xd6\xb0l\xea\xa2\x18'
    list_0 = [
        int(0x2bb3b3f3a0bf0a47),
        int(0x5e5a989cd75e912b)
    ]
    int_0 = int(0x8e644c66fe)
    bytes_1 = b'\x958\x89\xeczb\xb3\x05\xa3\x1f\xbf\x06\xea\x07'
    int_1 = int(0x8395b1a5a6)

# Generated at 2022-06-25 13:16:41.205910
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create mock inputs
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"

    # Run filter implementation
    var_0 = deduplicate_list(bytes_0)

    # Check outputs
    assert var_0 == b"U5w\xc1W\xa4\x87\x9f'( k\xf1\xdf\xc7"


# Generated at 2022-06-25 13:16:50.246841
# Unit test for function object_to_dict
def test_object_to_dict():
    try:
        import paramiko
    except ImportError as e:
        print("Skipping module object_to_dict")
        print("Requires: paramiko")
        return

    my_connection = paramiko.SSHClient()
    my_connection.set_missing_host_key_policy(
        paramiko.AutoAddPolicy())
    my_connection.load_system_host_keys()
    my_connection.connect("noc1.ansible.com", username="admin", password="password", timeout=5, compress=False)
    my_channel = my_connection.invoke_shell()
    print("")
    print("Unit test object_to_dict")
    my_dict = object_to_dict(my_channel, ["get_id", "get_name"])

# Generated at 2022-06-25 13:16:55.016834
# Unit test for function object_to_dict
def test_object_to_dict():

    from ansible.module_utils.network.junos.junos import Widget

    obj = Widget()
    output_dict = {
        'factory': None,
        'filename': None,
        'src': 'remote',
        'text': None,
        'update': False
    }

    assert object_to_dict(obj) == output_dict

    output_dict['filename'] = '/var/tmp/file'
    obj.filename = '/var/tmp/file'

    assert object_to_dict(obj) == output_dict

    output_dict.pop('filename')
    obj.filename = None

    assert object_to_dict(obj) == output_dict

    output_dict['factory'] = False
    obj.factory = False

    assert object_to_dict(obj) == output_dict




# Generated at 2022-06-25 13:16:56.635721
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert test_case_0() is not None



# Generated at 2022-06-25 13:16:57.480914
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

# Generated at 2022-06-25 13:17:04.121200
# Unit test for function object_to_dict
def test_object_to_dict():
    class class_0:
        def func_0(self):
            pass
        def func_1(self):
            pass
        def func_2(self):
            pass
        var_0 = 0
        var_1 = 1
        var_2 = 2
        var_3 = 3
    var_0 = class_0()
    result = object_to_dict(var_0, ['var_0'])
    assert result == {'var_1': 1, 'var_3': 3, 'var_2': 2}

# Generated at 2022-06-25 13:17:13.559423
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):

        def _private_method(self):
            return True

        def public_method(self):
            return True

        def __init__(self):
            self.excluded_attr = True
            self.included_attr = True

        def __repr__(self):
            return 'TestClass'

    test_class = TestClass()
    object_dict = object_to_dict(test_class, exclude=['excluded_attr'])

    assert object_dict.keys() == ['included_attr', 'public_method']



# Generated at 2022-06-25 13:17:20.698441
# Unit test for function deduplicate_list
def test_deduplicate_list():
    global bytes_0
    global var_0
    # Assignments
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"

    # Testing if the call to deduplicate_list() is correct
    var_0 = deduplicate_list(bytes_0)
    assert var_0 is not None
    # Testing if the type of the return value of deduplicate_list() is bytes
    assert type(var_0) is bytes



# Generated at 2022-06-25 13:17:21.887624
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-25 13:17:26.281250
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.one = 1
            self.two = 2
            self.three = 3

        def four(self):
            pass

    tc = TestClass()
    output = object_to_dict(tc, ['three'])

    assert output['one'] == 1
    assert 'two' in output
    assert 'three' not in output
    assert 'four' not in output

# Generated at 2022-06-25 13:17:34.334598
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object0(object):
        """
        Object instance for testing object_to_dict
        """
        def __init__(self, x, y):
            self.x = x
            self.y = y
            pass
        pass

    # Create an object instance
    object_0 = Object0(10, 20)
    # Perform the conversion
    result = object_to_dict(object_0)
    # Verify the results
    expected = {
        'x': 10,
        'y': 20
    }
    assert result == expected

if __name__ == '__main__':
    # Unit test this module
    test_case_0()
    test_object_to_dict()

# Generated at 2022-06-25 13:17:44.710278
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7") == b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    assert deduplicate_list((u'string', u'2', u'3', u'string')) == ('string', '2', '3')
    assert deduplicate_list([u'string', u'2', u'3', u'string']) == ['string', '2', '3']
    assert deduplicate_list((u'a', 2, 3, 2)) == ('a', 2, 3)

# Generated at 2022-06-25 13:17:47.279633
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        test_case_0()
    except (TypeError) as e:
        print("[-]test_deduplicate_list: TypeError exception happened, details:\n" + str(e))


# Execute main function
if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:17:50.957099
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object(object):
        a = 10
        b = [1,2,3]

    exclude = ['c']
    my_dict = {'a':10, 'b':[1,2,3]}

    assert object_to_dict(test_object, exclude) == my_dict


# Generated at 2022-06-25 13:18:00.823460
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """Test for function `deduplicate_list`"""

    bytes_0 = b'\xcf\xc7\xbe\xd3\x80\x9a\xd2\x87\xbd\x81\xbd\xb7'
    var_0 = deduplicate_list(bytes_0)
    assert var_0 == [bytes(b'\xcf'), bytes(b'\xc7'), bytes(b'\xbe'), bytes(b'\xd3'), bytes(b'\x80'), bytes(b'\x9a'), bytes(b'\xd2'), bytes(b'\x87'), bytes(b'\xbd'), bytes(b'\x81'), bytes(b'\xbd'), bytes(b'\xb7')]

# Generated at 2022-06-25 13:18:06.379036
# Unit test for function object_to_dict
def test_object_to_dict():
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    var_1 = object_to_dict(bytes_0)
    assert var_1 == b"U\\xe05w\\xc1\\xe7W\\xa4\\x87\\x9f'( \\x05k\\xf1\\xdf\\xc7"


# Generated at 2022-06-25 13:18:24.770003
# Unit test for function object_to_dict
def test_object_to_dict():
    value = getattr(__builtins__, 'True')
    value_dict = object_to_dict(value)

    assert isinstance(value_dict, dict)
    assert len(value_dict) == 14
    assert value_dict['__doc__'] is None
    assert value_dict['__hash__'] is None
    assert value_dict['__init__'] is None
    assert value_dict['__new__'] is None
    assert value_dict['__repr__'] is None
    assert value_dict['__setattr__'] is None
    assert value_dict['__sizeof__'] is None
    assert value_dict['__str__'] is None
    assert value_dict['__subclasshook__'] is None
    assert value_dict['__format__'] is None

# Generated at 2022-06-25 13:18:31.290473
# Unit test for function object_to_dict
def test_object_to_dict():
    class A(object):
        def __init__(self, a1, a2, a3):
            self.a1 = a1
            self.a2 = a2
            self.a3 = a3

    class B(object):
        def __init__(self, a1, b1, b2):
            self.a1 = a1
            self.b1 = b1
            self.b2 = b2

    class C(A):
        def __init__(self, a1, a2, a3, b1, b2, c1, c2):
            A.__init__(self, a1, a2, a3)
            self.b1 = b1
            self.b2 = b2
            self.c1 = c1
            self.c2 = c2

    test_

# Generated at 2022-06-25 13:18:38.412401
# Unit test for function deduplicate_list
def test_deduplicate_list():
    expected = ['U', 'w', 'c', '7', 'W', 'a', '4', '8', '9', 'f', '7', '39', '28', '20', '5', 'k', 'f', '1', 'd', 'c', '79']
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"
    test_case_0(bytes_0)


if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-25 13:18:39.213201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

# Generated at 2022-06-25 13:18:48.521374
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list([])
    assert type(result) is list
    assert len(result) == 0

    result = deduplicate_list([0])
    assert type(result) is list
    assert len(result) == 1
    assert result[0] == 0

    result = deduplicate_list([1, 1])
    assert type(result) is list
    assert len(result) == 1
    assert result[0] == 1

    result = deduplicate_list([0, 1])
    assert type(result) is list
    assert len(result) == 2
    assert result[0] == 0
    assert result[1] == 1

    result = deduplicate_list([0, 1, 1])
    assert type(result) is list
    assert len(result) == 2
   

# Generated at 2022-06-25 13:18:54.668471
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo:
        def __init__(self):
            self.a = 1
            self._b = 2
            self.c = 3
    foo = Foo()
    res = object_to_dict(foo, exclude=['_b'])
    assert 'a' in res
    assert 'c' in res
    assert '_b' not in res
    assert res['a'] == 1
    assert res['c'] == 3
    
    res = object_to_dict(foo)
    assert 'a' in res
    assert 'c' in res
    assert '_b' in res
    assert res['a'] == 1
    assert res['c'] == 3
    assert res['_b'] == 2

# Generated at 2022-06-25 13:19:01.419415
# Unit test for function object_to_dict
def test_object_to_dict():
    class Temp1(object):
        def __init__(self, name, address, email):
            self.name = name
            self.address = address
            self.email = email

    t = Temp1("John", "California", "john@temp.com")

    d = object_to_dict(t)
    print(d)

    d = object_to_dict(t, ["name"])
    print(d)


if __name__ == "__main__":
    test_object_to_dict()

# Generated at 2022-06-25 13:19:06.757472
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("[+] Running deduplicate_list tests")
    print("[+] Running test_case_0")
    test_case_0()
    if var_0 == b"E\x0e\xdc\xe1\xff\xa8\xb0\xc8\xdf\xee\xa0\x8d\x9c":
        print("[+] Test case 0 passed")
    else:
        print("[-] Test case 0 failed")
        print(var_0)



# Generated at 2022-06-25 13:19:10.426081
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:19:15.261879
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test to make sure byte object is handled as expected (it is converted to a list)
    expected_result = [85, 225, 95, 193, 231, 87, 164, 135, 159, 39, 40, 32, 5, 107, 241, 223, 199]
    actual_result = test_case_0()
    if actual_result == expected_result:
        print("Test case PASSED!")
    else:
        print("Test case FAILED!")

# Generated at 2022-06-25 13:19:35.827490
# Unit test for function object_to_dict
def test_object_to_dict():
    class Faux():
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'

    obj = Faux()
    dct = object_to_dict(obj)
    assert dct == {'foo': 'foo', 'bar': 'bar'}
    dct = object_to_dict(obj, exclude=['foo'])
    assert dct == {'bar': 'bar'}

# Generated at 2022-06-25 13:19:36.633797
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:19:46.474260
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:19:51.444639
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Dummy object class for testing object_to_dict
    """
    class Foo(object):
        x = 0
        y = 1
        z = 2
    res = object_to_dict(Foo())
    assert res["x"] == 0
    assert res["y"] == 1
    assert res["z"] == 2

# Unit tests for function deduplicate_list

# Generated at 2022-06-25 13:19:53.976859
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ["a","b","a","c","b","e","c","e"]
    list2 = deduplicate_list(list1)
    assert list2 == ['a', 'b', 'c', 'e']

# Generated at 2022-06-25 13:20:02.426035
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.foo = 'bar'
    class TestClassExclude():
        def __init__(self):
            self.foo = 'bar'
            self.exclude = None
            self.exclude_me = None
    obj = TestClass()
    obj2 = TestClassExclude()
    obj2.exclude = obj2.exclude_me
    assert object_to_dict(obj) == {'foo': 'bar'}
    assert object_to_dict(obj2, exclude=['exclude_me']) == {'foo': 'bar', 'exclude': None}

if __name__ == "__main__":
    import pytest
    pytest.main(["test_deduplicate_list.py"])

# Generated at 2022-06-25 13:20:11.809001
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"

# Generated at 2022-06-25 13:20:13.509298
# Unit test for function object_to_dict
def test_object_to_dict():
    class Temp:
        def __init__(self, value):
            self.x = value
    a = Temp(1)
    result = object_to_dict(a)
    print("Result: " + str(result))


# Generated at 2022-06-25 13:20:14.436865
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:20:23.319848
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:20:57.586673
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict({
        '_ansible_module': 'module',
        '_ansible_module_name': 'name',
        '_ansible_verbosity': 'verbosity',
        '_ansible_no_log': 'no_log'}) == {
            '_ansible_module': 'module',
            '_ansible_module_name': 'name',
            '_ansible_verbosity': 'verbosity',
            '_ansible_no_log': 'no_log'}


# Generated at 2022-06-25 13:21:04.266611
# Unit test for function object_to_dict
def test_object_to_dict():
    class ObjectWithProperties(object):
        def __init__(self):
            self.property_a = None
            self.property_b = None
            self.property_c = None
    obj = ObjectWithProperties()
    obj.property_a = "a"
    obj.property_b = "b"
    obj.property_c = "c"
    result = deduplicate_list(obj)
    assert list(result.keys()) == ['property_a', 'property_b', 'property_c']
    assert list(result.values()) == ['a', 'b', 'c']


# Generated at 2022-06-25 13:21:06.117923
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test different inputs
    test_case_0()


if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:21:13.439638
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self, test_str, test_str_1):
            self.test_str = test_str
            self.test_str_1 = test_str_1
            self.test_str_2 = self.test_str + self.test_str_1

    o = Obj('str', 'str_1')

    assert(object_to_dict(o) == {'test_str': 'str', 'test_str_1': 'str_1', 'test_str_2': 'strstr_1'})
    assert(object_to_dict(o, ['test_str']) == {'test_str_1': 'str_1', 'test_str_2': 'strstr_1'})

# Generated at 2022-06-25 13:21:15.567252
# Unit test for function deduplicate_list
def test_deduplicate_list():
    orig_list = ['a', 'b', 'a', 'c']
    assert ['a', 'b', 'c'] == deduplicate_list(orig_list)


# Generated at 2022-06-25 13:21:18.475292
# Unit test for function object_to_dict
def test_object_to_dict():
    class DummyClass():
        def __init__(self):
            self.a = 1
            self.b = 2

    dummy = DummyClass()
    var_0 = object_to_dict(dummy)

test_case_0()
test_object_to_dict()

# Generated at 2022-06-25 13:21:23.163414
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [1, 2, 3, 4] == deduplicate_list([1, 2, 3, 4])
    assert [1, 2, 3, 4] == deduplicate_list([1, 2, 3, 4, 3, 2, 1])
    assert [1, 2, 3, 4] == deduplicate_list([1, 1, 2, 2, 3, 3, 4, 4])

# Generated at 2022-06-25 13:21:32.872987
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass1(object):
        def __init__(self):
            self.foo = 'bar'
            self._baz = 'qux'

    my_obj = MyClass1()
    assert object_to_dict(my_obj, ['_baz']) == {'foo': 'bar'}
    my_obj2 = MyClass1()
    my_obj2._baz = 'not_secret'
    assert object_to_dict(my_obj2, ['foo', '_baz']) == {'_baz': 'not_secret'}
    my_obj3 = MyClass1()
    my_obj3._baz = 'secret'
    my_obj3.foo = 'notbar'

# Generated at 2022-06-25 13:21:38.582890
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        var_1 = "abc123"
        var_2 = "def456"

    test_case_1 = object_to_dict(TestClass())
    assert test_case == {
        'var_1': 'abc123',
        'var_2': 'def456'
    }

    test_case_2 = object_to_dict(TestClass(), exclude=['var_2'])
    assert test_case_2 == {
        'var_1': 'abc123'
    }




# Generated at 2022-06-25 13:21:41.442948
# Unit test for function deduplicate_list
def test_deduplicate_list():
    '''Test deduplicate_list function'''
    test_list = [b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"]
    assert deduplicate_list(test_list) == test_list


# Generated at 2022-06-25 13:22:53.971919
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert 0 == 0



# Generated at 2022-06-25 13:23:00.919714
# Unit test for function object_to_dict
def test_object_to_dict():
    obj_1 = object_to_dict(bytes_0, exclude=["__class__"])

# Generated at 2022-06-25 13:23:06.050973
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # pass
    y = b'U\xe05w\xc1\xe7W\xa4\x87\x9f\'( \x05k\xf1\xdf\xc7'
    assert deduplicate_list(y) == b'U5w\xc1\xe7W\xa4\x87\x9f\'( k\xf1\xdf\xc7'

# Generated at 2022-06-25 13:23:13.943513
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert len(deduplicate_list(None)) == 0, "Test: None"
    assert deduplicate_list('hello world') == ['h', 'e', 'l', 'o', ' ', 'w', 'r', 'd'], "Test: String"
    assert deduplicate_list('hello world') != ['h', 'e', 'o', 'w', 'r', 'd'], "Test: String"
    assert deduplicate_list('123') != ['1', '2'], "Test: String 123"
    assert deduplicate_list('123') == ['1', '2', '3'], "Test: String 123"
    assert deduplicate_list(123) == [], "Test: Integer"
    assert deduplicate_list(None) == [], "Test: None"
   

# Generated at 2022-06-25 13:23:15.091857
# Unit test for function object_to_dict
def test_object_to_dict():
    d = object_to_dict(test_case_0())

# Generated at 2022-06-25 13:23:22.116997
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:23:29.648552
# Unit test for function object_to_dict
def test_object_to_dict():
    from base64 import b64encode
    from sys import version_info
    from ansible.module_utils.network.common.utils import object_to_dict

    python_version = version_info[0]

    # Python3 - bytes
    py3_b1 = b'U\xe05w\xc1\xe7W\xa4\x87\x9f\'( \x05k\xf1\xdf\xc7'
    py3_b2 = b64encode(py3_b1)
    py3_h1 = '55e03757c1e757a4879f272805bf1dfc7'

# Generated at 2022-06-25 13:23:35.375538
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Setup test variables
    bytes_0 = b"U\xe05w\xc1\xe7W\xa4\x87\x9f'( \x05k\xf1\xdf\xc7"

    # Run the actual test
    deduplicate_list(bytes_0) == [b'U', b'5', b'w', b'\xc1', b'\xe7', b'W', b'\xa4', b'\x87', b'\x9f', b"'", b'(', b' ', b'\x05', b'k', b'\xf1', b'\xdf', b'\xc7']

test_case_0()

# Generated at 2022-06-25 13:23:36.431262
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-25 13:23:37.501717
# Unit test for function object_to_dict
def test_object_to_dict():
    object_0 = object_to_dict()
    assert(type(object_0) == dict)
