

# Generated at 2022-06-25 13:13:46.458270
# Unit test for function object_to_dict
def test_object_to_dict():
    from pyats.topology import Device
    from pyats.topology import loader

    testbed = loader.load('./testbed.yaml')
    device_0 = Device('Device0', testbed)

    var_0 = object_to_dict(device_0)
    var_1 = object_to_dict(device_0, exclude=['_Testbed', '_parent', '_uid'])
    var_2 = object_to_dict(testbed, exclude=['_devices', '_testbed_name'])

    assert var_0
    assert var_1
    assert var_2

# Generated at 2022-06-25 13:13:56.151422
# Unit test for function pct_to_int
def test_pct_to_int():

    # Test case from the specs
    # assert pct_to_int(50, 100) == 50, 'Expected value 50, but got {value}'.format(value=pct_to_int(50, 100))
    assert pct_to_int(50, 100) == 50, "Expected value 50, but got {value}".format(value=pct_to_int(50, 100))
    # Test percent with a decimal value (and floor the value)
    assert pct_to_int(25.65, 100) == 25, "Expected value 25, but got {value}".format(value=pct_to_int(25.65, 100))
    # Test percent with a string value
    assert pct_to_int('50%', 100) == 50, "Expected value 50, but got {value}".format

# Generated at 2022-06-25 13:14:05.445135
# Unit test for function pct_to_int
def test_pct_to_int():
    from pyVmomi import vim
    from pyVim.connect import SmartConnect, Disconnect

    # Disabling SSL certificate verification
    import ssl
    try:
        _create_unverified_https_context = ssl._create_unverified_context
    except AttributeError:
        # Legacy Python that doesn't verify HTTPS certificates by default
        pass
    else:
        # Handle target environment that doesn't support HTTPS verification
        ssl._create_default_https_context = _create_unverified_https_context

    # input params
    host = '192.168.110.136'
    user = 'root'
    passwd = '12345678'

    # connect
    si = SmartConnect(host=host,
                      user=user,
                      pwd=passwd,
                      port=443)
    # disconnect
    # Dis

# Generated at 2022-06-25 13:14:15.157773
# Unit test for function pct_to_int
def test_pct_to_int():
    value = '50%'
    num_items = 10
    min_value = 0
    assert(pct_to_int(value, num_items, min_value=0) == 5)
    assert(pct_to_int(5, num_items, min_value=0) == 5)
    assert(pct_to_int(value, num_items=2, min_value=0) == 1)
    assert(pct_to_int(value, num_items, min_value=1) == 5)
    assert(pct_to_int(1, num_items, min_value=1) == 1)
    assert(pct_to_int(value, num_items=1, min_value=1) == 1)


# Generated at 2022-06-25 13:14:25.253497
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(0, 100) == 0
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('1%', 100, 2) == 2
    assert pct_to_int(0.7, 100) == 0
    try:
        pct_to_int('invalid', 100)
    except ValueError:
        pass
    # This will raise a floating point exception because the resulting number is
    # 0.5 bytes, less than the minimum of 1 byte.

# Generated at 2022-06-25 13:14:30.072935
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10.5%', 10) == 1
    assert pct_to_int('10.5%', 0) == 0
    assert pct_to_int('10.5%', 10, min_value=2) == 2
    assert pct_to_int('-1%', 10) == 0
    assert pct_to_int('101%', 10) == 10
    assert pct_to_int('101%', 0) == 0



# Generated at 2022-06-25 13:14:33.458673
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(bool_0, exclude) == ret_0, 'Expected: {}, Got: {}'.format(ret_0, object_to_dict(bool_0, exclude))


# Generated at 2022-06-25 13:14:41.036230
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('35%', 10) == 4
    assert pct_to_int('35', 10) == 35
    assert pct_to_int('35', 10, 2) == 35
    assert pct_to_int('101%', 10) == 10
    assert pct_to_int('101%', 10, 2) == 10
    assert pct_to_int(1, 10) == 1
    assert pct_to_int(1, 10, 2) == 1
    assert pct_to_int(1, 10, 3) == 1


# Generated at 2022-06-25 13:14:43.388464
# Unit test for function pct_to_int
def test_pct_to_int():
    try:
        assert pct_to_int('', '', '')
    except TypeError:
        print('Invalid parameters')


# Generated at 2022-06-25 13:14:44.971837
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int('15%', 100)
    assert value == 15


# Generated at 2022-06-25 13:14:47.362284
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:14:52.713293
# Unit test for function object_to_dict
def test_object_to_dict():
    test_object = type('test_object', (object,), {'a': 1, 'b': 2, 'c': 3, 'd': 'yo', 'e': None})
    dict_1 = object_to_dict(test_object, exclude=['b', 'c'])
    print(dict_1)

    assert dict_1['a'] == 1
    assert dict_1['b'] == 2
    assert dict_1['c'] == 3
    assert dict_1['d'] == 'yo'
    assert dict_1['e'] is None



# Generated at 2022-06-25 13:14:55.316231
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bool_0 = None
    var_0 = deduplicate_list(bool_0)


# Generated at 2022-06-25 13:15:03.754746
# Unit test for function object_to_dict
def test_object_to_dict():
    # It should not return an empty dict when nothing is given
    if object_to_dict() != {}:
        raise Exception("It should not return an empty dict when nothing is given")

    # It should return an empty dict when None is given
    if object_to_dict(None) != {}:
        raise Exception("It should return an empty dict when None is given")

    # It should return the expected dict with an object
    name = object_to_dict(object_to_dict)
    if name['__module__'] != 'ansible.module_utils.basic':
        raise Exception("It should return the expected dict with an object")



# Generated at 2022-06-25 13:15:11.399299
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.common.utils import object_to_dict
    import unittest

    class MyClass(object):
        val = 'my_value'

    test_object = MyClass()

    def test_bad_case():
        test_output = object_to_dict(test_object, ['val'])
        assert test_output == {}, "Output is not expected"

    def test_good_case():
        test_output = object_to_dict(test_object)
        assert test_output == {'val': 'my_value'}, "Output is not expected"

    def test_case_4():
        var_0 = MyClass()
        var_1 = object_to_dict(var_0)
        var_2 = {'val': 'my_value'}

# Generated at 2022-06-25 13:15:14.799520
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_orig_list = [True, False, True, True]
    test_expected_result = [True, False]
    test_case_0(deduplicate_list(test_orig_list), test_expected_result)

# Generated at 2022-06-25 13:15:16.314582
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert callable(deduplicate_list)


# Generated at 2022-06-25 13:15:21.823369
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.var1 = 1
            self.var2 = 2
            self.var3 = 3

    test_class = TestClass()
    test_dict = {
        'var1': 1,
        'var2': 2,
        'var3': 3
    }
    assert test_dict == object_to_dict(test_class)


# Generated at 2022-06-25 13:15:26.318553
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj:
        test1 = 123
        test2 = 2
    obj = test_obj()
    result = object_to_dict(obj)
    expected = {
        'test1': 123,
        'test2': 2
    }
    assert result == expected, 'Expected: %s, Actual: %s' % (expected, result)


# Generated at 2022-06-25 13:15:27.984831
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'c', 'c'])
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-25 13:15:31.821698
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert test_case_0() == None



# Generated at 2022-06-25 13:15:38.582777
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = ["test", "test", "test", "testcase", "testcase", "test1", "test1", "test2", "test2", "test3", "test3", "test4", "test4"]
    deduped_list = deduplicate_list(my_list)

    assert(not None == deduped_list)
    assert(13 == len(my_list))
    assert(8 == len(deduped_list))
    assert(deduped_list[0] == "test")
    assert(deduped_list[1] == "testcase")
    assert(deduped_list[2] == "test1")
    assert(deduped_list[3] == "test2")
    assert(deduped_list[4] == "test3")

# Generated at 2022-06-25 13:15:44.645581
# Unit test for function object_to_dict
def test_object_to_dict():
    obj_0 = BasicUser()
    obj_0.uid = 'test'
    var_0 = obj_0.__dict__

    result = object_to_dict(obj_0)
    assert type(result) is dict

    result_keys = result.keys()
    expected_keys = var_0.keys()
    for key in result_keys:
        assert key in result
        assert key in expected_keys



# Generated at 2022-06-25 13:15:53.664961
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(None) == {}
    assert object_to_dict([]) == {}
    assert object_to_dict({'a': 1}) == {'a': 1}

# Generated at 2022-06-25 13:15:56.416784
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert callable(deduplicate_list), 'Function "deduplicate_list" is not callable'
    assert deduplicate_list(None) is None, "Function 'deduplicate_list' failed"



# Generated at 2022-06-25 13:15:58.526009
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list_0 = [None]
    result = deduplicate_list(original_list_0)
    assert result == [None]


# Generated at 2022-06-25 13:16:00.919538
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(object) is not None
"""
if __name__ == '__main__':
    test_object_to_dict()
"""

# Generated at 2022-06-25 13:16:01.790624
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()



# Generated at 2022-06-25 13:16:04.316096
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 4, 4, 6, 5, 5, 6]) == [1, 2, 3, 4, 6, 5]


# Generated at 2022-06-25 13:16:08.938318
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.junos import junos_common
    device_parameters = object_to_dict(junos_common.Device(host='1.1.1.1', username='aaa', password='bbb'))
    assert device_parameters['host'] == '1.1.1.1'
    assert device_parameters['username'] == 'aaa'
    assert device_parameters['password'] == 'bbb'

# Generated at 2022-06-25 13:16:20.368031
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['a','c','b','a','c','a','c','d','a','b','c','b','a','z','c','a','e','m','t','e']
    list2 = ['a','c','b','d','z','e','m','t']
    list3 = deduplicate_list(list1)
    assert list3 == list2



# Generated at 2022-06-25 13:16:26.139786
# Unit test for function object_to_dict
def test_object_to_dict():
    # Testing for object_to_dict(obj, exclude=None)
    obj = test_case_0()
    exclude = [3,4]
    # Testing if obj is a list or dictionary
    if isinstance(obj, (list, dict)):
        print ('object is list or dictionary')
    else:
        print ('object is not list or dictionary')

    if all(isinstance(x, int) for x in exclude):
        print ('exclude is integer')
    else:
        print ('exclude not integer')
    # Testing if exclude is a list
    if isinstance(exclude, list):
        print ('exclude is a list')
    else:
        print('exclude is not a list')
    # Testing if exclude is a list of strings

# Generated at 2022-06-25 13:16:35.717557
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'f', 'h', 'i', 'h', 'h', 'j', 'k', 'l', 'm', 'n', 'm', 'o', 'p',
              'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'u', 'a']
    ret_0 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
              'v', 'w', 'x', 'y', 'z']
    ret_1 = ded

# Generated at 2022-06-25 13:16:39.434573
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    test_0 = deduplicate_list(a)
    assert test_0 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0], "Error"


# Generated at 2022-06-25 13:16:48.836852
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:16:52.621885
# Unit test for function object_to_dict
def test_object_to_dict():
    dict1 = object_to_dict(pct_to_int)
    assert dict1.keys() == ['__name__', '__doc__', '__package__', '__loader__', '__spec__', '__builtins__', '__file__',
                            '__cached__', 'string_types', 'pct_to_int']

# Generated at 2022-06-25 13:16:54.043590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("Testing function deduplicate_list")
    assert deduplicate_list == None


# Generated at 2022-06-25 13:16:58.178782
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['list item 1','list item 2','list item 1','list item 3','list item 1','list item 4','list item 2']
    list_1 = deduplicate_list(list_0)
    assert list_1 == ['list item 1', 'list item 2', 'list item 3', 'list item 4']


# Generated at 2022-06-25 13:16:59.309144
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert 'Some objects are equal' in test_case_0()

# Generated at 2022-06-25 13:17:09.007676
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj_0(object):
        attr_1 = 'attr_1'
        attr_2 = 'attr_2'

    result = object_to_dict(Obj_0())
    assert type(result) == dict
    assert result['attr_1'] == 'attr_1'
    assert result['attr_2'] == 'attr_2'

    class Obj_1(object):
        attr_1 = 'attr_1'
        attr_2 = 'attr_2'

        def __init__(self):
            self.attr_3 = 'attr_3'

    result = object_to_dict(Obj_1())
    assert result['attr_3'] == 'attr_3'


# Generated at 2022-06-25 13:17:25.807972
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'b', 'c', 'b', 'a']

    deduplicate_list_result = deduplicate_list(list_0)

    print("\nTEST CASE 0:")
    print("Deduplicated List: ", deduplicate_list_result)

    print("\nTEST CASE 1:")
    print("Original List: ", list_0)
    test_case_0()
    print("Deduplicated List: ", deduplicate_list_result)
    print("\n")



# Generated at 2022-06-25 13:17:35.328097
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['item 0', 'item 1', 'item 2']
    list_1 = ['item 2', 'item 2', 'item 2']
    list_2 = [0, 1, 2, 3, 4]
    list_3 = [0, 0, 0, 1, 1, 2]
    list_4 = ['item 1', 'item 0', 'item 2']
    list_5 = [1, 1, 0, 0, 1, 0, 1, 0, 1, 1]
    var_0 = deduplicate_list(list_0)
    assert var_0 == ['item 0', 'item 1', 'item 2']
    var_1 = deduplicate_list(list_1)
    assert var_1 == ['item 2']
    var_2 = deduplicate_list(list_2)
   

# Generated at 2022-06-25 13:17:42.674114
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self):
            self.var1 = "Hello"
            self.var2 = "World"
            self.var3 = "!"

    my_obj = MyClass()
    my_dict = object_to_dict(my_obj, exclude=["var2"])
    assert my_dict['var1'] == 'Hello'
    assert 'var2' not in my_dict
    assert 'var3' in my_dict

test_object_to_dict()


# Generated at 2022-06-25 13:17:45.550374
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 3, 3, 4, 5]
    assert deduplicate_list(original_list) == [1, 2, 3, 4, 5]


# Generated at 2022-06-25 13:17:48.532778
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bool_0 = ['a', 'b', 'c', 'a', 'b', 'c']
    var_0 = deduplicate_list(bool_0)
    assert var_0 == ['a', 'b', 'c']



# Generated at 2022-06-25 13:17:50.326730
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(0.5) == {'real': 0.5, 'imag': 0.0}


# Generated at 2022-06-25 13:17:57.118681
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('obj', (object,), {})
    obj.prop1 = 'value1'
    obj.prop2 = 'value2'
    obj.prop3 = 'value3'

    actual_result = object_to_dict(obj, exclude=['prop2'])
    expected_result = dict(prop1='value1', prop3='value3')

    assert actual_result == expected_result

if __name__ == '__main__':
    test_object_to_dict()

# Generated at 2022-06-25 13:17:58.423925
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict('test')
    assert obj == None


# Generated at 2022-06-25 13:18:03.416790
# Unit test for function object_to_dict
def test_object_to_dict():

    class test_object:
        attr_a = 'one'
        attr_b = 'two'
        attr_c = 'three'

    result = object_to_dict(test_object)
    assert result['attr_a'] == 'one'
    assert result['attr_b'] == 'two'
    assert result['attr_c'] == 'three'



# Generated at 2022-06-25 13:18:06.290017
# Unit test for function deduplicate_list
def test_deduplicate_list():
    var_1 = ["a", "b", "a", "c", "b"]
    var_0 = deduplicate_list(var_1)
    assert var_0 == ["a", "b", "c"]


# Generated at 2022-06-25 13:18:44.459553
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['test1', 'test2', 'test3', 'test3', 'test3', 'test1', 'test4', 'test4']
    var_0 = deduplicate_list(list_0)
    assert var_0 == ['test1', 'test2', 'test3', 'test4']

    list_0 = ['test1', 'test2', 'test3', 'test4']
    var_0 = deduplicate_list(list_0)
    assert var_0 == ['test1', 'test2', 'test3', 'test4']

    list_0 = ['test1', 'test1', 'test1', 'test1']
    var_0 = deduplicate_list(list_0)
    assert var_0 == ['test1']

    list_0 = ['test2']

# Generated at 2022-06-25 13:18:49.218800
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj_1:
        var_0 = 'var_0'
        var_1 = 3
        var_2 = 'var_2'
        var_3 = obj_1

    var_0 = object_to_dict(obj_1, ['var_0', 'var_2'])

    assert var_0 == {'var_1': 3, 'var_3': obj_1}



# Generated at 2022-06-25 13:18:51.981851
# Unit test for function object_to_dict
def test_object_to_dict():
    # Module should return a dictionary when non-empty list is passed
    assert isinstance(object_to_dict(list(['test']), []), dict)

    # Module should return a dictionary when non-empty list with excludes is passed
    assert isinstance(object_to_dict(list(['test']), ['test']), dict)


# Generated at 2022-06-25 13:18:53.138575
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = []

    assert object_to_dict(obj) == {}


# Generated at 2022-06-25 13:18:54.055164
# Unit test for function object_to_dict
def test_object_to_dict():
    assert callable(object_to_dict)

test_case_0()

# Generated at 2022-06-25 13:18:59.582940
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = {'name': 'my_device', 'interface': 'eth0/1', 'mode': 'access', 'access_vlan': 10}
    obj = object_to_dict(obj)
    expected = {'interface': 'eth0/1', 'access_vlan': 10, 'name': 'my_device', 'mode': 'access'}
    assert obj == expected, 'Got {}'.format(obj)


# Generated at 2022-06-25 13:19:08.406615
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(['_', '_']) == {'': None, '_': None}
    assert object_to_dict(['--', '--']) == {'': None, '--': None}
    assert object_to_dict(['__', '__']) == {'': None, '__': None}
    assert object_to_dict(['__', '__']) == {'': None, '__': None}
    assert object_to_dict(['/', '/']) == {'': None, '/': None}
    assert object_to_dict(['_/', '_/']) == {'': None, '_/': None}
    assert object_to_dict(['_/__', '_/__']) == {'': None, '_/__': None}
    assert object

# Generated at 2022-06-25 13:19:15.309571
# Unit test for function deduplicate_list
def test_deduplicate_list():

  # Setup the test case
    bool_0 = []
    var_0 = deduplicate_list(bool_0)
    assert var_0 == []

  # Setup the test case
    bool_0 = [1, 1, 2, 2, 3, 4, 5, 6]
    var_0 = deduplicate_list(bool_0)
    assert var_0 == [1, 2, 3, 4, 5, 6]

  # Setup the test case
    bool_0 = [1]
    var_0 = deduplicate_list(bool_0)
    assert var_0 == [1]

# Generated at 2022-06-25 13:19:19.308219
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:19:29.248654
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bool_0 = []
    var_0 = deduplicate_list(bool_0)
    bool_0 = ['foo', 'bar', 'baz', 'foo']
    var_0 = deduplicate_list(bool_0)
    bool_0 = ['foo', 'bar', 'baz', 'foo']
    var_0 = deduplicate_list(bool_0)
    bool_0 = ['foo', 'bar', 'baz', 'foo']
    var_0 = deduplicate_list(bool_0)
    bool_0 = ['foo', 'bar', 'baz', 'foo', 'bar']
    var_0 = deduplicate_list(bool_0)
    bool_0 = ["foo"]
    var_0 = deduplicate_list(bool_0)
    bool

# Generated at 2022-06-25 13:20:41.961923
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleObject(object):
        attr1 = 1
        attr2 = 2
        attr3 = 3

        def __init__(self):
            self.attr4 = 4

    expected_result = {'attr1': 1, 'attr2': 2, 'attr3': 3, 'attr4': 4}

    result = object_to_dict(SampleObject())

    assert result == expected_result


# Generated at 2022-06-25 13:20:43.111778
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert(True)



# Generated at 2022-06-25 13:20:44.867796
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(test_case_0).keys()==['bool_0', 'var_0']


# Generated at 2022-06-25 13:20:48.637467
# Unit test for function deduplicate_list
def test_deduplicate_list():
    items = ['Billie Jean', 'Billie Jean', 'Smells Like Teen Spirit', 'Billie Jean', 'Smells Like Teen Spirit', 'Smells Like Teen Spirit']
    # check results
    assert deduplicate_list(items) == ['Billie Jean', 'Smells Like Teen Spirit']



# Generated at 2022-06-25 13:20:49.810264
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert isinstance(deduplicate_list(None), list)

# Generated at 2022-06-25 13:20:51.501421
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:20:56.661492
# Unit test for function object_to_dict
def test_object_to_dict():
    
    class TestObject(object):
        
        def __init__(self, a, b, c):
            self.c = c
            self.a = b
            self.b = a
    
    
    obj_0 = TestObject(a='a', b='b', c='c')
    dict_0 = object_to_dict(obj_0)
    
    


# Generated at 2022-06-25 13:21:05.255536
# Unit test for function object_to_dict
def test_object_to_dict():
    app_obj = {
        '2': {
            'ball': '1',
            'type': '3'
        },
        '3': {
            'ball': '2',
            'bat': '1',
            'type': '1'
        },
        '4': {
            'ball': '2',
            'bat': '1',
            'hat': '3',
            'type': '2'
        }
    }
    app_keys = var_0
    expected = {
        '2': '3',
        '3': '1',
        '4': '2'
    }
    result = object_to_dict(app_obj, app_keys)

# Generated at 2022-06-25 13:21:12.975969
# Unit test for function object_to_dict
def test_object_to_dict():
    # Get the original object
    original_obj = Object()

    # Exclude certain attributes
    excluded = ['_excluded_0', '_excluded_1']

    # Get the dict representation with excluded attributes
    dict_repr = object_to_dict(original_obj, excluded)

    # The dict should have the same number of keys as the objects number of attributes minus the number of excluded
    # attributes
    assert len(dict_repr) == len(dir(original_obj)) - len(excluded)

    # All the keys in the dict representation should be the objects attributes minus the excluded attributes
    for key in dict_repr:
        assert key in dir(original_obj) and key not in excluded

    # All the values should be equal to the object's attribute values

# Generated at 2022-06-25 13:21:16.166583
# Unit test for function deduplicate_list
def test_deduplicate_list():
    num_0 = ['host1', 'host1', 'host2', 'host3', 'host3']
    list_0 = deduplicate_list(num_0)
    assert list_0 == ['host1', 'host2', 'host3']
