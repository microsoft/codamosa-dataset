

# Generated at 2022-06-25 13:13:46.124430
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('2%', 100) == 2
    assert pct_to_int('77%', 100) == 77
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 101

# Generated at 2022-06-25 13:13:50.020201
# Unit test for function object_to_dict
def test_object_to_dict():
    class X(object):
        def __init__(self):
            self.val = 5
            self.prop = "hello"

    x = X()
    result = object_to_dict(x, exclude=["prop"])
    assert result["val"] == 5
    assert not "prop" in result


# Generated at 2022-06-25 13:13:53.975108
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 20, 2) == 4
    assert pct_to_int('10%', 20, 4) == 4
    assert pct_to_int('50%', 20, 1) == 10

test_case_0()

# Generated at 2022-06-25 13:14:03.391014
# Unit test for function pct_to_int
def test_pct_to_int():
    # check if the function returns 1 for 1%
    assert pct_to_int('1%', 100) == 1, "The output should be 1"

    # check if the function returns 4 for 4%
    assert pct_to_int('4%', 100) == 4, "The output should be 4"

    # check if the function returns 50 for 50%
    assert pct_to_int('50%', 100) == 50, "The output should be 50"

    # check if the function returns 100 for 100%
    assert pct_to_int('100%', 100) == 100, "The output should be 100"

    # check if the function returns 1 for 0%
    assert pct_to_int('0%', 100) == 1, "The output should be 1"

    # check if the function raises value error for 101%
   

# Generated at 2022-06-25 13:14:04.974490
# Unit test for function pct_to_int
def test_pct_to_int():
    value = '75%'
    num_items = 24
    result = pct_to_int(value, num_items)
    assert result == 18


# Generated at 2022-06-25 13:14:14.994514
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert(deduplicate_list([]) == [])
    assert(deduplicate_list(["1", "2", "1", "2", "1", "2"]) == ["1", "2"])
    assert(deduplicate_list(["1", "1", "1", "1", "1", "1"]) == ["1"])
    assert(deduplicate_list(["1", "2", "3", "4", "5", "6"]) == ["1", "2", "3", "4", "5", "6"])
    assert(deduplicate_list([]) == [])
    assert(deduplicate_list(["1", "2", "1", "2", "1", "2"]) == ["1", "2"])

# Generated at 2022-06-25 13:14:25.092478
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("2%", num_items=4, min_value=1) == 1
    assert pct_to_int("50%", num_items=4, min_value=1) == 2
    assert pct_to_int("150%", num_items=4, min_value=1) == 6
    assert pct_to_int("0%", num_items=4, min_value=1) == 1
    assert pct_to_int("100%", num_items=4, min_value=1) == 4
    assert pct_to_int("101%", num_items=4, min_value=1) == 5
    assert pct_to_int("-1%", num_items=4, min_value=1) == 1

# Generated at 2022-06-25 13:14:25.772982
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 1) == 1


# Generated at 2022-06-25 13:14:34.338770
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(1, 10) == 1
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int(2, 3) == 2
    assert pct_to_int('2%', 3) == 2
    assert pct_to_int(0, 100) == 1
    assert pct_to_int('0%', 100) == 1


# Generated at 2022-06-25 13:14:40.021068
# Unit test for function pct_to_int
def test_pct_to_int():
  assert pct_to_int(100,100,10) == 100
  assert pct_to_int(50,100,10) == 50
  assert pct_to_int(5,100,10) == 5
  assert pct_to_int(5,100) == 5
  assert pct_to_int('10%',100,10) == 10
  assert pct_to_int('100%',100,10) == 100


# Generated at 2022-06-25 13:14:47.444818
# Unit test for function object_to_dict
def test_object_to_dict():
    class test(object):

        def __init__(self, test1):
            self.test1 = test1
            self.test2 = None
            self.test3 = None

    test_obj = test('test1')
    assert object_to_dict(test_obj) == {'test1': 'test1', 'test2': None, 'test3': None}
    assert object_to_dict(test_obj, exclude=['test1']) == {'test2': None, 'test3': None}



# Generated at 2022-06-25 13:14:48.364250
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(test_case_0, exclude=None) == {'original_list': (), 'seen': set()}


# Generated at 2022-06-25 13:14:49.510418
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(tuple_0) == tuple_0

# Generated at 2022-06-25 13:14:54.959379
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1])
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]) != [5, 4, 3, 2, 1]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]) != [5, 4, 3, 2, 1]




# Generated at 2022-06-25 13:15:00.287919
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["a", "b"]
    deduplicate_list(original_list)
    original_list = ["b", "a"]
    deduplicate_list(original_list)
    original_list = ["a", "a", "b"]
    deduplicate_list(original_list)



# Generated at 2022-06-25 13:15:02.162465
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass(object):
        def __init__(self, name):
            self.name = name

    obj = MyClass('test')
    dict_ = object_to_dict(obj)
    assert dict_.get('name') == 'test'

# Generated at 2022-06-25 13:15:07.962103
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 3, 3, 2, 1, 1, 3, 2]) == [1, 3, 2]
    assert deduplicate_list([1, 3, 3, 2, 1, 1, 3, 2]) != [1, 2, 3]

# Generated at 2022-06-25 13:15:11.931232
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'a', 'b', 'c', 'd', 'e', 'd', 'e']
    var_0 = deduplicate_list(list_0)
    var_5 = deduplicate_list(var_0)
    print("Deduplicated list: " + str(var_0))


# Generated at 2022-06-25 13:15:18.771435
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    value = object_to_dict(obj)
    assert value == {}

    obj = type('test_object', (object,), {'test_key': 'test_val'})()
    value = object_to_dict(obj)
    assert value == {'test_key': 'test_val'}

    obj = type('test_object', (object,), {'test_key': 'test_val'})()
    value = object_to_dict(obj, ['test_key'])
    assert value == {}



# Generated at 2022-06-25 13:15:21.119464
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:15:25.374995
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = ('test', 1, 'test', 2, 'test', 'test')
    assert deduplicate_list(tuple_0) == ['test', 1, 2]


# Generated at 2022-06-25 13:15:33.050262
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['d', 'a', 'b', 'c', 'a', 'b', 'b']) == ['d', 'a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'b', 'a', 'c', 'd', 'd', 'd']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 13:15:41.386008
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Testing when original_list = ()
    tuple_0 = ()
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == ()

    # Testing when original_list = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2)
    tuple_1 = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2)
    var_1 = deduplicate_list(tuple_1)
   

# Generated at 2022-06-25 13:15:51.351122
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1,2,3]
    dict_0 = {'one': 1, 'two': 2, 'three': 3, 'four': 'four'}
    tuple_0 = (1,2,3,4)
    set_0 = set([1,2,3,4])
    str_0 = 'this is a test string'
    test_0 = deduplicate_list(list_0)
    assert test_0 == [1,2,3]
    test_1 = deduplicate_list(dict_0)
    assert test_1 == [1,2,3, 'four']
    test_2 = deduplicate_list(tuple_0)
    assert test_2 == [1,2,3,4]

# Generated at 2022-06-25 13:15:57.570661
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 6, 1, 2, 3, 4, 5, 6]
    deduplicated_list = deduplicate_list(original_list)

    assert (1 in deduplicated_list)
    assert (2 in deduplicated_list)
    assert (3 in deduplicated_list)
    assert (4 in deduplicated_list)
    assert (5 in deduplicated_list)
    assert (6 in deduplicated_list)

    assert (len(deduplicated_list) == 6)


# Generated at 2022-06-25 13:16:03.257660
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Generate the base tuple to test
    tuple_0 = (1, 2, 3, 4, 5)

    # Generate expected tuple
    expected_tuple = tuple_0

    # Generate the test tuple
    var_0 = deduplicate_list(tuple_0)

    # Verify the original tuple is not modified
    assert tuple_0 == expected_tuple

    # Verify the returned tuple
    assert var_0 == expected_tuple


# Generated at 2022-06-25 13:16:06.091183
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 4, 5, 3, 4]
    new_list = deduplicate_list(test_list)
    assert new_list == [1, 2, 3, 4, 5]



# Generated at 2022-06-25 13:16:14.763126
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1,2,3,4,5,6]) == [1,2,3,4,5,6]

# Generated at 2022-06-25 13:16:23.215608
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = []
    var_0 = deduplicate_list(list_0)
    assert isinstance(var_0, list)
    assert var_0 == []

    list_0 = [1, 2, 3, 4, 5]
    var_0 = deduplicate_list(list_0)
    assert isinstance(var_0, list)
    assert var_0 == [1, 2, 3, 4, 5]

    list_0 = [1, 2, 3, 2, 4, 5]
    var_0 = deduplicate_list(list_0)
    assert isinstance(var_0, list)
    assert var_0 == [1, 2, 3, 4, 5]

    list_0 = [1, 2, 3, 4, 5, 5]
    var_0 = ded

# Generated at 2022-06-25 13:16:32.880900
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestClass(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    obj = TestClass(option1='foo', option2='bar', option3='baz')
    dict_0 = object_to_dict(obj)
    assert dict_0.get('option1') == 'foo'
    assert dict_0.get('option2') == 'bar'
    assert dict_0.get('option3') == 'baz'

    dict_1 = object_to_dict(obj, exclude=['option2'])
    assert dict_1.get('option1') == 'foo'
    assert dict_1.get('option2') is None
    assert dict_1.get('option3') == 'baz'


# Generated at 2022-06-25 13:16:41.443480
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass:

        def __init__(self):
            self.one = "one"
            self.two = "two"
            self.three = "three"

    class_instance = MyClass()

    assert object_to_dict(class_instance) == {'one': 'one', 'three': 'three', 'two': 'two'}
    assert object_to_dict(class_instance, exclude=["one", "three"]) == {'two': 'two'}



# Generated at 2022-06-25 13:16:50.471776
# Unit test for function object_to_dict
def test_object_to_dict():
    test_object_1 = type('test_object_1', (object,), {'test_attribute_1': "test_attribute_value_1", 'test_attribute_2': "test_attribute_value_2"})
    test_object_2 = type('test_object_2', (object,), {'test_attribute_1': "test_attribute_value_1", 'test_attribute_2': "test_attribute_value_2"})
    test_object_1_dict = object_to_dict(test_object_1)
    test_object_2_dict = object_to_dict(test_object_2)
    if test_object_1_dict['test_attribute_1'] != "test_attribute_value_1":
        raise AssertionError()

# Generated at 2022-06-25 13:16:51.792781
# Unit test for function object_to_dict
def test_object_to_dict():
    param_0 = {'param_0': None}
    return object_to_dict(param_0)


# Generated at 2022-06-25 13:16:56.716440
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = ()
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == tuple_0, 'expected {}, got {} when calling \'deduplicate_list\' with the following parameters: tuple_0 = {}'.format(tuple_0, var_0, tuple_0)


if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:17:01.990990
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,2,2,3,3]) == [1,2,3], "Failed to deduplicate list with function deduplicate_list"
    assert deduplicate_list([]) == [], "Failed to deduplicate empty list with function deduplicate_list"

test_case_0()
test_deduplicate_list()

# Generated at 2022-06-25 13:17:02.852032
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

# Generated at 2022-06-25 13:17:08.066776
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_obj:
        def __init__(self):
            self.a = 'vala'
            self.b = 'valb'
            self.c = 'valc'
    tmp_obj = test_obj()
    ref_dict = {'a': 'vala', 'b': 'valb', 'c': 'valc'}
    tmp_dict = object_to_dict(tmp_obj)
    assert ref_dict == tmp_dict


# Generated at 2022-06-25 13:17:12.262777
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        int_val = 1
        string_val = "string"
    obj = TestObject()
    assert object_to_dict(obj) == {"int_val": 1, "string_val": "string"}
    assert object_to_dict(obj, exclude=["int_val"]) == {"string_val": "string"}



# Generated at 2022-06-25 13:17:16.111932
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:

        def __init__(self):
            self.var1 = 'Example_1'
            self.var2 = 'Example_2'

    obj = Test()
    assert object_to_dict(obj) == {'var1': 'Example_1', 'var2': 'Example_2'}

# Generated at 2022-06-25 13:17:16.994921
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:17:25.614309
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 9, 1, 0, 8, 4, 5, 8, 9, 9, 4, 1]
    var_0 = deduplicate_list(list_0)
    assert var_0 == [1, 9, 0, 8, 4, 5]



# Generated at 2022-06-25 13:17:31.377364
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self._d = 'd'

    test_obj = TestObj()

    result = object_to_dict(test_obj)
    expected = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert result == expected

    result = object_to_dict(test_obj, exclude=['a', 'b', 'c', 'd'])
    expected = {}
    assert result == expected

    result = object_to_dict(test_obj, exclude=['d'])
    expected = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert result == expected


# Generated at 2022-06-25 13:17:35.925438
# Unit test for function object_to_dict
def test_object_to_dict():
    _object_to_dict = meraki.modules.object_to_dict
    exclude = (
        'exclude',
        'obj',
        'return',
    )
    obj = meraki.models.object_to_dict.ObjectToDict()

# Generated at 2022-06-25 13:17:40.836021
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = [ 1, 2, 3, 4, 5, 5, 4, 3, 3, 2, 1, 2, 3, 5, 6 ]
    expected_list = [1, 2, 3, 4, 5, 6]
    actual_list = deduplicate_list(list)
    assert actual_list == expected_list


# Generated at 2022-06-25 13:17:46.823602
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list((1,2,3,4,5,6,7,8,9,10)) == [1,2,3,4,5,6,7,8,9,10]
    assert deduplicate_list((1,2,3,4,5,6,7,8,9,10,4,5,6,7,8,9,10)) == [1,2,3,4,5,6,7,8,9,10]

# Generated at 2022-06-25 13:17:57.038778
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list((1, 2)) == [1, 2]
    assert deduplicate_list(['1', '2']) == ['1', '2']
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list(['1', '2', '1']) == ['1', '2']
    assert deduplicate_list([1, 2, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 1]) == [1, 2]

# Generated at 2022-06-25 13:18:06.419047
# Unit test for function object_to_dict
def test_object_to_dict():
    print('Test object_to_dict')
    class TestObj:
        def __init__(self):
            self.name = 'test'
            self.id = 1
            self._foo = 'bar'
            self._bar = None
    test_obj = TestObj()
    dict_0 = object_to_dict(test_obj)
    assert(dict_0['name'] == 'test')
    assert(dict_0['id'] == 1)
    assert('_foo' not in dict_0.keys())
    assert('_bar' not in dict_0.keys())

    dict_1 = object_to_dict(test_obj, ['_foo'])
    assert(dict_1['name'] == 'test')
    assert(dict_1['id'] == 1)

# Generated at 2022-06-25 13:18:12.472312
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("\n\n####################### [START] test_deduplicate_list ##########################\n")
    tuple_0 = (1, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert deduplicate_list(tuple_0) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    tuple_1 = ('applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied')
    assert deduplicate_list(tuple_1) == ['applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied', 'applied']

    list_0 = []
    assert deduplicate

# Generated at 2022-06-25 13:18:20.389443
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(object()).keys() == ['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__',
                                               '__gt__', '__hash__', '__init__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__',
                                               '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__']



# Generated at 2022-06-25 13:18:26.144016
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.network.jnpr.junos.facts.swver import SwVer

    obj = SwVer({})
    obj.text = 'test string'
    obj.image = 'test string'
    obj.object = 'test string'

    actual = object_to_dict(obj)
    expected = {'text': 'test string', 'image': 'test string', 'object': 'test string'}
    assert actual == expected

# Generated at 2022-06-25 13:18:47.652108
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = (1, 2, 3, 4, 5)
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == tuple_0
    tuple_1 = (1, 1, 1, 2, 3, 3, 4, 5, 5, 5)
    var_1 = deduplicate_list(tuple_1)
    assert var_1 == (1, 2, 3, 4, 5)

# Generated at 2022-06-25 13:18:52.851972
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = (["a", "b", "c", "c", "d"],)
    var_0 = deduplicate_list(tuple_0)
    assert var_0[0] == ["a", "b", "c", "d"]

    tuple_1 = (["c", "b", "c", "c", "d"],)
    var_1 = deduplicate_list(tuple_1)
    assert var_1[0] == ["c", "b", "d"]



# Generated at 2022-06-25 13:18:55.005865
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = ('spam', 'ham', 'spam')
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == ('spam', 'ham')




# Generated at 2022-06-25 13:18:58.111392
# Unit test for function object_to_dict
def test_object_to_dict():

    class Test:
        def __init__(self):
            self.test = 'test'
            return

    assert object_to_dict(Test) == {'test': 'test'}



# Generated at 2022-06-25 13:19:07.103220
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'b', 'c', 'a', 'a', 'b', 'c']
    deduplicate_list_0 = deduplicate_list(list_0)
    # assert deduplicate_list_0 == ['a', 'b', 'c'], 'Expected: %s, Actual: %s' % (['a', 'b', 'c'], deduplicate_list_0)
    list_1 = ['a', 'a', 'a', 'a', 'a']
    deduplicate_list_1 = deduplicate_list(list_1)
    # assert deduplicate_list_1 == ['a'], 'Expected: %s, Actual: %s' % (['a'], deduplicate_list_1)

# Generated at 2022-06-25 13:19:13.653544
# Unit test for function object_to_dict
def test_object_to_dict():
    class Mock(object):
        pass

    obj = Mock()
    obj.name = 'joe'
    obj.age = 22
    obj.address = '123 street'

    result = object_to_dict(obj)
    assert result['name'] == 'joe'
    assert result['age'] == 22
    assert result['address'] == '123 street'

    result = object_to_dict(obj, exclude=['address'])
    assert result['name'] == 'joe'
    assert result['age'] == 22
    assert result.get('address') is None



# Generated at 2022-06-25 13:19:17.986589
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:19:21.358324
# Unit test for function deduplicate_list
def test_deduplicate_list():
    args = ()
    if not isinstance(deduplicate_list(), list):
        raise AssertionError(
            "Expected {}, got {}".format(
                'list',
                type(deduplicate_list())
            )
        )



# Generated at 2022-06-25 13:19:26.682038
# Unit test for function object_to_dict
def test_object_to_dict():
    assert None == object_to_dict("TestString")
    assert None == object_to_dict("String")
    cli_device = object_to_dict("String")
    if cli_device is not None:
        raise Exception("Expected None but got {0}".format(cli_device))

if __name__ == "__main__":
    test_object_to_dict()
    test_case_0()

# Generated at 2022-06-25 13:19:29.741679
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict('test') == {}
    assert object_to_dict('test', ['a']) == {}
    assert object_to_dict(object()) == {}
    assert object_to_dict(object(), ['a']) == {}



# Generated at 2022-06-25 13:20:10.800691
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(()) == {}
    assert object_to_dict((), exclude=[]) == {}

# Generated at 2022-06-25 13:20:14.052156
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass():
        def __init__(self):
            self.test_var = 0
            self.test_var2 = 1

    test_obj = TestClass()
    assert(object_to_dict(test_obj) == {"test_var": 0, "test_var2": 1})


# Generated at 2022-06-25 13:20:16.832094
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        name = 'name'
        age = 25

    obj = A()
    result = object_to_dict(obj)
    expect = {'name': 'name', 'age': 25}
    assert result == expect

# Generated at 2022-06-25 13:20:19.176460
# Unit test for function deduplicate_list
def test_deduplicate_list():
    hints = globals()
    for var, val in hints.items():
        if var.startswith("test_case_"):
            locals()[var]()



# Generated at 2022-06-25 13:20:24.697141
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, attr_1, **kwargs):
            self.attr_1 = attr_1
            self.kwargs = kwargs
    obj = TestClass(attr_1='attr1', attr2='attr2', attr3='attr3')
    ans = object_to_dict(obj, exclude=['kwargs'])
    assert(ans == {'attr_1': 'attr1'})



# Generated at 2022-06-25 13:20:25.574822
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

# Generated at 2022-06-25 13:20:34.376311
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == [], "Worng output: function deduplicate_list"
    assert deduplicate_list([1]) == [1], "Worng output: function deduplicate_list"
    assert deduplicate_list([1, 1, 1, 1.0, 1, 1]) == [1], "Worng output: function deduplicate_list"
    assert deduplicate_list(["1", 1, "1", 1, 1.0, 1, 1]) == [1, "1"], "Worng output: function deduplicate_list"
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5], "Worng output: function deduplicate_list"
    assert dedu

# Generated at 2022-06-25 13:20:38.396982
# Unit test for function deduplicate_list
def test_deduplicate_list():
    var_0 = ["c","b","a","a","b","c"]
    var_1 = deduplicate_list(var_0)
    assert var_1 == ["c","b","a"]
    var_2 = ["z","y","x","w","v","v","u","t","s","s","s"]
    var_3 = deduplicate_list(var_2)
    assert var_3 == ["z","y","x","w","v","u","t","s"]


# Generated at 2022-06-25 13:20:41.075045
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(()) is None, "func_0_0"
    assert deduplicate_list((1, 2, )) is None, "func_0_1"


# Generated at 2022-06-25 13:20:49.906275
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = []
    var_0 = deduplicate_list(list_0)
    assert var_0 == []

    list_1 = [('a', 'b', 'c')]
    var_1 = deduplicate_list(list_1)
    assert var_1 == [('a', 'b', 'c')]

    list_2 = [('d', 'e', 'f'), ('a', 'b', 'c')]
    var_2 = deduplicate_list(list_2)
    assert var_2 == [('d', 'e', 'f'), ('a', 'b', 'c')]

    list_3 = [('d', 'e', 'f'), ('a', 'b', 'c'), ('d', 'e', 'f')]
    var_3 = deduplicate_

# Generated at 2022-06-25 13:22:22.162043
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = (1, 2, 3, 4, 5)
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == tuple_0, "deduplicate_list() did not work as expected"
    tuple_1 = (1, 2, 1, 4, 5)
    var_1 = deduplicate_list(tuple_1)
    assert var_1 == (1, 2, 4, 5), "deduplicate_list() did not work as expected"
    tuple_2 = (1, 1, 1, 1, 1)
    var_2 = deduplicate_list(tuple_2)
    assert var_2 == (1,), "deduplicate_list() did not work as expected"
    tuple_3 = ()
    var_3 = dedu

# Generated at 2022-06-25 13:22:25.312586
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert len(deduplicate_list((1,))) == 1
    assert deduplicate_list((1, 2)) == [1, 2]
    assert deduplicate_list((1, 2, 2, 3, 2)) == [1, 2, 3]

# Generated at 2022-06-25 13:22:28.863741
# Unit test for function deduplicate_list
def test_deduplicate_list():
    tuple_0 = ()
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == tuple_0
    tuple_0 = ("value")
    var_0 = deduplicate_list(tuple_0)
    assert var_0 == tuple_0

# Generated at 2022-06-25 13:22:37.173483
# Unit test for function deduplicate_list
def test_deduplicate_list():
    out = deduplicate_list(())
    assert out == ()
    assert type(out) is tuple
    out = deduplicate_list((1, 2, 3))
    assert out == (1, 2, 3)
    assert type(out) is tuple
    out = deduplicate_list((1, 2, 2, 3))
    assert out == (1, 2, 3)
    assert type(out) is tuple
    out = deduplicate_list((1, 2, 2, 3, 3))
    assert out == (1, 2, 3)
    assert type(out) is tuple
    out = deduplicate_list((1, 2, 2, 3, 3, 3))
    assert out == (1, 2, 3)
    assert type(out) is tuple
    out = deduplicate_

# Generated at 2022-06-25 13:22:43.434592
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(None) == []
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 2, 3, 3, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-25 13:22:50.586065
# Unit test for function object_to_dict
def test_object_to_dict():
    class test0(object):
        def __init__(self):
            self.test = 'test'
            self.test1 = 'test1'

    class test1(object):
        def __init__(self):
            self.test = 'test'
            self.test1 = 'test1'

    assert object_to_dict(test0()) == {'test': 'test', 'test1': 'test1'}
    assert object_to_dict(test1(), ['test']) == {'test1': 'test1'}

# Generated at 2022-06-25 13:22:56.450608
# Unit test for function object_to_dict
def test_object_to_dict():
    # Default test
    class A ():
        a = "AAA"
        b = ["BBB", "BBB"]
        c = "CCC"
        def __init__(self):
            self.a = "AAA"
            self.b = ["BBB", "BBB"]
            self.c = "CCC"

    obj = A()
    result = object_to_dict(obj)
    expected = {'a': 'AAA', 'b': ['BBB', 'BBB'], 'c': 'CCC'}

    assert result == expected


# Generated at 2022-06-25 13:23:01.154472
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('TestObj', (object,), {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'})
    assert object_to_dict(obj, exclude=None) == {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    assert object_to_dict(obj, exclude=['var2']) == {'var1': 'value1', 'var3': 'value3'}
    assert object_to_dict(obj, exclude=['var1', 'var2', 'var3']) == {}



# Generated at 2022-06-25 13:23:03.217012
# Unit test for function object_to_dict
def test_object_to_dict():
    assert(object_to_dict(test_case_0()) == {})


# Generated at 2022-06-25 13:23:11.658198
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ["a", "b", "a", "c", "a", "b", "c"]
    list_1 = ["a"]
    list_2 = ["a", "b"]
    list_3 = ["a", "a", "a", "a", "b", "b", "a"]
    list_4 = [0, None, 0, None, None, 1, 2]
    list_5 = ["a"]
    list_6 = [""]
    list_7 = ["a", "b", "c", "a", "b", "c"]
    list_8 = ["a", "b"]
    list_9 = ["a", "a", "b", "b", "a", "b"]
    print(deduplicate_list(list_0))