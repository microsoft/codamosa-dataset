

# Generated at 2022-06-25 13:13:39.600784
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 3, 2, 1]) == [1, 2, 3]



# Generated at 2022-06-25 13:13:43.352696
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("90%", 100) == 90
    assert pct_to_int("13%", 100) == 13
    assert pct_to_int("0%", 100) == 1
    assert pct_to_int("5", 100) == 5
    assert pct_to_int("5", 100, 10) == 5
    assert pct_to_int("0%", 100, 10) == 10

# Generated at 2022-06-25 13:13:49.982160
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(0, 4) == 0
    assert pct_to_int(1, 4) == 1
    assert pct_to_int(25, 4) == 1
    assert pct_to_int(26, 4) == 2
    assert pct_to_int(50, 4) == 2
    assert pct_to_int(51, 4) == 3
    assert pct_to_int(75, 4) == 3
    assert pct_to_int(76, 4) == 4
    assert pct_to_int(100, 4) == 4



# Generated at 2022-06-25 13:13:59.944831
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(100, 10) == 10
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int(65, 10) == 6
    assert pct_to_int('65%', 10) == 6
    assert pct_to_int(100.5, 10) == 10
    assert pct_to_int('100.5%', 10) == 10
    assert pct_to_int(30.3, 10) == 3
    assert pct_to_int('30.3%', 10) == 3
    assert pct_to_int('160%', 10) == 10
    assert pct_to_int('160.5%', 10) == 10
    assert pct_to_int('-1%', 10) == 1
    assert pct_

# Generated at 2022-06-25 13:14:01.375389
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("20%", 100) == 20


# Generated at 2022-06-25 13:14:04.875697
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100) == 20
    assert pct_to_int("20%", 100) == 20
    assert pct_to_int("20%", 100, 5) == 20
    assert pct_to_int(5, 100, 5) == 5



# Generated at 2022-06-25 13:14:14.912268
# Unit test for function pct_to_int
def test_pct_to_int():
    # unit tests for the pct_to_int function
    assert pct_to_int(3, 100) == 3
    assert pct_to_int(3, 100, 0) == 3
    assert pct_to_int(3, 100, 1) == 3
    assert pct_to_int(3, 100, 10) == 3
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, 0) == 10
    assert pct_to_int(10, 100, 1) == 10
    assert pct_to_int(10, 100, 10) == 10
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 100, 0) == 100

# Generated at 2022-06-25 13:14:25.014852
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}
    tuple_1 = (1,2,3)
    var_1 = object_to_dict(tuple_1)

# Generated at 2022-06-25 13:14:27.238984
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 10
    assert pct_to_int('20%', num_items) == 2
    assert pct_to_int(20, num_items) == 20


# Generated at 2022-06-25 13:14:33.639771
# Unit test for function pct_to_int
def test_pct_to_int():
    assert (pct_to_int(20, 10) == 2)
    assert (pct_to_int(20, 10, min_value=2) == 2)
    assert (pct_to_int('20%', 10) == 2)
    assert (pct_to_int('20%', 10, min_value=2) == 2)
    assert (pct_to_int('0%', 10) == 1)
    assert (pct_to_int('0%', 10, min_value=2) == 2)


# Generated at 2022-06-25 13:14:38.100083
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'd', 'b', 'c']
    assert deduplicate_list(test_list) == ['a', 'b', 'c', 'd']


# Generated at 2022-06-25 13:14:39.893164
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == dict()


# Generated at 2022-06-25 13:14:43.293436
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 2, 3, 2, 1]
    var_0 = deduplicate_list(list_0)
    assert var_0 == [1, 2, 3]


# Generated at 2022-06-25 13:14:48.959850
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(()) == {}
    assert object_to_dict([]) == {}
    assert object_to_dict({}) == {}
    assert object_to_dict(set()) == {}
    assert object_to_dict(42) == {}
    assert object_to_dict('foo') == {}

    assert object_to_dict(object()) == {}
    assert object_to_dict(object, exclude=[]) == {}
    assert object_to_dict(object, exclude=[]) == {}



# Generated at 2022-06-25 13:14:54.710399
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ('a', 'b', 'c')
    var_0 = object_to_dict(tuple_0)

# Generated at 2022-06-25 13:14:59.735425
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}

    tuple_1 = ()
    var_1 = object_to_dict(tuple_1, exclude=["abc"])
    assert var_1 == {}


# Generated at 2022-06-25 13:15:04.030736
# Unit test for function object_to_dict
def test_object_to_dict():
    sample_dict = {"key1": 1, "key2": "val2", "key3": [1, 2, 3]}
    var_0 = object_to_dict(sample_dict)
    expected = {"key1": 1, "key2": "val2", "key3": [1, 2, 3]}
    assert var_0 == expected


# Generated at 2022-06-25 13:15:06.340967
# Unit test for function object_to_dict
def test_object_to_dict():
    print("function object_to_dict")
    # Example test case
    # Create a function that takes an argument,
    # and prints the value

    # Create a function that takes an argument,
    # and prints the value
    test_case_0()



# Generated at 2022-06-25 13:15:09.818510
# Unit test for function deduplicate_list
def test_deduplicate_list():
    L = [1,1,2,2,2,2,2,5,5,5,5,5,5,5,5,5,5,5]
    dedupe_L = deduplicate_list(L)
    assert dedupe_L == [1,2,5]


# Generated at 2022-06-25 13:15:13.180016
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    expected_0 = {}
    var_0 = object_to_dict(tuple_0)
    assert var_0 == expected_0, "Expected {}, got {}".format(expected_0, var_0)



# Generated at 2022-06-25 13:15:18.047245
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'a', 'b', 'b', 'c', 'c', 'c']
    real_result = ['a', 'b', 'c']
    assert deduplicate_list(test_list) == real_result



# Generated at 2022-06-25 13:15:20.362279
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,3,3]) == [1,3]


# Generated at 2022-06-25 13:15:29.233560
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test with a tuple with no values
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}

    # Test with a tuple with a few values
    tuple_1 = ("one", "two", "three")
    var_1 = object_to_dict(tuple_1)

# Generated at 2022-06-25 13:15:30.877179
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-25 13:15:32.650987
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 2, 3, 2]
    assert(deduplicate_list(sample_list) == [1, 2, 3])


# Generated at 2022-06-25 13:15:35.547034
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_list = [1,2,3,4,5,5,4,3,2,1]
    assert deduplicate_list(input_list) == [1,2,3,4,5]


if __name__ == "__main__":
    test_deduplicate_list()
    #test_case_0()

# Generated at 2022-06-25 13:15:38.271857
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}, "Expected {}, got {}".format(var_0, {})



# Generated at 2022-06-25 13:15:41.143321
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [ 7, 7, 1 ]
    deduplicate_list(list_0)


if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:15:44.128519
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['abc', 'abc', 'pqr', 'pqr']

    assert deduplicate_list(list_0) == ['abc', 'pqr']

# Generated at 2022-06-25 13:15:52.279454
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['b', 'b', 'a']) == ['b', 'a']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-25 13:15:56.215882
# Unit test for function deduplicate_list
def test_deduplicate_list():
   assert(deduplicate_list([1, 2, 3, 3, 1, 2, 4])) == [1, 2, 3, 4]

# Generated at 2022-06-25 13:15:57.037936
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(()) == {}



# Generated at 2022-06-25 13:15:58.255138
# Unit test for function object_to_dict
def test_object_to_dict():
    assert callable(object_to_dict)


# Generated at 2022-06-25 13:16:07.146859
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ('A', 'B', 'C')
    var_0 = object_to_dict(tuple_0)

# Generated at 2022-06-25 13:16:08.597234
# Unit test for function object_to_dict
def test_object_to_dict():
    var_0 = object_to_dict((1, 2, 3))
    var_1 = object_to_dict('test')
    var_2 = object_to_dict(1)


# Generated at 2022-06-25 13:16:11.257879
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ["a", "a", "b", "c", "b", "a"]
    assert deduplicate_list(test_list) == ["a", "b", "c"]



# Generated at 2022-06-25 13:16:14.246446
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicated_list = deduplicate_list(['a', 'b', 'b', 'c', 'd', 'a', 'd'])
    assert deduplicated_list == ['a', 'b', 'c', 'd']



# Generated at 2022-06-25 13:16:16.407456
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert(var_0 == {})



# Generated at 2022-06-25 13:16:22.241866
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 4, 2, 5, 1]) == [1, 2, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([]) == []



# Generated at 2022-06-25 13:16:26.447761
# Unit test for function deduplicate_list
def test_deduplicate_list():

    list_all_duplicates = [1,2,3,4,1,2,3,4]
    list_duplicates = list(deduplicate_list(list_all_duplicates))

    assert [1,2,3,4] == list_duplicates


# Generated at 2022-06-25 13:16:40.222638
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    print(var_0)
    list_0 = []
    var_1 = object_to_dict(list_0)
    print(var_1)
    str_0 = "ABC"
    var_2 = object_to_dict(str_0)
    print(var_2)
    dict_0 = {}
    var_3 = object_to_dict(dict_0)
    print(var_3)
    num_0 = 10
    var_4 = object_to_dict(num_0)
    print(var_4)


# Generated at 2022-06-25 13:16:41.206160
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()


# Generated at 2022-06-25 13:16:47.115670
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case = [
        (
            (
              object_to_dict(('a', 'b', 'c'), ['foo', 'bar']),
            ),
            {'a': 1, 'b': 2, 'c': 3}
        ),
    ]

    for test_input, expected_result in test_case:
        assert test_input == expected_result, 'Expected {0}, got {1}'.format(expected_result, test_input)



# Generated at 2022-06-25 13:16:48.913837
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,1,2,2,2,2]) == [1,2]


# Generated at 2022-06-25 13:16:53.988677
# Unit test for function object_to_dict
def test_object_to_dict():
    print("In test_object_to_dict function")

# Generated at 2022-06-25 13:16:55.660326
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)



# Generated at 2022-06-25 13:16:58.644968
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [0, 1, 1, 2, 2, 2, 3, 3, 3, 3]
    expected_list = [0, 1, 2, 3]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-25 13:17:02.645426
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(["alpha", "beta", "gamma", "delta", "beta", "gamma", "delta", "epsilon"])
    assert result == ["alpha", "beta", "gamma", "delta", "epsilon"]


# Generated at 2022-06-25 13:17:05.072776
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-25 13:17:06.861978
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}



# Generated at 2022-06-25 13:17:17.683326
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()

# Generated at 2022-06-25 13:17:21.926300
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1,2,3,4,5,2,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4]
    result = deduplicate_list(test_list)

    assert result == [1,2,3,4,5]

# Generated at 2022-06-25 13:17:22.764332
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()


# Generated at 2022-06-25 13:17:29.513664
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:17:33.243076
# Unit test for function object_to_dict
def test_object_to_dict():
    print('Test #0: object_to_dict()')
    try:
        test_case_0()
    except SystemExit:
        pass
    else:
        print('Test #0: object_to_dict() - FAILED')
        exit(255)



# Generated at 2022-06-25 13:17:39.776344
# Unit test for function object_to_dict
def test_object_to_dict():

    # Simple test for function object_to_dict
    import collections
    import random
    import csv
    class test_object:
        def __init__(self):
            self.a = random.randint(0,10)
            self.b = random.randint(0,10)
            pass
    test = test_object()
    assert 'a' in object_to_dict(test).keys()
    assert 'b' in object_to_dict(test).keys()



# Generated at 2022-06-25 13:17:49.183337
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert (var_0 == {})
    tuple_1 = ()
    var_1 = object_to_dict(tuple_1)
    assert (var_1 == {})
    tuple_2 = ()
    var_2 = object_to_dict(tuple_2)
    assert (var_2 == {})
    tuple_3 = ()
    var_3 = object_to_dict(tuple_3)
    assert (var_3 == {})
    tuple_4 = ()
    var_4 = object_to_dict(tuple_4)
    assert (var_4 == {})
    tuple_5 = ()
    var_5 = object_to_dict(tuple_5)

# Generated at 2022-06-25 13:17:51.478743
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,2,3,4,4,4,4,2,2,2,1,1,1,1,1]) == [1,2,3,4]

# Generated at 2022-06-25 13:17:53.796425
# Unit test for function object_to_dict
def test_object_to_dict():
    if not isinstance(object_to_dict(), dict):
        raise AssertionError()



# Generated at 2022-06-25 13:17:59.485103
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = ['a', 'b', 'c']
    tuple_0 = ()
    tuple_1 = ()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 13:18:28.106263
# Unit test for function object_to_dict
def test_object_to_dict():
    dict_0 = dict()
    dict_0['var_0'] = 'var_0'
    dict_0['var_1'] = 'var_1'
    dict_0['var_2'] = 'var_2'
    dict_0['var_3'] = 'var_3'
    dict_0['var_4'] = 'var_4'
    dict_0['var_5'] = 'var_5'
    dict_0['var_6'] = 'var_6'
    dict_0['var_7'] = 'var_7'
    dict_0['var_8'] = 'var_8'
    dict_0['var_9'] = 'var_9'
    dict_0['var_10'] = 'var_10'
    dict_0['var_11'] = 'var_11'

# Generated at 2022-06-25 13:18:35.841331
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 3, 3, 3, 4, 5, 6, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert deduplicate_list([1, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 6, 7, 8]) == [1, 3, 4, 5, 6, 7, 8]
    assert deduplicate_list(['a', 'a', 'a', 'b', 'c', 'd', 'e', 'e', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-25 13:18:38.716999
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 2, 3, 2, 1, 2, 1, 2, 3]
    expected_result = [1, 3, 2]
    result = deduplicate_list(original_list)
    assert result == expected_result

# Generated at 2022-06-25 13:18:40.922312
# Unit test for function object_to_dict
def test_object_to_dict():
    result = object_to_dict((1,2))
    assert( type(result) == dict)
    assert( len(result) > 0)


# Generated at 2022-06-25 13:18:49.757041
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    list_1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    list_2 = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]
    list_3 = [0, 1, 2, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list(list_0) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], "Function deduplicate_list returned an incorrect list."

# Generated at 2022-06-25 13:18:51.510377
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'b', 'c']
    deduped_list = ['a', 'b', 'c']

    assert deduplicate_list(original_list) == deduped_list


# Generated at 2022-06-25 13:18:54.215927
# Unit test for function deduplicate_list
def test_deduplicate_list():
    duplicate_list = [1, 2, 2, 4, 4, 5, 6, 6]
    correct_list = [1, 2, 4, 5, 6]
    assert deduplicate_list(duplicate_list) == correct_list


# Generated at 2022-06-25 13:18:58.795364
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == {}
    tuple_1 = (1, 2, 3)
    var_1 = object_to_dict(tuple_1)
    assert var_1 == {"count": 3, "index": 0}



# Generated at 2022-06-25 13:19:00.883886
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    assert object_to_dict(tuple_0) == {}


# Generated at 2022-06-25 13:19:01.818763
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()



# Generated at 2022-06-25 13:19:48.831151
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)

# Generated at 2022-06-25 13:19:52.990582
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]
    assert deduplicate_list(original_list) == [1,2,3]


# Generated at 2022-06-25 13:20:01.089643
# Unit test for function deduplicate_list
def test_deduplicate_list():

    # Test 1 - simple list
    actual = [1,2,3,1,3,4]
    expected = [1,2,3,4]

    assert deduplicate_list(actual) == expected

    # Test 2 - empty list
    actual = []
    expected = []

    assert deduplicate_list(actual) == expected

    # Test 3 - single item list
    actual = [1]
    expected = [1]

    assert deduplicate_list(actual) == expected

    # Test 4 - list with None value
    actual = [1,2,3,None,3,4]
    expected = [1,2,3,None,4]

    assert deduplicate_list(actual) == expected

    # Test 5 - list with complex list content

# Generated at 2022-06-25 13:20:03.757861
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original = [1, 2, 3, 2, 1]
    expected = [1, 2, 3]
    deduped = deduplicate_list(original)

    assert deduped == expected



# Generated at 2022-06-25 13:20:06.385930
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Test for object_to_dict
    """
    var_0 = object_to_dict()
    assert var_0 == {}



# Generated at 2022-06-25 13:20:14.929846
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 2, 3]
    list_1 = [1, 2, 1]
    list_2 = [1, 1, 1]
    list_3 = [1, 2, 1, 3, 3, 2]

    list_res_0 = deduplicate_list(list_0)
    assert list_res_0 == list_0

    list_res_1 = deduplicate_list(list_1)
    assert list_res_1 == [1, 2]

    list_res_2 = deduplicate_list(list_2)
    assert list_res_2 == [1]

    list_res_3 = deduplicate_list(list_3)
    assert list_res_3 == [1, 2, 3]


# Generated at 2022-06-25 13:20:17.383859
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(('hello', 'world')) == {'count': 2, 'index': 0, 'data': 'hello'}


# Generated at 2022-06-25 13:20:23.765121
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 6, 7, 7, 8, 9, 10, 11, 11, 12, 13, 14, 15, 16, 17, 18]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
    actual_list = deduplicate_list(original_list)

    assert len(actual_list) == len(expected_list)
    assert expected_list == actual_list


# Generated at 2022-06-25 13:20:24.823942
# Unit test for function object_to_dict
def test_object_to_dict():
    assert 'test_case_0' == 0

# Generated at 2022-06-25 13:20:30.477830
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'b', 'd', 'c', 'e', 'd', 'a', 'f']

    expected = ['a', 'b', 'c', 'd', 'e', 'f']
    actual = deduplicate_list(original_list)

    assert expected == actual, "Expected {0}, actual {1}".format(expected, actual)


if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-25 13:21:12.140647
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['first', 'first', 'third', 'third', 'third']
    list_0 = deduplicate_list(list_0)



# Generated at 2022-06-25 13:21:14.245870
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'a', 'c'])
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-25 13:21:18.827798
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 2, 3, 4, 5, 5, 4, 3, 0]
    result_0 = deduplicate_list(list_0)
    print(result_0)
    print("The result should be: [1, 2, 3, 4, 5, 0]")


if __name__ == '__main__':
    # Unit test for function object_to_dict
    test_deduplicate_list()

# Generated at 2022-06-25 13:21:24.502350
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 3]
    deduplicated_list = deduplicate_list(original_list)
    assert(deduplicated_list == [1, 2, 3])

    original_list = [1, 2, 3, 2, 1, 2]
    deduplicated_list = deduplicate_list(original_list)
    assert(deduplicated_list == [1, 2, 3])



# Generated at 2022-06-25 13:21:28.834986
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1,2,2,2,4,5,5,5,5,5,5,5,5,5,5,5.5,5.5]
    assert deduplicate_list(sample_list) == [1, 2, 2.0, 4, 5, 5.5]


# Generated at 2022-06-25 13:21:37.703790
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    var_0 = object_to_dict(tuple_0)
    assert var_0 == dict()

    tuple_1 = (1,)
    var_1 = object_to_dict(tuple_1, exclude=['__repr__'])
    assert var_1 == dict()

    list_0 = []
    var_2 = object_to_dict(list_0)
    assert var_2 == dict()

    list_1 = [1]
    var_3 = object_to_dict(list_1)

# Generated at 2022-06-25 13:21:40.510443
# Unit test for function object_to_dict
def test_object_to_dict():
    a = {'a':1, 'b':2, 'c':3}
    assert object_to_dict(a) == a
    class Object(object): pass
    o = Object()
    o.a = 1
    o.b = 2
    o.c = 3
    assert object_to_dict(o) == a



# Generated at 2022-06-25 13:21:45.172274
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestClass(object):
        """
        A class to test with
        """
        def __init__(self):
            self.test_var = 'test_value'
            self.test_private_var = 'test_private_value'

    test_class = TestClass()
    test_dict = {'test_var': 'test_value'}
    res_dict = object_to_dict(test_class)

    assert res_dict == test_dict

    test_dict = {'test_var': 'test_value', 'test_private_var': 'test_private_value'}
    res_dict = object_to_dict(test_class, exclude=['test_var'])

    assert res_dict == test_dict



# Generated at 2022-06-25 13:21:52.218103
# Unit test for function object_to_dict
def test_object_to_dict():
    tuple_0 = ()
    dict_0 = object_to_dict(tuple_0)
    assert dict_0 == {'count': None,
    'index': None}
    dictionary_0 = {
        2: None,
    }
    dict_1 = object_to_dict(dictionary_0)

# Generated at 2022-06-25 13:21:55.590597
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 7, 3, 8, 8, 7]
    assert deduplicate_list(list_0) == [1, 7, 3, 8]


if __name__ == "__main__":
    test_case_0()
    test_deduplicate_list()
    print("Test completed successfully")

# Generated at 2022-06-25 13:23:33.473923
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 4, 1, 2, 3, 5, 6, 4, 3, 6, 7, 8, 8, 3]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6, 7, 8]


# Generated at 2022-06-25 13:23:35.052408
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ('a', 'b', 'c', 'a', 'd', 'b', 'c')
    expected_list = ('a', 'b', 'c', 'd')
    assert deduplicate_list(original_list) == expected_list


# Generated at 2022-06-25 13:23:36.044899
# Unit test for function object_to_dict
def test_object_to_dict():
    assert callable(object_to_dict)

