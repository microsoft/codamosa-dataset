

# Generated at 2022-06-25 13:13:36.867076
# Unit test for function pct_to_int
def test_pct_to_int():
    bool_1 = True
    var_0 = pct_to_int(bool_1, 5)

    assert var_0 == 5



# Generated at 2022-06-25 13:13:37.420763
# Unit test for function object_to_dict
def test_object_to_dict():
    var0 = True
    assert var0 == True


# Generated at 2022-06-25 13:13:39.245077
# Unit test for function pct_to_int
def test_pct_to_int():
    print("Starting function test_pct_to_int")
    var_1 = pct_to_int("30%", 10)
    var_0 = pct_to_int("30%", 100)
    assert var_0==30
    assert var_1==3
    

# Generated at 2022-06-25 13:13:39.744880
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()

# Generated at 2022-06-25 13:13:42.837870
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    var_0 = object_to_dict(bool_0)
    assert var_0 == {'__class__': bool, '__hash__': None, '__repr__': None, '__str__': None, '__new__': None}


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:13:47.435377
# Unit test for function pct_to_int
def test_pct_to_int():
    change = pct_to_int('10%', 100)
    assert change == 10
    change = pct_to_int('100%', 100)
    assert change == 100
    change = pct_to_int('0%', 100)
    assert change == 1
    change = pct_to_int('10', 100)
    assert change == 10
    change = pct_to_int(10, 100)
    assert change == 10


# Generated at 2022-06-25 13:13:57.376363
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = 'abc'
    result = object_to_dict(obj)

# Generated at 2022-06-25 13:14:00.787788
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 100, min_value=10) == 10



# Generated at 2022-06-25 13:14:02.863734
# Unit test for function pct_to_int
def test_pct_to_int():
    value = '10%'
    num_items = 10
    assert pct_to_int(value, num_items) == 1


# Generated at 2022-06-25 13:14:11.795858
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:14:15.615310
# Unit test for function object_to_dict
def test_object_to_dict():
    # Exception in case of error
    # AssertionError: TypeError not raised
    test_case_0()


# Generated at 2022-06-25 13:14:19.560910
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'b', 'd', 'd']
    deduplicated_list = deduplicate_list(original_list)
    print(deduplicated_list)

# Generated at 2022-06-25 13:14:23.264416
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    var_0 = object_to_dict(bool_0)

# Generated at 2022-06-25 13:14:25.452065
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 2, 3, 1, 2]) == [1, 2, 3, 2]



# Generated at 2022-06-25 13:14:35.331525
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Tests for basic functionality:
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list([]) == []

    # Tests for correct output order
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'a', 'a']) == ['a', 'b']

    # Tests for correct input type handling
    assert deduplicate_list(('a', 'b', 'a')) == ['a', 'b']

#Unit test for

# Generated at 2022-06-25 13:14:40.517593
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,5,5,2,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5])  == [1,5,2]

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-25 13:14:47.239024
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1,2,3,3,3,2,2,2,2,3,3,3,3,3,1,1,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
    de_duped_list = deduplicate_list(original_list)
    if (de_duped_list != [1,2,3,4]):
        raise AssertionError(de_duped_list)

# Generated at 2022-06-25 13:14:51.254288
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(True) == {'__class__': bool, '__doc__': 'bool(x) -> bool\n\nReturns True when the argument x is true, False otherwise.\nThe builtins True and False are the only two instances of the class bool.\nThe class bool is a subclass of the class int, and cannot be subclassed.\n'}



# Generated at 2022-06-25 13:14:56.661418
# Unit test for function deduplicate_list
def test_deduplicate_list():
    var_0 = ['a', 'b', 'c', 'd', 'd']
    var_1 = ['a', 'b', 'c', 'd']
    test_var_0 = deduplicate_list(var_0)
    assert test_var_0 == var_1


# Generated at 2022-06-25 13:14:58.549626
# Unit test for function object_to_dict
def test_object_to_dict():


    assert var_0['__class__'] == "bool"
    assert var_0['__sizeof__'] == 24
    assert var_0['__str__'] == "True"
    assert var_0['__repr__'] == "True"


if __name__ == "__main__" :
    test_case_0()

# Generated at 2022-06-25 13:15:01.608973
# Unit test for function object_to_dict
def test_object_to_dict():
    x = False
    object_to_dict(x)



# Generated at 2022-06-25 13:15:06.449699
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'b', 'a', 'c', 'a', 'c', 'b', 'a']
    list_1 = deduplicate_list(list_0)
    assert list_1 == ['a', 'b', 'c']
    list_2 = ['a', 'b', 'c']
    assert deduplicate_list(list_2) == list_2

# Generated at 2022-06-25 13:15:07.724599
# Unit test for function object_to_dict
def test_object_to_dict():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:15:09.807012
# Unit test for function object_to_dict
def test_object_to_dict():
    assert test_case_0() == dict(var_0)
    print('Test Passed')

if __name__ == '__main__':
    test_object_to_dict()

# Generated at 2022-06-25 13:15:11.219131
# Unit test for function object_to_dict
def test_object_to_dict():
    assert test_case_0() is None, 'test_case_0() should return None'

# Generated at 2022-06-25 13:15:15.600435
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([None, 1, 2, 2, 3, 3, 3, 4, 5, 5, 6, 6, 6, 7, 7, 7, 8, 9, 9, 9, 10, 10]) == [None, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-25 13:15:18.281619
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 4, 5, 6, 1, 7]) == [1, 2, 3, 4, 5, 6, 7]


# Generated at 2022-06-25 13:15:22.044683
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    var_0 = object_to_dict(bool_0)
    assert var_0 == {'denominator': 1, 'imag': 0, 'numerator': 1, 'real': 1}


# Generated at 2022-06-25 13:15:24.819789
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 2, 1, 2, 3, 2, 1]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-25 13:15:32.651953
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:15:41.821168
# Unit test for function deduplicate_list
def test_deduplicate_list():
    int_0 = 1
    float_0 = 0.1
    str_0 = 'test'
    list_0 = [str_0, int_0, float_0, str_0]
    list_1 = [str_0, int_0, float_0]
    assert deduplicate_list(list_0) == list_1, 'Failed to deduplicate list'



# Generated at 2022-06-25 13:15:46.483068
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'a', 'd', 'e', 'a']
    deduped_list = deduplicate_list(original_list)
    assert deduped_list == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-25 13:15:49.791901
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 4, 3, 4, 1, 2]
    deduplicated_list = deduplicate_list(original_list)
    assert(deduplicated_list == [1, 2, 3, 4])



# Generated at 2022-06-25 13:15:54.418993
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        original_list = [1, 2, 3, 4, 5, 5, 6, 7, 7]
        deduplicated_list = deduplicate_list(original_list)

        assert deduplicated_list == [1, 2, 3, 4, 5, 6, 7]
    except AssertionError:
        raise AssertionError('Assertion failure')



# Generated at 2022-06-25 13:15:59.596259
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = False
    var_0 = object_to_dict(bool_0)
    assert var_0 == {'__class__': bool, '__doc__': "bool(x) -> bool\n\nReturns True when the argument x is true, False otherwise.\nThe builtins True and False are the only two instances of the class bool.\nThe class bool is a subclass of the class int, and cannot be subclassed.", '__init__': False}



# Generated at 2022-06-25 13:16:08.221422
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_0 = [1, 2, 1, 2, 3, 4, 5]
    original_1 = [1, 2, 1, 2, 3, 4, 5, 4, 3, 2, 3, 4, 5, 6, 7, 8, 9, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    original_2 = ['a', 'b', 'c', 'd', 'e', 'f', 'e', 'd', 'c', 'b', 'a']
    original_3 = ['a', 'b', 'c', 'd', 'e', 'f', 'e', 'd', 'c', 'b', 'a']
    original_4 = ['a', 'b', 'c', 'd', 'e', 'f', 'e', 'd', 'c', 'b', 'a']
    original

# Generated at 2022-06-25 13:16:17.248757
# Unit test for function object_to_dict
def test_object_to_dict():
    """Verify that given an object, it will convert the object to a dict."""
    # Unit tests for object_to_dict
    # Given an object, it will convert the object to a dict.
    # For example, an object of type bool
    bool_test = True
    bool_test_dict = object_to_dict(bool_test)
    assert isinstance(bool_test_dict, dict), "Should be of type dict."

# Generated at 2022-06-25 13:16:22.457350
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [0, 1, 2, 1.2, 3, 0, 4, 4, 1, 2.2, 0.1, 3.3]
    dedup_list = deduplicate_list(original_list)
    assert dedup_list == [0, 1, 2, 1.2, 3, 4, 2.2, 0.1, 3.3], 'Failed test case 0'
    # Extra test cases to be added below


# Generated at 2022-06-25 13:16:26.358084
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [10, 20, 30] == deduplicate_list([10, 10, 20, 30, 20, 10])

if __name__ == '__main__':
    test_case_0()
    test_deduplicate_list()

# Generated at 2022-06-25 13:16:32.481865
# Unit test for function deduplicate_list
def test_deduplicate_list():
	assert deduplicate_list([1,2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4]) == [1, 2, 3, 4]
	assert deduplicate_list([1,2,2,2,2,2,2,2,2]) == [1, 2]
	assert deduplicate_list([1,1,1,1,1,1,1,1,1]) == [1]

# Generated at 2022-06-25 13:16:42.448543
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 3]) == [1, 2, 3]

# Generated at 2022-06-25 13:16:47.779297
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ["Example1", "Example2", "Example2", "Example1"]
    list_dedup = deduplicate_list(list_0)
    assert 'Example1' in list_dedup
    assert 'Example2' in list_dedup
    assert len(list_dedup) == 2
    assert list_dedup.index('Example1') == 0
    assert list_dedup.index('Example2') == 1

# Generated at 2022-06-25 13:16:51.093826
# Unit test for function deduplicate_list
def test_deduplicate_list():
    v = [1, 1, 2, 2, 3, 3, 1]
    deduplicate_list(v)
    assert v == [1, 2, 3, 1]


if __name__ == '__main__':
    test_case_0()
    test_deduplicate_list()

# Generated at 2022-06-25 13:16:54.598855
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]


# Generated at 2022-06-25 13:16:57.812918
# Unit test for function object_to_dict
def test_object_to_dict():
    try:
        assert object_to_dict('a')
    except AssertionError as e:
        print('Test case 0 failed: ' + str(e))
    else:
        print('Test case 0 passed')



# Generated at 2022-06-25 13:17:02.107108
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['test_1','test_2','test_3','test_3','test_4','test_5','test_1','test_5']
    assert deduplicate_list(original_list) == ['test_1','test_2','test_3','test_4','test_5']

# Generated at 2022-06-25 13:17:05.477393
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(True) == {'numerator': 1, 'imag': 0, 'real': 1}
    assert object_to_dict(False) == {'numerator': 0, 'imag': 0, 'real': 0}


# Generated at 2022-06-25 13:17:09.196519
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,4,5]) == [1,2,3,4,5]
    assert deduplicate_list([1,2,3,3,3,3,2,1]) == [1,2,3]


# Generated at 2022-06-25 13:17:14.271272
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 2, 3, 4, 5]
    list_1 = deduplicate_list(list_0)
    list_2 = [1, 1, 2, 2, 2, 3, 4, 5]
    list_3 = deduplicate_list(list_2)
    list_4 = ['a', 'z', 'f', 'u', 'k', 'k', 'o']
    list_5 = deduplicate_list(list_4)
    list_6 = [1, 'a', 'f', 2, 4, 2]
    list_7 = deduplicate_list(list_6)

# Generated at 2022-06-25 13:17:15.901245
# Unit test for function object_to_dict
def test_object_to_dict():
    assert True == (True == object_to_dict(True))


# Generated at 2022-06-25 13:17:38.327250
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 1, 2, 1, 5, 6, 7, 7, 1]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-25 13:17:40.748671
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 2, 4, 2, 5]) == [1, 2, 3, 4, 5]


# Generated at 2022-06-25 13:17:49.743572
# Unit test for function deduplicate_list
def test_deduplicate_list():
    elements = [2,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,6,7,7,8,8,8,8,8,10,11,11,12,12,12,12,12,12,12]
    deduplicated_elements = deduplicate_list(elements)
    print(deduplicated_elements)
    assert deduplicated_elements == [2,5,6,7,8,10,11,12]
    return



# Generated at 2022-06-25 13:17:53.521438
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 5, 6, 6]
    expected = [1, 2, 3, 5, 6]
    actual = deduplicate_list(original_list)
    assert sorted(expected) == sorted(actual)

# Generated at 2022-06-25 13:17:55.660400
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,2]) == [1,2]

test_deduplicate_list()

# Generated at 2022-06-25 13:18:05.223784
# Unit test for function object_to_dict
def test_object_to_dict():
    true_0 = True

# Generated at 2022-06-25 13:18:11.461061
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    var_0 = object_to_dict(bool_0)
    assert var_0['__module__'] == bool.__module__
    assert var_0['__name__'] == bool.__name__
    assert var_0['__doc__'] == bool.__doc__
    assert var_0['__dict__'] == bool_0.__dict__
    assert var_0['__hash__'] == bool.__hash__
    assert var_0['__format__'] == bool.__format__
    assert var_0['__str__'] == bool.__str__
    assert var_0['__unicode__'] == bool.__unicode__
    assert var_0['__repr__'] == bool.__repr__
    assert var_0['__cmp__'] == bool.__cmp__


# Generated at 2022-06-25 13:18:13.912059
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'foo']
    deduplicated_list = deduplicate_list(original_list)

    assert deduplicated_list == original_list



# Generated at 2022-06-25 13:18:19.170405
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([5,5,5,5,5,5,5,5,5,5,5,5,5]) == [5]
    assert deduplicate_list([5,5,5,5,5,5,5,5,5,5,5,5,5,"Hello"]) == [5, "Hello"]


# Generated at 2022-06-25 13:18:20.671095
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    var_0 = object_to_dict(bool_0)



# Generated at 2022-06-25 13:19:00.022280
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(True) == {'numerator': 1, 'denominator': 1}
    assert object_to_dict(None) == {}

# Generated at 2022-06-25 13:19:02.338732
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    assert '__bool__' in object_to_dict(bool_0)

# Generated at 2022-06-25 13:19:03.811850
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = True
    assert object_to_dict(obj) == dict(obj=True)



# Generated at 2022-06-25 13:19:12.327147
# Unit test for function object_to_dict
def test_object_to_dict():
    bool_0 = True
    test_0 = object_to_dict(bool_0)

# Generated at 2022-06-25 13:19:14.994470
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 4, 5, 3, 6 , 6, 5, 7]) == [1, 2, 3, 4, 5, 6, 7]


# Generated at 2022-06-25 13:19:16.069343
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b'])

# Generated at 2022-06-25 13:19:17.283173
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,4,5]) == [1,2,3,4,5]


# Generated at 2022-06-25 13:19:19.252201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    bool_0 = True
    original_list = [ bool_0, bool_0, bool_0]
    deduplicate_list(original_list)


# Generated at 2022-06-25 13:19:20.642277
# Unit test for function object_to_dict
def test_object_to_dict():
    assert isinstance(test_case_0(), dict)

# Generated at 2022-06-25 13:19:23.670111
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4]) == [1,2,3,4]


# Generated at 2022-06-25 13:20:42.261347
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = 'a,b,b,c,c,c,a,d,e,e,a'
    original_list = split(original_list, ',')
    assert original_list == ['a','b','b','c','c','c','a','d','e','e','a']
    deduplicate_list = deduplicate_list(original_list)
    assert deduplicate_list == ['a','b','c','d','e']



# Generated at 2022-06-25 13:20:51.511969
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1]) == [1]
    assert deduplicate_list([1,1,1,2]) == [1,2]
    assert deduplicate_list([1,1,1,2,3,3,3]) == [1,2,3]
    assert deduplicate_list([1,2]) == [1,2]
    assert deduplicate_list([1,2,1]) == [1,2]

# Generated at 2022-06-25 13:20:59.235633
# Unit test for function object_to_dict
def test_object_to_dict():
    global bool_0

# Generated at 2022-06-25 13:21:03.797473
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 3, 5, 5, 5, 7, 5]
    expected_result = [1,3,5,7]
    actual_result = deduplicate_list(original_list)
    fail_message = 'Expected %s, got %s' % (expected_result, actual_result)
    assert expected_result == actual_result, fail_message


# Generated at 2022-06-25 13:21:06.529417
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 3, 3, 3, 4]
    assert (deduplicate_list(original_list) == [1, 2, 3, 4, 5])


# Generated at 2022-06-25 13:21:10.854258
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'bar', 'bar', 'baz']) == ['foo', 'bar', 'baz']
    assert deduplicate_list(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 13:21:18.678088
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = False
    dict_data = object_to_dict(obj)

# Generated at 2022-06-25 13:21:23.633294
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 6]
    assert deduplicate_list(original_list) == original_list

    original_list = [1, 2, 3, 4, 5, 6, 6, 4, 3, 2, 1]
    assert deduplicate_list(original_list) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-25 13:21:24.896603
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(test_case_0()) == test_case_0()

# Generated at 2022-06-25 13:21:27.370229
# Unit test for function object_to_dict
def test_object_to_dict():
    print('Running unittest for: object_to_dict')
    test_case_0()
    print('Successfully ran unittest for: object_to_dict')
