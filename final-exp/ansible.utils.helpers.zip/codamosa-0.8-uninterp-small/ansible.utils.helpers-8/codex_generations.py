

# Generated at 2022-06-25 13:13:42.652071
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('1%', 10) == 1
    assert pct_to_int(2, 10) == 2

# Generated at 2022-06-25 13:13:45.782265
# Unit test for function pct_to_int
def test_pct_to_int():
    assert 5 == pct_to_int('5%', 10)
    assert 0 == pct_to_int('5%', 0)
    assert 1 == pct_to_int('5%', 0, min_value=1)
    assert 10 == pct_to_int(10, 100)



# Generated at 2022-06-25 13:13:49.430825
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('100%', 10) == 10



# Generated at 2022-06-25 13:13:51.797290
# Unit test for function pct_to_int
def test_pct_to_int():
    complex_0 = "%1"
    int_0 = pct_to_int(complex_0, 0, 0)
    assert int_0 == 0


# Generated at 2022-06-25 13:14:02.022976
# Unit test for function pct_to_int
def test_pct_to_int():
    assert not pct_to_int(None, 100)
    assert not pct_to_int(None, 0)

    assert pct_to_int(1, 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(100, 100) == 100

    assert pct_to_int(0.5, 100) == 0
    assert pct_to_int(1, 100) == 1

    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('100%', 100) == 100

    assert pct_to_int('0.5%', 100) == 0


# Generated at 2022-06-25 13:14:03.229041
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("50%", 100) == 50


# Generated at 2022-06-25 13:14:07.718548
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_0 = [1, 1, 2, 3]
    var_0 = deduplicate_list(complex_0)
    assert var_0 == [1, 2, 3]
    complex_1 = [1, 4, 2, 2, 1, 0, 0, 9, 5, 5, 5]
    var_1 = deduplicate_list(complex_1)
    assert var_1 == [1, 4, 2, 0, 9, 5]



# Generated at 2022-06-25 13:14:19.159395
# Unit test for function pct_to_int

# Generated at 2022-06-25 13:14:20.773860
# Unit test for function pct_to_int
def test_pct_to_int():
    result = pct_to_int("33%", 3)
    assert result == 1


# Generated at 2022-06-25 13:14:28.708329
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_0 = ['a', 'b', 'c', 'a', 'b']
    pct_to_int_0 = pct_to_int('10%', 5, 1)
    assert pct_to_int_0 == 1
    pct_to_int_1 = pct_to_int('10', 5, 1)
    assert pct_to_int_1 == 10
    pct_to_int_2 = pct_to_int('a', 5, 1)
    assert pct_to_int_2 == 1
    pct_to_int_3 = pct_to_int('0', 5, 1)
    assert pct_to_int_3 == 1
    var_0 = deduplicate_list(complex_0)

# Generated at 2022-06-25 13:14:32.056629
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        test_case_0()
    except Exception as err:
        print("Testcase 0 Failed")
        print(err)
        assert False
    print("Testcase 0 Passed")

# Generated at 2022-06-25 13:14:33.596403
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert type(deduplicate_list(complex_0)) is list


# Generated at 2022-06-25 13:14:43.610611
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = {'key1': 'value1', 'key2': 'value2'}
    assert object_to_dict(obj) == {'key1': 'value1', 'key2': 'value2'}

    class Test:
        def __init__(self):
            self.key1 = 'value1'
            self.key2 = 'value2'

    obj = Test()
    assert object_to_dict(obj) == {'key1': 'value1', 'key2': 'value2'}

    class Test:
        def __init__(self):
            self._key1 = 'value1'
            self.key2 = 'value2'

    obj = Test()
    assert object_to_dict(obj) == {'key2': 'value2'}



# Generated at 2022-06-25 13:14:51.800964
# Unit test for function object_to_dict
def test_object_to_dict():
    from ansible.module_utils.nxos import object_to_dict
    from ansible.module_utils.nxos import get_capabilities
    from ansible.module_utils.nxos import get_device_info
    from ansible.module_utils.nxos import get_interface_capabilities
    from ansible.module_utils.nxos import get_lldp_neighbors_detail
    from ansible.module_utils.nxos import get_mac_address_table
    from ansible.module_utils.nxos import get_ntp_stats
    from ansible.module_utils.nxos import get_snmp_information
    from ansible.module_utils.nxos import get_interfaces
    from ansible.module_utils.nxos import get_arp_table
   

# Generated at 2022-06-25 13:14:56.661172
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 6, 8, 2, 1, 8, 10, 2, 8, 2, 1, 10, 8, 2, 6, 1]
    assert deduplicate_list(test_list) == [1, 2, 6, 8, 10]



# Generated at 2022-06-25 13:14:58.603431
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # assert deduplicate_list(complex_0) == expected_0
    pass



# Generated at 2022-06-25 13:15:07.442367
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # create test data for testing function.
    cases = [
        # list
        ["a", "e", "i", "o", "u", "a", "e", "i", "o", "u", "A", "E", "I", "O", "U"],
        # empty list
        [],
        # None
        None,
        # String
        "a"
    ]
    # loop through cases and test each one
    for case in cases:
        # create test data for testing function.
        test_data = deduplicate_list(case)
        # see if expected result is returned
        assert test_data == ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]



# Generated at 2022-06-25 13:15:08.490870
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(None) is None

# Generated at 2022-06-25 13:15:12.553265
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 1, 3, 4, 5, 2, 6, 7, 1, 2, 8]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8]

    actual_list = deduplicate_list(original_list)
    assert expected_list == actual_list


# Generated at 2022-06-25 13:15:15.740431
# Unit test for function object_to_dict
def test_object_to_dict():
    example = object_to_dict(interface_name = 'Ethernet1/1', bandwidth = '10')
    assert example == {'interface_name': 'Ethernet1/1', 'bandwidth': '10'}

# Generated at 2022-06-25 13:15:24.176724
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObject(object):

        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_obj = MyObject('a', 'b')
    assert object_to_dict(test_obj) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(test_obj, ['a']) == {'b': 'b'}
    pass


# Generated at 2022-06-25 13:15:26.446181
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict(test_case_0)
    assert obj == test_case_0.__code__.co_consts[0]


# Generated at 2022-06-25 13:15:28.128773
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict(test_object_to_dict)
    assert isinstance(obj, dict)
    assert 'test_object_to_dict' in obj



# Generated at 2022-06-25 13:15:29.347529
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert callable(deduplicate_list)


# Generated at 2022-06-25 13:15:31.246757
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(5) == {'real': 5, 'imag': 0}
    assert object_to_dict(None) == {}


# Generated at 2022-06-25 13:15:38.180055
# Unit test for function object_to_dict
def test_object_to_dict():
    """Test object_to_dict function"""

    class FooObj:
        """A simple class for making testing objects"""
        def __init__(self, foo_attr, foo_attr_two=1, foo_attr_three=2):
            self.foo_attr = foo_attr
            self.foo_attr_two = foo_attr_two
            self.foo_attr_three = foo_attr_three

    foo_obj = FooObj(1)

    dict_from_obj = object_to_dict(foo_obj)

    assert 'foo_attr' in dict_from_obj
    assert 'foo_attr_two' in dict_from_obj
    assert 'foo_attr_three' in dict_from_obj

    assert 'foo_attr' in dict_from_obj

# Generated at 2022-06-25 13:15:48.217325
# Unit test for function object_to_dict

# Generated at 2022-06-25 13:15:56.769147
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(None) == None
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 1]) == [1]
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2, 1, 2]) == [1, 2]

# Generated at 2022-06-25 13:15:59.368570
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_0 = ['cisco_ios', 'cisco_ios', 'cisco_nxos', 'cisco_nxos', 'cisco_nxos', 'arista_eos', 'arista_eos']
    output_0 = ['cisco_ios', 'cisco_nxos', 'arista_eos']
    assert deduplicate_list(input_0) == output_0

# Generated at 2022-06-25 13:16:01.874153
# Unit test for function object_to_dict
def test_object_to_dict():
    for key, value in object_to_dict(test_case_0).items():
        assert value != "" or key == "__builtins__"


# Generated at 2022-06-25 13:16:09.591717
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = [12, 'Ansible', 12, 12, 12, 12, 12, 'Ansible', 'Red Hat']
    # Compare results with expected one
    assert deduplicate_list(my_list) == [12, 'Ansible', 'Red Hat']

# Generated at 2022-06-25 13:16:14.810871
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_1 = [1, 2, 3, 4, 5, 2, 3, 4, 5, 2, 4, 2, 4, 2, 1, 2, 3, 4, 5, 2, 3, 4, 5, 2, 4, 2, 4, 2]
    list_1_expected = [1, 2, 3, 4, 5]
    assert deduplicate_list(list_1) == list_1_expected



# Generated at 2022-06-25 13:16:23.243686
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','b','c','d','a','e','f','f','g','h','h','g','i','i','j','k','k','k','k','j']) == ['a','b','c','d','e','f','g','h','i','j','k']
    assert deduplicate_list(['a','b','c','d','e','f','g','h','i','j','k','k','k','k','j','i','h','g','f','e','d','c','b','a']) == ['a','b','c','d','e','f','g','h','i','j','k']
    assert deduplicate_list([]) == []
    assert deduplicate_list([1,2,3]) == [1,2,3]


# Generated at 2022-06-25 13:16:26.861209
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["1","2","3","3","3","4","4","4","4","5","6","7","8","9","9","9","9","9"]
    deduplicate_list(original_list)



# Generated at 2022-06-25 13:16:36.294387
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,4,4,5,3,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5]) == [1,2,3,4,5], 'This should return [1,2,3,4,5]'

# Generated at 2022-06-25 13:16:45.839852
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([-1.0, 2, 3, 2]) == [-1.0, 2, 3]
    assert deduplicate_list([-1.0, 2, 3, 2]) == [-1.0, 2, 3]
    assert deduplicate_list([3, 2, 3, 2]) == [3, 2]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 2.0]) == [1, 2, 3, 2.0]
    assert deduplicate_list([2, 3, 3, 2]) == [2, 3]

# Generated at 2022-06-25 13:16:48.443713
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object_to_dict(object())
    assert isinstance(obj, dict)
    obj = object_to_dict(object(), exclude=["test"])
    assert isinstance(obj, dict)



# Generated at 2022-06-25 13:16:48.935421
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


# Generated at 2022-06-25 13:16:50.324454
# Unit test for function object_to_dict
def test_object_to_dict():
    test_obj = type('test', (object, ), {'a': 1, 'b': 2})
    assert {'a': 1, 'b': 2} == object_to_dict(test_obj)


# Generated at 2022-06-25 13:16:53.137779
# Unit test for function object_to_dict
def test_object_to_dict():
    exclude = []
    class TestObj:
        a = 1
        b = 2
        def _member_func_1(self):
            return "member_func_1"
    obj = TestObj()
    result = object_to_dict(obj, exclude)
    assert result.get('a') == 1
    assert result.get('b') == 2


# Generated at 2022-06-25 13:17:11.118691
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_1 = [1, 2, 3, 4]
    complex_2 = [1, 1, 1, 2, 3, 3, 3, 3, 4, 4, 4]
    complex_3 = [1, 2, 3, 3, 3, 3, 4, 4, 4]
    complex_4 = [1, 1, 2, 2, 2, 3, 4, 4, 4]
    complex_5 = ['test', 'test']
    complex_6 = ['test', 'test', 'test']
    complex_7 = 'test'
    complex_8 = [1, 1, 2, 'test', 4, 5, 6, 7]
    complex_9 = ['test', 'test', 'test', 1, 1, 2, 'test', 4, 5, 6, 7]

# Generated at 2022-06-25 13:17:14.020494
# Unit test for function object_to_dict
def test_object_to_dict():
    ret_obj = object_to_dict({"test1": "test1", "test2": "test2"})
    assert ret_obj["test1"] == "test1"
    assert ret_obj["test2"] == "test2"


# Generated at 2022-06-25 13:17:21.483839
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['1', '1', '2', '3', '4', '4', '5', '1']) == ['1', '2', '3', '4', '5']
    assert deduplicate_list(['1', '1', '1', '1', '1', '1', '1']) == ['1']
    assert deduplicate_list(['1', '1']) == ['1']
    assert deduplicate_list(['1']) == ['1']
    assert deduplicate_list([]) == []
    assert deduplicate_list(None) == []


# Generated at 2022-06-25 13:17:23.279824
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'quux', 'bar', 'quux']
    expected_results = ['foo', 'bar', 'quux']
    results = deduplicate_list(original_list)

    assert results == expected_results


# Generated at 2022-06-25 13:17:24.340695
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert callable(deduplicate_list), "Function does not exist"


# Generated at 2022-06-25 13:17:30.771827
# Unit test for function deduplicate_list
def test_deduplicate_list():
    x = [1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    y = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    z = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    test_case_0()
    assert y == z, 'Expected: %s, Got: %s' % (y, z)

# Generated at 2022-06-25 13:17:34.978913
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        assert len(deduplicate_list([43, 51, 63, 51, 63, 43])) == 3
    except AssertionError as e:
        raise AssertionError(str(e))

if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:17:43.092029
# Unit test for function object_to_dict
def test_object_to_dict():
    # This is a sample of the object and the desired dictionary result.
    class ExampleObject():
        some_property = "desired value"
        _some_property_excluded = "Not going to be in my dict"

    desired_dict = dict((key, getattr(ExampleObject, key)) for key in dir(ExampleObject) if not (key.startswith('_')))

    # This is the function we are testing.
    object_dict = object_to_dict(ExampleObject)

    # Now a simple assert to be sure it works as expected.
    assert object_dict == desired_dict

# Generated at 2022-06-25 13:17:47.335911
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = [{"b":2},{"b":3},{"a":2}]
    try:
        object_to_dict(obj)
    except AttributeError:
        print("AttributeError")
    else:
        print("No exception")
    assert(object_to_dict(obj)=={"b":3,"a":2})
    
    

# Generated at 2022-06-25 13:17:54.397151
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(BgpPeer(peer_address='1.1.1.1', peer_as=65300, remote_as=65300, peer_type='internal', remote_id='1.1.1.1', local_as=65001, auth_password='default', local_address='1.1.1.1', state='present', timeout=180), ['test']) == {'auth_password': 'default', 'local_as': 65001, 'local_address': '1.1.1.1', 'peer_as': 65300, 'peer_address': '1.1.1.1', 'peer_type': 'internal', 'remote_as': 65300, 'remote_id': '1.1.1.1', 'state': 'present', 'timeout': 180}

    assert object_to_

# Generated at 2022-06-25 13:18:16.802853
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,3]) == [1,2,3]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(None) is None


# Generated at 2022-06-25 13:18:19.748891
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['ansible', 'python', 'python', 'ansible', 'golang']) == ['ansible', 'python', 'golang']


# Generated at 2022-06-25 13:18:20.893696
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict('foo').has_key('bar')


# Generated at 2022-06-25 13:18:28.007146
# Unit test for function object_to_dict
def test_object_to_dict():
    mock_obj = MockObj(int_prop=42, str_prop="forty-two", list_prop=[1, 2, 3, 4], dict_prop={'key': 'value'})
    mock_obj_dict = object_to_dict(mock_obj)
    assert mock_obj_dict['int_prop'] == 42
    assert mock_obj_dict['str_prop'] == "forty-two"
    assert len(mock_obj_dict['list_prop']) == 4
    assert len(mock_obj_dict['dict_prop']) == 1


# Generated at 2022-06-25 13:18:29.708415
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(AnsibleModule, exclude=['module', 'connect_to']).get('argument_spec').get('type') == 'dict'


# Generated at 2022-06-25 13:18:31.202280
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert callable(deduplicate_list), "Function 'deduplicate_list' is not callable"


# Generated at 2022-06-25 13:18:32.752690
# Unit test for function object_to_dict
def test_object_to_dict():
    assert callable(object_to_dict), 'Function "object_to_dict" is not callable.'


# Generated at 2022-06-25 13:18:38.141855
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_0 = [
      'a',
      'b',
      'a',
      'c',
      'a',
      'b',
      'c',
      'c'
    ]
    var_0 = deduplicate_list(complex_0)
    result_0 = [
      'a',
      'b',
      'c'
    ]
    assert var_0 == result_0


# Generated at 2022-06-25 13:18:42.863394
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()
    a_list = ["apple", "banana", "carrot", "mango", "apple", "apple", "mango", "banana", "mango", "carrot"]
    uniq_list = deduplicate_list(a_list)
    assert uniq_list == ["apple", "banana", "carrot", "mango"]



# Generated at 2022-06-25 13:18:49.500577
# Unit test for function deduplicate_list
def test_deduplicate_list():
    ansible_test_array = [1,2,2,3,1,4,3,4,None]
    simple_test_array = ['foo1', 'foo2', 'bar1', 'bar2', 'foo1', 'bar1', 'bar2', 'foo2', 'foo2']
    ansible_test_res = deduplicate_list(ansible_test_array)
    simple_test_res = deduplicate_list(simple_test_array)
    assert len(ansible_test_res) == 6
    assert len(simple_test_res) == 7



# Generated at 2022-06-25 13:19:29.704438
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(test_case_0) == test_case_0

# Generated at 2022-06-25 13:19:33.794419
# Unit test for function deduplicate_list
def test_deduplicate_list():

    initial_list = [1, "string", 1, 1, 5, "string", False, False]
    expected_list = [1, "string", 5, False]

    assert deduplicate_list(initial_list) == expected_list
    #assert deduplicate_list(initial_list) == expected_list


# Generated at 2022-06-25 13:19:37.785666
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()


import json
import os
import sys
import unittest

if sys.version_info[0] >= 3:
    import builtins
    from io import StringIO
    string_types = str,
    from unittest.mock import patch
else:
    import __builtin__ as builtins
    from cStringIO import StringIO
    from mock import patch



# Generated at 2022-06-25 13:19:40.803595
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(None) == None
    assert deduplicate_list(['a', 'b', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-25 13:19:44.407201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_0 = [1, 2, 2, 3, 4, 5, 5, 1]
    var_0 = deduplicate_list(complex_0)
    assert var_0 == [1, 2, 3, 4, 5]



# Generated at 2022-06-25 13:19:45.378877
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_case_0()

#

# Generated at 2022-06-25 13:19:49.530649
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_empty = []
    assert len(deduplicate_list(list_empty)) == 0

    list_single = [3, 4, 7, 3]
    assert len(deduplicate_list(list_single)) == 3

    list_multiple = [1, 2, 3, 1, 4, 2, 5]
    assert len(deduplicate_list(list_multiple)) == 5


# Generated at 2022-06-25 13:19:58.686367
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1  = [1,1,1,1]
    list2  = [0,1,2,2,1]
    list3  = [0,2,2,2,1]
    list4  = [0,5,5,5,5]
    list5  = [0,0,0,0,0]
    list6  = [2,2,2,2,2]
    list7  = []
    list8  = [2,2,2,2,1,1,1]
    list9  = [2,2,2,1,1,1,1]
    list10 = [1,1,1,1,2,2,2]
    assert deduplicate_list(list1) == [1]

# Generated at 2022-06-25 13:20:00.044396
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:20:04.304755
# Unit test for function object_to_dict
def test_object_to_dict():
    class M():
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b

    obj = M(1, 2)
    assert object_to_dict(obj) == obj.__dict__



# Generated at 2022-06-25 13:21:32.595265
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_0 = [1, 2, 2, 3, 3, 1, 2]
    expected_0 = [1, 2, 3, 1, 2]

    actual_0 = deduplicate_list(input_0)

    assert expected_0 == actual_0

# Generated at 2022-06-25 13:21:36.698733
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [1, 2, 3, 4] == deduplicate_list([1, 1, 2, 3, 3, 4])
    assert [] == deduplicate_list([])
    assert [1] == deduplicate_list([1])
    assert [1, 2] == deduplicate_list([1, 2, 2, 1, 1, 2])

# Generated at 2022-06-25 13:21:43.707902
# Unit test for function object_to_dict
def test_object_to_dict():
    check = object_to_dict('some string')
    assert check == {}

    class SomeClass:
        def __init__(self):
            self._some_property = 0
            self.some_property = 1

    class SomeClassExclude:
        def __init__(self):
            self._some_property = 0
            self.some_property = 1

    check = object_to_dict(SomeClass())
    assert check == {'_some_property': 0, 'some_property': 1}

    check = object_to_dict(SomeClassExclude(), exclude=['_some_property'])
    assert check == {'some_property': 1}


# Generated at 2022-06-25 13:21:45.188616
# Unit test for function object_to_dict
def test_object_to_dict():
    var_none = object_to_dict(None)
    assert var_none is None


# Generated at 2022-06-25 13:21:51.125189
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, '2', 3, 1, 3, 1, 3, 3, '2', '2', '2', 1, 2, 3, 1, '2', 3, 1, 3, 1, 3, 3, '2', '2', '2']) \
        == [1, 2, 3, '2']
    assert deduplicate_list([1, 2, 1, 2, 1, 2, 3, 4, 5, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-25 13:21:57.358293
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = object()
    obj.__dict__['foo'] = 'bar'
    obj.__dict__['bar'] = 'baz'
    obj.__dict__['ham'] = 'spam'
    obj.spam = 'eggs'
    result = object_to_dict(obj, exclude=['bar'])
    assert 'foo' in result
    assert 'bar' not in result
    assert 'ham' in result
    assert 'spam' in result
    assert 'eggs' in result
    assert result.get('foo') == 'bar'
    assert result.get('ham') == 'spam'
    assert result.get('spam') == 'eggs'


# Generated at 2022-06-25 13:22:06.434199
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test with an empty exclude list
    class testObj(object):
        _debug = False
        _test = True
        _keys = None
        def __init__(self, test, debug):
            self.test = test
            self._debug = debug
        def to_dict(self):
            return object_to_dict(self, self._keys)
    obj = testObj(1, 'debug')
    result = obj.to_dict()
    assert '_debug' in result
    assert '_test' in result
    assert 'test' in result
    assert result['_test'] is True
    assert result['test'] is 1
    assert result['_debug'] == 'debug'

    # Test with an exclude list
    class testObj(object):
        _debug = False
        _test = True

# Generated at 2022-06-25 13:22:10.230760
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert ['a'] == deduplicate_list(['a'])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c'])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-25 13:22:12.467397
# Unit test for function deduplicate_list
def test_deduplicate_list():
    complex_0 = [1, 2, 2, 3, 4]
    var_0 = deduplicate_list(complex_0)

    assert var_0 == [1, 2, 3, 4]



# Generated at 2022-06-25 13:22:14.781075
# Unit test for function deduplicate_list
def test_deduplicate_list():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

