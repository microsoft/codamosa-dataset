

# Generated at 2022-06-25 13:13:53.506541
# Unit test for function pct_to_int
def test_pct_to_int():
    a = '1'
    assert pct_to_int(a, 100) == 1
    b = '%'
    assert pct_to_int(b, 100) == 1
    c = '%'
    assert pct_to_int(c, 100, 2) == 2
    d = '101%'
    assert pct_to_int(d, 100) == 101
    e = '100'
    assert pct_to_int(e, 100) == 100
    f = '110'
    assert pct_to_int(f, 100) == 110


# Generated at 2022-06-25 13:13:56.109625
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input = [1, 2, 100, 2, 100]
    output = deduplicate_list(input)
    assert len(output) == 3
    assert output == [1, 2, 100]



# Generated at 2022-06-25 13:14:01.853932
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(95, 100) == 95
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('95%', 100) == 95
    assert pct_to_int(0, 100, min_value=50) == 50
    assert pct_to_int(0, 100) == 1


# Generated at 2022-06-25 13:14:03.067275
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50


# Generated at 2022-06-25 13:14:08.594164
# Unit test for function pct_to_int
def test_pct_to_int():
    value = pct_to_int('15%', num_items=1000)
    assert value == 150
    value = pct_to_int(150, num_items=1000)
    assert value == 150
    value = pct_to_int('15%', num_items=10)
    assert value == 1
    value = pct_to_int('15%', num_items=1)
    assert value == 1
    value = pct_to_int('15%', num_items=0)
    assert value == 1
    value = pct_to_int('15', num_items=1000)
    assert value == 15


# Generated at 2022-06-25 13:14:20.043404
# Unit test for function object_to_dict
def test_object_to_dict():
    str_0 = '/9!C!,xLeeCKxf,O{\x0c'
    var_0 = object_to_dict(str_0)

# Generated at 2022-06-25 13:14:25.368796
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('99%', 100, min_value=10) == 10


# Generated at 2022-06-25 13:14:29.301405
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('110%', 100) == 110
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('10%', 10, 5) == 5


# Generated at 2022-06-25 13:14:32.571493
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 100) == 20
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int(20, 50) == 10
    assert pct_to_int('20%', 50) == 10
    assert pct_to_int('20%', 25) == 5
    assert pct_to_int('20%', 2) == 1



# Generated at 2022-06-25 13:14:42.584355
# Unit test for function pct_to_int
def test_pct_to_int():
    assert( pct_to_int(25, 100, 1) == 25 )
    assert( pct_to_int(75, 200, 1) == 150 )
    assert( pct_to_int('50%', 200, 1) == 100 )
    assert( pct_to_int('50%', 200, 1) == 100 )
    assert( pct_to_int('50%', 0, 1) == 1 )
    assert( pct_to_int('50%', 0, 5) == 5 )
    assert( pct_to_int('100%', 10, 1) == 10 )
    assert( pct_to_int('100%', 10, 0) == 10 )
    assert( pct_to_int(100, 10, 5) == 10 )

# Generated at 2022-06-25 13:14:51.426707
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 3, 5, 2, 1, 2, 3, 4, 5, 2, 3, 2, 3, 3, 4, 2, 1, 2, 5, 2, 1, 2, 4, 2, 1, 2, 5, 2, 1, 4, 1, 2]
    deduplicated_list = deduplicate_list(original_list)

    assert deduplicated_list == [1, 2, 3, 4, 5, 6, 7]


# Generated at 2022-06-25 13:14:58.176479
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 2, 3, 2, 3, 4, 1]
    assert(deduplicate_list(list1) == [1, 2, 3, 4])
    list2 = [1]
    assert(deduplicate_list(list2) == [1])
    list3 = []
    assert(deduplicate_list(list3) == [])



# Generated at 2022-06-25 13:15:07.401491
# Unit test for function object_to_dict
def test_object_to_dict():
    # Test var_0 is a string
    str_0 = '/9!C!,xLeeCKxf,O{\x0c'
    var_0 = object_to_dict(str_0)
    # Test var_1 is a string
    str_1 = '\x0c%S\n~'
    var_1 = object_to_dict(str_1)
    # Test var_2 is a string
    str_2 = '"+R<"J\x1aX\x1cQ;$J}n'
    var_2 = object_to_dict(str_2)
    # Test var_3 is a string
    str_3 = '\x1a$J\x1c\x1d'
    var_3 = object_to_dict(str_3)
    # Test var

# Generated at 2022-06-25 13:15:09.729066
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [1, 2, 2, 3, 4, 4, 4, 5]
    var_0 = deduplicate_list(list_0)


# Generated at 2022-06-25 13:15:15.647093
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a = [1, 2, 1, 1, 4, 5, 6, 7, 8, 4, 5, 9, 10, 10, 0, 9, 99, 99, 99, 99, 99, 1, 5]
    d = deduplicate_list(a)
    if d == [1, 2, 4, 5, 6, 7, 8, 9, 10, 0, 99]:
        return True
    else:
        return False


# Generated at 2022-06-25 13:15:18.675554
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['test', 'test', 'test1', 1, 1, 2, 3, 3]
    assert(deduplicate_list(test_list) == ['test', 'test1', 1, 2, 3])


# Generated at 2022-06-25 13:15:23.489667
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_original = ['a', 'a', 'b', 'b', 'c']
    list_deduplicated = deduplicate_list(list_original)
    assert isinstance(list_deduplicated, list)
    assert list_deduplicated == ['a', 'b', 'c']


# Generated at 2022-06-25 13:15:26.572401
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(["a", "b", "a"]) == ["a", "b"]


# Generated at 2022-06-25 13:15:29.384860
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 4, 3, 2, 1]) == [1, 2, 3, 4]


# Generated at 2022-06-25 13:15:30.946354
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 1]) == [1, 2, 3]


# Generated at 2022-06-25 13:15:39.941385
# Unit test for function object_to_dict
def test_object_to_dict():
    func_name = 'object_to_dict'
    test_cases = [
        (test_case_0.__name__, test_case_0),
    ]

    for case in test_cases:
        try:
            case[1]()
        except Exception:
            print('Test %s failed' % case[0])



# Generated at 2022-06-25 13:15:42.849738
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([12,24,35,24,88,120,155,88,120,155]) == [12,24,35,88,120,155]

# Generated at 2022-06-25 13:15:52.122389
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert [1, 2, 3] == deduplicate_list([1, 1, 2, 2, 2, 3, 3, 3, 3])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'c', 'c'])
    assert ['a', 'b', 'c'] == deduplicate_list(['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'c', 'c', 'c'])
    assert ['a', 'b', 'c', 'd', 'e'] == deduplicate_list(['a', 'b', 'c', 'd', 'e'])

# Generated at 2022-06-25 13:15:56.459411
# Unit test for function object_to_dict
def test_object_to_dict():
    str_0 = '/9!C!,xLeeCKxf,O{\x0c'
    var_0 = object_to_dict(str_0)
    var_1 = (True, False)
    var_2 = object_to_dict(var_1)
    print("var_0 = " + str(var_0))
    print("var_2 = " + str(var_2))



# Generated at 2022-06-25 13:16:00.777895
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # test_case_0
    original_list = [2, 3, 2, 1, 2, 3, 2, 1, 2, 1]
    var_0 = deduplicate_list(original_list)

if __name__ == '__main__':
    # test_case_0
    str_0 = '/9!C!,xLeeCKxf,O{\x0c'
    var_0 = object_to_dict(str_0)

# Generated at 2022-06-25 13:16:02.966103
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_cases = ['a', 'a', 'a', 'b']
    assert deduplicate_list(test_cases) == ['a', 'b']


# Generated at 2022-06-25 13:16:03.837997
# Unit test for function object_to_dict
def test_object_to_dict():

    assert test_case_0()
    


# Generated at 2022-06-25 13:16:05.052968
# Unit test for function object_to_dict
def test_object_to_dict():
    var_1 = test_case_0()
    assert 'chars' in var_1

# Generated at 2022-06-25 13:16:07.757815
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'd', 'a']
    expected = ['a', 'b', 'c', 'd']
    result = deduplicate_list(test_list)
    assert result == expected



# Generated at 2022-06-25 13:16:12.326020
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_data = [1, 2, 3, 1, 4, 2, 5, 6, 4, 2, 1, 7, 8, 9, 0]
    expected = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    actual = deduplicate_list(test_data)
    assert actual == expected, 'Result did not match the expected value'



# Generated at 2022-06-25 13:16:29.358824
# Unit test for function deduplicate_list
def test_deduplicate_list():
    var_1 = [1,2,2,3,4,4]
    var_2 = deduplicate_list(var_1)
    assert var_2 == [1,2,3,4]


# Generated at 2022-06-25 13:16:32.281081
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']


# Generated at 2022-06-25 13:16:37.319735
# Unit test for function deduplicate_list
def test_deduplicate_list():
    orig_list = ['a', 'b', 'c', 'c', 'c', 'b', 'c', 'd']
    expected_list = ['a', 'b', 'c', 'd']
    deduped_list = deduplicate_list(orig_list)
    assert deduped_list == expected_list, "Expected {}, got {}".format(expected_list, deduped_list)

# Generated at 2022-06-25 13:16:40.882999
# Unit test for function deduplicate_list
def test_deduplicate_list():
    str_list = ["ls", "-l", "foo", "-l", "bar", "-l"]
    str_list2 = deduplicate_list(str_list)
    assert(str_list2 == ["ls", "-l", "foo", "bar"])

# Generated at 2022-06-25 13:16:41.817813
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 1, 4, 2]) == [1, 2, 3, 4]



# Generated at 2022-06-25 13:16:45.260266
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([0, 1, 2, 3]) == [0, 1, 2, 3]
    assert deduplicate_list([0, 1, 2, 3, 0]) == [0, 1, 2, 3]


# Generated at 2022-06-25 13:16:47.858882
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'a', 'b', 'b', 'c', 'd', 'd']
    assert(deduplicate_list(test_list)) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 13:16:49.359216
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-25 13:16:52.495471
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list_0 = [True, 'i', ':', '=', 30, 30]
    var_0 = deduplicate_list(test_list_0)
    expected = [True, 'i', ':', '=', 30]
    if var_0 == expected:
        print('test_deduplicate_list passed')
    else:
        print('test_deduplicate_list failed')


# Generated at 2022-06-25 13:17:00.364224
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [ '~j\x7f\x08', 'Jc\x1a\x1f\x1e', '~j\x7f\x08', '\x1e', '\x1e', '\x7f\x08', '\x7f\x08', '\x1a\x1f\x1e', '\x7f\x08', 'Jc\x1a\x1f\x1e', 'Jc\x1a\x1f\x1e', '\x1e' ]
    assert len(list_0) == 12
    deduplicate_list(list_0)
    assert len(list_0) == 6


# Generated at 2022-06-25 13:17:28.221576
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["a", "b", "c", "a", "b"]) == ["a", "b", "c"]



# Generated at 2022-06-25 13:17:29.486603
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 3, 5]) == [1, 2, 3, 5]

# Generated at 2022-06-25 13:17:39.912236
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print('Test for object_to_dict')

    original_list = ['2', '2', '2', '2', '2', '2', '2', '1', '1', '1', '1', '1']
    actual = deduplicate_list(original_list)
    assert actual == ['2', '1']

    original_list = ['2', '2', '2', '2', '2', '1', '1', '1', '1', '1']
    actual = deduplicate_list(original_list)
    assert actual == ['2', '1']

    original_list = ['1', '1', '1', '1', '1', '2', '2', '2', '2', '2']
    actual = deduplicate_list(original_list)

# Generated at 2022-06-25 13:17:43.627443
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1,3,2,2,1,1,2,2,2,2,2,2,2,2]
    test_results = [1,3,2]
    assert deduplicate_list(test_list) == test_results


# Generated at 2022-06-25 13:17:50.136470
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import random
    from itertools import chain
    #Example 1:
    list_0 = [ random.random() for x in range(1,10) ]
    deduplicate_list(list_0)

    #Example 2:
    list_0 = [ random.randint(1,9) for x in range(50) ]
    deduplicate_list(list_0)

    #Example 3:
    list_0 = list(chain(range(1,10),range(1,10)))
    deduplicate_list(list_0)


# Generated at 2022-06-25 13:17:54.916760
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a List of ints
    dup_list = [1, 2, 3, 1, 2, 5, 6, 7, 8, 5, 9]
    # Create another List of ints
    dedup_list = deduplicate_list(dup_list)
    print(dedup_list)


# Generated at 2022-06-25 13:17:58.262208
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['2', '1', '1', '1', '3', '3', '3']
    result = deduplicate_list(original_list)
    assert(result == ['2', '1', '3'])

# Generated at 2022-06-25 13:18:03.641352
# Unit test for function deduplicate_list
def test_deduplicate_list():
    input_0 = ['a', 'b', 'c', 'a', 'd']
    expect = ['a', 'b', 'c', 'd']
    actual = deduplicate_list(input_0)
    assert expect == actual, """\
deduplicate_list(%r) returned %r, not %r\
""" % (input_0, actual, expect)



# Generated at 2022-06-25 13:18:07.382991
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'c', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []



# Generated at 2022-06-25 13:18:13.247736
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 3, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 1, 1, 2, 3, 3, 3, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([5, 4, 3, 3, 3, 3, 2, 1]) == [5, 4, 3, 2, 1]
    assert deduplicate_list([5, 4, 3, 2, 1, 1, 1, 1]) == [5, 4, 3, 2, 1]


# Generated at 2022-06-25 13:19:11.574834
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,1]) == [1, 2, 3]
    assert deduplicate_list([1,1,1,1]) == [1]
    assert deduplicate_list(['1','1','1','1']) == ['1']
    assert deduplicate_list([1,'1']) == [1,'1']
    assert deduplicate_list([None,None,None,None]) == [None]
    assert deduplicate_list(['a','b','c','d']) == ['a','b','c','d']


# Generated at 2022-06-25 13:19:14.537070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'c', 'c', 'c']) == ['a', 'b', 'c']

if __name__ == "__main__":
    test_deduplicate_list()

# Generated at 2022-06-25 13:19:16.961239
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # These tests ensure that deduplicate_list gets executed
    original_list_0 = [None, None]
    deduplicate_list(original_list_0)


# Generated at 2022-06-25 13:19:19.007566
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert ['A', 'B', 'C'] == deduplicate_list(['A', 'A', 'B', 'A', 'B', 'C'])


# Generated at 2022-06-25 13:19:21.813734
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['6', '', '0', '6', 'z', 'K', 'q', '6', '0', 'I']
    var_0 = deduplicate_list(list_0)



# Generated at 2022-06-25 13:19:23.293323
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list('ABC') == ['A', 'B', 'C']


# Generated at 2022-06-25 13:19:27.778577
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["foo", "foo", "bar", "bar", "baz", "baz", "baz", "baz", "baz", "foo", "baz"]) == ["foo", "bar", "baz"]

test_case_0()

# Generated at 2022-06-25 13:19:36.091974
# Unit test for function deduplicate_list

# Generated at 2022-06-25 13:19:41.929440
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([ 1, 2, 3, 2, 1 ]) == [ 1, 2, 3 ]
    assert deduplicate_list([ 1, 2, 3, 2, 3, 1 ]) == [ 1, 2, 3 ]
    assert deduplicate_list([ 1, 2, 3, 4, 5 ]) == [ 1, 2, 3, 4, 5 ]
    assert deduplicate_list([ 1, 1, 1, 1, 1 ]) == [ 1 ]



# Generated at 2022-06-25 13:19:46.918225
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,2,2,2,2,3,3,3,3,3,3]) == [1, 2, 3]
    assert deduplicate_list(["foo", "foo", "foo", "bar", "bar", "bar"]) == ["foo", "bar"]
    assert deduplicate_list([]) == []



# Generated at 2022-06-25 13:20:13.697605
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'a', 'b', 'a', 'c', 'd', 'e', 'd', 'g', 'b', 'f']
    assert deduplicate_list(original_list) == ['a', 'b', 'c', 'd', 'e', 'g', 'f']



# Generated at 2022-06-25 13:20:16.605976
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'a', 'c', 'c', 'a']
    expected = ['a', 'b', 'c']
    actual = deduplicate_list(original_list)
    assert expected == actual


# Generated at 2022-06-25 13:20:19.102416
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 1, 4, 3, 3, 3, 2]) == [1, 2, 4, 3]


# Generated at 2022-06-25 13:20:21.955367
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'f', 'c'])
    assert(result == ['a', 'b', 'c', 'f'])


# Generated at 2022-06-25 13:20:25.180122
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,2,2,2,2,4]) == [1,2,4]
    assert deduplicate_list('123123123') == ['1', '2', '3']

# Generated at 2022-06-25 13:20:33.970962
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd']
    assert deduplicate_list(original_list) == ['a', 'b', 'c', 'd']
    original_list = ['excl1', 'excl2', 'c', 'd', 'excl1', 'excl2', 'c', 'd']
    assert deduplicate_list(original_list) == ['c', 'd', 'excl1', 'excl2']
    original_list = ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 'd']
    assert deduplicate_list(original_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 13:20:37.781660
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 1, 5, 3, 6, 3, 5, 3, 6, 3, 5, 1, 6, 3, 5, 9, 4, 8, 5, 9]) == [1, 2, 3, 5, 6, 9, 4, 8]

if __name__ == "__main__":
    test_case_0()
    test_deduplicate_list()

# Generated at 2022-06-25 13:20:39.143353
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a']) == ['a', 'b', 'c']

# Generated at 2022-06-25 13:20:42.307153
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 4, 2, 5, 6, 1, 9]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 4, 5, 6, 9]

# Generated at 2022-06-25 13:20:44.830969
# Unit test for function deduplicate_list
def test_deduplicate_list():
    x = ['a', 'b', 'c', 'a', 'b', 'd']
    assert deduplicate_list(x) == ['a', 'b', 'c', 'd']


# Generated at 2022-06-25 13:21:30.573726
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 1, 3, 2, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-25 13:21:34.593616
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'z', 'a']
    assert(deduplicate_list(test_list) == ['a', 'b', 'z'])

if __name__ == '__main__':
    test_case_0()
    test_deduplicate_list()

# Generated at 2022-06-25 13:21:36.738630
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'a', 'c', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-25 13:21:38.581237
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]


# Generated at 2022-06-25 13:21:40.841409
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['a', 'b', 'c', 'b', 'a']
    assert deduplicate_list(list_0) == ['a', 'b', 'c']


# Generated at 2022-06-25 13:21:45.786475
# Unit test for function deduplicate_list
def test_deduplicate_list():
    print("Testing deduplicate_list")
    test_list = [1, 2, 3, 3, 3, 2, 10, 2, 10, 10, 3, 3]
    result = deduplicate_list(test_list)
    print("Result: {0}".format(result))
    assert result == [1, 2, 3, 10]
    print("deduplicate_list test passed")


# Generated at 2022-06-25 13:21:47.424095
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 3, 5]
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == [1, 2, 3, 5]

# Generated at 2022-06-25 13:21:54.084780
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 4, 5, 6, 4, 4, 5, 6, 7, 8, 5, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 2, 3, 2, 4, 2, 5, 2, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list(['a', 'a', 'a', 'a', 'b', 'a', 'a', 'a', 'a', 'a', 'a', 'a']) == ['a', 'b', 'a']
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([]) == []



# Generated at 2022-06-25 13:21:56.610052
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list((1,2,3,3,2,2,2,2,2,3,3,3,3,3,3,3)) == (1,2,3)


test_deduplicate_list()

# Generated at 2022-06-25 13:21:59.314339
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [2, 4, 6, 8, 10, 12, 10, 8, 6, 4, 2]
    assert deduplicate_list(original_list) == [2, 4, 6, 8, 10, 12]



# Generated at 2022-06-25 13:23:37.209568
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = ['foo', 'foo']
    list_1 = ['foo', 'bar']
    assert deduplicate_list(list_0) == ['foo']
    assert deduplicate_list(list_1) == ['foo', 'bar']

# Generated at 2022-06-25 13:23:42.741170
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_0 = [u'Bc', u'', u'l', u'Q', u'Sg', u'', u'', u'D', u'p', u'X']
    list_1 = [u'Bc', u'l', u'Q', u'Sg', u'D', u'p', u'X']
    list_2 = deduplicate_list(list_0)
    assert(list_1 == list_2)

