

# Generated at 2022-06-17 15:04:10.721090
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('0.5%', 100, min_value=10) == 10
    assert pct_to_int('0.9%', 100, min_value=10) == 10
    assert pct_to_int('0.99%', 100, min_value=10) == 10
    assert pct_to_int('0.999%', 100, min_value=10)

# Generated at 2022-06-17 15:04:21.330189
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:04:28.525721
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert dedupl

# Generated at 2022-06-17 15:04:38.165771
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_key3'])
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert 'test_key3' not in test_dict

# Generated at 2022-06-17 15:04:48.434665
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=10) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=10) == 101

# Generated at 2022-06-17 15:04:53.138955
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:05:01.297147
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=0) == 50
    assert pct_to_int('50%', 100, min_value=1) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('50%', 100, min_value=3) == 50
    assert pct_to_int('50%', 100, min_value=4) == 50
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int('50%', 100, min_value=6) == 50

# Generated at 2022-06-17 15:05:13.015194
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:05:22.246706
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to_int(1, 100, min_value=5) == 5
    assert pct_to_int(1, 100, min_value=5) == 5

# Generated at 2022-06-17 15:05:34.368153
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:05:46.653549
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert test_dict['test_key3'] == 'test_value3'

    test_dict = object_to_dict(test_obj, exclude=['test_key2'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict
    assert test

# Generated at 2022-06-17 15:05:58.224680
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:07.646127
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:06:15.438965
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 1, 1]) == [1]
    assert deduplicate_list([1, 2, 3, 4, 3, 2, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 3, 2, 1, 5, 6, 7, 8, 7, 6, 5]) == [1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-17 15:06:23.374481
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:06:31.279357
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert test_dict['test_attr4'] == 'test_attr4'

# Generated at 2022-06-17 15:06:36.932055
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self._test_key3 = 'test_value3'

    obj = TestClass()
    obj_dict = object_to_dict(obj)
    assert obj_dict['test_key'] == 'test_value'
    assert obj_dict['test_key2'] == 'test_value2'
    assert '_test_key3' not in obj_dict
    obj_dict = object_to_dict(obj, exclude=['test_key2'])
    assert obj_dict['test_key'] == 'test_value'
    assert 'test_key2' not in obj_dict
    assert '_test_key3' not in obj_

# Generated at 2022-06-17 15:06:45.478271
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3



# Generated at 2022-06-17 15:06:55.847596
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property_2 = 'test_value_2'
            self._test_property_3 = 'test_value_3'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property_2'] == 'test_value_2'
    assert '_test_property_3' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_property_2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property_2' not in test_

# Generated at 2022-06-17 15:07:07.331749
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7])

# Generated at 2022-06-17 15:07:16.744740
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:28.815773
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4', '_test_attr3'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict
    assert test_

# Generated at 2022-06-17 15:07:38.725126
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:07:48.337732
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'
            self.f = 'f'
            self.g = 'g'
            self.h = 'h'
            self.i = 'i'
            self.j = 'j'
            self.k = 'k'
            self.l = 'l'
            self.m = 'm'
            self.n = 'n'
            self.o = 'o'
            self.p = 'p'
            self.q = 'q'
            self.r = 'r'
            self.s = 's'
            self.t = 't'
            self

# Generated at 2022-06-17 15:07:57.467503
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_value'
            self.test_attr2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_value'
    assert test_dict['test_attr2'] == 'test_value2'
    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict
    assert test_dict['test_attr2'] == 'test_value2'

# Generated at 2022-06-17 15:08:09.636845
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:20.475590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:08:33.363185
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:08:47.315828
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'
            self.test_attr6 = 'test_attr6'
            self.test_attr7 = 'test_attr7'
            self.test_attr8 = 'test_attr8'
            self.test_attr9 = 'test_attr9'
            self.test_attr10 = 'test_attr10'
            self.test_attr11 = 'test_attr11'
            self.test_attr12 = 'test_attr12'
            self

# Generated at 2022-06-17 15:08:58.194689
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:11.569200
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr1'] == 'test_attr1'
    assert 'test_attr2' not in test

# Generated at 2022-06-17 15:09:20.749579
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = TestObject()
    obj_dict = object_to_dict(obj)
    assert obj_dict['a'] == 1
    assert obj_dict['b'] == 2
    assert obj_dict['c'] == 3

    obj_dict = object_to_dict(obj, exclude=['a'])
    assert obj_dict['a'] == 1
    assert obj_dict['b'] == 2
    assert obj_dict['c'] == 3

    obj_dict = object_to_dict(obj, exclude=['a', 'b'])
    assert obj_dict['a'] == 1
    assert obj_dict['b'] == 2

# Generated at 2022-06-17 15:09:28.544911
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-17 15:09:35.650767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:09:39.513330
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:46.589387
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:51.814937
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property_exclude = 'test_value_exclude'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_property_exclude'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property_exclude' not in test_dict

# Generated at 2022-06-17 15:10:00.793851
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:10:08.268860
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b', 'c', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a', 'b', 'c', 'c', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-17 15:10:16.088987
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test_obj = TestClass('a', 'b', 'c')
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'

    test_obj = TestClass('a', 'b', 'c')
    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'

    test_obj = TestClass

# Generated at 2022-06-17 15:10:31.606261
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:10:38.673704
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:10:41.908876
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 4, 1, 5, 2]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:49.343070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:10:57.939556
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'

    test_dict = object_to_dict(test_obj, ['test_property'])
    assert 'test_property' not in test_dict
    assert test_dict['test_property2'] == 'test_value2'

# Generated at 2022-06-17 15:11:06.045947
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6, 1, 2, 3, 2, 1, 4, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6, 1, 2, 3, 2, 1, 4, 5, 4, 5, 6, 1, 2, 3, 2, 1, 4, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:11:14.447956
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26



# Generated at 2022-06-17 15:11:24.444497
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:11:35.764878
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr1'])
    assert 'test_attr1' not in test_dict

# Generated at 2022-06-17 15:11:42.489039
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self._test_property3 = 'test_value3'

    test_object = TestClass()
    test_dict = object_to_dict(test_object, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict
    assert '_test_property3' not in test_dict

# Generated at 2022-06-17 15:12:03.706871
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:13.665573
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 6, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 6, 6, 1]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 6, 6, 1, 1]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:22.993598
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:12:26.324474
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key_2 = 'test_value_2'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key_2'] == 'test_value_2'
    assert len(test_dict) == 2

    test_dict = object_to_dict(test_obj, exclude=['test_key'])
    assert test_dict['test_key'] == 'test_value'
    assert len(test_dict) == 1



# Generated at 2022-06-17 15:12:33.002519
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test'
            self.test_attr2 = 'test2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test'
    assert test_dict['test_attr2'] == 'test2'
    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict
    assert test_dict['test_attr2'] == 'test2'

# Generated at 2022-06-17 15:12:46.516922
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:53.345792
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:13:04.916375
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:13:15.919365
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self._d = 4
            self._e = 5
            self.f = 6

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['f'] == 6
    assert '_d' not in test_dict
    assert '_e' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['a', 'b', 'c'])
    assert 'a' not in test_dict
    assert 'b' not in test

# Generated at 2022-06-17 15:13:24.492006
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:13:56.893949
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'
            self.test_attr6 = 'test_attr6'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2', 'test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test_dict['test_attr3'] == 'test_attr3'