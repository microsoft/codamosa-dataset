

# Generated at 2022-06-17 15:04:05.290343
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'
            self.f = 'f'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['d', 'e', 'f'])
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert 'd' not in test_dict
    assert 'e' not in test_dict
    assert 'f' not in test_dict



# Generated at 2022-06-17 15:04:16.762880
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:04:26.888092
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:04:34.943702
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=12) == 12
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('10.5%', 100, min_value=2) == 11
    assert pct_to_int('10.5%', 100, min_value=12) == 12
    assert pct_to_int('10.5%', 100, min_value=13) == 13
    assert p

# Generated at 2022-06-17 15:04:47.291287
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=12) == 12
    assert pct_to_int('10%', 100, min_value=13) == 13
    assert pct_to_int('10%', 100, min_value=14) == 14
    assert pct_to_int('10%', 100, min_value=15) == 15
    assert pct_to_int('10%', 100, min_value=16) == 16
    assert pct_

# Generated at 2022-06-17 15:04:59.530153
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 10, min_value=10) == 10
    assert pct_to_int('50%', 1) == 1
    assert pct_to_int('50%', 1, min_value=10) == 10
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, min_value=10) == 50
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(50, 10, min_value=10) == 10
    assert p

# Generated at 2022-06-17 15:05:12.079351
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=12) == 12
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=11) == 11
    assert pct_to_int('1%', 100, min_value=12) == 12

# Generated at 2022-06-17 15:05:22.634469
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:05:34.407674
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0.1%', 100, min_value=2) == 2
    assert pct_to_int('0.5%', 100, min_value=2) == 2
    assert pct_to_int('0.9%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=2) == 2

# Generated at 2022-06-17 15:05:43.148199
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26


# Generated at 2022-06-17 15:05:58.192925
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:01.665439
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, ['c'])
    assert test_dict == {'a': 'a', 'b': 'b', 'd': 'd'}

# Generated at 2022-06-17 15:06:11.671535
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 5, 4, 5]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:22.362876
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:31.349956
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:36.970207
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 4, 5, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 1, 1, 1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:47.217503
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:56.598297
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict

# Generated at 2022-06-17 15:07:07.939712
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 1, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 1, 6, 2, 1, 2, 3, 2, 1, 4, 5, 1, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 1, 6, 2, 1, 2, 3, 2, 1, 4, 5, 1, 6, 1, 2, 3, 2, 1, 4, 5, 1, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:14.413146
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['c'])
    assert test_dict == {'a': 'a', 'b': 'b', 'd': 'd'}

# Generated at 2022-06-17 15:07:25.280013
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    obj = TestClass()
    obj_dict = object_to_dict(obj, exclude=['test_attr3'])
    assert obj_dict['test_attr'] == 'test_attr'
    assert obj_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in obj_dict
    assert obj_dict['test_attr4'] == 'test_attr4'

# Generated at 2022-06-17 15:07:36.344562
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'a', 'b']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 15:07:42.007147
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'
            self.test_attr6 = 'test_attr6'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3', 'test_attr5'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert test_

# Generated at 2022-06-17 15:07:47.147552
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_key2'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict

# Generated at 2022-06-17 15:07:57.992075
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4', 'test_attr5'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:08:10.204225
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = "test_attr"
            self.test_attr2 = "test_attr2"
            self.test_attr3 = "test_attr3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == "test_attr"
    assert test_dict['test_attr2'] == "test_attr2"
    assert test_dict['test_attr3'] == "test_attr3"

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == "test_attr"
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:08:20.180710
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:08:27.177773
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'

    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict
    assert test_dict['test_attr2'] == 'test_attr2'

# Generated at 2022-06-17 15:08:36.552064
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a', 'b', 'c']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 15:08:48.589630
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'test_attr': 'test_attr', 'test_attr2': 'test_attr2', 'test_attr3': 'test_attr3', 'test_attr4': 'test_attr4'}
    assert object_to_dict(test_obj, exclude=['test_attr2', 'test_attr3']) == {'test_attr': 'test_attr', 'test_attr4': 'test_attr4'}

# Generated at 2022-06-17 15:09:02.395890
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:12.012140
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:09:20.974079
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 6, 5, 4, 7, 8, 9, 9, 8, 7]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:09:32.783023
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:43.486092
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_var = 'test'
            self.test_var2 = 'test2'
            self._test_var3 = 'test3'
    obj = TestClass()
    assert object_to_dict(obj) == {'test_var': 'test', 'test_var2': 'test2'}
    assert object_to_dict(obj, exclude=['test_var2']) == {'test_var': 'test'}

# Generated at 2022-06-17 15:09:56.816967
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:10:06.934878
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:18.433910
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:10:28.098256
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-17 15:10:35.837120
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_prop = 'test_value'
            self.test_prop2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_prop'] == 'test_value'
    assert test_dict['test_prop2'] == 'test_value2'

    test_dict = object_to_dict(test_obj, exclude=['test_prop'])
    assert 'test_prop' not in test_dict
    assert test_dict['test_prop2'] == 'test_value2'

# Generated at 2022-06-17 15:10:48.869046
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:10:56.767667
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self.test_property3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict
    assert test_dict['test_property3'] == 'test_value3'

# Generated at 2022-06-17 15:11:04.408934
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:11:10.040349
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:11:19.706419
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]

# Generated at 2022-06-17 15:11:27.784637
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:39.156977
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]

# Generated at 2022-06-17 15:11:47.759888
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:11:59.402173
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:10.146942
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26


# Generated at 2022-06-17 15:12:30.556312
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:39.511110
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:48.537171
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:57.273464
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test_dict['test_attr3'] == 'test_attr3'

# Generated at 2022-06-17 15:13:06.779286
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:13:17.502588
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:13:25.150086
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:13:36.123865
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:46.848392
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 9, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:56.708503
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]