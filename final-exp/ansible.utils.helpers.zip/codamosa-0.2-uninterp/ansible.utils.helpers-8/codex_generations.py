

# Generated at 2022-06-17 15:04:12.583501
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:04:23.754413
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10

# Generated at 2022-06-17 15:04:33.283121
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict

# Generated at 2022-06-17 15:04:46.615063
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
   

# Generated at 2022-06-17 15:04:54.840335
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100, min_value=1) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=3) == 3
    assert pct_

# Generated at 2022-06-17 15:05:02.394426
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101
    assert pct_to_int('-1%', 100) == -1

# Generated at 2022-06-17 15:05:13.184679
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10%', 100, min_value=2) == 2
    assert pct_to_int('10%', 100, min_value=3) == 3
    assert pct_

# Generated at 2022-06-17 15:05:23.214576
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101

# Generated at 2022-06-17 15:05:34.410490
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3', 'test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict
    assert test_dict

# Generated at 2022-06-17 15:05:41.866006
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['a', 'b', 'c'])
    assert test_dict == {'d': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10}

# Generated at 2022-06-17 15:05:57.298893
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 4, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:06.941391
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:15.040144
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:06:23.137269
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:31.722349
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'a', 'b', 'c', 'a', 'b', 'a', 'c', 'b', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-17 15:06:42.369241
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:52.481130
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:00.393533
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4'])

    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'
    assert 'test_attr4' not in test_dict


# Generated at 2022-06-17 15:07:11.136513
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:07:21.430558
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:07:39.799110
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:07:44.337377
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 6, 1]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 6, 1, 2]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:53.565876
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:00.975540
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:12.326583
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:22.410116
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:33.484471
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:47.350495
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:08:58.195071
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:03.101242
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:25.505676
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:09:34.545238
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 7, 7, 8, 9, 9, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 7, 7, 8, 9, 9, 9, 10, 10, 10, 10, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:47.033328
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'e', 'a', 'b', 'c', 'a', 'b', 'd', 'c', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 15:09:55.175071
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert dedupl

# Generated at 2022-06-17 15:10:06.565157
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:10:17.860881
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:27.714058
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:36.787049
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:47.741909
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 4, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:58.103287
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 5, 1, 2, 3]) == [1, 2, 3, 4, 5]
   

# Generated at 2022-06-17 15:11:27.385132
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:11:38.610971
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:11:47.311815
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:58.733266
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'a', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c', 'd']
   

# Generated at 2022-06-17 15:12:05.831380
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 3, 2, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 3, 2, 1, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:15.463083
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:19.674381
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,4,5,6,7,8,9,10]) == [1,2,3,4,5,6,7,8,9,10]
    assert deduplicate_list([1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10]) == [1,2,3,4,5,6,7,8,9,10]

# Generated at 2022-06-17 15:12:30.691972
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:12:35.237688
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-17 15:12:41.638766
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:36.084920
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 2, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:46.865198
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:13:56.769248
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert ded

# Generated at 2022-06-17 15:14:06.202750
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]